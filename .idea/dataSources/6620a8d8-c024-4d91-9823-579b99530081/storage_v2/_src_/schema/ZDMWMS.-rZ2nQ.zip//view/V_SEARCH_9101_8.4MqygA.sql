create view V_SEARCH_9101_8 as
select atc.owner_article_no,
       atc.article_name,
       sai.barcode,
       sc.packing_qty,
       atcp.packing_unit,
       to_char(sai.produce_date, 'yyyyMMdd') produce_date,
       to_date(to_char(sai.rgst_date, 'yyyyMMdd'), 'yyyyMMdd') indate,
       case when sai.lot_no='N' then to_char(sai.produce_date,'yyyy-MM-dd') else sai.lot_no end lot_no,
       sum(case when QUALITY='B' then sc.qty else 0 end) DM,
       sum(case when QUALITY='0' then mod(sc.qty,sc.packing_qty) else 0 end) NR,
       sum(case when QUALITY='0' then floor(sc.qty/sc.packing_qty) else 0 end) NRM,
       sum(case when QUALITY='A' then sc.qty else 0 end) QA,
       sum(sc.qty) sumqty,
       sc.warehouse_no,
       sc.enterprise_no,
       sc.owner_no,
       max(case when QUALITY='0' then 0 else 1 end) orderid
  from stock_content        sc,
       bdef_defarticle      atc,
       bdef_article_packing atcp,
       stock_article_info   sai
 where sc.enterprise_no = atc.enterprise_no
   and sc.owner_no = atc.owner_no
   and sc.article_no = atc.article_no
   and atc.article_no = atcp.article_no
   and sc.enterprise_no = atcp.enterprise_no
   and sc.packing_qty = atcp.packing_qty
  and sc.enterprise_no = sai.enterprise_no
  and  sc.article_no = sai.article_no
   and sc.article_id = sai.article_id
 group by atc.owner_article_no,
          atc.article_name,
          sai.barcode,
          sc.packing_qty,
          atcp.packing_unit,
          to_char(sai.produce_date, 'yyyyMMdd'),
          to_date(to_char(sai.rgst_date, 'yyyyMMdd'), 'yyyyMMdd'),
          case when sai.lot_no='N' then to_char(sai.produce_date,'yyyy-MM-dd') else sai.lot_no end,
          sc.warehouse_no,
          sc.enterprise_no,
          sc.owner_no
 order by orderid,atc.owner_article_no


/

