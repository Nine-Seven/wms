create procedure        p_getPackMate(strEnterpriseNo in stock_label_m.enterprise_no%type,
                                          strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                                          strSLabel_No    in stock_label_m.label_no%type, --源容器号
                                          strPackMateNo   out bdef_defarticle.article_no%type,
                                          strPackMateName out bdef_defarticle.article_name%type, --目的容器号
                                          nPackMateQTY    out integer, --数量（预留）
                                          strResult       out varchar2) is

  v_BoxVol      bdef_defarticle.unit_volumn%type;
  v_ArticleName bdef_defarticle.article_name%type;
  v_ArticleNo   bdef_defarticle.article_no%type;
  v_Owner_No    bdef_defowner.owner_no%type;

begin

  strResult    := 'N|p_getPackMate';
  nPackMateQTY := 1;
  strResult    := 'Y|成功';

  --商品材积
  select sum(bda.unit_volumn +
             bda.cumulative_volumn * (sld.qty - bda.qmin_operate_packing)),
         max(sld.owner_no)
    into v_BoxVol, v_Owner_No
    from bdef_defarticle bda, stock_label_d sld, stock_label_m slm
   where bda.enterprise_no = sld.enterprise_no
     and bda.article_no = sld.article_no
     and sld.container_no = slm.container_no
     and sld.enterprise_no = slm.enterprise_no
     and sld.warehouse_no = slm.warehouse_no
     and slm.enterprise_no = strEnterpriseNo
     and slm.warehouse_no = strWarehouseNo
     and slm.label_no = strSLabel_No;

  --可装下的最小包材
  /* begin
    select t.article_no, t.article_name
      into v_ArticleNo, v_ArticleName
      from (select (bap.a_length * bap.a_width * bap.a_height) v_PackVol,
                   bda.article_name,bda.article_no
              from bdef_article_packing bap, bdef_defarticle bda
             where bda.enterprise_no = bap.enterprise_no
               and bda.article_no = bap.article_no
               and bda.enterprise_no = strEnterpriseNo
               and bda.virtual_flag = '2' --包材
               and bda.status = '0'
               and (bap.a_length * bap.a_width * bap.a_height) >= v_BoxVol
             order by (bap.a_length * bap.a_width * bap.a_height)) t
     where rownum <= 1;
  exception
    when no_data_found then
      v_ArticleNo:='N';
      v_ArticleName := 'N';
  end;*/

  --使用本业主包材
  begin
    select t.article_no, t.article_name||'('||t.barcode||')'
      into v_ArticleNo, v_ArticleName
      from (select bda.unit_volumn, bda.article_name, bda.article_no,bda.barcode
              from bdef_defarticle bda
             where bda.enterprise_no = strEnterpriseNo
               and bda.virtual_flag = '2' --包材
               and bda.status = '0'
               and bda.unit_volumn >= v_BoxVol
               and bda.owner_no = v_Owner_No
             order by bda.unit_volumn) t
     where rownum <= 1;
  exception
    when no_data_found then
      v_ArticleNo   := 'N';
      v_ArticleName := 'N';
  end;

  --没有包材可装下，取最大包材名称
  if v_ArticleName = 'N' then
    begin
      select t.article_no, t.article_name||'('||t.barcode||')'
        into v_ArticleNo, v_ArticleName
        from (select bda.article_name, bda.article_no,bda.barcode
                from bdef_defarticle bda
               where bda.enterprise_no = strEnterpriseNo
                 and bda.virtual_flag = '2' --包材
                 and bda.status = '0'
                 and bda.owner_no = v_Owner_No
               order by bda.unit_volumn desc) t
       where rownum <= 1;
    exception
      when no_data_found then
        v_ArticleName := 'N';
        v_ArticleNo   := 'N';
    end;
  end if;

  if v_ArticleName = 'N' then
    --使用其它业主包材
    begin
      select t.article_no, t.article_name ||'('||t.barcode||')'
        into v_ArticleNo, v_ArticleName
        from (select bda.unit_volumn, bda.article_name, bda.article_no,
                     bda.barcode
                from bdef_defarticle bda, WMS_DEFPACKMETE w
               where W.ENTERPRISE_NO = BDA.ENTERPRISE_NO
                 AND W.WAREHOUSE_NO = strWarehouseNo
                 and w.packmete_owner_no = bda.owner_no
                 and w.status = '1'
                 and w.container_material = bda.rsv_attr1 --暂定
                 and w.use_owner_no = v_Owner_No
                 and bda.enterprise_no = strEnterpriseNo
                 and bda.virtual_flag = '2' --包材
                 and bda.status = '0'
               order by case
                          when bda.unit_volumn >= v_BoxVol then
                           0
                          else
                           1
                        end,
                        bda.unit_volumn) t
       where rownum <= 1;
    exception
      when no_data_found then
        v_ArticleName := 'N';
        v_ArticleNo   := 'N';
    end;
  end if;

  strPackMateNo   := v_ArticleNo;
  strPackMateName := v_ArticleName;

exception
  when others then
    strResult := 'N|' || SQLERRM ||
                 substr(dbms_utility.format_error_backtrace, 1, 256);
end;


/

