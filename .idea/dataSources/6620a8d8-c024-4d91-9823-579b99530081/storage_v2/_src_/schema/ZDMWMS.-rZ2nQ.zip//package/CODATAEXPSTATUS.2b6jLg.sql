create PACKAGE        COdataExpStatus IS

        -- 转病单（写病单指示)
         CancelDierct CONSTANT odata_exp_m.STATUS%TYPE := '90';

        -- 病单发单
         CancelGetTask CONSTANT odata_exp_m.STATUS%TYPE := '92';

         --病单处理
         CancelManage CONSTANT odata_exp_m.STATUS%TYPE := '94';

         --单据取消
         CancelClose  CONSTANT odata_exp_m.STATUS%TYPE := '16';

         --单据结案
         EndExp       CONSTANT odata_exp_m.STATUS%TYPE := '13';

         --出货调度
         ColletExp    CONSTANT odata_exp_m.STATUS%TYPE := '11';

         --定位

         locateExp    CONSTANT odata_exp_m.STATUS%TYPE := '12';

         CancelMiddStatus CONSTANT odata_exp_m.STATUS%TYPE := 'FF';

         /*出货单据跟踪状态 huangb 20160629*/
         --00:初始状态
         ExpTracFirst       CONSTANT ODATA_EXP_STATUS.Curr_Status%TYPE := '00';
         --05:部分分配
         ExpTracPartAllot   CONSTANT ODATA_EXP_STATUS.Curr_Status%TYPE := '05';
         --10:已分配
         ExpTracAllAllot    CONSTANT ODATA_EXP_STATUS.Curr_Status%TYPE := '10';
         --15:部分发单
         ExpTracPartSend    CONSTANT ODATA_EXP_STATUS.Curr_Status%TYPE := '15';
         --20:已发单
         ExpTracAllSend     CONSTANT ODATA_EXP_STATUS.Curr_Status%TYPE := '20';
         --25:部分回单
         ExpTracPartReceipt CONSTANT ODATA_EXP_STATUS.Curr_Status%TYPE := '25';
         --30:已回单
         ExpTracALLReceipt  CONSTANT ODATA_EXP_STATUS.Curr_Status%TYPE := '30';
         --35:部分分播
         ExpTracPartDivide  CONSTANT ODATA_EXP_STATUS.Curr_Status%TYPE := '35';
         --40:已分播
         ExpTracAllDivide   CONSTANT ODATA_EXP_STATUS.Curr_Status%TYPE := '40';
         --45:部分复核
         ExpTracPartCheck   CONSTANT ODATA_EXP_STATUS.Curr_Status%TYPE := '45';
         --50:已复核
         ExpTracAllCheck    CONSTANT ODATA_EXP_STATUS.Curr_Status%TYPE := '50';
         --55:部分装车
         ExpTracPartLoad    CONSTANT ODATA_EXP_STATUS.Curr_Status%TYPE := '55';
         --60:已装车
         ExpTracAllLoad     CONSTANT ODATA_EXP_STATUS.Curr_Status%TYPE := '60';
         --65:部分封车
         ExpTracPartDeliver CONSTANT ODATA_EXP_STATUS.Curr_Status%TYPE := '65';
         --70:已封车
         ExpTracAllDeliver  CONSTANT ODATA_EXP_STATUS.Curr_Status%TYPE := '70';
         --90:取消
         ExpTracCancel      CONSTANT ODATA_EXP_STATUS.Curr_Status%TYPE := '90';
         --98:部分转病单
         ExpTracPartIllness CONSTANT ODATA_EXP_STATUS.Curr_Status%TYPE := '98';
         --99:病单
         ExpTracAllIllness  CONSTANT ODATA_EXP_STATUS.Curr_Status%TYPE := '99';
         /*出货单据跟踪状态 huangb 20160629*/

end COdataExpStatus;


/

