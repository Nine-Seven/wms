create trigger TRG_STOCK_LABEL_M_SERIAL
    before insert
    on STOCK_LABEL_M
    for each row
declare
  i_report_up_SERIAL NUMBER;
begin
  select SEQ_STOCK_LABEL_M.NEXTVAL into i_report_up_SERIAL from dual;
  :NEW.REPORT_UP_SERIAL := i_report_up_SERIAL;
end TRG_STOCK_LABEL_M_SERIAL;


/

