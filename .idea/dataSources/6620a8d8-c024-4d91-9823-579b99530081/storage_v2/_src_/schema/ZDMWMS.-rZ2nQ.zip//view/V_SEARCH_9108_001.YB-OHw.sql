create view V_SEARCH_9108_001 as
select c."ENTERPRISE_NO",
       c."WAREHOUSE_NO",
       c."PLAN_NO",
       c."REQUEST_NO",
       c."CHECK_NO",
       c."CELL_NO",
       c."ARTICLE_NO",
       c."PACKING_QTY",
       c."LABEL_NO",
       c."PRODUCE_DATE",
       c."EXPIRE_DATE",
       c."QUALITY",
       c."ARTICLE_QTY",
       c."REAL_QTY",
       c."CHECK_QTY",
       c."CHECK_WORKER",
       c."CHECK_DATE",
       c."RECHECK_QTY",
       c."RECHECK_WORKER",
       c."RECHECK_DATE",
       c."THIRD_QTY",
       c."THIRD_WORKER",
       c."THIRD_DATE",
       c."DIFF_QTY",
       c.serial_no,-----流水号
       c.fcdata_type，------盘点类型
       bda.barcode,
       bda.rsv_attr2,
       bda.article_name,
       b1.worker_name as check_worker_name,
       b2.worker_name as recheck_worker_name,
       b3.worker_name as third_worker_name,
       trunc(fm.plan_date) as plan_date
  from (select m.enterprise_no,
               m.warehouse_no,
               m.plan_no,
               m.request_no,
               m.check_no,
               m.serial_no,--流水号
               m.fcdata_type,---盘点类型
               d.cell_no,
               d.article_no,
               d.packing_qty,
               d.label_no,
               d.produce_date,
               d.expire_date,
               d.quality,
               d.article_qty,
               d.real_qty,
               d.check_qty,
               d.check_worker,
               d.check_date,
               d.recheck_qty,
               d.recheck_worker,
               d.recheck_date,
               d.third_qty,
               d.third_worker,
               d.third_date,
               d.real_qty - d.article_qty as diff_qty
          from fcdata_check_d d, fcdata_check_m m
         where d.enterprise_no = m.enterprise_no
           and d.warehouse_no = m.warehouse_no
           and d.check_no = m.check_no
         order by m.plan_no,
                  m.request_no,
                  m.check_no,
                  d.cell_no,
                  d.label_no,
                  d.article_no,
                  d.packing_qty) c
 inner join fcdata_plan_m fm
    on fm.enterprise_no = c.enterprise_no
   and fm.warehouse_no = c.warehouse_no
   and fm.plan_no = c.plan_no
 inner join bdef_defarticle bda
    on bda.enterprise_no = c.enterprise_no
   and bda.article_no = c.article_no
  left join bdef_defworker b1
    on b1.enterprise_no = c.enterprise_no
   and b1.worker_no = c.check_worker
  left join bdef_defworker b2
    on b2.enterprise_no = c.enterprise_no
   and b2.worker_no = c.recheck_worker
  left join bdef_defworker b3
    on b3.enterprise_no = c.enterprise_no
   and b3.worker_no = c.third_worker


/

