create trigger DELETE_TIGGER_CDEF_DEFWARE
    before delete
    on CDEF_DEFWARE
    for each row
declare
  -- local variables here
  n_count        number(10); --记录数，以做判断;
--  strOutMsg      varchar(500) ;
begin
    n_count:=0 ;
/*    --判断仓区号是否存在
    select count(*) into n_count from cdef_defware where Warehouse_No =:old.warehouse_no and ware_no=:old.ware_no;
    if n_count=0 then
       RAISE_APPLICATION_ERROR(-50003,'N|删除的仓库编码不存在！');
      return;
    end if ;*/

    --判断当前仓区对应的储位是否有库存。
     select count(cc.cell_no) into n_count from stock_content cc,cdef_defcell cdc
      where cc.enterprise_no=cdc.enterprise_no
        and cc.Warehouse_No=cdc.Warehouse_No
        and cc.cell_no=cdc.cell_no
        and cdc.enterprise_no=:old.enterprise_no
        and cdc.Warehouse_No=:old.warehouse_no
        and cdc.ware_no=:old.ware_no  and  rownum=1 ;
     if n_count>0 then
        RAISE_APPLICATION_ERROR(-50003,'N|删除仓区对应的储位还存在库存，不能删除！');
        return;
     end if ;
    ----------------------------------删除对应的储位数据-------------------------------------------
    delete from  cdef_defcell where enterprise_no=:old.enterprise_no and warehouse_no=:old.warehouse_no and ware_no=:old.ware_no ;
    ----------------------------------删除对应的通道数据-------------------------------------------
    /*delete from  cdef_defstock where warehouse_no=:old.warehouse_no and   ware_no=:old.ware_no ;*/
    ----------------------------------删除对应的区域数据-------------------------------------------
    /*delete from  cdef_defarea where warehouse_no=:old.warehouse_no and   ware_no=:old.ware_no ;*/
    ----------------------------------删除仓区数据-------------------------------------------
   -- delete from  CDEF_DEFWARE  where Warehouse_No=:old.warehouse_no and   ware_no=:old.ware_no ;

end delete_tigger_CDEF_DEFWARE;


/

