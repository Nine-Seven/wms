create FUNCTION        add_three_numbers
(
a NUMBER:=0, b NUMBER:=0, c NUMBER:=0
)
RETURN NUMBER IS
BEGIN
       RETURN a+b+c;
END;


/

