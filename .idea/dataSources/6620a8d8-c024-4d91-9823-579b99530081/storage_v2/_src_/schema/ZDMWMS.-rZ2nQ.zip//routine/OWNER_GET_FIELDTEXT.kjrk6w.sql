create function        owner_get_fieldtext(v_tablename in varchar2,v_field in varchar2)
    return varchar2
    is
    v_text            VARCHAR(256);
    begin
       select field_name into v_text from wms_deffielddesc where table_name=v_tablename and field_id=upper(v_field);
       return v_text;
    end;


/

