create function EAN14(strEnterpriseNo VARCHAR2,strOwnerNo VARCHAR2,ART_NO VARCHAR2) return varchar2 is
    Result varchar2(13);
    ean    integer;
    artno  char(7);
  begin
    if ART_NO = 1 then--货主商品编号
      begin
         select
          max(t.owner_article_no)+1
         into ean
         from
         bdef_defarticle t
         where  t.enterprise_no=strEnterpriseNo;
      exception
      when no_data_found then
        ean := 1;
      end;

       if ean is null then
         ean:=1;
       end if;

    elsif ART_NO = 2 then--客户
      begin
         select nvl(max(lpad(substr(t.cust_no, -5, 5), 5, 0)),0) + 1
           into ean
           from bdef_defcust t
          where t.enterprise_no = strEnterpriseNo
          and t.owner_no=strOwnerNo;
      exception
      when no_data_found then
        ean := 1;
      end;

      if ean is null then
         ean:=1;
       end if;

    else--供应商

      begin
         select max(substr(t.supplier_no, 2, 5)) + 1
           into ean
           from bdef_defsupplier t
          where t.owner_no = strOwnerNo
            and t.enterprise_no = strEnterpriseNo;
      exception
      when no_data_found then
        ean := 1;
      end;
      if ean is null then
         ean:=1;
       end if;
    end if;

    if ART_NO = 1 then--货主商品编号商品
       select
        LPAD (to_char(ean) , 7 , '0')
      INTO RESULT
      FROM DUAL;
    elsif ART_NO = 2 then  --客户编号
      select
        'C' || LPAD (to_char(ean) , 5 , '0')
      INTO RESULT
      FROM DUAL;
    else --供应商编号
      select
        'S' || LPAD (to_char(ean) , 5 , '0')
      INTO RESULT
      FROM DUAL;
    end if;
    return(Result);
  end EAN14;


/

