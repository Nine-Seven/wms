create package body        PKLG_REPORT is
  ---------------------------------------------------------------------------
  --Create MM,20131118
  --Modify by
  ---------------------------------------------------------------------------
  PROCEDURE P_Create_ArticlInvAcc_View(beginDate in stock_content_rj.jc_date%type, --查询日期
                                       endDate   in stock_content_rj.jc_date%type,
                                       strOutMsg   out varchar2) IS
    V_SQL        VARCHAR2(32767);
    v_beginDay       integer;
    v_beginMonth     integer;
    v_beginYear      integer;
    v_endDay         integer;
    v_endMonth       integer;
    v_endYear        integer;

    v_maxDays        integer; --月份的最大天数

  BEGIN
    strOutMsg:='Y|';
    select extract(day from beginDate),extract(month from beginDate),extract(year from beginDate),
           extract(day from endDate),extract(month from endDate),extract(year from endDate)
      INTO v_beginDay,v_beginMonth,v_beginYear,v_endDay,v_endMonth,v_endYear
      from dual;

   -- V_SQL := 'select a.warehouse_no,a.owner_no,a.article_no ';



    if v_beginYear = v_endYear then
        if v_beginMonth = v_endMonth then
            for i in v_beginDay .. v_endDay loop
                --期初库存
                if i=v_beginDay then
                   P_CreatSql(v_beginMonth,i,'1',V_SQL);
                end if;
                --出入库
                P_CreatSql(v_beginMonth,i,'2',V_SQL);
                --结存库存
                if i = v_endDay then
                   P_CreatSql(v_beginMonth,i,'4',V_SQL);
                end if;
            end loop;
        else --同年不同月
           for i in v_beginMonth .. v_endMonth loop
              --获取月的天数
              P_GetMaxDay(v_beginYear,i,v_maxDays);

              if i=v_beginMonth then
                for j in v_beginDay .. v_maxDays loop
                   --期初库存
                   if j=v_beginDay then
                     P_CreatSql(i,j,'1',V_SQL);
                   end if;
                   --出入库
                   P_CreatSql(i,j,'2',V_SQL);
                end loop;

              elsif i=v_endMonth then
                  for j in 1 .. v_endDay loop
                   --出入库
                   P_CreatSql(i,j,'2',V_SQL);
                   --结存库存
                   if j = v_endDay then
                     P_CreatSql(i,j,'4',V_SQL);
                end if;
                 end loop;
              else
                for j in 1 .. v_maxDays loop
                    --出入库
                   P_CreatSql(i,j,'2',V_SQL);
                end loop;
              end if;
           end loop;
        end if;
    else
      --跨年
      for i in v_beginYear .. v_endYear loop  --第一年
         if i=v_beginYear then
           for j in v_beginMonth .. 12 loop
              --获取月的天数
              P_GetMaxDay(i,j,v_maxDays);
             if j=v_beginMonth   then         --第一年的开始月
                for x in v_beginDay .. v_maxDays loop
                   --期初库存
                   if x=v_beginDay then
                     P_CreatSql(j,x,'1',V_SQL);
                   end if;
                   --出入库
                   P_CreatSql(j,x,'2',V_SQL);
                end loop;
             else
               for x in 1 .. v_maxDays loop
                  --出入库
                  P_CreatSql(j,x,'2',V_SQL);
               end loop;
             end if;
           end loop;
         elsif i=v_endYear then             --最后一年
           for j in 1 .. v_endMonth loop
              P_GetMaxDay(i,j,v_maxDays);
             if j= v_endMonth then            --最后一年的最后一月
               for x in 1 .. v_endDay loop
                   --出入库
                  P_CreatSql(j,x,'2',V_SQL);
                  --结存库存
                  if x=v_endDay then
                      P_CreatSql(j,x,'4',V_SQL);
                  end if;
               end loop;
             else
                for x in 1 .. v_maxDays loop
                  --出入库
                  P_CreatSql(j,x,'2',V_SQL);

                end loop;
             end if;
           end loop;
         else
            for j in 1 .. 12 loop
             P_GetMaxDay(i,j,v_maxDays);
             for x in 1 .. v_maxDays loop
                  --出入库
                  P_CreatSql(j,x,'2',V_SQL);
                end loop;
           end loop;
         end if;
      end loop;
    end if;
    ------------------------------------------------------------------------------

    V_SQL := 'select a.warehouse_no,a.owner_no,a.article_no '||V_SQL || ' from stock_content_rj a ,bdef_defarticle b
    where 1=1
    and a.enterprise_no=b.enterprise_no
    and a.article_no=b.article_no
    and a.jc_date between ''' || beginDate || ''' and ''' ||
             endDate ||
             ''' group by a.warehouse_no,a.owner_no,a.article_no,b.unit_weight';
    V_SQL := 'CREATE OR REPLACE VIEW v_articlInvAcc  AS ' || V_SQL;
    DBMS_OUTPUT.PUT_LINE(V_SQL);
    EXECUTE IMMEDIATE V_SQL;
    exception
    when others then
      strOutMsg := V_SQL;
      return;
    strOutMsg := 'Y';
  END P_Create_ArticlInvAcc_View;

  --获取当月最大天数
  PROCEDURE P_GetMaxDay (strYear   in integer,
               strMonth  in integer,
               strDay    out integer) IS
   begin

   if (strMonth=1) or (strMonth=3) or (strMonth=5) or (strMonth=7) or (strMonth=8) or (strMonth=10) or (strMonth=12) then
      strDay:=31;
   elsif (strMonth=4) or (strMonth=6) or (strMonth=9) or (strMonth=11) then
      strDay:=30;
   else
     if (mod(strYear,4)=0 and  mod(strYear,100)<>0) or mod(strYear,100)=0 then
       strDay:=29;
     else
       strDay:=28;
     end if;
   end if;

   end P_GetMaxDay;

   --拼接SQL
   PROCEDURE P_CreatSql(
               strMonth  in integer,
               strDay    in integer,
               strFlag   in varchar2, --1：初期库存；2：出入库，；4：结算库存
               strSql    in out VARCHAR2 ) is
   begin

   if strFlag='1' then
      strSql := strSql|| ',' || 'sum(decode(lpad(extract(month from a.jc_date),2,''0'')||lpad(extract(day from a.jc_date),2,''0''),' ||
               lpad(strMonth,2,'0')|| lpad(strDay,2,'0') ||',a.qc_qty,0)) as qcqty';
      strSql := strSql || ',' || 'sum(decode(lpad(extract(month from a.jc_date),2,''0'')||lpad(extract(day from a.jc_date),2,''0''),' ||
               lpad(strMonth,2,'0')|| lpad(strDay,2,'0') ||',a.qc_qty,0))*b.unit_weight as QCWEIGHT';

   elsif strFlag='2' then
      strSql := strSql || ',' || 'sum(decode(lpad(extract(month from a.jc_date),2,''0'')||lpad(extract(day from a.jc_date),2,''0''),' ||
                lpad(strMonth,2,'0')|| lpad(strDay,2,'0') ||',a.in_qty,0)) as inqtyday' ||  lpad(strMonth,2,'0')|| lpad(strDay,2,'0');
      strSql := strSql || ',' || 'sum(decode(lpad(extract(month from a.jc_date),2,''0'')||lpad(extract(day from a.jc_date),2,''0''),'||
                lpad(strMonth,2,'0')|| lpad(strDay,2,'0') ||',a.in_qty,0))*b.unit_weight as INWEIGHT' ||  lpad(strMonth,2,'0')|| lpad(strDay,2,'0');
      strSql := strSql || ',' ||'sum(decode(lpad(extract(month from a.jc_date),2,''0'')||lpad(extract(day from a.jc_date),2,''0''),'||
                         lpad(strMonth,2,'0')|| lpad(strDay,2,'0') ||',a.out_qty,0)) as outqtyday' || lpad(strMonth ,2,'0')|| lpad(strDay,2,'0');
      strSql := strSql || ',' || 'sum(decode(lpad(extract(month from a.jc_date),2,''0'')||lpad(extract(day from a.jc_date),2,''0''),'||
                         lpad(strMonth ,2,'0')|| lpad(strDay,2,'0') ||',a.out_qty,0))*b.unit_weight as OUTWEIGHT' || lpad(strMonth,2,'0')|| lpad(strDay,2,'0');
   elsif strFlag='4' then
       strSql := strSql || ',' || 'sum(decode(lpad(extract(month from a.jc_date),2,''0'')||lpad(extract(day from a.jc_date),2,''0''),'||
                             lpad(strMonth,2,'0')|| lpad(strDay,2,'0') ||',a.qty,0)) as qty';
        strSql := strSql || ',' || 'sum(decode(lpad(extract(month from a.jc_date),2,''0'')||lpad(extract(day from a.jc_date),2,''0''),' ||
                            lpad(strMonth,2,'0')|| lpad(strDay,2,'0') ||',a.qty,0))*b.unit_weight as WEIGHT';
   end if;

   end P_CreatSql;

end PKLG_REPORT;

/

