create package        PKLG_ADJ is

  -- Author  : LUOZL
  -- Created : 2014-12-30 18:18:59
  -- Purpose :

/***********************************************************************************************************
创建人：luozhiling
创建时间：2014.12.30
功能说明：
*************************************************************************************************************/
    procedure P_SaveStockAdj(
           strEnterpriseNo      in        stock_adj_m.enterprise_no%type,
           strWareHouseNo       in        stock_adj_m.warehouse_no%type,
           strOwnerNo           in        stock_adj_m.owner_no%type,
           strAdjType           in        stock_adj_m.adj_type%type,
           strArticleNo         in        stock_adj_d.article_no%type,
           strBarcode           in        stock_adj_d.barcode%type,
           nPackingQty          in        stock_adj_d.packing_qty%type,
           dtProduceDate        in        stock_adj_d.produce_date%type,
           dtExpireDate         in        stock_adj_d.expire_date%type,
           strQuality           in        stock_adj_d.quality%type,
           strLotNo             in        stock_adj_d.lot_no%type,
           strRsvBatch1         in        stock_adj_d.rsv_batch1%type,
           strRsvBatch2         in        stock_adj_d.rsv_batch1%type,
           strRsvBatch3         in        stock_adj_d.rsv_batch1%type,
           strRsvBatch4         in        stock_adj_d.rsv_batch1%type,
           strRsvBatch5         in        stock_adj_d.rsv_batch1%type,
           strRsvBatch6         in        stock_adj_d.rsv_batch1%type,
           strRsvBatch7         in        stock_adj_d.rsv_batch1%type,
           strRsvBatch8         in        stock_adj_d.rsv_batch1%type,
           strCellNo            in        stock_adj_d.cell_no%type,
           nPlanQty             in        stock_adj_d.plan_qty%type,
           strStockType         in        stock_adj_d.stock_type%type,
           strStockValue        in        stock_adj_d.stock_value%type,
           strLabelNo           in        stock_adj_d.label_no%type,
           strUserId            in        stock_adj_m.rgst_name%type,
           strsAdjNo            in        stock_adj_m.adj_no%type,--
           strAdjNo             out        stock_adj_m.adj_no%type,--
           strResult            out       varchar2);
    procedure P_ComfireAdj(
             strEnterpriseNo        in          stock_adj_d.enterprise_no%type,
             strWareHouseNo         in          stock_adj_d.warehouse_no%type,
             strOwnerNo                           in          stock_adj_m.owner_no%type,
             strAdjNo                             in          stock_adj_m.adj_no%type,
             strUserId                            in          stock_adj_m.rgst_name%type,
             strResult                            out         varchar2);
    procedure P_Comfire_QU_Change(
             strEnterpriseNo      in          ORG_QUALITY_CHANGE_D.enterprise_no%type,
             strWareHouseNo       in          ORG_QUALITY_CHANGE_D.warehouse_no%type,
             strOwnerNo           in          ORG_QUALITY_CHANGE_D.owner_no%type,
             strChange_No         in          ORG_QUALITY_CHANGE_D.Change_No%type,
             strArticleNo         in          ORG_QUALITY_CHANGE_D.article_no%type,
             nRealQty             in          ORG_QUALITY_CHANGE_d.real_qty%type,
             nRow_ID              in          ORG_QUALITY_CHANGE_D.ROW_ID%type,
             strUserId            in          ORG_QUALITY_CHANGE_M.rgst_name%type,
             strResult            out         varchar2)  ;
  /*********************************************************************************************888
   功能说明：建立库存调整计划单
   2015.7.24
  *****************************************************************************************************/
  procedure P_saveStockPlan(strEnterpriseNo      in        stock_adj_m.enterprise_no%type,
         strWareHouseNo       in        stock_plan_d.warehouse_no%type,
         strOwnerNo           in        stock_plan_d.owner_no%type,
         strPlanType          in        stock_plan_m.plan_type%type,
         strPoNo              in        stock_plan_m.po_no%type,
         strArticleNo         in        stock_plan_d.article_no%type,
         nPackingQty          in        stock_plan_d.packing_qty%type,
         dtProduceDate        in        stock_plan_d.produce_date%type,
         dtExpireDate         in        stock_plan_d.expire_date%type,
         strQuality           in        stock_plan_d.quality%type,
         strLotNo             in        stock_plan_d.lot_no%type,
         strImportBatchNo     in        stock_plan_d.import_batch_no%type,
         strRsvBatch1         in        stock_plan_d.rsv_batch1%type,
         strRsvBatch2         in        stock_plan_d.rsv_batch1%type,
         strRsvBatch3         in        stock_plan_d.rsv_batch1%type,
         strRsvBatch4         in        stock_plan_d.rsv_batch1%type,
         strRsvBatch5         in        stock_plan_d.rsv_batch1%type,
         strRsvBatch6         in        stock_plan_d.rsv_batch1%type,
         strRsvBatch7         in        stock_plan_d.rsv_batch1%type,
         strRsvBatch8         in        stock_plan_d.rsv_batch1%type,
         strCellNo            in        stock_plan_d.cell_no%type,
         nPlanQty             in        stock_plan_d.plan_qty%type,
         strStockType         in        stock_plan_d.stock_type%type,
         strStockValue        in        stock_plan_d.stock_value%type,
         strLabelNo           in        stock_plan_d.label_no%type,
         strUserId            in        stock_plan_d.rgst_name%type,
         strCreateFlag        in        stock_plan_m.create_flag%type,--1:下传，0：自建
         strOrgNo             in        stock_plan_m.org_no%type,--机构代码
         strsPlanNo           in        stock_plan_d.plan_no%type,--
         strsRemark           in        stock_plan_m.remark%type,
         strPlanNo            out       stock_plan_d.plan_no%type,--
         strResult            out       varchar2);
  /*******************************************************************************************************
 创建人：luozhiling
 时间:2016.3.14
 功能：库存调账计划单取消
********************************************************************************************************/
  procedure P_PlanCancel(strEnterPriseNo           in    stock_plan_d.enterprise_no%type,
                         strWareHouseNo            in    stock_plan_d.warehouse_no%type,--仓库编码
                         strOwnerNo                in    stock_plan_m.owner_no%type,
                         strPlanNo                 in   stock_plan_d.plan_no%type,--移库计划头档
                         strUserId                 in   stock_plan_d.rgst_name%type,
                         strResult                 OUT    varchar2);

 /*****************************************************************************************************
   创建人：luozhiling
   时间：2015.7.24
   功能: 库存调账定位找库存
 ****************************************************************************************************/
  procedure P_StockPlanfoundStock(strEnterPriseNo           in    stock_plan_d.enterprise_no%type,
                                 strWareHouseNo            in    stock_plan_d.warehouse_no%type,--仓库编码
                                 strOwnerNo                in    stock_plan_m.owner_no%type,
                                 strPlanNo                 in   stock_plan_d.plan_no%type,--移库计划头档
                                 strCellNo                 in   stock_plan_d.cell_no%type,
                                 strUserId                 in   stock_plan_d.rgst_name%type,
                                 strResult                 OUT    varchar2);

  /******************************************************************************************************
  功能说明：库存调账单回单
  2015.7.25

  ******************************************************************************************************/
  procedure P_ComfireStockPlan(
           strEnterpriseNo      in        stock_confirm_m.enterprise_no%type,
           strWareHouseNo       in        stock_confirm_m.warehouse_no%type,
           strOwnerNo           in          stock_confirm_m.owner_no%type,
           strConfirmNo         in          stock_confirm_m.confirm_no%type,
           strUserId            in          stock_confirm_m.rgst_name%type,
           strDockNo            in          bdef_defdock.dock_no%type,
           strPrintFlag         in          stock_plan_m.plan_type%type,--是否打印，1-打印；0：不打印
           strResult            out         varchar2);
  /***********************************************************************************************
  功能：1、对库存调账单进行定位
        2、对库存调账单进行确认
        2015.9.9
  ***********************************************************************************************/
  procedure P_stockLocateComfire(strEnterPriseNo           in    stock_plan_d.enterprise_no%type,
                                 strWareHouseNo            in    stock_plan_d.warehouse_no%type,--仓库编码
                                 strOwnerNo                in    stock_plan_m.owner_no%type,
                                 strPlanNo                 in   stock_plan_d.plan_no%type,--移库计划头档
                                 strCellNo                 in   stock_plan_d.cell_no%type,
                                 strUserId                 in   stock_plan_d.rgst_name%type,
                                 strDockNo                 in          bdef_defdock.dock_no%type,
                                 strPrintFlag              in          stock_plan_m.plan_type%type,--是否打印，1-打印；0：不打印
                                 strResult                 OUT    varchar2);
end PKLG_ADJ;


/

