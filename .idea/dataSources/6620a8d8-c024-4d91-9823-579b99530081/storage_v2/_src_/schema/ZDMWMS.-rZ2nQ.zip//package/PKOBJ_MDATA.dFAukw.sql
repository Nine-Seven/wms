create package        PKOBJ_MDATA is
/**********************************************************************************************************
   luozhiling
   2013.11.16
   功能：新增移库计划单单头
***********************************************************************************************************/
    procedure P_mdata_PlanHead(strEnterPriseNo           in    mdata_plan_m.enterprise_no%type,
                               strWareHouseNo            in    mdata_plan_m.warehouse_no%type,--仓库编码
                               strOwnerNo                in    mdata_plan_m.owner_no%type,
                               strUserId                 in    mdata_plan_m.rgst_name%type,
                               strSouceType              in    mdata_plan_m.source_type%type,--移库类型；1:商品移库；2：标签移库
                               strOutstockType           in    mdata_plan_m.outstock_type%type,--下架类型：3：安全量补货；4:人工移库
                               strPlanNo                 out   mdata_plan_m.plan_no%type,--移库计划头档
                               strResult                 OUT    varchar2);
 /*****************************************************************************************************
   创建人：luozhiling
   时间：2013.11.16
   功能: 移库手建单明细
 ****************************************************************************************************/
    procedure P_mdata_PlanItem(strEnterPriseNo           in    mdata_plan_m.enterprise_no%type,
                               strWareHouseNo            in    mdata_plan_m.warehouse_no%type,--仓库编码
                               strOwnerNo                in    mdata_plan_m.owner_no%type,
                               strPlanNo                 in    mdata_plan_m.plan_no%type,--移库计划头档
                               strArticleNo              in    mdata_plan_d.article_no%type,--商品编码
                               dtProduceDate             in    stock_article_info.produce_date%type,--生产日期
                               dtExPireDate              in    stock_article_info.expire_date%type,--到期日
                               nPackingQty               in    mdata_plan_d.packing_qty%type,
                               strQUALITY                in    stock_article_info.quality%type,
                               strLotNo                  in    stock_article_info.lot_no%type, --批次号
                               strRSV_BATCH1             in    stock_article_info.rsv_batch1%type, --预留批属性1
                               strRSV_BATCH2             in    stock_article_info.rsv_batch2%type, --预留批属性2
                               strRSV_BATCH3             in    stock_article_info.rsv_batch3%type, --预留批属性3
                               strRSV_BATCH4             in    stock_article_info.rsv_batch4%type, --预留批属性4
                               strRSV_BATCH5             in    stock_article_info.rsv_batch5%type, --预留批属性5
                               strRSV_BATCH6             in    stock_article_info.rsv_batch6%type, --预留批属性6
                               strRSV_BATCH7             in    stock_article_info.rsv_batch7%type, --预留批属性7
                               strRSV_BATCH8             in    stock_article_info.rsv_batch8%type, --预留批属性8
                               nPlanQty                  in    mdata_plan_d.origin_qty%type,--计划移库量
                               strStockType              in    mdata_plan_d.stock_type%type,
                               strStockVAlue             in    mdata_plan_d.stock_value%type,
                               strsCellNo                in    mdata_plan_d.s_cell_no%type,--来源储位
                               strLabelNo                in    mdata_plan_d.s_label_no%type, --来源标签号
                               strSubLabelNo             in    mdata_plan_d.s_sub_label_no%type, --来源子标签号
                               strDestCellNo             in    mdata_plan_d.d_cell_no%type,--目的储位
                               strResult                 OUT    varchar2);
 /*****************************************************************************************************
   创建人：luozhiling
   时间：2013.11.16
   功能: 移库写定位指示
 ****************************************************************************************************/
    procedure P_mdata_locateDiect(strEnterPriseNo           in    mdata_plan_m.enterprise_no%type,
                                  strWareHouseNo            in    mdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo                in    mdata_plan_m.owner_no%type,
                                  strPlanNo                 in   mdata_plan_m.plan_no%type,--移库计划头档
                                  strUserId                 in   mdata_plan_m.rgst_name%type,
                                  strResult                 OUT    varchar2);

 /*****************************************************************************************************
   创建人：luozhiling
   时间：2013.11.16
   功能: 人工移库定位指示找库存
 ****************************************************************************************************/
    procedure P_mdata_foundStock(strEnterPriseNo           in    mdata_plan_m.enterprise_no%type,
                                 strWareHouseNo            in    mdata_plan_m.warehouse_no%type,--仓库编码
                                 strPlanNo                 in   mdata_plan_m.plan_no%type,--移库计划头档
                                 strUserId                 in   mdata_plan_m.rgst_name%type,
                                 strResult                 OUT    varchar2);
/***********************************************************************************************************
  创建人：lich
   时间：2014.07.16
   功能：Rf移库下架 更新状态
  ***********************************************************************************************************/
  procedure P_mdata_RfOut(strEnterPriseNo   in odata_outstock_m.enterprise_no%type,
                          strWareHouseNo    in odata_outstock_m.warehouse_no%type, --仓库编码
                          strOutstock_No    in odata_outstock_m.outstock_no%type,--下架单号
                          strArticleNo      in odata_outstock_d.article_no%type, --商品编码
                          nPacking_QTY      in odata_outstock_d.packing_qty%type,--包装数量
                          strQuality        in idata_check_d.quality%type,--品质
                          dtProduceDate     in stock_article_info.produce_date%type,--生产日期
                          dtExpireDate      in stock_article_info.expire_date%type,--到期日期
                          strLotNo          in stock_article_info.lot_no%type,--批次号
                          strRSV_BATCH1     in stock_article_info.rsv_batch1%type, --预留批属性1
                          strRSV_BATCH2     in stock_article_info.rsv_batch2%type, --预留批属性2
                          strRSV_BATCH3     in stock_article_info.rsv_batch3%type, --预留批属性3
                          strRSV_BATCH4     in stock_article_info.rsv_batch4%type, --预留批属性4
                          strRSV_BATCH5     in stock_article_info.rsv_batch5%type, --预留批属性5
                          strRSV_BATCH6     in stock_article_info.rsv_batch6%type, --预留批属性6
                          strRSV_BATCH7     in stock_article_info.rsv_batch7%type, --预留批属性7
                          strRSV_BATCH8     in stock_article_info.rsv_batch8%type, --预留批属性8
                          nQty              in odata_outstock_d.real_qty%type, --下架库量
                          strsCellNo        in odata_outstock_d.s_cell_no%type, --来源储位
                          strDestCellNo     in odata_outstock_d.d_cell_no%type, --目的储位
                          strLabelNo        in odata_outstock_d.label_no%type, --来源标签号
                          strUserId         in odata_outstock_m.rgst_name%type, --下架人
                          strResult         OUT varchar2);



  /***************************************************************************************************************
  功能说明：将标签库存回库写下架明细
  创建人:luozhiling
  创建时间：2014.12.4
  ***************************************************************************************************************/
  procedure Proc_Insert_LabelBackCellItem
  (strEnterPriseNo      IN                stock_content.enterprise_no%type,
   strWarehouseNo       in                stock_content.warehouse_no%type,
   strOutstockNo        in                odata_outstock_m.outstock_no%type,
   strOwnerNo           in                odata_outstock_d.owner_no%type,
   strsCellNo           in                stock_content.cell_no%type,--来源储位
   strLabelNo           in                stock_content.label_no%type,--来源标签
   strSubLabelNo        in                stock_content.sub_label_no%type,
   strSourceNo          in                stock_label_m.source_no%type,
   strArticleNo         in                stock_content.article_no%type,
   nDivideId            in                stock_label_d.divide_id%type,
   nArticleId           in                stock_content.article_id%type,
   nPackingQty          in                stock_content.packing_qty%type,
   NRealQty             in                stock_content.qty%type,
   strUserID            in                stock_content.rgst_name%type,
   strOutMsg            out               varchar2);

   /*******************************************************************************************************
  创建人：huangb
  创建时间：2016.05.18
  功能说明：移库计划单转历史
  ********************************************************************************************************/
  procedure P_mdata_PlanInsertHTY(strEnterPriseNo           in  mdata_plan_m.enterprise_no%type,
                                  strWareHouseNo            in  mdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo                in  mdata_plan_m.owner_no%type,
                                  strPlanNo                 in  mdata_plan_m.plan_no%type,--移库计划单号
                                  strUserId                 in  mdata_plan_m.rgst_name%type,
                                  strOutMsg                 OUT varchar2);

end PKOBJ_MDATA;


/

