create package body        PKOBJ_PRINTTASK is

  /*****************************************************************************************
     功能：根据码头写打印任务头档
    Modify By lizhiping AT 2013-12-12
  *****************************************************************************************/
  procedure p_insert_taskmaster(strEnterpriseNo in job_printtask_m.enterprise_no%type, --企业
                                strWarehouseNo  in job_printtask_m.WAREHOUSE_NO%type, --仓别
                                strSourceNo     in job_printtask_m.source_no%type, --源单号
                                strBackFlag     in job_printtask_m.back_flag%type, --后台打印标识，默认为0
                                strReportID     in job_printtask_m.report_id%type, --报表编号
                                strDockNo       in varchar2, --码头或工作站号
                                strReprintFlag  in job_printtask_m.reprint_flag%type, --补印标识
                                strUserNo       in job_printtask_m.Rgst_Name%type, --操作人员
                                strTaskNo       out job_printtask_m.task_no%type,
                                strErrorMsg     out varchar2) is

    v_PrintGroupNo job_printtask_m.printer_group_no%type; --打印机组
    v_nCount number;
  begin
    strErrorMsg := 'Y|';

    --根据码头或工作站获取打印机组
    PKLG_WMS_Public.GetPrintGroupByDockNo(strEnterpriseNo,
                                        strWarehouseNo,
                                        strDockNo,
                                        v_PrintGroupNo,
                                        strErrorMsg);
    if strErrorMsg <> 'Y' then
      return;
    end if;

    --取打印任务号
    PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                               strWarehouseNo,
                               CONST_DOCUMENTTYPE.PRINTPT,
                               strTaskNo,
                               strErrorMsg);
    if strErrorMsg <> 'Y' then
      return;
    end if;

    begin
      select count(1) into v_nCount
        from pntdef_report pr,pntset_printer_group pg,pntdef_defprinter p
        where p.enterprise_no=pg.enterprise_no
          and p.warehouse_no=pg.warehouse_no
          and p.printer_no=pg.printer_no
          and p.paper_type_no=pr.paper_type_no
          and pg.enterprise_no=strEnterpriseNo
          and pg.warehouse_no=strWarehouseNo
          and pg.printer_group_no=v_PrintGroupNo
          and pr.report_id=strReportID;
    exception
          when no_data_found then
            v_nCount := 0;
        end;
    if v_nCount <= 0 then
      strErrorMsg := 'N|[所指定工作站没有打印该报表的打印机]机组{' || v_PrintGroupNo || '}报表ID{' || strReportID || '}';
      return;
    end if;
    --写打印任务头档
    INSERT INTO JOB_PRINTTASK_M
      (Enterprise_No,
       Warehouse_No,
       TASK_NO,
       SOURCE_NO,
       BACK_FLAG,
       TASK_TYPE,
       REPRINT_FLAG,
       REPORT_ID,
       PRINTER_GROUP_NO,
       OPERATE_DATE,
       RGST_NAME,
       RGST_DATE)
      select distinct strEnterpriseNo,
                      strWarehouseNo,
                      strTaskNo,
                      strSourceNo,
                      strBackFlag,
                      a.task_type, --b.paper_type_no,
                      strReprintFlag,
                      strReportID,
                      v_PrintGroupNo,
                      trunc(sysdate),
                      strUserNo,
                      sysdate
        from PNTDEF_REPORT b, pntset_paper_type a
       where b.report_id = strReportID
         and b.paper_type_no = a.paper_type_no;

    if sql%rowcount <= 0 then
      strErrorMsg := 'N|[E00001]{' || strReportID || '}';
      return;
    end if;

  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_insert_taskmaster;

  /*****************************************************************************************
     功能：写打印任务明细
    Modify By lizhiping AT 2013-12-12
  *****************************************************************************************/
  procedure p_insert_taskdetail(strEnterPriseNo in job_printtask_m.enterprise_no%type,
                                strWarehouseNo  in job_printtask_m.WAREHOUSE_NO%type, --仓别
                                strTaskNo       in job_printtask_m.task_no%type,
                                strContainerNo  in job_printtask_d.container_no%type,
                                nSerialNo       in job_printtask_d.print_sn%type,
                                NPrintQty       in job_printtask_d.print_qty%type,
                                strErrorMsg     out varchar2) is

  begin
    strErrorMsg := 'Y|';

    --写打印任务明细
    INSERT INTO JOB_PRINTTASK_d
      (enterprise_no,
       Warehouse_No,
       TASK_NO,
       CONTAINER_NO,
       PRINT_SN,
       print_qty)
    values
      (strEnterPriseNo,
       strWarehouseNo,
       strTaskNo,
       strContainerNo,
       nSerialNo,
       NPrintQty);
  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_insert_taskdetail;

  /*****************************************************************************************
     功能：根据打印机组写打印任务头档
    Modify By lizhiping AT 2013-12-12
  *****************************************************************************************/
  procedure p_insert_PrintGrouptaskmaster(strEnterPriseNo in job_printtask_m.enterprise_no%type,
                                          strWarehouseNo  in job_printtask_m.WAREHOUSE_NO%type, --仓别
                                          strSourceNo     in job_printtask_m.source_no%type, --源单号
                                          strBackFlag     in job_printtask_m.back_flag%type, --后台打印标识，默认为0
                                          strReportID     in job_printtask_m.report_id%type, --报表编号
                                          strPrintGroupNo in job_printtask_m.printer_group_no%type,
                                          strReprintFlag  in job_printtask_m.reprint_flag%type, --补印标识
                                          strUserNo       in job_printtask_m.Rgst_Name%type, --操作人员
                                          strTaskNo       out job_printtask_m.task_no%type,
                                          strErrorMsg     out varchar2) is

                                          v_nCount number;
  begin
    strErrorMsg := 'Y|';

    --取打印任务号
    PKLG_WMS_BASE.p_getsheetno(strEnterPriseNo,
                               strWarehouseNo,
                               CONST_DOCUMENTTYPE.PRINTPT,
                               strTaskNo,
                               strErrorMsg);
    if strErrorMsg <> 'Y' then
      return;
    end if;

    begin
      select count(1) into v_nCount
        from pntdef_report pr,pntset_printer_group pg,pntdef_defprinter p
        where p.enterprise_no=pg.enterprise_no
          and p.warehouse_no=pg.warehouse_no
          and p.printer_no=pg.printer_no
          and p.paper_type_no=pr.paper_type_no
          and pg.enterprise_no=strEnterpriseNo
          and pg.warehouse_no=strWarehouseNo
          and pg.printer_group_no=strPrintGroupNo
          and pr.report_id=strReportID;
    exception
          when no_data_found then
            v_nCount := 0;
        end;
    if v_nCount <= 0 then
      strErrorMsg := 'N|[所指定工作站没有打印该报表的打印机]机组{' || strPrintGroupNo || '}报表ID{' || strReportID || '}';
      return;
    end if;

    --写打印任务头档
    INSERT INTO JOB_PRINTTASK_M
      (enterprise_no,
       Warehouse_No,
       TASK_NO,
       SOURCE_NO,
       BACK_FLAG,
       TASK_TYPE,
       REPRINT_FLAG,
       REPORT_ID,
       PRINTER_GROUP_NO,
       OPERATE_DATE,
       RGST_NAME,
       RGST_DATE)
      select distinct strEnterPriseNo,
                      strWarehouseNo,
                      strTaskNo,
                      strSourceNo,
                      strBackFlag,
                      a.task_type, --b.paper_type_no,
                      strReprintFlag,
                      strReportID,
                      strPrintGroupNo,
                      trunc(sysdate),
                      strUserNo,
                      sysdate
        from PNTDEF_REPORT b, pntset_paper_type a
       where b.report_id = strReportID
         and b.paper_type_no = a.paper_type_no;

    if sql%rowcount <= 0 then
      strErrorMsg := 'N|[E00001]{' || strReportID || '}';
      return;
    end if;

  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_insert_PrintGrouptaskmaster;

  /*****************************************************************************************
      功能：补印中心写打印任务
     chensr AT 2015-8-21
  *****************************************************************************************/
  procedure p_insert_printCenter(strEnterpriseNo in job_printtask_m.enterprise_no%type, --企业
                                strWarehouseNo  in job_printtask_m.WAREHOUSE_NO%type, --仓别
                                strSourceNo     in job_printtask_m.source_no%type, --源单号
                                strBackFlag     in job_printtask_m.back_flag%type, --后台打印标识，默认为0
                                strReportID     in job_printtask_m.report_id%type, --报表编号
                                strLabelLNoList in varchar2,                       --报表标签列表
                                strDockNo       in varchar2, --码头或工作站号
                                strHtyFlag      in job_printtask_m.hty_flag%type, --是否打印历史数据
                                strPrintNum     in varchar2,                     --打印份数
                                strUserNo       in job_printtask_m.Rgst_Name%type, --操作人员
                                strTaskNo       out job_printtask_m.task_no%type,
                                strErrorMsg     out varchar2) is

    v_PrintGroupNo job_printtask_m.printer_group_no%type; --打印机组
    v_count integer;
    v_nCount integer;
  begin
    strErrorMsg := 'Y|';
    v_count:=1;

    --根据码头或工作站获取打印机组
    PKLG_WMS_Public.GetPrintGroupByDockNo(strEnterpriseNo,
                                        strWarehouseNo,
                                        strDockNo,
                                        v_PrintGroupNo,
                                        strErrorMsg);
    if strErrorMsg <> 'Y' then
      return;
    end if;

    --取打印任务号
    PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                               strWarehouseNo,
                               CONST_DOCUMENTTYPE.PRINTPT,
                               strTaskNo,
                               strErrorMsg);
    if strErrorMsg <> 'Y' then
      return;
    end if;

    begin
      select count(1) into v_nCount
        from pntdef_report pr,pntset_printer_group pg,pntdef_defprinter p
        where p.enterprise_no=pg.enterprise_no
          and p.warehouse_no=pg.warehouse_no
          and p.printer_no=pg.printer_no
          and p.paper_type_no=pr.paper_type_no
          and pg.enterprise_no=strEnterpriseNo
          and pg.warehouse_no=strWarehouseNo
          and pg.printer_group_no=v_PrintGroupNo
          and pr.report_id=strReportID;
    exception
          when no_data_found then
            v_nCount := 0;
        end;
    if v_nCount <= 0 then
      strErrorMsg := 'N|[所指定工作站没有打印该报表的打印机]机组{' || v_PrintGroupNo || '}报表ID{' || strReportID || '}';
      return;
    end if;

    --写打印任务头档
    INSERT INTO JOB_PRINTTASK_M
      (Enterprise_No,
       Warehouse_No,
       TASK_NO,
       SOURCE_NO,
       BACK_FLAG,
       TASK_TYPE,
       REPRINT_FLAG,
       REPORT_ID,
       PRINTER_GROUP_NO,
       OPERATE_DATE,
       HTY_FLAG,
       RGST_NAME,
       RGST_DATE)
      select distinct strEnterpriseNo,
                      strWarehouseNo,
                      strTaskNo,
                      strSourceNo,
                      strBackFlag,
                      a.task_type, --b.paper_type_no,
                      '1',
                      strReportID,
                      v_PrintGroupNo,
                      trunc(sysdate),
                      strHtyFlag,
                      strUserNo,
                      sysdate
        from PNTDEF_REPORT b, pntset_paper_type a
       where b.report_id = strReportID
         and b.paper_type_no = a.paper_type_no;

    if sql%rowcount <= 0 then
      strErrorMsg := 'N|[E00001]{' || strReportID || '}';
      return;
    end if;

    if strLabelLNoList<>'N' and strLabelLNoList is not null then
     for m in ( select * from table(split(strLabelLNoList,'|')) ) loop
       insert into job_printtask_d(enterprise_no,
                                   warehouse_no,
                                   task_no,
                                   container_no,
                                   print_sn,
                                   print_qty)
                            values(strEnterpriseNo,
                                   strWarehouseNo,
                                   strTaskNo,
                                   m.column_value,
                                   v_count,
                                   strPrintNum);
       v_count:=v_count+1;
     end loop;
    end if;
  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_insert_printCenter;


	 /*****************************************************************************************
     功能：打印任务转历史 JOB用，JOB在每天凌晨2点执行一次
     sl AT 20160121
  *****************************************************************************************/
  PROCEDURE P_PRINTJOB_BACKUP IS
    PRAGMA AUTONOMOUS_TRANSACTION;
		--STRERRORMSG VARCHAR2(300);
		BEGIN
		--1. 头档数据转历史
		INSERT INTO JOB_PRINTTASK_MHTY
		SELECT * FROM JOB_PRINTTASK_M M WHERE TRUNC(M.RGST_DATE) <= TRUNC(SYSDATE -1);

    --2. 明细数据转历史
		INSERT INTO JOB_PRINTTASK_DHTY SELECT * FROM JOB_PRINTTASK_D D
		WHERE EXISTS(SELECT 1 FROM JOB_PRINTTASK_M M WHERE TRUNC(M.RGST_DATE) <= TRUNC(SYSDATE -1));

		--3. 删除明细数据
		DELETE JOB_PRINTTASK_D D
		WHERE EXISTS(SELECT 1 FROM JOB_PRINTTASK_M M WHERE TRUNC(M.RGST_DATE) <= TRUNC(SYSDATE -1));

		--4. 删除头档数据
		DELETE JOB_PRINTTASK_M M WHERE TRUNC(M.RGST_DATE) <= TRUNC(SYSDATE -1);

    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
			ROLLBACK;
      --STRERRORMSG := 'N|' || SQLERRM || SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
      RETURN;
  END P_PRINTJOB_BACKUP;

  /*=====================================================================================
  hb insert to 20160625
  打印-新增打印任务头档和明细
  ======================================================================================*/
  PROCEDURE p_Insert_TaskInfo( --新增打印任务条件
                               strEnterpriseNo    in pntset_module_report.enterprise_no%type,--企业
                               strWarehouseNo     in job_printtask_m.warehouse_no%type,--仓别号
                               strSourceNo        in job_printtask_m.source_no%type, --源单号
                               strReportId        in job_printtask_m.report_id%type, --打印的报表ID 如外部传入 则传具体的report_id且查询条件可全部为'N',否则本参数传'N'
                               strBackFlag        in job_printtask_m.back_flag%type, --后台打印标识，默认为0
                               strDockNo          in varchar2, --码头或工作站号
                               strReprintFlag     in job_printtask_m.reprint_flag%type, --补印标识
                               strUserNo          in job_printtask_m.Rgst_Name%type, --操作人员
                               strAddDetailFlag   in varchar2, --是否新增打印任务明细 0-不新增;1-新增
                               strContainerNo     in job_printtask_d.container_no%type, --需要打印的系统内部容器号不新增打印任务明细传'N'
                               nSerialNo          in job_printtask_d.print_sn%type, --不新增打印任务明细传 0
                               NPrintQty          in job_printtask_d.print_qty%type, --不新增打印任务明细传 1
                               --返回参数
                               strTaskNo          out job_printtask_m.task_no%type, --打印任务单号 如外部生成 则传外部生成打印任务号,否则传'N'
                               strOutMsg          out varchar2) is

    v_count        number := 0;
    v_PrintGroupNo job_printtask_m.printer_group_no%type; --打印机组
    v_TaskNo       job_printtask_m.task_no%type := 'N'; --打印任务单号 如外部生成 则传外部生成打印任务号,否则传'N'

  begin
    strOutMsg    := 'N|[p_Insert_TaskBySet]';

    --根据码头或工作站获取打印机组
    PKLG_WMS_Public.GetPrintGroupByDockNo(strEnterpriseNo,
                                        strWarehouseNo,
                                        strDockNo,
                                        v_PrintGroupNo,
                                        strOutMsg);
    if strOutMsg <> 'Y' then
      return;
    end if;

    v_count := 0;
    begin
      select count(1) into v_count
        from pntdef_report pr,pntset_printer_group pg,pntdef_defprinter p
        where p.enterprise_no=pg.enterprise_no
          and p.warehouse_no=pg.warehouse_no
          and p.printer_no=pg.printer_no
          and p.paper_type_no=pr.paper_type_no
          and pg.enterprise_no=strEnterpriseNo
          and pg.warehouse_no=strWarehouseNo
          and pg.printer_group_no=v_PrintGroupNo
          and pr.report_id=strReportId;
    exception
      when no_data_found then
        v_count := 0;
    end;
    if v_count <= 0 then
      strOutMsg := 'N|[所指定工作站没有打印该报表的打印机]机组{' || v_PrintGroupNo || '}报表ID{' || strReportId || '}';
      return;
    end if;

    --取打印任务号
    PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                               strWarehouseNo,
                               CONST_DOCUMENTTYPE.PRINTPT,
                               v_TaskNo,
                               strOutMsg);
    if strOutMsg <> 'Y' then
      return;
    end if;

    --写打印任务头档
    INSERT INTO JOB_PRINTTASK_M
      (Enterprise_No,
       Warehouse_No,
       TASK_NO,
       SOURCE_NO,
       BACK_FLAG,
       TASK_TYPE,
       REPRINT_FLAG,
       REPORT_ID,
       PRINTER_GROUP_NO,
       OPERATE_DATE,
       RGST_NAME,
       RGST_DATE)
      select distinct strEnterpriseNo,
                      strWarehouseNo,
                      v_TaskNo,
                      strSourceNo,
                      strBackFlag,
                      a.task_type,
                      strReprintFlag,
                      strReportId,
                      v_PrintGroupNo,
                      trunc(sysdate),
                      strUserNo,
                      sysdate
        from PNTDEF_REPORT b, pntset_paper_type a
       where b.report_id = strReportId
         and b.paper_type_no = a.paper_type_no;

    if sql%rowcount <= 0 then
      strOutMsg := 'N|新增报表['|| strReportId ||']打印任务头档失败';
      return;
    end if;

    if strAddDetailFlag = '1' then
      --写打印任务明细
      INSERT INTO JOB_PRINTTASK_d
        (enterprise_no,
         Warehouse_No,
         TASK_NO,
         CONTAINER_NO,
         PRINT_SN,
         print_qty)
      values
        (strEnterPriseNo,
         strWarehouseNo,
         v_TaskNo,
         strContainerNo,
         nSerialNo,
         NPrintQty);
      if sql%rowcount <= 0 then
        strOutMsg := 'N|新增报表['|| strReportId ||']标签['|| strContainerNo ||']打印任务明细失败';
        return;
      end if;
    end if;

    strTaskNo := v_TaskNo;
    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_Insert_TaskInfo;

    /*****************************************************************************************
      功能：补印中心写打印任务
     add by czh 2016/10/17 写明细的时候加了包装数量和预留字段
  *****************************************************************************************/
  procedure p_insert_printCenter_forRepair(strEnterpriseNo in job_printtask_m.enterprise_no%type, --企业
                                strWarehouseNo  in job_printtask_m.WAREHOUSE_NO%type, --仓别
                                strSourceNo     in job_printtask_m.source_no%type, --源单号
                                strBackFlag     in job_printtask_m.back_flag%type, --后台打印标识，默认为0
                                strReportID     in job_printtask_m.report_id%type, --报表编号
                                strLabelLNoList in varchar2,                       --报表标签列表
                                strDockNo       in varchar2, --码头或工作站号
                                strHtyFlag      in job_printtask_m.hty_flag%type, --是否打印历史数据
                                strPrintNum     in varchar2,                     --打印份数
                                strUserNo       in job_printtask_m.Rgst_Name%type, --操作人员
                                numPackingQty   in job_printtask_d.packing_qty%type, --包装数量
                                strRsvVarod1    in job_printtask_d.RSV_VAROD1%type, --预留字段1
                                strRsvVarod2    in job_printtask_d.RSV_VAROD2%type, --预留字段2
                                strRsvVarod3    in job_printtask_d.RSV_VAROD3%type, --预留字段3
                                strRsvVarod4    in job_printtask_d.RSV_VAROD4%type, --预留字段4
                                strRsvVarod5    in job_printtask_d.RSV_VAROD5%type, --预留字段5
                                strTaskNo       out job_printtask_d.task_no%type,
                                strErrorMsg     out varchar2) is

    v_PrintGroupNo job_printtask_m.printer_group_no%type; --打印机组
    v_count integer;
    v_nCount integer;
  begin
     strErrorMsg := 'N|[p_insert_printCenter_forRepair]!';
    v_count:=1;

    --根据码头或工作站获取打印机组
    PKLG_WMS_Public.GetPrintGroupByDockNo(strEnterpriseNo,
                                        strWarehouseNo,
                                        strDockNo,
                                        v_PrintGroupNo,
                                        strErrorMsg);
    if substr(strErrorMsg, 1, 2) = 'N|' then
      return;
    end if;

    --取打印任务号
    PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                               strWarehouseNo,
                               CONST_DOCUMENTTYPE.PRINTPT,
                               strTaskNo,
                               strErrorMsg);
    if substr(strErrorMsg, 1, 2) = 'N|' then
      return;
    end if;

    begin
      select count(1) into v_nCount
        from pntdef_report pr,pntset_printer_group pg,pntdef_defprinter p
        where p.enterprise_no=pg.enterprise_no
          and p.warehouse_no=pg.warehouse_no
          and p.printer_no=pg.printer_no
          and p.paper_type_no=pr.paper_type_no
          and pg.enterprise_no=strEnterpriseNo
          and pg.warehouse_no=strWarehouseNo
          and pg.printer_group_no=v_PrintGroupNo
          and pr.report_id=strReportID;
    exception
          when no_data_found then
            v_nCount := 0;
        end;
    if v_nCount <= 0 then
      strErrorMsg := 'N|[所指定工作站没有打印该报表的打印机]机组{' || v_PrintGroupNo || '}报表ID{' || strReportID || '}';
      return;
    end if;

    --写打印任务头档
    INSERT INTO JOB_PRINTTASK_M
      (Enterprise_No,
       Warehouse_No,
       TASK_NO,
       SOURCE_NO,
       BACK_FLAG,
       TASK_TYPE,
       REPRINT_FLAG,
       REPORT_ID,
       PRINTER_GROUP_NO,
       OPERATE_DATE,
       HTY_FLAG,
       RGST_NAME,
       RGST_DATE)
      select distinct strEnterpriseNo,
                      strWarehouseNo,
                      strTaskNo,
                      strSourceNo,
                      strBackFlag,
                      a.task_type, --b.paper_type_no,
                      '1',
                      strReportID,
                      v_PrintGroupNo,
                      trunc(sysdate),
                      strHtyFlag,
                      strUserNo,
                      sysdate
        from PNTDEF_REPORT b, pntset_paper_type a
       where b.report_id = strReportID
         and b.paper_type_no = a.paper_type_no;

    if sql%rowcount <= 0 then
      strErrorMsg := 'N|[E00001]{' || strReportID || '}';
      return;
    end if;

    if strLabelLNoList<>'N' and strLabelLNoList is not null then
     for m in ( select * from table(split(strLabelLNoList,'|')) ) loop
       insert into job_printtask_d(enterprise_no,
                                   warehouse_no,
                                   task_no,
                                   container_no,
                                   print_sn,
                                   print_qty,
                                   packing_qty,
                                   rsv_varod1,
                                   rsv_varod2,
                                   rsv_varod3,
                                   rsv_varod4,
                                   rsv_varod5)
                            values(strEnterpriseNo,
                                   strWarehouseNo,
                                   strTaskNo,
                                   m.column_value,
                                   v_count,
                                   strPrintNum,
                                   numPackingQty,
                                   strRsvVarod1,
                                   strRsvVarod2,
                                   strRsvVarod3,
                                   strRsvVarod4,
                                   strRsvVarod5);
       v_count:=v_count+1;
     end loop;
    end if;

     strErrorMsg := 'Y|成功!';
  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_insert_printCenter_forRepair;

end PKOBJ_PRINTTASK;

/

