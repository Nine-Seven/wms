create package        pklg_Deliveid_calculate is

  /*****************************************************************************************************************
  luozhiling
  20160308
  月台存放序号：按日期产生，每天从1还是往上累加
  ***************************************************************************************************************/
  procedure P_Deliver_calculate(strEnterpriseNo    in     odata_outstock_m.enterprise_no%type,
                               strWarehouseNo     in     stock_label_m.warehouse_no%type,
                               strOwnerNo         in     odata_exp_m.owner_no%type,
                               strWaveNo          in     odata_wave_trace.wave_no%type,
                               strOutMsg         out varchar2);

  /*****************************************************************************************
   功能：产生月台序号 编码
  Modify By wyf AT 2015-11-03
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure p_getExpOrderid(strEnterPriseNo in bdef_paperno.enterprise_no%type,
                       strOwnerNo      bdef_paperno.warehouse_no%type, --货主编码
                       SheetType       in bdef_paperno.papertype%type, --类型YTH:月台序号
                       cSheetNo        out varchar2, --返回编码
                       strOutMsg       out varchar2);
end pklg_Deliveid_calculate;


/

