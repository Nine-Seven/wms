create view V_SEARCH_9103_008 as
select "ENTERPRISE_NO",
       "WAREHOUSE_NO",
       "OWNER_NO",
       "LABEL_NO",
       "CUST_NO",
       "CUST_NAME",
       "STATUS",
       "STATUS_DESC",
       "ARTICLE_NO",
       "SOURCE_NO",
       "CONTAINER_NO",
       "WAVE_NO",
       "BATCH_NO",
       "PACKING_QTY",
       "ARTICLE_NAME",
       "BARCODE",
       "OWNER_ARTICLE_NO",
       "GROUP_NO",
       "GROUP_NAME",
       "EXP_NO",
       "QTY",
       "UPDT_DATE"
  from (select distinct slm.enterprise_no,
                        slm.warehouse_no,
                        sld.owner_no,
                        slm.label_no,
                        bdc.cust_no,
                        bdc.cust_name,
                        slm.status,
                        wdv.text as status_desc,
                        sld.article_no,
                        sld.source_no,
                        sld.container_no,
                        sld.wave_no,
                        sld.batch_no,
                        sld.packing_qty,
                        v.ARTICLE_NAME,
                        v.BARCODE,
                        v.OWNER_ARTICLE_NO,
                        v.GROUP_NO,
                        v.GROUP_NAME,
                        sld.exp_no,
                        sum（sld.qty） qty,
                        trunc(sld.updt_date) updt_date
          from (select warehouse_no,
                       enterprise_no,
                       container_no,
                       status,
                       label_no,
                       updt_date,
                       device_no,
                       use_type
                  from stock_label_m
                union
                select warehouse_no,
                       enterprise_no,
                       container_no,
                       status,
                       label_no,
                       updt_date,
                       device_no,
                       use_type
                  from stock_label_mhty) slm
          join (select warehouse_no,
                      enterprise_no,
                      owner_no,
                      article_no,
                      container_no,
                      article_id,
                      exp_no,
                      cust_no,
                      updt_date,
                      packing_qty,
                      batch_no,
                      wave_no,
                      source_no,
                      qty
                 from stock_label_d
               union
               select warehouse_no,
                      enterprise_no,
                      owner_no,
                      article_no,
                      container_no,
                      article_id,
                      exp_no,
                      cust_no,
                      updt_date,
                      packing_qty,
                      batch_no,
                      wave_no,
                      source_no,
                      qty
                 from stock_label_dhty) sld
            on slm.enterprise_no = sld.enterprise_no
           and slm.warehouse_no = sld.warehouse_no
           and slm.container_no = sld.container_no
          join v_bdef_defarticle v
            on sld.owner_no = v.OWNER_NO
           and sld.article_no = v.ARTICLE_NO
           and v.ENTERPRISE_NO = sld.enterprise_no
          join bdef_defcust bdc
            on sld.owner_no = bdc.owner_no
           and sld.cust_no = bdc.cust_no
           and sld.enterprise_no = bdc.enterprise_no
          left join wms_deffieldval wdv
            on slm.status = wdv.value
           and wdv.table_name = 'STOCK_LABEL_M'
           and wdv.colname = 'STATUS'
         where slm.use_type in ('1') --,不能查'2'类型的数据
         group by slm.enterprise_no,
                  slm.warehouse_no,
                  sld.owner_no,
                  slm.label_no,
                  bdc.cust_no,
                  bdc.cust_name,
                  slm.status,
                  wdv.text,
                  sld.article_no,
                  sld.source_no,
                  sld.container_no,
                  sld.wave_no,
                  sld.batch_no,
                  sld.packing_qty,
                  v.ARTICLE_NAME,
                  v.BARCODE,
                  v.OWNER_ARTICLE_NO,
                  v.GROUP_NO,
                  v.GROUP_NAME,
                  sld.exp_no,
                  trunc(sld.updt_date)) c


/

