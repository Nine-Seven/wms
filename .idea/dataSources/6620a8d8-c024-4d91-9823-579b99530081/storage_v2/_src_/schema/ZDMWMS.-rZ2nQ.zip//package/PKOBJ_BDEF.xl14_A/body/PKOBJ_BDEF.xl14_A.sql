create package body        PKOBJ_BDEF is

/**********************************************************************************************************
   MM
   2014.04.16
   功能：写入商品批号管理
***********************************************************************************************************/
    procedure p_bdef_insertarticlelot(strARTICLENO    in    BDEF_ARTICLE_LOT_MANAGE.ARTICLE_NO%type,--
                                  strLOTNO                  in    BDEF_ARTICLE_LOT_MANAGE.LOT_NO%type,
                                  dtPRODUCEDATE             in    BDEF_ARTICLE_LOT_MANAGE.PRODUCE_DATE%type,
                                  dtEXPIREDATE              in   BDEF_ARTICLE_LOT_MANAGE.EXPIRE_DATE%type,--
                                  intEXPIRYDAYS             in  BDEF_ARTICLE_LOT_MANAGE.EXPIRY_DAYS%type,--
                                  strUserId                 in BDEF_ARTICLE_LOT_MANAGE.RGST_NAME%type,
                                  douPRICE                  in BDEF_ARTICLE_LOT_MANAGE.PRICE%type,
                                  strResult                 OUT    varchar2)is

    begin
      strResult := 'N|[p_bdef_insertarticlelot]';

      insert into BDEF_ARTICLE_LOT_MANAGE(ARTICLE_NO,LOT_NO,PRODUCE_DATE,EXPIRE_DATE,EXPIRY_DAYS,RGST_NAME,RGST_DATE,PRICE)
      values(strARTICLENO,strLOTNO,dtPRODUCEDATE,dtEXPIREDATE,intEXPIRYDAYS,strUserId,sysdate,douPRICE);
      if (sql%rowcount <= 0) then
          strResult := 'N|[E00011]';
          return;
      end if;

      strResult:='Y|';

    end p_bdef_insertarticlelot;

/**********************************************************************************************************
  hekl
  2015.07.03
  功能：新增保存或者修改保存商品类别资料
  修改By panzhenxing
***********************************************************************************************************/
   procedure saveOrUpdateGroup(
                        strEnterpriseNo         in bdef_article_group.enterprise_no%type,
                        strOwnerNo              in bdef_article_group.owner_no%type,
                        strGroupNo              in bdef_article_group.group_no%type,
                        strGroupLevel           in bdef_article_group.group_level%type,
                        strGroupName            in bdef_article_group.group_name%type,
                        strMGroupNo             in bdef_article_group.m_group_no%type,
                        strMGroupName           in bdef_article_group.m_group_name%type,
                        strLGroupNo             in bdef_article_group.l_group_no%type,
                        strLGroupName           in bdef_article_group.l_group_name%type,
                        strAlarmrate            in bdef_article_group.alarmrate%type,
                        strCheckExcess          in bdef_article_group.check_excess%type,
                        strCheckQtyFlag         in bdef_article_group.check_qty_flag%type,
                        strCheckQtyRate         in bdef_article_group.check_qty_rate%type,
                        strCheckWeightFlag      in bdef_article_group.check_weight_flag%type,
                        strCheckWeightRate      in bdef_article_group.check_weight_rate%type,
                        strDivideExcess         in bdef_article_group.divide_excess%type,
                        strDoubleCheck          in bdef_article_group.double_check%type,
                        strFcStrategy           in bdef_article_group.fc_strategy%type,
                        strFreezerate           in bdef_article_group.freezerate%type,
                        strTurnOverRule         in bdef_article_group.turn_over_rule%type,
                        strUmCheckExcess        in bdef_article_group.um_check_excess%type,
                        strPickExcess           in bdef_article_group.pick_excess%type,
                        strTemperatureFlag      in bdef_article_group.temperature_flag%type,
                        strScanFlag             in bdef_article_group.scan_flag%type,
                        strMeasureMode          in bdef_article_group.measure_mode%type,
                        strMixFlag              in bdef_article_group.mix_flag%type,
                        strQcFlag               in bdef_article_group.qc_flag%type,
                        strQcRate               in bdef_article_group.qc_rate%type,
                        strIStrategy            in bdef_article_group.i_strategy%type,
                        strOStrategy            in bdef_article_group.o_strategy%type,
                        strMStrategy            in bdef_article_group.m_strategy%type,
                        strRiStrategy           in bdef_article_group.ri_strategy%type,
                        strRoStrategy           in bdef_article_group.ro_strategy%type,
                        strPrintFlag            in bdef_article_group.print_flag%type,
                        strRgstName             IN BDEF_ARTICLE_GROUP.RGST_NAME%TYPE,
                        strStatus               IN BDEF_ARTICLE_GROUP.Status%TYPE,
                        strRsvStrategy1         in bdef_article_group.rsv_strategy1%type,
                        strRsvStrategy2         in bdef_article_group.rsv_strategy1%type,
                        strRsvStrategy3         in bdef_article_group.rsv_strategy1%type,
                        strRsvStrategy4         in bdef_article_group.rsv_strategy1%type,
                        strRsvStrategy5         in bdef_article_group.rsv_strategy1%type,
                        strRsvStrategy6         in bdef_article_group.rsv_strategy1%type,
                        strFalg                 in varchar2,--1修改
                        strOutMsg               out varchar2

                        )is

     v_strStatus        bdef_article_group.status%type;

     begin
     strOutMsg:='N|[saveOrUpdateGroup]';

       --锁表
     update bdef_article_group t set t.status=t.status where t.enterprise_no=strEnterpriseNo
        and t.owner_no = strOwnerNo;

     --状态变更（类别与商品的状态值不一致）
     if strStatus = '0' then
       v_strStatus:='1';
     else
       v_strStatus:='0';
     end if;

     if strFalg = '1' then --修改
       --修改前写日志
       insert into bdef_article_group_log
           (enterprise_no,owner_no, group_no, group_name, m_group_no,
           m_group_name, l_group_no, l_group_name, group_level,
           status, create_flag, alarmrate, freezerate,
           turn_over_rule, check_excess, um_check_excess,
           pick_excess, divide_excess, temperature_flag,
           measure_mode, scan_flag, check_qty_flag,
           check_qty_rate, check_weight_flag, check_weight_rate,
           qc_flag, qc_rate, mix_flag, double_check, i_strategy,
           o_strategy, m_strategy, ri_strategy, ro_strategy,
           fc_strategy, rsv_strategy1, rsv_strategy2, rsv_strategy3,
           rsv_strategy4, rsv_strategy5, rsv_strategy6,
           rgst_name, rgst_date, updt_name, updt_date)
           select enterprise_no, owner_no, group_no, group_name, m_group_no,
           m_group_name, l_group_no, l_group_name, group_level,
           status, create_flag, alarmrate, freezerate,
           turn_over_rule, check_excess, um_check_excess,
           pick_excess, divide_excess, temperature_flag,
           measure_mode, scan_flag, check_qty_flag,
           check_qty_rate, check_weight_flag, check_weight_rate,
           qc_flag, qc_rate, mix_flag, double_check, i_strategy,
           o_strategy, m_strategy, ri_strategy, ro_strategy,
           fc_strategy, rsv_strategy1, rsv_strategy2, rsv_strategy3,
           rsv_strategy4, rsv_strategy5, rsv_strategy6,
           rgst_name, rgst_date,updt_name, sysdate from bdef_article_group a
           where a.group_no= strGroupNo and a.group_level= strGroupLevel
           and a.owner_no=strOwnerNo and a.enterprise_no=strEnterpriseNo;

      --取该记录的数据(只会循环一次)
       for ps in(select * from bdef_article_group a where a.owner_no=strOwnerNo
          and a.group_no=strGroupNo and a.group_level=strGroupLevel
          and a.enterprise_no=strEnterpriseNo)loop

           if strGroupLevel = 2 then --大类
             --修改本身
              update bdef_article_group g set
                 g.freezerate=strFreezerate,
                 g.alarmrate=strAlarmrate,
                 g.turn_over_rule=strTurnOverRule,
                -- g.alarmrate=strAlarmrate,
                 g.check_excess=strCheckExcess,g.um_check_excess=strUmCheckExcess, g.pick_excess=strPickExcess,
                 g.divide_excess=strDivideExcess, g.temperature_flag=strTemperatureFlag,
                 g.measure_mode=strMeasureMode, g.scan_flag=strScanFlag,
                 g.check_qty_flag=strCheckQtyFlag, g.check_qty_rate=strCheckQtyRate,
                 g.check_weight_flag=strCheckWeightFlag, g.check_weight_rate=strCheckWeightRate,
                 g.qc_flag=strQcFlag, g.qc_rate=strQcRate,
                 g.mix_flag=strMixFlag, g.double_check=strDoubleCheck,
                 g.i_strategy=strIStrategy, g.o_strategy=strOStrategy, g.m_strategy=strMStrategy,
                 g.ri_strategy=strRiStrategy, g.ro_strategy=strOStrategy, g.fc_strategy=strFcStrategy,
                 g.rsv_strategy1=strRsvStrategy1, g.rsv_strategy2=strRsvStrategy2,
                 g.rsv_strategy3=strRsvStrategy3, g.rsv_strategy4=strRsvStrategy4,
                 g.rsv_strategy5=strRsvStrategy5, g.rsv_strategy6=strRsvStrategy6,
                 g.print_flag=strPrintFlag,g.updt_name=strRgstName,g.updt_date=sysdate
               where g.enterprise_no=strEnterpriseNo and g.owner_no=strOwnerNo
                 and g.group_no=strGroupNo;

               update bdef_article_group g set  g.status=strStatus
               where g.enterprise_no=strEnterpriseNo and g.owner_no=strOwnerNo
                 and g.group_no=strGroupNo;

               --修改该大类下的中类和小类
               update bdef_article_group g set
                 g.freezerate=strFreezerate,
                 g.alarmrate=strAlarmrate,
                 g.turn_over_rule=strTurnOverRule,
                 g.check_excess=strCheckExcess,g.um_check_excess=strUmCheckExcess, g.pick_excess=strPickExcess,
                 g.divide_excess=strDivideExcess, g.temperature_flag=strTemperatureFlag,
                 g.measure_mode=strMeasureMode, g.scan_flag=strScanFlag,
                 g.check_qty_flag=strCheckQtyFlag, g.check_qty_rate=strCheckQtyRate,
                 g.check_weight_flag=strCheckWeightFlag, g.check_weight_rate=strCheckWeightRate,
                 g.qc_flag=strQcFlag, g.qc_rate=strQcRate,
                 g.mix_flag=strMixFlag, g.double_check=strDoubleCheck,
                 g.i_strategy=strIStrategy, g.o_strategy=strOStrategy, g.m_strategy=strMStrategy,
                 g.ri_strategy=strRiStrategy, g.ro_strategy=strOStrategy, g.fc_strategy=strFcStrategy,
                 g.rsv_strategy1=strRsvStrategy1, g.rsv_strategy2=strRsvStrategy2,
                 g.rsv_strategy3=strRsvStrategy3, g.rsv_strategy4=strRsvStrategy4,
                 g.rsv_strategy5=strRsvStrategy5, g.rsv_strategy6=strRsvStrategy6,
                 g.print_flag=strPrintFlag,g.updt_name=strRgstName,g.updt_date=sysdate
               where g.enterprise_no=strEnterpriseNo and g.owner_no=strOwnerNo
                 and g.l_group_no=strGroupNo and g.freezerate=ps.freezerate and g.turn_over_rule=ps.turn_over_rule and
                 g.check_excess=ps.check_excess and g.um_check_excess=ps.um_check_excess and g.pick_excess=ps.pick_excess and
                 g.divide_excess=ps.divide_excess and g.temperature_flag=ps.temperature_flag and
                 g.measure_mode=ps.measure_mode and g.scan_flag=ps.scan_flag and
                 g.check_qty_flag=ps.check_qty_flag and g.check_qty_rate=ps.check_qty_rate and
                 g.check_weight_flag=ps.check_weight_flag and g.check_weight_rate=ps.check_weight_rate and
                 g.qc_flag=ps.qc_flag and g.qc_rate=ps.qc_rate and
                 g.mix_flag=ps.mix_flag and g.double_check=ps.double_check and
                 g.i_strategy=ps.i_strategy and g.o_strategy=ps.o_strategy and g.m_strategy=ps.m_strategy and
                 g.ri_strategy=ps.ri_strategy and g.ro_strategy=ps.ro_strategy and g.fc_strategy=ps.fc_strategy and

             /*    g.rsv_strategy1=ps.rsv_strategy1 and g.rsv_strategy2=ps.rsv_strategy2 and
                 g.rsv_strategy3=ps.rsv_strategy3 and g.rsv_strategy4=ps.rsv_strategy4 and
                 g.rsv_strategy5=ps.rsv_strategy5 and g.rsv_strategy6=ps.rsv_strategy6 and*/
                 g.print_flag=ps.print_flag;

               update bdef_article_group g set  g.status=strStatus
               where g.enterprise_no=strEnterpriseNo and g.owner_no=strOwnerNo
                 and g.l_group_no=strGroupNo;


               --修改该大类下的商品
               update bdef_defarticle g set
                 g.freezerate=strFreezerate,
                 g.alarmrate=strAlarmrate,
                 g.turn_over_rule=strTurnOverRule,
                 g.check_excess=strCheckExcess,g.um_check_excess=strUmCheckExcess, g.pick_excess=strPickExcess,
                 g.divide_excess=strDivideExcess, g.temperature_flag=strTemperatureFlag,
                 g.measure_mode=strMeasureMode, g.scan_flag=strScanFlag,
                 g.check_qty_flag=strCheckQtyFlag, g.check_qty_rate=strCheckQtyRate,
                 g.check_weight_flag=strCheckWeightFlag, g.check_weight_rate=strCheckWeightRate,
                 g.qc_flag=strQcFlag, g.qc_rate=strQcRate,
                 g.mix_flag=strMixFlag, g.double_check=strDoubleCheck,
                 g.i_strategy=strIStrategy, g.o_strategy=strOStrategy, g.m_strategy=strMStrategy,
                 g.ri_strategy=strRiStrategy, g.ro_strategy=strOStrategy, g.fc_strategy=strFcStrategy,
                 g.rsv_strategy1=strRsvStrategy1, g.rsv_strategy2=strRsvStrategy2,
                 g.rsv_strategy3=strRsvStrategy3, g.rsv_strategy4=strRsvStrategy4,
                 g.rsv_strategy5=strRsvStrategy5, g.rsv_strategy6=strRsvStrategy6,
                 g.print_flag = (case when g.print_flag = ps.print_flag then
                    strPrintFlag else g.print_flag end),--修改大类下的商品打印标识

                 g.updt_name=strRgstName,g.updt_date=sysdate
                 where g.enterprise_no=strEnterpriseNo and g.owner_no=strOwnerNo
                 and g.group_no in
                  (select p.group_no from bdef_article_group p where p.enterprise_no=strEnterpriseNo
                 and p.owner_no=strOwnerNo and p.l_group_no=strGroupNo)
                 and g.freezerate=ps.freezerate and g.turn_over_rule=ps.turn_over_rule and
                 g.check_excess=ps.check_excess and g.um_check_excess=ps.um_check_excess and g.pick_excess=ps.pick_excess and
                 g.divide_excess=ps.divide_excess and g.temperature_flag=ps.temperature_flag and
                 g.measure_mode=ps.measure_mode and g.scan_flag=ps.scan_flag and
                 g.check_qty_flag=ps.check_qty_flag and g.check_qty_rate=ps.check_qty_rate and
                 g.check_weight_flag=ps.check_weight_flag and g.check_weight_rate=ps.check_weight_rate and
                 g.qc_flag=ps.qc_flag and g.qc_rate=ps.qc_rate and
                 g.mix_flag=ps.mix_flag and g.double_check=ps.double_check and
                 g.i_strategy=ps.i_strategy and g.o_strategy=ps.o_strategy and g.m_strategy=ps.m_strategy and
                 g.ri_strategy=ps.ri_strategy and g.ro_strategy=ps.ro_strategy and g.fc_strategy=ps.fc_strategy and
              /*   g.rsv_strategy1=ps.rsv_strategy1 and g.rsv_strategy2=ps.rsv_strategy2 and
                 g.rsv_strategy3=ps.rsv_strategy3 and g.rsv_strategy4=ps.rsv_strategy4 and
                 g.rsv_strategy5=ps.rsv_strategy5 and g.rsv_strategy6=ps.rsv_strategy6 and*/
                 g.print_flag=ps.print_flag;

               update bdef_defarticle g set  g.status=v_strStatus
               where g.enterprise_no=strEnterpriseNo and g.owner_no=strOwnerNo
                 and g.group_no in (select p.group_no from bdef_article_group p where p.enterprise_no=strEnterpriseNo
                 and p.owner_no=strOwnerNo and p.l_group_no=strGroupNo);


           elsif strGroupLevel = 1 then --中类

              --修改本身（中类）
              update bdef_article_group g set
                 g.freezerate=strFreezerate,
                 g.alarmrate=strAlarmrate,
                 g.turn_over_rule=strTurnOverRule,
                 g.check_excess=strCheckExcess,g.um_check_excess=strUmCheckExcess, g.pick_excess=strPickExcess,
                 g.divide_excess=strDivideExcess, g.temperature_flag=strTemperatureFlag,
                 g.measure_mode=strMeasureMode, g.scan_flag=strScanFlag,
                 g.check_qty_flag=strCheckQtyFlag, g.check_qty_rate=strCheckQtyRate,
                 g.check_weight_flag=strCheckWeightFlag, g.check_weight_rate=strCheckWeightRate,
                 g.qc_flag=strQcFlag, g.qc_rate=strQcRate,
                 g.mix_flag=strMixFlag, g.double_check=strDoubleCheck,
                 g.i_strategy=strIStrategy, g.o_strategy=strOStrategy, g.m_strategy=strMStrategy,
                 g.ri_strategy=strRiStrategy, g.ro_strategy=strOStrategy, g.fc_strategy=strFcStrategy,
                 g.rsv_strategy1=strRsvStrategy1, g.rsv_strategy2=strRsvStrategy2,
                 g.rsv_strategy3=strRsvStrategy3, g.rsv_strategy4=strRsvStrategy4,
                 g.rsv_strategy5=strRsvStrategy5, g.rsv_strategy6=strRsvStrategy6,
                 g.print_flag=strPrintFlag,g.updt_name=strRgstName,g.updt_date=sysdate
                 where g.enterprise_no=strEnterpriseNo
                 and g.owner_no=strOwnerNo and g.group_no=strGroupNo;

               update bdef_article_group g set  g.status=strStatus
               where g.enterprise_no=strEnterpriseNo
               and g.owner_no=strOwnerNo and g.group_no=strGroupNo;


               --修改该中类下的小类
               update bdef_article_group g set
                 g.freezerate=strFreezerate,
                 g.alarmrate=strAlarmrate,
                 g.turn_over_rule=strTurnOverRule,
                 g.check_excess=strCheckExcess,g.um_check_excess=strUmCheckExcess, g.pick_excess=strPickExcess,
                 g.divide_excess=strDivideExcess, g.temperature_flag=strTemperatureFlag,
                 g.measure_mode=strMeasureMode, g.scan_flag=strScanFlag,
                 g.check_qty_flag=strCheckQtyFlag, g.check_qty_rate=strCheckQtyRate,
                 g.check_weight_flag=strCheckWeightFlag, g.check_weight_rate=strCheckWeightRate,
                 g.qc_flag=strQcFlag, g.qc_rate=strQcRate,
                 g.mix_flag=strMixFlag, g.double_check=strDoubleCheck,
                 g.i_strategy=strIStrategy, g.o_strategy=strOStrategy, g.m_strategy=strMStrategy,
                 g.ri_strategy=strRiStrategy, g.ro_strategy=strOStrategy, g.fc_strategy=strFcStrategy,
                 g.rsv_strategy1=strRsvStrategy1, g.rsv_strategy2=strRsvStrategy2,
                 g.rsv_strategy3=strRsvStrategy3, g.rsv_strategy4=strRsvStrategy4,
                 g.rsv_strategy5=strRsvStrategy5, g.rsv_strategy6=strRsvStrategy6,
                 g.print_flag=strPrintFlag,g.updt_name=strRgstName,g.updt_date=sysdate
               where g.enterprise_no=strEnterpriseNo and g.owner_no=strOwnerNo
                 and g.m_group_no=strGroupNo and g.freezerate=ps.freezerate and g.turn_over_rule=ps.turn_over_rule and
                 g.check_excess=ps.check_excess and g.um_check_excess=ps.um_check_excess and g.pick_excess=ps.pick_excess and
                 g.divide_excess=ps.divide_excess and g.temperature_flag=ps.temperature_flag and
                 g.measure_mode=ps.measure_mode and g.scan_flag=ps.scan_flag and
                 g.check_qty_flag=ps.check_qty_flag and g.check_qty_rate=ps.check_qty_rate and
                 g.check_weight_flag=ps.check_weight_flag and g.check_weight_rate=ps.check_weight_rate and
                 g.qc_flag=ps.qc_flag and g.qc_rate=ps.qc_rate and
                 g.mix_flag=ps.mix_flag and g.double_check=ps.double_check and
                 g.i_strategy=ps.i_strategy and g.o_strategy=ps.o_strategy and g.m_strategy=ps.m_strategy and
                 g.ri_strategy=ps.ri_strategy and g.ro_strategy=ps.ro_strategy and g.fc_strategy=ps.fc_strategy and
               /*  g.rsv_strategy1=ps.rsv_strategy1 and g.rsv_strategy2=ps.rsv_strategy2 and
                 g.rsv_strategy3=ps.rsv_strategy3 and g.rsv_strategy4=ps.rsv_strategy4 and
                 g.rsv_strategy5=ps.rsv_strategy5 and g.rsv_strategy6=ps.rsv_strategy6 and*/
                 g.print_flag=ps.print_flag;

               update bdef_article_group g set  g.status=strStatus
               where g.enterprise_no=strEnterpriseNo
               and g.owner_no=strOwnerNo and g.m_group_no=strGroupNo;

               --修改该中类下的商品
               update bdef_defarticle g set
                 g.freezerate=strFreezerate,
                 g.alarmrate=strAlarmrate,
                 g.turn_over_rule=strTurnOverRule,
                 g.check_excess=strCheckExcess,g.um_check_excess=strUmCheckExcess, g.pick_excess=strPickExcess,
                 g.divide_excess=strDivideExcess, g.temperature_flag=strTemperatureFlag,
                 g.measure_mode=strMeasureMode, g.scan_flag=strScanFlag,
                 g.check_qty_flag=strCheckQtyFlag, g.check_qty_rate=strCheckQtyRate,
                 g.check_weight_flag=strCheckWeightFlag, g.check_weight_rate=strCheckWeightRate,
                 g.qc_flag=strQcFlag, g.qc_rate=strQcRate,
                 g.mix_flag=strMixFlag, g.double_check=strDoubleCheck,
                 g.i_strategy=strIStrategy, g.o_strategy=strOStrategy, g.m_strategy=strMStrategy,
                 g.ri_strategy=strRiStrategy, g.ro_strategy=strOStrategy, g.fc_strategy=strFcStrategy,
                 g.rsv_strategy1=strRsvStrategy1, g.rsv_strategy2=strRsvStrategy2,
                 g.rsv_strategy3=strRsvStrategy3, g.rsv_strategy4=strRsvStrategy4,
                 g.rsv_strategy5=strRsvStrategy5, g.rsv_strategy6=strRsvStrategy6,
                 g.print_flag = (case when g.print_flag = ps.print_flag then
                    strPrintFlag else g.print_flag end),--修改中类下的商品打印标识

                 g.updt_name=strRgstName,g.updt_date=sysdate
                 where g.enterprise_no=strEnterpriseNo and g.owner_no=strOwnerNo
                 and g.group_no in
                  (select p.group_no from bdef_article_group p where p.enterprise_no=strEnterpriseNo
                      and p.owner_no=strOwnerNo and p.m_group_no=strGroupNo)
                 and g.freezerate=ps.freezerate and g.turn_over_rule=ps.turn_over_rule and
                 g.check_excess=ps.check_excess and g.um_check_excess=ps.um_check_excess and g.pick_excess=ps.pick_excess and
                 g.divide_excess=ps.divide_excess and g.temperature_flag=ps.temperature_flag and
                 g.measure_mode=ps.measure_mode and g.scan_flag=ps.scan_flag and
                 g.check_qty_flag=ps.check_qty_flag and g.check_qty_rate=ps.check_qty_rate and
                 g.check_weight_flag=ps.check_weight_flag and g.check_weight_rate=ps.check_weight_rate and
                 g.qc_flag=ps.qc_flag and g.qc_rate=ps.qc_rate and
                 g.mix_flag=ps.mix_flag and g.double_check=ps.double_check and
                 g.i_strategy=ps.i_strategy and g.o_strategy=ps.o_strategy and g.m_strategy=ps.m_strategy and
                 g.ri_strategy=ps.ri_strategy and g.ro_strategy=ps.ro_strategy and g.fc_strategy=ps.fc_strategy and
               /*  g.rsv_strategy1=ps.rsv_strategy1 and g.rsv_strategy2=ps.rsv_strategy2 and
                 g.rsv_strategy3=ps.rsv_strategy3 and g.rsv_strategy4=ps.rsv_strategy4 and
                 g.rsv_strategy5=ps.rsv_strategy5 and g.rsv_strategy6=ps.rsv_strategy6 and*/
                 g.print_flag=ps.print_flag;

               update bdef_defarticle g set  g.status=v_strStatus
               where g.enterprise_no=strEnterpriseNo
               and g.owner_no=strOwnerNo  and g.group_no in
                  (select p.group_no from bdef_article_group p where p.enterprise_no=strEnterpriseNo
                      and p.owner_no=strOwnerNo and p.m_group_no=strGroupNo);

           else --小类
              update bdef_article_group g set g.freezerate=strFreezerate,
              g.alarmrate=strAlarmrate,
              g.turn_over_rule=strTurnOverRule,
                 g.check_excess=strCheckExcess,g.um_check_excess=strUmCheckExcess, g.pick_excess=strPickExcess,
                 g.divide_excess=strDivideExcess, g.temperature_flag=strTemperatureFlag,
                 g.measure_mode=strMeasureMode, g.scan_flag=strScanFlag,
                 g.check_qty_flag=strCheckQtyFlag, g.check_qty_rate=strCheckQtyRate,
                 g.check_weight_flag=strCheckWeightFlag, g.check_weight_rate=strCheckWeightRate,
                 g.qc_flag=strQcFlag, g.qc_rate=strQcRate,
                 g.mix_flag=strMixFlag, g.double_check=strDoubleCheck,
                 g.i_strategy=strIStrategy, g.o_strategy=strOStrategy, g.m_strategy=strMStrategy,
                 g.ri_strategy=strRiStrategy, g.ro_strategy=strOStrategy, g.fc_strategy=strFcStrategy,
                 g.rsv_strategy1=strRsvStrategy1, g.rsv_strategy2=strRsvStrategy2,
                 g.rsv_strategy3=strRsvStrategy3, g.rsv_strategy4=strRsvStrategy4,
                 g.rsv_strategy5=strRsvStrategy5, g.rsv_strategy6=strRsvStrategy6,
                 g.print_flag=strPrintFlag,g.updt_name=strRgstName,g.updt_date=sysdate
                 where g.enterprise_no=strEnterpriseNo
                 and g.owner_no=strOwnerNo and g.group_no=strGroupNo;


               update bdef_article_group g set  g.status=strStatus
               where g.enterprise_no=strEnterpriseNo
               and g.owner_no=strOwnerNo and g.group_no=strGroupNo;

              update bdef_defarticle g set g.freezerate=strFreezerate,
                 g.alarmrate=strAlarmrate,
                   g.turn_over_rule=strTurnOverRule,
                 g.check_excess=strCheckExcess,g.um_check_excess=strUmCheckExcess, g.pick_excess=strPickExcess,
                 g.divide_excess=strDivideExcess, g.temperature_flag=strTemperatureFlag,
                 g.measure_mode=strMeasureMode, g.scan_flag=strScanFlag,
                 g.check_qty_flag=strCheckQtyFlag, g.check_qty_rate=strCheckQtyRate,
                 g.check_weight_flag=strCheckWeightFlag, g.check_weight_rate=strCheckWeightRate,
                 g.qc_flag=strQcFlag, g.qc_rate=strQcRate,
                 g.mix_flag=strMixFlag, g.double_check=strDoubleCheck,
                 g.i_strategy=strIStrategy, g.o_strategy=strOStrategy, g.m_strategy=strMStrategy,
                 g.ri_strategy=strRiStrategy, g.ro_strategy=strOStrategy, g.fc_strategy=strFcStrategy,
                 g.rsv_strategy1=strRsvStrategy1, g.rsv_strategy2=strRsvStrategy2,
                 g.rsv_strategy3=strRsvStrategy3, g.rsv_strategy4=strRsvStrategy4,
                 g.rsv_strategy5=strRsvStrategy5, g.rsv_strategy6=strRsvStrategy6,

                 /*if(g.print_flag=ps.print_flag) then
                 g.print_flag=strPrintFlag;
                 end if;*/
                 g.updt_name=strRgstName,g.updt_date=sysdate,
                 g.print_flag = (case when g.print_flag = ps.print_flag then
                    strPrintFlag else g.print_flag end)--判断主档表和类别表打印标识是否一致，是：该；否：不该
                 where g.enterprise_no=strEnterpriseNo
                 and g.owner_no=strOwnerNo
                 and g.group_no = strGroupNo ;
             --    and g.print_flag = (case when g.print_flag = ps.print_flag then
                --    strPrintFlag else g.print_flag end);

               update bdef_defarticle g set  g.status=v_strStatus
               where g.enterprise_no=strEnterpriseNo
               and g.owner_no=strOwnerNo and g.group_no =strGroupNo;

           end if;

       end loop;


     else --新增
       insert into bdef_article_group(
         enterprise_no,
         owner_no, group_no,
         group_name, m_group_no, m_group_name,
         l_group_no, l_group_name,
         group_level, batch_id,
         status, create_flag,
         alarmrate, freezerate,
         turn_over_rule, check_excess,
         um_check_excess, pick_excess,
         divide_excess, temperature_flag,
         measure_mode, scan_flag,
         check_qty_flag, check_qty_rate,
         check_weight_flag, check_weight_rate,
         qc_flag, qc_rate,
         mix_flag, double_check,
         i_strategy, o_strategy, m_strategy,
         ri_strategy, ro_strategy, fc_strategy,
         rsv_strategy1, rsv_strategy2,
         rsv_strategy3, rsv_strategy4,
         rsv_strategy5, rsv_strategy6,
         rgst_name, rgst_date,
         print_flag)
        values(
         strEnterpriseNo,
         strOwnerNo,strGroupNo,
         strGroupName,strMGroupNo,strMGroupName,
         strLGroupNo,strLGroupName,
         strGroupLevel,1,1,1,
         strAlarmrate,strFreezerate,
         strTurnOverRule,strCheckExcess,
         strUmCheckExcess,strPickExcess,
         strDivideExcess,strTemperatureFlag,
         strMeasureMode,strScanFlag,
         strCheckQtyFlag,strCheckQtyRate,
         strCheckWeightFlag,strCheckWeightRate,
         strQcFlag,strQcRate,
         strMixFlag,strDoubleCheck,
         strIStrategy,strOStrategy,strMStrategy,
         strRiStrategy,strRoStrategy,strFcStrategy,
         strRsvStrategy1,strRsvStrategy2,
         strRsvStrategy3,strRsvStrategy4,
         strRsvStrategy5,strRsvStrategy6,
         strRgstName,Sysdate,
         strPrintFlag
         );

     end if;


     strOutMsg:='Y|';
   end saveOrUpdateGroup;
   /**********************************************************************************************************
   hcx
   2015.11.19
   功能：校验客户与电子标签储位对应关系是否可以解除
***********************************************************************************************************/

    procedure P_CheckDeliverCustNo(strEnterpriseNo in cset_cust_dpscell.enterprise_no%type,
                                             strWarehouseNo  in cset_cust_dpscell.warehouse_no%type,
                                             strOwnerNo     in cset_cust_dpscell.owner_no%type,
                                             strCustNo    in cset_cust_dpscell.cust_no%type,
                                             strResult       out varchar2) is
  v_Count            integer := 0;
  begin
     strResult := 'N|[P_CheckDeliverCustNo]';

   begin
     --检查是否有验收扫描未封箱商品
     select count(*)
       into v_Count
       from idata_check_pal_tmp icpt
       where icpt.enterprise_no=strEnterpriseNo
       and icpt.warehouse_no=strWarehouseNo
       and icpt.owner_no=strOwnerNo
       and icpt.cust_no=strCustNo;

    if v_Count>0 then
       strResult := 'N|[该客户有验收扫描未封箱商品，不能删除！]';
       return;
    end if;

     --检查是否有定位未发单的分播数据
     select count(*)
       into v_Count
       from odata_outstock_direct ood
       where ood.enterprise_no=strEnterpriseNo
       and ood.warehouse_no=strWarehouseNo
       and ood.owner_no=strOwnerNo
       and ood.cust_no=strCustNo
       and ood.pick_type='1';

    if v_Count>0 then
       strResult := 'N|[该客户有定位未发单的分播数据，不能删除！]';
       return;
    end if;

     --检查是否有发单未拣货回单的分播数据
     select count(*)
       into v_Count
       from odata_outstock_d ood,odata_outstock_m oom
       where ood.enterprise_no=oom.enterprise_no
       and ood.warehouse_no=oom.warehouse_no
       and ood.owner_no=oom.owner_no
       and ood.outstock_no=oom.outstock_no
       and ood.enterprise_no=strEnterpriseNo
       and ood.warehouse_no=strWarehouseNo
       and ood.owner_no=strOwnerNo
       and ood.cust_no=strCustNo
       and oom.outstock_type='0'
       and oom.pick_type='1';

    if v_Count>0 then
       strResult := 'N|[该客户有发单未拣货回单的分播数据，不能删除！]';
       return;
    end if;

     --检查是否有未分播完成数据
     select count(*)
       into v_Count
       from odata_divide_d odd
       where odd.enterprise_no=strEnterpriseNo
       and odd.warehouse_no=strWarehouseNo
       and odd.owner_no=strOwnerNo
       and odd.cust_no=strCustNo
       and odd.status<>'13';

    if v_Count>0 then
       strResult := 'N|[该客户有商品未分播完，不能删除！]';
       return;
    end if;

     --检查是否有分播完未封箱数据
     select count(*)
       into v_Count
       from dps_stock_label dsl,cset_cust_dpscell ccd
       where dsl.enterprise_no=ccd.enterprise_no
       and dsl.warehouse_no=ccd.warehouse_no
       and dsl.dps_cell_no=ccd.dps_cell_no
       and dsl.enterprise_no=strEnterpriseNo
       and dsl.warehouse_no=strWarehouseNo
       and ccd.owner_no=strOwnerNo
       and ccd.cust_no=strCustNo
       and dsl.status='1';

    if v_Count>0 then
       strResult := 'N|[该客户有商品分播后未封箱，不能删除！]';
       return;
    end if;

   end;

   strResult := 'Y';

  exception
   when others then
     strResult := 'N|' || SQLERRM ||
                  substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_CheckDeliverCustNo;


end PKOBJ_BDEF;

/

