create view V_SEARCH_9103_13 as
select oem.enterprise_no,
       oem.warehouse_no,
       oem.exp_no,
       oem.sourceexp_no,
       oem.updt_date as exp_date,
       oem.owner_no,
       oem.contactor_name as cust,
       oed.article_no,
       bda.article_name,
       bda.owner_article_no,
       bda.article_identifier,
       bda.barcode,
       nvl(bdp.packing_qty, 1) packing_qty,
       bda.unit,
       bda.spec,
       ((bda.unit_volumn * odd.qty) / 1000000) volumn,
       (bda.unit_weight *odd.qty) weight,
       oed.article_qty as articleQty,
       odd.qty as outQty,
       (oed.article_qty - odd.qty) as shortQty
  from odata_exp_m oem
  join odata_exp_d oed
    on oem.enterprise_no = oed.enterprise_no
   and oem.warehouse_no = oed.warehouse_no
   and oem.exp_no = oed.exp_no
   and oem.owner_no = oed.owner_no
  left join odata_deliver_d odd
    on odd.enterprise_no = oed.enterprise_no
   and odd.warehouse_no = oed.warehouse_no
   and odd.owner_no = oed.owner_no
   and odd.exp_no = oed.exp_no
   and odd.article_no = oed.article_no
  left join bdef_defarticle bda
    on bda.enterprise_no = oed.enterprise_no
   and bda.article_no = oed.article_no
   and bda.owner_no = oed.owner_no
   and bda.owner_article_no = oed.owner_article_no
  left join bdef_article_packing bdp
    on bdp.enterprise_no = bda.enterprise_no
   and bdp.article_no = bda.article_no
 /*group by oem.enterprise_no,
          oem.warehouse_no,
          oem.exp_no,
          oem.sourceexp_no,
          oem.updt_date,
          oem.owner_no,
          oem.contactor_name,
          oed.article_no,
          oed.article_no,
          bda.article_name,
          bda.owner_article_no,
          bda.article_identifier,
          bda.barcode,
          bdp.packing_qty,
          bda.unit,
          bda.spec,
          bda.unit_volumn,
          bda.unit_weight;
*/


/

