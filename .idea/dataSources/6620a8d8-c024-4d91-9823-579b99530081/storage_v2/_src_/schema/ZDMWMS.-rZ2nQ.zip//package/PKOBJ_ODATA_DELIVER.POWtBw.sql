create package        PKOBJ_ODATA_DELIVER is

  --建立装车建议单头档
  procedure P_odata_loadcarHead(strEnterprise             in    odata_loadpropose_m.enterprise_no%type,--企业编码
                                  strWareHouseNo            in    odata_loadpropose_m.warehouse_no%type,--仓库编码
                                  strCustNo                 in    Odata_Loadpropose_m.Cust_No%type,--客户编码
                                  strShipperNo              in    odata_loadpropose_m.shipper_no%type,--承运商编码
                                  strLineNo                 in    odata_loadpropose_m.line_no%type,--线路
                                  strCarNo                  in    bdef_defcar.car_no%type,---车辆编码
                                  strUserId                 in    odata_loadpropose_m.rgst_name%type,
                                  strDockNo                 in    odata_loadpropose_m.dock_no%type,
                                  strDivideTrunk            in    odata_loadpropose_m.divide_truck%type,--分车编号
                                  strcarPlanNo              IN    odata_loadpropose_m.car_plan_no%type,--派车计划单
                                  strSealNo                 in    Odata_Loadpropose_m.Seal_No%type,--封条号
                                  strLoadType               in    odata_loadpropose_m.loadtype%type,--装车类型：1：按承运商；2：线路；3：配送对象（客户、单）
                                  strProposeNo              out    odata_loadpropose_m.loadpropose_no%type,--建议单号
                                  strResult                 OUT    varchar2);

  /**********************************************************************************************************
     luozhiling
     2013.11.10
     功能：新增装车建议单明细
  ***********************************************************************************************************/
  procedure P_odata_loadcarItem(strEnterpriseNo in odata_loadpropose_m.enterprise_no%type, --企业编码
                                strWareHouseNo  in odata_loadpropose_m.warehouse_no%type, --仓库编码
                                strProposeNo    in odata_loadpropose_m.loadpropose_no%type,
                                strContainerNo  in stock_label_m.label_no%type, --标签号
                                strUserId       in odata_loadpropose_m.updt_name%type, --装车人
                                strPaperUserId  in odata_loadpropose_m.updt_name%type, --单据人
                                strResult       OUT varchar2);

/**********************************************************************************************************
   lich
   2014.06.04
   功能：新增出货配送单头档
***********************************************************************************************************/
    procedure P_Insert_Odata_Deliver_M(strEnterpriseNo           in    odata_loadpropose_m.enterprise_no%type,--企业
                                       strWareHouseNo            in    odata_loadpropose_m.warehouse_no%type,--仓库编码
                                       strOwnerNo                in    odata_deliver_m.owner_no%type,
                                       strProposeNo              in    odata_loadpropose_m.loadpropose_no%type,--装车建议单号
                                       strDeliverOBJ             IN    ODATA_LOADPROPOSE_D.Deliver_Obj%type,
                                       strUserId                 in    odata_loadpropose_m.updt_name%type,--装车人
                                       strDeliverNo              out   odata_deliver_m.deliver_no%type,
                                       strResult                 OUT   varchar2);
/**********************************************************************************************************
   lich
   2014.06.04
   功能：新增出货配送明细
***********************************************************************************************************/
    procedure P_Insert_Odata_Deliver_D(strEnterpriseNo           in    odata_loadpropose_m.enterprise_no%type,--企业
                                       strWareHouseNo            in    odata_loadpropose_m.warehouse_no%type,--仓库编码
              	                       strDeliverNo              in    odata_deliver_d.deliver_no%type,--分播单号
                                       strProposeNo              in    odata_loadpropose_m.loadpropose_no%type,--装车建议单号
                                       strDeliverObj             in    odata_loadpropose_d.deliver_obj%type,--配送对象
                                       strUserId                 in    odata_loadpropose_m.updt_name%type,--装车人
                                       strResult                 OUT   varchar2);

  /*******************************************************************************************************
  创建人：huangb
  创建时间：2016.05.17
  功能说明：出货单和装车单以及封车单据转历史
  ********************************************************************************************************/
  procedure P_Deliver_InsertHTY(strEnterpriseNo in odata_loadpropose_m.enterprise_no%type, --企业编码
                                strWareHouseNo  in odata_loadpropose_m.warehouse_no%type, --仓库编码
                                strProposeNo    in odata_loadpropose_m.loadpropose_no%type,
                                strUserID       in odata_loadpropose_m.rgst_name%type,
                                strOutMsg       out varchar2);

  /*******************************************************************************************************
  创建人：huangb
  创建时间：2016.05.17
  功能说明：封车单据转历史 供JOB调用
  ********************************************************************************************************/
  procedure P_Deliver_InsertHTYByJob;

  /*******************************************************************************************************
  创建人：huangb
  创建时间：2016.05.17
  功能说明：封车单据转历史 供接口调用
  ********************************************************************************************************/
  procedure P_Deliver_InsertHTYByInterface(strEnterpriseNo   in odata_deliver_mhty.enterprise_no%type, --企业编号
                                           strWareHouseNo    in odata_deliver_mhty.warehouse_no%type, --仓库编码
                                           strReportUpSerial in odata_deliver_mhty.REPORT_UP_SERIAL%type, --上传序列号
                                           strOutMsg         out varchar2);

end PKOBJ_ODATA_DELIVER;


/

