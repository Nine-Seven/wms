create view V_SEARCH_9103_007 as
select "ENTERPRISE_NO","WAREHOUSE_NO","OWNER_NO","LABEL_NO","ARTICLE_QTY","REAL_QTY","OPERATE_DATE","DIVIDE_DATE","STATUS","STATUS_DESC","DPS_CELL_NO","D_LABEL_NO","SOURCE_NO","BATCH_NO","WAVE_NO","DIVIDE_NO","RGST_NAME","ARTICLE_NO","PACKING_QTY","CUST_NO","UPDT_NAME","BARCODE","ARTICLE_NAME","GROUP_NO","GROUP_NAME","L_GROUP_NO","L_GROUP_NAME","OWNER_ARTICLE_NO","CUST_NAME"
  from (select odm.enterprise_no,
               odm.warehouse_no,
               odm.owner_no,
               sld.label_no,
               odd.article_qty,
               odd.real_qty,
               trunc(nvl(odd.divide_date, odD.operate_date)) operate_date,
               odd.divide_date,
               odd.status,
               wdv.text           status_desc,
               odd.dps_cell_no,
               slm.label_no       as d_label_no,
               odd.source_no,
               odd.batch_no,
               odd.wave_no,
               odd.divide_no,
               odm.rgst_name,
               odd.article_no,
               odd.packing_qty,
               odd.cust_no,
               odm.updt_name,
               v.BARCODE,
               v.ARTICLE_NAME,
               v.GROUP_NO,
               v.GROUP_NAME,
               v.L_GROUP_NO,
               v.L_GROUP_NAME,
               v.OWNER_ARTICLE_NO,
               --vg.max_group_name,
               bdc.cust_name
          from (select *
                  from odata_divide_m
                union
                select * from odata_divide_mhty) odm
          join (select *
                 from odata_divide_d odd
                 where odd.status='13'
               union
               select * from odata_divide_dhty) odd
            on odm.enterprise_no = odd.enterprise_no
           and odm.warehouse_no = odd.warehouse_no
           and odm.owner_no = odd.owner_no
           and odm.divide_no = odd.divide_no
          left join (select *
                      from stock_label_m
                    union
                    select * from stock_label_mhty) sld
            on odd.enterprise_no = sld.enterprise_no
           and odd.warehouse_no = sld.warehouse_no
           and odd.s_container_no = sld.container_no
          join v_bdef_defarticle v
            on odd.owner_no = v.OWNER_NO
           and odd.article_no = v.ARTICLE_NO
           and v.ENTERPRISE_NO = odd.enterprise_no
          join v_bdef_defarticle  vg
            on vg.enterprise_no=v.enterprise_no
            and vg.group_no=v.GROUP_NO
          join bdef_defcust bdc
            on odd.owner_no = bdc.owner_no
           and odd.enterprise_no = bdc.enterprise_no
           and odd.cust_no = bdc.cust_no
          left join wms_deffieldval wdv
            on odd.status = wdv.value
           and wdv.table_name = 'N'
           and wdv.colname = 'STATUS'
          left join (select *
                      from stock_label_m
                    union
                    select * from stock_label_mhty) slm
            on odd.enterprise_no = slm.enterprise_no
           and odd.warehouse_no = slm.warehouse_no
           and odd.cust_container_no = slm.container_no
        /*where odd.status<'13' and odd.exp_type='OE'*/
        ) c

/

