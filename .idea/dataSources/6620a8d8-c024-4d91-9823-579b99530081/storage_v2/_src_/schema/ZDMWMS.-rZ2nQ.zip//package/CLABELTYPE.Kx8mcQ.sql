create PACKAGE        CLabelType is


        -- 板标签
        LABEL_TYPE_P CONSTANT STOCK_LABEL_M.Container_Type%type := 'P';       --板标签

        -- 原装箱标签
        LABEL_TYPE_C CONSTANT STOCK_LABEL_M.Container_Type%type := 'C';           --原装箱标签

        -- 物流箱标签
        LABEL_TYPE_B CONSTANT STOCK_LABEL_M.Container_Type%type := 'B';             --物流箱标签

        -- 虚拟物流箱
        LABEL_TYPE_D CONSTANT STOCK_LABEL_M.Container_Type%type:= 'D';         --虚拟物流箱

        --笼车
        LABEL_TYPE_R CONSTANT STOCK_LABEL_M.Container_Type%type:= 'R';         --笼车

        --T 型 板标签
        LABEL_TYPE_R CONSTANT STOCK_LABEL_M.Container_Type%type:= 'T';         --T 型 板标签


end CLabelType;


/

