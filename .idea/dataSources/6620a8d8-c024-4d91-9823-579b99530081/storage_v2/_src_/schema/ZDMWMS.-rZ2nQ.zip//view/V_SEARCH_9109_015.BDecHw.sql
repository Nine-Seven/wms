create view V_SEARCH_9109_015 as
select i."ENTERPRISE_NO",i."WAREHOUSE_NO", i."WORKER_NO",i."WORKER_NAME",i."OPERATE_DATE",i."SUMQTY",i."CLASSTYPETEXT",i."STARTTIME",i."ENDTIME",floor((endtime - starttime) * 24 * 60) -
       case when to_char(starttime,'hh24:mi:ss') >= '13:00:00'  then 0 else
       case when to_char(endtime,'hh24:mi:ss') <= '12:30:00' then 0 else 90 end end
       as work_duration,
       floor(((sum(sumqty) over (partition by worker_no,operate_date))/(floor((endtime - starttime) * 24 * 60)+1  -
       case when to_char(starttime,'hh24:mi:ss') >= '13:00:00'  then 0 else
       case when to_char(endtime,'hh24:mi:ss') <= '12:30:00' then 0 else 90 end end))*60) qty_per_hour from
(select t.enterprise_no,
               t.warehouse_no,
               t.worker_no,
       t.worker_name,
       t.operate_date,
       t.sumqty,
       f_get_fieldtext('N', 'CLASS_TYPE', t.class_type) as classTypeText,
       min(starttime) over (partition by t.worker_no,t.operate_date) as starttime,
       max(endtime) over (partition by t.worker_no,t.operate_date) as endtime
  from (select icd.enterprise_no,
               icd.warehouse_no,
               b.worker_no,
               b.worker_name,icd.class_type,
               trunc(icd.scan_date) as operate_date,
               min(icd.scan_date) starttime,
               max(icd.scan_date) endtime,
               sum(icd.real_qty) as sumqty
          from (select rod.enterprise_no,rod.warehouse_no,rod.article_no,
          rod.real_qty as real_qty,rod.scan_date,rod.scan_name,rom.class_type
           from cdef_defarea cda,cdef_defcell cdc, rodata_outstock_d rod,rodata_outstock_m rom
                where cda.enterprise_no=cdc.enterprise_no
                  and cda.warehouse_no=cdc.warehouse_no
                  and cda.ware_no=cdc.ware_no
                  and cda.area_no=cdc.area_no
                  and cda.area_usetype in ('1','5','6')
                  and cdc.enterprise_no=rod.enterprise_no
                  and cdc.warehouse_no=rod.warehouse_no
                  and cdc.cell_no=rod.s_cell_no
                  and rod.enterprise_no=rom.enterprise_no
                  and rod.warehouse_no=rom.warehouse_no
                  and rod.outstock_no=rom.outstock_no
                  and rom.task_type = '1'
          union select rod.enterprise_no,rod.warehouse_no,rod.article_no,
          rod.real_qty as real_qty,rod.scan_date,rod.scan_name,rom.class_type
           from cdef_defarea cda,cdef_defcell cdc, rodata_outstock_dhty rod,rodata_outstock_mhty rom
                where cda.enterprise_no=cdc.enterprise_no
                  and cda.warehouse_no=cdc.warehouse_no
                  and cda.ware_no=cdc.ware_no
                  and cda.area_no=cdc.area_no
                  and cda.area_usetype in ('1','5','6')
                  and cdc.enterprise_no=rod.enterprise_no
                  and cdc.warehouse_no=rod.warehouse_no
                  and cdc.cell_no=rod.s_cell_no
                  and rod.enterprise_no=rom.enterprise_no
                  and rod.warehouse_no=rom.warehouse_no
                  and rod.outstock_no=rom.outstock_no
                  and rom.task_type = '1'
          ) icd, bdef_defworker b,bdef_defarticle bda
         where   bda.enterprise_no=icd.enterprise_no
         and bda.article_no=icd.article_no
         and b.enterprise_no=icd.enterprise_no
         and b.worker_no = icd.scan_name
         group by icd.enterprise_no,icd.warehouse_no,icd.class_type, b.worker_no, b.worker_name, trunc(icd.scan_date)
         having sum(icd.real_qty)>0) t) i
 order by worker_no,operate_date,classTypeText

/

