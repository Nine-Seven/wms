create trigger TRG_STOCK_CONTENT_LIST
    before insert
    on STOCK_CONTENT_LIST
    for each row
declare
i_id integer;
begin
select SEQ_STOCK_CONTENT_LIST.nextval into i_id from dual;
:NEW.ROW_ID := i_id;
end;


/

