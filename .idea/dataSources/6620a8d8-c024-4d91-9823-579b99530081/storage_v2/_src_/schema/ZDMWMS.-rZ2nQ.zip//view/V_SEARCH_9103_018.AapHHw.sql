create view V_SEARCH_9103_018 as
    select a.enterprise_no,a.warehouse_no,a.owner_no,a.exp_no,a.check_no,a.lable_no,a.article_no,a.packing_qty,
  a.article_qty plan_qty,a.article_qty,a.real_qty,a.status,a.check_name,a.check_date,
  b.article_name,b.barcode ,m.cust_no,m.check_chute_no,trunc(a.check_date) operate_date,cust.cust_name,a.d_label_no
from odata_check_label_d  a,odata_check_m m,bdef_defarticle b,bdef_defcust cust
where a.enterprise_no=m.ENTERPRISE_NO and a.enterprise_no=b.enterprise_no and a.warehouse_no=m.warehouse_no
and a.check_no=m.check_no and a.article_no=b.article_no
and m.enterprise_no=cust.enterprise_no and m.cust_no=cust.cust_no and m.owner_no=cust.owner_no
union all
select a.enterprise_no,a.warehouse_no,a.owner_no,a.exp_no,a.check_no,a.lable_no,a.article_no,a.packing_qty,
  a.article_qty plan_qty,a.article_qty,a.real_qty,a.status,a.check_name,a.check_date,
  b.article_name,b.barcode ,m.cust_no,m.check_chute_no,trunc(a.check_date) operate_date ,cust.cust_name,a.d_label_no
from odata_check_label_dhty a,odata_check_mhty m,bdef_defarticle b,bdef_defcust cust
where a.enterprise_no=m.ENTERPRISE_NO and a.enterprise_no=b.enterprise_no and a.warehouse_no=m.warehouse_no
and a.check_no=m.check_no and a.article_no=b.article_no
and m.enterprise_no=cust.enterprise_no and m.cust_no=cust.cust_no and m.owner_no=cust.owner_no


/

