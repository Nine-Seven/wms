create view V_SEARCH_9109_7 as
select sdate,workname,outstock_no,sum(articleQty) articleQty,round(sum(volumn),3) volumn,round(sum(weight),3) weight,sum(real_qty) real_qty,round(sum(pk),0) pk,round(sum(ss),0) ss,round(sum(outpal),0) outpal,round(sum(inpal),0) inpal
from
(select to_date(to_char(oom.updt_date,'yyyy-MM-dd'),'yyyy-MM-dd') sdate,ood.outstock_name as workname,oom.outstock_no,count(distinct ood.article_no) articleQty,sum(bda.unit_volumn*ood.real_qty/1000000) volumn,sum(bda.unit_weight*ood.real_qty) weight,
sum(ood.real_qty) real_qty,sum(floor(ood.real_qty/ood.packing_qty)) pk,sum(mod(ood.real_qty,ood.packing_qty)) ss,sum(ood.real_qty/(bap.pal_base_qbox*bap.pal_height_qbox)) outpal,
0 as inpal
from odata_outstock_mhty oom,odata_outstock_dhty ood,bdef_defarticle bda,bdef_article_packing bap
where oom.warehouse_no = ood.warehouse_no
 and  oom.outstock_no = ood.outstock_no
 and  oom.outstock_type='1'
 and ood.article_no = bda.article_no
 and ood.owner_no = bda.owner_no
 and bda.article_no = bap.article_no
 and ood.packing_qty = bap.packing_qty
 group by to_date(to_char(oom.updt_date,'yyyy-MM-dd'),'yyyy-MM-dd'),ood.outstock_name,oom.outstock_no
 union all
 select to_date(to_char(oom.updt_date,'yyyy-MM-dd'),'yyyy-MM-dd') sdate,ood.instock_name as workname,oom.outstock_no,count(distinct ood.article_no) articleQty,sum(bda.unit_volumn*ood.real_qty/1000000) volumn,sum(bda.unit_weight*ood.real_qty) weight,
sum(ood.real_qty) real_qty,sum(floor(ood.real_qty/ood.packing_qty)) pk,sum(mod(ood.real_qty,ood.packing_qty)) ss,0 outpal,
sum(ood.real_qty/(bap.pal_base_qbox*bap.pal_height_qbox)) as inpal
from odata_outstock_mhty oom,odata_outstock_dhty ood,bdef_defarticle bda,bdef_article_packing bap
where oom.warehouse_no = ood.warehouse_no
 and  oom.outstock_no = ood.outstock_no
 and  oom.outstock_type='1'
 and ood.article_no = bda.article_no
 and ood.owner_no = bda.owner_no
 and bda.article_no = bap.article_no
 and ood.packing_qty = bap.packing_qty
 group by to_date(to_char(oom.updt_date,'yyyy-MM-dd'),'yyyy-MM-dd'),ood.instock_name,oom.outstock_no) a
 group by sdate,workname,outstock_no


/

