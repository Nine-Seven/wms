create package body PKLG_WMS_Public is
  /*****************************************************************************************
   功能：公用包，WMS系统共用
  Modify By luozhiling AT 2016-6-22
  *****************************************************************************************/
  /*根据码头取打印机组*/
  procedure GetPrintGroupByDockNo(strEnterpriseNo in bdef_defdock.enterprise_no%type,
                                  strWarehouse_No in bdef_defdock.warehouse_no%type,
                                  strDockNo       in bdef_defdock.dock_no%type,
                                  strPrintGroupNo out pntset_printer_dock.printer_group_no%type,
                                  strOutMsg       out varchar) is
  begin
    strOutMsg := 'N|[GetPrintGroupByDockNo]';
    begin
      select min(bpd.printer_group_no)
        into strPrintGroupNo
        from pntSET_PRINTER_WORKSTATION bpd
       where bpd.warehouse_no = strWarehouse_No
         and bpd.enterprise_no = strEnterpriseNo
         and bpd.workstation_no = strDockNo;
    exception
      when no_data_found then
        strPrintGroupNo := 'N';
    end;

    if strPrintGroupNo = 'N' or strPrintGroupNo is null then
      begin
        select min(bpd.printer_group_no)
          into strPrintGroupNo
          from pntset_printer_dock bpd
         where bpd.warehouse_no = strWarehouse_No
           and bpd.enterprise_no = strEnterpriseNo
           and bpd.dock_no = strDockNo;
      exception
        when no_data_found then
          strPrintGroupNo := 'N';
      end;
    end if;
    if strPrintGroupNo = 'N' or strPrintGroupNo is null then
      strPrintGroupNo := 'N';
      strOutMsg       := 'N|[E00015]';
      return;
    end if;
    strOutMsg := 'Y';

  end GetPrintGroupByDockNo;

  /*****************************************************************************************
   功能：获取库存三级帐行号
  Modify By luozhiling AT 2013-11-4
  *****************************************************************************************/
  procedure p_MoveContent_rowid(n_Row_id out stock_content_move.row_id%type) --返回行号
   is
  begin
    begin
      select SEQ_stock_CONTENT_MOVE.nextval into n_Row_id from dual;
    exception
      -----没有查到，默认为1----------
      when no_data_found then
        n_Row_id := 1;
    end;
  end p_MoveContent_rowid;

  procedure P_Insert_ScanLabelNoLog(strEnterpriseNo in bdef_scan_log.enterprise_no%type,
                                    strWarehouseNo  in BDEF_SCAN_LOG.warehouse_no%type,
                                    strOwnerNo      in stock_box_m.owner_no%type,
                                    strScanBarcode  in BDEF_SCAN_LOG.Scan_Barcode%type,
                                    strSourceNo     in BDEF_SCAN_LOG.Source_No%type,
                                    strArticleNo    in bdef_scan_log.article_no%type, --进货整箱扫描时传实际商品，其余默认为N
                                    strCellNo       in BDEF_SCAN_LOG.Cell_No%type, --默认传 'N '，盘点使用
                                    strCheckType    in BDEF_SCAN_LOG.Check_Type%type, --默认传 '1' ,盘点使用
                                    strWorkerNo     in BDEF_SCAN_LOG.Rgst_Name%type,
                                    strLabelNo      in BDEF_SCAN_LOG.Label_No%type,
                                    strType         in varchar2, --[进货：I],[出货：O],[库内操作:M]
                                    strResult       out varchar2) --返回N失败，I 箱码不存在，Y成功
   is
    v_iCount      integer;
    v_ArticleNo   BDEF_SCAN_LOG.Article_No%type;
    v_MergeBoxNo  BDEF_SCAN_LOG.MERGE_BOX_NO%type; --默认传 'N '，尾箱传箱号(Scan_Barcode)
    v_strDeptNo   BDEF_SCAN_LOG.dept_no%type; --默认传 'N '，盘点使用
    v_strScanFlag bdef_defowner.scan_flag%type;
    v_strStatus   stock_box_m.status%type;
    nPackingQty   idata_import_d.pacKing_qty%type;
    v_strBarcode  stock_box_D.Barcode%type;
  begin
    v_MergeBoxNo := 'N';
    v_strDeptNo  := 'N';
    v_iCount     := 0;
    -------------是否被扫描
    select count(*)
      into v_iCount
      from BDEF_SCAN_LOG bsl
     where bsl.warehouse_no = strWarehouseNo
       and bsl.enterprise_no = strEnterpriseNo
       and bsl.scan_barcode = strScanBarcode;
    if v_iCount > 0 then
      strResult := 'N|[E00016]';
      return;
    end if;
    ----------------------------------------------------------------------------------
    ---是否是唯一码
    begin
      v_iCount := 0;
      select distinct bda.ARTICLE_NO, bda.barcode
        into v_ArticleNo, v_strBarcode
        from bdef_defarticle bda
      /*left join bdef_article_barcode bab
       on bab.article_no = bda.article_no
      and bab.primary_flag = '1'
      and bab.packing_qty = '1'*/
       where upper(bda.article_identifier) =
             upper(substr(strScanBarcode, 0, length(strScanBarcode) - 6))
         and bda.status <> '0'
         and bda.owner_no = strOwnerNo;

      goto m_Index;
    exception
      when no_data_found then
        null;
    end;

    -------------是否存在箱码表
    select count(*)
      into v_iCount
      from stock_box_m sbm
     where sbm.warehouse_no = strWarehouseNo
       and sbm.enterprise_no = strEnterpriseNo
       and box_no = strScanBarcode;
    if v_iCount <= 0 then

      --检查此货主是否需要自动采集箱码
      select scan_flag
        into v_strScanFlag
        from bdef_defowner bd
       where bd.owner_no = strOwnerNo
         and bd.enterprise_no = strEnterpriseNo;
      if strType = 'I' then
        v_strStatus := '0';
      end if;
      if strType = 'O' then
        v_strStatus := '3';
      end if;

      if strType = 'I' and v_strScanFlag = '1' then
        --自动采集箱码

        --写箱码表头档
        insert into stock_box_m
          (enterprise_no,
           warehouse_no,
           owner_no,
           box_no,
           creat_date,
           status,
           box_type,
           dept_no)
        values
          (strEnterpriseNo,
           strWarehouseNo,
           strOwnerNo,
           strScanBarcode,
           trunc(sysdate),
           v_strStatus,
           '0',
           'N');

        --获取该商品包装数量
        begin
          select packing_qty
            into nPackingQty
            from idata_import_sd iis
           where iis.warehouse_no = strWarehouseNo
             and iis.enterprise_no = strEnterpriseNo
             and iis.s_import_no = strSourceNo
             and iis.article_no = strArticleNo
             AND iis.po_qty - iis.import_qty > 0
             and rownum = 1;
        end;
        --写箱码表明细
        insert into stock_box_d
          (enterprise_no,
           warehouse_no,
           owner_no,
           box_no,
           box_id,
           article_no,
           barcode,
           Produce_Date,
           Expire_Date,
           Lot_No,
           Qty)
        values
          (strEnterpriseNo,
           strWarehouseNo,
           strOwnerNo,
           strScanBarcode,
           1,
           strArticleNo,
           v_strBarcode,
           to_date('19000101', 'yyyymmdd'),
           to_date('19000101', 'yyyymmdd'),
           'N',
           nPackingQty);

      end if;

      if v_strScanFlag = '0' then
        strResult := 'N|[E00017]';
        return;
      end if;
    end if;

    for i_box_info in (select bda.ARTICLE_NO,
                              C.PACKING_QTY,
                              C.MAX_PACKING_QTY,
                              CBD.QTY,
                              CBM.BOX_NO,
                              CBM.BOX_TYPE,
                              CBM.STATUS,
                              CBM.dept_no
                         from bdef_defarticle BDA,
                              stock_box_m CBM,
                              stock_box_d CBD,
                              (SELECT MAX(BAP.PACKING_QTY) PACKING_QTY,
                                      MAX(BAP.PACKING_QTY) MAX_PACKING_QTY,
                                      BAP.ARTICLE_NO
                                 FROM (SELECT baq.enterprise_no,
                                              baq.warehouse_no,
                                              bap.article_No,
                                              bap.packing_qty
                                         FROM bdef_article_packing bap
                                         LEFT JOIN bdef_warehouse_packing baq
                                           ON baq.article_no = BAp.ARTICLE_NO
                                          AND baq.packing_qty =
                                              bap.packing_qty
                                          and baq.enterprise_no =
                                              bap.enterprise_no) BAP,
                                      stock_box_d CBD
                                WHERE BAP.ARTICLE_NO = CBD.ARTICLE_NO
                                  and bap.enterprise_no = cbd.enterprise_no
                                  and cbd.enterprise_no = strEnterpriseNo
                                  AND CBD.warehouse_no = strWarehouseNo
                                  AND CBD.BOX_NO = strScanBarcode
                                  AND CBD.OWNER_NO = strOwnerNo
                                GROUP BY BAP.ARTICLE_NO) C
                        where CBM.warehouse_no = CBD.warehouse_no
                          and cbm.enterprise_no = cbd.enterprise_no
                          and cbm.enterprise_no = strEnterpriseNo
                          AND CBM.OWNER_NO = CBD.OWNER_NO
                          AND CBM.BOX_NO = CBD.BOX_NO
                          AND CBD.ARTICLE_NO = BDA.ARTICLE_NO
                          and BDA.ARTICLE_NO = C.ARTICLE_NO
                          AND CBM.warehouse_no = strWarehouseNo
                          AND CBM.BOX_NO = strScanBarcode
                             --  AND CBM.s_iMPORT_nO =strSourceNo
                          AND CBM.OWNER_NO = strOwnerNo) loop
      v_iCount := v_iCount + 1;

      v_ArticleNo := i_box_info.article_no;
      if strType = 'I' then
        if strArticleNo <> v_ArticleNo THEN
          strResult := 'N|[E00018]';
          return;
        end if;
      end if;

      if strType = 'O' then
        if strArticleNo <> v_ArticleNo THEN
          strResult := 'N|[E00019]';
          return;
        end if;
      end if;
      v_strDeptNo  := i_box_info.dept_no;
      v_MergeBoxNo := i_box_info.box_no;

      exit;
    end loop;

    if v_iCount = 0 then
      strResult := 'N|[E00020]';
      return;
    end if;
    ----------------------------------------------------------------------------------
    <<m_Index>>
  ----新增扫描日志
    if strScanBarcode = v_MergeBoxNo then
      insert into bdef_scan_log
        (enterprise_no,
         warehouse_no,
         scan_barcode,
         source_no,
         article_no,
         cell_no,
         label_no,
         qty,
         rgst_name,
         rgst_date,
         check_type,
         operate_date,
         merge_box_no,
         dept_no)
        select sbd.enterprise_no,
               sbd.warehouse_no,
               sbd.box_no,
               strSourceNo,
               sbd.article_no,
               strCellNo,
               strLabelNo,
               sum(sbd.qty),
               strWorkerNo,
               sysdate,
               strCheckType,
               trunc(sysdate),
               v_MergeBoxNo,
               v_strDeptNo
          from stock_box_d sbd
         where sbd.warehouse_no = strWarehouseNo
           and sbd.enterprise_no = strEnterpriseNo
           and sbd.box_no = strScanBarcode
         group by sbd.enterprise_no,
                  sbd.warehouse_no,
                  sbd.box_no,
                  sbd.article_no;
      if (sql%rowcount <= 0) then
        strResult := 'N|[E00021]';
        return;
      end if;
      -----------进货修改扫描标识
      if strType = 'I' then
        update stock_box_m sbm
           set sbm.status = '1', sbm.s_import_no = strSourceNo
         where sbm.warehouse_no = strWarehouseNo
           and sbm.enterprise_no = strEnterpriseNo
           and box_no = strScanBarcode
           and status = '0';
        if (sql%rowcount <= 0) then
          strResult := 'N|[E00017]';
          return;
        end if;
      end if;
      -----------进货出货扫描标识
      if strType = 'O' then
        update stock_box_m sbm
           set sbm.status = '3', sbm.export_no = strSourceNo
         where sbm.warehouse_no = strWarehouseNo
           and sbm.enterprise_no = strEnterpriseNo
           and box_no = strScanBarcode
           and status = '2';
        if (sql%rowcount <= 0) then
          strResult := 'N|[E00017]';
          return;
        end if;
      end if;
    else
      insert into bdef_scan_log
        (enterprise_no,
         warehouse_no,
         scan_barcode,
         source_no,
         article_no,
         cell_no,
         label_no,
         qty,
         rgst_name,
         rgst_date,
         check_type,
         operate_date,
         merge_box_no,
         dept_no)
      values
        (strEnterpriseNo,
         strWarehouseNo,
         strScanBarcode,
         strSourceNo,
         v_ArticleNo,
         strCellNo,
         strLabelNo,
         1,
         strWorkerNo,
         sysdate,
         strCheckType,
         trunc(sysdate),
         v_MergeBoxNo,
         v_strDeptNo);
      if (sql%rowcount <= 0) then
        strResult := 'N|[E00021]';
        return;
      end if;

    end if;
    strResult := 'Y';
  end P_Insert_ScanLabelNoLog;

  procedure P_Insert_article_barcode(strEnterpriseNo   in bset_article_barcode_m.enterprise_no%type,
                                     strWareHouseNo    in bset_article_barcode_m.warehouse_no%type,
                                     strOwnerNo        in bset_article_barcode_m.owner_no%type,
                                     strPaperNo        in bset_article_barcode_m.paper_no%type,
                                     strArticleNo      in bset_article_barcode_d.article_no%type,
                                     strFirstArticleNo in bset_article_barcode_d.barcode_type%type, --0:非第一个商品；1：第一个商品
                                     strUserId         in bset_article_barcode_m.rgst_name%type,
                                     nInSerialNo       in bset_article_barcode_m.serial_no%type,
                                     nSerialNo         out bset_article_barcode_m.serial_no%type,
                                     strResult         out varchar2) is
    --nSerialNo              bset_article_barcode_d.serial_no%type;
  begin
    strResult := 'Y|成功！';

    --写头档
    if strFirstArticleNo = '1' then
      --去单号
      --获取流水号
      select SEQ_BSET_ARTICLE_BARCODE_M.nextval into nSerialNo from dual;
      insert into bset_article_barcode_m
        (enterprise_no,
         warehouse_no,
         owner_no,
         paper_no,
         status,
         rgst_name,
         rgst_date,
         serial_no)
      values
        (strEnterpriseNo,
         strWareHouseNo,
         strOwnerNo,
         strPaperNo,
         '10',
         strUserId,
         sysdate,
         nSerialNo);
    else
      nSerialNo := nInSerialNo;
    end if;
    --写明细
    insert into bset_article_barcode_d
      (enterprise_no,
       warehouse_no,
       owner_no,
       article_no,
       serial_no,
       packing_qty,
       status,
       barcode_type)
      select strEnterpriseNo,
             strWareHouseNo,
             strOwnerNo,
             strArticleNo,
             nSerialNo,
             t.packing_qty,
             '10',
             decode(t.packing_qty, 1, '1', '0')
        from bdef_article_packing t
       where t.article_no = strArticleNo;

  end P_Insert_article_barcode;

  /*  procedure P_Get_Boxbarcode
           (strEnterpriseNo   in         bset_article_barcode_m.enterprise_no%type,
            strWareHouseNo    in         bset_article_barcode_m.warehouse_no%type,
            nSerialNo         in         bset_article_barcode_m.serial_no%type,
            strArticleNo      in         bset_article_barcode_d.article_no%type,
            strBarcode        IN         bdef_defarticle.barcode%type,
            nPackingQty       in         bdef_article_packing.packing_qty%type,
            strUserId         in         bset_article_barcode_m.rgst_name%type,
            strResult         out        varchar2)is
        v_iCount              integer;
        v_strPrimaryFlag      bdef_article_barcode1.primary_flag%type;
        v_strOwnerNo          bdef_defarticle.owner_no%type;
    begin
        strResult:='Y|成功！';

        --获取商品货主信息
        select owner_no into v_strOwnerNo from bset_article_barcode_m
               where warehouse_no=strWareHouseNo and serial_no=nSerialNo
               and enterprise_no=strEnterpriseNo;


        update bset_article_barcode_m t set t.status=status
        where t.warehouse_no=strWareHouseNo and t.owner_no=v_strOwnerNo and t.enterprise_no=strEnterpriseNo
        and t.serial_no=nSerialNo;

        if sql%notfound then
           strResult:='N|[E00102]';
        end if;

        select count(*) into v_iCount from bdef_article_barcode1 bd where bd.article_no=strArticleNo
               and bd.packing_qty=nPackingQty and bd.enterprise_no=strEnterpriseNo;

        if v_iCount>0 then
           if nPackingQty>1 then
               strResult:='N|[E00101]';
               return;
           end if;

           if nPackingQty=1 then
              select count(*) into v_iCount from bdef_article_barcode1 bd where bd.article_no=strArticleNo
                     and bd.packing_qty=nPackingQty and bd.primary_flag='0' and bd.enterprise_no=strEnterpriseNo
                     and bd.barcode=strBarcode;
               if v_iCount>0 then
                   strResult:='N|[E00101]';
                   return;
               end if;
              --直接将当前条码更新为主条码
              update bdef_article_barcode t set barcode=strBarcode,
                     updt_name=strUserId,updt_date=sysdate,primary_flag='1'
                     where t.article_no=strArticleNo and t.enterprise_no=strEnterpriseNo
                     and t.packing_qty=nPackingQTY and rownum=1;

              if sql%notfound then
                  --写条码表
                  insert into bdef_article_barcode(enterprise_no,barcode,owner_no,article_no,primary_flag,packing_qty,create_flag,rgst_name,
                         rgst_date)
                       values(strEnterpriseNo,strBarcode,v_strOwnerNo,strArticleNo,'1',nPackingQty,'1',strUserId,sysdate);
              end if;
           end if;
        else
            if nPackingQty>1 then
               v_strPrimaryFlag:='0';--包装大于1的为非主条码
            else
               v_strPrimaryFlag:='1';--包装=1的为主条码
            end if;

            --写条码表
            insert into bdef_article_barcode(enterprise_no,barcode,owner_no,article_no,primary_flag,packing_qty,create_flag,rgst_name,
                   rgst_date)
                 values(strEnterpriseNo,strBarcode,v_strOwnerNo,strArticleNo,v_strPrimaryFlag,nPackingQty,'1',strUserId,sysdate);
        end if;

        --更新条码采集表
        update bset_article_barcode_d t set t.barcode=strBarcode,t.status='13',updt_name=strUserId,updt_date=sysdate
               where t.owner_no=v_strOwnerNo and t.serial_no=nSerialNo and t.article_no=strArticleNo
               and t.enterprise_no=strEnterpriseNo
               and t.packing_qty=nPackingQty and t.warehouse_no=strWareHouseNo;



       --更新条码采集表头档
       update bset_article_barcode_m t set t.status='13',t.updt_name=strUserId,t.updt_date=sysdate
              where t.warehouse_no=strWareHouseNo and t.owner_no=v_strOwnerNo and t.enterprise_no=strEnterpriseNo
              AND T.serial_no=nSerialNo and not exists
              (select 'x' from bset_article_barcode_d where warehouse_no=strWareHouseNo
              and enterprise_no=strEnterpriseNo
              and owner_no=V_strOwnerNo and serial_no=nSerialNo and t.status='10');

    end P_Get_Boxbarcode;
  */
  PROCEDURE PROC_CREATE_STOCK_BOX(strEnterpriseNo in stock_box_m.enterprise_no%type,
                                  strWarehouseNo  in stock_box_m.warehouse_no%type,
                                  strArticleNo    in stock_box_d.article_no%type,
                                  strBoxNo        in stock_box_m.box_no%type,
                                  nPackingQty     in stock_box_d.qty%type,
                                  strUserId       in stock_box_m.rgst_name%type,
                                  strResult       out varchar2) IS
    v_iCOUNT       integer;
    v_strOwnerNo   bdef_defarticle.owner_no%type;
    v_strBarcodeNo bdef_defarticle.barcode%type;
  BEGIN
    --首先判断该箱码是否已在系统里存在
    select count(*)
      into v_iCount
      from stock_box_m
     where box_no = strBoxNo
       and enterprise_no = strEnterpriseNo
       and warehouse_no = strWarehouseNo;
    if v_iCount > 0 then
      strResult := 'N|[E00101]';
      return;
    end if;

    --获取商品对应的货主信息

    select owner_no, barcode
      into v_strOwnerNo, v_strBarcodeNo
      from bdef_defarticle
     where article_no = strArticleNo
       and enterprise_no = strEnterpriseNo;

    --写箱码表
    insert into stock_box_m
      (enterprise_no,
       warehouse_no,
       owner_no,
       box_no,
       creat_date,
       status,
       rgst_name,
       rgst_date)
    values
      (strEnterpriseNo,
       strWareHouseNo,
       v_strOwnerNo,
       strBoxNo,
       trunc(sysdate),
       '0',
       strUserId,
       sysdate);

    --获取箱码表最大的box_id
    select nvl(max(box_id) + 1, 1)
      into v_iCount
      from stock_box_d
     where warehouse_no = strWarehouseNo
       and enterprise_no = strEnterpriseNo
       and owner_no = v_strOwnerNo
       and box_no = strBoxNo;

    --写箱码表明细
    insert into stock_box_d
      (enterprise_no,
       warehouse_no,
       owner_no,
       box_no,
       box_id,
       article_no,
       barcode,
       qty)
    values
      (strEnterpriseNo,
       strWareHouseNo,
       v_strOwnerNo,
       strBoxNo,
       v_iCount,
       strArticleNo,
       v_strBarcodeNo,
       nPackingQty);

    strResult := 'Y|';

  END PROC_CREATE_STOCK_BOX;

  /*************************************************************************************************************
  功能说明：补印中心,
            目前只能补印进货验收和出货标签，补货、退货和返配标签暂不支持
            2015.9.22
  *************************************************************************************************************/
  procedure P_PrintLabel(strEnterPriseNo in job_printtask_m.Enterprise_No%type,
                         strWareHouseNo  in job_printtask_m.Warehouse_No%type,
                         strLabelNo      in stock_label_m.label_no%type,
                         strDockNo       in pntset_printer_group.printer_group_no%type,
                         strUserId       in stock_label_m.updt_name%type,
                         strOutMsg       out varchar2) is
    v_strUseType     stock_label_m.use_type%type;
    v_strStatus      stock_label_m.status%type;
    v_strSourceNo    stock_label_m.source_no%type;
    v_strPrtTask     stock_label_m.source_no%type;
    v_strReportId    stock_label_m.report_id%type;
    v_strContainerNo stock_label_m.container_no%type;
    v_strHtyFlag     job_printtask_m.hty_flag%type := '0';
    v_strLabelNo     stock_label_m.label_no%type;
  begin
    strOutMsg    := 'N|[P_PrintLabel]';
    v_strLabelNo := strLabelNo;
    --获取标签类型和状态
    begin
      select source_no, container_no, report_id, use_type, status
        into v_strSourceNo,
             v_strContainerNo,
             v_strReportId,
             v_strUseType,
             v_strStatus
        from stock_label_m
       where enterprise_no = strEnterPriseNo
         and warehouse_no = strWareHouseNo
         and label_no = strLabelNo;

      if v_strUseType = '0' then
        --收货标签
        --根据标签查找上架单
        begin
          select distinct t.instock_no
            into v_strSourceNo
            from idata_instock_d t
           where t.enterprise_no = strEnterPriseNo
             and t.warehouse_no = strWareHouseNo
             and t.label_no = strLabelNo
             and rownum <= 1;
        exception
          when no_data_found then
            strOutMsg := 'N|[该标签已做上架]';
            return;
        end;

      end if;

      if v_strUseType = '1' then
        if v_strStatus >= '52' then
          v_strReportId := CONST_REPORTID.IM_ID_Cust_type_p;

/*           if v_strDelierObjLevel='1' then
              v_strReportId:=CONST_REPORTID.IM_ID_Exp_type_p;
           else
              v_strReportId:=CONST_REPORTID.IM_ID_Cust_type_p;
           end if;  */
        else
          v_strLabelNo := v_strContainerNo;
        end if;
      end if;

      if v_strUseType = '2' then
        --分播标签，需判断是直通或存储
        if v_strStatus = '52' then
          if substr(v_strSourceNo, 1, 2) = CONST_REPORT_TYPE.ODATAHO then
            --存储标签
            v_strHtyFlag := '1';
          end if;
          v_strLabelNo := v_strContainerNo;
        end if;
      end if;

      if v_strStatus > '52' then
        v_strSourceNo := strLabelNo;
      end if;

      PKOBJ_PRINTTASK.p_insert_printCenter(strEnterpriseNo,
                                           strWarehouseNo,
                                           v_strSourceNo,
                                           '0',
                                           v_strReportId,
                                           v_strLabelNo,
                                           strDockNo,
                                           v_strHtyFlag,
                                           1,
                                           strUserId,
                                           v_strPrtTask,
                                           strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
    exception
      when no_data_found then
        --返配或者退货标签标签表查询不到数据 --预留

        begin
          select cc.label_no
            into v_strSourceNo
            from stock_content cc
           where cc.enterprise_no = strEnterpriseNo
             and cc.warehouse_no = strWarehouseNo
             and cc.label_no = strLabelNo;
          v_strHtyFlag  := '1';
          v_strReportId := 'HM8200BD';
          PKOBJ_PRINTTASK.p_insert_printCenter(strEnterpriseNo,
                                               strWarehouseNo,
                                               v_strSourceNo,
                                               '0',
                                               v_strReportId,
                                               v_strLabelNo,
                                               strDockNo,
                                               v_strHtyFlag,
                                               1,
                                               strUserId,
                                               v_strPrtTask,
                                               strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;

        exception
          when no_data_found then

            --首先查找是否是返配标签
            strOutMsg := 'N|[找不到标签信息]';
            return;
        end;
    end;

    strOutMsg := 'Y|[成功]';
  end P_PrintLabel;

 /*=====================================================================================
  hb 20160624
  获取报表ID 底层用 返回唯一报表ID
  ======================================================================================*/
  PROCEDURE p_GetReportId(strEnterPriseNo in wms_warehouse_outorder.enterprise_no%type,--企业号
                          strWarehouseNo  in job_printtask_m.warehouse_no%type,--仓别号
                          strPaperType    in pntset_module_report.paper_type%type,--单据类型 参考包CONST_REPORT_TYPE
                          strReportType   in pntset_module_report.report_type%type,--报表类型 L:表单；M:标签头档；D:标签明细;WAY-面单;INV-发票;BOX-装箱清
                          strSourceNo     in job_printtask_m.source_no%type, --源单号
                          --返回参数
                          strReportId     out pntset_module_report.report_id%type, --返回报表ID
                          strOutMsg       out varchar2) is
  --解析变量
  v_ReportId        pntset_module_report.report_id%type := 'N'; --返回报表ID
  v_PaperType       pntset_module_report.paper_type%type := 'N';--单据类型 例如'HO','IP','SS'等wms内部产生的单据类型,参考包CONST_DOCUMENTTYPE
  v_TaskType        pntset_module_report.task_type%type := 'N';--任务类型 0：标签发单；1：纯表单发单（纯RF发单）2：任务标签发单；
  v_PickType        pntset_module_report.pick_type%type := 'N';--作业类型 0-摘果；1-播种
  v_OperateType     pntset_module_report.operate_type%type := 'N';--操作类型 'P','C','B','MIX'
  v_ReportType      pntset_module_report.report_type%type := 'N';--报表类型 L:表单;M:标签头档;D:标签明细;WAY-面单;INV-发票;BOX-装箱清
  v_OrderType       pntset_module_report.order_type%type := 'N';--行业标识;1：传统；2：电商
  v_DeliverObjLevel pntset_module_report.deliver_obj_level%type := 'N';--配送对象级别 0:按客户,1:按单据,2:按实体客户
  v_UseType         pntset_module_report.use_type%type := 'N';--标签用途：0：收货标签；1：客户标签；2：分播标签；3：移库标签
  v_OwnerNo         pntset_module_report.owner_no%type := 'N';--货主编码
  v_CustNo          pntset_module_report.cust_no%type := 'N';--客户编码
  v_ShipperNo       pntset_module_report.shipper_no%type := 'N';--承运商编码

  --查询变量
  s_WaveNo  odata_locate_batch.wave_no%type := 'N';--波次号
  s_BatchNo odata_locate_batch.batch_no%type := 'N';--批次号

  begin
   strOutMsg := 'N|p_GetReportId';

   /*解析单据类型paper_type*/
   v_PaperType := strPaperType;

   /*解析报表类型report_type*/
   v_ReportType := strReportType;

   /*解析task_type,pick_type,operate_type,owner_no*/
   --出货发单,移库
   if(v_PaperType = CONST_REPORT_TYPE.ODATAHO
      or v_PaperType = CONST_REPORT_TYPE.MDATAHS) and strReportType <> 'L' then
     begin
       select oom.owner_no, oom.task_type, oom.pick_type, oom.operate_type, oom.wave_no, oom.batch_no
         into v_OwnerNo, v_TaskType, v_PickType, v_OperateType, s_WaveNo, s_BatchNo
         from odata_outstock_m oom
        where oom.enterprise_no = strEnterPriseNo and oom.warehouse_no = strWarehouseNo
          and oom.outstock_no = strSourceNo;
     exception
       when no_data_found then
         strOutMsg := 'N|获取报表ID-单据['|| strSourceNo ||']在表[odata_outstock_m]中不存在';
         return;
     end;
     --取客户
     begin
       select ood.cust_no
         into v_CustNo
         from odata_outstock_d ood
        where ood.enterprise_no = strEnterPriseNo and ood.warehouse_no = strWarehouseNo
          and ood.outstock_no = strSourceNo and rownum = 1;
     exception
       when no_data_found then
         strOutMsg := 'N|获取报表ID-单据['|| strSourceNo ||']在表[odata_outstock_d]中不存在';
         return;
     end;
   end if;
   --出货发单,移库 单据 huangb 20160729
   if v_PaperType = CONST_REPORT_TYPE.ODATAHO and strReportType = 'L' then
     begin
       select oom.pick_type, oom.wave_no, oom.batch_no, oom.owner_no
         into v_PickType, s_WaveNo, s_BatchNo, v_OwnerNo
         from odata_outstock_m oom
        where oom.enterprise_no = strEnterPriseNo and oom.warehouse_no = strWarehouseNo
          and oom.outstock_no = strSourceNo;
     exception
       when no_data_found then
         strOutMsg := 'N|获取报表ID-单据['|| strSourceNo ||']在表[odata_outstock_m]中不存在';
         return;
     end;
   end if;
   --分播单据
   if v_PaperType = CONST_REPORT_TYPE.ODATARD then
     begin
       select odd.owner_no, odd.wave_no, odd.batch_no
         into v_OwnerNo, s_WaveNo, s_BatchNo
         from odata_divide_m odd
        where odd.enterprise_no = strEnterPriseNo and odd.warehouse_no = strWarehouseNo
          and odd.divide_no = strSourceNo ;
     exception
       when no_data_found then
         strOutMsg := 'N|获取报表ID-单据['|| strSourceNo ||']在表[odata_outstock_m]中不存在';
         return;
     end;
   end if;

   --装车单据
   if v_PaperType = CONST_REPORT_TYPE.ODATAOL or v_PaperType = CONST_REPORT_TYPE.ODATAOL1 then
     begin
       select max(odd.wave_no)
         into s_WaveNo
         from odata_loadpropose_m a, odata_deliver_m odm, odata_deliver_d odd
        where odm.enterprise_no = a.enterprise_no
          and odm.warehouse_no = a.warehouse_no
          and odm.loadpropose_no = a.loadpropose_no
          and odd.enterprise_no = odm.enterprise_no
          and odd.warehouse_no = odm.warehouse_no
          and odd.deliver_no = odm.deliver_no
          and a.warehouse_no = strWareHouseNo
          and a.enterprise_no = strEnterpriseNo
          and a.loadpropose_no = strSourceNo;
     exception
       when no_data_found then
       strOutMsg := 'N|获取报表ID-单据['|| strSourceNo ||']在表[odata_loadpropose_m]中不存在';
       return;
     end;
   end if;

   --封车单据
   if v_PaperType = CONST_REPORT_TYPE.ODATAOD then
     begin
       select max(odd.wave_no) into s_WaveNo
         from odata_deliver_d odd
        where odd.enterprise_no = strEnterPriseNo and odd.warehouse_no = strWarehouseNo
          and odd.deliver_no = strSourceNo;
     exception
       when no_data_found then
         strOutMsg := 'N|获取报表ID-单据['|| strSourceNo ||']在表[odata_deliver_d]中不存在';
         return;
     end;

   end if;

   --封车箱明细
   if v_PaperType = CONST_REPORT_TYPE.ODATAODBOX then
     begin
       select max(odd.wave_no) into s_WaveNo
         from odata_deliver_d odd
        where odd.enterprise_no = strEnterPriseNo and odd.warehouse_no = strWarehouseNo
          and odd.container_no = strSourceNo;
     exception
       when no_data_found then
         strOutMsg := 'N|获取报表ID-单据['|| strSourceNo ||']在表[odata_deliver_d]中不存在';
         return;
     end;

   end if;

   --进货汇总单据
   if (v_PaperType = CONST_REPORT_TYPE.IDATAIMPORTSS
      or v_PaperType = CONST_REPORT_TYPE.IDATAIMPORTSD) then
     begin
       select iimm.owner_no into v_OwnerNo
         from idata_import_mm iimm
        where iimm.enterprise_no = strEnterPriseNo and iimm.warehouse_no = strWarehouseNo
          and iimm.s_import_no = strSourceNo;
     exception
       when no_data_found then
         strOutMsg := 'N|获取报表ID-单据['|| strSourceNo ||']在表[odata_outstock_m]中不存在';
         return;
     end;
   end if;

   --验收汇总单据
   if v_PaperType = CONST_REPORT_TYPE.IDATASC then
     begin
       select icm.owner_no into v_OwnerNo
         from idata_check_m icm
        where icm.enterprise_no = strEnterPriseNo and icm.warehouse_no = strWarehouseNo
          and icm.s_check_no = strSourceNo;
     exception
       when no_data_found then
         strOutMsg := 'N|获取报表ID-单据['|| strSourceNo ||']在表[idata_check_m]中不存在';
         return;
     end;
   end if;

   --上架单据
   if v_PaperType = CONST_REPORT_TYPE.IDATAIP then
     begin
       select iim.owner_no into v_OwnerNo
         from idata_instock_m iim
        where iim.enterprise_no = strEnterPriseNo and iim.warehouse_no = strWarehouseNo
          and iim.instock_no = strSourceNo;
     exception
       when no_data_found then
         strOutMsg := 'N|获取报表ID-单据['|| strSourceNo ||']在表[idata_instock_m]中不存在';
         return;
     end;
   end if;

   /*解析行业标识;1：传统；2：电商 ORDER_TYPE*/
   --出货发单,装车,封车
   if v_PaperType = CONST_REPORT_TYPE.ODATAHO
      or v_PaperType = CONST_REPORT_TYPE.ODATAOL or v_PaperType = CONST_REPORT_TYPE.ODATAOL1
      or v_PaperType = CONST_REPORT_TYPE.ODATAODBOX or v_PaperType = CONST_REPORT_TYPE.ODATAOD then
     begin
       select INDUSTRY_FLAG
         into v_OrderType
         from odata_locate_batch
        where enterprise_no = strEnterPriseNo and warehouse_no = strWarehouseNo --and owner_no = v_OwnerNo
          and wave_no = s_WaveNo and rownum = 1;
     exception
       when no_data_found then
         strOutMsg := 'N|获取报表ID-波次['|| s_WaveNo ||']在表[odata_locate_batch]中不存在';
         return;
     end;

   end if;

   /*解析配送对象级别deliver_obj_level*/
   --出货发单或分播
   if (v_PaperType = CONST_REPORT_TYPE.ODATAHO and strReportType <> 'L')
      or v_PaperType = CONST_REPORT_TYPE.ODATARD then
     begin
       select deliver_obj_level
         into v_DeliverObjLevel
         from odata_locate_batch
        where enterprise_no = strEnterPriseNo and warehouse_no = strWarehouseNo --and owner_no = v_OwnerNo
          and wave_no = s_WaveNo and batch_no = s_BatchNo;
     exception
       when no_data_found then
         strOutMsg := 'N|获取报表ID-波次['|| s_WaveNo ||']批次['|| s_BatchNo ||']在表[odata_locate_batch]中不存在';
         return;
     end;

   end if;

   /*解析标签用途use_type*/
   if(v_PaperType = CONST_REPORT_TYPE.ODATAHO
      or v_PaperType = CONST_REPORT_TYPE.MDATAHS) and strReportType <> 'L' then
     begin
       select nvl(slm.use_type,'N') into v_UseType
         from odata_outstock_m oom,stock_label_m slm
        where slm.enterprise_no(+) = oom.enterprise_no
          and slm.warehouse_no(+) = oom.warehouse_no
          and slm.source_no(+) = oom.outstock_no
          and oom.enterprise_no = strEnterPriseNo
          and oom.warehouse_no = strWarehouseNo
          and oom.outstock_no = strSourceNo
          and rownum = 1;
     exception
       when no_data_found then
         strOutMsg := 'N|获取报表ID-单据['|| strSourceNo ||']在表[odata_outstock_m]中不存在';
         return;
     end;
   end if;

   /*解析承运商编码shipper_no*/
   if v_ReportType = CREPORT_TYPE.TYPE_WAY then
     begin
       select nvl(bd.shipper_no,'N') into v_ShipperNo
         from odata_exp_m oem, bdef_defshipper bd
        where oem.enterprise_no = bd.enterprise_no(+)
          and oem.warehouse_no = bd.warehouse_no(+)
          and oem.shipper_no = bd.shipper_no(+)
          and oem.enterprise_no = strEnterPriseNo
          and oem.warehouse_no = strWarehouseNo
          and oem.exp_no = strSourceNo;
     exception
       when no_data_found then
         begin
           select DISTINCT nvl(opd.shipper_no,'N') into v_ShipperNo
             from odata_package_d opd
            where opd.enterprise_no = strEnterPriseNo
              and opd.warehouse_no = strWarehouseNo
              and opd.sourceexp_no = strSourceNo;
         exception
           when no_data_found then
             strOutMsg := 'N|获取报表ID-单据['|| strSourceNo ||']在表[odata_exp_m或odata_package_d]中不存在';
             return;
         end;
     end;
   end if;

   /*获取报表ID*/
   p_getReportSqlBySet(
     strEnterpriseNo,--企业
     strPaperType,--单据类型 例如'HO','IP','SS'等wms内部产生的单据类型，可为标签
     v_TaskType,--任务类型 0：标签发单；1：纯表单发单（纯RF发单）2：任务标签发单；
     v_PickType,--作业类型 0-摘果；1-播种
     v_OperateType,--操作类型 'P','C','B'
     strReportType,--报表类型 L:表单；M:标签头档；D:标签明细
     v_OrderType,--订单类型 例如'OE','ID'
     v_DeliverObjLevel,--配送对象级别 0:按客户,1:按单据,2:按实体客户
     v_UseType,--标签用途：0：收货标签；1：客户标签；2：分播标签；3：移库标签
     v_OwnerNo,--货主编码
     v_CustNo,--客户编码
     v_ShipperNo,--承运商编码
     'N','N','N','N','N','N','N','N',
     v_ReportId,--返回sql语句
     strOutMsg);
   if instr(strOutMsg, 'N', 1, 1) = 1 then
     return;
   end if;
   strReportId := v_ReportId;
   strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_GetReportId;

   /*=====================================================================================
  hb 20160624
  获取报表ID（扩展） 底层用 返回唯一报表ID
  ======================================================================================*/
  PROCEDURE p_GetReportIdExt(strEnterPriseNo in wms_warehouse_outorder.enterprise_no%type, --企业号
                             strWarehouseNo  in job_printtask_m.warehouse_no%type, --仓别号
                             strPaperType    in pntset_module_report.paper_type%type, --单据类型 参考包CONST_REPORT_TYPE
                             strReportType   in pntset_module_report.report_type%type, --报表类型 L:表单；M:标签头档；D:标签明细;WAY-面单;INV-发票;BOX-装箱清
                             strSourceNo     in job_printtask_m.source_no%type, --源单号
                             strRsvVarod1    in pntset_module_report.rsv_varod1%type, --预留字段
                             strRsvVarod2    in pntset_module_report.rsv_varod2%type, --预留字段
                             strRsvVarod3    in pntset_module_report.rsv_varod3%type, --预留字段
                             strRsvVarod4    in pntset_module_report.rsv_varod4%type, --预留字段
                             strRsvVarod5    in pntset_module_report.rsv_varod5%type, --预留字段
                             strRsvVarod6    in pntset_module_report.rsv_varod6%type, --预留字段
                             strRsvVarod7    in pntset_module_report.rsv_varod7%type, --预留字段
                             strRsvVarod8    in pntset_module_report.rsv_varod8%type, --预留字段
                             --返回参数
                             strReportId out pntset_module_report.report_id%type, --返回报表ID
                             strOutMsg   out varchar2) is
    --解析变量
    v_ReportId        pntset_module_report.report_id%type := 'N'; --返回报表ID
    v_PaperType       pntset_module_report.paper_type%type := 'N'; --单据类型 例如'HO','IP','SS'等wms内部产生的单据类型,参考包CONST_DOCUMENTTYPE
    v_TaskType        pntset_module_report.task_type%type := 'N'; --任务类型 0：标签发单；1：纯表单发单（纯RF发单）2：任务标签发单；
    v_PickType        pntset_module_report.pick_type%type := 'N'; --作业类型 0-摘果；1-播种
    v_OperateType     pntset_module_report.operate_type%type := 'N'; --操作类型 'P','C','B','MIX'
    v_ReportType      pntset_module_report.report_type%type := 'N'; --报表类型 L:表单;M:标签头档;D:标签明细;WAY-面单;INV-发票;BOX-装箱清
    v_OrderType       pntset_module_report.order_type%type := 'N'; --行业标识;1：传统；2：电商
    v_DeliverObjLevel pntset_module_report.deliver_obj_level%type := 'N'; --配送对象级别 0:按客户,1:按单据,2:按实体客户
    v_UseType         pntset_module_report.use_type%type := 'N'; --标签用途：0：收货标签；1：客户标签；2：分播标签；3：移库标签
    v_OwnerNo         pntset_module_report.owner_no%type := 'N'; --货主编码
    v_CustNo          pntset_module_report.cust_no%type := 'N'; --客户编码
    v_ShipperNo       pntset_module_report.shipper_no%type := 'N'; --承运商编码

    --查询变量
    s_WaveNo  odata_locate_batch.wave_no%type := 'N'; --波次号
    s_BatchNo odata_locate_batch.batch_no%type := 'N'; --批次号

  begin
    strOutMsg := 'N|p_GetReportId';

    /*解析单据类型paper_type*/
    v_PaperType := strPaperType;

    /*解析报表类型report_type*/
    v_ReportType := strReportType;

    /*解析task_type,pick_type,operate_type,owner_no*/
    --出货发单,移库
    if (v_PaperType = CONST_REPORT_TYPE.ODATAHO or
       v_PaperType = CONST_REPORT_TYPE.MDATAHS) and strReportType <> 'L' then
      begin
        select oom.owner_no,
               oom.task_type,
               oom.pick_type,
               oom.operate_type,
               oom.wave_no,
               oom.batch_no
          into v_OwnerNo,
               v_TaskType,
               v_PickType,
               v_OperateType,
               s_WaveNo,
               s_BatchNo
          from odata_outstock_m oom
         where oom.enterprise_no = strEnterPriseNo
           and oom.warehouse_no = strWarehouseNo
           and oom.outstock_no = strSourceNo;
      exception
        when no_data_found then
          strOutMsg := 'N|获取报表ID-单据[' || strSourceNo ||
                       ']在表[odata_outstock_m]中不存在';
          return;
      end;
      --取客户
      begin
        select ood.cust_no
          into v_CustNo
          from odata_outstock_d ood
         where ood.enterprise_no = strEnterPriseNo
           and ood.warehouse_no = strWarehouseNo
           and ood.outstock_no = strSourceNo
           and rownum = 1;
      exception
        when no_data_found then
          strOutMsg := 'N|获取报表ID-单据[' || strSourceNo ||
                       ']在表[odata_outstock_d]中不存在';
          return;
      end;
    end if;
    --出货发单,移库 单据 huangb 20160729
    if v_PaperType = CONST_REPORT_TYPE.ODATAHO and strReportType = 'L' then
      begin
        select oom.pick_type, oom.wave_no, oom.batch_no, oom.owner_no
          into v_PickType, s_WaveNo, s_BatchNo, v_OwnerNo
          from odata_outstock_m oom
         where oom.enterprise_no = strEnterPriseNo
           and oom.warehouse_no = strWarehouseNo
           and oom.outstock_no = strSourceNo;
      exception
        when no_data_found then
          strOutMsg := 'N|获取报表ID-单据[' || strSourceNo ||
                       ']在表[odata_outstock_m]中不存在';
          return;
      end;
    end if;
    --分播单据
    if v_PaperType = CONST_REPORT_TYPE.ODATARD then
      begin
        select odd.owner_no, odd.wave_no, odd.batch_no
          into v_OwnerNo, s_WaveNo, s_BatchNo
          from odata_divide_m odd
         where odd.enterprise_no = strEnterPriseNo
           and odd.warehouse_no = strWarehouseNo
           and odd.divide_no = strSourceNo;
      exception
        when no_data_found then
          strOutMsg := 'N|获取报表ID-单据[' || strSourceNo ||
                       ']在表[odata_outstock_m]中不存在';
          return;
      end;
    end if;

    --装车单据
    if v_PaperType = CONST_REPORT_TYPE.ODATAOL or
       v_PaperType = CONST_REPORT_TYPE.ODATAOL1 then
      begin
        select max(odd.wave_no)
          into s_WaveNo
          from odata_loadpropose_m a,
               odata_deliver_m     odm,
               odata_deliver_d     odd
         where odm.enterprise_no = a.enterprise_no
           and odm.warehouse_no = a.warehouse_no
           and odm.loadpropose_no = a.loadpropose_no
           and odd.enterprise_no = odm.enterprise_no
           and odd.warehouse_no = odm.warehouse_no
           and odd.deliver_no = odm.deliver_no
           and a.warehouse_no = strWareHouseNo
           and a.enterprise_no = strEnterpriseNo
           and a.loadpropose_no = strSourceNo;
      exception
        when no_data_found then
          strOutMsg := 'N|获取报表ID-单据[' || strSourceNo ||
                       ']在表[odata_loadpropose_m]中不存在';
          return;
      end;
    end if;

    --封车单据
    if v_PaperType = CONST_REPORT_TYPE.ODATAOD then
      begin
        select max(odd.wave_no)
          into s_WaveNo
          from odata_deliver_d odd
         where odd.enterprise_no = strEnterPriseNo
           and odd.warehouse_no = strWarehouseNo
           and odd.deliver_no = strSourceNo;
      exception
        when no_data_found then
          strOutMsg := 'N|获取报表ID-单据[' || strSourceNo ||
                       ']在表[odata_deliver_d]中不存在';
          return;
      end;

    end if;

    --封车箱明细
    if v_PaperType = CONST_REPORT_TYPE.ODATAODBOX then
      begin
        select max(odd.wave_no)
          into s_WaveNo
          from odata_deliver_d odd
         where odd.enterprise_no = strEnterPriseNo
           and odd.warehouse_no = strWarehouseNo
           and odd.container_no = strSourceNo;
      exception
        when no_data_found then
          strOutMsg := 'N|获取报表ID-单据[' || strSourceNo ||
                       ']在表[odata_deliver_d]中不存在';
          return;
      end;

    end if;

    --进货汇总单据
    if (v_PaperType = CONST_REPORT_TYPE.IDATAIMPORTSS or
       v_PaperType = CONST_REPORT_TYPE.IDATAIMPORTSD) then
      begin
        select iimm.owner_no
          into v_OwnerNo
          from idata_import_mm iimm
         where iimm.enterprise_no = strEnterPriseNo
           and iimm.warehouse_no = strWarehouseNo
           and iimm.s_import_no = strSourceNo;
      exception
        when no_data_found then
          strOutMsg := 'N|获取报表ID-单据[' || strSourceNo ||
                       ']在表[odata_outstock_m]中不存在';
          return;
      end;
    end if;

    --验收汇总单据
    if v_PaperType = CONST_REPORT_TYPE.IDATASC then
      begin
        select icm.owner_no
          into v_OwnerNo
          from idata_check_m icm
         where icm.enterprise_no = strEnterPriseNo
           and icm.warehouse_no = strWarehouseNo
           and icm.s_check_no = strSourceNo;
      exception
        when no_data_found then
          strOutMsg := 'N|获取报表ID-单据[' || strSourceNo ||
                       ']在表[idata_check_m]中不存在';
          return;
      end;
    end if;

    --上架单据
    if v_PaperType = CONST_REPORT_TYPE.IDATAIP then
      begin
        select iim.owner_no
          into v_OwnerNo
          from idata_instock_m iim
         where iim.enterprise_no = strEnterPriseNo
           and iim.warehouse_no = strWarehouseNo
           and iim.instock_no = strSourceNo;
      exception
        when no_data_found then
          strOutMsg := 'N|获取报表ID-单据[' || strSourceNo ||
                       ']在表[idata_instock_m]中不存在';
          return;
      end;
    end if;

    /*解析行业标识;1：传统；2：电商 ORDER_TYPE*/
    --出货发单,装车,封车
    if v_PaperType = CONST_REPORT_TYPE.ODATAHO or
       v_PaperType = CONST_REPORT_TYPE.ODATAOL or
       v_PaperType = CONST_REPORT_TYPE.ODATAOL1 or
       v_PaperType = CONST_REPORT_TYPE.ODATAODBOX or
       v_PaperType = CONST_REPORT_TYPE.ODATAOD then
      begin
        select INDUSTRY_FLAG
          into v_OrderType
          from odata_locate_batch
         where enterprise_no = strEnterPriseNo
           and warehouse_no = strWarehouseNo --and owner_no = v_OwnerNo
           and wave_no = s_WaveNo
           and rownum = 1;
      exception
        when no_data_found then
          strOutMsg := 'N|获取报表ID-波次[' || s_WaveNo ||
                       ']在表[odata_locate_batch]中不存在';
          return;
      end;

    end if;

    /*解析配送对象级别deliver_obj_level*/
    --出货发单或分播
    if (v_PaperType = CONST_REPORT_TYPE.ODATAHO and strReportType <> 'L') or
       v_PaperType = CONST_REPORT_TYPE.ODATARD then
      begin
        select deliver_obj_level
          into v_DeliverObjLevel
          from odata_locate_batch
         where enterprise_no = strEnterPriseNo
           and warehouse_no = strWarehouseNo --and owner_no = v_OwnerNo
           and wave_no = s_WaveNo
           and batch_no = s_BatchNo;
      exception
        when no_data_found then
          strOutMsg := 'N|获取报表ID-波次[' || s_WaveNo || ']批次[' || s_BatchNo ||
                       ']在表[odata_locate_batch]中不存在';
          return;
      end;

    end if;

    /*解析标签用途use_type*/
    if (v_PaperType = CONST_REPORT_TYPE.ODATAHO or
       v_PaperType = CONST_REPORT_TYPE.MDATAHS) and strReportType <> 'L' then
      begin
        select nvl(slm.use_type, 'N')
          into v_UseType
          from odata_outstock_m oom, stock_label_m slm
         where slm.enterprise_no(+) = oom.enterprise_no
           and slm.warehouse_no(+) = oom.warehouse_no
           and slm.source_no(+) = oom.outstock_no
           and oom.enterprise_no = strEnterPriseNo
           and oom.warehouse_no = strWarehouseNo
           and oom.outstock_no = strSourceNo
           and rownum = 1;
      exception
        when no_data_found then
          strOutMsg := 'N|获取报表ID-单据[' || strSourceNo ||
                       ']在表[odata_outstock_m]中不存在';
          return;
      end;
    end if;

    /*解析承运商编码shipper_no*/
    if v_ReportType = CREPORT_TYPE.TYPE_WAY then
      begin
        select nvl(bd.shipper_no, 'N')
          into v_ShipperNo
          from odata_exp_m oem, bdef_defshipper bd
         where oem.enterprise_no = bd.enterprise_no(+)
           and oem.warehouse_no = bd.warehouse_no(+)
           and oem.shipper_no = bd.shipper_no(+)
           and oem.enterprise_no = strEnterPriseNo
           and oem.warehouse_no = strWarehouseNo
           and oem.exp_no = strSourceNo;
      exception
        when no_data_found then
          begin
            select nvl(opd.shipper_no, 'N')
              into v_ShipperNo
              from odata_package_d opd
             where opd.enterprise_no = strEnterPriseNo
               and opd.warehouse_no = strWarehouseNo
               and opd.sourceexp_no = strSourceNo;
          exception
            when no_data_found then
              strOutMsg := 'N|获取报表ID-单据[' || strSourceNo ||
                           ']在表[odata_exp_m或odata_package_d]中不存在';
              return;
          end;
      end;
    end if;

    /*获取报表ID*/
    p_getReportSqlBySet(strEnterpriseNo, --企业
                        strPaperType, --单据类型 例如'HO','IP','SS'等wms内部产生的单据类型，可为标签
                        v_TaskType, --任务类型 0：标签发单；1：纯表单发单（纯RF发单）2：任务标签发单；
                        v_PickType, --作业类型 0-摘果；1-播种
                        v_OperateType, --操作类型 'P','C','B'
                        strReportType, --报表类型 L:表单；M:标签头档；D:标签明细
                        v_OrderType, --订单类型 例如'OE','ID'
                        v_DeliverObjLevel, --配送对象级别 0:按客户,1:按单据,2:按实体客户
                        v_UseType, --标签用途：0：收货标签；1：客户标签；2：分播标签；3：移库标签
                        v_OwnerNo, --货主编码
                        v_CustNo, --客户编码
                        v_ShipperNo, --承运商编码
                        strRsvVarod1,
                        strRsvVarod2,
                        strRsvVarod3,
                        strRsvVarod4,
                        strRsvVarod5,
                        strRsvVarod6,
                        strRsvVarod7,
                        strRsvVarod8,
                        v_ReportId, --返回sql语句
                        strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      return;
    end if;
    strReportId := v_ReportId;
    strOutMsg   := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_GetReportIdExt;


  /*=====================================================================================
  hb insert to 20160620
  打印-通过配置查找报表 底层用 返回唯一报表ID
  ======================================================================================*/
  PROCEDURE p_GetReportSqlBySet( --查询条件
                                strEnterpriseNo    in pntset_module_report.enterprise_no%type, --企业
                                strPaperType       in pntset_module_report.paper_type%type, --单据类型 参考包CONST_REPORT_TYPE
                                strTaskType        in pntset_module_report.task_type%type, --任务类型 0：标签发单；1：纯表单发单（纯RF发单）2：任务标签发单；
                                strPickType        in pntset_module_report.pick_type%type, --作业类型 0-摘果；1-播种
                                strOperateType     in pntset_module_report.operate_type%type, --操作类型 'P','C','B'
                                strReportType      in pntset_module_report.report_type%type, --报表类型 L:表单；M:标签头档；D:标签明细
                                strOrderType       in pntset_module_report.order_type%type, --订单类型 例如'OE','ID'
                                strDeliverObjLevel in pntset_module_report.deliver_obj_level%type, --配送对象级别 0:按客户,1:按单据,2:按实体客户
                                strUseType         in pntset_module_report.use_type%type, --标签用途：0：收货标签；1：客户标签；2：分播标签；3：移库标签
                                strOwnerNo         in pntset_module_report.owner_no%type, --货主编码
                                strCustNo          in pntset_module_report.cust_no%type, --客户编码
                                strShipperNo       in pntset_module_report.shipper_no%type, --承运商编码
                                strRsvVarod1       in pntset_module_report.rsv_varod1%type, --预留字段
                                strRsvVarod2       in pntset_module_report.rsv_varod2%type, --预留字段
                                strRsvVarod3       in pntset_module_report.rsv_varod3%type, --预留字段
                                strRsvVarod4       in pntset_module_report.rsv_varod4%type, --预留字段
                                strRsvVarod5       in pntset_module_report.rsv_varod5%type, --预留字段
                                strRsvVarod6       in pntset_module_report.rsv_varod6%type, --预留字段
                                strRsvVarod7       in pntset_module_report.rsv_varod7%type, --预留字段
                                strRsvVarod8       in pntset_module_report.rsv_varod8%type, --预留字段
                                --返回参数
                                strReportId out job_printtask_m.report_id%type, --打印的报表ID 如外部传入 则传具体的report_id且查询条件可全部为'N',否则本参数传'N'
                                strOutMsg   out varchar2) is
    v_count      number := 0;
    v_strSql     VARCHAR2(5000) := 'N';
    v_strWhere   VARCHAR2(3000) := 'N';
    v_strOrderBy VARCHAR2(1000) := 'N';

    --查询reportID 动态游标
    TYPE ref_cursor_type IS REF CURSOR;
    v_getReport ref_cursor_type;

    v_ReportId  pntset_module_report.report_id%type;
    v_OwnerNo   pntset_module_report.owner_no%type;
    v_CustNo    pntset_module_report.cust_no%type;
    v_ShipperNo pntset_module_report.shipper_no%type;
    v_OrderNo   pntset_module_report.order_no%type;

  begin
    strOutMsg := 'N|[p_getReportSqlBySet]';

    if (strEnterpriseNo = 'N' or strEnterpriseNo is null) then
      strOutMsg := 'N|[企业必须有值]';
      return;
    end if;

    --先拼条件
    v_strWhere := ' where pmr.enterprise_no = ''' || strEnterpriseNo || '''';
    v_strWhere := v_strWhere || ' and pmr.status = ''1''';
    if strPaperType <> 'N' then
      v_strWhere := v_strWhere || ' and pmr.paper_type = ''' ||
                    strPaperType || '''';
    end if;
    if strTaskType <> 'N' then
      v_strWhere := v_strWhere || ' and pmr.task_type = ''' || strTaskType || '''';
    end if;
    if strPickType <> 'N' then
      v_strWhere := v_strWhere || ' and pmr.pick_type = ''' || strPickType || '''';
    end if;
    if strOperateType <> 'N' then
      v_strWhere := v_strWhere || ' and pmr.operate_type = ''' ||
                    strOperateType || '''';
    end if;
    if strReportType <> 'N' then
      v_strWhere := v_strWhere || ' and pmr.report_type = ''' ||
                    strReportType || '''';
    end if;
    if strOrderType <> 'N' then
      v_strWhere := v_strWhere || ' and pmr.order_type = ''' ||
                    strOrderType || '''';
    end if;
    if strDeliverObjLevel <> 'N' then
      v_strWhere := v_strWhere || ' and pmr.deliver_obj_level = ''' ||
                    strDeliverObjLevel || '''';
    end if;
    if strUseType <> 'N' then
      v_strWhere := v_strWhere || ' and pmr.use_type = ''' || strUseType || '''';
    end if;
    if strOwnerNo <> 'N' then
      v_strWhere := v_strWhere || ' and (pmr.owner_no = ''' || strOwnerNo ||
                    ''' or pmr.owner_no = ''ALL'')';
    end if;
    if strCustNo <> 'N' then
      v_strWhere := v_strWhere || ' and (pmr.cust_no = ''' || strCustNo ||
                    ''' or pmr.cust_no = ''ALL'')';
    end if;
    if strShipperNo <> 'N' then
      v_strWhere := v_strWhere || ' and (pmr.shipper_no = ''' || strShipperNo ||
                    ''' or pmr.shipper_no = ''ALL'')';
    end if;
    --if strRsvVarod1 <> 'N' then
      v_strWhere := v_strWhere || ' and nvl(pmr.rsv_varod1,''N'') = ''' ||
                    strRsvVarod1 || '''';
    --end if;
    --if strRsvVarod2 <> 'N' then
      v_strWhere := v_strWhere || ' and nvl(pmr.rsv_varod2,''N'') = ''' ||
                    strRsvVarod2 || '''';
    --end if;
    --if strRsvVarod3 <> 'N' then
      v_strWhere := v_strWhere || ' and nvl(pmr.rsv_varod3,''N'') = ''' ||
                    strRsvVarod3 || '''';
    --end if;
    --if strRsvVarod4 <> 'N' then
      v_strWhere := v_strWhere || ' and nvl(pmr.rsv_varod4,''N'') = ''' ||
                    strRsvVarod4 || '''';
    --end if;
    --if strRsvVarod5 <> 'N' then
      v_strWhere := v_strWhere || ' and nvl(pmr.rsv_varod5,''N'') = ''' ||
                    strRsvVarod5 || '''';
    --end if;
    --if strRsvVarod6 <> 'N' then
      v_strWhere := v_strWhere || ' and nvl(pmr.rsv_varod6,''N'') = ''' ||
                    strRsvVarod6 || '''';
    --end if;
    --if strRsvVarod7 <> 'N' then
      v_strWhere := v_strWhere || ' and nvl(pmr.rsv_varod7,''N'') = ''' ||
                    strRsvVarod7 || '''';
    --end if;
    --if strRsvVarod8 <> 'N' then
      v_strWhere := v_strWhere || ' and nvl(pmr.rsv_varod8,''N'') = ''' ||
                    strRsvVarod8 || '''';
    --end if;

    --排序sql
    v_strOrderBy := ' order by (case when pmr.owner_no = ''' || strOwnerNo ||
                    ''' then 0 else 1 end),';
    v_strOrderBy := v_strOrderBy || ' (case when pmr.cust_no = ''' ||
                    strCustNo || ''' then 0 else 1 end),';
    v_strOrderBy := v_strOrderBy || ' (case when pmr.shipper_no = ''' ||
                    strShipperNo || ''' then 0 else 1 end),';
    v_strOrderBy := v_strOrderBy || ' pmr.order_no ';

    --查询sql
    v_strSql := ' select distinct pmr.report_id, pmr.owner_no, pmr.cust_no, pmr.shipper_no, pmr.order_no ';
    v_strSql := v_strSql || ' from pntset_module_report pmr ';
    v_strSql := v_strSql || v_strWhere || v_strOrderBy;

    --打开获取报表ID动态游标
    open v_getReport for v_strSql;
    loop
      fetch v_getReport
        into v_ReportId, v_OwnerNo, v_CustNo, v_ShipperNo, v_OrderNo;
      exit when v_getReport%notfound;
      --只取一个sql
      if v_count = 1 then
        exit;
      end if;
      v_count := v_count + 1;
    end loop;
    --关闭获取报表ID动态游标
    close v_getReport;

    if v_count <= 0 then
      strOutMsg := 'N|[报表配置表pntset_module_report未配置(' || strPaperType || ',' ||
                   strTaskType || ',' || strPickType || ',' ||
                   strOperateType || ',' || strReportType || ',' ||
                   strDeliverObjLevel || ',' || strUseType || ')]';
      return;
    end if;

    strReportId := v_ReportId;
    strOutMsg   := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_GetReportSqlBySet;

 /*=====================================================================================
  hb 20160624
  获取报表ID 供前台界面调用
  ======================================================================================*/
  PROCEDURE p_GetReportIdUI(strEnterPriseNo in wms_warehouse_outorder.enterprise_no%type,--企业号
                            strWarehouseNo  in job_printtask_m.warehouse_no%type,--仓别号
                            strPaperType    in pntset_module_report.paper_type%type,--单据类型 参考包CONST_REPORT_TYPE
                            strReportType   in pntset_module_report.report_type%type,--报表类型 L:表单；M:标签头档；D:标签明细;WAY-面单;INV-发票;BOX-装箱清
                            strSourceNo     in job_printtask_m.source_no%type, --源单号
                            --返回参数
                            strOutSql       out varchar2,--返回sql语句
                            strOutMsg       out varchar2) is
  --解析变量
  v_PaperType       pntset_module_report.paper_type%type := 'N';--单据类型 例如'HO','IP','SS'等wms内部产生的单据类型,参考包CONST_DOCUMENTTYPE
  v_TaskType        pntset_module_report.task_type%type := 'N';--任务类型 0：标签发单；1：纯表单发单（纯RF发单）2：任务标签发单；
  v_PickType        pntset_module_report.pick_type%type := 'N';--作业类型 0-摘果；1-播种
  v_OperateType     pntset_module_report.operate_type%type := 'N';--操作类型 'P','C','B','MIX'
  v_ReportType      pntset_module_report.report_type%type := 'N';--报表类型 L:表单;M:标签头档;D:标签明细;WAY-面单;INV-发票;BOX-装箱清
  v_OrderType       pntset_module_report.order_type%type := 'N';--订单类型 例如'OE','ID'
  v_DeliverObjLevel pntset_module_report.deliver_obj_level%type := 'N';--配送对象级别 0:按客户,1:按单据,2:按实体客户
  v_UseType         pntset_module_report.use_type%type := 'N';--标签用途：0：收货标签；1：客户标签；2：分播标签；3：移库标签
  v_OwnerNo         pntset_module_report.owner_no%type := 'N';--货主编码
  v_CustNo          pntset_module_report.cust_no%type := 'N';--客户编码
  v_ShipperNo       pntset_module_report.shipper_no%type := 'N';--承运商编码

  --查询变量
  s_WaveNo  odata_locate_batch.wave_no%type := 'N';--波次号
  s_BatchNo odata_locate_batch.batch_no%type := 'N';--批次号

  begin
   strOutMsg := 'N|p_GetReportIdUI';

   /*解析单据类型paper_type*/
   v_PaperType := strPaperType;

   /*解析报表类型report_type*/
   v_ReportType := strReportType;

   /*解析task_type,pick_type,operate_type,owner_no*/
   --出货发单,移库
   if(v_PaperType = CONST_REPORT_TYPE.ODATAHO
      or v_PaperType = CONST_REPORT_TYPE.MDATAHS) and strReportType <> 'L' then
     begin
       select oom.owner_no, oom.task_type, oom.pick_type, oom.operate_type, oom.wave_no, oom.batch_no
         into v_OwnerNo, v_TaskType, v_PickType, v_OperateType, s_WaveNo, s_BatchNo
         from odata_outstock_m oom
        where oom.enterprise_no = strEnterPriseNo and oom.warehouse_no = strWarehouseNo
          and oom.outstock_no = strSourceNo;
     exception
       when no_data_found then
         strOutMsg := 'N|获取报表ID-单据['|| strSourceNo ||']在表[odata_outstock_m]中不存在';
         return;
     end;
     --取客户
     begin
       select ood.cust_no
         into v_CustNo
         from odata_outstock_d ood
        where ood.enterprise_no = strEnterPriseNo and ood.warehouse_no = strWarehouseNo
          and ood.outstock_no = strSourceNo and rownum = 1;
     exception
       when no_data_found then
         strOutMsg := 'N|获取报表ID-单据['|| strSourceNo ||']在表[odata_outstock_d]中不存在';
         return;
     end;
   end if;
   --出货发单,移库 单据 huangb 20160729
   if v_PaperType = CONST_REPORT_TYPE.ODATAHO and strReportType = 'L' then
     begin
       select oom.pick_type, oom.wave_no, oom.batch_no, oom.owner_no
         into v_PickType, s_WaveNo, s_BatchNo, v_OwnerNo
         from odata_outstock_m oom
        where oom.enterprise_no = strEnterPriseNo and oom.warehouse_no = strWarehouseNo
          and oom.outstock_no = strSourceNo;
     exception
       when no_data_found then
         strOutMsg := 'N|获取报表ID-单据['|| strSourceNo ||']在表[odata_outstock_m]中不存在';
         return;
     end;
   end if;
   --分播单据
   if v_PaperType = CONST_REPORT_TYPE.ODATARD then
     begin
       select odd.owner_no, odd.wave_no, odd.batch_no
         into v_OwnerNo, s_WaveNo, s_BatchNo
         from odata_divide_d odd
        where odd.enterprise_no = strEnterPriseNo and odd.warehouse_no = strWarehouseNo
          and odd.divide_no = strSourceNo and rownum = 1;
     exception
       when no_data_found then
         strOutMsg := 'N|获取报表ID-单据['|| strSourceNo ||']在表[odata_outstock_m]中不存在';
         return;
     end;
   end if;
   --装车单据
   if v_PaperType = CONST_REPORT_TYPE.ODATAOL or v_PaperType = CONST_REPORT_TYPE.ODATAOL1 then
     begin
       select max(odd.wave_no)
         into s_WaveNo
         from odata_loadpropose_m a, odata_deliver_m odm, odata_deliver_d odd
        where odm.enterprise_no = a.enterprise_no
          and odm.warehouse_no = a.warehouse_no
          and odm.loadpropose_no = a.loadpropose_no
          and odd.enterprise_no = odm.enterprise_no
          and odd.warehouse_no = odm.warehouse_no
          and odd.deliver_no = odm.deliver_no
          and a.warehouse_no = strWareHouseNo
          and a.enterprise_no = strEnterpriseNo
          and a.loadpropose_no = strSourceNo;
     exception
       when no_data_found then
       strOutMsg := 'N|获取报表ID-单据['|| strSourceNo ||']在表[odata_loadpropose_m]中不存在';
       return;
     end;
   end if;

   --封车单据
   if v_PaperType = CONST_REPORT_TYPE.ODATAOD then
     begin
       select max(odd.wave_no) into s_WaveNo
         from odata_deliver_d odd
        where odd.enterprise_no = strEnterPriseNo and odd.warehouse_no = strWarehouseNo
          and odd.deliver_no = strSourceNo;
     exception
       when no_data_found then
         strOutMsg := 'N|获取报表ID-单据['|| strSourceNo ||']在表[odata_deliver_d]中不存在';
         return;
     end;

   end if;

   --封车箱明细
   if v_PaperType = CONST_REPORT_TYPE.ODATAODBOX then
     begin
       select max(odd.wave_no) into s_WaveNo
         from odata_deliver_d odd
        where odd.enterprise_no = strEnterPriseNo and odd.warehouse_no = strWarehouseNo
          and odd.container_no = strSourceNo;
     exception
       when no_data_found then
         strOutMsg := 'N|获取报表ID-单据['|| strSourceNo ||']在表[odata_deliver_d]中不存在';
         return;
     end;

   end if;

   --进货汇总单据
   if (v_PaperType = CONST_REPORT_TYPE.IDATAIMPORTSS
      or v_PaperType = CONST_REPORT_TYPE.IDATAIMPORTSD) then
     begin
       select iimm.owner_no into v_OwnerNo
         from idata_import_mm iimm
        where iimm.enterprise_no = strEnterPriseNo and iimm.warehouse_no = strWarehouseNo
          and iimm.s_import_no = strSourceNo;
     exception
       when no_data_found then
         strOutMsg := 'N|获取报表ID-单据['|| strSourceNo ||']在表[idata_import_mm]中不存在';
         return;
     end;
   end if;
   --验收汇总单据
   if v_PaperType = CONST_REPORT_TYPE.IDATASC then
     begin
       select icm.owner_no into v_OwnerNo
         from idata_check_m icm
        where icm.enterprise_no = strEnterPriseNo and icm.warehouse_no = strWarehouseNo
          and icm.s_check_no = strSourceNo;
     exception
       when no_data_found then
         strOutMsg := 'N|获取报表ID-单据['|| strSourceNo ||']在表[idata_check_m]中不存在';
         return;
     end;
   end if;
   --上架单据
   if v_PaperType = CONST_REPORT_TYPE.IDATAIP then
     begin
       select iim.owner_no into v_OwnerNo
         from idata_instock_m iim
        where iim.enterprise_no = strEnterPriseNo and iim.warehouse_no = strWarehouseNo
          and iim.instock_no = strSourceNo;
     exception
       when no_data_found then
         strOutMsg := 'N|获取报表ID-单据['|| strSourceNo ||']在表[idata_instock_m]中不存在';
         return;
     end;
   end if;

   /*解析行业标识;1：传统；2：电商 ORDER_TYPE*/
   --出货发单,装车,封车
   if v_PaperType = CONST_REPORT_TYPE.ODATAHO
      or v_PaperType = CONST_REPORT_TYPE.ODATAOL or v_PaperType = CONST_REPORT_TYPE.ODATAOL1
      or v_PaperType = CONST_REPORT_TYPE.ODATAODBOX or v_PaperType = CONST_REPORT_TYPE.ODATAOD then
     begin
       select INDUSTRY_FLAG
         into v_OrderType
         from odata_locate_batch
        where enterprise_no = strEnterPriseNo and warehouse_no = strWarehouseNo --and owner_no = v_OwnerNo
          and wave_no = s_WaveNo and rownum = 1;
     exception
       when no_data_found then
         strOutMsg := 'N|获取报表ID-波次['|| s_WaveNo ||']在表[odata_locate_batch]中不存在';
         return;
     end;

   end if;

   /*解析配送对象级别deliver_obj_level*/
   --出货发单或分播
   if (v_PaperType = CONST_REPORT_TYPE.ODATAHO and strReportType <> 'L')
      or v_PaperType = CONST_REPORT_TYPE.ODATARD then
     begin
       select deliver_obj_level
         into v_DeliverObjLevel
         from odata_locate_batch
        where enterprise_no = strEnterPriseNo and warehouse_no = strWarehouseNo and owner_no = v_OwnerNo
          and wave_no = s_WaveNo and batch_no = s_BatchNo;
     exception
       when no_data_found then
         strOutMsg := 'N|获取报表ID-波次['|| s_WaveNo ||']批次['|| s_BatchNo ||']在表[odata_locate_batch]中不存在';
         return;
     end;

   end if;

   /*解析标签用途use_type*/
   if(v_PaperType = CONST_REPORT_TYPE.ODATAHO
      or v_PaperType = CONST_REPORT_TYPE.MDATAHS) and strReportType <> 'L' then
     begin
       select nvl(slm.use_type,'N') into v_UseType
         from odata_outstock_m oom,stock_label_m slm
        where slm.enterprise_no(+) = oom.enterprise_no
          and slm.warehouse_no(+) = oom.warehouse_no
          and slm.source_no(+) = oom.outstock_no
          and oom.enterprise_no = strEnterPriseNo
          and oom.warehouse_no = strWarehouseNo
          and oom.outstock_no = strSourceNo
          and rownum = 1;
     exception
       when no_data_found then
         strOutMsg := 'N|获取报表ID-单据['|| strSourceNo ||']在表[odata_outstock_m]中不存在';
         return;
     end;
   end if;

   /*解析承运商编码shipper_no*/
   if v_ReportType = CREPORT_TYPE.TYPE_WAY then
     begin
       select nvl(bd.shipper_no,'N') into v_ShipperNo
         from odata_exp_m oem, bdef_defshipper bd
        where oem.enterprise_no = bd.enterprise_no(+)
          and oem.warehouse_no = bd.warehouse_no(+)
          and oem.shipper_no = bd.shipper_no(+)
          and oem.enterprise_no = strEnterPriseNo
          and oem.warehouse_no = strWarehouseNo
          and oem.exp_no = strSourceNo;
     exception
       when no_data_found then
         begin
           select max(nvl(opd.shipper_no,'N')) into v_ShipperNo
             from odata_package_d opd
            where opd.enterprise_no = strEnterPriseNo
              and opd.warehouse_no = strWarehouseNo
              and opd.sourceexp_no = strSourceNo;
         exception
           when no_data_found then
             strOutMsg := 'N|获取报表ID-单据['|| strSourceNo ||']在表[odata_exp_m或odata_package_d]中不存在';
             return;
         end;
     end;
   end if;

   /*获取报表sql*/
   p_getReportSqlBySetUI(
     strEnterpriseNo,--企业
     strWarehouseNo,
     strPaperType,--单据类型 例如'HO','IP','SS'等wms内部产生的单据类型，可为标签
     v_TaskType,--任务类型 0：标签发单；1：纯表单发单（纯RF发单）2：任务标签发单；
     v_PickType,--作业类型 0-摘果；1-播种
     v_OperateType,--操作类型 'P','C','B'
     strReportType,--报表类型 L:表单；M:标签头档；D:标签明细
     v_OrderType,--订单类型 例如'OE','ID'
     v_DeliverObjLevel,--配送对象级别 0:按客户,1:按单据,2:按实体客户
     v_UseType,--标签用途：0：收货标签；1：客户标签；2：分播标签；3：移库标签
     v_OwnerNo,--货主编码
     v_CustNo,--客户编码
     v_ShipperNo,--承运商编码
     'N','N','N','N','N','N','N','N',
     strOutSql,--返回sql语句
     strOutMsg);
   if instr(strOutMsg, 'N', 1, 1) = 1 then
     return;
   end if;

   strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_GetReportIdUI;


  /*=====================================================================================
  hb insert to 20160617
  补印-通过配置查找报表SQL 供前台界面调用
  ======================================================================================*/
  PROCEDURE p_GetReportSqlBySetUI(strEnterpriseNo    in pntset_module_report.enterprise_no%type,--企业
                                  strWarehouseNo     in job_printtask_m.warehouse_no%type,--仓别号
                                  strPaperType       in pntset_module_report.paper_type%type,--单据类型 参考包CONST_REPORT_TYPE
                                  strTaskType        in pntset_module_report.task_type%type,--任务类型 0：标签发单；1：纯表单发单（纯RF发单）2：任务标签发单；
                                  strPickType        in pntset_module_report.pick_type%type,--作业类型 0-摘果；1-播种
                                  strOperateType     in pntset_module_report.operate_type%type,--操作类型 'P','C','B'
                                  strReportType      in pntset_module_report.report_type%type,--报表类型 L:表单；M:标签头档；D:标签明细
                                  strOrderType       in pntset_module_report.order_type%type,--订单类型 例如'OE','ID'
                                  strDeliverObjLevel in pntset_module_report.deliver_obj_level%type,--配送对象级别 0:按客户,1:按单据,2:按实体客户
                                  strUseType         in pntset_module_report.use_type%type,--标签用途：0：收货标签；1：客户标签；2：分播标签；3：移库标签
                                  strOwnerNo         in pntset_module_report.owner_no%type,--货主编码
                                  strCustNo          in pntset_module_report.cust_no%type,--客户编码
                                  strShipperNo       in pntset_module_report.shipper_no%type,--承运商编码
                                  strRsvVarod1       in pntset_module_report.rsv_varod1%type,--预留字段
                                  strRsvVarod2       in pntset_module_report.rsv_varod2%type,--预留字段
                                  strRsvVarod3       in pntset_module_report.rsv_varod3%type,--预留字段
                                  strRsvVarod4       in pntset_module_report.rsv_varod4%type,--预留字段
                                  strRsvVarod5       in pntset_module_report.rsv_varod5%type,--预留字段
                                  strRsvVarod6       in pntset_module_report.rsv_varod6%type,--预留字段
                                  strRsvVarod7       in pntset_module_report.rsv_varod7%type,--预留字段
                                  strRsvVarod8       in pntset_module_report.rsv_varod8%type,--预留字段
                                  strOutSql          out varchar2,--返回sql语句
                                  strOutMsg          out varchar2) is

    v_strSql     VARCHAR2(5000);
    v_strWhere   VARCHAR2(3000);
    v_strOrderBy VARCHAR2(1000);

  begin
    strOutMsg    := 'N|[p_getReportSqlBySetUI]';
    v_strSql     := 'N';
    v_strWhere   := 'N';
    v_strOrderBy := 'N';

    if(strEnterpriseNo = 'N' or strEnterpriseNo is null) then
      strOutMsg := 'N|[企业必须有值]';
      return;
    end if;

    --先拼条件
    v_strWhere := ' where pmr.enterprise_no = ''' || strEnterpriseNo || '''';
    v_strWhere := v_strWhere || ' and pmr.report_id = pr.report_id ';
    v_strWhere := v_strWhere || ' and pmr.enterprise_no = ppt.enterprise_no ';
    v_strWhere := v_strWhere || ' and ppt.paper_type_no = pr.paper_type_no ';
    v_strWhere := v_strWhere || ' and ppt.warehouse_no = ''' || strWarehouseNo || '''';
    v_strWhere := v_strWhere || ' and pmr.status = ''1''';
    if strPaperType <> 'N' then
      v_strWhere := v_strWhere || ' and pmr.paper_type like ''%' || strPaperType || '%''';
    end if;
    if strTaskType <> 'N' then
      v_strWhere := v_strWhere || ' and pmr.task_type = ''' || strTaskType || '''';
    end if;
    if strPickType <> 'N' then
      v_strWhere := v_strWhere || ' and pmr.pick_type = ''' || strPickType || '''';
    end if;
    if strOperateType <> 'N' then
      v_strWhere := v_strWhere || ' and pmr.operate_type = ''' || strOperateType || '''';
    end if;
    if strReportType <> 'N' then
      v_strWhere := v_strWhere || ' and pmr.report_type = ''' || strReportType || '''';
    end if;
    if strOrderType <> 'N' then
      v_strWhere := v_strWhere || ' and pmr.order_type = ''' || strOrderType || '''';
    end if;
    if strDeliverObjLevel <> 'N' then
      v_strWhere := v_strWhere || ' and pmr.deliver_obj_level = ''' || strDeliverObjLevel || '''';
    end if;
    if strUseType <> 'N' then
      v_strWhere := v_strWhere || ' and pmr.use_type = ''' || strUseType || '''';
    end if;
    if strOwnerNo <> 'N' then
      v_strWhere := v_strWhere || ' and (pmr.owner_no = ''' || strOwnerNo || ''' or pmr.owner_no = ''ALL'')';
    end if;
    if strCustNo <> 'N' then
      v_strWhere := v_strWhere || ' and (pmr.cust_no = ''' || strOwnerNo || ''' or pmr.cust_no = ''ALL'')';
    end if;
    if strShipperNo <> 'N' then
      v_strWhere := v_strWhere || ' and (pmr.shipper_no = ''' || strOwnerNo || ''' or pmr.shipper_no = ''ALL'')';
    end if;
    if strRsvVarod1 <> 'N' then
      v_strWhere := v_strWhere || ' and pmr.rsv_varod1 = ''' || strRsvVarod1 || '''';
    end if;
    if strRsvVarod2 <> 'N' then
      v_strWhere := v_strWhere || ' and pmr.rsv_varod2 = ''' || strRsvVarod2 || '''';
    end if;
    if strRsvVarod3 <> 'N' then
      v_strWhere := v_strWhere || ' and pmr.rsv_varod3 = ''' || strRsvVarod3 || '''';
    end if;
    if strRsvVarod4 <> 'N' then
      v_strWhere := v_strWhere || ' and pmr.rsv_varod4 = ''' || strRsvVarod4 || '''';
    end if;
    if strRsvVarod5 <> 'N' then
      v_strWhere := v_strWhere || ' and pmr.rsv_varod5 = ''' || strRsvVarod5 || '''';
    end if;
    if strRsvVarod6 <> 'N' then
      v_strWhere := v_strWhere || ' and pmr.rsv_varod6 = ''' || strRsvVarod6 || '''';
    end if;
    if strRsvVarod7 <> 'N' then
      v_strWhere := v_strWhere || ' and pmr.rsv_varod7 = ''' || strRsvVarod7 || '''';
    end if;
    if strRsvVarod8 <> 'N' then
      v_strWhere := v_strWhere || ' and pmr.rsv_varod8 = ''' || strRsvVarod8 || '''';
    end if;

    --排序条件
    v_strOrderBy := ' order by (case when pmr.owner_no = ''' || strOwnerNo || ''' then 0 else 1 end),';
    v_strOrderBy := v_strOrderBy || ' (case when pmr.cust_no = ''' || strCustNo || ''' then 0 else 1 end),';
    v_strOrderBy := v_strOrderBy || ' (case when pmr.shipper_no = ''' || strShipperNo || ''' then 0 else 1 end),';
    v_strOrderBy := v_strOrderBy || ' pmr.order_no ';

    --查询sql
    v_strSql := ' select distinct pmr.report_id, pmr.report_name, ppt.task_type, pmr.owner_no, pmr.cust_no, pmr.shipper_no, pmr.order_no ';
    v_strSql := v_strSql || ' from pntset_module_report pmr,pntdef_report pr,pntset_paper_type ppt ';
    v_strSql := v_strSql || v_strWhere || v_strOrderBy;

    strOutSql := v_strSql;
    strOutMsg := 'Y|';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_GetReportSqlBySetUI;

  /*=====================================================================================
  hb 20160623
  特殊类报表通过配置新增打印任务(不写打印任务明细)
  ======================================================================================*/
  PROCEDURE p_Insert_SpecialReportTask(strEnterPriseNo in wms_warehouse_outorder.enterprise_no%type,--企业号
                                       strWarehouseNo  in job_printtask_m.warehouse_no%type,--仓别号
                                       strReportType   in pntset_module_report.report_type%type,--报表类型 WAY-面单;INV-发票;BOX-装箱清
                                       strSourceNo     in job_printtask_m.source_no%type, --源单号
                                       strDockNo       in varchar2, --码头或工作站号
                                       strReprintFlag  in job_printtask_m.reprint_flag%type, --补印标识
                                       strUserId       in job_printtask_m.Rgst_Name%type, --操作人员
                                       --返回参数
                                       strTaskNo       out job_printtask_m.task_no%type, --打印任务单号 如外部生成 则传外部生成打印任务号,否则传'N'
                                       strOutMsg       out varchar2) is

  v_Report_Id job_printtask_m.report_id%type := 'N';
  begin
   strOutMsg := 'N|p_Insert_SpecialReportTask';

   p_GetReportId(strEnterPriseNo,--企业号
                 strWarehouseNo,--仓别号
                 CONST_REPORT_TYPE.ODATAB2C,--单据类型 参考包CONST_REPORT_TYPE
                 strReportType,--报表类型 L:表单；M:标签头档；D:标签明细;WAY-面单;INV-发票;BOX-装箱清
                 strSourceNo, --源单号
                 --返回参数
                 v_Report_Id, --返回报表ID
                 strOutMsg);
   if instr(strOutMsg, 'N', 1, 1) = 1 then
     return;
   end if;

   --新增打印任务
   PKOBJ_PRINTTASK.p_Insert_TaskInfo
     ( --新增打印任务条件
     strEnterpriseNo,--企业
     strWarehouseNo,--仓别号
     strSourceNo, --源单号
     v_Report_Id, --打印的报表ID 如外部传入 则传具体的report_id且查询条件可全部为'N',否则本参数传'N'
     '0', --后台打印标识，默认为0
     strDockNo, --码头或工作站号
     strReprintFlag, --补印标识
     strUserId, --操作人员
     '0', --是否新增打印任务明细 0-不新增;1-新增
     'N', --需要打印的系统内部容器号不新增打印任务明细传'N'
     0, --不新增打印任务明细传 0
     1, --不新增打印任务明细传 1
     --返回参数
     strTaskNo, --打印任务单号 如外部生成 则传外部生成打印任务号,否则传'N'
     strOutMsg);
   if instr(strOutMsg, 'N', 1, 1) = 1 then
     return;
   end if;

   --Add BY QZH AT 2016-6-29
   --面单
   if strReportType=CREPORT_TYPE.TYPE_WAY then
      update odata_exp_m m
      set m.waybill_print_status=m.waybill_print_status+1
      where m.enterprise_no=strEnterPriseNo
      and m.warehouse_no=strWarehouseNo
      and m.exp_no=strSourceNo;
   end if;
   --发票
   if strReportType=CREPORT_TYPE.TYPE_INV then
      update odata_exp_m m
      set m.envoice_print_status=m.envoice_print_status+1
      where m.enterprise_no=strEnterPriseNo
      and m.warehouse_no=strWarehouseNo
      and m.exp_no=strSourceNo;
   end if;

   --箱清单
   if strReportType=CREPORT_TYPE.TYPE_BOX then
      update odata_exp_m m
      set m.packlist_print_status=m.packlist_print_status+1
      where m.enterprise_no=strEnterPriseNo
      and m.warehouse_no=strWarehouseNo
      and m.exp_no=strSourceNo;
   end if;
   --Add End BY QZH AT 2016-6-29

   strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_Insert_SpecialReportTask;

    /*=====================================================================================
  hb 20160623
  特殊类报表通过配置新增打印任务（扩展）
  ======================================================================================*/
  PROCEDURE p_Insert_SpecialReportTaskExt(strEnterPriseNo in wms_warehouse_outorder.enterprise_no%type, --企业号
                                          strWarehouseNo  in job_printtask_m.warehouse_no%type, --仓别号
                                          strReportType   in pntset_module_report.report_type%type, --报表类型 WAY-面单;INV-发票;BOX-装箱清
                                          strSourceNo     in job_printtask_m.source_no%type, --源单号
                                          strDockNo       in varchar2, --码头或工作站号
                                          strReprintFlag  in job_printtask_m.reprint_flag%type, --补印标识
                                          strUserId       in job_printtask_m.Rgst_Name%type, --操作人员
                                          strRsvVarod1    in pntset_module_report.rsv_varod1%type, --预留字段
                                          strRsvVarod2    in pntset_module_report.rsv_varod2%type, --预留字段
                                          strRsvVarod3    in pntset_module_report.rsv_varod3%type, --预留字段
                                          strRsvVarod4    in pntset_module_report.rsv_varod4%type, --预留字段
                                          strRsvVarod5    in pntset_module_report.rsv_varod5%type, --预留字段
                                          strRsvVarod6    in pntset_module_report.rsv_varod6%type, --预留字段
                                          strRsvVarod7    in pntset_module_report.rsv_varod7%type, --预留字段
                                          strRsvVarod8    in pntset_module_report.rsv_varod8%type, --预留字段
                                          --返回参数
                                          strTaskNo out job_printtask_m.task_no%type, --打印任务单号 如外部生成 则传外部生成打印任务号,否则传'N'
                                          strOutMsg out varchar2) is

    v_Report_Id job_printtask_m.report_id%type := 'N';
  begin
    strOutMsg := 'N|p_Insert_SpecialReportTask';

    p_GetReportIdExt(strEnterPriseNo, --企业号
                     strWarehouseNo, --仓别号
                     CONST_REPORT_TYPE.ODATAB2C, --单据类型 参考包CONST_REPORT_TYPE
                     strReportType, --报表类型 L:表单；M:标签头档；D:标签明细;WAY-面单;INV-发票;BOX-装箱清
                     strSourceNo, --源单号
                     strRsvVarod1,
                     strRsvVarod2,
                     strRsvVarod3,
                     strRsvVarod4,
                     strRsvVarod5,
                     strRsvVarod6,
                     strRsvVarod7,
                     strRsvVarod8,
                     --返回参数
                     v_Report_Id, --返回报表ID
                     strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      return;
    end if;

    --新增打印任务
    PKOBJ_PRINTTASK.p_Insert_TaskInfo( --新增打印任务条件
                                      strEnterpriseNo, --企业
                                      strWarehouseNo, --仓别号
                                      strSourceNo, --源单号
                                      v_Report_Id, --打印的报表ID 如外部传入 则传具体的report_id且查询条件可全部为'N',否则本参数传'N'
                                      '0', --后台打印标识，默认为0
                                      strDockNo, --码头或工作站号
                                      strReprintFlag, --补印标识
                                      strUserId, --操作人员
                                      '0', --是否新增打印任务明细 0-不新增;1-新增
                                      'N', --需要打印的系统内部容器号不新增打印任务明细传'N'
                                      0, --不新增打印任务明细传 0
                                      1, --不新增打印任务明细传 1
                                      --返回参数
                                      strTaskNo, --打印任务单号 如外部生成 则传外部生成打印任务号,否则传'N'
                                      strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      return;
    end if;

    --Add BY QZH AT 2016-6-29
    --面单
    if strReportType = CREPORT_TYPE.TYPE_WAY then
      update odata_exp_m m
         set m.waybill_print_status = m.waybill_print_status + 1
       where m.enterprise_no = strEnterPriseNo
         and m.warehouse_no = strWarehouseNo
         and m.exp_no = strSourceNo;
    end if;
    --发票
    if strReportType = CREPORT_TYPE.TYPE_INV then
      update odata_exp_m m
         set m.envoice_print_status = m.envoice_print_status + 1
       where m.enterprise_no = strEnterPriseNo
         and m.warehouse_no = strWarehouseNo
         and m.exp_no = strSourceNo;
    end if;

    --箱清单
    if strReportType = CREPORT_TYPE.TYPE_BOX then
      update odata_exp_m m
         set m.packlist_print_status = m.packlist_print_status + 1
       where m.enterprise_no = strEnterPriseNo
         and m.warehouse_no = strWarehouseNo
         and m.exp_no = strSourceNo;
    end if;
    --Add End BY QZH AT 2016-6-29

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_Insert_SpecialReportTaskExt;


  /*===========================================进货公用方法begin==============================================


  ==================================================================================================*/
  /********************************************************************
  取进货单据类型配置

  ********************************************************************/
  PROCEDURE P_GetIdataOrder(strEnterPriseNo in wms_warehouse_idatatype.enterprise_no%type,--企业号 必传
                            strWarehouseNo  in wms_warehouse_idatatype.warehouse_no%type, --仓别
                            strOwnerNo      in wms_warehouse_idatatype.owner_no%type, --系
                            strImportType   in wms_warehouse_idatatype.import_type%type, --单据类型 必传
                            strColumnName   in varchar2, --需要取值的列名
                            strColumnValue  out varchar2, --返回列名的值
                            strOutMsg       out varchar2) is
    v_strSql      VARCHAR2(5000) := 'N';
    v_ColumnValue VARCHAR2(50) := 'N';
  begin
       strOutMsg:='N|[P_GetIdataOrder]';

    begin
      v_strSql := ' select ' || strColumnName;
      v_strSql := v_strSql || ' from wms_warehouse_idatatype ';
      v_strSql := v_strSql || ' where enterprise_no = ''' || strEnterPriseNo || '''';
      v_strSql := v_strSql || '   and warehouse_no = ''' || strWarehouseNo || '''';
      v_strSql := v_strSql || '   and owner_no = ''' || strOwnerNo || '''';
      v_strSql := v_strSql || '   and import_type = ''' || strImportType || '''';

      execute immediate v_strSql into v_ColumnValue;
    exception
      when no_data_found then
        begin
        v_strSql := ' select ' || strColumnName;
        v_strSql := v_strSql || ' from wms_owner_idatatype ';
        v_strSql := v_strSql || ' where enterprise_no = ''' || strEnterPriseNo || '''';
        v_strSql := v_strSql || '   and owner_no = ''' || strOwnerNo || '''';
        v_strSql := v_strSql || '   and import_type = ''' || strImportType || '''';

        execute immediate v_strSql into v_ColumnValue;
        exception
          when no_data_found then
            begin
              v_strSql := ' select ' || strColumnName;
              v_strSql := v_strSql || ' from wms_idatatype ';
              v_strSql := v_strSql || ' where enterprise_no = ''' || strEnterPriseNo || '''';
              v_strSql := v_strSql || '   and import_type = ''' || strImportType || '''';

              execute immediate v_strSql into v_ColumnValue;
            exception
              when no_data_found then
                strOutMsg := 'N|订单类型['||strImportType||']没有配置策略';
                return;
            end;
        end;
    end;

    strColumnValue := v_ColumnValue;
    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end P_GetIdataOrder;

  /*==============================================进货公用方法 end=============================================*/


  /*==============================================出货公用方法 begin=============================================*/

  /*=====================================================================================
  hb 20160622
  取出货类型策略信息
  ======================================================================================*/
  PROCEDURE p_OM_GetOutOrder(strEnterPriseNo in wms_warehouse_outorder.enterprise_no%type,--企业号 必传
                             strWarehouseNo  in wms_warehouse_outorder.warehouse_no%type, --仓别
                             strOwnerNo      in wms_warehouse_outorder.owner_no%type, --委托业主
                             strExpType      in wms_warehouse_outorder.exp_type%type, --单据类型 必传
                             strColumnName   in varchar2, --需要取值的列名
                             strColumnValue  out varchar2, --返回列名的值
                             strOutMsg       out varchar2) is

    v_strSql      VARCHAR2(5000) := 'N';
    v_ColumnValue VARCHAR2(50) := 'N';

  begin
    strOutMsg := 'N|p_OM_GetOutOrder';

    begin
      v_strSql := ' select ' || strColumnName;
      v_strSql := v_strSql || ' from wms_warehouse_outorder ';
      v_strSql := v_strSql || ' where enterprise_no = ''' || strEnterPriseNo || '''';
      v_strSql := v_strSql || '   and warehouse_no = ''' || strWarehouseNo || '''';
      v_strSql := v_strSql || '   and owner_no = ''' || strOwnerNo || '''';
      v_strSql := v_strSql || '   and exp_type = ''' || strExpType || '''';

      execute immediate v_strSql into v_ColumnValue;
    exception
      when no_data_found then
        begin
        v_strSql := ' select ' || strColumnName;
        v_strSql := v_strSql || ' from wms_owner_outorder ';
        v_strSql := v_strSql || ' where enterprise_no = ''' || strEnterPriseNo || '''';
        v_strSql := v_strSql || '   and owner_no = ''' || strOwnerNo || '''';
        v_strSql := v_strSql || '   and exp_type = ''' || strExpType || '''';

        execute immediate v_strSql into v_ColumnValue;
        exception
          when no_data_found then
            begin
              v_strSql := ' select ' || strColumnName;
              v_strSql := v_strSql || ' from wms_outorder ';
              v_strSql := v_strSql || ' where enterprise_no = ''' || strEnterPriseNo || '''';
              v_strSql := v_strSql || '   and exp_type = ''' || strExpType || '''';

              execute immediate v_strSql into v_ColumnValue;
            exception
              when no_data_found then
                strOutMsg := 'N|出货类型['||strExpType||']没有配置策略';
                return;
            end;
        end;
    end;

    strColumnValue := v_ColumnValue;
    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_OM_GetOutOrder;

  /*==============================================出货公用方法 end=============================================*/



  /*==============================================返配公用方法 begin=============================================*/

  /*=====================================================================================
  hb 20160804
  取返配类型策略信息
  ======================================================================================*/
  PROCEDURE p_GetRIdataOrder(strEnterPriseNo in wms_warehouse_riordertype.enterprise_no%type,--企业号 必传
                             strWarehouseNo  in wms_warehouse_riordertype.warehouse_no%type, --仓别
                             strOwnerNo      in wms_warehouse_riordertype.owner_no%type, --委托业主
                             strUntreadType  in wms_warehouse_riordertype.untread_type%type, --单据类型 必传
                             strClassType    in wms_warehouse_riordertype.class_type%type, --必传
                             strQualityFlag  in wms_warehouse_riordertype.quality_flag%type, --必传
                             strColumnName   in varchar2, --需要取值的列名
                             strColumnValue  out varchar2, --返回列名的值
                             strOutMsg       out varchar2) is

    v_strSql      VARCHAR2(5000) := 'N';
    v_ColumnValue VARCHAR2(50) := 'N';

  begin
    strOutMsg := 'N|p_GetRIdataOrder';

    begin
      v_strSql := ' select ' || strColumnName;
      v_strSql := v_strSql || ' from wms_warehouse_riordertype ';
      v_strSql := v_strSql || ' where enterprise_no = ''' || strEnterPriseNo || '''';
      v_strSql := v_strSql || '   and warehouse_no = ''' || strWarehouseNo || '''';
      v_strSql := v_strSql || '   and owner_no = ''' || strOwnerNo || '''';
      v_strSql := v_strSql || '   and untread_type = ''' || strUntreadType || '''';
      v_strSql := v_strSql || '   and class_type = ''' || strClassType || '''';
      v_strSql := v_strSql || '   and quality_flag = ''' || strQualityFlag || '''';

      execute immediate v_strSql into v_ColumnValue;
    exception
      when no_data_found then
        begin
        v_strSql := ' select ' || strColumnName;
        v_strSql := v_strSql || ' from wms_owner_riordertype ';
        v_strSql := v_strSql || ' where enterprise_no = ''' || strEnterPriseNo || '''';
        v_strSql := v_strSql || '   and owner_no = ''' || strOwnerNo || '''';
        v_strSql := v_strSql || '   and untread_type = ''' || strUntreadType || '''';
        v_strSql := v_strSql || '   and class_type = ''' || strClassType || '''';
        v_strSql := v_strSql || '   and quality_flag = ''' || strQualityFlag || '''';

        execute immediate v_strSql into v_ColumnValue;
        exception
          when no_data_found then
            begin
              v_strSql := ' select ' || strColumnName;
              v_strSql := v_strSql || ' from wms_riordertype ';
              v_strSql := v_strSql || ' where enterprise_no = ''' || strEnterPriseNo || '''';
              v_strSql := v_strSql || '   and untread_type = ''' || strUntreadType || '''';
              v_strSql := v_strSql || '   and class_type = ''' || strClassType || '''';
              v_strSql := v_strSql || '   and quality_flag = ''' || strQualityFlag || '''';

              execute immediate v_strSql into v_ColumnValue;
            exception
              when no_data_found then
                strOutMsg := 'N|返配类型['||strUntreadType||','|| strClassType ||','|| strQualityFlag ||']没有配置策略';
                return;
            end;
        end;
    end;

    strColumnValue := v_ColumnValue;
    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_GetRIdataOrder;

  /*==============================================返配公用方法 end=============================================*/


end PKLG_WMS_Public;

/

