create view V_ODATA_OUTSTOCK_D as
    select warehouse_no,owner_no,outstock_no,divide_id,operate_date,batch_no,exp_type,exp_no,wave_no,
cust_no,sub_cust_no,article_no,article_id,packing_qty,s_cell_no,s_cell_id,s_container_no,d_cell_no,
d_cell_id,/*pick_container_no,cust_container_no,*/article_qty,real_qty,deliver_area,status,line_no,
trunck_cell_no,a_sorter_chute_no,check_chute_no,deliver_obj,advance_cell_no,assign_name,outstock_name,
instock_name,outstock_date,instock_date,dps_cell_no,/*equipment_no,*/priority,exp_date,pick_device,
advance_pick_name,advance_pick_date,label_no,stock_type,empty_flag,unbox_flag
from ODATA_OUTSTOCK_D
union all
select warehouse_no,owner_no,outstock_no,divide_id,operate_date,batch_no,exp_type,exp_no,wave_no,
cust_no,sub_cust_no,article_no,article_id,packing_qty,s_cell_no,s_cell_id,s_container_no,d_cell_no,
d_cell_id,/*pick_container_no,cust_container_no,*/article_qty,real_qty,deliver_area,status,line_no,
trunck_cell_no,a_sorter_chute_no,check_chute_no,deliver_obj,advance_cell_no,assign_name,outstock_name,
instock_name,outstock_date,instock_date,dps_cell_no,/*equipment_no,*/priority,exp_date,pick_device,
advance_pick_name,advance_pick_date,label_no,stock_type,empty_flag,unbox_flag
from ODATA_OUTSTOCK_DHTY


/

