create package PKLG_ODATA_DELIVER is
  /**********************************************************************************************************
     luozhiling
     2013.11.10
     功能：表单装车（多选装车）
  ***********************************************************************************************************/
  procedure P_odata_CloseCar(strEnterpriseNo in odata_loadpropose_m.enterprise_no%type, --企业编码
                             strWareHouseNo  in odata_loadpropose_m.warehouse_no%type, --仓库编码
                             strDeliverObj   in odata_divide_d.deliver_obj%type, --配送对象（客户编码、单号）
                             strShipperNo    in odata_loadpropose_m.shipper_no%type, --承运商编码
                             strLineNo       in odata_loadpropose_m.line_no%type, --线路
                             strCarNo        in bdef_defcar.car_no%type, ---车辆编码
                             strUserId       in odata_loadpropose_m.rgst_name%type,
                             strDockNo       in odata_loadpropose_m.dock_no%type,
                             strDivideTrunk  in odata_loadpropose_m.divide_truck%type, --分车编号
                             strcarPlanNo    IN odata_loadpropose_m.car_plan_no%type, --派车计划单
                             strSealNo       in Odata_Loadpropose_m.Seal_No%type, --封条号
                             strLoadType     in odata_loadpropose_m.loadtype%type, --装车类型：1：按承运商；2：线路；3：配送对象（客户\单）
                             --strContainerNo            in    odata_loadpropose_d.container_no%type,
                             strPaperUserId   in odata_loadpropose_m.rgst_name%type,
                             strTmpId         in odata_loadcar_tmp.tmp_id%type, --标识
                             strLoadProposeNo out varchar2,
                             strResult        OUT varchar2);
  /**********************************************************************************************************
     hkl
     2015.10.27
     功能：表单装车（单选装车）
  ***********************************************************************************************************/
  procedure P_odata_CloseCar_One(strEnterpriseNo in odata_loadpropose_m.enterprise_no%type, --企业编码
                                 strWareHouseNo  in odata_loadpropose_m.warehouse_no%type, --仓库编码
                                 strDeliverObj   in odata_divide_d.deliver_obj%type, --配送对象（客户编码、单号）
                                 strShipperNo    in odata_loadpropose_m.shipper_no%type, --承运商编码
                                 strLineNo       in odata_loadpropose_m.line_no%type, --线路
                                 strCarNo        in bdef_defcar.car_no%type, ---车辆编码
                                 strUserId       in odata_loadpropose_m.rgst_name%type,
                                 strDockNo       in odata_loadpropose_m.dock_no%type,
                                 strDivideTrunk  in odata_loadpropose_m.divide_truck%type, --分车编号
                                 strcarPlanNo    IN odata_loadpropose_m.car_plan_no%type, --派车计划单
                                 strSealNo       in Odata_Loadpropose_m.Seal_No%type, --封条号
                                 strLoadType     in odata_loadpropose_m.loadtype%type, --装车类型：1：按承运商；2：线路；3：配送对象（客户\单）
                                 --strContainerNo            in    odata_loadpropose_d.container_no%type,
                                 strPaperUserId   in odata_loadpropose_m.rgst_name%type,
                                 strTmpId         in odata_loadcar_tmp.tmp_id%type, --标识
                                 strLoadProposeNo out varchar2,
                                 strResult        OUT varchar2);

  /**********************************************************************************************************
     功能说明：根据码头号新建或获取建议单号：
              规则：一个码头对应一个装车建议单；
                    一张装车建议单对应多个客户
                    目前适用于天天惠的新建装车建议单
  ************************************************************************************************************/
  procedure P_CreateLoadPropose(strEnterpriseNo in odata_loadpropose_m.enterprise_no%type, --企业编码
                                strWareHouseNo  in odata_loadpropose_m.warehouse_no%type, --仓库编码
                                strDeliverObj   in stock_label_m.deliver_obj%type, --配送对象（客户编码、单号）
                                strShipperNo    in odata_loadpropose_m.shipper_no%type, --承运商编码
                                strLineNo       in odata_loadpropose_m.line_no%type, --线路
                                strCarNo        in bdef_defcar.car_no%type, ---车辆编码
                                strUserId       in odata_loadpropose_m.rgst_name%type,
                                strDockNo       in odata_loadpropose_m.dock_no%type,
                                strDivideTrunk  in odata_loadpropose_m.divide_truck%type, --分车编号
                                strcarPlanNo    IN odata_loadpropose_m.car_plan_no%type, --派车计划单
                                strSealNo       in Odata_Loadpropose_m.Seal_No%type, --封条号
                                strLoadType     in odata_loadpropose_m.loadtype%type, --装车类型：1：按承运商；2：线路；3：配送对象（客户\单）5，按码头
                                strPaperUserId  in odata_loadpropose_m.rgst_name%type,
                                strProposeNo    out odata_loadpropose_m.loadpropose_no%type,
                                strResult       OUT varchar2);
  /*************************************************************************************************************
    功能说明：RF扫描标签时校验此标签能否装车
               1、根据装车类型进行校验；
               2、判断标签状态是否可装车；
  ***********************************************************************************************************/
  procedure P_CheckCanLoadLabel(strEnterpriseNo in odata_loadpropose_m.enterprise_no%type, --企业编码
                                strWareHouseNo  in odata_loadpropose_m.warehouse_no%type, --仓库编码
                                strProposeNo    in odata_loadpropose_m.loadpropose_no%type,
                                strCustNo       in odata_loadpropose_m.cust_no%type,
                                strLabelNo      in stock_label_m.label_no%type,
                                strResult       OUT varchar2);
  /******************************************************************************************************
  功能说明：1、校验派车单是否可装车

  *******************************************************************************************************/
  procedure P_GetCarPlan(strEnterpriseNo  in odata_carplan_volume.enterprise_no%type, --企业编码
                         strWareHouseNo   in odata_carplan_volume.warehouse_no%type, --仓库编码
                         strCarPlanNo     in odata_carplan_volume.car_plan_no%type,
                         strOutCustNo     out odata_carplan_volume.cust_no%type,
                         strOutDeliverObj out stock_label_m.deliver_obj%type,
                         strCloseFlag     out odata_loadpropose_m.loadtype%type, --封车标识，1：可封车；0：不可封车
                         strResult        OUT varchar2);
  /******************************************************************************************************
  功能说明：1、读取派车单号，返回首先要装成的单和客户
            2、校验此客户是否可装车
            此功能适用于配送对象按单的处理方式。

  *******************************************************************************************************/
  procedure P_GetCarPlanAndCheck(strEnterpriseNo  in odata_carplan_volume.enterprise_no%type, --企业编码
                                 strWareHouseNo   in odata_carplan_volume.warehouse_no%type, --仓库编码
                                 strCarPlanNo     in odata_carplan_volume.car_plan_no%type,
                                 strUserId        in odata_loadpropose_m.rgst_name%type,
                                 strDockNo        in odata_loadpropose_m.dock_no%type,
                                 strDivideTrunk   in odata_loadpropose_m.divide_truck%type,
                                 strLoadType      in odata_loadpropose_m.loadtype%type,
                                 strProposeNo     out odata_loadpropose_m.loadpropose_no%type,
                                 strOutCustNo     out odata_carplan_volume.cust_no%type,
                                 strOutDeliverObj out stock_label_m.deliver_obj%type,
                                 strCloseFlag     out odata_loadpropose_m.loadtype%type, --封车标识，1：可封车；0：不可封车
                                 strResult        OUT varchar2);
  /******************************************************************************************************
  功能说明：扫描标签装车；
          处理：1、判断此门店是否已结束扫描，若结束扫描，系统给予拦截；
                2、若是扫描中状态状态，则写装车数据
  ******************************************************************************************************/
  procedure P_CreateLoadItem(strEnterpriseNo in odata_loadpropose_m.enterprise_no%type, --企业编码
                             strWareHouseNo  in odata_loadpropose_m.warehouse_no%type, --仓库编码
                             strProposeNo    in odata_loadpropose_m.loadpropose_no%type,
                             strCustNo       in odata_loadpropose_m.cust_no%type,
                             strLabelNo      in stock_label_m.label_no%type,
                             strUserId       in odata_loadpropose_m.rgst_name%type,
                             strResult       OUT varchar2);
  /***********************************************************************************************8***
  功能说明：1、校验此单是否可装车；
            2、校验此容器是否可装车；
            3、写装车建议单明细；
            4、返回要装车的客户和单号

  *******************************************************************************************************/
  procedure P_SaveLoadItem(strEnterpriseNo  in odata_loadpropose_m.enterprise_no%type, --企业编码
                           strWareHouseNo   in odata_loadpropose_m.warehouse_no%type, --仓库编码
                           strProposeNo     in odata_loadpropose_m.loadpropose_no%type,
                           strCarPlanNo     in odata_loadpropose_m.car_plan_no%type, --派车单号，若无记N
                           strCustNo        in odata_loadpropose_m.cust_no%type,
                           strDeliverObj    in odata_exp_m.exp_no%type, --当前配送对象
                           strLabelNo       in stock_label_m.label_no%type,
                           strUserId        in odata_loadpropose_m.rgst_name%type,
                           strOutCustNo     out odata_loadpropose_m.cust_no%type, --下一客户
                           strOutDeliverObj out odata_loadpropose_d.deliver_obj%type, --下一配送对象
                           strCloseFlag     out odata_loadpropose_m.loadtype%type, --封车标识，1：可封车；0：不可封车
                           strResult        OUT varchar2);
  /********************************************************************************************************
  功能说明：1、客户扫描完成
            处理：1
  ********************************************************************************************************/
  procedure P_CloseCust(strEnterpriseNo in odata_loadpropose_m.enterprise_no%type, --企业编码
                        strWareHouseNo  in odata_loadpropose_m.warehouse_no%type, --仓库编码
                        strProposeNo    in odata_loadpropose_m.loadpropose_no%type,
                        strCustNo       in odata_loadpropose_m.cust_no%type,
                        strDeliverObj   in odata_loadpropose_d.deliver_obj%type, --配送对象
                        strUserId       in odata_loadpropose_m.updt_name%type, --装车人
                        strResult       OUT varchar2);
  /********************************************************************************************************
  功能说明：1、判断单据是否扫描完，若扫描完
            2。1更新装车建议单装车
            2。2更新派车单装车

           此过程适用于按配送对象是出货单的情况
  ********************************************************************************************************/
  procedure P_CloseExp(strEnterpriseNo in odata_loadpropose_m.enterprise_no%type, --企业编码
                       strWareHouseNo  in odata_loadpropose_m.warehouse_no%type, --仓库编码
                       strProposeNo    in odata_loadpropose_m.loadpropose_no%type,
                       strCustNo       in odata_loadpropose_m.cust_no%type,
                       strDeliverObj   in odata_loadpropose_d.deliver_obj%type,
                       srrCarPlanNo    in odata_loadpropose_m.car_plan_no%type,
                       strResult       OUT varchar2);
  /**********************************************************************************************************
     luozhiling
     2013.11.10
     功能：整单封车
  ***********************************************************************************************************/
  procedure P_odata_deliver(strEnterpriseNo in odata_loadpropose_m.enterprise_no%type, --企业编码
                            strWareHouseNo  in odata_loadpropose_m.warehouse_no%type, --仓库编码
                            strProposeNo    in odata_loadpropose_m.loadpropose_no%type,
                            strUserId       in odata_loadpropose_m.updt_name%type, --装车人
                            strPaperUserId  in odata_loadpropose_m.updt_name%type, --单据人
                            strDeliverNo    out odata_deliver_m.deliver_no%type, --配送单号
                            strResult       OUT varchar2);
  /********************************************************************************************************
   功能说明：1、校验此标签是否能封车
                目前适用于天天惠模式

  **********************************************************************************************************/
  procedure P_CloseCar(strEnterpriseNo in odata_loadpropose_m.enterprise_no%type, --企业编码
                       strWareHouseNo  in odata_loadpropose_m.warehouse_no%type, --仓库编码
                       strProposeNo    in odata_loadpropose_m.loadpropose_no%type,
                       strUserId       in odata_loadpropose_m.updt_name%type, --装车人
                       strPaperUserId  in odata_loadpropose_m.updt_name%type, --单据人
                       strDeliverNo    out odata_deliver_m.deliver_no%type, --配送单号
                       strResult       OUT varchar2);
  /**********************************************************************************************************
     lich
     2014.06.05
     功能：校验此配送对象能否装车完成
  ***********************************************************************************************************/
  procedure P_CheckCanDeliver(strEnterpriseNo in odata_loadpropose_m.enterprise_no%type, --企业编码
                              strWareHouseNo  in odata_loadpropose_m.warehouse_no%type, --仓库编码
                              strProposeNo    in odata_loadpropose_m.loadpropose_no%type,
                              strDeliverObj   in odata_loadpropose_d.deliver_obj%type, --
                              strResult       OUT varchar2);
  /**********************************************************************************************************
     lich
     2014.06.05
     功能：校验能否装车
  ***********************************************************************************************************/
  procedure P_CheckCanLoadCar(strEnterpriseNo in odata_loadcar_tmp.enterprise_no%type, --企业编码
                              strWareHouseNo  in odata_loadcar_tmp.warehouse_no%type, --仓库编码
                              strTmpId        in odata_loadcar_tmp.tmp_id%type, --标识
                              strResult       OUT varchar2);
  /**********************************************************************************************************
     lich
     2014.06.05
     功能：前台界面校验能否装车，按单做校验
  ***********************************************************************************************************/
  procedure P_CheckCanLoadCarFromExp(strEnterpriseNo in odata_loadcar_tmp.enterprise_no%type, --企业编码
                                     strWareHouseNo  in odata_loadcar_tmp.warehouse_no%type, --仓库编码
                                     strOwner_No     in bdef_defowner.owner_no%type,
                                     strWave_No      in odata_deliver_d.wave_no%type,
                                     strDeliver_Obj  in odata_deliver_m.deliver_obj%type, --配送对象
                                     strResult       OUT varchar2);
  /**********************************************************************************************************
     wyf
     2015.08.21
     功能：更新出货单状态
  ***********************************************************************************************************/
  procedure P_Exp_Over(strEnterpriseNo in odata_deliver_d.enterprise_no%type, --企业编码
                       strWareHouseNo  in odata_deliver_d.warehouse_no%type, --仓库编码
                       strDeliverNo    in odata_deliver_d.deliver_no%type,
                       strUserID       in bdef_defworker.worker_no%type,
                       strResult       OUT varchar2);

  /**********************************************************************************************************************
  功能：自动封车,只适用于配送对象是出货单的情况
       luozhiling
  2015.6.1
  *********************************************************************************************************************/
  procedure P_AutoCloseCar(strEnterPriseNo in odata_outstock_m.enterprise_no%type, --企业号
                           strWareHouseNo  in odata_outstock_m.warehouse_no%type, --仓别
                           strExpNo        in odata_outstock_m.outstock_no%type, --下架单号
                           strDock_No      in odata_outstock_m.dock_no%type, --工作站
                           strUserID       in odata_outstock_m.rgst_name%type, --回单人
                           strOutMsg       out varchar2);

  /**********************************************************************************************************************
  功能：装车，扫描（客户，箱标签，板标签）
       sunl 2016.03.17
  *********************************************************************************************************************/
  procedure P_S_ScanLabelNo(strEnterPriseNo   in stock_label_m.enterprise_no%type, --企业号
                            strWareHouseNo    in stock_label_m.warehouse_no%type, --仓别
                            strScanNo         in stock_label_m.label_no%type, --扫描数据
                            strProposeNo      in odata_loadpropose_m.loadpropose_no%type, --装车建议单
                            strDeliverObj     out varchar2, --配送对象
                            strWaveNo         out varchar2, --波次
                            strBufferNo       out varchar2, --暂存区
                            strScanLabelCount out number, --已扫数量
                            strNotScanCount   out number, --未扫数量
                            strCustNo         out varchar2, --客户编码
                            strCustName       out varchar2, --客户名称
                            strOutMsg         out varchar2);

  /**********************************************************************************************************************
  功能：装车，扫描（板标签）,输入（物流箱数）
       sunl 2016.03.17
  *********************************************************************************************************************/
  procedure P_S_LoadCar(strEnterPriseNo   in stock_label_m.enterprise_no%type, --企业号
                        strWareHouseNo    in stock_label_m.warehouse_no%type, --仓别
                        strCustNo         in stock_label_m.cust_no%type, --客户
                        strScanNo         in stock_label_m.label_no%type, --扫描数据
                        strBoxCount       in number, --物流箱数
                        strProposeNo      in odata_loadpropose_m.loadpropose_no%type, --装车建议单
                        strUserID         in stock_label_m.rgst_name%type, --装车人
                        strWaveNo         IN VARCHAR2, --波次号
                        strScanLabelCount out number, --已扫数量
                        strNotScanCount   out number, --未扫数量
                        strOutMsg         out varchar2);
  /**********************************************************************************************************************
  功能：封车，输入（车辆编码）
       sunl 2016.03.17
  *********************************************************************************************************************/
  procedure P_S_CloseCar(strEnterPriseNo in stock_label_m.enterprise_no%type, --企业号
                         strWareHouseNo  in stock_label_m.warehouse_no%type, --仓别
                         strCarNo        in stock_label_m.label_no%type, --车辆编码
                         strProposeNo    in odata_loadpropose_m.loadpropose_no%type, --装车建议单
                         strDriverWorker in bdef_defcar.driver_worker%type, --司机
                         strUserID       in stock_label_m.rgst_name%type, --封车人
                         strOutMsg       out varchar2);

  /**********************************************************************************************************
   hb insert to 20160606
   装车-根据承运商装车
  ************************************************************************************************************/
  procedure P_CreateLoadMByShipper(strEnterpriseNo   in odata_loadpropose_m.enterprise_no%type, --企业编码
                                   strWareHouseNo    in odata_loadpropose_m.warehouse_no%type, --仓库编码
                                   strDeliverObj     in stock_label_m.deliver_obj%type, --配送对象（客户编码、单号）
                                   strShipperNo      in odata_loadpropose_m.shipper_no%type, --承运商编码
                                   strLineNo         in odata_loadpropose_m.line_no%type, --线路
                                   strCarNo          in bdef_defcar.car_no%type, ---车辆编码
                                   strUserId         in odata_loadpropose_m.rgst_name%type,
                                   strDockNo         in odata_loadpropose_m.dock_no%type,
                                   strDivideTrunk    in odata_loadpropose_m.divide_truck%type, --分车编号
                                   strcarPlanNo      IN odata_loadpropose_m.car_plan_no%type, --派车计划单
                                   strSealNo         in Odata_Loadpropose_m.Seal_No%type, --封条号
                                   strLoadType       in odata_loadpropose_m.loadtype%type, --装车类型：1：按承运商；2：线路；3：配送对象（客户\单）5，按码头6：派车单
                                   strProposeNo      out odata_loadpropose_m.loadpropose_no%type,
                                   strShipperName    out bdef_defshipper.shipper_name%type, --返回承运商名称
                                   strScanLabelCount out number, --当前建议单已扫数量
                                   strResult         OUT varchar2);

  /******************************************************************************************************
   hb insert to 20160606
   装车-根据承运商新增装车建议单单明细
  ******************************************************************************************************/
  procedure P_CreateLoadDByShipper(strEnterpriseNo   in odata_loadpropose_m.enterprise_no%type, --企业编码
                                   strWareHouseNo    in odata_loadpropose_m.warehouse_no%type, --仓库编码
                                   strProposeNo      in odata_loadpropose_m.loadpropose_no%type,
                                   strLabelNo        in stock_label_m.label_no%type,
                                   strUserId         in odata_loadpropose_m.rgst_name%type,
                                   strScanLabelCount out number, --当前建议单已扫数量
                                   strOutMsg         out varchar2);

  /**********************************************************************************************************************
   hb insert to 20160606
   装车-根据承运商封车
  *********************************************************************************************************************/
  procedure P_DeliverCarByShipper(strEnterPriseNo in stock_label_m.enterprise_no%type, --企业号
                                  strWareHouseNo  in stock_label_m.warehouse_no%type, --仓别
                                  strProposeNo    in odata_loadpropose_m.loadpropose_no%type, --装车建议单
                                  strUserID       in stock_label_m.rgst_name%type, --封车人
                                  strOutMsg       out varchar2);

  /**********************************************************************************************************************
  功能：按客户波次装车检查扫描数据(客户或客户标签)的合法性
  huangb 20160707
  *********************************************************************************************************************/
  procedure P_Check_ScanDataByWaveNo(strEnterPriseNo in stock_label_m.enterprise_no%type, --企业号
                                     strWareHouseNo  in stock_label_m.warehouse_no%type, --仓别
                                     strScanNo       in stock_label_m.label_no%type, --扫描数据
                                     strOutCustNo    out bdef_defcust.cust_no%type, --客户编号
                                     strOutMsg       out varchar2);

  /**********************************************************************************************************************
  功能：按客户波次装车
  huangb 20160707
  *********************************************************************************************************************/
  procedure P_LoadCarByWaveNo(strEnterPriseNo in stock_label_m.enterprise_no%type, --企业号
                              strWareHouseNo  in stock_label_m.warehouse_no%type, --仓别
                              strCustNo       in stock_label_m.cust_no%type, --客户
                              strBoxCount     in number, --物流箱数
                              strProposeNo    in odata_loadpropose_m.loadpropose_no%type, --装车建议单
                              strUserID       in stock_label_m.rgst_name%type, --装车人
                              strWaveNo       IN stock_label_m.wave_no%type, --波次号
                              strOutMsg       out varchar2);

  /**********************************************************************************************************************
  功能：按客户波次封车
  huangb 20160708
  *********************************************************************************************************************/
  procedure P_DeliverCarByWaveNo(strEnterPriseNo in stock_label_m.enterprise_no%type, --企业号
                                 strWareHouseNo  in stock_label_m.warehouse_no%type, --仓别
                                 strProposeNo    in odata_loadpropose_m.loadpropose_no%type, --装车建议单
                                 strCarNo        in bdef_defcar.car_no%type, --车辆编码
                                 strDriverWorker in bdef_defcar.driver_worker%type, --司机
                                 strUserID       in odata_deliver_m.rgst_name%type, --操作人员
                                 strOutMsg       out varchar2);

end PKlg_ODATA_DELIVER;


/

