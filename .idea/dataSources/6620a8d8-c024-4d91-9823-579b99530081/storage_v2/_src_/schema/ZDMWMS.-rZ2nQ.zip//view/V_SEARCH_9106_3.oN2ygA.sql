create view V_SEARCH_9106_3 as
select icm.check_no,
       icm.s_check_no,
       iim.po_no as import_no,
       --icm.import_no,
       to_char(icm.check_end_date, 'yyyy-mm-dd') check_date,
       --icd.article_no,
       bda.owner_article_no as article_no,
       bda.article_name,
       icd.barcode,
       icd.packing_qty,
       bdp.packing_unit,
       iisd.po_qty,
       TRUNC(iisd.po_qty / icd.packing_qty) as BOX_PO_QTY, --箱数
       MOD(iisd.po_qty, icd.packing_qty) as Pcs_PO_QTY, --零散数
       iisd.import_qty,
       TRUNC(iisd.import_qty / icd.packing_qty) as BOX_Import_QTY, --箱数
       MOD(iisd.import_qty, icd.packing_qty) as Pcs_Import_QTY, --零散数
       iisd.po_qty - iisd.import_qty CHECK_DIFF_QTY,
       TRUNC((iisd.po_qty - iisd.import_qty) / icd.packing_qty) as BOX_Diff_QTY, --箱数
       MOD((iisd.po_qty - iisd.import_qty), icd.packing_qty) as Pcs_Diff_QTY, --零散数
       icm.supplier_no,
       bds.supplier_name,
       bda.unit,
       bda.unit_volumn,
       bda.unit_weight
  from (select icd.article_no,
               icd.barcode,
               icd.check_no,
               icd.packing_qty,
               sum(icd.check_qty) check_qty
          from idata_check_d icd
         group by icd.check_no,
                  icd.article_no,
                  icd.barcode,
                  icd.check_qty,
                  icd.packing_qty
        ) icd
 inner join idata_check_m icm
    on icd.check_no = icm.check_no
 inner join bdef_defarticle bda
    on icd.article_no = bda.article_no
 inner join bdef_article_packing bdp
    on icd.article_no = bdp.article_no
   and icd.packing_qty = bdp.packing_qty
 inner join bdef_defsupplier bds
    on icm.supplier_no = bds.supplier_no
 inner join idata_import_sdhty iisd
    on icm.s_import_no = iisd.s_import_no
   and icd.article_no = iisd.article_no
 inner join idata_import_m iim
   on icm.import_no = iim.import_no
   and icm.warehouse_no = iim.warehouse_no

/

