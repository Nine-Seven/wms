create package body        PKLG_RILOCATE is
/**************************************************************************************************
  功能说明：返配入库定位
           1、好货转入库定位；
           2、坏货定位到退货区，
  创建人：luozhiling
  创建时间：2014.12.9
  返配定位根据策略来 huangb 20160809
***************************************************************************************************/
  procedure p_locate_main(strEnterPriseNo in  ridata_locate_direct.enterprise_no%type,
                          strWareHouseNo  in ridata_locate_direct.warehouse_no%type, --仓库代码
                          strOwnerNo      in ridata_locate_direct.owner_no%type, --货主代码
                          strLocateNo     in ridata_locate_direct.locate_no%type,
                          strDockNo       in ridata_locate_direct.dock_no%type,
                          strUserID       in ridata_locate_direct.rgst_name%type,
                          strOutMsg       out varchar2) is

   v_UmOrderCount number; --判断是否有定位指示信息

   begin
    strOutMsg := 'N|[p_locate_main]';

    --循环返配定位指示单据品质类型
    for curUmOrder in
      (select distinct rld.untread_type, rld.class_type, rld.quality_flag
         from ridata_locate_direct rld
        where rld.enterprise_no = strEnterPriseNo
          and rld.warehouse_no = strWareHouseNo
          and rld.owner_no = strOwnerNo
          and rld.locate_no = strLocateNo
          and rld.status = '10'
        order by rld.untread_type, rld.class_type, rld.quality_flag) loop

      v_UmOrderCount := v_UmOrderCount + 1;

      p_Ridata_Write_direct(strEnterPriseNo,
                            strWareHouseNo, --仓库代码
                            strOwnerNo, --货主代码
                            strLocateNo,
                            curUmOrder.Untread_Type, --单据类型
                            curUmOrder.Class_Type, --0:一般返配；1：仓调返配
                            curUmOrder.Quality_Flag,
                            strDockNo,
                            strUserID,
                            strOutMsg);
      if substr(strOutMsg, 1, 1) = 'N' then
            return;
          end if;

    end loop;
    if v_UmOrderCount <= 0 then
      strOutMsg := 'N|[返配定位指示板明细为空]';
      return;
    end if;

    /*--读取定位指示
    for curUmLocateDirect in (select distinct rld.quality_flag from ridata_locate_direct rld
       where rld.enterprise_no=strEnterPriseNo and rld.warehouse_no = strWareHouseNo
         and rld.owner_no = strOwnerNo
         and rld.locate_no = strLocateNo
         and rld.status = '10' order by rld.quality_flag) loop

       if curUmLocateDirect.quality_flag='A' or  curUmLocateDirect.quality_flag='2' then --退货区定位
          p_RecedeGoodslocate_main(strEnterPriseNo,strWareHouseNo,strOwnerNo,strLocateNo,curUmLocateDirect.quality_flag,
              strDockNo,strUserID,strOutMsg);
          if substr(strOutMsg, 1, 1) = 'N' then
            return;
          end if;
       end if;

       if curUmLocateDirect.quality_flag='0' then --转正常入库
          p_GoodLoate_Main(strEnterPriseNo,strWareHouseNo,strOwnerNo,strLocateNo,
             strDockNo,strUserID,strOutMsg);
          if substr(strOutMsg, 1, 1) = 'N' then
            return;
          end if;
       end if;

       if curUmLocateDirect.quality_flag='B' then     --报损库（次品库）
          p_BadGoodslocate_main(strEnterPriseNo,strWareHouseNo,strOwnerNo,strLocateNo,curUmLocateDirect.quality_flag,
             strDockNo,strUserID,strOutMsg);
          if substr(strOutMsg, 1, 1) = 'N' then
            return;
          end if;
       end if;

       if curUmLocateDirect.quality_flag='1' then     --过季品
          p_OutofSeasonGoodslocate_main(strEnterPriseNo,strWareHouseNo,strOwnerNo,strLocateNo,curUmLocateDirect.quality_flag,
             strDockNo,strUserID,strOutMsg);
          if substr(strOutMsg, 1, 1) = 'N' then
            return;
          end if;
       end if;

   end loop;*/

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_locate_main;

  /****************************************************************************************************
    返配定位写库存以及上架指示 huangb 20160809
  ***************************************************************************************************/
  procedure p_Ridata_Write_direct(strEnterPriseNo in ridata_locate_direct.enterprise_no%type,
                                  strWareHouseNo  in ridata_locate_direct.warehouse_no%type, --仓库代码
                                  strOwnerNo      in ridata_locate_direct.owner_no%type, --货主代码
                                  strLocateNo     in ridata_locate_direct.locate_no%type,
                                  strUntreadType  in ridata_check_pal.untread_type%type, --单据类型
                                  strClassType    in ridata_check_pal.class_type%type, --0:一般返配；1：仓调返配
                                  strQualityFlag  in ridata_check_pal.quality%type,
                                  strDockNo       in ridata_locate_direct.dock_no%type,
                                  strUserID       in ridata_locate_direct.rgst_name%type,
                                  strOutMsg       out varchar2) is

  v_UmRule                    number := 0; --判断是否有策略ID
  v_StrategyId                wms_riordertype.strategy_id%type := '1'; --返配策略ID
  v_AreaQuality               cdef_defarea.area_quality%type := strQualityFlag; --区域品质
  v_strInstockCellNo          cdef_defcell.cell_no%type := 'N'; --上架储位
  v_nLocateCellID             ridata_instock_direct.dest_cell_id%type := -1;

  begin
    strOutMsg := 'N|p_Ridata_Write_direct';

    --获取返配策略
    PKLG_WMS_Public.p_GetRIdataOrder(strEnterPriseNo,--企业号 必传
                                     strWarehouseNo, --仓别
                                     strOwnerNo, --委托业主
                                     strUntreadType, --单据类型 必传
                                     strClassType, --必传
                                     strQualityFlag, --必传
                                     'strategy_id', --需要取值的列名
                                     v_StrategyId, --返回列名的值
                                     strOutMsg);
    if substr(strOutMsg, 1, 1) = 'N' then
      return;
    end if;

    --循环返配策略规则
    for curRule in (select r.*
                      from wms_defstrategy t
                      inner join wms_defstrategy_d td
                        on t.strategy_type = td.strategy_type
                       and t.strategy_id = td.strategy_id
                      inner join wms_defrule r
                        on r.strategy_type = td.strategy_type
                       and r.rule_id = td.rule_id
                       and (r.use_type <> '0' or r.use_type is null)
                     where t.strategy_id = v_StrategyId
                       and t.strategy_type = 'RI'
                     order by td.rule_order) loop

      v_UmRule := v_UmRule + 1;
      /*1:定位到退货区(带品质条件)
      2:定位到报损区(带品质条件)
      3:转进货定位
      4:定位到异常区
      5:根据品质找储位
      6:定位到过季品储位(带品质条件) */

      if curRule.Rule_Id = '3' then
        --转进货定位
        p_GoodLoate_Main(strEnterPriseNo,strWareHouseNo,strOwnerNo,strLocateNo
                         ,strUntreadType,strClassType,strQualityFlag
                         ,strDockNo,strUserID,strOutMsg);
        if substr(strOutMsg, 1, 1) = 'N' then
          return;
        end if;
      else
        --查找上架储位
        p_Ridata_SelectInstockCellNo
        (strEnterPriseNo,strWarehouseNo,v_AreaQuality,curRule.Rule_Id,v_strInstockCellNo,strOutMsg);
        if substr(strOutMsg, 1, 1) = 'N' then
          return;
        end if;
      end if;

      --读取定位指示
      for curUmLocateDirect
        in (select distinct rld.*
              from ridata_locate_direct rld
             inner join ridata_check_pal rcp
                on rcp.enterprise_no = rld.enterprise_no
               and rcp.warehouse_no = rld.warehouse_no
               and rcp.owner_no = rcp.owner_no
               and rcp.label_no = rld.label_no
               and rcp.article_no = rld.article_no
               and rcp.untread_type = strUntreadType
               and rcp.class_type = strClassType
               and rcp.quality = strQualityFlag
             where rld.enterprise_no = strEnterPriseNo
               and rld.warehouse_no = strWareHouseNo
               and rld.owner_no = strOwnerNo
               and rld.locate_no = strLocateNo
               and rld.status = '10'
             order by rld.label_no, rld.cell_no, rld.article_no) loop

        if curUmLocateDirect.Specify_Cell_No = 'N' and v_strInstockCellNo = 'N' then
          exit;
        end if;

        if curUmLocateDirect.Specify_Cell_No <> 'N' then
          v_strInstockCellNo := curUmLocateDirect.Specify_Cell_No;
        end if;

        --写库存
        PKOBJ_STOCK.p_UpdtContent_Reservation(strEnterPriseNo,strWareHouseNo, --仓库编码
                                              curUmLocateDirect.Cell_No, --来源储位
                                              curUmLocateDirect.Cell_Id, --来源储位ID
                                              v_strInstockCellNo, --目的储位
                                              curUmLocateDirect.Label_No,
                                              curUmLocateDirect.sub_Label_No,
                                              curUmLocateDirect.Qty, --商品数量
                                              '0', --预上类型
                                              strUserID, --操作人员
                                              v_nLocateCellID, --储位id
                                              strOutMsg);
        if substr(strOutMsg, 1, 1) = 'N' then
          return;
        end if;

        --写上架指示
        p_write_instockdirect(strEnterPriseNo,strWareHouseNo,
                              curUmLocateDirect.Row_Id,
                              v_strInstockCellNo,
                              v_nLocateCellID,
                              strUserID,
                              strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;

      end loop;

    end loop;
    if v_UmRule <= 0 then
      strOutMsg := 'N|[策略ID[' || v_StrategyId || ']未配置]';
      return;
    end if;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_Ridata_Write_direct;

  /****************************************************************************************************
    返配定位查找储位 huangb 20160809
  ***************************************************************************************************/
  procedure p_Ridata_SelectInstockCellNo(strEnterPriseNo      in ridata_locate_direct.enterprise_no%type,
                                         strWareHouseNo       in ridata_locate_direct.warehouse_no%type, --仓库代码
                                         strAreaQuality       in cdef_defarea.area_quality%type,
                                         strRuleId            in wms_defrule.rule_id%type, --规则ID
                                         strReturnInstockCell out cdef_defcell.cell_no%type, --返回上架储位
                                         strOutMsg            out varchar2) is

  v_strInstockCellNo          cdef_defcell.cell_no%type := 'N'; --上架储位

  begin
    strOutMsg := 'N|p_Ridata_SelectInstockCellNo';

    /*1:定位到退货区(带品质条件)
      2:定位到报损区(带品质条件)
      3:转进货定位
      4:定位到异常区
      5:根据品质找储位
      6:定位到过季品储位(带品质条件) */
    begin
      if strRuleId = 1 then
        begin
          select cell_no into v_strInstockCellNo
            from (select cdc.cell_no
                    from cdef_defcell cdc
                   inner join cdef_defarea cdd
                      on cdc.enterprise_no = cdd.enterprise_no
                     and cdc.warehouse_no = cdd.warehouse_no
                     and cdc.ware_no = cdd.ware_no
                     and cdc.area_no = cdd.area_no
                     and cdc.cell_status = '0'
                     and cdc.check_status = '0'
                   where cdd.enterprise_no = strEnterPriseNo
                     and cdd.warehouse_no = strWareHouseNo
                     and cdd.area_quality = strAreaQuality
                     and cdd.area_usetype in ('3')
                     and cdd.area_attribute in ('0')
                   order by cdc.cell_no)
           where rownum <= 1;
        exception
          when no_data_found then
            v_strInstockCellNo := 'N';
        end;

      elsif strRuleId = 2 then
        begin
          select cell_no into v_strInstockCellNo
            from (select cdc.cell_no
                    from cdef_defcell cdc
                   inner join cdef_defarea cdd
                      on cdc.enterprise_no = cdd.enterprise_no
                     and cdc.warehouse_no = cdd.warehouse_no
                     and cdc.ware_no = cdd.ware_no
                     and cdc.area_no = cdd.area_no
                     and cdc.cell_status = '0'
                     and cdc.check_status = '0'
                   where cdd.enterprise_no = strEnterPriseNo
                     and cdd.warehouse_no = strWareHouseNo
                     and cdd.area_quality = strAreaQuality
                     and cdd.area_usetype in ('2')
                     and cdd.area_attribute in ('0')
                   order by cdc.cell_no)
           where rownum <= 1;
        exception
          when no_data_found then
            v_strInstockCellNo := 'N';
        end;

      elsif strRuleId = 4 then
        begin
          select cell_no into v_strInstockCellNo
            from (select cdc.cell_no
                    from cdef_defcell cdc
                   inner join cdef_defarea cdd
                      on cdc.enterprise_no = cdd.enterprise_no
                     and cdc.warehouse_no = cdd.warehouse_no
                     and cdc.ware_no = cdd.ware_no
                     and cdc.area_no = cdd.area_no
                     and cdc.cell_status = '0'
                     and cdc.check_status = '0'
                   where cdd.enterprise_no = strEnterPriseNo
                     and cdd.warehouse_no = strWareHouseNo
                     and cdd.area_usetype in ('5')
                     and cdd.area_attribute in ('0')
                   order by cdc.cell_no)
           where rownum <= 1;
        exception
          when no_data_found then
            v_strInstockCellNo := 'N';
        end;

      elsif strRuleId = 5 then
        begin
          select cell_no into v_strInstockCellNo
            from (select cdc.cell_no
                    from cdef_defcell cdc
                   inner join cdef_defarea cdd
                      on cdc.enterprise_no = cdd.enterprise_no
                     and cdc.warehouse_no = cdd.warehouse_no
                     and cdc.ware_no = cdd.ware_no
                     and cdc.area_no = cdd.area_no
                     and cdc.cell_status = '0'
                     and cdc.check_status = '0'
                   where cdd.enterprise_no = strEnterPriseNo
                     and cdd.warehouse_no = strWareHouseNo
                     and cdd.area_quality = strAreaQuality
                   order by cdc.cell_no)
           where rownum <= 1;
        exception
          when no_data_found then
            v_strInstockCellNo := 'N';
        end;
      elsif strRuleId = 6 then
        begin
          select cell_no into v_strInstockCellNo
            from (select cdc.cell_no
                    from cdef_defcell cdc
                   inner join cdef_defarea cdd
                      on cdc.enterprise_no = cdd.enterprise_no
                     and cdc.warehouse_no = cdd.warehouse_no
                     and cdc.ware_no = cdd.ware_no
                     and cdc.area_no = cdd.area_no
                     and cdc.cell_status = '0'
                     and cdc.check_status = '0'
                   where cdd.enterprise_no = strEnterPriseNo
                     and cdd.warehouse_no = strWareHouseNo
                     and cdd.area_quality = strAreaQuality
                     and cdd.area_usetype in ('1')
                     and cdd.area_attribute in ('0')
                     and cdd.attribute_type in ('0')
                   order by cdc.cell_no)
           where rownum <= 1;
        exception
          when no_data_found then
            v_strInstockCellNo := 'N';
        end;
      else
        strReturnInstockCell := v_strInstockCellNo;
        strOutMsg := 'N|策略规则['|| strRuleId ||']暂未实现';
        return;
      end if;
    end;

    strReturnInstockCell := v_strInstockCellNo;
    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_Ridata_SelectInstockCellNo;

/****************************************************************************************************
    定位到退货区

***************************************************************************************************/
  procedure p_RecedeGoodslocate_main(strEnterPriseNo  in  ridata_locate_direct.enterprise_no%type,
                          strWareHouseNo in ridata_locate_direct.warehouse_no%type, --仓库代码
                          strOwnerNo     in ridata_locate_direct.owner_no%type, --货主代码
                          strLocateNo    in ridata_locate_direct.locate_no%type,
                          strQualityFlag in ridata_locate_direct.quality_flag%type,
                          strDockNo      in ridata_locate_direct.dock_no%type,
                          strUserID      in ridata_locate_direct.rgst_name%type,
                          strOutMsg      out varchar2) is
    v_strUMEspecialCell cdef_defcell.cell_no%type;
    v_strLocateCellNo   cdef_defcell.cell_no%type; --定位的储位
    v_nLocateCellID     ridata_instock_direct.dest_cell_id%type := -1;
  begin
    strOutMsg := 'N|';

    --获取异常储位
    begin

      select cell_no
        into v_strUMEspecialCell
        from (select CDC.CELL_NO
                from cdef_defcell cdc, cdef_defarea cdd
               where cdc.enterprise_no=cdd.enterprise_no and cdc.enterprise_no=strEnterPriseNo
                 and cdc.warehouse_no = cdd.warehouse_no
                 and cdc.ware_no = cdd.ware_no
                 and cdc.area_no = cdd.area_no
                 AND CDC.CELL_STATUS = '0'
                 AND CDC.CHECK_STATUS = 0
                 and cdd.AREA_ATTRIBUTE = '0'
                 and cdd.AREA_USETYPE = '5'
                 and cdd.warehouse_no = strWareHouseNo
               order by CDC.CELL_NO)
       where rownum <= 1;
    exception
      when no_data_found then
        strOutMsg := 'N|[E24213]';
        return;
    end;


    --读取定位指示
    for curUmLocateDirect in (select rld.*,
                                     cai.barcode,
                                     cai.lot_no,
                                     cai.quality,
                                     cai.import_batch_no,
                                     bds.real_supplier_no
                                from ridata_locate_direct rld
                               inner join stock_article_info cai
                                  on rld.article_no = cai.article_no
                                  and rld.enterprise_no=cai.enterprise_no
                                 and rld.article_id = cai.article_id
                                left join bdef_defsupplier bds
                                  on rld.supplier_no = bds.supplier_no
                                  and rld.enterprise_no=bds.enterprise_no
                                 and rld.owner_no = bds.owner_no
                               where rld.enterprise_no=strEnterPriseNo
                                 and rld.warehouse_no = strWareHouseNo
                                 and rld.owner_no = strOwnerNo
                                 and rld.locate_no = strLocateNo
                                 and rld.status = '10'
                                 and rld.quality_flag=strQualityFlag
                               order by rld.label_no,
                                        rld.cell_no,
                                        rld.article_no,
                                        cai.barcode,
                                        cai.lot_no,
                                        cai.quality) loop
      --指定储位
      if curUmLocateDirect.SPECIFY_CELL_NO <> 'N' then
        v_strLocateCellNo := curUmLocateDirect.SPECIFY_CELL_NO;
      else
        --找新储位
        p_RecedeLocate(strEnterPriseNo,strWareHouseNo,
                       curUmLocateDirect.Quality,
                       curUmLocateDirect.article_no,
                       v_strLocateCellNo,
                       strOutMsg);
        if substr(strOutMsg, 1, 1) = 'N' then
          return;
        end if;

      end if;
      if v_strLocateCellNo is null or v_strLocateCellNo = 'N' then
        v_strLocateCellNo := v_strUMEspecialCell;
      end if;


      --写库存
      PKOBJ_STOCK.p_UpdtContent_Reservation(strEnterPriseNo,strWareHouseNo, --仓库编码
                                            curUmLocateDirect.Cell_No, --来源储位
                                            curUmLocateDirect.Cell_Id, --来源储位ID
                                            v_strLocateCellNo, --目的储位
                                            curUmLocateDirect.Label_No,
                                            curUmLocateDirect.sub_Label_No,
                                            curUmLocateDirect.Qty, --商品数量
                                            '0', --预上类型
                                            strUserID, --操作人员
                                            v_nLocateCellID, --储位id
                                            strOutMsg);
      if substr(strOutMsg, 1, 1) = 'N' then
        return;
      end if;

      --写上架指示
      p_write_instockdirect(strEnterPriseNo,strWareHouseNo,
                            curUmLocateDirect.Row_Id,
                            v_strLocateCellNo,
                            v_nLocateCellID,
                            strUserID,
                            strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

    end loop;
    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_RecedeGoodslocate_main;

/****************************************************************************************************
    定位到次品仓

***************************************************************************************************/
  procedure p_BadGoodslocate_main(strEnterPriseNo  in  ridata_locate_direct.enterprise_no%type,
                          strWareHouseNo in ridata_locate_direct.warehouse_no%type, --仓库代码
                          strOwnerNo     in ridata_locate_direct.owner_no%type, --货主代码
                          strLocateNo    in ridata_locate_direct.locate_no%type,
                          strQualityFlag in ridata_locate_direct.quality_flag%type,
                          strDockNo      in ridata_locate_direct.dock_no%type,
                          strUserID      in ridata_locate_direct.rgst_name%type,
                          strOutMsg      out varchar2) is
    v_strUMEspecialCell cdef_defcell.cell_no%type;
    v_strLocateCellNo   cdef_defcell.cell_no%type; --定位的储位
    v_nLocateCellID     ridata_instock_direct.dest_cell_id%type := -1;

  begin
    strOutMsg := 'N|';

    --获取异常储位
    begin

      select cell_no
        into v_strUMEspecialCell
        from (select CDC.CELL_NO
                from cdef_defcell cdc, cdef_defarea cdd
               where cdc.enterprise_no=cdd.enterprise_no and cdc.enterprise_no=strEnterPriseNo
                 and cdc.warehouse_no = cdd.warehouse_no
                 and cdc.ware_no = cdd.ware_no
                 and cdc.area_no = cdd.area_no
                 AND CDC.CELL_STATUS = '0'
                 AND CDC.CHECK_STATUS = 0
                 and cdd.AREA_ATTRIBUTE = '0'
                 and cdd.AREA_USETYPE = '5'
                 and cdd.warehouse_no = strWareHouseNo
               order by CDC.CELL_NO)
       where rownum <= 1;
    exception
      when no_data_found then
        strOutMsg := 'N|[E24213]';
        return;
    end;


    --读取定位指示
    for curUmLocateDirect in (select rld.*
                                from ridata_locate_direct rld
                               where rld.enterprise_no=strEnterPriseNo
                                 and rld.warehouse_no = strWareHouseNo
                                 and rld.owner_no = strOwnerNo
                                 and rld.locate_no = strLocateNo
                                 and rld.status = '10'
                                 and rld.quality_flag=strQualityFlag
                               order by rld.label_no,
                                        rld.cell_no,
                                        rld.article_no) loop
      --指定储位
      if curUmLocateDirect.SPECIFY_CELL_NO <> 'N' then
        v_strLocateCellNo := curUmLocateDirect.SPECIFY_CELL_NO;
      else
        --找新储位
        p_BadGoodLocate(strEnterPriseNo,strWareHouseNo,
                       curUmLocateDirect.article_no,
                       v_strLocateCellNo,
                       strOutMsg);
        if substr(strOutMsg, 1, 1) = 'N' then
          return;
        end if;

      end if;
      if v_strLocateCellNo is null or v_strLocateCellNo = 'N' then
        v_strLocateCellNo := v_strUMEspecialCell;
      end if;


      --写库存
      PKOBJ_STOCK.p_UpdtContent_Reservation(strEnterPriseNo,strWareHouseNo, --仓库编码
                                            curUmLocateDirect.Cell_No, --来源储位
                                            curUmLocateDirect.Cell_Id, --来源储位ID
                                            v_strLocateCellNo, --目的储位
                                            curUmLocateDirect.Label_No,
                                            curUmLocateDirect.sub_Label_No,
                                            curUmLocateDirect.Qty, --商品数量
                                            '0', --预上类型
                                            strUserID, --操作人员
                                            v_nLocateCellID, --储位id
                                            strOutMsg);
      if substr(strOutMsg, 1, 1) = 'N' then
        return;
      end if;

      --写上架指示
      p_write_instockdirect(strEnterPriseNo,strWareHouseNo,
                            curUmLocateDirect.Row_Id,
                            v_strLocateCellNo,
                            v_nLocateCellID,
                            strUserID,
                            strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

    end loop;
    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_BadGoodslocate_main;

/****************************************************************************************************
    功能说明：定位到过季品仓
    luozhiling
    2015.7.18
***************************************************************************************************/
  procedure p_OutofSeasonGoodslocate_main(strEnterPriseNo  in  ridata_locate_direct.enterprise_no%type,
                          strWareHouseNo in ridata_locate_direct.warehouse_no%type, --仓库代码
                          strOwnerNo     in ridata_locate_direct.owner_no%type, --货主代码
                          strLocateNo    in ridata_locate_direct.locate_no%type,
                          strQualityFlag in ridata_locate_direct.quality_flag%type,
                          strDockNo      in ridata_locate_direct.dock_no%type,
                          strUserID      in ridata_locate_direct.rgst_name%type,
                          strOutMsg      out varchar2) is
    v_strUMEspecialCell cdef_defcell.cell_no%type;
    v_strLocateCellNo   cdef_defcell.cell_no%type; --定位的储位
    v_nLocateCellID     ridata_instock_direct.dest_cell_id%type := -1;
  begin
    strOutMsg := 'N|';

    --获取异常储位
    begin

      select cell_no
        into v_strUMEspecialCell
        from (select CDC.CELL_NO
                from cdef_defcell cdc, cdef_defarea cdd
               where cdc.enterprise_no=cdd.enterprise_no and cdc.enterprise_no=strEnterPriseNo
                 and cdc.warehouse_no = cdd.warehouse_no
                 and cdc.ware_no = cdd.ware_no
                 and cdc.area_no = cdd.area_no
                 AND CDC.CELL_STATUS = '0'
                 AND CDC.CHECK_STATUS = 0
                 and cdd.AREA_ATTRIBUTE = '0'
                 and cdd.AREA_USETYPE = '5'
                 and cdd.warehouse_no = strWareHouseNo
               order by CDC.CELL_NO)
       where rownum <= 1;
    exception
      when no_data_found then
        strOutMsg := 'N|[E24213]';
        return;
    end;


    --读取定位指示
    for curUmLocateDirect in (select rld.*
                                from ridata_locate_direct rld
                               where rld.enterprise_no=strEnterPriseNo
                                 and rld.warehouse_no = strWareHouseNo
                                 and rld.owner_no = strOwnerNo
                                 and rld.locate_no = strLocateNo
                                 and rld.status = '10'
                                 and rld.quality_flag=strQualityFlag
                               order by rld.label_no,
                                        rld.cell_no,
                                        rld.article_no) loop
      --指定储位
      if curUmLocateDirect.SPECIFY_CELL_NO <> 'N' then
        v_strLocateCellNo := curUmLocateDirect.SPECIFY_CELL_NO;
      else
        --找新储位
        p_OutofSeasonCellNo(strEnterPriseNo,strWareHouseNo,
                       curUmLocateDirect.article_no,
                       v_strLocateCellNo,
                       strOutMsg);
        if substr(strOutMsg, 1, 1) = 'N' then
          return;
        end if;

      end if;
      if v_strLocateCellNo is null or v_strLocateCellNo = 'N' then
        v_strLocateCellNo := v_strUMEspecialCell;
      end if;


      --写库存
      PKOBJ_STOCK.p_UpdtContent_Reservation(strEnterPriseNo,strWareHouseNo, --仓库编码
                                            curUmLocateDirect.Cell_No, --来源储位
                                            curUmLocateDirect.Cell_Id, --来源储位ID
                                            v_strLocateCellNo, --目的储位
                                            curUmLocateDirect.Label_No,
                                            curUmLocateDirect.sub_Label_No,
                                            curUmLocateDirect.Qty, --商品数量
                                            '0', --预上类型
                                            strUserID, --操作人员
                                            v_nLocateCellID, --储位id
                                            strOutMsg);
      if substr(strOutMsg, 1, 1) = 'N' then
        return;
      end if;

      --写上架指示
      p_write_instockdirect(strEnterPriseNo,strWareHouseNo,
                            curUmLocateDirect.Row_Id,
                            v_strLocateCellNo,
                            v_nLocateCellID,
                            strUserID,
                            strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

    end loop;
    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_OutofSeasonGoodslocate_main;

/****************************************************************************************************
    良品转正常入库
    功能说明：1、更新返配定位指示为13状态，
             2、写对应的入库定位指示；
             3、入库定位；
             4、入库发单；
     创建人：luozhiling
     创建时间：2014.12.9
     返配定位根据策略来 huangb 20160809
     新增标签信息 huangb 20160906
     修改进货上架打印根据返配策略配置来 huangb 20160920
***************************************************************************************************/
  procedure p_GoodLoate_Main(strEnterPriseNo in  ridata_locate_direct.enterprise_no%type,
                             strWareHouseNo  in ridata_locate_direct.warehouse_no%type, --仓库代码
                             strOwnerNo      in ridata_locate_direct.owner_no%type, --货主代码
                             strLocateNo     in ridata_locate_direct.locate_no%type,
                             strUntreadType  in ridata_check_pal.untread_type%type, --单据类型 huangb 20160809
                             strClassType    in ridata_check_pal.class_type%type, --0:一般返配；1：仓调返配 huangb 20160809
                             strQualityFlag  in ridata_check_pal.quality%type, --品质标识 huangb 20160809
                             strDockNo       in ridata_locate_direct.dock_no%type,
                             strUserID       in ridata_locate_direct.rgst_name%type,
                             strOutMsg       out varchar2) is
    v_count            number := 0;
    v_strTaskNo        job_printtask_m.task_no%type;
    v_strLabelNoTmp    stock_label_m.label_no%type;
    v_strContainNo     stock_label_m.container_no%type;
    v_strSessionID     varchar2(10);
    v_PrintInstockType wms_riordertype.print_instock_type%type; --返配上架打印标识 huangb20160920

  begin
    strOutMsg := 'N|[p_NoGoodlocate_main]';

    --获取返配上架打印策略 huangb20160920
    PKLG_WMS_Public.p_GetRIdataOrder(strEnterPriseNo,--企业号 必传
                                     strWarehouseNo, --仓别
                                     strOwnerNo, --委托业主
                                     strUntreadType, --单据类型 必传
                                     strClassType, --必传
                                     strQualityFlag, --必传
                                     'print_instock_type', --需要取值的列名
                                     v_PrintInstockType, --返回列名的值
                                     strOutMsg);
    if substr(strOutMsg, 1, 1) = 'N' then
      return;
    end if;

    --将相应的返配定位i指示转入库定位指示
    insert into idata_locate_direct(enterprise_no,Warehouse_No,Owner_No,Locate_No,Locate_Type,
      Auto_Locate_Flag,Container_Locate_Flag,Source_No,Cell_No,Cell_Id,
      Operate_Type,Article_No,Article_Id,Packing_Qty,
      Article_Qty,Dock_No,Printer_Group_No,Exclude_Cell_No,
      Status,Locate_Time,Check_Worker,Stock_Type,Stock_Value,
      Sub_Label_No,Label_No,Business_Type,
      Rgst_Name,Rgst_Date,Specify_Cell_No,serial_no,import_type)
    select strEnterPriseNo,strWareHouseNo,strOwnerNo,strLocateNo,'3',
      '0','1',t.source_no,t.cell_no,t.cell_id,
      t.operate_type,t.article_no,t.article_id,t.packing_qty,
      t.qty,t.dock_no,t.printer_group_no,t.exclude_cell_no,
      '10',sysdate,strUserID,'1','N',
      t.sub_label_no,t.label_no,t.business_type,t.rgst_name,
      t.rgst_date,t.specify_cell_no,'N',t.untread_type
      from ridata_locate_direct t
      where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo and t.owner_no=strOwnerNo
      and t.untread_type = strUntreadType and t.class_type = strClassType and t.quality_flag = strQualityFlag
      and t.statuS='10' and t.locate_no=strLocateNo/* and t.quality_flag='0'*/;
      if sql%rowcount <= 0 then
        strOutMsg := 'N|[将返配定位指示转为进货定位指示失败0行]';
        return;
      end if;
      --更新返配定位指示状态；
      /*update ridata_locate_direct t set t.status='13'
      where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo and t.owner_no=strOwnerNo
      and t.status='10' and t.locate_no=strLocateNo and t.quality_flag='0';*/
      update ridata_locate_direct t set t.status='13'
       where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo and t.owner_no=strOwnerNo
         and t.untread_type = strUntreadType and t.class_type = strClassType and t.quality_flag = strQualityFlag
         and t.status='10' and t.locate_no=strLocateNo;

      --将返配定位指示转历史
      insert into ridata_locate_directhty
      (enterprise_no,warehouse_no,row_id,owner_no,locate_no,
       auto_locate_flag,source_no,cell_no,cell_id,operate_type,
       article_no,article_id,packing_qty,qty,dock_no,
       printer_group_no,exclude_cell_no,status,
       sub_label_no,label_no,business_type,
       rgst_name,rgst_date,updt_name,updt_date,
       batch_no,supplier_no,operate_date,quality_flag,wave_no)
       select distinct t.enterprise_no,t.warehouse_no,t.row_id,t.owner_no,t.locate_no,
             t.auto_locate_flag,t.source_no,t.cell_no,t.cell_id,t.operate_type,
             t.article_no,t.article_id,t.packing_qty,t.qty,t.dock_no,
             t.printer_group_no,t.exclude_cell_no,t.status,
             t.sub_label_no,t.label_no,t.business_type,
             t.rgst_name,t.rgst_date,t.updt_name,t.updt_date,
             t.batch_no,t.supplier_no,t.operate_date,t.quality_flag,t.wave_no
        from ridata_locate_direct t
        where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo and t.owner_no=strOwnerNo
        and t.untread_type = strUntreadType and t.class_type = strClassType and t.quality_flag = strQualityFlag
        and t.status in('13','16') and t.locate_no=strLocateNo/* and t.quality_flag='0'*/;

      /*delete from ridata_locate_direct t
        where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo and t.owner_no=strOwnerNo
        and t.status in('13','16') and t.locate_no=strLocateNo and t.quality_flag='0';*/
      delete from ridata_locate_direct t
       where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo and t.owner_no=strOwnerNo
         and t.untread_type = strUntreadType and t.class_type = strClassType and t.quality_flag = strQualityFlag
         and t.status='10' and t.locate_no=strLocateNo;

      --循环写标签信息 huangb 20160906
      for t in (select distinct ild.label_no,max(Cell_No) cell_no from idata_locate_direct ild
                 where ild.enterprise_no=strEnterPriseNo and ild.warehouse_no=strWareHouseNo
                   and ild.locate_no = strLocateNo
                 group by ild.label_no) loop
        v_count := v_count + 1;

        --获取系统内部容器号
        pklg_wms_base.p_get_ContainerNoBase(strEnterpriseNo,
                                            strWareHouseNo,
                                            'P',
                                            strUserID,
                                            'D',
                                            1,
                                            2, --标签用途
                                            '31', --容器材质(板)
                                            v_strLabelNoTmp,
                                            v_strContainNo,
                                            v_strSessionID,
                                            strOutMsg);
        if substr(strOutMsg,1,1)='N' then
          return;
        end if;

        if t.label_no <> 'N' then
          v_strLabelNoTmp := t.label_no;
        end if;

        --新增标签头档信息
        pkobj_label.proc_Insert_LabelMaster
          (strEnterPriseNo,strWareHouseNo,'N','N', v_strLabelNoTmp, v_strContainNo,
           'P','N',t.cell_no,'N','N','N',
           'N','N','0','N',strDockNo,'N',
           strUserID,CONST_REPORTID.B_I_INSTOCKP, 'N', 1, '1', '0',
           v_strContainNo,'0','1','N',strOutMsg);
        if substr(strOutMsg, 1, 1) = 'N' then
          return;
        end if;

      end loop;

      if v_count <= 0 then
        strOutMsg := 'N|[进货定位指示【'|| strLocateNo ||'】不存在]';
        return;
      end if;

      --入库定位；
      PKLG_ILOCATE.p_locate_main(strEnterPriseNo,strWareHouseNo,strOwnerNo,strLocateNo,'0',strUserId,v_strTaskNo,strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --入库发单；
      pklg_idata.P_InsertInstock(strEnterPriseNo,strWareHouseNo,strUserId,strLocateNo,strDockNo,v_PrintInstockType,v_strTaskNo,strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_GoodLoate_Main;

  --写上架指示
  procedure p_write_instockdirect(strEnterPriseNo in ridata_instock_direct.enterprise_no%type,
                                  strWareHouseNo  in ridata_instock_direct.warehouse_no%type, --仓库代码
                                  nRowid          in ridata_instock_direct.row_id%type, --定位指示行号
                                  strLocateCellNo in ridata_instock_direct.dest_cell_no%type, --定位储位
                                  nLocateCellID   in ridata_instock_direct.dest_cell_id%type,
                                  strUserID       in ridata_instock_direct.rgst_name%type, --员工代码
                                  strOutMsg       out varchar2) is
  begin
    insert into ridata_instock_direct
      (enterprise_no,row_id,
       source_no,
       locate_no,
       auto_locate_flag,
       operate_type,
       cell_no,
       cell_id,
       warehouse_no,
       owner_no,
       article_no,
       article_id,
       packing_qty,
       dest_cell_no,
       dest_cell_id,
       instock_qty,
       status,
       label_no,
       sub_label_no,
       business_type,
       rgst_name,
       rgst_date,
       updt_name,
       updt_date,supplier_no,batch_no,operate_date,quality_flag,wave_no,untread_type,class_type)
      select rld.enterprise_no,rld.row_id,
             rld.source_no,
             rld.locate_no,
             rld.auto_locate_flag,
             rld.operate_type,
             rld.cell_no,
             rld.cell_id,
             rld.warehouse_no,
             rld.owner_no,
             rld.article_no,
             rld.article_id,
             rld.packing_qty,
             strLocateCellNo,
             nLocateCellID,
             rld.qty,
             '10',
             rld.label_no,
             rld.sub_label_no,
             rld.business_type,
             strUserID,
             sysdate,
             strUserID,
             sysdate,rld.supplier_no,rld.batch_no,rld.operate_date,rld.quality_flag,rld.wave_no,rld.untread_type,rld.class_type
        from ridata_locate_direct rld
       where rld.enterprise_no=strEnterPriseNo and rld.row_id = nRowid
         and rld.status = '10'
         and rld.warehouse_no = strWareHouseNo;

    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E24214]';
      return;
    end if;

    --写定位指示状态
    update ridata_locate_direct ild
       set ild.status = '13',ild.updt_name=strUserID,ild.updt_date=sysdate
     where ild.row_id = nRowid
       and ild.status = '10';
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E24215]';
    end if;
    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_write_instockdirect;
  /*********************************************************************************************8

  功能说明：查找过季品储位
  ***********************************************************************************************/

  procedure p_OutofSeasonCellNo(strEnterPriseNo in ridata_instock_direct.enterprise_no%type,
                           strWareHouseNo in ridata_instock_direct.warehouse_no%type,
                           strArticleNo   in stock_article_info.article_no%type,
                           strCellNo      out ridata_instock_direct.dest_cell_no%type,
                           strOutMsg      out varchar2) is
    v_strCellNo      cdef_defcell.cell_no%type;
  begin
    strOutMsg := 'N|[p_LocateCellNo]';

     begin
           select cell_no
             into v_strCellNo
              from (select cdc.cell_no
                      from cdef_defcell cdc, cdef_defarea cda
                     where cdc.enterprise_no=cda.enterprise_no and
                       cdc.enterprise_no=strEnterPriseNo and cdc.warehouse_no = cda.warehouse_no
                       and cdc.ware_no = cda.ware_no
                       and cdc.area_no = cda.area_no
                       and cda.area_usetype='1'
                       and cdc.warehouse_no = strWareHouseNo
                       and cda.area_quality='1'
                       and cdc.cell_status = '0'
                       and cdc.check_status = '0'
                       and cda.Area_Attribute = '0'
                       and cda.attribute_type='0'
                       and rownum=1);

     exception when no_data_found then
        strOutMsg:='N|[EEEEEE]';--找不到过季品储位

     end;
     strCellNo:=strCellNo;
    strOutMsg := 'Y|';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_OutofSeasonCellNo;

  --查找储位
  /********************************************************************************************
  创建人：luozhiling
  创建时间：2014.12.12
  功能说明：定位到退货区
  **********************************************************************************************/
  procedure p_RecedeLocate(strEnterPriseNo in ridata_instock_direct.enterprise_no%type,
                           strWareHouseNo in ridata_instock_direct.warehouse_no%type,
                           strQuality     in stock_article_info.quality%type,
                           strArticleNo   in stock_article_info.article_no%type,
                           strCellNo      out ridata_instock_direct.dest_cell_no%type,
                           strOutMsg      out varchar2) is
    v_QualityBegin cdef_defarea.area_quality%type;
    v_QualityEnd   cdef_defarea.area_quality%type;
    v_AreaUseType  cdef_defarea.area_usetype%type;
    v_strAFlag     cdef_defarea.a_flag%type;
  begin
    strOutMsg := 'N|[p_LocateCellNo]';

    --良品
    if strQuality >= '0' and strQuality <= '9' then
      v_QualityBegin := '0';
      v_QualityEnd   := '9';
    else
      --if strQuality>='A' and strQuality<='Z' then
      v_QualityBegin := 'A';
      v_QualityEnd   := 'Z';
      --end if;
    end if;

    v_AreaUseType := '3'; --退货区--目前返配不考虑品质，全部定位到退货仓的大储位上

    if strQuality='A' then
       v_strAFlag:='1';
    else
        v_strAFlag:='0';
    end if;


    --找此商品此品质对应的储位
    begin
         select sc.cell_no into strCellNo
          from stock_content sc,stock_article_info sai,cdef_defcell cd,cdef_defarea a
                where sc.enterprise_no=sai.enterprise_no and sc.enterprise_no=cd.enterprise_no
                and sc.enterprise_no=a.enterprise_no and sc.enterprise_no=strEnterPriseNo
                and sc.article_no=sai.article_no and sc.article_id=sai.article_id
                and sc.warehouse_no=cd.warehouse_no and sc.cell_no=cd.cell_no
                and sc.warehouse_no=strWareHouseNo and a.Area_Attribute = '0' --作业区
                and a.area_usetype = v_AreaUseType
                and cd.warehouse_no=a.warehouse_no and cd.ware_no=a.ware_no and cd.area_no=a.area_no
                and cd.a_flag=v_strAFlag and rownum<=1;
    exception when no_data_found then
         strCellNo:='';
    end ;
    --查找此品质对应的空储位；

    if strCellNo ='' or strCellNo is null then
        begin
          select cell_no
            into strCellNo
            from (select cdc.cell_no
                    from cdef_defcell cdc, cdef_defarea cda
                   where cdc.enterprise_no=cda.enterprise_no
                     and cdc.enterprise_no=strEnterPriseNo
                     and cdc.warehouse_no = cda.warehouse_no
                     and cdc.ware_no = cda.ware_no
                     and cdc.area_no = cda.area_no
                     and cdc.warehouse_no = strWareHouseNo
                     and cdc.cell_status = '0'
                     and cdc.check_status = '0'
                     and cda.Area_Attribute = '0' --作业区
                     and cda.area_usetype = v_AreaUseType
                     and cdc.a_flag=v_strAFlag
                     and cda.area_quality >= v_QualityBegin
                     and cda.area_quality <= v_QualityEnd
                   order by cdc.cell_no) t
           where rownum <= 1;
        exception when no_data_found then
           strCellNo:='';
        end;
    end if;

    if strCellNo='' or strCellNo is null then

        begin
          select cell_no
            into strCellNo
            from (select cdc.cell_no
                    from cdef_defcell cdc, cdef_defarea cda
                   where cdc.enterprise_no=cda.enterprise_no
                     and cdc.enterprise_no=strEnterPriseNo
                     and cdc.warehouse_no = cda.warehouse_no
                     and cdc.ware_no = cda.ware_no
                     and cdc.area_no = cda.area_no
    /*                 and not exists
                   (select 'x'
                            from stock_content cc
                           where cc.warehouse_no = cdc.warehouse_no
                             and cc.cell_no = cdc.cell_no
                             and (cc.qty > 0 or cc.instock_qty > 0))*/
                     and cdc.warehouse_no = strWareHouseNo
                     and cdc.cell_status = '0'
                     and cdc.check_status = '0'
                     and cda.Area_Attribute = '0' --作业区
                     and cda.area_usetype = v_AreaUseType
    /*                 and cda.area_quality >= v_QualityBegin
                     and cda.area_quality <= v_QualityEnd*/
                   order by cdc.cell_no) t
           where rownum <= 1;
        exception when no_data_found then
            strCellNo := 'N';
            strOutMsg := 'N|[E24216]';
            return;
        end;
    end if;

    --加锁
    update cdef_defcell cdc
       set cdc.cell_status = cdc.cell_status
     where cdc.enterprise_no=strEnterPriseNo and cdc.cell_no = strCellNo
       and cdc.warehouse_no = strWareHouseNo;
    strOutMsg := 'Y|';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_RecedeLocate;

 --查找储位
  /********************************************************************************************
  创建人：luozhiling
  创建时间：2015.7.18
  功能说明：定位到报损库
  **********************************************************************************************/
  procedure p_BadGoodLocate(strEnterPriseNo in ridata_instock_direct.enterprise_no%type,
                           strWareHouseNo in ridata_instock_direct.warehouse_no%type,
                           strArticleNo   in stock_article_info.article_no%type,
                           strCellNo      out ridata_instock_direct.dest_cell_no%type,
                           strOutMsg      out varchar2) is
    v_strDestCellNo   cdef_defcell.cell_no%type;
  begin
    strOutMsg := 'N|[p_BadGoodLocate]';

     begin
           select cell_no
             into v_strDestCellNo
              from (select cdc.cell_no
                      from cdef_defcell cdc, cdef_defarea cda
                     where cdc.enterprise_no=cda.enterprise_no and
                       cdc.enterprise_no=strEnterPriseNo and cdc.warehouse_no = cda.warehouse_no
                       and cdc.ware_no = cda.ware_no
                       and cdc.area_no = cda.area_no
                       and cda.area_usetype='2'
                       and cdc.warehouse_no = strWareHouseNo
                       and cdc.cell_status = '0'
                       and cdc.check_status = '0'
                       and cda.Area_Attribute = '0'
                       and cda.attribute_type='0'
                       and rownum=1);

     exception when no_data_found then
        strOutMsg:='N|[EEEEEE]';--找不到过季品储位
     end;

     strCellNo:=v_strDestCellNo;
    strOutMsg := 'Y|';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_BadGoodLocate;

end PKLG_RILOCATE;

/

