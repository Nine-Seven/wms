create view V_ARTICLE_PACK_VOLUMN_WEIGHT as
select bda.enterprise_no,bwp.warehouse_no,
       bda.owner_no,
       bda.owner_article_no,
       bda.article_no,
       bda.article_name,
       nvl(bdp.packing_qty, 1) packing_qty,
       bda.unit,
       nvl(nvl(bwp.packing_unit,bdp.packing_unit), bda.unit) packing_unit,
       nvl(bdp.spec, bda.spec) spec,
       bda.barcode,
       nvl(nvl(bwp.pal_base_qbox,bdp.pal_base_qbox), 999) pal_base_qbox,
       nvl(nvl(bwp.pal_height_qbox,bdp.pal_height_qbox), 999) pal_height_qbox,
       nvl(nvl(bwp.qpalette,bdp.QPALETTE), 999 * 999) QPALETTE,
       case
         when nvl(bdp.a_length, 0) * nvl(bdp.a_width, 0) *
              nvl(bdp.a_height, 0) = 0 then
          round(bda.unit_volumn * nvl(bdp.packing_qty, 1) / 1000000, 6)
         else
          round(bdp.a_length * bdp.a_width * bdp.a_height / 1000000, 6)
       end packing_volumn,
       case
         when nvl(bdp.packing_weight, 0) = 0 then
          bda.unit_weight * nvl(bdp.packing_qty, 1)
         else
          bdp.packing_weight
       end packing_weight
  from bdef_defarticle        bda,
       bdef_article_packing   bdp,
       BDEF_WAREHOUSE_PACKING bwp
 where bda.enterprise_no = bdp.enterprise_no(+)
   and bda.article_no = bdp.article_no(+)
   and bdp.enterprise_no = bwp.enterprise_no(+)
   and bdp.article_no = bwp.article_no(+)
   and bdp.packing_qty = bwp.packing_qty(+)

/

