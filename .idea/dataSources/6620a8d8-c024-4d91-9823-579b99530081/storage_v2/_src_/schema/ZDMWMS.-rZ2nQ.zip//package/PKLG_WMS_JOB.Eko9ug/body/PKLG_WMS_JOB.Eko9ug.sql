create package body        PKLG_WMS_JOB is

/*************************************************************************************************************
--后台管理调用存储过程程序
--根据后台配置表（状态为0正常）去循环调用存储过程
*************************************************************************************************************/

procedure p_wmsJobConfig(strOutMsg  out varchar2) is
    begin
    strOutMsg    := 'N|[P_PrintLabel]';
    --锁表
    update wms_job_config t set t.execute_status=t.execute_status;

    for job in (select t.* from wms_job_config t where t.execute_status=0) loop
      --调用存储过程
      --job.proc_name(job.enterprise_no,job.warehouse_no,job.owner_no);
      null;

    end loop;


    strOutMsg    := 'Y|';
end p_wmsJobConfig;



end PKLG_WMS_JOB;

/

