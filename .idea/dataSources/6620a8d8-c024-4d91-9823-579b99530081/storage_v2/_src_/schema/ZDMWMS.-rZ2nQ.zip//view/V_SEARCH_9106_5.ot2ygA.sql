create view V_SEARCH_9106_5 as
select iim.enterprise_no ,iim.WAREHOUSE_NO,iim.OWNER_NO,iim.po_type potypeText,iim.import_no,
iim.po_no,iim.supplier_no,bs.supplier_name,iim.REQUEST_DATE,iim.end_date,iim.status statusText,
iid.article_no,bda.article_name,bag.group_name,iia.cust_no,cust_name,iia.po_no allot_po_no,
nvl(iia.po_qty,0) po_qty,nvl(iia.allot_qty,0) allot_qty,trunc(iim.rgst_date) rgst_date,bda.barcode,trunc(iia.updt_date) updt_date from
idata_import_m iim ,idata_import_d iid ,bdef_defsupplier bs,bdef_defarticle bda,
bdef_article_group bag,idata_import_allot iia,bdef_defcust cu
where iim.enterprise_no=iid.enterprise_no and iim.warehouse_no=iid.warehouse_no
 and iim.owner_no=iid.owner_no and iim.import_no=iid.import_no
 and iim.enterprise_no=bs.enterprise_no and iim.owner_no=bs.owner_no and iim.supplier_no=bs.supplier_no
 and iid.enterprise_no=bda.enterprise_no and iid.owner_no=bda.owner_no
 and iid.article_no=bda.article_no
 and bda.enterprise_no=bag.enterprise_no and bda.owner_no=bag.owner_no and bda.group_no=bag.group_no
 and iid.enterprise_no=iia.enterprise_no(+) and iid.warehouse_no=iia.warehouse_no(+)
 and iid.owner_no=iia.owner_no(+) and iid.import_no=iia.import_no(+) and iid.article_no=iia.article_no(+)
 and iia.enterprise_no=cu.enterprise_no(+) and iia.owner_no=cu.owner_no(+) and iia.cust_no=cu.cust_no(+)
 order by iim.enterprise_no ,iim.WAREHOUSE_NO,iim.OWNER_NO,iim.import_no,iia.cust_no,iia.po_no,iia.article_no


/

