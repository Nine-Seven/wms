create package body        PKLG_Tasklabel is
--出货标签
      -----------------------------------------------------------------------------------------------------------出 货  发 单
  --------------------------------------------------------出货发单写标签入口 begin-------------------------------------------------------------
  /*****************************************************************************************
     功能：写出货流水标签入口
  *****************************************************************************************/
  procedure P_O_WriteLabelSerial(strEnterPriseNo    in stock_label_m.enterprise_no%type,
                                 strwarehouse_no    in stock_label_m.warehouse_no%type, --仓别
                                 strOwnerNo         in odata_outstock_m.owner_no%type,
                                 strExpType         in odata_exp_m.exp_type%type,
                                 strOutStockNo      in odata_outstock_m.outstock_no%type, --下架单号
                                 strOperateType     in odata_outstock_m.operate_type%type,
                                 strSourceType      in odata_outstock_m.source_type%type,
                                 strPickType        in odata_outstock_m.pick_type%type,
                                 strTaskType        in odata_outstock_m.task_type%type,
                                 strPrintType       in odata_outstock_m.print_type%type,
                                 strOutstockType    in odata_outstock_m.outstock_type%type,
                                 strUserID          in stock_label_m.updt_name%type, --员工ID
                                 strOutMsg          out varchar2) --返回值
  is
  begin
    strOutMsg := 'N|[P_O_WriteLabelSerial]';

    ----------------出货 P 型流水标签-----------------
    if(strOperateType='P') then
       P_O_WriteLabelSerial_P(strEnterPriseNo,strwarehouse_no,strExpType,strOwnerNo,
                                    strOutStockNo,strOperateType,strPickType,strTaskType,strOutstockType,
                                    strSourceType,strPrintType,
                                    strUserID,
                                    strOutMsg); --返回值
       if  instr(strOutMsg,'N',1,1) = 1 then
           return;
       end if;
    end if;
    ----------------出货 C 型流水标签-----------------
    if(strOperateType='C') then
       P_O_WriteLabelSerial_C(strEnterPriseNo,strwarehouse_no,strExpType,strOwnerNo,
                                  strOutStockNo,/*strOperateType,*/strPickType,/*strTaskType,strOutstockType,
                                  strSourceType,*/strPrintType,
                                  strUserID,strOutMsg); --返回值
       if  instr(strOutMsg,'N',1,1) = 1 then
           return;
       end if;
    end if;
    ----------------出货 B 型标签----------------- B型不区分流水标签和任务标签，写标签和打印格式一样
    if(strOperateType='B') then

      ----------------------------按容器写标签——B 型  出货，----------------------------

      pkOBJ_label_odata.P_O_WriteLabelContainerNo_B(strEnterPriseNo,strwarehouse_no,strOwnerNo,
                        strExpType,strOutStockNo,strOperateType,strSourceType,strPickType,
                        strPrintType,strUserID,strOutMsg);
      if  instr(strOutMsg,'N',1,1) = 1 then
          return;
      end if;
    end if;
    ----------------出货 D 型流水标签-----------------
    if(strOperateType='D') then

        pkOBJ_label_odata.P_O_WriteLabelContainerNo_D(strEnterPriseNo,strwarehouse_no,strOwnerNo,
                            strExpType,strOutStockNo,strOperateType,strSourceType,strPickType,
                            strPrintType,strUserID,strOutMsg); --返回值
        if  instr(strOutMsg,'N',1,1) = 1 then
               return;
        end if;
    end if;
    ----------------出货 M 型流水标签-----------------
    if(strOperateType='M') then

       P_O_WriteLabelSerial_M(strEnterPriseNo,strwarehouse_no,strExpType,strOwnerNo,
                                  strOutStockNo,strOperateType,strPickType,strTaskType,strOutstockType,
                                  strSourceType,strPrintType,
                                  strUserID,strOutMsg); --返回值
       if  instr(strOutMsg,'N',1,1) = 1 then
           return;
       end if;
    end if;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_WriteLabelSerial;

  /*****************************************************************************************
     功能：写补货流水标签入口
  *****************************************************************************************/
  procedure P_H_WriteLabelSerial(strEnterPriseNo      in stock_label_m.enterprise_no%type,
                                 strwarehouse_no      in stock_label_m.warehouse_no%type, --仓别
                                 strOwnerNo           in odata_outstock_m.owner_no%type,
                                 strOutStockNo        in odata_outstock_m.outstock_no%type, --下架单号
                                 strOperateType       in odata_outstock_m.operate_type%type,
                                 strSourceType        in odata_outstock_m.source_type%type,
                                 strPickType          in odata_outstock_m.pick_type%type,
                                 strTaskType          in odata_outstock_m.task_type%type,
                                 strPrintType         in odata_outstock_m.print_type%type,
                                 strOutstockType      in odata_outstock_m.outstock_type%type,
                                 strUserID            in stock_label_m.updt_name%type, --员工ID
                                 strOutMsg            out varchar2) --返回值
  is
  begin
    strOutMsg := 'N|[P_H_WriteLabelSerial]';


    ----------------补货 C 型流水标签-----------------
    if(strOperateType='C') then


       P_H_WriteLabelSerial_C(strEnterPriseNo,strwarehouse_no, strOwnerNo,
                                    strOutStockNo,strOperateType,strPickType,strSourceType,strTaskType,strOutstockType,
                                    strPrintType,strUserID,strOutMsg); --返回值
       if  instr(strOutMsg,'N',1,1) = 1 then
           return;
       end if;
    end if;
    ----------------补货 B 型流水标签-----------------
    if(strOperateType='B') then

       P_H_WriteLabelSerial_B(strEnterPriseNo,strwarehouse_no, strOwnerNo,
                                    strOutStockNo,strOperateType,strPickType,strSourceType,strTaskType,strOutstockType,
                                    strPrintType,strUserID,strOutMsg); --返回值
       if  instr(strOutMsg,'N',1,1) = 1 then
           return;
       end if;
    end if;
    ----------------补货 M 型流水标签-----------------
    if(strOperateType='M') then

       P_H_WriteLabelSerial_M(strEnterPriseNo,strwarehouse_no,strOwnerNo,
                                  strOutStockNo,strOperateType,strPickType,strSourceType,strTaskType,strOutstockType,
                                  strPrintType,strUserID,strOutMsg); --返回值
       if  instr(strOutMsg,'N',1,1) = 1 then
           return;
       end if;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_H_WriteLabelSerial;

  /*****************************************************************************************
     功能：写出货任务标签入口
     新增MIX(混合类型)任务标签 huangb20160625
  *****************************************************************************************/
  procedure P_O_WriteLabelTask(strEnterPriseNo    in stock_label_m.enterprise_no%type,
                                 strwarehouse_no    in stock_label_m.warehouse_no%type, --仓别
                                 strOwnerNo         in odata_outstock_m.owner_no%type,
                                 strExpType         in odata_exp_m.exp_type%type,
                                 strOutStockNo      in odata_outstock_m.outstock_no%type, --下架单号
                                 strOperateType     in odata_outstock_m.operate_type%type,
                                 strSourceType      in odata_outstock_m.source_type%type,
                                 strPickType        in odata_outstock_m.pick_type%type,
                                 strTaskType        in odata_outstock_m.task_type%type,
                                 strPrintType       in odata_outstock_m.print_type%type,
                                 strOutstockType    in odata_outstock_m.outstock_type%type,
                                 strUserID          in stock_label_m.updt_name%type, --员工ID
                                 strOutMsg          out varchar2) --返回值
  is
  begin
    strOutMsg := 'N|[P_O_WriteLabelTask]';

    ----------------出货 P 型任务标签-----------------
    if(strOperateType='P') then

       pkOBJ_label_odata.P_O_WriteLabelTask_PCM(strEnterPriseNo,strwarehouse_no,strOwnerNo,strExpType,
                                  strOutStockNo,strOperateType,strSourceType,strPickType,strPrintType,
                                  strUserID,
                                  strOutMsg); --返回值
       if  instr(strOutMsg,'N',1,1) = 1 then
           return;
       end if;
    end if;
    ----------------出货 B 型标签----------------- B型不区分流水标签和任务标签，写标签和打印格式一样
    if(strOperateType='B') then

      ----------------------------按容器写标签——B 型  出货，----------------------------
      pkOBJ_label_odata.P_O_WriteLabelContainerNo_B(strEnterPriseNo,strwarehouse_no,strOwnerNo,
                        strExpType,strOutStockNo, strOperateType,strSourceType,strPickType,strPrintType,strUserID,strOutMsg);
      if  instr(strOutMsg,'N',1,1) = 1 then
          return;
      end if;

    end if;
    ----------------出货 C 型任务标签-----------------
    if(strOperateType='C') then

       P_O_WriteLabelTask_C(strEnterPriseNo,strwarehouse_no,strExpType,strOwnerNo,
                                  strOutStockNo,strOperateType,strPickType,strTaskType,
                                  strOutstockType,strSourceType,strPrintType,
                                  strUserID,
                                  strOutMsg); --返回值
       if  instr(strOutMsg,'N',1,1) = 1 then
           return;
       end if;
    end if;

    ----------------出货 D 型任务标签 huangb20160625-----------------
    if(strOperateType='D') then

       P_O_WriteLabelTask_D(strEnterPriseNo,strwarehouse_no,strExpType,strOwnerNo,
                            strOutStockNo,strOperateType,strPickType,strTaskType,
                            strOutstockType,strSourceType,strPrintType,
                            strUserID,
                            strOutMsg);
       if  instr(strOutMsg,'N',1,1) = 1 then
           return;
       end if;
    end if;

    ----------------出货 M 型任务标签-----------------
    if(strOperateType='M') then

       P_O_WriteLabelTask_M(strEnterPriseNo,strwarehouse_no,strExpType,strOwnerNo,
                                  strOutStockNo,strOperateType,strPickType,strTaskType,
                                  strOutstockType,strSourceType,strPrintType,
                                  strUserID,
                                  strOutMsg);
       if  instr(strOutMsg,'N',1,1) = 1 then
           return;
       end if;
    end if;

    ----------------出货 MIX 型任务标签 huangb20160625-----------------
    if(strOperateType='MIX') then

       P_O_WriteLabelTask_MIX(strEnterPriseNo,strwarehouse_no,strExpType,strOwnerNo,
                                  strOutStockNo,strOperateType,strPickType,strTaskType,
                                  strOutstockType,strSourceType,strPrintType,
                                  strUserID,
                                  strOutMsg);
       if  instr(strOutMsg,'N',1,1) = 1 then
           return;
       end if;
    end if;

    /*----------------出货 D 型任务标签 huangb20160625-----------------
    if(strOperateType='D') then

       P_O_WriteLabelTask_C(strEnterPriseNo,strwarehouse_no,strExpType,strOwnerNo,
                                  strOutStockNo,strOperateType,strPickType,strTaskType,
                                  strOutstockType,strSourceType,strPrintType,
                                  strUserID,
                                  strOutMsg); --返回值
       if  instr(strOutMsg,'N',1,1) = 1 then
           return;
       end if;
    end if;*/

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_WriteLabelTask;

  /*****************************************************************************************
     功能：写补货任务标签入口
  *****************************************************************************************/
  procedure P_H_WriteLabelTask(strEnterPriseNo      in stock_label_m.enterprise_no%type,
                               strwarehouse_no      in stock_label_m.warehouse_no%type, --仓别
                               strOwnerNo           in odata_outstock_m.owner_no%type,
                               strOutStockNo        in odata_outstock_m.outstock_no%type, --下架单号
                               strOperateType       in odata_outstock_m.operate_type%type,
                               strSourceType        in odata_outstock_m.source_type%type,
                               strPickType          in odata_outstock_m.pick_type%type,
                               strTaskType          in odata_outstock_m.task_type%type,
                               strPrintType         in odata_outstock_m.print_type%type,
                               strOutstockType      in odata_outstock_m.outstock_type%type,
                               strUserID            in stock_label_m.updt_name%type, --员工ID
                               strOutMsg            out varchar2) --返回值
  is
  begin
    strOutMsg := 'N|[P_H_WriteLabelTask]';

    ----------------补货 C 型任务标签-----------------
    if(strOperateType='C') then

       P_H_WriteLabelTask_C(strEnterPriseNo,strwarehouse_no,strOwnerNo,
                                  strOutStockNo,strOperateType,strPickType,strSourceType,strTaskType,
                                  strOutstockType,strPrintType,
                                  strUserID,
                                  strOutMsg); --返回值
       if  instr(strOutMsg,'N',1,1) = 1 then
           return;
       end if;
    end if;
    ----------------补货 B 型任务标签-----------------
    if(strOperateType='B') then
       P_H_WriteLabelTask_B(strEnterPriseNo,strwarehouse_no,strOwnerNo,
                                  strOutStockNo,strOperateType,strPickType,strSourceType,strTaskType,
                                  strOutstockType,strPrintType,
                                  strUserID,
                                  strOutMsg); --返回值
       if  instr(strOutMsg,'N',1,1) = 1 then
           return;
       end if;
    end if;
    ----------------补货 M 型任务标签-----------------
    if(strOperateType='M') then
       P_H_WriteLabelTask_M(strEnterPriseNo,strwarehouse_no,strOwnerNo,
                                  strOutStockNo,strOperateType,strPickType,strSourceType,strTaskType,
                                  strOutstockType,strPrintType,
                                  strUserID,
                                  strOutMsg); --返回值
       if  instr(strOutMsg,'N',1,1) = 1 then
           return;
       end if;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_H_WriteLabelTask;
  --------------------------------------------------------出货发单写标签入口 end-------------------------------------------------------------


  --------------------------------------------------------出货流水标签 begin-------------------------------------------------------------
  /*****************************************************************************************
     功能：写出货流水标签——P 型
  *****************************************************************************************/
  procedure P_O_WriteLabelSerial_P(strEnterPriseNo      in stock_label_m.enterprise_no%type,
                                   strwarehouse_no      in stock_label_m.warehouse_no%type, --仓别
                                   strExpType           in odata_exp_m.exp_type%type,
                                   strOwnerNo           in odata_outstock_m.owner_no%type,
                                   strOutStockNo       in odata_outstock_m.outstock_no%type, --下架单号
                                   strOperateType      in odata_outstock_m.operate_type%type,
                                   strPickType         in odata_outstock_m.pick_type%type,
                                   strTaskType         in odata_outstock_m.task_type%type,
                                   strOutstockType     in odata_outstock_m.outstock_type%type,
                                   strSourceType       in odata_outstock_m.source_type%type,
                                   strPrintType        in odata_outstock_m.print_type%type,
                                   strUserID           in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg           out varchar2) --返回值
  is
   strProduceLableTypeC  varchar2(500):='2'; --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)
   nProduceLableTypeC  varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)
  begin
    strOutMsg := 'N|[P_O_WriteLabelSerial_P]';
     begin
       PKLG_WMS_BASE.p_GetBasePara(strEnterPriseNo,strwarehouse_no,strOwnerNo,
         'TaskOmProduceLableTypeC','O','O_TASK',strProduceLableTypeC,nProduceLableTypeC,strOutMsg);
       if  instr(strOutMsg,'N',1,1) = 1 then
           strOutMsg := 'N|[E00570]';
           return;
       end if;
     exception
       when others then
         strOutMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
         return;
     end;
     if strSourceType = '1' then
       ----------------------------写流水标签——P  型 出货 -----------------------------
       if strProduceLableTypeC = '1' then
          --------------------(一箱一标签)--------------------
           pkOBJ_label_odata.P_O_WriteLabelSerial_PT(strEnterPriseNo,strwarehouse_no,strOwnerNo,
                                    strOutStockNo,strOperateType,strPickType,strTaskType,strOutstockType,
                                    strUserID,
                                    strOutMsg); --返回值
       else
         --------------------(按容器写标签)--------------------

          pkOBJ_label_odata.P_O_WriteLabelContainerNo_P(strEnterPriseNo,strwarehouse_no,strOwnerNo,strExpType,
                                    strOutStockNo,strOperateType,strSourceType,strPickType,strPrintType,
                                    strUserID,strOutMsg); --返回值
       end if;
     elsif strSourceType = '3' then
       ----------------------------写流水标签——P  型 出货 (普通客户别) 按 容器 写-----------------------------
          pkOBJ_label_odata.P_O_WriteLabelContainerNo_P(strEnterPriseNo,strwarehouse_no,strOwnerNo,strExpType,
                                    strOutStockNo,strOperateType,strSourceType,strPickType,strPrintType,
                                    strUserID,strOutMsg); --返回值
     elsif strSourceType = '5' then
     ----------------------------写流水标签——P  型 出货 (外贸客户别 ) -----------------------------

       pkOBJ_label_odata.P_O_WriteLabelSerial_Cust(strEnterPriseNo,strwarehouse_no,strOwnerNo,
                                    strOutStockNo,strOperateType,strPickType,strTaskType,strOutstockType,
                                    strUserID,
                                    strOutMsg); --返回值
     end if;
     if  instr(strOutMsg,'N',1,1) = 1 then
           return;
     end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_WriteLabelSerial_P;

  /*****************************************************************************************
     功能：写出货流水标签——C 型
  *****************************************************************************************/
  procedure P_O_WriteLabelSerial_C(strEnterPriseNo      in stock_label_m.enterprise_no%type,
                                   strwarehouse_no      in stock_label_m.warehouse_no%type, --仓别
                                   strExpType           in odata_exp_m.exp_type%type,
                                   strOwnerNo           in odata_outstock_m.owner_no%type,
                                   strOutStockNo       in odata_outstock_m.outstock_no%type, --下架单号
                                   strPickType         in odata_outstock_m.pick_type%type,
                                   strPrintType        in odata_outstock_m.print_type%type,
                                   strUserID           in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg           out varchar2) --返回值
  is
    strSorterFlag varchar2(1);--是否可上分拣标示

    strConversionOperateP varchar2(500):='0'; --是否允许C 、M 转 P ( 0 不允许 ，1 允许)
    strProduceLableTypeC  varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)

    nConversionOperateP varchar2(500); --是否允许C 、M 转 P ( 0 不允许 ，1 允许)
    nProduceLableTypeC  varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)

    strWriterLabel varchar2(1);--是否写 C 型流水标签
  begin
    strOutMsg := 'N|[P_O_WriteLabelSerial_C]';
    strWriterLabel := '0';--默认不写
    --------------------------------------
    select nvl(bap.sorter_flag,0)
      into strSorterFlag
      from odata_outstock_d ood
     left join bdef_article_packing bap
        on ood.article_no = bap.article_no
       and ood.packing_qty = bap.packing_qty
       and ood.enterprise_no =bap.enterprise_no
     where ood.warehouse_no = strwarehouse_no
       and ood.enterprise_no = strEnterPriseNo
       and ood.outstock_no = strOutStockNo
       and rownum <= 1;

/*      pklg_wms_base.p_GetBasePara(strEnterPriseNo,strwarehouse_no,strOwnerNo,'TaskOmConversionOperateP',
                                  'O','O_TASK',strConversionOperateP,nConversionOperateP,strOutMsg);

      if  instr(strOutMsg,'N',1,1) = 1 then
       strOutMsg := 'N|[读参数TaskOmConversionOperateP失败]';
       return;
     end if;*/

     pklg_wms_base.p_GetBasePara(strEnterPriseNo,strwarehouse_no,strOwnerNo,'TaskOmProduceLableTypeC',
     'O','O_TASK',strProduceLableTypeC,nProduceLableTypeC,strOutMsg);
     if  instr(strOutMsg,'N',1,1) = 1 then
       strOutMsg := 'N|[E22105]';
       return;
     end if;

    if strProduceLableTypeC= '2' then
      if strSorterFlag = '0' then--不可上分拣
/*        if strConversionOperateP = '0' then --分拨的出 分播标签  --  摘果的 按单出一张标签*/
            strWriterLabel := '1';
/*        end if;*/
      end if;
    end if;

    if strWriterLabel = '0' then
      ----------------------------写流水标签——C型  出货-----------------------------
      pkOBJ_label_odata.P_O_WriteLabelSerial_CT(strEnterPriseNo,strwarehouse_no,strOwnerNo,
                                    strOutStockNo,strSorterFlag,
                                    strUserID,strOutMsg);
      if  instr(strOutMsg,'N',1,1) = 1 then
          return;
      end if;

    else
      --------------不可上分拣  不允许 转 P 且  分播  写任务标签  大P 标签 ---------------

      pkOBJ_label_odata.P_O_WriteLabelTask_CM_S(strEnterPriseNo,strwarehouse_no, strOwnerNo,strExpType,
                                            strOutStockNo, strPickType,strPrintType,
                                            strSorterFlag, --是否可上分拣
                                            strUserID, --员工ID
                                            strOutMsg); --返回值
    end if;
    if  instr(strOutMsg,'N',1,1) = 1 then
        return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_WriteLabelSerial_C;

  /*****************************************************************************************
     功能：写出货流水标签——M 型
  *****************************************************************************************/

  procedure P_O_WriteLabelSerial_M(strEnterPriseNo      in stock_label_m.enterprise_no%type,
                                   strwarehouse_no      in stock_label_m.warehouse_no%type, --仓别
                                   strExpType           in odata_exp_m.exp_type%type,
                                   strOwnerNo           in odata_outstock_m.owner_no%type,
                                   strOutStockNo       in odata_outstock_m.outstock_no%type, --下架单号
                                   strOperateType      in odata_outstock_m.operate_type%type,
                                   strPickType         in odata_outstock_m.pick_type%type,
                                   strTaskType         in odata_outstock_m.task_type%type,
                                   strOutstockType     in odata_outstock_m.outstock_type%type,
                                   strSourceType       in odata_outstock_m.source_type%type,
                                   strPrintType        in odata_outstock_m.print_type%type,
                                   strUserID           in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg           out varchar2) --返回值
  is
    strSorterFlag varchar2(1);--是否可上分拣标示
    strConversionOperateP varchar2(500); --是否允许C 、M 转 P ( 0 不允许 ，1 允许)
    strProduceLableTypeC  varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)

    nConversionOperateP varchar2(500); --是否允许C 、M 转 P ( 0 不允许 ，1 允许)
    nProduceLableTypeC  varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)

    strWriterLabel varchar2(1);--是否写 C 型流水标签
  begin
    strOutMsg := 'N|[P_O_WriteLabelSerial_M]';

    strWriterLabel := '0';--默认不写
    --------------------------------------

    select nvl(bap.sorter_flag,0)
      into strSorterFlag
      from odata_outstock_d ood
     left join bdef_article_packing bap
        on ood.article_no = bap.article_no
       and ood.packing_qty = bap.packing_qty
       and ood.enterprise_no = bap.enterprise_no
     where ood.warehouse_no = strwarehouse_no
       and ood.enterprise_no = strEnterPriseNo
       and ood.outstock_no = strOutStockNo
       and rownum <= 1;

    pklg_wms_base.p_GetBasePara(strEnterPriseNo,strwarehouse_no,strOwnerNo,'TaskOmConversionOperateP','O','O_TASK',strConversionOperateP,nConversionOperateP,strOutMsg);

    if  instr(strOutMsg,'N',1,1) = 1 then
      strOutMsg := 'N|[E22106]';
    end if;

    pklg_wms_base.p_GetBasePara(strEnterPriseNo,strwarehouse_no,strOwnerNo,'TaskOmProduceLableTypeC','O','O_TASK',strProduceLableTypeC,nProduceLableTypeC,strOutMsg);
    if  instr(strOutMsg,'N',1,1) = 1 then
     strOutMsg := 'N|[E22105]';
    end if;

    if strProduceLableTypeC= '2' then
      if strSorterFlag = '0' then
        if strConversionOperateP = '0' then
          strWriterLabel := '1';
        end if;
      end if;
    end if;
    if strWriterLabel = '0' then
    ----------------------------写流水标签——M 型  出货 ----------------------------

      pkOBJ_label_odata.P_O_WriteLabelSerial_MT(strEnterPriseNo,strwarehouse_no,strOwnerNo,
                                    strOutStockNo,strOperateType,strPickType,strTaskType,strOutstockType,
                                    strUserID, --员工ID
                                    strOutMsg); --返回值
    else
      --------------不可上分拣  不允许 转 P 且  分播  写任务标签  大P 标签 ---------------
      pkOBJ_label_odata.P_O_WriteLabelTask_CM_S(strEnterPriseNo,strwarehouse_no, strOwnerNo,strExpType,
                                            strOutStockNo, strPickType,strPrintType,
                                            strSorterFlag, --是否可上分拣
                                            strUserID, --员工ID
                                            strOutMsg); --返回值
    end if;
    if  instr(strOutMsg,'N',1,1) = 1 then
        return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_WriteLabelSerial_M;

  --------------------------------------------------------出货流水标签 end---------------------------------------------------------------

  /*****************************************************************************************
     功能：写补货流水标签——C 型

  *****************************************************************************************/
  procedure P_H_WriteLabelSerial_C(strEnterPriseNo       in stock_label_m.enterprise_no%type,
                                   strwarehouse_no       in stock_label_m.warehouse_no%type, --仓别
                                   strOwnerNo            in odata_outstock_m.owner_no%type,
                                   strOutStockNo         in odata_outstock_m.outstock_no%type, --下架单号
                                   strOperateType        in odata_outstock_m.operate_type%type,
                                   strPickType           in odata_outstock_m.pick_type%type,
                                   strSourceType         in odata_outstock_m.source_type%type,--来源类型
                                   strTaskType           in odata_outstock_m.task_type%type,
                                   strOutstockType       in odata_outstock_m.outstock_type%type,
                                   strPrintType          in odata_outstock_m.print_type%type,
                                   strUserID             in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg             out varchar2) --返回值
  is
  begin
    strOutMsg := 'N|[P_H_WriteLabelSerial_C]';
    ----------------写流水标签——C （补货） (可出板标签 和 C 箱标签)  -------------------

    pkOBJ_label_odata.P_H_WriteLabelSerial_CT(strEnterPriseNo,strwarehouse_no, strOwnerNo,
                                    strOutStockNo,strOperateType,strPickType,strTaskType,strOutstockType,strPrintType,
                                    strUserID,strOutMsg); --返回值
    if  instr(strOutMsg,'N',1,1) = 1 then
           return;
     end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_H_WriteLabelSerial_C;

  /*****************************************************************************************
     功能：写补货流水标签——B 型

  *****************************************************************************************/
  procedure P_H_WriteLabelSerial_B(strEnterPriseNo       in stock_label_m.enterprise_no%type,
                                   strwarehouse_no       in stock_label_m.warehouse_no%type, --仓别
                                   strOwnerNo            in odata_outstock_m.owner_no%type,
                                   strOutStockNo         in odata_outstock_m.outstock_no%type, --下架单号
                                   strOperateType        in odata_outstock_m.operate_type%type,
                                   strPickType           in odata_outstock_m.pick_type%type,
                                   strSourceType         in odata_outstock_m.source_type%type,--来源类型
                                   strTaskType           in odata_outstock_m.task_type%type,
                                   strOutstockType       in odata_outstock_m.outstock_type%type,
                                   strPrintType          in odata_outstock_m.print_type%type,
                                   strUserID             in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg             out varchar2) --返回值
  is
  begin
    strOutMsg := 'N|[P_H_WriteLabelSerial_B]';
    ----------------写流水标签——B 型  补货 -------------------

    pkOBJ_label_odata.P_H_WriteLabelSerial_BT(strEnterPriseNo,strwarehouse_no, strOwnerNo,
                                    strOutStockNo,strOperateType,strPickType,strTaskType,strOutstockType,
                                    strUserID,strOutMsg);
    if  instr(strOutMsg,'N',1,1) = 1 then
           return;
     end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_H_WriteLabelSerial_B;

  /*****************************************************************************************
     功能：写补货流水标签——M 型  判断参数 CreateLabelByOutstockNo  （ 0 一单多标签  1 一单一标签） 一单一标签 则按容器写标签

  *****************************************************************************************/
  procedure P_H_WriteLabelSerial_M(strEnterPriseNo       in stock_label_m.enterprise_no%type,
                                   strwarehouse_no       in stock_label_m.warehouse_no%type, --仓别
                                   strOwnerNo            in odata_outstock_m.owner_no%type,
                                   strOutStockNo         in odata_outstock_m.outstock_no%type, --下架单号
                                   strOperateType        in odata_outstock_m.operate_type%type,
                                   strPickType           in odata_outstock_m.pick_type%type,
                                   strSourceType         in odata_outstock_m.source_type%type,--来源类型
                                   strTaskType           in odata_outstock_m.task_type%type,
                                   strOutstockType       in odata_outstock_m.outstock_type%type,
                                   strPrintType          in odata_outstock_m.print_type%type,
                                   strUserID             in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg             out varchar2) --返回值
  is
    strParaCreateLabelByOutstockNo varchar2(10):='0';--是否按单产生标签  0 一单多标签  1 一单一标签
    nParaCreateLabelByOutstockNo number(10);--是否按单产生标签  0 一单多标签  1 一单一标签

  begin
    strOutMsg := 'N|[P_H_WriteLabelSerial_M]';
    -----------------------获取是否按单产生标签参数 默认 无 补货设备------------------------
    pklg_wms_base.p_GetBasePara(strEnterPriseNo,strwarehouse_no,strOwnerNo,'TaskOmCreateLabelByOutstockNo',
                                'O','O_TASK',strParaCreateLabelByOutstockNo,nParaCreateLabelByOutstockNo,strOutMsg);

    if  instr(strOutMsg,'N',1,1) = 1 then
         return;
    end if;

     ------------------------------M 型 流水标签 ------------------------------
     if strParaCreateLabelByOutstockNo = '1' then
       ------------按容器写标签------------

       pkOBJ_label_odata.P_H_WriteLabelContainerNo_M(strEnterPriseNo,strwarehouse_no,strOwnerNo,
                                      strOutStockNo,strOperateType,strSourceType,strPickType,strPrintType,
                                      strUserID,strOutMsg); --返回值
      else
       ------------写 M 型流水标签--------------
       ------------------------------- M 型 补货现有的 切单规则配置 一般不会 配置成 流水标签  待需要 时  可 启用 -------------------------------
       pkOBJ_label_odata.P_H_WriteLabelSerial_CT(strEnterPriseNo,strwarehouse_no, strOwnerNo,
                                    strOutStockNo,strOperateType,strPickType,strTaskType,strOutstockType,
                                    strPrintType,strUserID, --员工ID
                                    strOutMsg); --返回值

     end if;
     if  instr(strOutMsg,'N',1,1) = 1 then
         return;
     end if;
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_H_WriteLabelSerial_M;
  --------------------------------------------------------补货流水标签 end---------------------------------------------------------------

  --------------------------------------------------------出货任务标签 begin-------------------------------------------------------------
  /*****************************************************************************************
     功能：写出货任务标签——P 型
  *****************************************************************************************/
  procedure P_O_WriteLabelTask_P(strEnterPriseNo      in stock_label_m.enterprise_no%type,
                                   strwarehouse_no      in stock_label_m.warehouse_no%type, --仓别
                                   strExpType           in odata_exp_m.exp_type%type,
                                   strOwnerNo           in odata_outstock_m.owner_no%type,
                                   strOutStockNo       in odata_outstock_m.outstock_no%type, --下架单号
                                   strOperateType      in odata_outstock_m.operate_type%type,
                                   strPickType         in odata_outstock_m.pick_type%type,
                                   strTaskType         in odata_outstock_m.task_type%type,
                                   strOutstockType     in odata_outstock_m.outstock_type%type,
                                   strSourceType       in odata_outstock_m.source_type%type,
                                   strPrintType        in odata_outstock_m.print_type%type,
                                   strUserID           in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg           out varchar) --返回值
  is
  begin
    strOutMsg := 'N|[P_O_WriteLabelTask_P]';

    ----------------按容器写标签——P 型   出货， -------------------
    pkOBJ_label_odata.P_O_WriteLabelContainerNo_P(strEnterPriseNo,strwarehouse_no,strOwnerNo,strExpType,
                              strOutStockNo,strOperateType,strSourceType,strPickType,strPrintType,
                              strUserID,strOutMsg); --返回值


    if  instr(strOutMsg,'N',1,1) = 1 then
           return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_WriteLabelTask_P;

  /*****************************************************************************************
     功能：写出货任务标签——C 型
  *****************************************************************************************/
  procedure P_O_WriteLabelTask_C(strEnterPriseNo      in stock_label_m.enterprise_no%type,
                                   strwarehouse_no      in stock_label_m.warehouse_no%type, --仓别
                                   strExpType           in odata_exp_m.exp_type%type,
                                   strOwnerNo           in odata_outstock_m.owner_no%type,
                                   strOutStockNo       in odata_outstock_m.outstock_no%type, --下架单号
                                   strOperateType      in odata_outstock_m.operate_type%type,
                                   strPickType         in odata_outstock_m.pick_type%type,
                                   strTaskType         in odata_outstock_m.task_type%type,
                                   strOutstockType     in odata_outstock_m.outstock_type%type,
                                   strSourceType       in odata_outstock_m.source_type%type,
                                   strPrintType        in odata_outstock_m.print_type%type,
                                   strUserID           in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg           out varchar) --返回值
  is
    strSorterFlag varchar2(1);--是否可上分拣标示

    --strConversionOperateP varchar2(500); --是否允许C 、M 转 P ( 0 不允许 ，1 允许)
    strProduceLableTypeC  varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)

    --nConversionOperateP varchar2(500); --是否允许C 、M 转 P ( 0 不允许 ，1 允许)
    nProduceLableTypeC  varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)

    strWriterLabel varchar2(1);--是否写 C 型流水标签
  begin
    strOutMsg := 'N|[P_O_WriteLabelTask_C]';
    strWriterLabel := '0';--默认不写
    --------------------------------------

    select nvl(bap.sorter_flag,0)
      into strSorterFlag
      from odata_outstock_d ood
     left join bdef_article_packing bap
        on ood.article_no = bap.article_no
       and ood.packing_qty = bap.packing_qty
       and ood.enterprise_no=bap.enterprise_no
     where ood.warehouse_no = strwarehouse_no and ood.enterprise_no=strEnterPriseNo
       and ood.outstock_no = strOutStockNo
       and rownum <= 1;


   begin
     pklg_wms_base.p_GetBasePara(strEnterPriseNo,strwarehouse_no,strOwnerNo,'TaskOmProduceLableTypeC','O',
                                 'O_TASK',strProduceLableTypeC,nProduceLableTypeC,strOutMsg);
     if  instr(strOutMsg,'N',1,1) = 1 then
       strOutMsg := 'N|[E22105]';
     end if;
   exception
     when others then
       strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
       return;
   end;
    if strProduceLableTypeC= '2' then
/*      if strPickType = '1' then*/
         strWriterLabel := '1';
/*      end if;*/
    end if;
    if strWriterLabel = '0' then
      pkOBJ_label_odata.P_O_WriteLabelSerial_CT(strEnterPriseNo,strwarehouse_no,strOwnerNo,
                                    strOutStockNo,strSorterFlag,
                                    strUserID,strOutMsg);
      if  instr(strOutMsg,'N',1,1) = 1 then
          return;
      end if;

    else
      --------------------写任务标签 C 型 出货---------------------

      pkOBJ_label_odata.P_O_WriteLabelTask_PCM(strEnterPriseNo,strwarehouse_no, strOwnerNo,strExpType,
                                              strOutStockNo,strOperateType,strSourceType,strPickType,strPrintType,
                                              strUserID, --员工ID
                                              strOutMsg); --返回值
    end if;
    if  instr(strOutMsg,'N',1,1) = 1 then
           return;
     end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_WriteLabelTask_C;

  /*****************************************************************************************
     功能：写出货任务标签——D型
     huangb 20160625
  *****************************************************************************************/
  procedure P_O_WriteLabelTask_D(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                 strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                 strExpType      in odata_exp_m.exp_type%type,
                                 strOwnerNo      in odata_outstock_m.owner_no%type,
                                 strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                 strOperateType  in odata_outstock_m.operate_type%type,
                                 strPickType     in odata_outstock_m.pick_type%type,
                                 strTaskType     in odata_outstock_m.task_type%type,
                                 strOutstockType in odata_outstock_m.outstock_type%type,
                                 strSourceType   in odata_outstock_m.source_type%type,
                                 strPrintType    in odata_outstock_m.print_type%type,
                                 strUserID       in stock_label_m.updt_name%type, --员工ID
                                 strOutMsg       out varchar) --返回值
  is
  begin
    strOutMsg := 'N|[P_O_WriteLabelTask_D]';
    --------------------按容器写标签——M 补货，---------------------
    pkOBJ_label_odata.P_O_WriteLabelTask_D
      (strEnterPriseNo,strwarehouse_no,strOwnerNo,strExpType,
       strOutStockNo,strOperateType,strSourceType,strPickType,
       strPrintType,strUserID,strOutMsg);
    if instr(strOutMsg,'N',1,1) = 1 then
           return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_WriteLabelTask_D;

  /*****************************************************************************************
     功能：写出货任务标签——M 型
  *****************************************************************************************/
  procedure P_O_WriteLabelTask_M(strEnterPriseNo      in stock_label_m.enterprise_no%type,
                                   strwarehouse_no      in stock_label_m.warehouse_no%type, --仓别
                                   strExpType           in odata_exp_m.exp_type%type,
                                   strOwnerNo           in odata_outstock_m.owner_no%type,
                                   strOutStockNo       in odata_outstock_m.outstock_no%type, --下架单号
                                   strOperateType      in odata_outstock_m.operate_type%type,
                                   strPickType         in odata_outstock_m.pick_type%type,
                                   strTaskType         in odata_outstock_m.task_type%type,
                                   strOutstockType     in odata_outstock_m.outstock_type%type,
                                   strSourceType       in odata_outstock_m.source_type%type,
                                   strPrintType        in odata_outstock_m.print_type%type,
                                   strUserID           in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg           out varchar) --返回值
  is
    strSorterFlag varchar2(1);--是否可上分拣标示

    strConversionOperateP varchar2(500); --是否允许C 、M 转 P ( 0 不允许 ，1 允许)
    strProduceLableTypeC  varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)

    nConversionOperateP varchar2(500); --是否允许C 、M 转 P ( 0 不允许 ，1 允许)
    nProduceLableTypeC  varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)

    strWriterLabel varchar2(1);--是否写 C 型流水标签
  begin
    strOutMsg := 'N|[P_O_WriteLabelTask_M]';

    strWriterLabel := '0';--默认不写
    --------------------------------------

    select nvl(bap.sorter_flag,0)
      into strSorterFlag
      from odata_outstock_d ood
     left join bdef_article_packing bap
        on ood.article_no = bap.article_no
       and ood.packing_qty = bap.packing_qty
       and ood.enterprise_no= bap.enterprise_no
     where ood.warehouse_no = strwarehouse_no and ood.enterprise_no=strEnterPriseNo
       and ood.outstock_no = strOutStockNo
       and rownum <= 1;

   begin
    pklg_wms_base.p_GetBasePara(strEnterPriseNo,strwarehouse_no,strOwnerNo,'TaskOmConversionOperateP','O',
                                'O_TASK',strConversionOperateP,nConversionOperateP,strOutMsg);

      if  instr(strOutMsg,'N',1,1) = 1 then
       strOutMsg := 'N|[E22106]';
     end if;
   exception
     when others then
       strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
       return;
   end;

   begin
     pklg_wms_base.p_GetBasePara(strEnterPriseNo,strwarehouse_no,strOwnerNo,'TaskOmProduceLableTypeC','O',
                                 'O_TASK',strProduceLableTypeC,nProduceLableTypeC,strOutMsg);
     if  instr(strOutMsg,'N',1,1) = 1 then
       strOutMsg := 'N|[E22105]';
     end if;
   exception
     when others then
       strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
       return;
   end;
    if strProduceLableTypeC= '2' then
      if strTaskType='1' or strTaskType='2' then
         strWriterLabel:='1';
      else if strSorterFlag = '0' then
        if strConversionOperateP = '0' then
          strWriterLabel := '1';
        end if;
      end if;
      end if;
    end if;
    if strWriterLabel = '0' then
    ----------------------------写流水标签——M 型  出货 ----------------------------
      pkOBJ_label_odata.P_O_WriteLabelSerial_MT(strEnterPriseNo,strwarehouse_no,strOwnerNo,
                                    strOutStockNo,strOperateType,strPickType,strTaskType,strOutstockType,
                                    strUserID,
                                    strOutMsg); --返回值
    else
    --------------------写任务标签 M 型 出货---------------------
       pkOBJ_label_odata.P_O_WriteLabelTask_PCM(strEnterPriseNo,strwarehouse_no,strOwnerNo,strExpType,
                                  strOutStockNo,strOperateType,strSourceType,strPickType,strPrintType,
                                  strUserID,
                                  strOutMsg);

    end if;
    if  instr(strOutMsg,'N',1,1) = 1 then
           return;
     end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_WriteLabelTask_M;

  /*****************************************************************************************
     功能：写出货任务标签——MIX型
     huangb 20160625
  *****************************************************************************************/
  procedure P_O_WriteLabelTask_MIX(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                   strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                   strExpType      in odata_exp_m.exp_type%type,
                                   strOwnerNo      in odata_outstock_m.owner_no%type,
                                   strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                   strOperateType  in odata_outstock_m.operate_type%type,
                                   strPickType     in odata_outstock_m.pick_type%type,
                                   strTaskType     in odata_outstock_m.task_type%type,
                                   strOutstockType in odata_outstock_m.outstock_type%type,
                                   strSourceType   in odata_outstock_m.source_type%type,
                                   strPrintType    in odata_outstock_m.print_type%type,
                                   strUserID       in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg       out varchar) --返回值
  is
  begin
    strOutMsg := 'N|[P_O_WriteLabelTask_MIX]';
    --------------------按容器写标签——M 补货，---------------------
    pkOBJ_label_odata.P_O_WriteLabelTask_MIX
      (strEnterPriseNo,strwarehouse_no,strOwnerNo,strExpType,
       strOutStockNo,strOperateType,strSourceType,strPickType,
       strPrintType,strUserID,strOutMsg);
    if instr(strOutMsg,'N',1,1) = 1 then
           return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_WriteLabelTask_MIX;

  --------------------------------------------------------出货任务标签 end---------------------------------------------------------------

  /*****************************************************************************************
     功能：写补货任务标签——M 型
  *****************************************************************************************/
  procedure P_H_WriteLabelTask_M(strEnterPriseNo       in stock_label_m.enterprise_no%type,
                                   strwarehouse_no       in stock_label_m.warehouse_no%type, --仓别
                                   strOwnerNo            in odata_outstock_m.owner_no%type,
                                   strOutStockNo         in odata_outstock_m.outstock_no%type, --下架单号
                                   strOperateType        in odata_outstock_m.operate_type%type,
                                   strPickType           in odata_outstock_m.pick_type%type,
                                   strSourceType         in odata_outstock_m.source_type%type,--来源类型
                                   strTaskType           in odata_outstock_m.task_type%type,
                                   strOutstockType       in odata_outstock_m.outstock_type%type,
                                   strPrintType          in odata_outstock_m.print_type%type,
                                   strUserID             in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg             out varchar2) --返回值
  is
  begin
    strOutMsg := 'N|[P_H_WriteLabelTask_M]';
    --------------------按容器写标签——M 补货，---------------------
       pkOBJ_label_odata.P_H_WriteLabelContainerNo_M(strEnterPriseNo,strwarehouse_no,strOwnerNo,
                                      strOutStockNo,strOperateType,strSourceType,strPickType,strPrintType,
                                      strUserID,strOutMsg);
    if  instr(strOutMsg,'N',1,1) = 1 then
           return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_H_WriteLabelTask_M;

  /*****************************************************************************************
     功能：写补货任务标签——B 型
  *****************************************************************************************/
  procedure P_H_WriteLabelTask_B(strEnterPriseNo       in stock_label_m.enterprise_no%type,
                                   strwarehouse_no       in stock_label_m.warehouse_no%type, --仓别
                                   strOwnerNo            in odata_outstock_m.owner_no%type,
                                   strOutStockNo         in odata_outstock_m.outstock_no%type, --下架单号
                                   strOperateType        in odata_outstock_m.operate_type%type,
                                   strPickType           in odata_outstock_m.pick_type%type,
                                   strSourceType         in odata_outstock_m.source_type%type,--来源类型
                                   strTaskType           in odata_outstock_m.task_type%type,
                                   strOutstockType       in odata_outstock_m.outstock_type%type,
                                   strPrintType          in odata_outstock_m.print_type%type,
                                   strUserID             in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg             out varchar2) --返回值
  is
    strDivideLine varchar2(1);
  begin
    strOutMsg := 'N|[P_H_WriteLabelTask_B]';
    strDivideLine := '0';
    -----检查B 型 补货 目的储区是否有输送线
    select distinct cda.divide_line_flag
      into strDivideLine
      from odata_outstock_d ood
     inner join cdef_defcell cdc
        on ood.warehouse_no = cdc.warehouse_no
        and ood.enterprise_no= cdc.enterprise_no
       and ood.d_cell_no = cdc.cell_no
     inner join cdef_defarea cda
        on cda.warehouse_no = cdc.warehouse_no
        and cda.enterprise_no= cdc.enterprise_no
       and cda.ware_no = cdc.ware_no
       and cda.area_no = cdc.area_no
     where ood.outstock_no = strOutStockNo
       and ood.warehouse_no = strwarehouse_no
       and ood.enterprise_no = strEnterPriseNo;

    if strDivideLine = '1' then
      ---有输送线   一箱一标签
    pkOBJ_label_odata.P_H_WriteLabelSerial_BT(strEnterPriseNo,strwarehouse_no, strOwnerNo,
                                    strOutStockNo,strOperateType,strPickType,strTaskType,strOutstockType,
                                    strUserID,strOutMsg); --返回值
      else
        --------------------写任务标签——B 补货，---------------------

    pkOBJ_label_odata.P_H_WriteLabelTask_BC(strEnterPriseNo,strwarehouse_no,strOwnerNo,
                            strOutStockNo,strOperateType,strPickType,strTaskType,strOutstockType,strPrintType,
                            strUserID,strOutMsg); --返回值
    end if;
    if  instr(strOutMsg,'N',1,1) = 1 then
           return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_H_WriteLabelTask_B;

  /*****************************************************************************************
     功能：写补货任务标签——C 型
  *****************************************************************************************/
  procedure P_H_WriteLabelTask_C(strEnterPriseNo       in stock_label_m.enterprise_no%type,
                                   strwarehouse_no       in stock_label_m.warehouse_no%type, --仓别
                                   strOwnerNo            in odata_outstock_m.owner_no%type,
                                   strOutStockNo         in odata_outstock_m.outstock_no%type, --下架单号
                                   strOperateType        in odata_outstock_m.operate_type%type,
                                   strPickType           in odata_outstock_m.pick_type%type,
                                   strSourceType         in odata_outstock_m.source_type%type,--来源类型
                                   strTaskType           in odata_outstock_m.task_type%type,
                                   strOutstockType       in odata_outstock_m.outstock_type%type,
                                   strPrintType          in odata_outstock_m.print_type%type,
                                   strUserID             in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg             out varchar2) --返回值
  is
  begin
    strOutMsg := 'N|[P_H_WriteLabelTask_C]';
    --------------------写任务标签——C 补货，---------------------
    pkOBJ_label_odata.P_H_WriteLabelTask_BC(strEnterPriseNo,strwarehouse_no,strOwnerNo,
                            strOutStockNo,strOperateType,strPickType,strTaskType,strOutstockType,strPrintType,
                            strUserID,strOutMsg); --返回值


    if  instr(strOutMsg,'N',1,1) = 1 then
           return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_H_WriteLabelTask_C;
end PKLG_Tasklabel;

/

