create view V_SEARCH_9107_001 as
select m.enterprise_no,m.warehouse_no,m.owner_no, m.po_no,m.recede_no,m.locate_times,
f_get_fieldtext('RODATA_RECEDE_M','RECEDE_TYPE',m.recede_type) recede_type,
     f_get_fieldtext('N','CLASS_TYPE',m.class_type) class_type,
    m.supplier_no,m.recede_date,
    d.article_no,art.ARTICLE_NAME,art.BARCODE,
    d.packing_qty,d.recede_qty,d.produce_date,d.expire_date,t.supplier_name,m.recede_remark
    from rodata_recede_m m,rodata_recede_d d,v_bdef_defarticle art,bdef_defsupplier t
    where m.enterprise_no=d.enterprise_no
    and m.warehouse_no=d.warehouse_no
    and m.owner_no=d.owner_no
    and m.recede_no=d.recede_no
    and d.article_no=art.ARTICLE_NO
    and m.enterprise_no=t.enterprise_no
    and m.supplier_no=t.supplier_no

/

