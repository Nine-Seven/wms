create view V_SEARCH_9107_002 as
select d.enterprise_no,d.warehouse_no,d.owner_no,d.outstock_no,d.source_no,
d.article_no,d.article_qty,d.real_qty,d.s_cell_no,d.s_label_no,
d.d_cell_no,d.status,d.outstock_date,d.label_no ,e.article_name,e.barcode
from (select t.enterprise_no,t.warehouse_no,t.owner_no,t.outstock_no,
   t.source_no,t.article_no,t.article_qty,t.real_qty,t.s_cell_no,
   t.s_label_no,t.d_cell_no,t.status,t.outstock_date,t.label_no
   from rodata_outstock_d t
   union
   select t.enterprise_no,t.warehouse_no,t.owner_no,t.outstock_no,
   t.source_no,t.article_no,t.article_qty,t.real_qty,t.s_cell_no,
   t.s_label_no,t.d_cell_no,t.status,t.outstock_date,t.label_no
   from rodata_outstock_dhty t)d,bdef_defarticle e
where d.enterprise_no=e.enterprise_no
and d.article_no=e.article_no order by d.outstock_no desc

/

