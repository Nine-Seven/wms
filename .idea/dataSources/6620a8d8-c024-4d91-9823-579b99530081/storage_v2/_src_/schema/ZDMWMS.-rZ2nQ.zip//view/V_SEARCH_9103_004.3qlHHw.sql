create view V_SEARCH_9103_004 as
select "ENTERPRISE_NO","WAREHOUSE_NO","OWNER_NO","DPS_CELL_NO","LABEL_NO","BATCH_NO","CUST_NO","CUST_NAME","ARTICLE_NO","PACKING_QTY","QTY","ARTICLE_NAME","BARCODE","GROUP_NO","GROUP_NAME" from (select dsl.enterprise_no,dsl.warehouse_no,cld.owner_no,dsl.dps_cell_no,
dsl.label_no,clm.batch_no,cld.cust_no,bdc.cust_name,
cld.article_no,cld.packing_qty,cld.qty,v.ARTICLE_NAME,v.BARCODE,v.GROUP_NO,v.GROUP_NAME
  from dps_stock_label dsl
  join stock_label_m clm on dsl.enterprise_no = clm.enterprise_no and dsl.warehouse_no = clm.warehouse_no and dsl.label_no = clm.label_no
  join stock_label_d cld on clm.enterprise_no = cld.enterprise_no and clm.warehouse_no = cld.warehouse_no and clm.container_no = cld.container_no
  join v_bdef_defarticle v on cld.owner_no=v.OWNER_NO and cld.article_no=v.ARTICLE_NO and v.ENTERPRISE_NO=cld.enterprise_no
   join bdef_defcust bdc on cld.owner_no=bdc.owner_no and cld.enterprise_no=bdc.enterprise_no and cld.cust_no=bdc.cust_no)c

/

