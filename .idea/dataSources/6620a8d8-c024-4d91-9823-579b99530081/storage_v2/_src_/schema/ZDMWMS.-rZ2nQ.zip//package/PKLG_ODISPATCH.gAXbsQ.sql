create PACKAGE PKLG_ODISPATCH IS

  TYPE TYPE_STU_LINE IS RECORD(
    STRLINENO ODATA_LOCATE_D.LINE_NO%TYPE,
    NCOUNT    NUMBER);

  /*****************************************************************************************
     功能：取指定出货单对应的区域（多区域返回空）
    MODIFY BY JUN 2016-06-20
  *****************************************************************************************/
  FUNCTION F_GETAREABYEXPNO(STRENTERPRISE   IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                            STRWAREHOUSE_NO IN ODATA_LOCATE_M.WAREHOUSE_NO%TYPE, --仓别
                            STROWNERNO      IN ODATA_LOCATE_M.OWNER_NO%TYPE, --货主
                            STREXPNO        IN ODATA_LOCATE_D.EXP_NO%TYPE --出货单号
                            ) RETURN VARCHAR2;
  /*****************************************************************************************
     功能：取指定出货单对应的储位（多区域返回最小的储位）
    MODIFY BY JUN 2016-08-01
  *****************************************************************************************/
  FUNCTION F_GETCELLNOBYEXPNO(STRENTERPRISE   IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                              STRWAREHOUSE_NO IN ODATA_LOCATE_M.WAREHOUSE_NO%TYPE, --仓别
                              STROWNERNO      IN ODATA_LOCATE_M.OWNER_NO%TYPE, --货主
                              STREXPNO        IN ODATA_LOCATE_D.EXP_NO%TYPE --出货单号
                              ) RETURN VARCHAR2 ;

/*****************************************************************************************
     功能：取订单所包含的所有储区信息(仓区+储区)
    MODIFY BY JUN 2016-08-15
  *****************************************************************************************/
  FUNCTION F_getAllAreaByExpNO(STRENTERPRISE   IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                              STRWAREHOUSE_NO IN ODATA_LOCATE_M.WAREHOUSE_NO%TYPE, --仓别
                              STROWNERNO      IN ODATA_LOCATE_M.OWNER_NO%TYPE, --货主
                              STREXPNO        IN ODATA_LOCATE_D.EXP_NO%TYPE --出货单号
                              ) RETURN VARCHAR2;

 /*****************************************************************************************
     功能：统计当前的单据是否包含异性品
    MODIFY BY SUN 2016-08-15
  *****************************************************************************************/
  FUNCTION F_setRuleFlagByExpNO(STRENTERPRISE   IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                              STRWAREHOUSE_NO IN ODATA_LOCATE_M.WAREHOUSE_NO%TYPE, --仓别
                              STROWNERNO      IN ODATA_LOCATE_M.OWNER_NO%TYPE, --货主
                              STREXPNO        IN ODATA_LOCATE_D.EXP_NO%TYPE --出货单号
                              )RETURN VARCHAR2;

  /*****************************************************************************************
     功能：对出货单进行集单(界面调用)
    MODIFY BY JUN 2014-05-20
  *****************************************************************************************/
  PROCEDURE P_INS_O_LOCATE_TASK(STRENTERPRISENO IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                                STRWAREHOUSENO  IN ODATA_LOCATE_M.WAREHOUSE_NO%TYPE, --仓别
                                STROWNERNO      IN ODATA_LOCATE_M.OWNER_NO%TYPE, --货主
                                STREXPTYPE      IN ODATA_LOCATE_M.EXP_TYPE%TYPE, --出货单类型
                                STRLOCATENAME   IN ODATA_LOCATE_M.LOCATE_NAME%TYPE, --集单人员
                                --DTLOCATEDATE     IN ODATA_LOCATE_M.LOCATE_DATE%TYPE,--集单时间
                                STRDIVIDEFLAG           IN ODATA_LOCATE_BATCH.C_DIVIDE_FLAG%TYPE, --1：允许分播；0：不允许分播
                                STRSENDBUF_COMPUTE_FLAG IN ODATA_LOCATE_BATCH.SENDBUF_COMPUTE_FLAG%TYPE, --是否试算月台资源，1:试算；0:不试算
                                STRSPECIFYCELL          IN ODATA_LOCATE_BATCH.SPECIFY_CELL%TYPE, --指定储位定位，默认N，表示不指定储位
                                NTASKBATCH              IN ODATA_LOCATE_BATCH.BATCH_NO%TYPE, --分布式定位，任务批次号
                                STRSOURCETYPE           IN ODATA_LOCATE_M.SOURCE_TYPE%TYPE, --分布式定位，任务批次号
                                STRDIVIDE_COMPUTE_FLAG  IN DEVICE_DIVIDE_M.DIVIDE_COMPUTE_FLAG%TYPE, --分播设备
                                STRCHECK_COMPUTE_FLAG   IN ODATA_LOCATE_BATCH.CHECK_COMPUTE_FLAG%TYPE, --复合台
                                STRORGNO                IN ODATA_EXP_M.ORG_NO%TYPE,
                                STRBATCH_RULE_ID        IN WMS_OUTWAVEPLAN_D.BATCH_RULE_ID%TYPE, --规则ID
                                STRAUTO                 NUMBER, --标记是否自动 1自动，2手动
                                STRIP                   IN VARCHAR2, --本地IP
                                --NRULE_ID          IN ODATA_LOCATE_M.RULE_ID%TYPE,
                                NTASK_ALLOTRULEID IN ODATA_LOCATE_BATCH.TASK_RULE_ID%TYPE,

                                STRWAVENO OUT ODATA_LOCATE_M.WAVE_NO%TYPE, --波次号
                                STRRESULT OUT VARCHAR2);

  /*****************************************************************************************
     功能：写执行日志
  *****************************************************************************************/
  PROCEDURE P_WRITELOG(STRSTRATEGY_ID   IN WMS_OUTWAVEPLAN_D.BATCH_STRATEGY_ID%TYPE, --策略ID
                       STRBATCH_RULE_ID IN WMS_OUTWAVEPLAN_D.BATCH_RULE_ID%TYPE, --策略序号
                       STRECECTYPE      IN TMP_LOCATEBATCH_LOG.EXECTYPE%TYPE, --类型
                       STREXECREMARK    IN TMP_LOCATEBATCH_LOG.EXECREMARK%TYPE, --说明
                       STRMESSAGE       IN TMP_LOCATEBATCH_LOG.MESSAGE%TYPE, --信息描述
                       STRWAVEID        IN TMP_LOCATEBATCH_LOG.WAVEID%TYPE, --波次流水（时间戳）
                       STRPROCNAME      IN TMP_LOCATEBATCH_LOG.PROCNAME%TYPE --执行过程名
                       );

  /*****************************************************************************************
      功能：自动集单：底层自动集单调用！
      参数为企业，仓别，货主
      注：底层自动集单不调定位！
  *****************************************************************************************/
  PROCEDURE P_AUTO_LOCATE(STRENTERPRISENO  IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                          STRWAREHOUSENO   IN ODATA_LOCATE_M.WAREHOUSE_NO%TYPE, --仓别
                          STROWNERNO       IN ODATA_LOCATE_M.OWNER_NO%TYPE, --货主
                          STRATEGY_ID      IN ODATA_LOCATE_BATCH.BATCH_STRATEGY_ID%TYPE, --指定策略 不指定传0
                          STRBATCH_RULE_ID IN ODATA_LOCATE_BATCH.BATCH_RULE_ID%TYPE, --指定规则 不指定传0
                          STRRESULT        OUT VARCHAR2);

/*****************************************************************************************
    功能：自动集单：指定出货单号集单
    Add by sunl 2016年7月27日
    注：自动定位！
*****************************************************************************************/
PROCEDURE P_AUTO_LOCATEBYEXPNO(STRENTERPRISENO IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                               STRWAREHOUSENO  IN ODATA_LOCATE_M.WAREHOUSE_NO%TYPE, --仓别
                               STROWNERNO      IN ODATA_LOCATE_M.OWNER_NO%TYPE, --货主
                               STRLOCATENAME   IN ODATA_LOCATE_M.LOCATE_NAME%TYPE, --定位人
                               STREXP_TYPE     IN ODATA_EXP_M.EXP_TYPE%TYPE, --指定出货单类型
                               STREXP_NO       IN ODATA_EXP_M.EXP_NO%TYPE, --指定出货单号
                               STRWAVENO       OUT ODATA_LOCATE_M.WAVE_NO%TYPE, --波次号
                               STRRESULT       OUT VARCHAR2) ;

  /*****************************************************************************************
      功能：自动集单：界面自动集单调用！
      注：界面自动集单要调定位！
  *****************************************************************************************/
  PROCEDURE P_FRONTAUTO_LOCATE(STRENTERPRISENO         IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                               STRWAREHOUSENO          IN ODATA_LOCATE_M.WAREHOUSE_NO%TYPE, --仓别
                               STROWNERNO              IN ODATA_LOCATE_M.OWNER_NO%TYPE, --货主
                               STREXPTYPE              IN ODATA_LOCATE_M.EXP_TYPE%TYPE, --出货单类型
                               STRLOCATENAME           IN ODATA_LOCATE_M.LOCATE_NAME%TYPE, --集单人员
                               STRDIVIDEFLAG           IN ODATA_LOCATE_BATCH.C_DIVIDE_FLAG%TYPE, --1：允许分播；0：不允许分播
                               STRSENDBUF_COMPUTE_FLAG IN ODATA_LOCATE_BATCH.SENDBUF_COMPUTE_FLAG%TYPE, --是否试算月台资源，1:试算；0:不试算
                               STRSPECIFYCELL          IN ODATA_LOCATE_BATCH.SPECIFY_CELL%TYPE, --指定储位定位，默认N，表示不指定储位
                               STRSOURCETYPE           IN ODATA_LOCATE_M.SOURCE_TYPE%TYPE, --分布式定位，任务批次号
                               STRDIVIDE_COMPUTE_FLAG  IN DEVICE_DIVIDE_M.DIVIDE_COMPUTE_FLAG%TYPE, --分播设备
                               STRCHECK_COMPUTE_FLAG   IN ODATA_LOCATE_BATCH.CHECK_COMPUTE_FLAG%TYPE, --复合台
                               STRORGNO                IN ODATA_EXP_M.ORG_NO%TYPE,
                               NTASKBATCH              IN ODATA_LOCATE_BATCH.BATCH_NO%TYPE, --分布式定位，任务批次号
                               STRATEGY_ID             IN ODATA_LOCATE_BATCH.BATCH_STRATEGY_ID%TYPE, --指定策略 不指定传0
                               STRBATCH_RULE_ID        IN ODATA_LOCATE_BATCH.BATCH_RULE_ID%TYPE, --指定规则 不指定传0
                               STRIP                   IN VARCHAR2, --本地IP
                               STRRESULT               OUT VARCHAR2);

  /*****************************************************************************************
     功能：界面自动集单入口
     ADD BY SUNL 20160627
  *****************************************************************************************/
  PROCEDURE P_AUTO_LOCATE_MAIN(STRENTERPRISENO         IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                               STRWAREHOUSENO          IN ODATA_LOCATE_M.WAREHOUSE_NO%TYPE, --仓别
                               STROWNERNO              IN ODATA_LOCATE_M.OWNER_NO%TYPE, --货主
                               STREXPTYPE              IN ODATA_LOCATE_M.EXP_TYPE%TYPE, --出货单类型
                               STRLOCATENAME           IN ODATA_LOCATE_M.LOCATE_NAME%TYPE, --集单人员
                               STRDIVIDEFLAG           IN ODATA_LOCATE_BATCH.C_DIVIDE_FLAG%TYPE, --1：允许分播；0：不允许分播
                               STRSENDBUF_COMPUTE_FLAG IN ODATA_LOCATE_BATCH.SENDBUF_COMPUTE_FLAG%TYPE, --是否试算月台资源，1:试算；0:不试算
                               STRSPECIFYCELL          IN ODATA_LOCATE_BATCH.SPECIFY_CELL%TYPE, --指定储位定位，默认N，表示不指定储位
                               STRSOURCETYPE           IN ODATA_LOCATE_M.SOURCE_TYPE%TYPE, --分布式定位，任务批次号
                               STRDIVIDE_COMPUTE_FLAG  IN DEVICE_DIVIDE_M.DIVIDE_COMPUTE_FLAG%TYPE, --分播设备
                               STRCHECK_COMPUTE_FLAG   IN ODATA_LOCATE_BATCH.CHECK_COMPUTE_FLAG%TYPE, --复合台
                               STRORGNO                IN ODATA_EXP_M.ORG_NO%TYPE,
                               STRATEGY_ID             IN ODATA_LOCATE_BATCH.BATCH_STRATEGY_ID%TYPE, --指定策略 不指定传0
                               STRBATCH_RULE_ID        IN ODATA_LOCATE_BATCH.BATCH_RULE_ID%TYPE, --指定规则 不指定传0
                               NTASKBATCH              IN ODATA_LOCATE_BATCH.BATCH_NO%TYPE, --分布式定位，任务批次号
                               STROPERATIONTYPE        IN VARCHAR2, --操作类型 1：底层自动，2：前台自动，3:前台手动
                               STRIP                   IN VARCHAR2, --本地IP
                               STRAUTOLOCATE           IN VARCHAR2, --是否自动定位 0：否，1：是
                               STRWAVENO               OUT ODATA_LOCATE_M.WAVE_NO%TYPE, --波次号
                               STRRESULT               OUT VARCHAR2);

  /*****************************************************************************************
     功能：写执行临时表
  *****************************************************************************************/
  PROCEDURE P_WRITETMP_ODATA_EXP(STRENTERPRISENO  IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                                 STRWAREHOUSENO   IN ODATA_LOCATE_M.WAREHOUSE_NO%TYPE, --仓别(前台集单需要传)
                                 STROWNERNO       IN ODATA_LOCATE_M.OWNER_NO%TYPE, --货主(前台集单需要传)
                                 STRORG_NO        IN ODATA_EXP_M.ORG_NO%TYPE, --机构(前台集单可能传)
                               STREXPTYPE              IN ODATA_LOCATE_M.EXP_TYPE%TYPE, --出货单类型
                                 STRIP            IN TMP_ODATA_EXP_M.STRIP%TYPE, --IP
                                 STRATEGY_ID      IN WMS_OUTWAVEPLAN_D.BATCH_STRATEGY_ID%TYPE, --策略ID
                                 STRBATCH_RULE_ID IN WMS_OUTWAVEPLAN_D.BATCH_RULE_ID%TYPE, --规则ID
                                 STRWAVEID        IN TMP_LOCATEBATCH_LOG.WAVEID%TYPE, --波次流水（时间戳）
                             STRINDUSTRY_FLAG      IN ODATA_LOCATE_M.INDUSTRY_FLAG%TYPE, --行业标识
                                 STRTYPE          IN VARCHAR2, --来源类型（1：底层自动，2：前台自动）
                                 STRRESULT        OUT VARCHAR2);

  /*****************************************************************************************
     功能：限制SKU数
     ADD BY SUNL 20160620
  *****************************************************************************************/
  PROCEDURE P_LOCATECHECK_SKUCOUNT(STRENTERPRISENO   IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                                   STRSKU_COUNT_MODE IN WMS_OUTWAVEPLAN_D.SKU_COUNT_MODE%TYPE, --订单类型
                                   STRSKUCOUNT       IN WMS_OUTWAVEPLAN_D.SKUCOUNT%TYPE, --SKU限制
                                   STRSKU_LIMMIT     IN WMS_OUTWAVEPLAN_D.SKU_LIMMIT%TYPE, --品项数限制
                                   STRIP             IN TMP_ODATA_EXP_M.STRIP%TYPE,
                                   STRATEGY_ID       IN WMS_OUTWAVEPLAN_D.BATCH_STRATEGY_ID%TYPE, --策略ID
                                   STRBATCH_RULE_ID  IN WMS_OUTWAVEPLAN_D.BATCH_RULE_ID%TYPE, --规则ID
                                   STRWAVEID         IN TMP_LOCATEBATCH_LOG.WAVEID%TYPE, --波次流水（时间戳）
                                   STRRESULT         OUT VARCHAR2);

  /*****************************************************************************************
     功能：限制区域
     ADD BY SUNL 20160620
  *****************************************************************************************/
  PROCEDURE P_LOCATECHECK_AREA(STRENTERPRISENO  IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                               STRIP            IN TMP_ODATA_EXP_M.STRIP%TYPE,
                               STRATEGY_ID      IN WMS_OUTWAVEPLAN_D.BATCH_STRATEGY_ID%TYPE, --策略ID
                               STRBATCH_RULE_ID IN WMS_OUTWAVEPLAN_D.BATCH_RULE_ID%TYPE, --规则ID
                               STRWAVEID        IN TMP_LOCATEBATCH_LOG.WAVEID%TYPE, --波次流水（时间戳）
                               STRRESULT        OUT VARCHAR2);
/*****************************************************************************************
     功能：限定区域
     ADD BY SUNL 20160815
  *****************************************************************************************/
  PROCEDURE P_LOCATECHECK_LimmitAREA(STRENTERPRISENO  IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                               STRIP            IN TMP_ODATA_EXP_M.STRIP%TYPE,
                               STRATEGY_ID      IN WMS_OUTWAVEPLAN_D.BATCH_STRATEGY_ID%TYPE, --策略ID
                               STRBATCH_RULE_ID IN WMS_OUTWAVEPLAN_D.BATCH_RULE_ID%TYPE, --规则ID
                               STRWAVEID        IN TMP_LOCATEBATCH_LOG.WAVEID%TYPE, --波次流水（时间戳）
															 StrArea_Limmit_Value  IN WMS_OUTWAVEPLAN_D.Area_Limmit_Value%TYPE, --限定区域出货
                               STRRESULT        OUT VARCHAR2) ;
  /*****************************************************************************************
     功能：获取数据量
     ADD BY SUNL 20160620
  *****************************************************************************************/
  PROCEDURE P_LOCATECHECK_GETDATASIZE(STRENTERPRISENO  IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                                      STRIP            IN TMP_ODATA_EXP_M.STRIP%TYPE,
                                      STRATEGY_ID      IN WMS_OUTWAVEPLAN_D.BATCH_STRATEGY_ID%TYPE, --策略ID
                                      STRBATCH_RULE_ID IN WMS_OUTWAVEPLAN_D.BATCH_RULE_ID%TYPE, --规则ID
                                      STRWAVEID        IN TMP_LOCATEBATCH_LOG.WAVEID%TYPE, --波次流水（时间戳）
                                      STRORDERTYPE     IN TMP_ODATA_EXP_M.ORDERTYPE%TYPE, --分类 可以传ALL
                                      STRDATASIZE      OUT NUMBER, --数据量
                                      STRRESULT        OUT VARCHAR2);
  /*****************************************************************************************
     功能：对出货单进行集单（自动集单）
     自动集单写批次，调LOCATE过程
     ADD BY SUNL 20160620
  *****************************************************************************************/
  PROCEDURE P_LOCATE_CONTROL(STRENTERPRISENO         IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                             STRWAREHOUSENO          IN ODATA_LOCATE_M.WAREHOUSE_NO%TYPE, --仓别
                             STROWNERNO              IN ODATA_LOCATE_M.OWNER_NO%TYPE, --货主
                             STREXPTYPE              IN ODATA_LOCATE_M.EXP_TYPE%TYPE, --出货单类型
                             STRLOCATENAME           IN ODATA_LOCATE_M.LOCATE_NAME%TYPE, --集单人员
                             STRATEGY_ID             IN ODATA_LOCATE_BATCH.BATCH_STRATEGY_ID%TYPE, --策略ID
                             STRBATCH_RULE_ID        IN WMS_OUTWAVEPLAN_D.BATCH_RULE_ID%TYPE, --规则ID
                             STRDIVIDEFLAG           IN ODATA_LOCATE_BATCH.C_DIVIDE_FLAG%TYPE, --1：允许分播；0：不允许分播
                             STRSENDBUF_COMPUTE_FLAG IN ODATA_LOCATE_BATCH.SENDBUF_COMPUTE_FLAG%TYPE, --是否试算月台资源，1:试算；0:不试算
                             STRSPECIFYCELL          IN ODATA_LOCATE_BATCH.SPECIFY_CELL%TYPE, --指定储位定位，默认N，表示不指定储位
                             NTASKBATCH              IN ODATA_LOCATE_BATCH.BATCH_NO%TYPE, --分布式定位，任务批次号
                             STRSOURCETYPE           IN ODATA_LOCATE_M.SOURCE_TYPE%TYPE, --分布式定位，任务批次号
                             STRDIVIDE_COMPUTE_FLAG  IN DEVICE_DIVIDE_M.DIVIDE_COMPUTE_FLAG%TYPE, --分播设备
                             STRCHECK_COMPUTE_FLAG   IN ODATA_LOCATE_BATCH.CHECK_COMPUTE_FLAG%TYPE, --复合台
                             STRORGNO                IN ODATA_EXP_M.ORG_NO%TYPE,
                             --NTASK_ALLOTRULEID       IN ODATA_LOCATE_BATCH.TASK_RULE_ID%TYPE,
                             STRBATCH_COMPUTE      IN WMS_OUTWAVEPLAN_D.BATCH_COMPUTE%TYPE, --批次切分模式
                             STRORDERTYPE          IN TMP_ODATA_EXP_M.ORDERTYPE%TYPE, --分类 可以传0
                             STRINDUSTRY_FLAG      IN ODATA_LOCATE_M.INDUSTRY_FLAG%TYPE, --行业标识
                             STRIP                 IN VARCHAR2, --本地IP
                             STRLOCATE_STRATEGY_ID IN WMS_OUTLOCATE_STRATEGY_D.LOCATE_STRATEGY_ID%TYPE, --定位策略ID
                             STRWAVEID             IN TMP_LOCATEBATCH_LOG.WAVEID%TYPE, --波次流水（时间戳）
                             STRWAVENO             IN OUT ODATA_LOCATE_M.WAVE_NO%TYPE, --波次号
                             STRNEWBATCH_NO        IN OUT ODATA_LOCATE_BATCH.BATCH_NO%TYPE, --作业批次号
                             STRRESULT             OUT VARCHAR2);

  /*****************************************************************************************
     功能：批次设置
     LIZHIPING 2015-12-21
  *****************************************************************************************/
  PROCEDURE P_SET_BATCH(STRENTERPRISENO IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE,
                        STRWAREHOUSENO  IN ODATA_LOCATE_M.WAREHOUSE_NO%TYPE,
                        STRWAVENO       IN ODATA_LOCATE_M.WAVE_NO%TYPE,
                        STRBATCHNO      IN NUMBER,
                        STRRESULT       OUT VARCHAR2);
  /*****************************************************************************************
     功能：根据(策略ID)、规则ID 获取所有有效的单据，写入临时表 前台用
     ADD BY SUNL 20160622
  *****************************************************************************************/
  PROCEDURE P_WRITEORDERBYRULEID(STRENTERPRISE IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                                 --STRBATCH_STRATEGY_ID IN WMS_OUTWAVEPLAN_D.BATCH_STRATEGY_ID%TYPE,--策略ID
                                 STRBATCH_RULE_ID IN WMS_OUTWAVEPLAN_D.BATCH_RULE_ID%TYPE, --规则ID
                                 STREXP_TYPE      IN ODATA_LOCATE_BATCH.EXP_TYPE%TYPE, --出货单类型
                                 STRIP            IN ODATA_TMP_LOCATE_SELECT.TMP_ID%TYPE, --IP
                                 STRRESULT        OUT VARCHAR2);

  /*****************************************************************************************
     功能：根据是否赠品刷指定单据的SKU数
     ADD BY SUNL 20160620
  *****************************************************************************************/
  PROCEDURE P_LOCATECHECK_UPDATESKU(STRENTERPRISE   IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE,
                                    STRWAREHOUSE_NO IN ODATA_LOCATE_M.WAREHOUSE_NO%TYPE,
                                    STROWNER_NO     IN ODATA_LOCATE_M.OWNER_NO%TYPE,
                                    STREXP_NO       IN ODATA_EXP_M.EXP_NO%TYPE,
                                    STRRESULT       OUT VARCHAR2);

  /*****************************************************************************************
     功能： 聚类算法！
     ADD BY SUNL 20160712
  *****************************************************************************************/
  PROCEDURE P_LOCATECHECK_CLUSTERING(
                                     --记录日志用
                                     STRBATCH_STRATEGY_ID IN ODATA_LOCATE_BATCH.BATCH_STRATEGY_ID%TYPE, --指定策略 不指定传0
                                     STRBATCH_RULE_ID     IN ODATA_LOCATE_BATCH.BATCH_RULE_ID%TYPE, --指定规则 不指定传0
                                     STRWAVEID            IN TMP_LOCATEBATCH_LOG.WAVEID%TYPE, --波次流水（时间戳）
                                     --聚类算法用
                                     STRSKU_LIMMIT     IN WMS_OUTWAVEPLAN_D.SKU_LIMMIT%TYPE, --每订单允许无重复品项数
                                     STRSKUCOUNT       IN WMS_OUTWAVEPLAN_D.SKUCOUNT%TYPE, --品项上限
                                     STRREPEAT_TIMES   IN WMS_OUTWAVEPLAN_D.REPEAT_TIMES%TYPE, --重复度限制
                                     STRORDERTYPE      IN TMP_ODATA_EXP_M.ORDERTYPE%TYPE, --分类
                                     STR_IP            IN VARCHAR2, --本地ip
                                     STRALEVEL         IN TMP_LOCATE_CLUSTERING1.ALEVEL%TYPE, -- 商品级别 P1
                                     STRELEVEL         IN TMP_LOCATE_CLUSTERING2.ELEVEL%TYPE, -- 订单级别 P2
                                     STR_FAILARTICLES  IN OUT VARCHAR2, --当前有效的商品编码 C1
                                     STR_ARTICLES      IN OUT VARCHAR2, --当前有效的商品编码 P3
                                     STR_ARTICLESCOUNT IN OUT NUMBER, --记录当前有效商品个数 P4
                                     STR_ISSUCCESS     OUT NUMBER, --记录当前是否执行成功 (0,失败；1，成功) P5

                                     --生成批次用
                                     STRENTERPRISENO         IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                                     STRWAREHOUSENO          IN ODATA_LOCATE_M.WAREHOUSE_NO%TYPE, --仓别
                                     STROWNERNO              IN ODATA_LOCATE_M.OWNER_NO%TYPE, --货主
                                     STREXPTYPE              IN ODATA_LOCATE_M.EXP_TYPE%TYPE, --出货单类型
                                     STRLOCATENAME           IN ODATA_LOCATE_M.LOCATE_NAME%TYPE, --集单人员
                                     STRDIVIDEFLAG           IN ODATA_LOCATE_BATCH.C_DIVIDE_FLAG%TYPE, --1：允许分播；0：不允许分播
                                     STRSENDBUF_COMPUTE_FLAG IN ODATA_LOCATE_BATCH.SENDBUF_COMPUTE_FLAG%TYPE, --是否试算月台资源，1:试算；0:不试算
                                     STRSPECIFYCELL          IN ODATA_LOCATE_BATCH.SPECIFY_CELL%TYPE, --指定储位定位，默认N，表示不指定储位
                                     NTASKBATCH              IN ODATA_LOCATE_BATCH.BATCH_NO%TYPE, --分布式定位，任务批次号
                                     STRSOURCETYPE           IN ODATA_LOCATE_M.SOURCE_TYPE%TYPE, --分布式定位，任务批次号
                                     STRDIVIDE_COMPUTE_FLAG  IN DEVICE_DIVIDE_M.DIVIDE_COMPUTE_FLAG%TYPE, --分播设备
                                     STRCHECK_COMPUTE_FLAG   IN ODATA_LOCATE_BATCH.CHECK_COMPUTE_FLAG%TYPE, --复合台
                                     STRORGNO                IN ODATA_EXP_M.ORG_NO%TYPE,
                                     STRBATCH_COMPUTE        IN WMS_OUTWAVEPLAN_D.BATCH_COMPUTE%TYPE, --批次切分模式
                                     STRINDUSTRY_FLAG        IN ODATA_LOCATE_M.INDUSTRY_FLAG%TYPE, --行业标识
                                     STRLOCATE_STRATEGY_ID   IN WMS_OUTLOCATE_STRATEGY_D.LOCATE_STRATEGY_ID%TYPE, --定位策略ID
                                     STRWAVENO               IN OUT ODATA_LOCATE_M.WAVE_NO%TYPE, --波次号
                                     NUM_BATCHNO             IN OUT ODATA_LOCATE_BATCH.BATCH_NO%TYPE, --作业批次号

                                     STRRESULT OUT VARCHAR2);
END PKLG_ODISPATCH;


/

