create package        PKOBJ_ADJ is

  -- Author  : LUOZL
  -- Created : 2014-12-30 17:56:54
  -- Purpose :

  /************************************************************************************************

  创建人：luozhiling
  创建说明：新增虚拟库存调整单明细。
  创建日期：2014.12.30
  *************************************************************************************************/
    procedure P_InsertStockAdj_d(
           strEnterpriseNo      in        stock_adj_m.enterprise_no%type,
           strWareHouseNo       in        stock_adj_m.warehouse_no%type,
           strOwnerNo           in        stock_adj_m.owner_no%type,
           strAdjType           in        stock_adj_m.adj_type%type,
           strAdjNo             in        stock_adj_m.adj_no%type,
           strArticleNo         in        stock_adj_d.article_no%type,
           nArticleId           in        stock_adj_d.article_id%type,
           nPackingQty          in        stock_adj_d.packing_qty%type,
           dtProduceDate        in        stock_adj_d.produce_date%type,
           dtExpireDate         in        stock_adj_d.expire_date%type,
           strQuality           in        stock_adj_d.quality%type,
           strLotNo             in        stock_adj_d.lot_no%type,
           strRsvBatch1         in        stock_adj_d.rsv_batch1%type,
           strRsvBatch2         in        stock_adj_d.rsv_batch1%type,
           strRsvBatch3         in        stock_adj_d.rsv_batch1%type,
           strRsvBatch4         in        stock_adj_d.rsv_batch1%type,
           strRsvBatch5         in        stock_adj_d.rsv_batch1%type,
           strRsvBatch6         in        stock_adj_d.rsv_batch1%type,
           strRsvBatch7         in        stock_adj_d.rsv_batch1%type,
           strRsvBatch8         in        stock_adj_d.rsv_batch1%type,
           strCellNo            in        stock_adj_d.cell_no%type,
           nPlanQty             in        stock_adj_d.plan_qty%type,
           nRealQty             in        stock_adj_d.real_qty%type,
           strBarcode           IN        stock_adj_d.barcode%type,
           strStockType         in        stock_adj_d.stock_type%type,
           strStockValue        in        stock_adj_d.stock_value%type,
           strLabelNo           in        stock_adj_d.label_no%type,
           strResult            out       varchar2);
/*************************************************************************************
 创建人：luozhiling
 创建时间:2014.12.30
 功能说明：新增虚拟库存调整单头档
****************************************************************************************/
    procedure P_InsertStockAdj_m(
           strEnterpriseNo      in        stock_adj_m.enterprise_no%type,
           strWareHouseNo       in        stock_adj_m.warehouse_no%type,
           strOwnerNo           in        stock_adj_m.owner_no%type,
           strAdjType           in        stock_adj_m.adj_type%type,
           strUserId            in        stock_adj_m.rgst_name%type,
           strAdjNo             out        stock_adj_m.adj_no%type,
           strResult            out       varchar2);

/***************************************************************************************************************
 创建人：luozhiling
 创建时间：2015.1.4
 创建说明：更新虚拟库存调整单明细
***************************************************************************************************************/
    procedure P_UpdateStockAdj_d(
           strEnterpriseNo      in        stock_adj_m.enterprise_no%type,
           strWareHouseNo       in        stock_adj_m.warehouse_no%type,
           strOwnerNo           in        stock_adj_m.owner_no%type,
           strAdjNo             in        stock_adj_m.adj_no%type,
           nRowId               in        stock_adj_d.row_id%type,
           nRealQty             in        stock_adj_d.real_qty%type,
           strResult            out       varchar2);
/***************************************************************************************************************
 创建人：luozhiling
 创建时间：2015.1.4
 创建说明：更新虚拟库存调整单头档
***************************************************************************************************************/
    procedure P_UpdateStockAdj_m(
           strEnterpriseNo      in        stock_adj_m.enterprise_no%type,
           strWareHouseNo       in        stock_adj_m.warehouse_no%type,
           strOwnerNo           in        stock_adj_m.owner_no%type,
           strAdjNo             in        stock_adj_m.adj_no%type,
           strUserId            in        stock_adj_m.rgst_name%type,
           strResult            out       varchar2);

/*************************************************************************************
 创建人：luozhiling
 创建时间:2014.12.30
 功能说明：新增库存调账单头档
****************************************************************************************/
    procedure P_InsertStockPlan_m(
           strEnterpriseNo      in        stock_plan_m.enterprise_no%type,
           strWareHouseNo       in        stock_plan_m.warehouse_no%type,
           strOwnerNo           in        stock_plan_m.owner_no%type,
           strPlanType          in       stock_plan_m.plan_type%type,
           strPoNo              in       stock_plan_m.po_no%type,
           strCreateFlag        in       stock_plan_m.create_flag%type,
           strOrgNo             in       stock_plan_m.org_no%type,
           strUserId            in        stock_plan_m.rgst_name%type,
           strsRemark           in        stock_plan_m.remark%type,
           strPlanNo            out       stock_plan_m.plan_no%type,
           strResult            out       varchar2);
  /************************************************************************************************
  创建人：luozhiling
  创建说明：新增库存调账单明细
  创建日期：2014.12.30
  *************************************************************************************************/
    procedure P_InsertStockPlan_d(
           strEnterpriseNo      in        stock_plan_d.enterprise_no%type,
           strWareHouseNo       in        stock_plan_d.warehouse_no%type,
           strOwnerNo           in        stock_plan_d.owner_no%type,
           strPlanNo            in        stock_plan_d.plan_no%type,
           strArticleNo         in        stock_plan_d.article_no%type,
           nPackingQty          in        stock_plan_d.packing_qty%type,
           dtProduceDate        in        stock_plan_d.produce_date%type,
           dtExpireDate         in        stock_plan_d.expire_date%type,
           strQuality           in        stock_plan_d.quality%type,
           strLotNo             in        stock_plan_d.lot_no%type,
           strImportBatchNo     in        stock_plan_d.import_batch_no%type,
           strRsvBatch1         in        stock_plan_d.rsv_batch1%type,
           strRsvBatch2         in        stock_plan_d.rsv_batch1%type,
           strRsvBatch3         in        stock_plan_d.rsv_batch1%type,
           strRsvBatch4         in        stock_plan_d.rsv_batch1%type,
           strRsvBatch5         in        stock_plan_d.rsv_batch1%type,
           strRsvBatch6         in        stock_plan_d.rsv_batch1%type,
           strRsvBatch7         in        stock_plan_d.rsv_batch1%type,
           strRsvBatch8         in        stock_plan_d.rsv_batch1%type,
           strCellNo            in        stock_plan_d.cell_no%type,
           nPlanQty             in        stock_plan_d.plan_qty%type,
           strStockType         in        stock_plan_d.stock_type%type,
           strStockValue        in        stock_plan_d.stock_value%type,
           strLabelNo           in        stock_plan_d.label_no%type,
           strUserID            in        stock_plan_m.rgst_name%type,
           strResult            out       varchar2);

  /*************************************************************************************
  功能说明：写库存调账确认单头档
  2015.7.25

 ************************************************************************************/
 procedure P_InsertStockConfirmHead( strEnterpriseNo      in        stock_confirm_m.enterprise_no%type,
           strWareHouseNo       in        stock_confirm_m.warehouse_no%type,
           strOwnerNo           in        stock_confirm_m.owner_no%type,
           strPlanNo             in       stock_confirm_m.plan_no%type,
           strUserId            in        stock_confirm_m.rgst_name%type,
           strConfrimNo         out       stock_confirm_m.plan_no%type,
           strResult            out       varchar2);

  /************************************************************************************************
  创建人：luozhiling
  创建说明：新增调账确认单明细
  创建日期：2015.7.25
  *************************************************************************************************/
    procedure P_InsertStockConfirmItem(
           strEnterpriseNo      in        stock_confirm_d.enterprise_no%type,
           strWareHouseNo       in        stock_confirm_d.warehouse_no%type,
           strOwnerNo           in        stock_confirm_d.owner_no%type,
           strConfirmNo         in        stock_confirm_d.confirm_no%type,
           strSourceNo          in        stock_confirm_d.source_no%type,
           strArticleNo         in        stock_confirm_d.article_no%type,
           nArticleId           in        stock_confirm_d.article_id%type,
           nPackingQty          in        stock_confirm_d.packing_qty%type,
           dtProduceDate        in        stock_confirm_d.produce_date%type,
           dtExpireDate         in        stock_confirm_d.expire_date%type,
           strQuality           in        stock_confirm_d.quality%type,
           strLotNo             in        stock_confirm_d.lot_no%type,
           strImportBatchNo     in        stock_confirm_d.import_batch_no%type,
           strRsvBatch1         in        stock_confirm_d.rsv_batch1%type,
           strRsvBatch2         in        stock_confirm_d.rsv_batch1%type,
           strRsvBatch3         in        stock_confirm_d.rsv_batch1%type,
           strRsvBatch4         in        stock_confirm_d.rsv_batch1%type,
           strRsvBatch5         in        stock_confirm_d.rsv_batch1%type,
           strRsvBatch6         in        stock_confirm_d.rsv_batch1%type,
           strRsvBatch7         in        stock_confirm_d.rsv_batch1%type,
           strRsvBatch8         in        stock_confirm_d.rsv_batch1%type,
           strCellNo            in        stock_confirm_d.cell_no%type,
           nArticleQty          in        stock_confirm_d.article_qty%type,
           strStockType         in        stock_confirm_d.stock_type%type,
           strStockValue        in        stock_confirm_d.stock_value%type,
           strLabelNo           in        stock_confirm_d.label_no%type,
           strUserID            in        stock_confirm_d.rgst_name%type,
           strResult            out       varchar2);

/************************************************************************************************
 功能说明：库存调整确认单回单
      2015.7.25

************************************************************************************************/
   procedure P_updateStockConfirmItem(
           strEnterpriseNo      in        stock_confirm_d.enterprise_no%type,
           strWareHouseNo       in        stock_confirm_d.warehouse_no%type,
           strOwnerNo           in        stock_confirm_d.owner_no%type,
           strConfirmNo         in        stock_confirm_d.confirm_no%type,
           nRowId               in        stock_confirm_d.row_id%type,
           nRealQty             in        stock_confirm_d.real_qty%type,
           strUserId            in        stock_confirm_d.rgst_name%type,
           strResult            out       varchar2);
/***************************************************************************************************************
 创建人：luozhiling
 创建时间：2015.1.4
 创建说明：更新虚拟库存调整单头档
***************************************************************************************************************/
    procedure P_UpdateStockConfirmHead(
           strEnterpriseNo      in        stock_confirm_m.enterprise_no%type,
           strWareHouseNo       in        stock_confirm_m.warehouse_no%type,
           strOwnerNo           in        stock_confirm_m.owner_no%type,
           strConfirmNo         in        stock_confirm_m.confirm_no%type,
           strUserId            in        stock_confirm_m.rgst_name%type,
           strResult            out       varchar2);
/*************************************************************************************
 创建人：huangsq
 创建时间:2015.7.20
 功能说明：新增品质转换单头档
****************************************************************************************/
    procedure P_Insert_QUALITY_CHANGE_m(
           strEnterpriseNo      in        ORG_QUALITY_CHANGE_m.enterprise_no%type,
           strWareHouseNo       in        ORG_QUALITY_CHANGE_m.warehouse_no%type,
           strOwnerNo           in        ORG_QUALITY_CHANGE_m.owner_no%type,
           strChangeType        in        ORG_QUALITY_CHANGE_m.CHANGE_TYPE%type,
           strUserId            in        ORG_QUALITY_CHANGE_m.rgst_name%type,
           strPo_no             in        ORG_QUALITY_CHANGE_m.Po_No%type,
           strChange_No         out       ORG_QUALITY_CHANGE_m.Change_no%type,
           strResult            out       varchar2) ;
/*************************************************************************************
 创建人：huangsq
 创建时间:2015.7.20
 功能说明：新增品质转换单明细
****************************************************************************************/
    procedure P_Insert_QUALITY_CHANGE_d(
           strEnterpriseNo      in        ORG_QUALITY_CHANGE_D.enterprise_no%type,
           strWareHouseNo       in        ORG_QUALITY_CHANGE_D.warehouse_no%type,
           strOwnerNo           in        ORG_QUALITY_CHANGE_D.owner_no%type,
           strChangeType        in        ORG_QUALITY_CHANGE_D.Change_No%type,
           strChange_No         in        ORG_QUALITY_CHANGE_D.Change_No%type,
           strArticleNo         in        ORG_QUALITY_CHANGE_D.article_no%type,
           nPackingQty          in        ORG_QUALITY_CHANGE_D.packing_qty%type,
           dtProduceDate        in        org_quality_change_d.produce_date%type,
           dtExpireDate         in        org_quality_change_d.expire_date%type,
           strImportBatchNo     in        org_quality_change_d.import_batch_no%type,
           strLotNo             in        org_quality_change_d.lot_no%type,--批次号
           strRSV_BATCH1        in        org_quality_change_d.rsv_batch1%type, --预留批属性1
           strRSV_BATCH2        in        org_quality_change_d.rsv_batch2%type, --预留批属性2
           strRSV_BATCH3        in        org_quality_change_d.rsv_batch3%type, --预留批属性3
           strRSV_BATCH4        in        org_quality_change_d.rsv_batch4%type, --预留批属性4
           strRSV_BATCH5        in        org_quality_change_d.rsv_batch5%type, --预留批属性5
           strRSV_BATCH6        in        org_quality_change_d.rsv_batch6%type, --预留批属性6
           strRSV_BATCH7        in        org_quality_change_d.rsv_batch7%type, --预留批属性7
           strRSV_BATCH8        in        org_quality_change_d.rsv_batch8%type, --预留批属性8
           strS_ORGNO           in        ORG_QUALITY_CHANGE_D.s_Org_No%type,
           strD_ORGNO           in        ORG_QUALITY_CHANGE_D.d_Org_No%type,
           nChangeQty           in        ORG_QUALITY_CHANGE_D.Change_Qty%type,
           nRealQty             in        ORG_QUALITY_CHANGE_D.real_qty%type,
           strDept_no           in        ORG_QUALITY_CHANGE_D.Dept_No%type,
           strStockType         in        ORG_QUALITY_CHANGE_D.stock_type%type,
           strStockValue        in        ORG_QUALITY_CHANGE_D.stock_value%type,
           strResult            out       varchar2) ;
/*************************************************************************************
 创建人：huangsq
 创建时间:2015.7.20
 功能说明：更新品质转换单头档
****************************************************************************************/
    procedure P_Update_QUALITY_CHANGE_m(
           strEnterpriseNo      in        ORG_QUALITY_CHANGE_m.enterprise_no%type,
           strWareHouseNo       in        ORG_QUALITY_CHANGE_m.warehouse_no%type,
           strOwnerNo           in        ORG_QUALITY_CHANGE_m.owner_no%type,
           strChange_No             in    ORG_QUALITY_CHANGE_m.Change_No%type,
           strUserId            in        ORG_QUALITY_CHANGE_m.rgst_name%type,
           strResult            out       varchar2);
/*************************************************************************************
 创建人：huangsq
 创建时间:2015.7.20
 功能说明：更新品质转换单明细
****************************************************************************************/
    procedure P_Update_QUALITY_CHANGE_d(
           strEnterpriseNo      in        ORG_QUALITY_CHANGE_m.enterprise_no%type,
           strWareHouseNo       in        ORG_QUALITY_CHANGE_m.warehouse_no%type,
           strOwnerNo           in        ORG_QUALITY_CHANGE_m.owner_no%type,
           strChange_No         in        ORG_QUALITY_CHANGE_m.Change_No%type,
           strArticleNo         in        ORG_QUALITY_CHANGE_D.article_no%type,
           nRealQty             in        ORG_QUALITY_CHANGE_d.real_qty%type,
           nRowID               in        ORG_QUALITY_CHANGE_D.ROW_ID%TYPE,
           strResult            out       varchar2) ;

end PKOBJ_ADJ;


/

