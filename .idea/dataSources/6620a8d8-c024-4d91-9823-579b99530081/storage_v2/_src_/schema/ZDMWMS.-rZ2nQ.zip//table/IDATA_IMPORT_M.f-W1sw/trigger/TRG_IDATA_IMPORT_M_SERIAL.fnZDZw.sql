create trigger TRG_IDATA_IMPORT_M_SERIAL
    before insert
    on IDATA_IMPORT_M
    for each row
declare
  i_report_up_SERIAL NUMBER;
begin
  select SEQ_IDATA_IMPORT_M.NEXTVAL into i_report_up_SERIAL from dual;
  :NEW.REPORT_UP_SERIAL := i_report_up_SERIAL;
end TRG_IDATA_IMPORT_M_SERIAL;


/

