create view V_SEARCH_9103_010 as
select m.enterprise_no,m.warehouse_no,cust.owner_no,m.CUST_NO,cust.cust_name,m.wave_no,
  m.label_no,m.status,f_get_fieldtext('STOCK_LABEL_M', 'STATUS', m.status)as status_desc,trunc(m.rgst_date) exp_date,bo.owner_name
  from stock_label_m m,BDEF_DEFCUST CUST,bdef_defowner bo--,stock_label_arrange_log t
  where m.status in ('A0')
  and m.enterprise_no=cust.enterprise_no
  and m.cust_no=cust.cust_no
--  and m.enterprise_no=t.enterprise_no
  --and m.label_no=t.label_no and t.arrange_type='4'
  and cust.enterprise_no=bo.enterprise_no
  and cust.owner_no=bo.owner_no  --and bo.owner_no='TJZCZ'
  and m.use_type=1
  order by m.CUST_NO,m.label_no


/

