create package body PKOBJ_STOCK is
  ---------------------------------------------------------【公共begin】--------------------------------------------
  /****************************************************************************************************************88
  修改说明：2015.3.16 luozhiling 增加库存三级帐记录和商品批次库存帐

  ******************************************************************************************************************/

  /*****************************************************************************************
     功能：扣减源库存 循环扣减, 不处理预约上下架量，直接扣减库存
    Modify By luozhiling AT 2013-09-28
  *****************************************************************************************/
  procedure p_UpdtContent_qtyByCellNo(strEnterPriseNo  in stock_content.enterprise_no%type, -- 企业编号
                                      strWAREHOUSE_NO  in stock_content.WAREHOUSE_NO%type, --仓别
                                      strOwner_No      in stock_content.Owner_No%type, --委托业主
                                      strArticle_no    in stock_content.article_no%type, --商品编号
                                      nArticle_id      in stock_content.article_id%type, --商品属性ID
                                      strCell_no       in stock_content.cell_no%type, --储位
                                      strR_cell_no     in stock_content.cell_no%type, --关系储位
                                      nPacking_Qty     in stock_content.Packing_Qty%type, --商品包装
                                      nQty             in stock_content.qty%type, --数量
                                      strlabelNo       in stock_content.label_no%type, --商品容器号
                                      strStock_type    in stock_content.stock_type%type, --存储类型
                                      strStock_value   in stock_content.stock_value%type, --对应存储值
                                      strUser_id       in stock_content.Rgst_Name%type, --操作人员
                                      strPAPER_NO      in stock_content_move.PAPER_NO%type, --操作单号
                                      strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                                      strErrorMsg      out varchar2) --返回 执行结果
   is
    n_MoveSumQty stock_content.Qty%type; --转移总数量
    n_MoveQty    stock_content.Qty%type; --转移数量
    n_count      number(10); --记录数，以做判断;
  begin

    strErrorMsg := 'N|[p_UpdtContent_qtyByCellNo]';

    n_count      := 0;
    n_MoveSumQty := nQty;

    for i_Content_Info in (select *
                             from stock_content sc
                            where sc.enterprise_no = strEnterPriseNo
                              and sc.WAREHOUSE_NO = strWAREHOUSE_NO
                              and sc.Owner_No = strOwner_No
                              and sc.article_no = strArticle_no
                              and sc.article_id = nArticle_id
                              and sc.cell_no = strCell_No
                              and sc.Packing_Qty = nPacking_Qty
                              and sc.label_no = strlabelNo
                                 --and sc.label_no = nlabel_no
                              and sc.stock_type = strStock_type
                              and sc.stock_value = strStock_value
                              and sc.qty - sc.outstock_qty > 0) loop
      n_count := 1; --判断是否进了循环
      ---当总转移数量等于0时，跳出本次循环
      if (n_MoveSumQty <= 0) then
        --跳出本次循环，
        goto CutContentEnd;
      end if;
      --------循环配量-------------------
      if (i_Content_Info.Qty >= n_MoveSumQty) then
        n_MoveQty := n_MoveSumQty;
      else
        n_MoveQty := i_Content_Info.Qty;
      end if;
      -----------是虚拟储位的时候---------------

      n_MoveSumQty := n_MoveSumQty - n_MoveQty;
      ---------记储位三级账-----------
      insert into stock_content_move
        (WAREHOUSE_NO,
         OWNER_NO,
         dept_no,
         ROW_ID,
         PAPER_TYPE,
         PAPER_NO,
         TERMINAL_FLAG,
         ARTICLE_NO,
         ARTICLE_ID,
         CELL_NO,
         LABEL_NO,
         CELL_ID,
         FIRST_QTY,
         FIRST_INSTOCK_QTY,
         FIRST_OUTSTOCK_QTY,
         R_CELL_NO,
         IO_FLAG,
         MOVE_QTY,
         RGST_NAME,
         RGST_DATE,
         STOCK_TYPE,
         STOCK_VALUE,
         enterprise_no)
      values
        (strWAREHOUSE_NO,
         strOWNER_NO,
         i_Content_Info.dept_no,
         SEQ_stock_CONTENT.nextval,
         substr(strPAPER_NO, 1, 2),
         strPAPER_NO,
         strTERMINAL_FLAG,
         strArticle_no,
         nARTICLE_ID,
         strCELL_NO,
         strlabelNo,
         i_Content_Info.Cell_Id,
         i_Content_Info.Qty,
         i_Content_Info.Instock_Qty,
         i_Content_Info.Outstock_Qty,
         strR_cell_no,
         'O',
         n_MoveQty,
         strUser_id,
         sysdate,
         i_Content_Info.Stock_Type,
         i_Content_Info.Stock_Value,
         strEnterPriseNo);

      --------修改库存数量,普通储位------------
      update stock_content sc
         set sc.qty       = sc.qty - n_MoveQty,
             sc.updt_name = struser_id,
             sc.updt_date = sysdate
       where sc.enterprise_no = strEnterPriseNo
         and sc.WAREHOUSE_NO = i_Content_Info.WAREHOUSE_NO
         and sc.cell_no = i_Content_Info.Cell_No
         and sc.cell_id = i_Content_Info.Cell_Id
         and sc.qty - sc.outstock_qty - n_MoveQty >= 0;
      ---------修改记录为0行------------
      if sql%notfound then
        strErrorMsg := 'N|[E00008]{' || strArticle_No || '}{' || strCell_No || '}';
        return;
      end if;

      --<<CutContentEnd>>标签后的null;语句不可少,因为goto标签后必须紧接着一个执行语句
      <<CutContentEnd>>
      null;

    end loop;

    --------删除库存表qty为0的记录--------------
    delete stock_content sc
     where sc.enterprise_no = strEnterPriseNo
       and sc.WAREHOUSE_NO = strWAREHOUSE_NO
       and sc.cell_no = strCell_no
       and sc.qty = 0
       and sc.instock_qty = 0
       and sc.outstock_qty = 0
       and sc.UNUSUAL_QTY = 0;

    if n_MoveSumQty > 0 then
      strErrorMsg := 'N|[E00401]';
      return;
    end if;
    if (n_count <= 0) then
      strErrorMsg := 'N|[E00150]';
      return;
    end if;

    strErrorMsg := 'Y|';
  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end p_UpdtContent_qtyByCellNo;
  /*****************************************************************************************
     功能：扣减源库存  不循环，带cell_ID,写预约下架数量
    Modify By luozhiling AT 2013-09-28
  *****************************************************************************************/
  procedure p_UpdtContent_qtyByCellID(strEnterPriseNo  in stock_content.enterprise_no%type, -- 企业编号
                                      strWAREHOUSE_NO  in stock_content.WAREHOUSE_NO%type, --仓库编码
                                      strcell_id       in stock_content.cell_id%type, --储位ID
                                      strcell_no       in stock_content.cell_no%type, --储位
                                      strR_cell_no     in stock_content.cell_no%type, --关系储位
                                      nQty             in stock_content.qty%type, --数量
                                      noutstock_qty    in stock_content.outstock_qty%type, --预下数量
                                      strUser_id       in stock_content.Rgst_Name%type, --操作人员
                                      strPAPER_NO      in stock_content_move.PAPER_NO%type, --操作单号
                                      strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                                      strOutMsg        out varchar2) --返回 执行结果
   is
    n_count number(10); --记录数，以做判断;
  begin
    strOutMsg := 'N|[p_UpdtContent_qtyByCellID]';
    n_count   := 0;

    for i_Content_Info in (select *
                             from stock_content sc
                            where sc.enterprise_no = strEnterPriseNo
                              and sc.WAREHOUSE_NO = strWAREHOUSE_NO
                              and sc.cell_no = strCell_No
                              and sc.cell_id = strcell_id) loop
      n_count := 1;
      ----------------------储位三级账--------
      insert into stock_content_move
        (WAREHOUSE_NO,
         OWNER_NO,
         Dept_no,
         ROW_ID,
         PAPER_TYPE,
         PAPER_NO,
         TERMINAL_FLAG,
         ARTICLE_NO,
         ARTICLE_ID,
         CELL_NO,
         LABEL_NO,
         CELL_ID,
         FIRST_QTY,
         FIRST_INSTOCK_QTY,
         FIRST_OUTSTOCK_QTY,
         R_CELL_NO,
         IO_FLAG,
         MOVE_QTY,
         RGST_NAME,
         RGST_DATE,
         STOCK_TYPE,
         STOCK_VALUE,
         enterprise_no)
      values
        (strWAREHOUSE_NO,
         i_Content_Info.OWNER_NO,
         i_Content_Info.dept_no,
         SEQ_stock_CONTENT.nextval,
         substr(strPAPER_NO, 1, 2),
         strPAPER_NO,
         strTERMINAL_FLAG,
         i_Content_Info.article_no,
         i_Content_Info.ARTICLE_ID,
         strCELL_NO,
         i_Content_Info.LABEL_NO,
         i_Content_Info.Cell_Id,
         i_Content_Info.Qty,
         i_Content_Info.Instock_Qty,
         i_Content_Info.Outstock_Qty,
         strR_cell_no,
         'O',
         nQty,
         struser_id,
         sysdate,
         i_Content_Info.Stock_Type,
         i_Content_Info.Stock_Value,
         strEnterPriseNo);
      -------------------把来源储位预下库存回单
      UPDATE stock_content
         SET qty          = qty - nQty,
             outstock_qty = outstock_qty - noutstock_qty,
             updt_date    = sysdate,
             updt_name    = strUser_id
       where enterprise_no = strEnterPriseNo
         and WAREHOUSE_NO = strWAREHOUSE_NO
         and cell_no = strCell_No
         and CELL_ID = strCell_Id
         AND QTY - nQty >= 0
         and outstock_qty - noutstock_qty >= 0;

      ---------修改记录为0行------------
      if sql%notfound then
        strOutMsg := 'N|[E00386]{' || strCell_No || '}{' || strCell_Id || '}';
        return;
      end if;
    end loop;
    -----------删除库存为0的记录------------------------
    delete stock_content
     where enterprise_no = strEnterPriseNo
       and WAREHOUSE_NO = WAREHOUSE_NO
       and cell_no = strCell_No
       and qty = 0
       and instock_qty = 0
       and outstock_qty = 0
       and UNUSUAL_QTY = 0;

    if n_count <= 0 then
      strOutMsg := 'N|[E00619]';
      return;
    end if;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end p_UpdtContent_qtyByCellID;

  /*****************************************************************************************
     功能：增加目的库存 没有预上数量 盘点记帐专用
    midyfy by MM 20140506
  *****************************************************************************************/
  procedure p_InstContent_fcqtyByCellNo(strEnterPriseNo  in stock_content.enterprise_no%type, -- 企业编号
                                        strWAREHOUSE_NO  in stock_content.WAREHOUSE_NO%type, --仓库编码
                                        strOwner_No      in stock_content.Owner_No%type, --委托业主
                                        strDeptNo        in stock_content.dept_no%type, --部门编码
                                        strArticle_no    in stock_content.article_no%type, --商品编号
                                        nArticle_id      in stock_content.article_id%type, --商品属性ID
                                        strCell_no       in stock_content.cell_no%type, --储位
                                        strR_cell_no     in stock_content.cell_no%type, --关系储位
                                        nPacking_Qty     in stock_content.Packing_Qty%type, --商品包装
                                        nQty             in stock_content.qty%type, --数量
                                        strlabel_no      in stock_content.label_no%type, --标签号
                                        strsub_label_no  in stock_content.sub_label_no%type, --子标签号
                                        strStock_type    in stock_content.stock_type%type, --存储类型
                                        strStock_value   in stock_content.stock_value%type, --对应存储值
                                        strUser_id       in stock_content.Rgst_Name%type, --操作人员
                                        strPAPER_NO      in stock_content_move.PAPER_NO%type, --操作单号
                                        strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                                        nMvHandFlag      in stock_content.mv_hand_flag%type, --是否可手工移库 0:不允许手工移库；1：可手工移库
                                        nOutCellID       out stock_content.cell_id%type, --返回的储位ID
                                        strOutMsg        out varchar2) --返回 执行结果
   is
    n_cell_id      stock_content.cell_id%type; --储位id
    n_outstock_qty stock_content.outstock_qty%type; --预下数量
    n_instock_qty  stock_content.instock_qty%type; --预上数量
    n_s_qty        stock_content.qty%type; --原来数量
    N_inTmp        stock_content.qty%type;
    N_Nqty         stock_content.qty%type;
  begin
    strOutMsg := 'N|[p_InstContent_fcqtyByCellNo]';

    N_Nqty := nqty;
    --先处理负库存数据
    for R in (select cell_id, outstock_qty, instock_qty, qty
              --into n_cell_id, n_outstock_qty, n_instock_qty, n_s_qty
                from stock_content sc
               where sc.enterprise_no = strEnterPriseNo
                 and sc.WAREHOUSE_NO = strWAREHOUSE_NO
                 and sc.Owner_No = strOwner_No
                 and sc.article_no = strarticle_no
                 and sc.cell_no = strCell_No
                 and sc.Flag = '0'
                 and sc.mv_hand_flag = nMvHandFlag
                 and sc.instock_type = '0'
                 and sc.stock_type = strStock_type
                 and sc.stock_value = strStock_value
                 and sc.Qty < 0) loop
      if N_Nqty <= 0 then
        exit;
      end if;

      if N_Nqty < abs(r.qty) then
        N_inTmp := N_Nqty;
        N_Nqty  := 0;
      else
        N_Nqty  := N_Nqty - abs(r.qty);
        N_inTmp := abs(r.qty);
      end if;

      -----------找到储位ID--------------------------------
      if (r.cell_id > 0) then
        ------------------添加储位三级账----------------------------
        insert into stock_content_move
          (WAREHOUSE_NO,
           OWNER_NO,
           DEPT_NO,
           /*           ROW_ID,  */
           PAPER_TYPE,
           PAPER_NO,
           TERMINAL_FLAG,
           ARTICLE_NO,
           ARTICLE_ID,
           CELL_NO,
           LABEL_NO,
           CELL_ID,
           FIRST_QTY,
           FIRST_INSTOCK_QTY,
           FIRST_OUTSTOCK_QTY,
           R_CELL_NO,
           IO_FLAG,
           MOVE_QTY,
           RGST_NAME,
           RGST_DATE,
           STOCK_TYPE,
           STOCK_VALUE,
           enterprise_no)
        values
          (strWAREHOUSE_NO,
           strOWNER_NO,
           strDeptNo,
           /*           SEQ_stock_CONTENT.nextval,*/
           substr(strPAPER_NO, 1, 2),
           strPAPER_NO,
           strTERMINAL_FLAG,
           strarticle_no,
           nARTICLE_ID,
           strCELL_NO,
           strlabel_no,
           r.cell_id,
           r.qty,
           r.instock_qty,
           r.outstock_qty,
           strR_cell_no,
           'I',
           N_inTmp,
           struser_id,
           sysdate,
           strStock_Type,
           strStock_Value,
           strEnterPriseNo);
        ----------------------------------增加目的储位库存数量-----------------------------
        update stock_content sc
           set sc.qty       = sc.qty + N_inTmp,
               sc.updt_name = strUSER_ID,
               sc.updt_date = sysdate
         where sc.enterprise_no = strEnterPriseNo
           and sc.WAREHOUSE_NO = STRWAREHOUSE_NO
           and sc.owner_no = strOwner_No
           and SC.cell_NO = strCell_no
           and sc.cell_id = r.cell_id;
        -----------------------------------修改记录为0行------------------------
        if sql%notfound then
          strOutMsg := 'N|[E00007]';
          return;
        end if;
      end if;

    end loop;

    if N_Nqty > 0 then
      begin
        --处理目的容器库存-
        -----------获取目的容器库存，储位ID-------------------
        select cell_id, outstock_qty, instock_qty, qty
          into n_cell_id, n_outstock_qty, n_instock_qty, n_s_qty
          from stock_content sc
         where sc.enterprise_no = strEnterPriseNo
           and sc.WAREHOUSE_NO = strWAREHOUSE_NO
           and sc.Owner_No = strOwner_No
           and sc.article_no = strarticle_no
           and sc.article_id = narticle_id
           and sc.cell_no = strCell_No
           and sc.Packing_Qty = nPacking_Qty
           and sc.label_no = strlabel_no
           and sc.Flag = '0'
           and sc.mv_hand_flag = nMvHandFlag
           and sc.instock_type = '0'
           and rownum = 1;
        -----------找到储位ID--------------------------------
        if (n_cell_id > 0) then
          ------------------添加储位三级账----------------------------
          insert into stock_content_move
            (WAREHOUSE_NO,
             OWNER_NO,
             DEPT_NO,
             /*           ROW_ID,  */
             PAPER_TYPE,
             PAPER_NO,
             TERMINAL_FLAG,
             ARTICLE_NO,
             ARTICLE_ID,
             CELL_NO,
             LABEL_NO,
             CELL_ID,
             FIRST_QTY,
             FIRST_INSTOCK_QTY,
             FIRST_OUTSTOCK_QTY,
             R_CELL_NO,
             IO_FLAG,
             MOVE_QTY,
             RGST_NAME,
             RGST_DATE,
             STOCK_TYPE,
             STOCK_VALUE,
             enterprise_no)
          values
            (strWAREHOUSE_NO,
             strOWNER_NO,
             strDeptNo,
             /*           SEQ_stock_CONTENT.nextval,*/
             substr(strPAPER_NO, 1, 2),
             strPAPER_NO,
             strTERMINAL_FLAG,
             strarticle_no,
             nARTICLE_ID,
             strCELL_NO,
             strlabel_no,
             n_cell_id,
             n_s_qty,
             n_instock_qty,
             n_outstock_qty,
             strR_cell_no,
             'I',
             N_Nqty,
             struser_id,
             sysdate,
             strStock_Type,
             strStock_Value,
             strEnterPriseNo);
          ----------------------------------增加目的储位库存数量-----------------------------
          update stock_content sc
             set sc.qty       = sc.qty + N_Nqty,
                 sc.updt_name = strUSER_ID,
                 sc.updt_date = sysdate
           where sc.enterprise_no = strEnterPriseNo
             and sc.WAREHOUSE_NO = STRWAREHOUSE_NO
             and sc.owner_no = strOwner_No
             and SC.cell_NO = strCell_no
             and sc.cell_id = n_cell_id;
          -----------------------------------修改记录为0行------------------------
          if sql%notfound then
            strOutMsg := 'N|[E00007]';
            return;
          end if;
        end if;
        ----------------------------没找到，新增一条库存记录-------------------
      exception
        when no_data_found then
          --------------------------获取储位ID----------------
          select SEQ_stock_CONTENT.nextval into n_cell_id from dual;
          ----------------------添加储位三级账----------------------------
          insert into stock_content_move
            (WAREHOUSE_NO,
             OWNER_NO,
             DEPT_NO,
             ROW_ID,
             PAPER_TYPE,
             PAPER_NO,
             TERMINAL_FLAG,
             ARTICLE_NO,
             ARTICLE_ID,
             CELL_NO,
             LABEL_NO,
             CELL_ID,
             FIRST_QTY,
             FIRST_INSTOCK_QTY,
             FIRST_OUTSTOCK_QTY,
             R_CELL_NO,
             IO_FLAG,
             MOVE_QTY,
             RGST_NAME,
             RGST_DATE,
             STOCK_TYPE,
             STOCK_VALUE,
             enterprise_no)
          values
            (strWAREHOUSE_NO,
             strOWNER_NO,
             strDeptNo,
             SEQ_stock_CONTENT.nextval,
             substr(strPAPER_NO, 1, 2),
             strPAPER_NO,
             strTERMINAL_FLAG,
             strarticle_no,
             nARTICLE_ID,
             strCELL_NO,
             strlabel_no,
             n_cell_id,
             0,
             0,
             0,
             strR_cell_no,
             'I',
             N_Nqty,
             struser_id,
             sysdate,
             strStock_Type,
             strStock_Value,
             strEnterPriseNo);
          ------------------------新增一笔库存记录-------------------------------------
          insert into stock_content
            (enterprise_no,
             WAREHOUSE_NO,
             owner_no,
             dept_no,
             cell_no,
             cell_id,
             ARTICLE_NO,
             ARTICLE_ID,
             PACKING_QTY,
             qty,
             outstock_qty,
             instock_qty,
             unusual_qty,
             rgst_name,
             rgst_date,
             UPDT_NAME,
             UPDT_DATE,
             status,
             flag,
             instock_type,
             stock_type,
             stock_VALUE,
             Label_No,
             Mv_hand_flag,
             sub_label_no)
          values
            (strEnterPriseNo,
             strWAREHOUSE_NO,
             strOwner_No,
             strDeptNo,
             strCell_No,
             n_cell_id,
             strArticle_No,
             nArticle_Id,
             nPacking_Qty,
             N_Nqty,
             0,
             0,
             0,
             strUSER_ID,
             sysdate,
             strUSER_ID,
             sysdate,
             0,
             0,
             0,
             strStock_Type,
             strStock_Value,
             strlabel_no,
             nMvHandFlag,
             strsub_label_no);
          -----------------------新增记录为0行----------------------
          if sql%notfound then
            strOutMsg := 'N|[E00008]{' || strArticle_No || '}{' ||
                         strCell_No || '}';
            return;
          end if;
      end;
    end if;

    --------删除库存表qty为0的记录--------------
    delete stock_content sc
     where sc.enterprise_no = strEnterPriseNo
       and sc.WAREHOUSE_NO = strWAREHOUSE_NO
       and sc.cell_no = strCell_No
       and sc.qty = 0
       and sc.instock_qty = 0
       and sc.outstock_qty = 0
       and sc.UNUSUAL_QTY = 0;

    nOutCellID := n_cell_id;
    strOutMsg  := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end p_InstContent_fcqtyByCellNo;

  /*****************************************************************************************
     功能：扣减源库存  不循环，带cell_ID,无预下数量
    Modify By luozhiling AT 2013-09-28
  *****************************************************************************************/
  procedure p_UpdtContentByCellID(strEnterPriseNo  in stock_content.enterprise_no%type, -- 企业编号
                                  strWAREHOUSE_NO  in stock_content.WAREHOUSE_NO%type, --仓库编码
                                  strcell_id       in stock_content.cell_id%type, --储位ID
                                  strcell_no       in stock_content.cell_no%type, --储位
                                  strR_cell_no     in stock_content.cell_no%type, --关系储位
                                  nQty             in stock_content.qty%type, --数量
                                  strUser_id       in stock_content.Rgst_Name%type, --操作人员
                                  strPAPER_NO      in stock_content_move.PAPER_NO%type, --操作单号
                                  strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                                  strOutMsg        out varchar2) --返回 执行结果
   is
    n_count number(10); --记录数，以做判断;
  begin
    strOutMsg := 'N|[p_UpdtContentByCellID]';
    n_count   := 0;

    for i_Content_Info in (select *
                             from stock_content sc
                            where sc.enterprise_no = strEnterPriseNo
                              and sc.WAREHOUSE_NO = strWAREHOUSE_NO
                              and sc.cell_no = strCell_No
                              and sc.cell_id = strcell_id) loop
      n_count := 1;
      ----------------------储位三级账--------
      insert into stock_content_move
        (WAREHOUSE_NO,
         OWNER_NO,
         Dept_no,
         ROW_ID,
         PAPER_TYPE,
         PAPER_NO,
         TERMINAL_FLAG,
         ARTICLE_NO,
         ARTICLE_ID,
         CELL_NO,
         LABEL_NO,
         CELL_ID,
         FIRST_QTY,
         FIRST_INSTOCK_QTY,
         FIRST_OUTSTOCK_QTY,
         R_CELL_NO,
         IO_FLAG,
         MOVE_QTY,
         RGST_NAME,
         RGST_DATE,
         STOCK_TYPE,
         STOCK_VALUE,
         enterprise_no)
      values
        (strWAREHOUSE_NO,
         i_Content_Info.OWNER_NO,
         i_Content_Info.dept_no,
         SEQ_stock_CONTENT.nextval,
         substr(strPAPER_NO, 1, 2),
         strPAPER_NO,
         strTERMINAL_FLAG,
         i_Content_Info.article_no,
         i_Content_Info.ARTICLE_ID,
         strCELL_NO,
         i_Content_Info.LABEL_NO,
         i_Content_Info.Cell_Id,
         i_Content_Info.Qty,
         i_Content_Info.Instock_Qty,
         i_Content_Info.Outstock_Qty,
         strR_cell_no,
         'O',
         nQty,
         struser_id,
         sysdate,
         i_Content_Info.Stock_Type,
         i_Content_Info.Stock_Value,
         strEnterPriseNo);
      -------------------把来源储位预下库存回单
      UPDATE stock_content
         SET qty = qty - nQty, updt_date = sysdate, updt_name = strUser_id
       where enterprise_no = strEnterPriseNo
         and WAREHOUSE_NO = strWAREHOUSE_NO
         and cell_no = strCell_No
         and CELL_ID = strCell_Id
         AND QTY - nQty >= 0;

      ---------修改记录为0行------------
      if sql%notfound then
        strOutMsg := 'N|[E00386]{' || strCell_No || '}{' || strCell_Id || '}';
        return;
      end if;
    end loop;
    -----------删除库存为0的记录------------------------
    delete stock_content
     where enterprise_no = strEnterPriseNo
       and WAREHOUSE_NO = WAREHOUSE_NO
       and cell_no = strCell_No
       and qty = 0
       and instock_qty = 0
       and outstock_qty = 0
       and UNUSUAL_QTY = 0;

    if n_count <= 0 then
      strOutMsg := 'N|[E00619]';
      return;
    end if;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end p_UpdtContentByCellID;

  /*转换库存STOCK_TYPE,STOCK_VALUE*/
  procedure p_TransContent_qtyByCellID(strEnterPriseNo in stock_content.enterprise_no%type, -- 企业编号
                                       strWAREHOUSE_NO in stock_content.WAREHOUSE_NO%type, --仓库编码
                                       strCell_No      in stock_content.cell_no%type, --储位
                                       nSCell_ID       in stock_content.cell_id%type, --储位ID
                                       nQTY            IN stock_content.qty%type, --数量
                                       strStock_type   in stock_content.stock_type%type, --存储类型
                                       strStock_value  in stock_content.stock_value%type, --对应存储值
                                       strUser_ID      in bdef_defworker.worker_no%type,
                                       nDCell_ID       out stock_content.cell_id%type, --新储位ID
                                       strOutMsg       out varchar2) --返回 执行结果
   is
    v_Cell_ID stock_content.cell_id%type; --储位id
  begin

    strOutMsg := 'N|[p_TransContent_qtyByCellID]';

    update stock_content t
       set t.updt_date = sysdate
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWAREHOUSE_NO
       and t.cell_no = strCell_No
       and t.qty - nvl(t.outstock_qty, 0) >= nQTY
       and t.cell_id = nSCell_ID;

    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E00386]';
      return;
    end if;

    select SEQ_stock_CONTENT.nextval into v_Cell_ID from dual;
    nDCell_ID := v_Cell_ID;

    insert into stock_content
      (enterprise_no,
       WAREHOUSE_NO,
       owner_no,
       dept_no,
       cell_no,
       cell_id,
       ARTICLE_NO,
       ARTICLE_ID,
       PACKING_QTY,
       qty,
       outstock_qty,
       instock_qty,
       unusual_qty,
       rgst_name,
       rgst_date,
       UPDT_NAME,
       UPDT_DATE,
       status,
       flag,
       instock_type,
       stock_type,
       stock_VALUE,
       Label_No,
       sub_label_no,
       Mv_hand_flag)
      select t.enterprise_no,
             t.warehouse_no,
             t.owner_no,
             t.dept_no,
             t.cell_no,
             v_Cell_ID,
             t.article_no,
             t.article_id,
             t.packing_qty,
             nQty,
             0,
             0,
             0,
             struser_id,
             sysdate,
             struser_id,
             sysdate,
             t.status,
             t.flag,
             t.instock_type,
             strstock_type,
             strstock_value,
             t.label_no,
             sub_label_no,
             t.mv_hand_flag
        from stock_content t
       where t.warehouse_no = strWAREHOUSE_NO
         and t.cell_no = strCell_No
         and t.cell_id = nSCell_ID
         and t.qty - nvl(t.outstock_qty, 0) >= nqty;

    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E00007]';
      return;
    end if;

    update stock_content t
       set t.qty       = t.qty - nQTY,
           t.updt_name = strUser_ID,
           t.updt_date = sysdate
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWAREHOUSE_NO
       and t.cell_no = strCell_No
       and t.cell_id = nSCell_ID;

    delete stock_content t
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWAREHOUSE_NO
       and t.cell_no = strCell_No
       and t.cell_id = nSCell_ID
       and t.qty = 0
       and t.outstock_qty = 0
       and t.instock_qty = 0;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_TransContent_qtyByCellID;

  /*****************************************************************************************
     功能：增加目的库存 没有预上数量
    Modify By luozhiling AT 2013-09-28
  *****************************************************************************************/
  procedure p_InstContent_qtyByCellNo(strEnterPriseNo  in stock_content.enterprise_no%type, -- 企业编号
                                      strWAREHOUSE_NO  in stock_content.WAREHOUSE_NO%type, --仓库编码
                                      strOwner_No      in stock_content.Owner_No%type, --委托业主
                                      strDeptNo        in stock_content.dept_no%type, --部门编码
                                      strArticle_no    in stock_content.article_no%type, --商品编号
                                      nArticle_id      in stock_content.article_id%type, --商品属性ID
                                      strCell_no       in stock_content.cell_no%type, --储位
                                      strR_cell_no     in stock_content.cell_no%type, --关系储位
                                      nPacking_Qty     in stock_content.Packing_Qty%type, --商品包装
                                      nQty             in stock_content.qty%type, --数量
                                      strlabel_no      in stock_content.label_no%type, --标签号
                                      strsub_label_no  in stock_content.sub_label_no%type, --子标签号
                                      strStock_type    in stock_content.stock_type%type, --存储类型
                                      strStock_value   in stock_content.stock_value%type, --对应存储值
                                      strUser_id       in stock_content.Rgst_Name%type, --操作人员
                                      strPAPER_NO      in stock_content_move.PAPER_NO%type, --操作单号
                                      strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                                      nMvHandFlag      in stock_content.mv_hand_flag%type, --是否可手工移库 0:不允许手工移库；1：可手工移库
                                      nOutCellID       out stock_content.cell_id%type, --返回的储位ID
                                      strOutMsg        out varchar2) --返回 执行结果
   is
    n_cell_id      stock_content.cell_id%type; --储位id
    n_outstock_qty stock_content.outstock_qty%type; --预下数量
    n_instock_qty  stock_content.instock_qty%type; --预上数量
    n_s_qty        stock_content.qty%type; --原来数量
  begin
    strOutMsg := 'N|[p_InstContent_qtyByCellNo]';

    begin
      --处理目的容器库存-
      -----------获取目的容器库存，储位ID-------------------
      select cell_id, outstock_qty, instock_qty, qty
        into n_cell_id, n_outstock_qty, n_instock_qty, n_s_qty
        from stock_content sc
       where sc.enterprise_no = strEnterPriseNo
         and sc.WAREHOUSE_NO = strWAREHOUSE_NO
         and sc.Owner_No = strOwner_No
         and sc.article_no = strarticle_no
         and sc.article_id = narticle_id
         and sc.cell_no = strCell_No
         and sc.Packing_Qty = nPacking_Qty
         and sc.label_no = strlabel_no
         and sc.Flag = '0'
         and sc.mv_hand_flag = nMvHandFlag
         and sc.instock_type = '0'
         and sc.stock_type = strStock_type
         and sc.stock_value = strStock_value
         and rownum = 1;
      -----------找到储位ID--------------------------------
      if (n_cell_id > 0) then
        ------------------添加储位三级账----------------------------
        insert into stock_content_move
          (WAREHOUSE_NO,
           OWNER_NO,
           DEPT_NO,
           /*           ROW_ID,  */
           PAPER_TYPE,
           PAPER_NO,
           TERMINAL_FLAG,
           ARTICLE_NO,
           ARTICLE_ID,
           CELL_NO,
           LABEL_NO,
           CELL_ID,
           FIRST_QTY,
           FIRST_INSTOCK_QTY,
           FIRST_OUTSTOCK_QTY,
           R_CELL_NO,
           IO_FLAG,
           MOVE_QTY,
           RGST_NAME,
           RGST_DATE,
           STOCK_TYPE,
           STOCK_VALUE,
           enterprise_no)
        values
          (strWAREHOUSE_NO,
           strOWNER_NO,
           strDeptNo,
           /*           SEQ_stock_CONTENT.nextval,*/
           substr(strPAPER_NO, 1, 2),
           strPAPER_NO,
           strTERMINAL_FLAG,
           strarticle_no,
           nARTICLE_ID,
           strCELL_NO,
           strlabel_no,
           n_cell_id,
           n_s_qty,
           n_instock_qty,
           n_outstock_qty,
           strR_cell_no,
           'I',
           nQty,
           struser_id,
           sysdate,
           strStock_Type,
           strStock_Value,
           strEnterPriseNo);
        ----------------------------------增加目的储位库存数量-----------------------------
        update stock_content sc
           set sc.qty       = sc.qty + nQty,
               sc.updt_name = strUSER_ID,
               sc.updt_date = sysdate
         where sc.enterprise_no = strEnterPriseNo
           and sc.WAREHOUSE_NO = STRWAREHOUSE_NO
           and sc.owner_no = strOwner_No
           and SC.cell_NO = strCell_no
           and sc.cell_id = n_cell_id;
        -----------------------------------修改记录为0行------------------------
        if sql%notfound then
          strOutMsg := 'N|[E00007]';
          return;
        end if;
      end if;
      ----------------------------没找到，新增一条库存记录-------------------
    exception
      when no_data_found then
        --------------------------获取储位ID----------------
        select SEQ_stock_CONTENT.nextval into n_cell_id from dual;
        ----------------------添加储位三级账----------------------------
        insert into stock_content_move
          (WAREHOUSE_NO,
           OWNER_NO,
           DEPT_NO,
           ROW_ID,
           PAPER_TYPE,
           PAPER_NO,
           TERMINAL_FLAG,
           ARTICLE_NO,
           ARTICLE_ID,
           CELL_NO,
           LABEL_NO,
           CELL_ID,
           FIRST_QTY,
           FIRST_INSTOCK_QTY,
           FIRST_OUTSTOCK_QTY,
           R_CELL_NO,
           IO_FLAG,
           MOVE_QTY,
           RGST_NAME,
           RGST_DATE,
           STOCK_TYPE,
           STOCK_VALUE,
           enterprise_no)
        values
          (strWAREHOUSE_NO,
           strOWNER_NO,
           strDeptNo,
           SEQ_stock_CONTENT.nextval,
           substr(strPAPER_NO, 1, 2),
           strPAPER_NO,
           strTERMINAL_FLAG,
           strarticle_no,
           nARTICLE_ID,
           strCELL_NO,
           strlabel_no,
           n_cell_id,
           0,
           0,
           0,
           strR_cell_no,
           'I',
           nQty,
           struser_id,
           sysdate,
           strStock_Type,
           strStock_Value,
           strEnterPriseNo);
        ------------------------新增一笔库存记录-------------------------------------
        insert into stock_content
          (enterprise_no,
           WAREHOUSE_NO,
           owner_no,
           dept_no,
           cell_no,
           cell_id,
           ARTICLE_NO,
           ARTICLE_ID,
           PACKING_QTY,
           qty,
           outstock_qty,
           instock_qty,
           unusual_qty,
           rgst_name,
           rgst_date,
           UPDT_NAME,
           UPDT_DATE,
           status,
           flag,
           instock_type,
           stock_type,
           stock_VALUE,
           Label_No,
           Mv_hand_flag,
           sub_label_no)
        values
          (strEnterPriseNo,
           strWAREHOUSE_NO,
           strOwner_No,
           strDeptNo,
           strCell_No,
           n_cell_id,
           strArticle_No,
           nArticle_Id,
           nPacking_Qty,
           nQty,
           0,
           0,
           0,
           strUSER_ID,
           sysdate,
           strUSER_ID,
           sysdate,
           0,
           0,
           0,
           strStock_Type,
           strStock_Value,
           strlabel_no,
           nMvHandFlag,
           strsub_label_no);
        -----------------------新增记录为0行----------------------
        if sql%notfound then
          strOutMsg := 'N|[E00008]{' || strArticle_No || '}{' || strCell_No || '}';
          return;
        end if;
    end;

    --------删除库存表qty为0的记录--------------
    delete stock_content sc
     where sc.enterprise_no = strEnterPriseNo
       and sc.WAREHOUSE_NO = strWAREHOUSE_NO
       and sc.cell_no = strCell_No
       and sc.qty = 0
       and sc.instock_qty = 0
       and sc.outstock_qty = 0
       and sc.UNUSUAL_QTY = 0;

    nOutCellID := n_cell_id;
    strOutMsg  := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end p_InstContent_qtyByCellNo;

  /*****************************************************************************************
     功能：增加目的库存  带cell_ID，有预上数量
    Modify By luozhiling AT 2013-09-28
  *****************************************************************************************/
  procedure p_InstContent_qtyByCellID(strEnterPriseNo  in stock_content.enterprise_no%type, -- 企业编号
                                      strWAREHOUSE_NO  in stock_content.WAREHOUSE_NO%type, --仓库编码
                                      strcell_id       in stock_content.cell_id%type, --储位ID
                                      strcell_no       in stock_content.cell_no%type, --储位
                                      strR_cell_no     in stock_content.cell_no%type, --关系储位
                                      nQty             in stock_content.qty%type, --数量
                                      ninstock_qty     in stock_content.instock_qty%type, --预上数量
                                      strUser_id       in stock_content.Rgst_Name%type, --操作人员
                                      strPAPER_NO      in stock_content_move.PAPER_NO%type, --操作单号
                                      strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                                      strOutMsg        out varchar2) --返回 执行结果
   is
    n_count number(10); --记录数，以做判断;
  begin
    strOutMsg := 'N|[p_InstContent_qtyByCellID]';
    n_count   := 0;

    for i_Content_Info in (select *
                             from stock_content cc
                            where cc.enterprise_no = strEnterPriseNo
                              and cc.WAREHOUSE_NO = strWAREHOUSE_NO
                              and cc.cell_no = strCell_No
                              and cc.cell_id = strcell_id) loop
      n_count := 1;

      ----------------------储位三级账--------
      insert into stock_content_move
        (WAREHOUSE_NO,
         OWNER_NO,
         DEPT_NO,
         ROW_ID,
         PAPER_TYPE,
         PAPER_NO,
         TERMINAL_FLAG,
         ARTICLE_NO,
         ARTICLE_ID,
         CELL_NO,
         LABEL_NO,
         CELL_ID,
         FIRST_QTY,
         FIRST_INSTOCK_QTY,
         FIRST_OUTSTOCK_QTY,
         R_CELL_NO,
         IO_FLAG,
         MOVE_QTY,
         RGST_NAME,
         RGST_DATE,
         STOCK_TYPE,
         STOCK_VALUE,
         enterprise_no)
      values
        (strWAREHOUSE_NO,
         i_Content_Info.OWNER_NO,
         i_Content_Info.dept_no,
         SEQ_stock_CONTENT.nextval,
         substr(strPAPER_NO, 1, 2),
         strPAPER_NO,
         strTERMINAL_FLAG,
         i_Content_Info.article_no,
         i_Content_Info.ARTICLE_ID,
         strCELL_NO,
         i_Content_Info.LABEL_NO,
         i_Content_Info.Cell_Id,
         i_Content_Info.Qty,
         i_Content_Info.Instock_Qty,
         i_Content_Info.Outstock_Qty,
         strR_cell_no,
         'I',
         nQty,
         struser_id,
         sysdate,
         i_Content_Info.Stock_Type,
         i_Content_Info.Stock_Value,
         strEnterPriseNo);

      -------------------把来源储位预下库存回单
      UPDATE stock_content
         SET qty          = qty + nQty,
             instock_qty  = instock_qty - ninstock_qty,
             instock_type = '0',
             updt_date    = sysdate,
             updt_name    = strUser_id
       where enterprise_no = strEnterPriseNo
         and WAREHOUSE_NO = strWAREHOUSE_NO
         and cell_no = strCell_No
         and CELL_ID = strCell_Id
         and instock_qty - ninstock_qty >= 0;

      ---------修改记录为0行------------
      if sql%notfound then
        strOutMsg := 'N|[E00386]{' || i_Content_Info.article_no || '}{' ||
                     strCell_No || '}{' || strCell_Id || '}';
        return;
      end if;
    end loop;

    -----------删除库存为0的记录------------------------
    delete stock_content
     where enterprise_no = strEnterPriseNo
       and WAREHOUSE_NO = WAREHOUSE_NO
       and cell_no = strCell_No
       and qty = 0
       and instock_qty = 0
       and outstock_qty = 0
       and UNUSUAL_QTY = 0;

    if n_count <= 0 then
      strOutMsg := 'N|[E00619]';
      return;
    end if;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end p_InstContent_qtyByCellID;

  /*****************************************************************************************
     功能：更新库存表的container_no,label_no
    Modify By luozhiling AT 2013-09-29,
    首先判断该标签是否有预上、下数量，若有需要先剥离有预约数量的库存，再转换库存
  *****************************************************************************************/
  procedure p_UpdtContent_ContainerNo(strEnterPriseNo   in stock_content.enterprise_no%type, -- 企业编号
                                      strWAREHOUSE_NO   in stock_content.WAREHOUSE_NO%type, --仓库编码
                                      strNewLabel_no    in stock_content.label_no%type, --新标签号
                                      strNewSupLabel_no in stock_content.sub_label_no%type, --新子标签号
                                      strCellNo         in stock_content.cell_no%type,
                                      nCellId           in stock_content.cell_id%type, --CellId
                                      strUser_id        in stock_content.Rgst_Name%type, --操作人员
                                      nOutcellId        out stock_content.cell_id%type,
                                      strOutMsg         out varchar2) is
    --返回 执行结果
    v_nInstockQty  stock_content.qty%type;
    v_nOutStockQty stock_content.qty%type;
    v_nQty         stock_content.qty%type;
    n_cell_id      stock_content.cell_id%type;
  begin
    strOutMsg := 'N|[p_UpdtContent_ContainerNo]';

    select instock_qty, outstock_qty, qty
      into v_nInstockQty, v_nOutStockQty, v_nQty
      from stock_content
     where enterprise_no = strEnterPriseNo
       and warehouse_no = strWAREHOUSE_NO
       and cell_no = strCellNo
       and cell_id = nCellId;

    if v_nInstockQty > 0 or v_nOutStockQty > 0 then
      --若有预上预下数量，需要剥离库存

      --------------------------获取储位ID----------------
      select SEQ_stock_CONTENT.nextval into n_cell_id from dual;
      nOutcellId := n_cell_id;

      --新增标签库存
      insert into stock_content
        (enterprise_no,
         WAREHOUSE_NO,
         owner_no,
         dept_no,
         cell_no,
         cell_id,
         ARTICLE_NO,
         ARTICLE_ID,
         PACKING_QTY,
         qty,
         outstock_qty,
         instock_qty,
         unusual_qty,
         status,
         flag,
         instock_type,
         stock_type,
         stock_VALUE,
         Label_No,
         Mv_hand_flag,
         sub_label_no,
         rgst_name,
         rgst_date,
         UPDT_NAME,
         UPDT_DATE)
        select t.enterprise_no,
               t.WAREHOUSE_NO,
               t.owner_no,
               t.dept_no,
               t.cell_no,
               n_cell_id,
               t.ARTICLE_NO,
               t.ARTICLE_ID,
               t.PACKING_QTY,
               v_nQty,
               0,
               0,
               t.unusual_qty,
               t.status,
               t.flag,
               t.instock_type,
               t.stock_type,
               t.stock_VALUE,
               strNewLabel_no,
               t.Mv_hand_flag,
               strNewSupLabel_no,
               t.rgst_name,
               t.rgst_date,
               t.UPDT_NAME,
               t.UPDT_DATE
          from stock_content t
         where t.enterprise_no = strEnterPriseNo
           and t.warehouse_no = strWAREHOUSE_NO
           and t.cell_no = strCellNo
           and t.cell_id = nCellId;

      --扣减原库存
      update stock_content t
         set t.qty = t.qty - v_nQty
       where t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strWAREHOUSE_NO
         and t.cell_no = strCellNo
         and t.cell_id = nCellId;
      ----------------修改记录为0行------------
      if sql%notfound then
        strOutMsg := 'N|[E00386]{' || strCellNo || '}';
        return;
      end if;

      -- 删除库存为0的数据
      delete from stock_content t
       where t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strWAREHOUSE_NO
         and t.cell_no = strCellNo
         and t.cell_id = nCellId
         and t.qty = 0
         and t.outstock_qty = 0
         and t.instock_qty = 0;
    else

      update stock_content sc
         set sc.label_no     = strNewLabel_no,
             sc.sub_label_no = strNewSupLabel_no,
             sc.UPDT_NAME    = strUser_id,
             sc.UPDT_DATE    = sysdate
       where sc.enterprise_no = strEnterPriseNo
         and sc.WAREHOUSE_NO = strWAREHOUSE_NO
         and sc.cell_no = strCellNo
         and sc.cell_id = nCellId;
      ----------------修改记录为0行------------
      if sql%notfound then
        strOutMsg := 'N|[E00386]{' || strCellNo || '}';
        return;
      end if;

      -- 删除库存为0的数据
      delete from stock_content t
       where t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strWAREHOUSE_NO
         and t.cell_no = strCellNo
         and t.cell_id = nCellId
         and t.qty = 0
         and t.outstock_qty = 0
         and t.instock_qty = 0;

      nOutcellId := nCellId;
    end if;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end p_UpdtContent_ContainerNo;

  /*****************************************************************************************
     功能：更新库存表的可移库标识
    Modify By luozhiling AT 2013-09-29
  *****************************************************************************************/
  procedure p_UpdtContent_Mvflag(strEnterPriseNo in stock_content.enterprise_no%type, -- 企业编号
                                 strWAREHOUSE_NO in stock_content.WAREHOUSE_NO%type, --仓库编码
                                 strCellNo       in stock_content.cell_no%type,
                                 nCellId         in stock_content.cell_id%type,
                                 strMvHandFlag   in stock_content.mv_hand_flag%type,
                                 strUser_id      in stock_content.Rgst_Name%type, --操作人员
                                 strOutMsg       out varchar2) --返回 执行结果
   is
  begin
    strOutMsg := 'N|[p_UpdtContent_Mvflag]';

    update stock_content sc
       set sc.mv_hand_flag = strMvHandFlag,
           updt_name       = strUser_id,
           updt_date       = sysdate
     where sc.enterprise_no = strEnterPriseNo
       and sc.WAREHOUSE_NO = strWAREHOUSE_NO
       and sc.cell_no = strCellNo
       and sc.cell_id = nCellId;
    ----------------修改记录为0行------------
    --有零回情况 不判断是否修改成功 huangb 20160819
    /*if sql%notfound then
      strOutMsg := 'N|[E00386]{' || strCellNo || '}{' || nCellId || '}';
      return;
    end if;*/
    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end p_UpdtContent_Mvflag;

  /*****************************************************************************************
     功能：写库存预上预下
    Modify By luozhiling AT 2013-09-29
  *****************************************************************************************/
  procedure p_UpdtContent_Reservation(strEnterPriseNo in stock_content.enterprise_no%type, -- 企业编号
                                      strWAREHOUSE_NO in stock_content.WAREHOUSE_NO%type, --仓库编码
                                      strS_Cell_no    in stock_content.cell_no%type, --来源储位
                                      strS_Cell_id    in stock_content.cell_id%type, --来源储位ID
                                      strD_cell_no    in stock_content.cell_no%type, --目的储位
                                      strD_Label_No   in stock_content.label_no%type,
                                      strSubLabelNo   in stock_content.sub_label_no%type, --子标签
                                      nQty            in stock_content.qty%type, --商品包装
                                      strInstock_type in stock_content.Instock_type%type, --存储类型
                                      strUser_id      in stock_content.Rgst_Name%type, --操作人员
                                      n_cell_id       in out stock_content.cell_id%type, --储位id
                                      strOutMsg       out varchar2) --返回 执行结果
   is
    n_outstock_qty stock_content.outstock_qty%type; --预下数量
    n_instock_qty  stock_content.instock_qty%type; --预上数量
  begin
    strOutMsg := 'N|[p_UpdtContent_Reservation]';
    -------------------写来源储位预下库存-------------------------------------------------------------
    UPDATE stock_content
       SET OUTSTOCK_QTY = OUTSTOCK_QTY + nQty,
           updt_date    = sysdate,
           updt_name    = strUser_ID
     where enterprise_no = strEnterPriseNo
       and WAREHOUSE_NO = strWAREHOUSE_NO
       and cell_no = strS_Cell_no
       and CELL_ID = strS_Cell_id
       AND QTY + INSTOCK_QTY + UNUSUAL_QTY - OUTSTOCK_QTY >= nQty;
    ---------修改记录为0行------------
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E00386]';
      return;
    end if;
    ------------------------处理目的储位预上库存-------------------------------------------------------------
    begin
      -----------获取目的容器库存，储位ID-------------------
      select cell_id, outstock_qty, instock_qty
        into n_cell_id, n_outstock_qty, n_instock_qty
        from stock_content cc
       where cc.enterprise_no = strEnterPriseNo
         and cc.WAREHOUSE_NO = strWAREHOUSE_NO
         and cc.cell_no = strD_cell_no
         and cc.instock_type = strInstock_type
         and cc.label_no = strD_Label_No
         and cc.sub_label_no = strSubLabelNo
         and exists (select 'x'
                from stock_content icc
               where icc.enterprise_no = strEnterPriseNo
                 and cc.warehouse_no = icc.warehouse_no
                 and cc.owner_no = icc.owner_no
                 and cc.dept_no = icc.dept_no
                 and cc.article_no = icc.article_no
                 and cc.article_id = icc.article_id
                 and cc.packing_qty = icc.packing_qty
                 and cc.flag = icc.flag
                 and cc.mv_hand_flag = icc.mv_hand_flag
                 and cc.stock_type = icc.stock_type
                 and cc.stock_value = icc.stock_value
                 and icc.WAREHOUSE_NO = strWAREHOUSE_NO
                 and icc.cell_no = strS_Cell_no
                 and icc.cell_id = strS_Cell_id)
         and rownum <= 1;

      -----------找到储位ID--------------------------------
      if (n_cell_id > 0) then
        ----------------------------------增加目的储位库存数量-----------------------------
        update stock_content cc
           set cc.instock_qty = cc.instock_qty + nQty,
               cc.updt_name   = strUSER_ID,
               cc.updt_date   = sysdate
         where cc.enterprise_no = strEnterPriseNo
           and cc.WAREHOUSE_NO = STRWAREHOUSE_NO
           and cc.cell_NO = strD_Cell_no
           and cc.cell_id = n_cell_id;
        -----------------------------------修改记录为0行------------------------
        if sql%notfound then
          strOutMsg := 'N|[E00007]';
          return;
        end if;
      end if;
      ----------------------------没找到，新增一条库存记录-------------------
    exception
      when no_data_found then
        --------------------------获取储位ID----------------
        select SEQ_stock_CONTENT.nextval into n_cell_id from dual;
        ------------------------新增一笔库存记录-------------------------------------
        insert into stock_content
          (enterprise_no,
           WAREHOUSE_NO,
           owner_no,
           dept_no,
           cell_no,
           cell_id,
           ARTICLE_NO,
           ARTICLE_ID,
           PACKING_QTY,
           qty,
           outstock_qty,
           instock_qty,
           unusual_qty,
           rgst_name,
           rgst_date,
           UPDT_NAME,
           UPDT_DATE,
           status,
           flag,
           instock_type,
           stock_type,
           stock_VALUE,
           Label_No,
           sub_label_no,
           mv_hand_flag)
          select strEnterPriseNo,
                 cc.WAREHOUSE_NO,
                 cc.Owner_No,
                 cc.Dept_no,
                 strD_cell_no,
                 n_cell_id,
                 cc.Article_No,
                 cc.Article_Id,
                 cc.Packing_Qty,
                 0,
                 0,
                 nQty,
                 0,
                 strUSER_ID,
                 sysdate,
                 strUSER_ID,
                 sysdate,
                 0,
                 0,
                 strInstock_type,
                 cc.Stock_Type,
                 cc.Stock_Value,
                 strD_Label_No,
                 strSubLabelNo,
                 cc.mv_hand_flag
            from stock_content cc
           where cc.enterprise_no = strEnterPriseNo
             and cc.WAREHOUSE_NO = strWAREHOUSE_NO
             and cc.cell_no = strS_Cell_no
             and cc.cell_id = strS_Cell_id;
        -----------------------新增记录为0行----------------------
        if sql%notfound then
          strOutMsg := 'N|[E00008]{' || strS_Cell_no || '}{' ||
                       strS_Cell_id || '}';
          return;
        end if;
    end;
    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end p_UpdtContent_Reservation;
  /*****************************************************************************************
     功能：根据下架明细扣减库存  （下架回单）
    Modify By yanJunFeng AT 2013-03-28
  *****************************************************************************************/
  procedure proc_OM_Receipt_WriteContent(strEnterPriseNo  in stock_content.enterprise_no%type, -- 企业编号
                                         strwarehouse_no  in stock_content.warehouse_no%type, --仓别
                                         strS_cell_id     in stock_content.cell_id%type, --来源储位ID
                                         strS_cell_no     in stock_content.cell_no%type, --来源储位
                                         strD_cell_id     in stock_content.cell_id%type, --来源储位ID
                                         strD_cell_no     in stock_content.cell_no%type, --来源储位
                                         nQty             in stock_content.qty%type, --数量
                                         nArticle_qty     in stock_content.qty%type, --预下数量
                                         strPAPER_NO      in stock_content_move.PAPER_NO%type, --操作单号
                                         strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                                         strUser_ID       in odata_outstock_m.rgst_name%type, --操作人员
                                         strOutMsg        out varchar2) --返回 执行结果
   is
  begin
    strOutMsg := 'N|[proc_OM_Receipt_WriteContent]';
    --------------------回写目的储位预上库存----------------------------------
    p_InstContent_qtyByCellID(strEnterPriseNo,
                              strwarehouse_no, --仓别
                              strD_cell_id, --储位ID
                              strD_cell_no, --储位
                              strS_cell_no, --关系储位
                              nQty, --数量
                              nArticle_qty, --预下数量
                              strUser_id, --操作人员
                              strPAPER_NO, --操作单号
                              strTERMINAL_FLAG, --操作设备
                              strOutMsg); --返回 执行结果
    if (substr(strOutMsg, 1, 1) <> 'Y') then
      return;
    end if;

    -----------删除库存为0的记录------------------------
    delete stock_content
     where enterprise_no = strEnterPriseNo
       and warehouse_no = strwarehouse_no
       and cell_no = strD_cell_no
          --and CELL_ID = strCell_Id
       and qty = 0
       and instock_qty = 0
       and outstock_qty = 0
       and UNUSUAL_QTY = 0;

    -------------------把来源储位预下库存回单-------------------------------
    p_UpdtContent_qtyByCellID(strEnterPriseNo,
                              strwarehouse_no, --仓别
                              strs_cell_id, --储位ID
                              strS_cell_no, --储位
                              strD_cell_no, --关系储位
                              nQty, --数量
                              nArticle_qty, --预下数量
                              strUser_id, --操作人员
                              strPAPER_NO, --操作单号
                              strTERMINAL_FLAG, --操作设备
                              strOutMsg); --返回 执行结果
    if (substr(strOutMsg, 1, 1) <> 'Y') then
      return;
    end if;

    -----------删除库存为0的记录------------------------
    delete stock_content
     where enterprise_no = strEnterPriseNo
       and warehouse_no = strwarehouse_no
       and cell_no = strS_cell_no
          --and CELL_ID = strCell_Id
       and qty = 0
       and instock_qty = 0
       and outstock_qty = 0
       and UNUSUAL_QTY = 0;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end proc_OM_Receipt_WriteContent;

  /*****************************************************************************************
       功能：根据标签，转移库存（表单回单转移目的容器号）
      Modify By luozhiling AT 2013-11-23
  *****************************************************************************************/
  procedure proc_OM_MoveContent_ByContenNo(strEnterPriseNo  in stock_content.enterprise_no%type, -- 企业编号
                                           strwarehouse_no  in stock_label_m.warehouse_no%type, --仓别
                                           strOustockNo     in stock_label_m.container_no%type, --来源容器
                                           nDivideID        IN stock_label_d.divide_id%type,
                                           strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                                           strUSER_ID       in stock_label_m.rgst_name%type, --员工ID
                                           strOutMsg        out varchar2) --是否成功
   is
    --n_count       number(10); --记录数，以做判断;
    n_Stock_Value stock_content.stock_value%type; --库别
    v_nCellID     stock_content.cell_id%type;
  begin
    --n_count   := 0;
    strOutMsg := 'N|[proc_OM_MoveContent_ByContenNo]';

    -------------------循环标签信息-------------------------------------------------------------
    for i_MoveLabel_Info in (select ood.*,
                                    lm.label_no as scan_label_no,
                                    lm.hm_manual_flag
                               from stock_label_m lm, odata_outstock_d ood
                              where lm.enterprise_no = ood.enterprise_no
                                and lm.warehouse_no = ood.warehouse_no
                                and lm.enterprise_no = strEnterPriseNo
                                and lm.warehouse_no = strwarehouse_no
                                and lm.containeR_no = ood.d_containeR_no
                                and ood.outstock_no = strOustockNo
                                and ood.divide_id = nDivideID
                                and ood.real_qty > 0) loop

      if (i_MoveLabel_Info.Stock_Type = 2) then
        --客户别数据 库存表需要写n_Stock_Value值
        n_Stock_Value := i_MoveLabel_Info.Cust_No;
      else
        n_Stock_Value := 'N';
      end if;
      --------------------------------处理目的容器库存------------------
      p_InstContent_qtyByCellNo(strEnterPriseNo,
                                i_MoveLabel_Info.warehouse_no, --仓别
                                i_MoveLabel_Info.Owner_No, --委托业主
                                'N',
                                i_MoveLabel_Info.Article_No, --商品编号
                                i_MoveLabel_Info.Article_Id, --商品属性ID
                                i_MoveLabel_Info.d_cell_no, --储位
                                i_MoveLabel_Info.d_cell_no, --关系储位
                                i_MoveLabel_Info.Packing_Qty, --商品包装
                                i_MoveLabel_Info.real_qty, --数量
                                i_MoveLabel_Info.scan_label_no, --标签号
                                i_MoveLabel_Info.scan_label_no, --标签号
                                i_MoveLabel_Info.Stock_Type, --存储类型
                                n_Stock_Value, --对应存储值
                                strUser_id, --操作人员
                                strOustockNo, --操作单号
                                strTERMINAL_FLAG, --操作设备
                                0, --是否可手工移库 0:不允许手工移库；1：可手工移库
                                v_nCellID,
                                strOutMsg); --返回 执行结果
      if (substr(strOutMsg, 1, 1) <> 'Y') then
        return;
      end if;

      p_UpdtContentByCellID(strEnterPriseNo,
                            i_MoveLabel_Info.warehouse_no,
                            i_MoveLabel_Info.d_cell_id,
                            i_MoveLabel_Info.d_cell_no,
                            i_MoveLabel_Info.d_cell_no,
                            i_MoveLabel_Info.real_qty,
                            strUser_id,
                            strOustockNo,
                            strTERMINAL_FLAG,
                            strOutMsg);
      /*      -----------处理来源容器库存----------------------------------
      p_UpdtContent_qtyByCellNo(i_MoveLabel_Info.warehouse_no, --仓别
                                i_MoveLabel_Info.Owner_No, --委托业主
                                i_MoveLabel_Info.Article_No, --商品编号
                                i_MoveLabel_Info.Article_Id, --商品属性ID
                                i_MoveLabel_Info.d_cell_no, --储位
                                i_MoveLabel_Info.d_cell_no, --关系储位
                                i_MoveLabel_Info.Packing_Qty, --商品包装
                                i_MoveLabel_Info.real_qty, --数量
                                'N', --商品容器号
                                --n_Label_no, --标签号
                                i_MoveLabel_Info.Stock_Type, --存储类型
                                n_Stock_Value, --对应存储值
                                strUser_id, --操作人员
                                strOustockNo, --操作单号
                                strTERMINAL_FLAG, --操作设备
                                strOutMsg); --返回 执行结果*/
      --会将要未分播的库存给当作此单的库存处理掉，导致不能分播回单

      if (substr(strOutMsg, 1, 1) <> 'Y') then
        return;
      end if;
    end loop;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end proc_OM_MoveContent_ByContenNo;

  /*****************************************************************************************
       功能：将分播的储位管理，转移到标签，目前用于直通分播单门店的转门店标签
         Modify By luozhiling AT 2015-12-5
  *****************************************************************************************/
  procedure proc_DivideCellToLabel(strEnterPriseNo  in stock_content.enterprise_no%type, -- 企业编号
                                   strwarehouse_no  in stock_label_m.warehouse_no%type, --仓别
                                   strSourceNo      in stock_label_m.source_no%type,
                                   nDivideID        IN stock_label_d.divide_id%type,
                                   strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                                   strUSER_ID       in stock_label_m.rgst_name%type, --员工ID
                                   strOutMsg        out varchar2) --是否成功
   is

    v_nCellID stock_content.cell_id%type;
  begin
    --n_count   := 0;
    strOutMsg := 'N|[proc_DivideCellToLabel]';

    -------------------循环标签信息-------------------------------------------------------------
    for i_MoveLabel_Info in (select ood.*,
                                    lm.label_no as scan_label_no,
                                    lm.hm_manual_flag
                               from stock_label_m       lm,
                                    odata_divide_direct ood
                              where lm.enterprise_no = ood.enterprise_no
                                and lm.warehouse_no = ood.warehouse_no
                                and lm.enterprise_no = strEnterPriseNo
                                and lm.warehouse_no = strwarehouse_no
                                and lm.containeR_no = ood.s_container_no
                                and ood.source_no = strSourceNo
                                and ood.divide_id = nDivideID) loop

      --------------------------------处理目的容器库存------------------
      p_InstContent_qtyByCellNo(strEnterPriseNo,
                                i_MoveLabel_Info.warehouse_no, --仓别
                                i_MoveLabel_Info.Owner_No, --委托业主
                                'N',
                                i_MoveLabel_Info.Article_No, --商品编号
                                i_MoveLabel_Info.Article_Id, --商品属性ID
                                i_MoveLabel_Info.s_cell_no, --储位
                                i_MoveLabel_Info.s_cell_no, --关系储位
                                i_MoveLabel_Info.Packing_Qty, --商品包装
                                i_MoveLabel_Info.article_qty, --数量
                                i_MoveLabel_Info.scan_label_no, --标签号
                                i_MoveLabel_Info.scan_label_no, --标签号
                                '1', --存储类型
                                'N', --对应存储值
                                strUser_id, --操作人员
                                strSourceNo, --操作单号
                                strTERMINAL_FLAG, --操作设备
                                0, --是否可手工移库 0:不允许手工移库；1：可手工移库
                                v_nCellID,
                                strOutMsg); --返回 执行结果
      if (substr(strOutMsg, 1, 1) <> 'Y') then
        return;
      end if;

      p_UpdtContentByCellID(strEnterPriseNo,
                            i_MoveLabel_Info.warehouse_no,
                            i_MoveLabel_Info.s_cell_id,
                            i_MoveLabel_Info.s_cell_no,
                            i_MoveLabel_Info.s_cell_no,
                            i_MoveLabel_Info.article_qty,
                            strUser_id,
                            strSourceNo,
                            strTERMINAL_FLAG,
                            strOutMsg);

      if (substr(strOutMsg, 1, 1) <> 'Y') then
        return;
      end if;
    end loop;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end proc_DivideCellToLabel;
  /*****************************************************************************************
       功能：封车，直接删除库存（封车使用）
      Modify By luozhiling AT 2013-11-20
  *****************************************************************************************/
  procedure proc_OM_deliver_DelContent(strEnterPriseNo  in stock_content.enterprise_no%type, -- 企业编号
                                       strwarehouse_no  in odata_loadpropose_m.warehouse_no%type, --仓别
                                       strLoadproposeNo in odata_loadpropose_m.loadpropose_no%type, --装车建议单
                                       strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                                       strUSER_ID       in stock_content_move.rgst_name%type, --员工ID
                                       strOutMsg        out varchar2) --是否成功
   is
  begin
    strOutMsg := 'N|[proc_OM_deliver_DelContent]';
    
     --循环写库存三级帐
    for GetDeliverItem in (select odm.owner_no,
                                  odd.enterprise_no,
                                  odd.warehouse_no,
                                  odd.exp_no,
                                  odd.article_no,
                                  odd.barcode,
                                  odd.packing_qty,
                                  odd.produce_date,
                                  odd.expire_date,
                                  odd.quality,
                                  odd.lot_no,
                                  odd.import_batch_no,
                                  odd.rsv_batch1,
                                  odd.rsv_batch2,
                                  odd.rsv_batch3,
                                  odd.rsv_batch4,
                                  odd.rsv_batch5,
                                  odd.rsv_batch6,
                                  odd.rsv_batch7,
                                  odd.rsv_batch8,
                                  sum(qty) qty
                             from odata_deliver_m odm, odata_deliver_d odd
                            where odm.enterprise_no = odd.enterprise_no
                              and odm.warehouse_no = odd.warehouse_no
                              and odm.deliver_no = odd.deliver_no
                              and odm.enterprise_no = strEnterpriseNo
                              and odm.warehouse_no = strwarehouse_no
                              and odm.loadpropose_no = strLoadproposeNo
                            group by odm.owner_no,
                                     odd.enterprise_no,
                                     odd.warehouse_no,
                                     odd.exp_no,
                                     odd.article_no,
                                     odd.barcode,
                                     odd.packing_qty,
                                     odd.produce_date,
                                     odd.expire_date,
                                     odd.quality,
                                     odd.lot_no,
                                     odd.import_batch_no,
                                     odd.rsv_batch1,
                                     odd.rsv_batch2,
                                     odd.rsv_batch3,
                                     odd.rsv_batch4,
                                     odd.rsv_batch5,
                                     odd.rsv_batch6,
                                     odd.rsv_batch7,
                                     odd.rsv_batch8) loop

      PKOBJ_STOCK.P_insertImportBatchStock(strEnterPriseNo,
                                           strwarehouse_no,
                                           GetDeliverItem.owner_no,
                                           'N',
                                           GetDeliverItem.article_no,
                                           GetDeliverItem.quality,
                                           GetDeliverItem.import_batch_no,
                                           GetDeliverItem.produce_date,
                                           GetDeliverItem.expire_date,
                                           GetDeliverItem.lot_no,
                                           GetDeliverItem.rsv_batch1,
                                           GetDeliverItem.rsv_batch2,
                                           GetDeliverItem.rsv_batch3,
                                           GetDeliverItem.rsv_batch4,
                                           GetDeliverItem.rsv_batch5,
                                           GetDeliverItem.rsv_batch6,
                                           GetDeliverItem.rsv_batch7,
                                           GetDeliverItem.rsv_batch8,
                                           GetDeliverItem.barcode,
                                           GetDeliverItem.packing_qty,
                                           -GetDeliverItem.qty,
                                           '1',
                                           'N',
                                           strUSER_ID,
                                           strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      pkobj_stock.P_InsertArticleStockList(strEnterPriseNo,
                                           strwarehouse_no,
                                           GetDeliverItem.owner_no,
                                           'N',
                                           GetDeliverItem.article_no,
                                           GetDeliverItem.quality,
                                           GetDeliverItem.produce_date,
                                           GetDeliverItem.expire_date,
                                           GetDeliverItem.lot_no,
                                           GetDeliverItem.rsv_batch1,
                                           GetDeliverItem.rsv_batch2,
                                           GetDeliverItem.rsv_batch3,
                                           GetDeliverItem.rsv_batch4,
                                           GetDeliverItem.rsv_batch5,
                                           GetDeliverItem.rsv_batch6,
                                           GetDeliverItem.rsv_batch7,
                                           GetDeliverItem.rsv_batch8,
                                           GetDeliverItem.barcode,
                                           GetDeliverItem.packing_qty,
                                           -GetDeliverItem.qty,
                                           '1',
                                           'n',
                                           2,
                                           'O',
                                           GetDeliverItem.exp_no,
                                           strUSER_ID,
                                           GetDeliverItem.import_batch_no,
                                           strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

    end loop;

    ----------------------------直接删除库存--------------------------------------------------------
    delete stock_content cc
     where cc.enterprise_no = strEnterPriseNo
       and cc.warehouse_no = strwarehouse_no
       and (cc.cell_no, cc.label_no) in
           (select distinct lm.owner_cell_no, lm.label_no
              from odata_loadpropose_d ld
             inner join stock_label_m lm
                on lm.warehouse_no = ld.warehouse_no
               and lm.enterprise_no = ld.enterprise_no
               and lm.owner_container_no = ld.container_no
             where ld.warehouse_no = strwarehouse_no
               and ld.loadpropose_no = strLoadproposeNo
               and lm.enterprise_no = strEnterPriseNo)
       and qty > 0
       and cc.instock_qty = 0
       and cc.outstock_qty = 0;
    if sql%notfound then
      strOutMsg := 'N|[E00842]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end proc_OM_deliver_DelContent;
  ---------------------------------------------------------【出货end】---------------------------------------------
  /*
  作者:luozhiling
   日期:  2013-11-23
   功能: 盘点结案写库存
  */
  procedure P_fcdata_insetStock(strEnterPriseNo in stock_content.enterprise_no%type, -- 企业编号
                                strWareHouseNo  in fcdata_check_m.warehouse_no%type, --仓别
                                strOwner_no     in fcdata_check_m.owner_no%type, --委托业主编码
                                strCheckNo      in fcdata_check_m.plan_no%type, --计划单号
                                strWorkerNo     in fcdata_check_m.rgst_name%type, --操作人
                                v_iCount        out varchar2,
                                strResult       out varchar2) is
    articleId     stock_content.article_id%type; --返回articleid
    inTotal       stock_content.qty%type; --记录差异量
    inTmp         stock_content.qty%type; --扣减中转量
    v_iCount1     integer;
    intEXPIRYDAYS integer;
    v_nCellID     stock_content.cell_id%type;
    v_price       stock_article_info.price%type;
    Cursor v_GetCheckItem is
      select fcd.cell_no,
             fcd.owner_no,
             fcd.barcode,
             fcd.article_no,
             fcd.packing_qty,
             fcd.produce_date,
             fcd.expire_date,
             fcd.quality,
             fcd.lot_no,
             fcd.rsv_batch1,
             fcd.rsv_batch2,
             fcd.rsv_batch3,
             fcd.rsv_batch4,
             fcd.rsv_batch5,
             fcd.rsv_batch6,
             fcd.rsv_batch7,
             fcd.rsv_batch8,
             fcd.label_no,
             fcd.add_flag,
             fcd.stock_type,
             fcd.stock_value,
             fcd.sub_label_no,
             fcd.dept_no,
             sum(fcd.real_qty - fcd.article_qty) check_qty
        from fcdata_check_d fcd
       where fcd.enterprise_no = strEnterPriseNo
         and fcd.warehouse_no = strWareHouseNo
         and fcd.article_no <> 'N'
         and fcd.check_no = strCheckNo
         and fcd.real_qty <> fcd.article_qty
       group by fcd.cell_no,
                fcd.owner_no,
                fcd.barcode,
                fcd.article_no,
                fcd.packing_qty,
                fcd.produce_date,
                fcd.expire_date,
                fcd.quality,
                fcd.lot_no,
                fcd.rsv_batch1,
                fcd.rsv_batch2,
                fcd.rsv_batch3,
                fcd.rsv_batch4,
                fcd.rsv_batch5,
                fcd.rsv_batch6,
                fcd.rsv_batch7,
                fcd.rsv_batch8,
                fcd.label_no,
                fcd.add_flag,
                fcd.stock_type,
                fcd.stock_value,
                fcd.sub_label_no,
                fcd.dept_no
       order by fcd.cell_no, fcd.label_no, fcd.article_no;
  begin
    strResult := 'N|[P_fcdata_insetStock]';
    v_iCount  := '0';
    v_iCount1 := 0;

    --读取有差异的库存
    for GetCheckItem in v_GetCheckItem loop
      v_iCount := '1';
      --新增或盘盈
      if GetCheckItem.add_flag = 1 or GetCheckItem.check_qty > 0 then
        --是否存在批号
        select count(*)
          into v_iCount1
          from stock_article_info
         where article_no = GetCheckItem.article_no
           and Barcode = GetCheckItem.barcode
           and lot_no = GetCheckItem.lot_no
           and produce_date = GetCheckItem.produce_date
           and expire_date = GetCheckItem.expire_date
           and quality = GetCheckItem.quality
           and import_batch_no = strCheckNo
           and enterprise_no = strEnterPriseNo;

        --取该商品在商品属性表id最大的单价，没有则给0
        begin
          select info.price
            into v_price
            from stock_article_info info
           where info.enterprise_no = strEnterPriseNo
             and info.article_no = GetCheckItem.article_no
             and info.article_id =
                 (select distinct max(article_id)
                    from stock_article_info
                   where article_no = GetCheckItem.article_no
                     and enterprise_no = strEnterPriseNo);
        exception
          when no_data_found then
            v_price := 0;
        end;

        --设置商品属性表
        articleId := 0;
        pklg_wms_base.p_getArticleID(strEnterPriseNo,
                                     GetCheckItem.article_no,
                                     GetCheckItem.barcode,
                                     GetCheckItem.lot_no,
                                     GetCheckItem.produce_date,
                                     GetCheckItem.expire_date,
                                     --GetCheckItem.item_type,
                                     GetCheckItem.quality,
                                     --GetCheckItem.batch_serial_no,
                                     --'N',
                                     GetCheckItem.Rsv_Batch1,
                                     GetCheckItem.Rsv_Batch2,
                                     GetCheckItem.Rsv_Batch3,
                                     GetCheckItem.Rsv_Batch4,
                                     GetCheckItem.Rsv_Batch5,
                                     GetCheckItem.Rsv_Batch6,
                                     GetCheckItem.Rsv_Batch7,
                                     GetCheckItem.Rsv_Batch8,
                                     strCheckNo,
                                     '0',
                                     strWorkerNo,
                                     v_price,
                                     articleId,
                                     strResult);
        if (substr(strResult, 1, 1) <> 'Y') then
          return;
        end if;

        pkobj_stock.p_InstContent_fcqtyByCellNo(strEnterPriseNo,
                                                strWareHouseNo,
                                                GetCheckItem.Owner_No,
                                                'N',
                                                GetCheckItem.article_no,
                                                articleId,
                                                GetCheckItem.cell_no,
                                                GetCheckItem.cell_no,
                                                GetCheckItem.packing_qty,
                                                GetCheckItem.check_qty,
                                                GetCheckItem.label_no,
                                                GetCheckItem.sub_label_no,
                                                GetCheckItem.stock_type,
                                                GetCheckItem.stock_value,
                                                strWorkerNo,
                                                strCheckNo,
                                                '1',
                                                case when
                                                GetCheckItem.label_no = 'N' then '1' else '0' end,
                                                v_nCellID,
                                                strResult);

        if (substr(strResult, 1, 1) <> 'Y') then
          return;
        end if;

        --写商品批次库存帐
        pkobj_stock.P_insertImportBatchStock(strEnterPriseNo,
                                             strWareHouseNo,
                                             GetCheckItem.Owner_No,
                                             GetCheckItem.dept_no,
                                             GetCheckItem.article_no,
                                             GetCheckItem.quality,
                                             strCheckNo,
                                             GetCheckItem.produce_date,
                                             GetCheckItem.expire_date,
                                             GetCheckItem.lot_no,
                                             GetCheckItem.rsv_batch1,
                                             GetCheckItem.rsv_batch2,
                                             GetCheckItem.rsv_batch3,
                                             GetCheckItem.rsv_batch4,
                                             GetCheckItem.rsv_batch5,
                                             GetCheckItem.rsv_batch6,
                                             GetCheckItem.rsv_batch7,
                                             GetCheckItem.rsv_batch8,
                                             GetCheckItem.barcode,
                                             GetCheckItem.packing_qty,
                                             GetCheckItem.check_qty,
                                             GetCheckItem.stock_type,
                                             GetCheckItem.stock_value,
                                             strWorkerNo,
                                             strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        --写库存三级帐
        pkobj_stock.P_InsertArticleStockList(strEnterPriseNo,
                                             strWareHouseNo,
                                             GetCheckItem.Owner_No,
                                             GetCheckItem.dept_no,
                                             GetCheckItem.article_no,
                                             GetCheckItem.quality,
                                             GetCheckItem.produce_date,
                                             GetCheckItem.expire_date,
                                             GetCheckItem.lot_no,
                                             GetCheckItem.rsv_batch1,
                                             GetCheckItem.rsv_batch2,
                                             GetCheckItem.rsv_batch3,
                                             GetCheckItem.rsv_batch4,
                                             GetCheckItem.rsv_batch5,
                                             GetCheckItem.rsv_batch6,
                                             GetCheckItem.rsv_batch7,
                                             GetCheckItem.rsv_batch8,
                                             GetCheckItem.barcode,
                                             GetCheckItem.packing_qty,
                                             GetCheckItem.check_qty,
                                             GetCheckItem.stock_type,
                                             GetCheckItem.stock_value,
                                             1,
                                             'FC',
                                             strCheckNo,
                                             strWorkerNo,
                                             strCheckNo,
                                             strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

      else
        --盘亏
        inTotal := -GetCheckItem.check_qty;
        inTmp   := 0;
        --取有库存的储位
        for con in (select art.article_id,
                           con.qty,
                           con.cell_id,
                           art.import_batch_no
                      from stock_content con
                     inner join stock_article_info art
                        on con.article_id = art.article_id
                       and con.article_no = art.article_no
                       and con.enterprise_no = art.enterprise_no
                     where con.qty > 0
                       and con.enterprise_no = strEnterPriseNo
                       and con.warehouse_no = strWareHouseNo
                       and con.owner_no = GetCheckItem.Owner_No
                       and con.cell_no = GetCheckItem.cell_no
                       and con.article_no = GetCheckItem.article_no
                       and con.packing_qty = GetCheckItem.packing_qty
                       and con.stock_type = GetCheckItem.stock_type
                       and con.stock_value = GetCheckItem.stock_value
                       and art.lot_no = GetCheckItem.lot_no
                       and art.produce_date = GetCheckItem.produce_date
                       and art.expire_date = GetCheckItem.expire_date
                          -- and art.quality = GetCheckItem.quality
                       and art.barcode = GetCheckItem.barcode
                          --and art.item_type = GetCheckItem.item_type
                          --and art.Batch_Serial_No =
                          --    GetCheckItem.batch_serial_no
                       and con.label_no = GetCheckItem.label_no) loop

          if inTotal < con.qty then
            inTmp   := inTotal;
            inTotal := 0;
          else
            inTotal := inTotal - con.qty;
            inTmp   := con.qty;
          end if;
          p_UpdtContentByCellID(strEnterPriseNo,
                                strWareHouseNo,
                                con.cell_id,
                                GetCheckItem.cell_no,
                                GetCheckItem.cell_no,
                                inTmp,
                                strWorkerNo,
                                strCheckNo,
                                '1',
                                strResult);

          if (substr(strResult, 1, 1) <> 'Y') then
            return;
          end if;

          --写商品批次库存帐
          pkobj_stock.P_insertImportBatchStock(strEnterPriseNo,
                                               strWareHouseNo,
                                               GetCheckItem.Owner_No,
                                               GetCheckItem.dept_no,
                                               GetCheckItem.article_no,
                                               GetCheckItem.quality,
                                               con.import_batch_no,
                                               GetCheckItem.produce_date,
                                               GetCheckItem.expire_date,
                                               GetCheckItem.lot_no,
                                               GetCheckItem.rsv_batch1,
                                               GetCheckItem.rsv_batch2,
                                               GetCheckItem.rsv_batch3,
                                               GetCheckItem.rsv_batch4,
                                               GetCheckItem.rsv_batch5,
                                               GetCheckItem.rsv_batch6,
                                               GetCheckItem.rsv_batch7,
                                               GetCheckItem.rsv_batch8,
                                               GetCheckItem.barcode,
                                               GetCheckItem.packing_qty,
                                               -inTmp,
                                               GetCheckItem.stock_type,
                                               GetCheckItem.stock_value,
                                               strWorkerNo,
                                               strResult);

          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;

          --写库存三级帐
          pkobj_stock.P_InsertArticleStockList(strEnterPriseNo,
                                               strWareHouseNo,
                                               GetCheckItem.Owner_No,
                                               GetCheckItem.dept_no,
                                               GetCheckItem.article_no,
                                               GetCheckItem.quality,
                                               GetCheckItem.produce_date,
                                               GetCheckItem.expire_date,
                                               GetCheckItem.lot_no,
                                               GetCheckItem.rsv_batch1,
                                               GetCheckItem.rsv_batch2,
                                               GetCheckItem.rsv_batch3,
                                               GetCheckItem.rsv_batch4,
                                               GetCheckItem.rsv_batch5,
                                               GetCheckItem.rsv_batch6,
                                               GetCheckItem.rsv_batch7,
                                               GetCheckItem.rsv_batch8,
                                               GetCheckItem.barcode,
                                               GetCheckItem.packing_qty,
                                               -inTmp,
                                               GetCheckItem.stock_type,
                                               GetCheckItem.stock_value,
                                               1,
                                               'FC',
                                               strCheckNo,
                                               strWorkerNo,
                                               con.import_batch_no,
                                               strResult);

          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;

          if inTotal = 0 then
            exit;
          end if;
        end loop;
      end if;
    end loop;

    --删除货主与储位的对应关系
    delete from stock_owner_cell t
     where (t.enterprise_no, t.warehouse_no, t.owner_no, t.cell_no) in
           (select fcd.enterprise_no,
                   fcd.warehouse_no,
                   fcd.owner_no,
                   fcd.cell_no
              from fcdata_check_d fcd
             where fcd.enterprise_no = strEnterPriseNo
               and fcd.warehouse_no = strWareHouseNo
               and fcd.check_no = strCheckNo);

    insert into stock_owner_cell
      (enterprise_no, warehouse_no, owner_no, cell_no, updt_date)
      select distinct fcd.enterprise_no,
                      fcd.warehouse_no,
                      fcd.owner_no,
                      fcd.cell_no,
                      sysdate
        from fcdata_check_d fcd
       where fcd.enterprise_no = strEnterPriseNo
         and fcd.warehouse_no = strWareHouseNo
         and fcd.check_no = strCheckNo
         and fcd.article_no <> 'N';

    --删除商品与储位的对应关系
    delete from stock_art_cell t
     where (t.enterprise_no, t.warehouse_no, t.article_no, t.cell_no) in
           (select fcd.enterprise_no,
                   fcd.warehouse_no,
                   fcd.article_no,
                   fcd.cell_no
              from fcdata_check_d fcd
             where fcd.enterprise_no = strEnterPriseNo
               and fcd.warehouse_no = strWareHouseNo
               and fcd.check_no = strCheckNo);

    insert into stock_art_cell
      (enterprise_no, warehouse_no, article_no, cell_no, updt_date)
      select distinct fcd.enterprise_no,
                      fcd.warehouse_no,
                      fcd.article_no,
                      fcd.cell_no,
                      sysdate
        from fcdata_check_d fcd
       where fcd.enterprise_no = strEnterPriseNo
         and fcd.warehouse_no = strWareHouseNo
         and fcd.check_no = strCheckNo
         and fcd.article_no <> 'N';

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_fcdata_insetStock;
  --  ---------------------------------------------------------[返配库存处理】------------------------------------------
  --
  --  /***********************************************************************************************************
  --    功能：根据验收汇总单增加暂存区库存  返配验收封板
  --   作者：luozhiling
  --   日期：2013-11-15
  --  ***************************************************************************************************************/

  procedure p_Ridata_InsertSCheckStock(strEnterPriseNo    in stock_content.enterprise_no%type, -- 企业编号
                                       strWareHouseNo     in ridata_check_pal.warehouse_no%type, --仓别
                                       strScheckNo        in ridata_check_m.s_check_no%type, --汇总验收单号
                                       strTools           in stock_content_move.terminal_flag%type, --操作设备
                                       strUser_ID         in ridata_check_m.Rgst_Name%type, --操作人员
                                       strLocateNo        in ridata_locate_direct.locate_no%type,
                                       strspecify_cell_no IN ridata_locate_direct.specify_cell_no%type, --指定储位
                                       strOutMsg          out varchar2) --返回 执行结果
   is

    cursor v_GetCheckPal is
      select icd.*,
             icp.batch_no,
             icp.wave_no,
             icp.sub_label_no,
             icp.label_no,
             icp.containeR_no,
             icp.dock_no,
             icp.printer_group_no,
             icp.check_row_id,
             iim.untread_type,
             iim.class_type,
             icp.quality as quality_flag
        from ridata_check_pal icp,
             ridata_check_m   icm,
             ridata_check_d   icd,
             ridata_untread_m iim
       where icm.warehouse_no = icp.warehouse_no
         and icm.enterprise_no = icp.enterprise_no
         and icm.enterprise_no = icd.enterprise_no
         and icm.warehouse_no = icd.warehouse_no
         and icm.enterprise_no = iim.enterprise_no
         and icm.owner_no = icp.owner_no
         and icm.owner_no = icd.owner_no
         and icm.check_no = icd.check_no
         and icm.check_no = icp.check_no
         and iim.warehouse_no = icm.warehouse_no
         and iim.owner_no = icm.owner_no
         and iim.untread_no = icm.untread_no
         and icm.enterprise_no = strEnterPriseNo
         and icm.warehouse_no = strWareHouseNo
         and icm.s_check_no = strScheckNo
         and icd.row_id = icp.check_row_id
         and icd.article_no = icp.article_no --add by luozhiling 20160813
         and icp.status = '10'
       order by icp.label_no, icp.sub_label_no;

    strCellNo    stock_content.cell_no%type; --暂存区储位
    v_nArticleId stock_content.article_id%type; --商品属性ID
    n_count      number(10); --记录数，以做判断;
    v_nCellID    stock_content.cell_id%type;
  begin
    n_count   := 0;
    strOutMsg := 'N|[p_Ridata_InsertSCheckStock]';

    --获取暂存区储位 注：这里和程序中取暂存区(方法GetSpecialAreaCellNo)对应.别随意动
    begin
      select cell_no
        into strCellNo
        from (select CDC.CELL_NO
                FROM Cdef_DEFAREA CDA, Cdef_DEFCELL CDC
               WHERE cda.enterprise_no = cdc.enterprise_no
                 and CDA.warehouse_no = CDC.warehouse_no
                 AND CDA.WARE_NO = CDC.WARE_NO
                 AND CDA.AREA_NO = CDC.AREA_NO
                 AND CDA.AREA_ATTRIBUTE = '1' --暂存区
                 and CDA.AREA_USETYPE = '1' --普通区
                 AND (CDA.ATTRIBUTE_TYPE = '1' OR CDA.ATTRIBUTE_TYPE = '0') --进货区或者存储区
                 and cdc.cell_status = '0'
                 and cdc.check_status = '0'
                 and cdc.warehouse_no = strWareHouseNo
                 and cda.enterprise_no = strEnterPriseNo
               ORDER BY CDA.ATTRIBUTE_TYPE DESC, CDC.cell_no)
       where rownum < 2;
    exception
      when no_data_found then
        strOutMsg := 'N|[E00100]';
        return;
    end;

    --循环板明细添加标签信息
    for GetCheckPal in v_GetCheckPal loop
      n_count := 1; --判断是否进了循环

      --获取商品属性ID
      PKLG_WMS_BASE.p_getArticleID(strEnterPriseNo,
                                   GetCheckPal.article_no,
                                   GetCheckPal.barcode,
                                   GetCheckPal.lot_no,
                                   GetCheckPal.Produce_Date,
                                   GetCheckPal.expire_date,
                                   '0',
                                   GetCheckPal.rsv_batch1,
                                   GetCheckPal.rsv_batch2,
                                   GetCheckPal.rsv_batch3,
                                   GetCheckPal.rsv_batch4,
                                   GetCheckPal.rsv_batch5,
                                   GetCheckPal.rsv_batch6,
                                   GetCheckPal.rsv_batch7,
                                   GetCheckPal.rsv_batch8,
                                   GetCheckPal.check_no,
                                   '0',
                                   strUser_ID,
                                   GetCheckPal.Price,
                                   v_nArticleId,
                                   strOutMsg);

      if (substr(strOutMsg, 1, 1) <> 'Y') then
        return;
      end if;

      --增加目的储位库存
      PKobj_stock.p_InstContent_qtyByCellNo(strEnterPriseNo,
                                            strWareHouseNo,
                                            GetCheckPal.owner_no,
                                            GetCheckPal.dept_no,
                                            GetCheckPal.article_no,
                                            v_nArticleId,
                                            strCellNo,
                                            strCellNo,
                                            GetCheckPal.packing_qty,
                                            GetCheckPal.check_qty,
                                            GetCheckPal.label_no,
                                            GetCheckPal.sub_label_no,
                                            GetCheckPal.stock_type,
                                            GetCheckPal.stock_value,
                                            strUser_ID,
                                            strScheckNo,
                                            strTools,
                                            '0',
                                            v_nCellID,
                                            strOutMsg);

      if (substr(strOutMsg, 1, 1) <> 'Y') then
        return;
      end if;

      --写入库定位指示
      insert into ridata_locate_direct
        (enterprise_no,
         warehouse_no,
         owner_no,
         locate_no,
         auto_locate_flag,
         source_no,
         cell_no,
         cell_id,
         operate_type,
         article_no,
         article_id,
         packing_qty,
         qty,
         dock_no,
         printer_group_no,
         exclude_cell_no,
         status,
         sub_label_no,
         label_no,
         rgst_name,
         rgst_date,
         specify_cell_no,
         wave_no,
         batch_no,
         supplier_no,
         operate_date,
         quality_flag,
         untread_type,
         class_type)
        select strEnterPriseNo,
               strWareHouseNo,
               GetCheckPal.owner_no,
               strLocateNo,
               '1',
               strScheckNo,
               strCellNo,
               t.cell_id,
               'P',
               GetCheckPal.article_no,
               v_nArticleId,
               GetCheckPal.packing_qty,
               t.qty,
               GetCheckPal.dock_no,
               GetCheckPal.printer_group_no,
               'N',
               '10',
               GetCheckPal.sub_label_no,
               GetCheckPal.label_no,
               strUser_ID,
               sysdate,
               strspecify_cell_no,
               GetCheckPal.wave_no,
               GetCheckPal.batch_no,
               GetCheckPal.supplier_no,
               trunc(sysdate),
               GetCheckPal.quality_flag,
               GetCheckPal.untread_type,
               GetCheckPal.class_type
          from stock_content t
         where t.warehouse_no = strWareHouseNo
           and t.enterprise_no = strEnterPriseNo
           AND t.owner_no = GetCheckPal.owner_no
           and t.cell_no = strCellNo
           and t.article_no = GetCheckPal.article_no
           and t.article_id = v_nArticleId
           AND t.packing_qty = GetCheckPal.packing_qty
           and t.stock_type = GetCheckPal.stock_type
           and t.stock_value = GetCheckPal.stock_value
           and t.label_no = GetCheckPal.sub_label_no;

      --更新板明细状态
      update Ridata_check_pal icp
         set icp.status    = '13',
             icp.updt_name = strUser_ID,
             icp.updt_date = sysdate
       where icp.enterprise_no = strEnterPriseNo
         and icp.warehouse_no = strWareHouseNo
         and icp.owner_no = GetCheckPal.owner_no
         AND icp.check_no = GetCheckPal.check_no
         and icp.check_row_id = GetCheckPal.check_row_id
         and icp.container_no = GetCheckPal.container_no
         and icp.label_no = GetCheckPal.label_no
         and icp.sub_label_no = GetCheckPal.sub_label_no;

      if sql%notfound then
        strOutMsg := 'N|[E24201]';
        return;
      end if;
    end loop;

    if (n_count <= 0) then
      strOutMsg := 'N|[E24202]';
      return;
    end if;
    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_Ridata_InsertSCheckStock;

  --  ---------------------------------------------------------[返配库存处理】------------------------------------------
  --
  --  /***********************************************************************************************************
  --    功能：根据验收板号增加暂存区库存  返配验收封板
  --   作者：luozhiling
  --   日期：2013-11-15
  --  ***************************************************************************************************************/

  procedure p_Ridata_InsertPalStock(strEnterPriseNo in stock_content.enterprise_no%type, -- 企业编号
                                    strWareHouseNo  in ridata_check_pal.warehouse_no%type, --仓别
                                    strLabelNo      in ridata_check_pal.label_no%type, --汇总验收单号
                                    strTools        in stock_content_move.terminal_flag%type, --操作设备
                                    strUser_ID      in ridata_check_m.Rgst_Name%type, --操作人员
                                    strLocateNo     in ridata_locate_direct.locate_no%type,
                                    strDestCellNo   in cdef_defcell.cell_no%type,
                                    strOutMsg       out varchar2) --返回 执行结果
   is

    cursor v_GetCheckPal is
      select iim.untread_type,
             iim.class_type,
             icm.s_check_no,
             icm.check_no,
             icd.supplier_no,
             icm.owner_no,
             icd.dept_no,
             icp.check_qty,
             icd.article_no,
             icd.barcode,
             icd.packing_qty,
             icd.lot_no,
             icd.produce_date,
             icd.expire_date,
             icd.quality,
             icd.rsv_batch1,
             icd.rsv_batch2,
             icd.rsv_batch3,
             icd.rsv_batch4,
             icd.rsv_batch5,
             icd.rsv_batch6,
             icd.rsv_batch7,
             icd.rsv_batch8,
             icd.price,
             icd.stock_type,
             icd.stock_value,
             icp.sub_label_no,
             icp.containeR_no,
             icp.dock_no,
             icp.printer_group_no,
             icp.check_row_id,
             icp.batch_no,
             icp.cell_no,
             icp.WAVE_NO,
             icp.quality quality_flag
        from ridata_check_pal icp,
             ridata_check_m   icm,
             ridata_check_d   icd,
             ridata_untread_m iim
       where icm.enterprise_no = icp.enterprise_no
         and icm.enterprise_no = icd.enterprise_no
         and icm.enterprise_no = iim.enterprise_no
         and icm.warehouse_no = icp.warehouse_no
         and icm.warehouse_no = icd.warehouse_no
         and icm.owner_no = icp.owner_no
         and icm.owner_no = icd.owner_no
         and icm.check_no = icd.check_no
         and icm.check_no = icp.check_no
         and iim.warehouse_no = icm.warehouse_no
         and iim.owner_no = icm.owner_no
         and iim.untread_no = icm.untread_no
         and icm.enterprise_no = strEnterPriseNo
         and icm.warehouse_no = strWareHouseNo
         and icp.label_no = strLabelNo
         and icd.row_id = icp.check_row_id
         and icp.status = '10'
       order by icp.check_no, icp.article_no;

    strCellNo       stock_content.cell_no%type; --暂存区储位
    v_nArticleId    stock_content.article_id%type; --商品属性ID
    n_count         number(10); --记录数，以做判断;
    v_nCellID       stock_content.cell_id%type;
    v_strDestCellNo cdef_defcell.cell_no%type;
  begin
    n_count   := 0;
    strOutMsg := 'N|[p_Ridata_InsertPalStock]';

    --获取暂存区储位 注：这里和程序中取暂存区(方法GetSpecialAreaCellNo)对应.别随意动
    begin
      select cell_no
        into strCellNo
        from (select CDC.CELL_NO
                FROM Cdef_DEFAREA CDA, Cdef_DEFCELL CDC
               WHERE cda.enterprise_no = cdc.enterprise_no
                 and CDA.warehouse_no = CDC.warehouse_no
                 AND CDA.WARE_NO = CDC.WARE_NO
                 AND CDA.AREA_NO = CDC.AREA_NO
                 AND CDA.AREA_ATTRIBUTE = '1' --暂存区
                 and CDA.AREA_USETYPE = '1' --普通区
                 and cda.area_attribute = '1'
                 AND (CDA.ATTRIBUTE_TYPE = '1' OR CDA.ATTRIBUTE_TYPE = '0') --进货区或者存储区
                 and cdc.cell_status = '0'
                 and cdc.check_status = '0'
                 and cda.enterprise_no = strEnterPriseNo
                 and cdc.warehouse_no = strWareHouseNo
               ORDER BY CDA.ATTRIBUTE_TYPE DESC, CDC.cell_no)
       where rownum < 2;
    exception
      when no_data_found then
        strOutMsg := 'N|[E00100]';
        return;
    end;

    --循环板明细添加标签信息
    for GetCheckPal in v_GetCheckPal loop
      n_count := 1; --判断是否进了循环

      --获取商品属性ID
      PKLG_WMS_BASE.p_getArticleID(strEnterPriseNo,
                                   GetCheckPal.article_no,
                                   GetCheckPal.barcode,
                                   GetCheckPal.lot_no,
                                   GetCheckPal.Produce_Date,
                                   GetCheckPal.expire_date,
                                   GetCheckPal.quality,
                                   GetCheckPal.rsv_batch1,
                                   GetCheckPal.rsv_batch2,
                                   GetCheckPal.rsv_batch3,
                                   GetCheckPal.rsv_batch4,
                                   GetCheckPal.rsv_batch5,
                                   GetCheckPal.rsv_batch6,
                                   GetCheckPal.rsv_batch7,
                                   GetCheckPal.rsv_batch8,
                                   GetCheckPal.check_no,
                                   '0',
                                   strUser_ID,
                                   GetCheckPal.Price,
                                   v_nArticleId,
                                   strOutMsg);

      if (substr(strOutMsg, 1, 1) <> 'Y') then
        return;
      end if;

      --增加目的储位库存
      PKobj_stock.p_InstContent_qtyByCellNo(strEnterPriseNo,
                                            strWareHouseNo,
                                            GetCheckPal.owner_no,
                                            GetCheckPal.dept_no,
                                            GetCheckPal.article_no,
                                            v_nArticleId,
                                            strCellNo,
                                            strCellNo,
                                            GetCheckPal.packing_qty,
                                            GetCheckPal.check_qty,
                                            strLabelNo,
                                            GetCheckPal.sub_label_no,
                                            GetCheckPal.stock_type,
                                            GetCheckPal.stock_value,
                                            strUser_ID,
                                            GetCheckPal.s_check_no,
                                            strTools,
                                            '0',
                                            v_nCellID,
                                            strOutMsg);

      if (substr(strOutMsg, 1, 1) <> 'Y') then
        return;
      end if;

      if strDestCellNo <> 'N' then
        v_strDestCellNo := strDestCellNo;
      else
        v_strDestCellNo := GetCheckPal.cell_no;
      end if;

      --写入库定位指示
      insert into ridata_locate_direct
        (enterprise_no,
         warehouse_no,
         owner_no,
         locate_no,
         auto_locate_flag,
         source_no,
         cell_no,
         cell_id,
         operate_type,
         article_no,
         article_id,
         packing_qty,
         qty,
         dock_no,
         printer_group_no,
         exclude_cell_no,
         status,
         sub_label_no,
         label_no,
         rgst_name,
         rgst_date,
         specify_cell_no,
         wave_no,
         batch_no,
         supplier_no,
         operate_date,
         quality_flag,
         untread_type,
         class_type)
        select strEnterPriseNo,
               strWareHouseNo,
               GetCheckPal.owner_no,
               strLocateNo,
               '1',
               GetCheckPal.s_check_no,
               strCellNo,
               t.cell_id,
               'P',
               GetCheckPal.article_no,
               v_nArticleId,
               GetCheckPal.packing_qty,
               t.qty,
               GetCheckPal.dock_no,
               GetCheckPal.printer_group_no,
               'N',
               '10',
               GetCheckPal.sub_label_no,
               strLabelNo,
               strUser_ID,
               sysdate,
               v_strDestCellNo,
               GetCheckPal.wave_no,
               GetCheckPal.batch_no,
               GetCheckPal.supplier_no,
               trunc(sysdate),
               GetCheckPal.quality_flag,
               GetCheckPal.untread_type,
               GetCheckPal.class_type
          from stock_content t
         where t.enterprise_no = strEnterPriseNo
           and t.warehouse_no = strWareHouseNo
           AND t.owner_no = GetCheckPal.owner_no
           and t.cell_no = strCellNo
           and t.article_no = GetCheckPal.article_no
           and t.article_id = v_nArticleId
           AND t.packing_qty = GetCheckPal.packing_qty
           and t.stock_type = GetCheckPal.stock_type
           and t.stock_value = GetCheckPal.stock_value
           and t.label_no = GetCheckPal.sub_label_no;

      --更新板明细状态
      update Ridata_check_pal icp
         set icp.status    = '13',
             icp.updt_name = strUser_ID,
             icp.updt_date = sysdate
       where icp.enterprise_no = strEnterPriseNo
         and icp.warehouse_no = strWareHouseNo
         and icp.owner_no = GetCheckPal.owner_no
         AND icp.check_no = GetCheckPal.check_no
         and icp.check_row_id = GetCheckPal.check_row_id
         and icp.container_no = GetCheckPal.container_no
         and icp.label_no = strLabelNo
         and icp.sub_label_no = GetCheckPal.sub_label_no;

      if sql%notfound then
        strOutMsg := 'N|[E24201]';
        return;
      end if;
    end loop;

    if (n_count <= 0) then
      strOutMsg := 'N|[E24202]';
      return;
    end if;
    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_Ridata_InsertPalStock;

  /**********************************************************************************************************
  MM
  2014.4.17
  功能：写进出帐表
  ***********************************************************************************************************/
  procedure P_stock_Insertaccount(strEnterPriseNo in stock_content.enterprise_no%type, -- 企业编号
                                  strWareHouseNo  in fcdata_check_m.warehouse_no%type, --仓库编码
                                  strOwnerNo      in fcdata_check_m.owner_no%type,
                                  strPlanNo       in fcdata_check_m.plan_no%type, --盘点计划单号
                                  strUserId       in fcdata_plan_m.rgst_name%type,
                                  strResult       OUT varchar2) is
    v_strPlanType fcdata_request_m.plan_type%type;
  begin
    strResult := 'N|P_stock_Insertaccount';

    --写进出帐表
    insert into STOCK_ACCOUNT
      (enterprise_no,
       warehouse_no,
       owner_no,
       paper_no,
       article_no,
       packing_qty,
       dept_no,
       barcode,
       produce_date,
       expire_date,
       quality,
       lot_no,
       rsv_batch1,
       rsv_batch2,
       rsv_batch3,
       rsv_batch4,
       rsv_batch5,
       rsv_batch6,
       rsv_batch7,
       rsv_batch8,
       stock_type,
       stock_value,
       change_qty,
       rgst_name,
       rgst_date)
      select strEnterPriseNo,
             m.warehouse_no,
             d.owner_no,
             m.check_no,
             d.article_no,
             d.packing_qty,
             'N',
             d.barcode,
             d.produce_date,
             d.expire_date,
             d.quality,
             d.lot_no,
             d.rsv_batch1,
             d.rsv_batch2,
             d.rsv_batch3,
             d.rsv_batch4,
             d.rsv_batch5,
             d.rsv_batch6,
             d.rsv_batch7,
             d.rsv_batch8,
             d.stock_type,
             d.stock_value,
             sum(real_qty - d.article_qty),
             strUserId,
             sysdate
        from fcdata_check_d d, fcdata_check_m m
       where d.enterprise_no = m.enterprise_no
         and d.warehouse_no = m.warehouse_no
            --and d.owner_no = m.owner_no
         and d.check_no = m.check_no
         and m.plan_no = strPlanNo
         and m.owner_no = strOwnerNo
         and m.enterprise_no = strEnterPriseNo
         and m.warehouse_no = strWareHouseNo
         and d.article_no <> 'N'
         and article_qty - real_qty <> 0
       group by m.enterprise_no,
                m.warehouse_no,
                d.owner_no,
                m.check_no,
                d.article_no,
                d.packing_qty,
                'N',
                d.barcode,
                d.produce_date,
                d.expire_date,
                d.quality,
                d.lot_no,
                d.rsv_batch1,
                d.rsv_batch2,
                d.rsv_batch3,
                d.rsv_batch4,
                d.rsv_batch5,
                d.rsv_batch6,
                d.rsv_batch7,
                d.rsv_batch8,
                d.stock_type,
                d.stock_value;

    --if (sql%rowcount <= 0) then
    --    strResult := 'N|[E30024]';
    --    return;
    --end if;

    strResult := 'Y|';

  end P_stock_Insertaccount;
  /*****************************************************************************************
     功能：上架回单，分两步更新库存
    Modify By lich AT 2014-05-15
  *****************************************************************************************/
  procedure p_UpdtInstContent_Qty(strEnterPriseNo  in stock_content.enterprise_no%type, -- 企业编号
                                  strWAREHOUSE_NO  in stock_content.WAREHOUSE_NO%type, --仓库编码
                                  strcell_id       in stock_content.cell_id%type, --储位ID
                                  strcell_no       in stock_content.cell_no%type, --储位
                                  strR_cell_no     in stock_content.cell_no%type, --关系储位
                                  nQty             in stock_content.qty%type, --数量
                                  ninstock_qty     in stock_content.instock_qty%type, --预上数量
                                  strUser_id       in stock_content.Rgst_Name%type, --操作人员
                                  strPAPER_NO      in stock_content_move.PAPER_NO%type, --操作单号
                                  strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                                  nOutCellId       out stock_content.cell_id%type,
                                  strOutMsg        out varchar2) --返回 执行结果
   is
    n_count number(10); --记录数，以做判断;

  begin
    strOutMsg := 'N|[p_UpdtInstContent_Qty]';
    n_count   := 0;

    for i_Content_Info in (select *
                             from stock_content cc
                            where cc.enterprise_no = strEnterPriseNo
                              and cc.WAREHOUSE_NO = strWAREHOUSE_NO
                              and cc.cell_no = strCell_No
                              and cc.cell_id = strcell_id) loop
      n_count := 1;

      ----------------------储位三级账--------
      insert into stock_content_move
        (WAREHOUSE_NO,
         OWNER_NO,
         DEPT_NO,
         ROW_ID,
         PAPER_TYPE,
         PAPER_NO,
         TERMINAL_FLAG,
         ARTICLE_NO,
         ARTICLE_ID,
         CELL_NO,
         LABEL_NO,
         CELL_ID,
         FIRST_QTY,
         FIRST_INSTOCK_QTY,
         FIRST_OUTSTOCK_QTY,
         R_CELL_NO,
         IO_FLAG,
         MOVE_QTY,
         RGST_NAME,
         RGST_DATE,
         STOCK_TYPE,
         STOCK_VALUE,
         enterprise_no)
      values
        (strWAREHOUSE_NO,
         i_Content_Info.OWNER_NO,
         i_Content_Info.dept_no,
         SEQ_stock_CONTENT.nextval,
         substr(strPAPER_NO, 1, 2),
         strPAPER_NO,
         strTERMINAL_FLAG,
         i_Content_Info.article_no,
         i_Content_Info.ARTICLE_ID,
         strCELL_NO,
         i_Content_Info.LABEL_NO,
         i_Content_Info.Cell_Id,
         i_Content_Info.Qty,
         i_Content_Info.Instock_Qty,
         i_Content_Info.Outstock_Qty,
         strR_cell_no,
         'I',
         nQty,
         struser_id,
         sysdate,
         i_Content_Info.Stock_Type,
         i_Content_Info.Stock_Value,
         strEnterPriseNo);

      ------------------修改来源储位预上库存------------------------
      UPDATE stock_content
         SET instock_qty  = instock_qty - ninstock_qty,
             instock_type = '0',
             updt_date    = sysdate,
             updt_name    = strUser_id
       where enterprise_no = strEnterPriseNo
         and WAREHOUSE_NO = strWAREHOUSE_NO
         and cell_no = strCell_No
         and CELL_ID = strCell_Id
         and instock_qty - ninstock_qty >= 0;

      ------------------修改记录为0行--------------------------------
      if sql%notfound then
        strOutMsg := 'N|[E00386]{' || i_Content_Info.article_no || '}{' ||
                     strCell_No || '}{' || strCell_Id || '}';
        return;
      end if;

      -----------删除库存为0的记录------------------------
      delete stock_content
       where enterprise_no = strEnterPriseNo
         and WAREHOUSE_NO = strWAREHOUSE_NO
         and cell_no = strCell_No
         and qty = 0
         and instock_qty = 0
         and outstock_qty = 0
         and UNUSUAL_QTY = 0;

      if nQty > 0 then

        --------------------------获取Cell_ID----------------
        select SEQ_stock_CONTENT.nextval into nOutCellId from dual;
        ----------------------添加储位三级账----------------------------
        insert into stock_content_move
          (WAREHOUSE_NO,
           OWNER_NO,
           DEPT_NO,
           ROW_ID,
           PAPER_TYPE,
           PAPER_NO,
           TERMINAL_FLAG,
           ARTICLE_NO,
           ARTICLE_ID,
           CELL_NO,
           LABEL_NO,
           CELL_ID,
           FIRST_QTY,
           FIRST_INSTOCK_QTY,
           FIRST_OUTSTOCK_QTY,
           R_CELL_NO,
           IO_FLAG,
           MOVE_QTY,
           RGST_NAME,
           RGST_DATE,
           STOCK_TYPE,
           STOCK_VALUE,
           enterprise_no)
        values
          (strWAREHOUSE_NO,
           i_Content_Info.OWNER_NO,
           i_Content_Info.dept_no,
           SEQ_stock_CONTENT.nextval,
           substr(strPAPER_NO, 1, 2),
           strPAPER_NO,
           strTERMINAL_FLAG,
           i_Content_Info.article_no,
           i_Content_Info.ARTICLE_ID,
           strCELL_NO,
           i_Content_Info.LABEL_NO,
           nOutCellId,
           0,
           0,
           0,
           strR_cell_no,
           'I',
           nQty,
           struser_id,
           sysdate,
           i_Content_Info.Stock_Type,
           i_Content_Info.Stock_Value,
           strEnterPriseNo);
        ------------------------新增一笔库存记录-------------------------------------
        insert into stock_content
          (enterprise_no,
           WAREHOUSE_NO,
           owner_no,
           dept_no,
           cell_no,
           cell_id,
           ARTICLE_NO,
           ARTICLE_ID,
           PACKING_QTY,
           qty,
           outstock_qty,
           instock_qty,
           unusual_qty,
           rgst_name,
           rgst_date,
           UPDT_NAME,
           UPDT_DATE,
           status,
           flag,
           instock_type,
           stock_type,
           stock_VALUE,
           Label_No,
           Mv_hand_flag,
           sub_label_no)
        values
          (strEnterPriseNo,
           strWAREHOUSE_NO,
           i_Content_Info.Owner_No,
           i_Content_Info.Dept_No,
           strCell_No,
           nOutCellId,
           i_Content_Info.Article_No,
           i_Content_Info.Article_Id,
           i_Content_Info.Packing_Qty,
           nQty,
           0,
           0,
           0,
           strUSER_ID,
           sysdate,
           strUSER_ID,
           sysdate,
           0,
           0,
           0,
           i_Content_Info.Stock_Type,
           i_Content_Info.Stock_Value,
           i_Content_Info.Label_No,
           i_Content_Info.Mv_Hand_Flag,
           i_Content_Info.Sub_Label_No);
        -----------------------新增记录为0行----------------------
        if sql%notfound then
          strOutMsg := 'N|[E00008]{' || i_Content_Info.Article_No || '}{' ||
                       strCell_No || '}';
          return;
        end if;
      end if;
    end loop;

    if n_count <= 0 then
      strOutMsg := 'N|[E00619]';
      return;
    end if;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end p_UpdtInstContent_Qty;

  /*****************************************************************************************************
    功能：根据验收明细增加暂存区库存  进货验收封板
   作者：luozhiling
   日期：2013-11-25
  *******************************************************************************************************/

  procedure p_Idata_InsertIdStockItem(strEnterPriseNo in stock_content.enterprise_no%type, -- 企业编号
                                      strWareHouseNo  in idata_check_pal.warehouse_no%type, --仓别
                                      strScheckNo     in idata_check_pal.s_check_no%type, --汇总验收单号
                                      strArticleNo    in idata_check_pal.article_no%type,
                                      strContainerNo  in idata_check_pal.container_no%type,
                                      strBarcode      in idata_check_d.barcode%type,
                                      strLotNo        in idata_check_d.lot_no%type,
                                      dtProduceDate   in idata_check_d.produce_date%type,
                                      dtExpireDate    in idata_check_d.expire_date%type,
                                      strQuality      in idata_check_d.quality%type,
                                      nArticleId      in stock_content.article_id%type,
                                      nPackingQty     in stock_content.packing_qty%type,
                                      nRowId          in idata_check_d.row_id%type,
                                      CheckQty        in idata_check_d.check_qty%type,
                                      strCheckNo      in idata_check_pal.check_no%type,
                                      strTools        in stock_content_move.terminal_flag%type, --操作设备
                                      strUser_ID      in idata_check_pal.Rgst_Name%type, --操作人员
                                      strCellNo       in stock_content.cell_no%type, --指定储位
                                      nCellID         out stock_content.cell_id%type,
                                      strOutMsg       out varchar2) --返回 执行结果
   is
    cursor v_GetCheckPal is
      select icp.*, icm.Supplier_No --, iim.dept_no
        from idata_check_pal icp,
             idata_check_m   icm,
             idata_check_d   icd,
             idata_import_m  iim
       where icm.enterprise_no = icp.enterprise_no
         and icm.enterprise_no = icd.enterprise_no
         and icm.enterprise_no = iim.enterprise_no
         and icm.enterprise_no = strEnterPriseNo
         and icm.warehouse_no = icp.warehouse_no
         and icm.warehouse_no = icd.warehouse_no
         and icm.owner_no = icp.owner_no
         and icm.owner_no = icd.owner_no
         and icm.check_no = icd.check_no
         and icm.check_no = icp.check_no
         and iim.warehouse_no = icm.warehouse_no
         and iim.owner_no = icm.owner_no
         and iim.import_no = icm.import_no
         and icm.warehouse_no = strWareHouseNo
         and icm.s_check_no = strScheckNo
         and icd.row_id = icp.check_row_id
         and icd.article_no = strArticleNo
         and icd.quality = strQuality
         and icd.row_id = nRowId
         and icp.packing_qty = nPackingQty
         and icp.barcode = strBarcode
         AND icp.lot_no = strLotNo
         and icp.produce_date = dtProduceDate
         and icp.expire_date = dtExpireDate
         and icp.check_no = strCheckNo
         and icp.status = '10'
         and icp.container_no = strContainerNo
       order by icp.label_no;

    n_count         number(10); --记录数，以做判断;
    v_nCellID       stock_content.cell_id%type;
    v_strLocateType idata_locate_direct.locate_type%type;
    v_LocateFlag    idata_locate_direct.container_locate_flag%type; --0按箱定位；1：按商品定位
  begin
    n_count   := 0;
    strOutMsg := 'N|[p_Idata_InsertIdStockItem]';

    --循环板明细添加标签信息
    for GetCheckPal in v_GetCheckPal loop
      n_count := 1; --判断是否进了循环

      --增加目的储位库存
      PKobj_stock.p_InstContent_qtyByCellNo(strEnterPriseNo,
                                            strWareHouseNo,
                                            GetCheckPal.owner_no,
                                            GetCheckPal.dept_no,
                                            GetCheckPal.article_no,
                                            nArticleId,
                                            strCellNo,
                                            strCellNo,
                                            GetCheckPal.packing_qty,
                                            CheckQty,
                                            'N',
                                            'N',
                                            --GetCheckPal.Label_No,
                                            --GetCheckPal.Sub_Label_No,
                                            GetCheckPal.stock_type,
                                            GetCheckPal.stock_value,
                                            strUser_ID,
                                            strScheckNo,
                                            strTools,
                                            '0',
                                            v_nCellID,
                                            strOutMsg);

      if (substr(strOutMsg, 1, 1) <> 'Y') then
        return;
      end if;
      nCellID := v_nCellID;

      if GetCheckPal.BUSINESS_TYPE = '0' then
        v_strLocateType := '1';
        v_LocateFlag    := '1';
      end if;

    end loop;

    if (n_count <= 0) then
      strOutMsg := 'N|[E00151]';
      return;
    end if;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_Idata_InsertIdStockItem;

  /*****************************************************************************************************
    功能：根据验收汇总单增加暂存区库存  进货验收封板
   作者：luozhiling
   日期：2013-11-25
  *******************************************************************************************************/

  procedure p_Idata_InsertIdStock(strEnterPriseNo in stock_content.enterprise_no%type, -- 企业编号
                                  strWareHouseNo  in idata_check_pal.warehouse_no%type, --仓别
                                  strScheckNo     in idata_check_pal.s_check_no%type, --汇总验收单号
                                  strTools        in stock_content_move.terminal_flag%type, --操作设备
                                  strUser_ID      in idata_check_pal.Rgst_Name%type, --操作人员
                                  strCellNo       out stock_content.cell_no%type, --指定储位
                                  nCellID         out stock_content.cell_id%type,
                                  strOutMsg       out varchar2) --返回 执行结果
   is

    cursor v_GetCheckPal is
      select icp.*, icm.Supplier_No
        from idata_check_pal icp,
             idata_check_m   icm,
             idata_check_d   icd,
             idata_import_m  iim
       where icm.enterprise_no = icp.enterprise_no
         and icm.enterprise_no = icd.enterprise_no
         and icm.enterprise_no = iim.enterprise_no
         and icm.enterprise_no = strEnterPriseNo
         and icm.warehouse_no = icp.warehouse_no
         and icm.warehouse_no = icd.warehouse_no
         and icm.owner_no = icp.owner_no
         and icm.owner_no = icd.owner_no
         and icm.check_no = icd.check_no
         and icm.check_no = icp.check_no
         and iim.warehouse_no = icm.warehouse_no
         and iim.owner_no = icm.owner_no
         and iim.import_no = icm.import_no
         and icm.warehouse_no = strWareHouseNo
         and icm.s_check_no = strScheckNo
         and icd.row_id = icp.check_row_id
         and icp.status = '10'
       order by icp.label_no;

    v_nArticleId    stock_content.article_id%type; --商品属性ID
    n_count         number(10); --记录数，以做判断;
    v_nCellID       stock_content.cell_id%type;
    v_strLocateType idata_locate_direct.locate_type%type;
    v_LocateFlag    idata_locate_direct.container_locate_flag%type; --0按箱定位；1：按商品定位
  begin
    n_count   := 0;
    strOutMsg := 'N|[p_Idata_InsertIdStock]';

    --获取暂存区储位 注：这里和程序中取暂存区(方法GetSpecialAreaCellNo)对应.别随意动
    begin
      select cell_no
        into strCellNo
        from (select CDC.CELL_NO
                FROM Cdef_DEFAREA CDA, Cdef_DEFCELL CDC
               WHERE cda.enterprise_no = cdc.enterprise_no
                 and CDA.warehouse_no = CDC.warehouse_no
                 AND CDA.WARE_NO = CDC.WARE_NO
                 AND CDA.AREA_NO = CDC.AREA_NO
                 and cda.enterprise_no = strEnterPriseNo
                 and cda.warehouse_no = strWareHouseNo
                 AND CDA.AREA_ATTRIBUTE = '1' --暂存区
                 and CDA.AREA_USETYPE = '1' --普通区
                 AND CDA.ATTRIBUTE_TYPE = '2' --进货区或者存储区
                 and cdc.cell_status = '0'
                 and cdc.check_status = '0'
               ORDER BY CDA.ATTRIBUTE_TYPE DESC, CDC.cell_no)
       where rownum < 2;
    exception
      when no_data_found then
        strOutMsg := 'N|[E00100]';
        return;
    end;

    --循环板明细添加标签信息
    for GetCheckPal in v_GetCheckPal loop
      n_count := 1; --判断是否进了循环

      --获取商品属性ID
      PKLG_WMS_BASE.p_getArticleID(strEnterPriseNo,
                                   GetCheckPal.article_no,
                                   GetCheckPal.barcode,
                                   GetCheckPal.lot_no,
                                   GetCheckPal.Produce_Date,
                                   GetCheckPal.expire_date,
                                   --GetCheckPal.item_type,
                                   GetCheckPal.quality,
                                   --GetCheckPal.batch_serial_no,
                                   --'N',
                                   GetCheckPal.RSV_BATCH1,
                                   GetCheckPal.RSV_BATCH2,
                                   GetCheckPal.RSV_BATCH3,
                                   GetCheckPal.RSV_BATCH4,
                                   GetCheckPal.RSV_BATCH5,
                                   GetCheckPal.RSV_BATCH6,
                                   GetCheckPal.RSV_BATCH7,
                                   GetCheckPal.RSV_BATCH8,
                                   GetCheckPal.check_no,
                                   '0',
                                   strUser_ID,
                                   GetCheckPal.Price,
                                   v_nArticleId,
                                   strOutMsg);

      if (substr(strOutMsg, 1, 1) <> 'Y') then
        return;
      end if;

      --增加目的储位库存
      PKobj_stock.p_InstContent_qtyByCellNo(strEnterPriseNo,
                                            strWareHouseNo,
                                            GetCheckPal.owner_no,
                                            GetCheckPal.dept_no,
                                            GetCheckPal.article_no,
                                            v_nArticleId,
                                            strCellNo,
                                            strCellNo,
                                            GetCheckPal.packing_qty,
                                            GetCheckPal.check_qty,
                                            'N',
                                            'N',
                                            GetCheckPal.stock_type,
                                            GetCheckPal.stock_value,
                                            strUser_ID,
                                            strScheckNo,
                                            strTools,
                                            '0',
                                            v_nCellID,
                                            strOutMsg);

      if (substr(strOutMsg, 1, 1) <> 'Y') then
        return;
      end if;

      if n_count = 1 then
        select cell_id
          into nCellID
          from stock_content sc
         where sc.enterprise_no = strEnterPriseNo
           and sc.WAREHOUSE_NO = strWareHouseNo
           and sc.Owner_No = GetCheckPal.owner_no
           and sc.article_no = GetCheckPal.article_no
           and sc.article_id = v_nArticleId
           and sc.cell_no = strCellNo
           and sc.Packing_Qty = GetCheckPal.packing_qty
           and sc.label_no = GetCheckPal.Label_No
           and sc.Flag = '0'
           and sc.mv_hand_flag = '0'
           and sc.instock_type = '0'
           and rownum = 1;
      end if;

      if GetCheckPal.BUSINESS_TYPE = '0' then
        v_strLocateType := '1';
        v_LocateFlag    := '1';
      end if;

    end loop;

    if (n_count <= 0) then
      strOutMsg := 'N|[E00151]';
      return;
    end if;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_Idata_InsertIdStock;

  /*****************************************************************************************
     功能：增加目的库存 没有预上数量,不写储位三级帐
    Modify By luozhiling AT 2014-11-7
  *****************************************************************************************/
  procedure p_InstStockContent(strEnterPriseNo in stock_content.enterprise_no%type, -- 企业编号
                               strWAREHOUSE_NO in stock_content.WAREHOUSE_NO%type, --仓库编码
                               strOwner_No     in stock_content.Owner_No%type, --委托业主
                               strDeptNo       in stock_content.dept_no%type, --部门编码
                               strArticle_no   in stock_content.article_no%type, --商品编号
                               nArticle_id     in stock_content.article_id%type, --商品属性ID
                               strCell_no      in stock_content.cell_no%type, --储位
                               nPacking_Qty    in stock_content.Packing_Qty%type, --商品包装
                               nQty            in stock_content.qty%type, --数量
                               strlabel_no     in stock_content.label_no%type, --标签号
                               strsub_label_no in stock_content.sub_label_no%type, --子标签号
                               strStock_type   in stock_content.stock_type%type, --存储类型
                               strStock_value  in stock_content.stock_value%type, --对应存储值
                               strUser_id      in stock_content.Rgst_Name%type, --操作人员
                               strOutMsg       out varchar2) --返回 执行结果
   is
    n_cell_id      stock_content.cell_id%type; --储位id
    n_outstock_qty stock_content.outstock_qty%type; --预下数量
    n_instock_qty  stock_content.instock_qty%type; --预上数量
    n_s_qty        stock_content.qty%type; --原来数量
    nMvHandFlag    stock_content.mv_hand_flag%type;
  begin
    strOutMsg := 'N|[p_InstContent_qtyByCellNo]';

    begin
      --处理目的容器库存-
      -----------获取目的容器库存，储位ID-------------------
      select cell_id, outstock_qty, instock_qty, qty, mv_hand_flag
        into n_cell_id, n_outstock_qty, n_instock_qty, n_s_qty, nMvHandFlag
        from stock_content sc
       where sc.enterprise_no = strEnterPriseNo
         and sc.WAREHOUSE_NO = strWAREHOUSE_NO
         and sc.Owner_No = strOwner_No
         and sc.article_no = strarticle_no
         and sc.article_id = narticle_id
         and sc.cell_no = strCell_No
         and sc.Packing_Qty = nPacking_Qty
         and sc.label_no = strlabel_no
         and sc.instock_type = '0'
         and sc.stock_type = strStock_type
         and sc.stock_value = strStock_value
         and rownum = 1;
      -----------找到储位ID--------------------------------
      if (n_cell_id > 0) then
        ----------------------------------增加目的储位库存数量-----------------------------
        update stock_content sc
           set sc.qty       = sc.qty + nQty,
               sc.updt_name = strUSER_ID,
               sc.updt_date = sysdate
         where sc.enterprise_no = strEnterPriseNo
           and sc.WAREHOUSE_NO = STRWAREHOUSE_NO
           and sc.owner_no = strOwner_No
           and SC.cell_NO = strCell_no
           and sc.cell_id = n_cell_id;
        -----------------------------------修改记录为0行------------------------
        if sql%notfound then
          strOutMsg := 'N|[E00007]';
          return;
        end if;
      end if;
      ----------------------------没找到，新增一条库存记录-------------------
    exception
      when no_data_found then

        --------------------------获取储位ID----------------
        select SEQ_stock_CONTENT.nextval into n_cell_id from dual;
        ------------------------新增一笔库存记录-------------------------------------
        insert into stock_content
          (WAREHOUSE_NO,
           owner_no,
           dept_no,
           cell_no,
           cell_id,
           ARTICLE_NO,
           ARTICLE_ID,
           PACKING_QTY,
           qty,
           outstock_qty,
           instock_qty,
           unusual_qty,
           rgst_name,
           rgst_date,
           UPDT_NAME,
           UPDT_DATE,
           status,
           flag,
           instock_type,
           stock_type,
           stock_VALUE,
           Label_No,
           Mv_hand_flag,
           sub_label_no,
           enterprise_no)
        values
          (strWAREHOUSE_NO,
           strOwner_No,
           strDeptNo,
           strCell_No,
           n_cell_id,
           strArticle_No,
           nArticle_Id,
           nPacking_Qty,
           nQty,
           0,
           0,
           0,
           strUSER_ID,
           sysdate,
           strUSER_ID,
           sysdate,
           0,
           0,
           0,
           strStock_Type,
           strStock_Value,
           strlabel_no,
           '0',
           strsub_label_no,
           strEnterPriseNo);
        -----------------------新增记录为0行----------------------
        if sql%notfound then
          strOutMsg := 'N|[E00008]{' || strArticle_No || '}{' || strCell_No || '}';
          return;
        end if;
    end;

    --------删除库存表qty为0的记录--------------
    delete stock_content sc
     where sc.enterprise_no = strEnterPriseNo
       and sc.WAREHOUSE_NO = strWAREHOUSE_NO
       and sc.cell_no = strCell_No
       and sc.qty = 0
       and sc.instock_qty = 0
       and sc.outstock_qty = 0
       and sc.UNUSUAL_QTY = 0;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end p_InstStockContent;
  /*****************************************************************************************
     功能：扣减源库存 循环扣减, 不处理预约上下架量，直接扣减库存,不记录储位三级帐
    创建人 luozhiling AT 2014-10-7
  *****************************************************************************************/
  procedure p_UpdateStockContent(strEnterPriseNo in stock_content.enterprise_no%type, -- 企业编号
                                 strWAREHOUSE_NO in stock_content.WAREHOUSE_NO%type, --仓别
                                 strOwner_No     in stock_content.Owner_No%type, --委托业主
                                 strArticle_no   in stock_content.article_no%type, --商品编号
                                 nArticle_id     in stock_content.article_id%type, --商品属性ID
                                 strCell_no      in stock_content.cell_no%type, --储位
                                 nPacking_Qty    in stock_content.Packing_Qty%type, --商品包装
                                 nQty            in stock_content.qty%type, --数量
                                 strlabelNo      in stock_content.label_no%type, --商品容器号
                                 strStock_type   in stock_content.stock_type%type, --存储类型
                                 strStock_value  in stock_content.stock_value%type, --对应存储值
                                 strUser_id      in stock_content.Rgst_Name%type, --操作人员
                                 strErrorMsg     out varchar2) --返回 执行结果
   is
    n_MoveSumQty stock_content.Qty%type; --转移总数量
    n_MoveQty    stock_content.Qty%type; --转移数量
    n_count      number(10); --记录数，以做判断;
  begin

    strErrorMsg := 'N|[p_UpdateStockContent]';

    n_count      := 0;
    n_MoveSumQty := nQty;

    for i_Content_Info in (select *
                             from stock_content sc
                            where sc.enterprise_no = strEnterPriseNo
                              and sc.WAREHOUSE_NO = strWAREHOUSE_NO
                              and sc.Owner_No = strOwner_No
                              and sc.article_no = strArticle_no
                              and sc.article_id = nArticle_id
                              and sc.cell_no = strCell_No
                              and sc.Packing_Qty = nPacking_Qty
                              and sc.label_no = strlabelNo
                              and sc.stock_type = strStock_type
                              and sc.stock_value = strStock_value
                              and sc.qty - sc.outstock_qty > 0) loop
      n_count := 1; --判断是否进了循环
      ---当总转移数量等于0时，跳出本次循环
      if (n_MoveSumQty <= 0) then
        --跳出本次循环，
        goto CutContentEnd;
      end if;
      --------循环配量-------------------
      if (i_Content_Info.Qty >= n_MoveSumQty) then
        n_MoveQty := n_MoveSumQty;
      else
        n_MoveQty := i_Content_Info.Qty;
      end if;
      -----------是虚拟储位的时候---------------

      n_MoveSumQty := n_MoveSumQty - n_MoveQty;

      --------修改库存数量,普通储位------------
      update stock_content sc
         set sc.qty       = sc.qty - n_MoveQty,
             sc.updt_name = struser_id,
             sc.updt_date = sysdate
       where sc.enterprise_no = strEnterPriseNo
         and sc.WAREHOUSE_NO = i_Content_Info.WAREHOUSE_NO
         and sc.cell_no = i_Content_Info.Cell_No
         and sc.cell_id = i_Content_Info.Cell_Id
         and sc.qty - sc.outstock_qty - n_MoveQty >= 0;
      ---------修改记录为0行------------
      if sql%notfound then
        strErrorMsg := 'N|[E00008]{' || strArticle_No || '}{' || strCell_No || '}';
        return;
      end if;

      --<<CutContentEnd>>标签后的null;语句不可少,因为goto标签后必须紧接着一个执行语句
      <<CutContentEnd>>
      null;

      --------删除库存表qty为0的记录--------------
      delete stock_content sc
       where sc.enterprise_no = strEnterPriseNo
         and sc.WAREHOUSE_NO = i_Content_Info.WAREHOUSE_NO
         and sc.cell_no = i_Content_Info.Cell_No
         and sc.qty = 0
         and sc.instock_qty = 0
         and sc.outstock_qty = 0
         and sc.UNUSUAL_QTY = 0;
    end loop;

    if n_MoveSumQty > 0 then
      strErrorMsg := 'N|[E00401]';
      return;
    end if;
    if (n_count <= 0) then
      strErrorMsg := 'N|[E00150]';
      return;
    end if;

    strErrorMsg := 'Y|';
  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end p_UpdateStockContent;

  /*******************************************************************************************8
  功能说明：根据退货下架单明细更新库存
           1、对整张下架单进行处理
           2015.7.22
  *******************************************************************************************/
  procedure P_WM_Receipt_WriteContent(strEnterPriseNo  in rodata_outstock_m.enterprise_no%type,
                                      strwarehouse_no  in rodata_outstock_m.warehouse_no%type, --仓别
                                      strOutstock_no   in rodata_outstock_m.outstock_no%type, --退货单号
                                      strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                                      strUser_ID       in bdef_defworker.worker_no%type, --操作人员
                                      strOutMsg        out varchar2) --返回 执行结果
   is
    n_count      number(10); --记录数，以做判断;
    v_nCellID    stock_content.cell_id%type;
    v_nOldCellID stock_content.cell_id%type;
  begin

    n_count   := 0;
    strOutMsg := 'N|[P_WM_Receipt_WriteContent]';
    -------------------查询退货下架指示-------------------------
    for i_WM_Detail_Info in (select d.*
                               from rodata_outstock_d d
                              where d.enterprise_no = strEnterPriseNo
                                and d.warehouse_no = strwarehouse_no
                                and d.outstock_no = stroutstock_no
                                and STATUS = '11') loop
      n_count := 1; --判断是否进了循环
      --------------------回写目的储位预上库存----------------------------------
      PKOBJ_STOCK.p_InstContent_qtyByCellID(strEnterPriseNo,
                                            i_WM_Detail_Info.warehouse_no, --仓别
                                            i_WM_Detail_Info.d_Cell_Id, --储位ID
                                            i_WM_Detail_Info.d_Cell_No, --储位
                                            i_WM_Detail_Info.s_Cell_No, --关系储位
                                            i_WM_Detail_Info.Real_Qty, --数量
                                            i_WM_Detail_Info.Article_Qty, --预下数量
                                            strUser_id, --操作人员
                                            strOutstock_no, --操作单号
                                            strTERMINAL_FLAG, --操作设备
                                            strOutMsg); --返回 执行结果
      if (substr(strOutMsg, 1, 1) <> 'Y') then
        return;
      end if;

      -------------------把来源储位预下库存回单-------------------------------
      PKOBJ_STOCK.p_UpdtContent_qtyByCellID(strEnterPriseNo,
                                            i_WM_Detail_Info.warehouse_no, --仓别
                                            i_WM_Detail_Info.s_Cell_Id, --储位ID
                                            i_WM_Detail_Info.s_Cell_No, --储位
                                            i_WM_Detail_Info.d_Cell_No, --关系储位
                                            i_WM_Detail_Info.Real_Qty, --数量
                                            i_WM_Detail_Info.Article_Qty, --预下数量
                                            strUser_id, --操作人员
                                            strOutstock_no, --操作单号
                                            strTERMINAL_FLAG, --操作设备
                                            strOutMsg); --返回 执行结果
      if (substr(strOutMsg, 1, 1) <> 'Y') then
        return;
      end if;
      v_nOldCellID := i_WM_Detail_Info.d_Cell_Id;
      --------------------是否有修改储位----------------------------------
      if i_WM_Detail_Info.d_Cell_No <> i_WM_Detail_Info.Outstock_Cell_No then
        ----------------增加新储位库存------------------
        PKOBJ_STOCK.p_InstContent_qtyByCellNo(strEnterPriseNo,
                                              i_WM_Detail_Info.warehouse_no, --仓别
                                              i_WM_Detail_Info.Owner_No, --委托业主
                                              'N',
                                              i_WM_Detail_Info.Article_No, --商品编号
                                              i_WM_Detail_Info.Article_Id, --商品属性ID
                                              i_WM_Detail_Info.Outstock_Cell_No, --储位
                                              i_WM_Detail_Info.d_Cell_No, --关系储位
                                              i_WM_Detail_Info.Packing_Qty, --商品包装
                                              i_WM_Detail_Info.Real_Qty, --数量
                                              'N', --标签号
                                              'N', --子标签号
                                              i_WM_Detail_Info.Stock_Type, --存储类型
                                              i_WM_Detail_Info.Stock_Value, --对应存储值
                                              strUser_id, --操作人员
                                              strOutstock_no, --操作单号
                                              strTERMINAL_FLAG, --操作设备
                                              1, --是否可手工移库 0:不允许手工移库；1：可手工移库
                                              v_nOldCellID,
                                              strOutMsg); --返回 执行结果
        if (substr(strOutMsg, 1, 1) <> 'Y') then
          return;
        end if;
        -----------处理目的容器库存----------------------------------
        PKOBJ_STOCK.p_UpdtContent_qtyByCellNo(strEnterPriseNo,
                                              i_WM_Detail_Info.warehouse_no, --仓别
                                              i_WM_Detail_Info.Owner_No, --委托业主
                                              i_WM_Detail_Info.Article_No, --商品编号
                                              i_WM_Detail_Info.Article_Id, --商品属性ID
                                              i_WM_Detail_Info.d_Cell_No, --储位
                                              i_WM_Detail_Info.Outstock_Cell_No, --关系储位
                                              i_WM_Detail_Info.Packing_Qty, --商品包装
                                              i_WM_Detail_Info.Real_Qty, --数量
                                              i_WM_Detail_Info.label_no, --商品容器号
                                              i_WM_Detail_Info.Stock_Type, --存储类型
                                              i_WM_Detail_Info.Stock_Value, --对应存储值
                                              strUser_id, --操作人员
                                              strOutstock_no, --操作单号
                                              strTERMINAL_FLAG, --操作设备
                                              strOutMsg); --返回 执行结果
        if (substr(strOutMsg, 1, 1) <> 'Y') then
          return;
        end if;
      end if;

      --将目的储位的标签号进行转换
      if i_WM_Detail_Info.Real_Qty > 0 then
        PKOBJ_STOCK.p_UpdtContent_ContainerNo(strEnterPriseNo,
                                              i_WM_Detail_Info.warehouse_no,
                                              i_WM_Detail_Info.label_no,
                                              i_WM_Detail_Info.sub_label_no,
                                              i_WM_Detail_Info.d_cell_no,
                                              i_WM_Detail_Info.d_cell_id,
                                              strUser_id,
                                              v_nOldCellID,
                                              strOutMsg); --返回 执行结果
        if (substr(strOutMsg, 1, 1) <> 'Y') then
          return;
        end if;

        --库存转换
        PKOBJ_STOCK.p_TransContent_qtyByCellID(strEnterPriseNo,
                                               i_WM_Detail_Info.warehouse_no,
                                               i_WM_Detail_Info.Outstock_Cell_No,
                                               v_nOldCellID,
                                               i_WM_Detail_Info.Real_Qty,
                                               '3',
                                               i_WM_Detail_Info.Source_No,
                                               strUser_id,
                                               v_nCellID,
                                               strOutMsg);

        if (substr(strOutMsg, 1, 1) <> 'Y') then
          return;
        end if;
      end if;

      update rodata_recede_d d
         set d.outstock_qty = d.outstock_qty + i_WM_Detail_Info.Real_Qty
       where d.enterprise_no = strEnterPriseNo
         and d.warehouse_no = strwarehouse_no
         and d.owner_no = i_WM_Detail_Info.Owner_No
         and d.recede_no = i_WM_Detail_Info.Source_No
         and d.po_id = i_WM_Detail_Info.Po_Id
         and d.article_no = i_WM_Detail_Info.Article_No;

      update rodata_outstock_d d
         set d.status = '13', d.OUTSTOCK_CELL_ID = v_nCellID
       where d.status = '11'
         and d.warehouse_no = strwarehouse_no
         and d.enterprise_no = strEnterPriseNo
         and d.outstock_no = strOutstock_no
         and d.row_id = i_WM_Detail_Info.row_id;

    end loop;
    if (n_count <= 0) then
      strOutMsg := 'N|[E25405]';
      return;
    end if;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_WM_Receipt_WriteContent;

  /********************************************************************************************
  创建人：luozhiling
  创建时间：2014.11.8
  功能说明：退货标签回单库存处理。
  ********************************************************************************************/

  --根据退货下架单明细更新库存
  procedure P_WM_label_stock(strEnterPriseNo  in stock_content.enterprise_no%type, -- 企业编号
                             strwarehouse_no  in rodata_outstock_m.warehouse_no%type, --仓别
                             strOutstock_no   in rodata_outstock_m.outstock_no%type, --退货单号
                             strLabelNo       in rodata_outstock_d.label_no%type, --
                             strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                             strUser_ID       in bdef_defworker.worker_no%type, --操作人员
                             strOutMsg        out varchar2) --返回 执行结果
   is
    n_count      number(10); --记录数，以做判断;
    v_nCellID    stock_content.cell_id%type;
    v_nOldCellID stock_content.cell_id%type;
  begin

    n_count   := 0;
    strOutMsg := 'N|[P_WM_Receipt_WriteContent]';
    -------------------查询退货下架指示-------------------------
    for i_WM_Detail_Info in (select d.*, d.rowid as d_rowid
                               from rodata_outstock_d d
                              where d.enterprise_no = strEnterPriseNo
                                and d.warehouse_no = strwarehouse_no
                                and d.outstock_no = stroutstock_no
                                and d.label_no = strLabelNo
                                and STATUS = '11') loop
      n_count := 1; --判断是否进了循环
      --------------------回写目的储位预上库存----------------------------------
      PKOBJ_STOCK.p_InstContent_qtyByCellID(strEnterPriseNo,
                                            i_WM_Detail_Info.warehouse_no, --仓别
                                            i_WM_Detail_Info.d_Cell_Id, --储位ID
                                            i_WM_Detail_Info.d_Cell_No, --储位
                                            i_WM_Detail_Info.s_Cell_No, --关系储位
                                            i_WM_Detail_Info.Real_Qty, --数量
                                            i_WM_Detail_Info.Article_Qty, --预下数量
                                            strUser_id, --操作人员
                                            strOutstock_no, --操作单号
                                            strTERMINAL_FLAG, --操作设备
                                            strOutMsg); --返回 执行结果
      if (substr(strOutMsg, 1, 1) <> 'Y') then
        return;
      end if;

      -------------------把来源储位预下库存回单-------------------------------
      PKOBJ_STOCK.p_UpdtContent_qtyByCellID(strEnterPriseNo,
                                            i_WM_Detail_Info.warehouse_no, --仓别
                                            i_WM_Detail_Info.s_Cell_Id, --储位ID
                                            i_WM_Detail_Info.s_Cell_No, --储位
                                            i_WM_Detail_Info.d_Cell_No, --关系储位
                                            i_WM_Detail_Info.Real_Qty, --数量
                                            i_WM_Detail_Info.Article_Qty, --预下数量
                                            strUser_id, --操作人员
                                            strOutstock_no, --操作单号
                                            strTERMINAL_FLAG, --操作设备
                                            strOutMsg); --返回 执行结果
      if (substr(strOutMsg, 1, 1) <> 'Y') then
        return;
      end if;
      v_nOldCellID := i_WM_Detail_Info.d_Cell_Id;
      --------------------是否有修改储位----------------------------------
      if i_WM_Detail_Info.d_Cell_No <> i_WM_Detail_Info.Outstock_Cell_No then
        ----------------增加新储位库存------------------
        PKOBJ_STOCK.p_InstContent_qtyByCellNo(strEnterPriseNo,
                                              i_WM_Detail_Info.warehouse_no, --仓别
                                              i_WM_Detail_Info.Owner_No, --委托业主
                                              'N',
                                              i_WM_Detail_Info.Article_No, --商品编号
                                              i_WM_Detail_Info.Article_Id, --商品属性ID
                                              i_WM_Detail_Info.Outstock_Cell_No, --储位
                                              i_WM_Detail_Info.d_Cell_No, --关系储位
                                              i_WM_Detail_Info.Packing_Qty, --商品包装
                                              i_WM_Detail_Info.Real_Qty, --数量
                                              'N', --标签号
                                              'N', --子标签号
                                              '3', --存储类型
                                              i_WM_Detail_Info.source_no, --对应存储值
                                              strUser_id, --操作人员
                                              strOutstock_no, --操作单号
                                              strTERMINAL_FLAG, --操作设备
                                              1, --是否可手工移库 0:不允许手工移库；1：可手工移库
                                              v_nOldCellID,
                                              strOutMsg); --返回 执行结果
        if (substr(strOutMsg, 1, 1) <> 'Y') then
          return;
        end if;
        -----------处理来源容器库存----------------------------------
        PKOBJ_STOCK.p_UpdtContent_qtyByCellNo(strEnterPriseNo,
                                              i_WM_Detail_Info.warehouse_no, --仓别
                                              i_WM_Detail_Info.Owner_No, --委托业主
                                              i_WM_Detail_Info.Article_No, --商品编号
                                              i_WM_Detail_Info.Article_Id, --商品属性ID
                                              i_WM_Detail_Info.d_Cell_No, --储位
                                              i_WM_Detail_Info.Outstock_Cell_No, --关系储位
                                              i_WM_Detail_Info.Packing_Qty, --商品包装
                                              i_WM_Detail_Info.Real_Qty, --数量
                                              i_WM_Detail_Info.s_label_no, --商品容器号
                                              i_WM_Detail_Info.Stock_Type, --存储类型
                                              i_WM_Detail_Info.Stock_Value, --对应存储值
                                              strUser_id, --操作人员
                                              strOutstock_no, --操作单号
                                              strTERMINAL_FLAG, --操作设备
                                              strOutMsg); --返回 执行结果
        if (substr(strOutMsg, 1, 1) <> 'Y') then
          return;
        end if;
      end if;

      update rodata_recede_d d
         set d.outstock_qty = d.outstock_qty + i_WM_Detail_Info.Real_Qty
       where d.enterprise_no = strEnterPriseNo
         and d.warehouse_no = strwarehouse_no
         and d.owner_no = i_WM_Detail_Info.Owner_No
         and d.recede_no = i_WM_Detail_Info.Source_No
         and d.po_id = i_WM_Detail_Info.Po_Id
         and d.article_no = i_WM_Detail_Info.Article_No;

      update rodata_outstock_d d
         set d.status = '13', d.OUTSTOCK_CELL_ID = v_nCellID
       where d.status = '11'
         and d.rowid = i_WM_Detail_Info.d_rowid;

    end loop;
    if (n_count <= 0) then
      strOutMsg := 'N|[E25405]';
      return;
    end if;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_WM_label_stock;

  procedure proc_stock_account_log is
    /********************************************************************
     功能说明：产生前一天的库存流水账

    ********************************************************************/
  begin
    --获取前一天的验收流水帐
    --写入库帐
    insert into stock_account_day
      (warehouse_no,
       owner_no,
       dept_no,
       paper_no,
       paper_type,
       operate_date,
       article_no,
       packing_qty,
       change_qty,
       weight,
       rgst_name,
       rgst_date,
       enterprise_no)
      select a.warehouse_no,
             a.owner_no,
             a.dept_no,
             a.check_no,
             a.paper_type,
             trunc(sysdate - 1),
             a.article_no,
             a.packing_qty,
             inqty,
             inweight,
             'admin',
             sysdate,
             a.enterprise_no
        from (select 'I' paper_type,
                     icd.dept_no,
                     icd.warehouse_no,
                     icd.owner_no,
                     icd.check_no,
                     icd.article_no,
                     icd.packing_qty,
                     sum(icd.check_qty) InQty,
                     sum(icd.check_qty * a.unit_weight) InWeight,
                     icd.enterprise_no
                from idata_check_m icm, idata_check_d icd, bdef_defarticle a
               where icm.enterprisE_no = icd.enterprise_no
                 and icm.warehouse_no = icd.warehouse_no
                 and icm.owner_no = icd.owner_no
                 and icm.check_no = icd.check_no /* and icm.status='13'*/
                 and icd.owner_no = a.owner_no
                 and icd.article_no = a.article_no
                 and icd.enterprise_no = a.enterprise_no
                 and icd.enterprise_no = a.enterprise_no
                 and trunc(icm.rgst_date) = trunc(sysdate - 1)
               group by 'I',
                        icd.dept_no,
                        icd.warehouse_no,
                        icd.owner_no,
                        icd.check_no,
                        icd.article_no,
                        icd.packing_qty,
                        icd.enterprise_no
              union
              select 'I' paper_type,
                     rcd.dept_no,
                     rcd.warehouse_no,
                     rcd.owner_no,
                     rcd.check_no,
                     rcd.article_no,
                     rcd.packing_qty,
                     sum(rcd.check_qty) InQty,
                     sum(rcd.check_qty * a.unit_weight) InWeight,
                     rcd.enterprise_no
                from ridata_check_m  rcm,
                     ridata_check_d  rcd,
                     bdef_defarticle a
               where rcm.enterprise_no = rcd.enterprise_no
                 and rcm.warehouse_no = rcd.warehouse_no
                 and rcm.owner_no = rcd.owner_no
                 and rcm.check_no = rcd.check_no /*and rcm.status='13'*/
                 and rcd.owner_no = a.owner_no
                 and rcd.article_no = a.article_no
                 and rcd.enterprise_no = a.enterprise_no
                 and trunc(rcm.rgst_date) = trunc(sysdate - 1)
               group by 'I',
                        rcd.dept_no,
                        rcd.warehouse_no,
                        rcd.owner_no,
                        rcd.check_no,
                        rcd.article_no,
                        rcd.packing_qty,
                        rcd.enterprise_no) a;

    --写出库帐
    insert into stock_account_day
      (enterprise_no,
       warehouse_no,
       owner_no,
       dept_no,
       paper_no,
       paper_type,
       operate_date,
       article_no,
       packing_qty,
       change_qty,
       weight,
       rgst_name,
       rgst_date)
      select odm.enterprise_no,
             odm.warehouse_no,
             odm.owner_no,
             'N',
             odm.deliver_no,
             'O',
             trunc(odm.rgst_date),
             odd.article_no,
             odd.packing_qty,
             sum(odd.qty) outqty,
             sum(odd.qty * a.unit_weight) outweight,
             'admin',
             sysdate
        from odata_deliver_m odm, odata_deliver_d odd, bdef_defarticle a
       where odm.enterprise_no = odd.enterprise_no
         and odm.warehouse_no = odd.warehouse_no
         and odm.owner_no = odd.owner_no
         and odm.deliver_no = odd.deliver_no
         and odm.operate_date = trunc(sysdate - 1)
         and odd.owner_no = a.owner_no
         and odd.article_no = a.article_no
         and odd.enterprise_no = a.enterprise_no
       group by odm.enterprise_no,
                odm.warehouse_no,
                odm.owner_no,
                'N',
                odm.deliver_no,
                'O',
                trunc(odm.rgst_date),
                odd.article_no,
                odd.packing_qty
      union
      select rdm.enterprise_no,
             rdm.warehouse_no,
             rdm.owner_no,
             'N',
             rdm.deliver_no,
             'O',
             trunc(rdm.rgst_date),
             rdd.article_no,
             rdd.packing_qty,
             sum(rdd.real_qty) outqty,
             sum(rdd.real_qty * a.unit_weight) outweight,
             'admin',
             sysdate
        from rodata_deliver_m rdm, rodata_deliver_d rdd, bdef_defarticle a
       where rdm.enterprise_no = rdd.enterprise_no
         and rdm.warehouse_no = rdd.warehouse_no
         and rdm.owner_no = rdd.owner_no
         and rdm.deliver_no = rdd.deliver_no
         and rdm.operate_date = trunc(sysdate - 1)
         and rdd.owner_no = a.owner_no
         and rdd.article_no = a.article_no
         and rdd.enterprise_no = a.enterprise_no
       group by rdm.enterprise_no,
                rdm.warehouse_no,
                rdm.owner_no,
                'N',
                rdm.deliver_no,
                'O',
                trunc(rdm.rgst_date),
                rdd.article_no,
                rdd.packing_qty;

    --盘点盈亏帐
    insert into stock_account_day
      (enterprise_no,
       warehouse_no,
       owner_no,
       dept_no,
       paper_no,
       paper_type,
       operate_date,
       article_no,
       packing_qty,
       change_qty,
       weight,
       rgst_name,
       rgst_date)
      select fdm.enterprise_no,
             fdm.warehouse_no,
             fdm.owner_no,
             fdd.dept_no,
             fdm.different_no,
             case
               when sum(fdd.real_qty - fdd.article_qty) > 0 then
                'I'
               else
                'O'
             end as operate_type,
             trunc(fdm.rgst_date),
             fdd.article_no,
             fdd.packing_qty,
             case
               when sum(fdd.real_qty - fdd.article_qty) > 0 then
                sum(fdd.real_qty - fdd.article_qty)
               else
                sum(fdd.article_qty - fdd.real_qty)
             end qty,
             case
               when sum(fdd.real_qty - fdd.article_qty) > 0 then
                sum((fdd.real_qty - fdd.article_qty) * a.unit_weight)
               else
                sum((fdd.article_qty - fdd.real_qty) * a.unit_weight)
             end weight,
             'admin',
             sysdate
        from fcdata_different_d fdd,
             fcdata_different_m fdm,
             bdef_defarticle    a
       where fdm.enterprise_no = fdm.enterprise_no
         and fdm.different_no = fdd.different_no
         and fdm.warehouse_no = fdd.warehouse_no
         and fdm.owner_no = fdd.owner_no
         and trunc(fdm.rgst_date) = trunc(sysdate - 1)
         and fdd.owner_no = a.owner_no
         and fdd.enterprise_no = a.enterprise_no
         and fdd.article_no = a.article_no
       group by fdm.enterprise_no,
                fdm.warehouse_no,
                fdm.owner_no,
                fdd.dept_no,
                fdm.different_no,
                trunc(fdm.rgst_date),
                fdd.article_no,
                fdd.packing_qty;
    --库存调整
    insert into stock_account_day
      (enterprise_no,
       warehouse_no,
       owner_no,
       dept_no,
       paper_no,
       paper_type,
       operate_date,
       article_no,
       packing_qty,
       change_qty,
       weight,
       rgst_name,
       rgst_date)
      select d.enterprise_no,
             d.warehouse_no,
             d.owner_no,
             'N',
             d.confirm_no,
             case
               when sum(d.real_qty) > 0 then
                'I'
               else
                'O'
             end paper_type,
             trunc(m.updt_date),
             d.article_no,
             d.packing_qty,
             case
               when sum(d.real_qty) > 0 then
                sum(d.real_qty)
               else
                -sum(d.real_qty)
             end qty,
             case
               when sum(d.real_qty) > 0 then
                sum(d.real_qty * a.unit_weight)
               else
                -sum(d.real_qty * a.unit_weight)
             end weight,
             'admin',
             sysdate
        from stock_confirm_m m, stock_confirm_d d, bdef_defarticle a
       where m.enterprise_no = d.enterprise_no
         and m.warehouse_no = d.warehouse_no
         and m.owner_no = d.owner_no
         and m.confirm_no = d.confirm_no
         and d.enterprise_no = a.enterprise_no
         and d.owner_no = a.owner_no
         and d.article_no = a.article_no
         and m.status = '13'
         and trunc(m.updt_date) = trunc(sysdate - 1)
       group by d.enterprise_no,
                d.warehouse_no,
                d.owner_no,
                'N',
                d.confirm_no,
                trunc(m.updt_date),
                d.article_no,
                d.packing_qty;
    --报损
    insert into stock_account_day
      (enterprise_no,
       warehouse_no,
       owner_no,
       dept_no,
       paper_no,
       paper_type,
       operate_date,
       article_no,
       packing_qty,
       change_qty,
       weight,
       rgst_name,
       rgst_date)
      select d.enterprise_no,
             d.warehouse_no,
             d.owner_no,
             'N',
             d.outstock_no,
             'O',
             trunc(m.updt_date),
             d.article_no,
             d.packing_qty,
             sum(d.real_qty) qty,
             sum(d.real_qty * a.unit_weight) weight,
             'admin',
             sysdate
        from sodata_outstock_mhty m,
             sodata_outstock_dhty d,
             bdef_defarticle      a
       where m.enterprise_no = d.enterprise_no
         and m.warehouse_no = d.warehouse_no
         and m.owner_no = d.owner_no
         and m.outstock_no = d.outstock_no
         and d.enterprise_no = a.enterprise_no
         and d.owner_no = a.owner_no
         and d.article_no = a.article_no
         and trunc(m.updt_date) = trunc(sysdate - 1)
       group by d.enterprise_no,
                d.warehouse_no,
                d.owner_no,
                'N',
                d.outstock_no,
                trunc(m.updt_date),
                d.article_no,
                d.packing_qty;

  END proc_stock_account_log;

  procedure proc_stock_content_rj is
  begin
    --首先对前一天的库存和进出帐记流水帐；
    proc_stock_account_log;
    /*************************************
    添加计算重量 weiyufei 2015-06-17
    *************************************/
    --做前一天的库存结算
    insert into stock_content_rj
      (warehouse_no,
       owner_no,
       dept_no,
       article_no,
       packing_qty,
       jc_date,
       qc_qty,
       in_qty,
       out_qty,
       qty,
       rgst_name,
       rgst_date,
       qc_weight,
       in_weight,
       out_weight,
       weight)
      select a.warehouse_no,
             a.owner_no,
             a.dept_no,
             a.article_no,
             a.packing_qty,
             trunc(sysdate - 1),
             sum(a.qcqty),
             sum(a.inqty),
             sum(a.outqty),
             sum(a.qcqty) + sum(a.inqty) - sum(a.outqty),
             'admin',
             sysdate,
             sum(a.qcweight),
             sum(a.inweight),
             sum(a.outweight),
             sum(a.qcweight) + sum(a.inweight) - sum(a.outweight)
        from (select scr.warehouse_no,
                     scr.owner_no,
                     scr.dept_no,
                     scr.article_no,
                     scr.packing_qty,
                     sum(scr.qty) qcqty,
                     0 inqty,
                     0 outqty,
                     sum(scr.weight) qcweight,
                     0 inweight,
                     0 outweight
                from stock_content_rj scr
               where scr.jc_date = trunc(sysdate - 2)
               group by scr.warehouse_no,
                        scr.owner_no,
                        scr.dept_no,
                        scr.article_no,
                        scr.packing_qty --将前天的库存量作为昨天的期初库存
              union
              select sad.warehouse_no,
                     sad.owner_no,
                     sad.dept_no,
                     sad.article_no,
                     sad.packing_qty,
                     0 qcqty,
                     sum(sad.change_qty) inqty,
                     0 outqty,
                     0 qcweight,
                     sum(sad.weight) inweight,
                     0 outweight
                from stock_account_day sad
               where sad.operate_date = trunc(sysdate - 1)
                 and sad.paper_type = 'I'
               group by sad.warehouse_no,
                        sad.owner_no,
                        sad.dept_no,
                        sad.article_no,
                        sad.packing_qty
              union
              select sad.warehouse_no,
                     sad.owner_no,
                     sad.dept_no,
                     sad.article_no,
                     sad.packing_qty,
                     0 qcqty,
                     0 inqty,
                     sum(sad.change_qty) Outqty,
                     0 qcweight,
                     0 inweight,
                     sum(sad.weight) outweight
                from stock_account_day sad
               where sad.operate_date = trunc(sysdate - 1)
                 and sad.paper_type = 'O'
               group by sad.warehouse_no,
                        sad.owner_no,
                        sad.dept_no,
                        sad.article_no,
                        sad.packing_qty) a
       group by a.warehouse_no,
                a.owner_no,
                a.dept_no,
                a.article_no,
                a.packing_qty;

  END proc_stock_content_rj;

  /**********************************************************************************************
   作者:lich
   日期:  2014-05-12
   功能: 新增商品批号
  ************************************************************************************************/
  procedure p_Insert_Article_lot_manage(strEnterPriseNo in bdef_article_lot_manage.enterprise_no%type,
                                        strwarehouse_no in bdef_article_lot_manage.warehouse_no%type,
                                        strArticleNo    in bdef_article_lot_manage.article_no%type, --商品编码
                                        strLotNo        in bdef_article_lot_manage.lot_no%type, --批号
                                        dtProduceDate   in bdef_article_lot_manage.produce_date%type, --生产日期
                                        dtExpireDate    in bdef_article_lot_manage.expire_date%type, --有期期
                                        nExpiryDays     in bdef_article_lot_manage.expiry_days%type, --天数
                                        strWorkerNo     in bdef_article_lot_manage.rgst_name%type, --操作人
                                        nPrice          in bdef_article_lot_manage.price%type, --价格
                                        strResult       out varchar2 --返回结果
                                        ) is

  begin
    strResult := 'N|[p_Insert_Article_lot_manage]';

    --写入验收单头档
    begin
      update bdef_article_lot_manage alm
         set alm.rgst_name = strWorkerNo, alm.rgst_date = sysdate
       where alm.enterprise_no = strEnterPriseNo
         and alm.warehouse_no = strwarehouse_no
         and alm.article_no = strArticleNo
         and alm.lot_no = strLotNo
         and alm.produce_date = dtProduceDate
         and alm.expire_date = dtExpireDate
         and alm.expiry_days = nExpiryDays;

      if (sql%rowcount <= 0) then
        Insert into bdef_article_lot_manage
          (enterprise_no,
           warehouse_no,
           article_no,
           lot_no,
           produce_date,
           expire_date,
           expiry_days,
           rgst_name,
           rgst_date,
           price)
        values
          (strEnterPriseNo,
           strwarehouse_no,
           strArticleNo,
           strLotNo,
           dtProduceDate,
           dtExpireDate,
           nExpiryDays,
           strWorkerNo,
           sysdate,
           nPrice);
      end if;
    end;

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_Insert_Article_lot_manage;

  /**********************************************************************************************
   作者:luozhiling
   日期:  2015-03-16
   功能: 新增商品库存三级帐
  ************************************************************************************************/
  procedure P_InsertArticleStockList(strEnterprise_no in stock_content_list.enterprise_no%type, --企业
                                     strWAREHOUSE_NO  in stock_content_list.WAREHOUSE_NO%type, --仓库编码
                                     strOwner_No      in stock_content_list.owner_no%type, --委托业主编码
                                     strDeptNo        in stock_content_list.dept_no%type,
                                     strArticleNo     in stock_content_list.article_no%type, --商品编码
                                     strQuality       in stock_content_list.quality%type, --品质
                                     dtProduceDate    in stock_content_list.produce_date%type, --生产日期
                                     dtExpireDate     in stock_content_list.expire_date%type, --有效日期
                                     strLotNo         in stock_content_list.lot_no%type, --批号
                                     strRSV_BATCH1    in stock_content_list.rsv_batch1%type, --预留批属性1
                                     strRSV_BATCH2    in stock_content_list.rsv_batch2%type, --预留批属性2
                                     strRSV_BATCH3    in stock_content_list.rsv_batch3%type, --预留批属性3
                                     strRSV_BATCH4    in stock_content_list.rsv_batch4%type, --预留批属性4
                                     strRSV_BATCH5    in stock_content_list.rsv_batch5%type, --预留批属性5
                                     strRSV_BATCH6    in stock_content_list.rsv_batch6%type, --预留批属性6
                                     strRSV_BATCH7    in stock_content_list.rsv_batch7%type, --预留批属性7
                                     strRSV_BATCH8    in stock_content_list.rsv_batch8%type, --预留批属性8
                                     strBarcode       in stock_content_list.barcode%type, --商品条码
                                     nPackQty         in stock_content_list.packing_qty%type, --包装数量
                                     nRealQty         in stock_content_list.qty%type, --验收数量
                                     strStockType     in stock_content_list.stock_type%type, --存储类型
                                     strStockValue    in stock_content_list.stock_value%type, --存储类型对应值
                                     strMoveType      in stock_content_list.move_type%type,
                                     strPaperType     in stock_content_list.paper_type%type,
                                     strPaperNo       in stock_content_list.paper_no%type,
                                     strUserId        in stock_content_list.rgst_name%type, --人员
                                     strImportBatchNo in stock_content_list.import_batch_no%type,
                                     strResult        out varchar2 --返回结果
                                     ) is
    v_nCurrQty stock_article_cost.qty%type;
  begin
    strResult := 'N|[P_InsertArticleStockList]';

    --获取当前库存
    select nvl(qty, 0)
      into v_nCurrQty
      from stock_article_cost
     where enterprise_no = strEnterprise_no
       and warehouse_no = strWAREHOUSE_NO
       and owner_no = strOwner_No
       and dept_no = strDeptNo
       and article_no = strArticleNo
       and packing_qty = nPackQty
       and barcode = strBarcode
       and quality = strQuality
       and produce_date = dtProduceDate
       and import_batch_no = strImportBatchNo
       and expire_date = dtExpireDate
       and lot_no = strLotNo
       and rsv_batch1 = strRSV_BATCH1
       and rsv_batch2 = strRSV_BATCH2
       and rsv_batch3 = strRSV_BATCH3
       and rsv_batch4 = strRSV_BATCH4
       and rsv_batch5 = strRSV_BATCH5
       and rsv_batch6 = strRSV_BATCH6
       and rsv_batch7 = strRSV_BATCH7
       and rsv_batch8 = strRSV_BATCH8 /*and stock_type=strStockType and stock_value=strStockValue*/
    ;

    update stock_content_list
       set qty       = v_nCurrQty,
           move_qty  = move_qty + nRealQty,
           rgst_date = sysdate,
           rgst_name = strUserId
     where enterprise_no = strEnterprise_no
       and warehouse_no = strWAREHOUSE_NO
       and owner_no = strOwner_No
       and dept_no = strDeptNo
       and article_no = strArticleNo
       and packing_qty = nPackQty
       and barcode = strBarcode
       and quality = strQuality
       and produce_date = dtProduceDate
       and import_batch_no = strImportBatchNo
       and expire_date = dtExpireDate
       and lot_no = strLotNo
       and rsv_batch1 = strRSV_BATCH1
       and paper_no = strPaperNo
       and rsv_batch2 = strRSV_BATCH2
       and rsv_batch3 = strRSV_BATCH3
       and rsv_batch4 = strRSV_BATCH4
       and rsv_batch5 = strRSV_BATCH5
       and rsv_batch6 = strRSV_BATCH6
       and rsv_batch7 = strRSV_BATCH7
       and rsv_batch8 = strRSV_BATCH8 /*and stock_type=strStockType and stock_value=strStockValue*/
    ;

    if sql%notfound then
      insert into stock_content_list
        (enterprise_no,
         warehouse_no,
         owner_no,
         dept_no,
         article_no,
         barcode,
         import_batch_no,
         produce_date,
         expire_date,
         quality,
         lot_no,
         rsv_batch1,
         rsv_batch2,
         rsv_batch3,
         rsv_batch4,
         rsv_batch5,
         rsv_batch6,
         rsv_batch7,
         rsv_batch8,
         stock_type,
         stock_value,
         packing_qty,
         qty,
         move_qty,
         move_type,
         paper_no,
         paper_type,
         paper_date,
         rgst_name,
         rgst_date)
      values
        (strEnterprise_no,
         strWAREHOUSE_NO,
         strOwner_No,
         strDeptNo,
         strArticleNo,
         strBarcode,
         strImportBatchNo,
         dtProduceDate,
         dtExpireDate,
         strQuality,
         strLotNo,
         strRSV_BATCH1,
         strRSV_BATCH2,
         strRSV_BATCH3,
         strRSV_BATCH4,
         strRSV_BATCH5,
         strRSV_BATCH6,
         strRSV_BATCH7,
         strRSV_BATCH8,
         strStockType,
         strStockValue,
         nPackQty,
         v_nCurrQty,
         nRealQty,
         strMoveType,
         strPaperNo,
         strPaperType,
         trunc(sysdate),
         strUserId,
         sysdate);
    end if;

    strResult := 'Y|';
  end P_InsertArticleStockList;

  /**********************************************************************************************
   作者:luozhiling
   日期:  2015-03-16
   功能: 新增商品批次库存
  ************************************************************************************************/
  procedure P_insertImportBatchStock(strEnterpriseNo  in stock_article_cost.enterprise_no%type, --企业
                                     strWAREHOUSENO   in stock_article_cost.WAREHOUSE_NO%type, --仓库编码
                                     strOwnerNo       in stock_article_cost.owner_no%type, --委托业主编码
                                     strDeptNo        in stock_article_cost.dept_no%type,
                                     strArticleNo     in stock_article_cost.article_no%type, --商品编码
                                     strQuality       in stock_article_cost.quality%type, --品质
                                     strImportBatchNo in stock_article_cost.import_batch_no%type,
                                     dtProduceDate    in stock_article_cost.produce_date%type, --生产日期
                                     dtExpireDate     in stock_article_cost.expire_date%type, --有效日期
                                     strLotNo         in stock_article_cost.lot_no%type, --批号
                                     strRSV_BATCH1    in stock_article_cost.rsv_batch1%type, --预留批属性1
                                     strRSV_BATCH2    in stock_article_cost.rsv_batch2%type, --预留批属性2
                                     strRSV_BATCH3    in stock_article_cost.rsv_batch3%type, --预留批属性3
                                     strRSV_BATCH4    in stock_article_cost.rsv_batch4%type, --预留批属性4
                                     strRSV_BATCH5    in stock_article_cost.rsv_batch5%type, --预留批属性5
                                     strRSV_BATCH6    in stock_article_cost.rsv_batch6%type, --预留批属性6
                                     strRSV_BATCH7    in stock_article_cost.rsv_batch7%type, --预留批属性7
                                     strRSV_BATCH8    in stock_article_cost.rsv_batch8%type, --预留批属性8
                                     strBarcode       in stock_article_cost.barcode%type, --商品条码
                                     nPackQty         in stock_article_cost.packing_qty%type, --包装数量
                                     nRealQty         in stock_article_cost.qty%type, --验收数量
                                     strStockType     in stock_article_cost.stock_type%type, --存储类型
                                     strStockValue    in stock_article_cost.stock_value%type, --存储类型对应值
                                     strUserId        in stock_article_cost.rgst_name%type, --人员
                                     strResult        out varchar2 --返回结果
                                     ) is
  begin
    strResult := 'N|[P_insertImportBatchStock]';
    update STOCK_ARTICLE_COST
       set qty = qty + nRealQty, updt_name = strUserID, updt_date = sysdate
     where enterprise_no = strEnterpriseNo
       and warehouse_no = strWAREHOUSENO
       and owner_no = strOwnerNo
       and dept_no = strDeptNo
       and article_no = strArticleNo
       and packing_qty = nPackQty
       and import_batch_no = strImportBatchNo
       and barcode = strBarcode
       and quality = strQuality
       and produce_date = dtProduceDate
       and expire_date = dtExpireDate
       and lot_no = strLotNo
       and rsv_batch1 = strRSV_BATCH1
       and rsv_batch2 = strRSV_BATCH2
       and rsv_batch3 = strRSV_BATCH3
       and rsv_batch4 = strRSV_BATCH4
       and rsv_batch5 = strRSV_BATCH5
       and rsv_batch6 = strRSV_BATCH6
       and rsv_batch7 = strRSV_BATCH7
       and rsv_batch8 = strRSV_BATCH8 /*and stock_type=strStockType and stock_value=strStockValue*/
    ;

    if sql%notfound then
      insert into stock_article_cost
        (enterprise_no,
         warehouse_no,
         owner_no,
         dept_no,
         article_no,
         barcode,
         import_batch_no,
         produce_date,
         expire_date,
         quality,
         lot_no,
         rsv_batch1,
         rsv_batch2,
         rsv_batch3,
         rsv_batch4,
         rsv_batch5,
         rsv_batch6,
         rsv_batch7,
         rsv_batch8,
         stock_type,
         stock_value,
         packing_qty,
         qty,
         rgst_name,
         rgst_date,
         updt_name,
         updt_date)
      values
        (strEnterpriseNo,
         strWAREHOUSENO,
         strOwnerNo,
         strDeptNo,
         strArticleNo,
         strBarcode,
         strImportBatchNo,
         dtProduceDate,
         dtExpireDate,
         strQuality,
         strLotNo,
         strRSV_BATCH1,
         strRSV_BATCH2,
         strRSV_BATCH3,
         strRSV_BATCH4,
         strRSV_BATCH5,
         strRSV_BATCH6,
         strRSV_BATCH7,
         strRSV_BATCH8,
         strStockType,
         strStockValue,
         nPackQty,
         nRealQty,
         strUserId,
         sysdate,
         strUserId,
         sysdate);
    end if;

    strResult := 'Y|';

  end P_insertImportBatchStock;

  /*****************************************************************************************
       功能：退货确认，直接删除库存（封车使用）
      Modify By luozhiling AT 2015-3-24
  *****************************************************************************************/
  procedure proc_RO_deliver_DelContent(strEnterPriseNo  in stock_content.enterprise_no%type, -- 企业编号
                                       strwarehouse_no  in rodata_deliver_m.warehouse_no%type, --仓别
                                       strDeliverNo     in rodata_deliver_m.deliver_no%type, --装车建议单
                                       strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                                       strUSER_ID       in stock_content_move.rgst_name%type, --员工ID
                                       strOutMsg        out varchar2) --是否成功
   is
  begin
    strOutMsg := 'N|[proc_RO_deliver_DelContent]';

    --循环写库存三级帐
    for GetDeliverItem in (select oem.owner_no,
                                  oem.dept_no,
                                  odd.enterprise_no,
                                  odd.warehouse_no,
                                  odd.recede_no,
                                  odd.article_no,
                                  odd.barcode,
                                  odd.packing_qty,
                                  odd.produce_date,
                                  odd.expire_date,
                                  odd.quality,
                                  odd.lot_no,
                                  odd.import_batch_no,
                                  odd.rsv_batch1,
                                  odd.rsv_batch2,
                                  odd.rsv_batch3,
                                  odd.rsv_batch4,
                                  odd.rsv_batch5,
                                  odd.rsv_batch6,
                                  odd.rsv_batch7,
                                  odd.rsv_batch8,
                                  sum(article_qty) qty
                             from rodata_deliver_d odd, rodata_recede_m oem
                            where odd.enterprise_no = oem.enterprise_no
                              and odd.warehouse_no = oem.warehouse_no
                              and odd.recede_no = oem.recede_no
                              and odd.enterprise_no = strEnterpriseNo
                              and oem.warehouse_no = strwarehouse_no
                              and odd.deliver_no = strDeliverNo
                            group by oem.owner_no,
                                     oem.dept_no,
                                     odd.enterprise_no,
                                     odd.warehouse_no,
                                     odd.recede_no,
                                     odd.article_no,
                                     odd.barcode,
                                     odd.packing_qty,
                                     odd.produce_date,
                                     odd.expire_date,
                                     odd.quality,
                                     odd.lot_no,
                                     odd.import_batch_no,
                                     odd.rsv_batch1,
                                     odd.rsv_batch2,
                                     odd.rsv_batch3,
                                     odd.rsv_batch4,
                                     odd.rsv_batch5,
                                     odd.rsv_batch6,
                                     odd.rsv_batch7,
                                     odd.rsv_batch8) loop

      PKOBJ_STOCK.P_insertImportBatchStock(strEnterpriseNo,
                                           strwarehouse_no,
                                           GetDeliverItem.owner_no,
                                           GetDeliverItem.dept_no,
                                           GetDeliverItem.article_no,
                                           GetDeliverItem.quality,
                                           GetDeliverItem.import_batch_no,
                                           GetDeliverItem.produce_date,
                                           GetDeliverItem.expire_date,
                                           GetDeliverItem.lot_no,
                                           GetDeliverItem.rsv_batch1,
                                           GetDeliverItem.rsv_batch2,
                                           GetDeliverItem.rsv_batch3,
                                           GetDeliverItem.rsv_batch4,
                                           GetDeliverItem.rsv_batch5,
                                           GetDeliverItem.rsv_batch6,
                                           GetDeliverItem.rsv_batch7,
                                           GetDeliverItem.rsv_batch8,
                                           GetDeliverItem.barcode,
                                           GetDeliverItem.packing_qty,
                                           -GetDeliverItem.qty,
                                           '3',
                                           GetDeliverItem.recede_no,
                                           strUSER_ID,
                                           strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      pkobj_stock.P_InsertArticleStockList(strEnterpriseNo,
                                           strwarehouse_no,
                                           GetDeliverItem.owner_no,
                                           GetDeliverItem.dept_no,
                                           GetDeliverItem.article_no,
                                           GetDeliverItem.quality,
                                           GetDeliverItem.produce_date,
                                           GetDeliverItem.expire_date,
                                           GetDeliverItem.lot_no,
                                           GetDeliverItem.rsv_batch1,
                                           GetDeliverItem.rsv_batch2,
                                           GetDeliverItem.rsv_batch3,
                                           GetDeliverItem.rsv_batch4,
                                           GetDeliverItem.rsv_batch5,
                                           GetDeliverItem.rsv_batch6,
                                           GetDeliverItem.rsv_batch7,
                                           GetDeliverItem.rsv_batch8,
                                           GetDeliverItem.barcode,
                                           GetDeliverItem.packing_qty,
                                           -GetDeliverItem.qty,
                                           '3',
                                           GetDeliverItem.recede_no,
                                           2,
                                           'O',
                                           GetDeliverItem.recede_no,
                                           strUSER_ID,
                                           GetDeliverItem.import_batch_no,
                                           strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

    end loop;

    ----------------------------直接删除库存--------------------------------------------------------
    delete stock_content cc
     where cc.enterprise_no = strEnterPriseNo
       and cc.warehouse_no = strwarehouse_no
       and (cc.stock_value) in
           (select distinct rd.recede_no
              from rodata_deliver_d rd
             where rd.enterprise_no = strEnterPriseNo
               and rd.warehouse_no = strwarehouse_no
               and rd.deliver_no = strDeliverNo)
       and qty > 0
       and cc.instock_qty = 0
       and cc.outstock_qty = 0;
    if sql%notfound then
      strOutMsg := 'N|[E00842]';
      return;
    end if;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end proc_RO_deliver_DelContent;

  /*****************************************************************************************
       功能：报损确认，直接删除库存（封车使用）
      Modify By luozhiling AT 2015-7-28
  *****************************************************************************************/
  procedure proc_So_deliver_DelContent(strEnterPriseNo in stock_content.enterprise_no%type, -- 企业编号
                                       strwarehouse_no in sodata_waste_m.warehouse_no%type, --仓别
                                       strWasteNo      in sodata_waste_m.waste_no%type, --报损单
                                       strUSER_ID      in stock_content_move.rgst_name%type, --员工ID
                                       strOutMsg       out varchar2) --是否成功
   is
  begin
    strOutMsg := 'N|[proc_So_deliver_DelContent]';

    --循环写库存三级帐
    for GetWasteConfirm in (select sc.owner_no,
                                   sc.dept_no,
                                   sc.enterprise_no,
                                   sc.warehouse_no,
                                   swm.waste_no,
                                   sc.article_no,
                                   sai.barcode,
                                   sc.packing_qty,
                                   sai.produce_date,
                                   sai.expire_date,
                                   sai.quality,
                                   sai.lot_no,
                                   sai.import_batch_no,
                                   sai.rsv_batch1,
                                   sai.rsv_batch2,
                                   sai.rsv_batch3,
                                   sai.rsv_batch4,
                                   sai.rsv_batch5,
                                   sai.rsv_batch6,
                                   sai.rsv_batch7,
                                   sai.rsv_batch8,
                                   sum(sc.qty) qty
                              from stock_content      sc,
                                   stock_article_info sai,
                                   sodata_waste_m     swm
                             where sc.enterprise_no = sai.enterprise_no
                               and sc.enterprise_no = swm.enterprise_no
                               and sc.warehouse_no = swm.warehouse_no
                               and sc.stock_value = swm.waste_no
                               and sc.article_no = sai.article_no
                               and sc.article_id = sai.article_id
                               and sc.enterprise_no = strEnterPriseNo
                               and sc.warehouse_no = strwarehouse_no
                               and swm.waste_no = strWasteNo
                             group by sc.owner_no,
                                      sc.dept_no,
                                      sc.enterprise_no,
                                      sc.warehouse_no,
                                      swm.waste_no,
                                      sc.article_no,
                                      sai.barcode,
                                      sc.packing_qty,
                                      sai.produce_date,
                                      sai.expire_date,
                                      sai.quality,
                                      sai.lot_no,
                                      sai.import_batch_no,
                                      sai.rsv_batch1,
                                      sai.rsv_batch2,
                                      sai.rsv_batch3,
                                      sai.rsv_batch4,
                                      sai.rsv_batch5,
                                      sai.rsv_batch6,
                                      sai.rsv_batch7,
                                      sai.rsv_batch8) loop

      PKOBJ_STOCK.P_insertImportBatchStock(strEnterpriseNo,
                                           strwarehouse_no,
                                           GetWasteConfirm.owner_no,
                                           GetWasteConfirm.dept_no,
                                           GetWasteConfirm.article_no,
                                           GetWasteConfirm.quality,
                                           GetWasteConfirm.import_batch_no,
                                           GetWasteConfirm.produce_date,
                                           GetWasteConfirm.expire_date,
                                           GetWasteConfirm.lot_no,
                                           GetWasteConfirm.rsv_batch1,
                                           GetWasteConfirm.rsv_batch2,
                                           GetWasteConfirm.rsv_batch3,
                                           GetWasteConfirm.rsv_batch4,
                                           GetWasteConfirm.rsv_batch5,
                                           GetWasteConfirm.rsv_batch6,
                                           GetWasteConfirm.rsv_batch7,
                                           GetWasteConfirm.rsv_batch8,
                                           GetWasteConfirm.barcode,
                                           GetWasteConfirm.packing_qty,
                                           -GetWasteConfirm.qty,
                                           '3',
                                           strWasteNo,
                                           strUSER_ID,
                                           strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      pkobj_stock.P_InsertArticleStockList(strEnterpriseNo,
                                           strwarehouse_no,
                                           GetWasteConfirm.owner_no,
                                           GetWasteConfirm.dept_no,
                                           GetWasteConfirm.article_no,
                                           GetWasteConfirm.quality,
                                           GetWasteConfirm.produce_date,
                                           GetWasteConfirm.expire_date,
                                           GetWasteConfirm.lot_no,
                                           GetWasteConfirm.rsv_batch1,
                                           GetWasteConfirm.rsv_batch2,
                                           GetWasteConfirm.rsv_batch3,
                                           GetWasteConfirm.rsv_batch4,
                                           GetWasteConfirm.rsv_batch5,
                                           GetWasteConfirm.rsv_batch6,
                                           GetWasteConfirm.rsv_batch7,
                                           GetWasteConfirm.rsv_batch8,
                                           GetWasteConfirm.barcode,
                                           GetWasteConfirm.packing_qty,
                                           -GetWasteConfirm.qty,
                                           '3',
                                           strWasteNo,
                                           2,
                                           'O',
                                           strWasteNo,
                                           strUSER_ID,
                                           GetWasteConfirm.import_batch_no,
                                           strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

    end loop;

    ----------------------------直接删除库存--------------------------------------------------------
    delete stock_content cc
     where cc.enterprise_no = strEnterPriseNo
       and cc.warehouse_no = strwarehouse_no
       and cc.stock_value = strWasteNo
       and qty > 0
       and cc.instock_qty = 0
       and cc.outstock_qty = 0;
    if sql%notfound then
      strOutMsg := 'N|[E00842]';
      return;
    end if;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end proc_So_deliver_DelContent;
  /*************************************************************************************************
  功能说明：1、判断货主是否绑定储位管理；
            2、若不绑定储位，根据是否混货主的标识来更新或者新增储位与货主的对应关系
            3,根据是否混载储位的标识来更新或者新增商品与储位的对应关系。
  ***************************************************************************************************/
  procedure P_InsertOwnerCell(strEnterpriseNo in idata_instock_m.enterprise_no%type,
                              strWareHouseNo  in idata_instock_m.warehouse_no%type,
                              strOwnerNo      in bdef_defowner.owner_no%type,
                              strCellNo       in idata_instock_d.dest_cell_no%type,
                              strArticleNo    in idata_instock_d.article_no%type,
                              strResult       out varchar2) is
    v_strFixedCellNo  bdef_defowner.fixedcell_flag%type;
    v_strMixOwnerFlag cdef_defcell.mix_owner%type;
    v_strMixFlag      cdef_defcell.mix_flag%type;
    v_iCount          integer;
  begin
    strResult := 'N|[P_InsertOwnerCell]';
    begin
      select bd.FIXEDCELL_FLAG
        into v_strFixedCellNo
        from bdef_defowner bd
       where bd.enterprise_no = strEnterpriseNo
         and bd.owner_no = strOwnerNo;
    exception
      when no_data_found then
        strResult := 'N|[找不到相应的货主信息]';
        return;
    end;

    --检查目的储位是否是作业区
    begin
      select count(*),
             nvl(cc.mix_owner, 0) mix_owner,
             nvl(cc.mix_flag, 0) mix_flag
        into v_iCount, v_strMixOwnerFlag, v_strMixFlag
        from cdef_defarea cd, cdef_defcell cc
       where cd.enterprise_no = cc.enterprise_no
         and cd.warehouse_no = cc.warehouse_no
         AND CD.ware_no = cc.ware_no
         and cd.area_no = cc.area_no
         and cd.enterprise_no = strEnterpriseNo
         and cd.warehouse_no = strWareHouseNo
         and cc.cell_no = strCellNo
         and cc.cell_status in ('0', '2')
         and cc.check_status = '0'
         and cd.AREA_USETYPE in ('1', '6')
         and cd.AREA_ATTRIBUTE = '0'
       group by cc.mix_owner, cc.mix_flag;

      if v_iCount > 0 then
        if v_strFixedCellNo = '0' then
          --不绑定储位
          if v_strMixOwnerFlag = '1' then
            --可混货主
            --建议货主与储位的所属关系

            update stock_owner_cell t
               set t.updt_date = sysdate
             where t.enterprise_no = strEnterpriseNo
               and t.warehouse_no = strWareHouseNo
               and t.cell_no = strCellNo
               and t.owner_no = strOwnerNo;

            if sql%notfound then
              insert into stock_owner_cell
                (enterprise_no, warehouse_no, owner_no, cell_no, updt_date)
              values
                (strEnterpriseNo,
                 strWareHouseNo,
                 strOwnerNo,
                 strCellNo,
                 sysdate);
            end if;
          else
            --不可混货主
            update stock_owner_cell t
               set t.owner_no = strOwnerNo, t.updt_date = sysdate
             where t.enterprise_no = strEnterpriseNo
               and t.warehouse_no = strWareHouseNo
               and t.cell_no = strCellNo /*and t.owner_no<>strOwnerNo*/
            ;
            if sql%notfound then
              insert into stock_owner_cell
                (enterprise_no, warehouse_no, owner_no, cell_no, updt_date)
              values
                (strEnterpriseNo,
                 strWareHouseNo,
                 strOwnerNo,
                 strCellNo,
                 sysdate);
            end if;
          end if;

          if v_strMixFlag = '0' or v_strMixFlag = '1' then
            --不可混商品
            --Modify BY QZH AT 2016-8-16
            --建议商品与储位的所属关系
            delete from stock_Art_cell t
             where t.cell_no = strCellNo
               and t.enterprise_no = strEnterpriseNo
               and t.warehouse_no = strWareHouseNo;

            insert into stock_Art_cell
              (enterprise_no, warehouse_no, cell_no, article_no, updt_date)
            values
              (strEnterpriseNo,
               strWareHouseNo,
               strCellNo,
               strArticleNo,
               sysdate);
          else
            --建议商品与储位的所属关系
            update stock_Art_cell t
               set t.updt_date = sysdate
             where t.enterprise_no = strEnterpriseNo
               and t.warehouse_no = strWareHouseNo
               and t.cell_no = strCellNo
               and t.article_no = strArticleNo;

            if sql%notfound then
              insert into stock_Art_cell
                (enterprise_no,
                 warehouse_no,
                 cell_no,
                 article_no,
                 updt_date)
              values
                (strEnterpriseNo,
                 strWareHouseNo,
                 strCellNo,
                 strArticleNo,
                 sysdate);
            end if;
          end if;
        end if;
      end if;
    exception
      when no_data_found then
        strResult := 'Y|[]';
        return;
    end;

    strResult := 'Y|[]';
  end P_InsertOwnerCell;

  /**************************************************************************************************
  功能说明：
          1、上架储位的校验：
          1）、上架的储位必须是作业区的可用储位；
          2）、必须是同机构的储位；（预留）
          3）、查找此货主是否是绑定储位；
          3.1）若绑定储位，只能找绑定关系的储位；且判断是否可混、混商品，货主混属性
          3.2）若不绑定储位，判断目的储位是否是混货主的储位，若不可混货主，则只能是空储位，或存放该货主货品的储位

  2015.12.7
  **************************************************************************************************/
  procedure CheckRealInstockCell(strEnterpriseNo in idata_instock_m.enterprise_no%type,
                                 strWareHouseNo  in idata_instock_m.warehouse_no%type,
                                 strOwnerNo      in bdef_defowner.owner_no%type,
                                 strArticleNo    in idata_instock_d.article_no%type,
                                 dtProduceDate   in idata_check_d.produce_date%type,
                                 dtExpireDate    in idata_check_d.expire_date%type,
                                 strQuality      in idata_check_d.quality%type, --品质
                                 strLotNo        in idata_check_d.lot_no%type, --批次号
                                 strRSV_BATCH1   in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                                 strRSV_BATCH2   in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                                 strRSV_BATCH3   in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                                 strRSV_BATCH4   in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                                 strRSV_BATCH5   in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                                 strRSV_BATCH6   in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                                 strRSV_BATCH7   in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                                 strRSV_BATCH8   in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                                 strDCellNo      in idata_instock_d.real_cell_no%type, --实际上架储位
                                 strResult       out varchar2) is
    v_strFixedCell    bdef_defowner.fixedcell_flag%type;
    v_iCount          integer;
    v_strMixFlag      cdef_defcell.mix_flag%type; --0:不可混，1：混属性；2：混商品
    v_strMixOwnerFlag cdef_defcell.mix_owner%type; --0：不可混，1：可混

    i integer := 0;

    v_strSQL varchar(2048);

  begin
    strResult := 'N|[CheckRealInstockCell]';
    --只能是作业区
    begin
      select count(*), nvl(cc.mix_flag, 0), nvl(cc.mix_owner, 0)
        into v_iCount, v_strMixFlag, v_strMixOwnerFlag
        from cdef_defarea cd, cdef_defcell cc
       where cd.enterprise_no = cc.enterprise_no
         and cd.warehouse_no = cc.warehouse_no
         and cd.ware_no = cc.ware_no
         and cd.area_no = cc.area_no
         and cd.enterprise_no = strEnterpriseNo
         and cd.warehouse_no = strWareHouseNo
         and cc.cell_no = strDCellNo
         and cc.cell_status in ('0', '2')
         and cc.check_status = '0'
         and cd.AREA_USETYPE in ('1', '5', '6')
         and cd.AREA_ATTRIBUTE = '0'
       group by cc.mix_flag, cc.mix_owner;

    exception
      when no_data_found then
        strResult := 'N|[此上架储位不可上架]';
        return;
    end;

    --判断此储位是否可混
    if v_strMixFlag = '0' then
      --不可混载
      --检查是否有其他库存
      v_strSQL := ' select count(1) from stock_content t,stock_article_info sai
            where t.enterprise_no= ''' || strEnterpriseNo ||
                  ''' and t.warehouse_no= ''' || strWareHouseNo || '''
            and t.enterprise_no=sai.enterprise_no and t.article_no=sai.article_no
            and t.article_id=sai.article_id
            and t.cell_no= ''' || strDCellNo || '''
            and (t.article_no <> ''' || strArticleNo ||
                  '''  ';
      for curBatch in (select lower(d.field_id) as field_id
                         from bset_article_batch_d d
                        where exists
                        (select 'x'
                                 from bdef_defarticle bda
                                where bda.enterprise_no = strEnterPriseNo
                                  and bda.article_no = strArticleNo
                                  and bda.batch_id = d.batch_id)) loop

        v_strSQL := v_strSQL || '  or ';

        if curBatch.Field_Id = 'produce_date' then
          v_strSQL := v_strSQL || ' sai.produce_date <> to_date(' ||
                      to_char(dtProduceDate, 'yyyymmdd') ||
                      ',''yyyymmdd'')';
        end if;

        if curBatch.Field_Id = 'expire_date' then
          v_strSQL := v_strSQL || ' sai.expire_date <> to_date(' ||
                      to_char(dtExpireDate, 'yyyymmdd') || ',''yyyymmdd'')';
        end if;

        if curBatch.Field_Id = 'quality' then
          v_strSQL := v_strSQL || ' sai.quality <> ''' || strQuality || '''';
        end if;

        if curBatch.Field_Id = 'lot_no' then
          v_strSQL := v_strSQL || ' sai.lot_no <> ''' || strLotNo || '''';
        end if;

        if curBatch.Field_Id = 'rsv_batch1' then
          v_strSQL := v_strSQL || ' sai.rsv_batch1 <> ''' || strRSV_BATCH1 || '''';
        end if;

        if curBatch.Field_Id = 'rsv_batch2' then
          v_strSQL := v_strSQL || ' sai.rsv_batch2 <> ''' || strRSV_BATCH2 || '''';
        end if;

        if curBatch.Field_Id = 'rsv_batch3' then
          v_strSQL := v_strSQL || ' sai.rsv_batch3 <> ''' || strRSV_BATCH3 || '''';
        end if;

        if curBatch.Field_Id = 'rsv_batch4' then
          v_strSQL := v_strSQL || ' sai.rsv_batch4 <> ''' || strRSV_BATCH4 || '''';
        end if;

        if curBatch.Field_Id = 'rsv_batch5' then
          v_strSQL := v_strSQL || ' sai.rsv_batch5 <> ''' || strRSV_BATCH5 || '''';
        end if;

        if curBatch.Field_Id = 'rsv_batch6' then
          v_strSQL := v_strSQL || ' sai.rsv_batch6 <> ''' || strRSV_BATCH6 || '''';
        end if;

        if curBatch.Field_Id = 'rsv_batch7' then
          v_strSQL := v_strSQL || ' sai.rsv_batch7 <> ''' || strRSV_BATCH7 || '''';
        end if;

        if curBatch.Field_Id = 'rsv_batch8' then
          v_strSQL := v_strSQL || ' sai.rsv_batch8 <> ''' || strRSV_BATCH8 || '''';
        end if;

      end loop;
      v_strSQL := v_strSQL || '  ) ';

      execute immediate v_strSQL
        into v_iCount;

      if v_iCount > 0 then
        strResult := 'N|[不可混载的储位不可放入不同商品或不同批次相同商品]';
        return;
      end if;
    end if;

    if v_strMixFlag = '1' then
      --可混同商品
      --检查是否有其他库存
      select count(*)
        into v_iCount
        from stock_content t
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.cell_no = strDCellNo
         and t.article_no <> strArticleNo;

      if v_iCount > 0 then
        strResult := 'N|[不可混载商品]';
        return;
      end if;
    end if;

    --获取货主对应的储位绑定标识
    begin
      select bd.FIXEDCELL_FLAG
        into v_strFixedCell
        from bdef_defowner bd
       where bd.enterprise_no = strEnterpriseNo
         and bd.owner_no = strOwnerNo;
    exception
      when no_data_found then
        strResult := 'N|[找不到货主信息]';
        return;
    end;

    if v_strFixedCell = '0' then
      --不绑定储位
      --
      if v_strMixOwnerFlag = '0' then
        select count(*)
          into v_iCount
          from stock_content soc
         where soc.enterprise_no = strEnterPriseNo
           and soc.warehouse_no = strWareHouseNo
           and soc.cell_no = strDCellNo
           and soc.owner_no <> strOwnerNo;

        if v_iCount > 0 then
          strResult := 'N|[该储位已被其他货主暂用]';
          return;
        end if;
      end if;
    else
      select count(*)
        into v_iCount
        from cset_owner_cell coc
       where coc.enterprise_no = strEnterpriseNo
         and coc.warehouse_no = strWareHouseNo
         and coc.owner_no = strOwnerNo
         and coc.cell_no = strDCellNo;
      if v_iCount = 0 then
        strResult := 'N|[找不到此货主对应的储位]';
        return;
      end if;
    end if;

    strResult := 'Y|[]';
  end CheckRealInstockCell;

  /**************************************************************************************************
  功能说明：
          1、移库目的储位的校验：
          1）、移库目的储位必须是作业区的可用储位；
          2）、必须是同机构的储位；（预留）
          3）、查找此货主是否是绑定储位；
          3.1）若绑定储位，只能找绑定关系的储位；且判断是否可混、混商品，货主混属性
          3.2）若不绑定储位，判断目的储位是否是混货主的储位，若不可混货主，则只能是空储位，或存放该货主货品的储位

  2015.12.7
  **************************************************************************************************/
  procedure CheckMoveDestCell(strEnterpriseNo in idata_instock_m.enterprise_no%type,
                              strWareHouseNo  in idata_instock_m.warehouse_no%type,
                              strOwnerNo      in bdef_defowner.owner_no%type,
                              strArticleNo    in idata_instock_d.article_no%type,
                              dtProduceDate   in idata_check_d.produce_date%type,
                              dtExpireDate    in idata_check_d.expire_date%type,
                              strQuality      in idata_check_d.quality%type, --品质
                              strLotNo        in idata_check_d.lot_no%type, --批次号
                              strRSV_BATCH1   in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                              strRSV_BATCH2   in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                              strRSV_BATCH3   in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                              strRSV_BATCH4   in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                              strRSV_BATCH5   in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                              strRSV_BATCH6   in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                              strRSV_BATCH7   in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                              strRSV_BATCH8   in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                              strDCellNo      in idata_instock_d.real_cell_no%type, --实际上架储位
                              strResult       out varchar2) is
    v_strFixedCell    bdef_defowner.fixedcell_flag%type;
    v_iCount          integer;
    v_strMixFlag      cdef_defcell.mix_flag%type; --0:不可混，1：混属性；2：混商品
    v_strMixOwnerFlag cdef_defcell.mix_owner%type; --0：不可混，1：可混
    v_strAreaUseType  cdef_defarea.area_usetype%type; --储区用途

    i integer := 0;

    v_strSQL varchar(2048);

  begin
    strResult := 'N|[CheckMoveDestCell]';

    begin
      select count(*),
             nvl(cc.mix_flag, 0),
             nvl(cc.mix_owner, 0),
             nvl(cd.area_usetype, '0')
        into v_iCount, v_strMixFlag, v_strMixOwnerFlag, v_strAreaUseType
        from cdef_defarea cd, cdef_defcell cc
       where cd.enterprise_no = cc.enterprise_no
         and cd.warehouse_no = cc.warehouse_no
         and cd.ware_no = cc.ware_no
         and cd.area_no = cc.area_no
         and cd.enterprise_no = strEnterpriseNo
         and cd.warehouse_no = strWareHouseNo
         and cc.cell_no = strDCellNo
         and cc.cell_status in ('0', '2')
         and cc.check_status = '0'
       group by cc.mix_flag, cc.mix_owner, cd.area_usetype;

    exception
      when no_data_found then
        strResult := 'N|[此上架储位不可上架]';
        return;
    end;

    if v_strAreaUseType = '1' or v_strAreaUseType = '6' then

      --判断此储位是否可混
      if v_strMixFlag = '0' then
        --不可混载
        --检查是否有其他库存
        v_strSQL := ' select count(1) from stock_content t,stock_article_info sai
            where t.enterprise_no= ''' ||
                    strEnterpriseNo || ''' and t.warehouse_no= ''' ||
                    strWareHouseNo || '''
            and t.enterprise_no=sai.enterprise_no and t.article_no=sai.article_no
            and t.article_id=sai.article_id
            and t.cell_no= ''' || strDCellNo || '''
            and (t.article_no <> ''' || strArticleNo ||
                    '''  ';
        for curBatch in (select lower(d.field_id) as field_id
                           from bset_article_batch_d d
                          where exists
                          (select 'x'
                                   from bdef_defarticle bda
                                  where bda.enterprise_no = strEnterPriseNo
                                    and bda.article_no = strArticleNo
                                    and bda.batch_id = d.batch_id)) loop

          v_strSQL := v_strSQL || '  or ';

          if curBatch.Field_Id = 'produce_date' then
            v_strSQL := v_strSQL || ' sai.produce_date <> to_date(' ||
                        to_char(dtProduceDate, 'yyyymmdd') ||
                        ',''yyyymmdd'')';
          end if;

          if curBatch.Field_Id = 'expire_date' then
            v_strSQL := v_strSQL || ' sai.expire_date <> to_date(' ||
                        to_char(dtExpireDate, 'yyyymmdd') ||
                        ',''yyyymmdd'')';
          end if;

          if curBatch.Field_Id = 'quality' then
            v_strSQL := v_strSQL || ' sai.quality <> ''' || strQuality || '''';
          end if;

          if curBatch.Field_Id = 'lot_no' then
            v_strSQL := v_strSQL || ' sai.lot_no <> ''' || strLotNo || '''';
          end if;

          if curBatch.Field_Id = 'rsv_batch1' then
            v_strSQL := v_strSQL || ' sai.rsv_batch1 <> ''' ||
                        strRSV_BATCH1 || '''';
          end if;

          if curBatch.Field_Id = 'rsv_batch2' then
            v_strSQL := v_strSQL || ' sai.rsv_batch2 <> ''' ||
                        strRSV_BATCH2 || '''';
          end if;

          if curBatch.Field_Id = 'rsv_batch3' then
            v_strSQL := v_strSQL || ' sai.rsv_batch3 <> ''' ||
                        strRSV_BATCH3 || '''';
          end if;

          if curBatch.Field_Id = 'rsv_batch4' then
            v_strSQL := v_strSQL || ' sai.rsv_batch4 <> ''' ||
                        strRSV_BATCH4 || '''';
          end if;

          if curBatch.Field_Id = 'rsv_batch5' then
            v_strSQL := v_strSQL || ' sai.rsv_batch5 <> ''' ||
                        strRSV_BATCH5 || '''';
          end if;

          if curBatch.Field_Id = 'rsv_batch6' then
            v_strSQL := v_strSQL || ' sai.rsv_batch6 <> ''' ||
                        strRSV_BATCH6 || '''';
          end if;

          if curBatch.Field_Id = 'rsv_batch7' then
            v_strSQL := v_strSQL || ' sai.rsv_batch7 <> ''' ||
                        strRSV_BATCH7 || '''';
          end if;

          if curBatch.Field_Id = 'rsv_batch8' then
            v_strSQL := v_strSQL || ' sai.rsv_batch8 <> ''' ||
                        strRSV_BATCH8 || '''';
          end if;

        end loop;
        v_strSQL := v_strSQL || '  ) ';

        execute immediate v_strSQL
          into v_iCount;

        if v_iCount > 0 then
          strResult := 'N|[不可混载的储位不可放入不同商品或不同批次相同商品]';
          return;
        end if;
      end if;

      if v_strMixFlag = '1' then
        --可混同商品
        --检查是否有其他库存
        select count(*)
          into v_iCount
          from stock_content t
         where t.enterprise_no = strEnterpriseNo
           and t.warehouse_no = strWareHouseNo
           and t.cell_no = strDCellNo
           and t.article_no <> strArticleNo;

        if v_iCount > 0 then
          strResult := 'N|[不可混载商品]';
          return;
        end if;
      end if;

      --获取货主对应的储位绑定标识
      begin
        select bd.FIXEDCELL_FLAG
          into v_strFixedCell
          from bdef_defowner bd
         where bd.enterprise_no = strEnterpriseNo
           and bd.owner_no = strOwnerNo;
      exception
        when no_data_found then
          strResult := 'N|[找不到货主信息]';
          return;
      end;

      if v_strFixedCell = '0' then
        --不绑定储位
        --
        if v_strMixOwnerFlag = '0' then
          select count(*)
            into v_iCount
            from stock_content soc
           where soc.enterprise_no = strEnterPriseNo
             and soc.warehouse_no = strWareHouseNo
             and soc.cell_no = strDCellNo
             and soc.owner_no <> strOwnerNo;

          if v_iCount > 0 then
            strResult := 'N|[该储位已被其他货主暂用]';
            return;
          end if;
        end if;
      else
        select count(*)
          into v_iCount
          from cset_owner_cell coc
         where coc.enterprise_no = strEnterpriseNo
           and coc.warehouse_no = strWareHouseNo
           and coc.owner_no = strOwnerNo
           and coc.cell_no = strDCellNo;
        if v_iCount = 0 then
          strResult := 'N|[找不到此货主对应的储位]';
          return;
        end if;
      end if;
    end if;

    strResult := 'Y|[]';
  end CheckMoveDestCell;

  /*转换库存：C to B */
  procedure p_TransContent_C2B(strEnterPriseNo  in stock_content.enterprise_no%type, -- 企业编号
                               strWAREHOUSE_NO  in stock_content.WAREHOUSE_NO%type, --仓库编码
                               strCell_No       in stock_content.cell_no%type, --储位
                               strCell_ID       in stock_content.cell_id%type,
                               nArticle_QTY     IN stock_content.qty%type, --数量
                               nOutstock_QTY    IN stock_content.outstock_qty%type,
                               nQMinOperatePack in bdef_defarticle.qmin_operate_packing%type,
                               nOutCell_ID      out stock_content.cell_id%type,
                               strOutMsg        out varchar2) --返回 执行结果
   is
    v_Cell_ID stock_content.cell_id%type; --储位id

  begin

    strOutMsg   := 'N|[p_TransContent_C2B]';
    nOutCell_ID := -1;

    update stock_content sc
       set sc.qty          = sc.qty - nArticle_QTY,
           sc.outstock_qty = sc.outstock_qty - nOutstock_QTY
     where sc.cell_no = strCell_No
       and sc.cell_id = strCell_ID
       and sc.enterprise_no = strEnterPriseNo
       and sc.warehouse_no = strWAREHOUSE_NO
       and sc.qty >= nArticle_QTY
       and sc.outstock_qty >= nOutstock_QTY;

    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E00386]';
      return;
    end if;

    select SEQ_stock_CONTENT.nextval into v_Cell_ID from dual;

    insert into stock_content
      (enterprise_no,
       WAREHOUSE_NO,
       owner_no,
       dept_no,
       cell_no,
       cell_id,
       ARTICLE_NO,
       ARTICLE_ID,
       PACKING_QTY,
       qty,
       outstock_qty,
       instock_qty,
       unusual_qty,
       rgst_name,
       rgst_date,
       UPDT_NAME,
       UPDT_DATE,
       status,
       flag,
       instock_type,
       stock_type,
       stock_VALUE,
       Label_No,
       sub_label_no,
       Mv_hand_flag)
      select t.enterprise_no,
             t.warehouse_no,
             t.owner_no,
             t.dept_no,
             t.cell_no,
             v_Cell_ID,
             t.article_no,
             t.article_id,
             nQMinOperatePack,
             nArticle_QTY,
             nOutstock_QTY,
             0,
             0,
             t.rgst_name,
             sysdate,
             t.updt_name,
             sysdate,
             t.status,
             t.flag,
             t.instock_type,
             t.stock_type,
             t.stock_value,
             t.label_no,
             sub_label_no,
             t.mv_hand_flag
        from stock_content t
       where t.warehouse_no = strWAREHOUSE_NO
         and t.enterprise_no = strEnterPriseNo
         and t.cell_no = strCell_No
         and t.cell_id = strCell_ID;

    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E00007]';
      return;
    end if;

    delete stock_content t
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWAREHOUSE_NO
       and t.cell_no = strCell_No
       and t.cell_id = strCell_ID
       and t.qty = 0
       and t.outstock_qty = 0
       and t.instock_qty = 0;

    nOutCell_ID := v_Cell_ID;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_TransContent_C2B;

  /*转换库存: B to C */
  procedure p_TransContent_B2C(strEnterPriseNo in stock_content.enterprise_no%type, -- 企业编号
                               strWAREHOUSE_NO in stock_content.WAREHOUSE_NO%type, --仓库编码
                               strCell_No      in stock_content.cell_no%type, --储位
                               strCell_ID      in stock_content.cell_id%type,
                               strArticle_No   in bdef_defarticle.article_no%type,
                               nArticle_QTY    IN stock_content.qty%type, --数量
                               strOutMsg       out varchar2) --返回 执行结果
   is
    v_Cell_ID      stock_content.cell_id%type; --储位id
    v_TotalArticle stock_content.qty%type := nArticle_QTY;
    v_AllotQTY     stock_content.qty%type := nArticle_QTY;
  begin

    strOutMsg := 'N|[p_TransContent_B2C]';

    for v_curPacking in (select packing_qty
                           from bdef_article_packing bap,
                                bdef_defarticle      bda
                          where bap.article_no = strArticle_No
                            and bap.enterprise_no = strEnterPriseNo
                            and bap.article_no = bda.article_no
                            and bap.enterprise_no = bda.enterprise_no
                            and bap.packing_qty > bda.qmin_operate_packing
                          order by bap.packing_qty desc) loop

      if v_TotalArticle <= v_curPacking.packing_qty then
        goto next_loop;
      end if;

      v_AllotQTY := floor(v_TotalArticle / v_curPacking.packing_qty) *
                    v_curPacking.packing_qty;

      v_TotalArticle := v_TotalArticle - v_AllotQTY;

      update stock_content sc
         set sc.qty = sc.qty - v_AllotQTY
       where sc.cell_no = strCell_No
         and sc.cell_id = strCell_ID
         and sc.enterprise_no = strEnterPriseNo
         and sc.warehouse_no = strWAREHOUSE_NO
         and sc.qty - sc.outstock_qty >= v_AllotQTY;

      if sql%rowcount <= 0 then
        strOutMsg := 'N|[E00386]';
        return;
      end if;

      select SEQ_stock_CONTENT.nextval into v_Cell_ID from dual;

      insert into stock_content
        (enterprise_no,
         WAREHOUSE_NO,
         owner_no,
         dept_no,
         cell_no,
         cell_id,
         ARTICLE_NO,
         ARTICLE_ID,
         PACKING_QTY,
         qty,
         outstock_qty,
         instock_qty,
         unusual_qty,
         rgst_name,
         rgst_date,
         UPDT_NAME,
         UPDT_DATE,
         status,
         flag,
         instock_type,
         stock_type,
         stock_VALUE,
         Label_No,
         sub_label_no,
         Mv_hand_flag)
        select t.enterprise_no,
               t.warehouse_no,
               t.owner_no,
               t.dept_no,
               t.cell_no,
               v_Cell_ID,
               t.article_no,
               t.article_id,
               v_curPacking.Packing_Qty,
               v_AllotQTY,
               0,
               0,
               0,
               t.rgst_name,
               sysdate,
               t.updt_name,
               sysdate,
               t.status,
               t.flag,
               t.instock_type,
               t.stock_type,
               t.stock_value,
               t.label_no,
               sub_label_no,
               t.mv_hand_flag
          from stock_content t
         where t.warehouse_no = strWAREHOUSE_NO
           and t.enterprise_no = strEnterPriseNo
           and t.cell_no = strCell_No
           and t.cell_id = strCell_ID;

      if sql%rowcount <= 0 then
        strOutMsg := 'N|[E00007]';
        return;
      end if;

      <<next_loop>>
      null;
    end loop;

    delete stock_content t
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWAREHOUSE_NO
       and t.cell_no = strCell_No
       and t.cell_id = strCell_ID
       and t.qty = 0
       and t.outstock_qty = 0
       and t.instock_qty = 0;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_TransContent_B2C;

  /*更新库存报警冻结标识 */
  procedure proc_up_container_flag  as

    --@intTransFlag: 0/内部不下事务 1/在内部下事务

    curDate   date; -- 当前时间
    errType   integer; -- 日志类型 0:信息 1:告警 2:错误
    errID     integer; -- 错误编号
    errSource varchar2(50); -- 错误源
    errMessage varchar2(50);

    iErrFlag    integer;
    nLognextval number;
    nCount NUMBER;

  begin

    set transaction read write; --开始事务
    iErrFlag   := 0;
    nCount := 0;
    errMessage := 'N|[E00025]';

    --更新报警库存
    UPDATE STOCK_CONTENT A
       SET A.FLAG = '1', A.UPDT_DATE = SYSDATE
     WHERE A.ROWID IN (SELECT B.ROWID
                         FROM STOCK_CONTENT      B,
                              STOCK_ARTICLE_INFO CAI,
                              CDEF_DEFCELL       CE,
                              CDEF_DEFAREA       CA,
                              BDEF_DEFARTICLE    C
                        WHERE B.ARTICLE_NO = CAI.ARTICLE_NO
                          AND B.ARTICLE_ID = CAI.ARTICLE_ID
                          AND B.ARTICLE_NO = C.ARTICLE_NO
                          AND CAI.EXPIRE_DATE - TRUNC(SYSDATE) <=
                              C.EXPIRY_DAYS * C.ALARMRATE / 100
                          AND B.WAREHOUSE_NO = CE.WAREHOUSE_NO
                          AND B.CELL_NO = CE.CELL_NO
                          AND CE.WAREHOUSE_NO = CA.WAREHOUSE_NO
                          AND CE.WARE_NO = CA.WARE_NO
                          AND CE.AREA_NO = CA.AREA_NO
                          and CA.attribute_type = '0'
                          AND CA.AREA_ATTRIBUTE IN ('0', '3', '4')
                          AND C.EXPIRY_DAYS > 0
                          AND B.QTY > 0
                          and C.virtual_flag = '0'
                          AND NVL(B.FLAG, '0') = '0');
                          
    FOR GetAlarmStock in(SELECT enterprise_no,warehouse_no,COUNT(DISTINCT article_no) AS articlenum 
      FROM STOCK_CONTENT WHERE flag = '1' GROUP BY enterprise_no,warehouse_no)LOOP
      INSERT INTO wms_defmessage(enterprise_no,warehouse_no,message_module,worker_no,message_id,message_desc,status,rgst_date)
      VALUES(GetAlarmStock.enterprise_no,GetAlarmStock.warehouse_no,'ODATA','admin',SEQ_WMS_DEFMESSAGE.Nextval,
      '有'||GetAlarmStock.articlenum||'个商品库存达到报警，请注意!','10',SYSDATE);
    END LOOP;
    
    iErrFlag := 1;
    --更新冻结库存
    UPDATE STOCK_CONTENT A
       SET A.FLAG = '2', A.UPDT_DATE = SYSDATE
     WHERE A.ROWID IN (SELECT B.ROWID
                         FROM STOCK_CONTENT      B,
                              STOCK_ARTICLE_INFO CAI,
                              CDEF_DEFCELL       CE,
                              CDEF_DEFAREA       CA,
                              BDEF_DEFARTICLE    C
                        WHERE B.ARTICLE_NO = CAI.ARTICLE_NO
                          AND B.ARTICLE_ID = CAI.ARTICLE_ID
                          AND B.ARTICLE_NO = C.ARTICLE_NO
                          AND CAI.EXPIRE_DATE - TRUNC(SYSDATE) <=
                              C.EXPIRY_DAYS * C.FREEZERATE / 100
                          AND B.WAREHOUSE_NO = CE.WAREHOUSE_NO
                          AND B.CELL_NO = CE.CELL_NO
                          AND CE.WAREHOUSE_NO = CA.WAREHOUSE_NO
                          AND CE.WARE_NO = CA.WARE_NO
                          AND CE.AREA_NO = CA.AREA_NO
                          and CA.attribute_type = '0'
                          AND CA.AREA_ATTRIBUTE IN ('0', '3', '4')
                          and CA.AREA_USETYPE NOT IN ('2', '3')
                          AND C.EXPIRY_DAYS > 0
                          AND B.QTY > 0
                          and C.virtual_flag = '0'
                          AND NVL(B.FLAG, '0') < '2');
                          
    FOR GetFreezeStock in(SELECT enterprise_no,warehouse_no,COUNT(DISTINCT article_no) AS articlenum 
      FROM STOCK_CONTENT WHERE flag = '2' GROUP BY enterprise_no,warehouse_no)LOOP
      INSERT INTO wms_defmessage(enterprise_no,warehouse_no,message_module,worker_no,message_id,message_desc,status,rgst_date)
      VALUES(GetFreezeStock.enterprise_no,GetFreezeStock.warehouse_no,'ODATA','admin',SEQ_WMS_DEFMESSAGE.Nextval,
      '有'||GetFreezeStock.articlenum||'个商品库存达到冻结比率，请注意!','10',SYSDATE);
    END LOOP;
    
    commit;

    errMessage := 'Y|';
  exception
    when others then
      begin
        rollback;
        if iErrFlag = 0 then
          errType    := 2;
          errID      := sqlcode;
          errSource  := 'ORACLE';
          errMessage := 'N|向数据表(CONTAINER_CONTENT)更新报警数据时发生错误';
        end if;
        if iErrFlag = 1 then
          errType    := 2;
          errID      := sqlcode;
          errSource  := 'ORACLE';
          errMessage := 'N|从数据表(CONTAINER_CONTENT)更新冻结数据时发生错误';
        end if;
      end;
  end proc_up_container_flag;

  /*界面更新库存FLAG标识*/
procedure proc_up_container_flagUI(strEnterPriseNo  in stock_content.enterprise_no%type, -- 企业编号
                                  strWAREHOUSE_NO  in stock_content.WAREHOUSE_NO%type, --仓库编码
                                  strcell_id       in stock_content.cell_id%type, --储位ID
                                  strcell_no       in stock_content.cell_no%type, --储位
                                  strFlag     in stock_content.flag%type, --库存状态：2-冻结；3-解冻
                                  strUser_id       in stock_content.Rgst_Name%type, --操作人员
                                  strOutMsg        out varchar2) --返回 执行结果
   is

  begin
    strOutMsg := 'N|[proc_up_container_flagUI]';

    -----------修改库存状态------------------------
    update STOCK_CONTENT CC set CC.flag = strFlag,
          CC.updt_name= strUser_id,CC.updt_date=sysdate
          where  CC.ENTERPRISE_NO = strEnterPriseNo
           AND CC.WAREHOUSE_NO= strWAREHOUSE_NO
          AND CC.CELL_NO= strcell_no
           AND CC.CELL_ID= strcell_id;

      -----------------------------------修改记录为0行------------------------
        if sql%notfound then
          strOutMsg := 'N|[E00007]';
          return;
        end if;
    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end proc_up_container_flagUI;

end PKOBJ_STOCK;

/

