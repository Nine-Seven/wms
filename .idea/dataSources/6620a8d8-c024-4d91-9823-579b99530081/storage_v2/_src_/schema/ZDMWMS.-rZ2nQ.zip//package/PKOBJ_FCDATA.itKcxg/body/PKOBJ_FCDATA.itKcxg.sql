create package body        PKOBJ_FCDATA is

/**********************************************************************************************************
   luozhiling
   2013.11.16
   功能：按盘点计划成需求,一盘点计划单成一张需求单
***********************************************************************************************************/
    procedure P_Fcdata_Request(strEnterPriseNo         in    fcdata_plan_m.enterprise_no%type,
                               strWareHouseNo          in    fcdata_plan_m.warehouse_no%type,--仓库编码
                               strOwnerNo              in    fcdata_plan_m.owner_no%type,
                               strUserId               in    fcdata_plan_m.rgst_name%type,
                               strPlanNo               in    fcdata_plan_m.plan_no%type,--盘点计划单号
                               strRequstNo             OUT   fcdata_request_m.request_no%type,--盘点需求单号
                               strResult               OUT    varchar2)is
         v_strPlanType            fcdata_request_m.plan_type%type;
    begin
      strResult := 'N|[P_Fcdata_Request]';

      begin
          select fpm.plan_type into v_strPlanType
          from fcdata_plan_m fpm where fpm.enterprise_no=strEnterPriseNo and fpm.warehouse_no=strWareHouseNo
               and fpm.owner_no=strOwnerNo and fpm.plan_no=strPlanNo;
      exception when no_data_found then
          strResult:='N|[E30005]';
          return;
      end;

      --获取需求单号
      pklg_wms_base.p_getsheetno(strEnterPriseNo,strWareHouseNo,CONST_DOCUMENTTYPE.FCDATACR,strRequstNo,strResult);

      if substr(strResult,1,1)='N' then
         return;
      end if;

      --写需求单号头档
      insert into fcdata_request_m(enterprise_no,warehouse_no,owner_no,plan_type,plan_no,status,
             request_no,request_date,rgst_name,rgst_date)
          values(strEnterPriseNo,strWareHouseNo,strOwnerNo,v_strPlanType,strPlanNo,'10',
             strRequstNo,trunc(sysdate),strUserID,sysdate);

      --写需求单号明细
      insert into fcdata_request_d(enterprise_no,warehouse_no,owner_no,request_no,ware_no,
             area_no,stock_no,article_no,group_no,cell_no)
            select strEnterPriseNo,strWareHouseNo,strOwnerNo, strRequstNo,fpd.ware_no,
            fpd.area_no,fpd.stock_no,fpd.article_no,fpd.group_no,fpd.cell_no
            from fcdata_plan_d fpd where fpd.enterprise_no=strEnterPriseNo and fpd.warehouse_no=strWareHouseNo
            and fpd.owner_no=strOwnerNO and fpd.plan_no=strPlanNo;

      --更新盘点计划单头档
      update fcdata_plan_m set status='11' where status='10' and owner_no=strOwnerNo
      and enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo and plan_no=strPlanNo;

      if sql%notfound then
         strResult:='N|[E30013]';
         return;
      end if;

      strResult:='Y|';

    end P_Fcdata_Request;
/***************************************************************************************************************
  luozhiling
  2015.4.1
  功能：储位盘的找储位规则
***************************************************************************************************************/

    procedure P_CellCheckGetCell(strEnterPriseNo         in    fcdata_plan_m.enterprise_no%type,
                                  strWareHouseNo         in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo             in    fcdata_plan_m.owner_no%type,
                                  strRequstNo            IN    fcdata_request_m.request_no%type,--需求单号
                                  StrFIXEDCELLFLAG       in    bdef_defowner.FIXEDCELL_FLAG%type,
                                  strAllCells            in    WMS_DEFBASE.sdefine%type,--是否盘需求单范围全部储位
                                  strResult               OUT    varchar2)is
    begin
      strResult := 'N|[P_CellCheckGetCell]';

      for GetRequstItem in(select * from fcdata_request_d frd
              where frd.warehouse_no=strWareHouseNo and frd.owner_no=strOwnerNo and frd.enterprise_no=strEnterPriseNo
              and frd.request_no=strRequstNo) loop

          if UPPER(GetRequstItem.stock_no)='ALL' then --按储区盘点
             if strOwnerNo='N' then --按需求单范围盘点
                     insert into tmp_Requstcell(enterprise_no,WAREHOUSE_NO,OWNER_NO,WARE_NO,AREA_NO,STOCK_NO,cell_no,request_no)
                         select distinct b.enterprise_no,b.WAREHOUSE_NO,a.OWNER_NO,b.WARE_NO,b.AREA_NO,b.STOCK_NO,b.cell_no,strRequstNo
                         from fcdata_request_d a,cdef_defcell b
                         where a.enterprise_no=b.enterprise_no and a.warehouse_no=b.warehouse_no
                         and a.enterprise_no= strEnterPriseNo and a.ware_no=b.ware_no
                         and a.area_no=b.area_no and a.warehouse_no=strWareHouseNo
                         and a.request_no=strRequstNo and a.ware_no=GetRequstItem.ware_no
                         and a.area_no=GetRequstItem.area_no;
             else
                 if StrFIXEDCELLFLAG='0'  then --0：不绑定固定储位
                     if strAllCells='0' then  --找需求单范围的全部储位
                         insert into tmp_Requstcell(enterprise_no,WAREHOUSE_NO,OWNER_NO,WARE_NO,AREA_NO,STOCK_NO,cell_no,request_no)
                             select distinct b.enterprise_no,b.WAREHOUSE_NO,a.OWNER_NO,b.WARE_NO,b.AREA_NO,b.STOCK_NO,b.cell_no,strRequstNo
                             from fcdata_request_d a,cdef_defcell b
                             where a.enterprise_no=b.enterprise_no and a.warehouse_no=b.warehouse_no
                             and a.enterprise_no= strEnterPriseNo and a.ware_no=b.ware_no
                             and a.area_no=b.area_no and a.warehouse_no=strWareHouseNo
                             and a.request_no=strRequstNo and a.ware_no=GetRequstItem.ware_no
                             and a.area_no=GetRequstItem.area_no;
                     end if;
                     if strAllCells='1' then  --1、找当前货主有库存的储位
                         insert into tmp_Requstcell(enterprise_no,WAREHOUSE_NO,OWNER_NO,WARE_NO,AREA_NO,STOCK_NO,cell_no,Request_No)
                             select distinct b.enterprisE_no,b.WAREHOUSE_NO,c.OWNER_NO,b.WARE_NO,b.AREA_NO,b.STOCK_NO,b.cell_no,strRequstNo
                             from fcdata_request_d a,cdef_defcell b,stock_content c
                             where a.enterprise_no=b.enterprise_no and a.enterprise_no=c.enterprise_no
                             and a.warehouse_no=b.warehouse_no  and a.warehouse_no=c.warehouse_no
                             and a.ware_no=b.ware_no and a.area_no=b.area_no
                             and (a.owner_no=c.owner_no or strOwnerNo='N') and b.cell_no=c.cell_no
                             and a.warehouse_no=strWareHouseNo and a.enterprise_no=strEnterPriseNo
                             and a.request_no=strRequstNo and a.ware_no=GetRequstItem.ware_no
                             and a.area_no=GetRequstItem.area_no;
                     end if;

                     if strAllCells='2' then  --1、找当前货主有库存的储位
                         insert into tmp_Requstcell(enterprise_no,WAREHOUSE_NO,OWNER_NO,WARE_NO,AREA_NO,STOCK_NO,cell_no,Request_No)
                             select distinct b.enterprise_no,b.WAREHOUSE_NO,c.OWNER_NO,b.WARE_NO,b.AREA_NO,b.STOCK_NO,b.cell_no,strRequstNo
                             from fcdata_request_d a,cdef_defcell b,Stock_Owner_Cell c
                             where a.enterprise_no=b.enterprise_no and a.enterprise_no=c.enterprise_no
                             and a.warehouse_no=b.warehouse_no  and a.warehouse_no=c.warehouse_no
                             and a.ware_no=b.ware_no and a.area_no=b.area_no
                             and a.enterprise_no=strEnterPriseNo
                             and (a.owner_no=c.owner_no or strOwnerNo='N') and b.cell_no=c.cell_no
                             and a.warehouse_no=strWareHouseNo
                             and a.request_no=strRequstNo and a.ware_no=GetRequstItem.ware_no
                             and a.area_no=GetRequstItem.area_no;
                     end if;

                 else
                     --读取储位
                     insert into tmp_Requstcell(enterprise_no,WAREHOUSE_NO,OWNER_NO,WARE_NO,AREA_NO,STOCK_NO,cell_no,request_no)
                         select distinct b.enterprise_no,b.WAREHOUSE_NO,c.OWNER_NO,b.WARE_NO,b.AREA_NO,b.STOCK_NO,b.cell_no,strRequstNo
                         from fcdata_request_d a,cdef_defcell b,Cset_owner_cell c
                         where a.enterprise_no=b.enterprise_no and a.enterprise_no=c.enterprise_no
                         and a.enterprise_no=strEnterPriseNo and a.warehouse_no=b.warehouse_no and a.ware_no=b.ware_no
                         and a.area_no=b.area_no
                         and a.warehouse_no=c.warehouse_no and (a.owner_no=c.owner_no or strOwnerNo='N')
                         and b.cell_no=c.cell_no
                         and a.warehouse_no=strWareHouseNo
                         and a.request_no=strRequstNo and a.ware_no=GetRequstItem.ware_no
                         and a.area_no=GetRequstItem.area_no;
                 end if;
             end if;
          end if;

          if UPPER(GetRequstItem.cell_no)='ALL' then --按仓+区+通道盘点
             if strOwnerNo='N' then --按需求单范围盘点
                     insert into tmp_Requstcell(enterprise_no,WAREHOUSE_NO,OWNER_NO,WARE_NO,AREA_NO,STOCK_NO,cell_no,request_no)
                     select distinct b.enterprise_no,b.WAREHOUSE_NO,a.OWNER_NO,b.WARE_NO,b.AREA_NO,b.STOCK_NO,b.cell_no,strRequstNo
                     from fcdata_request_d a,cdef_defcell b
                     where a.enterprise_no=b.enterprise_no and a.enterprise_no=strEnterPriseNo
                     and a.warehouse_no=b.warehouse_no and a.ware_no=b.ware_no
                     and a.area_no=b.area_no and b.stock_no=a.stock_no and a.warehouse_no=strWareHouseNo
                     and a.request_no=strRequstNo and a.ware_no=GetRequstItem.ware_no
                     and a.area_no=GetRequstItem.area_no and a.stock_no=GetRequstItem.stock_no;
             else
                 if StrFIXEDCELLFLAG='0' then --0：不绑定固定储位
                     if strAllCells='0' then  --找需求单范围的全部储位
                         --读取储位
                         insert into tmp_Requstcell(enterprise_no,WAREHOUSE_NO,OWNER_NO,WARE_NO,AREA_NO,STOCK_NO,cell_no,request_no)
                         select distinct b.enterprise_no,b.WAREHOUSE_NO,a.OWNER_NO,b.WARE_NO,b.AREA_NO,b.STOCK_NO,b.cell_no,strRequstNo
                         from fcdata_request_d a,cdef_defcell b
                         where a.enterprise_no=b.enterprise_no and a.enterprise_no=strEnterPriseNo
                         and a.warehouse_no=b.warehouse_no and a.ware_no=b.ware_no
                         and a.area_no=b.area_no and b.stock_no=a.stock_no and a.warehouse_no=strWareHouseNo
                         and a.request_no=strRequstNo and a.ware_no=GetRequstItem.ware_no
                         and a.area_no=GetRequstItem.area_no and a.stock_no=GetRequstItem.stock_no;
                     end if;

                     --找当前货主有帐的储位
                     if strAllCells='1' then
                             insert into tmp_Requstcell(enterprise_no,WAREHOUSE_NO,OWNER_NO,WARE_NO,AREA_NO,STOCK_NO,cell_no,request_no)
                             select distinct b.enterprise_no,b.WAREHOUSE_NO,c.OWNER_NO,b.WARE_NO,b.AREA_NO,b.STOCK_NO,b.cell_no,strRequstNo
                             from fcdata_request_d a,cdef_defcell b,stock_content c
                             where a.enterprise_no=b.enterprise_no and a.enterprise_no=c.enterprise_no
                             and a.enterprise_no=strEnterPriseNo and a.warehouse_no=b.warehouse_no and a.ware_no=b.ware_no
                             and a.area_no=b.area_no and b.stock_no=a.stock_no and a.warehouse_no=c.warehouse_no
                             and (a.owner_no=c.owner_no or strOwnerNo='N') and b.cell_no=c.cell_no
                             and a.warehouse_no=strWareHouseNo
                             and a.request_no=strRequstNo and a.ware_no=GetRequstItem.ware_no
                             and a.area_no=GetRequstItem.area_no and a.stock_no=GetRequstItem.stock_no;
                     end if;
                     --所有货主的所有储位
                     if strAllCells='2' then
                             insert into tmp_Requstcell(enterprise_no,WAREHOUSE_NO,OWNER_NO,WARE_NO,AREA_NO,STOCK_NO,cell_no,request_no)
                             select distinct b.enterprise_no,b.WAREHOUSE_NO,c.OWNER_NO,b.WARE_NO,b.AREA_NO,b.STOCK_NO,b.cell_no,strRequstNo
                             from fcdata_request_d a,cdef_defcell b,Stock_Owner_Cell c
                             where a.enterprise_no=b.enterprise_no and a.enterprise_no=c.enterprise_no
                             and a.enterprise_no=strEnterPriseNo and a.warehouse_no=b.warehouse_no and a.ware_no=b.ware_no
                             and a.area_no=b.area_no and b.stock_no=a.stock_no and a.warehouse_no=c.warehouse_no
                             and (a.owner_no=c.owner_no or strOwnerNo='N') and b.cell_no=c.cell_no
                             and a.warehouse_no=strWareHouseNo
                             and a.request_no=strRequstNo and a.ware_no=GetRequstItem.ware_no
                             and a.area_no=GetRequstItem.area_no and a.stock_no=GetRequstItem.stock_no;
                     end if;
                else  --绑定固定储位
                 --找需求单范围的全部储位
                     insert into tmp_Requstcell(enterprise_no,WAREHOUSE_NO,OWNER_NO,WARE_NO,AREA_NO,STOCK_NO,cell_no,request_no)
                     select distinct b.enterprise_no,b.WAREHOUSE_NO,c.OWNER_NO,b.WARE_NO,b.AREA_NO,b.STOCK_NO,b.cell_no,strRequstNo
                     from fcdata_request_d a,cdef_defcell b,Cset_owner_cell c
                     where a.enterprise_no=b.enterprise_no and a.enterprise_no=c.enterprise_no
                     and a.enterprise_no=strEnterPriseNo and a.warehouse_no=b.warehouse_no and a.ware_no=b.ware_no
                     and a.area_no=b.area_no and a.stock_no=b.stock_no
                     and a.warehouse_no=c.warehouse_no and (a.owner_no=c.owner_no or strOwnerNo='N') and b.cell_no=c.cell_no
                     and a.warehouse_no=strWareHouseNo
                     and a.request_no=strRequstNo and a.ware_no=GetRequstItem.ware_no
                     and a.area_no=GetRequstItem.area_no and a.stock_no=GetRequstItem.stock_no;
                end if;
            end if;
          else --按储位盘点
            if strOwnerNo='N' then
                   --读取储位
                   insert into tmp_Requstcell(enterprise_no,WAREHOUSE_NO,OWNER_NO,WARE_NO,AREA_NO,STOCK_NO,cell_no,request_no)
                   select distinct b.enterprise_no,b.WAREHOUSE_NO,a.OWNER_NO,b.WARE_NO,b.AREA_NO,b.STOCK_NO,b.cell_no,strRequstNo
                   from fcdata_request_d a,cdef_defcell b
                   where a.enterprise_no=b.enterprise_no and a.enterprise_no=strEnterPriseNo
                   and a.warehouse_no=b.warehouse_no and a.ware_no=b.ware_no
                   and a.area_no=b.area_no and b.stock_no=a.stock_no and a.cell_no=b.cell_no
                   and a.warehouse_no=strWareHouseNo
                   and a.request_no=strRequstNo and a.ware_no=GetRequstItem.ware_no
                   and a.area_no=GetRequstItem.area_no and a.stock_no=GetRequstItem.stock_no
                   and a.cell_no=GetRequstItem.cell_no;
            else
                if StrFIXEDCELLFLAG='0' then --0：不绑定固定储位
                   if strAllCells='0' then  --找需求单范围的全部储位
                       --读取储位
                       insert into tmp_Requstcell(enterprise_no,WAREHOUSE_NO,OWNER_NO,WARE_NO,AREA_NO,STOCK_NO,cell_no,request_no)
                       select distinct b.enterprise_no,b.WAREHOUSE_NO,a.OWNER_NO,b.WARE_NO,b.AREA_NO,b.STOCK_NO,b.cell_no,strRequstNo
                       from fcdata_request_d a,cdef_defcell b
                       where a.enterprise_no=b.enterprise_no and a.enterprise_no=strEnterPriseNo
                       and a.warehouse_no=b.warehouse_no and a.ware_no=b.ware_no
                       and a.area_no=b.area_no and b.stock_no=a.stock_no and a.cell_no=b.cell_no
                       and a.warehouse_no=strWareHouseNo
                       and a.request_no=strRequstNo and a.ware_no=GetRequstItem.ware_no
                       and a.area_no=GetRequstItem.area_no and a.stock_no=GetRequstItem.stock_no
                       and a.cell_no=GetRequstItem.cell_no;
                   end if;

                   --找当前货主有帐的储位
                   if strAllCells='1' then
                       insert into tmp_Requstcell(enterprise_no,WAREHOUSE_NO,OWNER_NO,WARE_NO,AREA_NO,STOCK_NO,cell_no,request_no)
                       select distinct b.enterprise_no,b.WAREHOUSE_NO,c.OWNER_NO,b.WARE_NO,b.AREA_NO,b.STOCK_NO,b.cell_no,strRequstNo
                       from fcdata_request_d a,cdef_defcell b,stock_content c
                       where a.enterprise_no=b.enterprise_no and a.enterprise_no=c.enterprise_no
                       and a.enterprise_no=strEnterPriseNo and a.warehouse_no=b.warehouse_no and a.ware_no=b.ware_no
                       and a.area_no=b.area_no and b.stock_no=a.stock_no and a.warehouse_no=c.warehouse_no
                       and (a.owner_no=c.owner_no or strOwnerNo='N') and b.cell_no=c.cell_no and a.cell_no=b.cell_no
                       and a.warehouse_no=strWareHouseNo
                       and a.request_no=strRequstNo and a.ware_no=GetRequstItem.ware_no
                       and a.area_no=GetRequstItem.area_no and a.stock_no=GetRequstItem.stock_no
                       and a.cell_no=GetRequstItem.cell_no;
                   end if;

                   --找货主商品最后清空的空储位
                   if strAllCells='2' then
                       insert into tmp_Requstcell(enterprise_no,WAREHOUSE_NO,OWNER_NO,WARE_NO,AREA_NO,STOCK_NO,cell_no,request_no)
                       select distinct b.enterprise_no,b.WAREHOUSE_NO,c.OWNER_NO,b.WARE_NO,b.AREA_NO,b.STOCK_NO,b.cell_no,strRequstNo
                       from fcdata_request_d a,cdef_defcell b,Stock_Owner_Cell c
                       where a.enterprise_no=b.enterprise_no and a.enterprise_no=c.enterprise_no
                       and a.enterprise_no=strEnterPriseNo and a.warehouse_no=b.warehouse_no and a.ware_no=b.ware_no
                       and a.area_no=b.area_no and b.stock_no=a.stock_no and a.warehouse_no=c.warehouse_no
                       and (a.owner_no=c.owner_no or strOwnerNo='N') and b.cell_no=c.cell_no and a.cell_no=b.cell_no
                       and a.warehouse_no=strWareHouseNo
                       and a.request_no=strRequstNo and a.ware_no=GetRequstItem.ware_no
                       and a.area_no=GetRequstItem.area_no and a.stock_no=GetRequstItem.stock_no
                       and a.cell_no=GetRequstItem.cell_no;
                   end if;
               else  --绑定固定储位找需求单范围的全部储位
                       insert into tmp_Requstcell(enterprise_no,WAREHOUSE_NO,OWNER_NO,WARE_NO,AREA_NO,STOCK_NO,cell_no,Request_No)
                       select distinct b.enterprise_no,b.WAREHOUSE_NO,c.OWNER_NO,b.WARE_NO,b.AREA_NO,b.STOCK_NO,b.cell_no,strRequstNo
                       from fcdata_request_d a,cdef_defcell b,Cset_owner_cell c
                       where a.enterprise_no=b.enterprise_no and a.enterprise_no=c.enterprise_no
                       and a.enterprise_no=strEnterPriseNo and a.warehouse_no=b.warehouse_no and a.ware_no=b.ware_no
                       and a.area_no=b.area_no and a.stock_no=b.stock_no and a.cell_no=b.cell_no
                       and a.warehouse_no=c.warehouse_no and a.owner_no=c.owner_no and b.cell_no=c.cell_no
                       and a.warehouse_no=strWareHouseNo
                       and a.request_no=strRequstNo and a.ware_no=GetRequstItem.ware_no
                       and a.area_no=GetRequstItem.area_no and a.stock_no=GetRequstItem.stock_no
                       and a.cell_no=GetRequstItem.cell_no;
               end if;
           end if;
        end if;
      end loop;

      strResult:='Y|[成功]';

    end P_CellCheckGetCell;
/***************************************************************************************************************
  luozhiling
  2015.4.1
  功能：商品盘找储位规则
***************************************************************************************************************/

    procedure P_ArtCheckGetCell(strEnterPriseNo         in    fcdata_plan_m.enterprise_no%type,
                                  strWareHouseNo         in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo             in    fcdata_plan_m.owner_no%type,
                                  strRequstNo            IN    fcdata_request_m.request_no%type,--需求单号
                                  strFullCellarts        in    WMS_DEFBASE.sdefine%type,--是否盘当前商品有帐的储位
                                  strVIRCellarts         in    WMS_DEFBASE.sdefine%type,--若当前商品无库存，是否盘异常储位
                                  strResult               OUT    varchar2) is

      v_strAbnormalCellNo         cdef_defcell.cell_no%type;--异常储位
      v_strOrgNo                  fcdata_plan_m.org_no%type;

    begin
      strResult:='N|[P_ArtCheckGetCell]';

      --获取异常储位
      begin

        select cell_no  into v_strAbnormalCellNo
          from (select CDC.CELL_NO
                  from cdef_defcell cdc, cdef_defarea cdd
                 where cdc.enterprise_no=cdd.enterprise_no
                   and cdc.enterprise_no=strEnterPriseNo and cdc.warehouse_no = cdd.warehouse_no
                   and cdc.ware_no = cdd.ware_no
                   and cdc.area_no = cdd.area_no
                   AND CDC.CELL_STATUS = '0'
                   AND CDC.CHECK_STATUS = 0
                   and cdd.AREA_ATTRIBUTE = '0'
                   and cdd.AREA_USETYPE = '5'
                   and cdd.warehouse_no = strWareHouseNo
                 order by CDC.CELL_NO)
         where rownum <= 1;
      exception
        when no_data_found then
          strResult := 'N|[E30009]';
          return;
      end;

      --获取机构代码
      begin
            select T.org_no into v_strOrgNo
              from fcdata_plan_m t,fcdata_request_m frm
              where t.enterprise_no=frm.enterprise_no and t.warehouse_no=frm.warehouse_no
              and t.plan_no=frm.plan_no and frm.request_no=strRequstNo;
      exception when no_data_found then
            strResult:='N|[获取机构代码失败]';
            return;
      end;

      for GetRequstItem in(select * from fcdata_request_d frd
          where frd.warehouse_no=strWareHouseNo and frd.owner_no=strOwnerNo and frd.enterprise_no=strEnterPriseNo
          and frd.request_no=strRequstNo) loop
                --类别盘
           if UPPER(GetRequstItem.ARTICLE_NO)='ALL' then
                if strFullCellarts='1' then--找当前商品有帐的储位
                    insert into tmp_RequstARTICLE(enterprise_no,WAREHOUSE_NO,OWNER_NO,WARE_NO,AREA_NO,STOCK_NO,
                           cell_no,ARTICLE_NO,Request_No)
                       select distinct b.enterprise_no,b.WAREHOUSE_NO,a.OWNER_NO,b.WARE_NO,b.AREA_NO,b.STOCK_NO,
                              b.cell_no,d.ARTICLE_NO,strRequstNo
                       from fcdata_request_d a,cdef_defcell b,cdef_defarea ca,cdef_defware cd,stock_content c,bdef_defarticle d
                       where a.enterprise_no=b.enterprise_no and a.enterprise_no=c.enterprise_no
                       and a.enterprise_no=d.enterprise_no and b.enterprise_no=ca.enterprise_no
                       and cd.enterprise_no=ca.enterprise_no and cd.warehouse_no=ca.warehouse_no
                       and cd.ware_no=ca.ware_no and cd.org_no=v_strOrgNo
                       and b.warehouse_no=ca.warehouse_no and b.ware_no=ca.ware_no  and b.area_no=ca.area_no
                       /*and ca.area_attribute not in('0','2')*/
                       and a.enterprise_no=strEnterPriseNo
                       and a.warehouse_no=b.warehouse_no and a.warehouse_no=c.warehouse_no
                       and a.owner_no=c.owner_no and b.cell_no=c.cell_no and c.owner_no=d.owner_no
                       and a.GROUP_NO=d.GROUP_NO and c.ARTICLE_NO=d.ARTICLE_NO
                       and a.warehouse_no=strWareHouseNo
                       and a.request_no=strRequstNo and a.GROUP_NO=GetRequstItem.GROUP_NO;
                end if ;

                if strFullCellarts='2' then--找当前商品曾使用过的全部储位
                    insert into tmp_RequstARTICLE(enterprise_no,WAREHOUSE_NO,OWNER_NO,WARE_NO,AREA_NO,STOCK_NO,cell_no,ARTICLE_NO,Request_No)
                       select distinct b.enterprise_no,b.WAREHOUSE_NO,a.OWNER_NO,b.WARE_NO,b.AREA_NO,b.STOCK_NO,b.cell_no,d.ARTICLE_NO,strRequstNo
                       from fcdata_request_d a,cdef_defcell b,cdef_defware cd,bdef_defarticle d,Stock_Art_Cell f
                       where a.enterprise_no=b.enterprise_no and a.enterprise_no=cd.enterprise_no
                       and a.enterprise_no=d.enterprise_no and a.enterprise_no=f.enterprise_no
                       and a.warehouse_no=b.warehouse_no and a.warehouse_no=cd.warehouse_no
                       and a.warehouse_no=f.warehouse_no
                       and b.ware_no=cd.ware_no
                       and cd.org_no=v_strOrgNo
                       and a.enterprise_no=strEnterPriseNo
                       and b.cell_no=f.cell_no
                       and d.ARTICLE_NO=f.ARTICLE_NO
                       and a.GROUP_NO=d.GROUP_NO and a.warehouse_no=strWareHouseNo
                       and a.request_no=strRequstNo and a.GROUP_NO=GetRequstItem.GROUP_NO;
                end if ;

                if strVIRCellarts='1' then--若商品找不到任何储位，给出异常区
                      insert into tmp_RequstARTICLE(enterprise_no,WAREHOUSE_NO,OWNER_NO,WARE_NO,AREA_NO,STOCK_NO,cell_no,ARTICLE_NO,request_no)
                         select distinct b.enterprise_no,b.WAREHOUSE_NO,a.OWNER_NO,b.WARE_NO,b.AREA_NO,b.STOCK_NO,b.cell_no,d.ARTICLE_NO,strRequstNo
                         from fcdata_request_d a,cdef_defcell b,bdef_defarticle d
                         where a.enterprise_no=b.enterprise_no and a.enterprise_no=d.enterprise_no
                         and a.enterprise_no=strEnterPriseNo and a.warehouse_no=b.warehouse_no and a.GROUP_NO=d.GROUP_NO
                         and not exists (select ARTICLE_NO from tmp_RequstARTICLE where ARTICLE_NO=d.ARTICLE_NO
                         and enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo)
                         and a.warehouse_no=strWareHouseNo and b.CELL_NO=v_strAbnormalCellNo
                         and a.request_no=strRequstNo and a.GROUP_NO=GetRequstItem.GROUP_NO;
                end if;
           else --商品盘
               if strFullCellarts='1' then
                    insert into tmp_RequstARTICLE(enterprise_no,WAREHOUSE_NO,OWNER_NO,WARE_NO,AREA_NO,STOCK_NO,cell_no,ARTICLE_NO,request_no)
                       select distinct b.enterprise_no,b.WAREHOUSE_NO,a.OWNER_NO,b.WARE_NO,b.AREA_NO,b.STOCK_NO,b.cell_no,d.ARTICLE_NO,strRequstNo
                       from fcdata_request_d a,cdef_defcell b,cdef_defarea ca,cdef_defware cd,stock_content c,bdef_defarticle d
                       where a.enterprise_no=b.enterprise_no and a.enterprise_no=c.enterprise_no
                       and a.enterprise_no=d.enterprise_no and b.enterprise_no=ca.enterprise_no
                       and ca.enterprise_no=cd.enterprise_no and ca.warehouse_no=cd.warehouse_no
                       and ca.ware_no=cd.ware_no and cd.org_no=v_strOrgNo
                       and b.warehouse_no=ca.warehouse_no and b.ware_no=ca.ware_no  and b.area_no=ca.area_no
                       /*and ca.area_attribute not in('1','2')*/
                       and a.enterprise_no=strEnterPriseNo
                       and a.warehouse_no=b.warehouse_no and a.warehouse_no=c.warehouse_no
                       and a.owner_no=c.owner_no and b.cell_no=c.cell_no and c.owner_no=d.owner_no
                       and a.ARTICLE_NO=d.ARTICLE_NO and c.ARTICLE_NO=d.ARTICLE_NO and a.warehouse_no=strWareHouseNo
                       and a.request_no=strRequstNo and a.ARTICLE_NO=GetRequstItem.ARTICLE_NO;
                end if ;
                if strFullCellarts='2' then--找当前商品曾使用过的全部储位
                    insert into tmp_RequstARTICLE(enterprise_no,WAREHOUSE_NO,OWNER_NO,WARE_NO,AREA_NO,STOCK_NO,cell_no,ARTICLE_NO,request_no)
                       select distinct b.enterprise_no,b.WAREHOUSE_NO,a.OWNER_NO,b.WARE_NO,b.AREA_NO,b.STOCK_NO,b.cell_no,d.ARTICLE_NO,strRequstNo
                       from fcdata_request_d a,cdef_defcell b,cdef_defware cd,bdef_defarticle d,Stock_Art_Cell f
                       where a.enterprise_no=b.enterprise_no and a.enterprise_no=cd.enterprise_no
                       and a.enterprise_no=d.enterprise_no and a.enterprise_no=f.enterprise_no
                       and a.warehouse_no=b.warehouse_no and a.warehouse_no=cd.warehouse_no
                       and a.warehouse_no=f.warehouse_no
                       and b.ware_no=cd.ware_no
                       and cd.org_no=v_strOrgNo
                       and a.enterprise_no=strEnterPriseNo
                       and b.cell_no=f.cell_no
                       and d.ARTICLE_NO=f.ARTICLE_NO
                       and a.ARTICLE_NO=d.ARTICLE_NO and a.warehouse_no=strWareHouseNo
                       and a.request_no=strRequstNo and a.ARTICLE_NO=GetRequstItem.ARTICLE_NO;
                end if ;

                if strVIRCellarts='1' then--若商品找不到任何储位，给出异常区
                    insert into tmp_RequstARTICLE(enterprise_no,WAREHOUSE_NO,OWNER_NO,WARE_NO,AREA_NO,STOCK_NO,cell_no,ARTICLE_NO,request_no)
                       select distinct b.enterprise_no,b.WAREHOUSE_NO,a.OWNER_NO,b.WARE_NO,b.AREA_NO,b.STOCK_NO,b.cell_no,d.ARTICLE_NO,strRequstNo
                       from fcdata_request_d a,cdef_defcell b,cdef_defware cd,bdef_defarticle d
                       where a.enterprise_no=b.enterprise_no and a.enterprise_no=d.enterprise_no
                       and b.enterprise_no=cd.enterprise_no and b.warehouse_no=cd.warehouse_no
                       and b.ware_no=cd.ware_no and cd.org_no=v_strOrgNo
                       and a.enterprise_no=strEnterpriseNo and a.warehouse_no=b.warehouse_no and a.ARTICLE_NO=d.ARTICLE_NO
                       and not exists (select ARTICLE_NO from tmp_RequstARTICLE where  ARTICLE_NO=d.ARTICLE_NO
                       and enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo)
                       and a.warehouse_no=strWareHouseNo and b.CELL_NO=v_strAbnormalCellNo
                       and a.request_no=strRequstNo and a.ARTICLE_NO=GetRequstItem.ARTICLE_NO;
                end if;
           end if;
      end loop;

      strResult:='Y|[成功]';

    end P_ArtCheckGetCell;

/***************************************************************************************************************
  luozhiling
  2015.4.1
  功能：动销盘找储位规则
***************************************************************************************************************/

    procedure P_dynamicCheckGetCell(strEnterPriseNo      in    fcdata_plan_m.enterprise_no%type,
                                  strWareHouseNo         in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo             in    fcdata_plan_m.owner_no%type,
                                  strRequstNo            IN    fcdata_request_m.request_no%type,--需求单号
                                  stroutstockCells       in    WMS_DEFBASE.sdefine%type,--找存在下架动作的储位
                                  strinstockCells        in    WMS_DEFBASE.sdefine%type,--找存在上架动作的储位
                                  dtBEGIN_DATE           IN    fcdata_plan_m.BEGIN_DATE%type,
                                  dtEND_DATE             IN    fcdata_plan_m.end_date%type,
                                  strResult               OUT    varchar2) is

    begin

      strResult:='N|[P_dynamicCheckGetCell]';

       if stroutstockCells='1'then--动销盘：找存在下架动作的储位
           insert into tmp_Requstcell(enterprise_no,WAREHOUSE_NO,OWNER_NO,WARE_NO,AREA_NO,STOCK_NO,cell_no,request_no)
           select distinct m.enterprise_no,m.WAREHOUSE_NO,strOwnerNo,c.WARE_NO,c.AREA_NO,c.STOCK_NO,c.cell_no,strRequstNo
           from ODATA_OUTSTOCK_M m ,ODATA_OUTSTOCK_d d,cdef_defcell c,fcdata_request_d frd
           where m.enterprise_no=d.enterprise_no and m.enterprise_no=c.enterprise_no
           and m.enterprise_no=frd.enterprise_no and m.enterprise_no=strEnterPriseNo
           and m.warehouse_no=d.warehouse_no and d.OUTSTOCK_NO=m.OUTSTOCK_NO
           and c.warehouse_no = frd.warehouse_no and c.ware_no = frd.ware_no
           and c.area_no = frd.area_no and frd.request_no = strRequstNo
           and (upper(frd.stock_no) = 'ALL' or frd.stock_no = c.stock_no)
           and (upper(frd.cell_no) = 'ALL' or frd.cell_no = c.cell_no)
           /*and OUTSTOCK_TYPE='0'*/ and d.S_CELL_NO=c.CELL_NO and m.warehouse_no=c.warehouse_no
           and m.warehouse_no=strWareHouseNo and m.OWNER_NO=strOwnerNo
           and d.operate_date>=to_date(to_char(dtBEGIN_DATE,'yyyy-MM-dd'),'yyyy-MM-dd')
           and d.operate_date<=to_date(to_char(dtEND_DATE,'yyyy-MM-dd'),'yyyy-MM-dd');

           insert into tmp_Requstcell(enterprise_no,WAREHOUSE_NO,OWNER_NO,WARE_NO,AREA_NO,STOCK_NO,cell_no,request_no)
           select distinct m.enterprise_no,m.WAREHOUSE_NO,strOwnerNo,c.WARE_NO,c.AREA_NO,c.STOCK_NO,c.cell_no,strRequstNo
           from ODATA_OUTSTOCK_Mhty m ,ODATA_OUTSTOCK_dhty d,cdef_defcell c,fcdata_request_d frd
           where m.enterprise_no=d.enterprise_no and m.enterprise_no=c.enterprise_no
           and m.enterprise_no=frd.enterprise_no and m.enterprise_no=strEnterPriseNo
           and m.warehouse_no=d.warehouse_no and d.OUTSTOCK_NO=m.OUTSTOCK_NO
           /*and OUTSTOCK_TYPE='0'*/ and d.S_CELL_NO=c.CELL_NO and m.warehouse_no=c.warehouse_no
           and c.warehouse_no = frd.warehouse_no and c.ware_no = frd.ware_no
           and c.area_no = frd.area_no and frd.request_no = strRequstNo
           and (upper(frd.stock_no) = 'ALL' or frd.stock_no = c.stock_no)
           and (upper(frd.cell_no) = 'ALL' or frd.cell_no = c.cell_no)
           and m.warehouse_no=strWareHouseNo and m.OWNER_NO=strOwnerNo
           and d.operate_date>=to_date(to_char(dtBEGIN_DATE,'yyyy-MM-dd'),'yyyy-MM-dd')
           and d.operate_date<=to_date(to_char(dtEND_DATE,'yyyy-MM-dd'),'yyyy-MM-dd');
       end if;

       if strinstockCells='1'then--动销盘：找存在上架动作的储位
           insert into tmp_Requstcell(enterprise_no,WAREHOUSE_NO,OWNER_NO,WARE_NO,AREA_NO,STOCK_NO,cell_no,request_no)
           select distinct m.enterprise_no,m.WAREHOUSE_NO,strOwnerNo,a.WARE_NO,a.AREA_NO,a.STOCK_NO,a.cell_no,strRequstNo
           from IDATA_INSTOCK_M m,IDATA_INSTOCK_D d, cdef_defcell a,fcdata_request_d frd
           where m.enterprise_no=d.enterprise_no and m.enterprise_no=a.enterprise_no
           and m.enterprise_no=frd.enterprise_no and m.enterprise_no=strEnterPriseNo
           and m.warehouse_no=d.warehouse_no and m.OWNER_NO=d.OWNER_NO and m.INSTOCK_NO=d.INSTOCK_NO
           and a.warehouse_no = frd.warehouse_no and a.ware_no = frd.ware_no
           and a.area_no = frd.area_no and frd.request_no = strRequstNo
           and (upper(frd.stock_no) = 'ALL' or frd.stock_no = a.stock_no)
           and (upper(frd.cell_no) = 'ALL' or frd.cell_no = a.cell_no)
           and d.REAL_CELL_NO=a.CELL_NO and d.warehouse_no=a.warehouse_no
           and m.warehouse_no=strWareHouseNo and m.OWNER_NO=strOwnerNo
           and trunc(m.INSTOCK_DATE)>=to_date(to_char(dtBEGIN_DATE,'yyyy-MM-dd'),'yyyy-MM-dd')
           and trunc(m.INSTOCK_DATE)<=to_date(to_char(dtEND_DATE,'yyyy-MM-dd'),'yyyy-MM-dd');

           insert into tmp_Requstcell(enterprise_no,WAREHOUSE_NO,OWNER_NO,WARE_NO,AREA_NO,STOCK_NO,cell_no,request_no)
           select distinct m.enterprise_no,m.WAREHOUSE_NO,strOwnerNo,a.WARE_NO,a.AREA_NO,a.STOCK_NO,a.cell_no,strRequstNo
           from IDATA_INSTOCK_Mhty m,IDATA_INSTOCK_Dhty d, cdef_defcell a,fcdata_request_d frd
           where m.enterprise_no=d.enterprise_no and m.enterprise_no=a.enterprise_no
           and m.enterprise_no=frd.enterprise_no and m.enterprise_no=strEnterPriseNo
           and m.warehouse_no=d.warehouse_no and m.OWNER_NO=d.OWNER_NO and m.INSTOCK_NO=d.INSTOCK_NO
           and a.warehouse_no = frd.warehouse_no and a.ware_no = frd.ware_no
           and a.area_no = frd.area_no and frd.request_no = strRequstNo
           and (upper(frd.stock_no) = 'ALL' or frd.stock_no = a.stock_no)
           and (upper(frd.cell_no) = 'ALL' or frd.cell_no = a.cell_no)
           and d.REAL_CELL_NO=a.CELL_NO and d.warehouse_no=a.warehouse_no
           and m.warehouse_no=strWareHouseNo and m.OWNER_NO=strOwnerNo
           and trunc(m.INSTOCK_DATE)>=to_date(to_char(dtBEGIN_DATE,'yyyy-MM-dd'),'yyyy-MM-dd')
           and trunc(m.INSTOCK_DATE)<=to_date(to_char(dtEND_DATE,'yyyy-MM-dd'),'yyyy-MM-dd');
       end if;
      strResult:='Y|[成功]';

    end P_dynamicCheckGetCell;
/**********************************************************************************************************
   luozhiling
   2015.4.1
   功能：写储位盘定位指示
***********************************************************************************************************/
    procedure P_InsertCellLocateDiect(strEnterPriseNo        in    fcdata_plan_m.enterprise_no%type,
                                  strWareHouseNo          in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_plan_m.owner_no%type,
                                  strPlanNo               in    fcdata_plan_m.plan_no%type,
                                  strRequstNo             in    fcdata_request_m.request_no%type,
                                  strUserId               in    fcdata_plan_m.rgst_name%type,
                                  strFcdataType           in    fcdata_plan_m.fcdata_type%type,
                                  dtRequestDate           in    fcdata_request_m.request_date%type,
                                  strResult               OUT    varchar2)is
        v_iCount                  integer;
    begin
       strResult := 'N|[P_InsertCellLocateDiect]';

        insert into fcdata_check_direct(enterprise_no,warehouse_no,owner_no,plan_no,request_no,cell_no,article_no,
        packing_qty,article_qty,status,request_date,fcdata_type,label_no,sub_label_no,dept_no,barcode,produce_date,
        expire_date,quality,lot_no,rsv_batch1,rsv_batch2,rsv_batch3,rsv_batch4,rsv_batch5,rsv_batch6,rsv_batch7,
        rsv_batch8,stock_type,stock_value,rgst_name,rgst_date)
            select strEnterPriseNo,strWareHouseNo,nvl(b.owner_no,strOwnerNo),strPlanNo,
                strRequstNo,a.cell_no,nvl(b.article_no,'N'),nvl(b.packing_qty,0),nvl(b.qty,0),'10',dtRequestDate,
                strFcdataType,nvl(b.label_no,'N'),nvl(b.sub_label_no,'N'),nvl(b.dept_no,'N'),
                nvl(b.barcode,'N'),nvl(b.produce_date,to_date('1900-01-01','yyyy-MM-dd')),
                nvl(b.expire_date,to_date('1900-01-01','yyyy-MM-dd')),'0',
                nvl(b.lot_no,'N'),nvl(b.rsv_batch1,'N'),nvl(b.rsv_batch2,'N'),nvl(b.rsv_batch3,'N'),
                nvl(b.rsv_batch4,'N'),
                nvl(b.rsv_batch5,'N'),nvl(b.rsv_batch6,'N'),nvl(b.rsv_batch7,'N'),nvl(b.rsv_batch8,'N'),
                nvl(b.stock_type,'1'),nvl(b.stock_value,'N'),strUserId,sysdate
            from cdef_defcell a ,tmp_Requstcell c,(
            select sc.enterprise_no,sc.warehouse_no,sc.owner_no,sc.dept_no,sc.cell_no,sc.article_no,sc.packing_qty,
                 sai.produce_date,sai.expire_date,sai.barcode,sai.lot_no,sai.quality,
                 sai.rsv_batch1,sai.rsv_batch2,sai.rsv_batch3,sai.rsv_batch4,sai.rsv_batch5,
                 sai.rsv_batch6,sai.rsv_batch7,sai.rsv_batch8,
                 sum(sc.qty-sc.outstock_qty+sc.instock_qty+sc.unusual_qty) qty,
                 sc.label_no,sc.sub_label_no,sc.stock_type,sc.stock_value
                 from stock_content sc,stock_article_info sai,cdef_defcell cd
            where sc.enterprise_no=sai.enterprise_no and sc.enterprise_no=cd.enterprise_no
            and sc.warehouse_no=cd.warehouse_no and sc.article_no=sai.article_no
            and sc.article_id=sai.article_id and sc.cell_no=cd.cell_no and sc.status='0'
            and sc.enterprise_no=strEnterPriseNo and sc.warehouse_no=strWareHouseNo
            and (sc.owner_no = strOwnerNo or strOwnerNo = 'N')
            group by sc.enterprise_no,sc.warehouse_no,sc.owner_no,sc.dept_no,sc.cell_no,sc.article_no,sc.packing_qty,
                 sai.produce_date,sai.expire_date,sai.barcode,sai.lot_no,sai.quality,
                 sc.label_no,sc.sub_label_no,sc.stock_type,sc.stock_value,
                 sai.rsv_batch1,sai.rsv_batch2,sai.rsv_batch3,sai.rsv_batch4,sai.rsv_batch5,
                 sai.rsv_batch6,sai.rsv_batch7,sai.rsv_batch8) b
            where a.enterprise_no=b.enterprise_no(+) and a.enterprise_no=c.enterprise_no
            and a.cell_no=b.cell_no(+) and a.warehouse_no = b.warehouse_no(+)
            and a.warehouse_no = c.warehouse_no and a.cell_no=c.cell_no
            and a.ware_no = c.ware_no and a.area_no = c.area_no and a.stock_no=c.stock_no
            and a.cell_status in('0','2') and a.check_status='0'
            and a.warehouse_no=strWarehouseNo and a.enterprise_no=strEnterPriseNo;

       if strFcdataType='1' then

            --检查是否有预上预下的数据
            select nvl(sum(t.instock_qty+t.outstock_qty),0) into v_iCount
            from stock_content t,tmp_Requstcell a
            where t.enterprise_no=a.enterprise_no and t.enterprise_no=strEnterPriseNo
            and (t.instock_qty>0 or t.outstock_qty>0)
            and t.cell_no=a.cell_no and t.warehouse_no=a.warehouse_no and t.warehouse_no=strWarehouseNo;
            if v_iCount>0 then
               strResult:='N|[E30010]';
               return;
            end if;

            select count(*) into v_iCount from cdef_defcell cd,tmp_Requstcell frd
            where cd.enterprise_no=frd.enterprise_no and cd.enterprise_no=strEnterPriseNo
            and cd.warehouse_no=frd.warehouse_no and cd.cell_no=frd.cell_no and cd.warehouse_no=strWarehouseNo
            and cd.check_status='3';
            if v_iCount>0 then
               strResult:='N|[E30011]';
               return;
            end if;

           --更新储位状态
           update cdef_defcell set check_status='3'
                 where cell_no in (select cell_no from tmp_Requstcell where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo)
                 and warehouse_no=strWareHouseNo and enterprise_no=strEnterpriseNo and check_status='0' and cell_status in('0','2');

           --更新库存状态
           update stock_content set status='1' where warehouse_no=strWareHouseNo
                  and enterprise_no=strEnterPriseNo
                  and cell_no in (select a.cell_no from cdef_defcell a,tmp_Requstcell b
                  where a.enterprise_no=b.enterprise_no and a.enterprise_no=strEnterPriseNo
                  and a.warehouse_no = b.warehouse_no and a.cell_no = b.cell_no
                  AND a.ware_no=b.ware_no and a.area_no=b.area_no) and status='0';
       end if;

        --删除储位数据
        delete from tmp_Requstcell where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo
        and request_no=strRequstNo;
       strResult:='Y|';

    end P_InsertCellLocateDiect;

/**********************************************************************************************************
   luozhiling
   2015.10.17
   功能：储位检查只抓取储位的储位盘定位指示
***********************************************************************************************************/
    procedure P_InsertGetCellLocateDiect(strEnterPriseNo        in    fcdata_plan_m.enterprise_no%type,
                                  strWareHouseNo          in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_plan_m.owner_no%type,
                                  strPlanNo               in    fcdata_plan_m.plan_no%type,
                                  strRequstNo             in    fcdata_request_m.request_no%type,
                                  strUserId               in    fcdata_plan_m.rgst_name%type,
                                  strFcdataType           in    fcdata_plan_m.fcdata_type%type,
                                  dtRequestDate           in    fcdata_request_m.request_date%type,
                                  strResult               OUT    varchar2)is
    begin
       strResult := 'N|[P_InsertGetCellLocateDiect]';

        insert into fcdata_check_direct(enterprise_no,warehouse_no,owner_no,plan_no,request_no,cell_no,article_no,
        packing_qty,article_qty,status,request_date,fcdata_type,label_no,sub_label_no,dept_no,barcode,produce_date,
        expire_date,quality,lot_no,rsv_batch1,rsv_batch2,rsv_batch3,rsv_batch4,rsv_batch5,rsv_batch6,rsv_batch7,
        rsv_batch8,stock_type,stock_value,rgst_name,rgst_date)
            select a.enterprise_no,a.warehouse_no,strOwnerNo,strPlanNo,
                strRequstNo,a.cell_no,'N',0,0,'10',dtRequestDate,
                strFcdataType,'N','N','N',
                'N',to_date('1900-01-01','yyyy-MM-dd'),
                to_date('1900-01-01','yyyy-MM-dd'),'0',
                'N','N','N','N','N','N','N','N','N','1','N',strUserId,sysdate
            from cdef_defcell a ,tmp_Requstcell c
            where a.enterprise_no=c.enterprise_no
            and a.warehouse_no = c.warehouse_no and a.cell_no=c.cell_no
            and a.cell_status in('0','2') and a.check_status='0'
            and a.warehouse_no=strWarehouseNo and a.enterprise_no=strEnterPriseNo;
        if sql%notfound then
            strResult := 'N|[E30012]';
            return;
        end if;

         --删除储位数据
        delete from tmp_Requstcell where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo and owner_no=strOwnerNo;

       strResult:='Y|';

    end P_InsertGetCellLocateDiect;

/**********************************************************************************************************
   luozhiling
   2015.4.1
   功能：写商品盘定位指示
***********************************************************************************************************/
    procedure P_InsertArtLocateDiect(strEnterPriseNo        in    fcdata_plan_m.enterprise_no%type,
                                  strWareHouseNo          in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_plan_m.owner_no%type,
                                  strPlanNo               in    fcdata_plan_m.plan_no%type,
                                  strRequstNo             in    fcdata_request_m.request_no%type,
                                  strUserId               in    fcdata_plan_m.rgst_name%type,
                                  strFcdataType           in    fcdata_plan_m.fcdata_type%type,
                                  dtRequestDate           in    fcdata_request_m.request_date%type,
                                  strResult               OUT    varchar2)is
        v_iCount                  integer;
    begin
        strResult := 'N|[P_InsertArtLocateDiect]';

        insert into fcdata_check_direct(enterprise_no,warehouse_no,owner_no,plan_no,request_no,cell_no,article_no,
        packing_qty,article_qty,status,request_date,fcdata_type,label_no,sub_label_no,dept_no,barcode,produce_date,
        expire_date,quality,lot_no,rsv_batch1,rsv_batch2,rsv_batch3,rsv_batch4,rsv_batch5,rsv_batch6,rsv_batch7,
        rsv_batch8,stock_type,stock_value,rgst_name,rgst_date)
        select distinct strEnterPriseNo,strWareHouseNo,c.owner_no,strPlanNo,
            strRequstNo,a.cell_no,c.article_no,nvl(b.packing_qty,1),nvl(b.qty,0),'10',dtRequestDate,
            strFcdataType,nvl(b.label_no,'N'),nvl(b.sub_label_no,'N'),nvl(b.dept_no,'N'),
            nvl(b.barcode,bd.BARCODE),nvl(b.produce_date,to_date('1900-01-01','yyyy-MM-dd')),
            nvl(b.expire_date,to_date('1900-01-01','yyyy-MM-dd')),'0',
            nvl(b.lot_no,'N'),nvl(b.rsv_batch1,'N'),nvl(b.rsv_batch2,'N'),nvl(b.rsv_batch3,'N'),
            nvl(b.rsv_batch4,'N'),
            nvl(b.rsv_batch5,'N'),nvl(b.rsv_batch6,'N'),nvl(b.rsv_batch7,'N'),nvl(b.rsv_batch8,'N'),
            nvl(b.stock_type,'1'),nvl(b.stock_value,'N'),strUserId,sysdate
        from cdef_defcell a ,tmp_RequstARTICLE c,(
        select sc.enterprise_no,sc.warehouse_no,sc.owner_no,sc.dept_no,sc.cell_no,sc.article_no,sc.packing_qty,
             sai.produce_date,sai.expire_date,sai.barcode,sai.lot_no,sai.quality,
             sai.rsv_batch1,sai.rsv_batch2,sai.rsv_batch3,sai.rsv_batch4,sai.rsv_batch5,
             sai.rsv_batch6,sai.rsv_batch7,sai.rsv_batch8,
             sum(sc.qty-sc.outstock_qty+sc.instock_qty+sc.unusual_qty) qty,
             sc.label_no,sc.sub_label_no,sc.stock_type,sc.stock_value
             from stock_content sc,stock_article_info sai,cdef_defcell cd
        where sc.enterprise_no=sai.enterprise_no and sc.enterprise_no=cd.enterprise_no
        and sc.enterprise_no=strEnterPriseNo and sc.warehouse_no=strWareHouseNo and sc.owner_no=strOwnerNo
        and sc.warehouse_no=cd.warehouse_no and sc.article_no=sai.article_no
        and sc.article_id=sai.article_id and sc.cell_no=cd.cell_no and sc.status='0'
        group by sc.enterprise_no,sc.warehouse_no,sc.owner_no,sc.dept_no,sc.cell_no,sc.article_no,sc.packing_qty,
             sai.produce_date,sai.expire_date,sai.barcode,sai.lot_no,sai.quality,
             sc.label_no,sc.sub_label_no,sc.stock_type,sc.stock_value,sai.rsv_batch1,sai.rsv_batch2,
             sai.rsv_batch3,sai.rsv_batch4,sai.rsv_batch5,
             sai.rsv_batch6,sai.rsv_batch7,sai.rsv_batch8) b,bdef_defarticle bd
        where c.enterprise_no=b.enterprise_no(+) and c.enterprise_no=a.enterprise_no
        and a.enterprise_no=strEnterPriseNo and c.cell_no=b.cell_no(+) and c.warehouse_no = b.warehouse_no(+) and c.article_no=b.article_no(+)
        and a.warehouse_no = c.warehouse_no and a.cell_no=c.cell_no
        and a.ware_no = c.ware_no and a.area_no = c.area_no and a.stock_no=c.stock_no
        and c.article_no=bd.article_no
        and a.cell_status in('0','2') and a.check_status='0'
        and a.warehouse_no=strWarehouseNo;

        --大盘要检查数据和锁定储位
        if strFcdataType=1 then
              --检查是否有预上预下的数据
              select nvl(sum(t.instock_qty+t.outstock_qty),0) into v_iCount
              from stock_content t,tmp_RequstARTICLE a
              where t.enterprise_no=a.enterprise_no
              and t.enterprise_no=strEnterPriseNo and (t.instock_qty>0 or t.outstock_qty>0)
              and t.cell_no=a.cell_no and t.warehouse_no=a.warehouse_no and a.article_no=t.article_no
              and t.warehouse_no=strWarehouseNo;
              if v_iCount>0 then
                 strResult:='N|[E30010]';
                 return;
              end if;

              select count(*) into v_iCount
              from cdef_defcell cd,tmp_RequstARTICLE frd
              where cd.enterprise_no=frd.enterprise_no and cd.warehouse_no=frd.warehouse_no and cd.cell_no=frd.cell_no and cd.warehouse_no=strWarehouseNo
              and cd.enterprise_no=strEnterPriseNo and cd.check_status='3';
              if v_iCount>0 then
                 strResult:='N|[E30011]';
                 return;
              end if;
       end if;
        --删除储位数据
        delete from tmp_requstarticle where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo and request_no=strRequstNo;

       strResult:='Y|';
    end P_InsertArtLocateDiect;
/**********************************************************************************************************
   luozhiling
   2013.11.16
   功能：按盘点计划成需求,一盘点计划单成一张需求单
***********************************************************************************************************/
    procedure P_Fcdata_LocateDiect(strEnterPriseNo        in    fcdata_plan_m.enterprise_no%type,
                                  strWareHouseNo          in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_plan_m.owner_no%type,
                                  strUserId               in    fcdata_plan_m.rgst_name%type,
                                  strRequstNo             IN    fcdata_plan_m.plan_no%type,--移库计划头档
                                  strResult               OUT    varchar2)is
         v_strPlanType            fcdata_request_m.plan_type%type;
         v_strPlanNo              fcdata_request_m.plan_no%type;
         dtRequestDate            fcdata_request_m.request_date%type;
         v_iCount                 integer;
    begin
      strResult := 'N|[P_Fcdata_LocateDiect]';
      v_iCount:=0;

      begin
          select fpm.plan_type,fpm.plan_no,fpm.request_date into v_strPlanType,v_strPlanNo,dtRequestDate--1：储位盘；0：商品盘
          from fcdata_request_m fpm where fpm.enterprise_no=strEnterPriseNo and fpm.warehouse_no=strWareHouseNo
                 and fpm.owner_no=strOwnerNo and fpm.request_no=strRequstNo and fpm.status='10';
      exception when no_data_found then
          strResult:='N|[E30005]';
          return;
      end;

      if v_strPlanType=1 then
         --储位盘定位
         for GetRequstItem in(select * from fcdata_request_d frd
             where frd.enterprise_no=strEnterPriseNo and frd.warehouse_no=strWareHouseNo and frd.owner_no=strOwnerNo
             and frd.request_no=strRequstNo) loop

             if GetRequstItem.ware_no='ALL' then -- 全仓盘点

                 --检查是否有预上预下的数据
                 select nvl(sum(t.instock_qty+t.outstock_qty),0) into v_iCount
                 from stock_content t where (t.instock_qty>0 or t.outstock_qty>0)
                 and t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo;
                 if v_iCount>0 then
                    strResult:='N|[E30010]';
                    return;
                 end if;

                 select count(*) into v_iCount from cdef_defcell
                 where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo and check_status='3';
                 if v_iCount>0 then
                    strResult:='N|[E30011]';
                    return;
                 end if;


                  --更新储位状态
                  update cdef_defcell set check_status='3' where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo /*AND owner_no=strOwnerNo*/
                  and check_status='0' and cell_status in('0','2');

                  if sql%notfound then
                     strResult:='N|[E30026]';
                     return;
                  end if;

                  --更新库存状态
                  update stock_content set status='1' where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo AND owner_no=strOwnerNo and status='0';

                  if sql%notfound then
                     strResult:='N|[E30026]';
                     return;
                  end if;
             end if;

             if GetRequstItem.area_no='ALL' then --按仓盘点

                 --检查是否有预上预下的数据
                 select nvl(sum(t.instock_qty+t.outstock_qty),0) into v_iCount
                 from stock_content t,fcdata_request_d fcd,cdef_defcell a
                 where t.enterprise_no=fcd.enterprise_no and t.enterprise_no=a.enterprise_no
                 and t.enterprise_no=strEnterPriseNo and (t.instock_qty>0 or t.outstock_qty>0)
                 and t.cell_no=a.cell_no and t.warehouse_no=fcd.warehouse_no and t.warehouse_no=a.warehouse_no
                 and fcd.ware_no=a.ware_no and t.warehouse_no=strWareHouseNo and fcd.request_no=strRequstNo
                 and fcd.ware_no=GetRequstItem.ware_no;
                 if v_iCount>0 then
                    strResult:='N|[E30010]';
                    return;
                 end if;
                 select count(*) into v_iCount from cdef_defcell cd,fcdata_request_d frd
                 where cd.enterprise_no=frd.enterprise_no and cd.enterprise_no=strEnterPriseNo
                 and cd.warehouse_no=frd.warehouse_no and cd.ware_no=frd.ware_no
                 and CD.warehouse_no=strWareHouseNo and cd.check_status='3' and frd.request_no=strRequstNo
                 and cd.ware_no=frd.ware_no and frd.ware_no=GetRequstItem.ware_no;
                 if v_iCount>0 then
                    strResult:='N|[E30011]';
                    return;
                 end if;


                  --更新储位状态
                  update cdef_defcell set check_status='3' where enterprise_no=strEnterPriseNo
                        and warehouse_no=strWareHouseNo /*AND owner_no=strOwnerNo*/
                        and ware_no=GetRequstItem.ware_no and check_status='0'
                        and cell_status in('0','2');

                  --更新库存状态
                  update stock_content set status='1' where enterprise_no=strEnterPriseNo
                         and warehouse_no=strWareHouseNo AND owner_no=strOwnerNo
                         and cell_no in(select cell_no from cdef_defcell where warehouse_no=strWareHouseNo
                         AND ware_no=GetRequstItem.ware_no) and status='0';
             end if;

             if GetRequstItem.stock_no='ALL' then --按储区盘点
                 --检查是否有预上预下的数据
                 select nvl(sum(t.instock_qty+t.outstock_qty),0) into v_iCount
                 from stock_content t,fcdata_request_d fcd,cdef_defcell a
                 where t.enterprise_no=fcd.enterprise_no and t.enterprise_no=a.enterprise_no
                 and t.enterprise_no=strEnterPriseNo and (t.instock_qty>0 or t.outstock_qty>0)
                 and t.cell_no=a.cell_no and t.warehouse_no=fcd.warehouse_no
                 and t.warehouse_no=a.warehouse_no and fcd.ware_no=A.ware_no
                 and fcd.area_no=A.area_no and t.warehouse_no=strWareHouseNo
                 and fcd.request_no=strRequstNo;
                 if v_iCount>0 then
                    strResult:='N|[E30010]';
                    return;
                 end if;
                 select count(*) into v_iCount from cdef_defcell cd,fcdata_request_d frd
                 where cd.enterprise_no=frd.enterprise_no and cd.enterprise_no=strEnterPriseNo
                 and cd.warehouse_no=frd.warehouse_no and cd.ware_no=frd.ware_no
                 and cd.area_no=frd.area_no and frd.ware_no=GetRequstItem.ware_no
                 and frd.area_no=GetRequstItem.area_no
                 and CD.warehouse_no=strWareHouseNo and cd.check_status='3' and frd.request_no=strRequstNo;
                 if v_iCount>0 then
                    strResult:='N|[E30011]';
                    return;
                 end if;

                  --更新储位状态
                  update cdef_defcell set check_status='3' where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo /*AND owner_no=strOwnerNo*/
                        and ware_no=GetRequstItem.ware_no and area_no=GetRequstItem.area_no and check_status='0'
                        and cell_status in('0','2');

                  --更新库存状态
                  update stock_content set status='1' where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo AND owner_no=strOwnerNo
                         and cell_no in(select cell_no from cdef_defcell where warehouse_no=strWareHouseNo
                         AND ware_no=GetRequstItem.ware_no and area_no=GetRequstItem.area_no) and status='0';
             end if;

             if GetRequstItem.cell_no='ALL' then --按仓+区+通道盘点
                 --检查是否有预上预下的数据
                 select nvl(sum(t.instock_qty+t.outstock_qty),0) into v_iCount
                 from stock_content t,fcdata_request_d fcd,cdef_defcell a
                 where t.enterprise_no=fcd.enterprise_no and t.enterprise_no=a.enterprise_no
                 and t.enterprise_no=strEnterPriseNo and (t.instock_qty>0 or t.outstock_qty>0)
                 and t.cell_no=a.cell_no and t.warehouse_no=fcd.warehouse_no
                 and t.warehouse_no=a.warehouse_no and fcd.ware_no=A.ware_no
                 and fcd.area_no=a.area_no and fcd.stock_no=a.stock_no
                 and t.warehouse_no=strWareHouseNo and fcd.request_no=strRequstNo;
                 if v_iCount>0 then
                    strResult:='N|[E30010]';
                    return;
                 end if;

                 select count(*) into v_iCount from cdef_defcell cd,fcdata_request_d frd
                 where cd.enterprise_no=frd.enterprise_no and cd.enterprise_no=strEnterPriseNo
                 and cd.warehouse_no=frd.warehouse_no and cd.ware_no=frd.ware_no
                 and cd.area_no=frd.area_no and cd.stock_no=frd.stock_no
                 and CD.warehouse_no=strWareHouseNo and cd.check_status='3' and frd.request_no=strRequstNo;
                 if v_iCount>0 then
                    strResult:='N|[E30011]';
                    return;
                 end if;

                  --更新储位状态
                  update cdef_defcell set check_status='3' where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo/* AND owner_no=strOwnerNo*/
                        and ware_no=GetRequstItem.ware_no and area_no=GetRequstItem.area_no
                        and stock_no=GetRequstItem.stock_no
                        and check_status='0'
                        and cell_status in('0','2');

                  --更新库存状态
                  update stock_content set status='1' where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo AND owner_no=strOwnerNo
                         and cell_no in(select cell_no from cdef_defcell where warehouse_no=strWareHouseNo
                         AND ware_no=GetRequstItem.ware_no and area_no=GetRequstItem.area_no
                         and stock_no=GetRequstItem.stock_no) and status='0';
             else--按储位盘点

                 --检查是否有预上预下的数据
                 select nvl(sum(t.instock_qty+t.outstock_qty),0) into v_iCount
                 from stock_content t,fcdata_request_d fcd,cdef_defcell a
                 where t.enterprise_no=fcd.enterprise_no and t.enterprise_no=a.enterprise_no
                 and t.enterprise_no=strEnterPriseNo and (t.instock_qty>0 or t.outstock_qty>0)
                 and t.cell_no=fcd.cell_no and t.warehouse_no=fcd.warehouse_no
                 and t.warehouse_no=a.warehouse_no and t.cell_no=a.cell_no
                 and t.warehouse_no=strWareHouseNo and fcd.request_no=strRequstNo;
                 if v_iCount>0 then
                    strResult:='N|[E30010]';
                    return;
                 end if;

                 select count(*) into v_iCount from cdef_defcell cd,fcdata_request_d frd
                 where cd.enterprise_no=frd.enterprise_no and cd.enterprise_no=strEnterPriseNo
                 and cd.warehouse_no=frd.warehouse_no and cd.cell_no=frd.cell_no
                 and frd.warehouse_no=strWareHouseNo and cd.check_status='3' and frd.request_no=strRequstNo
                 and frd.cell_no=GetRequstItem.cell_no;
                 if v_iCount>0 then
                    strResult:='N|[E30011]';
                    return;
                 end if;

                  --更新储位状态
                  update cdef_defcell set check_status='3' where warehouse_no=strWareHouseNo /*AND owner_no=strOwnerNo*/
                        and enterprise_no=strEnterPriseNo and ware_no=GetRequstItem.ware_no and area_no=GetRequstItem.area_no
                        and stock_no=GetRequstItem.stock_no and cell_no=GetRequstItem.cell_no
                        and check_status='0'
                        and cell_status in('0','2');

                  --更新库存状态
                  update stock_content set status='1' where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo AND owner_no=strOwnerNo
                         and cell_no in(select cell_no from cdef_defcell where warehouse_no=strWareHouseNo
                         AND ware_no=GetRequstItem.ware_no and area_no=GetRequstItem.area_no
                         and stock_no=GetRequstItem.stock_no and cell_no=GetRequstItem.cell_no)
                         and status='0';
            end if;
              v_iCount:=v_iCount+1;
         end loop;
         if v_iCount=0 then
            strResult:='N|[E30027]';
            return;
         end if;
      end if;

      --更新需求单
      update fcdata_request_m set status='13',updt_name=strUserId,updt_date=sysdate
      where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo and owner_no=strOwnerNo
      AND request_no=strRequstNo and status='10';

      if sql%notfound then
          strResult:='N|[E30013]';
          return;
      end if;

/*      if v_strPlanType='0' then --商品盘，预留
      end if;*/


      strResult:='Y|';
   end P_Fcdata_LocateDiect;

/**********************************************************************************************************
   luozhiling
   2013.11.16
   功能：按盘点指示发盘切单,按通道发单
***********************************************************************************************************/
    procedure P_Fcdata_GetTask(strEnterPriseNo           in     fcdata_plan_m.enterprise_no%type,
                               strWareHouseNo            in     fcdata_plan_m.warehouse_no%type,--仓库编码
                               strOwnerNo                in     fcdata_plan_m.owner_no%type,
                               strUserId                 in     fcdata_plan_m.rgst_name%type,--作业人
                               strPaperUserId            in     fcdata_plan_m.rgst_name%type,--单据人
                               strRequstNo               in     fcdata_plan_m.plan_no%type,--需求单号
                               strResult                 OUT    varchar2)is
         v_iCount                 integer;
         v_strAStockNo            cdef_defcell.cell_no%type;
         v_strCheckNo             fcdata_check_m.check_no%type;
         nRowId                   integer;
    begin
      strResult := 'N|[P_Fcdata_GetTask]';
      v_iCount:=0;
      v_strAStockNo:='N';

      for GetCheckDiect in (select cd.ware_no||cd.area_no||cd.stock_no a_stock_no,fcd.*
          from fcdata_check_direct fcd,cdef_defcell cd
          where fcd.enterprise_no=cd.enterprise_no
          and fcd.enterprise_no=strEnterPriseNo and fcd.warehouse_no=cd.warehouse_no and fcd.cell_no=cd.cell_no
          and fcd.warehouse_no=strWareHouseNo
          and fcd.owner_no=strOwnerNo and fcd.request_no=strRequstNo and fcd.status='10' )loop
          v_iCount:=v_iCount+1;

          if GetCheckDiect.a_stock_no<>v_strAStockNo then
             --取盘点单号；
               --获取需求单号
              pklg_wms_base.p_getsheetno(strEnterPriseNo,strWareHouseNo,CONST_DOCUMENTTYPE.FCDATACH,v_strCheckNo,strResult);
              if substr(strResult,1,1)='N' then
                 return;
              end if;

          end if;

          --获取最大的行号
          select nvl(max(row_id),0) into nRowId from fcdata_check_d where enterprise_no=strEnterPriseNo
          and warehouse_no=strWareHouseNo
          and owner_no=strOwnerNo and check_no=v_strCheckNo;

           v_strAStockNo:=GetCheckDiect.a_stock_no;
      end loop;

      if v_iCount=0 then
          strResult:='N|[E30028]';
          return;
      end if;
      --更新盘点指示状态
       update fcdata_check_direct set status='13' ,updt_name=strUserId,updt_date=sysdate
              where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo and owner_no=strOwnerNo
              and request_no=strRequstNo and status='10';
       if sql%notfound then
          strResult:='N|[E30203]';
          return;
       end if;

      strResult:='Y|';

    end P_Fcdata_GetTask;

/**********************************************************************************************************
    功能：校验储位的混载属性
    1、若该储位是不可混商品属性的储位，则不可放不同属性的商品；若储位是不可混载储位，只能存放同商品同属性
    2、该储位是否混货主储位，若可混，可存放多货主商品，若不可混，只能存放单货主商品

***********************************************************************************************************/
     procedure P_CheckMixOwnerArt(strEnterPriseNo         in    fcdata_plan_m.enterprise_no%type,
                                  strWareHouseNo          in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_plan_m.owner_no%type,
                                  strCheckNo              in    fcdata_plan_m.plan_no%type,--需求单号
                                  strCellNo               in    fcdata_check_d.cell_no%type,--盘点储位
                                  strArticleNo            in    fcdata_check_d.article_no%type,
                                  dtProduceDate           in    fcdata_check_d.produce_date%type,
                                  dtExpireDate            in    fcdata_check_d.expire_date%type,
                                  strQuality              in    fcdata_check_d.quality%type,
                                  strLotNo                in    fcdata_check_d.lot_no%type,
                                  strLabelNo              in    fcdata_check_d.label_no%type,
                                  strSubLabelNo           in    fcdata_check_d.sub_label_no%type,
                                  strStockType            in    fcdata_check_d.stock_type%type,
                                  strStockValue           in    fcdata_check_d.stock_value%type,
                                  strRsvBatch1            in    fcdata_check_d.rsv_batch1%type,
                                  strRsvBatch2            in    fcdata_check_d.rsv_batch2%type,
                                  strRsvBatch3            in    fcdata_check_d.rsv_batch3%type,
                                  strRsvBatch4            in    fcdata_check_d.rsv_batch4%type,
                                  strRsvBatch5            in    fcdata_check_d.rsv_batch5%type,
                                  strRsvBatch6            in    fcdata_check_d.rsv_batch6%type,
                                  strRsvBatch7            in    fcdata_check_d.rsv_batch7%type,
                                  strRsvBatch8            in    fcdata_check_d.rsv_batch8%type,
                                  strResult               OUT    varchar2)is
        v_strMixFlag              cdef_defcell.mix_flag%type;--0:不可混；1：同商品不同属性混(混属性)；2：不同商品混(混商品)'
        v_strMixOwner             cdef_defcell.mix_owner%type;--是否混货主,0:不可混,1:可混
        v_iCount                  integer;
     begin
          strResult:='N|[P_CheckMixOwnerArt]';
          --获取储位的标识
          select cd.mix_flag,cd.mix_owner
                into v_strMixFlag,v_strMixOwner
              from cdef_defcell cd where cd.enterprise_no=strEnterPriseNo and cd.warehouse_no=strWareHouseNo
                 and cd.cell_no=strCellNo;

          if v_strMixFlag='0' then--不可混载
             select count(*) into v_iCount from fcdata_check_d fcd
             where fcd.enterprise_no=strEnterPriseNo and fcd.warehouse_no=strWareHouseNo
             and fcd.check_no=strCheckNo and fcd.cell_no=strCellNo
             and ((fcd.article_no<>'N' and fcd.article_no<>strArticleNo)
             or fcd.produce_date<>dtProduceDate or fcd.expire_date<>dtExpireDate
             or fcd.quality<>strQuality or fcd.lot_no<>strLotNo or fcd.label_no<>strLabelNo
             or fcd.sub_label_no<>strSubLabelNo or fcd.stock_type<>strStockType
             or fcd.stock_value<>strStockValue or fcd.rsv_batch1<>strRsvBatch1
             or fcd.rsv_batch1<>strRsvBatch2 or fcd.rsv_batch1<>strRsvBatch3
             or fcd.rsv_batch1<>strRsvBatch4 or fcd.rsv_batch1<>strRsvBatch4
             or fcd.rsv_batch1<>strRsvBatch5 or fcd.rsv_batch1<>strRsvBatch6
             or fcd.rsv_batch1<>strRsvBatch7 or fcd.rsv_batch1<>strRsvBatch8);

             if v_iCount>0 then
                strResult:='N|[不可混载的储位，不能盘点此商品]';
                return;
             end if;
          end if;

          if v_strMixFlag='1' then--混属性
             select count(*) into v_iCount from fcdata_check_d fcd
             where fcd.enterprise_no=strEnterPriseNo and fcd.warehouse_no=strWareHouseNo
             and fcd.check_no=strCheckNo and fcd.cell_no=strCellNo
             and (fcd.article_no<>'N' and fcd.article_no<>strArticleNo);

             if v_iCount>0 then
                strResult:='N|[混属性的储位,不可放多个商品,不能盘点此商品]';
                return;
             end if;
          end if;

          if v_strMixOwner='0' then
             select count(*) into v_iCount from fcdata_check_d fcd
             where fcd.enterprise_no=strEnterPriseNo and fcd.warehouse_no=strWareHouseNo
             and fcd.check_no=strCheckNo and fcd.cell_no=strCellNo
             and (fcd.owner_no<>strOwnerNo and fcd.owner_no<>'N');

             if v_iCount>0 then
                strResult:='N|[不可混货主的储位,不可放货主的商品]';
                return;
             end if;
          end if;

          strResult:='Y|[成功]';

     end P_CheckMixOwnerArt;
/**********************************************************************************************************
   luozhiling
   2013.11.16
   功能：盘点回单,循环复盘
***********************************************************************************************************/
     procedure P_Fcdata_SaveCheck(strEnterPriseNo         in    fcdata_plan_m.enterprise_no%type,
                                  strWareHouseNo          in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_plan_m.owner_no%type,
                                  strOperateType          in    fcdata_check_m.check_type%type,--1:初盘；2：复盘；3三盘
                                  strUserId               in    fcdata_plan_m.rgst_name%type,--作业人
                                  strCheckNo              in    fcdata_plan_m.plan_no%type,--需求单号
                                  strCellNo               in    fcdata_check_d.cell_no%type,--盘点储位
                                  strArticleNo            in    fcdata_check_d.article_no%type,
                                  nPackingQty             in    fcdata_check_d.packing_qty%type,
                                  dtProduceDate           in    fcdata_check_d.produce_date%type,
                                  dtExpireDate            in    fcdata_check_d.expire_date%type,
                                  strQuality              in    fcdata_check_d.quality%type,
                                  strLotNo                in    fcdata_check_d.lot_no%type,
                                  nCheckQty               in    fcdata_check_d.check_qty%type,
                                  strLabelNo              in    fcdata_check_d.label_no%type,
                                  strSubLabelNo           in    fcdata_check_d.sub_label_no%type,
                                  strStockType            in    fcdata_check_d.stock_type%type,
                                  strStockValue           in    fcdata_check_d.stock_value%type,
                                  strRsvBatch1            in    fcdata_check_d.rsv_batch1%type,
                                  strRsvBatch2            in    fcdata_check_d.rsv_batch2%type,
                                  strRsvBatch3            in    fcdata_check_d.rsv_batch3%type,
                                  strRsvBatch4            in    fcdata_check_d.rsv_batch4%type,
                                  strRsvBatch5            in    fcdata_check_d.rsv_batch5%type,
                                  strRsvBatch6            in    fcdata_check_d.rsv_batch6%type,
                                  strRsvBatch7            in    fcdata_check_d.rsv_batch7%type,
                                  strRsvBatch8            in    fcdata_check_d.rsv_batch8%type,
                                  strAddFlag              in    fcdata_check_m.check_type%type,--1：按总量盘点覆盖数量 ；2：累加数量盘点
                                  strResult               OUT    varchar2)is
         v_iCount                 integer;
         nRowId                   integer;
         v_nRowCount              integer;
         v_strBarcode             fcdata_check_d.barcode%type;
         v_nArticleQty            fcdata_check_d.article_qty%type;
         v_nCheckQty              fcdata_check_d.check_qty%type;
         v_nRealQty               fcdata_check_d.real_qty%type;
         v_nReCheckQty            fcdata_check_d.recheck_qty%type;
         v_nThirdCheckQty         fcdata_check_d.third_qty%type;
         v_nOrderId               fcdata_check_d.order_id%type;
         v_nSubOrderId            fcdata_check_d.sub_order_id%type;
         v_strLotType             bdef_defarticle.lot_type%type;
         v_nExpiryDays            bdef_defarticle.expiry_days%type;
         v_nTotalCheckQty         fcdata_check_d.check_qty%type;
         v_strDifFlag             fcdata_check_d.different_flag%type;--差异标识，1:差异；0:无差异
         v_nPreQty                fcdata_check_d.check_qty%type;--当前盘点量
         v_strCheckName           fcdata_check_d.check_worker%type;--初盘人
         v_strRecheckName         fcdata_check_d.recheck_worker%type;--复盘人
         v_strThirdName           fcdata_check_d.third_worker%type;
         dtCheckDate              fcdata_check_d.check_date%type;
         dtReCheckDate            fcdata_check_d.check_date%type;
         dtThirdDate              fcdata_check_d.check_date%type;
         v_strOwnerNo             fcdata_check_m.owner_no%type;
    begin
      strResult := 'N|[P_Fcdata_SaveCheck]';
      if strAddFlag=1 and nCheckQty<0 then
         strResult:='N|[覆盖盘点的方式不支持盘入负数]';
         return;
      end if;
      v_iCount:=0;
      select owner_no into v_strOwnerNo from fcdata_check_m where enterprise_no=strEnterPriseNo
      and warehouse_no=strWareHouseNo and check_no=strCheckNo;

      if v_strOwnerNo<>'N' and v_strOwnerNo<>strOwnerNo then
         strResult:='N|[不是当前货主的盘点点，不允许盘此商品]';
         return;
      end if;

      --update by sunl 20160429
      --校验生产日期不能大于今天。
      if (dtProduceDate > sysdate) then
         strResult:='N|[商品生产日期不能大于今天！]';
         return;
      end if;

      --锁盘点单
      update fcdata_check_m set status=status where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo
             and check_no=strCheckNo and status='10' and check_type=strOperateType;
      if sql%notfound  then
         --strResult:='N|找不到对应的盘点单,请检查!';
         strResult:='N|[E30401]';
         return;
      end if;

      --校验混载和混货主
      P_CheckMixOwnerArt(strEnterPriseNo,strWareHouseNo,strOwnerNo,strCheckNo,strCellNo,strArticleNo,dtProduceDate,
         dtExpireDate,strQuality,strLotNo,strLabelNo,strSubLabelNo,strStockType,strStockValue,strRsvBatch1,strRsvBatch2,
         strRsvBatch3,strRsvBatch4,strRsvBatch5,strRsvBatch6,strRsvBatch7,strRsvBatch8,strResult);

   	  if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      if strArticleNo='N' then --无库存的数据
         update fcdata_check_d set check_flag='1',different_flag='0'
                where enterprise_no=strEnterPriseNo and cell_no=strCellNo and warehouse_no=strWareHouseNo
                and check_no=strCheckNo and status='10';
         strResult:='Y';
         return;

      end if;


       --查找盘点单是否有该数据，没有就新增
       select count(*) into v_iCount from fcdata_check_d fcd where fcd.warehouse_no=strWareHouseNo
       and fcd.enterprise_no=strEnterPriseNo
       and fcd.owner_no=strOwnerNo and fcd.check_no=strCheckNo and fcd.cell_no=strCellNo
       and fcd.article_no=strArticleNo and fcd.packing_qty=nPackingQty
       and fcd.produce_date=dtProduceDate and fcd.expire_date=dtExpireDate
       and fcd.lot_no=strLotNo
       and fcd.check_type=strOperateType
       and fcd.label_no=strLabelNo and fcd.sub_label_no=strSubLabelNo
       and fcd.stock_type=strStockType and fcd.stock_value=strStockValue
       and rsv_batch1=strRsvBatch1
       and rsv_batch2=strRsvBatch2 and rsv_batch3=strRsvBatch3 and rsv_batch4=strRsvBatch4
       and rsv_batch5=strRsvBatch5 and rsv_batch6=strRsvBatch6 and rsv_batch7=strRsvBatch7
       and rsv_batch8=strRsvBatch8;

       if v_iCount=0 then  --该储位找不到对应的商品信息，需要新增
          if nCheckQty<0 then
             strResult:='N|[没有足够的数量进行扣减]';
             return;
          end if;

          --如果商品管批号信息，则写商品批号管理信息
          begin
              select bda.lot_type,bda.expiry_days
              into v_strLotType,v_nExpiryDays
              from BDEF_DEFARTICLE bda
              where  Owner_no=strOwnerNo and article_no=strArticleNo
							AND BDA.ENTERPRISE_NO = strEnterPriseNo --ADD by sunl 20160601
							;
          exception when no_data_found then
             strResult:='N|[找不到对应的商品资料]';
             return;
          end;

          if v_strLotType='1' or v_strLotType='3' then
            PKOBJ_stock.p_Insert_Article_lot_manage(strEnterPriseNo,strWareHouseNo,
                                           strArticleNo ,
                                           strLotNo ,
                                           dtProduceDate ,
                                           dtExpireDate ,
                                           v_nExpiryDays ,
                                           strUserId ,
                                           0 ,
                                           strResult);
         	  if (substr(strResult, 1, 1) = 'N') then
              return;
            end if;
           end if;
          if strOperateType=1 then
             v_nCheckQty:=nCheckQty;
             v_nReCheckQty:='';
             v_nThirdCheckQty:='';
             v_nRealQty:=nCheckQty;
             v_strCheckName:=strUserId;
             v_strRecheckName:='';
             v_strThirdName:='';
             dtCheckDate:=sysdate;
             dtReCheckDate:='';
             dtThirdDate:='';
          end if;

          if strOperateType=2 then
             v_nCheckQty:='';
             v_nReCheckQty:=nCheckQty;
             v_nThirdCheckQty:='';
             v_nRealQty:=nCheckQty;
             v_strCheckName:='';
             v_strRecheckName:=strUserId;
             v_strThirdName:='';
             dtCheckDate:='';
             dtReCheckDate:=sysdate;
             dtThirdDate:='';
          end if;

          if strOperateType=3 then
             v_nCheckQty:='';
             v_nReCheckQty:='';
             v_nThirdCheckQty:=nCheckQty;
             v_nRealQty:=nCheckQty;
             v_strCheckName:='';
             v_strRecheckName:='';
             v_strThirdName:=strUserId;
             dtCheckDate:='';
             dtReCheckDate:='';
             dtThirdDate:=sysdate;
          end if;

            --获取单内序号
            select nvl(max(row_id),0) into nRowId from fcdata_check_d where warehouse_no=strWareHouseNo
                   and enterprise_no=strEnterPriseNo and check_no=strCheckNo;

            --获取储位的排列顺序
            select distinct order_id into v_nOrderId from fcdata_check_d where warehouse_no=strWareHouseNo
                   and enterprise_no=strEnterPriseNo and check_no=strCheckNo and cell_no=strCellNo;

            --获取储位上商品的排列顺序
            select count(1) into v_nRowCount from fcdata_check_d
            where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo
            and check_no=strCheckNo and cell_no=strCellNo and article_no=strArticleNo;
            if v_nRowCount>0 then
              select distinct nvl(sub_order_id,0) into v_nSubOrderId from fcdata_check_d
            where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo
                and check_no=strCheckNo and cell_no=strCellNo
                and article_no=strArticleNo;
            else
              select nvl(max(sub_order_id+1),0) into v_nSubOrderId from fcdata_check_d
            where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo
                and check_no=strCheckNo and cell_no=strCellNo;
            end if;

            --读取商品条码
            begin
                 select bab.barcode into v_strBarcode from bdef_defarticle bab
                 where bab.enterprise_no=strEnterPriseNo and bab.article_no=strArticleNo  and rownum=1;
            exception when no_data_found then
                 --strResult:='N|读取不到商品的条码信息';
                 strResult:='N|[E30402]';
                 return;
            end;

            insert into fcdata_check_d(enterprise_no,warehouse_no,owner_no,check_no,row_id,cell_no,article_no,
                   order_id,sub_order_id,barcode,packing_qty,
                   produce_date,expire_date,quality,lot_no,article_qty,
                   check_qty,recheck_qty,third_qty,real_qty,add_flag,status,check_type,
                   check_worker,check_date,recheck_worker,recheck_date,third_worker,third_date,different_flag,
                   label_no,sub_label_no,stock_type,stock_value,check_flag,
                   rsv_batch1,rsv_batch2,rsv_batch3,rsv_batch4,
                   rsv_batch5,rsv_batch6,rsv_batch7,rsv_batch8)
               values(strEnterPriseNo,strWareHouseNo,strOwnerNo,strCheckNo,nRowId+1,strCellNo,strArticleNo,
                   v_nOrderId,v_nSubOrderId,v_strBarcode,nPackingQty,
                   dtProduceDate,dtExpireDate,'0',strLotNo,0,
                   v_nCheckQty,v_nReCheckQty,v_nThirdCheckQty,v_nRealQty,'1','10',strOperateType,
                   v_strCheckName,dtCheckDate,v_strRecheckName,dtReCheckDate,v_strThirdName,dtThirdDate,'1',
                   strLabelNo,strSubLabelNo,strStockType,strStockValue,'1',
                   strRsvBatch1,strRsvBatch2,strRsvBatch3,strRsvBatch4,
                   strRsvBatch5,strRsvBatch6,strRsvBatch7,strRsvBatch8);

      else
          if strOperateType=1 then  --初盘
              --已经有该商品的库存数据，直接更新盘点量
               select nvl(fcd.article_qty,0),nvl(fcd.check_qty,0) into v_nArticleQty,v_nPreQty from fcdata_check_d fcd where fcd.warehouse_no=strWareHouseNo
               and fcd.enterprise_no=strEnterPriseNo
               and fcd.owner_no=strOwnerNo and fcd.check_no=strCheckNo and fcd.cell_no=strCellNo
               and fcd.article_no=strArticleNo and fcd.packing_qty=nPackingQty
               and fcd.produce_date=dtProduceDate and fcd.expire_date=dtExpireDate
               and/* fcd.quality=strQuality and*/ fcd.lot_no=strLotNo
               and fcd.check_type=strOperateType/* and fcd.status='10'*/
               and fcd.label_no=strLabelNo and fcd.sub_label_no=strSubLabelNo
               and fcd.stock_type=strStockType and fcd.stock_value=strStockValue
               and fcd.rsv_batch1=strRsvBatch1
               and fcd.rsv_batch2=strRsvBatch2 and fcd.rsv_batch3=strRsvBatch3 and fcd.rsv_batch4=strRsvBatch4
               and fcd.rsv_batch5=strRsvBatch5 and fcd.rsv_batch6=strRsvBatch6 and fcd.rsv_batch7=strRsvBatch7
               and fcd.rsv_batch8=strRsvBatch8
               and rownum<2;

               if v_nPreQty+nCheckQty<0 then
                  strResult:='N|[没有足够的数量进行扣减]';
                  return;
               end if;

               if strAddFlag='1' then --覆盖
                  if v_nArticleQty=nCheckQty then
                     v_strDifFlag:='0';
                  else
                     v_strDifFlag:='1';
                  end if;
                  v_nTotalCheckQty:=nCheckQty;
               else--累加
                  if v_nArticleQty=nCheckQty+v_nPreQty then
                     v_strDifFlag:='0';
                  else
                     v_strDifFlag:='1';
                  end if;
                  v_nTotalCheckQty:=v_nPreQty+nCheckQty;
               end if;

                update fcdata_check_d fcd set fcd.check_qty=v_nTotalCheckQty,fcd.real_qty=v_nTotalCheckQty,
                       fcd.different_flag=v_strDifFlag,fcd.check_flag='1',
                       fcd.check_worker=strUserId,fcd.check_date=sysdate
                   where fcd.enterprise_no=strEnterPriseNo and fcd.warehouse_no=strWareHouseNo
                   and fcd.owner_no=strOwnerNo and fcd.check_no=strCheckNo and fcd.cell_no=strCellNo
                   and fcd.article_no=strArticleNo and fcd.packing_qty=nPackingQty
                   and fcd.produce_date=dtProduceDate and fcd.expire_date=dtExpireDate
                   and fcd.lot_no=strLotNo and fcd.check_type=strOperateType
                   and fcd.check_type=strOperateType
                   and fcd.label_no=strLabelNo and fcd.sub_label_no=strSubLabelNo
                   and fcd.stock_type=strStockType and fcd.stock_value=strStockValue
                   and fcd.rsv_batch1=strRsvBatch1
                   and fcd.rsv_batch2=strRsvBatch2 and fcd.rsv_batch3=strRsvBatch3 and fcd.rsv_batch4=strRsvBatch4
                   and fcd.rsv_batch5=strRsvBatch5 and fcd.rsv_batch6=strRsvBatch6 and fcd.rsv_batch7=strRsvBatch7
                   and fcd.rsv_batch8=strRsvBatch8;
          end if;

          if strOperateType=2 then                  --复盘

             --已经有该商品的库存数据，直接更新盘点量
             select nvl(fcd.article_qty,0),nvl(fcd.check_qty,0),nvl(fcd.recheck_qty,0)
             into v_nArticleQty,v_nCheckQty,v_nPreQty
               from fcdata_check_d fcd where fcd.enterprise_no=strEnterPriseNo and fcd.warehouse_no=strWareHouseNo
               and fcd.owner_no=strOwnerNo and fcd.check_no=strCheckNo and fcd.cell_no=strCellNo
               and fcd.article_no=strArticleNo and fcd.packing_qty=nPackingQty
               and fcd.produce_date=dtProduceDate and fcd.expire_date=dtExpireDate
               /*and fcd.quality=strQuality */and fcd.lot_no=strLotNo
               and fcd.check_type=strOperateType
               and fcd.label_no=strLabelNo and fcd.sub_label_no=strSubLabelNo
               and fcd.stock_type=strStockType and fcd.stock_value=strStockValue
               and rsv_batch1=strRsvBatch1
               and rsv_batch2=strRsvBatch2 and rsv_batch3=strRsvBatch3 and rsv_batch4=strRsvBatch4
               and rsv_batch5=strRsvBatch5 and rsv_batch6=strRsvBatch6 and rsv_batch7=strRsvBatch7
               and rsv_batch8=strRsvBatch8;

               if v_nPreQty+nCheckQty<0 then
                  strResult:='N|[没有足够的数量进行扣减]';
                  return;
               end if;

               if strAddFlag='1' then --覆盖
                  if v_nCheckQty=nCheckQty then
                     v_strDifFlag:='0';
                  else
                     v_strDifFlag:='1';
                  end if;
                  v_nTotalCheckQty:=nCheckQty;
               else--累加
                  if v_nCheckQty=nCheckQty+v_nPreQty then
                     v_strDifFlag:='0';
                  else
                     v_strDifFlag:='1';
                  end if;
                  v_nTotalCheckQty:=v_nPreQty+nCheckQty;
               end if;

              update fcdata_check_d fcd set fcd.recheck_qty=v_nTotalCheckQty,fcd.real_qty=v_nTotalCheckQty,
                     fcd.different_flag=v_strDifFlag,fcd.check_flag='1',fcd.check_type='2',/*status='10',*/
                     fcd.recheck_worker=strUserId,fcd.recheck_date=sysdate
                 where fcd.enterprise_no=strEnterPriseNo and fcd.warehouse_no=strWareHouseNo
                 and fcd.owner_no=strOwnerNo and fcd.check_no=strCheckNo and fcd.cell_no=strCellNo
                 and fcd.article_no=strArticleNo and fcd.packing_qty=nPackingQty
                 and fcd.produce_date=dtProduceDate and fcd.expire_date=dtExpireDate
                 /*and fcd.quality=strQuality */and fcd.lot_no=strLotNo
                 and fcd.check_type=strOperateType
                 and fcd.label_no=strLabelNo and fcd.sub_label_no=strSubLabelNo
                 and fcd.stock_type=strStockType and fcd.stock_value=strStockValue
                 and rsv_batch1=strRsvBatch1
                 and rsv_batch2=strRsvBatch2 and rsv_batch3=strRsvBatch3 and rsv_batch4=strRsvBatch4
                 and rsv_batch5=strRsvBatch5 and rsv_batch6=strRsvBatch6 and rsv_batch7=strRsvBatch7
                 and rsv_batch8=strRsvBatch8;
           end if;
          if strOperateType=3 then
             if strAddFlag='1' then --覆盖
                v_nTotalCheckQty:=nCheckQty;
             else--累加
                v_nTotalCheckQty:=v_nPreQty+nCheckQty;      --目前三盘不要支持累加数量
             end if;

              update fcdata_check_d fcd set fcd.third_qty=v_nTotalCheckQty,fcd.real_qty=v_nTotalCheckQty,
                     fcd.different_flag='1',fcd.check_flag='1',fcd.check_type='3',/*status='10',*/
                     fcd.third_worker=strUserId,fcd.third_date=sysdate
                 where fcd.enterprise_no=strEnterPriseNo and fcd.warehouse_no=strWareHouseNo
                 and fcd.owner_no=strOwnerNo and fcd.check_no=strCheckNo and fcd.cell_no=strCellNo
                 and fcd.article_no=strArticleNo and fcd.packing_qty=nPackingQty
                 and fcd.produce_date=dtProduceDate and fcd.expire_date=dtExpireDate
                 /*and fcd.quality=strQuality */and fcd.lot_no=strLotNo
                 and fcd.check_type=strOperateType
                 and fcd.label_no=strLabelNo and fcd.sub_label_no=strSubLabelNo
                 and fcd.stock_type=strStockType and fcd.stock_value=strStockValue
                 and rsv_batch1=strRsvBatch1
                 and rsv_batch2=strRsvBatch2 and rsv_batch3=strRsvBatch3 and rsv_batch4=strRsvBatch4
                 and rsv_batch5=strRsvBatch5 and rsv_batch6=strRsvBatch6 and rsv_batch7=strRsvBatch7
                 and rsv_batch8=strRsvBatch8;
          end if;
      end if;
      strResult:='Y|';
    end P_Fcdata_SaveCheck;
/********************************************************************************************************
   创建人：luozhiling
   创建时间：2013.11.22
   功能说明：盘点回单确认
*********************************************************************************************************/
    procedure P_fcdata_comfireCheck(strEnterPriseNo       in    fcdata_plan_m.enterprise_no%type,
                                  strWareHouseNo          in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_plan_m.owner_no%type,
                                  strOperateType          in    fcdata_check_m.check_type%type,--1:初盘；2：复盘；3三盘
                                  strUserId               in    fcdata_plan_m.rgst_name%type,--作业人
                                  strCheckNo              in    fcdata_plan_m.plan_no%type,--盘点单号
                                  strResult               OUT    varchar2)is

      cursor v_GetCheckQty is
        select fcd.cell_no,fcd.article_no,
               sum(nvl(fcd.article_qty,0))as article_qty,
               sum(nvl(fcd.check_qty,0)) as check_qty
           from fcdata_check_d fcd
           where fcd.enterprise_no=strEnterPriseNo and fcd.warehouse_no=strWareHouseNo
           and fcd.check_no=strCheckNo and check_type='1' and fcd.status='10'
           group by fcd.cell_no,fcd.article_no;
      cursor v_GetRecheckQty is
        select fcd.cell_no,fcd.article_no,
               sum(nvl(fcd.article_qty,0))as article_qty,
               sum(nvl(fcd.check_qty,0)) as check_qty,
               sum(nvl(fcd.recheck_qty,0)) as recheck_qty
           from fcdata_check_d fcd
           where fcd.enterprise_no=strEnterPriseNo and fcd.warehouse_no=strWareHouseNo
           and fcd.check_no=strCheckNo and fcd.status='10'
           group by fcd.cell_no,fcd.article_no;

       cursor v_GetCell is
        select distinct fcd.cell_no
           from fcdata_check_d fcd
           where fcd.enterprise_no=strEnterPriseNo and fcd.warehouse_no=strWareHouseNo
           and fcd.check_no=strCheckNo and fcd.status='10';
       v_strPlanNo               fcdata_check_m.plan_no%type;
       v_strFcdataType           fcdata_check_m.fcdata_type%type;
       v_strCellNo               fcdata_check_d.cell_no%type;
       v_strRecheckCycleFlag     varchar2(20);
       v_nRecheckCycleFlag       number(10);
       v_strDifferentLevel       varchar2(20);
       v_nDifferentLevel         number(10);
       v_nCount                  number(10);
       v_strResult               varchar2(20);
    begin
      strResult := 'N|[P_fcdata_comfireCheck]';

      update fcdata_check_m t set t.status=status
      where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo
      and t.check_no=strCheckNo and t.status='10' and t.check_type=strOperateType;

      if sql%notfound then
         strResult:='N|[找不到对应的盘点单]';
         return;
      end if;

      --获取视储位差异的值；2：不支持；1：支持
      PKLG_WMS_BASE.p_GetBasePara(strEnterPriseNo,strWareHouseNo,strOwnerNo,
             'FCS_DifferentLevel','FC','FCS',v_strDifferentLevel,v_nDifferentLevel,v_strResult);
      if substr(v_strResult, 1, 1) <> 'Y' then
            strResult :='N|[E30406]';
            return;
      end if;
      if strOperateType='1' then --初盘
         --检查是否还有储位未盘到
         begin
            select distinct t.cell_no into v_strCellNo from fcdata_check_d t
                   where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo and t.check_no=strCheckNo
                   and t.check_flag='0' and t.check_type='1' and rownum<=1;
         exception when no_data_found then
            v_strCellNo:='';
         end ;

         if v_strCellNo is null then--全部储位已盘点完
             --更新盘点单状态
             update fcdata_check_m set status='11',check_type='2',real_no=strUserId,
                    updt_name=strUserId,updt_date=sysdate
                 where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo and check_no=strCheckNo;
             --对没有盘点到的记录默认为0
             update FCdata_check_d set check_qty=0,real_qty=0
                 where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo and check_no=strCheckNo
                 and check_qty is null and article_no<>'N';

             --1：按储位级别,当储位上任意商品有差异，视为全部有差异；
             --2：按储位+商品级别，当储位上的某一商品有差异，按商品置差异"
             /* 添加盘点差异等级参数 添加3控制 20160722 wyf  */
             --3：按储位+商品属性，单品属性有差异，总数量无差异，视为无差异
             if v_strDifferentLevel='1' then
                 for GetCell in v_GetCell loop
                     update fcdata_check_d  set different_flag=(case when exists(
                     select 1 from fcdata_check_d a
                     where enterprise_no=strEnterPriseNo
                     and warehouse_no=strWareHouseNo
                     and cell_no=GetCell.cell_no
                     and check_no=strCheckNo
                     and a.article_qty<>a.check_qty   ) then '1'
                     else '0' end )
                     where enterprise_no=strEnterPriseNo
                       and warehouse_no=strWareHouseNo
                       and cell_no=GetCell.cell_no
                       and check_no=strCheckNo;
                 end loop;
             elsif v_strDifferentLevel='2' then
                 for GetCheckQty in v_GetCheckQty loop
                 --更新实盘量
                 update fcdata_check_d fcd
                 set fcd.different_flag=(case when GetCheckQty.check_qty = GetCheckQty.article_qty  --初盘量=库存量
                                    then '0' else '1' end)
                 where fcd.enterprise_no=strEnterPriseNo and fcd.warehouse_no=strWareHouseNo
                       and fcd.check_no=strCheckNo and fcd.cell_no=GetCheckQty.cell_no
                       and fcd.article_no=GetCheckQty.article_no;
                 end loop;
             elsif v_strDifferentLevel='3' then
               for GetCell in v_GetCell loop
                  update fcdata_check_d  set different_flag=(case when exists(
                     select 1 from fcdata_check_d a
                     where enterprise_no=strEnterPriseNo
                     and warehouse_no=strWareHouseNo
                     and cell_no=GetCell.cell_no
                     and check_no=strCheckNo
                     having sum(a.article_qty) <> sum(a.check_qty)
                     group by a.check_no,a.cell_no,a.article_no) then '1'
                     else '0' end )
                     where enterprise_no=strEnterPriseNo
                       and warehouse_no=strWareHouseNo
                       and cell_no=GetCell.cell_no
                       and check_no=strCheckNo;
                end loop;
             else
               strResult :='N|[盘点置差异参数超出范围]';
                return;
             end if;

             --获取盘点类型
             select fcm.fcdata_type into v_strFcdataType from fcdata_check_m fcm
             where fcm.enterprise_no=strEnterPriseNo and fcm.warehouse_no=strWareHouseNo and fcm.check_no=strCheckNo;
             if v_strFcdataType is null then
                strResult :='N|[E30406]';
                return;
             end if;

             if v_strFcdataType <> '1'then
                 --更新状态
                 update fcdata_check_m fcm set status=13,check_type='1'
                 where fcm.enterprise_no=strEnterPriseNo and fcm.warehouse_no=strWareHouseNo and fcm.owner_no=strOwnerNo
                 and fcm.check_no=strCheckNo;

                 update fcdata_check_d fcd set status=13,check_type='1'
                 where fcd.enterprise_no=strEnterPriseNo and fcd.warehouse_no=strWareHouseNo and fcd.owner_no=strOwnerNo
                 and fcd.check_no=strCheckNo;

                 --获取需求单号
                 select nvl(fcm.plan_no,'N') into v_strPlanNo from fcdata_check_m fcm
                        where fcm.enterprise_no=strEnterPriseNo and fcm.warehouse_no=strWareHouseNo and fcm.check_no=strCheckNo
                        and owner_no=strOwnerNo;

                 if v_strPlanNo <> 'N' then
                     select count(*) into v_nCount from fcdata_request_m
                         where enterprise_no=strEnterPriseNo and plan_no=v_strPlanNo and status='10'
                         and warehouse_no=strWareHouseNo;
                     if v_nCount=0 then
                         select count(*) into v_nCount from fcdata_check_direct
                            where enterprise_no=strEnterPriseNo and plan_no=v_strPlanNo and status='10'
                            and warehouse_no=strWareHouseNo;
                         if v_nCount=0 then
                             select count(*) into v_nCount from fcdata_check_m
                               where enterprise_no=strEnterPriseNo and plan_no=v_strPlanNo and status<>'13'
                               and warehouse_no=strWareHouseNo;
                             if v_nCount=0 then
                                --fcdata_plan_m的状态更新为13，将fcdata_check_m/d,fcdata_plan_m/d都转历史
                                update fcdata_plan_m set status=13
                                    where enterprise_no=strEnterPriseNo and plan_no=v_strPlanNo and warehouse_no=strWareHouseNo;

                                --huangb 20160509 转历史模式有select * 模式改为列字段模式
                                insert into fcdata_check_d_hty
                                (WAREHOUSE_NO,OWNER_NO,CHECK_NO,ROW_ID,CELL_NO,ARTICLE_NO,ORDER_ID
                                ,SUB_ORDER_ID,PACKING_QTY,LABEL_NO,SUB_LABEL_NO,DEPT_NO,BARCODE,PRODUCE_DATE
                                ,EXPIRE_DATE,QUALITY,LOT_NO,RSV_BATCH1,RSV_BATCH2,RSV_BATCH3,RSV_BATCH4,RSV_BATCH5
                                ,RSV_BATCH6,RSV_BATCH7,RSV_BATCH8,STOCK_TYPE,STOCK_VALUE,ARTICLE_QTY,CHECK_QTY,RECHECK_QTY
                                ,REAL_QTY,ADD_FLAG,STATUS,CHECK_TYPE,THIRD_QTY,CHECK_FLAG,CHECK_WORKER,CHECK_DATE
                                ,DIFFERENT_FLAG,RECHECK_WORKER,RECHECK_DATE,THIRD_WORKER,THIRD_DATE,ENTERPRISE_NO)
                                select a.WAREHOUSE_NO,a.OWNER_NO,a.CHECK_NO,a.ROW_ID,a.CELL_NO,a.ARTICLE_NO,a.ORDER_ID
                                ,a.SUB_ORDER_ID,a.PACKING_QTY,a.LABEL_NO,a.SUB_LABEL_NO,a.DEPT_NO,a.BARCODE,a.PRODUCE_DATE
                                ,a.EXPIRE_DATE,a.QUALITY,a.LOT_NO,a.RSV_BATCH1,a.RSV_BATCH2,a.RSV_BATCH3,a.RSV_BATCH4,a.RSV_BATCH5
                                ,a.RSV_BATCH6,a.RSV_BATCH7,a.RSV_BATCH8,a.STOCK_TYPE,a.STOCK_VALUE,a.ARTICLE_QTY,a.CHECK_QTY,a.RECHECK_QTY
                                ,a.REAL_QTY,a.ADD_FLAG,a.STATUS,a.CHECK_TYPE,a.THIRD_QTY,a.CHECK_FLAG,a.CHECK_WORKER,a.CHECK_DATE
                                ,a.DIFFERENT_FLAG,a.RECHECK_WORKER,a.RECHECK_DATE,a.THIRD_WORKER,a.THIRD_DATE,a.ENTERPRISE_NO
                                from fcdata_check_d a
                                where a.enterprise_no=strEnterPriseNo
                                  and a.warehouse_no=strWareHouseNo
                                  and a.OWNER_NO = strOwnerNo
                                  and a.check_no in
                                  (select b.check_no from fcdata_check_m b
                                    where b.enterprise_no=strEnterPriseNo
                                      and b.warehouse_no=strWareHouseNo
                                      and b.OWNER_NO = strOwnerNo
                                      and b.plan_no = v_strPlanNo);

                                delete fcdata_check_d a
                                 where a.enterprise_no=strEnterPriseNo
                                   and a.warehouse_no=strWareHouseNo
                                   and a.OWNER_NO = strOwnerNo
                                   and a.check_no in
                                   (select b.check_no from fcdata_check_m b
                                     where b.enterprise_no=strEnterPriseNo
                                       and b.warehouse_no=strWareHouseNo
                                       and b.OWNER_NO = strOwnerNo
                                       and b.plan_no = v_strPlanNo);

                                --huangb 20160509 转历史模式有select * 模式改为列字段模式 以及增加REPORT_UP_SERIAL字段
                                insert into fcdata_check_m_hty
                                (WAREHOUSE_NO,OWNER_NO,PLAN_NO,REQUEST_NO,CHECK_NO,CHECK_DATE,REQUEST_DATE
                                ,ASSIGN_NO,REAL_NO,STATUS,CHECK_REMARK,SERIAL_NO,FCDATA_TYPE,CHECK_TYPE
                                ,RGST_NAME,RGST_DATE,UPDT_NAME,UPDT_DATE,ENTERPRISE_NO,REPORT_UP_SERIAL)
                                select WAREHOUSE_NO,OWNER_NO,PLAN_NO,REQUEST_NO,CHECK_NO,CHECK_DATE,REQUEST_DATE
                                ,ASSIGN_NO,REAL_NO,STATUS,CHECK_REMARK,SERIAL_NO,FCDATA_TYPE,CHECK_TYPE
                                ,RGST_NAME,RGST_DATE,UPDT_NAME,UPDT_DATE,ENTERPRISE_NO,REPORT_UP_SERIAL
                                 from fcdata_check_m
                                 where enterprise_no = strEnterPriseNo
                                   and warehouse_no = strWareHouseNo
                                   and OWNER_NO = strOwnerNo
                                   and plan_no = v_strPlanNo;

                                delete fcdata_check_m
                                 where enterprise_no = strEnterPriseNo
                                   and warehouse_no = strWareHouseNo
                                   and OWNER_NO = strOwnerNo
                                   and plan_no = v_strPlanNo;

                             end if;
                         end if;
                     end if;
                 end if;
             else
               --更新状态
               update fcdata_check_d fcd set fcd.status='13', fcd.CHECK_TYPE= '1'
                   where fcd.enterprise_no=strEnterPriseNo and fcd.warehouse_no=strWareHouseNo
                   and fcd.check_no=strCheckNo
                   and fcd.different_flag='0';

            	 update fcdata_check_d fcd set fcd.status='10', fcd.CHECK_TYPE= '2'
                  where fcd.enterprise_no=strEnterPriseNo and fcd.warehouse_no=strWareHouseNo
                  and fcd.check_no=strCheckNo
                  and fcd.different_flag='1';
               if sql%notfound then
                  update fcdata_check_m fcm set fcm.status='13',fcm.check_type='1'
                  where fcm.enterprise_no=strEnterPriseNo and fcm.warehouse_no=strWareHouseNo
                  and fcm.check_no=strCheckNo;
               end if;
             end if;

         else
             strResult:='N|' || v_strCellNo || '[E30403]';--XX储位未盘点
             return;
         end if;
      end if;

      if strOperateType='2' or strOperateType='3' then  --复盘、三盘
         --检查是否还有储位未盘到
         begin
            select distinct t.cell_no into v_strCellNo from fcdata_check_d t
                   where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo and t.check_no=strCheckNo
                   and t.check_flag='0' and t.check_type=strOperateType and rownum<=1;
         exception when no_data_found then
            v_strCellNo:='';
         end ;

         --获取是否支持循环复盘的值；0：不支持；1：支持
         PKLG_WMS_BASE.p_GetBasePara(strEnterPriseNo,strWareHouseNo,strOwnerNo,
             'FCS_RecheckCycleFlag','FC','FCS',v_strRecheckCycleFlag,v_nRecheckCycleFlag,v_strResult);
         if substr(v_strResult, 1, 1) <> 'Y' then
                strResult :='N|[E30406]';
                return;
         end if;

         if v_strCellNo is null then
             --更新复盘单
             update fcdata_check_m set status='11',check_type='3',real_no=strUserId,
                    updt_name=strUserId,updt_date=sysdate
                 where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo and check_no=strCheckNo;
             --更新有差异的记录,但未被盘到的记录
             if strOperateType='2' then
                 --更新进入二盘但未盘记录的复盘量
                 update fcdata_check_d fcd set fcd.recheck_qty = 0,fcd.real_qty=0
                     where fcd.enterprise_no=strEnterPriseNo and fcd.warehouse_no=strWareHouseNo and fcd.check_no=strCheckNo
                       and fcd.check_type='2'
                       and fcd.recheck_qty is null;
                 --1：按储位级别,当储位上任意商品有差异，视为全部有差异；
                 --2：按储位+商品级别，当储位上的某一商品有差异，按商品置差异"
                 /* 添加盘点差异等级参数 添加3控制 20160722 wyf  */
                 --3：按储位+商品属性，单品属性有差异，总数量无差异，视为无差异
                 if v_strDifferentLevel='1' then
                     for GetCell in v_GetCell loop
                         update fcdata_check_d  set different_flag=(case when exists(
                         select 1 from fcdata_check_d a
                         where warehouse_no=strWareHouseNo and enterprise_no=strEnterPriseNo
                         and cell_no=GetCell.cell_no
                         and check_no=strCheckNo
                         and a.check_qty<>a.recheck_qty) then '1'
                         else '0' end )
                         where cell_no=GetCell.cell_no and check_no=strCheckNo
                         and warehouse_no=strWareHouseNo and enterprise_no=strEnterPriseNo
                         and check_type='2';
                     end loop;
                 elsif v_strDifferentLevel='2' then
                     for GetRecheckQty in v_GetRecheckQty loop
                     --更新实盘量
                     update fcdata_check_d fcd
                     set fcd.different_flag=(case when GetRecheckQty.check_qty <> GetRecheckQty.recheck_qty  --初盘量<>库存量
                                        then '1'
                                              else '0'  --初盘量<>复盘量
                                              end)
                     where fcd.enterprise_no=strEnterPriseNo and fcd.warehouse_no=strWareHouseNo
                           and fcd.owner_no=strOwnerNo
                           and fcd.check_no=strCheckNo and fcd.cell_no=GetRecheckQty.cell_no
                           and fcd.article_no=GetRecheckQty.article_no
                           and fcd.check_type='2';
                     end loop;
                 elsif v_strDifferentLevel='3' then
                   for GetCell in v_GetCell loop
                      update fcdata_check_d  set different_flag=(case when exists(
                         select 1 from fcdata_check_d a
                         where enterprise_no=strEnterPriseNo
                         and warehouse_no=strWareHouseNo
                         and cell_no=GetCell.cell_no
                         and check_no=strCheckNo
                         having sum(a.recheck_qty) <> sum(a.check_qty)
                         group by a.check_no,a.cell_no,a.article_no) then '1'
                         else '0' end )
                         where enterprise_no=strEnterPriseNo
                           and warehouse_no=strWareHouseNo
                           and cell_no=GetCell.cell_no
                           and check_no=strCheckNo;
                    end loop;
                 else
                   strResult :='N|[盘点置差异参数超出范围]';
                   return;
                 end if;
                 --写复盘日志
                 insert into fcdata_recheck_d(enterprise_no,warehouse_no, owner_no, check_no, row_id, cell_no, article_no,
                    packing_qty, label_no, sub_label_no, dept_no, barcode,
                    produce_date, expire_date,quality, lot_no,
                    rsv_batch1, rsv_batch2, rsv_batch3, rsv_batch4,
                    rsv_batch5, rsv_batch6, rsv_batch7, rsv_batch8,
                    stock_type, stock_value, recheck_qty, check_worker, recheck_time)
                 select fcd.enterprise_no,fcd.warehouse_no,fcd.owner_no,strCheckNo,rownum,fcd.cell_no,fcd.article_no,
                    fcd.packing_qty,fcd.label_no,fcd.sub_label_no,fcd.dept_no,fcd.barcode,
                    fcd.produce_date,fcd.expire_date,fcd.quality,fcd.lot_no,
                    fcd.rsv_batch1,fcd.rsv_batch2,fcd.rsv_batch3,fcd.rsv_batch4,
                    fcd.rsv_batch5,fcd.rsv_batch6,fcd.rsv_batch7,fcd.rsv_batch8,
                    fcd.stock_type,fcd.stock_value,fcd.recheck_qty,fcd.recheck_worker,fcd.recheck_date
                 from fcdata_check_d fcd
                 where fcd.enterprise_no=strEnterPriseNo and fcd.warehouse_no=strWareHouseNo and fcd.check_no=strCheckNo
                    and fcd.check_type=strOperateType;
                 --更新状态
                 update fcdata_check_d fcd set fcd.status='13'
                     where fcd.enterprise_no=strEnterPriseNo and fcd.warehouse_no=strWareHouseNo
                           and fcd.check_no=strCheckNo and fcd.check_type='2'
                           and fcd.different_flag='0';
                 --是否需要支持循环复盘；0：不支持；1：支持
                 if v_strRecheckCycleFlag='0' then
                     update fcdata_check_d fcd set fcd.status='10', fcd.CHECK_TYPE= '3'
                       where fcd.enterprise_no=strEnterPriseNo and fcd.warehouse_no=strWareHouseNo
                             and fcd.check_no=strCheckNo and fcd.check_type='2'
                             and fcd.different_flag='1';

                     if sql%notfound then
                        update fcdata_check_m fcm set fcm.status='13',fcm.check_type='2'
                        where fcm.enterprise_no=strEnterPriseNo
                         and fcm.warehouse_no=strWareHouseNo and fcm.check_no=strCheckNo;
                     else
                        update fcdata_check_m fcm set fcm.status='11',fcm.check_type='3'
                        where fcm.enterprise_no=strEnterPriseNo and fcm.warehouse_no=strWareHouseNo and fcm.check_no=strCheckNo;
                     end if;
                 else
                     update fcdata_check_d fcd set fcd.status='10', fcd.CHECK_TYPE= '2'
                       where fcd.enterprise_no=strEnterPriseNo and fcd.warehouse_no=strWareHouseNo
                             and fcd.check_no=strCheckNo and fcd.check_type='2'
                             and fcd.different_flag='1';
                     if sql%notfound then
                        update fcdata_check_m fcm set fcm.status='13',fcm.check_type='2'
                        where fcm.enterprise_no=strEnterPriseNo and fcm.warehouse_no=strWareHouseNo and fcm.check_no=strCheckNo;
                     else
                        update fcdata_check_m fcm set fcm.status='11',fcm.check_type='2'
                        where fcm.enterprise_no=strEnterPriseNo and fcm.warehouse_no=strWareHouseNo and fcm.check_no=strCheckNo;
                     end if;
                 end if;

             else
                 --更新有进入三盘但未盘的三盘量及实盘量
                 update fcdata_check_d fcd set fcd.third_qty = 0,fcd.real_qty=0
                     where fcd.enterprise_no=strEnterPriseNo and fcd.warehouse_no=strWareHouseNo and fcd.check_no=strCheckNo
                       and fcd.check_type='3'
                       and fcd.Third_Qty is null;

                 --写复盘日志
                 insert into fcdata_recheck_d(enterprise_no,warehouse_no, owner_no, check_no, row_id, cell_no, article_no,
                    packing_qty, label_no, sub_label_no, dept_no, barcode,
                    produce_date, expire_date,quality, lot_no,
                    rsv_batch1, rsv_batch2, rsv_batch3, rsv_batch4,
                    rsv_batch5, rsv_batch6, rsv_batch7, rsv_batch8,
                    stock_type, stock_value, recheck_qty, check_worker, recheck_time)
                 select fcd.enterprise_no,fcd.warehouse_no,fcd.owner_no,strCheckNo,rownum,fcd.cell_no,fcd.article_no,
                    fcd.packing_qty,fcd.label_no,fcd.sub_label_no,fcd.dept_no,fcd.barcode,
                    fcd.produce_date,fcd.expire_date,fcd.quality,fcd.lot_no,
                    fcd.rsv_batch1,fcd.rsv_batch2,fcd.rsv_batch3,fcd.rsv_batch4,
                    fcd.rsv_batch5,fcd.rsv_batch6,fcd.rsv_batch7,fcd.rsv_batch8,
                    fcd.stock_type,fcd.stock_value,fcd.third_qty,fcd.third_worker,fcd.third_date
                 from fcdata_check_d fcd
                 where fcd.enterprise_no=strEnterPriseNo and fcd.warehouse_no=strWareHouseNo and fcd.check_no=strCheckNo
                    and fcd.check_type=strOperateType;

                 --更新状态
                 update fcdata_check_d fcd set fcd.status='13',fcd.real_qty=fcd.third_qty
                     where fcd.enterprise_no=strEnterPriseNo and fcd.warehouse_no=strWareHouseNo
                           and fcd.check_no=strCheckNo and fcd.check_type='3';

                 update fcdata_check_m fcm set fcm.status='13',fcm.check_type='3'
                    where fcm.enterprise_no=strEnterPriseNo and fcm.warehouse_no=strWareHouseNo and fcm.check_no=strCheckNo;
             end if;
         else
             strResult:='N|' || v_strCellNo || '[E30403]';--XX储位未盘点
             return;
         end if;
      end if;

      strResult:='Y';

    end P_fcdata_comfireCheck;

    /**********************************************************************************************************
   zhouhuan
   2014.4.17
   功能：写需求单号头档
   ***********************************************************************************************************/
   procedure P_Fcdata_InsertRequestM(strEnterPriseNo      in    fcdata_plan_m.enterprise_no%type,
                                  strWareHouseNo          in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_plan_m.owner_no%type,
                                  strUserId               in    fcdata_plan_m.rgst_name%type,
                                  strPlanNo               in    fcdata_plan_m.plan_no%type,--盘点计划单号
                                  strRequstNo             OUT   fcdata_request_m.request_no%type,--盘点需求单号
                                  strResult               OUT   varchar2)is
         v_strPlanType            fcdata_request_m.plan_type%type;
         v_strFCDATATYPE          fcdata_request_m.FCDATA_TYPE%type;
    begin
      strResult := 'N|[P_Fcdata_InsertRequestM]';

    --获取盘点类型
      begin
          select fpm.plan_type,fpm.FCDATA_TYPE into v_strPlanType,v_strFCDATATYPE
          from fcdata_plan_m fpm where fpm.enterprise_no=strEnterPriseNo and fpm.warehouse_no=strWareHouseNo  and fpm.owner_no=strOwnerNo
                 and fpm.plan_no=strPlanNo;
      exception when no_data_found then
          strResult:='N|[E30006]';
          return;
      end;

     --取单号
     begin
          pklg_wms_base.p_getsheetno(strEnterPriseNo,strWareHouseNo,CONST_DOCUMENTTYPE.FCDATACR,strRequstNo,strResult);
          if (strRequstNo is null or substr(strResult, 1, 1) = 'N') then
            strResult := 'N|[E00541]'; --取单号错误!
            return;
          end if;
      end;

      --写需求单号头档
      insert into fcdata_request_m(enterprise_no,warehouse_no,owner_no,plan_type,FCDATA_TYPE,plan_no,status,
             request_no,request_date,rgst_name,rgst_date)
          values(strEnterPriseNo,strWareHouseNo,strOwnerNo,v_strPlanType,v_strFCDATATYPE,strPlanNo,'10',
             strRequstNo,trunc(sysdate),strUserID,sysdate);
      if (sql%rowcount <= 0) then
          strResult := 'N|[E30007]'; --写需求单号头档错误!
          return;
      end if;

      strResult:='Y|';

    end P_Fcdata_InsertRequestM;

    /**********************************************************************************************************
   MM
   2014.4.17
   功能：写差异单头档
   ***********************************************************************************************************/
   procedure P_Fcdata_Insertdifferentm(strEnterPriseNo    in    fcdata_check_m.enterprise_no%type,
                                  strWareHouseNo          in    fcdata_check_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_check_m.owner_no%type,
                                  strUserId               in    fcdata_check_m.rgst_name%type,
                                  strrequestno            in    fcdata_check_m.request_no %type,
                                  strcheckno              in    fcdata_check_m.check_no %type,
                                  strPlanNo               in   fcdata_check_m.plan_no%type,--盘点计划单号
                                  strDiffNo               OUT  fcdata_different_m.different_no%type,--盘点需求单号
                                  strResult               OUT    varchar2)is
    begin
      strResult := 'N|P_Fcdata_Insertdifferentm';


      --取差异单号
      pklg_wms_base.p_getsheetno(strEnterPriseNo,strWareHouseNo,CONST_DOCUMENTTYPE.FCDATACD, strDiffNo, strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;

      --写差异单头档
      insert into fcdata_different_m(enterprise_no,warehouse_no,owner_no,different_no,plan_no,
             request_no,check_no,operate_status,rgst_name,rgst_date)
          values(strEnterPriseNo,strWareHouseNo,strOwnerNo,strDiffNo,strplanno,
             strrequestno,strcheckno,'13',strUserId,sysdate);
      if (sql%rowcount <= 0) then
          strResult := 'N|[E30020]';
          return;
      end if;

      strResult:='Y|';

    end P_Fcdata_Insertdifferentm;

    /**********************************************************************************************************
   MM
   2014.4.17
   功能：写差异单明细档
   ***********************************************************************************************************/
   procedure P_Fcdata_InsertdifferentD(strEnterPriseNo    in    fcdata_check_m.enterprise_no%type,
                                  strWareHouseNo          in    fcdata_check_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_check_m.owner_no%type,
                                  strDiffNo               in    fcdata_different_m.different_no%type,
                                  strcheckno              in    fcdata_check_m.check_no %type,
                                  strResult               OUT    varchar2)is
    begin
      strResult := 'N|P_Fcdata_InsertdifferentD';


      --写差异单明细档
      insert into FCDATA_DIFFERENT_D
        (enterprise_no,warehouse_no,owner_no,different_no,cell_no,article_no,packing_qty,dept_no,barcode,
        produce_date,expire_date,quality,lot_no,rsv_batch1,rsv_batch2,rsv_batch3,rsv_batch4,
        rsv_batch5,rsv_batch6,rsv_batch7,rsv_batch8,stock_type,stock_value,article_qty,real_qty)
          select fcd.enterprise_no,fcd.warehouse_no,fcd.owner_no,strDiffNo,fcd.cell_no,fcd.article_no,
             fcd.packing_qty,'N',fcd.barcode,fcd.produce_date,
             fcd.expire_date,fcd.quality,fcd.lot_no,fcd.rsv_batch1,fcd.rsv_batch2,fcd.rsv_batch3,fcd.rsv_batch4,
             fcd.rsv_batch5,fcd.rsv_batch6,fcd.rsv_batch7,fcd.rsv_batch8,fcd.stock_type,fcd.stock_value,
             sum(article_qty) article_qty,sum(real_qty)real_qty
          from fcdata_check_d fcd
          where fcd.enterprise_no=strEnterPriseNo and fcd.warehouse_no=strWareHouseNo
          AND fcd.check_no=strcheckno and article_qty-real_qty<>0
          group by fcd.enterprise_no,fcd.warehouse_no,fcd.owner_no,fcd.cell_no,fcd.article_no,
             fcd.packing_qty,fcd.barcode,fcd.produce_date,
             fcd.expire_date,fcd.quality,fcd.lot_no,fcd.rsv_batch1,fcd.rsv_batch2,fcd.rsv_batch3,fcd.rsv_batch4,
             fcd.rsv_batch5,fcd.rsv_batch6,fcd.rsv_batch7,fcd.rsv_batch8,fcd.stock_type,fcd.stock_value;
      if (sql%rowcount <= 0) then
          strResult := 'N|[E30021]';
          return;
      end if;

      strResult:='Y|';

    end P_Fcdata_InsertdifferentD;

    /**********************************************************************************************************
   MM
   2014.4.17
   功能：写盘点单头档
   ***********************************************************************************************************/
   procedure P_Fcdata_Insertpdm(strEnterPriseNo           in    fcdata_check_m.enterprise_no%type,
                                strWareHouseNo            in    fcdata_check_m.warehouse_no%type,--仓库编码
                                strOwnerNo                in    fcdata_check_m.owner_no%type,
                                strUserId                 in    fcdata_check_m.rgst_name%type,
                                strPlanNo                 in    fcdata_check_m.plan_no%type,--盘点计划单号
                                strResult                 OUT   varchar2)is
    begin
      strResult := 'N|P_Fcdata_Insertpdm';

      --写盘点头档
      insert into fcdata_pd_m(enterprise_no,warehouse_no,OWNER_NO,PLAN_NO,PLAN_TYPE,STATUS,RGST_NAME,RGST_DATE,UPDT_NAME,UPDT_DATE)
        select m.enterprise_no,m.warehouse_no,m.owner_no,m.plan_no,m.plan_type,'13',strUserId,sysdate,strUserId,sysdate
          from fcdata_plan_m m
         where m.enterprise_no=strEnterPriseNo and m.plan_no = strPlanNo
           and m.owner_no = strOwnerNo
           and m.warehouse_no = strWareHouseNo;
      if (sql%rowcount <= 0) then
          strResult := 'N|[E30022]';
          return;
      end if;

      strResult:='Y|';

    end P_Fcdata_Insertpdm;

    /**********************************************************************************************************
   MM
   2014.4.17
   功能：写写盘点单明细档
   ***********************************************************************************************************/
   procedure P_Fcdata_Insertpdd(strEnterPriseNo           in    fcdata_check_m.enterprise_no%type,
                                strWareHouseNo            in    fcdata_check_m.warehouse_no%type,--仓库编码
                                strOwnerNo                in    fcdata_check_m.owner_no%type,
                                strPlanNo                 in    fcdata_check_m.plan_no%type,--盘点计划单号
                                strUserId                 in    fcdata_check_m.rgst_name%type,
                                strResult                 OUT   varchar2)is
    begin
      strResult := 'N|P_Fcdata_Insertpdd';


      --写盘点单明细档
      insert into FCDATA_PD_D
        (enterprise_no,warehouse_no,owner_no,plan_no,article_no,packing_qty,dept_no,barcode,produce_date,expire_date,
        quality,lot_no,rsv_batch1,rsv_batch2,rsv_batch3,rsv_batch4,rsv_batch5,rsv_batch6,rsv_batch7,
        rsv_batch8,stock_type,stock_value,article_qty,real_qty,error_no,rgst_name,rgst_date)
      select d.enterprise_no,d.warehouse_no,d.owner_no,m.plan_no,d.article_no,d.packing_qty,'N',d.barcode,
                 d.produce_date,d.expire_date,d.quality,d.lot_no,rsv_batch1,rsv_batch2,rsv_batch3,rsv_batch4,
                 rsv_batch5,rsv_batch6,rsv_batch7,rsv_batch8,d.stock_type,d.stock_value,
                 sum(d.article_qty) article_qty,sum(d.real_qty) real_qty,'',strUserId,sysdate
            from fcdata_check_d d, fcdata_check_m m
           where d.enterprise_no=m.enterprise_no
             and d.warehouse_no = m.warehouse_no
             and d.check_no = m.check_no
              and m.plan_no = strPlanNo
             and m.owner_no = strOwnerNo
             and m.warehouse_no = strWareHouseNo
             and m.enterprise_no = strEnterPriseNo
             and d.article_no <> 'N'
           group by d.enterprise_no,d.warehouse_no,d.owner_no,m.plan_no,d.article_no,d.packing_qty,'N',d.barcode,
                 d.produce_date,d.expire_date,d.quality,d.lot_no,rsv_batch1,rsv_batch2,rsv_batch3,rsv_batch4,
                 rsv_batch5,rsv_batch6,rsv_batch7,rsv_batch8,d.stock_type,d.stock_value;
      /*if (sql%rowcount <= 0) then
          strResult := 'N|[E30023]';
          return;
      end if;*/

      strResult:='Y|';

    end P_Fcdata_Insertpdd;

/**********************************************************************************************************
   zhouhuan
   2014.04.21
   功能：盘点发单--》切单-->写盘点单头档
***********************************************************************************************************/
    procedure P_InsertCheckM(strEnterPriseNo           in    fcdata_plan_m.enterprise_no%type,
                             strWareHouseNo            in    fcdata_plan_m.warehouse_no%type,--仓库编码
                             strOwnerNo                in    fcdata_plan_m.owner_no%type,
                             strUserId                 in    fcdata_plan_m.rgst_name%type,--作业人
                             strPaperUserId            in    fcdata_plan_m.rgst_name%type,--单据人
                             strDirectSerial           in   fcdata_check_direct.Direct_Serial%type,--指示序号
                             strCheckNo                OUT   fcdata_check_m.check_no%type,--盘点单号
                             strResult                 OUT    varchar2)is
                   v_strSerialNo         fcdata_check_m.serial_no%type;

    begin
      strResult := 'N|[P_InsertCheckM]';

             --取盘点单号；
               --获取需求单号
              pklg_wms_base.p_getsheetno(strEnterPriseNo,strWareHouseNo,CONST_DOCUMENTTYPE.FCDATACH,strCheckNo,strResult);
              if substr(strResult,1,1)='N' then
                 return;
              end if;

              v_strSerialNo := SEQ_FCDATA_CHECK_M.NEXTVAL;
              --写盘点头档
              insert into fcdata_check_m(enterprise_no,warehouse_no,owner_no,plan_no,request_no,check_no,
                     check_date,request_date,assign_no,status,fcdata_type,check_type,serial_no,
                     rgst_name,rgst_date)
                     select distinct strEnterPriseNo,strWareHouseNo,strOwnerNo,fcd.plan_no,fcd.request_no,
                     strCheckNo,trunc(sysdate),fcd.request_date,strPaperUserId,'11',
                     fcd.fcdata_type,'1',v_strSerialNo,strUserId,sysdate
                     from fcdata_check_direct fcd where fcd.enterprise_no=strEnterPriseNo and fcd.warehouse_no=strWareHouseNo
                     /*and fcd.owner_no=strOwnerNo*/ and fcd.direct_serial=strDirectSerial;
              if (sql%rowcount <= 0) then
                  strResult := 'N|[E30208]'; --写盘点单头档失败!
                  return;
              end if;

      strResult:='Y|';

    end P_InsertCheckM;

 /**********************************************************************************************************
   zhouhuan
   2014.04.21
   功能：盘点发单--》切单-->写盘点单明细
***********************************************************************************************************/
  procedure P_InsertCheckD(strEnterPriseNo          in    fcdata_plan_m.enterprise_no%type,
                           strWareHouseNo           in    fcdata_plan_m.warehouse_no%type,--仓库编码
                           strOwnerNo               in    fcdata_plan_m.owner_no%type,--货主编号
                           strPaperUserid           in    fcdata_plan_m.rgst_name%type,--单据人
                           strCheckNo               in    fcdata_check_m.check_no%type,--盘点单号
                           strRowId                 in    fcdata_check_m.check_no%type,--行号
                           strOrderId               in    fcdata_check_m.check_no%type,--储位顺序
                           strSubOrderId            in    fcdata_check_m.check_no%type,--储位上商品顺序
                           strDirectSerial          in    fcdata_check_direct.Direct_Serial%type,--指示序号
                           strResult                OUT   varchar2)is

         begin
          strResult := 'N|[P_InsertCheckD]';

          --写盘点明细
          insert into fcdata_check_d(enterprise_no,warehouse_no,owner_no,check_no,row_id,cell_no,
             article_no,order_id,sub_order_id,barcode,packing_qty,lot_no,produce_date,expire_date,
             quality,rsv_batch1,rsv_batch2,rsv_batch3,rsv_batch4,rsv_batch5,rsv_batch6,rsv_batch7,
             rsv_batch8,label_no,sub_label_no,stock_type,stock_value,dept_no,article_qty,
             status,check_type,check_flag,different_flag,check_date,check_worker)
             select distinct strEnterPriseNo,strWareHouseNo,strOwnerNo,strCheckNo,strRowId+1,fcd.cell_no,
             fcd.article_no,strOrderId,strSubOrderId,fcd.barcode,fcd.packing_qty,fcd.lot_no,
             fcd.produce_date,fcd.expire_date,fcd.quality,fcd.rsv_batch1,fcd.rsv_batch2,fcd.rsv_batch3,
             fcd.rsv_batch4,fcd.rsv_batch5,fcd.rsv_batch6,fcd.rsv_batch7,fcd.rsv_batch8,
             fcd.label_no,fcd.sub_label_no,fcd.stock_type,fcd.stock_value,fcd.dept_no,
             fcd.article_qty,'10','1','0','1',trunc(sysdate),strPaperUserid from fcdata_check_direct fcd
             where fcd.enterprise_no=strEnterPriseNo and fcd.warehouse_no=strWareHouseNo and fcd.owner_no=strOwnerNo and
             fcd.direct_serial=strDirectSerial;
           if (sql%rowcount <= 0) then
                strResult := 'N|[E30209]'; --写盘点单明细失败!
                return;
            end if;
           strResult:='Y|';
   end P_InsertCheckD;

 /**********************************************************************************************************
   luozhiling
   2015.10.17
   功能：储位检查时按储位写检查单的实时库存，目前这种方式只适用于RF的储位检查
***********************************************************************************************************/
  procedure P_InsertCellToCheckD(strEnterPriseNo          in    fcdata_plan_m.enterprise_no%type,
                           strWareHouseNo           in    fcdata_plan_m.warehouse_no%type,--仓库编码
                           strOwnerNo               in    fcdata_plan_m.owner_no%type,--货主编号
                           strCheckNo               in    fcdata_check_m.check_no%type,--盘点单号
                           strCellNo                in    fcdata_check_d.cell_no%type,
                           strUserId                in    fcdata_check_m.rgst_name%type,--盘点人
                           strResult                OUT   varchar2)is
     v_nRowId              integer;
     v_nOrderId            integer;
     v_nSubOrderId         integer;
   begin
      strResult := 'N|[P_InsertCellToCheckD]';

      --获取当前盘点单最大的ROW_id;
      select max(t.row_id) into v_nRowId from fcdata_check_d t where t.enterprise_no=strEnterPriseNo
      and t.warehouse_no=strWareHouseNo and t.check_no=strCheckNo;

      --获取当前盘点单当前储位的
      select max(t.order_id),max(t.sub_order_id) into v_nOrderId,v_nSubOrderId
      from fcdata_check_d t where t.enterprise_no=strEnterPriseNo
      and t.warehouse_no=strWareHouseNo and t.check_no=strCheckNo
      and t.cell_no=strCellNo;

      -- 获取当前储位库存
      for InertCheckd in (select t.cell_no,t.article_no,sai.barcode,t.packing_qty,sai.lot_no,sai.produce_date,
          sai.expire_date,sai.quality,sai.rsv_batch1,sai.rsv_batch2,sai.rsv_batch3,sai.rsv_batch4,
          sai.rsv_batch5,sai.rsv_batch6,sai.rsv_batch7,sai.rsv_batch8,t.label_no,t.sub_label_no,
          t.stock_type,t.stock_value,t.dept_no,sum(t.qty) qty
          from stock_content t,stock_article_info sai
          where t.enterprise_no=sai.enterprise_no and t.article_no=sai.article_no
          and t.article_id=sai.article_id and t.enterprise_no=strEnterPriseNo
           and t.warehouse_no=strWareHouseNo and t.cell_no=strCellNo
           and t.qty>0
       group by t.cell_no,t.article_no,sai.barcode,t.packing_qty,sai.lot_no,sai.produce_date,
          sai.expire_date,sai.quality,sai.rsv_batch1,sai.rsv_batch2,sai.rsv_batch3,sai.rsv_batch4,
          sai.rsv_batch5,sai.rsv_batch6,sai.rsv_batch7,sai.rsv_batch8,t.label_no,t.sub_label_no,
          t.stock_type,t.stock_value,t.dept_no) loop
          insert into fcdata_check_d(enterprise_no,warehouse_no,owner_no,check_no,row_id,cell_no,
             article_no,order_id,sub_order_id,barcode,packing_qty,lot_no,produce_date,expire_date,
             quality,rsv_batch1,rsv_batch2,rsv_batch3,rsv_batch4,rsv_batch5,rsv_batch6,rsv_batch7,
             rsv_batch8,label_no,sub_label_no,stock_type,stock_value,dept_no,article_qty,
             status,check_type,check_flag,different_flag,check_date,check_worker)
          values(strEnterPriseNo,strWareHouseNo,strOwnerNo,strCheckNo,v_nRowId+1,strCellNo,
            InertCheckd.article_no,v_nOrderId,v_nSubOrderId+1,InertCheckd.barcode,InertCheckd.packing_qty,
            InertCheckd.lot_no,InertCheckd.produce_date,InertCheckd.expire_date,InertCheckd.quality,
            InertCheckd.rsv_batch1,InertCheckd.rsv_batch2,InertCheckd.rsv_batch3,InertCheckd.rsv_batch4,
            InertCheckd.rsv_batch5,InertCheckd.rsv_batch6,InertCheckd.rsv_batch7,InertCheckd.rsv_batch8,
            InertCheckd.label_no,InertCheckd.sub_label_no,InertCheckd.stock_type,InertCheckd.stock_value,
            InertCheckd.dept_no,InertCheckd.qty,'10','1','1','0',sysdate,strUserId);
      end loop;

       strResult:='Y|';
   end P_InsertCellToCheckD;
 /**********************************************************************************************************
   zhouhuan
   2014.04.21
   功能：定位指示转历史
***********************************************************************************************************/
   procedure P_CheckDirectToHty(strEnterPriseNo       in    fcdata_plan_m.enterprise_no%type,
                            strWareHouseNo            in    fcdata_check_direct.warehouse_no%type,--仓库编码
                            strOwnerNo                in    fcdata_check_direct.owner_no%type,--货主编号
                            strRequestNo              in    fcdata_check_direct.request_no%type,--需求单号
                            strResult                 out   varchar2) is
               begin
                 strResult := 'N|[P_CheckDirectToHty]';

                 --将需求单对应的定位指示转历史
                 insert into FCDATA_CHECK_DIRECT_HTY
                   (enterprise_no,WAREHOUSE_NO,OWNER_NO,DIRECT_SERIAL,PLAN_NO,REQUEST_NO,
                    CELL_NO,ARTICLE_NO,PACKING_QTY,ARTICLE_QTY,STATUS,REQUEST_DATE,FCDATA_TYPE,
                    LABEL_NO,SUB_LABEL_NO,DEPT_NO,BARCODE,PRODUCE_DATE,EXPIRE_DATE,QUALITY,LOT_NO,
                    RSV_BATCH1,RSV_BATCH2,RSV_BATCH3,RSV_BATCH4,
                    RSV_BATCH5,RSV_BATCH6,RSV_BATCH7,RSV_BATCH8,
                    STOCK_TYPE,STOCK_VALUE,RGST_NAME,RGST_DATE,UPDT_NAME,UPDT_DATE)
                  select  fcd.enterprise_no,fcd.WAREHOUSE_NO,fcd.OWNER_NO,fcd.DIRECT_SERIAL,fcd.PLAN_NO,fcd.REQUEST_NO,
                      fcd.CELL_NO,fcd.ARTICLE_NO,fcd.PACKING_QTY,fcd.ARTICLE_QTY,fcd.STATUS,fcd.REQUEST_DATE,fcd.FCDATA_TYPE,
                      fcd.LABEL_NO,fcd.SUB_LABEL_NO,fcd.DEPT_NO,fcd.BARCODE,fcd.PRODUCE_DATE,fcd.EXPIRE_DATE,fcd.QUALITY,fcd.LOT_NO,
                      fcd.RSV_BATCH1,fcd.RSV_BATCH2,fcd.RSV_BATCH3,fcd.RSV_BATCH4,
                      fcd.RSV_BATCH5,fcd.RSV_BATCH6,fcd.RSV_BATCH7,fcd.RSV_BATCH8,
                      fcd.STOCK_TYPE,fcd.STOCK_VALUE,fcd.RGST_NAME,fcd.RGST_DATE,fcd.UPDT_NAME,fcd.UPDT_DATE
                  from fcdata_check_direct fcd
                  where fcd.enterprise_no=strEnterPriseNo and fcd.warehouse_no=strWareHouseNo
                    and fcd.request_no=strRequestNo
                    and fcd.status='13';

       --删除需求单对应的定位指示数据
       delete from fcdata_check_direct fcd
         where fcd.enterprise_no=strEnterPriseNo and fcd.warehouse_no=strWareHouseNo
         and fcd.request_no=strRequestNo
         and fcd.status='13';

       strResult := 'Y|';
        exception
          when others then
            strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

       end P_CheckDirectToHty;


/**********************************************************************************************************
   zhouhuan
   2014.05.6
   功能：盘点需求转历史
***********************************************************************************************************/
   procedure P_CheckRequestToHty(strEnterPriseNo      in    fcdata_plan_m.enterprise_no%type,
                            strWareHouseNo            in    fcdata_request_m.warehouse_no%type,--仓库编码
                            strOwnerNo                in    fcdata_request_m.owner_no%type,--货主编号
                            strRequestNo              in    fcdata_request_m.request_no%type,--需求单号
                            strResult                 out   varchar2) is
               begin
                 strResult := 'N|[P_CheckRequestToHty]';

                 --将需求单头档转历史
                 insert into FCDATA_REQUEST_M_HTY
                   (enterprise_no,WAREHOUSE_NO,
                    OWNER_NO,
                    PLAN_TYPE,
                    FCDATA_TYPE,
                    PLAN_NO,
                    REQUEST_NO,
                    REQUEST_DATE,
                    STATUS,
                    RGST_NAME,
                    RGST_DATE,
                    UPDT_NAME,
                    UPDT_DATE,
                    --huangb 20150509
                    REPORT_UP_SERIAL)
                  select  strEnterPriseNo,strWareHouseNo,
                    strOwnerNo,
                    frm.PLAN_TYPE,
                    frm.FCDATA_TYPE,
                    frm.PLAN_NO,
                    frm.REQUEST_NO,
                    frm.REQUEST_DATE,
                    frm.STATUS,
                    frm.RGST_NAME,
                    frm.RGST_DATE,
                    frm.UPDT_NAME,
                    frm.UPDT_DATE,
                    --huangb 20150509
                    REPORT_UP_SERIAL
                  from fcdata_request_m frm
                  where frm.enterprise_no=strEnterPriseNo and frm.warehouse_no=strWareHouseNo

                    and frm.request_no=strRequestNo
                    and frm.status='13';

       --删除需求单头档数据
       delete from fcdata_request_m frm
         where frm.enterprise_no=strEnterPriseNo and frm.warehouse_no=strWareHouseNo
                    and frm.request_no=strRequestNo
                    and frm.status='13';


             --将需求单明细转历史
                 insert into FCDATA_REQUEST_D_HTY
                   (enterprise_no,WAREHOUSE_NO,
                    OWNER_NO,
                    REQUEST_NO,
                    WARE_NO,
                    AREA_NO,
                    STOCK_NO,
                    ARTICLE_NO,
                    GROUP_NO,
                    CELL_NO)
                  select strEnterPriseNo,strWareHouseNo,
                        strOwnerNo,
                        strRequestNo,
                        frd.WARE_NO,
                        frd.AREA_NO,
                        frd.STOCK_NO,
                        frd.ARTICLE_NO,
                        frd.GROUP_NO,
                        frd.CELL_NO
                  from fcdata_request_d frd
                  where frd.enterprise_no=strEnterPriseNo and frd.warehouse_no=strWareHouseNo
                    and frd.request_no=strRequestNo;

       --删除需求单对应的定位指示数据
       delete from fcdata_request_d frd
         where frd.enterprise_no=strEnterPriseNo and frd.warehouse_no=strWareHouseNo
                    and frd.request_no=strRequestNo;

       strResult := 'Y|';
        exception
          when others then
            strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

       end P_CheckRequestToHty;

  /**********************************************************************************************************
   JUN
   2014.05.6
   功能：更新盘点单
   ***********************************************************************************************************/
   procedure P_Update_Fcdata_CheckM(strEnterPriseNo        in       fcdata_check_m.enterprise_no%type,
                                    strWareHouseNo         in       fcdata_check_m.warehouse_no%type,
                                    strOwnerNo             in       fcdata_check_m.owner_no%type,
                                    strCheckNo             in       fcdata_check_m.check_no%type,
                                    strUserId              in       fcdata_check_m.rgst_name%type,
                                    strCheckType           in       fcdata_check_m.check_type%type,
                                    strStatus              in       fcdata_check_m.status%type,
                                    strResult              out      varchar2) is
  begin
    strResult:='N|[P_Update_Fcdata_CheckM]';
    update fcdata_check_m t
      set t.status=strStatus,
          t.check_type=strCheckType,
          t.assign_no=strUserId,
          t.updt_name=strUserId,
          t.updt_date=sysdate
   where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo
         and t.owner_no=strOwnerNo
         and t.check_no=strCheckNo;
   if sql%notfound then
     strResult:='N|[E30407]';
     return;
   end if;

   strResult:='Y';
  exception
     when others then
       strResult := 'N|' || SQLERRM ||
           substr(dbms_utility.format_error_backtrace, 1, 256);


  end P_Update_Fcdata_CheckM;

  /**********************************************************************************************************
   JUN
   2014.05.6
   功能：更新盘点明细
   ***********************************************************************************************************/
  procedure P_Update_Fcdata_CheckD(strEnterPriseNo         in      fcdata_check_m.enterprise_no%type,
                                   strWareHouseNo          in      fcdata_check_d.warehouse_no%type,
                                    strOwnerNo             in      fcdata_check_d.owner_no%type,
                                    strCheckNo             in      fcdata_check_d.check_no%type,
                                    strCellNo              in      fcdata_check_d.cell_no%type,
                                    strCheckType           in      fcdata_check_d.check_type%type,
                                    strStatus              in      fcdata_check_d.status%type,
                                    strResult              out      varchar2)is
  begin
    strResult:='N|[P_Update_Fcdata_CheckD]';
    if strCheckType='2' then  --如果等于复盘
       update fcdata_check_d t set t.check_type=strCheckType,t.status=strStatus,
         t.different_flag='1',t.real_qty=null,t.check_flag='0'
       where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo
       and t.check_no=strCheckNo and t.cell_no=strCellNo;

       if sql%notfound then
         strResult:='N|[E30408]';
         return;
       end if;
    else                  --如果是三盘
       update fcdata_check_d t set t.check_type=strCheckType,t.status=strStatus,
         t.different_flag='1',t.real_qty=null,t.check_flag='0'
       where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo
       and t.check_no=strCheckNo and t.check_type='3';

       if sql%notfound then
         strResult:='N|[E30408]';
         return;
       end if;
    end if;

  strResult:='Y';

  exception
      when others then
        strResult := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);


  end P_Update_Fcdata_CheckD;

  /*******************************************************************************************************
  创建人：huangb
  创建时间：2016.05.17
  功能说明：盘点单据转历史
  ********************************************************************************************************/
  procedure P_FC_InsertHTY(strEnterPriseNo in  fcdata_plan_m.enterprise_no%type,
                           strWareHouseNo  in  fcdata_plan_m.warehouse_no%type,--仓库编码
                           strOwnerNo      in  fcdata_plan_m.owner_no%type,
                           strPlanNo       in  fcdata_plan_m.plan_no%type,--盘点计划单号
                           strUserId       in  fcdata_plan_m.rgst_name%type,--作业人
                           strOutMsg       OUT varchar2) is
  begin
   strOutMsg := 'N|[P_FC_InsertHTY]';

   --盘点计划单头档转历史
   insert into fcdata_plan_mhty
     (warehouse_no, owner_no, plan_type, fcdata_type, source_plan_no, plan_no, plan_date
     , begin_date, end_date, status, create_flag, plan_remark, send_flag, rgst_name
     , rgst_date, updt_name, updt_date, enterprise_no, org_no, report_up_serial)
   select fpm.warehouse_no, fpm.owner_no, fpm.plan_type, fpm.fcdata_type, fpm.source_plan_no, fpm.plan_no, fpm.plan_date
     , fpm.begin_date, fpm.end_date, fpm.status, fpm.create_flag, fpm.plan_remark, fpm.send_flag, fpm.rgst_name
     , fpm.rgst_date, strUserId, sysdate, fpm.enterprise_no, fpm.org_no, fpm.report_up_serial
   from fcdata_plan_m fpm
   where fpm.enterprise_no = strEnterPriseNo
     and fpm.warehouse_no = strWareHouseNo
     and fpm.owner_no = strOwnerNo
     and fpm.plan_no = strPlanNo;

   --盘点计划单明细转历史
   insert into fcdata_plan_dhty
     (warehouse_no, owner_no, plan_no, plan_id, ware_no, area_no, stock_no
     , article_no, group_no, cell_no, enterprise_no)
   select fpd.warehouse_no, fpd.owner_no, fpd.plan_no, fpd.plan_id, fpd.ware_no, fpd.area_no, fpd.stock_no
     , fpd.article_no, fpd.group_no, fpd.cell_no, fpd.enterprise_no
   from fcdata_plan_d fpd
   where fpd.enterprise_no = strEnterPriseNo
     and fpd.warehouse_no = strWareHouseNo
     and fpd.owner_no = strOwnerNo
     and fpd.plan_no = strPlanNo;

   --盘点单明细转历史
   insert into fcdata_check_d_hty
     (WAREHOUSE_NO,OWNER_NO,CHECK_NO,ROW_ID,CELL_NO,ARTICLE_NO,ORDER_ID
     ,SUB_ORDER_ID,PACKING_QTY,LABEL_NO,SUB_LABEL_NO,DEPT_NO,BARCODE,PRODUCE_DATE
     ,EXPIRE_DATE,QUALITY,LOT_NO,RSV_BATCH1,RSV_BATCH2,RSV_BATCH3,RSV_BATCH4,RSV_BATCH5
     ,RSV_BATCH6,RSV_BATCH7,RSV_BATCH8,STOCK_TYPE,STOCK_VALUE,ARTICLE_QTY,CHECK_QTY,RECHECK_QTY
     ,REAL_QTY,ADD_FLAG,STATUS,CHECK_TYPE,THIRD_QTY,CHECK_FLAG,CHECK_WORKER,CHECK_DATE
     ,DIFFERENT_FLAG,RECHECK_WORKER,RECHECK_DATE,THIRD_WORKER,THIRD_DATE,ENTERPRISE_NO)
   select a.WAREHOUSE_NO,a.OWNER_NO,a.CHECK_NO,a.ROW_ID,a.CELL_NO,a.ARTICLE_NO,a.ORDER_ID
     ,a.SUB_ORDER_ID,a.PACKING_QTY,a.LABEL_NO,a.SUB_LABEL_NO,a.DEPT_NO,a.BARCODE,a.PRODUCE_DATE
     ,a.EXPIRE_DATE,a.QUALITY,a.LOT_NO,a.RSV_BATCH1,a.RSV_BATCH2,a.RSV_BATCH3,a.RSV_BATCH4,a.RSV_BATCH5
     ,a.RSV_BATCH6,a.RSV_BATCH7,a.RSV_BATCH8,a.STOCK_TYPE,a.STOCK_VALUE,a.ARTICLE_QTY,a.CHECK_QTY,a.RECHECK_QTY
     ,a.REAL_QTY,a.ADD_FLAG,a.STATUS,a.CHECK_TYPE,a.THIRD_QTY,a.CHECK_FLAG,a.CHECK_WORKER,a.CHECK_DATE
     ,a.DIFFERENT_FLAG,a.RECHECK_WORKER,a.RECHECK_DATE,a.THIRD_WORKER,a.THIRD_DATE,a.ENTERPRISE_NO
   from fcdata_check_d a
   where a.enterprise_no=strEnterPriseNo
     and a.warehouse_no=strWareHouseNo
     and a.OWNER_NO = strOwnerNo
     and a.check_no in
     (select b.check_no from fcdata_check_m b
       where b.enterprise_no=strEnterPriseNo
         and b.warehouse_no=strWareHouseNo
         and b.OWNER_NO = strOwnerNo
         and b.plan_no = strPlanNo);

   --盘点单头档转历史
   insert into fcdata_check_m_hty
     (WAREHOUSE_NO,OWNER_NO,PLAN_NO,REQUEST_NO,CHECK_NO,CHECK_DATE,REQUEST_DATE
     ,ASSIGN_NO,REAL_NO,STATUS,CHECK_REMARK,SERIAL_NO,FCDATA_TYPE,CHECK_TYPE
     ,RGST_NAME,RGST_DATE,UPDT_NAME,UPDT_DATE,ENTERPRISE_NO,REPORT_UP_SERIAL)
   select WAREHOUSE_NO,OWNER_NO,PLAN_NO,REQUEST_NO,CHECK_NO,CHECK_DATE,REQUEST_DATE
     ,ASSIGN_NO,REAL_NO,STATUS,CHECK_REMARK,SERIAL_NO,FCDATA_TYPE,CHECK_TYPE
     ,RGST_NAME,RGST_DATE,strUserId,sysdate,ENTERPRISE_NO,REPORT_UP_SERIAL
   from fcdata_check_m
   where enterprise_no = strEnterPriseNo
     and warehouse_no = strWareHouseNo
     and OWNER_NO = strOwnerNo
     and plan_no = strPlanNo;

   --删除正表数据
   delete fcdata_plan_m fpm
    where fpm.enterprise_no = strEnterPriseNo
      and fpm.warehouse_no = strWareHouseNo
      and fpm.owner_no = strOwnerNo
      and fpm.plan_no = strPlanNo;

   delete fcdata_plan_d fpd
    where fpd.enterprise_no = strEnterPriseNo
      and fpd.warehouse_no = strWareHouseNo
      and fpd.owner_no = strOwnerNo
      and fpd.plan_no = strPlanNo;

   delete fcdata_check_d a
    where a.enterprise_no=strEnterPriseNo
      and a.warehouse_no=strWareHouseNo
      and a.OWNER_NO = strOwnerNo
      and a.check_no in
      (select b.check_no from fcdata_check_m b
        where b.enterprise_no=strEnterPriseNo
          and b.warehouse_no=strWareHouseNo
          and b.OWNER_NO = strOwnerNo
          and b.plan_no = strPlanNo);

   delete fcdata_check_m
    where enterprise_no = strEnterPriseNo
      and warehouse_no = strWareHouseNo
      and OWNER_NO = strOwnerNo
      and plan_no = strPlanNo;

  strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|P_FC_InsertHTY' || SQLERRM ||
            substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end P_FC_InsertHTY;

  /*******************************************************************************************************
  创建人：huangb
  创建时间：2016.05.17
  功能说明：盘点差异以及盘点确认装历史 供接口调用
  ********************************************************************************************************/
  procedure P_FC_DiffAndPDHTYByInterface(strEnterpriseNo   in fcdata_different_mhty.enterprise_no%type, --企业编号
                                         strWareHouseNo    in fcdata_different_mhty.warehouse_no%type, --仓库编码
                                         strOwnerNo        in fcdata_different_mhty.owner_no%type,
                                         strReportUpSerial in fcdata_different_mhty.REPORT_UP_SERIAL%type, --上传序列号
                                         strOutMsg         out varchar2) is
   begin
    strOutMsg := 'N|[P_FC_DiffAndPDHTYByInterface]';

    --盘点差异明细转历史
    insert into fcdata_different_dhty
      (warehouse_no, owner_no, different_no, cell_no, article_no, packing_qty, dept_no
      , barcode, produce_date, expire_date, quality, lot_no, rsv_batch1, rsv_batch2
      , rsv_batch3, rsv_batch4, rsv_batch5, rsv_batch6, rsv_batch7, rsv_batch8, stock_type
      , stock_value, article_qty, real_qty, enterprise_no)
    select fdd.warehouse_no, fdd.owner_no, fdd.different_no, fdd.cell_no, fdd.article_no, fdd.packing_qty, fdd.dept_no
      , fdd.barcode, fdd.produce_date, fdd.expire_date, fdd.quality, fdd.lot_no, fdd.rsv_batch1, fdd.rsv_batch2
      , fdd.rsv_batch3, fdd.rsv_batch4, fdd.rsv_batch5, fdd.rsv_batch6, fdd.rsv_batch7, fdd.rsv_batch8, fdd.stock_type
      , fdd.stock_value, fdd.article_qty, fdd.real_qty, fdd.enterprise_no
    from fcdata_different_d fdd
    where fdd.enterprise_no = strEnterpriseNo
      and fdd.warehouse_no = strWareHouseNo
      and fdd.owner_no = strOwnerNo
      and exists
          (select 'X' from fcdata_different_m fdm
            where fdd.enterprise_no = fdm.enterprise_no
              and fdd.warehouse_no = fdm.warehouse_no
              and fdd.owner_no = fdm.owner_no
              and fdd.different_no = fdm.different_no
              and fdm.enterprise_no = strEnterpriseNo
              and fdm.warehouse_no = strWareHouseNo
              and fdm.owner_no = strOwnerNo
              and fdm.REPORT_UP_SERIAL <= strReportUpSerial);

    --盘点差异头档转历史
    insert into fcdata_different_mhty
      (warehouse_no, owner_no, different_no, plan_no, request_no, check_no, operate_status
      , different_remark, send_flag, rgst_name, rgst_date, updt_name, updt_date, enterprise_no
      , report_up_serial)
    select fdm.warehouse_no, fdm.owner_no, fdm.different_no, fdm.plan_no, fdm.request_no, fdm.check_no, fdm.operate_status
      , fdm.different_remark, fdm.send_flag, fdm.rgst_name, fdm.rgst_date, 'admin', sysdate, fdm.enterprise_no
      , fdm.report_up_serial
    from fcdata_different_m fdm
    where fdm.enterprise_no = strEnterpriseNo
      and fdm.warehouse_no = strWareHouseNo
      and fdm.owner_no = strOwnerNo
      and fdm.REPORT_UP_SERIAL <= strReportUpSerial;

    --盘点确认明细转历史
    insert into fcdata_pd_dhty
      (warehouse_no, owner_no, plan_no, article_no, packing_qty, dept_no, barcode
      , produce_date, expire_date, quality, lot_no, rsv_batch1, rsv_batch2, rsv_batch3
      , rsv_batch4, rsv_batch5, rsv_batch6, rsv_batch7, rsv_batch8, stock_type, stock_value
      , article_qty, real_qty, error_no, rgst_name, rgst_date, updt_name
      , updt_date, enterprise_no)
    select fpd.warehouse_no, fpd.owner_no, fpd.plan_no, fpd.article_no, fpd.packing_qty, fpd.dept_no, fpd.barcode
      , fpd.produce_date, fpd.expire_date, fpd.quality, fpd.lot_no, fpd.rsv_batch1, fpd.rsv_batch2, fpd.rsv_batch3
      , fpd.rsv_batch4, fpd.rsv_batch5, fpd.rsv_batch6, fpd.rsv_batch7, fpd.rsv_batch8, fpd.stock_type, fpd.stock_value
      , fpd.article_qty, fpd.real_qty, fpd.error_no, fpd.rgst_name, fpd.rgst_date, 'admin'
      , sysdate, fpd.enterprise_no
    from fcdata_pd_d fpd
    where fpd.enterprise_no = strEnterpriseNo
      and fpd.warehouse_no = strWareHouseNo
      and fpd.owner_no = strOwnerNo
      and exists
          (select 'X' from fcdata_pd_m fpm
            where fpd.enterprise_no = fpm.enterprise_no
              and fpd.warehouse_no = fpm.warehouse_no
              and fpd.owner_no = fpm.owner_no
              and fpd.plan_no = fpm.plan_no
              and fpm.enterprise_no = strEnterpriseNo
              and fpm.warehouse_no = strWareHouseNo
              and fpm.owner_no = strOwnerNo
              and fpm.REPORT_UP_SERIAL <= strReportUpSerial);

    --盘点确认头档转历史
    insert into fcdata_pd_mhty
      (warehouse_no, owner_no, plan_no, plan_type, status, send_flag, rgst_name
      , rgst_date, updt_name, updt_date, enterprise_no, report_up_serial)
    select fpm.warehouse_no, fpm.owner_no, fpm.plan_no, fpm.plan_type, fpm.status, fpm.send_flag, fpm.rgst_name
      , fpm.rgst_date, 'admin', sysdate, fpm.enterprise_no, fpm.report_up_serial
    from fcdata_pd_m fpm
    where fpm.enterprise_no = strEnterpriseNo
      and fpm.warehouse_no = strWareHouseNo
      and fpm.owner_no = strOwnerNo
      and fpm.REPORT_UP_SERIAL <= strReportUpSerial;

    --删除正表数据
    delete fcdata_different_d fdd
     where fdd.enterprise_no = strEnterpriseNo
       and fdd.warehouse_no = strWareHouseNo
       and fdd.owner_no = strOwnerNo
       and exists
           (select 'X' from fcdata_different_m fdm
             where fdd.enterprise_no = fdm.enterprise_no
               and fdd.warehouse_no = fdm.warehouse_no
               and fdd.owner_no = fdm.owner_no
               and fdd.different_no = fdm.different_no
               and fdm.enterprise_no = strEnterpriseNo
               and fdm.warehouse_no = strWareHouseNo
               and fdm.owner_no = strOwnerNo
               and fdm.REPORT_UP_SERIAL <= strReportUpSerial);

    delete fcdata_different_m fdm
     where fdm.enterprise_no = strEnterpriseNo
       and fdm.warehouse_no = strWareHouseNo
       and fdm.owner_no = strOwnerNo
       and fdm.REPORT_UP_SERIAL <= strReportUpSerial;

    delete fcdata_pd_d fpd
     where fpd.enterprise_no = strEnterpriseNo
       and fpd.warehouse_no = strWareHouseNo
       and fpd.owner_no = strOwnerNo
       and exists
           (select 'X' from fcdata_pd_m fpm
             where fpd.enterprise_no = fpm.enterprise_no
               and fpd.warehouse_no = fpm.warehouse_no
               and fpd.owner_no = fpm.owner_no
               and fpd.plan_no = fpm.plan_no
               and fpm.enterprise_no = strEnterpriseNo
               and fpm.warehouse_no = strWareHouseNo
               and fpm.owner_no = strOwnerNo
               and fpm.REPORT_UP_SERIAL <= strReportUpSerial);

    delete fcdata_pd_m fpm
     where fpm.enterprise_no = strEnterpriseNo
       and fpm.warehouse_no = strWareHouseNo
       and fpm.owner_no = strOwnerNo
       and fpm.REPORT_UP_SERIAL <= strReportUpSerial;

    strOutMsg := 'Y|';
   exception
     when others then
       strOutMsg := 'N|P_FC_DiffAndPDHTYByInterface' || SQLERRM ||
             substr(dbms_utility.format_error_backtrace, 1, 256);
       return;

  end P_FC_DiffAndPDHTYByInterface;

end PKOBJ_FCDATA;

/

