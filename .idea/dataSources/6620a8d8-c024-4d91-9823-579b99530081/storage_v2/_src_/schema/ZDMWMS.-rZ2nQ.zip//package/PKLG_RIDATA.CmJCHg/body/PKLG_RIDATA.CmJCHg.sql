create package body        PKLG_RIDATA is
 /************************************************************************************************
   功能：集单
   日期：2015-07-03
   chensr
  *************************************************************************************************/
    procedure p_single_set(strEnterpriseNo   in ridata_untread_m.enterprise_no%type,
                            strWareHouseNo     in ridata_untread_m.warehouse_no%type,
                            strUntreadNo       in ridata_untread_m.untread_no%type,
                            strsUntreadNo      in ridata_untread_mm.s_untread_no%type, --原汇总单号(第一次默认为N)
                            strOutUntreadNo    out ridata_untread_mm.s_untread_no%type, --返回的汇总单号
                            strResult out varchar2)is
   v_strQType               ridata_untread_mm.quality%type;--品质类型
   v_strClassType           ridata_untread_mm.Class_Type%type;--是否直通
   v_strCust                ridata_untread_mm.Cust_No%type;--返配客户
   v_strOwner               ridata_untread_mm.owner_no%type;
   v_strPoNo                ridata_untread_mm.s_po_no%type;
   v_strRgstName            ridata_untread_mm.rgst_name%type;
   v_strAutoCollectOrder    wms_defbase.sdefine%type;---0:不自动集单；1：自动集单
   v_nAutoCollectOrder      wms_defbase.ndefine%type;
   begin
   strResult := 'N|[p_SaveUntreadm]';

    select m.quality,m.class_type,m.cust_no,m.owner_no,m.po_no,m.rgst_name
     into v_strQType,v_strClassType,v_strCust,v_strOwner,v_strPoNo,v_strRgstName
     from ridata_untread_m m where m.enterprise_no=strEnterpriseNo
     and m.warehouse_no=strWareHouseNo and m.untread_no=strUntreadNo;


    PKLG_WMS_BASE.p_GetBasePara(strEnterpriseNo,
                                strWareHouseNo ,
                                v_strOwner  ,
                                'RIAutoCollectOrder'  ,
                                'RI' ,
                                'CREATE'  ,
                                v_strAutoCollectOrder  ,
                                v_nAutoCollectOrder  ,
                                strResult );
    if (substr(strResult, 1, 1) = 'N') then
         return;
    end if;

    if v_strAutoCollectOrder='1' then
           strOutUntreadNo:=v_strPoNo;
    else
       --获取返配汇总单号
       PKLG_WMS_BASE.p_getsheetno(strEnterPriseNo,strWareHouseNo,CONST_DOCUMENTTYPE.RIDATAVM,strOutUntreadNo,strResult);
       if (substr(strResult, 1, 1) = 'N') then
          return;
       end if;
    end if;

       --写返配汇总mm表
       PKOBJ_RIDATA.p_ridata_saveUntreadmm(strEnterpriseNo,strWareHouseNo,strUntreadNo,
        v_strQType,v_strClassType,v_strCust,strOutUntreadNo,
        v_strOwner,v_strPoNo,v_strRgstName,strResult);
        if substr(strResult, 1, 1) = 'N' then
          return;
        end if;



    --写返配汇总sm表
    pkobj_ridata.p_ridata_saveUntreadsm(strEnterpriseNo,strWareHouseNo,strUntreadNo,
                           strOutUntreadNo,strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;

    strResult := 'Y';
   end p_single_set;


   /**********************************************************************************
   hekl
   2015-04-07
   功能说明：返配手建单保存汇总单信息
   **********************************************************************************/
   procedure p_SaveUntread_m(strEnterpriseNo   in ridata_untread_m.enterprise_no%type,
                            strWareHouseNo     in ridata_untread_m.warehouse_no%type,
                            strUntreadNo       in ridata_untread_m.untread_no%type,
                            strsUntreadNo      in ridata_untread_mm.s_untread_no%type, --原汇总单号(第一次默认为N)
                            strOutUntreadNo    out ridata_untread_mm.s_untread_no%type, --返回的汇总单号
                            strResult out varchar2)is
   v_strQType     ridata_untread_mm.s_untread_no%type;--品质类型
   v_strClassType  ridata_untread_mm.Class_Type%type;--是否直通
   v_strCust       ridata_untread_mm.Cust_No%type;--返配客户
   v_strOwner      ridata_untread_mm.owner_no%type;
   v_strPoNo       ridata_untread_mm.s_po_no%type;
   v_strRgstName      ridata_untread_mm.rgst_name%type;
   begin
   strResult := 'N|[p_SaveUntreadm]';

    select m.quality,m.class_type,m.cust_no,m.owner_no,m.po_no,m.rgst_name
     into v_strQType,v_strClassType,v_strCust,v_strOwner,v_strPoNo,v_strRgstName
     from ridata_untread_m m where m.enterprise_no=strEnterpriseNo
     and m.warehouse_no=strWareHouseNo and m.untread_no=strUntreadNo;

    if strsUntreadNo = 'N' then

       --获取返配汇总单号
       PKLG_WMS_BASE.p_getsheetno(strEnterPriseNo,strWareHouseNo,CONST_DOCUMENTTYPE.RIDATAVM,strOutUntreadNo,strResult);
       if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

       --写返配汇总mm表
       PKOBJ_RIDATA.p_ridata_saveUntreadmm(strEnterpriseNo,strWareHouseNo,strUntreadNo,
        v_strQType,v_strClassType,v_strCust,strOutUntreadNo,
        v_strOwner,v_strPoNo,v_strRgstName,strResult);
        if substr(strResult, 1, 1) = 'N' then
          return;
        end if;
    else
        strOutUntreadNo := strsUntreadNo;
    end if;


    --写返配汇总sm表
    pkobj_ridata.p_ridata_saveUntreadsm(strEnterpriseNo,strWareHouseNo,strUntreadNo,
                           strOutUntreadNo,strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;

    strResult := 'Y';
   end p_SaveUntread_m;
    /**********************************************************************************************************
   功能：校验能否超量验收
***********************************************************************************************************/
  procedure P_CheckExists(strEnterpriseNo           in    ridata_check_m.enterprise_no%type,--企业
                          strWareHouseNo            in    ridata_check_m.warehouse_no%type,--仓库编码
                          strOwnerNo                in    ridata_untread_m.Owner_No%type,--进货汇总单号
                          strUntreadType            in    ridata_untread_m.untread_type%type,
                          strClassType              in    ridata_untread_mm.class_type%type,
                          strQualityFlag            in    ridata_untread_mm.quality%type,
                          strsUntreadNo             in    ridata_untread_mm.s_untread_no%type,--进货汇总单号
                          strArticleNo              in    ridata_check_d.article_no%type,--商品编码
                          nPackingQty               in    ridata_check_d.packing_qty%type,--商品条码
                          nCheckQty                 in    ridata_check_d.check_qty%type,--验收数量
                          strResult                 OUT   varchar2)is

  v_nmaxQty                    ridata_untread_d.check_qty%type;
  v_ncheckQty                    ridata_untread_d.check_qty%type;
  v_nTmpCheckQty                 ridata_check_pal_tmp.check_qty%type;
  v_strOverQtyFlag               wms_riordertype.over_qty_flag%type;--0:不超；1：超量；2：超品
  begin
    strResult := 'N|[P_CheckExists]';

    --获取单据类型配置的是否能超量标识 huangb 20160804
    PKLG_WMS_Public.p_GetRIdataOrder
    (strEnterPriseNo,strWareHouseNo,strOwnerNo,strUntreadType,strClassType,strQualityFlag,
     'over_qty_flag',v_strOverQtyFlag,strResult);
    if substr(strResult,1,1)='N' then
      return;
    end if;

    /* 改为通过公用方法获取 huangb 20160804
    --根据货主仓别级别对应的单据类型获取是否需要混单验收的标识
    begin
        select over_qty_flag into v_strOverQtyFlag
         from wms_warehouse_riordertype where enterprise_no=strEnterPriseNo
               and warehouse_no=strWareHouseNo and owner_no=strOwnerNo and untread_type=strUntreadType
               and class_type=strClassType and quality_flag=strQualityFlag;
    exception when no_data_found then
        --获取货主级别对应的标识
        begin
            select over_qty_flag into v_strOverQtyFlag
            from wms_owner_riordertype where enterprise_no=strEnterPriseNo
                   and owner_no=strOwnerNo and untread_type=strUntreadType
                   and class_type=strClassType and quality_flag=strQualityFlag;
        exception when no_data_found then
            --获取系统级别对应的标识
            begin
                select over_qty_flag into v_strOverQtyFlag
                from wms_riordertype where enterprise_no=strEnterPriseNo
                       and untread_type=strUntreadType
                       and class_type=strClassType and quality_flag=strQualityFlag;
            exception when no_data_found then
                strResult:='N|[找不到对应的单据配置]';
                return;
            end;
         end;
    end;*/

    if v_strOverQtyFlag='0' then

        --检验是否超量
        begin
          select rud.untread_qty,rud.check_qty
          into v_nmaxQty,v_ncheckQty
          from ridata_untread_d rud,ridata_untread_sm rus
          where
            rud.enterprise_no=rus.enterprise_no and rud.warehouse_no=rus.warehouse_no
            and rud.untread_no=rus.untread_no and rus.enterprise_no=strEnterpriseNo
            and rus.warehouse_no=strWareHouseNo and rus.s_untread_no=strsUntreadNo
            and rus.owner_no=strOwnerNo and rud.article_no=strArticleNo
						--因为允许修改包装，所以这里需要去掉包装条件 update by sl 20160518
            ;--and rud.packing_qty=nPackingQty;
        exception
          when no_data_found then
            strResult := 'N|[E20933]';--商品不存在
            return;
        end;


        select nvl(sum(t.check_qty),0)
         into v_nTmpCheckQty
        from ridata_check_pal_tmp t
        where t.enterprise_no=strEnterpriseNo
        and t.warehouse_no=strWareHouseNo
        and t.s_untread_no=strsUntreadNo
        and t.article_no=strArticleNo
        --因为允许修改包装，所以这里需要去掉包装条件 update by sl  20160518
				;--and t.packing_qty=nPackingQty;


        if v_nmaxQty-v_ncheckQty-v_nTmpCheckQty-nCheckQty <0 then
        --判断是否能超量
             strResult := 'N|[E20936]';--不能超量验收
             return;
        end if;
    end if;

    strResult:='Y|[]';
  end P_CheckExists;

 /**********************************************************************************
   luozhiling
   2015-7-14
    功能说明：天天惠校验单号此商品是否可扫描验收
   **********************************************************************************/
   function f_CheckDevice(strEnterPriseNo  in ridata_check_m.enterprise_no%type,
             strWareHouseNo               in	ridata_check_m.warehouse_no%type,
             strsUntreadNo                in  ridata_untread_sm.s_untread_no%type,
             strStyle                     in  bdef_defarticle.rsv_attr2%type,--款号,若取到空，传N
             strSupplierNo                in  ridata_check_pal_tmp.supplier_no%type,
             strDeviceNo                  in  ridata_check_pal_tmp.device_no%type,
             strLabelId                   in  ridata_check_pal_tmp.label_id%type)--扫描墙号，若无，传N
              return boolean is
              v_Result      boolean := false;
             v_iCount                     integer;
             v_strWaveNo                  ridata_untread_mm.wave_no%type;
   begin

        --获取单据的波次号
        select nvl(wave_no,'N') into v_strWaveNo from ridata_untread_mm where enterprise_no=strEnterPriseNo and  warehouse_no=strWareHouseNo
             and s_untread_no=strsUntreadNo and status not in('13','16');

         select count(*) into v_iCount from ridata_box rb where rb.enterprise_no=strEnterPriseNo and rb.warehouse_no=strWareHouseNo
                and rb.supplier_no=strSupplierNo and rb.device_no=strDeviceNo
                and rb.style=strStyle and rb.status in ('1','2') and label_id=strLabelId;

         if v_iCount=0 then
            return v_Result;
         end if;

          v_Result := true;
          return v_Result;
  exception
    when others then
      return false;
  end;

 /* 验收存储过程(前台和RF通用)
    支持前台验收 huangb 20160816
 */
 procedure P_RF_SaveCheck(strEnterPriseNo   in ridata_check_m.enterprise_no%type,
                          strWareHouseNo    in ridata_check_m.warehouse_no%type,
                          strOwnerNo        in ridata_check_m.owner_no%type,
                          strsUntreadNo     in ridata_untread_sm.s_untread_no%type,
                          strUntreadType    in ridata_untread_sm.untread_type%type,
                          strArticleNo      in ridata_check_d.article_no%type,
                          strBarcode        in ridata_check_d.barcode%type,
                          nPackingQty       in ridata_check_d.packing_qty%type,
                          nCheckQty         in ridata_check_d.check_qty%type,
                          strPrinterGroupNo in ridata_check_m.printer_group_no%type,
                          strDockNo         in ridata_check_m.dock_no%type,
                          strWorkerNo       in ridata_check_m.rgst_name%type, --验收人
                          strCheckTools     in ridata_check_m.check_tools%type,
                          nIsAdd            in integer, --是否累加 0:覆盖 1:累加
                          strQuality        in ridata_check_d.quality%type, --品质
                          dtProduceDate     in ridata_check_d.produce_date%type,
                          dtExpireDate      in Ridata_check_d.expire_date%type,
                          strLotNo          in ridata_check_d.lot_no%type, --批次号
                          strRSV_BATCH1     in ridata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                          strRSV_BATCH2     in ridata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                          strRSV_BATCH3     in ridata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                          strRSV_BATCH4     in ridata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                          strRSV_BATCH5     in ridata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                          strRSV_BATCH6     in ridata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                          strRSV_BATCH7     in ridata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                          strRSV_BATCH8     in ridata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                          strLabelNo        in stock_label_m.label_no%type,
                          strSubLabelNo     in stock_label_m.label_no%type,
                          strSupplierNo     in ridata_untread_d.supplier_no%type,
                          strFixPalFlag     in ridata_check_pal.Fixpal_Flag%type, --1：固定板号；2：流水板号;
                          strBusinessType   in ridata_check_pal.Business_Type%type, --业务类型：0-普通验收；1-直通验收；2-大批量验收；3-客户别；5-越库；6-B/C品
                          strDeviceNo       in ridata_check_pal_tmp.device_no%type, --分播墙号，若无，系统默认N
                          strCellNo         in ridata_check_pal_tmp.cell_no%type,
                          strQualityFlag    in ridata_check_pal_tmp.quality_flag%type, --品质类型0滞销品，1过季品，A质量问题，B次品
                          strBatchNo        in ridata_check_pal_tmp.batch_no%type,
                          strClassType      in ridata_untread_m.class_type%type,
                          strsCheckNo       out ridata_check_m.s_check_no%type,
                          strOutLabelNo     out ridata_check_pal_tmp.label_no%type,
                          strResult         out varchar2) is
    v_strLabelNoTmp     stock_label_m.label_no%type;
    v_strContainNo stock_label_m.container_no%type;
    v_strSessionID varchar2(10);
 begin
   strResult := 'N|[P_RF_SaveCheck]';

   --混合板验收先取板号
   --if strFixPalFlag = '3' and strLabelNo = 'N' then
   if strLabelNo = 'N' then
     begin
       select distinct t.label_no into strOutLabelNo from ridata_check_pal_tmp t
        where t.enterprise_no = strEnterPriseNo and t.warehouse_no = strWareHouseNo
          and t.owner_no = strOwnerNo and t.s_untread_no = strsUntreadNo and t.untread_type =  strUntreadType
          and t.class_type = strClassType and t.quality_flag = strQualityFlag;
     exception
       when no_data_found then
         pklg_wms_base.p_get_ContainerNoBase(strEnterpriseNo,
                                              strWareHouseNo,
                                              'P',
                                              strWorkerNo,
                                              'D',
                                              1,
                                              2, --标签用途
                                              '31', --容器材质(板)
                                              v_strLabelNoTmp,
                                              v_strContainNo,
                                              v_strSessionID,
                                              strResult);
          if substr(strResult,1,1)='N' then
            return;
          end if;
        strOutLabelNo := v_strLabelNoTmp;
     end;
   else
     strOutLabelNo := strLabelNo;
     strOutLabelNo := strSubLabelNo;
   end if;

   --调用验收保存方法
   P_SaveCheck(strEnterPriseNo,strWareHouseNo,strOwnerNo,strsUntreadNo,strArticleNo,strBarcode,
               nPackingQty,nCheckQty,strPrinterGroupNo,strDockNo,strWorkerNo,strCheckTools,
               nIsAdd,strQuality,dtProduceDate,dtExpireDate,strLotNo,strRSV_BATCH1,strRSV_BATCH2,
               strRSV_BATCH3,strRSV_BATCH4,strRSV_BATCH5,strRSV_BATCH6,strRSV_BATCH7,strRSV_BATCH8,
               'N',strOutLabelNo,strOutLabelNo,strSupplierNo,strFixPalFlag,strBusinessType,
               strDeviceNo,strCellNo,strQualityFlag,strBatchNo,strClassType,strsCheckNo,
               strResult);
   if (substr(strResult, 1, 1) = 'N') then
     return;
   end if;

   strResult := 'Y|';
 end P_RF_SaveCheck;
 /**********************************************************************************
  hekangli
  2015-03-09
  功能说明：返配验收数据保存
  **********************************************************************************/
 procedure P_SaveCheck(strEnterPriseNo   in ridata_check_m.enterprise_no%type,
                         strWareHouseNo    in ridata_check_m.warehouse_no%type,
                         strOwnerNo        in ridata_check_m.owner_no%type,
                         strsUntreadNo     in ridata_untread_sm.s_untread_no%type,
                         strArticleNo      in ridata_check_d.article_no%type,
                         strBarcode        in ridata_check_d.barcode%type,
                         nPackingQty       in ridata_check_d.packing_qty%type,
                         nCheckQty         in ridata_check_d.check_qty%type,
                         strPrinterGroupNo in ridata_check_m.printer_group_no%type,
                         strDockNo         in ridata_check_m.dock_no%type,
                         strWorkerNo       in ridata_check_m.rgst_name%type, --验收人
                         strCheckTools     in ridata_check_m.check_tools%type,
                         nIsAdd            in integer, --是否累加 0:覆盖 1:累加
                         strQuality        in ridata_check_d.quality%type, --品质
                         dtProduceDate     in ridata_check_d.produce_date%type,
                         dtExpireDate      in Ridata_check_d.expire_date%type,
                         strLotNo          in ridata_check_d.lot_no%type, --批次号
                         strRSV_BATCH1     in ridata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                         strRSV_BATCH2     in ridata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                         strRSV_BATCH3     in ridata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                         strRSV_BATCH4     in ridata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                         strRSV_BATCH5     in ridata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                         strRSV_BATCH6     in ridata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                         strRSV_BATCH7     in ridata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                         strRSV_BATCH8     in ridata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                         strLabeId         in ridata_check_pal_tmp.label_id%type, --
                         strLabelNo        in stock_label_m.label_no%type,
                         strSubLabelNo     in stock_label_m.label_no%type,
                         strSupplierNo     in ridata_untread_d.supplier_no%type,
                         strFixPalFlag     in ridata_check_pal.Fixpal_Flag%type, --1：固定板号；2：流水板号;3:天天惠模式
                         strBusinessType   in ridata_check_pal.Fixpal_Flag%type, --业务类型：0-普通验收；1-直通验收；2-大批量验收；3-客户别；5-越库；6-B/C品
                         strDeviceNo       in ridata_check_pal_tmp.device_no%type, --分播墙号，若无，系统默认N
                         strCellNo         in ridata_check_pal_tmp.cell_no%type,
                         strQualityFlag    in ridata_check_pal_tmp.quality_flag%type, --品质类型0滞销品，1过季品，A质量问题，B次品
                         strBatchNo        in ridata_check_pal_tmp.batch_no%type,
                         strClassType      in ridata_untread_m.class_type%type,
                         strsCheckNo       out ridata_check_m.s_check_no%type,
                         strResult         out varchar2) is
   v_iCount      integer;
   v_strsCheckNo ridata_check_m.s_check_no%type;
   v_stockType   ridata_untread_m.stock_type%type;
   v_stockValue  ridata_untread_m.stock_value%type;
   v_strWaveNo   ridata_box.wave_no%type := 'N';
   v_strUntreadType  ridata_untread_m.untread_type%type;
   v_strMixOrderCheck wms_riordertype.mix_ordercheck%type;
   v_strDirectCellFlag  wms_riordertype.direct_cell_flag%type;
   v_strDirectCellNo    wms_riordertype.DIRECT_CELL_NO%type;
 begin
   strResult := 'N|[P_SaveCheck]';

   --检查返配汇总单是否已验收确认；
   select count(*)
     into v_iCount
     from ridata_untread_mm
    where enterprise_no = strEnterPriseNo
      and warehouse_no = strWareHouseNo
      and owner_no = strOwnerNo
      and s_untread_no = strsuntreadNo
      and status not in ('16', '13');
   if v_iCount = 0 then
     strResult := 'N|[E24217]';
     return;
   end if;

   begin
        select untread_type into v_strUntreadType from ridata_untread_sm
               where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo
               and s_untread_no=strsUntreadNo and rownum=1;
   exception when no_data_found then
        strResult:='N|[找不到对应的返配汇总单]';
        return;
   end;

   P_CheckExists(strEnterpriseNo,strWareHouseNo,strOwnerNo,v_strUntreadType,strClassType,strQualityFlag,
       strsUntreadNo,strArticleNo,nPackingQty,nCheckQty,strResult);
    if substr(strResult,1,1)='N' then
       return;
    end if;


      --根据货主仓别级别对应的单据类型获取是否需要混单验收的标识
      begin
          select mix_ordercheck,direct_cell_no,direct_cell_flag
                 into v_strMixOrderCheck,v_strDirectCellNo,v_strDirectCellFlag
           from wms_warehouse_riordertype where enterprise_no=strEnterPriseNo
                 and warehouse_no=strWareHouseNo and owner_no=strOwnerNo and untread_type=v_strUntreadType
                 and class_type=strClassType and quality_flag=strQualityFlag;
      exception when no_data_found then
          --获取货主级别对应的标识
          begin
              select mix_ordercheck,direct_cell_no,direct_cell_flag
              into v_strMixOrderCheck,v_strDirectCellNo,v_strDirectCellFlag
              from wms_owner_riordertype where enterprise_no=strEnterPriseNo
                     and owner_no=strOwnerNo and untread_type=v_strUntreadType
                     and class_type=strClassType and quality_flag=strQualityFlag;
          exception when no_data_found then
              --获取系统级别对应的标识
              begin
                  select mix_ordercheck,direct_cell_no,direct_cell_flag
                  into v_strMixOrderCheck,v_strDirectCellNo,v_strDirectCellFlag
                  from wms_riordertype where enterprise_no=strEnterPriseNo
                         and untread_type=v_strUntreadType
                         and class_type=strClassType and quality_flag=strQualityFlag;
              exception when no_data_found then
                  strResult:='N|[找不到对应的单据配置]';
                  return;
              end;
           end;
      end;
   if strCellNo<>'N' then
      v_strDirectCellNo:=strCellNo;
   else
      if (v_strDirectCellNo is null or v_strDirectCellNo='')and v_strDirectCellFlag='1'  then
          strResult:='N|[此单据类型没有配置指定的储位]';
          return;
      end if;

      if v_strDirectCellFlag='0' then
         v_strDirectCellNo:='N';
      end if;
   end if;


   if v_strMixOrderCheck='0' then
         --判断是否一个标签号（物流箱）只有一张返配汇总单号，如果有多张单返配汇总单则拦截
         select count(*) into v_iCount from ridata_check_pal_tmp rcpt
          where rcpt.enterprise_no = strEnterPriseNo
            and rcpt.warehouse_no = strWareHouseNo
            and rcpt.device_no=strDeviceNo
            and rcpt.label_id=strLabeId
            and rcpt.batch_no=strBatchNo
            and rcpt.label_no = strLabelNo
            and rcpt.s_untread_no<>strsUntreadNo;
        if v_iCount>0 then
           strResult := 'N|[P_SaveCheck]';
           return;
        end if;
   end if;

   --获取单据试算信息
   begin
     select nvl(wave_no, 'N')
       into v_strWaveNo
       from ridata_untread_mm
      where enterprise_no = strEnterPriseNo
        and warehouse_no = strWareHouseNo
        and owner_no = strOwnerNo
        and s_untread_no = strsuntreadNo;
   exception
     when no_data_found then
       strResult := 'N|[E24217]';
       return;
   end;

   --锁定进货汇总单头；

   update ridata_untread_mm
      set status = '12'
    where enterprise_no = strEnterPriseNo
      and warehouse_no = strWareHouseNo
      and owner_no = strOwnerNo
      and s_untread_no = strsuntreadNo;

   if sql%notfound then
     strResult := 'N|[E24211]';
     return;
   end if;

   --取汇总验收单号；
   begin
     select distinct s_check_no
       into v_strsCheckNo
       from ridata_check_m
      where enterprise_no = strEnterPriseNo
        and warehouse_no = strWareHouseNo
        and owner_no = strOwnerNo
        and untread_no in
            (select untread_no
               from ridata_untread_sm
              where s_untread_no = strsuntreadNo
                and warehouse_no = strWareHouseNo)
        and status <> '13';
   exception
     when no_data_found then
       --若取不到汇总验收单号，则写验收头档；
       PKOBJ_RIDATA.p_InsertImCheckMaster(strEnterPriseNo,
                                          strWareHouseNo,
                                          strOwnerNo,
                                          strSuntreadNo,
                                          strDockNo,
                                          strWorkerNo,
                                          strPrinterGroupNo,
                                          strCheckTools,
                                          v_strsCheckNo,
                                          strResult);
       if (substr(strResult, 1, 1) = 'N') then
         return;
       end if;
   end;

   strsCheckNo := v_strsCheckNo;

   --获取单据等信息
   begin
     select stock_type, stock_value
       into v_stockType, v_StockValue
       from ridata_untread_mm
      where enterprise_no = strEnterPriseNo
        and warehouse_no = strWareHouseNo
        and owner_no = strOwnerNo
        and s_untread_no = strsuntreadNo;
   exception
     when no_data_found then
       strResult := 'N|[E24211]';
       return;
   end;

   --写临时板表；
   PKOBJ_RIDATA.p_InsertPalTmp(strEnterPriseNo,
                               strWareHouseNo,
                               strOwnerNo,
                               strsuntreadNo,
                               v_strsCheckNo,
                               strArticleNo,
                               strBarcode,
                               strQuality,
                               dtProduceDate,
                               dtExpireDate,
                               strLotNo,
                               strRSV_BATCH1,
                               strRSV_BATCH2,
                               strRSV_BATCH3,
                               strRSV_BATCH4,
                               strRSV_BATCH5,
                               strRSV_BATCH6,
                               strRSV_BATCH7,
                               strRSV_BATCH8,
                               nPackingQty,
                               nCheckQty,
                               strLabelNo,
                               strLabeId,
                               strBusinessType,
                               strFixPalFlag,
                               strPrinterGroupNo,
                               strDockNo,
                               v_stockType,
                               v_stockValue,
                               strSubLabelNo,
                               strWorkerNo,
                               'UM',
                               strSupplierNo,
                               strCheckTools,
                               v_strWaveNo,
                               strBatchNo,
                               v_strDirectCellNo,
                               strDeviceNo,
                               strQualityFlag,strClassType,
                               nIsAdd,
                               strResult);
   if (substr(strResult, 1, 1) = 'N') then
     return;
   end if;

   --写临时板表日志；
   PKOBJ_RIDATA.p_InsertPalTmp_log(strEnterPriseNo,
                                   strWareHouseNo,
                                   strOwnerNo,
                                   strsuntreadNo,
                                   v_strsCheckNo,
                                   strArticleNo,
                                   strBarcode,
                                   strQuality,
                                   dtProduceDate,
                                   dtExpireDate,
                                   strLotNo,
                                   strRSV_BATCH1,
                                   strRSV_BATCH2,
                                   strRSV_BATCH3,
                                   strRSV_BATCH4,
                                   strRSV_BATCH5,
                                   strRSV_BATCH6,
                                   strRSV_BATCH7,
                                   strRSV_BATCH8,
                                   nPackingQty,
                                   nCheckQty,
                                   strLabeId,
                                   strLabelNo,
                                   strBusinessType,
                                   strFixPalFlag,
                                   strPrinterGroupNo,
                                   strDockNo,
                                   v_stockType,
                                   v_stockValue,
                                   strSubLabelNo,
                                   strWorkerNo,
                                   'UM',
                                   strSupplierNo,
                                   strCheckTools,
                                   v_strWaveNo,
                                   strBatchNo,
                                   v_strDirectCellNo,
                                   strDeviceNo,
                                   strQualityFlag,
                                   nIsAdd,
                                   strResult);
   if (substr(strResult, 1, 1) = 'N') then
     return;
   end if;

   strResult := 'Y|';
 end P_SaveCheck;
/*********************************************************************************************************************
 luozhiling
 2015.7.15
 功能说明：1、校验商品对应的供应商是否有设置资源，有继续，若无，系统拦截
           2、返配验收保存
*********************************************************************************************************************/
procedure P_SaveCheckTTH(strEnterPriseNo  in ridata_check_m.enterprise_no%type,
             strWareHouseNo               in	ridata_check_m.warehouse_no%type,
             strOwnerNo                   in  ridata_check_m.owner_no%type,
             strUntreadType               in  ridata_untread_m.untread_type%type,
             strsUntreadNo                in  ridata_untread_sm.s_untread_no%type,
             strArticleNo                 in	ridata_check_d.article_no%type,
             strBarcode                   in	ridata_check_d.barcode%type,
             nPackingQty                  in	ridata_check_d.packing_qty%type,
             nCheckQty                    in	ridata_check_d.check_qty%type,
             strPrinterGroupNo            in	ridata_check_m.printer_group_no%type,
             strDockNo                    in	ridata_check_m.dock_no%type,
             strWorkerNo		              in	ridata_check_m.rgst_name%type,--验收人
             strCheckTools	              in	ridata_check_m.check_tools%type,
             nIsAdd		                    in	integer,--是否累加 0:覆盖 1:累加
             strQuality                   in  ridata_check_d.quality%type,--品质
             dtProduceDate                in  ridata_check_d.produce_date%type,
             dtExpireDate                 in  Ridata_check_d.expire_date%type,
             strLotNo                     in  ridata_check_d.lot_no%type,--批次号
             strRSV_BATCH1                in  ridata_check_pal_tmp.rsv_batch1%type, --预留批属性1
             strRSV_BATCH2                in  ridata_check_pal_tmp.rsv_batch2%type, --预留批属性2
             strRSV_BATCH3                in  ridata_check_pal_tmp.rsv_batch3%type, --预留批属性3
             strRSV_BATCH4                in  ridata_check_pal_tmp.rsv_batch4%type, --预留批属性4
             strRSV_BATCH5                in  ridata_check_pal_tmp.rsv_batch5%type, --预留批属性5
             strRSV_BATCH6                in  ridata_check_pal_tmp.rsv_batch6%type, --预留批属性6
             strRSV_BATCH7                in  ridata_check_pal_tmp.rsv_batch7%type, --预留批属性7
             strRSV_BATCH8                in  ridata_check_pal_tmp.rsv_batch8%type, --预留批属性8
             strLabelNo		                in	stock_label_m.label_no%type,
             strSubLabelNo	              in	stock_label_m.label_no%type,
             strSupplierNo                in  ridata_untread_d.supplier_no%type,
             strFixPalFlag	              in	ridata_check_pal.Fixpal_Flag%type,--1：固定板号；2：流水板号;3:天天惠模式
             strBusinessType              in	ridata_check_pal.Fixpal_Flag%type, --业务类型：0-普通验收；1-直通验收；2-大批量验收；3-客户别；5-越库；6-B/C品
             strDeviceNo                  in  ridata_check_pal_tmp.device_no%type,--分播墙号，若无，系统默认N
             strLabelId                    in  ridata_check_pal_tmp.label_id%type,--扫描墙号,若无，系统默认N
             strStyle                     in  ridata_box.style%type,--款号，若无，记为N
             strCellNo                    in  cdef_defcell.cell_no%type,--指定储位，若无指定储位，传N
             strClassType                 in  ridata_untread_mm.class_type%type,--0:存储,1:清场
             strQualityFlag               in  ridata_check_pal_tmp.quality_flag%type,--品质类型0滞销品，1过季品2, 清场A质量问题，B次品
             strsCheckNo                  out  ridata_check_m.s_check_no%type,
             strResult                    out varchar2)is
   v_strCellNo      cdef_defcell.cell_no%type:='N';
   v_strBatchNo     stock_label_m.batch_no%type:='N';
   v_strWaveNo      ridata_box.wave_no%type:='N';
   v_strLabelNo     ridata_check_pal_tmp.label_no%type;
   strLabelNoTmp    ridata_check_pal_tmp .label_no%type;
   strContainNo     stock_label_m.container_no%type;
   strSessionID  varchar2(10);
   v_strSupplierNo  bdef_defsupplier.supplier_no%type:='N';
   v_strStyle       bdef_defarticle.rsv_attr2%type:='N';
   v_strDeviceCompute  wms_riordertype.device_compute%type;
   v_strDirectCellFlag  wms_riordertype.direct_cell_flag%type;
   v_strAdvanceLocate   wms_riordertype.advance_locate%type;
   v_strMixOrderCheck   wms_riordertype.mix_ordercheck%type;
 begin
      strResult:='N|[P_SaveCheckTTH]';

      if strQualityFlag='A' or strClassType='1' then
         v_strSupplierNo:=strSupplierNo;
      end if;

      if strClassType='1' then
         v_strStyle:=strStyle;
      end if;
      --校验商品是否可扫描

      --根据货主仓别级别对应的单据类型获取是否需要混单验收的标识
      begin
          select DEVICE_COMPUTE,direct_cell_flag,ADVANCE_LOCATE,MIX_ORDERCHECK
                 into v_strDeviceCompute,v_strDirectCellFlag,v_strAdvanceLocate,v_strMixOrderCheck
                 from wms_warehouse_riordertype where enterprise_no=strEnterPriseNo
                 and warehouse_no=strWareHouseNo and owner_no=strOwnerNo and untread_type=strUntreadType
                 and class_type=strClassType and quality_flag=strQualityFlag;
      exception when no_data_found then
          --获取货主级别对应的标识
          begin
              select DEVICE_COMPUTE,direct_cell_flag,ADVANCE_LOCATE,MIX_ORDERCHECK
                     into v_strDeviceCompute,v_strDirectCellFlag,v_strAdvanceLocate,v_strMixOrderCheck
                  from wms_owner_riordertype where enterprise_no=strEnterPriseNo
                     and owner_no=strOwnerNo and untread_type=strUntreadType
                     and class_type=strClassType and quality_flag=strQualityFlag;
          exception when no_data_found then
              --获取系统级别对应的标识
              begin
                  select DEVICE_COMPUTE,direct_cell_flag,ADVANCE_LOCATE,MIX_ORDERCHECK
                     into v_strDeviceCompute,v_strDirectCellFlag,v_strAdvanceLocate,v_strMixOrderCheck
                     from wms_riordertype where enterprise_no=strEnterPriseNo
                         and untread_type=strUntreadType
                         and class_type=strClassType and quality_flag=strQualityFlag;
              exception when no_data_found then
                  strResult:='N|[找不到对应的单据配置]';
                  return;
              end;
           end;
      end;

      if v_strDeviceCompute='1' then--需要进行资源试算类型的单据需要校验商品是否资源试算
          if f_CheckDevice(strEnterPriseNo,strWareHouseNo,strsUntreadNo,
             v_strStyle,v_strSupplierNo,strDeviceNo,strLabelId)=false then
             strResult:='N|[f_CheckDevice]';
             return;
          end if;
      end if;

      --获取波次号
      select nvl(wave_no,'N') into v_strWaveNo from ridata_untread_mm where enterprise_no=strEnterPriseNo
             and warehouse_no=strWareHouseNo and s_untread_no=strsUntreadNo;

      if v_strDirectCellFlag='1' then --指定储位，以传入的储位位置
         v_strCellNo:=strCellNo;
      else-- 不指定储位
          if v_strAdvanceLocate='0' then --如果不预定位，取预定位的储位
              begin
                select t.dps_cell_no,t.batch_no into v_strCellNo,v_strBatchNo
                    from ridata_box t where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo
                    and t.supplier_no=strSupplierNo and t.style=v_strStyle and t.wave_no=v_strWaveNo and t.device_no=strDeviceNo
                    and t.status in('1','2') and t.quality=strQualityFlag
                    and t.label_id=strLabelId;
              exception when no_data_found then
                   v_strCellNo:='N';
                   v_strBatchNo:='N';
              end;
          else
             select nvl(max(cell_no),'N') into v_strCellNo from ridata_untread_sm sm,ridata_untread_d d
             where sm.enterprise_no=d.enterprise_no and sm.warehouse_no=d.warehouse_no
             and sm.untread_no=d.untread_no and sm.enterprise_no=strEnterPriseNo
             and sm.warehouse_no=strWarehouseNo and sm.s_untread_no=strsUntreadNo
             and d.article_no=strArticleNo;
          end if;

      end if;



      --固定容器号的特殊处理，天天惠、
      if strFixPalFlag='3' then
         if v_strMixOrderCheck='0' then --按汇总单号获取标签号，若没有则新取号
          --获取临时表中strLabeId对应的标签号，若无，取号
              begin
                   select distinct label_no into v_strLabelNo from ridata_check_pal_tmp t
                       where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo
                       and t.wave_no=v_strWaveNo
                       and t.batch_no=v_strBatchNo and t.device_no=strDeviceNo
                       and t.s_untread_no=strsUntreadNo
                       and t.quality_flag=strQualityFlag and rownum=1;

              exception when no_data_found then
                   v_strLabelNo:='N';
              end;
         else--混单验收的，则按格子、菠次，扫描台等条件取标签号，
              begin
                   select distinct label_no into v_strLabelNo from ridata_check_pal_tmp t
                       where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo
                       and t.label_id=strLabelId and t.wave_no=v_strWaveNo
                       and t.batch_no=v_strBatchNo and t.device_no=strDeviceNo
                       and t.quality_flag=strQualityFlag and rownum=1;

              exception when no_data_found then
                   v_strLabelNo:='N';
              end;
        end if;

        if v_strLabelNo='N' then --取标签号

            --取B标签 只取一个标签
            pklg_wms_base.p_get_ContainerNoBase(strEnterPriseNo,strWareHouseNo,'B',strWorkerNo,'D',1,'2','11',
                                                strLabelNoTmp,strContainNo,strSessionID,strResult);
            if (substr(strResult, 1, 1) = 'N') then
              return;
            end if;

            v_strLabelNo:=strLabelNoTmp;
        end if;
      end if;

      P_SaveCheck(strEnterPriseNo,strWareHouseNo,strOwnerNo,strsUntreadNo,strArticleNo,
             strBarcode,nPackingQty,nCheckQty,strPrinterGroupNo,strDockNo,strWorkerNo,
             strCheckTools,nIsAdd,strQuality,dtProduceDate,dtExpireDate,strLotNo,
             strRSV_BATCH1,strRSV_BATCH2,strRSV_BATCH3,strRSV_BATCH4,strRSV_BATCH5,
             strRSV_BATCH6,strRSV_BATCH7,strRSV_BATCH8,strLabelId,v_strLabelNo,v_strLabelNo,
             strSupplierNo,strFixPalFlag,strBusinessType,strDeviceNo,v_strCellNo,strQualityFlag,
             v_strBatchNo,strClassType,strsCheckNo,strResult);

      if substr(strResult,1,1)='N' then
         return;
      end if;

      strResult:='Y|[成功]';

 end P_SaveCheckTTH;
/**************************************************************************************************
  luozhiling
  2013.12.19
  功能说明：返配验收、定位、上架发单,共速达,此过程会通过参数配置来判断是否需要自动上架
  转历史判断是否还有已验收未封板的数据 huangb 20160816
**************************************************************************************************/
procedure P_SaveClosePal_main(strEnterPriseNo in ridata_check_pal_tmp.enterprise_no%type,
                              strWareHouseNo  in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                              strOwnerNo      in ridata_check_pal_tmp.owner_no%type, --委托业主编码
                              strsUntreadNo   in ridata_untread_sm.s_untread_no%type, --进货汇总单号
                              strUntreadType  in ridata_untread_m.untread_type%type,
                              strClassType    in ridata_untread_m.class_type%type,
                              strQualityFlag  in ridata_untread_m.quality%type,
                              strsCheckNo     in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                              strLabelNo      in ridata_check_pal_tmp.label_no%type, --板号
                              strWorkerNo     in ridata_check_pal_tmp.rgst_name%type, --操作人
                              strDockNo       iN ridata_check_m.dock_no%type,
                              strPrintFlag    in job_printtask_m.back_flag%type,--打印标识，0：不打印，1：打印表单，2：打印标签
                              strResult       out varchar2) is
  v_strLocateNo  ridata_locate_direct.locate_no%type;
  v_strInstockNo ridata_locate_direct.locate_no%type;
  v_count        number := 0;--huangb 20160816

begin
  strResult := 'N|[P_SaveClosePal_main]';
  --封板
  P_CheckSplitPal(strEnterPriseNo,
                              strWareHouseNo,
                              strOwnerNo,
                              strsUntreadNo,
                              strsCheckNo,
                              strLabelNo,
                              strWorkerNo,
                              strResult);
  if substr(strResult, 1, 1) = 'N' then
    return;
  end if;
  --写定位指示
  p_sCheckLocate(strEnterPriseNo,
                             strWareHouseNo,
                             strsCheckNo,
                             strWorkerNo,
                             '1',
                             'N',
                             v_strLocateNo,
                             strResult);
  if substr(strResult, 1, 1) = 'N' then
    return;
  end if;
  --定位
  PKLG_RILOCATE.p_locate_main(strEnterPriseNo,
                              strWareHouseNo,
                              strOwnerNo,
                              v_strLocateNo,
                              strDockNo,
                              strWorkerNo,
                              strResult);
  if substr(strResult, 1, 1) = 'N' then
    return;
  end if;

  SendInstockTaskAndComfire(strEnterPriseNo,strWareHouseNo,strOwnerNo,strUntreadType,strClassType,
        strQualityFlag,strWorkerNo,v_strLocateNo,strDockNo,strPrintFlag,v_strInstockNo,strResult);
  if substr(strResult, 1, 1) = 'N' then
    return;
  end if;

  --转历史判断是否还有已验收未封板的数据 huangb 20160816
  select count(1) into v_count
    from ridata_check_pal_tmp t
   where t.enterprise_no = strEnterPriseNo and t.warehouse_no = strWareHouseNo
     and t.owner_no = strOwnerNo and t.s_untread_no = strsUntreadNo;

  if v_count <= 0 then
    --验收确认,根据配置判断
    P_comfireCheckTTH(strEnterPriseNo,strWareHouseNo,strsUntreadNo,strUntreadType,strClassType,strQualityFlag,
        strOwnerNo,strsCheckNo,strWorkerNo,strDockNo,'0',strResult);
    if substr(strResult,1,1)='N' then
      return;
    end if;
  end if;

  strResult := 'Y';

end P_SaveClosePal_main;
/******************************************************************************************************
 功能说明：天天惠封箱
           1、根据类型判断封箱
           A、质量问题、清场商品、滞销品按标签做封箱，
           B、过季品按标签做封箱，但需要指定储位，并系统自动上架回单
*******************************************************************************************************/
 procedure P_TTHClosePal_Main(strEnterPriseNo      in ridata_check_pal_tmp.enterprise_no%type,
                                 strWareHouseNo       in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                 strOwnerNo           in ridata_check_pal_tmp.owner_no%type, --委托业主编码
                                 strUntreadType       in ridata_untread_m.untread_type%type,
                                 strClassType         in ridata_untread_m.class_type%type,
                                 strQualityFlag       in ridata_untread_m.quality%type,
                                 strsUntreadNo        in ridata_untread_sm.s_untread_no%type, --进货汇总单号
                                 strsCheckNo          in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                 strLabelNo           in ridata_check_pal_tmp.label_no%type, --板号
                                 strWorkerNo          in ridata_check_pal_tmp.rgst_name%type, --操作人
                                 strDockNo            iN ridata_check_m.dock_no%type,
                                 strDestCellNo        in cdef_defcell.cell_no%type,--指定储位，若无，传N
                                 strPrintFlag         in job_printtask_m.back_flag%type,--打印标识，0：不打印，1：打印表单，2：打印标签
                                 strResult            out varchar2)is
 begin
      strResult:='N|[P_TTHClosePal_Main]';

      P_ClosePalDivide_main(strEnterPriseNo,strWareHouseNo,strOwnerNo,strsUntreadNo,strUntreadType,
         strClassType,strQualityFlag,strsCheckNo,
          strLabelNo,strWorkerNo,strDockNo,strDestCellNo,strPrintFlag,strResult);
      if substr(strResult,1,1)='N' then
         return;
      end if;


      strResult:='Y|[]';
 end P_TTHClosePal_Main;
/**************************************************************************************************
  luozhiling
  2014.6.20
  功能说明：1、固定板号封板，定位并上架
            2、适用于一箱对应多张返配汇总单的情况
            3、目前天天惠在用，用于对某箱号做封箱并上架上架定位、发单
**************************************************************************************************/
 procedure P_ClosePalDivide_main(strEnterPriseNo      in ridata_check_pal_tmp.enterprise_no%type,
                                 strWareHouseNo       in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                 strOwnerNo           in ridata_check_pal_tmp.owner_no%type, --委托业主编码
                                 strsUntreadNo        in ridata_untread_sm.s_untread_no%type, --进货汇总单号,传N
                                 strUntreadType       in ridata_untread_m.untread_type%type,
                                 strClassType         in ridata_untread_m.class_type%type,
                                 strQualityFlag       in ridata_untread_m.quality%type,
                                 strsCheckNo          in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号，传N
                                 strLabelNo           in ridata_check_pal_tmp.label_no%type, --板号
                                 strWorkerNo          in ridata_check_pal_tmp.rgst_name%type, --操作人
                                 strDockNo            iN ridata_check_m.dock_no%type,
                                 strDestCellNo        in cdef_defcell.cell_no%type,--指定储位，若无，传N
                                 strPrintFlag         in job_printtask_m.back_flag%type,--打印标识，0：不打印，1：打印表单，2：打印标签
                                 strResult            out varchar2) is
            v_strLocateNo               ridata_locate_direct.locate_no%type;
            v_strInstockNo              ridata_locate_direct.locate_no%type;
 begin
    strResult := 'N|[P_ClosePalDivide_main]';

    for p in (select distinct s_check_no,s_untread_no
                from ridata_check_pal_tmp
               where enterprise_no=strEnterPriseNo and WAREHOUSE_NO = strWareHouseNo
                 and owner_no = strOwnerNo
                 and label_no = strLabelNo order by s_check_no) loop
        P_CheckFixPal(strEnterPriseNo,strWareHouseNo,strOwnerNo,p.s_untread_no,p.s_check_no,strLabelNo,strWorkerNo,
                strResult);
        if substr(strResult,1,1)='N' then
           return;
        end if;
        --验收确认
        P_comfireCheckTTH(strEnterPriseNo,strWareHouseNo,p.s_untread_no,strUntreadType,strClassType,strQualityFlag,
            strOwnerNo,p.s_check_no,strWorkerNo,strDockNo,'0',strResult);
        if substr(strResult,1,1)='N' then
          return;
        end if;
    end loop;

    p_Labellocate(strEnterPriseNo,strWareHouseNo,strLabelNo,strWorkerNo,'1','1',strDestCellNo,v_strLocateNo,strResult);
    if substr(strResult,1,1)='N' then
       return;
    end if;


    PKLG_RILOCATE.p_locate_main(strEnterPriseNo,strWareHouseNo,strOwnerNo,v_strLocateNo,strDockNo,strWorkerNo,strResult);
    if substr(strResult,1,1)='N' then
      return;
    end if;


    SendInstockTaskAndComfire(strEnterPriseNo,strWareHouseNo,strOwnerNo,strUntreadType,strClassType,
          strQualityFlag,strWorkerNo,v_strLocateNo,strDockNo,strPrintFlag,v_strInstockNo,strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    strResult:='Y';

 end P_ClosePalDivide_main;

 /*************************************************************************************************
 创建人：luozhiling
 创建时间：2015.7.20
 功能说明：次品仓指定储位验收、上架
           1、按单做验收保存；
           2、一张单对应一张标签；
           3、按单写定位指示、上架定位
           4、上架发单；
           5、自动上架回单；
           6、对返配单对应的验收单做验收确认
 ***************************************************************************************************/
  procedure P_BadGoodSaveCheck_Instock(strEnterpriseNo       in ridata_check_pal_tmp.enterprise_no%type,
                                  strWareHouseNo                 in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                  strOwnerNo                     in ridata_check_pal_tmp.owner_no%type, --委托业主编码
                                  strsUntreadNo                  in ridata_check_m.s_untread_no%type, --进货汇总单号
                                  strsCheckNo                    in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                  strCellNo                      in ridata_locate_direct.cell_no%type, --板号
                                  strDockNo                      in ridata_check_m.dock_no%type,
                                  strWorkerNo                    in ridata_check_pal_tmp.rgst_name%type, --操作人
                              strResult                           out varchar2) is
     v_strLocateNo            ridata_locate_direct.locate_no%type;
     v_strInStockNo           ridata_instock_m.instock_no%type;
     v_strUntreadType         ridata_untread_m.untread_type%type;
     v_strClassType           ridata_untread_m.class_type%type;
     v_strQualityFlag         ridata_untread_m.quality%type;
 begin
      strResult:='N|[P_OutOfSeasonSaveCheck_Instock]';

      --验收单数据保存
      for p in (select distinct a.label_no
                  from ridata_check_pal_tmp a
                 where a.enterprise_no=strEnterPriseNo and a.s_check_no=strsCheckNo and a.WAREHOUSE_NO = strWareHouseNo
                   and a.owner_no = strOwnerNo and a.s_untread_no=strsUntreadNo order by a.label_no) loop

          pklg_ridata.P_CheckSplitPal(strEnterPriseNo,strWareHouseNo,strOwnerNo,strsUntreadNo,strsCheckNo,p.label_no,strWorkerNo,
                  strResult);
          if substr(strResult,1,1)='N' then
             return;
          end if;
      end loop;

      --获取单据类型
      begin
           select RUS.untread_type,t.quality,t.class_type
           into v_strUntreadType,v_strQualityFlag,v_strClassType
            from ridata_untread_sm rus,ridata_untread_mm t
           where rus.enterprise_no=t.enterprise_no and rus.warehouse_no=t.warehouse_no
           and rus.s_untread_no=t.s_untread_no and t.s_untread_no=strsUntreadNo
           and rownum=1;
      exception when no_data_found then
          strResult:='N|[找不到对应的汇总单]';
          return;
      end;

      p_sCheckLocate(strEnterPriseNo,strWareHouseNo,strsCheckNo,strWorkerNo,'1',strCellNo,
           v_strLocateNo,strResult);
      if substr(strResult,1,1)='N' then
         return;
      end if;


      PKLG_RILOCATE.p_locate_main(strEnterPriseNo,strWareHouseNo,strOwnerNo,v_strLocateNo,strDockNo,strWorkerNo,strResult);
      if substr(strResult,1,1)='N' then
        return;
      end if;


      SendInstockTaskAndComfire(strEnterPriseNo,strWareHouseNo,strOwnerNo,v_strUntreadType,v_strClassType,
            v_strQualityFlag,strWorkerNo,v_strLocateNo,strDockNo,'0',v_strInstockNo,strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;

      --验收确认
      P_comfireCheckTTH(strEnterPriseNo,strWareHouseNo,strsUntreadNo,v_strUntreadType,v_strClassType,v_strQualityFlag,
          strOwnerNo,strsCheckNo,strWorkerNo,strDockNo,'0',strResult);
      if substr(strResult,1,1)='N' then
        return;
      end if;

      strResult:='Y|[]';
 end P_BadGoodSaveCheck_Instock;
 /****************************************************************************************************
 功能说明：1、返配发单；
           2、根据返配单据类型判断是否需要自动回单
  luozhiling
 ****************************************************************************************************/
 procedure SendInstockTaskAndComfire(strEnterPriseNo       in ridata_check_m.enterprise_no%type,
                                    strWareHouseNo        in ridata_instock_direct.warehouse_no%type, --仓别
                                    strOwnerNo            in ridata_instock_direct.owner_no%type,
                                    strUntreadType        in ridata_untread_m.untread_type%type,
                                    strClassType          in ridata_untread_m.class_type%type,
                                    strQualityFlag        in ridata_untread_m.quality%type,
                                    strWorkerNo           in ridata_instock_direct.rgst_name%type, --操作人
                                    strLocateNo           in ridata_instock_direct.locate_no%type,
                                    strDockNo             in ridata_check_m.dock_no%type,
                                    strPrintFlag          in job_printtask_m.reprint_flag%type,--打印标识，0-不打印;1-打印上架清单;2-打印上架标签
                                    strInstockNo          out ridata_instock_d.instock_no%type, --上架单号
                                    strResult             out varchar2) is
    v_strAutoInstock   wms_riordertype.auto_instock%type;
    v_PrintInstockType wms_riordertype.PRINT_INSTOCK_TYPE%type; --huangb 20160804
 begin

     --获取单据类型配置的是否需要自动上架的标识 huangb 20160804
     PKLG_WMS_Public.p_GetRIdataOrder
     (strEnterPriseNo,strWareHouseNo,strOwnerNo,strUntreadType,strClassType,strQualityFlag,
      'auto_instock',v_strAutoInstock,strResult);
     if substr(strResult,1,1)='N' then
       return;
     end if;

     --获取单据类型配置的上架打印类型 huangb 20160804
     PKLG_WMS_Public.p_GetRIdataOrder
     (strEnterPriseNo,strWareHouseNo,strOwnerNo,strUntreadType,strClassType,strQualityFlag,
      'PRINT_INSTOCK_TYPE',v_PrintInstockType,strResult);
     if substr(strResult,1,1)='N' then
       return;
     end if;

     if(v_PrintInstockType <> '0') then
       v_PrintInstockType := strPrintFlag;
     end if;

     --返配上架发单 strPrintFlag 改为 v_PrintInstockType huangb 20160804
     pkobj_ridata.P_insertInstock
     (strEnterPriseNo,strWareHouseNo,strWorkerNo,strLocateNo,strDockNo,v_PrintInstockType,strInstockNo,strResult);
     if substr(strResult,1,1)='N' then
       return;
     end if;

     /* 改为通过公用方法获取 huangb 20160804
     --根据货主仓别级别对应的单据类型获取是否需要自动上架的标识
     begin
         select auto_instock into v_strAutoInstock from wms_warehouse_riordertype where enterprise_no=strEnterPriseNo
                and warehouse_no=strWareHouseNo and owner_no=strOwnerNo and untread_type=strUntreadType
                and class_type=strClassType and quality_flag=strQualityFlag;
     exception when no_data_found then
         --获取货主级别对应的标识
         begin
             select auto_instock into v_strAutoInstock from wms_owner_riordertype where enterprise_no=strEnterPriseNo
                    and owner_no=strOwnerNo and untread_type=strUntreadType
                    and class_type=strClassType and quality_flag=strQualityFlag;
         exception when no_data_found then
             --获取系统级别对应的标识
             begin
                 select auto_instock into v_strAutoInstock from wms_riordertype where enterprise_no=strEnterPriseNo
                        and untread_type=strUntreadType
                        and class_type=strClassType and quality_flag=strQualityFlag;
             exception when no_data_found then
                 strResult:='N|[找不到对应的单据配置]';
                 return;
             end;
          end;
     end;*/

     if v_strAutoInstock='1' then --自动回单
         P_saveInstockAll(strEnterPriseNo,strWareHouseNo,strInstockNo,strWorkerNo,strWorkerNo,'1',strResult);
         if substr(strResult,1,1)='N' then
           return;
         end if;
     end if;

 end SendInstockTaskAndComfire;

   /**************************************************************************************************
  创建人：luozhiling
  创建日期:2015.7.20
  功能说明：整单上架回单
  ***************************************************************************************************/
  procedure P_saveInstockAll(   strEnterpriseNo   in Ridata_instock_m.enterprise_no%type,
                                strWarehouseNo    in Ridata_instock_m.warehouse_no%type,
                                strInstockNo      in Ridata_instock_m.instock_no%type,
                                strUserId         in Ridata_instock_m.rgst_name%type, --上架人
                                strPaperUserId    in Ridata_instock_m.rgst_name%type, --回单人
                                strTools          in stock_content_move.terminal_flag%type,
                                strResult         out varchar2) is
  begin
       strResult:='N|[P_saveInstockAll]';
       for p in(select iid.owner_no, sai.produce_date,sai.expire_date,sai.lot_no,sai.quality,sai.rsv_batch1,sai.rsv_batch2,
           sai.rsv_batch3,sai.rsv_batch4,sai.rsv_batch5,sai.rsv_batch6,sai.rsv_batch7,sai.rsv_batch8,
           iid.instock_no,iid.cell_no,iid.article_no,iid.dest_cell_no,iid.label_no,iid.packing_qty,sum(iid.article_qty) article_qty
           from ridata_instock_d iid,stock_article_info sai where iid.warehouse_no=strWarehouseNo
           and iid.enterprise_no=strEnterpriseNo and iid.instock_no=strInstockNo and iid.status='10'
           and iid.article_no=sai.article_no and iid.article_id=sai.article_id
           group by iid.owner_no,sai.produce_date,sai.expire_date,sai.lot_no,sai.quality,sai.rsv_batch1,sai.rsv_batch2,
           sai.rsv_batch3,sai.rsv_batch4,sai.rsv_batch5,sai.rsv_batch6,sai.rsv_batch7,sai.rsv_batch8,
           iid.instock_no,iid.cell_no,iid.article_no,iid.dest_cell_no,iid.label_no,iid.packing_qty) loop
           --上架回单
           P_SaveInstock(strEnterpriseNo,strWareHouseNo,strInstockNo,p.dest_cell_no,p.dest_cell_no,
               p.label_no,p.article_no,p.produce_date,p.packing_qty,
               p.article_qty,strUserId,strPaperUserId,'1',strResult);

          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;
       end loop;

       strResult:='Y|[成功]';
  end P_saveInstockAll;


/*****************************************************************************************************
 功能说明：返配上架取消：
           1、将整单做上架回单，
           2、将差异部分库存转移到质量问题差异区
  创建人：luozhiling
  日期：2015-12-27
*****************************************************************************************************/
 procedure P_InstockCancel(strEnterpriseNo in Ridata_instock_m.enterprise_no%type,
                             strWarehouseNo  in Ridata_instock_m.warehouse_no%type,
                             strInstockNo    in Ridata_instock_m.instock_no%type,
                             strUserId       in Ridata_instock_m.rgst_name%type, --上架人
                             strPaperUserId  in Ridata_instock_m.rgst_name%type, --回单人
                             strTools        in stock_content_move.terminal_flag%type,
                             strResult       out varchar2)is
    v_strDestCellNo          ridata_instock_d.dest_cell_no%type;
 begin
      strResult:='N|[P_InstockCancel]';
      --先检查这张上架单对应的电子标签储位是否有未封箱的
      begin
          select t.dest_cell_no into v_strDestCellNo from ridata_instock_d t where t.enterprise_no=strEnterpriseNo
                 and t.warehouse_no=strWarehouseNo and t.instock_no=strInstockNo
                 and t.real_qty>0 and t.status<'13' and rownum=1;
      exception when no_data_found then
            v_strDestCellNo:='N';
      end;
      if v_strDestCellNo<>'N' then
         strResult:='N|['||v_strDestCellNo||'未封箱!';
         return;
      end if;

      for p in(select sai.produce_date,sai.expire_date,sai.lot_no,sai.quality,sai.rsv_batch1,sai.rsv_batch2,
         sai.rsv_batch3,sai.rsv_batch4,sai.rsv_batch5,sai.rsv_batch6,sai.rsv_batch7,sai.rsv_batch8,
         iid.* from ridata_instock_d iid,stock_article_info sai where iid.warehouse_no=strWarehouseNo
         and iid.enterprise_no=strEnterpriseNo and iid.instock_no=strInstockNo and iid.status<'13'
         and iid.article_no=sai.article_no and iid.article_id=sai.article_id) loop
         --上架回单
         pklg_ridata.P_SaveInstock(strEnterpriseNo,strWareHouseNo,strInstockNo,p.dest_cell_no,p.dest_cell_no,
             p.label_no,p.article_no,p.produce_date,p.packing_qty,
             0,strUserId,strPaperUserId,'1',strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;
      end loop;

      strResult:='Y|[成功]';


 end P_InstockCancel;

/**************************************************************************************************
 luozhiling
 2015.7.15
 功能说明：1、对扫描墙进行封箱(包括自动封箱)
**************************************************************************************************/
 procedure P_DeviceCloseBox_Main(strEnterPriseNo      in ridata_check_pal_tmp.enterprise_no%type,
                             strWareHouseNo       in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                             strOwnerNo           in ridata_check_pal_tmp.owner_no%type, --委托业主编码
                             strDeviceNo          in ridata_box.device_no%type,--扫描墙号
                             strWaveNo            in ridata_box.wave_no%type,--波次号
                             strWorkerNo          in ridata_check_pal_tmp.rgst_name%type, --操作人
                             strDockNo            iN ridata_check_m.dock_no%type,
                             strQualityFlag       in ridata_box.quality%type,--0,正常，1过季，A，质量问题，B次品
                             strDestCellNo        in cdef_defcell.cell_no%type,--指定储位，若无，传N
                             strResult            out varchar2) is
  v_strLocateNo              ridata_locate_direct.locate_no%type;
  v_strInstockNo             ridata_instock_m.instock_no%type;
  v_strDestCellNo            cdef_defcell.cell_no%type;
  v_iCount                   integer:=0;
 begin
     strResult:='N|[P_DeviceCloseBox_Main]';

     v_strDestCellNo:=strDestCellNo;

     --循环查询扫描墙上需要封箱的资料
     for GetLabelInf in(select distinct s_check_no,s_untread_no,t.label_no from ridata_check_pal_tmp t
         where t.enterprise_no=strEnterPriseNo
         and t.warehouse_no=strWareHouseNo and t.device_no=strDeviceNo and t.wave_no=strWaveNo
         order by t.s_untread_no,t.label_no)loop

        v_iCount:=v_iCount+1;

        pklg_ridata.P_CheckFixPal(strEnterPriseNo,strWareHouseNo,strOwnerNo,
                  GetLabelInf.s_untread_no,GetLabelInf.s_check_no,GetLabelInf.label_no,strWorkerNo,
                strResult);
        if substr(strResult,1,1)='N' then
           return;
        end if;
    end loop;

    --0，A通过资源试算知道上架储位，1和B需要指定储位上架
    --
    if v_iCount>0 then
        if strQualityFlag='1' then--获取过季品储位
           begin
                 select cell_no
                   into v_strDestCellNo
                    from (select cdc.cell_no
                            from cdef_defcell cdc, cdef_defarea cda
                           where cdc.enterprise_no=cda.enterprise_no and
                             cdc.enterprise_no=strEnterPriseNo and cdc.warehouse_no = cda.warehouse_no
                             and cdc.ware_no = cda.ware_no
                             and cdc.area_no = cda.area_no
                             and cda.area_usetype='1'
                             and cda.area_quality='1'
                             and cdc.warehouse_no = strWareHouseNo
                             and cdc.cell_status = '0'
                             and cdc.check_status = '0'
                             and cda.Area_Attribute = '0'
                             and cda.attribute_type='0'
                             and rownum=1);

           exception when no_data_found then
              strResult:='N|[EEEEEE]';--找不到过季品储位
              return;
           end;
        end if;



        for P in (select distinct t.untread_type,t.class_type,t.quality, t.label_no from ridata_check_pal t where  t.enterprise_no=strEnterPriseNo
             and t.warehouse_no=strWareHouseNo and t.device_no=strDeviceNo and t.wave_no=strWaveNo
             and t.status='10')loop

            p_Labellocate(strEnterPriseNo,strWareHouseNo,p.label_no,strWorkerNo,'1','1',v_strDestCellNo,v_strLocateNo,strResult);
            if substr(strResult,1,1)='N' then
               return;
            end if;


            PKLG_RILOCATE.p_locate_main(strEnterPriseNo,strWareHouseNo,strOwnerNo,v_strLocateNo,strDockNo,strWorkerNo,strResult);
            if substr(strResult,1,1)='N' then
              return;
            end if;


            SendInstockTaskAndComfire(strEnterPriseNo,strWareHouseNo,strOwnerNo,P.untread_type,P.class_type,
                  p.quality,strWorkerNo,v_strLocateNo,strDockNo,'2',v_strInstockNo,strResult);
            if substr(strResult, 1, 1) = 'N' then
              return;
            end if;

        end loop;
    else
        --没有需要封箱的数据
        update ridata_box t set t.status='3',t.updt_name=strWorkerNo,t.updt_date=sysdate
        where t.enterprise_no=strEnterPriseNo
               and t.warehouse_no=strWareHouseNo and t.wave_no=strWaveNo
               and t.device_no=strDeviceNo;


         --将扫描墙资源转历史
        pkobj_ridata.p_Insert_box_hty(strEnterPriseNo,strWareHouseNo,
              strWaveNo,strDeviceNo,'N',strResult);
        if (substr(strResult, 1, 1) = 'N') then
             return;
        end if;
    end if;

    strResult:='Y';


     strResult:='Y|[成功]';
 end P_DeviceCloseBox_Main;

/**************************************************************************************************
  luozhiling
  2014.6.20
  功能说明：返配验收，整单验收封板，按品质分板，定位并上架
**************************************************************************************************/
 procedure P_ClosePalQuality_main(strEnterPriseNo       in ridata_check_pal_tmp.enterprise_no%type,
                                  strWareHouseNo        in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                  strOwnerNo            in ridata_check_pal_tmp.owner_no%type, --委托业主编码
                                  strsUntreadNo         in ridata_untread_sm.s_untread_no%type, --进货汇总单号
                                  strsCheckNo           in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                  strLabelNo            in ridata_check_pal_tmp.label_no%type, --板号
                                  strWorkerNo           in ridata_check_pal_tmp.rgst_name%type, --操作人
                                  strDestCellNo         in cdef_defcell.cell_no%type,
                                  strDockNo             iN ridata_check_m.dock_no%type,
                                  strResult             out varchar2) is
            v_strLocateNo               ridata_locate_direct.locate_no%type;
            v_strInstockNo              ridata_locate_direct.locate_no%type;
            v_strUntreadType            ridata_untread_m.untread_type%type;
            v_strClassType              ridata_untread_m.class_type%type;
            v_strQualityFlag            ridata_untread_m.quality%type;
            v_iCount                    integer:=0;
 begin
    strResult := 'N|[P_ClosePalQuality_main]';

    for p in (select distinct a.untread_type,a.class_type,a.quality_flag,a.label_no
                from ridata_check_pal_tmp a
               where a.enterprise_no=strEnterPriseNo and a.s_check_no=strsCheckNo and a.WAREHOUSE_NO = strWareHouseNo
                 and a.owner_no = strOwnerNo and a.s_untread_no=strsUntreadNo order by a.label_no) loop
        v_iCount:=1;
        v_strUntreadType:=p.untread_type;
        v_strClassType:=p.class_type;
        v_strQualityFlag:=P.quality_flag;

        pklg_ridata.P_CheckFixPal(strEnterPriseNo,strWareHouseNo,strOwnerNo,strsUntreadNo,strsCheckNo,p.label_no,strWorkerNo,
                strResult);
        if substr(strResult,1,1)='N' then
           return;
        end if;

        pklg_ridata.p_Labellocate(strEnterPriseNo,strWareHouseNo,p.label_no,strWorkerNo,'1','0',strDestCellNo,v_strLocateNo,strResult);
        if substr(strResult,1,1)='N' then
           return;
        end if;

        PKLG_RILOCATE.p_locate_main(strEnterPriseNo,strWareHouseNo,strOwnerNo,v_strLocateNo,strDockNo,strWorkerNo,strResult);
        if substr(strResult,1,1)='N' then
          return;
        end if;

        SendInstockTaskAndComfire(strEnterPriseNo,strWareHouseNo,strOwnerNo,p.untread_type,p.class_type,
              p.quality_flag,strWorkerNo,v_strLocateNo,strDockNo,'2',v_strInstockNo,strResult);
        if substr(strResult, 1, 1) = 'N' then
          return;
        end if;
    end loop;

    if v_iCount=0 then
       strResult:='N|[找不到对应的板明细]';
       return;
    end if;

    --验收确认
    P_comfireCheckTTH(strEnterPriseNo,strWareHouseNo,strsUntreadNo,v_strUntreadType,v_strClassType,v_strQualityFlag,
        strOwnerNo,strsCheckNo,strWorkerNo,strDockNo,'0',strResult);
    if substr(strResult,1,1)='N' then
      return;
    end if;


    strResult:='Y';

 end P_ClosePalQuality_main;
 /***********************************************************************************************8
   作者:luozhiling
   日期:  2013-11-12
   功能: 返配验收时，将临时板明细的数据转移到验收数据里，按品质产生板号(共速达）
   拆板根据品质标识来 huangb 20160813
*************************************************************************************************/
  procedure P_CheckSplitPal(strEnterPriseNo      in ridata_check_pal_tmp.enterprise_no%type,
                            strWareHouseNo       in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                            strOwnerNo           in ridata_check_pal_tmp.owner_no%type, --委托业主编码
                            strsUntreadNo        in ridata_untread_sm.s_untread_no%type, --进货汇总单号
                            strsCheckNo          in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                            strLabelNo           in ridata_check_pal_tmp.label_no%type, --板号
                            strWorkerNo          in ridata_check_pal_tmp.rgst_name%type, --操作人
                            strResult            out varchar2) is
    cursor v_GetCheckPalTmp is
     select * from ridata_check_pal_tmp
               where enterprise_no=strEnterPriseNo and WAREHOUSE_NO = strWareHouseNo  and owner_no = strOwnerNo
                 and s_untread_no = strsUntreadNo and s_check_no = strsCheckNo
                 and label_no = strLabelNo and status = '10'
                 order by quality,label_no,article_no,rowid;


    strContainNo  varchar2(24); --内部容器号
    strLabelNoTmp varchar2(24); --板号
    strSessionID  varchar2(10);
    intCount      integer; --记录拆板数
    v_strLabelNo  Ridata_check_pal.label_no%type;
    v_strQuality  ridata_check_pal.quality%type := 'N';
  begin
    strResult := 'N|[P_CheckSplitPal]';
    intCount  := 0;
       --取板信息
    for GetCheckPalTmp in v_GetCheckPalTmp loop
        if v_strQuality<>GetCheckPalTmp.Quality_Flag or v_strQuality = 'N' then--品质不同的商品自动分拆到不同的标签上
            --取P标签 只取一个标签
            pklg_wms_base.p_get_ContainerNoBase(strEnterPriseNo,strWareHouseNo,'P',strWorkerNo,'D',1,'2','31',
                                                strLabelNoTmp,strContainNo,strSessionID,strResult);
            if (substr(strResult, 1, 1) = 'N') then
              return;
            end if;
        end if;
        --拆板根据品质标识来 huangb 20160813
        --v_strQuality:=GetCheckPalTmp.quality;
        v_strQuality:=GetCheckPalTmp.Quality_Flag;

        if strLabelNo='N' then
           v_strLabelNo:=strLabelNoTmp;
        else
          v_strLabelNo:=strLabelNo;
        end if;

        --配量,写验收数据
        begin
          p_MixAmount(strEnterPriseNo,strWareHouseNo,strOwnerNo,strsUntreadNo,GetCheckPalTmp.untread_type,
          GetCheckPalTmp.class_type,GetCheckPalTmp.quality_flag,strSCheckNo,strLabelNo,v_strLabelNo,
             strContainNo,GetCheckPalTmp.check_qty,GetCheckPalTmp.row_id,strWorkerNo,strResult);
          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;
       end;
       intCount := intCount + 1;

       delete from ridata_check_pal_tmp where enterprise_no=strEnterPriseNo  and WAREHOUSE_NO = strWareHouseNo
       and owner_no = strOwnerNo
       and s_untread_no = strsUntreadNo
       and s_check_no = strSCheckNo
       and label_no = strLabelNo
       and row_id=GetCheckPalTmp.row_id;
    end loop;

    if (intcount = 0) then
      strResult := 'N|[E24218]';
      return;
    end if;
    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_CheckSplitPal;

 /***********************************************************************************************8
   作者:luozhiling
   日期:  2014-6-20
   功能: 返配验收封箱时，检查是否需要释放资源
*************************************************************************************************/
  procedure P_ReleaseDevice(strEnterPriseNo      in ridata_check_pal_tmp.enterprise_no%type,
                          strWareHouseNo       in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                          strLabelNo           in ridata_check_pal_tmp.label_no%type, --板号
                          strLabelId           in ridata_check_pal_tmp.label_id%type,--扫描墙储位（箱序号）
                          strDeviceNo          in ridata_check_pal_tmp.device_no%type,--扫描墙号
                          strUserID            in ridata_check_m.updt_name%type,
                          strResult            out varchar2)is
      v_strWaveNo         ridata_check_pal.wave_no%type;
      v_strStatus         bset_wave_manage.status%type;
      v_nCheckQty         ridata_check_pal.check_qty%type;--封箱数量
      v_nYCheckQty        ridata_check_pal.check_qty%type;--扫描数量
      v_nUntreadQty       ridata_check_pal.check_qty%type;--预计返配数量
      v_strBatchNo        ridata_check_pal.batch_no%type;
      v_strQualityFlag    ridata_check_pal.quality%type;
      v_strWaveType       ridata_box.wave_type%type;
  begin
       strResult:='N|[P_ReleaseDevice]';

       --获取此箱号对应的波次
       select distinct t.wave_no,t.batch_no,t.quality into v_strWaveNo,v_strBatchNo,v_strQualityFlag
       from ridata_check_pal t where t.enterprise_no=strEnterPriseNo
              and t.warehouse_no=strWareHouseNo and t.label_no=strLabelNo;

       if strDeviceNo<>'N' then

           --锁定波次状态表
           update bset_wave_manage t set t.status=t.status
               where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo
               and t.wave_no=v_strWaveNo;

           --获取波次状态
           select t.status into v_strStatus from bset_wave_manage t where t.enterprise_no=strEnterPriseNo
               and t.warehouse_no=strWareHouseNo and t.wave_no=v_strWaveNo;

           if v_strStatus='15' then --扫描结束的波次,需要释放该扫描墙的所有资源
              update ridata_box t set t.status='3',t.updt_name=strUserID,t.updt_date=sysdate
              where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo
                     and t.wave_no=v_strWaveNo and t.device_no=strDeviceNo and t.status in('1','2');
               --将扫描墙资源转历史
               pkobj_ridata.p_Insert_box_hty(strEnterPriseNo,strWareHouseNo,v_strWaveNo,strDeviceNo,'N',strResult);
               if (substr(strResult, 1, 1) = 'N') then
                 return;
               end if;

           else--正常波次，判断是否需要释放本扫描墙储位的资源
               --获取该箱号对应的返配单

               --滞销品和过季品暂不释放储位
               begin
                     select distinct wave_type into v_strWaveType from ridata_box where enterprise_no=strWareHouseNo
                      and warehouse_no=strWareHouseNo and wave_no=v_strWaveNo and device_no=strDeviceNo
                      AND label_id=strLabelId ;
               exception when no_data_found then
                     v_strWaveType:='N';
               end;

               if v_strWaveType<>'5' and v_strWaveType<>'6' and v_strWaveType<>'N' then


                --计算该箱号对应的返配单的总验收数量
                  select nvl(sum(t.check_qty),0) into v_nCheckQty from ridata_check_pal t
                  where t.enterprise_no=strEnterpriseNo and t.warehouse_no=strWareHouseNo
                  and (t.check_no,t.article_no) in
                  (select check_no,article_no from ridata_check_pal rcp where rcp.enterprise_no=strEnterPriseNo
                  and rcp.warehouse_no=strWareHouseNo and rcp.label_no=strLabelNo and rcp.wave_no=v_strWaveNo
                  and rcp.device_no=strDeviceNo)
                  and t.wave_no=v_strWaveNo and t.device_no=strDeviceNo and t.batch_no=v_strBatchNo
                  and t.quality=v_strQualityFlag;

                 --统计该箱号的对应的返配临时表的总数量

                  select nvl(sum(t.check_qty),0) into v_nYCheckQty from ridata_check_pal_tmp t
                  where t.enterprise_no=strEnterpriseNo and t.warehouse_no=strWareHouseNo
                  and (t.s_check_no,t.article_no) in
                  (select s_check_no,article_no from ridata_check_pal_tmp rcp where rcp.enterprise_no=strEnterPriseNo
                  and rcp.warehouse_no=strWareHouseNo and rcp.label_no=strLabelNo and rcp.wave_no=v_strWaveNo
                  and rcp.device_no=strDeviceNo)
                  and t.wave_no=v_strWaveNo and t.device_no=strDeviceNo and t.batch_no=v_strBatchNo
                  and t.quality=v_strQualityFlag;

                  --统计该箱号对应的返配单通知单的总数量

                  select nvl(sum(t.untread_qty),0) into v_nUntreadQty from ridata_untread_d t
                  where t.enterprise_no=strEnterpriseNo and t.warehouse_no=strWareHouseNo
                  and (t.untread_no,t.article_no) in
                  (select distinct untread_no,rcp.article_no from ridata_check_pal rcp,ridata_check_m t
                  where rcp.enterprise_no=t.enterprise_no and rcp.warehouse_no=t.warehouse_no
                  and rcp.check_no=t.check_no and rcp.enterprise_no=strEnterPriseNo
                  and rcp.warehouse_no=strWareHouseNo and rcp.label_no=strLabelNo and rcp.wave_no=v_strWaveNo
                  and rcp.device_no=strDeviceNo) ;

                  if v_nUntreadQty=v_nYCheckQty+v_nCheckQty then--此标签对应的单全部扫描完成，可释放扫描墙储位号
                      update ridata_box t set t.status='3',t.updt_name=strUserID,t.updt_date=sysdate
                      where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo
                             and t.wave_no=v_strWaveNo and t.device_no=strDeviceNo and t.status in('1','2')
                             and t.label_id=strLabelId and t.status in ('1','2');
                       --将扫描墙资源转历史
                      pkobj_ridata.p_Insert_box_hty(strEnterPriseNo,strWareHouseNo,
                            v_strWaveNo,strDeviceNo,strLabelId,strResult);
                      if (substr(strResult, 1, 1) = 'N') then
                           return;
                      end if;

                  end if;
              end if;
           end if;

      end if;

       strResult:='Y|[]';
  end P_ReleaseDevice;
 /***********************************************************************************************8
   作者:luozhiling
   日期:  2014-6-20
   功能: 返配验收时，将临时板明细的数据转移到验收数据里，一板对应多汇总单,
   此过程适用于固定板号收货，目前天天惠在用
*************************************************************************************************/
  procedure P_CheckFixPal(strEnterPriseNo      in ridata_check_pal_tmp.enterprise_no%type,
                          strWareHouseNo       in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                          strOwnerNo           in ridata_check_pal_tmp.owner_no%type, --委托业主编码
                          strsUntreadNo        in ridata_untread_sm.s_untread_no%type, --进货汇总单号
                          strsCheckNo          in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                          strLabelNo           in ridata_check_pal_tmp.label_no%type, --板号
                          strWorkerNo          in ridata_check_pal_tmp.rgst_name%type, --操作人
                          strResult            out varchar2) is
    cursor v_GetCheckPalTmp is
     select * from ridata_check_pal_tmp
               where enterprise_no=strEnterPriseNo and WAREHOUSE_NO = strWareHouseNo  and owner_no = strOwnerNo
                 and label_no = strLabelNo and status = '10' and s_untread_no=strsUntreadNo
                 order by s_untread_no,label_no,article_no,row_id;


    strContainNo  varchar2(24); --内部容器号
    strLabelNoTmp varchar2(24); --板号
    strSessionID  varchar2(10);
    intCount      integer; --记录拆板数
    v_strLabelNo  Ridata_check_pal.label_no%type;
    v_strLabelId  ridata_check_pal.firstcheck_label_no%type;--扫描墙号（箱序号）
    v_strDeviceNo  ridata_check_pal.device_no%type;
  begin
    strResult := 'N|[P_CheckFixPal]';
    intCount  := 0;

    --获取标签号
    begin
       select distinct container_no into strContainNo
              from ridata_check_pal t where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo AND T.label_no=strLabelNo;
    exception when no_data_found then
        strContainNo:='N';
    end;

    if strContainNo='N' then
        --取P标签 只取一个标签
        pklg_wms_base.p_get_ContainerNoBase(strEnterPriseNo,strWareHouseNo,'P',strWorkerNo,'D',1,'2','31',
                                            strLabelNoTmp,strContainNo,strSessionID,strResult);
        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;
    end if;

    if strLabelNo='N' then
       v_strLabelNo:=strLabelNoTmp;
    else
      v_strLabelNo:=strLabelNo;
    end if;

       --取板信息
    for GetCheckPalTmp in v_GetCheckPalTmp loop

        --配量,写验收数据
        begin
          p_MixAmount(strEnterPriseNo,strWareHouseNo,strOwnerNo,strsUntreadNo,GetCheckPalTmp.untread_type,
             GetCheckPalTmp.class_type,GetCheckPalTmp.quality_flag,strSCheckNo,strLabelNo,v_strLabelNo,
             strContainNo,GetCheckPalTmp.check_qty,GetCheckPalTmp.row_id,strWorkerNo,strResult);
          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;
       end;
       intCount := intCount + 1;

       delete from ridata_check_pal_tmp where enterprise_no=strEnterPriseNo and WAREHOUSE_NO = strWareHouseNo
         and owner_no = strOwnerNo
         and s_untread_no = strsUntreadNo
         and s_check_no = strSCheckNo
         and label_no = strLabelNo
         and row_id=GetCheckPalTmp.row_id;

    end loop;

    if (intcount = 0) then
      strResult := 'N|[E24218]';
      return;
    end if;
    --获取箱序号
    select distinct firstcheck_label_no,device_no into v_strLabelId,v_strDeviceNo from ridata_check_pal t
           where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo
           and t.label_no=strLabelNo and rownum=1;
    --释放扫描墙资料
    P_ReleaseDevice(strEnterPriseNo,strWareHouseNo,strLabelNo,v_strLabelId,v_strDeviceNo,strWorkerNo,strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_CheckFixPal;
  /************************************************************************************************
  luozhiling
  2013-10-10
  说明：根据临时板明细写验收数据,不超品、超量

  ***********************************************************************************************/
  procedure p_MixAmount(strEnterPriseNo       in ridata_check_pal_tmp.enterprise_no%type,
                        strWareHouseNo        in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                        strOwnerNo            in ridata_check_pal_tmp.owner_no%type, --委托业主
                        strsUntreadNo         in ridata_check_pal_tmp.s_untread_no%type, --返配汇总单号
                        strUntreadType        in ridata_untread_m.untread_type%type,
                        strClassType          in ridata_untread_m.class_type%type,
                        strQualityFlag        in ridata_untread_m.quality%type,
                        strSCheckNo           in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                        strLabelNo            in ridata_check_pal_tmp.label_no%type, --扫描的原板号，若没有默认N
                        strNewLabelNo         in ridata_check_pal_tmp.label_no%type, --新取板号，流水板验收时用
                        strContainerNo        in ridata_check_pal_tmp.label_no%type,
                        nCheckQty             in ridata_check_pal_tmp.check_qty%type,
                        nRowId                in ridata_check_pal_tmp.row_id%type,
                        strWorkerNo           in ridata_check_pal_tmp.rgst_name%type, --操作人
                        strResult             out varchar2) is

    --取未验量
    cursor cur_UnCheckInfo is
      select d.untread_qty, d.check_qty, m.untread_no, tmp.row_id
        from ridata_untread_d     d,
             ridata_untread_sm    m,
             ridata_check_pal_tmp tmp
       where m.enterprise_no=d.enterprise_no and m.enterprise_no=tmp.enterprise_no
         and m.enterprise_no=strEnterPriseNo and m.WAREHOUSE_NO = d.WAREHOUSE_NO
         and m.owner_no = d.owner_no and m.untread_no = d.untread_no
         and tmp.WAREHOUSE_NO = m.WAREHOUSE_NO and tmp.owner_no = m.owner_no
         and tmp.s_untread_no = m.s_untread_no and tmp.s_check_no = strSCheckNo
         and tmp.label_no = strLabelNo and d.article_no = tmp.article_no
         and d.packing_qty = tmp.packing_qty and m.WAREHOUSE_NO = strWareHouseNo
         and m.owner_no = strOwnerNo and m.s_untread_no = strsUntreadNo
         and tmp.row_id = nRowId and d.untread_qty - d.check_qty > 0
         and m.status <> '13' and m.status <> '16'
         and d.status <> '13' and d.status <> '16';

    nUnCheckQty  ridata_check_d.check_qty%type; --未验量
    nTmpQty      ridata_check_d.check_qty%type; --中间量
    nSumCheckQty ridata_check_d.check_qty%type; --板验收量
    v_strOverQtyFlag               wms_riordertype.over_qty_flag%type;--0:不超；1：超量；2：超品

  begin
    strResult := 'N|[p_MixAmount]';

    --获取单据类型配置的是否能超量标识 huangb 20160804
    PKLG_WMS_Public.p_GetRIdataOrder
    (strEnterPriseNo,strWareHouseNo,strOwnerNo,strUntreadType,strClassType,strQualityFlag,
     'over_qty_flag',v_strOverQtyFlag,strResult);
    if substr(strResult,1,1)='N' then
      return;
    end if;

    /* 改为通过公用方法获取 huangb 20160804
    --根据货主仓别级别对应的单据类型获取是否需要混单验收的标识
    begin
        select over_qty_flag into v_strOverQtyFlag
         from wms_warehouse_riordertype where enterprise_no=strEnterPriseNo
               and warehouse_no=strWareHouseNo and owner_no=strOwnerNo and untread_type=strUntreadType
               and class_type=strClassType and quality_flag=strQualityFlag;
    exception when no_data_found then
        --获取货主级别对应的标识
        begin
            select over_qty_flag into v_strOverQtyFlag
            from wms_owner_riordertype where enterprise_no=strEnterPriseNo
                   and owner_no=strOwnerNo and untread_type=strUntreadType
                   and class_type=strClassType and quality_flag=strQualityFlag;
        exception when no_data_found then
            --获取系统级别对应的标识
            begin
                select over_qty_flag into v_strOverQtyFlag
                from wms_riordertype where enterprise_no=strEnterPriseNo
                       and untread_type=strUntreadType
                       and class_type=strClassType and quality_flag=strQualityFlag;
            exception when no_data_found then
                strResult:='N|[找不到对应的单据配置]';
                return;
            end;
         end;
    end;*/

    --取板信息
    nTmpQty := 0;

    nSumCheckQty := nCheckQty;


    if v_strOverQtyFlag='2' then --超品
       for overSkuCheck in (select rus.untread_no,rcpt.* from ridata_check_pal_tmp rcpt,ridata_untread_sm rus
           where rcpt.enterprise_no=rus.enterprise_no and rcpt.enterprise_no=strEnterPriseNo
           and rcpt.warehouse_no=strWareHouseNo and rcpt.owner_no=strOwnerNo
           and rcpt.s_untread_no=strsUntreadNo and rcpt.s_check_no=strSCheckNo
           and rcpt.label_no=strLabelNo and rcpt.warehouse_no=rus.warehouse_no
           and rcpt.s_untread_no=rus.s_untread_no and rcpt.row_id=nRowId order by rcpt.article_no,rus.untread_no) loop

           --不考虑超量，直接写验收数据
           pkobj_ridata.p_insertcheckD(strEnterPriseNo,strWareHouseNo,
                      strOwnerNo,
                      strsUntreadNo,
                      strsCheckNo,
                      overSkuCheck.untread_no,
                      strWorkerNo,
                      nCheckQty,
                      nRowId,
                      strLabelNo,
                      strResult);

          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;

                    --写返配对象
          pkobj_ridata.p_OverSkuInsertCheckNo(strEnterPriseNo,strWareHouseNo,
                                 strOwnerNo,
                                 overSkuCheck.untread_no,
                                 strSCheckNo,
                                 strWorkerNo,
                                 strLabelNo,
                                 strNewLabelNo,
                                 strContainerNo,
                                 nCheckQty,
                                 nRowId,
                                 strResult);
          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;

          nSumCheckQty:= nSumCheckQty-nCheckQty;

          if (nSumCheckQty <= 0) then
            exit;
          end if;
       end loop;
    end if;

    if v_strOverQtyFlag='0' then--不允许超量

        for cur_UnCheck in cur_UnCheckInfo loop

              --正常配量
              nUnCheckQty := cur_UnCheck.untread_qty - cur_UnCheck.check_qty;
              if (nUnCheckQty > 0) then
                --有未验量时扣减数量
                if (nSumCheckQty < nUnCheckQty) then
                  nTmpQty := nSumCheckQty;
                else
                  nTmpQty := nUnCheckQty;
                end if;

                pkobj_ridata.p_insertcheckD(strEnterPriseNo,strWareHouseNo,
                                      strOwnerNo,
                                      strsUntreadNo,
                                      strsCheckNo,
                                      cur_UnCheck.untread_no,
                                      strWorkerNo,
                                      nTmpQty,
                                      nRowId,
                                      strLabelNo,
                                      strResult);

                if (substr(strResult, 1, 1) = 'N') then
                  return;
                end if;

                --写返配对象
                pkobj_ridata.p_insertcheckno(strEnterPriseNo,strWareHouseNo,
                                       strOwnerNo,
                                       cur_UnCheck.untread_no,
                                       strSCheckNo,
                                       strWorkerNo,
                                       strLabelNo,
                                       strNewLabelNo,
                                       strContainerNo,
                                       nTmpQty,
                                       nRowId,
                                       strResult);
                if (substr(strResult, 1, 1) = 'N') then
                  return;
                end if;

                nSumCheckQty := nSumCheckQty - nTmpQty; --验收量扣减完,跳出循环
              end if;

              if (nSumCheckQty <= 0) then
                exit;
              end if;
        end loop;
      end if;

      if v_strOverQtyFlag='1' then --超量,目前的超量不支持集单验收
        for p in (select d.untread_qty, tmp.check_qty, m.untread_no, tmp.row_id
              from ridata_untread_d     d,ridata_untread_sm    m,ridata_check_pal_tmp tmp
             where m.enterprise_no=d.enterprise_no and m.enterprise_no=tmp.enterprise_no
               and m.enterprise_no=strEnterPriseNo and m.WAREHOUSE_NO = d.WAREHOUSE_NO
               and m.owner_no = d.owner_no and m.untread_no = d.untread_no
               and tmp.WAREHOUSE_NO = m.WAREHOUSE_NO and tmp.owner_no = m.owner_no
               and tmp.s_untread_no = m.s_untread_no and tmp.s_check_no = strSCheckNo
               and tmp.label_no = strLabelNo and d.article_no = tmp.article_no
               and d.packing_qty = tmp.packing_qty and m.WAREHOUSE_NO = strWareHouseNo
               and m.owner_no = strOwnerNo and m.s_untread_no = strsUntreadNo
               and tmp.row_id = nRowId
               and m.status <> '13' and m.status <> '16'
               and d.status <> '13' and d.status <> '16') loop


                pkobj_ridata.p_insertcheckD(strEnterPriseNo,strWareHouseNo,
                                      strOwnerNo,
                                      strsUntreadNo,
                                      strsCheckNo,
                                      p.untread_no,
                                      strWorkerNo,
                                      nCheckQty,
                                      nRowId,
                                      strLabelNo,
                                      strResult);

                if (substr(strResult, 1, 1) = 'N') then
                  return;
                end if;

                --写返配对象
                pkobj_ridata.p_insertcheckno(strEnterPriseNo,strWareHouseNo,
                                       strOwnerNo,
                                       p.untread_no,
                                       strSCheckNo,
                                       strWorkerNo,
                                       strLabelNo,
                                       strNewLabelNo,
                                       strContainerNo,
                                       nCheckQty,
                                       nRowId,
                                       strResult);
                if (substr(strResult, 1, 1) = 'N') then
                  return;
                end if;
        end loop;
    end if;


    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_MixAmount;

 /***********************************************************************************************
 修改人:luozhiling
 日期:2013-11-4
 功能：根据验收汇总单写标签数据、定位指示和库存
 ************************************************************************************************/
 procedure p_sCheckLocate(strEnterPriseNo   in stock_label_m.enterprise_no%type,
                          strWareHouseNo    in stock_label_m.warehouse_no%type, --仓别
                          strScheckNo       in ridata_check_m.s_check_no%type, --汇总验收单号
                          strUser_ID        in stock_label_m.Rgst_Name%type, --操作人员
                          strCheckTool      in   ridata_check_pal_tmp.check_tools%type,--验收工具
                          strspecify_cell_no  in  ridata_locate_direct.specify_cell_no%type,--指定储位
                          strLocateNo         OUT   ridata_locate_direct.locate_no%type,
                          strOutMsg           out varchar2) is

      strCellNo            stock_content.cell_no%type; --暂存区储位
      v_strLocateNo        idata_locate_direct.locate_no%type;--进货定位单号

   begin

      strOutMsg        := 'N|[p_sCheckLocate]';
      --获取暂存区储位
      begin
        select CDC.CELL_NO
          into strCellNo
          FROM CDEF_DEFAREA CDA, CDEF_DEFCELL CDC
         WHERE cda.enterprise_no=cdc.enterprise_no and cda.enterprise_no=strEnterPriseNo
           and CDA.warehouse_no = CDC.warehouse_no
           AND CDA.WARE_NO = CDC.WARE_NO
           AND CDA.AREA_NO = CDC.AREA_NO
           AND CDA.AREA_ATTRIBUTE = '1'
           AND (CDA.ATTRIBUTE_TYPE = '1' OR CDA.ATTRIBUTE_TYPE = '0')
           and CDA.warehouse_no=strWareHouseNo
           and rownum < 2;
      exception
        when no_data_found then
          strOutMsg := 'N|[E24219]';
          return;
      end;

      --取定位指示号；
      begin
        PKLG_WMS_BASE.p_getsheetno(strEnterPriseNo,strWareHouseNo, CONST_DOCUMENTTYPE.IDATAIL, v_strLocateNo, strOutMsg);
        if (strOutMsg is null or substr(strOutMsg, 1, 1) = 'N') then
          strOutMsg := 'N|[E24220]'; --取汇总验收单号错误!
          return;
        end if;
      end;

      strLocateNo:=v_strLocateNo;

      --根据板明细表库存
      PKOBJ_STOCK.p_Ridata_InsertSCheckStock(strEnterPriseNo,strWareHouseNo,strScheckNo,strCheckTool,
           strUser_ID,v_strLocateNo,strspecify_cell_no,strOutMsg);

      --根据板明细写上架定位指示
      if substr(strOutMsg, 1, 1) = 'N' then
        return;
      end if;
      strOutMsg := 'Y|';
    exception
      when others then
        strOutMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
        return;

 end p_sCheckLocate;

/*************************************************************************************************
     修改人：luozhiling
     日期：2013-10-20
     功能：上架回单

*************************************************************************************************/
  procedure P_SaveInstock(strEnterPriseNo          in      ridata_instock_m.enterprise_no%type,
                          strWareHouseNo           in      Ridata_instock_m.warehouse_no%type,
                          strInstockNo             in      Ridata_instock_m.instock_no%type,
                          strDestCellNo            in      Ridata_instock_d.dest_cell_no%type,
                          strInstockCellNo         in      Ridata_instock_d.real_cell_no%type,
                          strLabelNo               in      Ridata_instock_d.label_no%type,
                          strArticleNo             in      Ridata_instock_d.article_no%type,
                          dtProduceDate            in      stock_article_info.produce_date%type,
                          nPackingQty              in      Ridata_instock_d.packing_qty%type,
                          nRealQty                 in      Ridata_instock_d.real_qty%type,
                          strUserId                in      Ridata_instock_m.rgst_name%type,--上架人
                          strPaperUserId           in      Ridata_instock_m.rgst_name%type,--回单人
                          strTools                 in      stock_content_move.terminal_flag%type,
                          strResult                out     varchar2) is
      cursor v_GetInstockItem is
        select iid.instock_id,iid.owner_no,iid.cell_no,iid.cell_id,iid.article_no,iid.article_id,iid.dest_cell_id,
        iid.dest_cell_no,iid.article_qty,iid.real_qty,iid.real_cell_no,iid.packing_qty,iid.label_no,
        iid.sub_label_no,iiD.stock_type,iid.stock_value,iid.business_type,iim.untread_type,iim.class_type,iim.quality_flag
         from Ridata_instock_d iid,ridata_instock_m iim,stock_article_info sai
         where iid.enterprise_no=iim.enterprise_no and iid.enterprise_no=sai.enterprise_no
         and iid.enterprise_no=strEnterPriseNo and iim.warehouse_no=iid.warehouse_no and iim.instock_no=iid.instock_no
         and iid.article_no=sai.article_no and iid.article_id=sai.article_id
         and iid.warehouse_no=strWareHouseNo AND iid.instock_no=strInstockNo
         and iid.label_no=strLabelNo and iid.article_no=strArticleNo and iid.dest_cell_no=strDestCellNo
         AND iid.packing_qty=nPackingQty and sai.produce_date=dtProduceDate
         and iid.status<'13';
      v_strDeptNo           stock_content.dept_no%type;
      nRemainQty            stock_content.qty%type;--剩余数量
      nTempQty              stock_content.qty%type;--当次回单数量
      v_icount          integer;
      strOtype          cdef_defarea.o_type%type;
      v_nCellID         stock_content.cell_id%type;
      v_strRsvLabelFlag  wms_riordertype.rsv_label_flag%type;
      v_strOwnerNo       bdef_defowner.owner_no%type;
      v_strUntreadType   ridata_instock_m.untread_type%type;
      v_strClassType     ridata_instock_m.class_type%type;
      v_strQualityFlag   ridata_instock_m.quality_flag%type;
  begin
      strResult      := 'N|P_SaveInstock';


      nRemainQty:=nRealQty;
      v_icount:=0;

      select owner_no,untread_type,class_type,quality_flag
             into v_strOwnerNo,v_strUntreadType,v_strClassType,v_strQualityFlag
          from ridata_instock_m where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo
          and instock_no=strInstockNo;

      --获取单据类型配置的是否需要保留标签的标识 huangb 20160804
      PKLG_WMS_Public.p_GetRIdataOrder
      (strEnterPriseNo,strWareHouseNo,v_strOwnerNo,v_strUntreadType,v_strClassType,v_strQualityFlag,
       'RSV_LABEL_FLAG',v_strRsvLabelFlag,strResult);
      if substr(strResult,1,1)='N' then
        return;
      end if;

      /*改为通过公用方法获取 huangb 20160804
      --根据货主仓别级别对应的单据类型获取是否需要保留标签的标识
      begin
          select RSV_LABEL_FLAG into v_strRsvLabelFlag from wms_warehouse_riordertype where enterprise_no=strEnterPriseNo
                 and warehouse_no=strWareHouseNo and owner_no=v_strOwnerNo and untread_type=v_strUntreadType
                 and class_type=v_strClassType and quality_flag=v_strQualityFlag;
      exception when no_data_found then
          --获取货主级别对应的标识
          begin
              select RSV_LABEL_FLAG into v_strRsvLabelFlag from wms_owner_riordertype where enterprise_no=strEnterPriseNo
                     and owner_no=v_strOwnerNo and untread_type=v_strUntreadType
                     and class_type=v_strClassType and quality_flag=v_strQualityFlag;
          exception when no_data_found then
              --获取系统级别对应的标识
              begin
                  select RSV_LABEL_FLAG into v_strRsvLabelFlag from wms_riordertype where enterprise_no=strEnterPriseNo
                         and untread_type=v_strUntreadType
                         and class_type=v_strClassType and quality_flag=v_strQualityFlag;
              exception when no_data_found then
                  strResult:='N|[找不到对应的单据配置]';
                  return;
              end;
           end;
      end;*/

      for GetInstockItem in v_GetInstockItem loop
          v_icount:=v_icount+1;
          --获取部门编码
          begin
              select sc.dept_no into v_strDeptNo
                     from stock_content sc where sc.enterprise_no=strEnterPriseNo
                     and sc.warehouse_no=strWareHouseNo and sc.owner_no=GetInstockItem.owner_no
                     and sc.cell_no=GetInstockItem.cell_no and sc.cell_id=GetInstockItem.cell_id;
          exception when no_data_found then
              strResult:='N|获取库存信息失败';
              return;
          end;

          if nRemainQty>=GetInstockItem.article_qty then
             nTempQty:=GetInstockItem.article_qty;
          else
             nTempQty:=nRemainQty;
          end if;

          nRemainQty:=nRemainQty-nTempQty;

           --更新上架明细
          pkobj_ridata.P_UpdateInstock(strEnterPriseNo,strWareHouseNo,strInstockNo,GetInstockItem.instock_id,strInstockCellNo,
              nTempQty,strUserId,strPaperUserId,'13',strResult);

          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;

          --更新来源储位库存
          PKOBJ_STOCK.p_UpdtContent_qtyByCellID(strEnterPriseNo,strWareHouseNo,GetInstockItem.cell_id,GetInstockItem.cell_no,
             GetInstockItem.dest_cell_no,nTempQty,GetInstockItem.article_qty,strUserId,
             strInstockNo,strTools,strResult);

          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;

          --更新目的储位库存
          pkobj_stock.p_InstContent_qtyByCellID(strEnterPriseNo,strWareHouseNo,GetInstockItem.dest_cell_id,GetInstockItem.dest_cell_no,
            GetInstockItem.cell_no,nTempQty,GetInstockItem.article_qty,strUserId,
             strInstockNo,strTools,strResult);

          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;

          if nTempQty=0 then
              --修改可移库标识
              pkobj_stock.p_UpdtContent_Mvflag(strEnterPriseNo,strWareHouseNo,
                                               GetInstockItem.cell_no,
                                               GetInstockItem.cell_id,
                                               '1',
                                               strUserId,
                                               strResult);

              if (substr(strResult, 1, 1) = 'N') then
                return;
              end if;


              if v_strRsvLabelFlag='0' then
                  --将标签库存转为储位库存
                   pkobj_stock.p_UpdtContent_ContainerNo(strEnterPriseNo,strWareHouseNo,'N',
                        'N',GetInstockItem.cell_no,GetInstockItem.cell_id,
                        strUserId,v_nCellID,strResult);
                   if (substr(strResult, 1, 1) = 'N') then
                     return;
                   end if;
              end if;
          else
              --修改可移库标识
              pkobj_stock.p_UpdtContent_Mvflag(strEnterPriseNo,strWareHouseNo,
                                               GetInstockItem.dest_cell_no,
                                               GetInstockItem.dest_cell_id,
                                               '1',
                                               strUserId,
                                               strResult);

              if (substr(strResult, 1, 1) = 'N') then
                return;
              end if;


              --检查上架区域是否是保留容器的区域
              begin
                  select cd.o_type into strOtype
                  from cdef_defarea cd,cdef_defcell t where cd.enterprise_no=strEnterPriseNo
                         and cd.enterprise_no=t.enterprise_no
                         and cd.warehouse_no=strWareHouseNo and cd.ware_no=t.ware_no
                         and cd.warehouse_no=t.warehouse_no
                         and cd.area_no=t.area_no and t.cell_no=strDestCellNo;
              exception when no_data_found then
                  strResult:='N|获取上架储区的信息失败';
                  return;
              end;

             if strDestCellNo<>strInstockCellNo then--修改储位时，需将预计上架储位的库存移库到实际上架储位
                --更新来源储位库存
                pkobj_stock.p_UpdtContent_qtyByCellNo(strEnterPriseNo,strWareHouseNo,GetInstockItem.owner_no,GetInstockItem.article_no,
                  GetInstockItem.article_id,strDestCellNo,strInstockCellNo,GetInstockItem.packing_qty,
                  nTempQty,GetInstockItem.sub_label_no,GetInstockItem.stock_type,GetInstockItem.stock_value,
                  strUserId,strInstockNo,strTools,strResult);

                if (substr(strResult, 1, 1) = 'N') then
                  return;
                end if;

                --更新目的储位库存
                pkobj_stock.p_InstContent_qtyByCellNo(strEnterPriseNo,strWareHouseNo,GetInstockItem.owner_no,v_strDeptNo,GetInstockItem.article_no,
                   GetInstockItem.article_id,strInstockCellNo,strDestCellNo,GetInstockItem.packing_qty,
                   nTempQty,GetInstockItem.label_no,GetInstockItem.sub_label_no,GetInstockItem.stock_type,GetInstockItem.stock_value,
                    strUserId,strInstockNo,strTools,'1',v_nCellID,strResult);

                if (substr(strResult, 1, 1) = 'N') then
                  return;
                end if;
             end if;

              --判断是否保留容器号
             if  strOtype<>'P' or  (GetInstockItem.business_type<>'3' and GetInstockItem.business_type<>'6') or v_strRsvLabelFlag='0' then --3客户别，6B品\P保留标签
                 if strDestCellNo<>strInstockCellNo  then
                   pkobj_stock.p_UpdtContent_ContainerNo(strEnterPriseNo,strWareHouseNo,'N',
                        'N',strInstockCellNo,v_nCellID,
                        strUserId,v_nCellID,strResult);
                   if (substr(strResult, 1, 1) = 'N') then
                     return;
                   end if;
                 else
                   pkobj_stock.p_UpdtContent_ContainerNo(strEnterPriseNo,strWareHouseNo,'N',
                        'N',strDestCellNo,GetInstockItem.Dest_Cell_Id,
                        strUserId,v_nCellID,strResult);
                   if (substr(strResult, 1, 1) = 'N') then
                     return;
                   end if;
                 end if;
             end if;
         end if;
         if nRemainQty=0 then
            exit;
         end if;
         --标签追踪
      end loop;
      if v_icount=0 then
         strResult:='N|没有读取到上架明细';
         return;
      end if;


      select count(*) into v_iCount from ridata_instock_m iim where iim.enterprise_no=strEnterPriseNo
      and iim.warehouse_no=strWareHouseNo
      and iim.instock_no=strInstockNo and status='13';

      if v_icount=1 then--上架回单已完成，需要转历史
         pkobj_Ridata.P_InstockToHty(strEnterPriseNo,strWareHouseNo,strInstockNo,strResult);

          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;
      end if;

      strResult:='Y';
  end P_SaveInstock;

/*************************************************************************************************
     修改人：luozhiling
     日期：2013-10-20
     功能：电子标签更新上架明细

*************************************************************************************************/
  procedure P_UpdateDPSInstockitem(strEnterPriseNo  in      ridata_instock_m.enterprise_no%type,
                              strWareHouseNo    in          Ridata_instock_m.warehouse_no%type,
                              strInstockNo         in          Ridata_instock_m.instock_no%type,
                              strLabelNo           in          Ridata_instock_d.label_no%type,
                              strArticleNo         in          Ridata_instock_d.article_no%type,
                              strBarcode           in          stock_article_info.barcode%type,
                              nPackingQty          in          Ridata_instock_d.packing_qty%type,
                              nRealQty             in          Ridata_instock_d.real_qty%type,
                              strUserId            in          Ridata_instock_m.rgst_name%type,--上架人
                              strPaperUserId       in          Ridata_instock_m.rgst_name%type,--回单人
                              strTools              in         stock_content_move.terminal_flag%type,
                              strResult            out         varchar2) is
      cursor v_GetInstockItem is
        select iim.quality_flag, iid.instock_id,iid.owner_no,iid.cell_no,iid.cell_id,iid.article_no,iid.article_id,
        iid.dest_cell_id,iid.dest_cell_no,iid.article_qty,iid.real_qty,iid.real_cell_no,
        iid.packing_qty,iid.label_no,
        iid.sub_label_no,iiD.stock_type,iid.stock_value,iid.business_type,iid.operate_date,iid.batch_no,
        iid.supplier_no,iid.wave_no
         from Ridata_instock_d iid,ridata_instock_m iim
         where iid.enterprise_no=iim.enterprise_no
         and iid.enterprise_no=strEnterPriseNo and iim.warehouse_no=iid.warehouse_no
         and iim.instock_no=iid.instock_no
         and iid.warehouse_no=strWareHouseNo AND iid.instock_no=strInstockNo
         and iid.label_no=strLabelNo and iid.article_no=strArticleNo
         AND iid.packing_qty=nPackingQty
         and iid.article_qty-iid.real_qty>0;
      nRemainQty            stock_content.qty%type;--剩余数量
      nTempQty              stock_content.qty%type;--当次回单数量
      v_icount          integer;
      v_strRealLabelNo  ridata_instock_d.real_label_no%type;
      v_strRealSubLabelNo   ridata_instock_d.real_sub_label_no%type;
      v_strContainerNo      ridata_instock_d.label_no%type;
    strSessionID  varchar2(10);
  begin
      strResult      := 'N|P_UpdateDPSInstockitem';


      nRemainQty:=nRealQty;
      v_icount:=0;

      for GetInstockItem in v_GetInstockItem loop
          v_icount:=v_icount+1;

          if nRemainQty>=GetInstockItem.article_qty-GetInstockItem.real_qty then
             nTempQty:=GetInstockItem.article_qty-GetInstockItem.real_qty;
          else
             nTempQty:=nRemainQty;
          end if;

          nRemainQty:=nRemainQty-nTempQty;

          --获取标签
          begin
              select distinct nvl(iid.real_label_no,'N') into v_strRealLabelNo
                     from ridata_instock_D iid,ridata_instock_m iim
                   where iim.enterprise_no=iid.enterprise_no and iim.warehouse_no=iid.warehouse_no
                   and iim.instock_no=iid.instock_no and iim.quality_flag=GetInstockItem.quality_flag
                   and iid.enterprise_no=strEnterPriseNo and iid.warehouse_no=strWareHouseNo
                   and iid.supplier_no=GetInstockItem.supplier_no and iid.real_label_no<>'N'
                   and iid.dest_cell_no=GetInstockItem.dest_cell_no
                   and iid.wave_no = GetInstockItem.Wave_No
                   and iid.batch_no = GetInstockItem.Batch_No
                   and iid.status ='11' and rownum=1;

          exception when no_data_found then
              v_strRealLabelNo:='N';
          end;

          if  v_strRealLabelNo='N' then
               --若没有找到数据，新取号，并写此表
              --取P标签 只取一个标签
              pklg_wms_base.p_get_ContainerNoBase(strEnterPriseNo,strWareHouseNo,'B',strUserId,'D',1,'2','11',
                                                  v_strRealLabelNo,v_strContainerNo,strSessionID,strResult);

              if (substr(strResult, 1, 1) = 'N') then
                return;
              end if;
              v_strRealSubLabelNo:=v_strRealLabelNo;
          else
              v_strRealSubLabelNo:=v_strRealLabelNo;
          end if;



           --更新上架明细
          pkobj_ridata.P_UpdateDPSInstock(strEnterPriseNo,strWareHouseNo,strInstockNo,GetInstockItem.instock_id,GetInstockItem.dest_cell_no,
              v_strRealLabelNo,v_strRealSubLabelNo,nTempQty,strUserId,strPaperUserId,strResult);

          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;

         if nRemainQty=0 then
            exit;
         end if;
         --标签追踪
      end loop;
      if v_icount=0 then
         strResult:='N|[EEEEEE]';--没有读取到上架明细
         return;
      end if;
      strResult:='Y';
  end P_UpdateDPSInstockitem;
/*************************************************************************************************
     修改人：luozhiling
     日期：2014-6-20
     功能：电子标签上架回单
*************************************************************************************************/

  procedure P_DpsComfireInstock(strEnterPriseNo   in          ridata_instock_m.enterprise_no%type,
                                strWareHouseNo    in          Ridata_instock_m.warehouse_no%type,
                                strInstockCellNo  in          Ridata_instock_d.label_no%type,
                                strUserId         in          Ridata_instock_m.rgst_name%type,--上架人
                                strPaperUserId    in          Ridata_instock_m.rgst_name%type,--回单人
                                strTools          in         stock_content_move.terminal_flag%type,
                                strPrinterGroupNo in         ridata_check_m.printer_group_no%type,
                                strResult         out         varchar2) is
      cursor v_GetInstockItem is
        select iid.instock_no,iid.instock_id,iid.owner_no,iid.cell_no,iid.cell_id,iid.article_no,iid.article_id,
        iid.dest_cell_id,
        iid.dest_cell_no,iid.article_qty,iid.real_qty,iid.real_cell_no,iid.packing_qty,iid.label_no,
        iid.sub_label_no,iiD.stock_type,iid.stock_value,iid.business_type,iid.real_label_no,iid.real_sub_label_no
         from Ridata_instock_d iid,ridata_instock_m iim,stock_article_info sai
         where iid.enterprise_no=iim.enterprise_no and iid.enterprise_no=sai.enterprise_no
         and iid.enterprise_no=strEnterPriseNo and iim.warehouse_no=iid.warehouse_no
         and iim.instock_no=iid.instock_no
         and iid.article_no=sai.article_no and iid.article_id=sai.article_id
         and iid.warehouse_no=strWareHouseNo  and iid.real_cell_no=strInstockCellNo
         and iid.status='11' and iid.article_qty=iid.real_qty
         order by iid.instock_no,iid.article_no;
      v_strDeptNo           stock_content.dept_no%type;
      v_icount          integer;--未回单记录数
      nOutCellID         stock_content.cell_id%type;
      v_strPrtTask      ridata_instock_d.instock_no%type;
      v_strRealLabelNo  ridata_instock_d.real_label_no%type;
      v_nCount          integer;--循环数据记录数

  begin
      strResult      := 'N|P_DpsComfireInstock';

      v_icount:=0;
      v_nCount:=0;


      --锁定此储位对应的上架明细
      update ridata_instock_d t set t.status=t.status
             where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo
             and t.real_cell_no=strInstockCellNo
             and t.status='11' and t.real_qty>0;


      --首先将该储位未完全回单的明细剥离
      for p in (select * from Ridata_instock_d iid where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo
          and real_cell_no=strInstockCellNo and iid.status='11' and iid.article_qty-iid.real_qty>0
          and iid.real_qty>0
          order by iid.instock_no,iid.instock_id)
          loop

          pkobj_ridata.p_Insert_Instock_D(strEnterPriseNo,strWareHouseNo,p.owner_no,p.instock_no,p.instock_id,p.article_qty-p.real_qty,
             strUserId,'10',strResult);
          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;

          update ridata_instock_d t set t.article_qty=p.real_qty
                 where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo
                 and instock_no=p.instock_no and instock_id=p.instock_id;

      end loop;

      for GetInstockItem in v_GetInstockItem loop

          --获取部门编码
          begin
              select sc.dept_no into v_strDeptNo
                     from stock_content sc where sc.enterprise_no=strEnterPriseNo and sc.warehouse_no=strWareHouseNo
                     and sc.owner_no=GetInstockItem.owner_no
                     and sc.cell_no=GetInstockItem.cell_no and sc.cell_id=GetInstockItem.cell_id;
          exception when no_data_found then
              strResult:='N|获取库存信息失败';
              return;
          end;


          v_strRealLabelNo:=GetInstockItem.real_label_no;

          --更新来源储位库存
          PKOBJ_STOCK.p_UpdtContent_qtyByCellID(strEnterPriseNo,strWareHouseNo,GetInstockItem.cell_id,GetInstockItem.cell_no,
             GetInstockItem.dest_cell_no,GetInstockItem.real_qty,GetInstockItem.article_qty,strUserId,
             GetInstockItem.instock_no,strTools,strResult);

          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;

          --更新目的储位库存
          pkobj_stock.p_InstContent_qtyByCellID(strEnterPriseNo,strWareHouseNo,GetInstockItem.dest_cell_id,GetInstockItem.dest_cell_no,
            GetInstockItem.cell_no,GetInstockItem.real_qty,GetInstockItem.article_qty,strUserId,
             GetInstockItem.instock_no,strTools,strResult);

          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;

          --拆库存,扣减上架储位库存
          pkobj_stock.p_UpdtContentByCellID(strEnterPriseNo,strWareHouseNo,GetInstockItem.dest_cell_id,GetInstockItem.dest_cell_no,
             GetInstockItem.dest_cell_no,GetInstockItem.real_qty,strUserId,GetInstockItem.instock_no,'2',strResult);
          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;

          --增加封箱库存
          pkobj_stock.p_InstContent_qtyByCellNo(strEnterPriseNo,strWareHouseNo,GetInstockItem.owner_no,v_strDeptNo,GetInstockItem.ARTICLE_NO,
             GetInstockItem.article_id,GetInstockItem.dest_cell_no,GetInstockItem.dest_cell_no,GetInstockItem.packing_qty,
             GetInstockItem.real_qty,GetInstockItem.real_label_no,GetInstockItem.real_sub_label_no,GetInstockItem.stock_type,
             GetInstockItem.stock_value,strUserId,GetInstockItem.instock_no,'2','0',nOutCellID,strResult);

          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;

           --修改可移库标识
          pkobj_stock.p_UpdtContent_Mvflag(strEnterPriseNo,strWareHouseNo,
                                           strInstockCellNo,
                                           nOutCellID,
                                           '1',
                                           strUserId,
                                           strResult);
          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;


           pkobj_stock.p_UpdtContent_ContainerNo(strEnterPriseNo,strWareHouseNo,GetInstockItem.real_label_no,
                GetInstockItem.real_sub_label_no,strInstockCellNo,nOutCellID,
                strUserId,nOutCellID,strResult);
          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;


/*          pklg_rolocate.P_ridata_locate_recede(strEnterPriseNo,strWareHouseNo, GetInstockItem.real_label_no, GetInstockItem.article_no,
               GetInstockItem.Instock_No,GetInstockItem.Instock_Id,GetInstockItem.Real_Cell_No,nOutCellID,
               strUserId, strResult );

          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;*/

         --标签追踪
         --更新上架单状态
         pkobj_ridata.P_UpdateInstock(strEnterPriseNo,strWareHouseNo,GetInstockItem.instock_no,
             GetInstockItem.instock_id,GetInstockItem.dest_cell_no,GetInstockItem.article_qty,strUserId,
             strUserId,'13',strResult);
          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;

          select count(*) into v_iCount from ridata_instock_d iim where iim.enterprise_no=strEnterPriseNo
          and iim.warehouse_no=strWareHouseNo
          and iim.instock_no=GetInstockItem.instock_NO and status in ('10','12','11');

          if v_icount=0 then--上架回单已完成，需要转历史
             -- 更新上架单头档
             update ridata_instock_m t set T.status='13' where enterprise_no=strEnterPriseNo
                    and instock_no=GetInstockItem.instock_no
                    and warehouse_no=strWareHouseNo;

             pkobj_Ridata.P_InstockToHty(strEnterPriseNo,strWareHouseNo,GetInstockItem.instock_no,strResult);

              if (substr(strResult, 1, 1) = 'N') then
                return;
              end if;
          end if;
          v_nCount:=v_nCount+1;

      end loop;


      --打印封箱标签

      --写打印箱标签任务头档
      if v_nCount>0 then
          PKOBJ_PRINTTASK.p_insert_PrintGrouptaskmaster(strEnterPriseNo,strWareHouseNo,
                                              v_strRealLabelNo,
                                              0,
                                              CONST_REPORTID.RPT_UM_CHECKCLOSEBOX,
                                              strPrinterGroupNo,
                                              0,
                                              strUserId,
                                              v_strPrtTask,
                                              strResult);
          if substr(strResult, 1, 1) <> 'Y' then
            return;
          end if;


    /*      --写打印箱明细任务头档
          PKOBJ_PRINTTASK.p_insert_PrintGrouptaskmaster(strEnterPriseNo,strWareHouseNo,
                                              v_strRealLabelNo,
                                              0,
                                              CONST_REPORTID.RPT_UM_IntstockBoxItem,
                                              strPrinterGroupNo,
                                              0,
                                              strUserId,
                                              v_strPrtTask,
                                              strResult);
          if substr(strResult, 1, 1) <> 'Y' then
            return;
          end if;*/
      end if;


      strResult:='Y';
  end P_DpsComfireInstock;
 /*************************************************************************************************
     修改人：luozhiling
     日期：2013-10-20
     功能：验收确认,一单一验，可直接对返配单做结案,按汇总单做确认，需考虑一张汇总单对应多张验收单的情况
     打印返配验收单根据配置来写打印任务 huangb 20160816
*************************************************************************************************/
  procedure P_comfireCheck(strEnterPriseNo       in     ridata_untread_m.enterprise_no%type,
                           strWAREHOUSE_NO       in     ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码)
                           strS_untread_no       in     ridata_untread_sm.s_untread_no%type, --进货汇总单号
                           strUntreadType        in     ridata_untread_m.untread_type%type,
                           strClassType          in     ridata_untread_m.class_type%type,
                           strQualityFlag        in     ridata_untread_m.quality%type,
                           strOwnerNo            in     ridata_untread_m.owner_no%type,
                           strS_Check_no         in     ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                           strWorkerNo           in     ridata_check_pal_tmp.rgst_name%type, --操作人
                           strDockNo             in     ridata_check_m.dock_no%type,
                           strComfirFlag         in     ridata_check_m.check_tools%type,--强制做验收确认，做验收确认操作是传1，验收保存带确认时传0
                           strResult             Out    varchar2)is

    v_strPrtTask job_printtask_m.task_no%type;
    v_strPintCheckFlag       wms_riordertype.print_check_flag%type;--根据此判断是否打印验收单
    v_strAutoCheckComfirFlag Wms_Riordertype.Auto_Check_Comfir_Flag%type;--根据此判断验收时是否自动做验收确认，主要用于表单验收界面
    v_reportId               pntdef_report.report_id%type := 'N'; --报表ID huangb 20160816
  begin
     strResult:= 'N|P_comfireCheck';
        --获取配置信息
      --根据货主仓别级别对应的单据类型获取是否需要混单验收的标识
      begin
          select PRINT_CHECK_FLAG,AUTO_CHECK_COMFIR_FLAG
                 into v_strPintCheckFlag,v_strAutoCheckComfirFlag
                 from wms_warehouse_riordertype where enterprise_no=strEnterPriseNo
                 and warehouse_no=strWAREHOUSE_NO and owner_no=strOwnerNo and untread_type=strUntreadType
                 and class_type=strClassType and quality_flag=strQualityFlag;
      exception when no_data_found then
          --获取货主级别对应的标识
          begin
              select PRINT_CHECK_FLAG,AUTO_CHECK_COMFIR_FLAG
                     into v_strPintCheckFlag,v_strAutoCheckComfirFlag
                  from wms_owner_riordertype where enterprise_no=strEnterPriseNo
                     and owner_no=strOwnerNo and untread_type=strUntreadType
                     and class_type=strClassType and quality_flag=strQualityFlag;
          exception when no_data_found then
              --获取系统级别对应的标识
              begin
                  select PRINT_CHECK_FLAG,AUTO_CHECK_COMFIR_FLAG
                     into v_strPintCheckFlag,v_strAutoCheckComfirFlag
                     from wms_riordertype where enterprise_no=strEnterPriseNo
                         and untread_type=strUntreadType
                         and class_type=strClassType and quality_flag=strQualityFlag;
              exception when no_data_found then
                  strResult:='N|[找不到对应的单据配置]';
                  return;
              end;
           end;
      end;

     if strComfirFlag='0' then --若不是强制确认，则读取配置看是否要自动确认
        if v_strAutoCheckComfirFlag='0' then --不强制做验收确认，且不自动验收确认，则返回
           strResult:='Y|[成功]';
           return;
        end if;
     end if;

     --做品质转换
     P_QUALITY_CHANGETTH(strEnterPriseNo,strWAREHOUSE_NO, strS_untread_no,strS_Check_no,
            strWorkerNo,strDockNo, strResult);
     if (substr(strResult,1,1) = 'N') then
       return;
     end if;


     --更新验收单状态
     PKOBJ_RIDATA.P_CloseCheck(strEnterPriseNo,strWAREHOUSE_NO,strS_untread_no,strS_Check_nO,strDockNo,strWorkerNo,strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

   --根据验收明细写库存三级帐
    for GetCheckItem in (select icm.untread_type,icd.* from ridata_check_m icm,ridata_check_d icd
        where icm.enterprise_no=icd.enterprise_no and icm.warehouse_no=icd.warehouse_no
        and icm.check_no=icd.check_no and icm.enterprise_no=strEnterPriseNo and icm.warehouse_no=strWAREHOUSE_NO
        and icm.s_check_no=strS_Check_no) loop

        --写商品批次库存帐
        pkobj_stock.P_insertImportBatchStock(strEnterPriseNo,strWAREHOUSE_NO,GetCheckItem.owner_no,GetCheckItem.dept_no,
             GetCheckItem.article_no,GetCheckItem.quality,GetCheckItem.check_no,GetCheckItem.produce_date,
             GetCheckItem.expire_date,GetCheckItem.lot_no,GetCheckItem.rsv_batch1,GetCheckItem.rsv_batch2,
             GetCheckItem.rsv_batch3,GetCheckItem.rsv_batch4,GetCheckItem.rsv_batch5,GetCheckItem.rsv_batch6,
             GetCheckItem.rsv_batch7,GetCheckItem.rsv_batch8,GetCheckItem.barcode,GetCheckItem.packing_qty,
             GetCheckItem.check_qty,GetCheckItem.stock_type,GetCheckItem.stock_value,strWorkerNo,strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;
        --写库存三级帐
        pkobj_stock.P_InsertArticleStockList(strEnterPriseNo,strWAREHOUSE_NO,GetCheckItem.owner_no,GetCheckItem.dept_no,
             GetCheckItem.article_no,GetCheckItem.quality,GetCheckItem.produce_date,GetCheckItem.expire_date,
             GetCheckItem.lot_no,GetCheckItem.rsv_batch1,GetCheckItem.rsv_batch2,GetCheckItem.rsv_batch3,
             GetCheckItem.rsv_batch4,GetCheckItem.rsv_batch5,GetCheckItem.rsv_batch6,GetCheckItem.rsv_batch7,
             GetCheckItem.rsv_batch8,GetCheckItem.barcode,GetCheckItem.packing_qty,GetCheckItem.check_qty,
             GetCheckItem.stock_type,GetCheckItem.stock_value,1,GetCheckItem.untread_type,GetCheckItem.check_no,
             strWorkerNo,GetCheckItem.check_no,strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

    end loop;

     if v_strPintCheckFlag='1' then
      v_reportId := 'N';
      PKLG_WMS_Public.p_GetReportId
      (strEnterPriseNo,strWAREHOUSE_NO,CONST_REPORT_TYPE.RISC,
       'L',strS_Check_no,v_reportId,strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;

       --写打印任务
       PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterPriseNo,
                                           strWAREHOUSE_NO,
                                           strS_Check_no,
                                           0,
                                           v_reportId,
                                           --CONST_REPORTID.RPT_UM_CHECK,
                                           strDockNo,
                                           0,
                                           strWorkerNo,
                                           v_strPrtTask,
                                           strResult);
       if substr(strResult, 1, 1) <> 'Y' then
         return;
       end if;
     end if;

     --将进货单状态改为结案；
     PKOBJ_RIDATA.P_CloseImport(strEnterPriseNo,strWAREHOUSE_NO,strS_Check_nO,strWorkerNo,strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

     --将进货汇总单数据转历史
     PKOBJ_RIDATA.P_UntreadToHty(strEnterPriseNo,strWAREHOUSE_NO,strS_untread_no,strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

		 --作业单据做结转，不转历史 sunl 2016年7月25日
     /*--返配单、返配验收单、返配验收板明细转历史 huangb 20160518
     PKOBJ_RIDATA.P_Ridata_UnteradCheckHTY(strEnterPriseNo,strWAREHOUSE_NO,strOwnerNo,strS_untread_no,strWorkerNo,strResult);
     if (substr(strResult, 1, 1) = 'N') then
       return;
     end if;*/

     strResult:='Y|';

  end P_comfireCheck;

 /***********************************************************************************************
 修改人:luozhiling
 日期:2014-6-20
 功能：根据板号写标签数据、库存，上架指示
 ************************************************************************************************/
 procedure p_LabelLocate(strEnterPriseNo   in stock_label_m.enterprise_no%type,
                         strWareHouseNo    in stock_label_m.warehouse_no%type, --仓别
                         strLabelNo        in ridata_check_m.s_check_no%type, --汇总验收单号
                         strUser_ID        in stock_label_m.Rgst_Name%type, --操作人员
                         strCheckTool      in ridata_check_pal_tmp.check_tools%type,--验收工具
                         strPrintFlag      in ridata_check_m.check_tools%type,--是否打印：0：不打印，1：打印
                         strDestCellNo     in ridata_check_pal.cell_no%type,--指定上架储位
                         strLocateNo      OUT   ridata_locate_direct.locate_no%type,
                         strOutMsg         out varchar2) is
      strContainerType     stock_label_m.container_type%type; --标签类型
      v_strContainerNo       stock_label_m.container_no%type; --容器号
      strREPORT_ID         stock_label_m.report_id%type; --报表ID
      v_strCellNo            stock_content.cell_no%type; --暂存区储位
      v_strLocateNo        ridata_locate_direct.locate_no%type;--进货定位单号
      v_strDockNo          ridata_check_m.dock_no%type;
      v_strPrtTask         ridata_locate_direct.locate_no%type;
      v_strQualityFlag    ridata_check_pal.quality%type;

   begin

      strOutMsg        := 'N|p_LabelLocate';
      v_strContainerNo   := 'N';
      --获取暂存区储位
      begin
        select CDC.CELL_NO
          into v_strCellNo
          FROM CDEF_DEFAREA CDA, CDEF_DEFCELL CDC
         WHERE cda.enterprise_no=cdc.enterprise_no
           and cda.enterprise_no=strEnterPriseNo and CDA.warehouse_no = CDC.warehouse_no
           AND CDA.WARE_NO = CDC.WARE_NO
           AND CDA.AREA_NO = CDC.AREA_NO
           AND CDA.AREA_ATTRIBUTE = '1'
           AND (CDA.ATTRIBUTE_TYPE = '1' OR CDA.ATTRIBUTE_TYPE = '0')
           and CDA.warehouse_no=strWareHouseNo
           and rownum < 2;
      exception
        when no_data_found then
          strOutMsg := 'N|[E00100]';
          return;
      end;


      --取定位指示号；
      begin
        PKLG_WMS_BASE.p_getsheetno(strEnterPriseNo,strWareHouseNo,
                                   CONST_DOCUMENTTYPE.ODATAWO,
                                   v_strLocateNo,
                                   strOutMsg);
        if (strOutMsg is null or substr(strOutMsg, 1, 1) = 'N') then
          strOutMsg := 'N|[E00014]'; --取汇总验收单号错误!
          return;
        end if;
      end;

      strLocateNo := v_strLocateNo;
      --获取标签号
      begin
        select distinct icp.container_no, icp.dock_no
          into v_strContainerNo, v_strDockNo
          from ridata_check_pal icp
         where icp.enterprise_no=strEnterPriseNo and icp.warehouse_no = strWareHouseNo
           and icp.label_no = strLabelNo
           and icp.status='10'
           and rownum<=1;

      exception
        when no_data_found then
          strOutMsg := 'N|找不到板明细';
          return;
      end;
      --判断容器类型
      if substr(strLabelNo, 0, 1) = 'B' then
        strContainerType := 'B';
        strREPORT_ID     := CONST_REPORTID.IM_ID_DIVIDE_B;
      else
        strContainerType := 'P';
        strREPORT_ID     := CONST_REPORTID.B_I_INSTOCKP;
      end if;


      select nvl(min(quality),'0') into v_strQualityFlag from ridata_check_pal t
      where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo
      and t.label_no=strLabelNo;

      if v_strQualityFlag<='1' then --良品需要转正常商品入库

          --写标签头
          pkobj_label.proc_Insert_LabelMaster(strEnterPriseNo,strWareHouseNo,
                                              'N',
                                              'N',
                                              strLabelNo,
                                              v_strContainerNo,
                                              strContainerType,
                                              'N',
                                              v_strCellNo,
                                              'N',
                                              'N',
                                              'N',
                                              'N',
                                              'N',
                                              '0',
                                              'N',
                                              v_strDockNo,
                                              'N',
                                              strUser_ID,
                                              strREPORT_ID,
                                              'N',
                                              1,
                                              '1',
                                              '0',
                                              v_strContainerNo,
                                              '0',
                                              '1','N',
                                              strOutMsg);
          if substr(strOutMsg, 1, 1) = 'N' then
            return;
          end if;
      end if;

      if strPrintFlag='1' then

          --写打印任务头档
          PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterPriseNo,strWareHouseNo,
                                              strLabelNo,
                                              0,
                                              CONST_REPORTID.RPT_UM_CHECKBOX,
                                              v_strDockNo,
                                              0,
                                              strUser_ID,
                                              v_strPrtTask,
                                              strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;


          --写打印任务明细
          PKOBJ_PRINTTASK.p_insert_taskdetail(strEnterPriseNo,strWarehouseNo,v_strPrtTask,strLabelNo,1,1,strOutMsg);

          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
      end if;

      --根据板明细表库存
      PKOBJ_STOCK.p_Ridata_InsertPalStock(strEnterPriseNo,strWareHouseNo,
                                              strLabelNo,
                                              strCheckTool,
                                              strUser_ID,
                                              v_strLocateNo,
                                              strDestCellNo,
                                              strOutMsg);


      if substr(strOutMsg, 1, 1) = 'N' then
        return;
      end if;
      strOutMsg := 'Y|';
    exception
      when others then
        strOutMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
        return;

 end p_LabelLocate;
 /***********************************************************************************************
 修改人:luozhiling
 日期:2014-6-21
 功能：获取返配验收箱标签号
 ************************************************************************************************/
  procedure P_GetLabelNo
     (strEnterPriseNo         in                   ridata_untread_m.enterprise_no%type,
      strWarehouseNo          in                   ridata_untread_m.warehouse_no%type,
      strSupplierNo           in                   ridata_untread_d.supplier_no%type,
      strWorkerNo             in                   ridata_check_pal_tmp.rgst_name%type,
      strDockNo               in                   ridata_check_pal_tmp.dock_no%type,
      dtOperateDate           in                   cset_cell_supplier.operate_date%type,
      strLabelId            out                   ridata_check_pal_tmp.label_no%type,
      strLaebelNo           out                   stock_label_m.label_no%type,
      strResult               out                  varchar2)is
      v_strBatchNo            bset_defbatch.batch_no%type;
      v_strCellNo             cdef_defcell.cell_no%type;
      strContainNo  varchar2(24); --内部容器号
      strLabelNoTmp varchar2(24); --板号
      strSessionID  varchar2(10);

  begin
      --
      strResult := 'N|[P_GetLabelNo]';

      --锁定供应商对应关系表
      update cset_cell_supplier t set t.status=t.status
             where t.warehouse_no=strWarehouseNo and t.enterprise_no=strEnterPriseNo
             and t.supplier_no=strSupplierNo and t.use_type='1' and t.status='1' and t.operate_date=dtOperateDate;
      begin
          select rb.dps_cell_no,rb.batch_no,/*rb.EQUIPMENT_NO,*/ max(rb.label_id)
           into v_strCellNo ,v_strBatchNo,strLabelId
              from ridata_box rb
              where rb.enterprise_no=strEnterPriseNo and rb.warehouse_no=strWarehouseNo
              and rb.supplier_no=strSupplierNo
              and rb.operate_date=dtOperateDate
              and rb.status in ('0','1')
              group by rb.dps_cell_no,rb.batch_no;


       exception when no_data_found then
              insert into ridata_box(enterprise_no,warehouse_no,owner_no,operate_date,label_id,batch_no,device_no,
                  supplier_no,status,rgst_name,rgst_date,dps_cell_no)
                  select distinct strEnterPriseNo,strWarehouseNo,rb.owner_no,dtOperateDate,rb.label_id,rb.batch_no,
                    rb.device_no,strSupplierNo,'0',strWorkerNo,sysdate,rb.dps_cell_no
                  from ridata_box rb
                  where rb.enterprise_no=strEnterPriseNo and rb.warehouse_no=strWarehouseNo
                  and rb.supplier_no=strSupplierNo
                  and rb.operate_date=dtOperateDate
                  and rb.status='3' and rownum=1;

       --    strResult:='N|[E24226]';
         --  return;
      end;

      --锁定返配验收临时表，一个扫描台一个批次只存在一个箱号
      update ridata_check_pal_tmp t set t.status='10'
             where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWarehouseNo AND t.batch_no=v_strBatchNo
             and t.dock_no=strDockNo;

      if sql%rowcount>0 then
         --获取箱号信息
         begin
              select distinct label_no into strLaebelNo from ridata_check_pal_tmp t
              where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWarehouseNo
                and t.batch_no=v_strBatchNo AND dock_no=strDockNo
                and t.label_no<>'N' and rownum=1;
         exception when no_data_found then
             strLaebelNo:='';
         end ;
      end if;

      if strLaebelNo is null or strLaebelNo='' then --若strLaebelNo为空，需要取容器号
          --
          --取B标签 只取一个标签
          pklg_wms_base.p_get_ContainerNoBase(strEnterPriseNo,strWareHouseNo,'B',strWorkerNo,'D',1,'2','11',
                                              strLabelNoTmp,strContainNo,strSessionID,strResult);
          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;

           strLaebelNo:=strLabelNoTmp;

      end if;

      strResult:='Y|';

  end P_GetLabelNo;

  /*=====================================================================================
   insert to 20140621
  返配供应商分配储位（天天惠）
  ======================================================================================*/
    PROCEDURE p_RI_SupperAllotCell(strEnterPriseNo in ridata_untread_sm.enterprise_no%type,
                                 strwarehouse_no in ridata_untread_sm.warehouse_no%type, --仓别
                                 strowner_no     in ridata_untread_sm.owner_no%type,
                                 strSUntreadNo   in ridata_untread_sm.s_untread_no%type, --返配汇总单号
                                 strDockNo       in ridata_check_m.dock_no%type,--扫描台
                                 strDeviceNo     in device_divide_m.device_no%type,--扫描墙号
                                 strUser_Id      in ridata_untread_sm.rgst_name%type, --操作人员
                                 strQuality      in ridata_untread_d.quality%type,--界面传入的品质类型,不传默认为‘N';如果不为'N',那么根据传入值进行判断。
                                 strBoxCount     out integer,--需要的物流箱数目
                                 strFinishBox    out varchar2,
                                 strOutMsg       out varchar2) is

    n_count       number(10); --循环行数
    nAddBatchFlag integer;--是否新增批次 0: 不新增；1：新增
    n_batch_no    cset_cell_supplier.batch_no%type; --批次号
    n_cell_no     cset_cell_supplier.cell_no%type; --可用储位
    n_cell_num    number(10); --可用储位数
    nLabelId      number(10);
    v_strequipment_no        cdef_defcell_dps.DEVICE_NO%type;
    v_strCheckFlag           ridata_untread_m.status%type;--0: 已试算，可直接验收，1:系统拦截，2：需试算
    n_OldBatchNo             cset_cell_supplier.batch_no%type; --批次号
    v_DEVICE_NO              device_divide_m.device_no%type ;
    v_strWAVE_TYPE           BSET_WAVE_MANAGE.Wave_Type%type ;--从返配单类型取波次表批次类型。
    v_strWAVE_TYPE_tmp            varchar2(10) ;--当前扫描墙目前扫描的单据类型。
    v_strStatus                ridata_untread_mm.status%type;
    v_str_finish                  varchar2(1) ; --1:表示执行结案
    v_str_ri_wave_no        ridata_untread_mm.wave_no%type;--当前返配单已分配的波次号
    strQualityFlag          ridata_untread_m.quality%type;
    n_stockNum            number(10) ;--用来判断滞销品、过季品是不是按区或按巷道来分配分播墙格子号,0为区，其它为巷道

  begin
    strOutMsg     := 'N|[p_RI_SupperAllotCell]';
    nAddBatchFlag := 0;
    n_batch_no    := 0;
    n_cell_num    := 0;
    nLabelId:=1;
    v_strWAVE_TYPE :='' ;
    v_str_finish :='' ;
    strFinishBox :='0' ;
    --*****************************************************************************************
    --1.判断返配单实际的分配情况。
    --     A.取返配单对应的波次类型，为0时，说明返配单是次品单，不能使用扫描墙。
    --     B。首先判断分播墙号是否有效；
    --     C.判断当前返配单是不是已经分配有分播墙号；
    --     D。如果已经分播好对应的关系，那么判断新录入的墙号跟已经分配的墙号是否一致；

    --类型字段定义
    --清场 quality='0' and  class='1';
    --质量 quality='A' and  class='0';
    --滞销 quality='0' and  class='0';
    --过季 quality='1' and  class='0';
    --*****************************************************************************************
    --取返配单对应的波次类型，为0时，说明返配单是次品单，不能使用扫描墙。
    if strQuality ='N' or strQuality ='' then
        select pkobj_Ridata.f_get_untread_type(rum.quality,rum.class_type) WAVE_TYPE,quality
             into v_strWAVE_TYPE,strQualityFlag
                from  ridata_untread_sm rus,ridata_untread_m rum
        where rus.enterprise_no=rum.enterprise_no and  rus.warehouse_no=rum.warehouse_no
          and rus.owner_no=rum.owner_no and rus.untread_no=rum.untread_no
          and rus.enterprise_no= strEnterPriseNo and rus.warehouse_no=strwarehouse_no
          and rus.s_untread_no= strSUntreadNo  and rus.s_untread_no= strSUntreadNo;
        if   v_strWAVE_TYPE ='0' then
            strOutMsg:='N|[次品返配单不能使用扫描墙！]';
            return;
        end if ;
    else
        v_strWAVE_TYPE:=strQuality ;
    end if ;

    select count(1)  into n_count
      from ridata_untread_sm rus,
           ridata_untread_d  rud
     where rus.enterprise_no=rud.enterprise_no
       and rud.owner_no = rus.owner_no
       and rud.untread_no = rus.untread_no
       and rus.status in ('10', '11','12')
       and rud.status in ('10', '11','12')
       and rus.enterprise_no= strEnterPriseNo
       and rus.warehouse_no = strwarehouse_no
       and rus.s_untread_no = strSUntreadNo
       and rud.untread_qty-rud.check_qty>0 ;
    if n_count = 0 then
        strOutMsg:='N|[当前单号已经验收完成！]';
        return;
    end if ;


    --首先判断分播墙号是否有效；
    select count(1),nvl(max(ddm.cust_qty),0) into n_count,n_stockNum
    from device_divide_m ddm,device_divide_group ddg
    where ddm.enterprise_no=ddg.enterprise_no and ddm.warehouse_no=ddg.warehouse_no
    and ddg.use_type='2' and ddm.enterprise_no=strEnterPriseNo
    and ddm.warehouse_no=strwarehouse_no  and ddm.device_no=strDeviceNo ;
    if n_count = 0 then
        strOutMsg:='N|[当前扫描墙无效，请扫描员重新选择可行的扫描墙号！]';
        return;
    end if ;

    --判断当前返配单是不是已经分配有分播墙号；
    begin
       select case when rum.device_no is null or rum.device_no='' then '0' else rum.device_no end  device_no into v_DEVICE_NO
       from ridata_untread_mm rum where rum.enterprise_no= strEnterPriseNo
       and rum.warehouse_no=strwarehouse_no   and rum.s_untread_no= strSUntreadNo ;
       if v_DEVICE_NO <> '0' then
          IF v_DEVICE_NO <> strDeviceNo THEN
            strOutMsg:='N|[该返配单已经分配到'||v_DEVICE_NO||'号扫描墙，请到相应的扫描墙进行扫描！]';
            return;
          END IF ;
       end if ;
    end ;

    --判断当前扫描墙使用的类型是不是跟当前扫描单的类型一致
    begin
      select /*case when rum.quality='0' and  rum.class_type='1' then '3'
              when rum.quality='A' and  rum.class_type='0' then '4'
              when rum.quality='0' and  rum.class_type='0' then '5'
              when rum.quality='1' and  rum.class_type='0' then '6'  else '0'
              end*/  WAVE_TYPE into v_strWAVE_TYPE_tmp  from ridata_box rb--,ridata_untread_mm rum
      where /*rb.enterprise_no=rum.enterprise_no and rb.warehouse_no=rum.warehouse_no
      and rb.owner_no=rum.owner_no and rb.device_no=rum.device_no
      and*/ rb.enterprise_no=strEnterPriseNo
      and rb.warehouse_no=strwarehouse_no
      and rb.device_no=strDeviceNo and rb.status<='2'  and rownum=1;

    exception when no_data_found then
         v_strWAVE_TYPE_tmp :='9999' ;--'9999'说明还没有进行扫描墙分配
    end;

    --对已经分配的扫描墙类型进行判断
    if (v_strWAVE_TYPE <> v_strWAVE_TYPE_tmp) and
       v_strWAVE_TYPE_tmp <> '9999' then

      --扫描类型不一样时，要增加当前分播墙上的波次有没有结案
      for a in (select distinct rb.device_no, rb.wave_no, bd.status
                  from ridata_box rb, Bset_wave_manage bd
                 where rb.enterprise_no = bd.enterprise_no
                   and rb.warehouse_no = bd.warehouse_no
                   and rb.wave_no = bd.wave_no
                   and rb.device_no = strDeviceNo
                   and rb.enterprise_no = strEnterPriseNo
                   and rb.warehouse_no = strwarehouse_no
                   and rb.status <= '2') loop
        --循环读取该扫描墙号下的批次状态
        if a.status = '15' or a.status = '25' then
          --扫描结束或批次结束，则更新供应商储位对应关系表的状态
          --判断当前墙号，该结案批次是不是还有没有封箱的数据;
          --有封箱数据，调用封箱存储过程
          select count(1)
            into n_count
            from ridata_box rb
           where rb.enterprise_no = strEnterPriseNo
             and rb.warehouse_no = strwarehouse_no
             and rb.status <= '2'
             and rb.wave_no = a.wave_no
             and rb.device_no = a.device_no;
          if n_count > 0 then
            --************************调用封箱存储过程*****************************************
            PKLG_RIDATA.P_DeviceCloseBox_Main(strEnterPriseNo,
                                              strWareHouse_No,
                                              strOwner_No,
                                              strDeviceNo,
                                              a.wave_no,
                                              strUser_Id,
                                              strDockNo,
                                              strQualityFlag,
                                              'N',
                                              strOutMsg);
            if (substr(strOutMsg, 1, 1) = 'N') then
              return;
            end if;
            --更新汇总单头档的,要对该单值初始状态，重新试算
            update ridata_untread_mm t
               set t.wave_no = '', t.status = '10', t.Device_No = ''
             where t.enterprise_no = strEnterPriseNo
               and t.warehouse_no = strwarehouse_no
               and t.s_untread_no = strSUntreadNo;
            if sql%notfound then
              strOutMsg := 'N|[重新更新返配单状态有问题！]';
              return;
            end if;
            v_str_finish := '1';
          end if;

        else
          --先查看是否有未封箱数据
          select count(1)
            into n_count
            from ridata_check_pal_tmp icp
           where icp.enterprise_no = strEnterPriseNo
             and icp.warehouse_no = strwarehouse_no
             and icp.device_no = strDeviceNo;

          if n_count <= 0 then
            update ridata_untread_mm t
               set t.wave_no = '', t.status = '10', t.Device_No = ''
             where t.enterprise_no = strEnterPriseNo
               and t.warehouse_no = strwarehouse_no
               and t.device_no = strDeviceNo
               and t.wave_no = a.wave_no
               and t.status not in ('13', '16');

            insert into ridata_boxhty
              (enterprise_no,
               warehouse_no,
               owner_no,
               operate_date,
               wave_no,
               batch_no,
               label_id,
               device_no,
               supplier_no,
               style,
               status,
               dps_cell_no,
               quality,
               rgst_name,
               rgst_date,
               updt_name,
               updt_date,
               wave_type)
              select enterprise_no,
                     warehouse_no,
                     owner_no,
                     operate_date,
                     wave_no,
                     batch_no,
                     label_id,
                     device_no,
                     supplier_no,
                     style,
                     status,
                     dps_cell_no,
                     quality,
                     rgst_name,
                     rgst_date,
                     updt_name,
                     updt_date,
                     wave_type
                from ridata_box rb
               where rb.enterprise_no = strEnterPriseNo
                 and rb.warehouse_no = warehouse_no
                 and rb.wave_no = a.wave_no
                 and rb.device_no = strDeviceNo;

            delete from ridata_box rb
             where rb.enterprise_no = strEnterPriseNo
               and rb.warehouse_no = warehouse_no
               and rb.wave_no = a.wave_no
               and rb.device_no = strDeviceNo;

            v_str_finish := '2';
          ELSE
            v_str_finish:='1';
          end if;

        end if;
      end loop;
      if v_str_finish = '1' then
        strFinishBox := '1';
        strOutMsg    := 'Y|[该扫描墙号有结束的波次，已打印出封箱标签，请先处理封箱商品！]';
        return;
      else
        if v_str_finish <> '2' then
          strOutMsg := 'N|[当前扫描墙处理的单据类型跟刚扫描的返配单类型不一致，不能在该墙上分播！]';
          return;
        end if;
      end if;
    end if;

    --初始化n_count
    n_count := 0;



    --判断单号是否做试算
    select rum.status,case when rum.wave_no is null or rum.wave_no ='' then 'N' else rum.wave_no end wave_no
      into v_strStatus,v_str_ri_wave_no
      from ridata_untread_mm rum
     where rum.enterprise_no=strEnterPriseNo and rum.warehouse_no = strwarehouse_no
       and rum.s_untread_no = strSUntreadNo;

    if v_strStatus='13' or v_strStatus='16' then--订单结案或取消
       strOutMsg:='N|[E24224]';
       return;
    end if;

    --判断当前扫描墙波次号是否已经结案
    for a in (select distinct  rb.device_no,rb.wave_no,bd.status
        from ridata_box rb,Bset_wave_manage bd --cset_cell_supplier ccs,
             where /*rb.enterprise_no=ccs.enterprise_no and rb.warehouse_no=ccs.warehouse_no and rb.owner_no=ccs.owner_no
             and rb.wave_no=ccs.wave_no and rb.device_no=ccs.device_no
             and*/ rb.enterprise_no=bd.enterprise_no and rb.warehouse_no=bd.warehouse_no
             and rb.wave_no=bd.wave_no /*and ccs.use_type='1' and ccs.status='1' */
             and rb.device_no=strDeviceNo
             and  rb.enterprise_no=strEnterPriseNo and rb.warehouse_no=strwarehouse_no
             and rb.status<='2' ) loop
               --v_iCount:=v_iCount+1;
               --循环读取该扫描墙号下的批次状态
           if a.status='15' or a.status='25' then --扫描结束或批次结束，则更新供应商储位对应关系表的状态
               --判断当前墙号，该结案批次是不是还有没有封箱的数据;
               --有封箱数据，调用封箱存储过程
               select count(1)  into n_count from  ridata_box rb where rb.enterprise_no=strEnterPriseNo
               and rb.warehouse_no=strwarehouse_no
               and rb.status<='2' and rb.wave_no=a.wave_no and rb.device_no=a.device_no;
               if n_count>0  then
                   --************************调用封箱存储过程*****************************************
                   /*PKLG_RIDATA.P_ClosePalDivide_main(strEnterPriseNo,strWareHouse_No,strOwner_No
                                 ,'N','N','N',strUser_Id,strDockNo,strOutMsg );*/
                   PKLG_RIDATA.P_DeviceCloseBox_Main(strEnterPriseNo,strWareHouse_No,strOwner_No,strDeviceNo,
                              a.wave_no,strUser_Id,strDockNo,strQualityFlag,'N',strOutMsg) ;
                   if (substr(strOutMsg, 1, 1) = 'N') then
                      return;
                   end if ;
                   --更新汇总单头档的,要对该单值初始状态，重新试算
                   update ridata_untread_mm t set t.wave_no='',t.status='10',t.Device_No=''
                   where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strwarehouse_no
                         and t.s_untread_no=strSUntreadNo;
                   if sql%notfound then
                      strOutMsg:='N|[重新更新返配单状态有问题！]' ;
                      return ;
                   end if ;
                   v_str_finish :='1' ;
               end if ;
            end if ;
    end loop;

    if v_str_finish ='1' then
       strFinishBox:='1' ;
       strOutMsg:='Y|[该扫描墙号有结束的波次，已打印出封箱标签，请先处理封箱商品！]' ;
       return ;
    end if ;


/*    --************************判断该返配单是否已经分配*****************************************
    if v_strStatus='10' or v_strStatus='11' then--未资源试算
           --调用分配资源存储过程
           strOutMsg:='Y|[成功]';
           return;
    end if;*/
    --************************调用资源分配存储过程*****************************************
    pkobj_ridata.p_scan_calculate(strEnterPriseNo,strwarehouse_no,strSUntreadNo,
                                strDeviceNo,v_strWAVE_TYPE,strQualityFlag,
                                strUser_Id,v_str_ri_wave_no,n_stockNum,strBoxCount,strOutMsg);
    if (substr(strOutMsg, 1, 1) = 'N') then
      return;
    end if ;


    --检查返配单有没有经过试算
    /*pkobj_ridata.p_Check_calculate(strEnterPriseNo,strwarehouse_no,strSUntreadNo,strDeviceNo,v_strWAVE_TYPE,v_strCheckFlag,strOutMsg);
    if (substr(strOutMsg, 1, 1) = 'N') then
      return;
    else
       if v_strCheckFlag='0' then
          select count(distinct label_id) into strBoxCount from ridata_box where
                     enterprise_no=strEnterPriseNo and warehouse_no=strwarehouse_no
                     and dock_no=strDockNo and status='1'
                     and operate_date in(select calculate_date from ridata_untread_mm where
                     warehouse_no=strwarehouse_no and s_untread_no=strSUntreadNo);

          strOutMsg:='Y|[成功]';
          return;
       end if;
    end if;*/
    strOutMsg := 'Y|';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_RI_SupperAllotCell;

  --*********************************************************************************
  --获取扫描墙格子号信息（天天惠）
  --*********************************************************************************
  PROCEDURE p_GET_SCAN_LABEL_ID(strEnterPriseNo in ridata_untread_sm.enterprise_no%type,
                                 strwarehouse_no in ridata_untread_sm.warehouse_no%type, --仓别
                                 strowner_no     in ridata_untread_sm.owner_no%type,
                                 strSUntreadNo   in ridata_untread_sm.s_untread_no%type, --返配汇总单号
                                 strDeviceNo     in device_divide_m.device_no%type,--扫描墙号
                                 strArticleNo    in ridata_untread_d.article_no%type,
                                 strWave_no      in ridata_untread_mm.wave_no%type,
                                 --strStyle        in bdef_defarticle.rsv_strategy2%type,
                                 strlabel_id     out ridata_box.label_id%type,--需要的物流箱数目
                                 strOutMsg       out varchar2) is

    n_count       number(10); --循环行数
    nAddBatchFlag integer;--是否新增批次 0: 不新增；1：新增
    n_batch_no    cset_cell_supplier.batch_no%type; --批次号
    n_cell_no     cset_cell_supplier.cell_no%type; --可用储位
    n_cell_num    number(10); --可用储位数
    nLabelId      number(10);
    v_strequipment_no        cdef_defcell_dps.DEVICE_NO%type;
    v_strCheckFlag           ridata_untread_m.status%type;--0: 已试算，可直接验收，1:系统拦截，2：需试算
    n_OldBatchNo             cset_cell_supplier.batch_no%type; --批次号
    v_DEVICE_NO              device_divide_m.device_no%type ;
    v_strWAVE_TYPE           BSET_WAVE_MANAGE.Wave_Type%type ;--从返配单类型取波次表批次类型。
    v_strWAVE_TYPE_tmp           BSET_WAVE_MANAGE.Wave_Type%type ;--当前扫描墙目前扫描的单据类型。
    v_strStatus                ridata_untread_mm.status%type;
    v_str_finish                  varchar2(1) ; --1:表示执行结案
    v_str_ri_wave_no        ridata_untread_mm.wave_no%type;--当前返配单已分配的波次号
    strQualityFlag          ridata_untread_m.quality%type;
    strArea_no              cdef_defarea.area_no%type ;
    n_stockNum            number(10) ;--用来判断滞销品、过季品是不是按区或按巷道来分配分播墙格子号,0为区，其它为巷道

  begin
    strOutMsg     := 'N|[p_GET_SCAN_Cell_NO]';

    if strWave_no='' or strDeviceNo='' then
       strOutMsg:='N|[该返配单还没有分配扫描墙，请先分播！]';
       return;
    end if ;
    --判断单号是否做试算
    select rum.status,case when rum.quality='2' and  rum.class_type='1' then '3'
                when rum.quality='A' and  rum.class_type='0' then '4'
                when rum.quality='0' and  rum.class_type='0' then '5'
                when rum.quality='1' and  rum.class_type='0' then '6'  else '0'
                end  WAVE_TYPE
      into v_strStatus,v_strWAVE_TYPE
      from ridata_untread_mm rum
     where rum.enterprise_no=strEnterPriseNo and rum.warehouse_no = strwarehouse_no
       and rum.s_untread_no = strSUntreadNo ;

    if v_strStatus='13' or v_strStatus='16' then--订单结案或取消
       strOutMsg:='N|[E24224]';
       return;
    end if;

    select nvl(max(ddm.cust_qty),0) into n_stockNum from device_divide_m ddm,device_divide_group ddg
    where ddg.enterprise_no=ddm.enterprise_no and ddg.warehouse_no=ddm.warehouse_no
    and ddg.device_group_no=ddm.device_group_no and ddm.enterprise_no=strEnterPriseNo
    and ddm.warehouse_no=strwarehouse_no  and ddg.use_type='2'  and ddm.device_no=strDeviceNo ;

    --查询当前返配单扫描的商品所对应的扫描墙格子号
    --v_strWAVE_TYPE='3'要增加款式的判断
    if v_strWAVE_TYPE='3' then
       begin
         select  label_id into strlabel_id  from ridata_box rb--,ridata_untread_mm rum
          where/* rb.enterprise_no=rum.enterprise_no and rb.warehouse_no=rum.warehouse_no
          and rb.owner_no=rum.owner_no and rb.device_no=rum.device_no
          and*/ rb.enterprise_no=strEnterPriseNo
          and rb.warehouse_no=strwarehouse_no
          and rb.device_no=strDeviceNo and rb.wave_no=strWave_no and rb.wave_type=v_strWAVE_TYPE and rb.status<='2'
          and   exists (select 1 from bdef_defarticle   bda
          where rb.enterprise_no=bda.enterprise_no and rb.owner_no=bda.owner_no
          and rb.supplier_no=bda.supplier_no and rb.style=bda.rsv_attr2 and bda.enterprise_no= strEnterPriseNo
          and bda.owner_no=strowner_no   and bda.article_no=strArticleNo ) ;
       exception when no_data_found then
          strOutMsg:='N|[没有相应的分播数据，请确认扫描的商品是不是正确！]';
          return;
       end ;

    end if ;

    --v_strWAVE_TYPE='4'只判断供应商
    if v_strWAVE_TYPE='4' then
       begin
         select  label_id into strlabel_id  from ridata_box rb--,ridata_untread_mm rum
          where/* rb.enterprise_no=rum.enterprise_no and rb.warehouse_no=rum.warehouse_no
          and rb.owner_no=rum.owner_no and rb.device_no=rum.device_no
          and*/ rb.enterprise_no=strEnterPriseNo
          and rb.warehouse_no=strwarehouse_no
          and rb.device_no=strDeviceNo and rb.wave_no=strWave_no and rb.wave_type=v_strWAVE_TYPE and rb.status<='2'
          and  exists (select 1 from bdef_defarticle   bda
          where rb.enterprise_no=bda.enterprise_no and rb.owner_no=bda.owner_no
          and rb.supplier_no=bda.supplier_no --and rb.style=bda.rsv_attr2
          and bda.enterprise_no= strEnterPriseNo
          and bda.owner_no=strowner_no   and bda.article_no=strArticleNo ) ;
       exception when no_data_found then
          strOutMsg:='N|[没有相应的分播数据，请确认扫描的商品是不是正确！]';
          return;
       end  ;

    end if ;

    --v_strWAVE_TYPE='5' or v_strWAVE_TYPE='6'判断区域相同
    if v_strWAVE_TYPE='5' or v_strWAVE_TYPE='6'  then
       begin
         if n_stockNum =0 then
             select  label_id into strlabel_id  from ridata_untread_sm sm,ridata_untread_d d,ridata_untread_mm mm,
                     ridata_box rb,cdef_defcell cd
                  where sm.enterprise_no=d.enterprise_no and sm.enterprise_no=mm.enterprise_no
                  and sm.enterprise_no=rb.enterprise_no and sm.enterprise_no=cd.enterprise_no
                  and sm.warehouse_no=d.warehouse_no and sm.warehouse_no=mm.warehouse_no
                  and sm.warehouse_no=rb.warehouse_no and sm.warehouse_no=cd.warehouse_no
                  and sm.untread_no=d.untread_no and sm.s_untread_no=mm.s_untread_no
                  and mm.wave_no=rb.wave_no and mm.device_no=rb.device_no
                  and d.cell_no=cd.cell_no
                  and mm.s_untread_no=strSUntreadNo
                  and rb.enterprise_no=strEnterPriseNo
              and rb.warehouse_no=strwarehouse_no
              and rb.device_no=strDeviceNo and rb.wave_no=strWave_no and rb.wave_type=v_strWAVE_TYPE and rb.status<='2'
              and rb.dps_cell_no=cd.ware_no||cd.area_no --判断区域相同
              and d.article_no=strArticleNo;
         else
             select  label_id into strlabel_id  from ridata_untread_sm sm,ridata_untread_d d,ridata_untread_mm mm,
                     ridata_box rb,cdef_defcell cd
                  where sm.enterprise_no=d.enterprise_no and sm.enterprise_no=mm.enterprise_no
                  and sm.enterprise_no=rb.enterprise_no and sm.enterprise_no=cd.enterprise_no
                  and sm.warehouse_no=d.warehouse_no and sm.warehouse_no=mm.warehouse_no
                  and sm.warehouse_no=rb.warehouse_no and sm.warehouse_no=cd.warehouse_no
                  and sm.untread_no=d.untread_no and sm.s_untread_no=mm.s_untread_no
                  and mm.wave_no=rb.wave_no and mm.device_no=rb.device_no
                  and d.cell_no=cd.cell_no
                  and rb.enterprise_no=strEnterPriseNo
              and rb.warehouse_no=strwarehouse_no
              and mm.s_untread_no=strSUntreadNo
              and rb.device_no=strDeviceNo and rb.wave_no=strWave_no and rb.wave_type=v_strWAVE_TYPE and rb.status<='2'
              and rb.dps_cell_no=cd.ware_no||cd.area_no||to_char(floor((to_number(cd.stock_no)-1)/n_stockNum)) --判断区域相同
              and d.article_no=strArticleNo;
         end if ;

       exception when no_data_found then
          strOutMsg:='N|[没有相应的分播数据，请确认扫描的商品是不是正确！]';
          return;
       end  ;

    end if ;

    strOutMsg := 'Y|';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_GET_SCAN_LABEL_ID;
  /*************************************************************************************************
     修改人：hekl
     日期：2015-07-23
     功能：对次品和过季品做品质转换（天天惠）
*************************************************************************************************/
  procedure P_QUALITY_CHANGETTH(strEnterPriseNo       in     ridata_untread_m.enterprise_no%type,
                           strWAREHOUSE_NO       in     ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码)
                           strS_untread_no       in     ridata_untread_sm.s_untread_no%type, --进货汇总单号
                           strS_Check_no         in     ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                           strWorkerNo           in     ridata_check_pal_tmp.rgst_name%type, --操作人
                           strDockNo             in     ridata_check_m.dock_no%type,
                           strResult             Out    varchar2)is

    v_strQuality     ridata_untread_m.quality%type;--单据质量类型
    v_strOwnerNo     ridata_untread_m.owner_no%type;--货主
    strChange_No     org_quality_change_m.change_no%type;--品质转换单号
    strCheck_No      org_quality_change_m.change_no%type;--验收单号
    v_strS_Org_No    org_quality_change_d.s_org_no%type;--原机构号
    v_strD_Org_No    org_quality_change_d.s_org_no%type;--目的机构号
  begin
     strResult:= 'N|P_QUALITY_CHANGETTH';
     --对次品和过季品做品质转换
     select m.quality,m.owner_no,km.check_no,m.org_no
        into v_strQuality,v_strOwnerNo,strCheck_No,v_strS_Org_No
        from ridata_check_m km,ridata_untread_m m
        where km.enterprise_no=m.enterprise_no
        and km.warehouse_no=m.warehouse_no
        and km.untread_no=m.untread_no
        and km.enterprise_no=strEnterPriseNo
        and km.warehouse_no=strWAREHOUSE_NO
        and km.s_untread_no=strS_untread_no;

     if v_strQuality = '1' or v_strQuality = 'B' then

       --取目的机构号
       if v_strQuality ='1' then--过季
          begin
           select org_no into v_strD_Org_No
              from (select cdc.org_no
                      from cdef_defware cdc, cdef_defarea cda
                     where cdc.enterprise_no=cda.enterprise_no and
                       cdc.enterprise_no=strEnterPriseNo
                       and cdc.warehouse_no = cda.warehouse_no
                       and cdc.ware_no = cda.ware_no
                       and cda.area_usetype='1'
                       and cdc.warehouse_no = strWAREHOUSE_NO
                       and cda.area_quality='1'
                       and cda.Area_Attribute = '0'
                       and cda.attribute_type='0'
                       and cdc.org_no<>v_strS_Org_No
                       and rownum=1);
           exception when no_data_found then
             --strResult:='N|[取目的机构号失败]';
             return;
           end;

       else--次品
          begin
           select org_no into v_strD_Org_No
              from (select cdc.org_no
                      from cdef_defware cdc, cdef_defarea cda
                     where cdc.enterprise_no=cda.enterprise_no
                       and cdc.enterprise_no=strEnterPriseNo
                       and cdc.warehouse_no = cda.warehouse_no
                       and cdc.ware_no = cda.ware_no
                       and cda.area_usetype='2'
                       and cdc.warehouse_no = strWAREHOUSE_NO
                       and cda.Area_Attribute = '0'
                       and cda.attribute_type='0'
                       and cdc.org_no<>v_strS_Org_No
                       and rownum=1);
           exception when no_data_found then
               --strResult:='N|[取目的机构号失败]';
               return;
           end;
       end if;


       --写品质转换单头档
       PKOBJ_ADJ.P_Insert_QUALITY_CHANGE_m(strEnterPriseNo,strWAREHOUSE_NO,v_strOwnerNo,'0',
                                      strWorkerNo,strCheck_No,strChange_No ,strResult );
       if (substr(strResult, 1, 1) = 'N') then
           strResult:='N|[写品质转换单头档失败！]';
           return;
       end if ;
       --写品质转换单明细
       insert into org_quality_change_d(enterprise_no,
              warehouse_no,
              owner_no,
              change_no,
              row_id,
              article_no,
              packing_qty,
              s_org_no,
              d_org_no,
              change_qty,
              status,
              dept_no,
              stock_type,
              stock_value)
       select d.enterprise_no,d.warehouse_no,d.owner_no,strChange_No,
         d.row_id,d.article_no,d.packing_qty,v_strS_Org_No,v_strD_Org_No,
         d.check_qty,'10',d.dept_no, d.stock_type,d.stock_value
         from ridata_check_d d where d.enterprise_no=strEnterPriseNo
         and d.warehouse_no=strWAREHOUSE_NO and d.check_no=strCheck_No;
       if sql%notfound then
          strResult:='N|[写品质转换明细失败]';
          return;
       end if;

       --品质转换回单
       PKOBJ_ADJ.P_Update_QUALITY_CHANGE_m(strEnterPriseNo,strWAREHOUSE_NO,
               v_strOwnerNo,strChange_No, strWorkerNo, strResult);
       if (substr(strResult,1,1) = 'N') then
          return;
       end if;

       update ORG_QUALITY_CHANGE_d t set t.real_qty=t.change_qty,t.status='13'
       where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWAREHOUSE_NO
              and t.owner_no=v_strOwnerNo and t.change_no=strChange_No and t.status='10';

     end if;
     strResult:='Y|';

  end P_QUALITY_CHANGETTH;

 /*************************************************************************************************
     修改人：hekl
     日期：2015-07-23
     功能：1、对次品和过季品做品质转换（天天惠）
           2、验收确认,一单一验，可直接对返配单做结案
*************************************************************************************************/
  procedure P_comfireCheckTTH(strEnterPriseNo       in     ridata_untread_m.enterprise_no%type,
                           strWAREHOUSE_NO       in     ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码)
                           strS_untread_no       in     ridata_untread_sm.s_untread_no%type, --进货汇总单号
                           strUntreadType        in     ridata_untread_m.untread_type%type,
                           strClassType          in     ridata_untread_m.class_type%type,
                           strQualityFlag        in     ridata_untread_m.quality%type,
                           strOwnerNo            in     ridata_untread_m.owner_no%type,
                           strS_Check_no         in     ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                           strWorkerNo           in     ridata_check_pal_tmp.rgst_name%type, --操作人
                           strDockNo             in     ridata_check_m.dock_no%type,
                           strComfirFlag         in     ridata_check_m.check_tools%type,--强制做验收确认，做验收确认操作是传1，验收保存带确认时传0
                           strResult             Out    varchar2)is
  begin
     strResult:= 'N|P_comfireCheckTTH';

      --验收确认
      P_comfireCheck(strEnterPriseNo,strWAREHOUSE_NO,strS_untread_no,strUntreadType,strClassType,strQualityFlag,
          strOwnerNo,strS_Check_no,strWorkerNo,strDockNo,strComfirFlag,strResult);
      if substr(strResult,1,1)='N' then
        return;
      end if;

     strResult:='Y|';

  end P_comfireCheckTTH;
  /*********************************************************************************88
  功能说明： 电子标签扫描标签时的储位校验
             2015.9.11
  ***********************************************************************************/
  procedure P_CheckDpsDeviceNo(strEnterPriseNo       in     ridata_untread_m.enterprise_no%type,
                           strWAREHOUSE_NO       in     ridata_untread_m.WAREHOUSE_NO%type, --仓库编码)
                           strDpsArea            in     cdef_defcell_dps.dps_area%type, --电子标签小区
                           strStockNo            in     cdef_defcell_dps.stock_no%type,
                           strUseType            in     cdef_defcell_dps.use_type%type,
                           strCtrlNo             in     cdef_defcell_dps.ctrl_no%type,--控制箱号
                           strLabelNo            in     ridata_instock_d.label_no%type,--分播标签号
                           strResult             Out    varchar2)is
      v_strdWaveNo          ridata_instock_d.wave_no%type;--
      v_strdBatchNo         ridata_instock_d.batch_no%type;
      v_strdDeviceNo        cdef_defcell_dps.device_no%type;
      v_strsWaveNo          ridata_instock_d.wave_no%type;
      v_strsBatchNo         ridata_instock_d.batch_no%type;
      v_strsDeviceNo        cdef_defcell_dps.device_no%type;
  begin
       strResult:='N|[P_CheckDpsDeviceNo]';

       --校验此标签是否存在
       begin
            select distinct t.wave_no,t.batch_no,cdd.device_no
                into v_strdWaveNo,v_strdBatchNo,v_strdDeviceNo
                   from ridata_instock_d t,cdef_defcell_dps cdd
                   where t.enterprise_no=cdd.enterprise_no and t.warehouse_no=cdd.warehouse_no
                   and t.enterprise_no=strEnterPriseNo
                   AND t.warehouse_no=strWAREHOUSE_NO and t.label_no=strLabelNo
                   and t.dest_cell_no=cdd.cell_no and cdd.use_type=strUseType;
       exception when no_data_found then
           strResult:='N|[' ||strLabelNo || '该标签不存在]';
           return;
       end;

       --获取该分播墙当前的波次、批次
       begin
            select distinct t.wave_no,t.batch_no,cdd.device_no
                into v_strsWaveNo,v_strsBatchNo,v_strsDeviceNo
                   from ridata_instock_d t,cdef_defcell_dps cdd
                   where t.enterprise_no=cdd.enterprise_no and t.warehouse_no=cdd.warehouse_no
                   and t.enterprise_no=strEnterPriseNo
                   AND t.warehouse_no=strWAREHOUSE_NO and t.dest_cell_no=cdd.cell_no
                   and t.real_qty > 0
                   and cdd.use_type=strUseType
                   and cdd.dps_area=strDpsArea and cdd.stock_no=strStockNo
                   and cdd.ctrl_no=strCtrlNo and t.status in('11');
       exception when no_data_found then
                 strResult:='Y|[]';
           return;
       end;

       if (v_strsWaveNo<>v_strdWaveNo) or (v_strsBatchNo<>v_strdBatchNo)
          or (v_strdDeviceNo<>v_strsDeviceNo) then
          strResult:='N|[波次、批次和分播墙不匹配]';
          return;
       end if;

       strResult:='Y|[]';
     end P_CheckDpsDeviceNo;


 procedure Proc_RIData_Locate_Tmp(strEnterpriseNo in ridata_untread_m.enterprise_no%type,
                                  strWarehouseNo  in ridata_untread_m.warehouse_no%type,
                                  strOwnerNo      in ridata_untread_m.owner_no%type,
                                  strSUntreadNo   in ridata_untread_mm.s_untread_no%type,
                                  strOutMsg       out varchar2) is
   v_strCellNo         ridata_untread_d.cell_no%type;
   v_strTmpCell        ridata_untread_d.cell_no%type;
   v_strAbnormalCellNo ridata_untread_d.cell_no%type;
   v_nCount            integer; --明细统计
   v_nRuleCount        integer; --策略统计
 begin
   strOutMsg    := 'N|[Proc_RIData_Locate_Tmp]';
   v_strCellNo  := 'N';
   v_strTmpCell := 'N';
   v_nCount     := 0;
   v_nRuleCount := 0;
   --获取异常储位
   begin
     select cell_no
       into v_strAbnormalCellNo
       from (select CDC.CELL_NO
               from cdef_defcell cdc, cdef_defarea cdd
              where cdc.enterprise_no = cdd.enterprise_no
                and cdc.enterprise_no = strEnterPriseNo
                and cdc.warehouse_no = cdd.warehouse_no
                and cdc.ware_no = cdd.ware_no
                and cdc.area_no = cdd.area_no
                AND CDC.CELL_STATUS = '0'
                AND CDC.CHECK_STATUS = 0
                and cdd.AREA_ATTRIBUTE = '0'
                and cdd.AREA_USETYPE = '5'
                and cdd.warehouse_no = strWareHouseNo
              order by CDC.CELL_NO)
      where rownum <= 1;
   exception
     when no_data_found then
       strOutMsg := 'N|[E21706]'; --获取异常区储位失败
       return;
   end;
   --获取商品和策略
   for p in (select distinct d.article_no, w.strategy_id
               from ridata_untread_mm mm,
                    ridata_untread_sm sm,
                    ridata_untread_m  m,
                    ridata_untread_d  d,
                    bdef_defarticle   bda,
                    wms_defstrategy   w
              where mm.s_untread_no = sm.s_untread_no
                and mm.enterprise_no = sm.enterprise_no
                and mm.warehouse_no = sm.warehouse_no
                and mm.owner_no = sm.owner_no
                and sm.enterprise_no = m.enterprise_no
                and sm.warehouse_no = m.warehouse_no
                and sm.owner_no = m.owner_no
                and sm.untread_no = m.untread_no
                and m.enterprise_no = d.enterprise_no
                and m.warehouse_no = d.warehouse_no
                and m.owner_no = d.owner_no
                and m.untread_no = d.untread_no
                and d.enterprise_no = bda.enterprise_no
                and d.owner_no = bda.owner_no
                and d.article_no = bda.article_no
                and bda.ri_strategy = w.strategy_id
                and w.strategy_type = 'RI'
                and m.status not in ('13', '16')
                and mm.enterprise_no = strEnterpriseNo
                and mm.warehouse_no = strWarehouseNo
                and mm.owner_no = strOwnerNo
                and mm.s_untread_no = strSUntreadNo) loop
     v_nCount     := v_nCount + 1;
     v_nRuleCount := 0;
     --获取策略
     for rule in (select d.rule_id
                    from wms_defrule t, wms_defstrategy_d d
                   where t.strategy_type = d.strategy_type
                     and t.rule_id = d.rule_id
                     and t.strategy_type = 'RI'
                     and d.strategy_id = p.strategy_id
                   order by d.rule_order) loop
       v_nRuleCount := v_nRuleCount + 1;
       /*1 查找拆零拣货位
       2 查找整箱拣货位
       3 查找有库存的拆零拣货区储位
       4 查找有库存的整箱拣货区储位
       5 进异常区*/
       if rule.rule_id = 1 then
         --1查找拆零拣货位
         begin
           select a.cell_no
             into v_strTmpCell
             from cset_cell_article a
            where a.enterprise_no = strEnterpriseNo
              and a.warehouse_no = strWarehouseNo
              and a.owner_no = strOwnerNo
              and a.article_no = p.article_no
              and a.pick_type = 'B';
         exception
           when no_data_found then
             v_strTmpCell := 'N';
         end;
       elsif rule.rule_id = 2 then
         --2查找整箱拣货位
         begin
           select a.cell_no
             into v_strTmpCell
             from cset_cell_article a
            where a.enterprise_no = strEnterpriseNo
              and a.warehouse_no = strWarehouseNo
              and a.owner_no = strOwnerNo
              and a.article_no = p.article_no
              and a.pick_type = 'C';
         exception
           when no_data_found then
             v_strTmpCell := 'N';
         end;
       elsif rule.rule_id = 3 then
         --3查找有库存的拆零拣货区储位
         begin
           select cell_no
             into v_strTmpCell
             from (select c.cell_no, sum(c.qty - c.outstock_qty)
                     from stock_content c,
                          cdef_defarea  cda,
                          cdef_defcell  cdc
                    where c.enterprise_no = cdc.enterprise_no
                      and c.warehouse_no = cdc.warehouse_no
                      and c.cell_no = cdc.cell_no
                      and cdc.enterprise_no = cda.enterprise_no
                      and cdc.warehouse_no = cda.warehouse_no
                      and cdc.ware_no = cda.ware_no
                      and cdc.area_no = cda.area_no
                      AND CDC.CELL_STATUS = '0'
                      AND CDC.CHECK_STATUS = 0
                      and cda.o_type = 'B'
                      and cda.area_pick = '1'
                      and cda.AREA_USETYPE in ('1', '6')
                      and cda.AREA_ATTRIBUTE = '0'
                      and c.enterprise_no = strEnterpriseNo
                      and c.warehouse_no = strWarehouseNo
                      and c.owner_no = strOwnerNo
                      and c.article_no = p.article_no
                    group by c.cell_no
                    order by sum(c.qty - c.outstock_qty))
            where rownum = 1;
         exception
           when no_data_found then
             v_strTmpCell := 'N';
         end;
       elsif rule.rule_id = 4 then
         --4查找有库存的整箱拣货区储位
         begin
           select cell_no
             into v_strTmpCell
             from (select c.cell_no, sum(c.qty - c.outstock_qty)
                     from stock_content c,
                          cdef_defarea  cda,
                          cdef_defcell  cdc
                    where c.enterprise_no = cdc.enterprise_no
                      and c.warehouse_no = cdc.warehouse_no
                      and c.cell_no = cdc.cell_no
                      and cdc.enterprise_no = cda.enterprise_no
                      and cdc.warehouse_no = cda.warehouse_no
                      and cdc.ware_no = cda.ware_no
                      and cdc.area_no = cda.area_no
                      AND CDC.CELL_STATUS = '0'
                      AND CDC.CHECK_STATUS = 0
                      and cda.o_type = 'C'
                      and cda.area_pick = '1'
                      and cda.AREA_USETYPE in ('1', '6')
                      and cda.AREA_ATTRIBUTE = '0'
                      and c.enterprise_no = strEnterpriseNo
                      and c.warehouse_no = strWarehouseNo
                      and c.owner_no = strOwnerNo
                      and c.article_no = p.article_no
                    group by c.cell_no
                    order by sum(c.qty - c.outstock_qty))
            where rownum = 1;
         exception
           when no_data_found then
             v_strTmpCell := 'N';
         end;
       elsif rule.rule_id = 5 then
         --5进异常区
         v_strTmpCell := v_strAbnormalCellNo;
       end if;
       --若找到货位 则跳出循环
       if v_strTmpCell is not null and v_strTmpCell <> 'N' then
         goto NextArt;
       end if;
     end loop;
     if v_nRuleCount = 0 then
       strOutMsg := 'N|[商品' || p.article_no || '未维护返配策略!]';
       return;
     end if;
     <<NextArt>>
     null;
     v_strCellNo := v_strTmpCell;
     --更新返配明细对应商品的储位
     update ridata_untread_d d
        set d.cell_no = v_strCellNo
      where d.enterprise_no = strEnterpriseNo
        and d.owner_no = strOwnerNo
        and d.warehouse_no = strWarehouseNo
        and d.article_no = p.article_no
        and exists (select 1
               from ridata_untread_sm sm
              where sm.enterprise_no = d.enterprise_no
                and sm.warehouse_no = d.warehouse_no
                and sm.owner_no = d.owner_no
                and sm.untread_no = d.untread_no
                and sm.s_untread_no = strSUntreadNo)
        and d.cell_no = 'N';
   end loop;
   if v_nCount = 0 then
     strOutMsg := 'N|[单据不存在或者已完成!]';
     return;
   end if;
   strOutMsg := 'Y';
 exception
   when others then
     strOutMsg := 'N|' || SQLERRM ||
                  substr(dbms_utility.format_error_backtrace, 1, 256);
 end Proc_RIData_Locate_Tmp;

   /********************************************************************************************
   功能说明：特殊的返配验收封箱、上架定位、发单和自动回单
             此流程是特殊流程，不根据系统配置来处理

   ********************************************************************************************/
   procedure P_SpecialCloseBoxAndInstock(strEnterPriseNo in ridata_check_pal_tmp.enterprise_no%type,
                                strWareHouseNo  in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                strOwnerNo      in ridata_check_pal_tmp.owner_no%type, --委托业主编码
                                strsUntreadNo   in ridata_check_m.s_untread_no%type, --进货汇总单号
                                strsCheckNo     in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                strLabelNo      in ridata_check_pal_tmp.label_no%type, --板号
                                strWorkerNo     in ridata_check_pal_tmp.rgst_name%type, --操作人
                                strDestCellNo   in cdef_defcell.cell_no%type,
                                strDockNo       iN ridata_check_m.dock_no%type,
                                strPrintFlag    in job_printtask_m.back_flag%type,--打印标识，0：不打印，1：打印表单，2：打印标签
                                strResult       out varchar2) is
       v_strLocateNo            ridata_locate_direct.locate_no%type;
       v_strInStockNo           ridata_instock_m.instock_no%type;
       v_strUntreadType         ridata_untread_m.untread_type%type;
       v_strClassType           ridata_untread_m.class_type%type;
       v_strQualityFlag         ridata_untread_m.quality%type;
   begin
        strResult:='N|[P_SpecialCloseBoxAndInstock]';

      P_CheckCloseBoxCell(strEnterPriseNo,strWareHouseNo,strOwnerNo,strsUntreadNo,strsCheckNo,strDestCellNo,strResult);
      if substr(strResult,1,1)='N' then
         return;
      end if;


      P_CheckFixPal(strEnterPriseNo,strWareHouseNo,strOwnerNo,strsUntreadNo,strsCheckNo,strLabelNo,strWorkerNo,
              strResult);
      if substr(strResult,1,1)='N' then
         return;
      end if;



      p_Labellocate(strEnterPriseNo,strWareHouseNo,strLabelNo,strWorkerNo,'1','1',strDestCellNo,v_strLocateNo,strResult);
      if substr(strResult,1,1)='N' then
         return;
      end if;


      PKLG_RILOCATE.p_locate_main(strEnterPriseNo,strWareHouseNo,strOwnerNo,v_strLocateNo,strDockNo,strWorkerNo,strResult);
      if substr(strResult,1,1)='N' then
        return;
      end if;

      --判断走进货还是返配上架
      begin
          select rum.quality into v_strQualityFlag from ridata_check_m icm,ridata_untread_m rum
          where icm.enterprise_no=rum.enterprise_no and icm.warehouse_no=rum.warehouse_no
          and icm.untread_no=rum.untread_no
          and icm.enterprise_no=strEnterPriseNo and icm.warehouse_no=strWareHouseNo
          and icm.s_untread_no=strsUntreadNo and icm.s_check_no=strsCheckNo;
      exception when no_data_found then
          strResult:='N|[找不到对应的返配单]';
          return;
      end;

      if v_strQualityFlag='0' then
         --进货上架回单
         begin
             select iim.instock_no into v_strInStockNo  from idata_instock_m iim where iim.enterprise_no=strEnterPriseNo
             and iim.warehouse_no=strWareHouseNo and iim.locate_no=v_strLocateNo;
         exception when no_data_found then
            strResult:='N|[找不到对应的上架单]';
            return;
         end;

         PkLG_Idata.P_saveInstockAll(strEnterpriseNo,strWareHouseNo,v_strInStockNo,strWorkerNo,strWorkerNo,1,strResult);
          if substr(strResult,1,1)='N' then
            return;
          end if;
      else
         --返配上架发单
          pkobj_ridata.P_insertInstock(strEnterPriseNo,strWareHouseNo,strWorkerNo,v_strLocateNo,strDockNo,'0',v_strInStockNo,strResult);
          if substr(strResult,1,1)='N' then
            return;
          end if;

          for p in(select iid.owner_no, sai.produce_date,sai.expire_date,sai.lot_no,sai.quality,sai.rsv_batch1,sai.rsv_batch2,
               sai.rsv_batch3,sai.rsv_batch4,sai.rsv_batch5,sai.rsv_batch6,sai.rsv_batch7,sai.rsv_batch8,
               iid.instock_no,iid.cell_no,iid.article_no,iid.dest_cell_no,iid.label_no,iid.packing_qty,sum(iid.article_qty) article_qty
               from ridata_instock_d iid,stock_article_info sai where iid.warehouse_no=strWarehouseNo
               and iid.enterprise_no=strEnterpriseNo and iid.instock_no=v_strInStockNo and iid.status='10'
               and iid.article_no=sai.article_no and iid.article_id=sai.article_id
               group by iid.owner_no,sai.produce_date,sai.expire_date,sai.lot_no,sai.quality,sai.rsv_batch1,sai.rsv_batch2,
               sai.rsv_batch3,sai.rsv_batch4,sai.rsv_batch5,sai.rsv_batch6,sai.rsv_batch7,sai.rsv_batch8,
               iid.instock_no,iid.cell_no,iid.article_no,iid.dest_cell_no,iid.label_no,iid.packing_qty) loop
               --上架回单
               P_SpecialSaveInstock(strEnterpriseNo,strWareHouseNo,v_strInStockNo,p.dest_cell_no,p.dest_cell_no,
                   p.label_no,p.article_no,p.produce_date,p.packing_qty,
                   p.article_qty,strWorkerNo,strWorkerNo,'1',strResult);

              if (substr(strResult, 1, 1) = 'N') then
                return;
              end if;
           end loop;
      end if;

      strResult:='Y|[]';
   end P_SpecialCloseBoxAndInstock;

/*************************************************************************************************
     功能说明：特殊回单流程，
               不根据单据配置保留标签
*************************************************************************************************/
  procedure P_SpecialSaveInstock(strEnterPriseNo          in      ridata_instock_m.enterprise_no%type,
                          strWareHouseNo           in      Ridata_instock_m.warehouse_no%type,
                          strInstockNo             in      Ridata_instock_m.instock_no%type,
                          strDestCellNo            in      Ridata_instock_d.dest_cell_no%type,
                          strInstockCellNo         in      Ridata_instock_d.real_cell_no%type,
                          strLabelNo               in      Ridata_instock_d.label_no%type,
                          strArticleNo             in      Ridata_instock_d.article_no%type,
                          dtProduceDate            in      stock_article_info.produce_date%type,
                          nPackingQty              in      Ridata_instock_d.packing_qty%type,
                          nRealQty                 in      Ridata_instock_d.real_qty%type,
                          strUserId                in      Ridata_instock_m.rgst_name%type,--上架人
                          strPaperUserId           in      Ridata_instock_m.rgst_name%type,--回单人
                          strTools                 in      stock_content_move.terminal_flag%type,
                          strResult                out     varchar2) is
      cursor v_GetInstockItem is
        select iid.instock_id,iid.owner_no,iid.cell_no,iid.cell_id,iid.article_no,iid.article_id,iid.dest_cell_id,
        iid.dest_cell_no,iid.article_qty,iid.real_qty,iid.real_cell_no,iid.packing_qty,iid.label_no,
        iid.sub_label_no,iiD.stock_type,iid.stock_value,iid.business_type,iim.untread_type,iim.class_type,iim.quality_flag
         from Ridata_instock_d iid,ridata_instock_m iim,stock_article_info sai
         where iid.enterprise_no=iim.enterprise_no and iid.enterprise_no=sai.enterprise_no
         and iid.enterprise_no=strEnterPriseNo and iim.warehouse_no=iid.warehouse_no and iim.instock_no=iid.instock_no
         and iid.article_no=sai.article_no and iid.article_id=sai.article_id
         and iid.warehouse_no=strWareHouseNo AND iid.instock_no=strInstockNo
         and iid.label_no=strLabelNo and iid.article_no=strArticleNo and iid.dest_cell_no=strDestCellNo
         AND iid.packing_qty=nPackingQty and sai.produce_date=dtProduceDate
         and iid.status<'13';
      v_strDeptNo           stock_content.dept_no%type;
      nRemainQty            stock_content.qty%type;--剩余数量
      nTempQty              stock_content.qty%type;--当次回单数量
      v_icount          integer;
      strOtype          cdef_defarea.o_type%type;
      v_nCellID         stock_content.cell_id%type;
      v_strRsvLabelFlag  wms_riordertype.rsv_label_flag%type;
      v_strOwnerNo       bdef_defowner.owner_no%type;
      v_strUntreadType   ridata_instock_m.untread_type%type;
      v_strClassType     ridata_instock_m.class_type%type;
      v_strQualityFlag   ridata_instock_m.quality_flag%type;
  begin
      strResult      := 'N|[P_SpecialSaveInstock]';

      nRemainQty:=nRealQty;
      v_icount:=0;

      for GetInstockItem in v_GetInstockItem loop
          v_icount:=v_icount+1;
          --获取部门编码
          begin
              select sc.dept_no into v_strDeptNo
                     from stock_content sc where sc.enterprise_no=strEnterPriseNo
                     and sc.warehouse_no=strWareHouseNo and sc.owner_no=GetInstockItem.owner_no
                     and sc.cell_no=GetInstockItem.cell_no and sc.cell_id=GetInstockItem.cell_id;
          exception when no_data_found then
              strResult:='N|获取库存信息失败';
              return;
          end;

          if nRemainQty>=GetInstockItem.article_qty then
             nTempQty:=GetInstockItem.article_qty;
          else
             nTempQty:=nRemainQty;
          end if;

          nRemainQty:=nRemainQty-nTempQty;

           --更新上架明细
          pkobj_ridata.P_UpdateInstock(strEnterPriseNo,strWareHouseNo,strInstockNo,GetInstockItem.instock_id,strInstockCellNo,
              nTempQty,strUserId,strPaperUserId,'13',strResult);

          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;

          --更新来源储位库存
          PKOBJ_STOCK.p_UpdtContent_qtyByCellID(strEnterPriseNo,strWareHouseNo,GetInstockItem.cell_id,GetInstockItem.cell_no,
             GetInstockItem.dest_cell_no,nTempQty,GetInstockItem.article_qty,strUserId,
             strInstockNo,strTools,strResult);

          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;

          --更新目的储位库存
          pkobj_stock.p_InstContent_qtyByCellID(strEnterPriseNo,strWareHouseNo,GetInstockItem.dest_cell_id,GetInstockItem.dest_cell_no,
            GetInstockItem.cell_no,nTempQty,GetInstockItem.article_qty,strUserId,
             strInstockNo,strTools,strResult);

          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;

          if nTempQty=0 then
              --修改可移库标识
              pkobj_stock.p_UpdtContent_Mvflag(strEnterPriseNo,strWareHouseNo,
                                               GetInstockItem.cell_no,
                                               GetInstockItem.cell_id,
                                               '1',
                                               strUserId,
                                               strResult);

              if (substr(strResult, 1, 1) = 'N') then
                return;
              end if;


              if v_strRsvLabelFlag='0' then
                  --将标签库存转为储位库存
                   pkobj_stock.p_UpdtContent_ContainerNo(strEnterPriseNo,strWareHouseNo,'N',
                        'N',GetInstockItem.cell_no,GetInstockItem.cell_id,
                        strUserId,v_nCellID,strResult);
                   if (substr(strResult, 1, 1) = 'N') then
                     return;
                   end if;
              end if;
          else
              --修改可移库标识
              pkobj_stock.p_UpdtContent_Mvflag(strEnterPriseNo,strWareHouseNo,
                                               GetInstockItem.dest_cell_no,
                                               GetInstockItem.dest_cell_id,
                                               '1',
                                               strUserId,
                                               strResult);

              if (substr(strResult, 1, 1) = 'N') then
                return;
              end if;


              --检查上架区域是否是保留容器的区域
              begin
                  select cd.o_type into strOtype
                  from cdef_defarea cd,cdef_defcell t where cd.enterprise_no=strEnterPriseNo
                         and cd.enterprise_no=t.enterprise_no
                         and cd.warehouse_no=strWareHouseNo and cd.ware_no=t.ware_no
                         and cd.warehouse_no=t.warehouse_no
                         and cd.area_no=t.area_no and t.cell_no=strDestCellNo;
              exception when no_data_found then
                  strResult:='N|获取上架储区的信息失败';
                  return;
              end;

             if strDestCellNo<>strInstockCellNo then--修改储位时，需将预计上架储位的库存移库到实际上架储位
                --更新来源储位库存
                pkobj_stock.p_UpdtContent_qtyByCellNo(strEnterPriseNo,strWareHouseNo,GetInstockItem.owner_no,GetInstockItem.article_no,
                  GetInstockItem.article_id,strDestCellNo,strInstockCellNo,GetInstockItem.packing_qty,
                  nTempQty,GetInstockItem.sub_label_no,GetInstockItem.stock_type,GetInstockItem.stock_value,
                  strUserId,strInstockNo,strTools,strResult);

                if (substr(strResult, 1, 1) = 'N') then
                  return;
                end if;

                --更新目的储位库存
                pkobj_stock.p_InstContent_qtyByCellNo(strEnterPriseNo,strWareHouseNo,GetInstockItem.owner_no,v_strDeptNo,GetInstockItem.article_no,
                   GetInstockItem.article_id,strInstockCellNo,strDestCellNo,GetInstockItem.packing_qty,
                   nTempQty,GetInstockItem.label_no,GetInstockItem.sub_label_no,GetInstockItem.stock_type,GetInstockItem.stock_value,
                    strUserId,strInstockNo,strTools,'1',v_nCellID,strResult);

                if (substr(strResult, 1, 1) = 'N') then
                  return;
                end if;
             end if;

              --判断是否保留容器号
             if  strOtype<>'P' or  (GetInstockItem.business_type<>'3' and GetInstockItem.business_type<>'6') then --3客户别，6B品\P保留标签
                 if strDestCellNo<>strInstockCellNo  then
                   pkobj_stock.p_UpdtContent_ContainerNo(strEnterPriseNo,strWareHouseNo,'N',
                        'N',strInstockCellNo,v_nCellID,
                        strUserId,v_nCellID,strResult);
                   if (substr(strResult, 1, 1) = 'N') then
                     return;
                   end if;
                 else
                   pkobj_stock.p_UpdtContent_ContainerNo(strEnterPriseNo,strWareHouseNo,'N',
                        'N',strDestCellNo,GetInstockItem.Dest_Cell_Id,
                        strUserId,v_nCellID,strResult);
                   if (substr(strResult, 1, 1) = 'N') then
                     return;
                   end if;
                 end if;
             end if;
         end if;
         if nRemainQty=0 then
            exit;
         end if;
         --标签追踪
      end loop;
      if v_icount=0 then
         strResult:='N|没有读取到上架明细';
         return;
      end if;


      select count(*) into v_iCount from ridata_instock_m iim where iim.enterprise_no=strEnterPriseNo
      and iim.warehouse_no=strWareHouseNo
      and iim.instock_no=strInstockNo and status='13';

      if v_icount=1 then--上架回单已完成，需要转历史
         pkobj_Ridata.P_InstockToHty(strEnterPriseNo,strWareHouseNo,strInstockNo,strResult);

          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;
      end if;

      strResult:='Y';
  end P_SpecialSaveInstock;

  /*********************************************************************************************
  功能说明：校验封箱储位是否合法

  *********************************************************************************************/
  procedure P_CheckCloseBoxCell(strEnterPriseNo in ridata_check_pal_tmp.enterprise_no%type,
                                strWareHouseNo  in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                strOwnerNo      in ridata_check_pal_tmp.owner_no%type, --委托业主编码
                                strsUntreadNo   in ridata_check_m.s_untread_no%type, --进货汇总单号
                                strsCheckNo     in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                strDestCellNo   in cdef_defcell.cell_no%type,
                                strResult       out varchar2)is
       v_strOrgNo               ridata_untread_m.org_no%type;
       v_strDestCellOrgNo       ridata_untread_m.org_no%type;
  begin

       if strDestCellNo<>'N' then --校验货物;
         -- 货位必须存在且同机构
        --获取返配单的机构
        begin
            select nvl(rum.org_no,'N') into v_strOrgNo from ridata_check_m icm,ridata_untread_m rum
            where icm.enterprise_no=rum.enterprise_no and icm.warehouse_no=rum.warehouse_no
            and icm.untread_no=rum.untread_no and icm.enterprise_no=strEnterPriseNo
            and icm.warehouse_no=strWareHouseNo and icm.s_untread_no=strsUntreadNo
            and icm.s_check_no=strsCheckNo and rownum<=1;
        exception when no_data_found then
             strResult:='N|[找不到对应的返配单]';
             return;
        end;

        --获取目的储位对应的机构
        begin
            select cw.org_no into v_strDestCellOrgNo from cdef_defcell cd,cdef_defware cw,cdef_defarea ca
            where cd.enterprise_no=cw.enterprise_no and cd.warehouse_no=cw.warehouse_no
            and cd.enterprise_no=ca.enterprise_no and cd.warehouse_no=ca.warehouse_no
            and cd.ware_no=ca.ware_no and cd.area_no=ca.area_no and ca.AREA_ATTRIBUTE='0'
            and cd.cell_status='0'
            and cd.ware_no=cw.ware_no and cd.cell_no=strDestCellNo;
        exception when no_data_found then
             strResult:='N|[目的储位不存在或不是作业区]';
             return;
        end;

        if v_strOrgNo<>v_strDestCellOrgNo then
             strResult:='N|[目的储位的机构与返配单不是同一机构]';
             return;
        end if;
      end if;
      strResult:='Y|[]';
   end P_CheckCloseBoxCell;

   /**************************************************************************************************
  创建人：luozhiling
  创建日期:2015.7.20
  功能说明：整单指定储位上架回单
  ***************************************************************************************************/
  procedure P_LocateCellsaveInstockAll(   strEnterpriseNo   in Ridata_instock_m.enterprise_no%type,
                                strWarehouseNo    in Ridata_instock_m.warehouse_no%type,
                                strInstockNo      in Ridata_instock_m.instock_no%type,
                                strUserId         in Ridata_instock_m.rgst_name%type, --上架人
                                strPaperUserId    in Ridata_instock_m.rgst_name%type, --回单人
                                strInstockCellNo  in cdef_defcell.cell_no%type,
                                strTools          in stock_content_move.terminal_flag%type,
                                strResult         out varchar2) is
        v_iCount                integer:=0;
        v_strInstockOrgNo       cdef_defware.org_no%type;
        v_strDestCellOrgNo      cdef_defware.org_no%type;
  begin
       strResult:='N|[P_LocateCellsaveInstockAll]';

       for p in(select iid.owner_no, sai.produce_date,sai.expire_date,sai.lot_no,sai.quality,sai.rsv_batch1,sai.rsv_batch2,
           sai.rsv_batch3,sai.rsv_batch4,sai.rsv_batch5,sai.rsv_batch6,sai.rsv_batch7,sai.rsv_batch8,
           iid.instock_no,iid.cell_no,iid.article_no,iid.dest_cell_no,iid.label_no,iid.packing_qty,sum(iid.article_qty) article_qty
           from ridata_instock_d iid,stock_article_info sai where iid.warehouse_no=strWarehouseNo
           and iid.enterprise_no=strEnterpriseNo and iid.instock_no=strInstockNo and iid.status='10'
           and iid.article_no=sai.article_no and iid.article_id=sai.article_id
           group by iid.owner_no,sai.produce_date,sai.expire_date,sai.lot_no,sai.quality,sai.rsv_batch1,sai.rsv_batch2,
           sai.rsv_batch3,sai.rsv_batch4,sai.rsv_batch5,sai.rsv_batch6,sai.rsv_batch7,sai.rsv_batch8,
           iid.instock_no,iid.cell_no,iid.article_no,iid.dest_cell_no,iid.label_no,iid.packing_qty) loop

           v_iCount:=v_iCount+1;
           --第一次校验储位
           if v_iCount=1 then

              --获取目的储位对应的机构
              begin
                  select cw.org_no into v_strDestCellOrgNo from cdef_defcell cd,cdef_defware cw,cdef_defarea ca
                  where cd.enterprise_no=cw.enterprise_no and cd.warehouse_no=cw.warehouse_no
                  and cd.enterprise_no=ca.enterprise_no and cd.warehouse_no=ca.warehouse_no
                  and cd.ware_no=ca.ware_no and cd.area_no=ca.area_no
                  and cd.ware_no=cw.ware_no and cd.cell_no=p.dest_cell_no;
              exception when no_data_found then
                   strResult:='N|[目的储位不存在或不是作业区]';
                   return;
              end;

              --获取指定上架储位储位对应的机构
              begin
                  select cw.org_no into v_strInstockOrgNo from cdef_defcell cd,cdef_defware cw,cdef_defarea ca
                  where cd.enterprise_no=cw.enterprise_no and cd.warehouse_no=cw.warehouse_no
                  and cd.enterprise_no=ca.enterprise_no and cd.warehouse_no=ca.warehouse_no
                  and cd.ware_no=ca.ware_no and cd.area_no=ca.area_no and ca.AREA_ATTRIBUTE in('0')
                  and cd.cell_status='0'
                  and cd.ware_no=cw.ware_no and cd.cell_no=strInstockCellNo;
              exception when no_data_found then
                   strResult:='N|[指定上架储位不存在或不是作业区]';
                   return;
              end;

              if  v_strDestCellOrgNo<>v_strInstockOrgNo then
                 strResult:='N|[不能上架到此机构!';
                 return;
              end if;
           end if;

           --上架回单
           P_SaveInstock(strEnterpriseNo,strWareHouseNo,strInstockNo,p.dest_cell_no,strInstockCellNo,
               p.label_no,p.article_no,p.produce_date,p.packing_qty,
               p.article_qty,strUserId,strPaperUserId,'1',strResult);

          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;
       end loop;

       strResult:='Y|[成功]';
  end P_LocateCellsaveInstockAll;
   /***********************************************************************************************
  修改人:hcx
  日期:2016-3-1
  功能：审空单
  ************************************************************************************************/
  procedure P_ComfireEmptyList(
                           strEnterpriseNo  in    ridata_untread_m.enterprise_no%type,
                           strWareHouseNo   in    ridata_untread_m.warehouse_no%type,
                           strOwnerNo       in    ridata_untread_m.owner_no%type,
                           strSUntreadNo    in    ridata_untread_mm.s_untread_no%type,
                           strUntreadNo     in    ridata_untread_m.untread_no%type,
                           strUserId        in    ridata_untread_m.rgst_name%type,
                           strResult        out   varchar2) is
   v_count       number;
 begin
   strResult:='Y|[P_idata_import]';
   begin
      --检查返配单是否有验收数据
      select count(1) into v_count from ridata_check_d rcd,ridata_check_m rcm
       where rcd.enterprise_no=rcm.enterprise_no
         and rcd.wareHouse_no=rcm.warehouse_no
         and rcd.owner_no=rcm.owner_no
         and rcd.check_no=rcm.check_no
         and rcd.enterprise_no=strEnterpriseNo
         and rcd.wareHouse_no=strWareHouseNo
         and rcd.owner_no=strOwnerNo
         and rcm.s_untread_no=strSUntreadNo;
      if v_count > 0 then
         strResult:= 'N|[该返配单有验收数据，不能审空单！]';
         return;
      end if;

      --检查返配单是否有验收扫描数据
      select count(1) into v_count from ridata_check_pal_tmp rcpt
       where rcpt.enterprise_no=strEnterpriseNo
         and rcpt.wareHouse_no=strWareHouseNo
         and rcpt.owner_no=strOwnerNo
         and rcpt.s_untread_no=strSUntreadNo;
      if v_count > 0 then
         strResult:= 'N|[该返配单有验收扫描数据，不能审空单！]';
         return;
      end if;

      --更新返配汇总单对应关系状态为16
      update ridata_untread_sm
         set status = '16', updt_name = strUserId, updt_date = sysdate
       where enterprise_no=strEnterPriseNo and warehouse_no = strWareHouseNo
         and s_untread_no = strSUntreadNo  and owner_no=strOwnerNo
         and status not in ('13');
      if sql%notfound then
         strResult := 'N|[E24210]';
         return;
      end if;

     --更新返配汇总单头档状态为16
      update ridata_untread_mm
         set status = '16', updt_name = strUserId, updt_date = sysdate
       where enterprise_no=strEnterPriseNo and warehouse_no = strWareHouseNo
         and owner_no=strOwnerNo and s_untread_no = strSUntreadNo
         and status not in ('13');
      if sql%notfound then
         strResult := 'N|[E24211]';
         return;
      end if;

      --将进货汇总单数据转历史
      PKOBJ_RIDATA.P_UntreadToHty(strEnterPriseNo,strWareHouseNo,strSUntreadNo,strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --更新返配单明细状态
      update ridata_untread_d
         set status = '16'
       where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo
         and owner_no=strOwnerNo and untread_no=strUntreadNo
         and status not in ('13');

      --更新返配头档状态
      update ridata_untread_m
         set status = '16', updt_name = strUserId, updt_date = sysdate
       where enterprise_no=strEnterPriseNo and warehouse_no = strWareHouseNo
         and owner_no=strOwnerNo and untread_no=strUntreadNo
         and status not in ('13');
      if sql%notfound then
         strResult := 'N|[E24212]';
         return;
      end if;
    end;
 end P_ComfireEmptyList;
 end PKLG_RIDATA;

/

