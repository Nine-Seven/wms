create view V_SEARCH_9102_1 as
select a.enterprise_no,
       a.warehouse_no,
       a.owner_no,
       a.S_CHECK_NO,
       a.UNTREAD_NO,
       d.po_no,
       OEM.SHIPPER_DELIVER_NO,
       IID.REAL_CELL_NO,
       f_get_fieldtext('RIDATA_UNTREAD_M', 'QUALITY', d.quality) untread_type,
       to_char(a.CHECK_START_DATE, 'yyyy-mm-dd') CHECK_START_DATE,
       to_char(a.CHECK_END_DATE, 'yyyy-mm-dd') CHECK_END_DATE,
       (case
         when a.quality = '0' then
          '正常商品'
         else
          case
            when a.quality = 'B' then
             'DM商品'
            else
             case
               when a.quality = 'A' then
                'QA商品'
             end
          end
       end) AS quality,
       a.ARTICLE_NO,
       c.OWNER_ARTICLE_NO,
       c.ARTICLE_NAME,
       c.BARCODE,
       c.UNIT,
       a.PACKING_QTY,
       a.CHECK_QTY,
       b.untread_qty,
       a.CHECK_QTY - b.untread_qty diffqty,
       to_char(a.produce_date, 'yyyy-mm-dd') produce_date,
       to_char(a.expire_date, 'yyyy-mm-dd') expire_date,
       a.lot_no,
       d.cust_no,
       e.cust_name
  from (select a.enterprise_no,
               a.warehouse_no,
               a.owner_no,
               b.quality,
               a.s_check_no,
               a.untread_no,
               trunc(b.rgst_date) as check_start_date,
               trunc(b.rgst_date) as check_end_date,
               b.article_no,
               b.packing_qty,
               b.produce_date,
               b.expire_date,
               b.lot_no,
               sum(b.check_qty) check_qty,
               trunc(sum(b.check_qty) / b.packing_qty) as checkbox,
               mod(sum(b.check_qty), b.packing_qty) as checkpcs
          from ridata_check_m a,
               (select rcd.enterprise_no,
                       rcd.warehouse_no,
                       rcm.s_check_no,
                       rcd.quality,
                       rcd.article_no,
                       rcd.packing_qty,
                       rcd.produce_date,
                       rcd.expire_date,
                       rcd.lot_no,
                       rcp.check_qty,
                       rcp.updt_date as rgst_date,
                       rcp.rgst_name
                  from ridata_check_pal rcp,
                       ridata_check_d   rcd,
                       ridata_check_m   rcm
                 where rcm.enterprise_no = rcd.enterprise_no
                   and rcm.warehouse_no = rcd.warehouse_no
                   and rcm.check_no = rcd.check_no
                   and rcp.enterprise_no = rcd.enterprise_no
                   and rcp.warehouse_no = rcd.warehouse_no
                   and rcp.check_no = rcd.check_no
                   and rcp.check_row_id = rcd.row_id
                union
                select enterprise_no,
                       warehouse_no,
                       s_check_no,
                       quality,
                       article_no,
                       packing_qty,
                       produce_date,
                       expire_date,
                       lot_no,
                       check_qty,
                       rgst_date,
                       rgst_name
                  from ridata_check_pal_tmp) b
         where a.enterprise_no = b.enterprise_no
           and a.s_check_no = b.s_check_no
           and a.warehouse_no = b.warehouse_no
         group by a.enterprise_no,
                  a.warehouse_no,
                  a.owner_no,
                  b.quality,
                  a.s_check_no,
                  a.untread_no,
                  trunc(b.rgst_date),
                  b.article_no,
                  b.packing_qty,
                  b.produce_date,
                  b.expire_date,
                  b.lot_no) a,
       ridata_untread_d b,
       bdef_defarticle c,
       ridata_untread_m d,
       ODATA_EXP_M OEM,
       idata_instock_mhty iim,
       idata_instock_dhty iid,
       bdef_defcust e
 where c.enterprise_no = b.enterprise_no
   and c.article_no = b.article_no
   and e.enterprise_no = d.enterprise_no
   and e.owner_no = d.owner_no
   and e.cust_no = d.cust_no
   and d.enterprise_no = b.enterprise_no
   and d.warehouse_no = b.warehouse_no
   and d.untread_no = b.untread_no
   AND OEM.ENTERPRISE_NO=D.ENTERPRISE_NO
   AND OEM.WAREHOUSE_NO=D.WAREHOUSE_NO
   AND OEM.OWNER_NO=D.OWNER_NO
   AND OEM.SOURCEEXP_NO=D.PO_NO

   and iim.enterprise_no=a.enterprise_no
   and iim.warehouse_no=a.warehouse_no
   and iim.owner_no=a.owner_no
   and iid.enterprise_no=iim.enterprise_no
   and iid.warehouse_no=iim.warehouse_no
   and iid.Owner_No=IIM.OWNER_NO
   AND IID.INSTOCK_NO=IIM.INSTOCK_NO
   AND IID.SOURCE_NO=A.S_CHECK_NO
   AND IID.ARTICLE_NO=A.ARTICLE_NO
   and b.enterprise_no = a.enterprise_no
   and b.warehouse_no = a.warehouse_no
   and b.untread_no = a.untread_no
   and b.article_no = a.article_no
 order by a.enterprise_no,
          a.warehouse_no,
          a.owner_no,
          d.untread_no desc,
          d.po_no,
          a.quality,
          c.OWNER_ARTICLE_NO

/

