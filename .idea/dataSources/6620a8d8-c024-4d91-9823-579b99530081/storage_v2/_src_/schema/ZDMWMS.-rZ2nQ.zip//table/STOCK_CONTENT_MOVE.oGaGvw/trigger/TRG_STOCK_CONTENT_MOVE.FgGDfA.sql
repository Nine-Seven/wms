create trigger TRG_STOCK_CONTENT_MOVE
    before insert
    on STOCK_CONTENT_MOVE
    for each row
declare
i_id integer;
begin
select SEQ_STOCK_CONTENT_MOVE.nextval into i_id from dual;
:NEW.ROW_ID := i_id;
end;


/

