create function        f_get_errortext(v_errorId in varchar2)
    return varchar2
    is
    v_text            VARCHAR(256);
    begin
       select errordesc into v_text from wms_deferror where errorid=v_errorId;
       return v_text;
    end;


/

