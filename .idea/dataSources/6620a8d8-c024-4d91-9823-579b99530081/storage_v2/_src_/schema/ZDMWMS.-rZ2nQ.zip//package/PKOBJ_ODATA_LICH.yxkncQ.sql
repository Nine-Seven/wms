create package        PKOBJ_ODATA_LICH is
  /*****************************************************************************************
      LICH
      20140521
     功能：修改出货下架明细信息
  *****************************************************************************************/
    procedure P_Update_Odata_OutStock_D(strEnterPriseNo      in odata_outstock_d.enterprise_no%type, --企业号
                                      strWarehouse_no      in odata_outstock_d.warehouse_no%type, --仓别
                                      strOutStockNo     in odata_outstock_d.outstock_no%type, --下架单号
                                      strRealQty        in odata_outstock_d.real_qty%type,
                                      strCustContainerNo   in odata_outstock_d.d_container_no%type,
                                      strOwnerNo        in odata_outstock_d.owner_no%type,
                                      strDivideId       in odata_outstock_d.divide_id%type,
                                      strOutstockName   in odata_outstock_d.outstock_name%type, --出货员工ID
                                      strInstockName    in odata_outstock_d.instock_name%type, --出货员工ID
                                      strStatus         in odata_outstock_d.status%type, --状态
                                      strOutMsg         out varchar2); --返回值

  /****************************************************************************************************
     quzhihui
     2013.11.25
     功能说明：更新下架单头档
  ******************************************************************************************************/
  procedure p_Update_Odata_Outstock_M(strEnterPriseNo      in odata_outstock_d.enterprise_no%type, --企业号
                                      strWAREHOUSE_NO in odata_outstock_m.warehouse_no%type,
                                      strOutstockNo   in odata_outstock_m.outstock_no%type,
                                      strUserID       in odata_outstock_m.rgst_name%type,
                                      strOutMsg       out varchar2);
/*****************************************************************************************
     功能：下架回单 数据转历史处理
  *****************************************************************************************/
  procedure P_Update_Odata_OutStock_Hty(strEnterPriseNo      in odata_outstock_d.enterprise_no%type, --企业号
                                        v_warehouse_no      in odata_outstock_m.warehouse_no%type, --仓别
                                        strOutStockNo in odata_outstock_m.outstock_no%type, --下架单号
                                        strUserId     in odata_outstock_m.rgst_name%type, --员工ID
                                        strFlagZero   in varchar2,--拣货零回标示
                                        strOutMsg     out varchar2); --返回值


 /************************************************************************************************
  功能说明：拣货差异回单时可支持重定位
  创建人：luozhiling
  创建时间：2014.12.3
************************************************************************************************/
  procedure P_O_DiffOutstock(strEnterPriseNo  in  odata_outstock_m.enterprise_no%type,
                             strWareHouseNo          in     odata_outstock_m.warehouse_no%type,
                             strOutstockNo         in     odata_outstock_m.outstock_no%type,
                             strUserID             in     bdef_defworker.worker_no%type, --系统操作人员
                             strOutMsg             out   varchar2);
 /*****************************************************************************************
      LICH
      20150416
     功能：根据波次更新出货手建单
  *****************************************************************************************/
  procedure P_Update_Odata_Exp_By_WaveNo(strEnterPriseNo   in odata_locate_m.enterprise_no%type, --企业号
                                      strWarehouse_no      in odata_locate_m.warehouse_no%type, --仓别
                                      strWaveNo            in odata_locate_m.wave_no%type, --波次
                                      strUpdateName        in odata_locate_m.locate_name%type, --出货员工ID
                                      strOutMsg         out varchar2);
  /***************************************************************************88
  功能说明：将来源标签明细转移到目的标签明细

  ********************************************************************************/
  procedure P_odata_move_label(strEnterPriseNo    in stock_label_d.enterprise_no%type,
                                 strWareHouseNo     in stock_label_d.warehouse_no%type, --仓库编码
                                 strOwner_No        in stock_label_d.owner_no%type,
                                 strExp_Type        in stock_label_d.exp_type%type,
                                 strSourceNo        in stock_label_d.source_no%type, --来源单号
                                 strsContainerNo    in stock_label_d.container_no%type, --来源容器号
                                 strDestContainerNo in stock_label_d.container_no%type, --目的容器号
                                 nDivideId          in stock_label_d.divide_id%type, --
                                 strArticleNo       in stock_label_d.article_no%type,
                                 nArticleId         in stock_label_d.article_id%type,
                                 nPackingQty        in stock_label_d.packing_qty%type,
                                 strExpNo           in stock_label_d.exp_no%type,
                                 nRealQty           in stock_label_d.qty%type,
                                 strCustNo          in stock_label_d.Cust_No%type, --客户编码
                                 strUserId          in stock_label_m.rgst_name%type,
                                 strResult          OUT varchar2);
end PKOBJ_ODATA_LICH;


/

