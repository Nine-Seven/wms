create function        f_get_fieldtext(v_tablename in varchar2,v_colname in varchar2,v_value in varchar2)
    return varchar2
    is
    v_text            VARCHAR(256);
    begin
       select distinct text into v_text from wms_deffieldval where table_name=upper(v_tablename)
          and colname=upper(v_colname) and value=v_value and status='1';
       return v_text;
    end;
/

