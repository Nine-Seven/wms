create view V_SEARCH_9109_001 as
select c.enterprise_no,c.warehouse_no,c.owner_no,sum(c.qty) qty,c.divide_name,c.worker_name,to_char(c.divide_date,'yyyy-mm-dd hh24') divide_date,c.arttype
 from (select sum(t.real_qty) qty,t.divide_name,w.worker_name,t.divide_date,
(case when instr(b.article_name,'鞋')>0 then '鞋' else '服装' end) arttype,t.enterprise_no,t.warehouse_no,t.owner_no
from odata_divide_dhty t,bdef_defworker w,bdef_defarticle b
where t.enterprise_no=w.enterprise_no and t.warehouse_no=w.warehouse_no and t.divide_name=w.worker_no
and t.article_no=b.article_no and t.enterprise_no=b.enterprise_no and t.owner_no=b.owner_no
group by t.divide_name,w.worker_name,t.divide_date,
(case when instr(b.article_name,'鞋')>0 then '鞋' else '服装' end),t.enterprise_no,t.warehouse_no,t.owner_no)c
group by c.enterprise_no,c.warehouse_no,c.owner_no,c.divide_name,c.worker_name,to_char(c.divide_date,'yyyy-mm-dd hh24'),c.arttype
order by c.worker_name,to_char(c.divide_date,'yyyy-mm-dd hh24')


/

