create package PKOBJ_CDEF is

  -- Author  : LICH
  -- Created : 2015-03-25 18:28:44
  -- Purpose :

 PROCEDURE p_create_cell_no(strEnterpriseNo   in cdef_defcell.enterprise_no%type,
                                strWareHouseNo    in cdef_defcell.warehouse_no%type,
                                strWareNo         in cdef_defcell.ware_no%type,
                                strAreaNo         in cdef_defcell.area_no%type,
                                nMinStockNo       in varchar2,--通道
                                nMaxStockNo       in varchar2,
                                nMinStockY        in varchar2,--层
                                nMaxStockY        in varchar2,
                                nMinStockX        in varchar2,--格
                                nMaxStockX        in varchar2,
                                nMinBayX          in varchar2,--位，若为空则给值0
                                nMaxBayX          in varchar2,
                                strCodePrefix     in varchar2,--前缀
                                nMixFlag          in cdef_defcell.mix_flag%type,
                                strMixSupplier    in cdef_defcell.mix_supplier%type,
                                strMixOwner       in cdef_defcell.mix_owner%type,
                                nMaxQty           in cdef_defcell.max_qty%type,
                                nMaxWeight        in cdef_defcell.max_weight%type,
                                nMaxVolume        in cdef_defcell.max_volume%type,
                                nMaxCase          in cdef_defcell.max_case%type,
                                strLimitType      in cdef_defcell.limit_type%type,
                                nlimitRate        in cdef_defcell.limit_rate%type,
                                strBPick          in cdef_defcell.b_pick%type,
                                strCellStatus     in cdef_defcell.cell_status%type,
                                strCheckStatus    in cdef_defcell.check_status%type,
                                strAFlag          in cdef_defcell.a_flag%type,
                                strPickFlag       in cdef_defcell.pick_flag%type,
                                strPerf1          in varchar,
                                strPerf2          in varchar,
                                strPerf3          in varchar,
                                strPerf4          in varchar,
                                strRgstName       in cdef_defcell.rgst_name%type,
                                strKeepLabelFlag  in cdef_defcell.keep_label_flag%type,
                                strCellRule       in varchar,
                                strResult         out varchar2
                                );

 /**********************************************************************************************************
   chensr
   2015.9.14
   功能：添加格子号
  ***********************************************************************************************************/
  PROCEDURE p_create_divide_d(strEnterpriseNo in device_divide_d.enterprise_no%type,

                              strWareHouseNo  in device_divide_d.warehouse_no%type,
                              strPerfix       in device_divide_d.bay_x%type,
                              strBayMin       in device_divide_d.bay_x%type,
                              strBayMax       in device_divide_d.bay_x%type,
                              strFloorMin     in device_divide_d.stock_y%type,
                              strFloorMax     in device_divide_d.stock_y%type,
                              strDeviceGroup  in device_divide_d.device_group_no%type,
                              strDeviceNo     in device_divide_d.device_no%type,
                              strMixflag      in device_divide_d.mix_flag%type,
                              strMixSupplier  in device_divide_d.mix_supplier%type,
                              strMaxQty       in device_divide_d.max_qty%type,
                              strMaxCase      in device_divide_d.max_case%type,
                              strMaxVolume    in device_divide_d.max_volume%type,
                              strMaxWeigth    in device_divide_d.max_weight%type,
                              strStatus       in device_divide_d.status%type,
                              strWorkerNo     in device_divide_d.rgst_name%type,
                              strResult       out varchar2);

 /**********************************************************************************************************
   hekl
   2015.3.27
   功能：插入商品储位对应关系
***********************************************************************************************************/
  PROCEDURE saveOrUpdateCset_Cell_Article(strEnterpriseNo   in cdef_defcell.enterprise_no%type,
                                strWareHouseNo    in cdef_defcell.warehouse_no%type,
                                strOwnerNo        in cset_cell_article.Owner_No%type,
                                strWareNo         in cdef_defcell.ware_no%type,--库区
                                strAreaNo         in cdef_defcell.area_no%type,--储区
                                strStockNo        in cset_cell_article.stock_no%type, --通道
                                strAStockNo       in cset_cell_article.a_stock_no%type,--库区+储区+通道
                                strCellNo         in cset_cell_article.cell_no%type,--储位
                                strGroupNo        in bdef_article_group.group_no%type,--类别
                                strArticleNo      in bdef_article_group.group_no%type,--商品编码
                                strPackingQty     in Bdef_Article_Packing.Packing_Qty%type,--包装数量
                                strLineId         in cset_cell_article.line_id%type,--线路
                                strMaxQtyA        in cset_cell_article.max_qty_a%type,--A类最大存储量
                                strAlertQtyA      in cset_cell_article.alert_qty_a%type,--A类补货警示量
                                strSuppQtyA       in cset_cell_article.supp_qty_a%type,--A类循环补货触发量
                                strMaxQtyNa       in cset_cell_article.max_qty_na%type,--非A类最大存储量
                                strAlertQtyNa     in cset_cell_article.alert_qty_na%type,--非A类补货警示量
                                strSuppQtyNa      in cset_cell_article.supp_qty_na%type,--非A类循环补货触发量
                                strKeepCells      in cset_cell_article.keep_cells%type,--非A类最大可用储位数
                                strPickType       in cset_cell_article.pick_type%type,--拣货类型
                                strKeepCellsA     in cset_cell_article.keep_cells_a%type, --A类最大可用储位数
                                strRgstName       in cdef_defcell.rgst_name%type,
                                strResult         out varchar2
                                );

  /**********************************************************************************************************
   hekl
   2015.12.14
   功能：储位修改保存
***********************************************************************************************************/
  PROCEDURE p_update_cell(strEnterpriseNo   in cdef_defcell.enterprise_no%type,
                                strWareHouseNo    in cdef_defcell.warehouse_no%type,
                                strCellNo         in cdef_defcell.cell_no%type,
                                strMixFlag          in cdef_defcell.mix_flag%type,
                                strMixSupplier    in cdef_defcell.mix_supplier%type,
                                strMixOwner       in cdef_defcell.mix_owner%type,
                                strMaxQty           in cdef_defcell.max_qty%type,
                                strMaxWeight        in cdef_defcell.max_weight%type,
                                strMaxVolume        in cdef_defcell.max_volume%type,
                                strMaxCase          in cdef_defcell.max_case%type,
                                strLimitType      in cdef_defcell.limit_type%type,
                                strlimitRate        in cdef_defcell.limit_rate%type,
                                strBPick          in cdef_defcell.b_pick%type,
                                strCellStatus     in cdef_defcell.cell_status%type,
                                strCheckStatus    in cdef_defcell.check_status%type,
                                strAFlag          in cdef_defcell.a_flag%type,
                                strPickFlag       in cdef_defcell.pick_flag%type,
                                strRgstName       in cdef_defcell.rgst_name%type,
                                strKeepLabelFlag  in cdef_defcell.keep_label_flag%type,
                                strResult         out varchar2);

  /*=====================================================================================
  hb insert to 20160526
  拣货位采集-检查商品对应的储位合法性
  ======================================================================================*/
  PROCEDURE p_Check_ArticleCell(strEnterPriseNo  in cdef_defcell.enterprise_no%type,--企业号,
                                strwarehouse_no  in cdef_defcell.warehouse_no%type, --仓别
                                strOwnerNo       in stock_content.owner_no%type, --货主编码
                                strLineId        in varchar2, --保拣线
                                strCellNo        in cdef_defcell.cell_no%type, --储位编号
                                strPickType      in cset_cell_article.pick_type%type, --拣货位类型
                                strArticleNo     in bdef_defarticle.article_no%type, --商品编号
                                strCellArticleNo out varchar2, --返回储位对应的商品编号
                                strOutMsg        out varchar2);

  /*=====================================================================================
  hb insert to 20160526
  拣货位采集-删除当前储位与原有商品的对应关系
  ======================================================================================*/
  PROCEDURE p_delete_ArticleCell(strEnterPriseNo  in cset_cell_article.enterprise_no%type,--企业号,
                                 strwarehouse_no  in cset_cell_article.warehouse_no%type, --仓别
                                 strOwnerNo       in cset_cell_article.owner_no%type, --货主编码
                                 strPickType      in cset_cell_article.pick_type%type, --拣货位类型
                                 strCellArticleNo in bdef_defarticle.article_no%type, --商品编号
                                 strOutMsg        out varchar2);

  /*=====================================================================================
  hb insert to 20160526
  拣货位采集-保存商品与储位对应关系
  ======================================================================================*/
  PROCEDURE p_save_ArticleCell(strEnterPriseNo    in cset_cell_article.enterprise_no%type,--企业号,
                               strwarehouse_no  in cset_cell_article.warehouse_no%type, --仓别
                               strOwnerNo       in cset_cell_article.owner_no%type, --货主编码
                               strPickType      in cset_cell_article.pick_type%type, --拣货位类型
                               strCellNo        in cdef_defcell.cell_no%type, --储位
                               nPackingQty      in cset_cell_article.packing_qty%type, --包装数量
                               nLineId          in cset_area_backup_m.line_id%type, --拣货线
                               nMaxQtyA         in cset_cell_article.MAX_QTY_A%type, --最大存储量（箱）
                               nAlertQtyA       in cset_cell_article.ALERT_QTY_A%type, --补货警示量（箱）
                               nSuppQtyA        in cset_cell_article.SUPP_QTY_A%type, --循环补货触发量（箱）
                               nKeepCells       in cset_cell_article.KEEP_CELLS%type, --可用货位数
                               strArticleNo     in bdef_defarticle.article_no%type, --商品编号
                               strUser_Id       in cset_cell_article.rgst_name%type, --操作人员
                               strOutMsg        out varchar2);

end PKOBJ_CDEF;


/

