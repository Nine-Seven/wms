create view V_SEARCH_9109_8 as
select sdate,workname,sum(sheetQty) sheetQty,sum(articleQty) articleQty,sum(checkQty) checkQty,round(sum(checkpk),0) checkpk,round(sum(checkss),0) checkss,sum(isheetQty) isheetQty,
sum(iarticleQty) iarticleQty,round(sum(icheckss),0) icheckss,sum(msheetQty) msheetQty,sum(marticleQty) marticleQty,sum(mcheckQty) mcheckQty,round(sum(mcheckpk),0) mcheckpk,
round(sum(mcheckss),0) mcheckss,round(sum(mpalQty),0) mpalQty,round(sum(fmcheckQty),0) fmcheckQty,round(sum(fmcheckpk),0) fmcheckpk,
round(sum(fmcheckss),0) fmcheckss,round(sum(fmpalQty),0) fmpalQty,sum(osheetQty) osheetQty,sum(oarticleqty) oarticleqty,round(sum(opalQty),0) opalQty
from
(
select to_date(to_char(icm.updt_date,'yyyy-MM-dd'),'yyyy-MM-dd') as sdate,icm.check_worker workname, count(distinct icm.check_no) sheetQty,count(distinct icd.article_no) articleQty,sum(icd.check_qty) checkQty,
sum(floor(icd.check_qty/icd.packing_qty)) checkpk,sum(mod(icd.check_qty,icd.packing_qty)) checkss,0 isheetQty,0 iarticleQty,0 icheckpk,0 icheckss,
0 msheetQty,0 marticleQty,0 mcheckQty,0 mcheckpk,0 mcheckss,0 mpalQty,0 fmcheckQty,0 fmcheckpk,0 fmcheckss,0 fmpalQty,0 osheetQty,0 oarticleqty,0 opalQty
from idata_check_d icd,idata_check_m icm
where icd.warehouse_no = icm.warehouse_no
  and icd.check_no = icm.check_no
  and icm.status = '13'
group by  to_date(to_char(icm.updt_date,'yyyy-MM-dd'),'yyyy-MM-dd'),icm.check_worker
union all
select to_date(to_char(iim.updt_date,'yyyy-MM-dd'),'yyyy-MM-dd') as sdate,iim.instock_worker workname, 0 sheetQty,0 articleQty,0 checkQty,0 checkpk,0 checkss,
count(distinct iim.instock_no) isheetQty,count(distinct iid.article_no) iarticleQty,sum(floor(iid.real_qty/iid.packing_qty)) icheckpk,
sum(mod(iid.real_qty,iid.packing_qty)) icheckss,
0 msheetQty,0 marticleQty,0 mcheckQty,0 mcheckpk,0 mcheckss,0 mpalQty,0 fmcheckQty,0 fmcheckpk,0 fmcheckss,0 fmpalQty,0 osheetQty,0 oarticleqty,0 opalQty
from idata_instock_d iid,idata_instock_m iim
where iid.warehouse_no = iim.warehouse_no
  and iid.instock_no = iim.instock_no
  and iid.status = '13'
group by  to_date(to_char(iim.updt_date,'yyyy-MM-dd'),'yyyy-MM-dd'),iim.instock_worker
union all
select to_date(to_char(oom.updt_date,'yyyy-MM-dd'),'yyyy-MM-dd') as sdate,ood.outstock_name workname, 0 sheetQty,0 articleQty,0 checkQty,0 checkpk,0 checkss,
0 isheetQty,0 iarticleQty,0 icheckpk,0 icheckss,
count(distinct ood.exp_no) msheetQty,count(distinct ood.article_no) marticleQty,
sum(case when cda.area_pick='1' then ood.real_qty else 0 end) mcheckQty,
sum(floor(case when cda.area_pick='1' then ood.real_qty else 0 end)/ood.packing_qty) mcheckpk,
sum(mod(case when cda.area_pick='1' then ood.real_qty else 0 end,ood.packing_qty)) mcheckss,
sum((case when cda.area_pick='1' then ood.real_qty else 0 end)/(bap.pal_base_qbox*bap.pal_height_qbox)) mpalQty,
sum(case when cda.area_pick='0' then ood.real_qty else 0 end) fmcheckQty,
sum(floor(case when cda.area_pick='0' then ood.real_qty else 0 end)/ood.packing_qty) fmcheckpk,
sum(mod(case when cda.area_pick='0' then ood.real_qty else 0 end,ood.packing_qty)) fmcheckss,
sum((case when cda.area_pick='0' then ood.real_qty else 0 end)/(bap.pal_base_qbox*bap.pal_height_qbox)) fmpalQty,0 osheetQty,0 oarticleqty,0 opalQty
from odata_outstock_dhty ood,odata_outstock_Mhty oom,cdef_defcell cd,CDEF_DEFAREA cda,bdef_article_packing bap
where ood.warehouse_no = oom.warehouse_no
  and ood.outstock_no = oom.outstock_no
  and  oom.outstock_type='0'
  and ood.s_cell_no = cd.cell_no
  and ood.warehouse_no = cd.warehouse_no
  and cd.warehouse_no=cda.warehouse_no
  and cd.ware_no = cda.ware_no
  and cd.area_no = cda.area_no
  and ood.article_no = bap.article_no
  and ood.packing_qty = bap.packing_qty
group by  to_date(to_char(oom.updt_date,'yyyy-MM-dd'),'yyyy-MM-dd'),ood.outstock_name
union all
select to_date(to_char(oom.updt_date,'yyyy-MM-dd'),'yyyy-MM-dd') as sdate,ood.instock_name workname, 0 sheetQty,0 articleQty,0 checkQty,0 checkpk,0 checkss,
0 isheetQty,0 iarticleQty,0 icheckpk,0 icheckss,
0 msheetQty,0 marticleQty,0 mcheckQty,0 mcheckpk,0 mcheckss,0 mpalQty,0 fmcheckQty,0 fmcheckpk,0 fmcheckss,0 fmpalQty,
count(distinct ood.outstock_no) osheetQty,count(distinct ood.article_no) oarticleqty,
sum(ood.real_qty/(bap.pal_base_qbox*bap.pal_height_qbox)) opalQty
from odata_outstock_mhty oom,odata_outstock_dhty ood,bdef_defarticle bda,bdef_article_packing bap
where oom.warehouse_no = ood.warehouse_no
 and  oom.outstock_no = ood.outstock_no
 and  oom.outstock_type='1'
 and ood.article_no = bda.article_no
 and ood.owner_no = bda.owner_no
 and bda.article_no = bap.article_no
 and ood.packing_qty = bap.packing_qty
group by  to_date(to_char(oom.updt_date,'yyyy-MM-dd'),'yyyy-MM-dd'),ood.instock_name
union all
select to_date(to_char(oom.updt_date,'yyyy-MM-dd'),'yyyy-MM-dd') sdate,ood.outstock_name workname, 0 sheetQty,0 articleQty,0 checkQty,0 checkpk,0 checkss,
0 isheetQty,0 iarticleQty,0 icheckpk,0 icheckss,
0 msheetQty,0 marticleQty,0 mcheckQty,0 mcheckpk,0 mcheckss,0 mpalQty,0 fmcheckQty,0 fmcheckpk,0 fmcheckss,0 fmpalQty,
count(distinct ood.outstock_no) osheetQty,count(distinct ood.article_no) oarticleqty,
sum(ood.real_qty/(bap.pal_base_qbox*bap.pal_height_qbox)) opalQty
from odata_outstock_mhty oom,odata_outstock_dhty ood,bdef_defarticle bda,bdef_article_packing bap
where oom.warehouse_no = ood.warehouse_no
 and  oom.outstock_no = ood.outstock_no
 and  oom.outstock_type='1'
 and ood.article_no = bda.article_no
 and ood.owner_no = bda.owner_no
 and bda.article_no = bap.article_no
 and ood.packing_qty = bap.packing_qty
group by  to_date(to_char(oom.updt_date,'yyyy-MM-dd'),'yyyy-MM-dd'),ood.outstock_name
)
group by sdate,workname


/

