create package        PKLG_ILOCATE is

  -- Author  : LIZHIPING
  -- Created : 2013-09-28 10:56:43
  -- Purpose :

  -- Public type declarations
  -- type <TypeName> is <Datatype>;
  TYPE cv_type IS REF CURSOR; --声明游标类型

  -- Public constant declarations
  -- <ConstantName> constant <Datatype> := <Value>;

  -- Public variable declarations
  -- <VariableName> <Datatype>;

  -- Public function and procedure declarations
  -- function <FunctionName>(<Parameter> <Datatype>) return <Datatype>;

  --进货定位程序入口
  procedure p_locate_main(strEnterPriseNo in varchar2,
                          strWareHouseNo  in varchar2, --仓库代码
                          strOwnerNo      in varchar2, --货主代码
                          strLocateNo     in varchar2, --定位号
                          strPrintFlag    in varchar2, --是否后台打印
                          strWorkNo       in varchar2, --员工代码
                          strPrintTaskNo  out varchar2, --打印任务号
                          strErrorMsg     out varchar2);

  --良品商品定位入口
  procedure p_locate_good(strEnterPriseNo in varchar2,
                          strWareHouseNo  in varchar2, --仓库代码
                          strOwnerNo      in varchar2, --货主代码
                          strArticleNo    in varchar2, --商品代码
                          nArticleID      in stock_content.article_id%type,
                          nDirectRow_ID   in idata_locate_direct.row_id%type,
                          strOperateType  in varchar2, --定位类型
                          nPackingQty     in number,
                          nLocateQty      in number,
                          strWorker       in bdef_defworker.worker_no%type,
                          blSplitCToB     in out boolean,
                          strLocateCellNo in out varchar2,
                          strErrorMsg     in out varchar2);

  --不良品商品定位入口
  procedure p_locate_bad(strEnterPriseNo in varchar2,
                         strWareHouseNo  in varchar2, --仓库代码
                         strOwnerNo      in varchar2, --货主代码
                         strArticleNo    in varchar2, --商品代码
                         nArticleID      in stock_content.article_id%type,
                         nPackingQty     in number,
                         nLocateQty      in number,
                         strLocateCellNo in out varchar2,
                         strErrorMsg     in out varchar2);
  --获取保拣线
  function f_get_PickLine(strEnterPriseNo in bdef_defowner.enterprise_no%type,
                          strWareHouseNo  in bset_worker_loc.warehouse_no%type,
                          strOwnerNo      in bdef_defowner.owner_no%type,
                          strArticleNo    in bdef_defarticle.article_no%type,
                          strPickCellNo   in cset_cell_article.cell_no%type,
                          nLineID         in cset_cell_article.line_id%type,
                          nRuleID         in WMS_DEFSTRATEGY_D.Rule_Id%type)
    return varchar2;
  --定位到拣货位
  procedure p_locate_pickcell_C(strEnterPriseNo in varchar2,
                                strWareHouseNo  in varchar2, --仓库代码
                                strOwnerNo      in varchar2, --货主代码
                                strArticleNo    in varchar2, --商品代码
                                nPackingQTY     in bdef_article_packing.packing_qty%type,
                                nArticleID      in number,
                                nLocateQty      in number, --定位数量
                                strPickCellNo   in cset_cell_article.cell_no%type,
                                nCellMaxQTY     in cset_cell_article.max_qty_a%type,
                                nMaxCellUse     in cset_cell_article.keep_cells%type,
                                nRuleOrder      in number, --规则顺序
                                strLocateCellNo out varchar2,
                                strErrorMsg     out varchar2);
  --定到零散拣货位
  procedure p_locate_pickcell_B(strEnterPriseNo in cdef_defware.enterprise_no%type,
                                strWareHouseNo  in cdef_defware.warehouse_no%type, --仓库代码
                                strOwnerNo      in bdef_defowner.owner_no%type, --货主代码
                                strArticleNo    in bdef_defarticle.article_no%type, --商品代码
                                nPackingQTY     in bdef_article_packing.packing_qty%type,
                                nArticleID      in stock_article_info.article_id%type,
                                nLocateQty      in number, --定位数量
                                strPickCellNo   in cset_cell_article.cell_no%type,
                                nCellMaxQTY     in cset_cell_article.max_qty_a%type,
                                nMaxCellUse     in cset_cell_article.keep_cells%type,
                                strLocateCellNo out cdef_defcell.cell_no%type,
                                strErrorMsg     out varchar2);

  --拆箱入零散拣货位
  procedure p_locate_SplitCtoB(strEnterPriseNo in cdef_defware.enterprise_no%type,
                               strWareHouseNo  in cdef_defware.warehouse_no%type, --仓库代码
                               strOwnerNo      in bdef_defowner.owner_no%type, --货主代码
                               strArticleNo    in bdef_defarticle.article_no%type, --商品代码
                               nDirectRow_ID   in idata_locate_direct.row_id%type,
                               nLocateQty      in number, --定位数量
                               strPickCellNo   in cset_cell_article.cell_no%type,
                               nCellMaxQTY     in cset_cell_article.max_qty_a%type,
                               nMaxCellUse     in cset_cell_article.keep_cells%type,
                               strWorkNo       in bdef_defworker.worker_no%type,
                               strLocateCellNo out cdef_defcell.cell_no%type,
                               strErrorMsg     out varchar2);
  --定到拣货区
  procedure p_locate_pickArea(strEnterPriseNo in varchar2,
                              strWareHouseNo  in varchar2, --仓库代码
                              strOwnerNo      in varchar2, --货主代码
                              strArticleNo    in varchar2, --商品代码
                              nPackingQTY     in bdef_article_packing.packing_qty%type,
                              nArticleID      in number,
                              strOperateType  in varchar2, --定位类型
                              nLocateQty      in number, --定位数量
                              strPickCellNo   in cset_cell_article.cell_no%type,
                              nCellMaxQTY     in cset_cell_article.max_qty_a%type,
                              nMaxCellUse     in cset_cell_article.keep_cells%type,
                              nRuleOrder      in number, --规则顺序
                              strLocateCellNo out varchar2,
                              strErrorMsg     out varchar2);

  --按保拣线定位到拣货位
  --定位到拣货位
  procedure p_PickCellByPickLine(strEnterPriseNo in varchar2,
                                 strWareHouseNo  in varchar2, --仓库代码
                                 strOwnerNo      in varchar2, --货主代码
                                 strArticleNo    in varchar2, --商品代码
                                 nArticleID      in stock_article_info.article_id%type,
                                 nPackingQTY     in bdef_article_packing.packing_qty%type,
                                 --strOperateType in varchar2, --定位类型
                                 strWareNo     in varchar2, --拣货位所在库
                                 strAreaNo     in varchar2, --拣货位所在储区
                                 strStockNo    in varchar2, --拣货位所在通道（如何拣货位到区，下面几个字段没有参考意义）
                                 strStockX     in varchar2, --拣货位所在格
                                 strStockY     in varchar2, --拣货位所在层
                                 strBayX       in varchar2, --拣货位所在位
                                 strPickCellNo in varchar2, --拣货位储位
                                 nLocateQty    in number, --定位数量
                                 --nMaxQty         in number, --拣货位最大量
                                 nKeepCells  in number, --允许占用最大储位数
                                 nMergerFlag in number, --是否并入
                                 nStockFlag  in number, --
                                 nFloorFlag  in number, --
                                 nStockXFlag in number, --
                                 nBayFlag    in number, --
                                 nSortFlag   in number, --
                                 --nForceFlag      in number, --是否允许强制进入
                                 nRuleOrder      in number, --规则顺序
                                 strLocateCellNo in out varchar2,
                                 strErrorMsg     in out varchar2);

  --定位到保管位
  procedure p_SaveCellByPickLine(strEnterPriseNo in varchar2,
                                 strWareHouseNo  in varchar2, --仓库代码
                                 strOwnerNo      in varchar2, --货主代码
                                 strArticleNo    in varchar2, --商品代码
                                 nArticleID      in stock_article_info.article_id%type,
                                 nPackingQTY     in bdef_article_packing.packing_qty%type,
                                 blSameArticle   in boolean,
                                 --strOperateType in varchar2, --定位类型
                                 strSWareNo  in varchar2, --保管库
                                 strSAreaNo  in varchar2, --保管储区
                                 strSStockNo in varchar2, --保管通道
                                 strStockNo  in varchar2, --拣货位所在通道（如何拣货位到区，下面几个字段没有参考意义）
                                 strStockX   in varchar2, --拣货位所在格
                                 strStockY   in varchar2, --拣货位所在层
                                 strBayX     in varchar2, --拣货位所在位
                                 nLocateQty  in number, --定位数量
                                 nKeepCells  in number, --允许占用最大储位数
                                 nMergerFlag in number, --是否并入
                                 nStockFlag  in number, --
                                 nFloorFlag  in number, --
                                 nStockXFlag in number, --
                                 nBayFlag    in number, --
                                 nSortFlag   in number, --
                                 --nForceFlag      in number, --是否允许强制进入
                                 --nRuleID         in wms_defstrategy_d.rule_id%type,
                                 nRuleOrder      in wms_defstrategy_d.rule_order%type, --规则顺序
                                 strLocateCellNo in out varchar2,
                                 strErrorMsg     in out varchar2);

  --定位到异常区
  procedure p_locate_special(strEnterPriseNo in cdef_defware.enterprise_no%type,
                             strWareHouseNo  in cdef_defware.warehouse_no%type,
                             strOwnerNo      in bdef_defowner.owner_no%type, --货主代码
                             strArticleNo    in bdef_defarticle.article_no%type,
                             nArticleID      in stock_article_info.article_id%type,
                             nPackingQTY     in bdef_article_packing.packing_qty%type,
                             nRuleOrder      in wms_defstrategy_d.rule_order%type, --规则顺序
                             nLocateQty      in number,
                             strLocateCellNo out cdef_defcell.cell_no%type,
                             strErrorMsg     out varchar2);

  procedure p_write_instockdirect(strEnterPriseNo in varchar2,
                                  strWareHouseNo  in varchar2, --仓库代码
                                  nRowid          in number, --定位指示行号
                                  strLocateCellNo in varchar2, --定位储位
                                  nLocate_QTY     in number, --定位数量
                                  strWorkNo       in varchar2, --员工代码
                                  strErrorMsg     in out varchar2);

  --获取储位排序字串,储位表的别名为cdf,每个通道已占储位数量为stockno_used_cells
  function f_get_sortstring(strStockNo  in varchar2, --拣货位所在通道（如何拣货位到区，下面几个字段没有参考意义）
                            strStockX   in varchar2, --拣货位所在格
                            strStockY   in varchar2, --拣货位所在层
                            strBayX     in varchar2, --拣货位所在位
                            nStockFlag  in number, --通道查找顺序
                            nFloorFlag  in number, --层数查找顺序
                            nStockXFlag in number, --储格查找顺序
                            nBayFlag    in number, --BAY查找顺序
                            nSortFlag   in number) --排列顺序
   return varchar2;

  --检查板数量
  function f_check_PalQTY(strEnterPriseNo in cdef_defware.enterprise_no%type,
                          strWareHouseNo  in cdef_defware.warehouse_no%type,
                          --strOwnerNo     in bdef_defowner.owner_no%type,
                          strArticleNo in bdef_defarticle.article_no%type,
                          nPackingQTY  in bdef_article_packing.packing_qty%type,
                          nLocateQTY   in number,
                          strCellNo    in cdef_defcell.cell_no%type)
    return boolean;

  --检查拣货位（区）数量
  function f_check_QTY(strEnterPriseNo in cdef_defware.enterprise_no%type,
                       strWareHouseNo  in cdef_defware.warehouse_no%type,
                       strArticleNo    in bdef_defarticle.article_no%type,
                       nCellMaxQTY     in cset_cell_article.max_qty_a%type,
                       nLocateQTY      in number,
                       strCellNo       in cdef_defcell.cell_no%type)
    return boolean;

  --检查箱数量
  function f_check_CaseQTY(strEnterPriseNo in cdef_defware.enterprise_no%type,
                           strWareHouseNo  in cdef_defware.warehouse_no%type,
                           nPackingQTY     in bdef_article_packing.packing_qty%type,
                           nLocateQTY      in number,
                           strCellNo       in cdef_defcell.cell_no%type)
    return boolean;

  --检查重量
  function f_check_Weight(strEnterPriseNo in cdef_defware.enterprise_no%type,
                          strWareHouseNo  in cdef_defware.warehouse_no%type,
                          --strOwnerNo     in bdef_defowner.owner_no%type,
                          strArticleNo in bdef_defarticle.article_no%type,
                          nLocateQTY   in number,
                          strCellNo    in cdef_defcell.cell_no%type)
    return boolean;

  --检查类别
  function f_check_Group(strEnterPriseNo in cdef_defware.enterprise_no%type,
                         strWareHouseNo  in cdef_defware.warehouse_no%type,
                         --strOwnerNo     in bdef_defowner.owner_no%type,
                         strArticleNo in bdef_defarticle.article_no%type,
                         strCellNo    in cdef_defcell.cell_no%type)
    return boolean;

  --检查混批
  function f_check_ArticleBatch(strEnterPriseNo in cdef_defware.enterprise_no%type,
                                strWareHouseNo  in cdef_defware.warehouse_no%type,
                                strOwnerNo      in bdef_defowner.owner_no%type,
                                strArticleNo    in bdef_defarticle.article_no%type,
                                nArticleID      in stock_article_info.article_id%type,
                                strCellNo       in cdef_defcell.cell_no%type)
    return boolean;

  --检查商品混载
  function f_check_ArticleMix(strEnterPriseNo in cdef_defware.enterprise_no%type,
                              strWareHouseNo  in cdef_defware.warehouse_no%type,
                              strOwnerNo      in bdef_defowner.owner_no%type,
                              strArticleNo    in bdef_defarticle.article_no%type,
                              nArticleID      in stock_article_info.article_id%type,
                              strCellNo       in cdef_defcell.cell_no%type)
    return boolean;

  --检查已使用的储位数
  function f_check_UseCells(strEnterPriseNo in cdef_defware.enterprise_no%type,
                            strWareHouseNo  in cdef_defware.warehouse_no%type,
                            strArticleNo    in bdef_defarticle.article_no%type,
                            strCellNo       in cdef_defcell.cell_no%type)
    return integer;

  --判断是否可入（按入库箱数）
  function f_check_LimitCase(nPackingQTY in bdef_article_packing.packing_qty%type,
                             nLocateQTY  in number,
                             nLimitCase  in cdef_defarea.limit_rate%type)
    return boolean;

  --判断是否可入（按入库比率）
  function f_check_LimitRate(strEnterPriseNo in bdef_defarticle.enterprise_no%type,
                             strArticleNo    in bdef_defarticle.article_no%type,
                             nPackingQTY     in bdef_article_packing.packing_qty%type,
                             nLocateQTY      in number,
                             nLimitRate      in cdef_defarea.limit_rate%type)
    return boolean;

  --获取C型拣货位数量
  function f_GetCPickNum(strEnterPriseNo in cdef_defware.enterprise_no%type,
                         strWareHouseNo  in cdef_defware.warehouse_no%type,
                         strArticleNo    in bdef_defarticle.article_no%type)
    return integer;

  --定位到最小库存的储位
  procedure p_locate_MinStockArea(strEnterPriseNo in varchar2,
                                  strWareHouseNo  in varchar2, --仓库代码
                                  strOwnerNo      in varchar2, --货主代码
                                  strArticleNo    in varchar2, --商品代码
                                  nPackingQTY     in bdef_article_packing.packing_qty%type,
                                  nArticleID      in number,
                                  nLocateQty      in number, --定位数量
                                  nRuleOrder      in number, --规则顺序
                                  strLocateCellNo out varchar2,
                                  strErrorMsg     out varchar2);

  procedure p_write_short_log(strEnterpriseNo in idata_locate_direct.enterprise_no%type,
                              strWareHouseNo  in idata_locate_direct.warehouse_no%type, --仓库代码
                              strSourceNo     in idata_locate_direct.source_no%type, --定位号
                              strOwnerNo      in idata_locate_direct.owner_no%type, --货主
                              strCellNo       in idata_locate_direct.cell_no%type, --货位
                              strArticleNo    in idata_locate_direct.article_no%type, --商品编码
                              nArticleID      in idata_locate_direct.article_id%type, --商品批次ID
                              nPackingQty     in idata_locate_direct.packing_qty%type, --库存包装
                              nLocateQty      in idata_locate_direct.article_qty%type, --需求量
                              strOperateType  in idata_locate_direct.operate_type%type, --定位类型
                              strShortReason  in varchar2);

end PKLG_ILOCATE;


/

