create package body        PKLG_ODATA_EXPCANCEL is

  /****************************************************************************************************
   创建人：hcx
   2015.4.27
   转病单写病单指示
  ******************************************************************************************************/
  procedure P_TurnOdataExpCancel(strEnterpriseNo in odata_exp_cancel_direct.enterprise_no%type, --企业
                                 strWareHouseNo  in odata_exp_cancel_direct.warehouse_no%type, --仓别
                                 strOwnerNo      in odata_exp_cancel_direct.owner_no%type, --货主
                                 strExpNo        in odata_exp_cancel_direct.exp_no%type, --出货单号
                                 strSourceType   in odata_exp_cancel_direct.source_type%type, --病单来源
                                 strUserId       in odata_exp_cancel_direct.rgst_Name%type, --操作人员
                                 strResult       out varchar2) is
    --返回结果
    v_iCount integer;
  begin
    strResult := 'N|[P_TurnOdataExpCancel]';

    --锁出货通知单头档
    update odata_exp_m t
       set t.status = t.status
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWareHouseNo
       and t.exp_no = strExpNo;

    --检查此出货单是否有对应的病单
    select count(*)
      into v_iCount
      from odata_exp_cancel_direct
     where enterprise_no = strEnterpriseNo
       and warehouse_no = strWareHouseNo
       and exp_no = strExpNo;

    if v_iCount = 0 then

      --写病单处理指示
      PKOBJ_ODATA_EXPCANCEL.P_InOdataExpCancelDirect(strEnterpriseNo,
                                                     strWareHouseNo,
                                                     strOwnerNo,
                                                     strExpNo,
                                                     strSourceType,
                                                     strUserId,
                                                     strResult);
      if (substr(strResult, 1, 1) <> 'Y') then
        return;
      end if;

      --修改出货通知单状态
      pkobj_odispatch.P_Update_Odata_exp_m(strEnterpriseNo,
                                           strWarehouseNo,
                                           strExpNo,
                                           '12',
                                           '90',
                                           '00',
                                           strUserId,
                                           strResult);
      if substr(strResult, 1, 1) = 'N' then
          --修改出货通知单状态
          pkobj_odispatch.P_Update_Odata_exp_m(strEnterpriseNo,
                                               strWarehouseNo,
                                               strExpNo,
                                               '16',
                                               '90',
                                               '00',
                                               strUserId,
                                               strResult);
          if substr(strResult, 1, 1) = 'N' then
            return;
          end if;
      end if;

      pkobj_odispatch.P_Update_Odata_exp_d(strEnterpriseNo,
                                           strWarehouseNo,
                                           strExpNo,
                                           '90',
                                           strUserId,
                                           strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;

    end if;

        --病单发单
      P_CreateOdataExpCancel(strEnterpriseNo,
                             strWareHouseNo,
                             strOwnerNo,
                             strExpNo,
                             strSourceType,
                             strUserId,
                             strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

    strResult := 'Y|成功';
  end P_TurnOdataExpCancel;
  /*****************************************************************************************************
   对某个波次有整单缺量的出货单转病单
   luozhiling
   2015.5.11
  *******************************************************************************************************/
  procedure P_WaveToexpCancel(strEnterpriseNo in odata_exp_cancel_direct.enterprise_no%type, --企业
                              strWareHouseNo  in odata_exp_cancel_direct.warehouse_no%type, --仓别
                              strOwnerNo      in odata_exp_cancel_direct.owner_no%type, --货主
                              strWaveNo       in odata_exp_cancel_direct.exp_no%type, --出货单号
                              strSourceType   in odata_exp_cancel_direct.source_type%type, --病单来源
                              strUserId       in odata_exp_cancel_direct.rgst_Name%type, --操作人员
                              strResult       out varchar2)

   is
    v_iCount integer;
  begin
    strResult := 'N|[P_WaveToexpCancel]';

    for GetExp in (select *
                     from odata_exp_m t
                    where t.enterprise_no = strEnterPriseNo
                      and t.warehouse_no = strWareHouseNo
                      and t.wave_no = strWaveNo
                      and t.status = COdataExpStatus.CancelMiddStatus) loop
      --锁出货通知单头档
      update odata_exp_m t
         set t.status = t.status
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.exp_no = GetExp.exp_no;

      --检查此出货单是否有对应的病单
      select count(*)
        into v_iCount
        from odata_exp_cancel_direct
       where enterprise_no = strEnterpriseNo
         and warehouse_no = strWareHouseNo
         and exp_no = GetExp.exp_no;

      if v_iCount = 0 then

        --写病单处理指示
        PKOBJ_ODATA_EXPCANCEL.P_InOdataExpCancelDirect(strEnterpriseNo,
                                                       strWareHouseNo,
                                                       strOwnerNo,
                                                       GetExp.exp_no,
                                                       '1',
                                                       strUserId,
                                                       strResult);
        if (substr(strResult, 1, 1) <> 'Y') then
          return;
        end if;

        --修改出货通知单状态
        pkobj_odispatch.P_Update_Odata_exp_m(strEnterpriseNo,
                                             strWarehouseNo,
                                             GetExp.exp_no,
                                             COdataExpStatus.CancelMiddStatus,
                                             '90',
                                             '00',
                                             strUserId,
                                             strResult);
        if substr(strResult, 1, 1) = 'N' then
          return;
        end if;

        pkobj_odispatch.P_Update_Odata_exp_d(strEnterpriseNo,
                                             strWarehouseNo,
                                             GetExp.exp_no,
                                             '90',
                                             strUserId,
                                             strResult);
        if substr(strResult, 1, 1) = 'N' then
          return;
        end if;

      end if;

      --病单发单
      P_CreateOdataExpCancel(strEnterpriseNo,
                             strWareHouseNo,
                             strOwnerNo,
                             GetExp.exp_no,
                             '1',
                             strUserId,
                             strResult);
      if (substr(strResult, 1, 1) <> 'Y') then
        return;
      end if;

    end loop;

    strResult := 'Y|[]';
  end P_WaveToexpCancel;
  /****************************************************************************************************
   创建人：hcx
   2015.4.27
   病单发单
  ******************************************************************************************************/
  procedure P_CreateOdataExpCancel(strEnterpriseNo in odata_exp_cancel_m.enterprise_no%type, --企业
                                   strWareHouseNo  in odata_exp_cancel_m.warehouse_no%type, --仓别
                                   strOwnerNo      in odata_exp_cancel_m.owner_no%type, --货主
                                   strExpNo        in odata_exp_cancel_m.exp_no%type, --出货单号
                                   strSourceType   in odata_exp_cancel_direct.source_type%type, --病单来源
                                   strUserId       in odata_exp_cancel_m.rgst_Name%type, --操作人员
                                   strResult       out varchar2) is
    --返回结果
    v_CanCelNo odata_exp_cancel_m.cancel_no%type; --病单单号
    v_iCount   integer;
    v_count    integer;
  begin
    strResult := 'N|[P_CreateOdataExpCancel]';

    if (strSourceType = '2') then
      --订单是否还有拣货指示未发单
      select count(*)
        into v_iCount
        from odata_outstock_direct t
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.exp_no = strExpNo
         and t.status in ('10', '11', '12');
      if v_iCount > 0 then
        strResult := 'N|[E22520]';
        return;
      end if;
      --订单是否还有拣货单未回单
      select count(*)
        into v_iCount
        from odata_outstock_d t
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.exp_no = strExpNo
         and t.status in ('10', '11', '12');
      if v_iCount > 0 then
        strResult := 'N|[E22521]';
        return;
      end if;
    end if;

    --获取病单单号
    PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                               strWareHouseNo,
                               CONST_DOCUMENTTYPE.ODATAOE,
                               v_CanCelNo,
                               strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    --跟新病单处理指示表病单来源
    if (strSourceType in ('3')) then
      update odata_exp_cancel_direct oecd
         set oecd.source_type = strSourceType,
             oecd.updt_name   = strUserId,
             oecd.updt_date   = sysdate
       where oecd.enterprise_no = strEnterpriseNo
         and oecd.warehouse_no = strWareHouseNo
         and oecd.exp_no = strExpNo
         and oecd.status = '10'
         and oecd.source_type = '2';
    end if;

    --写病单处理单头档
    PKOBJ_ODATA_EXPCANCEL.P_InsertOdataExpCancelM(strEnterpriseNo,
                                                  strWareHouseNo,
                                                  v_CanCelNo,
                                                  strOwnerNo,
                                                  strExpNo,
                                                  strSourceType,
                                                  strUserId,
                                                  strResult);
    if (substr(strResult, 1, 1) <> 'Y') then
      return;
    end if;

    --写病单处理单明细
    PKOBJ_ODATA_EXPCANCEL.P_InsertOdataExpCancelD(strEnterpriseNo,
                                                  strWareHouseNo,
                                                  strOwnerNo,
                                                  v_CanCelNo,
                                                  strExpNo,
                                                  strSourceType,
                                                  strUserId,
                                                  strResult);
    if (substr(strResult, 1, 1) <> 'Y') then
      return;
    end if;

    --修改出货通知单状态
    pkobj_odispatch.P_Update_Odata_exp_m(strEnterpriseNo,
                                         strWarehouseNo,
                                         strExpNo,
                                         '90',
                                         '92',
                                         '00',
                                         strUserId,
                                         strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    pkobj_odispatch.P_Update_Odata_exp_d(strEnterpriseNo,
                                         strWarehouseNo,
                                         strExpNo,
                                         '92',
                                         strUserId,
                                         strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    --更新病单处理指示状态
    update odata_exp_cancel_direct oecd
       set oecd.status    = '13',
           oecd.updt_name = strUserId,
           oecd.updt_date = sysdate
     where oecd.enterprise_no = strEnterpriseNo
       and oecd.warehouse_no = strWareHouseNo
       and oecd.exp_no = strExpNo
       and oecd.source_type = strSourceType
       and oecd.status = '10';

    --病单处理指示转历史
    PKOBJ_ODATA_EXPCANCEL.p_RemoveOdataExpCancelDirect(strEnterpriseNo,
                                                       strWarehouseNo,
                                                       strExpNo,
                                                       strSourceType,
                                                       strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    --写病单处理标签明细
    if (strSourceType in ('2', '3')) then
      select count(*)
        into v_count
        from (select slm.label_no
                from odata_exp_cancel_d t,
                     stock_label_d      sld,
                     stock_label_m      slm
               where t.enterprise_no = slm.enterprise_no
                 and t.enterprise_no = sld.enterprise_no
                 and t.warehouse_no = slm.warehouse_no
                 and t.warehouse_no = sld.warehouse_no
                 and t.exp_no = sld.exp_no
                 and sld.container_no = slm.container_no
                 and t.article_no = sld.article_no
                 and t.enterprise_no = strEnterpriseNo
                 and t.warehouse_no = strWareHouseNo
                 and t.cancel_no = v_CanCelNo);

      if (v_count = 0) then
        strResult := 'Y|[成功]';
        return;
      end if;

      PKOBJ_ODATA_EXPCANCEL.P_InOdataExpCancelLabelItem(strEnterpriseNo,
                                                        strWareHouseNo,
                                                        v_CanCelNo,
                                                        strExpNo,
                                                        strUserId,
                                                        strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;
    end if;
    strResult := 'Y|成功';

  end P_CreateOdataExpCancel;

  /****************************************************************************************************
   创建人：hcx
   2015.4.27
   病单处理-补拣
  ******************************************************************************************************/
  procedure P_RepeatLocate(strEnterpriseNo in odata_exp_cancel_m.enterprise_no%type, --企业
                           strWareHouseNo  in odata_exp_cancel_m.warehouse_no%type, --仓别
                           strOwnerNo      in odata_exp_cancel_m.owner_no%type, --货主
                           strCancelNo     in odata_exp_cancel_m.cancel_no%type, --病单单号
                           strExpNo        in odata_exp_cancel_m.exp_no%type, --出货单号
                           strSourceType   in odata_exp_cancel_m.source_type%type, --病单来源
                           strUserId       in odata_exp_cancel_m.rgst_Name%type, --操作人员
                           strResult       out varchar2) is
    --返回结果
    v_strWaveNo odata_exp_m.wave_no%type;
    v_ExpType   odata_exp_cancel_m.exp_type%type;
    v_iCount    integer;
  begin
    --更新出货单明细
    if (strSourceType in ('2', '3')) then
      for m in (select oecd.*
                  from odata_exp_cancel_d oecd
                 where oecd.enterprise_no = strEnterpriseNo
                   and oecd.warehouse_no = strWareHouseNo
                   and oecd.cancel_no = strCancelNo
                   and oecd.exp_no = strExpNo) loop
        update odata_exp_d oed
           set oed.locate_qty = m.real_qty, oed.status = '10'
         where oed.enterprise_no = strEnterpriseNo
           and oed.warehouse_no = strWareHouseNo
           and oed.exp_no = strExpNo
           and oed.article_no = m.article_no
           and oed.packing_qty = m.packing_qty;
      end loop;
    end if;
    --更新出货单头档状态
    pkobj_odispatch.P_Update_Odata_exp_m(strEnterpriseNo,
                                         strWarehouseNo,
                                         strExpNo,
                                         '92',
                                         '10',
                                         '00',
                                         strUserId,
                                         strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    select oecm.exp_type
      into v_ExpType
      from odata_exp_cancel_m oecm
     where oecm.enterprise_no = strEnterpriseNo
       and oecm.warehouse_no = strWareHouseNo
       and oecm.cancel_no = strCancelNo
       and oecm.exp_no = strExpNo;

    /*      --出货单集单
    PKLG_ODISPATCH.p_Auto_Set(strEnterpriseNo,strWarehouseNo,'N',strExpNo,
                              v_ExpType,strUserId,'0','A',v_strWaveNo,strResult);
         if substr(strResult, 1, 1) <> 'Y' then
            return;
         end if;*/

    --设置定位提交组别
    pklg_olocate.p_set_transgroup(strEnterpriseNo,
                                  strWareHouseNo,
                                  v_strWaveNo,
                                  strUserId,
                                  strResult);
    if substr(strResult, 1, 1) <> 'Y' then
      return;
    end if;
    --定位程序入口
    pklg_olocate.p_locate_main(strEnterpriseNo,
                               strWareHouseNo,
                               v_strWaveNo,
                               strUserId,
                               strResult);
    if substr(strResult, 1, 1) <> 'Y' then
      return;
    end if;
    --更新病单处理单头档
    update odata_exp_cancel_m oecm
       set oecm.handle_flag = '1',
           oecm.status      = '13',
           oecm.updt_name   = strUserId,
           oecm.updt_date   = sysdate
     where oecm.enterprise_no = strEnterpriseNo
       and oecm.warehouse_no = strWareHouseNo
       and oecm.owner_no = strOwnerNo
       and oecm.cancel_no = strCancelNo
       and oecm.exp_no = strExpNo;
    --更新病单处理单明细
    pkobj_odispatch.P_Update_Odata_exp_cancel_d(strEnterpriseNo,
                                                strWarehouseNo,
                                                strCancelNo,
                                                '13',
                                                strUserId,
                                                strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;
    --病单头档明细转历史
    PKOBJ_ODATA_EXPCANCEL.proc_RemoveCancel(strEnterpriseNo,
                                            strWarehouseNo,
                                            strCancelNo,
                                            strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;
    --判断病单标签表是否有数据（定位时转病单不写标签明细）
    select count(*)
      into v_iCount
      from odata_exp_cancel_label_item item
     where item.enterprise_no = strEnterpriseNo
       and item.warehouse_no = strWarehouseNo
       and item.owner_no = strOwnerNo
       and item.cancel_no = strCancelNo;
    if v_iCount = 0 then
      strResult := '成功';
      return;
    end if;
    --锁病单标签
    update odata_exp_cancel_label_item t
       set t.status = t.status
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWarehouseNo
       and t.cancel_no = strCancelNo;

    --根据病单标签明细表处理标签（置回之前状态）
    for GetLabel in (select distinct t.d_label_no,
                                     t.d_container_no,
                                     t.label_status
                       from odata_exp_cancel_label_item t
                      where t.enterprise_no = strEnterpriseNo
                        and t.warehouse_no = strWarehouseNo
                        and t.cancel_no = strCancelNo
                        and t.status <> '15') loop

      --更新标签明细表状态
      PKOBJ_label.p_updt_labelDetail_status(strEnterPriseNo,
                                            strWarehouseNo,
                                            GetLabel.d_container_no,
                                            strUserId,
                                            GetLabel.label_status,
                                            strResult);

      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;

      --更新标签头档表状态
      PKOBJ_label.p_updt_label_status(strEnterPriseNo,
                                      strWarehouseNo,
                                      GetLabel.d_container_no,
                                      strUserId,
                                      GetLabel.label_status,
                                      strResult);

      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;

    end loop;

    --更新病单标签表
    update odata_exp_cancel_label_item t
       set t.status = '13'
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWarehouseNo
       and t.cancel_no = strCancelNo;

    --病单标签表转历史
    pkobj_odata_expcancel.proc_RemoveCancelLabel(strEnterpriseNo,
                                                 strWarehouseNo,
                                                 strCancelNo,
                                                 strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    strResult := 'Y|成功';
  end P_RepeatLocate;
  /*****************************************************************************************************************
  hcx
  20150430
  功能说明：病单处理-上传
  ***************************************************************************************************************/

  procedure P_UpLocate(strEnterpriseNo in odata_exp_cancel_m.enterprise_no%type, --企业
                       strWareHouseNo  in odata_exp_cancel_m.warehouse_no%type, --仓别
                       strOwnerNo      in odata_exp_cancel_m.owner_no%type, --货主
                       strCancelNo     in odata_exp_cancel_m.cancel_no%type, --病单单号
                       strExpNo        in odata_exp_cancel_m.exp_no%type, --出货单号
                       strUserId       in odata_exp_cancel_label_item.rgst_name%type, --操作人员
                       strResult       out varchar2) is --返回结果
  begin
    strResult := 'N|[p_cancel_check]';

    --更新病单处理单头档
    update odata_exp_cancel_m oecm
       set oecm.send_flag = '13',
           oecm.status    = '12',
           oecm.updt_name = strUserId,
           oecm.updt_date = sysdate
     where oecm.enterprise_no = strEnterpriseNo
       and oecm.warehouse_no = strWareHouseNo
       and oecm.owner_no = strOwnerNo
       and oecm.cancel_no = strCancelNo
       and oecm.exp_no = strExpNo;
    --更新病单处理单明细状态
    pkobj_odispatch.P_Update_Odata_exp_cancel_d(strEnterpriseNo,
                                                strWarehouseNo,
                                                strCancelNo,
                                                '12',
                                                strUserId,
                                                strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;
    --更新出货单状态
    pkobj_odispatch.P_Update_Odata_exp_m(strEnterpriseNo,
                                         strWarehouseNo,
                                         strExpNo,
                                         '92',
                                         '94',
                                         '00',
                                         strUserId,
                                         strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;
    pkobj_odispatch.P_Update_Odata_exp_d(strEnterpriseNo,
                                         strWarehouseNo,
                                         strExpNo,
                                         '94',
                                         strUserId,
                                         strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;
    strResult := 'Y|成功';
  end P_UpLocate;
  /*****************************************************************************************************************
  hekangli
  20150428
  功能说明：病单审核
  ***************************************************************************************************************/
  procedure p_cancel_check(strEnterpriseNo in Odata_Exp_Cancel_m.Enterprise_No%type,
                           strWarehouseNo  in ODATA_EXP_CANCEL_M.Warehouse_No%type,
                           strOwnerNo      in odata_exp_cancel_m.owner_no%type,
                           strCancelNo     in odata_exp_cancel_m.cancel_no%type,
                           strExpNo        in odata_exp_cancel_m.exp_no%type,
                           strWorkerNo     in odata_exp_cancel_m.rgst_name%type,
                           strWorkSpaceNo  IN idata_locate_direct.dock_no%type, --码头号
                           strHandleflag   in odata_exp_cancel_m.handle_flag%type, --处理方式
                           strResult       out varchar2) is

  begin
    strResult := 'N|[p_cancel_check]';

    if strHandleflag = '2' then
      --订单取消
      p_cancel_colsedata(strEnterpriseNo,
                         strWarehouseNo,
                         strOwnerNo,
                         strCancelNo,
                         strExpNo,
                         strWorkerNo,
                         strWorkSpaceNo,
                         strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;

    else
      if strHandleflag = '3' then
        --出货
        p_cancel_outdata(strEnterpriseNo,
                         strWarehouseNo,
                         strOwnerNo,
                         strCancelNo,
                         strExpNo,
                         strWorkerNo,
                         strResult);
        if substr(strResult, 1, 1) = 'N' then
          return;
        end if;
      end if;
    end if;

    strResult := 'Y|成功！';

  end p_cancel_check;

  /*****************************************************************************************************************
  hekangli
  20150428
  功能说明：病单审核，处理方式为出货（有多少出多少）
  ***************************************************************************************************************/
  procedure p_cancel_outdata(strEnterpriseNo in Odata_Exp_Cancel_m.Enterprise_No%type,
                             strWarehouseNo  in ODATA_EXP_CANCEL_M.Warehouse_No%type,
                             strOwnerNo      in odata_exp_cancel_m.owner_no%type,
                             strCancelNo     in odata_exp_cancel_m.cancel_no%type,
                             strExpNo        in odata_exp_cancel_m.exp_no%type,
                             strWorkerNo     in odata_exp_cancel_m.rgst_name%type,
                             strResult       out varchar2) is
    v_iCount integer;
  begin
    strResult := 'N|[p_cancel_outdata]';

    v_iCount := 0;

    --锁病单标签
    update odata_exp_cancel_label_item t
       set t.status = t.status
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWarehouseNo
       and t.cancel_no = strCancelNo;

    --根据病单标签明细表处理标签（置回之前状态）
    for GetLabel in (select distinct t.d_label_no,
                                     t.d_container_no,
                                     t.label_status
                       from odata_exp_cancel_label_item t
                      where t.enterprise_no = strEnterpriseNo
                        and t.warehouse_no = strWarehouseNo
                        and t.cancel_no = strCancelNo
                        and t.status <> '15') loop

      v_iCount := v_iCount + 1;

      --更新标签明细表状态
      PKOBJ_label.p_updt_labelDetail_status(strEnterPriseNo,
                                            strWarehouseNo,
                                            GetLabel.d_container_no,
                                            strWorkerNo,
                                            GetLabel.label_status,
                                            strResult);

      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;

      --更新标签头档表状态
      PKOBJ_label.p_updt_label_status(strEnterPriseNo,
                                      strWarehouseNo,
                                      GetLabel.d_container_no,
                                      strWorkerNo,
                                      GetLabel.label_status,
                                      strResult);

      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;

    end loop;

    --更新病单标签表为已审核
    update odata_exp_cancel_label_item t
       set t.status = '15'
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWarehouseNo
       and t.cancel_no = strCancelNo;

    --病单标签表转历史
    pkobj_odata_expcancel.proc_RemoveCancelLabel(strEnterpriseNo,
                                                 strWarehouseNo,
                                                 strCancelNo,
                                                 strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    if v_iCount = 0 then
      --没有要处理的标签
      strResult := 'N|[E39005]';
      return;
    end if;

    --修改出货通知单状态为已定位
    pkobj_odispatch.P_Update_Odata_exp_m(strEnterpriseNo,
                                         strWarehouseNo,
                                         strExpNo,
                                         COdataExpStatus.CancelGetTask,
                                         COdataExpStatus.locateExp,
                                         '00',
                                         strWorkerNo,
                                         strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    pkobj_odispatch.P_Update_Odata_exp_d(strEnterpriseNo,
                                         strWarehouseNo,
                                         strExpNo,
                                         COdataExpStatus.locateExp,
                                         strWorkerNo,
                                         strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    -- 修改病单通知单状态为结案
    pkobj_odispatch.P_Update_Odata_exp_cancel_m(strEnterpriseNo,
                                                strWarehouseNo,
                                                strCancelNo,
                                                '10',
                                                '13',
                                                strWorkerNo,
                                                strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    pkobj_odispatch.P_Update_Odata_exp_cancel_d(strEnterpriseNo,
                                                strWarehouseNo,
                                                strCancelNo,
                                                '13',
                                                strWorkerNo,
                                                strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    --病单通知单转历史
    pkobj_odata_expcancel.proc_RemoveCancel(strEnterpriseNo,
                                            strWarehouseNo,
                                            strCancelNo,
                                            strResult);

    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    strResult := 'Y|成功！';
  end p_cancel_outdata;
  /*****************************************************************************************************************
   hekangli
  20150428
  功能说明：病单审核，处理方式为取消订单
  ***************************************************************************************************************/
  procedure p_cancel_colsedata(strEnterpriseNo in Odata_Exp_Cancel_m.Enterprise_No%type,
                               strWarehouseNo  in ODATA_EXP_CANCEL_M.Warehouse_No%type,
                               strOwnerNo      in odata_exp_cancel_m.owner_no%type,
                               strCancelNo     in odata_exp_cancel_m.cancel_no%type,
                               strExpNo        in odata_exp_cancel_m.exp_no%type,
                               strWorkerNo     in odata_exp_cancel_m.rgst_name%type, --操作人
                               strWorkSpaceNo  IN idata_locate_direct.dock_no%type, --码头号
                               strResult       out varchar2) is
    v_strLocateNo           idata_locate_direct.locate_no%type; --定位号
    v_strTaskNo             job_printtask_m.task_no%type;
    v_strCellId             stock_content.cell_id%type; --储位id
    v_strCellNo             stock_content.cell_no%type; --病单销毁区
    v_strInstockLabelNo     stock_label_m.label_no%type;
    v_strInstockContainerNo stock_label_m.container_no%type;
    strSessionID            varchar2(10);
    v_iCount                integer;
    v_iCount2               integer;

  begin
    strResult := 'N|[p_cancel_colsedata]';
    v_iCount  := 0;

    --锁病单
    update odata_exp_cancel_m t
       set t.status = t.status
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWarehouseNo
       and t.cancel_no = strCancelNo;

    --判断病单标签表是否有数据（定位时转病单不写标签明细）
    select count(*)
      into v_iCount2
      from odata_exp_cancel_label_item item
     where item.enterprise_no = strEnterpriseNo
       and item.warehouse_no = strWarehouseNo
       and item.owner_no = strOwnerNo
       and item.cancel_no = strCancelNo;

    if v_iCount2 <> 0 then
      --有标签明细

      --获取病单暂存区储位
      begin
        select CDC.CELL_NO
          into v_strCellNo
          FROM CDEF_DEFAREA CDA, CDEF_DEFCELL CDC
         WHERE CDA.ENTERPRISE_NO = CDC.ENTERPRISE_NO
           AND CDA.warehouse_no = CDC.warehouse_no
           AND CDA.WARE_NO = CDC.WARE_NO
           AND CDA.AREA_NO = CDC.AREA_NO
           AND CDA.AREA_ATTRIBUTE = '3'
           --AND CDA.ATTRIBUTE_TYPE in ('2', '3', '4')
           and cda.warehouse_no = strWareHouseNo
           and cda.enterprise_no = strEnterpriseNo
           and rownum < 2
         order by cdc.cell_no;
      exception
        when no_data_found then
          strResult := 'N|[E39006]'; --获取病单问题区失败;
          return;
      end;

      --将需要回库的标签做标签销毁,销毁标签的同时也要对库存进行处理
      --处理库存
      for t in (select *
                  from odata_exp_cancel_label_item item
                 where item.enterprise_no = strEnterpriseNo
                   and item.warehouse_no = strWarehouseNo
                   and item.owner_no = strOwnerNo
                   and item.cancel_no = strCancelNo
                 order by item.d_container_no, item.article_no) loop

        --根据标签转移库存
        --1.增加病单问题区库存
        PKOBJ_STOCK.p_InstContent_qtyByCellNo(strEnterpriseNo, --
                                              strWarehouseNo, --仓别
                                              strOwnerNo, --货主
                                              'N', --部门
                                              t.article_no, --商品编码
                                              t.article_id, --商品ID
                                              v_strCellNo, --目的储位
                                              t.owner_cell_no, --源储位
                                              t.packing_qty, --包装数量
                                              t.real_qty, --转移数量
                                              t.d_label_no, --标签号
                                              t.d_label_no, --子标签
                                              '1', --存储类型
                                              'N', --存储类型的值
                                              strWorkerNo, --操作人
                                              strCancelNo, --整理单号
                                              '1', --操作工具
                                              '0', --是否可手工移库 0:不允许手工移库；1：可手工移库
                                              v_strCellId, --返回的储位ID
                                              strResult --返回的结果
                                              );
        if (substr(strResult, 1, 1) <> 'Y') then
          strResult := strResult;
          return;
        end if;

        --2.扣减源库存 循环扣减, 不处理预约上下架量，直接扣减库存
        PKOBJ_STOCK.p_UpdtContent_qtyByCellNo(strEnterpriseNo, --
                                              strWarehouseNo, --仓别
                                              strOwnerNo, --货主
                                              t.article_no, --商品编码
                                              t.article_id, --商品ID
                                              t.owner_cell_no, --源储位
                                              v_strCellNo, --目的储位
                                              t.packing_qty, --包装数量
                                              t.real_qty, --转移数量
                                              t.d_label_no, --源标签
                                              '1', --存储类型
                                              'N', --存储类型的值
                                              strWorkerNo, --操作人
                                              strCancelNo, --整理单号
                                              1, --操作工具
                                              strResult); --返回结果
        if (substr(strResult, 1, 1) <> 'Y') then
          strResult := strResult;
          return;
        end if;

      end loop;

      --处理标签

      --更新标签头档和明细为撤票销毁
      for GetLabel in (select distinct t.owner_cell_no,
                                       t.d_label_no,
                                       t.d_container_no,
                                       t.label_status
                         from odata_exp_cancel_label_item t
                        where t.enterprise_no = strEnterpriseNo
                          and t.warehouse_no = strWarehouseNo
                          and t.cancel_no = strCancelNo) loop

        v_iCount := v_iCount + 1;

        --更新标签明细表状态
        PKOBJ_label.p_updt_labelDetail_status(strEnterPriseNo,
                                              strWarehouseNo,
                                              GetLabel.d_container_no,
                                              strWorkerNo,
                                              CLabelStatus.BillCANCEL_LABEL_CANCEL,
                                              strResult);

        if substr(strResult, 1, 1) = 'N' then
          return;
        end if;

        --更新标签头档表状态
        PKOBJ_label.p_updt_label_status(strEnterPriseNo,
                                        strWarehouseNo,
                                        GetLabel.d_container_no,
                                        strWorkerNo,
                                        CLabelStatus.BillCANCEL_LABEL_CANCEL,
                                        strResult);

        if substr(strResult, 1, 1) = 'N' then
          return;
        end if;

        --标签表转历史
        PKOBJ_label.proc_RemoveLabel(strEnterPriseNo,
                                     strWarehouseNo,
                                     GetLabel.d_container_no,
                                     strResult);

        if substr(strResult, 1, 1) = 'N' then
          return;
        end if;

        -- 产生新的上架标签
        --取P标签 只取一个标签
        pklg_wms_base.p_get_ContainerNoBase(strEnterpriseNo,
                                            strWareHouseNo,
                                            'P',
                                            strWorkerNo,
                                            'D',
                                            1,
                                            '2',
                                            '31',
                                            v_strInstockLabelNo,
                                            v_strInstockContainerNo,
                                            strSessionID,
                                            strResult);
        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        /*pkobj_label.proc_Insert_LabelMaster(strEnterPriseNo,strWarehouseNo,'N',strCancelNo,GetLabel.d_label_no,
        v_strInstockContainerNo,'P','N',GetLabel.owner_cell_no,'N','N','N','N','N','0','N',
        strWorkSpaceNo,'N',strWorkerNo,CONST_REPORTID.ImNewLabel_P,'N','N','1','0',v_strInstockContainerNo,'0','0',strResult);*/

        pkobj_label.proc_Insert_LabelMaster(strEnterPriseNo,
                                            strWarehouseNo,
                                            'N',
                                            strCancelNo,
                                            GetLabel.d_label_no,
                                            v_strInstockContainerNo,
                                            'P',
                                            'N',
                                            GetLabel.owner_cell_no,
                                            'N',
                                            'N',
                                            'N',
                                            'N',
                                            'N',
                                            '0',
                                            'N',
                                            strWorkSpaceNo,
                                            'N',
                                            strWorkerNo,
                                            'AA',
                                            'N',
                                            'N',
                                            '1',
                                            '0',
                                            v_strInstockContainerNo,
                                            '0',
                                            '0',
                                            'N',
                                            strResult);
        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;
      end loop;

      --更新病单标签表为已审核
      update odata_exp_cancel_label_item t
         set t.status = '13'
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWarehouseNo
         and t.cancel_no = strCancelNo;

      if v_iCount = 0 then
        --没有要处理的标签
        strResult := 'N|[E39005]';
        return;
      end if;

      --获取定位号
      PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                 strWareHouseNo,
                                 CONST_DOCUMENTTYPE.IDATAIL,
                                 v_strLocateNo,
                                 strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        strResult := strResult;
        return;
      end if;

      --写入库定位i指示
      insert into idata_locate_direct
        (enterprise_no,
         warehouse_no,
         owner_no,
         locate_no,
         locate_type,
         auto_locate_flag,
         container_locate_flag,
         source_no,
         cell_no,
         cell_id,
         operate_type,
         article_no,
         article_id,
         packing_qty,
         article_qty,
         dock_no,
         status,
         locate_time,
         check_worker,
         sub_label_no,
         label_no,
         business_type,
         fixpal_flag,
         rgst_name,
         rgst_date,
         serial_no,IMPORT_TYPE)
        select strEnterpriseNo,
               strWarehouseNo,
               strOwnerNo,
               v_strLocateNo,
               '5',
               '0',
               '1',
               strCancelNo,
               sc.cell_no,
               sc.cell_id,
               'C',
               sc.article_no,
               sc.article_id,
               sc.packing_qty,
               sc.qty,
               strWorkSpaceNo,
               '10',
               sysdate,
               strWorkerNo,
               sc.label_no,
               sc.sub_label_no,
               '0',
               '2',
               strWorkerNo,
               sysdate,
               'N','IR'
          from stock_content sc
         where sc.enterprise_no = strEnterPriseNo
           and sc.warehouse_no = strWareHouseNo
           and (sc.label_no, sc.article_no, sc.article_id) in
               (select oe.d_label_no, oe.article_no, oe.article_id
                  from odata_exp_cancel_label_item oe
                 where oe.enterprise_no = strEnterPriseNo
                   and oe.warehouse_no = strWareHouseNo
                   and oe.cancel_no = strCanCelNo);
      if sql%rowcount <= 0 then
        strResult := 'N|[E39003]'; --写入病单处理单明细失败];
        return;
      end if;

      --入库定位
      PKLG_ILOCATE.p_locate_main(strEnterpriseNo,
                                 strWarehouseNo,
                                 strOwnerNo,
                                 v_strLocateNo,
                                 '0',
                                 strWorkerNo,
                                 v_strTaskNo,
                                 strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;

      --入库发单，写上架单
      pklg_idata.P_InsertInstock(strEnterpriseNo,
                                 strWarehouseNo,
                                 strWorkerNo,
                                 v_strLocateNo,
                                 strWorkSpaceNo,
                                 '0',
                                 v_strTaskNo,
                                 strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;

      --病单标签转历史
      pkobj_odata_expcancel.proc_RemoveCancelLabel(strEnterpriseNo,
                                                   strWarehouseNo,
                                                   strCancelNo,
                                                   strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;
    end if;

    --对应的出货单做取消
    pkobj_odispatch.P_Update_Odata_exp_m(strEnterpriseNo,
                                         strWarehouseNo,
                                         strExpNo,
                                         COdataExpStatus.CancelGetTask,
                                         COdataExpStatus.CancelClose,
                                         '50',
                                         strWorkerNo,
                                         strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    pkobj_odispatch.P_Update_Odata_exp_d(strEnterpriseNo,
                                         strWarehouseNo,
                                         strExpNo,
                                         COdataExpStatus.CancelClose,
                                         strWorkerNo,
                                         strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    --修改病单通知单状态为结案
    pkobj_odispatch.P_Update_Odata_exp_cancel_m(strEnterpriseNo,
                                                strWarehouseNo,
                                                strCancelNo,
                                                '10',
                                                '13',
                                                strWorkerNo,
                                                strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    pkobj_odispatch.P_Update_Odata_exp_cancel_d(strEnterpriseNo,
                                                strWarehouseNo,
                                                strCancelNo,
                                                '13',
                                                strWorkerNo,
                                                strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    --病单通知单转历史
    pkobj_odata_expcancel.proc_RemoveCancel(strEnterpriseNo,
                                            strWarehouseNo,
                                            strCancelNo,
                                            strResult);

    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    strResult := 'Y|成功！';

  end p_cancel_colsedata;

  /**********************************************************************************************
  功能说明：对销毁的标签做自动回库处理
  1、将标签库存移到销毁去；
  2、改变标签状态；
  3、根据标签写移库单；
  4、移库回单
  luozhiling
  2015.05.08
  **********************************************************************************************/
  procedure P_Cancel_LabeltoMove(strEnterpriseNo in stock_label_m.enterprise_no%type,
                                 strWareHouseNo  in stock_label_m.warehouse_no%type,
                                 strLabelNo      in stock_label_m.label_no%type,
                                 strWorkerNo     in stock_label_m.rgst_name%type,
                                 strResult       out varchar2) is
    strPaperNo       stock_label_m.source_no%type;
    v_strCancelCell  cdef_defcell.cell_no%type;
    v_nCellID        stock_content.cell_id%type;
    v_strLabelNo     stock_label_m.label_no%type;
    v_strContainerNo stock_label_m.container_no%type;
    v_strOwnerNo     bdef_defowner.owner_no%type;
    v_iCount         integer;

  begin
    strResult := 'N|[P_Cancel_LabeltoMove]';
    v_iCount  := 0;
    --读取标签销毁储区
    begin
      select cell_no
        into v_strCancelCell
        from cdef_defarea cd, cdef_defcell t
       where cd.warehouse_no = t.warehouse_no
         and cd.area_no = t.area_no
         and cd.ware_no = t.ware_no
         and cd.area_usetype = '1'
         and cd.area_attribute = '3' --and cd.attribute_type='0'
         and cd.enterprise_no = t.enterprise_no
         and cd.enterprise_no = strEnterpriseNo
         and rownum = 1;
    exception
      when no_data_found then
        strResult := 'N|[E21306]'; --没有读取到差异数量计账储位
        return;
    end;

    --取标签销毁单号
    begin
      PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                 strWareHouseNo,
                                 CONST_DOCUMENTTYPE.LABELXH,
                                 strPaperNo,
                                 strResult);
      if (strPaperNo is null or substr(strResult, 1, 1) = 'N') then
        strResult := 'N|[E20909]'; --取汇总验收单号错误!
        return;
      end if;
    end;

    --获取标签内部容器号
    begin
      select container_no
        into v_strContainerNo
        from stock_label_m slm
       where slm.warehouse_no = strWareHouseNo
         and slm.label_no = strLabelNo
         and slm.enterprise_no = strEnterpriseNo;
    exception
      when no_data_found then
        strResult := 'N|[E21707]';
        return;
    end;
    --

    for GetLableItem in (select slm.owner_cell_no, slm.HM_MANUAL_FLAG, sld.*
                           from stock_label_m slm, stock_label_d sld
                          where slm.enterprise_no = sld.enterprise_no
                            and slm.enterprise_no = strEnterPriseNo
                            and slm.warehouse_no = sld.warehouse_no
                            and slm.container_no = sld.container_no
                            and slm.warehouse_no = strWareHouseNo
                            and slm.label_no = strLabelNo) loop

      v_iCount     := v_iCount + 1;
      v_strOwnerNo := GetLableItem.owner_no;
      --将库存移至标签销毁区；
      if GetLableItem.HM_MANUAL_FLAG = '0' then
        v_strLabelNo := strLabelNo;
      else
        v_strLabelNo := 'N';
      end if;

      --将目的储位库存转移到销毁区:扣减来源储位库存
      pkobj_stock.p_UpdtContent_qtyByCellNo(strEnterpriseNo,
                                            strWareHouseNo,
                                            GetLableItem.owner_no,
                                            GetLableItem.article_no,
                                            GetLableItem.article_id,
                                            GetLableItem.owner_cell_no,
                                            v_strCancelCell,
                                            GetLableItem.packing_qty,
                                            GetLableItem.qty,
                                            v_strLabelNo,
                                            '1',
                                            'N',
                                            strWorkerNo,
                                            strPaperNo,
                                            '1',
                                            strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --增加目的储位库存
      pkobj_stock.p_InstContent_qtyByCellNo(strEnterpriseNo,
                                            strWareHouseNo,
                                            GetLableItem.owner_no,
                                            'N',
                                            GetLableItem.article_no,
                                            GetLableItem.article_id,
                                            v_strCancelCell,
                                            GetLableItem.owner_cell_no,
                                            GetLableItem.packing_qty,
                                            GetLableItem.qty,
                                            v_strLabelNo,
                                            v_strLabelNo,
                                            '1',
                                            'N',
                                            strWorkerNo,
                                            strPaperNo,
                                            '1',
                                            '1',
                                            v_nCellID,
                                            strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

    end loop;

    if v_iCount > 0 then

      --更新标签的所属储位
      update stock_label_m t
         set t.owner_cell_no = v_strCancelCell
       where t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strWareHouseNo
         and t.label_no = strLabelNo;

      --将标签明细数据回库
      PKLG_MDATA.Proc_LabelBackCell(strEnterpriseNo,
                                    strWareHouseNo,
                                    v_strOwnerNo,
                                    strLabelNo,
                                    strWorkerNo,
                                    strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --更新标签状态
      pkobj_label.p_updt_label_status(strEnterpriseNo,
                                      strWareHouseNo,
                                      v_strContainerNo,
                                      strWorkerNo,
                                      CLabelStatus.DIVIDED_CANCEL,
                                      strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --标签转历史
      pkobj_label.proc_RemoveLabel(strEnterpriseNo,
                                   strWareHouseNo,
                                   v_strContainerNo,
                                   strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
    else
      strResult := 'N|[EEEE]';
    end if;

    strResult := 'Y|[成功]';
  end P_Cancel_LabeltoMove;

end PKLG_ODATA_EXPCANCEL;

/

