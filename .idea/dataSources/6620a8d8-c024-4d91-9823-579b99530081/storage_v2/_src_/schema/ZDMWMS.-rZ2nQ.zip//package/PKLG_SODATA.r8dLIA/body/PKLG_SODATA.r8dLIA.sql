create package body        PKLG_SODATA is
  /***********************************************************************************************************
   创建人：luozhiling
   时间：2015.7.27
   功能：报损手建单
  ***********************************************************************************************************/
  procedure P_CreatePlan(strEnterPriseNo in sodata_waste_m.enterprise_no%type,
                         strWareHouseNo  in sodata_waste_m.warehouse_no%type, --仓库编码
                         strOwnerNo      in sodata_waste_m.owner_no%type,
                         strUserId       in sodata_waste_m.rgst_name%type,
                         strCreateFlag   in sodata_waste_m.create_flag%type, --
                         strStockType   in sodata_waste_m.stock_type%type,
                         strStockValue  in sodata_waste_m.stock_value%type,
                         strOrgNo       in sodata_waste_m.org_no%type,
                         strArticleNo    in sodata_waste_d.article_no%type, --商品编码
                         nPackingQty     in sodata_waste_d.packing_qty%type,
                         strLotNo        in sodata_waste_d.lot_no%type,
                         nPlanQty        in sodata_waste_d.waste_qty%type, --计划报损量
                         strsWasteNo     in sodata_waste_d.waste_no%type, --原计划单号
                         strWasteNo       out sodata_waste_d.waste_no%type, --返回的计划单号
                         strResult       OUT varchar2) is
    v_strWasteNo sodata_waste_d.waste_no%type;
  begin

    strResult := 'N|[P_CreatePlan]';

    if strsWasteNo = 'N' then

      --写报损单头档
      pkobj_sodata.P_InsertWasteHead(strEnterPriseNo,strWareHouseNo,strOwnerNo,strCreateFlag,
          strStockType,strStockValue,strOrgNo,strUserId,v_strWasteNo,strResult);

      if substr(strResult, 1, 1) = 'N' then
        strResult:='N|[写报损单头档失败]';
        return;
      end if;

      strWasteNo := v_strWasteNo;
    else
      v_strWasteNo := strsWasteNo;
      strWasteNo   := strsWasteNo;
    end if;

    --写报损通知单明细
    pkobj_Sodata.P_InsertWasteItem(strEnterPriseNo ,strWarehouseNo ,strOwnerNo, v_strWasteNo ,strArticleNo,
            nPackingQty,strLotNo,'0',nPlanQty,strResult);

    if substr(strResult, 1, 1) = 'N' then
      strResult:='N|[写报损单明细失败]';
      return;
    end if;

    strResult := 'Y';

  end P_CreatePlan;

  /*****************************************************************************************************
   功能说明：报损定位
   2015.7.27
   huangb 20160511 新增策略
  *****************************************************************************************************/
  procedure P_solocate_main(strEnterPriseNo in sodata_waste_m.enterprise_no%type,
                             strWareHouseNo  in sodata_waste_m.warehouse_no%type, --仓库编码
                             strOwnerNo      in sodata_waste_m.owner_no%type,
                             strWasteNo      in sodata_waste_m.waste_no%type,
                             strUserId       in sodata_waste_m.rgst_name%type,
                             strResult       OUT varchar2) is
    v_StrategyId   wms_rodataorder.strategy_id%type;
    v_Packinglevel wms_rodataorder.strategy_id%type;
    strDestCellNo  cdef_defcell.cell_no%type;

    /*cursor v_GetLocateItem is
      select swm.org_no,swm.stock_type,swm.stock_value,swd.*
        from sodata_waste_m swm,sodata_waste_d swd
        where swm.enterprise_no=swd.enterprise_no and swm.warehouse_no=swd.warehouse_no
        and swm.waste_no=swd.waste_no and swm.enterprise_no=strEnterPriseNo
        and swm.warehouse_no=strWareHouseNo and swm.waste_no=strWasteNo and swm.status='10'
        order by swd.article_no,swd.po_id;

    nRemainQty    sodata_waste_d.waste_qty%type; --剩余定位量
    v_iCount      integer;*/

  begin
      strResult:='N|[P_solocate_main]';

      --锁报损单头档
      update sodata_waste_m t set t.status=status
      where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo
      and t.waste_no=strWasteNo and t.status='10';

      if sql%notfound then
        strResult := 'N|[更新报损单头档失败]';
        return;
      end if;

      --获取报损区暂存区
      begin
          select cell_no
            into strDestCellNo
            from cdef_defarea cd, cdef_defcell t
           where cd.enterprise_no = t.enterprise_no
             and cd.enterprise_no = strEnterPriseNo
             and cd.ware_no = t.ware_no
             and cd.area_no = t.area_no
             and t.warehouse_no = cd.warehouse_no
             and t.warehouse_no = strWareHouseNo
             and cd.area_usetype = '2'
             and cd.area_attribute = '1'
             and cd.attribute_type = '7'
             and rownum = 1;
      exception
        when no_data_found then
          strResult := 'N|[获取不到报损暂存区储位]';
          return;
      end;

      --huangb 20160511 新增策略
      begin
       select wws.strategy_id, wws.Packinglevel
         into v_StrategyId, v_Packinglevel
         from sodata_waste_m swm,wms_warehouse_sodataorder wws
        where wws.enterprise_no = swm.enterprise_no
          and wws.warehouse_no = swm.warehouse_no
          and wws.owner_no = swm.owner_no
          and wws.waste_type = swm.waste_type
          and swm.enterprise_no = strEnterpriseNo
          and swm.warehouse_no = strWareHouseNo
          and swm.owner_no = strOwnerNo
          and swm.waste_no = strWasteNo;
      exception
        when no_data_found then
          --获取货主级别对应的标识
          begin
            select wos.strategy_id, wos.Packinglevel
              into v_StrategyId, v_Packinglevel
              from sodata_waste_m swm,wms_owner_sodataorder wos
             where wos.enterprise_no = swm.enterprise_no
               and wos.owner_no = swm.owner_no
               and wos.waste_type = swm.waste_type
               and swm.enterprise_no = strEnterpriseNo
               and swm.warehouse_no = strWareHouseNo
               and swm.owner_no = strOwnerNo
               and swm.waste_no = strWasteNo;
          exception
            when no_data_found then
              --获取系统级别对应的标识
              begin
                select ws.strategy_id, ws.Packinglevel
                  into v_StrategyId, v_Packinglevel
                  from sodata_waste_m swm,wms_sodataorder ws
                 where ws.enterprise_no = swm.enterprise_no
                   and ws.waste_type = swm.waste_type
                   and swm.enterprise_no = strEnterpriseNo
                   and swm.warehouse_no = strWareHouseNo
                   and swm.owner_no = strOwnerNo
                   and swm.waste_no = strWasteNo;
              exception
                when no_data_found then
                  strResult := 'N|[找不到对应的单据配置]';
                  return;
              end;
          end;
      end;

      --huangb 20160511
      /*for GetLocateItem in v_GetLocateItem loop
        v_iCount   := v_iCount + 1;
        nRemainQty := GetLocateItem.waste_qty - GetLocateItem.locate_qty;

        --报损定位
        pkobj_sodata.P_InsertSodateDirect(strEnterPriseNo,strWareHouseNo,strWasteNo,GetLocateItem.article_no,
             GetLocateItem.lot_no,GetLocateItem.produce_date,GetLocateItem.expire_date,
             GetLocateItem.stock_type,GetLocateItem.stock_value,GetLocateItem.org_no,strDestCellNo,strUserId,
             GetLocateItem.po_id,nRemainQty,strResult);
      end loop;


      if v_iCount = 0 then
        strResult := 'N|[获取不到报损通知单明细]';
        return;
      end if;
      */

      --报损写下架指示以及库存
      P_SODATA_LOCATE(strEnterPriseNo,strWareHouseNo,strOwnerNo, strWasteNo,
                      v_StrategyId,v_Packinglevel,strDestCellNo,strUserId,strResult);

      update sodata_waste_m
         set status    = '14',
             updt_name = strUserId,
             updt_datE = sysdate
       where enterprise_no = strEnterPriseNo
         and warehouse_no = strWareHouseNo
         and waste_no = strWasteNo
         and status = '10';

      if sql%notfound then
        strResult := 'N|[更新报损通知单头档失败]';
        return;
      end if;

      strResult := 'Y';

  end P_solocate_main;

  /*******************************************************************************************************
  功能说明：报损拣货单发单
  1、一张报损单产生一张拣货单；
  2015.7.27
  打印根据配置来 huangb 20160804
  *******************************************************************************************************/
  procedure P_GetTaskWaste(strEnterPriseNo in sodata_outstock_m.enterprise_no%type,
                          strWarehose_No   in sodata_outstock_m.warehouse_no%type,
                          strOwnerNo       in sodata_outstock_m.owner_no%type,
                          strWasteNo        in sodata_outstock_direct.source_no%type,
                          strUserID        in bdef_defworker.worker_no%type,
                          strDockNo        in bdef_defdock.dock_no%type,
                          strPrintFlag     in job_printtask_m.back_flag%type,--是否打印，0：表示不打印；1：表示打印
                          strOutMsg        out varchar2) IS
  v_iCount        integer:=0;
  v_strOutstockNo sodata_outstock_m.outstock_no%type;
  v_PrintTaskNo   job_printtask_m.task_no%type;
  v_reportId      pntdef_report.report_id%type := 'N'; --报表ID huangb 20160804
  begin
    strOutMsg:='N|[P_GetTaskWaste]';


    for t in (select * from sodata_outstock_direct sod
       where sod.enterprise_no=strEnterPriseNo and sod.warehouse_no=strWarehose_No
       and sod.source_no=strWasteNo and sod.status='10' for update) loop

       v_iCount:=v_iCount+1;

       if v_iCount=1 then --获取下架单号

          --取下架单号
          PKLG_WMS_BASE.p_getsheetno(strEnterPriseNo,strWarehose_No,
                                     CONST_DOCUMENTTYPE.ODATAHO,
                                     v_strOutstockNo,
                                     strOutMsg);

          if substr(strOutMsg, 1, 1) = 'N' then
            strOutMsg:='N|[取下架单号失败]';
            return;
          end if;


          --写报损下架单头档
          Pkobj_Sodata.P_InsertWasteOutstockHead(strEnterPriseNo,strWarehose_No,strOwnerNo,v_strOutstockNo,
                            strUserID,strOutMsg);

          if substr(strOutMsg, 1, 1) = 'N' then
            strOutMsg:='N|[写报损下架单头失败]';
            return;
          end if;
       end if;

       --写报损下架明细
       pkobj_sodata.P_InserWasteOutStockItem(strEnterPriseNo,strWarehose_No,strOwnerNo,v_strOutstockNo,
           strUserId,t.direct_serial,strOutMsg);

        if substr(strOutMsg, 1, 1) = 'N' then
          strOutMsg:='N|[写报损下架明细失败]';
          return;
        end if;

    end loop;

    if strPrintFlag='1' then--写打印任务

      --获取报表ID huangb 20160804
      PKLG_WMS_Public.p_GetReportId
      (strEnterPriseNo,strWarehose_No,CONST_REPORT_TYPE.SOSEND,
       'L',v_strOutstockNo,v_reportId,strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --写打印任务 CONST_REPORTID.RPT_WasteOutstock 报损下架单
      PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterPriseNo,strWarehose_No,
                                          v_strOutstockNo,
                                          '0',
                                          v_reportId,
                                          strDockNo,
                                          '0',
                                          strUserId,
                                          v_PrintTaskNo,
                                          strOutMsg);

       if substr(strOutMsg, 1, 1) <> 'Y' then
         strOutMsg:='N|[写打印任务失败]';
         return;
       end if;
    end if;

    --更新报损下架指示
    pkobj_sodata.P_UpdatedWasteDirect(strEnterPriseNo,strWarehose_No,strOwnerNo,strWasteNo,strUserID,strOutMsg);

    if substr(strOutMsg, 1, 1) = 'N' then
      strOutMsg:='N|[更新报损下架指示失败]';
      return;
    end if;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end P_GetTaskWaste;

  /***********************************************************************************************8
  功能说明：按商品明细做拣货回单
           步骤：1、更新拣货明细；
                 2、更新库存；
  打印根据配置来 huangb 20160804
  ************************************************************************************************/
  procedure P_SaveOutstock(strEnterPriseNo in sodata_outstock_m.enterprise_no%type,
                            strWarehose_No in sodata_outstock_m.warehouse_no%type,
                            strOwnerNo     in sodata_outstock_m.owner_no%type,
                            strOutStockNo  in sodata_outstock_d.outstock_no%type,
                            strArticleNo   in sodata_outstock_d.article_no%type,
                            nPackingQTY    in sodata_outstock_d.packing_qty%type,
                            strScellNo     in sodata_outstock_d.s_cell_no%type,
                            nRealQTY       in sodata_outstock_d.real_qty%type,
                            strOutUserID   in sodata_outstock_d.outstock_name%type,
                            strUserID      in sodata_outstock_d.assign_name%type,
                            strTERMINAL_FLAG  in stock_content_move.terminal_flag%type,
                            strDockNo        in bdef_defdock.dock_no%type,
                            strPrintFlag     in job_printtask_m.back_flag%type,--是否打印，0：表示不打印；1：表示打印
                            strOutMsg      out varchar2) is
    v_TotalRealQTY    sodata_outstock_d.article_qty%type := nRealQTY;
    v_RealQTY         sodata_outstock_d.article_qty%type := 0;
    v_iCount          integer := 0;
    v_nOldCellID      stock_content.cell_id%type;
    v_strWasteNo      sodata_waste_m.waste_no%type;
    v_PrintTaskNo     job_printtask_m.task_no%type;
    v_reportId        pntdef_report.report_id%type := 'N'; --报表ID huangb 20160804
  begin
       strOutMsg:='N|[P_SaveOutstock]';
    for curOutstockInfor in (select *
                               from sodata_outstock_d d
                              where d.enterprise_no=strEnterPriseNo and d.warehouse_no = strWarehose_No
                                and d.owner_no = strOwnerNo
                                and d.outstock_no = strOutStockNo
                                and d.article_no = strArticleNo
                                and d.s_cell_no = strScellNo
                                and d.packing_qty = nPackingQTY
                                and d.status='10'
                                order by d.s_cell_no,d.article_no
                                for update) loop
        v_strWasteNo:=curOutstockInfor.Source_No;

        if v_TotalRealQTY >= curOutstockInfor.Article_Qty then
          v_RealQTY := curOutstockInfor.Article_Qty;
        else
          v_RealQTY := v_TotalRealQTY;
        end if;
        v_TotalRealQTY := v_TotalRealQTY - v_RealQTY;

        --更新拣货明细
        pkobj_sodata.P_UpdateWasteOutstockItem(strEnterPriseNo,strWarehose_No,strOutStockNo,v_RealQTY,
                  strOwnerNo,curOutstockInfor.divide_id,strOutUserID,strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          strOutMsg:='[N|更新拣货明细失败]';
          return;
        end if;

        --扣减来源储位库存
        -------------------把来源储位预下库存回单-------------------------------
        PKOBJ_STOCK.p_UpdtContent_qtyByCellID(strEnterPriseNo,curOutstockInfor.warehouse_no, --仓别
                                              curOutstockInfor.s_Cell_Id, --储位ID
                                              curOutstockInfor.s_Cell_No, --储位
                                              curOutstockInfor.d_Cell_No, --关系储位
                                              v_RealQTY, --数量
                                              curOutstockInfor.Article_Qty, --预下数量
                                              strUserID, --操作人员
                                              strOutStockNo, --操作单号
                                              strTERMINAL_FLAG, --操作设备
                                              strOutMsg); --返回 执行结果
        if (substr(strOutMsg, 1, 1) <> 'Y') then
          strOutMsg:='N|[扣减库存失败]';
          return;
        end if;

        --增加目的储位库存
        --------------------回写目的储位预上库存----------------------------------
        PKOBJ_STOCK.p_InstContent_qtyByCellID(strEnterPriseNo,curOutstockInfor.warehouse_no, --仓别
                                              curOutstockInfor.d_Cell_Id, --储位ID
                                              curOutstockInfor.d_Cell_No, --储位
                                              curOutstockInfor.s_Cell_No, --关系储位
                                              v_RealQTY, --数量
                                              curOutstockInfor.Article_Qty, --预下数量
                                              strUserId, --操作人员
                                              strOutStockNo, --操作单号
                                              strTERMINAL_FLAG, --操作设备
                                              strOutMsg); --返回 执行结果
        if (substr(strOutMsg, 1, 1) <> 'Y') then
          strOutMsg:='N|[扣减库存失败]';
          return;
        end if;

        if v_RealQTY>0 then
            --库存转换
            PKOBJ_STOCK.p_TransContent_qtyByCellID(strEnterPriseNo,curOutstockInfor.warehouse_no,
                                                   curOutstockInfor.d_Cell_No,
                                                   curOutstockInfor.d_Cell_Id,
                                                   v_RealQTY,
                                                   '1',
                                                   v_strWasteNo,
                                                   strUserId,
                                                   v_nOldCellID,
                                                   strOutMsg);

            if (substr(strOutMsg, 1, 1) <> 'Y') then
              strOutMsg:='N|[库存转换失败]';
              return;
            end if;
        end if;


      update sodata_waste_d d
         set d.real_qty = d.real_qty + v_RealQTY
       where d.enterprise_no=strEnterPriseNo and d.warehouse_no = strWarehose_No
         and d.owner_no = curOutstockInfor.Owner_No
         and d.waste_no = curOutstockInfor.Source_No
         and d.po_id = curOutstockInfor.Po_Id
         and d.article_no = curOutstockInfor.Article_No;

      update sodata_outstock_d d
         set d.status = '13'
       where d.status = '10' and d.warehouse_no=strWarehose_No
         and d.enterprise_no =strEnterPriseNo and d.outstock_no=strOutStockNo
         and d.divide_id = curOutstockInfor.divide_id;

    end loop;

    --更新报损下架单头
    select count(1)
      into v_iCount
      from sodata_outstock_d d
     where d.status = '10' and d.enterprise_no=strEnterPriseNo
       and d.warehouse_no = strWarehose_No
       and d.owner_no = strOwnerNo
       and d.outstock_no = strOutStockNo;
    if v_iCount > 0 then
      return;
    end if;

    --更新下架单头档
    pkobj_sodata.P_UpdateWasteOutStockHeader(strEnterPriseNo,strWarehose_No,
                                           strOutStockNo,
                                           strOwnerNo,
                                           strUserID,
                                           strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      strOutMsg:='N|[更新报损下架单失败]';
      return;
    end if;

    --
    if strPrintFlag='1' then --打印报损清单

      --获取报表ID huangb 20160804
      PKLG_WMS_Public.p_GetReportId
      (strEnterPriseNo,strWarehose_No,CONST_REPORT_TYPE.SODELIVER,
       'L',strOutStockNo,v_reportId,strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --CONST_REPORTID.rpt_wasteDelive 报损清单
      PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterPriseNo,strWarehose_No,
                                          strOutStockNo,
                                          '0',
                                          v_reportId,
                                          strDockNo,
                                          '0',
                                          strUserId,
                                          v_PrintTaskNo,
                                          strOutMsg);

       if substr(strOutMsg, 1, 1) <> 'Y' then
         strOutMsg:='N|[写打印任务失败-]'||strOutMsg;
         return;
       end if;
    end if;

    --报损单据转历史 huangb 20160516
    --注：报损单必须在下架单据转历史前转历史 报损单转历史前有用到报损下架单
    pkobj_sodata.P_SO_InsertHTY(strEnterPriseNo
                                ,strWarehose_No
                                ,strOwnerNo
                                ,strOutStockNo
                                ,strUserID
                                ,strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      strOutMsg:='N|[报损单据转历史失败]';
      return;
    end if;

    --转历史
    pkobj_sodata.P_UpdateOutStockHistory(strEnterPriseNo,strWarehose_No,strOutStockNo,strOwnerNo,
                                           strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      strOutMsg:='N|[下架单转历史失败]';
      return;
    end if;
    --删除库存
    pkobj_stock.proc_So_deliver_DelContent(strEnterPriseNo,strWarehose_No,v_strWasteNO,strUserID,
                                           strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      strOutMsg:='N|[失败]';
      return;
    end if;
    --根据下架单号更新报损单主档
    update sodata_waste_m t set t.status='13' where t.enterprise_no=strEnterPriseNo
           and t.warehouse_no=strWarehose_No and t.waste_no=v_strWasteNo;

    strOutMsg:='Y|[]';
  end P_SaveOutstock;

/*******************************************************************************************************
 创建人：czh
 时间:2016.5.25
 功能：报损手建单取消
********************************************************************************************************/
  procedure P_WasteCancel(strEnterPriseNo           in    sodata_waste_d.enterprise_no%type,
                         strWareHouseNo            in    sodata_waste_d.warehouse_no%type,--仓库编码
                         strOwnerNo                in    sodata_waste_m.owner_no%type,
                         strWasteNo                 in   sodata_waste_d.waste_no%type,--报损头档
                         strUserId                 in   sodata_waste_m.rgst_name%type,
                         strResult                 OUT    varchar2)is
      v_strStatus        sodata_waste_m.status%type;
  begin
       strResult:='N|[P_WasteCancel]';

       update sodata_waste_m  set status=status
       where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo
            and owner_no=strOwnerNo and waste_no=strWasteNo;

       if sql%notfound then
           strResult:='N|[找不到对应的计划单]';
           return;
       end if;

        select status into v_strStatus from sodata_waste_m
        where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo
        and owner_no=strOwnerNo and waste_no=strWasteNo;

        if v_strStatus<>'10' then
           strResult:='N|[不是新建的单，不可取消]';
           return;
        end if;

       update sodata_waste_m t set t.status='16',t.updt_name=strUserId,t.updt_date=sysdate
       where t.enterprise_no=strEnterPriseNo
       and t.warehouse_no=strWareHouseNo
        and t.owner_no=strOwnerNo and waste_no=strWasteNo;

       strResult:='Y|[]';
  end P_WasteCancel;

  /*****************************************************************************************************
   功能说明：1、对报损单进行定位；
             2、对报损单对应的下架指示进行发单；
             3、拣货回单；
             4、整单做报损确认（回写实际报损数量）
             此功能需按单处理，所有的定位、发单、回单都是按报损单操作，并且一一对应。
   2015.7.27
  *****************************************************************************************************/
  procedure P_SaveConfirm(strEnterPriseNo in sodata_waste_m.enterprise_no%type,
                           strWareHouseNo  in sodata_waste_m.warehouse_no%type, --仓库编码
                           strOwnerNo      in sodata_waste_m.owner_no%type,
                           strWasteNo      in sodata_waste_m.waste_no%type,
                           strDockNo        in bdef_defdock.dock_no%type,
                           strPrintFlag     in job_printtask_m.back_flag%type,--是否打印，0：表示不打印；1：表示打印
                           strUserId       in sodata_waste_m.rgst_name%type,
                           strResult       OUT varchar2)is
  v_nLocateQty      sodata_waste_d.locate_qty%type;
  v_nArticleQty       sodata_waste_d.waste_qty%type;
  begin
       strResult:='N|[P_SaveConfirm]';
       --锁定报损单头档
       update sodata_waste_m t set t.status=status where t.enterprise_no=strEnterPriseNo
       and t.warehouse_no=strWareHouseNo and t.owner_no=strOwnerNo and t.waste_no=strWasteNo;

       --报损定位
       P_solocate_main(strEnterPriseNo,strWareHouseNo,strOwnerNo,strWasteNo,strUserId,strResult);
       if substr(strResult, 1, 1) <> 'Y' then
         strResult:='N|[报损定位失败]';
         return;
       end if;

       --统计下报损数量是否足够，若不够，系统拦截
       select sum(t.waste_qty),nvl(sum(t.locate_qty),0) into v_nArticleQty,v_nLocateQty
       from sodata_waste_d t
       where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo
       and t.waste_no=strWasteNo;

       if v_nLocateQty<>v_nArticleQty then
          strResult:='N|[报损库存不足]';
          return;
       end if;

       --报损发单
       P_GetTaskWaste(strEnterPriseNo,strWareHouseNo,strOwnerNo,strWasteNo,strUserID,strDockNo,
            strPrintFlag,strResult);
       if substr(strResult, 1, 1) <> 'Y' then
         strResult:='N|[报损发单失败]';
         return;
       end if;

       --报损回单
       for GetSoutstock in (select * from sodata_outstock_d t where t.enterprise_no=strEnterPriseNo
           and t.warehouse_no=strWareHouseNo and t.source_no=strWasteNo) loop

           P_SaveOutstock(strEnterPriseNo,strWareHouseNo,strOwnerNo,GetSoutstock.outstock_no,
                GetSoutstock.article_no,GetSoutstock.packing_qty,GetSoutstock.s_cell_no,
                GetSoutstock.article_qty,strUserID,strUserID,'1',strDockNo,strPrintFlag,strResult);
           if substr(strResult, 1, 1) <> 'Y' then
             strResult:='N|[报损回单失败]';
             return;
           end if;
       end loop;

       strResult:='Y|[]';
  end;
  /********************************************************************************************************
  功能说明：按报损计划单进行定位并发单
  2015.11.13
  ********************************************************************************************************/
  procedure P_LocateAndGetTask(strEnterPriseNo in sodata_waste_m.enterprise_no%type,
                             strWareHouseNo  in sodata_waste_m.warehouse_no%type, --仓库编码
                             strOwnerNo      in sodata_waste_m.owner_no%type,
                             strWasteNo      in sodata_waste_m.waste_no%type,
                             strUserId       in sodata_waste_m.rgst_name%type,
                             strDockNo        in bdef_defdock.dock_no%type,
                             strPrintFlag     in job_printtask_m.back_flag%type,--是否打印，0：表示不打印；1：表示打印
                             strResult       OUT varchar2) is
      v_iCount               integer;
  begin
       strResult:='N|[P_LocateAndGetTask]';
       --按报损单定位
       P_solocate_main(strEnterPriseNo,strWareHouseNo,strOwnerNo,strWasteNo,strUserId,strResult);

       if substr(strResult, 1, 1) <> 'Y' then
         strResult:='N|[定位失败]';
         return;
       end if;

       --
       select count(*) into v_iCount
       from sodata_outstock_direct t
       where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo
       and t.source_no=strWasteNo;

       if v_iCount>0 then --报损检货发单
          P_GetTaskWaste(strEnterPriseNo,strWareHouseNo,strOwnerNo,strWasteNo,strUserID,strDockNo,strPrintFlag,
             strResult);

           if substr(strResult, 1, 1) <> 'Y' then
             strResult:='N|[发单失败]';
             return;
           end if;
       end if;

       strResult:='Y|[]';
  end P_LocateAndGetTask;

  /********************************************************************************
   huangb 20150511
   功能说明：根据报损类型配置的策略对报损单进行定位
   huangb 20160513 支持库存拆零
   huangb 20160527 去掉支持库存拆零
  ********************************************************************************/
  PROCEDURE P_SODATA_LOCATE(strEnterPriseNo in sodata_waste_m.enterprise_no%type,
                            strWareHouseNo  in sodata_waste_m.warehouse_no%type, --仓库编码
                            strOwnerNo      in sodata_waste_m.owner_no%type,
                            strWasteNo      in sodata_waste_m.waste_no%type,
                            strStrategyId   in wms_sodataorder.strategy_id%type,
                            strPackinglevel in wms_sodataorder.packinglevel%type,
                            strDestCellNo   in cdef_defcell.cell_no%type,
                            strUserId       in sodata_waste_m.rgst_name%type,
                            strResult       OUT varchar2) is
    v_nRemainQty sodata_waste_d.WASTE_QTY%type; --剩余定位量

    v_iCount   integer;
    v_nCount   integer;
    v_strSql   VARCHAR2(5000);
    v_strUpSql VARCHAR2(5000);

    --报损明细
    cursor v_GetLocateItem is
      select swm.org_no,swm.stock_type,swm.stock_value,swd.*
        from sodata_waste_m swm,sodata_waste_d swd
        where swm.enterprise_no=swd.enterprise_no and swm.warehouse_no=swd.warehouse_no
        and swm.owner_no = swd.owner_no and swm.waste_no=swd.waste_no
        and swm.enterprise_no=strEnterPriseNo and swm.warehouse_no=strWareHouseNo
        and swm.owner_no = strOwnerNo and swm.waste_no=strWasteNo and swm.status='10'
        order by swd.article_no,swd.po_id;

    v_strCondition              varchar2(500);
    v_strOrderCondition         varchar2(500);--排序条件 huangb 20160511
    v_strAreaUseTypeCondition   varchar2(100);
    v_strAreaAttributeCondition varchar2(100);
    v_strLabelNoCondition       varchar2(100);
    v_strPackingQtyCondition    varchar2(200);--库存包装条件 huangb 20160511
    --v_strBoxCondition           varchar2(200);--箱定位条件 huangb 20160513

  BEGIN
    strResult := 'N|[P_SODATA_LOCATE]';

    for p in v_GetLocateItem loop
      v_iCount     := v_iCount + 1;
      v_nRemainQty := p.waste_qty - p.locate_qty;
      v_nCount     := 0;
      --获取策略
      for rule in (select r.*, td.LIMMIT_RSV01
                     from wms_defstrategy t
                     join wms_defstrategy_d td on t.strategy_type =
                                                  td.strategy_type
                                              and t.strategy_id =
                                                  td.strategy_id
                     join wms_defrule r on r.strategy_type =
                                           td.strategy_type
                                       and r.rule_id = td.rule_id
                                       and (r.use_type <> '0' or
                                           r.use_type is null)
                    where t.strategy_id = strStrategyId
                      and t.strategy_type = 'SM'
                    order by td.rule_order) loop
        v_nCount := v_nCount + 1;
        --选择储区类型
        begin
          /*1 定位报损区储位
          2 定位次品区储位        0
          3 定位商品拣货位        0
          4 定位异常区
          5 定位良品区储位拣货区  0
          6 定位良品区储位保管区  0
          7 定位良品区（含异常区）
          8 定位过季品区          0
          9 定位良品区（不含异常区）  0*/
          if rule.rule_id = 1 then
            v_strAreaUseTypeCondition   := ' and t.area_usetype in (''2'')';
            v_strAreaAttributeCondition := ' and t.area_attribute in (''0'')';
          elsif rule.rule_id = 2 then
            goto NextOne;
          elsif rule.rule_id = 3 then
            goto NextOne;
          elsif rule.rule_id = 4 then
            v_strAreaUseTypeCondition   := ' and t.area_usetype in (''5'')';
            v_strAreaAttributeCondition := ' and t.area_attribute in (''0'')';
          elsif rule.rule_id = 5 then
            goto NextOne;
          elsif rule.rule_id = 6 then
            goto NextOne;
          elsif rule.rule_id = 7 then
            v_strAreaUseTypeCondition   := ' and t.area_usetype in (''1'',''5'')';
            v_strAreaAttributeCondition := ' and t.area_attribute in (''0'')';
          elsif rule.rule_id = 8 then
            goto NextOne;
          elsif rule.rule_id = 9 then
            goto NextOne;
          end if;
        end;
        --定位标签库存条件
        begin
          /*是否定位标签库存:
          0：普通库存，
          1：标签库存，
          2：优先标签库存*/
          if rule.limmit_rsv01 = '0' then
            v_strLabelNoCondition := ' and sc.label_no =''N'' ';
          elsif rule.limmit_rsv01 = '1' then
            v_strLabelNoCondition := ' and sc.label_no <>''N'' ';
          elsif rule.limmit_rsv01 = '2' then
            v_strLabelNoCondition := '';
          end if;
        end;

        if v_strAreaUseTypeCondition is null or
           v_strAreaAttributeCondition is null then
          strResult := 'N|[未加载到可用的退货策略，请维护！]';
          return;
        end if;

        --定位包装条件 报损定位规格类型(0-不管规格；1-优先退厂明细规格；2-按退厂规格)
        if strPackinglevel = '2' then
          v_strPackingQtyCondition   := ' and sc.packing_qty = ' || p.packing_qty;
        else
          v_strPackingQtyCondition   := '';
        end if;

        --锁定此商品的库存；
        v_strUpSql := ' update stock_content sc set sc.status=status ' ||
                      ' where sc.enterprise_no = ''' || strEnterPriseNo ||
                      ''' and sc.warehouse_no = ''' || strWarehouseNo ||
                      ''' and sc.article_no = ''' || p.Article_No ||
                      ''' and sc.stock_type = ''' || p.stock_type ||
                      ''' and sc.stock_value = ''' || p.stock_value ||
                      ''' and sc.cell_no in ( ' ||
                      ' select cell_no from cdef_defware cw,cdef_defarea t,cdef_defcell cd  ' ||
                      ' where cw.ENTERPRISE_NO = cd.enterprise_no and cw.WAREHOUSE_NO = cd.warehouse_no and cw.WARE_NO = cd.ware_no ' ||
                      ' and t.ENTERPRISE_NO = cd.enterprise_no and t.WAREHOUSE_NO = cd.WAREHOUSE_NO and t.WARE_NO = cd.WARE_NO and t.AREA_NO = cd.AREA_NO ' ||
                      ' and cd.ENTERPRISE_NO = sc.ENTERPRISE_NO and cd.WAREHOUSE_NO = sc.WAREHOUSE_NO and cd.CELL_NO = sc.CELL_NO ' ||
                      ' and cd.cell_status<>''1'' ';
        v_strUpSql := v_strUpSql || v_strAreaUseTypeCondition ||
                      v_strAreaAttributeCondition || ')' ||
                      v_strPackingQtyCondition ;
        execute immediate v_strUpSql;

          --新增排序条件 huangb 20160511
        v_strOrderCondition := ' order by ';
        if rule.limmit_rsv01 = '2' then
           v_strOrderCondition := v_strOrderCondition || ' (case sc.label_no when ''N'' then 1 else 0 end),';
           if strPackinglevel = '1'  then
             v_strOrderCondition := v_strOrderCondition || ' (case when sc.packing_qty = ' || p.packing_qty || ' then 0 else 1 end),';
          end if;
        else
           if strPackinglevel = '1'  then
             v_strOrderCondition := v_strOrderCondition || ' (case when sc.packing_qty = ' || p.packing_qty || ' then 0 else 1 end),';
             end if;
        end if;
        v_strOrderCondition := v_strOrderCondition || ' sc.cell_no, sai.produce_date';
        --此处请注意 v_strOrderCondition的结尾不能有空格，此处是截取最后一个逗号的作用
        --v_strOrderCondition := substr(v_strOrderCondition,0,length(v_strOrderCondition) - 1);

        begin
          v_strSql := 'select sc.owner_no, sc.article_no, sc.article_id, sc.Qty,' ||
                      ' sc.OutStock_Qty, sc.packing_qty, sc.cell_no,  sc.cell_id, ' ||
                      ' sc.stock_type, sc.stock_value, sc.label_no, sc.sub_label_no,bda.QMIN_OPERATE_PACKING ' ||
                      ' from stock_content sc,stock_article_info sai,cdef_defcell cd,cdef_defarea t,cdef_defware cw,bdef_defarticle bda ' ||
                      ' where sai.ENTERPRISE_NO = sc.ENTERPRISE_NO and sai.ARTICLE_NO = sc.ARTICLE_NO and sai.ARTICLE_ID =sc.ARTICLE_ID ' ||
                      ' and cd.ENTERPRISE_NO = sc.ENTERPRISE_NO and cd.WAREHOUSE_NO = sc.WAREHOUSE_NO and cd.CELL_NO = sc.CELL_NO ' ||
                      ' and t.ENTERPRISE_NO = cd.enterprise_no and t.WAREHOUSE_NO = cd.WAREHOUSE_NO and t.WARE_NO = cd.WARE_NO and t.AREA_NO = cd.AREA_NO ' ||
                      ' and cw.ENTERPRISE_NO = cd.enterprise_no and cw.WAREHOUSE_NO = cd.warehouse_no and cw.WARE_NO = cd.ware_no ' ||
                      ' and bda.ENTERPRISE_NO = sc.ENTERPRISE_NO and bda.owner_no = sc.owner_no and bda.article_no = sc.article_no ' ||
                      --条件
                      ' and cd.cell_status <> ''1'' ' ||
                      ' and sc.qty - sc.outstock_qty > 0 ' ||
                      ' and sc.enterprise_no = ''' || strEnterPriseNo || '''' ||
                      ' and sc.warehouse_no = ''' || strWareHouseNo || '''' ||
                      ' and sc.article_no = ''' || p.article_no || '''' ||
                      ' and sc.stock_type = ''' || p.stock_type || '''' ||
                      ' and sc.stock_value = ''' || p.stock_value || '''';
          --org_no
          v_strCondition := ' and (''' || p.org_no || ''' = ''N'' or (''' ||
                            p.org_no || ''' <> ''N'' and cw.org_no = ''' ||
                            p.org_no || ''')) ';
          --lot_no
          v_strCondition := v_strCondition || ' and (''' || p.lot_no ||
                            ''' = ''N'' or (''' || p.lot_no ||
                            ''' <> ''N'' and sai.lot_no = ''' || p.lot_no ||
                            ''')) ';
          --quality
          if p.quality is not null then
            v_strCondition := v_strCondition || ' and sai.quality = ''' ||
                              p.quality || '''';
          end if;
          --produce_date
          if p.produce_date is not null then
            v_strCondition := v_strCondition || ' and sai.produce_date = ''' ||
                              p.produce_date || '''';
          end if;
          --expire_date
          if p.expire_date is not null then
            v_strCondition := v_strCondition || ' and sai.expire_date = ''' ||
                              p.expire_date || '''';
          end if;

          v_strSql := v_strSql ||
                      v_strCondition ||
                      --v_strBoxCondition ||
                      v_strPackingQtyCondition ||
                      v_strAreaUseTypeCondition ||
                      v_strAreaAttributeCondition ||
                      v_strLabelNoCondition ||
                      --注意 排序必须放在最后
                      v_strOrderCondition;

        end;
        --写报损下架指示和库存
        P_InsertSodateDirect(strEnterPriseNo,
                              strWareHouseNo,
                              strWasteNo,
                              strDestCellNo,
                              strUserId,
                              p.po_id,
                              v_strSql,
                              --v_lcount,
                              v_nRemainQty,
                              strResult);
        if substr(strResult, 1, 1) = 'N' then
          return;
        end if;

        <<NextOne>>
        null;
        if v_nRemainQty = 0 then
          exit;
        end if;
      end loop;
      if v_nCount = 0 then
        strResult := 'N|[未获取到报损策略，请联系维护人员添加！]';
        return;
      end if;

    end loop;

    if v_iCount = 0 then
      strResult := 'N|[获取不到报损通知单明细]';
      return;
    end if;

    strResult := 'Y';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  END P_SODATA_LOCATE;

  /**********************************************************************************************
  功能：写报损下架指示
    2015.7.27
  huangb 20160511 从PKOBJ_SODATA移至PKLG_SODATA包 以及增加策略定位
  huangb 20160513 支持库存拆零
  huangb 20160527 去掉支持库存拆零
  **********************************************************************************************/
  procedure P_InsertSodateDirect(strEnterPriseNo  in sodata_waste_m.enterprise_no%type,
                                  strWareHouseNo  in sodata_waste_m.warehouse_no%type,
                                  strWasteNo      in sodata_waste_m.waste_no%type,
                                  strDestCellNo   in cdef_defcell.cell_no%type,
                                  strUserId       in sodata_waste_m.rgst_name%type,
                                  nPoID           in sodata_waste_d.po_id%type,
                                  strSql          in varchar2,
                                  nQty            in out sodata_waste_d.waste_qty%type,
                                  strResult       out varchar2) IS
    v_nCount     number;
    v_nCurQty    sodata_waste_d.waste_qty%type; --当前定位数量
    v_nRemainQty sodata_waste_d.waste_qty%type; --剩余定位量
    v_destCellID stock_content.cell_id%type;

    --报损库存 动态游标
    TYPE waf_cursor_type IS REF CURSOR;
    v_getWasteStock waf_cursor_type;

    v_owner_no             stock_content.owner_no%type;
    v_article_no           stock_content.article_no%type;
    v_article_id           stock_content.article_id%type;
    v_nQty                 stock_content.qty%type;
    v_nOutStockQty         stock_content.outstock_qty%type;
    v_packing_qty          stock_content.packing_qty%type;
    v_cell_no              stock_content.cell_no%type;
    v_cell_id              stock_content.cell_id%type;
    v_stock_type           stock_content.stock_type%type;
    v_stock_value          stock_content.stock_value%type;
    v_label_no             stock_content.label_no%type;
    v_sub_label_no         stock_content.sub_label_no%type;
    v_qmin_operate_packing bdef_defarticle.qmin_operate_packing%type; --商品最小操作包装 huangb20160513

  begin
     strResult    := 'N|[P_InsertSodateDirect]';
     v_nRemainQty := nQty;
     v_nCount     := 0;
     open v_getWasteStock for strSql;

     loop
       fetch v_getWasteStock
        into v_owner_no, v_article_no, v_article_id, v_nQty, v_nOutStockQty, v_packing_qty
        , v_cell_no, v_cell_id, v_stock_type, v_stock_value, v_label_no, v_sub_label_no,v_qmin_operate_packing;
      exit when v_getWasteStock%notfound;

       v_nCount := v_nCount + 1;
       if v_nRemainQty >= v_nQty - v_nOutStockQty then
         v_nCurQty := v_nQty - v_nOutStockQty;
       else
         v_nCurQty := v_nRemainQty;
       end if;
       v_nRemainQty := v_nRemainQty - v_nCurQty;

       --写报损定位预上预下库存
       pkobj_stock.p_UpdtContent_Reservation(strEnterPriseNo,
                                            strWareHouseNo,
                                            v_cell_no,
                                            v_cell_id,
                                            strDestCellNo,
                                            v_label_no,
                                            v_sub_label_no,
                                            v_nCurQty,
                                            '0',
                                            strUserId,
                                            v_destCellID,
                                            strResult);

       if substr(strResult, 1, 1) = 'N' then
        return;
       end if;

       insert into sodata_outstock_direct(enterprise_no,warehouse_no,owner_no,operate_type,operate_date,
           article_no,article_id,packing_qty,s_cell_no,s_cell_id,
           d_cell_no,d_cell_id,locate_qty,status,po_id,source_no,
           stock_type,stock_value,rgst_name,rgst_date)
        values(strEnterPriseNo,strWarehouseNo,v_owner_no,'C',trunc(sysdate),
           v_article_no,v_article_id,v_packing_qty,v_cell_no,
           v_cell_id,strDestCellNo,v_destCellID,v_nCurQty,'10',nPoId,strWasteNo,
           v_stock_type,v_stock_value,strUserID,sysdate);

       --更新报损单明细
       update sodata_waste_d t
          set t.locate_qty = t.locate_qty + v_nCurQty
        where t.enterprise_no = strEnterPriseNo
          and t.warehouse_no = strWareHouseNo
          and t.waste_no = strWasteNo
          and t.article_no = v_article_no
          and t.po_id = nPoID;

       if v_nRemainQty = 0 then
         exit;
       end if;

     end loop;
     close v_getWasteStock;
     nQty      := v_nRemainQty;
     strResult := 'Y';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_InsertSodateDirect;


end PKLG_SODATA;

/

