create view V_SEARCH_9104_5 as
select t.enterprise_no,t.warehouse_no,t.owner_no,t.label_no,r.worker_name,t.arrange_type,t.rgst_date from stock_label_arrange_log t,bdef_defworker r where t.arrange_type='4'
and t.enterprise_no=r.enterprise_no and  t.rgst_name=r.worker_no order by r.worker_name,t.rgst_date

/

