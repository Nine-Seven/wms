create view V_SEARCH_9103_12 as
select oem.enterprise_no,
       oem.warehouse_no,
       oem.owner_no,
       oem.cust_no,
       oed.article_no,
       bda.article_name,
       bda.owner_article_no,
       bda.article_identifier,
       bda.barcode,
       nvl(bdp.packing_qty,1)packing_qty,
       bda.unit,
       bda.spec,
       (bda.unit_volumn * sum(odd.qty)) volumn,
       (bda.unit_weight * sum(odd.qty)) weight,
       sum(oed.article_qty) articleQty,
       sum(odd.qty) outQty
  from odata_exp_m oem
  join odata_exp_d oed
    on oem.enterprise_no = oed.enterprise_no
   and oem.warehouse_no = oed.warehouse_no
   and oem.exp_no = oed.exp_no
   and oem.owner_no = oed.owner_no
  left join odata_deliver_d odd
    on odd.enterprise_no = oed.enterprise_no
   and odd.warehouse_no = oed.warehouse_no
   and odd.owner_no = oed.owner_no
   and odd.exp_no = oed.exp_no
   and odd.article_no = oed.article_no
 left join bdef_defarticle bda
    on bda.enterprise_no = oed.enterprise_no
   and bda.article_no = oed.article_no
   and bda.owner_no = oed.owner_no
   and bda.owner_article_no = oed.owner_article_no
left  join bdef_article_packing bdp
    on bdp.enterprise_no=bda.enterprise_no
    and bdp.article_no=bda.article_no
 group by oem.enterprise_no,
          oem.warehouse_no,
          oem.owner_no,
          oem.cust_no,
          oed.article_no,
          oed.article_no,
          bda.article_name,
          bda.owner_article_no,
          bda.article_identifier,
          bda.barcode,
          bdp.packing_qty,
          bda.unit,
          bda.spec,
          bda.unit_volumn,
          bda.unit_weight


/

