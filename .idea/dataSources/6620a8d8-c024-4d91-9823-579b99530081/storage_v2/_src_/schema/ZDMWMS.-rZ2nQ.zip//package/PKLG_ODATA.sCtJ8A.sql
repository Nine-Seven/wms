create package pklg_odata is
  --出货逻辑

  /*\*****************************************************************************************************************
    QUZHIHUI
    20131110
    功能说明：按区域+客户发单
    ***************************************************************************************************************\
    procedure p_pick_by_cust(strEnterpriseNo     in odata_outstock_m.enterprise_no%type,
                             v_warehouse_No      in odata_locate_m.warehouse_no%type,
                             v_Owner_No          in odata_outstock_d.owner_no%type,
                             v_Exp_Type          in odata_outstock_direct.exp_type%type,
                             v_WAVE_No           in odata_outstock_d.wave_no%type,
                             v_Area_No           in cdef_defcell.cell_no%type,
                             v_Cust_No           in bdef_defcust.cust_no%type,
                             v_Dock_No           in bdef_defdock.dock_no%type,
                             v_PickWorker        in odata_outstock_d.assign_name%type, --拣货人员
                             v_Operate_Type      in varchar2,
                             v_deliverObj        in odata_outstock_d.deliver_obj%type, --配送对象，如果不按配送对象切单，传N
                             v_strUserID         in odata_outstock_m.rgst_name%type, --系统操作人员
                             v_strPrintPaperType in odata_outstock_m.task_type%type, --是否打印表单标识，0：不打印，1，打印
                             strOutMsg           out varchar2);
    \*****************************************************************************************************************
    2016.3.9
    功能说明：按配送对象发单，不分区域和作业类型
    ***************************************************************************************************************\
    procedure p_pick_by_deliver_obj(strEnterpriseNo     in odata_outstock_m.enterprise_no%type,
                                    v_warehouse_No      in odata_locate_m.warehouse_no%type,
                                    v_Owner_No          in odata_outstock_d.owner_no%type,
                                    v_Exp_Type          in odata_outstock_direct.exp_type%type,
                                    v_WAVE_No           in odata_outstock_d.wave_no%type,
                                    v_DeliverOBJ        in odata_outstock_d.deliver_obj%type,
                                    v_Dock_No           in bdef_defdock.dock_no%type,
                                    v_PickWorker        in odata_outstock_d.assign_name%type, --拣货人员
                                    v_strUserID         in odata_outstock_m.rgst_name%type, --系统操作人员
                                    v_strPrintPaperType in odata_outstock_m.task_type%type, --是否打印表单标识，0：不打印，1，打印
                                    strOutMsg           out varchar2);

    \* 功能说明：自动成单发单*\
    procedure p_pick_by_Area(strEnterpriseNo     in odata_outstock_m.enterprise_no%type,
                             v_warehouse_No      in odata_locate_m.warehouse_no%type,
                             v_Owner_No          in odata_outstock_d.owner_no%type,
                             v_Exp_Type          in odata_outstock_direct.exp_type%type,
                             v_Source_Type       in odata_outstock_direct.source_type%type,
                             v_WAVE_No           in odata_outstock_d.wave_no%type,
                             v_Area_No           in cdef_defcell.cell_no%type,
                             v_Dock_No           in bdef_defdock.dock_no%type,
                             v_Operate_Type      in varchar2,
                             v_strUserID         in odata_outstock_m.rgst_name%type, --系统操作人员
                             v_strPrintPaperType in odata_outstock_m.task_type%type, --是否打印表单标识，0：不打印，1，打印
                             strOutMsg           out varchar2);
  */
  /*****************************************************************************************************************
  功能说明：电商发单
  Modify BY QZH AT 2016-5-24 支持RF索单
  ***************************************************************************************************************/
  procedure p_pick_by_ec(strEnterpriseNo     in odata_outstock_m.enterprise_no%type,
                         v_warehouse_No      in odata_locate_m.warehouse_no%type,
                         v_Owner_No          in odata_outstock_d.owner_no%type,
                         v_Exp_Type          in odata_outstock_direct.exp_type%type,
                         v_WAVE_No           in odata_outstock_d.wave_no%type,
                         v_Batch_No          in odata_outstock_d.batch_no%type, --批次 huangb 20160618
                         v_Area_No           in cdef_defcell.cell_no%type,
                         v_Cust_No           in bdef_defcust.cust_no%type, --客户，电商传N
                         v_DeliverOBJ        in odata_outstock_d.deliver_obj%type, --配送对象，无法确定传N
                         v_Dock_No           in bdef_defdock.dock_no%type,
                         v_PickWorker        in odata_outstock_d.assign_name%type, --拣货人员
                         v_Operate_Type      in varchar2,
                         v_strUserID         in odata_outstock_m.rgst_name%type, --系统操作人员
                         v_strPrintPaperType in odata_outstock_m.task_type%type, --是否打印拣货单标识，0：不打印，1，打印
                         strPrintWayBill     in odata_outstock_m.task_type%type, --是否打印快递面单，0：不打印，1：打印
                         strPrintPackList    in odata_outstock_m.task_type%type, --是否打印装箱清单，0：不打印，1：打印
                         strPrintInVoice     in odata_outstock_m.task_type%type, --是否打印发票，0：不打印，1：打印
                         strOutMsg           out varchar2);

  /* 功能说明：出货量补货发单*/
  procedure p_Hm_by_Area(strEnterpriseNo     in odata_outstock_m.enterprise_no%type,
                         v_warehouse_No      in odata_locate_m.warehouse_no%type,
                         v_Owner_No          in odata_outstock_d.owner_no%type,
                         v_Exp_Type          in odata_outstock_direct.exp_type%type,
                         v_WAVE_No           in odata_outstock_d.wave_no%type,
                         v_Batch_No          in odata_outstock_d.batch_no%type, --批次 huangb 20160618
                         v_Area_No           in cdef_defcell.cell_no%type,
                         v_Dock_No           in bdef_defdock.dock_no%type,
                         v_Operate_Type      in odata_outstock_m.operate_type%type,
                         v_strUserID         in odata_outstock_m.rgst_name%type, --系统操作人员
                         v_strPrintPaperType in odata_outstock_m.task_type%type, --是否打印表单标识，0：不打印，1，打印
                         strOutMsg           out varchar2);

  --写标签信息
  procedure P_WriteLabelInfo(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                             strWarehouse_No in odata_outstock_m.warehouse_no%type,
                             v_strExpType    in odata_exp_m.exp_type%type,
                             strOwnerNo      in odata_outstock_m.owner_no%type,
                             strOutStockNo   in odata_outstock_m.outstock_no%type,
                             strOutMsg       out varchar2);

  --写打印任务
  procedure P_WritePrintJob(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                            strWarehouse_No in odata_outstock_m.warehouse_no%type,
                            strOutStockNo   in odata_outstock_m.outstock_no%type,
                            strPrintJobType in odata_outstock_m.task_type%type,
                            strUserId       in Odata_Outstock_m.rgst_name%type,
                            strOutMsg       out varchar2);
  /*为避免修改JAVA端， 这个方法是复制的上面的方法，加了一个dockno的参数 Add by sl*/
  procedure P_WritePrintJob2(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                             strWarehouse_No in odata_outstock_m.warehouse_no%type,
                             strOutStockNo   in odata_outstock_m.outstock_no%type,
                             strPrintJobType in odata_outstock_m.task_type%type,
                             strUserId       in Odata_Outstock_m.rgst_name%type,
                             strdockno       in Odata_Outstock_m.Dock_No%type,
                             strOutMsg       out varchar2);

  /*打印方法统一控制层 Add by sl*/
  procedure P_WritePrintJob_Control(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                                    strWarehouse_No in odata_outstock_m.warehouse_no%type,
                                    strOutStockNo   in odata_outstock_m.outstock_no%type,
                                    strPrintJobType in odata_outstock_m.task_type%type,
                                    strUserId       in Odata_Outstock_m.rgst_name%type,
                                    strdockno       in Odata_Outstock_m.Dock_No%type,
                                    strOutMsg       out varchar2);

  /*******************************************************************************8
  功能说明： 写拣货、补货表单打印任务；
           规则、1一张下架单一个打印任务
           2、根据下架单号写JOB_PRIINT_M
  *******************************************************************************/
  procedure P_WritePrintJob_Paper(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                                  strWarehouse_No in odata_outstock_m.warehouse_no%type,
                                  strOutstockNo   in odata_outstock_m.outstock_no%type,
                                  strDockNo       in odata_outstock_m.dock_no%type,
                                  strUserId       in Odata_Outstock_m.rgst_name%type,
                                  strOutMsg       out varchar2);

  /*************************************************************************************************8
   功能说明：只打印拣货标签头的打印任务；
            规则：1、一拣货单一打印任务；
                  2、根据拣货单写对应的JOB_PRINT_M
  ****************************************************************************************************/
  procedure P_WritePrintJOb_LabelM(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                                   strWarehouse_No in odata_outstock_m.warehouse_no%type,
                                   strOutstockNo   in odata_outstock_m.outstock_no%type,
                                   strDockNo       in odata_outstock_m.dock_no%type,
                                   strUserId       in Odata_Outstock_m.rgst_name%type,
                                   strOutMsg       out varchar2);

  /***************************************************************************************8
   功能说明：写打印标签明细的打印任务；
             规则：1、一拣货任务会产生一个打印任务号；
                   2、将拣货单号和报表ID写入对应的JOB_PRINT_M表
                   3、将拣货单下的内部标签号写入对应个JOB_PRINT_D表
  ****************************************************************************************/
  procedure P_WritePrintJob_LabelD(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                                   strWarehouse_No in odata_outstock_m.warehouse_no%type,
                                   strOutstockNo   in odata_outstock_m.outstock_no%type,
                                   strDockNo       in odata_outstock_m.dock_no%type,
                                   strUserId       in Odata_Outstock_m.rgst_name%type,
                                   strOutMsg       out varchar2);

  /***************************************************************************************8
   功能说明：打印任务单头和标签明细的打印任务；
             规则：1、会产生拣货单号和标签号的两个打印任务；
                  2、 产生拣货单号的打印任务同P_WritePrintJob_LabelM；
                  3、产生拣货标签明细的打印任务同P_WritePrintJob_LabelD

  ****************************************************************************************/
  procedure P_WritePrintJob_LabelMD(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                                    strWarehouse_No in odata_outstock_m.warehouse_no%type,
                                    strOutstockNo   in odata_outstock_m.outstock_no%type,
                                    strDockNo       in odata_outstock_m.dock_no%type,
                                    strUserId       in Odata_Outstock_m.rgst_name%type,
                                    strOutMsg       out varchar2);
  --外部号转内部号
  procedure TransFixNoToSerialNo(strEnterpriseNo     in odata_outstock_m.enterprise_no%type,
                                 strWAREHOUSE_NO     in stock_label_m.warehouse_no%type,
                                 strLabel_No         in stock_label_m.label_no%type,
                                 strUserID           in stock_label_m.rgst_name%type,
                                 strUseType          in stock_label_m.use_type%type,
                                 strDeliverOBJ       in stock_label_m.deliver_obj%type,
                                 strContainer_Type   out stock_label_m.container_type%type,
                                 strContainer_No     out stock_label_m.container_no%type,
                                 strContainerNewFlag out integer,
                                 strOutMsg           out varchar2);
  --检查标签状态
  procedure CheckContainerStatus(strEnterpriseNo   in odata_outstock_m.enterprise_no%type,
                                 strWAREHOUSE_NO   in stock_label_m.warehouse_no%type,
                                 strLabel_No       in stock_label_m.label_no%type,
                                 strUserID         in stock_label_m.rgst_name%type,
                                 strUseType        in stock_label_m.use_type%type,
                                 strDeliverOBJ     in stock_label_m.deliver_obj%type,
                                 strContainer_Type out stock_label_m.container_type%type,
                                 strContainer_No   out stock_label_m.container_no%type,
                                 strOutMsg         out varchar2);

  procedure p_UpdtOutstockHeader(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                                 strWAREHOUSE_NO in odata_outstock_m.warehouse_no%type,
                                 strOutstockNo   in odata_outstock_m.outstock_no%type,
                                 strUserID       in odata_outstock_m.rgst_name%type,
                                 strOutMsg       out varchar2);

  --添加临时表数据
  procedure insert_tmp_locate_select(strTmpId            in odata_tmp_locate_select.tmp_id%type,
                                     strCurrEnterpriseNo in odata_tmp_locate_select.enterprise_no%type,
                                     strWareHouseNo      in odata_tmp_locate_select.warehouse_no%type,
                                     strOwnerNo          in odata_tmp_locate_select.owner_no%type,
                                     strCustNo           in varchar2,
                                     strLineNo           in odata_tmp_locate_select.line_no%type,
                                     strBatchNo          in odata_tmp_locate_select.batch_no%type,
                                     strExpNo            in odata_tmp_locate_select.exp_no%type,
                                     strVolume           in odata_tmp_locate_select.volume%type,
                                     strWeigth           in odata_tmp_locate_select.weight%type,
                                     strQbox             in odata_tmp_locate_select.qbox%type,
                                     flag                in varchar2,
                                     strResult           out varchar2);

  --删除临时表
  procedure delete_tmp_locate_select(strTmpId            in odata_tmp_locate_select.tmp_id%type,
                                     strCurrEnterpriseNo in odata_tmp_locate_select.enterprise_no%type,
                                     strWareHouseNo      in odata_tmp_locate_select.warehouse_no%type,
                                     strOwnerNo          in odata_tmp_locate_select.owner_no%type,
                                     strCustNo           in varchar2,
                                     strLineNo           in odata_tmp_locate_select.line_no%type,
                                     strBatchNo          in odata_tmp_locate_select.batch_no%type,
                                     strExpNo            in odata_tmp_locate_select.exp_no%type,
                                     flag                in varchar2,
                                     strResult           out varchar2);
  /*******************************************************************************8
  功能说明： 写打印面单
           规则、1一张订单一个打印任务
           2、根据下架单号写JOB_PRIINT_M
  新增打印顺序 huangb 20160705
  *******************************************************************************/
  procedure P_WritePrintJob_WayBill(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                                    strWarehouse_No in odata_outstock_m.warehouse_no%type,
                                    strOutstockNo   in odata_outstock_m.outstock_no%type,
                                    strDockNo       in odata_outstock_m.dock_no%type,
                                    strUserId       in Odata_Outstock_m.rgst_name%type,
                                    strOutMsg       out varchar2);

  /*******************************************************************************
  功能说明： 写打印发票
           规则、1一张订单一个打印任务
           2、根据下架单号写JOB_PRIINT_M
  *******************************************************************************/
  procedure P_WritePrintJob_Invoice(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                                    strWarehouse_No in odata_outstock_m.warehouse_no%type,
                                    strOutstockNo   in odata_outstock_m.outstock_no%type,
                                    strDockNo       in odata_outstock_m.dock_no%type,
                                    strUserId       in Odata_Outstock_m.rgst_name%type,
                                    strOutMsg       out varchar2);

  /*******************************************************************************
  功能说明： 写打印发票
           规则、1一张订单一个打印任务
           2、根据下架单号写JOB_PRIINT_M
  *******************************************************************************/
  procedure P_WritePrintJob_BoxList(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                                    strWarehouse_No in odata_outstock_m.warehouse_no%type,
                                    strOutstockNo   in odata_outstock_m.outstock_no%type,
                                    strDockNo       in odata_outstock_m.dock_no%type,
                                    strUserId       in Odata_Outstock_m.rgst_name%type,
                                    strOutMsg       out varchar2);

  /*******************************************************************************************
   发单完成出货单据跟踪状态修改
   huangb 20160629
  *******************************************************************************************/
  procedure P_Send_ExpTrace(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                            strWarehouseNo  in odata_outstock_m.warehouse_no%type,
                            strOutStockNo   in odata_outstock_m.outstock_no%type,
                            strUserID       in odata_outstock_m.rgst_name%type, --操作人员
                            strOutMsg       out varchar2);
end pklg_odata;


/

