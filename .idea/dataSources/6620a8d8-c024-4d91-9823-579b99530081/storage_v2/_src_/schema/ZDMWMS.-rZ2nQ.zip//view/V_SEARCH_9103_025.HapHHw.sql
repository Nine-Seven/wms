create view V_SEARCH_9103_025 as
select wr.pushresult,
       '8888' as enterprise_no,
       customid as owner_no,
       wr.palletzone as warehouse_no,
       wr.sheetid,
       customid,
       goodsid,
       wr.article_identifier,
       to_char(wr.sdate,'yyyy-mm-dd')sdate,
       wr.barcode,
       planqty,
       bda.owner_article_no,
       bda.article_identifier as article_identifier1,
       bda.barcode as barcode1,
       bda.article_name
  from wms_rationnote@zdmwms_jk wr
  left join bdef_defarticle bda
    on wr.customid = bda.owner_no
   and wr.goodsid = bda.owner_article_no
 order by wr.sheetid, wr.goodsid,wr.sdate

/

