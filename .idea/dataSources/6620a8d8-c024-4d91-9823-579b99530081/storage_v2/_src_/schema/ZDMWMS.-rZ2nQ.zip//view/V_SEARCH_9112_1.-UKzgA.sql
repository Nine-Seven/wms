create view V_SEARCH_9112_1 as
select a.enterprise_no,
       a.warehouse_no,
       a.owner_no,
       a.area_name,
       a.area_no,
       (case when a.po_no is null then  'N' else a.po_no end) as po_no,
       a.disp_cell_no cell_no,
       bd.owner_article_no,
       a.barcode,
       bd.article_no,
       bd.article_identifier,
       bd.article_name,
       bd.supplier_no,
       bds.supplier_name,
       NVL(P.PACKING_UNIT, BD.UNIT) PACKING_UNIT,
       bd.RSV_ATTR8,
       a.packing_qty,
       bd.spec,
       a.qty,
       a.outstock_qty,
       a.instock_Qty,
       trunc(a.qty / a.packing_qty) article_box_qty,
       mod(a.qty, a.packing_qty) / bd.qmin_operate_packing article_dis_qty,
       trunc(a.outstock_qty / a.packing_qty) outstock_box_qty,
       mod(a.outstock_qty, a.packing_qty) / bd.qmin_operate_packing outstock_dis_qty,
       trunc(a.instock_qty / a.packing_qty) instock_box_qty,
       mod(a.instock_qty, a.packing_qty) / bd.qmin_operate_packing instock_dis_qty,
       a.label_no,
       bw.worker_name as updt_name,
       to_char(a.produce_date, 'yyyy-mm-dd') produce_date,
       to_char(a.expire_date, 'yyyy-mm-dd') expire_date,
       a.Cell_Status,
       a.flag,
       ware_no,
       bo.owner_alias
  from bdef_defarticle bd,
       (select a.*,im.po_no from
(select sc.enterprise_no,
       t.area_name,
       t.area_no,
       sc.warehouse_no,
       sc.owner_no,
       cd.disp_cell_no,
       sc.packing_qty,
       (case
         when sc.flag = '0' then
          '正常'
         when sc.flag = '1' then
          '临期'
         when sc.flag = '2' then
          '冻结'
         else
          '解冻'
       end) as flag,
       (case
         when cd.Cell_Status = '0' then
          '可用'
         else
          case
            when cd.Cell_Status = '1' then
             '禁用'
            else
             case
               when cd.Cell_Status = '2' then
                '冻结'
             end
          end
       end) AS Cell_Status,
       sc.article_no,
       sai.barcode,
       sai.produce_date,
       sai.expire_date,
       sai.import_batch_no,
       sai.lot_no,
       sc.label_no,
       sc.updt_name,
       sum(sc.qty) qty,
       sum(sc.outstock_qty) outstock_qty,
       sum(sc.instock_qty) instock_qty,
       cd.ware_no
  from stock_content sc,
       stock_article_info sai,
       cdef_defcell cd,
       cdef_defarea t
 where sc.article_no = sai.article_no
   and sc.article_id = sai.article_id
   and sc.warehouse_no = cd.warehouse_no
   and sc.cell_no = cd.cell_no
   and sc.enterprise_no = cd.enterprise_no
   and cd.enterprise_no = t.enterprise_no
   and cd.warehouse_no = t.warehouse_no
   and cd.ware_no || cd.area_no = t.ware_no || t.area_no
 group by sc.enterprise_no,
          t.area_name,
          t.area_no,
          sc.warehouse_no,
          sc.owner_no,
          cd.cell_no,
          cd.disp_cell_no,
          sc.packing_qty,
          sc.flag,
          cd.cell_status,
          sc.article_no,
          sai.barcode,
          sai.produce_date,
          sai.expire_date,
          sai.import_batch_no,
          sc.label_no,
          sai.lot_no,
          cd.ware_no,
          sc.updt_name)a,
          (select icm.enterprise_no,
               icm.warehouse_no,
               icm.owner_no,
               icm.check_no,
               iim.po_no
          from idata_check_m icm, idata_import_m iim
         where icm.enterprise_no = iim.enterprise_no
           and icm.warehouse_no = iim.warehouse_no
           and icm.owner_no = iim.owner_no
           and icm.import_no = iim.import_no) im
           where a.enterprise_no = im.enterprise_no(+)
           and a.warehouse_no = im.warehouse_no(+)
           and a.owner_no = im.owner_no(+)
           and a.import_batch_no = im.check_no(+)) a,
       bdef_defsupplier bds,
       bdef_defworker bw,
       BDEF_ARTICLE_PACKING P,
       bdef_defowner bo
 where bd.article_no = a.article_no
   AND bd.enterprise_no = a.enterprise_no
   and bd.supplier_no = bds.supplier_no(+)
   AND bd.owner_no = bds.owner_no(+)
   AND bd.enterprise_no = bds.enterprise_no(+)
   and bw.enterprise_no = a.enterprise_no
   and bw.worker_no = a.updt_name
   AND A.ENTERPRISE_NO = P.ENTERPRISE_NO(+)
   AND A.ARTICLE_NO = P.ARTICLE_NO(+)
   AND A.PACKING_QTY = P.PACKING_QTY(+)
   and bo.enterprise_no = bd.enterprise_no
   and bo.owner_no = bd.owner_no
 order by a.enterprise_no,
          a.warehouse_no,
          a.owner_no,
          a.area_name,
          a.disp_cell_no,
          bd.owner_article_no


/

