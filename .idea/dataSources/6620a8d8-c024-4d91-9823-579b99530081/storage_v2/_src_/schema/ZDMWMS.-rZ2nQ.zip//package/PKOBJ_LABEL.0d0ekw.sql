create package        pkobj_label is
  --标签
  -------------------------------------------------【公共begin】-------------------------------------------
  /*****************************************************************************************
   功能：新增标签日志
  *****************************************************************************************/
  procedure proc_InsertLabel_Log(strEnterprise_no in STOCK_LABEL_M.enterprise_no%type, --企业
                                 strwarehouse_no  in STOCK_LABEL_M.warehouse_no%type, --仓别
                                 strLableNo       in STOCK_LABEL_M.Label_No%type, --板号
                                 /*strContainerNo  in STOCK_LABEL_M.container_no%type, --容器号*/
                                 strUSER_ID   in STOCK_LABEL_M.updt_name%type, --员工ID
                                 blInsertFlag in number, --标签跟踪非插入时,要判断新状态是否与老状态一致,如一致不新增日志
                                 strSTATUS    in STOCK_LABEL_M.status%type, --状态
                                 strOutMsg    out varchar2); --返回值

  /*****************************************************************************************
   功能：更新标签状态
  *****************************************************************************************/
  procedure p_updt_label_status(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                strwarehouse_no in STOCK_LABEL_M.warehouse_no%type, --仓别
                                strContainerNo  in STOCK_LABEL_M.container_no%type, --容器号
                                strUSER_ID      in STOCK_LABEL_M.updt_name%type, --员工ID
                                strSTATUS       in STOCK_LABEL_M.status%type, --状态
                                strOutMsg       out varchar2); --返回值
  /**************************************************************************************
  功能：更新标签明细表状态
  luozhiling
  2015.04.30
  ***************************************************************************************/
  procedure p_updt_labelDetail_status(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                      strwarehouse_no in STOCK_LABEL_M.warehouse_no%type, --仓别
                                      strContainerNo  in STOCK_LABEL_M.container_no%type, --容器号
                                      strUSER_ID      in STOCK_LABEL_M.updt_name%type, --员工ID
                                      strSTATUS       in STOCK_LABEL_M.status%type, --状态
                                      strOutMsg       out varchar2);
  /*****************************************************************************************
   功能：标签日志 转历史
  *****************************************************************************************/
  procedure proc_InsertLabel_LogHTY(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                    strwarehouse_no in STOCK_LABEL_M.warehouse_no%type, --仓别
                                    strContainerNo  in STOCK_LABEL_M.container_no%type, --容器号
                                    strUSER_ID      in STOCK_LABEL_M.updt_name%type, --员工ID
                                    strOutMsg       out varchar2); --返回值

  /*****************************************************************************************
     功能：新增标签号
  *****************************************************************************************/
  procedure proc_Insert_LabelMaster(strEnterprise_no      in STOCK_LABEL_M.enterprise_no%type, --企业
                                    strwarehouse_no       in STOCK_LABEL_M.warehouse_no%type, --仓别
                                    strBATCH_NO           in STOCK_LABEL_M.BATCH_NO%type, --批次
                                    strSOURCE_NO          in STOCK_LABEL_M.SOURCE_NO%type, --来源单号
                                    strLABEL_NO           in STOCK_LABEL_M.LABEL_NO%type, --标签号
                                    strCONTAINER_NO       in STOCK_LABEL_M.CONTAINER_NO%type, --内部容器号
                                    strCONTAINER_TYPE     in STOCK_LABEL_M.CONTAINER_TYPE%type, --容器类型
                                    strDELIVER_AREA       in STOCK_LABEL_M.DELIVER_AREA%type, --发货区储位
                                    strOWNER_CELL_NO      in STOCK_LABEL_M.OWNER_CELL_NO%type, --最后并入储位
                                    strCUST_NO            in STOCK_LABEL_M.CUST_NO%type, --客户编号
                                    strTRUNCK_CELL_NO     in STOCK_LABEL_M.TRUNCK_CELL_NO%type, --笼车上储位编码
                                    strA_SORTER_CHUTE_NO  in STOCK_LABEL_M.A_SORTER_CHUTE_NO%type, --大分拣机滑道号
                                    strCHECK_CHUTE_NO     in STOCK_LABEL_M.CHECK_CHUTE_NO%type, --复核台滑道号
                                    strDELIVER_OBJ        in STOCK_LABEL_M.DELIVER_OBJ%type, --配送对象
                                    strUSE_TYPE           in STOCK_LABEL_M.USE_TYPE%type, --标签用途
                                    strLINE_NO            in STOCK_LABEL_M.LINE_NO%type, --线路
                                    strCURR_AREA          in STOCK_LABEL_M.CURR_AREA%type, --当前位置
                                    strDeviceNo           in STOCK_LABEL_M.DEVICE_NO%type, --设备类型
                                    strRGST_NAME          in STOCK_LABEL_M.RGST_NAME%type, --添加人员
                                    strREPORT_ID          in STOCK_LABEL_M.REPORT_ID%type, --报表ID
                                    strMID_LABEL_NO       in STOCK_LABEL_M.MID_LABEL_NO%type, --出货物流箱号
                                    strBIG_EXP_NO_FLAG    in STOCK_LABEL_M.BIG_EXP_NO_FLAG%type, --大批量出货单标识
                                    strSTOCK_TYPE         in STOCK_LABEL_M.STOCK_TYPE%type, --存储类型
                                    strCHUTE_LABEL_FLAG   in STOCK_LABEL_M.CHUTE_LABEL_FLAG%type, --是否大分拣机滑道口取号标签，可用于并板，0：不是；1：是
                                    strOWNER_CONTAINER_NO in STOCK_LABEL_M.OWNER_CONTAINER_NO%type, --最后并入容器号
                                    strstatus             in STOCK_LABEL_M.status%type, --状态
                                    strHm_Manual_Flag     in STOCK_LABEL_M.Hm_Manual_Flag%type, --是否储位库存 1储位库存，0标签库存
                                    strWaveNo             in stock_label_m.wave_no%type, --若没有波次，写为N
                                    strOutMsg             out varchar2); --返回 执行结果
  /*功能：新增标签明细*/
  procedure proc_Insert_LabelDetail(strEnterPriseNo    in stock_label_m.enterprise_no%type,
                                    strWAREHOUSE_NO    in STOCK_LABEL_D.WAREHOUSE_NO%TYPE,
                                    strBATCH_NO        in STOCK_LABEL_D.BATCH_NO%TYPE,
                                    strOWNER_NO        in stock_label_d.owner_no%type,
                                    strSOURCE_NO       in stock_label_d.source_no%type,
                                    strCONTAINER_NO    in stock_label_d.container_no%type,
                                    strCONTAINER_TYPE  in stock_label_d.container_type%type,
                                    strARTICLE_NO      in stock_label_d.article_no%type,
                                    nARTICLE_ID        in stock_label_d.article_id%type,
                                    nPACKING_QTY       in stock_label_d.packing_qty%type,
                                    nQTY               in stock_label_d.qty%type,
                                    strEXP_NO          in stock_label_d.exp_no%type,
                                    strWaveNo          in stock_label_d.wave_no%type,
                                    strCUST_NO         in stock_label_d.CUST_NO%type,
                                    strSUB_CUST_NO     in stock_label_d.SUB_CUST_NO%type,
                                    strLINE_NO         in stock_label_d.LINE_NO%type,
                                    strSTATUS          in stock_label_d.STATUS%type,
                                    nDIVIDE_ID         in stock_label_d.DIVIDE_ID%type,
                                    strEXP_TYPE        in stock_label_d.EXP_TYPE%type,
                                    strDPS_CELL_NO     in stock_label_d.DPS_CELL_NO%type,
                                    strUserID          in stock_label_d.RGST_NAME%type,
                                    strDELIVER_OBJ     in stock_label_d.DELIVER_OBJ%type,
                                    strDeliverObjOrder in stock_label_d.deliverobj_order%type,
                                    dEXP_DATE          in stock_label_d.EXP_DATE%type,
                                    strADVANCE_CELL_NO in stock_label_d.ADVANCE_CELL_NO%type,
                                    strADVANCE_STATUS  in stock_label_d.ADVANCE_STATUS%type,
                                    strOutMsg          out varchar2);
  /*****************************************************************************************
   功能：标签转历史
  *****************************************************************************************/
  procedure proc_RemoveLabel(strEnterPriseNo in stock_label_m.enterprise_no%type,
                             strwarehouse_no in STOCK_LABEL_M.warehouse_no%type, --仓别
                             strContainerNo  in STOCK_LABEL_M.container_no%type, --容器号
                             strOutMsg       out varchar2); --返回值

  -------------------------------------------------【公共end】-------------------------------------------------------

  -------------------------------------------------【出货begin】-------------------------------------------------

  /*****************************************************************************************
   功能：销毁空标签头 容器整理使用
  Modify By YanJunFeng AT 2013-03-20
  *****************************************************************************************/

  procedure proc_OM_Destory_NullLabel(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                      strwarehouse_no in STOCK_LABEL_M.warehouse_no%type, --仓别
                                      strContainerNo  in STOCK_LABEL_M.container_no%type, --容器号
                                      strUSER_ID      in STOCK_LABEL_M.updt_name%type, --员工ID
                                      strOutMsg       out varchar2); --是否成功

  /*=====================================================================================
  snake insert to 20130325
  容器整理----标签转移
  ======================================================================================*/
  PROCEDURE proc_OM_ArrangeMoveLabelInfo(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                         strwarehouse_no in STOCK_LABEL_M.warehouse_no%type, --仓别
                                         strArrange_No   in STOCK_LABEL_Move_log.arrange_no%type, --整理单据号
                                         strUser_Id      in STOCK_LABEL_M.rgst_name%type,
                                         strOutMsg       out varchar2);

  /*标签信息转移*/
  PROCEDURE proc_om_ArrangeByCheck_No(strEnterPriseNo   in stock_label_m.enterprise_no%type,
                                      strwarehouse_no   in STOCK_LABEL_M.warehouse_no%type, --仓别
                                      strOwner_no       in odata_check_label_d.owner_no%type,
                                      strCheck_No       in odata_check_m.check_no%type, --复核单号
                                      strS_Container_No in odata_check_label_d.container_no%type,
                                      nRealQty          in odata_check_label_d.real_qty%type,
                                      nS_RowID          in odata_check_label_d.row_id%type,
                                      strUser_Id        in STOCK_LABEL_M.rgst_name%type,
                                      strOutMsg         out varchar2);
  /*=====================================================================================
  snake insert to 20130418
  拆板----新增目的标签明细
  ======================================================================================*/
  PROCEDURE proc_OM_SplitInsertLabelDetail(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                           strwarehouse_no in STOCK_LABEL_M.warehouse_no%type, --仓别
                                           strArrange_No   in STOCK_LABEL_Move_log.arrange_no%type, --整理单据号
                                           strUser_Id      in STOCK_LABEL_M.rgst_name%type,
                                           strOutMsg       out varchar2);
  -------------------------------------------------【出货end】-------------------------------------------------------

  /*****************************************************************************************
  修改人：lich
  日期：2013-05-16
  功能：更新上架回单子标签状态
  *****************************************************************************************/
  procedure p_Updt_InStock_Label(strEnterPriseNo in stock_label_d.enterprise_no%type, --企业编码,
                                 strWareHouseNo  in STOCK_LABEL_M.warehouse_no%type, --仓别
                                 strInstockNo    in idata_instock_m.instock_no%type, --上架单号
                                 strLabelNo      in STOCK_LABEL_M.Label_No%type, --标签号
                                 strUserId       in STOCK_LABEL_M.updt_name%type, --员工ID
                                 strOutMsg       out varchar2);

  /*****************************************************************************************
  修改人：lich
  日期：2013-05-26
  功能：更新下架回单子标签状态
  *****************************************************************************************/
  procedure P_Updt_OutStock_Label(strEnterPriseNo in stock_label_d.enterprise_no%type, --企业编码
                                  strwarehouse_no in stock_label_d.warehouse_no%type, --仓别
                                  strOwnerNo      in stock_label_d.owner_no%type, --货主
                                  strSourceNo     in stock_label_d.source_no%type, --来源单号
                                  strLabelNo      in stock_label_m.label_no%type, --标签号
                                  strRealQty      in stock_label_d.qty%type, --实际回单量
                                  strDCellNo      in odata_outstock_d.d_cell_no%type, --目的储位
                                  strDivideId     in stock_label_d.divide_id%type, --序列号
                                  strUserID       in stock_label_d.rgst_name%type, --操作人员
                                  --strOutStockType     in odata_outstock_m.outstock_type%type,--下架类型
                                  strOutMsg out varchar2); --返回值
  /*****************************************************************************************
  修改人：lich
  日期：2013-05-26
  功能：流水标签状态取消回单
  *****************************************************************************************/
  procedure P_UpdtCancelOutStock_Label(strEnterPriseNo in stock_label_d.enterprise_no%type, --企业编码
                                       strwarehouse_no in stock_label_d.warehouse_no%type, --仓别
                                       strSourceNo     in stock_label_d.source_no%type, --来源单号
                                       strLabelNo      in stock_label_m.label_no%type, --标签号
                                       strRealQty      in stock_label_d.qty%type, --实际回单量
                                       strDivideId     in stock_label_d.divide_id%type, --序列号
                                       strUserID       in stock_label_d.rgst_name%type, --操作人员
                                       strOutMsg       out varchar2);
  /**************************************************************************************************8
  创建人：luozhiling
  创建时间：2014.11.3
  功能说明：扣减标签明细数据
  ***************************************************************************************************/
  Procedure P_UpdtLabelItme(strEnterPriseNo in stock_label_m.enterprise_no%type,
                            strWareHouseNo  in stock_label_m.warehouse_no%type, --仓别
                            strContainerNo  in stock_label_m.container_no%type, --容器号
                            strUSER_ID      in stock_label_m.updt_name%type,
                            nDivideId       in stock_label_d.divide_id%type,
                            strArticleNo    in stock_label_d.article_no%type,
                            nArticleId      in stock_label_d.article_id%type,
                            nQty            in stock_label_d.qty%type,
                            nRowId          in stock_label_d.row_id%type,
                            strOutMsg       out varchar2);
end pkobj_label;


/

