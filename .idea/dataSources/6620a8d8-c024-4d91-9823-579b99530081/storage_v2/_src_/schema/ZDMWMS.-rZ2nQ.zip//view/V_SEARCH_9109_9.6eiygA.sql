create view V_SEARCH_9109_9 as
select fcm.warehouse_no,
       fcm.owner_no,
       (case
         when fcm.plan_type = '1' then
          '储位盘'
         else
          case
            when fcm.plan_type = '0' then
             '商品盘'
          end
       end) AS plan_type,
       (case
         when fcm.fcdata_type = '1' then
          '盘点'
         else
          case
            when fcm.fcdata_type = '2' then
             '循环盘'
            else
             case
               when fcm.fcdata_type = '3' then
                '动销盘'
             end
          end
       end) AS fcdata_type,
       fcm.source_plan_no,
       to_char(fcm.plan_date, 'yyyy-mm-dd') plan_date,
       to_char(fcm.begin_date, 'yyyy-mm-dd') begin_date,
       to_char(fcm.end_date, 'yyyy-mm-dd') end_date,
       count(distinct b.article_no) articleCount,
       b.check_worker,
       c.worker_name
  from fcdata_plan_m  fcm,
       fcdata_check_m a,
       fcdata_check_d b,
       bdef_defworker c
 where fcm.source_plan_no = a.plan_no
   and a.check_no = b.check_no
   and b.check_worker = c.worker_no
 group by fcm.warehouse_no,
          fcm.owner_no,
          (case
            when fcm.plan_type = '1' then
             '储位盘'
            else
             case
               when fcm.plan_type = '0' then
                '商品盘'
             end
          end),
          (case
            when fcm.fcdata_type = '1' then
             '盘点'
            else
             case
               when fcm.fcdata_type = '2' then
                '循环盘'
               else
                case
                  when fcm.fcdata_type = '3' then
                   '动销盘'
                end
             end
          end),
          fcm.source_plan_no,
          to_char(fcm.plan_date, 'yyyy-mm-dd'),
          to_char(fcm.begin_date, 'yyyy-mm-dd'),
          to_char(fcm.end_date, 'yyyy-mm-dd'),
          b.check_worker,
          c.worker_name
 order by plan_date desc, fcm.source_plan_no desc

/

