create view V_SEARCH_9102_4 as
select tmp.enterprise_no,tmp.warehouse_no,tmp.device_no,tmp.label_id,el.ARTICLE_NO,el.BARCODE,el.ARTICLE_NAME,
tmp.check_qty, um.po_no,f_get_fieldtext('RIDATA_UNTREAD_M','QUALITY',um.quality) quality
from ridata_check_pal_tmp tmp,ridata_check_m cm,ridata_untread_m um
,v_bdef_defarticle el
where tmp.enterprise_no=cm.ENTERPRISE_NO
and tmp.warehouse_no=cm.warehouse_no
and tmp.s_check_no=cm.s_check_no
and cm.untread_no=um.untread_no
and cm.enterprise_no=um.enterprise_no
and cm.warehouse_no=um.warehouse_no
and tmp.enterprise_no=el.ENTERPRISE_NO
and tmp.article_no=el.ARTICLE_NO
order by tmp.device_no,tmp.label_id,el.ARTICLE_NO,um.po_no

/

