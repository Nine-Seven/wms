create trigger UPDATE_TIGGER_CDEF_DEFWARE
    before update
    on CDEF_DEFWARE
    for each row
declare
  -- local variables here
  n_count        number(10); --记录数，以做判断;
--  strOutMsg      varchar(500) ;
begin
    n_count:=0 ;

      --判断仓别是否正确
    begin
      select count(*) into n_count from BDEF_DEFLOC
       where enterprise_no=:old.enterprise_no
         and Warehouse_No =:old.warehouse_no;
    exception
    when no_data_found then
      RAISE_APPLICATION_ERROR(-20002,'N|录入的仓库编码不正确！');
      --strOutMsg:='N|录入的仓别不正确！';
    end;

    if n_count=0 then
      RAISE_APPLICATION_ERROR(-20002,'N|录入的仓库编码不正确！');
    end if ;

    --判断录入strWareName的长度
    if (length(:new.WARE_NAME)=0) then
        RAISE_APPLICATION_ERROR(-20002,'N|修改的仓区名称不能为空！');
--        strOutMsg:='N|录入的仓区名称不能为空';
    end if;

end update_tigger_CDEF_DEFWARE;


/

