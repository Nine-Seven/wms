create package        PKLG_OLOCATE is

  -- Author  : LIZHIPING
  -- Created : 2013-09-28 10:56:43
  -- Purpose :

  -- Public type declarations
  -- type <TypeName> is <Datatype>;
  TYPE cv_type IS REF CURSOR; --声明游标类型

  -- Public constant declarations
  -- <ConstantName> constant <Datatype> := <Value>;

  -- Public variable declarations
  -- <VariableName> <Datatype>;

  -- Public function and procedure declarations
  -- function <FunctionName>(<Parameter> <Datatype>) return <Datatype>;

  --设置定位提交组别
  procedure p_set_transgroup(strEnterpriseNo in varchar2, --企业
                             strWareHouseNo  in varchar2, --仓库代码
                             strWaveNo       in varchar2, --定位号
                             strWorkNo       in varchar2, --员工代码
                             strErrorMsg     out varchar2);
  --提交出货任务
  procedure p_locate_task_commit(strEnterpriseNo in odata_locate_m.enterprise_no%type,
                                 strWareHouseNo  in varchar2, --仓库代码
                                 strWaveNo       in varchar2, --定位号
                                 strWorkNo       in varchar2, --员工代码
                                 strErrorMsg     out varchar2);
  --出货定位程序入口
  procedure p_locate_main(strEnterpriseNo in odata_locate_m.enterprise_no%type,
                          strWareHouseNo  in varchar2, --仓库代码
                          strWaveNo       in varchar2, --定位号
                          strWorkNo       in varchar2, --员工代码
                          strErrorMsg     out varchar2);

  --组定位程序入口
  procedure p_locate_group(strEnterpriseNo    in odata_locate_m.enterprise_no%type,
                           strWareHouseNo     in varchar2, --仓库代码
                           strWaveNo          in varchar2, --定位号
                           nGroupNo           in number, --出货组号
                           strWorkNo          in varchar2, --员工代码
                           blPartShortLocFlag out boolean, --部分缺量标识
                           blAllShortLocFlag  out boolean, --全部缺量标识
                           strErrorMsg        out varchar2);

  --商品定位
  procedure p_locate_article(v_nTmpStockID   in number,
                             strEnterpriseNo in odata_locate_m.enterprise_no%type,
                             strWareHouseNo  in varchar2, --仓库代码
                             strWaveNo       in varchar2, --定位号
                             nGroupNo        in number, --出货组号
                             strMinBatchNo   in varchar2, --最小批次号
                             strDestCellNo   in varchar2,
                             strOwnerNo      in varchar2,
                             strArticleNo    in varchar2, --商品代码
                             nStockRange     in number, --库存范围（0：保拣线；1：全仓）
                             strSourceType   in varchar2,
                             strexptype      in varchar2,
                             strPriority     in varchar2,
                             dtLocateDate    in date,
                             -- strCondition   in varchar2, --特殊条件(预留)
                             --strItemType    in varchar2, --商品属性
                             strStockType  in varchar2, --库存性质
                             strStockValue in varchar2, --库存值
                             --strQuality     in varchar2, --商品品质
                             nLocateQty  in out number, --定位量
                             strWorkNo   in varchar2, --员工代码
                             v_nAllotID  out number,
                             strErrorMsg out varchar2);

  --商品出货类型定位
  procedure p_locate_article_otype(v_nTmpStockID   in number,
                                   v_nAllotID      in number,
                                   strEnterpriseNo in odata_locate_m.enterprise_no%type,
                                   strWareHouseNo  in varchar2, --仓库代码
                                   strOwnerNo      in varchar2, -- 委托业主
                                   strWaveNo       in varchar2, --定位号
                                   nGroupNo        in number, --出货组号
                                   strOperateType  in varchar2, --定位类型
                                   strDestCellNo   in varchar2,
                                   strBatchNo      in varchar2, --定位批次
                                   strArticleNo    in varchar2, --商品代码
                                   nStockRange     in number, --库存范围（0：保拣线；1：全仓）
                                   nPickLine       in number, --保拣线
                                   nPickCount      in number, --拣货位数
                                   strCPickCellNo  in varchar2,
                                   strBPickCellNo  in varchar2,
                                   --strCondition   in varchar2, --特殊条件(预留)
                                   --strItemType    in varchar2, --商品属性
                                   strStockType  in varchar2, --库存性质
                                   strStockValue in varchar2, --库存值
                                   --strQuality     in varchar2, --商品品质
                                   nLocateQty  in out number, --定位量
                                   strWorkNo   in varchar2, --员工代码
                                   Strexptype  in varchar2,
                                   strErrorMsg out varchar2);

  --写库存及定位指示
  procedure p_write_direct(v_nTmpStockID   in number,
                           v_nAllotID      in number,
                           strEnterpriseNo in odata_locate_m.enterprise_no%type,
                           strWareHouseNo  in varchar2, --仓库代码
                           strOwnerNo      in odata_locate_m.owner_no%type,
                           strWaveNo       in varchar2, --定位号
                           nGroupNo        in number, --出货组号
                           strDestCellNo   in varchar2, --目的储位
                           strOperateType  in varchar2, --定位类型
                           strBatchNo      in varchar2, --定位批次
                           strArticleNo    in varchar2, --商品代码
                           strCellNo      in varchar2,
                           strDeptNo      in varchar2,
                           strContainerNo in varchar2,
                           nPacking_Qty   in number,
                           nProduceFlag   in number,
                           dtProduceDate  in date,
                           strQuality     in varchar2, --商品品质
                           --strItemType    in varchar2, --商品属性
                           strLotNo in varchar2,
                           --strSupplierNo  in varchar2,
                           strStockType  in varchar2, --库存性质
                           strStockValue in varchar2, --库存值
                           nStockQty     in number, --可定位库存量
                           nLocateQty    in out number, --定位量
                           strWorkNo     in varchar2, --员工代码
                           Strexptype    in varchar2, --单据类型
                           strErrorMsg   out varchar2);

  --计算拆零拣货补货量
  procedure p_calculate_suppQty(v_nTmpStockID     in number,
                                strEnterpriseNo   in odata_locate_m.enterprise_no%type,
                                strWareHouseNo    in varchar2, --仓库代码
                                strWaveNo         in varchar2, --定位号
                                nGroupNo          in number, --出货组号
                                strArticleNo      in varchar2, --商品代码
                                strPickType       in varchar2, --计算类型 'B','C'
                                strBPickCellNo    in varchar2,
                                strCPickCellNo    in varchar2,
                                strDFlag          in odata_locate_batch.d_flag%type,
                                nCMaxQty          cset_cell_article.max_qty_a%type,
                                nBMaxQty          cset_cell_article.max_qty_a%type,
                                strBrepLenishRule in varchar2,
                                strCrepLenishRule in varchar2,
                                --strCondition   in varchar2, --特殊条件
                                --strItemType    in varchar2, --商品属性
                                strStockType in varchar2, --库存性质
                                --strQuality     in varchar2, --商品品质
                                nLocateQty  in number, --定位量
                                nSupQty     out number,
                                nMinSupQty  out number,
                                strErrorMsg out varchar2);
  --计算拆零量
  procedure p_calculate_bSPlitQty(strEnterPriseNo in odata_locate_m.enterprise_no%type,
                                  strWareHouseNo  in varchar2, --仓库代码
                                  strWaveNo       in varchar2, --定位号
                                  strErrorMsg     out varchar2);

  --物流箱试算
  --procedure p_calculate_bcustbox(strWareHouseNo in varchar2, --仓库代码
  --                               strWaveNo      in varchar2, --定位号
  --                               strWorkNo      in varchar2, --员工代码
  --                               strErrorMsg    out varchar2);
  /**************************************************************************************8
   功能说明：置出货通知单状态为已定位完成。
   创建人：luouzhiling
    创建时间：2014.12.4
  ****************************************************************************************/
  procedure p_close_exp(strCurrEnterpriseNo in odata_exp_m.enterprise_no%type,
                        strWareHouseNo      in odata_exp_m.warehouse_no%type,
                        strExpNo            in odata_exp_m.exp_no%type,
                        strOpereateType     in odata_exp_m.fast_flag%type, --1:取消；2：关单
                        strWorkNo           in varchar2, --员工代码
                        strErrorMsg         out varchar2);

  /**************************************************************************************8
   功能说明：写出货定位日志。
   创建人：lizhiping
   创建时间：2015.7.29
  ****************************************************************************************/
  procedure p_write_log(strEnterpriseNo in odata_locate_m.enterprise_no%type,
                        strWareHouseNo  in varchar2, --仓库代码
                        strWaveNo       in varchar2, --定位号
                        strLogText      in varchar2, --日志
                        strLogStatus    in varchar2);

  /**************************************************************************************8
   功能说明：写出货定位日志。
   创建人：lizhiping
   创建时间：2015.7.29
  ****************************************************************************************/
  procedure p_write_short_log(strEnterpriseNo in odata_locate_m.enterprise_no%type,
                              strWareHouseNo  in varchar2, --仓库代码
                              strWaveNo       in varchar2, --定位号
                              strOwnerNo      in varchar2, --货主
                              nGroupNo        in number, --提交组别
                              strExpNo        in varchar2, --单号
                              strCustNo       in varchar2, --客户代码
                              strSubCustNo    in varchar2, --子客户代码
                              strCellNo       in varchar2, --货位
                              strArticleNo    in varchar2, --商品编码
                              nArticleID      in number, --商品批次ID
                              nPackingQty     in number, --库存包装
                              nStockQty       in number, --库存量
                              nLocateQty      in number, --需求量
                              strOperateType  in varchar2, --定位类型
                              strShortReason  in varchar2 --不能定位原因
                              );

  /**************************************************************************************8
   功能说明：设置定位补货方式。
   创建人：lizhiping
   创建时间：2015.7.29
  ****************************************************************************************/
  procedure p_setsupp_mode(strEnterpriseNo in odata_locate_m.enterprise_no%type,
                           strWareHouseNo  in varchar2, --仓库代码
                           strWaveNo       in varchar2, --定位号
                           strOwnerNo      in varchar2,
                           strArticleNo    in varchar2, --商品代码
                           strErrorMsg     out varchar2);
  /**************************************************************************************************************
    功能说明：1、对出货单进行集单；目前采用临时表的方式选取单据
             2、定位；
             3、拣货发单

  ***************************************************************************************************************/
  procedure P_LocateAndGetTask(strEnterpriseNo in odata_locate_m.enterprise_no%type, --企业
                               strWarehouseNo  in odata_locate_m.warehouse_no%type, --仓别
                               strOwnerNo      in odata_locate_m.owner_no%type, --货主
                               strExpType      in odata_locate_m.EXP_TYPE%type, --出货单类型
                               strUserId       in odata_locate_m.locate_name%type, --集单人员
                               strExpNo        in odata_exp_m.sourceexp_no%type, --出货通知单
                               strDockNo       in bdef_defdock.dock_no%type,
                               strNewWaveNo    out odata_exp_m.sourceexp_no%type, --返回波次号
                               strResult       out varchar2);

  /************************************************************************************************************
    读取出货类型的配送级别
    2015.12.12
  *************************************************************************************************************/
  procedure GetDeliverObjLevel(strEnterpriseNo    in varchar2, --企业
                               strWareHouseNo     in varchar2, --仓库代码
                               strOwnerNo         in varchar2,
                               strExpType         in varchar2, --定位号
                               strDelvierObjLevel out varchar2, --配送对象级别
                               strErrorMsg        out varchar2);

  /************************************************************************************************************
    特殊区域快速定位，直接进出货暂存区，不产生拣货任务(比如电商赠品出库)
    2016.06.23
  *************************************************************************************************************/
  procedure P_Locate_SpecialArea(strEnterpriseNo  in odata_locate_m.enterprise_no%type,
                                 strWareHouseNo   in varchar2, --仓库代码
                                 strWorkNo        in varchar2, --员工代码
                                 strArticleNo     in bdef_defarticle.article_no%type, --商品
                                 nLocateQty       in out number, --定位量
                                 strItemType      in cdef_defarea.item_type%type, --储区类型(0:普通区域;1:赠品区域)
                                 strSourceCellNo  in cdef_defcell.cell_no%type, --指定储位出货(默认N)
                                 strSourceNo      in stock_content_move.PAPER_NO%type, --来源单号
                                 strExpNo         in odata_exp_m.exp_no%type, --出货单号
                                 strLabelNo       in stock_label_m.label_no%type,
                                 strContainerNo   in stock_label_m.container_no%type,
                                 strContainerType in stock_label_m.container_type%type,
                                 strStatus        in stock_label_d.status%type, --标签状态
                                 strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                                 nRealQty         out number, --返回定位数量
                                 strErrorMsg      out varchar2);

  /**************************************************************************************
   功能说明：定位后回写出货单明细定位数量
   创建人：jiangchenglong
   创建时间：2016.6.23
  ****************************************************************************************/
  procedure P_UpdateExpLocateQty(strEnterPriseNo in odata_exp_d.enterprise_no%type,
                                 strWareHouseNo  in odata_exp_d.warehouse_no%type,
                                 strOwnerNo      in odata_exp_d.owner_no%type,
                                 strExpNo        in odata_exp_d.exp_no%type,
                                 strArticleNo    in odata_exp_d.article_no%type,
                                 nAllotQty       in number,
                                 strErrorMsg     out varchar2);

end PKLG_OLOCATE;


/

