create package body        pkobj_sodata is

  /**************************************************************************************************8
   功能说明：写报损手建单头档
   2015.7.25

  ***************************************************************************************************/
  procedure P_InsertWasteHead(strEnterPriseNo in sodata_waste_m.enterprise_no%type,
                               strWarehouseNo in sodata_waste_m.warehouse_no%type, --仓别
                               strOwnerNo     in sodata_waste_m.owner_no%type,
                               strCreateFlag  in sodata_waste_m.create_flag%type,--
                               strStockType   in sodata_waste_m.stock_type%type,
                               strStockValue  in sodata_waste_m.stock_value%type,
                               strOrgNo       in sodata_waste_m.org_no%type,
                               strUserID      in sodata_waste_m.rgst_name%type,
                               strWasteNo     out sodata_waste_m.waste_no%type,
                               strResult      out varchar2) is
  begin
    strResult := 'N|[P_InsertWasteHead]';

    --获取报损单号

    PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,strWareHouseNo,CONST_DOCUMENTTYPE.SOPLAN,strWasteNo,strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    insert into sodata_waste_m(enterprise_no,warehouse_no,owner_no,waste_type,waste_no,
           po_type,po_no,waste_date,request_date,status,create_flag,stock_type,
           stock_value,org_no,rgst_name,rgst_date)
        values(strEnterPriseNo,strWarehouseNo,strOwnerNo,CONST_DOCUMENTTYPE.SOPLAN,strWasteNo,
           CONST_DOCUMENTTYPE.SOPLAN,strWasteNo,trunc(sysdate),trunc(sysdate),'10',strCreateFlag,
           strStockType,strStockValue,strOrgNo,strUserID,sysdate);

    strResult := 'Y';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_InsertWasteHead;

  /***********************************************************************************************
  功能说明：写报损单明细
  2015.7.27

  ***********************************************************************************************/
  procedure P_InsertWasteItem(strEnterPriseNo in sodata_waste_m.enterprise_no%type,
                                   strWarehouseNo in sodata_waste_m.warehouse_no%type, --仓别
                                   strOwnerNo     in sodata_waste_m.owner_no%type,
                                   strWasteNo     in sodata_waste_m.waste_no%type,
                                   strArticleNo   in sodata_waste_d.article_no%type,
                                   nPackingQty    in sodata_waste_d.packing_qty%type,
                                   strLotNo       in sodata_waste_d.lot_no%type,
                                   strQuality     in sodata_waste_d.quality%type,
                                   nWasteQty      in sodata_waste_d.waste_qty%type,
                                   strOutMsg      out varchar2) is
       v_iCount                    integer;
  begin
       strOutMsg:='N|[P_InsertWasteItem]';

       --获取最大的单内序号
       select nvl(max(po_id)+1,1) into v_iCount from sodata_waste_d where enterprise_no=strEnterPriseNo
              and warehouse_no=strWarehouseNo and waste_no=strWasteNo;
       insert into sodata_waste_d(enterprise_no,warehouse_no,owner_no,waste_no,po_id,
              article_no,packing_qty,lot_no,quality,waste_qty)
          values(strEnterPriseNo,strWarehouseNo,strOwnerNo,strWasteNo,v_iCount,
              strArticleNo,nPackingQty,strLotNo,strQuality,nWasteQty);

       strOutMsg:='Y|[]';
  end P_InsertWasteItem;

  /**********************************************************************************************
  功能：写报损下架指示
    2015.7.27
  huangb 20160511 移至PKLG_SODATA包
  **********************************************************************************************/
  /*procedure P_InsertSodateDirect(strEnterPriseNo in sodata_waste_m.enterprise_no%type,
                                  strWareHouseNo  in sodata_waste_m.warehouse_no%type,
                                  strWasteNo      in sodata_waste_m.waste_no%type,
                                  strArticleNo    in sodata_waste_d.article_no%type,
                                  strLotNo        in sodata_waste_d.lot_no%type,
                                  dtProduceDate   in sodata_waste_d.produce_date%type,
                                  dtExpireDate    in sodata_waste_d.expire_date%type,
                                  strStockType    in sodata_waste_m.stock_type%type,
                                  strStockValue   in sodata_waste_m.stock_value%type,
                                  strOrgNo        in sodata_waste_m.org_no%type,
                                  strDestCellNo   in cdef_defcell.cell_no%type,
                                  strUserId       in sodata_waste_m.rgst_name%type,
                                  nPoID           in sodata_waste_d.po_id%type,
                                  nQty            in sodata_waste_d.waste_qty%type,
                                  strResult       out varchar2) IS
    v_nCurQty       sodata_waste_d.waste_qty%type; --当前定位数量
    v_nRemainQty    sodata_waste_d.waste_qty%type; --剩余定位量
    v_strDestCellNo cdef_defcell.cell_no%type;
    v_destCellID    stock_content.cell_id%type;

    cursor v_getWasteStock is
      select sc.*,
             sai.lot_no,
             sai.produce_date,
             sai.expire_date,
             sai.quality
        from stock_content      sc,
             stock_article_info sai,
             cdef_defcell       cd,
             cdef_defarea       t,
             cdef_defware       cw
       where sc.enterprise_no = sai.enterprise_no
         and sc.enterprise_no = cd.enterprise_no
         and sc.enterprise_no = t.enterprise_no
         and sc.enterprise_no = strEnterPriseNo
         and sc.warehouse_no = cd.warehouse_no
         and t.enterprise_no =cw.enterprise_no
         and t.warehouse_no=cw.warehouse_no
         and t.ware_no=cd.ware_no and cw.org_no=strOrgNo
         and sc.warehouse_no = t.warehouse_no
         and sc.warehouse_no = strWareHouseNo
         and sc.article_no = sai.article_no
         and sc.article_id = sai.article_id
         and sc.cell_no = cd.cell_no
         and cd.ware_no = t.ware_no
         and cd.area_no = t.area_no
         and t.area_usetype in ('2')
         and t.area_attribute in ('0')
         and (strLotNo = 'N' or
             (strLotNo <> 'N' and sai.lot_no = strLotNo))
         and (dtProduceDate is null or
             (dtProduceDate is not null and
             sai.produce_date = dtProduceDate))
         and (dtExpireDate is null or (dtExpireDate is not null and
             sai.expire_date = dtExpireDate))
         and cd.cell_status <> '1'
         and sc.qty - sc.outstock_qty > 0
         and sc.stock_type = strStockType and
             sc.stock_value = strStockValue
         and sc.article_no = strArticleNo
       order by sc.cell_no, sai.produce_date;

  begin
     strResult    := 'N|[P_InsertSodateDirect]';
     v_nRemainQty := nQty;

     --锁定此商品的库存；
     update stock_content t set t.status=status
     where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWarehouseNo
     and t.article_no=strArticleNo and t.stock_type=strStockType
     and t.stock_value=strStockValue and t.cell_no in(
     select cell_no from cdef_defware cw,cdef_defarea ca,cdef_defcell cd
     where cw.enterprise_no=ca.enterprise_no and cw.warehouse_no=ca.warehouse_no
     and cw.ware_no=ca.ware_no and cw.org_no=strOrgNo
     and cw.enterprise_no=cd.enterprise_no and cw.warehouse_no=cd.warehouse_no
     and ca.ware_no=cd.ware_no and ca.area_no=cd.area_no
     and ca.area_usetype in ('2') and ca.area_attribute in ('0')
     and cd.cell_status<>'1');

     for GetStock  in v_getWasteStock loop
         if v_nRemainQty >= GetStock.qty - GetStock.outstock_qty then
            v_nCurQty := GetStock.qty - GetStock.outstock_qty;
          else
            v_nCurQty := v_nRemainQty;
          end if;
          v_nRemainQty := v_nRemainQty - v_nCurQty;
              --写库存
          pkobj_stock.p_UpdtContent_Reservation(strEnterPriseNo,
                                                strWareHouseNo,
                                                GetStock.cell_no,
                                                GetStock.cell_id,
                                                strDestCellNo,
                                                GetStock.label_no,
                                                GetStock.sub_label_no,
                                                v_nCurQty,
                                                '0',
                                                strUserId,
                                                v_destCellID,
                                                strResult);

          if substr(strResult, 1, 1) = 'N' then
            return;
          end if;

          insert into sodata_outstock_direct(enterprise_no,warehouse_no,owner_no,operate_type,operate_date,
                 article_no,article_id,packing_qty,s_cell_no,s_cell_id,
                 d_cell_no,d_cell_id,locate_qty,status,po_id,source_no,
                 stock_type,stock_value,rgst_name,rgst_date)
             values(strEnterPriseNo,strWarehouseNo,GetStock.owner_no,'C',trunc(sysdate),
                 GetStock.article_no,GetStock.article_id,GetStock.packing_qty,GetStock.cell_no,
                 GetStock.cell_id,strDestCellNo,v_destCellID,v_nCurQty,'10',nPoId,strWasteNo,
                 strStockType,strStockValue,strUserID,sysdate);


          --更新报损单明细
          update sodata_waste_d t
             set t.locate_qty = t.locate_qty + v_nCurQty
           where t.enterprise_no = strEnterPriseNo
             and t.warehouse_no = strWareHouseNo
             and t.waste_no = strWasteNo
             and t.article_no = GetStock.article_no
             and t.po_id = nPoID;

        if v_nRemainQty = 0 then
          exit;
        end if;

     end loop;



      strResult := 'Y';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_InsertSodateDirect;
*/
  /***************************************************************************************************
   功能说明：写报损下架单头档
   2015.7.27

  *****************************************************************************************************/
  procedure P_InsertWasteOutstockHead(strEnterPriseNo in sodata_outstock_m.enterprise_no%type,
                                   strWarehouseNo in sodata_outstock_m.warehouse_no%type, --仓别
                                   strOwnerNo     in sodata_outstock_m.owner_no%type,
                                   strOutStockNo  in sodata_outstock_m.outstock_no%type, --下架单号
                                   strAssignName  in sodata_outstock_m.rgst_name%type, --计划作业人员
                                   strOutMsg      out varchar2) is
  begin
       strOutMsg:='N|[P_InsertWasteOutstockHead]';

       insert into sodata_outstock_m(enterprise_no,warehouse_no,owner_no,outstock_no,status,
          operate_date,rgst_name,rgst_date)
          values(strEnterPriseNo,strWarehouseNo,strOwnerNo,strOutStockNo,'10',
             trunc(sysdate),strAssignName,sysdate);

       strOutMsg:='Y|[]';
  end P_InsertWasteOutstockHead;
  /********************************************************************************************
  功能说明：写报损单明细档
  2015.7.27
  *********************************************************************************************/
  procedure P_InserWasteOutStockItem(strEnterPriseNo in sodata_outstock_m.enterprise_no%type,
                                   strWarehouseNo in sodata_outstock_m.warehouse_no%type, --仓别
                                   strOwnerNo     in sodata_outstock_m.owner_no%type,
                                   strOutStockNo  in sodata_outstock_m.outstock_no%type, --下架单号
                                   strUserId      in sodata_outstock_m.rgst_name%type, --计划作业人员
                                   nDirectSerial  in sodata_outstock_d.divide_id%type, --指示序列
                                   strOutMsg      out varchar2) is
  begin
    strOutMsg := 'N|[P_InserWasteOutStockItem]';


    insert into sodata_outstock_d(enterprise_no,warehouse_no,owner_no,outstock_no,divide_id,source_no,
        po_id,article_no,article_id,packing_qty,article_qty,real_qty,s_cell_no,s_cell_id,
        d_cell_no,d_cell_id,status,assign_name)
      select d.enterprise_no,d.warehouse_no,d.owner_no,strOutStockNo,d.direct_serial,
        d.source_no,d.po_id,d.article_no,d.article_id,d.packing_qty,d.locate_qty,0,
        d.s_cell_no,d.s_cell_id,d.d_cell_no,d.d_cell_id,'10',d.rgst_name
        from sodata_outstock_direct d
       where d.enterprise_no=strEnterPriseNo
         and d.warehouse_no = strWarehouseNo
         and d.owner_no = strOwnerNo
         and d.direct_serial = nDirectSerial;
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[P_InserWasteOutStockItem]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_InserWasteOutStockItem;

  /*********************************************************************************************
  功能说明：更新报损下架指示
  2015.7.27

  **********************************************************************************************/
  procedure P_UpdatedWasteDirect(strEnterPriseNo in sodata_outstock_d.enterprise_no%type,
                                 strWarehouseNo in sodata_outstock_d.warehouse_no%type, --仓别
                                 strOwnerNo     in sodata_outstock_d.owner_no%type,
                                 strWasteNo     in sodata_outstock_d.source_no%type, --报损单号
                                 strUserID      in sodata_outstock_d.assign_name%type, --员工ID
                                 strOutMsg      out varchar2) --返回值
   is
  begin
    strOutMsg := 'N|[P_UpdatedWasteDirect]';

    update sodata_outstock_direct t
       set UPDT_DATE = SYSDATE, t.status = '13', t.updt_name = strUserID
     where t.enterprise_no=strEnterPriseNo and t.warehouse_no = strWarehouseNo
       and t.owner_no = strOwnerNo
       and t.status = '10'
       and t.source_no = strWasteNo;
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E25204]';
      return;
    end if;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_UpdatedWasteDirect;
  /****************************************************************************************************
  功能说明：更新报损下架单头档
  2015.7.27

  *****************************************************************************************************/
  procedure P_UpdateWasteOutStockHeader(strEnterPriseNo in sodata_outstock_m.enterprise_no%type,
                                      strWarehouseNo in sodata_outstock_m.warehouse_no%type, --仓别
                                      strOutStockNo  in sodata_outstock_m.outstock_no%type, --下架单号
                                      strOwnerNo     in sodata_outstock_m.owner_no%type,
                                      strUserId      in sodata_outstock_m.rgst_name%type, --员工ID
                                      strOutMsg      out varchar2) --返回值
   is
  begin
    strOutMsg := 'N|[P_UpdateWasteOutStockHeader]';

    ---更新下架单头档
    UPDATE sodata_outstock_m OOM
       SET OOM.UPDT_DATE = SYSDATE,
           OOM.UPDT_NAME = strUserId,
           OOM.STATUS    = '13'
     where oom.enterprise_no=strEnterPriseNo and oom.warehouse_no = strWarehouseNo
       and oom.outstock_no = strOutStockNo
       and oom.owner_no = strOwnerNo
       and oom.status < '13';
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[sodata_outstock_m]';
      return;
    end if;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_UpdateWasteOutStockHeader;

  /***************************************************************************************************88
  功能说明：更新报损下架明细
  2015.7.27
  ***********************************************************************************************/
  procedure P_UpdateWasteOutstockItem(strEnterPriseNo in sodata_outstock_m.enterprise_no%type,
                             strWarehouseNo  in sodata_outstock_d.warehouse_no%type, --仓别
                             strOutStockNo   in sodata_outstock_d.outstock_no%type, --下架单号
                             nRealQty        in sodata_outstock_d.real_qty%type,
                             strOwnerNo      in sodata_outstock_d.owner_no%type,
                             nDivideId          in sodata_outstock_d.divide_id%type,
                             strOutstockName in sodata_outstock_d.outstock_name%type, --出货员工ID
                             strOutMsg       out varchar2) is
  begin
    strOutMsg := 'N|[P_UpdateWasteOutstockItem]';
    update sodata_outstock_d d
       set d.real_qty         = nRealQty,
           d.outstock_name=strOutstockName,
           d.outstock_date=sysdate
     where d.enterprise_no=strEnterPriseNo and d.warehouse_no = strWarehouseNo
       and d.outstock_no = strOutStockNo
       and d.owner_no = strOwnerNo
       and d.divide_id = nDivideId;
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[P_UpdateWasteOutstockItem]';
      return;
    end if;
    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_UpdateWasteOutstockItem;

  /******************************************************************************************888
  功能说明：报损下架单转历史
  2015.7.27

  *********************************************************************************************/
  procedure P_UpdateOutStockHistory(strEnterPriseNo in sodata_outstock_m.enterprise_no%type,
                                       strWarehouseNo in sodata_outstock_m.warehouse_no%type, --仓别
                                       strOutStockNo  in sodata_outstock_m.outstock_no%type, --下架单号
                                       strOwnerNo     in sodata_outstock_m.owner_no%type,
                                       strOutMsg      out varchar2) is

    iCount integer := 0;
    v_strWasteNo   sodata_waste_m.waste_no%type;
  begin

    strOutMsg := 'N|[P_UpdateOutStockHistory]';
    select count(1)
      into iCount
      from sodata_outstock_d d
     where d.enterprise_no=strEnterPriseNo and d.warehouse_no = strWarehouseNo
       and d.owner_no = strOwnerNo
       and d.outstock_no = strOutStockNo
       and d.status = '10';
    if iCount > 0 then
      strOutMsg := 'Y|';
      return;
    end if;

    --获取报损单号；
    select source_no into v_strWasteNo from sodata_outstock_d
    where enterprise_no=strEnterPriseNo and warehouse_no=strWarehouseNo
    and outstock_no=strOutStockNo and rownum=1;

    --写报损下架指示历史表
    insert into sodata_outstock_directhty(enterprise_no,warehouse_no,owner_no,operate_type,
                 operate_date,direct_serial,article_no,article_id,packing_qty,s_cell_no,s_cell_id,
                 d_cell_no,d_cell_id,locate_qty,status,po_id,source_no,
                 stock_type,stock_value,rgst_name,rgst_date,updt_name,updt_date)
       select enterprise_no,warehouse_no,owner_no,operate_type,
                 operate_date,direct_serial,article_no,article_id,packing_qty,s_cell_no,s_cell_id,
                 d_cell_no,d_cell_id,locate_qty,status,po_id,source_no,
                 stock_type,stock_value,rgst_name,rgst_date,updt_name,updt_date
       from sodata_outstock_direct
       where enterprise_no=strEnterPriseNo and warehouse_no=strWarehouseNo
       and source_no=v_strWasteNo;

    --删除报损下架指示
    delete from sodata_outstock_direct
       where enterprise_no=strEnterPriseNo and warehouse_no=strWarehouseNo
       and source_no=v_strWasteNo;

    insert into sodata_outstock_dhty(enterprise_no,warehouse_no,owner_no,outstock_no,
           divide_id,source_no,po_id,article_no,article_id,packing_qty,article_qty,
           real_qty,s_cell_no,s_cell_id,d_cell_no,d_cell_id,status,
           assign_name,outstock_name,outstock_date)
       select enterprise_no,warehouse_no,owner_no,outstock_no,
           divide_id,source_no,po_id,article_no,article_id,packing_qty,article_qty,
           real_qty,s_cell_no,s_cell_id,d_cell_no,d_cell_id,status,
           assign_name,outstock_name,outstock_date
        from sodata_outstock_d
       where enterprise_no=strEnterPriseNo and warehouse_no = strWarehouseNo
         and owner_no = strOwnerNo
         and outstock_no = strOutStockNo;


    delete sodata_outstock_d
     where enterprise_no=strEnterPriseNo and warehouse_no = strWarehouseNo
       and owner_no = strOwnerNo
       and outstock_no = strOutStockNo;
    insert into sodata_outstock_mhty(enterprise_no,warehouse_no,owner_no,
           outstock_no,operate_date,status,rgst_name,rgst_date,updt_name,updt_date,
           --huangb 20160509
           REPORT_UP_SERIAL)
      select enterprise_no,warehouse_no,owner_no,
           outstock_no,operate_date,status,rgst_name,rgst_date,updt_name,updt_date,
           --huangb 20160509
           REPORT_UP_SERIAL
        from sodata_outstock_m
       where enterprise_no=strEnterPriseNo and warehouse_no = strWarehouseNo
         and owner_no = strOwnerNo
         and outstock_no = strOutStockNo;
    delete sodata_outstock_m
     where enterprise_no=strEnterPriseNo and warehouse_no = strWarehouseNo
       and owner_no = strOwnerNo
       and outstock_no = strOutStockNo;
    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_UpdateOutStockHistory;

  /*******************************************************************************************************
  创建人：huangb
  创建时间：2016.05.16
  功能说明：报损单据转历史
  ********************************************************************************************************/
  procedure P_SO_InsertHTY(strEnterPriseNo in sodata_outstock_m.enterprise_no%type,
                           strWarehouseNo  in sodata_outstock_m.warehouse_no%type, --仓别
                           strOwnerNo      in sodata_outstock_m.owner_no%type,
                           strOutstockNo   in sodata_outstock_m.outstock_no%type, --报损下架单
                           strUserID       in sodata_outstock_m.rgst_name%type,
                           strOutMsg       out varchar2) is
  begin
   strOutMsg := 'N|[P_SO_InsertHTY]';

   --报损单明细转历史
   insert into sodata_waste_dhty
     (enterprise_no, warehouse_no, owner_no, waste_no, po_id, article_no, packing_qty, lot_no
     , quality, produce_date, expire_date, waste_qty, real_qty, locate_qty)
   select swd.enterprise_no, swd.warehouse_no, swd.owner_no, swd.waste_no, swd.po_id, swd.article_no, swd.packing_qty, swd.lot_no
     , swd.quality, swd.produce_date, swd.expire_date, swd.waste_qty, swd.real_qty, swd.locate_qty
   from sodata_waste_d swd
   where swd.enterprise_no = strEnterPriseNo
     and swd.warehouse_no = strWarehouseNo
     and swd.owner_no = strOwnerNo
     and swd.waste_no in
         (select sod.source_no
            from sodata_outstock_d sod
            where sod.enterprise_no = strEnterPriseNo
              and sod.warehouse_no = strWarehouseNo
              and sod.owner_no = strOwnerNo
              and sod.outstock_no = strOutstockNo);

   --报损单头档转历史
   insert into sodata_waste_mhty
     (enterprise_no, warehouse_no, owner_no, waste_type, waste_no, po_type, po_no, waste_date
     , request_date, status, create_flag, send_flag, stock_type, stock_value, org_no, rgst_name
     , rgst_date, updt_name, updt_date, report_up_serial)
   select swm.enterprise_no, swm.warehouse_no, swm.owner_no, swm.waste_type, swm.waste_no, swm.po_type, swm.po_no, swm.waste_date
     , swm.request_date, swm.status, swm.create_flag, swm.send_flag, swm.stock_type, swm.stock_value, swm.org_no, swm.rgst_name
     , swm.rgst_date, strUserID, sysdate, swm.report_up_serial
   from sodata_waste_m swm
   where swm.enterprise_no = strEnterPriseNo
     and swm.warehouse_no = strWarehouseNo
     and swm.owner_no = strOwnerNo
     and swm.status in ('13',16)
     and swm.waste_no in
         (select sod.source_no
            from sodata_outstock_d sod
            where sod.enterprise_no = strEnterPriseNo
              and sod.warehouse_no = strWarehouseNo
              and sod.owner_no = strOwnerNo
              and sod.outstock_no = strOutstockNo);

   --删除正表
   delete sodata_waste_d swd
    where swd.enterprise_no = strEnterPriseNo
      and swd.warehouse_no = strWarehouseNo
      and swd.owner_no = strOwnerNo
      and swd.waste_no in
          (select sod.source_no
             from sodata_outstock_d sod
             where sod.enterprise_no = strEnterPriseNo
               and sod.warehouse_no = strWarehouseNo
               and sod.owner_no = strOwnerNo
               and sod.outstock_no = strOutstockNo);

   delete sodata_waste_m swm
    where swm.enterprise_no = strEnterPriseNo
      and swm.warehouse_no = strWarehouseNo
      and swm.owner_no = strOwnerNo
      and swm.status in ('13',16)
      and swm.waste_no in
          (select sod.source_no
             from sodata_outstock_d sod
             where sod.enterprise_no = strEnterPriseNo
               and sod.warehouse_no = strWarehouseNo
               and sod.owner_no = strOwnerNo
               and sod.outstock_no = strOutstockNo);

  strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|P_SO_InsertHTY' || SQLERRM ||
            substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end P_SO_InsertHTY;

 end pkobj_Sodata;

/

