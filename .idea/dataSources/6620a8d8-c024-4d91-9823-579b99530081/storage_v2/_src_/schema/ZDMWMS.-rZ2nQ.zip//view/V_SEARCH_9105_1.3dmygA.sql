create view V_SEARCH_9105_1 as
select a.article_no,
       b.BARCODE,
       b.article_name,
       b.UNIT,
       b.SPEC,
       a.cell_no,
       a.label_no,
       a.packing_qty,
       a.qty,
       a.outstock_qty,
       a.instock_qty,
       a.updt_name,
       a.updt_date
  from stock_content a, bdef_defarticle b
 where a.article_no = b.article_no
   and a.owner_no = b.owner_no
   and a.enterprise_no = b.enterprise_no


/

