create view V_SEARCH_9112_4 as
select lis.enterprise_no,
       lis.warehouse_no,
       lis.owner_no,
       o.owner_alias,
       oem.sourceexp_no,
       icm.s_import_no,
       spm.plan_no,
       case lis.paper_type
         when 'I' THEN
          '进货'
         when 'O' then
          '出货'
         when 'UM' THEN
          '客户退货'
         when 'RO' THEN
          '退货'
         when 'SP' THEN
          '调账'
         when 'FC' THEN
          '盘点'
       end paper_type,
       to_char(lis.paper_date, 'yyyy-mm-dd') operate_date,
       lis.paper_no,
       lis.article_no,
       lis.packing_qty,
       v.owner_article_no,
       v.barcode,
       v.article_identifier,
       v.article_name,
       lis.move_qty
  from stock_content_list lis
  left join odata_exp_m oem
    on oem.enterprise_no = lis.enterprise_no
   and oem.warehouse_no = lis.warehouse_no
   and oem.owner_no = lis.owner_no
   and oem.exp_no = paper_no
  left join IDATA_CHECK_M ICM
    on ICM.Enterprise_No = lis.ENTERPRISE_NO
   AND ICM.warehouse_no = lis.warehouse_no
   AND ICM.OWNER_NO = lis.OWNER_NO
   AND ICM.CHECK_NO = lis.PAPER_NO
 left join stock_plan_m SPM
    on SPM.Enterprise_No = lis.ENTERPRISE_NO
   AND SPM.warehouse_no = lis.warehouse_no
   AND SPM.OWNER_NO = lis.OWNER_NO
   AND SPM.PLAN_NO = lis.PAPER_NO
  join bdef_defarticle v
    ON lis.enterprise_no = v.enterprise_no
   and lis.article_no = v.article_no
  join bdef_defowner o
    ON o.enterprise_no = v.enterprise_no
   and o.owner_no = v.owner_no
 order by  lis.paper_date/* ,o.owner_no, v.article_no */desc


/

