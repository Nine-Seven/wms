create PACKAGE BODY        PKLG_BUFFER_CALCULATE IS
  -- Author  : weiyufei
  -- Created : 2016-02-25
  -- Purpose : 出货暂存区资源试算
  /**************************************************************************************************/
  /*
   功能说明：定位前勾单校验暂存区资源是否够用
   创建人：wyf
   创建时间：2016.2.29
   strDelFlag = '1' and strRetryFlag = '1'时，相当于取消勾选【是否试算】可不传客户与出货单
   strDelFlag = '1' and strRetryFlag = '0'时，相当于取消勾选订单或者客户，根据是否【按客户调度】传出货单号或者客户
   strDelFlag = '0' and strRetryFlag = '1'时，相当于重算月台资源，可不传客户与出货单
   strDelFlag = '0' and strRetryFlag = '0'时，正常勾选客户或者订单，根据是否【按客户调度】传出货单号或者客户

   出货暂存区资源按出货类型策略试算 huangb 20160622
  */
  /**************************************************************************************************/
  procedure P_DeliverArea_Cal_Tmp(strEnterpriseNo in varchar2, --企业
                                  strWareHouseNo  in varchar2, --仓库代码
                                  strOwnerNo      in varchar2,
                                  strExpType      in odata_exp_m.exp_type%type,
                                  strTmpID        in odata_tmp_locate_select.tmp_id%type,
                                  strExpNo        in odata_tmp_locate_select.exp_no%type, --按单调度传 重整时不传
                                  strCustNo       in odata_exp_m.cust_no%type, --按客户时传 重整时不传
                                  strSendBufFlag  in ODATA_LOCATE_BATCH.SENDBUF_COMPUTE_FLAG%TYPE, --是否资源试算
                                  /*strSendBufLv    in ODATA_LOCATE_BATCH.SENDBUF_COMPUTE_LEVEL%TYPE, --
                                  strSendBufVal   in ODATA_LOCATE_BATCH.SENDBUF_COMPUTE_VALUE%TYPE, --
                                  strDeliverObjLv in ODATA_LOCATE_BATCH.DELIVER_OBJ_LEVEL%TYPE,*/
                                  strDelFlag      in varchar2, --是否删除 0：不删除，1：删除
                                  strRetryFlag    in varchar2, --是否暂存区资源重整 0：不重整，1：重整
                                  strResult       out varchar2) IS
    v_nCount integer;

    v_strSql           varchar2(1500);
    v_strDeliverObjSql varchar2(64);

    TYPE ref_cursor_type IS REF CURSOR;
    v_GetExpInfo ref_cursor_type;

    v_strLinNo      ODATA_TMP_LOCATE_SELECT.LINE_NO%TYPE;
    v_strDeliverObj ODATA_LOCATE_D.DELIVER_OBJ%TYPE;
    v_nLineSeqNo    OSET_LINE_CUST.LINE_SEQ_NO%TYPE;
    v_nMaxWeight    ODATA_SEND_AREA_CALCULATE.MAX_WEIGHT%TYPE;
    v_nMaxVolume    ODATA_SEND_AREA_CALCULATE.MAX_VOLUME%TYPE;
    v_nMaxCase      ODATA_SEND_AREA_CALCULATE.MAX_CASE%TYPE;

    --hb 20160622
    v_ComputeStrategyId   wms_outorder.COMPUTE_STRATEGY_ID%type;--试算策略
    v_LocateStrategyId    wms_outorder.LOCATE_STRATEGY_ID%type;--分配策略
    v_SendbufComputeFlag  wms_compute_strategy_d.SENDBUF_COMPUTE_FLAG%type;--月台资源试算 0-不试算；1-试算
    v_SendbufComputeLevel wms_compute_strategy_d.SENDBUF_COMPUTE_LEVEL%type;--月台资源试算级别
    v_SendbufComputeValue wms_compute_strategy_d.SENDBUF_COMPUTE_VALUE%type;--月台资源试算值
    v_DeliverObjLevel     wms_outlocate_strategy_d.DELIVER_OBJ_LEVEL%type;--配送对象级别0-按客户,1-按单据,2-按实体客户

  BEGIN
    strResult := 'N|[P_DeliverArea_Cal_Tmp]';
    v_nCount  := 0;
    v_strSql  := null;
    --删掉所有试算结果
    if strRetryFlag = '1' then
      delete from odata_temp_send_area_calculate a
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWareHouseNo
         and a.tmp_id = strTmpID;
      if strDelFlag = '1' then
        strResult := 'Y|';
        return;
      end if;
    end if;

    --获取试算策略 hb 20160622
    PKLG_WMS_Public.p_OM_GetOutOrder(strEnterpriseNo,strWareHouseNo,strOwnerNo,strExpType,'COMPUTE_STRATEGY_ID',v_ComputeStrategyId,strResult);
    if instr(strResult, 'N', 1, 1) = 1 then
      return;
    end if;

    --获取分配策略 hb 20160622
    PKLG_WMS_Public.p_OM_GetOutOrder(strEnterpriseNo,strWareHouseNo,strOwnerNo,strExpType,'LOCATE_STRATEGY_ID',v_LocateStrategyId,strResult);
    if instr(strResult, 'N', 1, 1) = 1 then
      return;
    end if;

    --获取月台试算策略信息 hb 20160622
    begin
      select SENDBUF_COMPUTE_FLAG, SENDBUF_COMPUTE_LEVEL, SENDBUF_COMPUTE_VALUE
        into v_SendbufComputeFlag, v_SendbufComputeLevel, v_SendbufComputeValue
        from wms_compute_strategy_d
       where enterprise_no = strEnterpriseNo and compute_strategy_id = v_ComputeStrategyId;
    exception
      when no_data_found then
        strResult := 'N|[获取月台试算策略信息失败]';
        return;
    end;

    --获取配送对象级别 hb 20160622
    begin
      select DELIVER_OBJ_LEVEL
        into v_DeliverObjLevel
        from wms_outlocate_strategy_d
       where enterprise_no = strEnterpriseNo and locate_strategy_id = v_LocateStrategyId
         and rownum = 1;
    exception
      when no_data_found then
        strResult := 'N|[获取配送对象级别失败]';
        return;
    end;

    --系统否认的界面不能肯定,系统肯定的界面可以否认 hb 20160622
    --不进行暂存区资源试算，直接返回
    if (v_SendbufComputeFlag = '0'
        or (v_SendbufComputeFlag = '1' and strSendBufFlag = '0')) then
      strResult := 'Y|';
      return;
    end if;

    --不进行暂存区资源试算，直接返回
    /*if strSendBufFlag = '0' then
      strResult := 'Y|';
      return;
    end if;*/

    --获取配送对象
    if v_DeliverObjLevel = '0' then
      v_strDeliverObjSql := 'm.cust_no ';
      --重整不获取配送对象
      if strRetryFlag = '0' then
        select distinct cust_no
          into v_strDeliverObj
          from odata_exp_m
         where (exp_no = strExpNo or cust_no = strCustNo)
           and enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and owner_no = strOwnerNo;
        --删除当前配送对象的临时暂存区试算结果
        delete from odata_temp_send_area_calculate a
         where a.enterprise_no = strEnterpriseNo
           and a.warehouse_no = strWareHouseNo
           and a.deliver_obj = v_strDeliverObj
           and a.tmp_id = strTmpID;
      end if;
    elsif v_DeliverObjLevel = '1' then
      v_strDeliverObjSql := 'm.sourceexp_no';
    elsif v_DeliverObjLevel = '2' then
      strResult := 'N|[按实体客户为配送对象未实现！]';
      return;
    else
      strResult := 'N|[配送对象配置参数 DELIVER_OBJ_LEVEL 设置有误，请检查！]';
      return;
    end if;
    --删单处理
    if strDelFlag = '1' then
      --配送对象是客户，直接判断该客户是否需要重新试算
      if v_DeliverObjLevel = '0' then
        --判断条件odata_tmp_locate_select无改客户的订单则不试算，有则试算
        select count(1)
          into v_nCount
          from odata_tmp_locate_select t, odata_exp_m m
         where t.enterprise_no = m.enterprise_no
           and t.warehouse_no = m.warehouse_no
           and t.owner_no = m.owner_no
           and t.exp_no = m.exp_no
           and t.tmp_id = strTmpID
           and (m.exp_no = strExpNo or m.cust_no = strCustNo)
           and t.enterprise_no = strEnterpriseNo
           and t.warehouse_no = strWareHouseNo
           and t.owner_no = strOwnerNo;
        if v_nCount = 0 then
          strResult := 'Y|';
          return;
        end if;
      end if;
      --配送对象是订单，直接删除odata_temp_send_area_calculate 直接返回
      if v_DeliverObjLevel = '1' then
        delete from odata_temp_send_area_calculate t
         where t.tmp_id = strTmpID
           and t.enterprise_no = strEnterpriseNo
           and t.warehouse_no = strWareHouseNo
           and exists
         (select 1
                  from odata_exp_m m
                 where t.enterprise_no = m.enterprise_no
                   and t.warehouse_no = m.warehouse_no
                   and m.owner_no = strOwnerNo
                   and t.deliver_obj = m.sourceexp_no
                   and (m.exp_no = strExpNo or m.cust_no = strCustNo));
        strResult := 'Y|';
        return;
      end if;
    end if;
    --根据配送对象配置，获取对应的订单信息
    --？？？？？？？是否使用包装表最大包装换算箱数
    v_strSql := 'select nvl(olc.line_no,''N'') line_no,' ||
                v_strDeliverObjSql ||
                ' as deliver_obj, nvl(olc.LINE_SEQ_NO,0) LINE_SEQ_NO,' ||
                'sum(d.article_qty * a.unit_volumn) SumVolumn, sum(d.article_qty * a.unit_weight) SumWeight,' ||
                'sum(round(d.article_qty / nvl((select max(bap.packing_qty) from bdef_article_packing bap' ||
                ' where bap.article_no = d.article_no  and bap.enterprise_no = d.enterprise_no),  d.packing_qty), 3)) SumBox ' ||
                '/*,sum(d.article_qty) sumQty*/' ||
                ' from odata_tmp_locate_select t,odata_exp_m m, odata_exp_d d, bdef_defarticle a,oset_line_cust olc' ||
                ' where t.enterprise_no = d.enterprise_no and t.warehouse_no = d.warehouse_no and t.owner_no = d.owner_no and t.exp_no = d.exp_no' ||
                ' and m.enterprise_no = d.enterprise_no and m.warehouse_no = d.warehouse_no and m.owner_no = d.owner_no and m.exp_no = d.exp_no' ||
                ' and d.enterprise_no = a.enterprise_no and d.owner_no = a.owner_no and d.article_no = a.article_no ' ||
                ' and m.enterprise_no = olc.enterprise_no(+) and m.warehouse_no = olc.warehouse_no(+) and m.cust_no = olc.cust_no(+) ' ||
                ' and t.enterprise_no = ''' || strEnterpriseNo ||
                ''' and t.warehouse_no =''' || strWareHouseNo ||
                ''' and t.owner_no = ''' || strOwnerNo ||
                ''' and t.tmp_id = ''' || strTmpID || '''';
    --重整则全部勾选的数据都需要试算
    if strRetryFlag = '0' then
      v_strSql := v_strSql || ' and (m.cust_no = ''' || strCustNo ||
                  ''' or m.exp_no = ''' || strExpNo || ''') ';
    end if;
    v_strSql := v_strSql ||
                'group by nvl(olc.line_no,''N''),nvl(olc.LINE_SEQ_NO,0),' ||
                v_strDeliverObjSql ||
                ' order by nvl(olc.line_no,''N''),nvl(olc.LINE_SEQ_NO,0) desc,' ||
                v_strDeliverObjSql;
    open v_GetExpInfo for v_strSql;
    --根据配送对象，循环分配暂存区资源
    loop
      fetch v_GetExpInfo
        into v_strLinNo,
             v_strDeliverObj,
             v_nLineSeqNo,
             v_nMaxVolume,
             v_nMaxWeight,
             v_nMaxCase;
      exit when v_GetExpInfo%notfound;
      --计算暂存区资源P_Locate_SendArea
      P_Locate_SendArea(strEnterpriseNo,
                        strWareHouseNo,
                        --strSendBufLv,
                        v_SendbufComputeLevel,
                        --strSendBufVal,
                        v_SendbufComputeValue,
                        strTmpID,
                        v_strLinNo,
                        v_strDeliverObj,
                        v_nMaxWeight,
                        v_nMaxVolume,
                        v_nMaxCase,
                        strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;
    end loop;
    close v_GetExpInfo;
    strResult := 'Y|';
  EXCEPTION
    WHEN OTHERS THEN
      strResult := 'N|' || v_strSql || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  END P_DeliverArea_Cal_Tmp;
  /**************************************************************************************************/
  /*
   功能说明：定位发货暂存区资源试算。
   创建人：wyf
   创建时间：2016.2.25
  */
  /**************************************************************************************************/
  procedure P_DeliverArea_Cal(strEnterpriseNo in varchar2, --企业
                              strWareHouseNo  in varchar2, --仓库代码
                              strWaveNo       in odata_locate_batch.wave_no%type, --波次号
                              strBatchNo      in odata_locate_batch.batch_no%type, --作业批次号
                              strResult       out varchar2) IS

    v_strOwnerNo     odata_locate_m.owner_no%type;
    v_strExpType     odata_locate_m.exp_type%type;
    v_strSendBufFlag ODATA_LOCATE_BATCH.SENDBUF_COMPUTE_FLAG%TYPE; --
    v_strSendBufLv   ODATA_LOCATE_BATCH.SENDBUF_COMPUTE_LEVEL%TYPE; --
    v_strSendBufVal  ODATA_LOCATE_BATCH.SENDBUF_COMPUTE_VALUE%TYPE; --

    v_strTmpID odata_tmp_locate_select.tmp_id%type;

    v_strSql varchar2(2500);

    TYPE ref_cursor_type IS REF CURSOR;
    v_GetExpInfo ref_cursor_type;

    v_strLinNo      ODATA_TMP_LOCATE_SELECT.LINE_NO%TYPE;
    v_strDeliverObj ODATA_LOCATE_D.DELIVER_OBJ%TYPE;
    v_nLineSeqNo    OSET_LINE_CUST.LINE_SEQ_NO%TYPE;
    v_nUseWeight    ODATA_SEND_AREA_CALCULATE.USE_WEIGHT%TYPE;
    v_nUseVolume    ODATA_SEND_AREA_CALCULATE.USE_VOLUMN%TYPE;
    v_nUseBoxNum    ODATA_SEND_AREA_CALCULATE.USE_BOXNUM%TYPE;
  BEGIN
    strResult := 'N|[P_DeliverArea_Cal]';

    --锁发货暂存区储位资源
    update cdef_defcell t
       set t.cell_status = t.cell_status
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWareHouseNo
       and exists (select 1
              from cdef_defarea a
             where t.enterprise_no = a.enterprise_no
               and t.warehouse_no = a.warehouse_no
               and t.ware_no = a.ware_no
               and t.area_no = a.area_no
               and a.area_attribute = '1'
               and a.attribute_type in ('2', '5'));

    --获取批次试算规格
    begin
      select exp_type,
             owner_no,
             sendbuf_compute_flag,
             sendbuf_compute_level,
             sendbuf_compute_value
        into v_strExpType,
             v_strOwnerNo,
             v_strSendBufFlag,
             v_strSendBufLv,
             v_strSendBufVal
        from odata_locate_batch
       where enterprise_no = strEnterpriseNo
         and warehouse_no = strWareHouseNo
         and wave_no = strWaveNo
         and batch_no = strBatchNo;
    exception
      when no_data_found then
        strResult := 'N|[找不到对应的波次信息]';
        return;
    end;

    if v_strSendBufFlag = '0' THEN
      strResult := 'Y|';
      return;
    end if;

    select SEQ_ODATA_BUFFER_CAL_TMPID.NEXTVAL into v_strTmpID from dual;

    --读取订单材积信息
    v_strSql := 'select nvl(olc.line_no,''N'') line_no,t.deliver_obj,nvl(olc.LINE_SEQ_NO,0) LINE_SEQ_NO, ' ||
                'sum(t.locate_qty * a.unit_volumn) SumVolumn, sum(t.locate_qty * a.unit_weight) SumWeight,' ||
                'sum(round(t.locate_qty / nvl((select max(bap.packing_qty) from bdef_article_packing bap ' ||
                ' where bap.article_no = t.article_no  and bap.enterprise_no = t.enterprise_no),  t.packing_qty), 3)) SumBox ' ||
                '/*,sum(t.article_qty) sumQty*/' ||
                ' from odata_outstock_direct t,odata_exp_m m, bdef_defarticle a,oset_line_cust olc ' ||
                ' where m.enterprise_no = t.enterprise_no and m.warehouse_no = t.warehouse_no and m.owner_no = t.owner_no and m.exp_no = t.exp_no ' ||
                ' and t.enterprise_no = a.enterprise_no and t.owner_no = a.owner_no and t.article_no = a.article_no ' ||
                ' and m.enterprise_no = olc.enterprise_no(+) and m.warehouse_no = olc.warehouse_no(+) and m.cust_no = olc.cust_no(+) ' ||
                ' and t.enterprise_no = ''' || strEnterpriseNo ||
                ''' and t.warehouse_no =''' || strWareHouseNo ||
                ''' and t.owner_no = ''' || v_strOwnerNo ||
                ''' and t.wave_no = ''' || strWaveNo ||
                ''' group by nvl(olc.line_no,''N''),t.deliver_obj,nvl(olc.LINE_SEQ_NO,0) ' ||
                ' order by nvl(olc.line_no,''N''),nvl(olc.LINE_SEQ_NO,0) desc,t.deliver_obj';
    open v_GetExpInfo for v_strSql;
    --根据配送对象，循环分配暂存区资源
    loop
      fetch v_GetExpInfo
        into v_strLinNo,
             v_strDeliverObj,
             v_nLineSeqNo,
             v_nUseVolume,
             v_nUseWeight,
             v_nUseBoxNum;
      exit when v_GetExpInfo%notfound;
      --计算暂存区资源P_Locate_SendArea
      P_Locate_SendArea(strEnterpriseNo,
                        strWareHouseNo,
                        v_strSendBufLv,
                        v_strSendBufVal,
                        v_strTmpID,
                        v_strLinNo,
                        v_strDeliverObj,
                        v_nUseWeight,
                        v_nUseVolume,
                        v_nUseBoxNum,
                        strResult);

      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;

      --更新出货月台信息
      P_SetOutStoctk_SendArea(strEnterpriseNo,
                              strWareHouseNo,
                              v_strOwnerNo,
                              strWaveNo,
                              v_strTmpID,
                              strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;
      --月台试算复制临时表到正式表
      P_Ins_DeliverArea_Cal(strEnterpriseNo,
                            strWareHouseNo,
                            v_strTmpID,
                            strWaveNo,
                            strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;
      --删除临时表
      P_Del_DeliverArea_Cal_Tmp(strEnterpriseNo,
                                strWareHouseNo,
                                v_strTmpID,
                                null,
                                strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;
    end loop;
    close v_GetExpInfo;

    strResult := 'Y|';
  EXCEPTION
    WHEN OTHERS THEN
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  END P_DeliverArea_Cal;
  /**************************************************************************************************/
  /*
   功能说明：按配送对象计算暂存区资源。试算写临时表
   创建人：wyf
   创建时间：2016.2.25
  */
  /**************************************************************************************************/
  procedure P_Locate_SendArea(strEnterpriseNo in varchar2, --企业
                              strWareHouseNo  in varchar2, --仓库代码
                              strSendBufLv    in ODATA_LOCATE_BATCH.SENDBUF_COMPUTE_LEVEL%TYPE,
                              SendBufCompute  in ODATA_LOCATE_BATCH.SENDBUF_COMPUTE_VALUE%type,
                              strTmpID        in ODATA_SEND_AREA_CALCULATE.TMP_ID%TYPE,
                              strLineNo       in ODATA_SEND_AREA_CALCULATE.LINE_NO%TYPE,
                              strDeliverObj   in ODATA_LOCATE_D.DELIVER_OBJ%TYPE,
                              nUseWeight      in ODATA_SEND_AREA_CALCULATE.USE_WEIGHT%TYPE,
                              nUseVolume      in ODATA_SEND_AREA_CALCULATE.USE_VOLUMN%TYPE,
                              nUseBoxNum      in ODATA_SEND_AREA_CALCULATE.USE_BOXNUM%TYPE,
                              strResult       out varchar2) IS
    v_RealSum number;

    TYPE ref_cursor_type IS REF CURSOR;
    v_GetBufInfo ref_cursor_type;
    v_strSql     varchar2(2500);

    v_strWareNo  cdef_defcell.ware_no%type;
    v_strAreaNo  cdef_defcell.area_no%type;
    v_strStockNo cdef_defcell.stock_no%type;
    v_UseFlag    varchar(10);
    v_strCellNo  cdef_defcell.cell_no%type;
    v_nMaxQty    odata_temp_send_area_calculate.max_qty%type;
    v_nMaxWeight odata_temp_send_area_calculate.max_weight%type;
    v_nMaxVolume odata_temp_send_area_calculate.max_volume%type;
    v_nMaxCase   odata_temp_send_area_calculate.max_case%type;

    v_strTmpWareNo  cdef_defcell.ware_no%type;
    v_strTmpAreaNo  cdef_defcell.area_no%type;
    v_strTmpStockNo cdef_defcell.stock_no%type;
    v_nRowID        number; --连续空暂存区块序号
    v_nContinueNum  number; --连续空暂存区储位序号

    v_nCount        integer;
    v_strRealCellNo cdef_defcell.cell_no%type;
    v_blFind        boolean;
  BEGIN
    strResult := 'N|[P_Locate_SendArea]';
    if strSendBufLv = '1' then
      --精细管理
      if SendBufCompute = '1' then
        --按体积试算
        v_RealSum := nUseVolume;
      elsif SendBufCompute = '2' then
        --按重量试算
        v_RealSum := nUseWeight;
      elsif SendBufCompute = '3' then
        --按包装系数试算
        v_RealSum := nUseBoxNum;
      else
        strResult := 'N|[暂存区资源试算参数设置有误，超出参数设置范围！]';
        return;
      end if;
    else
      --粗放管理
      v_RealSum := 1;
    end if;
    --获取可用的暂存区资源信息
    v_strSql := 'SELECT c.ware_no, c.area_no, c.stock_no,' ||
                'case when ((c.cell_no in (select temp_a.cell_no from ODATA_SEND_AREA_CALCULATE temp_a '||
                'where temp_a.enterprise_no = c.enterprise_no and temp_a.warehouse_no = c.warehouse_no)) or ' ||
                '(c.cell_no in (select temp_b.cell_no from ODATA_SEND_AREA_CALCULATE temp_b where temp_b.tmp_id = ''' ||
                strTmpID || ''' and temp_b.enterprise_no = c.enterprise_no and temp_b.warehouse_no = c.warehouse_no))) then 1  else  0 end used_flag,' ||
                'c.cell_no, c.max_qty, c.max_weight, c.max_case, c.max_volume ' ||
                ' FROM cdef_defcell c, cdef_defarea a, OSET_BUFFER T ' ||
                ' where T.warehouse_no = c.warehouse_no and T.ware_no = c.ware_no and T.area_no = c.area_no ' ||
                ' and T.stock_no = c.stock_no and T.enterprise_no = c.enterprise_no ' ||
                ' and T.cell_no = (case when T.cell_no = ''N'' then  ''N'' else c.cell_no end) ' ||
                ' and T.warehouse_no =''' || strWareHouseNo ||
                ''' and T.enterprise_no = ''' || strEnterpriseNo ||
                ''' and T.status = ''0'' and a.enterprise_no = c.enterprise_no and a.warehouse_no = c.warehouse_no ' ||
                ' and a.area_attribute = ''1'' and a.attribute_type in (''2'', ''5'') and c.cell_status = ''0'' and a.ware_no = c.ware_no ' ||
                ' and a.area_no = c.area_no ' ||
                ' order by c.warehouse_no, c.ware_no, c.area_no, c.stock_no, c.cell_no';

    /*' and not exists (select 1 from ODATA_TEMP_SEND_AREA_CALCULATE tmp where tmp.enterprise_no=T.enterprise_no and tmp.warehouse_no = T.warehouse_no
      and tmp.ware_no = T.ware_no and tmp.area_no = T.area_no and tmp.stock_no = T.stock_no and tmp.cell_no = T.cell_no)' ||
    ' and not exists (select 1 from ODATA_SEND_AREA_CALCULATE tmp where tmp.enterprise_no=T.enterprise_no and tmp.warehouse_no = T.warehouse_no
      and tmp.ware_no = T.ware_no and tmp.area_no = T.area_no and tmp.stock_no = T.stock_no and tmp.cell_no = T.cell_no)' ||*/

    v_strTmpWareNo  := '*';
    v_strTmpAreaNo  := '*';
    v_strTmpStockNo := '*';

    v_nRowID       := 0;
    v_nContinueNum := 0;

    open v_GetBufInfo for v_strSql;
    loop
      fetch v_GetBufInfo
        into v_strWareNo,
             v_strAreaNo,
             v_strStockNo,
             v_UseFlag,
             v_strCellNo,
             v_nMaxQty,
             v_nMaxWeight,
             v_nMaxCase,
             v_nMaxVolume;
      exit when v_GetBufInfo%notfound;

      --收集有连续储位的通道
      select count(1) into v_nCount from odata_temp_EmptyBuf1;
      --换通道
      if v_strTmpWareNo <> v_strWareNo or v_strTmpAreaNo <> v_strAreaNo or
         v_strTmpStockNo <> v_strStockNo then
        if (v_nCount > 0) then
          --新增空暂存区资源临时表
          P_Ins_temp_EmptyBuf(v_nContinueNum, v_nRowID);
        end if;

        v_nRowID        := v_nRowID + 1;
        v_strTmpWareNo  := v_strWareNo;
        v_strTmpAreaNo  := v_strAreaNo;
        v_strTmpStockNo := v_strStockNo;
      end if;

      --已占用且有做限制
      if v_UseFlag = '1' and
         ((strSendBufLv = '1' and
         (SendBufCompute = '1' and v_nMaxVolume > 0) or
         (SendBufCompute = '2' and v_nMaxWeight > 0) or
         (SendBufCompute = '3' and v_nMaxCase > 0)) or strSendBufLv = '0') then
        if v_nCount > 0 then
          --新增空暂存区资源临时表
          P_Ins_temp_EmptyBuf(v_nContinueNum, v_nRowID);
        end if;
        goto NextOne;
      end if;
      --添加空暂存区临时表1
      select count(1) into v_nCount from odata_temp_EmptyBuf1;
      if v_nCount = 0 then
        insert into odata_temp_EmptyBuf1
          (Cell_No, Max_Volume, Max_Weight, Max_Case)
        values
          (v_strCellNo, v_nMaxVolume, v_nMaxWeight, v_nMaxCase);
        v_nContinueNum := 0;
      end if;
      v_nContinueNum := v_nContinueNum + 1;
      <<NextOne>>
      null;
    end loop;
    close v_GetBufInfo;
    select count(1) into v_nCount from odata_temp_EmptyBuf1;
    if v_nCount > 0 then
      --新增空暂存区资源临时表
      P_Ins_temp_EmptyBuf(v_nContinueNum, v_nRowID);
    end if;
    --是否已计算出连续的暂存区资源
    select count(*) into v_nCount from odata_temp_EmptyBuf;
    if v_nCount = 0 then
      strResult := 'N|配送对象[' || strDeliverObj ||
                   ']已无连续的空暂存区资源，请等待出货暂存区清理后再做调度！';
      return;
    end if;

    --判断连续储位是否能满足
    v_nContinueNum  := 0;
    v_strRealCellNo := null;
    for p in (select * from odata_temp_EmptyBuf order by Row_Id, Empty_Num) loop
      if v_nContinueNum = 0 then
        if strSendBufLv = '1' then
          --精细管理
          if SendBufCompute = '1' then
            --按体积试算
            if p.max_volume = 0 then
              v_nContinueNum := 1;
            else
              v_nContinueNum := ceil(v_RealSum / p.max_volume);
            end if;
          elsif SendBufCompute = '2' then
            --按重量试算
            if p.max_weight = 0 then
              v_nContinueNum := 1;
            else
              v_nContinueNum := ceil(v_RealSum / p.max_weight);
            end if;
          elsif SendBufCompute = '3' then
            --按包装系数试算
            if p.max_case = 0 then
              v_nContinueNum := 1;
            else
              v_nContinueNum := ceil(v_RealSum / p.max_case);
            end if;
          end if;
        else
          --粗放管理
          v_nContinueNum := 1;
        end if;
      end if;

      if p.empty_num >= v_nContinueNum then
        v_strRealCellNo := p.cell_no;
        goto break;
      end if;
      --分配到无限制的暂存区储位
      if (SendBufCompute = '1' and p.max_volume = 0) or
         (SendBufCompute = '2' and p.max_weight = 0) or
         (SendBufCompute = '3' and p.max_case = 0) then
        v_nContinueNum  := 1;
        v_strRealCellNo := p.cell_no;
        goto break;
      end if;
    end loop;
    <<break>>
    null;
    --找暂存区储位
    if v_strRealCellNo is not null then
      v_blFind := false;
      open v_GetBufInfo for v_strSql;
      loop
        fetch v_GetBufInfo
          into v_strWareNo,
               v_strAreaNo,
               v_strStockNo,
               v_UseFlag,
               v_strCellNo,
               v_nMaxQty,
               v_nMaxWeight,
               v_nMaxCase,
               v_nMaxVolume;
        exit when v_GetBufInfo%notfound;
        if v_strCellNo <> v_strRealCellNo and v_blFind = false then
          goto NextCell;
        end if;
        v_blFind := true;
        --写暂存区资源占用临时表P_Ins_DeliverArea_Cal_Tmp
        P_Ins_DeliverArea_Cal_Tmp(strEnterpriseNo,
                                  strWareHouseNo,
                                  strTmpID,
                                  v_strWareNo,
                                  v_strAreaNo,
                                  v_strStockNo,
                                  v_strCellNo,
                                  0,
                                  0,
                                  0,
                                  0,
                                  '0',
                                  strLineNo,
                                  nUseVolume,
                                  nUseWeight,
                                  nUseBoxNum,
                                  strDeliverObj,
                                  strResult);
        if substr(strResult, 1, 1) <> 'Y' then
          return;
        end if;
        v_nContinueNum := v_nContinueNum - 1;

        if (v_nContinueNum <= 0) then
          goto outloop;
        end if;
        <<NextCell>>
        null;
      end loop;
      <<outloop>>
      null;
      close v_GetBufInfo;
    else
      strResult := 'N|[配送对象[' || strDeliverObj || ']连续暂存区资源不够！]';
      return;
    end if;
    --删除空暂存区列表
    delete from odata_temp_EmptyBuf;
    strResult := 'Y|';
  EXCEPTION
    WHEN OTHERS THEN
      strResult := 'N|' || v_strSql || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  END P_Locate_SendArea;
  /**************************************************************************************************/
  /*
   功能说明：新增空暂存区资源临时表
   创建人：wyf
   创建时间：2016.3.2
  */
  /**************************************************************************************************/
  procedure P_Ins_temp_EmptyBuf(nContinueNum in odata_temp_EmptyBuf.Empty_Num%type, --连续空暂存区储位序号
                                nRowID       in odata_temp_EmptyBuf.Row_Id%type) --连续空暂存区块序号
   IS
  BEGIN
    insert into odata_temp_EmptyBuf
      (Cell_No, Max_Volume, Max_Weight, Max_Case, Empty_Num, Row_Id)
      select Cell_No,
             Max_Volume,
             Max_Weight,
             Max_Case,
             nContinueNum,
             nRowID
        from odata_temp_EmptyBuf1;
    delete from odata_temp_EmptyBuf1;
  END P_Ins_temp_EmptyBuf;
  /**************************************************************************************************/
  /*
   功能说明：新增暂存区资源试算临时表
   创建人：wyf
   创建时间：2016.2.29
  */
  /**************************************************************************************************/
  procedure P_Ins_DeliverArea_Cal_Tmp(strEnterpriseNo in varchar2, --企业
                                      strWareHouseNo  in varchar2, --仓库代码
                                      strTmpID        in odata_tmp_locate_select.tmp_id%type,
                                      strWareNo       in cdef_defcell.ware_no%type,
                                      strAreaNo       in cdef_defcell.area_no%type,
                                      strStockNo      in cdef_defcell.stock_no%type,
                                      strCellNo       in cdef_defcell.cell_no%type,
                                      nMaxQty         in odata_temp_send_area_calculate.max_qty%type,
                                      nMaxWeight      in odata_temp_send_area_calculate.max_weight%type,
                                      nMaxVolume      in odata_temp_send_area_calculate.max_volume%type,
                                      nMaxCase        in odata_temp_send_area_calculate.max_case%type,
                                      strCellStatus   in odata_temp_send_area_calculate.cell_status%type,
                                      strLineNo       in odata_temp_send_area_calculate.line_no%type,
                                      nUseVolumn      in odata_temp_send_area_calculate.use_volumn%type,
                                      nUseWeight      in odata_temp_send_area_calculate.use_weight%type,
                                      nUseBoxNum      in odata_temp_send_area_calculate.use_boxnum%type,
                                      strDeliverObj   in odata_temp_send_area_calculate.deliver_obj%type,
                                      strResult       out varchar2) IS
  BEGIN
    strResult := 'N|[P_Ins_DeliverArea_Cal_Tmp]';
    insert into odata_temp_send_area_calculate
      (enterprise_no,
       warehouse_no,
       tmp_id,
       ware_no,
       area_no,
       stock_no,
       cell_no,
       max_qty,
       max_weight,
       max_volume,
       max_case,
       cell_status,
       line_no,
       status,
       use_volumn,
       use_weight,
       use_boxnum,
       deliver_obj)
    values
      (strEnterpriseNo,
       strWareHouseNo,
       strTmpID,
       strWareNo,
       strAreaNo,
       strStockNo,
       strCellNo,
       nMaxQty,
       nMaxWeight,
       nMaxVolume,
       nMaxCase,
       strCellStatus,
       strLineNo,
       '1',
       nUseVolumn,
       nUseWeight,
       nUseBoxNum,
       strDeliverObj);
    strResult := 'Y|';
  EXCEPTION
    WHEN OTHERS THEN
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  END P_Ins_DeliverArea_Cal_Tmp;
  /**************************************************************************************************/
  /*
   功能说明：删除暂存区资源试算临时表
   创建人：wyf
   创建时间：2016.2.29
  */
  /**************************************************************************************************/
  procedure P_Del_DeliverArea_Cal_Tmp(strEnterpriseNo in varchar2, --企业
                                      strWareHouseNo  in varchar2, --仓库代码
                                      strTmpID        in odata_tmp_locate_select.tmp_id%type,
                                      strDeliverObj   in odata_locate_d.deliver_obj%type,
                                      strResult       out varchar2) IS
  BEGIN
    strResult := 'N|[P_Del_DeliverArea_Cal_Tmp]';
    delete from odata_temp_send_area_calculate t
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWareHouseNo
       and t.tmp_id = strTmpID
       and (t.deliver_obj = strDeliverObj or strDeliverObj is null);
    strResult := 'Y|';
  EXCEPTION
    WHEN OTHERS THEN
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  END P_Del_DeliverArea_Cal_Tmp;

  /**************************************************************************************************/
  /*
   功能说明：修出货下架指示DELIVER_AREA
   创建人：wyf
   创建时间：2016.2.29
  */
  /**************************************************************************************************/
  procedure P_SetOutStoctk_SendArea(strEnterpriseNo in varchar2, --企业
                                    strWareHouseNo  in varchar2, --仓库代码
                                    strOwnerNo      in odata_outstock_direct.owner_no%type,
                                    strWaveNo       in odata_outstock_direct.wave_no%type,
                                    strTmpID        in odata_tmp_locate_select.tmp_id%type,
                                    strResult       out varchar2) IS
    v_strBeginCellNo ODATA_TEMP_SEND_AREA_CALCULATE.CELL_NO%TYPE;
    v_strBeginBuf    ODATA_OUTSTOCK_DIRECT.DELIVER_AREA%TYPE;
    v_strEndCellNo   ODATA_TEMP_SEND_AREA_CALCULATE.CELL_NO%TYPE;
    v_strEndBuf      ODATA_OUTSTOCK_DIRECT.DELIVER_AREA%TYPE;

    v_DeliverArea ODATA_OUTSTOCK_DIRECT.DELIVER_AREA%TYPE;
  BEGIN
    strResult := 'N|[P_SetOutStoctk_SendArea]';
    for p in (select distinct deliver_obj
                from ODATA_TEMP_SEND_AREA_CALCULATE t
               where t.tmp_id = strTmpID
                 and t.enterprise_no = strEnterpriseNo
                 and t.warehouse_no = strWareHouseNo
               order by deliver_obj) loop
      --取最小储位 为起始区域
      select min(cell_no)
        into v_strBeginCellNo
        from ODATA_TEMP_SEND_AREA_CALCULATE t
       where t.tmp_id = strTmpID
         and t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.deliver_obj = p.deliver_obj;
      --获取起始暂存区编码
      select a.buffer_name
        into v_strBeginBuf
        from oset_buffer a
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWareHouseNo
         and a.cell_no = v_strBeginCellNo;
      --取最大储位 为结束区域
      select max(cell_no)
        into v_strEndCellNo
        from ODATA_TEMP_SEND_AREA_CALCULATE t
       where t.tmp_id = strTmpID
         and t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.deliver_obj = p.deliver_obj;
      --获取结束暂存区编码
      select a.buffer_name
        into v_strEndBuf
        from oset_buffer a
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWareHouseNo
         and a.cell_no = v_strEndCellNo;
      if v_strBeginBuf = v_strEndBuf then
        v_DeliverArea := v_strBeginBuf;
      else
        v_DeliverArea := v_strBeginBuf || '-' || v_strEndBuf;
      end if;
      --写入下架指示发货暂存区信息
      update odata_outstock_direct a
         set a.deliver_area = v_DeliverArea
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWareHouseNo
         and a.owner_no = strOwnerNo
         and a.deliver_obj = p.deliver_obj
         and a.wave_no = strWaveNo;
    end loop;
    strResult := 'Y|';
  EXCEPTION
    WHEN OTHERS THEN
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  END P_SetOutStoctk_SendArea;
  /**************************************************************************************************/
  /*
   功能说明：新增暂存区资源试算表
   创建人：wyf
   创建时间：2016.2.29
  */
  /**************************************************************************************************/
  procedure P_Ins_DeliverArea_Cal(strEnterpriseNo in varchar2, --企业
                                  strWareHouseNo  in varchar2, --仓库代码
                                  strTmpID        in odata_tmp_locate_select.tmp_id%type,
                                  strWaveNo       in odata_outstock_direct.wave_no%type,
                                  strResult       out varchar2) IS
  BEGIN
    strResult := 'N|[P_Ins_DeliverArea_Cal]';
    insert into odata_send_area_calculate
      select t.*, strWaveNo
        from odata_temp_send_area_calculate t
       where t.tmp_id = strTmpID
         and t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo;
    strResult := 'Y|';
  EXCEPTION
    WHEN OTHERS THEN
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  END P_Ins_DeliverArea_Cal;

  /**************************************************************************************************/
  /*
   功能说明：释放暂存区资源
   创建人：wyf
   创建时间：2016.2.29
   获取批次以读取参数 huangb 20160726
  */
  /**************************************************************************************************/
  procedure P_Clear_DeliverArea_Cal(strEnterpriseNo in varchar2, --企业
                                    strWareHouseNo  in varchar2, --仓库代码
                                    strOwnerNo      in odata_outstock_direct.owner_no%type,
                                    strWaveNo       in odata_locate_batch.wave_no%type,
                                    --strBatchNo      in odata_locate_batch.batch_no%type,
                                    strDeliverObj   in odata_locate_d.deliver_obj%type,
                                    strExpType      in odata_locate_batch.exp_type%type,
                                    --strLabelNo in stock_label_m.label_no%type,
                                    --strDeliverArea  in odata_outstock_direct.deliver_area%type,
                                    strResult out varchar2) IS
    v_nDCount        integer;
    v_nLCount        integer;
    --v_strOwnerNo     odata_outstock_direct.owner_no%type;
    --v_strExpType     odata_locate_m.exp_type%type;
    v_SendBufCompute odata_locate_batch.sendbuf_compute_flag%type;
  BEGIN
    strResult := 'N|[P_Clear_DeliverArea_Cal]';


    --获取参数是否进行暂存区试算
    select t.sendbuf_compute_flag
      into v_SendBufCompute
      from odata_locate_batch t
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWareHouseNo
       and t.wave_no = strWaveNo
       and t.exp_type = strExpType and rownum=1;
    if v_SendBufCompute = '0' THEN
      strResult := 'Y|';
      return;
    end if;

    --是否有未发单的下架指示
    select count(1)
      into v_nDCount
      from odata_outstock_direct d
     where d.enterprise_no = strEnterpriseNo
       and d.warehouse_no = strWareHouseNo
       and d.owner_no = strOwnerNo
       and d.deliver_obj = strDeliverObj
       and d.wave_no = strWaveNo
       and d.status < '13';

    if v_nDCount = 0 then
      --是否存在未装车的标签
      select count(1)
        into v_nLCount
        from stock_label_d sld, stock_label_m slm
       where sld.enterprise_no = strEnterpriseNo
         and sld.warehouse_no = strWareHouseNo
         and sld.owner_no = strOwnerNo
         and sld.deliver_obj = strDeliverObj
         and sld.wave_no = strWaveNo
         and sld.enterprise_no = slm.enterprise_no
         and sld.warehouse_no = slm.warehouse_no
         and sld.container_no = slm.container_no;
      if v_nLCount = 0 then
        delete from odata_send_area_calculate t
         where t.enterprise_no = strEnterpriseNo
           and t.warehouse_no = strWareHouseNo
           and t.wave_no = strWaveNo
           and t.deliver_obj = strDeliverObj;
      end if;
    end if;
    strResult := 'Y|';
  EXCEPTION
    WHEN OTHERS THEN
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  END P_Clear_DeliverArea_Cal;
  /**************************************************************************************************/
/*
   功能说明：暂存区资源转移
   创建人：wyf
   创建时间：2016.2.29
  */
/**************************************************************************************************/
/*  procedure P_Move_DeliverArea(strEnterpriseNo in varchar2, --企业
                               strWareHouseNo  in varchar2, --仓库代码
                               strTmpID        in odata_tmp_locate_select.tmp_id%type,
                               strWaveNo       in odata_locate_d.wave_no%type,
                               strDeliverObj   in odata_locate_d.deliver_obj%type,
                               strResult       out varchar2) is
  BEGIN
    strResult := 'N|[P_Move_DeliverArea]';

    strResult := 'Y|';
  EXCEPTION
    WHEN OTHERS THEN
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  END P_Move_DeliverArea;
*/
END PKLG_BUFFER_CALCULATE;

/

