create view V_STOCK_CONTENT_MOVE as
select t.enterprise_no,t.warehouse_no,owner_no,dept_no,paper_type,
t.paper_no,t.terminal_flag,t.article_no,t.article_id,
t.cell_no,sum(t.first_qty) first_qty ,sum(t.first_instock_qty) first_instock_qty,
sum(t.first_outstock_qty) first_outstock_qty,t.io_flag,sum(t.move_qty) move_qty , t.r_cell_no,t.rgst_name,t.rgst_date
 from stock_content_move t
 group by t.enterprise_no,t.warehouse_no,owner_no,dept_no,paper_type,
t.paper_no,t.terminal_flag,t.article_no,t.article_id,
t.cell_no,t.io_flag, t.r_cell_no,t.rgst_name,t.rgst_date
order by t.enterprise_no,t.warehouse_no,owner_no,dept_no,t.rgst_date asc ,t.io_flag desc ,t.article_no,t.cell_no,paper_type,
t.paper_no,t.terminal_flag


/

