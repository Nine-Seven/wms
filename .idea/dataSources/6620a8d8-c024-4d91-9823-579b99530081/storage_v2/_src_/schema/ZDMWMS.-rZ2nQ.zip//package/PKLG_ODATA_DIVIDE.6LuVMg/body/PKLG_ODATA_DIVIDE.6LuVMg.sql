create package body        PKLG_ODATA_DIVIDE is

  /**********************************************************************************************8
  lich
  20140521
  功能说明：写分播单
  ***********************************************************************************************/
  procedure P_OutStock_Divide(strEnterPriseNo   in ODATA_DIVIDE_D.Enterprise_No%type, --企业号
                              strwarehouse_no   in ODATA_DIVIDE_D.warehouse_no%type, --仓别
                              strOWNER_NO       in ODATA_DIVIDE_D.OWNER_NO%type, --委托业主
                              strDockNo         in bdef_defdock.dock_no%type, --码头
                              strSource_No      in odata_divide_direct.source_no%type, --来源单号
                              strS_CONTAINER_NO in odata_divide_direct.S_CONTAINER_NO%type, --来源容器
                              strAssign_No      in odata_divide_d.assign_name%type, --预定分播人员
                              strUserID         in bdef_defworker.worker_no%type, --系统操作人员
                              strPrint_Flag     in varchar, --是否打印
                              strOutMsg         out varchar2) --返回值
   IS
    intCount      integer := 0;
    v_DivideNo    ODATA_DIVIDE_D.Divide_No%type;
    v_PrintTaskNo job_printtask_m.task_no%type;

  BEGIN
    strOutMsg := 'N|[P_OutStock_Divide]';
    for curDivideDirect in (select d.*,olb.owner_no real_owner_no
                              from odata_divide_direct d,odata_locate_batch olb
                             where d.WAREHOUSE_NO = strwarehouse_no
                               and d.enterprise_no = strEnterPriseNo
                               --and d.OWNER_NO = strOWNER_NO
                               and d.SOURCE_NO = strSource_No
                               and (strS_CONTAINER_NO = 'N' or
                                   d.s_container_no = strS_CONTAINER_NO)
                               and d.status = 10
                                 and olb.enterprise_no=d.enterprise_no
                               and olb.warehouse_no=d.warehouse_no
                               and olb.wave_no=d.wave_no
                               and olb.batch_no=d.batch_no
                               for update) loop
      intCount := intCount + 1;

      if intCount = 1 then

        --写分播单头档
        PKOBJ_ODATA_DIVIDE.P_Insert_Odata_Divide_M(strEnterPriseNo,
                                                   strwarehouse_no,
                                                   curDivideDirect.Real_Owner_No,
                                                   trunc(sysdate),
                                                   'C',
                                                   curDivideDirect.source_type,
                                                   curDivideDirect.Wave_No,
                                                   curDivideDirect.Batch_No,
                                                   --Modify BY QZH AT 2016-7-23 表示未分配分播设备
                                                   'N', --curDivideDirect.device_no,
                                                   curDivideDirect.Exp_Date,
                                                   strUserID,
                                                   v_DivideNo,
                                                   strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;

        if strPrint_Flag = '1' then
          --写打印任务
          PKLG_WMS_BASE.p_getsheetno(strEnterPriseNo,
                                     strwarehouse_no,
                                     CONST_DOCUMENTTYPE.PRINTPT,
                                     v_PrintTaskNo,
                                     strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;

          PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterPriseNo,
                                              strwarehouse_no,
                                              v_DivideNo,
                                              '0',
                                              const_reportid.OmDivideReport,
                                              strDockNo,
                                              '0',
                                              strUserID,
                                              v_PrintTaskNo,
                                              strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        end if;

      end if;

      --写分播单明细
      PKOBJ_ODATA_DIVIDE.P_Insert_Odata_Divide_D(strEnterPriseNo,
                                                 strwarehouse_no,
                                                 curDivideDirect.Owner_No,
                                                 curDivideDirect.Batch_No,
                                                 v_DivideNo,
                                                 curDivideDirect.Source_No,
                                                 curDivideDirect.Divide_Id,
                                                 curDivideDirect.Operate_Date,
                                                 curDivideDirect.Cust_No,
                                                 curDivideDirect.Sub_Cust_No,
                                                 curDivideDirect.Exp_Type,
                                                 curDivideDirect.Exp_No,
                                                 curDivideDirect.Wave_No,
                                                 curDivideDirect.Article_No,
                                                 curDivideDirect.Article_Id,
                                                 curDivideDirect.Packing_Qty,
                                                 curDivideDirect.Article_Qty,
                                                 curDivideDirect.s_Cell_No,
                                                 curDivideDirect.s_Cell_Id,
                                                 curDivideDirect.s_Container_No,
                                                 curDivideDirect.Deliver_Area,
                                                 curDivideDirect.Line_No,
                                                 curDivideDirect.Trunck_Cell_No,
                                                 curDivideDirect.Check_Chute_No,
                                                 curDivideDirect.Deliver_Obj,
                                                 curDivideDirect.deliverobj_order,
                                                 curDivideDirect.Outstock_Date,
                                                 strAssign_No,
                                                 curDivideDirect.Dps_Cell_No,
                                                 curDivideDirect.a_Sorter_Chute_No,
                                                 curDivideDirect.Exp_Date,
                                                 curDivideDirect.Deliver_Obj,
                                                 strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
      update odata_divide_direct d
         set d.status = '13'
       where d.status = '10'
         and d.warehouse_no = curDivideDirect.Warehouse_No
         and d.enterprise_no = curDivideDirect.Enterprise_No
         and d.owner_no = curDivideDirect.Owner_No
         and d.source_no = curDivideDirect.Source_No
         and d.divide_id = curDivideDirect.Divide_Id;

      if sql%rowcount <= 0 then
        strOutMsg := 'N|Source_No:' || curDivideDirect.Source_No ||
                     ',Divide_id:' || curDivideDirect.Divide_Id;
        return;
      end if;
    end loop;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_OutStock_Divide;

  /**********************************************************************************************8
  quzhihui
  20160621
  功能说明：按来源单号写分播单，并返回分播单号
  ***********************************************************************************************/
  procedure P_WriteOutStock_Divide(strEnterPriseNo in ODATA_DIVIDE_D.Enterprise_No%type, --企业号
                                   strwarehouse_no in ODATA_DIVIDE_D.warehouse_no%type, --仓别
                                   strSource_No    in odata_divide_direct.source_no%type, --来源单号
                                   strAssign_No    in odata_divide_d.assign_name%type, --预定分播人员
                                   strUserID       in bdef_defworker.worker_no%type, --系统操作人员
                                   --strPrint_Flag   in varchar, --是否打印
                                   strDivide_No out odata_divide_m.divide_no%type, --分播单号
                                   strOutMsg    out varchar2) --返回值
   IS
    intCount   integer := 0;
    v_DivideNo ODATA_DIVIDE_D.Divide_No%type;
    --v_PrintTaskNo job_printtask_m.task_no%type;

  BEGIN
    strOutMsg := 'N|[P_OutStock_Divide]';
    for curDivideDirect in (select d.*,olb.owner_no real_owner_no
                              from odata_divide_direct d,odata_locate_batch olb
                             where d.WAREHOUSE_NO = strwarehouse_no
                               and d.enterprise_no = strEnterPriseNo
                               and d.SOURCE_NO = strSource_No
                               and olb.enterprise_no=d.enterprise_no
                               and olb.warehouse_no=d.warehouse_no
                               and olb.wave_no=d.wave_no
                               and olb.batch_no=d.batch_no
                               and d.status = 10
                               for update) loop
      intCount := intCount + 1;

      if intCount = 1 then

        --写分播单头档
        PKOBJ_ODATA_DIVIDE.P_Insert_Odata_Divide_M(strEnterPriseNo,
                                                   strwarehouse_no,
                                                   curDivideDirect.Real_Owner_No,
                                                   trunc(sysdate),
                                                   'C',
                                                   curDivideDirect.source_type,
                                                   curDivideDirect.Wave_No,
                                                   curDivideDirect.Batch_No,
                                                   --Modify BY QZH AT 2016-7-23 表示未分配分播设备
                                                   'N', --curDivideDirect.device_no,
                                                   curDivideDirect.Exp_Date,
                                                   strUserID,
                                                   v_DivideNo,
                                                   strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
        /*
        if strPrint_Flag = '1' then
          --写打印任务
          PKLG_WMS_BASE.p_getsheetno(strEnterPriseNo,
                                     strwarehouse_no,
                                     CONST_DOCUMENTTYPE.PRINTPT,
                                     v_PrintTaskNo,
                                     strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;

          PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterPriseNo,
                                              strwarehouse_no,
                                              v_DivideNo,
                                              '0',
                                              const_reportid.OmDivideReport,
                                              strDockNo,
                                              '0',
                                              strUserID,
                                              v_PrintTaskNo,
                                              strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        end if;
        */
      end if;

      --写分播单明细
      PKOBJ_ODATA_DIVIDE.P_Insert_Odata_Divide_D(strEnterPriseNo,
                                                 strwarehouse_no,
                                                 curDivideDirect.Owner_No,
                                                 curDivideDirect.Batch_No,
                                                 v_DivideNo,
                                                 curDivideDirect.Source_No,
                                                 curDivideDirect.Divide_Id,
                                                 curDivideDirect.Operate_Date,
                                                 curDivideDirect.Cust_No,
                                                 curDivideDirect.Sub_Cust_No,
                                                 curDivideDirect.Exp_Type,
                                                 curDivideDirect.Exp_No,
                                                 curDivideDirect.Wave_No,
                                                 curDivideDirect.Article_No,
                                                 curDivideDirect.Article_Id,
                                                 curDivideDirect.Packing_Qty,
                                                 curDivideDirect.Article_Qty,
                                                 curDivideDirect.s_Cell_No,
                                                 curDivideDirect.s_Cell_Id,
                                                 curDivideDirect.s_Container_No,
                                                 curDivideDirect.Deliver_Area,
                                                 curDivideDirect.Line_No,
                                                 curDivideDirect.Trunck_Cell_No,
                                                 curDivideDirect.Check_Chute_No,
                                                 curDivideDirect.Deliver_Obj,
                                                 curDivideDirect.deliverobj_order,
                                                 curDivideDirect.Outstock_Date,
                                                 strAssign_No,
                                                 curDivideDirect.Dps_Cell_No,
                                                 curDivideDirect.a_Sorter_Chute_No,
                                                 curDivideDirect.Exp_Date,
                                                 'N',
                                                 strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
      update odata_divide_direct d
         set d.status = '13'
       where d.status = '10'
         and d.warehouse_no = curDivideDirect.Warehouse_No
         and d.enterprise_no = curDivideDirect.Enterprise_No
         and d.owner_no = curDivideDirect.Owner_No
         and d.source_no = curDivideDirect.Source_No
         and d.divide_id = curDivideDirect.Divide_Id;

      if sql%rowcount <= 0 then
        strOutMsg := 'N|Source_No:' || curDivideDirect.Source_No ||
                     ',Divide_id:' || curDivideDirect.Divide_Id;
        return;
      end if;
    end loop;
    --如果没有分播指示 则 报失败 huangb 20160716
    if intCount <= 0 then
      strOutMsg := 'N|[找不到分播指示数据]';
      return;
    end if;
    strDivide_No := v_DivideNo;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_WriteOutStock_Divide;

  /*****************************************************************************************
    luozhiling
    20141023
    功能：分播回单功能，拆分分播明细
  *****************************************************************************************/
  procedure p_DpsDiveSave(strEnterPriseNo in odata_divide_d.enterprise_no%type,
                          strWareHouseNo  in odata_divide_d.warehouse_no%type, --仓别
                          strDivideNo     in odata_divide_d.divide_no%type, --分播单号
                          strArticleNo    in odata_divide_d.article_no%type, --商品编号
                          strDpsCellNo    in odata_divide_d.dps_cell_no%type,
                          strBarcode      in stock_article_info.barcode%type,
                          nRealQty        in odata_divide_d.real_qty%type,
                          strDivideName   in odata_divide_d.divide_name%type,
                          strCustNo       in odata_divide_d.cust_no%type,
                          strLabelNo      in stock_label_m.label_no%type, --来源箱号
                          strAddFlag      in odata_divide_m.divide_type%type, --1：按数量回单；2：按记录数回单
                          strResult       out varchar2) is
    cursor v_divide_info is
      SELECT sai.barcode,
             sai.produce_date,
             sai.expire_date,
             sai.quality,
             sai.lot_no,
             sai.rsv_batch1,
             sai.rsv_batch2,
             sai.rsv_batch3,
             sai.rsv_batch4,
             sai.rsv_batch5,
             sai.rsv_batch6,
             sai.rsv_batch7,
             sai.rsv_batch8,
             d.owner_no,
             d.divide_no,
             d.s_container_no,
             d.cust_no,
             d.deliver_obj,
             d.s_cell_no,
             d.batch_no,
             sum(d.article_qty) article_qty
        from odata_divide_d d, stock_article_info sai, stock_label_m slm
       where d.article_no = sai.article_no
         and d.article_id = sai.article_id
         and slm.container_no = d.s_container_no
         and slm.label_no = strLabelNo
         and d.warehouse_no = strWareHouseNo
         and d.enterprise_no = strEnterPriseNo
         and d.DIVIDE_NO = strDivideNo
         and d.ARTICLE_NO = strArticleNo
         and d.cust_no = strCustNo
         and d.status = '10'
         and d.article_qty - d.real_qty > 0
         and sai.barcode = strBarcode
       group by sai.barcode,
                sai.produce_date,
                sai.expire_date,
                sai.quality,
                sai.lot_no,
                sai.rsv_batch1,
                sai.rsv_batch2,
                sai.rsv_batch3,
                sai.rsv_batch4,
                sai.rsv_batch5,
                sai.rsv_batch6,
                sai.rsv_batch7,
                sai.rsv_batch8,
                d.owner_no,
                d.divide_no,
                d.s_container_no,
                d.cust_no,
                d.deliver_obj,
                d.s_cell_no,
                d.batch_no;
    v_strCustLabelNo stock_label_m.label_no%type;
    v_strContainerNo stock_label_m.container_no%type;
    strSessionID     varchar2(10);
    nRemainQty       odata_divide_d.article_qty%type;
    nCurrQty         odata_divide_d.article_qty%type;
    v_iCount         integer := 0;
  begin
    strResult := 'N|[p_DpsDiveSave]';

    -- 获取当前储位的电子标签号码
    begin
      select label_no
        into v_strCustLabelNo
        from dps_stock_label
       where warehouse_no = strWareHouseNo
         and enterprise_no = strEnterPriseNo
         and dps_cell_no = strDpsCellNo
         and status = '1';
    exception
      when no_data_found then
        --取号
        --取P标签 只取一个标签
        pklg_wms_base.p_get_ContainerNoBase(strEnterPriseNo,
                                            strWareHouseNo,
                                            'B',
                                            strDivideName,
                                            'D',
                                            1,
                                            '0',
                                            '11',
                                            v_strCustLabelNo,
                                            v_strContainerNo,
                                            strSessionID,
                                            strResult);
        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        insert into dps_stock_label
          (warehouse_no,
           dps_cell_no,
           label_no,
           status,
           rgst_name,
           rgst_date,
           enterprise_no)
        values
          (strWareHouseNo,
           strDpsCellNo,
           v_strCustLabelNo,
           '1',
           strDivideName,
           sysdate,
           strEnterPriseNo);
    end;
    nRemainQty := nRealQty;

    for GetDivideItem in v_divide_info loop
      v_iCount := v_iCount + 1;
      if nRemainQty >= GetDivideItem.article_qty then
        nRemainQty := nRemainQty - GetDivideItem.article_qty;
        nCurrQty   := GetDivideItem.article_qty;
      else
        nCurrQty   := nRemainQty;
        nRemainQty := 0;
      end if;
      p_Save_Odata_divide(strEnterPriseNo,
                          strwarehouseNo,
                          GetDivideItem.owner_no,
                          strDivideNo,
                          strArticleNo,
                          v_strCustLabelNo,
                          GetDivideItem.article_qty,
                          nCurrQty,
                          strDivideName,
                          GetDivideItem.batch_no,
                          GetDivideItem.quality,
                          GetDivideItem.produce_date,
                          GetDivideItem.expire_date,
                          GetDivideItem.lot_no,
                          GetDivideItem.rsv_batch1,
                          GetDivideItem.rsv_batch2,
                          GetDivideItem.rsv_batch3,
                          GetDivideItem.rsv_batch4,
                          GetDivideItem.rsv_batch5,
                          GetDivideItem.rsv_batch6,
                          GetDivideItem.rsv_batch7,
                          GetDivideItem.rsv_batch8,
                          GetDivideItem.s_cell_no,
                          GetDivideItem.s_container_no,
                          strCustNo,
                          GetDivideItem.deliver_obj,
                          strDivideName,
                          strAddFlag,
                          'B',
                          strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      if nRemainQty = 0 then
        exit;
      end if;
    end loop;

    if v_iCount = 0 then
      strResult := 'N|[找不到分播数据]';
      return; --如果不返回 还是会报成功 huangb 20160716
    end if;
    strResult := 'Y|[成功]';
  end p_DpsDiveSave;

  /*****************************************************************************************
    luozhiling
    20141027
    功能：分播取消
  *****************************************************************************************/
  procedure p_DpsDiveCancel(strEnterPriseNo in odata_divide_d.enterprise_no%type,
                            strWareHouseNo  in odata_divide_d.warehouse_no%type, --仓别
                            strDivideNo     in odata_divide_d.divide_no%type, --分播单号
                            strDivideName   in odata_divide_d.divide_name%type,
                            strAddFlag      in odata_divide_m.divide_type%type, --1：按数量回单；2：按记录数回单
                            strResult       out varchar2) is

  begin
    strResult := 'N|[p_DpsDiveSave]';

    for divideItem in (select sai.barcode,
                              sai.produce_date,
                              sai.expire_date,
                              sai.quality,
                              sai.lot_no,
                              sai.rsv_batch1,
                              sai.rsv_batch2,
                              sai.rsv_batch3,
                              sai.rsv_batch4,
                              sai.rsv_batch5,
                              sai.rsv_batch6,
                              sai.rsv_batch7,
                              sai.rsv_batch8,
                              d.owner_no,
                              d.divide_no,
                              sai.article_no,
                              d.s_container_no,
                              d.cust_no,
                              d.deliver_obj,
                              d.s_cell_no,
                              d.batch_no,
                              sum(d.article_qty) article_qty
                         from odata_divide_d d, stock_article_info sai
                        where d.warehouse_no = strWareHouseNo
                          and d.enterprise_no = strEnterPriseNo
                          and d.article_no = sai.article_no
                          and d.article_id = sai.article_id
                          and d.divide_no = strDivideNo
                          and d.status = '10'
                          and d.article_qty > d.real_qty
                        group by sai.barcode,
                                 sai.produce_date,
                                 sai.expire_date,
                                 sai.quality,
                                 sai.lot_no,
                                 sai.rsv_batch1,
                                 sai.rsv_batch2,
                                 sai.rsv_batch3,
                                 sai.rsv_batch4,
                                 sai.rsv_batch5,
                                 sai.rsv_batch6,
                                 sai.rsv_batch7,
                                 sai.rsv_batch8,
                                 d.owner_no,
                                 d.divide_no,
                                 sai.article_no,
                                 d.s_container_no,
                                 d.cust_no,
                                 d.deliver_obj,
                                 d.s_cell_no,
                                 d.batch_no) loop

      p_Save_Odata_divide(strEnterPriseNo,
                          strWareHouseNo,
                          divideItem.owner_no,
                          strDivideNo,
                          divideItem.article_no,
                          'N',
                          divideItem.article_qty,
                          0,
                          strDivideName,
                          divideItem.batch_no,
                          divideItem.quality,
                          divideItem.produce_date,
                          divideItem.expire_date,
                          divideItem.lot_no,
                          divideItem.rsv_batch1,
                          divideItem.rsv_batch2,
                          divideItem.rsv_batch3,
                          divideItem.rsv_batch4,
                          divideItem.rsv_batch5,
                          divideItem.rsv_batch6,
                          divideItem.rsv_batch7,
                          divideItem.rsv_batch8,
                          divideItem.s_cell_no,
                          divideItem.s_container_no,
                          divideItem.cust_no,
                          divideItem.deliver_obj,
                          strDivideName,
                          strAddFlag,
                          'B',
                          strResult);

    end loop;

    strResult := 'Y|[成功]';
  end p_DpsDiveCancel;

  /*****************************************************************************************
    lich
    20141028
    功能：封箱
  *****************************************************************************************/
  procedure P_ODATA_DIVIDE_CUTBOX(strEnterPriseNo   in odata_divide_d.enterprise_no%type,
                                  strWareHouseNo    in odata_divide_d.warehouse_no%type, --仓别
                                  strCellNo         in dps_stock_label.dps_cell_no%type, --储位
                                  strUserId         in Ridata_instock_m.rgst_name%type, --上架人
                                  strPaperUserId    in Ridata_instock_m.rgst_name%type, --回单人
                                  strTools          in stock_content_move.terminal_flag%type,
                                  strPrinterGroupNo in ridata_check_m.printer_group_no%type,
                                  strResult         out varchar2) is
    v_strLabelNo dps_stock_label.label_no%type;
    v_strPrtTask ridata_instock_d.instock_no%type;

  begin
    strResult := 'N|[P_ODATA_DIVIDE_CUTBOX]';

    --取标签号
    begin
      select b.label_no
        into v_strLabelNo
        from dps_stock_label b
       where b.dps_cell_no = strCellNo
         and b.warehouse_no = strWareHouseNo
         and b.enterprise_no = strEnterPriseNo;
    exception
      when no_data_found then
        v_strLabelNo := 'N';
    end;

    --更新标签状态
    update dps_stock_label a
       set a.status = '0', a.updt_name = strUserId, a.updt_date = sysdate
     where a.warehouse_no = strWareHouseNo
       and a.enterprise_no = strEnterPriseNo
       and a.label_no = v_strLabelNo;

    if sql%notfound then
      strResult := 'Y|[成功]';
      return;
    end if;

    --写打印任务头档
    PKOBJ_PRINTTASK.p_insert_PrintGrouptaskmaster(strEnterPriseNo,
                                                  strWareHouseNo,
                                                  v_strLabelNo,
                                                  0,
                                                  CONST_REPORTID.RPT_BOXITEM,
                                                  strPrinterGroupNo,
                                                  0,
                                                  strUserId,
                                                  v_strPrtTask,
                                                  strResult);
    if substr(strResult, 1, 1) <> 'Y' then
      return;
    end if;

    --写打印任务头档
    PKOBJ_PRINTTASK.p_insert_PrintGrouptaskmaster(strEnterPriseNo,
                                                  strWareHouseNo,
                                                  v_strLabelNo,
                                                  0,
                                                  CONST_REPORTID.B_CLOSEExpBOX,
                                                  strPrinterGroupNo,
                                                  0,
                                                  strUserId,
                                                  v_strPrtTask,
                                                  strResult);
    if substr(strResult, 1, 1) <> 'Y' then
      return;
    end if;

    --转历史表
    insert into dps_stock_labelhty
      (warehouse_no,
       dps_cell_no,
       label_no,
       status,
       rgst_name,
       rgst_date,
       updt_name,
       updt_date,
       enterprise_no)
      select warehouse_no,
             dps_cell_no,
             label_no,
             status,
             rgst_name,
             rgst_date,
             updt_name,
             updt_date,
             enterprise_no
        from dps_stock_label a
       where a.warehouse_no = strWareHouseNo
         and a.enterprise_no = strEnterPriseNo
         and a.dps_cell_no = strCellNo;

    --删除
    delete from dps_stock_label a
     where a.warehouse_no = strWareHouseNo
       and a.enterprise_no = strEnterPriseNo
       and a.dps_cell_no = strCellNo;

    /*       pkobj_hb.p_OM_AerrangeConfirm(strWareHouseNo,v_strLabelNo,strUserId,strResult);

    if substr(strResult, 1, 1) <> 'Y' then
      return;
    end if;*/

    strResult := 'Y|[成功]';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_ODATA_DIVIDE_CUTBOX;
  /*****************************************************************************************
  2015.12.4
  功能说明：1、根据分播标签的分播信息进行取号
            2、打印
  ******************************************************************************************/
  procedure GetCustLabelAndPrint(strEnterPriseNo  in ODATA_DIVIDE_D.Enterprise_No%type, --企业号
                                 strWareHouseNo   in ODATA_DIVIDE_D.warehouse_no%type, --仓别
                                 strDivideNo      in odata_divide_d.divide_no%type, --
                                 strsLabelNo      in stock_label_m.label_no%type, --来源标签号
                                 strCustNo        in stock_label_m.cust_no%type, --客户（配送对象）
                                 strArticleNo     in stock_label_d.article_no%type, --商品编码
                                 strDockNo        in bdef_defdock.dock_no%type, --工作站
                                 strContainerType in stock_label_m.container_type%type, --P：栈板；
                                 strUserId        in stock_label_m.rgst_name%type,
                                 strDLabelNo      out stock_label_m.label_no%type, --目的标签号
                                 strOutMsg        out varchar2) is
    --返回值
    v_strPrtTask         job_printtask_m.task_no%type;
    v_strExpType         odata_outstock_d.exp_type%type;
    v_strOwnerNo         odata_outstock_d.owner_no%type; --
    v_strDeliverObjLevel wms_outlocate_strategy_d.deliver_obj_level%type; --0:按客户；1：按单据
    v_strReportId        job_printtask_m.report_id%type;
  begin
    strOutMsg := 'N|[GetCustLabelAndPrint]';

    GetCustLabel(strEnterPriseNo,
                 strWareHouseNo,
                 strDivideNo,
                 strsLabelNo,
                 strCustNo,
                 strArticleNo,
                 strContainerType,
                 strUserId,
                 strDLabelNo,
                 strOutMsg);

    if (substr(strOutMsg, 1, 1) = 'N') then
      return;
    end if;

    --获取配送对象级别
    begin
      select ood.exp_type, ood.owner_no
        into v_strExpType, v_strOwnerNo
        from odata_divide_d ood
       where ood.warehouse_no = strWareHouseNo
         and ood.enterprise_no = strEnterPriseNo
         and ood.divide_no = strDivideNo
         and rownum = 1;
    exception
      when no_data_found then
        return;
    end;

    PKLG_OLOCATE.GetDeliverObjLevel(strEnterpriseNo,
                                    strWareHouseNo,
                                    v_strOwnerNo,
                                    v_strExpType,
                                    v_strDeliverObjLevel,
                                    strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      strOutMsg := 'N|[E22105]';
      return;
    end if;

    if v_strDeliverObjLevel = '1' then
      --按单；
      v_strReportId := CONST_REPORTID.B_CLOSEExpBOX;
    else
      v_strReportId := CONST_REPORTID.B_CLOSECustBOX;
    end if;

    --写打印任务头档
    PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterpriseNo,
                                        strWareHouseNo,
                                        strDLabelNo,
                                        0,
                                        v_strReportId,
                                        strDockNo,
                                        0,
                                        strUserId,
                                        v_strPrtTask,
                                        strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    strOutMsg := 'Y|[成功]';

  end GetCustLabelAndPrint;

  /*****************************************************************************************
  2015.12.4
  功能说明：根据分播标签的客户进行取号
  ******************************************************************************************/
  procedure GetCustLabel(strEnterPriseNo  in ODATA_DIVIDE_D.Enterprise_No%type, --企业号
                         strWareHouseNo   in ODATA_DIVIDE_D.warehouse_no%type, --仓别
                         strDivideNo      in odata_divide_d.divide_no%type, --
                         strsLabelNo      in stock_label_m.label_no%type, --来源标签号
                         strDeliver_Obj   in stock_label_m.cust_no%type, --配送对象
                         strArticleNo     in stock_label_d.article_no%type, --商品编码
                         strContainerType in stock_label_m.container_type%type, --P：栈板；
                         strUserId        in stock_label_m.rgst_name%type,
                         strDLabelNo      out stock_label_m.label_no%type, --目的标签号
                         strOutMsg        out varchar2) is
    --返回值
    v_iCount               integer := 0;
    v_strDcontainerNo      stock_label_m.container_no%type;
    v_strContainerMaterial wms_defcontainer.container_material%type;
    strSessionID           varchar2(10);
    v_strDeliverObjLevel   wms_outlocate_strategy_d.deliver_obj_level%type; --0:按客户；1：按单据
    v_strReportId          job_printtask_m.report_id%type;
  begin
    strOutMsg := 'N|[GetCustLabelAndPrint]';

    if strContainerType = 'P' then
      v_strContainerMaterial := '31';
    end if;
    if strContainerType = 'B' then
      v_strContainerMaterial := '11';
    end if;

    for GetDivideLabel in (select ood.trunck_cell_no,
                                  ood.a_sorter_chute_no,
                                  ood.check_chute_no,
                                  ood.s_cell_no,
                                  sld.*
                             from odata_divide_d ood,
                                  stock_label_d  sld,
                                  stock_label_m  slm
                            where ood.enterprise_no = sld.enterprise_no
                              and ood.warehouse_no = sld.warehouse_no
                              and sld.enterprise_no = slm.enterprise_no
                              and sld.warehouse_no = slm.warehouse_no
                              and sld.container_no = slm.container_no
                              and ood.s_container_no = sld.container_no
                              and ood.enterprise_no = strEnterPriseNo
                              and ood.warehouse_no = strWareHouseNo
                              and ood.divide_no = strDivideNo
                              and slm.label_no = strsLabelNo
                              and sld.article_no = ood.article_no
                              and sld.cust_no = ood.cust_no
                              and sld.divide_id = ood.divide_id
                              and ood.article_no = strArticleNo
                              and ood.deliver_obj = strDeliver_Obj
                              and sld.article_id = ood.article_id
                              and sld.packing_qty = ood.packing_qty
                              and sld.exp_no = ood.exp_no
                              and ood.status = '10'
                              and rownum = 1) loop

      v_iCount := v_iCount + 1;

      pklg_wms_base.p_get_ContainerNoBase(strEnterPriseNo,
                                          strWareHouseNo,
                                          strContainerType,
                                          strUserId,
                                          'D',
                                          1,
                                          '2',
                                          v_strContainerMaterial,
                                          strDLabelNo,
                                          v_strDcontainerNo,
                                          strSessionID,
                                          strOutMsg);
      if (substr(strOutMsg, 1, 1) = 'N') then
        return;
      end if;

      PKLG_OLOCATE.GetDeliverObjLevel(strEnterpriseNo,
                                      strWareHouseNo,
                                      GetDivideLabel.owner_no,
                                      GetDivideLabel.exp_type,
                                      v_strDeliverObjLevel,
                                      strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        strOutMsg := 'N|[E22105]';
        return;
      end if;

      if v_strDeliverObjLevel = '1' then
        --按单；
        v_strReportId := CONST_REPORTID.B_CLOSEExpBOX;
      else
        v_strReportId := CONST_REPORTID.B_CLOSECustBOX;
      end if;

      pkobj_label.proc_Insert_LabelMaster(strEnterPriseNo,
                                          strWareHouseNo,
                                          GetDivideLabel.batch_no,
                                          strDivideNo,
                                          strDLabelNo,
                                          v_strDcontainerNo,
                                          strContainerType,
                                          'N',
                                          GetDivideLabel.S_CELL_NO,
                                          GetDivideLabel.CUST_NO,
                                          GetDivideLabel.TRUNCK_CELL_NO,
                                          GetDivideLabel.a_sorter_chute_no,
                                          GetDivideLabel.CHECK_CHUTE_NO,
                                          GetDivideLabel.DELIVER_OBJ,
                                          CLabelUseType.CUSTOMER_LABEL,
                                          GetDivideLabel.line_no,
                                          'N',
                                          'N',
                                          strUserId,
                                          v_strReportId,
                                          'N',
                                          'N',
                                          '1',
                                          '0',
                                          v_strDcontainerNo,
                                          CLABELSTATUS.NEW_LABEL_NO,
                                          '0',
                                          GetDivideLabel.wave_no,
                                          strOutMsg);
      if (substr(strOutMsg, 1, 1) = 'N') then
        return;
      end if;

    end loop;

    if v_iCOUNT = 0 THEN
      --找不到对应的分播数据
      strOutMsg := 'N|[找不到对应的分播数据]';
      return;
    end if;

    strOutMsg := 'Y|[成功]';

  end GetCustLabel;

  /*****************************************************************************************
    lich
    20140529
    功能：分播回单功能
  *****************************************************************************************/
  procedure p_Save_Odata_divide(strEnterPriseNo   in ODATA_DIVIDE_D.Enterprise_No%type, --企业号
                                strwarehouse_no   in ODATA_DIVIDE_D.warehouse_no%type, --仓别
                                strOWNER_NO       in ODATA_DIVIDE_D.OWNER_NO%type, --委托业主
                                strDIVIDE_NO      in ODATA_DIVIDE_D.DIVIDE_NO%type, --分播单号
                                strARTICLE_NO     in ODATA_DIVIDE_D.ARTICLE_NO%type, --商品编码
                                strDLabelNo       in ODATA_DIVIDE_D.CUST_CONTAINER_NO%type, --目的标签号
                                nArticleQty       in odata_divide_d.article_qty%type, --计划量
                                nREAL_QTY         in ODATA_DIVIDE_D.REAL_QTY%type, --实际分播数量
                                strDIVIDE_NAME    in ODATA_DIVIDE_D.DIVIDE_NAME%type, --实际分播人
                                strBATCH_NO       in ODATA_DIVIDE_D.BATCH_NO%type, --批次号
                                strQuality        in idata_check_d.quality%type, --品质
                                dtProduceDate     in stock_article_info.produce_date%type, --生产日期
                                dtExpireDate      in stock_article_info.expire_date%type, --到期日期
                                strLotNo          in stock_article_info.lot_no%type, --批号
                                strRSV_BATCH1     in stock_article_info.rsv_batch1%type, --预留批属性1
                                strRSV_BATCH2     in stock_article_info.rsv_batch2%type, --预留批属性2
                                strRSV_BATCH3     in stock_article_info.rsv_batch3%type, --预留批属性3
                                strRSV_BATCH4     in stock_article_info.rsv_batch4%type, --预留批属性4
                                strRSV_BATCH5     in stock_article_info.rsv_batch5%type, --预留批属性5
                                strRSV_BATCH6     in stock_article_info.rsv_batch6%type, --预留批属性6
                                strRSV_BATCH7     in stock_article_info.rsv_batch7%type, --预留批属性7
                                strRSV_BATCH8     in stock_article_info.rsv_batch8%type, --预留批属性8
                                strS_CELL_NO      in ODATA_DIVIDE_D.S_CELL_NO%type, --来源储位编码
                                strS_CONTAINER_NO in ODATA_DIVIDE_D.S_CONTAINER_NO%type, --来源容器
                                strCUST_NO        in ODATA_DIVIDE_D.CUST_NO%type, --客户
                                strDelvierObj     in odata_divide_d.deliver_obj%type, --配送对象
                                strUPDT_NAME      in ODATA_DIVIDE_M.UPDT_NAME%type, --更新人员
                                strAddFlag        in odata_divide_m.divide_type%type,
                                strContainerType  in wms_defcontainer.container_type%type,
                                strOutMsg         out varchar2) --返回值
   is
    v_strDcontainerNo      ODATA_DIVIDE_D.Cust_Container_No%type;
    strLabelNoTmp          varchar2(24); --板号
    strSessionID           varchar2(10);
    v_nCurrQty             number(14, 5); --当前分播数量
    v_nTotalQty            number(14, 5); --分播总数量
    strStock_type          VARCHAR2(1); --存储类型
    strStock_value         VARCHAR2(20); --对应的存储值
    intcount               integer;
    nOutCellID             stock_content.cell_id%type; --返回的储位ID
    v_strContainerMaterial wms_defcontainer.container_material%type;
    v_strFlowFlag          wms_deflabel_status.flow_flag%type;
    v_strExpType           odata_outstock_d.exp_type%type;

    v_strReportId        job_printtask_m.report_id%type;
    Cursor v_GetDivideInf is
      SELECT d.*, b.divide_excess
        from ODATA_DIVIDE_D d, bdef_defarticle b, stock_article_info sai
       where d.article_no = b.article_no
         and d.article_id = sai.article_id
         and d.enterprise_no = b.enterprise_no
         and d.enterprise_no = sai.enterprise_no
         and d.article_no = sai.article_no
         and d.warehouse_no = strwarehouse_no
         and d.enterprise_no = strEnterPriseNo
         and d.OWNER_NO = strOWNER_NO
         and d.DIVIDE_NO = strDIVIDE_NO
         and d.ARTICLE_NO = strARTICLE_NO
         and d.cust_no = strCUST_NO
         and d.s_container_no = strS_CONTAINER_NO
         and d.batch_no = strBATCH_NO
         and d.s_cell_no = strS_CELL_NO
         and sai.produce_date = dtProduceDate
         and sai.expire_date = dtExpireDate
         and sai.lot_no = strLotNo
         and sai.quality = strQuality
         and sai.rsv_batch1 = strRSV_BATCH1
         and sai.rsv_batch2 = strRSV_BATCH2
         and sai.rsv_batch3 = strRSV_BATCH3
         and sai.rsv_batch4 = strRSV_BATCH4
         and sai.rsv_batch5 = strRSV_BATCH5
         and sai.rsv_batch6 = strRSV_BATCH6
         and sai.rsv_batch7 = strRSV_BATCH7
         and sai.rsv_batch8 = strRSV_BATCH8
         and d.status = '10'
         and d.deliver_obj = strDelvierObj;
    v_strUnableDiffQtyFlag wms_defbase.sdefine%type;
    v_strdStatus           stock_label_m.status%type; --   目的标签状态
    v_ExpTraceStatus       odata_exp_m.status%type;
    v_ExpTraceStatusCount  integer := 0;

  begin
    strOutMsg := 'N|[p_Save_Odata_divide]';

    --获取是否可差异回单的判断
    begin
         select wos.divide_diff_flag into v_strUnableDiffQtyFlag
         from odata_divide_d oom,odata_locate_batch olb,wms_outpick_strategy wos
         where oom.enterprise_no=olb.enterprise_no and oom.warehouse_no=olb.warehouse_no
         and oom.wave_no=olb.wave_no and oom.batch_no=olb.batch_no
         and olb.enterprise_no=wos.enterprisE_no and olb.PICK_STRATEGY_ID=wos.PICK_STRATEGY_ID
         and oom.divide_no=strDIVIDE_NO and olb.enterprise_no=strEnterPriseNo
         and olb.warehouse_no=strwarehouse_no
         and rownum=1;
    exception when no_data_found then
      strOutMsg := 'N|[找不到对应的拣货分播策略配置]';
      return;
    end;


    --按记录数回单才判断
    if strAddFlag = '2' then
      if v_strUnableDiffQtyFlag = '0' and nArticleQty <> nREAL_QTY then
        strOutMsg := 'N|[分播回单不允许有差异]';
        return;
      end if;
    end if;

    --获取报表ID
    PKLG_WMS_Public.p_GetReportId(strEnterPriseNo,strwarehouse_no,'RD','D',
         strDIVIDE_NO,v_strReportId,strOutMsg);
    if (substr(strOutMsg, 1, 1) = 'N') then
      return;
    end if;

    intcount    := 0;
    v_nTotalQty := nREAL_QTY;

    if strContainerType = 'B' then
      v_strContainerMaterial := '11';
    end if;

    if strContainerType = 'C' then
      v_strContainerMaterial := '21';
    end if;
    if strContainerType = 'P' then
      v_strContainerMaterial := '31';
    end if;
    for GetDivideInf in v_GetDivideInf loop
      intcount := intcount + 1;
      --分摊数量
      if v_nTotalQty >= GetDivideInf.article_qty - GetDivideInf.real_qty then
        v_nCurrQty := GetDivideInf.article_qty - GetDivideInf.real_qty;
      else
        v_nCurrQty := v_nTotalQty;
      end if;

      v_nTotalQty := v_nTotalQty - v_nCurrQty;

      --1.转换目的标签,没有则生成标签,写入标签表
      begin
        SELECT CONTAINER_NO
          INTO v_strDcontainerNo
          FROM STOCK_LABEL_M
         WHERE warehouse_no = strwarehouse_no
           and enterprise_no = strEnterPriseNo
           AND LABEL_NO = strDLabelNo;
      exception
        when no_data_found then
          pklg_wms_base.p_get_ContainerNoBase(strEnterPriseNo,
                                              strwarehouse_no,
                                              strContainerType,
                                              strDIVIDE_NAME,
                                              'D',
                                              1,
                                              '2',
                                              v_strContainerMaterial,
                                              strLabelNoTmp,
                                              v_strDcontainerNo,
                                              strSessionID,
                                              strOutMsg);
          if (substr(strOutMsg, 1, 1) = 'N') then
            return;
          end if;
          pkobj_label.proc_Insert_LabelMaster(strEnterPriseNo,
                                              strwarehouse_no,
                                              strBATCH_NO,
                                              strDIVIDE_NO,
                                              strDLabelNo,
                                              v_strDcontainerNo,
                                              strContainerType,
                                              'N',
                                              GetDivideInf.S_CELL_NO,
                                              GetDivideInf.CUST_NO,
                                              GetDivideInf.TRUNCK_CELL_NO,
                                              GetDivideInf.a_sorter_chute_no,
                                              GetDivideInf.CHECK_CHUTE_NO,
                                              GetDivideInf.DELIVER_OBJ,
                                              CLabelUseType.CUSTOMER_LABEL,
                                              GetDivideInf.line_no,
                                              'N',
                                              'N',
                                              strDIVIDE_NAME,
                                              v_strReportId,
                                              'N',
                                              'N',
                                              '1',
                                              '0',
                                              v_strDcontainerNo,
                                              CLABELSTATUS.RECEIVING,
                                              '0',
                                              GetDivideInf.wave_no,
                                              strOutMsg);
          if (substr(strOutMsg, 1, 1) = 'N') then
            return;
          end if;
      end;

      --更新分播单明细的分播数量,板号,状态
      Pkobj_Odata_Divide.p_Update_Odata_Divide_D(strEnterPriseNo,
                                                 strwarehouse_no,
                                                 strOWNER_NO,
                                                 strDIVIDE_NO,
                                                 GetDivideInf.row_id,
                                                 v_nCurrQty,
                                                 v_strDcontainerNo,
                                                 strDIVIDE_NAME,
                                                 strAddFlag,
                                                 strOutMsg);
      if (substr(strOutMsg, 1, 1) = 'N') then
        return;
      end if;

      --从库存读取存储类型和对应的存储值
      begin
        select STOCK_TYPE, STOCK_VALUE
          into strStock_type, strStock_value
          From STOCK_CONTENT
         where warehouse_no = strwarehouse_no
           and enterprise_no = strEnterPriseNo
           and CELL_NO = GetDivideInf.s_CELL_NO
           and CELL_ID = GetDivideInf.s_CELL_ID;
      exception
        when no_data_found then
          strOutMsg := 'N|找不到序列' || GetDivideInf.DIVIDE_ID || '对应的库存';
          return;
      End;
      v_strExpType:=GetDivideInf.Exp_Type;
      --增加目的标签商品数量,减少源标签商品数量
      PKOBJ_ODATA_DIVIDE.P_Odata_divide_label(strEnterPriseNo,
                                              strwarehouse_no,
                                              strOWNER_NO,
                                              v_strExpType,
                                              GetDivideInf.source_no,
                                              strDIVIDE_NO,
                                              GetDivideInf.S_CONTAINER_NO,
                                              v_strDcontainerNo,
                                              GetDivideInf.DIVIDE_ID,
                                              strArticle_no,
                                              GetDivideInf.ARTICLE_ID,
                                              GetDivideInf.PACKING_QTY,
                                              GetDivideInf.EXP_NO,
                                              v_nCurrQty,
                                              strCUST_NO,
                                              strDIVIDE_NAME,
                                              strOutMsg);
      if (substr(strOutMsg, 1, 1) = 'N') then
        return;
      end if;

      --扣减源库存数量
      PKOBJ_STOCK.p_UpdtContentByCellID(strEnterPriseNo,
                                        strwarehouse_no,
                                        GetDivideInf.s_cell_id,
                                        GetDivideInf.S_CELL_NO,
                                        GetDivideInf.D_CELL_NO,
                                        v_nCurrQty,
                                        strDIVIDE_NAME,
                                        strDIVIDE_NO,
                                        1,
                                        strOutMsg);

      if (substr(strOutMsg, 1, 1) = 'N') then
        return;
      end if;
      --增加目的库存数量
      PKOBJ_STOCK.p_InstContent_qtyByCellNo(strEnterPriseNo,
                                            strwarehouse_no,
                                            strOwner_No,
                                            'N',
                                            strArticle_no,
                                            GetDivideInf.ARTICLE_ID,
                                            GetDivideInf.D_CELL_NO,
                                            GetDivideInf.S_CELL_NO,
                                            GetDivideInf.PACKING_QTY,
                                            v_nCurrQty,
                                            strDLabelNo,
                                            strDLabelNo,
                                            strStock_type,
                                            strStock_value,
                                            strDIVIDE_NAME,
                                            strDIVIDE_NO,
                                            1,
                                            0,
                                            nOutCellID,
                                            strOutMsg);

      if (substr(strOutMsg, 1, 1) = 'N') then
        return;
      end if;

      --全部回单
      v_ExpTraceStatus := COdataExpStatus.ExpTracAllDivide;

      select count(1)
        into v_ExpTraceStatusCount
        from odata_divide_d d
       where d.warehouse_no = strwarehouse_no
         and d.enterprise_no = strEnterPriseNo
         and d.exp_type = GetDivideInf.Exp_Type
         and d.exp_no = GetDivideInf.Exp_No
         and d.status < '13';
      if v_ExpTraceStatusCount > 0 then
        v_ExpTraceStatus := COdataExpStatus.ExpTracPartDivide; --部分回单
      end if;
      select count(1)
        into v_ExpTraceStatusCount
        from odata_outstock_d d
       where d.warehouse_no = strwarehouse_no
         and d.enterprise_no = strEnterPriseNo
         and d.exp_type = GetDivideInf.Exp_Type
         and d.exp_no = GetDivideInf.Exp_No
         and d.status < '13';

      if v_ExpTraceStatusCount > 0 then
        v_ExpTraceStatus := COdataExpStatus.ExpTracPartDivide; --部分回单
      end if;

      select count(1)
        into v_ExpTraceStatusCount
        from odata_outstock_direct d
       where d.warehouse_no = strwarehouse_no
         and d.enterprise_no = strEnterPriseNo
         and d.exp_type = GetDivideInf.Exp_Type
         and d.exp_no = GetDivideInf.Exp_No
         and d.status < '13';

      if v_ExpTraceStatusCount > 0 then
        v_ExpTraceStatus := COdataExpStatus.ExpTracPartDivide; --部分回单
      end if;

      --单据状态跟踪
      PKOBJ_ODISPATCH.P_Insert_Odata_Exp_Trace(strEnterPriseNo,
                                               strwarehouse_no,
                                               GetDivideInf.Exp_No,
                                               v_ExpTraceStatus,
                                               strDIVIDE_NAME,
                                               strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

    End loop;

    --目的容器调工作流
    --获取标签类型
    pkobj_hb.p_getlabelnoFlow(strEnterPriseNo,
                              strwarehouse_no,
                              strOWNER_NO,
                              v_strExpType,
                              v_strDcontainerNo,
                              v_strFlowFlag,
                              strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    if v_strFlowFlag = '0' then

      --判断是否调用工作流

      PKOBJ_HB.p_OM_OutWorkflow(strEnterPriseNo,
                                strwarehouse_no,
                                strOWNER_NO,
                                v_strExpType,
                                v_strDcontainerNo,
                                strUPDT_NAME,
                                'N',
                                strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
    else
      --获取目的标签头档状态
      begin
        select status
          into v_strdStatus
          from stock_label_m slm
         where slm.enterprise_no = strEnterPriseNo
           and slm.warehouse_no = strwarehouse_no
           and slm.label_no = strDLabelNo;
      exception
        when no_data_found then
          strOutMsg := 'N|[找不到对应的标签]';
          return;
      end;

      if v_strdStatus = '60' then
        update stock_label_m slm
           set slm.status    = '61',
               slm.updt_name = strUPDT_NAME,
               slm.updt_date = sysdate
         where slm.enterprise_no = strEnterPriseNo
           and slm.warehouse_no = strwarehouse_no
           and slm.label_no = strDLabelNo;
      end if;
    end if;

    --如果状态都为13,把分播数据转历史,分播指示数据转历史,下架指示转历史
    select count(*)
      into intcount
      from ODATA_DIVIDE_D
     where DIVIDE_NO = strDIVIDE_NO
       and STATUS <> 13;

    if intcount = 0 then
      --更新分播单主档
      Pkobj_Odata_Divide.p_Update_Odata_Divide_M(strEnterPriseNo,
                                                 strwarehouse_no,
                                                 strDIVIDE_NO,
                                                 strUPDT_NAME,
                                                 strOutMsg);
      if (substr(strOutMsg, 1, 1) = 'N') then
        return;
      end if;

      --分播数据转历史
      Pkobj_Odata_Divide.p_Update_Odata_Divide_Hty(strEnterPriseNo,
                                                   strwarehouse_no,
                                                   strOwner_No,
                                                   strDIVIDE_NO,
                                                   strOutMsg);
      if (substr(strOutMsg, 1, 1) = 'N') then
        return;
      end if;
    end if;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_Save_Odata_divide;

  /***********************************************************************************************
  整单分播回单功能
  2016.3.9
  **********************************************************************************************/
  procedure p_AllSaveDivide(strEnterPriseNo in ODATA_DIVIDE_D.Enterprise_No%type, --企业号
                            strwarehouse_no in ODATA_DIVIDE_D.warehouse_no%type, --仓别
                            strOWNER_NO     in ODATA_DIVIDE_D.OWNER_NO%type, --委托业主
                            strDIVIDE_NO    in ODATA_DIVIDE_D.DIVIDE_NO%type, --分播单号
                            strUPDT_NAME    in ODATA_DIVIDE_M.UPDT_NAME%type, --更新人员
                            strOutMsg       out varchar2) is
    v_strDLabelNo stock_label_m.label_no%type;
  begin
    strOutMsg := 'N|[p_AllSave]';
    for GetDivideInf in (select olb.industry_flag,
                                oem.shipper_deliver_no,t.owner_no,
                                t.divide_no,
                                t.article_no,
                                t.batch_no,
                                sai.quality,
                                sai.produce_date,
                                sai.expire_date,
                                sai.lot_no,
                                sai.rsv_batch1,
                                sai.rsv_batch2,
                                sai.rsv_batch3,
                                sai.rsv_batch4,
                                sai.rsv_batch5,
                                sai.rsv_batch6,
                                sai.rsv_batch7,
                                sai.rsv_batch8,
                                t.s_cell_no,
                                t.s_container_no,
                                t.cust_no,
                                t.deliver_obj,
                                sum(t.article_qty) article_qty
                           from odata_divide_d     t,
                                odata_locate_batch olb,
                                stock_article_info sai,
                                odata_exp_m        oem
                          where t.enterprise_no = olb.enterprise_no
                            and t.warehouse_no = olb.warehouse_no
                            and t.wave_no = olb.wave_no
                            and t.batch_no = olb.batch_no
                            and t.enterprise_no = oem.enterprise_no
                            and t.warehouse_no = oem.warehouse_no
                            and t.exp_no = oem.exp_no
                            and t.article_no = sai.article_no
                            and t.article_id = sai.article_id
                            and t.enterprise_no = strEnterPriseNo
                            and t.warehouse_no = strwarehouse_no
                            and t.divide_no = strDIVIDE_NO
                            and t.status = '10'
                          group by olb.industry_flag,
                                   oem.shipper_deliver_no,t.owner_no,
                                   t.divide_no,
                                   t.article_no,
                                   t.batch_no,
                                   sai.quality,
                                   sai.produce_date,
                                   sai.expire_date,
                                   sai.lot_no,
                                   sai.rsv_batch1,
                                   sai.rsv_batch2,
                                   sai.rsv_batch3,
                                   sai.rsv_batch4,
                                   sai.rsv_batch5,
                                   sai.rsv_batch6,
                                   sai.rsv_batch7,
                                   sai.rsv_batch8,
                                   t.s_cell_no,
                                   t.s_container_no,
                                   t.cust_no,
                                   t.deliver_obj) loop

      if GetDivideInf.industry_flag = '2' then
        --电商
        v_strDLabelNo := GetDivideInf.Shipper_Deliver_No;
      else
        v_strDLabelNo := GetDivideInf.Deliver_Obj;
      end if;

      p_Save_Odata_divide(strEnterPriseNo,
                          strwarehouse_no,
                          GetDivideInf.owner_no,
                          strDIVIDE_NO,
                          GetDivideInf.article_no,
                          v_strDLabelNo,
                          GetDivideInf.article_qty,
                          GetDivideInf.article_qty,
                          strUPDT_NAME,
                          GetDivideInf.batch_no,
                          GetDivideInf.quality,
                          GetDivideInf.produce_date,
                          GetDivideInf.expire_date,
                          GetDivideInf.lot_no,
                          GetDivideInf.rsv_batch1,
                          GetDivideInf.rsv_batch2,
                          GetDivideInf.rsv_batch3,
                          GetDivideInf.rsv_batch4,
                          GetDivideInf.rsv_batch5,
                          GetDivideInf.rsv_batch6,
                          GetDivideInf.rsv_batch7,
                          GetDivideInf.rsv_batch8,
                          GetDivideInf.s_cell_no,
                          GetDivideInf.s_container_no,
                          GetDivideInf.cust_no,
                          GetDivideInf.deliver_obj,
                          strUPDT_NAME,
                          '1',
                          'P',
                          strOutMsg);
      if (substr(strOutMsg, 1, 1) = 'N') then
        return;
      end if;

    end loop;
    strOutMsg := 'Y|[]';
  end p_AllSaveDivide;

  /*****************************************************************************************
    lich
    20150129
    功能：RF分播回单，调用目的标签校验，再调用p_Save_Odata_divide
  *****************************************************************************************/
  procedure p_SaveDivide(strEnterPriseNo   in ODATA_DIVIDE_D.Enterprise_No%type, --企业号
                         strwarehouse_no   in ODATA_DIVIDE_D.warehouse_no%type, --仓别
                         strOWNER_NO       in ODATA_DIVIDE_D.OWNER_NO%type, --委托业主
                         strDIVIDE_NO      in ODATA_DIVIDE_D.DIVIDE_NO%type, --分播单号
                         strARTICLE_NO     in ODATA_DIVIDE_D.ARTICLE_NO%type, --商品编码
                         strdLabelNo       in stock_label_m.label_no%type, --目的标签
                         nArticleQty       in odata_divide_d.article_qty%type,
                         nREAL_QTY         in ODATA_DIVIDE_D.REAL_QTY%type, --实际分播数量
                         strDIVIDE_NAME    in ODATA_DIVIDE_D.DIVIDE_NAME%type, --实际分播人
                         strBATCH_NO       in ODATA_DIVIDE_D.BATCH_NO%type, --批次号
                         strQuality        in idata_check_d.quality%type, --品质
                         dtProduceDate     in stock_article_info.produce_date%type, --生产日期
                         dtExpireDate      in stock_article_info.expire_date%type, --到期日期
                         strLotNo          in stock_article_info.lot_no%type, --批号
                         strRSV_BATCH1     in stock_article_info.rsv_batch1%type, --预留批属性1
                         strRSV_BATCH2     in stock_article_info.rsv_batch2%type, --预留批属性2
                         strRSV_BATCH3     in stock_article_info.rsv_batch3%type, --预留批属性3
                         strRSV_BATCH4     in stock_article_info.rsv_batch4%type, --预留批属性4
                         strRSV_BATCH5     in stock_article_info.rsv_batch5%type, --预留批属性5
                         strRSV_BATCH6     in stock_article_info.rsv_batch6%type, --预留批属性6
                         strRSV_BATCH7     in stock_article_info.rsv_batch7%type, --预留批属性7
                         strRSV_BATCH8     in stock_article_info.rsv_batch8%type, --预留批属性8
                         strS_CELL_NO      in ODATA_DIVIDE_D.S_CELL_NO%type, --来源储位编码
                         strS_CONTAINER_NO in ODATA_DIVIDE_D.S_CONTAINER_NO%type, --来源内部容器
                         strCUST_NO        in ODATA_DIVIDE_D.CUST_NO%type, --客户
                         strDelvierObj     in odata_divide_d.deliver_obj%type, --配送对象
                         strUPDT_NAME      in ODATA_DIVIDE_M.UPDT_NAME%type, --更新人员
                         strAddFlag        in odata_divide_m.divide_type%type, --1：按数量回单；2：按记录数回单
                         strContainerType  in wms_defcontainer.container_type%type,
                         strOutMsg         out varchar2) is

  begin
    pkcheck_odata.P_DivideCheckDLabelNo(strEnterpriseNo,
                                        strwarehouse_no,
                                        strOWNER_NO,
                                        strS_CONTAINER_NO,
                                        strdLabelNo,
                                        strDelvierObj,
                                        strCUST_NO,
                                        strARTICLE_NO,
                                        strOutMsg);
    if (substr(strOutMsg, 1, 1) = 'N') then
      return;
    end if;

    p_Save_Odata_divide(strEnterPriseNo,
                        strwarehouse_no,
                        strOWNER_NO,
                        strDIVIDE_NO,
                        strARTICLE_NO,
                        strdLabelNo,
                        nArticleQty,
                        nREAL_QTY,
                        strDIVIDE_NAME,
                        strBATCH_NO,
                        strQuality,
                        dtProduceDate,
                        dtExpireDate,
                        strLotNo,
                        strRSV_BATCH1,
                        strRSV_BATCH2,
                        strRSV_BATCH3,
                        strRSV_BATCH4,
                        strRSV_BATCH5,
                        strRSV_BATCH6,
                        strRSV_BATCH7,
                        strRSV_BATCH8,
                        strS_CELL_NO,
                        strS_CONTAINER_NO,
                        strCUST_NO,
                        strDelvierObj,
                        strUPDT_NAME,
                        strAddFlag,
                        strContainerType,
                        strOutMsg);
    if (substr(strOutMsg, 1, 1) = 'N') then
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END p_SaveDivide;

  /*****************************************************************************************
    wyf
    20150718
    功能：RF分播回单，分播到电子标签储位，现获取电子标签储位上的箱标签，再调用p_SaveDivide做RF分播回单
  *****************************************************************************************/
  procedure p_SaveDivide_dps(strEnterPriseNo   in ODATA_DIVIDE_D.Enterprise_No%type, --企业号
                             strwarehouse_no   in ODATA_DIVIDE_D.warehouse_no%type, --仓别
                             strOWNER_NO       in ODATA_DIVIDE_D.OWNER_NO%type, --委托业主
                             strDIVIDE_NO      in ODATA_DIVIDE_D.DIVIDE_NO%type, --分播单号
                             strARTICLE_NO     in ODATA_DIVIDE_D.ARTICLE_NO%type, --商品编码
                             strDpsCellNo      in cdef_defcell_dps.cell_no%type, --电子标签储位号
                             nArticleQty       in oDATA_DIVIDE_D.article_qty%type,
                             nREAL_QTY         in ODATA_DIVIDE_D.REAL_QTY%type, --实际分播数量
                             strDIVIDE_NAME    in ODATA_DIVIDE_D.DIVIDE_NAME%type, --实际分播人
                             strBATCH_NO       in ODATA_DIVIDE_D.BATCH_NO%type, --批次号
                             strQuality        in idata_check_d.quality%type, --品质
                             dtProduceDate     in stock_article_info.produce_date%type, --生产日期
                             dtExpireDate      in stock_article_info.expire_date%type, --到期日期
                             strLotNo          in stock_article_info.lot_no%type, --批号
                             strRSV_BATCH1     in stock_article_info.rsv_batch1%type, --预留批属性1
                             strRSV_BATCH2     in stock_article_info.rsv_batch2%type, --预留批属性2
                             strRSV_BATCH3     in stock_article_info.rsv_batch3%type, --预留批属性3
                             strRSV_BATCH4     in stock_article_info.rsv_batch4%type, --预留批属性4
                             strRSV_BATCH5     in stock_article_info.rsv_batch5%type, --预留批属性5
                             strRSV_BATCH6     in stock_article_info.rsv_batch6%type, --预留批属性6
                             strRSV_BATCH7     in stock_article_info.rsv_batch7%type, --预留批属性7
                             strRSV_BATCH8     in stock_article_info.rsv_batch8%type, --预留批属性8
                             strS_CELL_NO      in ODATA_DIVIDE_D.S_CELL_NO%type, --来源储位编码
                             strS_CONTAINER_NO in ODATA_DIVIDE_D.S_CONTAINER_NO%type, --来源容器
                             strCUST_NO        in ODATA_DIVIDE_D.CUST_NO%type, --客户
                             strDelvierObj     in odata_divide_d.deliver_obj%type, --配送对象
                             strUPDT_NAME      in ODATA_DIVIDE_M.UPDT_NAME%type, --更新人员
                             strAddFlag        in odata_divide_m.divide_type%type, --1：按数量回单；2：按记录数回单
                             strContainerType  in wms_defcontainer.container_type%type,
                             strOutMsg         out varchar2) is
    v_strLabelNo           stock_label_m.label_no%type := 'N';
    v_strDcontainerNo      odata_divide_d.cust_container_no%type;
    v_strSessionID         varchar2(10);
    v_strContainerMaterial wms_defcontainer.container_material%type;
  begin
    --查询电子标签储位上正在分播的箱号，若无则取一个
    begin
      select t.label_no
        into v_strLabelNo
        from dps_stock_label t
       where t.dps_cell_no = strDpsCellNo
         and t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strwarehouse_no
         and t.status = '1';
    exception
      when no_data_found then
        if strContainerType = 'B' then
          v_strContainerMaterial := '11';
        end if;

        if strContainerType = 'C' then
          v_strContainerMaterial := '21';
        end if;
        if strContainerType = 'P' then
          v_strContainerMaterial := '31';
        end if;
        pklg_wms_base.p_get_ContainerNoBase(strEnterPriseNo,
                                            strwarehouse_no,
                                            strContainerType,
                                            strDIVIDE_NAME,
                                            'D',
                                            1,
                                            '2',
                                            v_strContainerMaterial,
                                            v_strLabelNo,
                                            v_strDcontainerNo,
                                            v_strSessionID,
                                            strOutMsg);
        if (substr(strOutMsg, 1, 1) = 'N') then
          return;
        end if;

        insert into dps_stock_label
          (warehouse_no,
           dps_cell_no,
           label_no,
           status,
           rgst_name,
           rgst_date,
           enterprise_no)
        values
          (strwarehouse_no,
           strDpsCellNo,
           v_strLabelNo,
           '1',
           strUPDT_NAME,
           sysdate,
           strEnterPriseNo);
    end;
    --RF分播回单
    p_SaveDivide(strEnterPriseNo,
                 strwarehouse_no,
                 strOWNER_NO,
                 strDIVIDE_NO,
                 strARTICLE_NO,
                 v_strLabelNo,
                 nArticleQty,
                 nREAL_QTY,
                 strDIVIDE_NAME,
                 strBATCH_NO,
                 strQuality,
                 dtProduceDate,
                 dtExpireDate,
                 strLotNo,
                 strRSV_BATCH1,
                 strRSV_BATCH2,
                 strRSV_BATCH3,
                 strRSV_BATCH4,
                 strRSV_BATCH5,
                 strRSV_BATCH6,
                 strRSV_BATCH7,
                 strRSV_BATCH8,
                 strS_CELL_NO,
                 strS_CONTAINER_NO,
                 strCUST_NO,
                 strDelvierObj,
                 strUPDT_NAME,
                 strAddFlag,
                 strContainerType,
                 strOutMsg);

    if (substr(strOutMsg, 1, 1) = 'N') then
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END p_SaveDivide_dps;

  /**********************************************************************************************8
  lich
  20140521
  功能说明：扫描拣货标签写分播单
  ***********************************************************************************************/
  procedure p_Wall_Send_odata_Divide(strEnterPriseNo  in ODATA_DIVIDE_D.Enterprise_No%type, --企业号
                                     strwarehouse_no  in ODATA_DIVIDE_D.warehouse_no%type, --仓别
                                     strDockNo        in bdef_defdock.dock_no%type, --码头
                                     strDeviceNo      in odata_divide_direct.device_no%type, --分播墙号
                                     strSLabel_No     in stock_label_m.label_no%type,
                                     strAssign_No     in odata_divide_d.assign_name%type, --预定分播人员
                                     strUserID        in bdef_defworker.worker_no%type, --系统操作人员
                                     strPrintWayBill  in odata_outstock_m.task_type%type, --是否打印快递面单，0：不打印，1：打印
                                     strPrintPackList in odata_outstock_m.task_type%type, --是否打印装箱清单，0：不打印，1：打印
                                     strPrintInVoice  in odata_outstock_m.task_type%type, --是否打印发票，0：不打印，1：打印
                                     strOutDivide_No  out odata_divide_m.divide_no%type, --返回分播单号
                                     strOutMsg        out varchar2) --返回值
   IS
    intCount   integer := 0;
    v_DivideNo ODATA_DIVIDE_D.Divide_No%type;
    --v_PrintTaskNo     job_printtask_m.task_no%type;
    --strContainerNo    ODATA_DIVIDE_D.Cust_Container_No%type;
    --v_strsContainerNo stock_label_m.container_no%type; --来源容器号
    v_Wave_No         odata_divide_d.wave_no%type;
    v_Batch_No        odata_divide_d.batch_no%type;
    v_Device_No       odata_divide_m.device_no%type := 'N';
    v_SDevice_No      odata_divide_m.device_no%type := 'N';
    v_Deliver_Obj     odata_divide_d.deliver_obj%type := 'N';
    v_nStartLimit     DEVICE_DIVIDE_M.Start_Limit%type;
    v_Task_No         job_printtask_m.task_no%type := 'N';
    v_D_Label_No      stock_label_m.label_no%type;
    v_strCurrDivideNo  ODATA_DIVIDE_D.Divide_No%type;--当前设备对应分播单号
  BEGIN
    strOutMsg := 'N|[p_Wall_Send_odata_Divide]';

    --判断分播墙是否需要拣货完成
    begin
      select ddm.start_limit
        into v_nStartLimit
        from DEVICE_DIVIDE_M DDM
       WHERE DDM.ENTERPRISE_NO = strEnterPriseNo
         and DDM.WAREHOUSE_NO = strwarehouse_no
         and ddm.device_no = strDeviceNo;
    exception
      when no_data_found then
        strOutMsg := 'N|' || strDeviceNo || '分播设备不存在设备表中'; --还有拣货单未发，不能分播
        return;
    end;

    --if v_nStartLimit = 1 then
    --强制判断，否则无法按分播设备建单

    --判断该分播单是否能发单
    select count(*)
      into intCount
      from odata_outstock_direct ood
     where ood.enterprise_no = strEnterPriseNo
       and ood.warehouse_no = strwarehouse_no
       and ood.status < '13'
       and exists (select 'x'
              from stock_label_m slm
             where slm.warehouse_no = strwarehouse_no
               and slm.enterprise_no = strEnterPriseNo
               and (slm.label_no = strSLabel_No or slm.source_no=strSLabel_No)
               and slm.wave_no = ood.wave_no
               and slm.batch_no = ood.batch_no
               and slm.device_no = ood.device_no);

    if intCount > 0 then
      strOutMsg := 'N|[还有拣货单未发，不能分播]'; --还有拣货单未发，不能分播
      return;
    end if;

    --判断该分播单是否能发单
    select count(*)
      into intCount
      from odata_outstock_d ood
     where ood.enterprise_no = strEnterPriseNo
       and ood.warehouse_no = strwarehouse_no
       and ood.status < '13'
       and exists (select 'x'
              from stock_label_m slm
             where slm.warehouse_no = strwarehouse_no
               and slm.enterprise_no = strEnterPriseNo
               and (slm.label_no = strSLabel_No or slm.source_no=strSLabel_No)
               and slm.wave_no = ood.wave_no
               and slm.batch_no = ood.batch_no
               and slm.device_no = ood.device_no);

    if intCount > 0 then
      strOutMsg := 'N|[还有拣货单未回，不能分播]'; --还有拣货单未回，不能分播
      return;
    end if;
    --end if;

    --获取该分播单对应的标签号
    begin
      select distinct /*t.container_no,*/ t.device_no, t.wave_no, t.batch_no
        into /*v_strsContainerNo,*/ v_SDevice_No, v_Wave_No, v_Batch_No
        from stock_label_m t
       where t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strwarehouse_no
         and (t.label_no = strSLabel_No or t.source_no=strSLabel_No)
         and t.status = CLABELSTATUS.PICK_END;
    exception
      when no_data_found then
        strOutMsg := 'N|[该分播单对应的标签号不存在]';
        return;
    end;

    begin
       select divide_no into v_strCurrDivideNo from odata_divide_m oom where oom.enterprise_no=strEnterPriseNo
          and oom.warehouse_no=strwarehouse_no and oom.device_no=strDeviceNo;
    exception when no_data_found then
        v_strCurrDivideNo := 'N';
    end;

    --判断是否存在分播设备
    begin
      select distinct odm.device_no, odm.divide_no
        into v_Device_No, v_DivideNo
        from odata_divide_d ood, odata_divide_m odm
       where odm.enterprise_no = ood.enterprise_no
         and odm.warehouse_no = ood.warehouse_no
         and odm.divide_no = ood.divide_no
         and ood.enterprise_no = strEnterPriseNo
         and ood.warehouse_no = strwarehouse_no
         and ood.status < '13'
         --Modify BY QZH AT 2016-7-25
         and ood.wave_no=v_Wave_No
         and ood.batch_no=v_Batch_No
        /* and exists (select 'x'
                from stock_label_d sld
               where sld.warehouse_no = ood.warehouse_no
                 and sld.enterprise_no = ood.enterprise_no
                 and sld.container_no = v_strsContainerNo
                 and sld.wave_no = ood.wave_no
                 and sld.batch_no = ood.batch_no
                 and sld.deliver_obj = ood.deliver_obj)*/;
      --v_Device_No 为N，表示自动建的分播单
      if v_Device_No <> strDeviceNo and v_Device_No <> 'N' then
        strOutMsg := 'N|已在设备号' || v_Device_No || '扫描过相同配送对象';
        return;
      end if;
    exception
      when no_data_found then
        v_DivideNo := 'N';
      when others then
        strOutMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
        return;
    end;

    if v_strCurrDivideNo<>'N' and v_strCurrDivideNo<>v_DivideNo then
        strOutMsg := 'N|此设备已有其他分播单在分播';
        return;
    end if;


    --已有分播单
    if v_DivideNo <> 'N' then
      update odata_divide_m odm
         set odm.device_no = strDeviceNo,
             odm.updt_name = strUserID,
             odm.updt_date = sysdate
       where odm.enterprise_no = strEnterPriseNo
         and odm.warehouse_no = strwarehouse_no
         and odm.divide_no = v_DivideNo
         and odm.device_no = 'N';
      strOutDivide_No := v_DivideNo;
      strOutMsg       := 'Y|';
      return;
    end if;

    for curDivideDirect in (select d.*,olb.owner_no real_owner_no,
                                   oem.print_bill_flag       Print_InVoice_Flag,
                                   oem.ENVOICE_PRINT_STATUS  Print_InVoiceCount,
                                   OLB.PRINT_PACKLIST        Print_PackList_Flag,
                                   oem.PACKLIST_PRINT_STATUS Print_PackListCount,
                                   OLB.PRINT_WAYBILL         Print_WayBill_Flag,
                                   oem.waybill_print_status  Print_WayBillCount,
                                   OLB.INDUSTRY_FLAG,
                                   OEM.SHIPPER_DELIVER_NO
                              from odata_divide_direct d,
                                   odata_exp_m         oem,
                                   ODATA_LOCATE_BATCH  OLB
                             where d.WAREHOUSE_NO = strwarehouse_no
                               and d.enterprise_no = strEnterPriseNo
                               and d.wave_no = v_Wave_No
                               and d.batch_no = v_Batch_No
                               and d.device_no = v_SDevice_No
                               and d.status = '10'
                               and oem.enterprise_no = d.enterprise_no
                               and oem.warehouse_no = d.warehouse_no
                               and oem.exp_type = d.exp_type
                               and oem.exp_no = d.exp_no
                               and olb.enterprise_no = d.enterprise_no
                               and olb.warehouse_no = d.warehouse_no
                               and olb.wave_no = d.wave_no
                               and olb.batch_no = d.batch_no

                             order by d.dps_cell_no,d.deliver_obj, d.exp_no) loop
      intCount := intCount + 1;

      if intCount = 1 then

        --写分播单头档
        PKOBJ_ODATA_DIVIDE.P_Insert_Odata_Divide_M(strEnterPriseNo,
                                                   strwarehouse_no,
                                                   --curDivideDirect.Owner_No,
                                                   curDivideDirect.Real_Owner_No,
                                                   trunc(sysdate),
                                                   'C',
                                                   curDivideDirect.source_type,
                                                   curDivideDirect.Wave_No,
                                                   curDivideDirect.Batch_No,
                                                   strDeviceNo, --curDivideDirect.device_no,
                                                   curDivideDirect.Exp_Date,
                                                   strUserID,
                                                   v_DivideNo,
                                                   strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
      end if;

      if curDivideDirect.Industry_Flag = '2' then
        --电商
        v_D_Label_No := curDivideDirect.Shipper_Deliver_No;
      else
        v_D_Label_No := curDivideDirect.Deliver_Obj;
      end if;

      --写分播单明细
      PKOBJ_ODATA_DIVIDE.P_Insert_Odata_Divide_D(strEnterPriseNo,
                                                 strwarehouse_no,
                                                 curDivideDirect.Owner_No,
                                                 curDivideDirect.Batch_No,
                                                 v_DivideNo,
                                                 curDivideDirect.Source_No,
                                                 curDivideDirect.Divide_Id,
                                                 curDivideDirect.Operate_Date,
                                                 curDivideDirect.Cust_No,
                                                 curDivideDirect.Sub_Cust_No,
                                                 curDivideDirect.Exp_Type,
                                                 curDivideDirect.Exp_No,
                                                 curDivideDirect.Wave_No,
                                                 curDivideDirect.Article_No,
                                                 curDivideDirect.Article_Id,
                                                 curDivideDirect.Packing_Qty,
                                                 curDivideDirect.Article_Qty,
                                                 curDivideDirect.s_Cell_No,
                                                 curDivideDirect.s_Cell_Id,
                                                 curDivideDirect.s_Container_No,
                                                 curDivideDirect.Deliver_Area,
                                                 curDivideDirect.Line_No,
                                                 curDivideDirect.Trunck_Cell_No,
                                                 curDivideDirect.Check_Chute_No,
                                                 curDivideDirect.Deliver_Obj,
                                                 curDivideDirect.deliverobj_order,
                                                 curDivideDirect.Outstock_Date,
                                                 strAssign_No,
                                                 curDivideDirect.Dps_Cell_No,
                                                 curDivideDirect.a_Sorter_Chute_No,
                                                 curDivideDirect.Exp_Date,
                                                 v_D_Label_No,
                                                 strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --更新分播指示
      update odata_divide_direct d
         set d.status = '13'
       where d.status = '10'
         and d.warehouse_no = curDivideDirect.Warehouse_No
         and d.enterprise_no = curDivideDirect.Enterprise_No
         and d.owner_no = curDivideDirect.Owner_No
         and d.source_no = curDivideDirect.Source_No
         and d.divide_id = curDivideDirect.Divide_Id;

      if sql%rowcount <= 0 then
        strOutMsg := 'N|Source_No:' || curDivideDirect.Source_No ||
                     ',Divide_id:' || curDivideDirect.Divide_Id;
        return;
      end if;

      v_Task_No := 'N';

      --按配送对象打印发票
      if v_Deliver_Obj <> curDivideDirect.Deliver_Obj and
         curDivideDirect.Print_Invoicecount <= '0' and
         curDivideDirect.Print_Invoice_Flag > '0' then
        if strPrintInVoice = '1' or
           curDivideDirect.Print_Invoice_Flag = '2' then
          --分播环节打发票
          PKLG_WMS_Public.p_Insert_SpecialReportTask(strEnterPriseNo, --企业号
                                                     strWarehouse_No, --仓别号
                                                     CREPORT_TYPE.TYPE_INV, --报表类型 WAY-面单;INV-发票;BOX-装箱清
                                                     curDivideDirect.Exp_No, --源单号
                                                     strDockNo, --码头或工作站号
                                                     '0', --补印标识
                                                     strUserId, --操作人员
                                                     --返回参数
                                                     v_Task_No, --打印任务单号 如外部生成 则传外部生成打印任务号,否则传'N'
                                                     strOutMsg);
          if instr(strOutMsg, 'N', 1, 1) = 1 then
            return;
          end if;
        end if;
      end if;

      v_Task_No := 'N';
      --按配送对象打印清单
      if v_Deliver_Obj <> curDivideDirect.Deliver_Obj and
         curDivideDirect.Print_Packlistcount <= 0 then
        if curDivideDirect.Print_Packlist_Flag = '2' or
           strPrintPackList = '1' then
          --分播环节打清单

          PKLG_WMS_Public.p_Insert_SpecialReportTask(strEnterPriseNo, --企业号
                                                     strWarehouse_No, --仓别号
                                                     CREPORT_TYPE.TYPE_BOX, --报表类型 WAY-面单;INV-发票;BOX-装箱清
                                                     curDivideDirect.exp_no, --源单号
                                                     strDockNo, --码头或工作站号
                                                     '0', --补印标识
                                                     strUserId, --操作人员
                                                     --返回参数
                                                     v_Task_No, --打印任务单号 如外部生成 则传外部生成打印任务号,否则传'N'
                                                     strOutMsg);
          if instr(strOutMsg, 'N', 1, 1) = 1 then
            return;
          end if;
        end if;
      end if;

      v_Task_No := 'N';
      --按配送对象打印面单
      if v_Deliver_Obj <> curDivideDirect.Deliver_Obj and
         curDivideDirect.Print_Waybillcount <= '0' then
        if curDivideDirect.Print_Waybill_Flag = '2' or
           strPrintWayBill = '1' then
          --分播环节打面单

          PKLG_WMS_Public.p_Insert_SpecialReportTask(strEnterPriseNo, --企业号
                                                     strWarehouse_No, --仓别号
                                                     CREPORT_TYPE.TYPE_WAY, --报表类型 WAY-面单;INV-发票;BOX-装箱清
                                                     curDivideDirect.exp_no, --源单号
                                                     strDockNo, --码头或工作站号
                                                     '0', --补印标识
                                                     strUserId, --操作人员
                                                     --返回参数
                                                     v_Task_No, --打印任务单号 如外部生成 则传外部生成打印任务号,否则传'N'
                                                     strOutMsg);
          if instr(strOutMsg, 'N', 1, 1) = 1 then
            return;
          end if;
        end if;
      end if;

      --单据状态跟踪
      if v_Deliver_Obj <> curDivideDirect.Deliver_Obj then
        PKOBJ_ODISPATCH.P_Insert_Odata_Exp_Trace(curDivideDirect.Enterprise_No,
                                                 curDivideDirect.Warehouse_No,
                                                 curDivideDirect.Exp_No,
                                                 COdataExpStatus.ExpTracPartDivide,
                                                 strUserID,
                                                 strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
      end if;

      v_Deliver_Obj := curDivideDirect.Deliver_Obj;
    end loop;

    if intCount = 0 then
      strOutMsg := 'N|[该标签号不存在]';
      return;
    end if;
    strOutDivide_No := v_DivideNo;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END p_Wall_Send_odata_Divide;

  /*****************************************************************************************
    lich
    20150529
    功能：分播墙回单
  *****************************************************************************************/
  procedure p_Wall_Save_odata_Divide(strEnterPriseNo in ODATA_DIVIDE_D.Enterprise_No%type, --企业号
                                     strWarehouseNo  in ODATA_DIVIDE_D.warehouse_no%type, --仓别
                                     strDivide_No    in ODATA_DIVIDE_M.Divide_No%type, --分播单号
                                     strArticleNo    in ODATA_DIVIDE_D.ARTICLE_NO%type, --商品编码
                                     strDivideName   in ODATA_DIVIDE_D.DIVIDE_NAME%type, --实际分播人
                                     strUpdtName     in ODATA_DIVIDE_M.UPDT_NAME%type, --更新人员
                                     strDpsCellNo    out ODATA_DIVIDE_D.DPS_CELL_NO%type, --分播储位
                                     strFinishFlag   out ODATA_DIVIDE_M.STATUS%type, --分播单完成标志：Y-完成；N—未完成
                                     strOutMsg       out varchar2) --返回值
   is
    intcount     integer;
    v_RealQTY    STOCK_CONTENT.QTY%TYPE;
    v_Exp_No     odata_exp_m.exp_no%type;
    v_Exp_Type   odata_exp_m.exp_type%type;
    v_D_Label_No stock_label_m.label_no%type; --目的标签
  begin
    strOutMsg := 'N|[p_Wall_Save_odata_Divide]'; --p_Wall_Save_odata_Divide
    strFinishFlag:='N';

    intcount  := 0;
    --numRealQty := nRealQty;

    for Divide_INFO in (SELECT bda.qmin_operate_packing,
                               d.owner_no,
                               d.deliver_obj,
                               d.article_qty,
                               d.batch_no,
                               d.s_cell_no,
                               d.s_container_no,
                               d.cust_no,
                               d.divide_no,
                               d.row_id,
                               d.dps_cell_no,
                               d.exp_no,
                               d.exp_type,
                               olb.industry_flag,
                               oem.shipper_deliver_no,
                               sai.*
                          from odata_divide_m     m,
                               odata_divide_d     d,
                               bdef_defarticle    bda,
                               stock_article_info sai,
                               odata_locate_batch olb,
                               odata_exp_m        oem
                         where olb.enterprise_no = d.enterprise_no
                           and olb.warehouse_no = d.warehouse_no
                          -- and olb.owner_no = d.owner_no
                           and olb.wave_no = d.wave_no
                           and olb.batch_no = d.batch_no
                           and oem.enterprise_no = d.enterprise_no
                           and oem.warehouse_no = d.warehouse_no
                           and oem.exp_type = d.exp_type
                           and oem.exp_no = d.exp_no
                           and m.enterprise_no = d.enterprise_no
                           and m.divide_no = d.divide_no
                           and m.warehouse_no = d.warehouse_no
                           and d.enterprise_no = bda.enterprise_no
                           and d.article_no = bda.article_no
                           and d.enterprise_no = sai.enterprise_no
                           and d.article_no = sai.article_no
                           and d.article_id = sai.article_id
                           and m.warehouse_no = strWarehouseNo
                           and m.enterprise_no = strEnterPriseNo
                           and m.divide_no = strDivide_No
                           and d.article_no = strArticleNo
                           and d.article_qty - d.real_qty > 0
                           and d.status < '13'
                         order by d.dps_cell_no,d.deliver_obj
                           for update) loop

      v_RealQTY := Divide_INFO.Qmin_Operate_Packing;

      intcount     := intcount + 1;
      strDpsCellNo := Divide_INFO.Dps_Cell_No;
      v_Exp_No     := Divide_INFO.Exp_No;
      v_Exp_Type   := Divide_INFO.Exp_Type;

      if Divide_INFO.Industry_Flag = '2' then
        --电商
        v_D_Label_No := Divide_INFO.Shipper_Deliver_No;
      else
        v_D_Label_No := Divide_INFO.Deliver_Obj;
      end if;

      --分播回单
      PKLG_ODATA_DIVIDE.p_Save_Odata_divide(strEnterPriseNo,
                                            strWarehouseNo,
                                            Divide_INFO.Owner_No,
                                            strDivide_No,
                                            strArticleNo,
                                            v_D_Label_No, --目的标签
                                            Divide_INFO.Article_Qty,
                                            v_RealQTY,
                                            strDivideName,
                                            Divide_INFO.Batch_No,
                                            Divide_INFO.Quality,
                                            Divide_INFO.Produce_Date,
                                            Divide_INFO.Expire_Date,
                                            Divide_INFO.Lot_No,
                                            Divide_INFO.Rsv_Batch1,
                                            Divide_INFO.Rsv_Batch2,
                                            Divide_INFO.Rsv_Batch3,
                                            Divide_INFO.Rsv_Batch4,
                                            Divide_INFO.Rsv_Batch5,
                                            Divide_INFO.Rsv_Batch6,
                                            Divide_INFO.Rsv_Batch7,
                                            Divide_INFO.Rsv_Batch8,
                                            Divide_INFO.s_Cell_No,
                                            Divide_INFO.s_Container_No,
                                            Divide_INFO.Cust_No,
                                            Divide_INFO.Deliver_Obj,
                                            strUpdtName,
                                            '3',
                                            'B',
                                            strOutMsg);

      if (substr(strOutMsg, 1, 1) = 'N') then
        return;
      end if;
      /*
        if Divide_INFO.Exp_Status = '16' then
          strOutMsg := 'N|订单' || Divide_INFO.Exp_No || '已取消！';
          return;
        end if;
      */
      --一次扫描只执行一次
      exit;
    End loop;

    if intcount = 0 then
      strOutMsg := 'N|没有找到该商品的分播信息或已经分播完成，请核对'; --找不到分播明细
      return;
    end if;

    select count(1)
      into intcount
      from odata_divide_d odd
     where odd.enterprise_no = strEnterPriseNo
       and odd.warehouse_no = strWarehouseNo
       and odd.divide_no = strDivide_No
       and odd.status < '13';

    if intcount <= 0 then
      strOutMsg:='Y|分播完成!';
      strFinishFlag := 'Y';
    end if;

    --strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_Wall_Save_odata_Divide;
  /*****************************************************************************************
    lich
    20150529
    功能：分播墙转病单
  *****************************************************************************************/
  procedure p_Wall_Sure_odata_Divide(strEnterPriseNo in ODATA_DIVIDE_D.Enterprise_No%type, --企业号
                                     strWarehouseNo  in ODATA_DIVIDE_D.warehouse_no%type, --仓别
                                     strDeviceNo     in ODATA_DIVIDE_M.device_no%type, --分播组号
                                     strDivideName   in ODATA_DIVIDE_D.DIVIDE_NAME%type, --实际分播人
                                     strUpdtName     in ODATA_DIVIDE_M.UPDT_NAME%type, --更新人员
                                     strOutMsg       out varchar2) --返回值
   is
    v_Divide_NO odata_divide_m.Divide_No%type;
    v_Exp_No    odata_exp_m.exp_no%type := 'N';
    v_D_Label   stock_label_m.label_no%type;
    v_Count     integer := 0;
  begin
    strOutMsg := 'N|[p_Wall_Sure_odata_Divide]'; --p_Wall_Sure_odata_Divide

    begin
      select m.divide_no
        into v_Divide_NO
        from odata_divide_m m
       where m.warehouse_no = strWarehouseNo
         and m.enterprise_no = strEnterPriseNo
         and m.status < '13'
         and m.device_no = strDeviceNo;
    exception
      when no_data_found then
        strOutMsg := 'N|' || strDeviceNo || '该设备没有未完成的分播任务!';
        return;
      when others then
        strOutMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
        return;
    end;

    select count(*)
      into v_Count
      from odata_outstock_direct ood
     where ood.enterprise_no = strEnterPriseNo
       and ood.warehouse_no = strWarehouseNo
       and ood.status < '13'
       and exists (select 'x'
              from odata_divide_m odm, odata_divide_d odd
             where odm.warehouse_no = strWarehouseNo
               and odm.enterprise_no = ood.enterprise_no
               and odm.warehouse_no = ood.warehouse_no
               and odm.divide_no = odd.divide_no
               and odm.enterprise_no = strEnterPriseNo
               and odm.status < '13'
               and odm.device_no = strDeviceNo
               and odd.enterprise_no = ood.enterprise_no
               and odd.warehouse_no = ood.warehouse_no
               and odd.exp_type = ood.exp_type
               and odd.exp_no = ood.exp_no);

    if v_Count > 0 then
      strOutMsg := 'N|' || strDeviceNo || '该设备还有任务未拣货发单!';
      return;
    end if;

    select count(*)
      into v_Count
      from odata_outstock_d ood
     where ood.enterprise_no = strEnterPriseNo
       and ood.warehouse_no = strWarehouseNo
       and ood.status < '13'
       and exists (select 'x'
              from odata_divide_m odm, odata_divide_d odd
             where odm.warehouse_no = strWarehouseNo
               and odm.enterprise_no = ood.enterprise_no
               and odm.warehouse_no = ood.warehouse_no
               and odm.divide_no = odd.divide_no
               and odm.enterprise_no = strEnterPriseNo
               and odm.status < '13'
               and odm.device_no = strDeviceNo
               and odd.enterprise_no = ood.enterprise_no
               and odd.warehouse_no = ood.warehouse_no
               and odd.exp_type = ood.exp_type
               and odd.exp_no = ood.exp_no);

    if v_Count > 0 then
      strOutMsg := 'N|' || strDeviceNo || '该设备还有任务未拣货货回单!';
      return;
    end if;

    for Divide_INFO in (SELECT d.owner_no,
                               d.deliver_obj,
                               d.exp_type,
                               d.exp_no,
                               m.divide_no,
                               d.article_qty,
                               (d.article_qty - d.real_qty) diff_qty,
                               d.batch_no,
                               d.s_cell_no,
                               d.s_container_no,
                               d.cust_no,
                               d.dps_cell_no,
                               d.cust_container_no,
                               sai.*,
                               olb.industry_flag,
                               oem.shipper_deliver_no
                          from odata_divide_m     m,
                               odata_divide_d     d,
                               stock_article_info sai,
                               odata_exp_m        oem,
                               odata_locate_batch olb
                         where oem.enterprise_no = d.enterprise_no
                           and oem.warehouse_no = d.warehouse_no
                           and oem.exp_type = d.exp_type
                           and oem.exp_no = d.exp_no
                           and olb.enterprise_no = d.enterprise_no
                           and olb.warehouse_no = d.warehouse_no
                           and olb.owner_no = d.owner_no
                           and olb.wave_no = d.wave_no
                           and olb.batch_no = d.batch_no

                           and m.enterprise_no = d.enterprise_no
                           and m.divide_no = d.divide_no
                           and m.warehouse_no = d.warehouse_no
                           and d.enterprise_no = sai.enterprise_no
                           and d.article_no = sai.article_no
                           and d.article_id = sai.article_id
                           and m.warehouse_no = strWarehouseNo
                           and m.enterprise_no = strEnterPriseNo
                           and m.divide_no = v_Divide_NO
                           and d.article_qty - d.real_qty > 0
                           and d.status < '13'
                         order by d.exp_type, d.exp_no, d.deliver_obj
                           for update) loop

      if v_Exp_No <> Divide_INFO.Exp_No then
        --转病单
        PKLG_ODATA_EXPCANCEL.P_TurnOdataExpCancel(strEnterPriseNo,
                                                  strWarehouseNo,
                                                  Divide_INFO.Owner_No,
                                                  Divide_INFO.Exp_No,
                                                  '4', --分播转病单
                                                  strDivideName,
                                                  strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;

        --单据状态跟踪，转病单
        PKOBJ_ODISPATCH.P_Insert_Odata_Exp_Trace(strEnterPriseNo,
                                                 strWarehouseNo,
                                                 Divide_INFO.Exp_No,
                                                 COdataExpStatus.ExpTracAllIllness,
                                                 strDivideName,
                                                 strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;

        --标签跟踪
        update stock_label_m slm
           set slm.status    = 'C0',
               slm.updt_name = strDivideName,
               slm.updt_date = sysdate
         where slm.enterprise_no = strEnterPriseNo
           and slm.warehouse_no = strWarehouseNo
           and slm.container_no = Divide_INFO.cust_container_no;
      end if;

      if Divide_INFO.Industry_Flag = '2' then
        --电商
        v_D_Label := Divide_INFO.Shipper_Deliver_No;
      else
        v_D_Label := Divide_INFO.Deliver_Obj;
      end if;

      --分播回单
      PKLG_ODATA_DIVIDE.p_Save_Odata_divide(strEnterPriseNo,
                                            strWarehouseNo,
                                            Divide_INFO.Owner_No,
                                            Divide_INFO.divide_no,
                                            Divide_INFO.Article_No,
                                            v_D_Label,
                                            Divide_INFO.Diff_Qty,
                                            0,
                                            strDivideName,
                                            Divide_INFO.Batch_No,
                                            Divide_INFO.Quality,
                                            Divide_INFO.Produce_Date,
                                            Divide_INFO.Expire_Date,
                                            Divide_INFO.Lot_No,
                                            Divide_INFO.Rsv_Batch1,
                                            Divide_INFO.Rsv_Batch2,
                                            Divide_INFO.Rsv_Batch3,
                                            Divide_INFO.Rsv_Batch4,
                                            Divide_INFO.Rsv_Batch5,
                                            Divide_INFO.Rsv_Batch6,
                                            Divide_INFO.Rsv_Batch7,
                                            Divide_INFO.Rsv_Batch8,
                                            Divide_INFO.s_Cell_No,
                                            Divide_INFO.s_Container_No,
                                            Divide_INFO.Cust_No,
                                            Divide_INFO.Deliver_Obj,
                                            strUpdtName,
                                            '3',
                                            'B',
                                            strOutMsg);

      if (substr(strOutMsg, 1, 1) = 'N') then
        return;
      end if;

      v_Exp_No := Divide_INFO.Exp_No;

    End loop;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_Wall_Sure_odata_Divide;

end PKLG_ODATA_DIVIDE;

/

