create package body        PKOBJ_ODATA IS
  ------------------------------------------------------------------------------------------------------------------------------发单
  /*****************************************************************************************
     功能：写出货下架单头档
     Modify BY QZH AT 2016-5-24 RF索单的打印状态为0
  *****************************************************************************************/
  procedure P_O_WriteOutStockHead(strEnterPriseNo in odata_outstock_m.enterprise_no%type,
                                  v_warehouse_no  in odata_outstock_m.warehouse_no%type, --仓别
                                  strOwnerNo      in odata_outstock_m.owner_no%type, --货主
                                  strWaveNo       in odata_outstock_m.wave_no%type,
                                  strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                  strPickType     in odata_outstock_m.pick_type%type, --拣货方式
                                  strBatchNo      in odata_outstock_m.batch_no%type, --批次
                                  strOperateType  in odata_outstock_m.operate_type%type, --作业类型
                                  strStatus       in odata_outstock_m.status%type, --作业状态
                                  strUserID       in odata_outstock_m.rgst_name%type, --员工ID
                                  strTaskType     in odata_outstock_m.task_type%type, --发单方式
                                  strPriorty      in odata_outstock_m.priority%type, --优先级
                                  strExp_Date     in odata_outstock_m.operate_date%type, --操作日期
                                  strOutStockType in odata_outstock_m.outstock_type%type, --出货类型
                                  strDockNo       in odata_outstock_m.dock_no%type, --码头编码
                                  strSourceType   in odata_outstock_m.source_type%type, --作业类型
                                  strPrintType    in odata_outstock_m.print_type%type,
                                  strPrintStatus  in odata_outstock_m.print_status%type,
                                  strTaskGetType  in odata_outstock_m.task_get_type%type,
                                  strMemo         in odata_outstock_m.memo%type,
                                  strOutMsg       out varchar2) --返回值
   is
  begin
    strOutMsg := 'N|[P_O_WriteOutStockHead]';

    INSERT INTO odata_outstock_m
      (enterprise_no,
       warehouse_no,
       owner_no,
       OUTSTOCK_NO,
       PICK_TYPE,
       OPERATE_DATE,
       BATCH_NO,
       OPERATE_TYPE,
       STATUS,
       RGST_NAME,
       RGST_DATE,
       TASK_TYPE,
       PRIORITY,
       EXP_DATE,
       OUTSTOCK_TYPE,
       PRINT_STATUS,
       DOCK_NO,
       SOURCE_TYPE,
       print_type,
       wave_no,
       task_get_type,
       memo)
    VALUES
      (strEnterPriseNo,
       v_warehouse_no,
       strOwnerNo,
       strOutStockNo,
       strPickType,
       trunc(sysdate),
       strBatchNo,
       strOperateType,
       strStatus,
       strUserID,
       sysdate,
       strTaskType,
       strPriorty,
       strExp_Date,
       strOutStockType,
       strPrintStatus,
       strDockNo,
       strSourceType,
       strPrintType,
       strWaveNo,
       strTaskGetType,
       strMemo);
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E22101]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_WriteOutStockHead;

  /*****************************************************************************************
     功能：写出货下架单明细
     如果是混合类型 则 下架明细中的s_container_no为'N'
  *****************************************************************************************/
  procedure P_O_WriteOutStockItem(strEnterPriseNo in odata_outstock_m.enterprise_no%type,
                                  v_warehouse_no  in odata_outstock_d.warehouse_no%type, --仓别
                                  strOutStockNo   in odata_outstock_d.outstock_no%type, --下架单号
                                  strAssignName   in odata_outstock_d.assign_name%type, --计划作业人员
                                  strDirectSerial in odata_outstock_d.divide_id%type, --指示序列
                                  strOperateDate  in odata_outstock_m.operate_date%type, --操作日期
                                  strPickType     in odata_outstock_m.pick_type%type, --0：摘果；1：播种
                                  strOutMsg       out varchar2) --返回值
   is
  strOperateType  odata_outstock_m.operate_type%type; --作业类型
  begin
    strOutMsg := 'N|[P_O_WriteOutStockItem]';

    select oom.operate_type into strOperateType
      from odata_outstock_m oom
     where oom.warehouse_no = v_warehouse_no
       and oom.enterprise_no = strEnterPriseNo
       and oom.outstock_no = strOutStockNo;

    insert into odata_outstock_d
      (enterprise_no,
       warehouse_no,
       OWNER_NO,
       OUTSTOCK_NO,
       DIVIDE_ID,
       OPERATE_DATE,
       BATCH_NO,
       EXP_TYPE,
       EXP_NO,
       EXP_DATE,
       wave_no,
       CUST_NO,
       SUB_CUST_NO,
       ARTICLE_NO,
       ARTICLE_ID,
       PACKING_QTY,
       S_CELL_NO,
       S_CELL_ID,
       S_CONTAINER_NO,
       D_CELL_NO,
       D_CELL_ID,
       D_CONTAINER_NO,
       ARTICLE_QTY,
       REAL_QTY,
       DELIVER_AREA,
       STATUS,
       LINE_NO,
       A_SORTER_CHUTE_NO,
       DELIVER_OBJ,
       ASSIGN_NAME,
       device_no,
       CHECK_CHUTE_NO,
       DPS_CELL_NO,
       LABEL_NO,
       STOCK_TYPE,
       deliverobj_order)
      select t.enterprise_no,
             t.warehouse_no,
             t.owner_no,
             strOutStockNo,
             t.direct_serial,
             t.OPERATE_DATE,
             t.batch_no,
             T.EXP_TYPE,
             t.exp_no,
             t.exp_date,
             t.WAVE_NO,
             t.CUST_NO,
             t.SUB_CUST_NO,
             t.article_no,
             t.ARTICLE_ID,
             t.PACKING_QTY,
             t.S_CELL_NO,
             t.S_CELL_ID,
             (case when strOperateType = COPERATE_TYPE.TYPE_MIX then 'N' else t.s_container_no end),
             T.D_CELL_NO,
             T.D_CELL_ID,
             'N',
             t.LOCATE_QTY,
             0,
             NVL(t.DELIVER_AREA, 'N') DELIVER_AREA,
             t.STATUS,
             t.LINE_NO,
             t.A_SORTER_CHUTE_NO,
             t.DELIVER_OBJ,
             strAssignName,
             t.device_no,
             t.CHECK_CHUTE_NO,
             t.DPS_CELL_NO,
             t.LABEL_NO,
             t.STOCK_TYPE,
             t.deliverobj_order
        from odata_outstock_dIRECT t
       where t.warehouse_no = v_warehouse_no
         and t.enterprise_no = strEnterPriseNo
         and t.DIRECT_SERIAL = strDirectSerial
         and t.status = '10'
         and t.operate_date = strOperateDate;
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E22102]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_WriteOutStockItem;

  /*****************************************************************************************
     功能：修改出货下架指示
  *****************************************************************************************/
  procedure P_O_UpdatedOmOutStockDirect(strEnterPriseNo in odata_outstock_m.enterprise_no%type,
                                        v_warehouse_no  in odata_outstock_m.warehouse_no%type, --仓别
                                        strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                        strUserID       in odata_outstock_m.rgst_name%type, --员工ID
                                        strOutMsg       out varchar2) --返回值
   is
  begin
    strOutMsg := 'N|[P_O_UpdatedOmOutStockDirect]';

    update odata_outstock_dIRECT t
       set UPDT_DATE = SYSDATE, t.status = '13', t.updt_name = strUserID
     where t.warehouse_no = v_warehouse_no
       and t.enterprise_no = strEnterPriseNo
       and t.status = '10'
       and t.DIRECT_SERIAL in
           (select d.divide_id
              from odata_outstock_d d
             where d.outstock_no = strOutStockNo
               and d.enterprise_no = strEnterPriseNo);
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E22103]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_UpdatedOmOutStockDirect;

  ------------------------------------------------------------------------------------------------------------------------------回单

  /*****************************************************************************************
     功能：修改出货下架明细信息    --按 下架明细序号回单
  *****************************************************************************************/
  procedure P_O_UpdatedOmOutStockItem(strEnterPriseNo in odata_outstock_d.enterprise_no%type,
                                      v_warehouse_no  in odata_outstock_d.warehouse_no%type, --仓别
                                      strOutStockNo   in odata_outstock_d.outstock_no%type, --下架单号
                                      strRealQty      in odata_outstock_d.real_qty%type,
                                      strScontainerNo in odata_outstock_d.s_container_no%type,
                                      strOwnerNo      in odata_outstock_d.owner_no%type,
                                      strDivideId     in odata_outstock_d.divide_id%type,
                                      strOutstockName in odata_outstock_d.outstock_name%type, --出货员工ID
                                      strInstockName  in odata_outstock_d.instock_name%type, --出货员工ID
                                      strStatus       in odata_outstock_d.status%type, --状态
                                      strOutMsg       out varchar2) --返回值
   is
    v_strcContainerNo odata_outstock_d.s_container_no%type;
  begin
    strOutMsg := 'N|[P_O_UpdatedOmOutStockItem]';

    if strScontainerNo is null then
      v_strcContainerNo := 'N';
    else
      v_strcContainerNo := strScontainerNo;
    end if;

    ------------------更新下架单明细信息------------------
    update odata_outstock_d ood
       set ood.outstock_name  = strOutstockName,
           ood.outstock_date  = sysdate,
           ood.instock_name   = strInstockName,
           ood.instock_date   = sysdate,
           ood.real_qty       = nvl(ood.real_qty, 0) + strRealQty,
           ood.s_container_no = v_strcContainerNo,
           ood.status = CASE
                          WHEN OOD.ARTICLE_QTY <=
                               NVL(OOD.REAL_QTY, 0) + strRealQty THEN
                           '13'
                          WHEN NOT EXISTS
                           (SELECT 'x'
                                  FROM stock_label_d B
                                 WHERE B.warehouse_no = OOD.warehouse_no
                                   and b.enterprise_no = ood.enterprise_no
                                   AND B.SOURCE_NO = OOD.OUTSTOCK_NO
                                   AND B.DIVIDE_ID = OOD.DIVIDE_ID
                                   AND (B.STATUS = '40' OR B.STATUS = '50')) THEN
                           '13'
                          ELSE
                           STATUS
                        END
     where ood.warehouse_no = v_warehouse_no
       and ood.enterprise_no = strEnterPriseNo
       and ood.owner_no = strOwnerNo
       and ood.outstock_no = strOutStockNo
       and ood.divide_id = strDivideId
       and ood.status < strStatus;
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E22301]';
      return;
    end if;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_UpdatedOmOutStockItem;

  /*****************************************************************************************
     功能：修改出货下架头档信息
  *****************************************************************************************/
  procedure P_O_UpdateOmOutStockHeader(strEnterPriseNo in odata_outstock_m.enterprise_no%type,
                                       v_warehouse_no  in odata_outstock_m.warehouse_no%type, --仓别
                                       strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                       strUserId       in odata_outstock_m.rgst_name%type, --员工ID
                                       strOutMsg       out varchar2) --返回值
   is
  begin
    strOutMsg := 'N|[P_O_UpdateOmOutStockHeader]';

    ---更新下架单头档
    UPDATE odata_outstock_m OOM
       SET OOM.UPDT_DATE    = SYSDATE,
           OOM.UPDT_NAME    = strUserId,
           OOM.STATUS       = 13,
           OOM.Handout_Name = strUserId,
           OOM.Handout_Date = sysdate
     where oom.warehouse_no = v_warehouse_no
       and oom.enterprise_no = strEnterPriseNo
       and oom.outstock_no = strOutStockNo
       and oom.status < 13;
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E22101]';
      return;
    end if;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_UpdateOmOutStockHeader;

  /*****************************************************************************************
     功能：下架回单 数据转历史处理
     更改strOutStockType,strOutStockType,strTaskType,strOperateType参数值类型 huangb 20160629
  *****************************************************************************************/
  procedure P_O_UpdateOmOutStockHistory(strEnterPriseNo in odata_outstock_m.enterprise_no%type, --仓别
                                        v_warehouse_no  in odata_outstock_m.warehouse_no%type, --仓别
                                        strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                        strUserId       in odata_outstock_m.rgst_name%type, --员工ID
                                        strFlagZero     in varchar2, --拣货零回标示
                                        strOutMsg       out varchar2) --返回值
   is

    strOutStockDirect varchar2(2); --下架指示转历史标示

    --strOutStockType varchar2(1); --下架类型
    --strPickType     varchar2(1); --拣货类型
    --strTaskType     varchar2(1); --发单方式
    --strOperateType  varchar2(1); --作业类型
    strOutStockType odata_outstock_m.outstock_type%type; --下架类型
    strPickType     odata_outstock_m.pick_type%type; --拣货类型
    strTaskType     odata_outstock_m.task_type%type; --发单方式
    strOperateType  odata_outstock_m.operate_type%type; --作业类型
  begin
    strOutMsg         := 'N|[P_O_UpdateOmOutStockHistory]';
    strOutStockDirect := '0';

    select oom.outstock_type,
           oom.pick_type,
           oom.task_type,
           oom.operate_type
      into strOutStockType, strPickType, strTaskType, strOperateType
      from odata_outstock_m oom
     where oom.warehouse_no = v_warehouse_no
       and oom.enterprise_no = strEnterPriseNo
       and oom.outstock_no = strOutStockNo;

    if strOutStockType = '1' then
      --------------出货量补货处理
      --更新标签 并转历史
      pkOBJ_label_odata.P_O_UpdateLabelDetail(strEnterPriseNo,
                                              v_warehouse_no,
                                              strOutStockNo,
                                              strOutStockType,
                                              strUserId,
                                              'F1',
                                              strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        return;
      end if;
    end if;

    if strOutStockType = '0' or strOutStockType = '3' or
       strOutStockType = '4' then
      --------------出货下架、安全量补货、人工移库 被销毁的 标签处理
      pkOBJ_label_odata.P_O_UpdateLabelDetail(strEnterPriseNo,
                                              v_warehouse_no,
                                              strOutStockNo,
                                              strOutStockType,
                                              strUserId,
                                              'FF',
                                              strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        return;
      end if;
    end if;

    ---------------下架单头 转历史
    insert into odata_outstock_mHTY
      (UPDT_DATE,
       UPDT_NAME,
       RGST_DATE,
       RGST_NAME,
       PRINT_STATUS,
       HANDOUT_NAME,
       HANDIN_NAME,
       HANDOUT_DATE,
       HANDIN_DATE,
       DOCK_NO,
       PRIORITY,
       STATUS,
       TASK_TYPE,
       PICK_TYPE,
       OPERATE_TYPE,
       BATCH_NO,
       OUTSTOCK_TYPE,
       OPERATE_DATE,
       OUTSTOCK_NO,
       warehouse_no,
       SOURCE_TYPE,
       EXP_DATE,
       OWNER_NO,
       enterprise_no,
       print_type,
       --huangb 20160509
       REPORT_UP_SERIAL,wave_no)
      select UPDT_DATE,
             UPDT_NAME,
             RGST_DATE,
             RGST_NAME,
             PRINT_STATUS,
             HANDOUT_NAME,
             HANDIN_NAME,
             HANDOUT_DATE,
             HANDIN_DATE,
             DOCK_NO,
             PRIORITY,
             STATUS,
             TASK_TYPE,
             PICK_TYPE,
             OPERATE_TYPE,
             BATCH_NO,
             OUTSTOCK_TYPE,
             OPERATE_DATE,
             OUTSTOCK_NO,
             warehouse_no,
             SOURCE_TYPE,
             EXP_DATE,
             OWNER_NO,
             enterprise_no,
             print_type,
             --huangb 20160509
             REPORT_UP_SERIAL,wave_no
        from odata_outstock_m
       where warehouse_no = v_warehouse_no
         and enterprise_no = strEnterPriseNo
         and OUTSTOCK_NO = strOutStockNo;
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E22303]';
      return;
    end if;

    delete from odata_outstock_m
     where warehouse_no = v_warehouse_no
       and enterprise_no = strEnterPriseNo
       and OUTSTOCK_NO = strOutStockNo;

    ---------------下架指示转历史
    if strOutStockType = '0' then
      if strPickType = '0' or strOperateType = 'P' or strOperateType = 'C' then
        strOutStockDirect := '1'; --写指示 标示
      end if;
    end if;

    if strOutStockType <> '0' then
      strOutStockDirect := '1'; --写指示 标示
    end if;
    if strFlagZero = '0' then
      strOutStockDirect := '1'; --写指示 标示
    end if;

    if strOutStockDirect = '1' then
      insert into odata_outstock_dIRECTHTY
        (EXP_DATE,
         TEMP_STATUS,
         UPDT_DATE,
         UPDT_NAME,
         RGST_DATE,
         RGST_NAME,
         DPS_CELL_NO,
         device_no,
         SUPP_COUNT,
         DELIVER_OBJ,
         CHECK_CHUTE_NO,
         A_SORTER_CHUTE_NO,
         PRIORITY,
         LINE_NO,
         DELIVER_AREA,
         STATUS,
         LOCATE_QTY,
         D_CELL_ID,
         D_CELL_NO,
         S_CONTAINER_NO,
         S_CELL_ID,
         S_CELL_NO,
         PACKING_QTY,
         ARTICLE_ID,
         ARTICLE_NO,
         SUB_CUST_NO,
         CUST_NO,
         EXP_NO,
         EXP_TYPE,
         WAVE_NO,
         DIRECT_SERIAL,
         BATCH_NO,
         PICK_TYPE,
         OPERATE_DATE,
         OPERATE_TYPE,
         OUTSTOCK_TYPE,
         OWNER_NO,
         warehouse_no,
         STOCK_TYPE,
         source_type,
         enterprise_no,
         deliverobj_order)
        select dir.EXP_DATE,
               dir.TEMP_STATUS,
               dir.UPDT_DATE,
               dir.UPDT_NAME,
               dir.RGST_DATE,
               dir.RGST_NAME,
               dir.DPS_CELL_NO,
               dir.device_no,
               dir.SUPP_COUNT,
               dir.DELIVER_OBJ,
               dir.CHECK_CHUTE_NO,
               dir.A_SORTER_CHUTE_NO,
               dir.PRIORITY,
               dir.LINE_NO,
               dir.DELIVER_AREA,
               dir.STATUS,
               dir.LOCATE_QTY,
               dir.D_CELL_ID,
               dir.D_CELL_NO,
               dir.S_CONTAINER_NO,
               dir.S_CELL_ID,
               dir.S_CELL_NO,
               dir.PACKING_QTY,
               dir.ARTICLE_ID,
               dir.ARTICLE_NO,
               dir.SUB_CUST_NO,
               dir.CUST_NO,
               dir.EXP_NO,
               dir.EXP_TYPE,
               dir.WAVE_NO,
               dir.DIRECT_SERIAL,
               dir.BATCH_NO,
               dir.PICK_TYPE,
               dir.OPERATE_DATE,
               dir.OPERATE_TYPE,
               dir.OUTSTOCK_TYPE,
               dir.OWNER_NO,
               dir.warehouse_no,
               dir.STOCK_TYPE,
               dir.source_type,
               dir.enterprise_no,
               dir.deliverobj_order
          from odata_outstock_dIRECT dir, odata_outstock_d d
         where d.warehouse_no = v_warehouse_no
           and dir.warehouse_no = d.warehouse_no
           and d.enterprise_no = dir.enterprise_no
           and d.enterprise_no = strEnterPriseNo
           and d.OUTSTOCK_NO = strOutStockNo
           and d.DIVIDE_ID = dir.DIRECT_SERIAL;
      /*if strOutStockType <>'5' and strOutStockType <>'4' then--差异移库，即时移库，没有下架指示，不判断
        if sql%rowcount <=0 then
          strOutMsg := 'N|[写下架指示历史表失败]';
          return;--暂时去掉 造数据不
        end if;
      end if;*/
      delete from odata_outstock_dIRECT
       where warehouse_no = warehouse_no
         and enterprise_no = strEnterPriseNo
         and DIRECT_SERIAL in
             (select d.DIVIDE_ID as DIRECT_SERIAL
                from odata_outstock_d d
               where d.warehouse_no = v_warehouse_no
                 and d.enterprise_no = strEnterPriseNo
                 and d.OUTSTOCK_NO = strOutStockNo);
    end if;
    ---------------下架明细转历史
    insert into odata_outstock_dHTY
      (enterprise_no,
       CHECK_CHUTE_NO,
       A_SORTER_CHUTE_NO,
       TRUNCK_CELL_NO,
       LINE_NO,
       STATUS,
       DELIVER_AREA,
       REAL_QTY,
       ARTICLE_QTY,
       D_CONTAINER_NO,
       D_CELL_ID,
       D_CELL_NO,
       S_CONTAINER_NO,
       S_CELL_ID,
       S_CELL_NO,
       PACKING_QTY,
       ARTICLE_ID,
       ARTICLE_NO,
       SUB_CUST_NO,
       CUST_NO,
       WAVE_NO,
       EXP_NO,
       EXP_TYPE,
       BATCH_NO,
       OPERATE_DATE,
       DIVIDE_ID,
       OUTSTOCK_NO,
       OWNER_NO,
       warehouse_no,
       PICK_DEVICE,
       EXP_DATE,
       PRIORITY,
       device_no,
       DPS_CELL_NO,
       INSTOCK_DATE,
       OUTSTOCK_DATE,
       INSTOCK_NAME,
       OUTSTOCK_NAME,
       ASSIGN_NAME,
       ADVANCE_CELL_NO,
       DELIVER_OBJ,
       ADVANCE_PICK_NAME,
       ADVANCE_PICK_DATE,
       STOCK_TYPE,
       UNBOX_FLAG,
       deliverobj_order)
      select enterprise_no,
             CHECK_CHUTE_NO,
             A_SORTER_CHUTE_NO,
             TRUNCK_CELL_NO,
             LINE_NO,
             STATUS,
             DELIVER_AREA,
             REAL_QTY,
             ARTICLE_QTY,
             D_CONTAINER_NO,
             D_CELL_ID,
             D_CELL_NO,
             S_CONTAINER_NO,
             S_CELL_ID,
             S_CELL_NO,
             PACKING_QTY,
             ARTICLE_ID,
             ARTICLE_NO,
             SUB_CUST_NO,
             CUST_NO,
             wave_no,
             EXP_NO,
             EXP_TYPE,
             BATCH_NO,
             OPERATE_DATE,
             DIVIDE_ID,
             OUTSTOCK_NO,
             OWNER_NO,
             warehouse_no,
             PICK_DEVICE,
             EXP_DATE,
             PRIORITY,
             device_no,
             DPS_CELL_NO,
             INSTOCK_DATE,
             OUTSTOCK_DATE,
             INSTOCK_NAME,
             OUTSTOCK_NAME,
             ASSIGN_NAME,
             ADVANCE_CELL_NO,
             DELIVER_OBJ,
             ADVANCE_PICK_NAME,
             ADVANCE_PICK_DATE,
             STOCK_TYPE,
             UNBOX_FLAG,
             deliverobj_order
        from odata_outstock_d
       where warehouse_no = v_warehouse_no
         and enterprise_no = strEnterPriseNo
         and OUTSTOCK_NO = strOutStockNo;
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E22304]';
      return;
    end if;

    delete from odata_outstock_d
     where warehouse_no = v_warehouse_no
       and OUTSTOCK_NO = strOutStockNo;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_UpdateOmOutStockHistory;

  /*****************************************************************************************
     功能：修改出货下架明细信息    --按下架单号、按储位、按商品回单
  *****************************************************************************************/
  procedure P_O_UpdtStockByStockArticle(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                        v_warehouse_no  in stock_label_m.warehouse_no%type,
                                        strOutStockNo   in stock_label_m.source_no%type,
                                        strArticleNo    in stock_label_d.article_no%type,
                                        strScellNo      in odata_outstock_d.s_cell_no%type,
                                        strFlagZero     in varchar2,
                                        strUserID       in stock_label_m.updt_name%type,
                                        strOutMsg       out varchar2) --返回值
   is
  begin
    strOutMsg := 'N|[P_O_UpdtStockByStockArticle]';

    ------------------更新下架单明细信息------------------
    UPDATE odata_outstock_d A
       SET A.STATUS = CASE
                        WHEN A.ARTICLE_QTY <= NVL(A.REAL_QTY, 0) then
                         '13'
                        WHEN NOT EXISTS
                         (SELECT 'x'
                                FROM stock_label_d B
                               WHERE B.warehouse_no = A.warehouse_no
                                 and b.enterprise_no = a.enterprise_no
                                 AND B.SOURCE_NO = A.OUTSTOCK_NO
                                 AND B.DIVIDE_ID = A.DIVIDE_ID
                                 AND (B.STATUS = '40' or B.STATUS = '50')) then
                         '13'
                        ELSE
                         STATUS
                      END,
           A.OUTSTOCK_NAME = NVL(A.OUTSTOCK_NAME, strUserID),
           A.OUTSTOCK_DATE = NVL(A.OUTSTOCK_DATE, SYSDATE),
           A.REAL_QTY = case
                          when strFlagZero = '1' then
                           NVL(A.REAL_QTY, 0)
                          else
                           A.Article_Qty
                        end
     WHERE warehouse_no = v_warehouse_no
       and enterprise_no = strEnterPriseNo
       AND ARTICLE_NO = strArticleNo
       AND OUTSTOCK_NO = strOutStockNo
       AND S_CELL_NO = strScellNo
       AND STATUS < '13';
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E22301]';
      return;
    end if;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_UpdtStockByStockArticle;

  /*****************************************************************************************
     功能：修改出货下架明细信息    --按下架单号整单回单
  *****************************************************************************************/
  procedure P_O_UpdatedStockDByStockNo(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                       v_warehouse_no  in stock_label_m.warehouse_no%type,
                                       strOutStockNo   in stock_label_m.source_no%type,
                                       strFlagZero     in varchar2,
                                       strUserID       in stock_label_m.updt_name%type,
                                       strOutMsg       out varchar2) --返回值
   is
  begin
    strOutMsg := 'N|[P_O_UpdatedStockDByStockNo]';

    ------------------更新下架单明细信息------------------
    UPDATE odata_outstock_d A
       SET A.STATUS = CASE
                        WHEN A.ARTICLE_QTY <= NVL(A.REAL_QTY, 0) then
                         '13'
                        WHEN NOT EXISTS
                         (SELECT 'x'
                                FROM stock_label_d B
                               WHERE B.warehouse_no = A.warehouse_no
                                 and b.enterprise_no = a.enterprise_no
                                 AND B.SOURCE_NO = A.OUTSTOCK_NO
                                 AND B.DIVIDE_ID = A.DIVIDE_ID
                                 AND (B.STATUS = '40' or B.STATUS = '50')) then
                         '13'
                        ELSE
                         STATUS
                      END,
           A.OUTSTOCK_NAME = NVL(A.OUTSTOCK_NAME, strUserID),
           A.OUTSTOCK_DATE = NVL(A.OUTSTOCK_DATE, SYSDATE),
           A.REAL_QTY = case
                          when strFlagZero = '1' then
                           NVL(A.REAL_QTY, 0)
                          else
                           A.Article_Qty
                        end
     WHERE warehouse_no = v_warehouse_no
       and enterprise_no = strEnterPriseNo
       AND OUTSTOCK_NO = strOutStockNo
       AND STATUS < '13';

    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E22301]';
      return;
    end if;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_UpdatedStockDByStockNo;

  /*****************************************************************************************
     功能：下架单号更新下架单头档派单人员 ( RF 派单+换人+回收 功能 )
  *****************************************************************************************/
  procedure P_O_UpdatedOutNameByStockNo(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                        v_warehouse_no  in stock_label_m.warehouse_no%type, --仓别
                                        strOutStockNo   in stock_label_m.source_no%type, --下架单号
                                        strHandOutName  in stock_label_m.updt_name%type, --派单人
                                        strType         in varchar2, --操作类型  （1：派单， 2 ：换人, 3：回收）
                                        strUserID       in stock_label_m.updt_name%type, --操作人
                                        strOutMsg       out varchar2) --返回值
   is
    strOutName varchar2(20); --派单人
  begin
    strOutMsg  := 'N|[E00025]';
    strOutName := 'N';
    ------------------更新下架单明细信息------------------
    if strType = '1' then
      --检查是否派过单
      select oom.handout_name
        into strOutName
        from odata_outstock_m oom
       where oom.warehouse_no = v_warehouse_no
         and oom.enterprise_no = strEnterPriseNo
         and oom.outstock_no = strOutStockNo;
      if strOutName is null then
        --已派单  不允许再次派单操作
        strOutMsg := 'N|[E01240]';
        return;
      else
        update odata_outstock_m oom
           set oom.updt_date    = sysdate,
               oom.handout_name = strHandOutName,
               oom.handout_date = sysdate,
               oom.updt_name    = strUserID
         where oom.warehouse_no = v_warehouse_no
           and oom.enterprise_no = strEnterPriseNo
           and oom.outstock_no = strOutStockNo;
        if sql%rowcount <= 0 then
          strOutMsg := 'N|[E01230]';
          return;
        end if;
      end if;
    end if;

    if strType = '2' then
      --检查是否派过单
      select oom.handout_name
        into strOutName
        from odata_outstock_m oom
       where oom.warehouse_no = v_warehouse_no
         and oom.enterprise_no = strEnterPriseNo
         and oom.outstock_no = strOutStockNo;
      if strOutName is null or strOutName = 'N' then
        --还未派单  不允许换人操作
        strOutMsg := 'N|[E01231]';
        return;
      else
        update odata_outstock_m oom
           set oom.updt_date    = sysdate,
               oom.handout_name = strHandOutName,
               oom.handout_date = sysdate,
               oom.updt_name    = strUserID
         where oom.warehouse_no = v_warehouse_no
           and oom.enterprise_no = strEnterPriseNo
           and oom.outstock_no = strOutStockNo;
        if sql%rowcount <= 0 then
          strOutMsg := 'N|[E01232]';
          return;
        end if;
      end if;
    end if;

    if strType = '3' then
      ---回收
      update odata_outstock_mhty oom
         set oom.handin_name = strHandOutName,
             oom.handin_date = sysdate,
             oom.updt_name   = strUserID,
             oom.updt_date   = sysdate
       where oom.warehouse_no = v_warehouse_no
         and oom.enterprise_no = strEnterPriseNo
         and oom.outstock_no = strOutStockNo;
      if sql%rowcount <= 0 then
        strOutMsg := 'N|[E01236]';
        return;
      end if;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_UpdatedOutNameByStockNo;

  /*****************************************************************************************
     功能：下架回单  触发未触发的 出货或补货
  *****************************************************************************************/
  procedure P_O_CheckStatusCanOutstock(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                       v_warehouse_no  in stock_label_m.warehouse_no%type, --仓别
                                       strOwnerNo      in odata_outstock_d.owner_no%type, --委托业主编码
                                       strOutMsg       out varchar2) --返回值
   is
  begin

    strOutMsg := 'N|[P_O_CheckStatusCanOutstock]';

    update odata_outstock_direct
       set status = '10'
     where (enterprise_no, warehouse_no, direct_serial) in
           (select d.enterprise_no, d.warehouse_no, d.direct_serial
              from odata_outstock_direct d
             where d.warehouse_no = v_warehouse_no
               and d.enterprise_no = strEnterPriseNo
               and d.outstock_type = '0'
               and d.status = '11'
               and not exists
             (select 'x'
                      from odata_outstock_direct id --不存在没有发单的补货指示
                     where id.enterprise_no = d.enterprise_no
                       and id.warehouse_no = d.warehouse_no
                       and id.d_cell_no = d.s_cell_no
                       and id.d_cell_id = d.s_cell_id
                       and id.direct_serial < d.direct_serial));

    update odata_outstock_direct
       set status = '10'
     where (enterprise_no, warehouse_no, direct_serial) in
           (select d.enterprise_no, d.warehouse_no, d.direct_serial
              from odata_outstock_direct d
             where d.warehouse_no = v_warehouse_no
               and d.enterprise_no = strEnterPriseNo
               and d.outstock_type in ('1', '3')
               and d.status in ('11', '12')
               and not exists
             (select 'x'
                      from odata_outstock_direct id --不存在没有发单的下架指示
                     where id.enterprise_no = d.enterprise_no
                       and id.warehouse_no = d.warehouse_no
                       and id.s_cell_no = d.d_cell_no
                       and id.article_no = d.article_no
                       and id.status <> '13'
                       and id.direct_serial < d.direct_serial)
               and not exists
             (select 'x'
                      from odata_outstock_d ood --不存在没有回单的下架指示
                     where ood.enterprise_no = d.enterprise_no
                       and ood.warehouse_no = d.warehouse_no
                       and ood.s_cell_no = d.d_cell_no
                       and ood.article_no = d.article_no
                       and ood.divide_id < d.direct_serial)
               and not exists
             (select 'x'
                      from odata_outstock_direct id --不存在比当前补货次数更小的补货指示
                     where id.enterprise_no = d.enterprise_no
                       and id.warehouse_no = d.warehouse_no
                       and id.d_cell_no = d.d_cell_no
                       and id.article_no = d.article_no
                       and id.supp_count < d.supp_count)
               and not exists
             (select 'x'
                      from odata_outstock_direct id --不存在没有发单的上一级补货指示
                     where id.enterprise_no = d.enterprise_no
                       and id.warehouse_no = d.warehouse_no
                       and id.outstock_type in ('1', '3')
                       and id.d_cell_no = d.s_cell_no
                       and id.d_cell_id = d.s_cell_id
                       and d.status = '12'));

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_CheckStatusCanOutstock;

  /*****************************************************************************************
     功能：修改出货下架头档信息( 立库移库  修改状态为中间状态 A1)
  *****************************************************************************************/
  procedure P_O_UpdateHmOutStockHeader(strEnterPriseNo in odata_outstock_m.enterprise_no%type,
                                       v_warehouse_no  in odata_outstock_m.warehouse_no%type, --仓别
                                       strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                       strUserId       in odata_outstock_m.rgst_name%type, --员工ID
                                       strOutMsg       out varchar2) --返回值
   is
  begin
    strOutMsg := 'N|[P_O_UpdateHmOutStockHeader]';

    ---更新下架单头档
    UPDATE odata_outstock_m OOM
       SET OOM.UPDT_DATE    = SYSDATE,
           OOM.UPDT_NAME    = strUserId,
           OOM.STATUS       = 'A1',
           OOM.Handout_Name = strUserId,
           OOM.Handout_Date = sysdate
     where oom.warehouse_no = v_warehouse_no
       and oom.enterprise_no = strEnterPriseNo
       and oom.outstock_no = strOutStockNo
       and oom.status < 13;
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E22302]';
      return;
    end if;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_UpdateHmOutStockHeader;

  /***********************************************************************************************************
   创建人：luozhiling
   时间：2013.11.11
   功能：表单回单时将来源标签库存转移到目的标签
  ************************************************************************************************************/
  procedure P_Odata_Outstock_label(strEnterPriseNo    in odata_outstock_m.enterprise_no%type,
                                   strWareHouseNo     in odata_outstock_d.warehouse_no%type, --仓库编码
                                   strOutstockNo      in odata_outstock_d.outstock_no%type, --分播单号
                                   strsContainerNo    in odata_outstock_d.s_container_no%type, --来源容器号
                                   strDestContainerNo in odata_outstock_d.D_container_no%type, --目的容器号
                                   nDivideId          in odata_outstock_d.divide_id%type, --
                                   strArticleNo       in odata_outstock_d.article_no%type,
                                   nArticleId         in odata_outstock_d.article_id%type,
                                   nPackingQty        in odata_outstock_d.packing_qty%type,
                                   strExpNo           in odata_outstock_d.exp_no%type,
                                   nRealQty           in odata_outstock_d.real_qty%type,
                                   strCustNo          in odata_outstock_d.Cust_No%type, --客户编码
                                   strUserId          in odata_outstock_m.rgst_name%type,
                                   strResult          OUT varchar2) is
    v_iCount integer;
    tmpQty   odata_outstock_d.article_qty%type;
  begin
    strResult := 'N|P_Odata_Outstock_label';

    --增加目的标签明细
    update stock_label_d sld
       set sld.qty       = qty + nRealQty,
           sld.updt_name = strUserId,
           sld.updt_date = sysdate
     where sld.warehouse_no = strWareHouseNo
       and sld.enterprise_no = strEnterPriseNo
       and sld.container_no = strdestContainerNo
       and sld.source_no = strOutstockNo
       and sld.article_no = strArticleNo
       and sld.article_id = nArticleId
       and sld.Exp_No = strExpNo
       and sld.divide_id = nDivideId
       and rownum = 1;
    if sql%notfound then
      --获取标签明细的ROW_ID
      select nvl(max(row_id), 0)
        into v_iCount
        from stock_label_d sld
       where sld.container_no = strDestContainerNo
         and sld.warehouse_no = strWareHouseNo;
      insert into stock_label_d
        (enterprise_no,
         warehouse_no,
         batch_no,
         owner_no,
         source_no,
         container_no,
         container_type,
         article_no,
         article_id,
         packing_qty,
         qty,
         exp_no,
         wave_no,
         cust_no,
         sub_cust_no,
         line_no,
         status,
         divide_id,
         row_id,
         exp_type,
         dps_cell_no,
         deliver_obj,
         exp_date,
         advance_cell_no,
         advance_status,
         rgst_name,
         rgst_date,
         updt_name,
         updt_date,
         deliverobj_order)
        select strEnterPriseNo,
               strWareHouseNo,
               sld.batch_no,
               sld.owner_no,
               strOutstockNo,
               strDestContainerNo,
               sld.container_type,
               strArticleNo,
               nArticleId,
               nPackingQty,
               nRealQty,
               sld.exp_no,
               sld.wave_no,
               strCustNo,
               sld.sub_cust_no,
               sld.line_no,
               CLabelStatus.RECEIVING,
               nDivideId,
               v_iCount + 1,
               sld.exp_type,
               sld.dps_cell_no,
               sld.deliver_obj,
               sld.exp_date,
               sld.advance_cell_no,
               sld.advance_status,
               sld.rgst_name,
               sld.rgst_date,
               strUserId,
               sysdate,
               sld.deliverobj_order
          from stock_label_d sld
         where sld.warehouse_no = strWareHouseNo
           and sld.enterprise_no = strEnterPriseNo
           and sld.container_no = strsContainerNo
           and sld.source_no = strOutstockNo
           and sld.article_no = strArticleNo
           and sld.article_id = nArticleId
           and sld.Exp_No = strExpNo
           and sld.divide_id = nDivideId
           and rownum = 1;
    end if;

    --扣减来源标签明细
    update stock_label_d sld
       set sld.qty       = qty - nRealQty,
           sld.updt_name = strUserId,
           sld.updt_date = sysdate
     where sld.warehouse_no = strWareHouseNo
       and sld.enterprise_no = strEnterPriseNo
       and sld.container_no = strsContainerNo
       and sld.source_no = strOutstockNo
       and sld.article_no = strArticleNo
       and sld.article_id = nArticleId
       and sld.Exp_No = strExpNo
       and sld.divide_id = nDivideId
       and rownum = 1;
    if sql%notfound then
      strResult := 'N|[E22305]';
      return;
    end if;

    -------------------------删除 标签明细为 0  的数据--------------------------
    DELETE stock_label_d
     WHERE warehouse_no = strWareHouseNo
       and enterprise_no = strEnterPriseNo
       AND CONTAINER_NO = strsContainerNo
       and QTY = 0;

    --检查标签明细是否都已转移完成
    select nvl(sum(qty), 0)
      into tmpQty
      from stock_label_d sld
     where sld.warehouse_no = strWareHouseNo
       and enterprise_no = strEnterPriseNo
       AND CONTAINER_NO = strsContainerNo;

    if tmpQty = 0 then
      --标签明细已分播完成,需要置标签头档状态
      update stock_label_m t
         set t.status  = CLabelStatus.PICK_CLOSE,
             updt_name = strUserId,
             updt_date = sysdate
       where t.warehouse_no = strWareHouseNo
         and t.enterprise_no = strEnterPriseNo
         AND t.CONTAINER_NO = strsContainerNo;
      -------------标签转历史
      PKOBJ_LABEL.proc_RemoveLabel(strEnterPriseNo,
                                   strwarehouseno,
                                   strsContainerNo,
                                   strResult);
      if instr(strResult, 'N', 1, 1) = 1 then
        return;
      end if;
    end if;
    strResult := 'Y';
  end P_Odata_Outstock_label;

  /*--检查下架单时间限制
    Add BY QZH AT 2016-5-25
  */
  procedure P_O_check_TimeLimit(strEnterPriseNo in cdef_defware.enterprise_no%type,
                                strWareHouseNo  in cdef_defware.warehouse_no%type,
                                strOutstock_No  in odata_outstock_m.outstock_no%type,
                                strOwner_No     in odata_outstock_m.owner_no%type,
                                strResult       OUT varchar2) is
    v_strSDeFine   WMS_DEFBASE.Sdefine%type;
    v_strNDeFine   WMS_DEFBASE.Ndefine%type;
    v_HandOut_Date odata_outstock_m.handout_date%type;
    v_TaskGetType  odata_outstock_m.task_get_type%type;
  begin

    strResult := 'N|P_O_check_TimeLimit';

    --时间限制参数
    PKLG_WMS_BASE.p_GetBasePara(strEnterpriseNo,
                                strWareHouseNo,
                                strOwner_No,
                                'TaskEndTimeLimit',
                                'O',
                                'O_TASK',
                                v_strSDeFine,
                                v_strNDeFine,
                                strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;
    if v_strNDeFine <= 0 then
      strResult := 'Y|';
      return;
    end if;

    begin
      --派单时间
      select nvl(m.HANDOUT_DATE, m.rgst_date), m.task_get_type
        into v_HandOut_Date, v_TaskGetType
        from odata_outstock_m m
       where m.enterprise_no = strEnterPriseNo
         and m.warehouse_no = strWareHouseNo
         and m.outstock_no = strOutstock_No
         and m.status = '10';
    exception
      when no_data_found then
        strResult := 'N|单据' || strOutstock_No || '不存在或已回单';
        return;
    end;

    if v_TaskGetType <> '1' then
      --1-RF索单
      strResult := 'Y|';
      return;
    end if;

    if (sysdate - v_HandOut_Date) * 24 * 60 < v_strNDeFine then
      strResult := 'N|单据' || strOutstock_No || '未到回单时间';
      return;
    end if;
    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_O_check_TimeLimit;

END PKOBJ_ODATA;

/

