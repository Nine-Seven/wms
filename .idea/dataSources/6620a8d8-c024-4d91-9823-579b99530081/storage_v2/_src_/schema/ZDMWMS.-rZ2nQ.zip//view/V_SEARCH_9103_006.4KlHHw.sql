create view V_SEARCH_9103_006 as
select c.ENTERPRISE_NO "ENTERPRISE_NO", c.WAREHOUSE_NO "WAREHOUSE_NO",c.owner_no as "OWNER_NO","TASK_TYPE_DESC","TASK_TYPE",
"OUTSTOCK_NO","OPERATE_TYPE",c."CUST_NO","CUST_NAME","BARCODE","ARTICLE_NO","ARTICLE_NAME","PACKING_QTY",
"ARTICLE_QTY","REAL_QTY",c."BATCH_NO",c."WAVE_NO","S_CELL_NO","D_CELL_NO","DEVICE_NO","LABEL_NO","OPERATE_DATE",
"PICK_TYPE_DESC","PICK_TYPE",b1.worker_name as "OUTSTOCK_NAME","OUTSTOCK_DATE",
b2.worker_name as "UPDT_NAME",c."EXP_NO","PICK_CONTAINER_NO",c.status as "STATUS","STATUS_DESC",
oem.sourceexp_no,oem.shipper_deliver_no
  from (select oom.enterprise_no,
               oom.warehouse_no,
               oom.owner_no,
               wdv.text task_type_desc,
               oom.task_type,
               oom.outstock_no,
               oom.operate_type,
               ood.cust_no,
               bdc.cust_name,
               bda.BARCODE,
               bda.ARTICLE_NO,
               bda.ARTICLE_NAME,
               ood.packing_qty,
               ood.article_qty,
               ood.real_qty,
               ood.batch_no,
               ood.wave_no,
               ood.s_cell_no,
               ood.d_cell_no,
               ood.device_no,nvl(slm.label_no,'N') as label_no,
               trunc(oom.operate_date) operate_date,
               wdv1.text pick_type_desc,
               oom.pick_type,
               ood.outstock_name,
               ood.outstock_date outstock_date,
               oom.updt_name,
               ood.exp_no,
               '' pick_container_no,
               ood.status,
               wdv2.text status_desc
          from (select *
                  from odata_outstock_mhty
                union
                select * from odata_outstock_m) oom
          join (select *
                 from odata_outstock_d
               union
               select * from odata_outstock_dhty) ood
            on oom.enterprise_no = ood.enterprise_no
           and oom.warehouse_no = ood.warehouse_no
           and oom.outstock_no = ood.outstock_no
          join bdef_defcust bdc
            on ood.owner_no = bdc.owner_no
           and ood.enterprise_no = bdc.enterprise_no
           and ood.cust_no = bdc.cust_no
          join v_bdef_defarticle bda
            on ood.owner_no = bda.owner_no
           and ood.enterprise_no = bda.enterprise_no
           and ood.article_no = bda.article_no
           left join (select * from stock_label_m union select * from stock_label_mhty) slm
           on ood.s_container_no=slm.container_no
           and ood.warehouse_no=slm.warehouse_no and ood.enterprise_no=slm.enterprise_no
          left join wms_deffieldval wdv
            on oom.task_type = wdv.value
           and wdv.table_name = 'ODATA_OUTSTOCK_M'
           and wdv.colname = 'TASK_TYPE'
          left join wms_deffieldval wdv1
            on oom.pick_type = wdv1.value
           and wdv1.table_name = 'ODATA_OUTSTOCK_M'
           and wdv1.colname = 'PICK_TYPE'
          left join wms_deffieldval wdv2
            on ood.status = wdv2.value
           and wdv2.table_name = 'N'
           and wdv2.colname = 'STATUS'
         where oom.outstock_type = '0') c
         left join bdef_defworker b1 on c.enterprise_no=b1.enterprise_no
           and c.outstock_name=b1.worker_no
         left join bdef_defworker b2 on c.enterprise_no=b2.enterprise_no
           and c.updt_name=b2.worker_no
         inner join odata_exp_m oem on  c.enterprise_no = oem.enterprise_no
           and c.warehouse_no = oem.warehouse_no
           and c.exp_no = oem.exp_no


/

