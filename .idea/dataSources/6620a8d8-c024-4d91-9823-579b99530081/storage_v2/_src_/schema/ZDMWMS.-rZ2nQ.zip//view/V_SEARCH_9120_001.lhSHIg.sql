create view V_SEARCH_9120_001 as
SELECT
       (SELECT COUNT(0) FROM cdef_defcell c WHERE c.cell_status = 0) YXHWS ,--当前仓库有效货位数
       0 CCHWS ,--出错货位数
       ROUND(((SELECT COUNT(0) FROM cdef_defcell c WHERE c.cell_status = 0)-0)
       /(SELECT COUNT(0) FROM cdef_defcell c WHERE c.cell_status = 0),4) * 100 || '%' HWZQL
--货位准确率（KPI1）标准值为99%
--货位准确率=（当前仓库有效货位数–出错货位数）/ (当前仓库有效货位数)*100%
--注：出错包括——数量、库位或项目号的错误。
--仓库有效货位数指当前系统有记录货位数。
 FROM dual

/

