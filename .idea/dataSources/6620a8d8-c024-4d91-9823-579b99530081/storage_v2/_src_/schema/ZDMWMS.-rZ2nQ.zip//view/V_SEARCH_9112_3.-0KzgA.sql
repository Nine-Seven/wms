create view V_SEARCH_9112_3 as
select distinct a.enterprise_no,
       a.warehouse_no,
       a.owner_no,
       bo.owner_alias ,
       a.area_name,
       a.area_no,
       bd.owner_article_no,
       bd.article_no,
       bd.barcode,
       bd.article_identifier,
       bd.article_name,
       NVL(P.PACKING_UNIT, BD.UNIT) PACKING_UNIT, --BD.PACKING_UNIT,
       a.packing_qty,
       bd.spec,
       a.qty
  from bdef_defarticle bd,
       (select sc.enterprise_no,
               t.area_name,
               t.area_no,
               sc.warehouse_no,
               sc.owner_no,
               sc.packing_qty,
               sc.article_no,
               sum(sc.qty) qty
          from stock_content      sc,
               cdef_defcell       cd,
               cdef_defarea       t
         where  sc.warehouse_no = cd.warehouse_no
           and sc.cell_no = cd.cell_no
           and sc.enterprise_no = cd.enterprise_no
           and cd.enterprise_no = t.enterprise_no
           and cd.warehouse_no = t.warehouse_no
           and cd.ware_no || cd.area_no = t.ware_no || t.area_no
         group by sc.enterprise_no,
                  t.area_name,
                  t.area_no,
                  sc.warehouse_no,
                  sc.owner_no,
                  sc.packing_qty,
                  sc.article_no) a,
       bdef_defsupplier bds,
       bdef_defworker bw,
       BDEF_ARTICLE_PACKING P,
       bdef_defowner bo
 where bd.article_no = a.article_no
   AND bd.enterprise_no = a.enterprise_no
   and bd.supplier_no = bds.supplier_no(+)
   AND bd.owner_no = bds.owner_no(+)
   AND bd.enterprise_no = bds.enterprise_no(+)
   and bw.enterprise_no = a.enterprise_no
   AND A.ENTERPRISE_NO = P.ENTERPRISE_NO(+)
   AND A.ARTICLE_NO = P.ARTICLE_NO(+)
   AND A.PACKING_QTY = P.PACKING_QTY(+)
   and bo.enterprise_no = bd.enterprise_no
   and bo.owner_no = bd.owner_no
 order by a.enterprise_no,
          a.warehouse_no,
          a.owner_no,
          a.area_name,
          bd.owner_article_no


/

