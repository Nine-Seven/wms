create package body        pkobj_Ridata is
 /**********************************************************************************************
   作者:hekl
   日期:  2015-04-07
   功能: 返配手建单对象：写汇总头档表
  ************************************************************************************************/
  procedure p_ridata_saveUntreadmm(
              strEnterpriseNo in ridata_untread_m.enterprise_no%type,
              strWareHouseNo in ridata_untread_m.warehouse_no%type,
              strUntreadNo in ridata_untread_m.untread_no%type,
              v_strQType   in ridata_untread_m.po_type%type ,
              v_strClassType in ridata_untread_m.class_type%type,
              v_strCust      in ridata_untread_m.cust_no%type,
              strSUntreadNo in ridata_untread_mm.s_untread_no%type,--返配汇总单
              v_strOwner    in ridata_untread_m.owner_no%type,
              v_strPoNo    in ridata_untread_m.po_no%type,
              v_strRgstName  in ridata_untread_m.rgst_name%type,
              strResult out varchar2
    )is
    begin
    strResult := 'N|[p_ridata_saveUntreadmm]';


     update ridata_untread_mm m
       set m.status = m.status
     where m.warehouse_no = strWareHouseNo
       and m.s_untread_no = strSUntreadNo
       and m.enterprise_no = strEnterpriseNo;

    if sql%rowcount <= 0 then
       --写返配汇总单头档
       insert into ridata_untread_mm(enterprise_no,warehouse_no,owner_no,s_untread_no,s_po_no,
       cust_no,class_type,status,serial_no,print_flag,carplate,track_no,boardnum,
       rgst_name,rgst_date,stock_type,stock_value,quality)
       values(strEnterpriseNo,strWareHouseNo,v_strOwner,strSUntreadNo,v_strPoNo,v_strCust,
       v_strClassType,'10',SEQ_RIDATA_UNTREAD_MM.Nextval,0,'N','N','0',
       v_strRgstName,sysdate,1,'N',v_strQType);

    end if;

  strResult:='Y|';

  end p_ridata_saveUntreadmm;
  /**********************************************************************************************
   作者:hekl
   日期:  2015-04-07
   功能: 返配手建单对象：写汇总明细表
  ************************************************************************************************/
  procedure p_ridata_saveUntreadsm(
                           strEnterpriseNo in ridata_untread_m.enterprise_no%type,
                           strWareHouseNo in ridata_untread_m.warehouse_no%type,
                           strUntreadNo in ridata_untread_m.untread_no%type,
                           strSUntreadNo in ridata_untread_mm.s_untread_no%type,
                           strResult out varchar2
    )is
    begin

    strResult := 'N|[p_ridata_saveUntreadsm]';

    --写汇总明细表
    insert into ridata_untread_sm(enterprise_no,warehouse_no,owner_no,s_untread_no,untread_type,
    untread_no,po_type,po_no,status,rgst_name,rgst_date)
    select b.enterprise_no,b.warehouse_no,b.owner_no,strSUntreadNo,
    b.untread_type,b.untread_no,b.po_type,b.po_no,b.status,
    b.rgst_name,b.rgst_date
    from ridata_untread_m b
    where b.untread_no=strUntreadNo and b.warehouse_no=strWareHouseNo
    and b.enterprise_no=strEnterpriseNo;

    strResult:='Y|';

    end p_ridata_saveUntreadsm;
  -----------------------------------【存储验收begin】---------------------------------------------------
  /**********************************************************************************************
   作者:luozhiling
   日期:  2013-09-29
   功能: 返配单对象：写入临时板表
  ************************************************************************************************/
  procedure p_InsertPalTmp(strEnterPriseNo    in ridata_check_pal_tmp.enterprise_no%type,
                           strWAREHOUSE_NO    in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                           strOwner_No        in ridata_check_pal_tmp.owner_no%type, --委托业主编码
                           strsUntreadNo      in ridata_untread_sm.s_untread_no%type,
                           strS_Check_No      in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                           strArticle_No      in ridata_check_pal_tmp.article_no%type, --商品编码
                           strBarcode         in ridata_check_pal_tmp.barcode%type, --商品条码
                           strQuality         in  ridata_check_d.quality%type,--品质
                           dtProduceDate      in  ridata_check_d.produce_date%type,
                           dtExpireDate       in  Ridata_check_d.expire_date%type,
                           strLotNo           in  ridata_check_d.lot_no%type,--批次号
                           strRSV_BATCH1      in  ridata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                           strRSV_BATCH2      in  ridata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                           strRSV_BATCH3      in  ridata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                           strRSV_BATCH4      in  ridata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                           strRSV_BATCH5      in  ridata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                           strRSV_BATCH6      in  ridata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                           strRSV_BATCH7      in  ridata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                           strRSV_BATCH8      in  ridata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                           nPack_Qty          in ridata_check_pal_tmp.packing_qty%type, --包装数量
                           nCheck_Qty         in ridata_check_pal_tmp.check_qty%type, --验收数量
                           strLabel_No        in ridata_check_pal_tmp.label_no%type, --板号
                           strLabelId         in ridata_check_pal_tmp.label_id%type,
                           strBusiness_Type   in ridata_check_pal_tmp.business_type%type, --业务类型
                           strFixpal_Flag     in ridata_check_pal_tmp.fixpal_flag%type, --板类型
                           strPrintGroup      in ridata_check_pal_tmp.printer_group_no%type, --打印机组
                           strDock_No         in ridata_check_pal_tmp.dock_no%type, --码头
                           strStockType       in ridata_check_pal_tmp.stock_type%type, --存储类型
                           strStockValue      in ridata_check_pal_tmp.stock_value%type, --存储类型对应值
                           strSub_Label_No   in ridata_check_pal_tmp.sub_label_no%type, --尾箱标签
                           strWorker_No       in ridata_check_pal_tmp.rgst_name%type, --验收人员
                           strUntreadType     in ridata_check_pal_tmp.untread_type%type, --返配单别
                           strSupplierNo      in ridata_check_pal_tmp.supplier_no%type, --供应商
                           strCheck_Tools     in char, --检查工具 1:前台2:RF
                           strWaveNo          in ridata_check_pal_tmp.wave_no%type,
                           strBatchNo         in ridata_check_pal_tmp.batch_no%type,
                           strCellNo          in ridata_check_pal_tmp.cell_no%type,
                           strDeviceNo        in ridata_check_pal_tmp.device_no%type,
                           strQualityFlag     in ridata_check_pal_tmp.quality_flag%type,--品质类型0滞销品，1过季品，A质量问题，B次品
                           strClassType       in ridata_untread_mm.class_type%type,
                           nIsAdd             in integer, --是否累加 0:覆盖 1:累加
                           strResult          out varchar2) is--返回结果

    intRowId ridata_check_pal_tmp.row_id%type; --记录最大的row_id
		m_ArticleQty ridata_untread_d.untread_qty%TYPE;--记录当前商品的总量
		m_CheckQty   ridata_untread_d.untread_qty%TYPE;--记录已经验收的量
    v_nPreCheckQty   ridata_untread_d.untread_qty%type;--预验收数量
  begin
    strResult := 'N|[p_InsertPalTmp]';

    if nCheck_Qty<0 then
       select nvl(check_qty,0) into v_nPreCheckQty from ridata_check_pal_tmp
       where WAREHOUSE_NO = strWAREHOUSE_NO and enterprise_no=strEnterPriseNo
           and owner_no = strOwner_No
           and S_Check_No = strS_Check_No
           and label_no = strLabel_No
           and article_no = strArticle_no
           and barcode = strBarcode
           and packing_qty = nPack_Qty
           and Quality = strQuality
           and status = '10'
           and stock_type = strStockType
           and stock_value = strStockValue
           and sub_label_no = strsub_Label_No
           and lot_no = strLotNo
           and produce_date = dtProduceDate
           and expire_date = dtExpireDate
           and rsv_batch1=strRSV_BATCH1
           and rsv_batch2=strRSV_BATCH2
           and rsv_batch3=strRSV_BATCH3
           and rsv_batch4=strRSV_BATCH4
           and rsv_batch5=strRSV_BATCH5
           and rsv_batch6=strRSV_BATCH6
           and rsv_batch7=strRSV_BATCH7
           and rsv_batch8=strRSV_BATCH8
           and supplier_no = strSupplierNo
           and untread_type = strUntreadType
           and rgst_name = strWorker_No
           and batch_no=strBatchNo
           and wave_no=strWaveNo and device_no=strDeviceNo
           and quality_flag=strQualityFlag;
       if nCheck_Qty+v_nPreCheckQty<0 then
          strResult := 'N|当前商品已无量可扣';
          return;
       end if;

    end if;


    if (nIsAdd = 0) then

      --锁临时板明细
      update ridata_check_pal_tmp t
         set t.status = status
       where WAREHOUSE_NO = strWAREHOUSE_NO and enterprise_no=strEnterPriseNo
         and owner_no = strOwner_No
         and S_Check_No = strS_Check_No
         and label_no = strLabel_No
         and packing_qty=nPack_Qty
         and quality_flag=strQualityFlag;
      --取最大的row_id
      begin
        select max(row_id) + 1
          into intRowId
          from ridata_check_pal_tmp
         where WAREHOUSE_NO = strWAREHOUSE_NO and enterprise_no=strEnterPriseNo
           and owner_no = strOwner_No
           and S_Check_No = strS_Check_No
           and label_no = strLabel_No;
      exception
        when no_data_found then
          intRowId := 1;
      end;
      if (intRowId is null) then
        intRowId := 1;
      end if;
      --覆盖式先删除,后增加
      delete from ridata_check_pal_tmp
       where WAREHOUSE_NO = strWAREHOUSE_NO and enterprise_no=strEnterPriseNo
         and owner_no = strOwner_No
         and S_Check_No = strS_Check_No
         and label_no = strLabel_No
         and article_no = strArticle_no
         and barcode = strBarcode
         and packing_qty = nPack_Qty
         and Quality = strQuality
         and status = '10'
         and stock_type = strStockType
         and stock_value = strStockValue
         and sub_label_no = strsub_Label_No
         and lot_no = strLotNo
         and produce_date = dtProduceDate
         and expire_date = dtExpireDate
         and rsv_batch1=strRSV_BATCH1
         and rsv_batch2=strRSV_BATCH2
         and rsv_batch3=strRSV_BATCH3
         and rsv_batch4=strRSV_BATCH4
         and rsv_batch5=strRSV_BATCH5
         and rsv_batch6=strRSV_BATCH6
         and rsv_batch7=strRSV_BATCH7
         and rsv_batch8=strRSV_BATCH8
         and supplier_no = strSupplierNo
         and untread_type = strUntreadType
         and rgst_name = strWorker_No
         and batch_no=strBatchNo
         and wave_no=strWaveNo
         and device_no=strDeviceNo
         and quality_flag=strQualityFlag;

      insert into ridata_check_pal_tmp
        (enterprise_no,row_id,warehouse_no,Owner_No,S_Check_No,s_untread_no,
         Article_No,Quality,Produce_Date,Expire_Date,
         Lot_No,Barcode,Packing_Qty,Check_Qty,
         Label_No,status,
         Business_Type,Fixpal_Flag,printer_group_no,Dock_No,
         Stock_Type,Stock_Value,Sub_Label_No,
         RSV_BATCH1,RSV_BATCH2,RSV_BATCH3,RSV_BATCH4,
         RSV_BATCH5,RSV_BATCH6,RSV_BATCH7,RSV_BATCH8,
         check_tools,untread_type,supplier_no,cell_no,
         rgst_name,rgst_date,wave_no,batch_no,device_no,quality_flag,label_id,class_type)
      values
        (strEnterPriseNo,intRowId,strWAREHOUSE_NO,strOwner_No,strS_Check_No,strsUntreadNo,
         strArticle_No,strQuality,dtProduceDate,dtExpireDate,
         strLotNo,strBarcode,nPack_Qty,nCheck_Qty,
         strLabel_No,'10',
         strBusiness_Type,strFixpal_Flag,strPrintGroup,strDock_No,
         strStockType,strStockValue,strSub_Label_No,
         strRSV_BATCH1,strRSV_BATCH2,strRSV_BATCH3,strRSV_BATCH4,
         strRSV_BATCH5,strRSV_BATCH6,strRSV_BATCH7,strRSV_BATCH1,
         strCheck_Tools,strUntreadType,strSupplierNo,strCellNo,
         strWorker_No,sysdate,strWaveNo,strBatchNo,strDeviceNo,strQualityFlag,strLabelId,strClassType);
    ELSE
        --更新不了则新增
        update ridata_check_pal_tmp
           set Check_Qty = check_qty + nCheck_Qty
         where WAREHOUSE_NO = strWAREHOUSE_NO and enterprise_no=strEnterPriseNo
           and owner_no = strOwner_No
           and S_Check_No = strS_Check_No
           and label_no = strLabel_No
           and article_no = strArticle_no
           and barcode = strBarcode
           and packing_qty = nPack_Qty
           and Quality = strQuality
           and status = '10'
           and stock_type = strStockType
           and stock_value = strStockValue
           and sub_label_no = strsub_Label_No
           and lot_no = strLotNo
           and produce_date = dtProduceDate
           and expire_date = dtExpireDate
           and rsv_batch1=strRSV_BATCH1
           and rsv_batch2=strRSV_BATCH2
           and rsv_batch3=strRSV_BATCH3
           and rsv_batch4=strRSV_BATCH4
           and rsv_batch5=strRSV_BATCH5
           and rsv_batch6=strRSV_BATCH6
           and rsv_batch7=strRSV_BATCH7
           and rsv_batch8=strRSV_BATCH8
           and supplier_no = strSupplierNo
           and untread_type = strUntreadType
           and rgst_name = strWorker_No
           and batch_no=strBatchNo
           and wave_no=strWaveNo and device_no=strDeviceNo
           and quality_flag=strQualityFlag;
        if sql%rowcount <= 0 then

          --取最大的row_id
          begin
            select max(row_id) + 1
              into intRowId
              from ridata_check_pal_tmp
             where WAREHOUSE_NO = strWAREHOUSE_NO and enterprise_no=strEnterPriseNo
               and owner_no = strOwner_No
               and S_Check_No = strS_Check_No
               and label_no = strLabel_No;
          exception
            when no_data_found then
              intRowId := 1;
          end;
          if (intRowId is null) then
            intRowId := 1;
          end if;

          insert into ridata_check_pal_tmp
            (enterprise_no,row_id,warehouse_no,Owner_No,S_Check_No,s_untread_no,
             Article_No,Quality,Produce_Date,Expire_Date,
             Lot_No,Barcode,Packing_Qty,Check_Qty,
             Label_No,status,
             Business_Type,Fixpal_Flag,printer_group_no,Dock_No,
             Stock_Type,Stock_Value,Sub_Label_No,
             RSV_BATCH1,RSV_BATCH2,RSV_BATCH3,RSV_BATCH4,
             RSV_BATCH5,RSV_BATCH6,RSV_BATCH7,RSV_BATCH8,
             check_tools,untread_type,supplier_no,cell_no,
             rgst_name,rgst_date,wave_no,batch_no,device_no,quality_flag,label_id,class_type)
          values
            (strEnterPriseNo,intRowId,strWAREHOUSE_NO,strOwner_No,strS_Check_No,strsUntreadNo,
             strArticle_No,strQuality,dtProduceDate,dtExpireDate,
             strLotNo,strBarcode,nPack_Qty,nCheck_Qty,
             strLabel_No,'10',
             strBusiness_Type,strFixpal_Flag,strPrintGroup,strDock_No,
             strStockType,strStockValue,strSub_Label_No,
             strRSV_BATCH1,strRSV_BATCH2,strRSV_BATCH3,strRSV_BATCH4,
             strRSV_BATCH5,strRSV_BATCH6,strRSV_BATCH7,strRSV_BATCH1,
             strCheck_Tools,strUntreadType,strSupplierNo,strCellNo,
             strWorker_No,sysdate,strWaveNo,strBatchNo,strDeviceNo,strQualityFlag,strLabelId,strClassType);
          end if;
    end if;
    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_InsertPalTmp;

  -----------------------------------【存储验收begin】---------------------------------------------------
  /**********************************************************************************************
   作者:luozhiling
   日期:  2015-10-20
   功能: 返配单对象：写入临时板表日志
  ************************************************************************************************/
  procedure p_InsertPalTmp_Log(strEnterPriseNo    in ridata_check_pal_tmp.enterprise_no%type,
                           strWAREHOUSE_NO    in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                           strOwner_No        in ridata_check_pal_tmp.owner_no%type, --委托业主编码
                           strsUntreadNo      in ridata_untread_sm.s_untread_no%type,
                           strS_Check_No      in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                           strArticle_No      in ridata_check_pal_tmp.article_no%type, --商品编码
                           strBarcode         in ridata_check_pal_tmp.barcode%type, --商品条码
                           strQuality         in  ridata_check_d.quality%type,--品质
                           dtProduceDate      in  ridata_check_d.produce_date%type,
                           dtExpireDate       in  Ridata_check_d.expire_date%type,
                           strLotNo           in  ridata_check_d.lot_no%type,--批次号
                           strRSV_BATCH1      in  ridata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                           strRSV_BATCH2      in  ridata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                           strRSV_BATCH3      in  ridata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                           strRSV_BATCH4      in  ridata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                           strRSV_BATCH5      in  ridata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                           strRSV_BATCH6      in  ridata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                           strRSV_BATCH7      in  ridata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                           strRSV_BATCH8      in  ridata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                           nPack_Qty          in ridata_check_pal_tmp.packing_qty%type, --包装数量
                           nCheck_Qty         in ridata_check_pal_tmp.check_qty%type, --验收数量
                           strLabel_No        in ridata_check_pal_tmp.label_no%type, --板号
                           strLabelId         in ridata_check_pal_tmp.label_id%type,
                           strBusiness_Type   in ridata_check_pal_tmp.business_type%type, --业务类型
                           strFixpal_Flag     in ridata_check_pal_tmp.fixpal_flag%type, --板类型
                           strPrintGroup      in ridata_check_pal_tmp.printer_group_no%type, --打印机组
                           strDock_No         in ridata_check_pal_tmp.dock_no%type, --码头
                           strStockType       in ridata_check_pal_tmp.stock_type%type, --存储类型
                           strStockValue      in ridata_check_pal_tmp.stock_value%type, --存储类型对应值
                           strSub_Label_No   in ridata_check_pal_tmp.sub_label_no%type, --尾箱标签
                           strWorker_No       in ridata_check_pal_tmp.rgst_name%type, --验收人员
                           strUntreadType     in ridata_check_pal_tmp.untread_type%type, --返配单别
                           strSupplierNo      in ridata_check_pal_tmp.supplier_no%type, --供应商
                           strCheck_Tools     in char, --检查工具 1:前台2:RF
                           strWaveNo          in ridata_check_pal_tmp.wave_no%type,
                           strBatchNo         in ridata_check_pal_tmp.batch_no%type,
                           strCellNo          in ridata_check_pal_tmp.cell_no%type,
                           strDeviceNo        in ridata_check_pal_tmp.device_no%type,
                           strQualityFlag     in ridata_check_pal_tmp.quality_flag%type,--品质类型0滞销品，1过季品，A质量问题，B次品
                           nIsAdd             in integer, --是否累加 0:覆盖 1:累加
                           strResult          out varchar2) is--返回结果

    intRowId ridata_check_pal_tmp.row_id%type; --记录最大的row_id
  begin
    strResult := 'N|[p_InsertPalTmp_Log]';

    if (nIsAdd = 0) then

      --锁临时板明细
      update ridata_check_pal_tmp_log t
         set t.status = status
       where WAREHOUSE_NO = strWAREHOUSE_NO and enterprise_no=strEnterPriseNo
         and owner_no = strOwner_No
         and S_Check_No = strS_Check_No
         and label_no = strLabel_No
         and packing_qty=nPack_Qty
         and quality_flag=strQualityFlag;
      --取最大的row_id
      begin
        select max(row_id) + 1
          into intRowId
          from ridata_check_pal_tmp_log
         where WAREHOUSE_NO = strWAREHOUSE_NO and enterprise_no=strEnterPriseNo
           and owner_no = strOwner_No
           and S_Check_No = strS_Check_No
           and label_no = strLabel_No;
      exception
        when no_data_found then
          intRowId := 1;
      end;
      if (intRowId is null) then
        intRowId := 1;
      end if;
      --覆盖式先删除,后增加
      delete from ridata_check_pal_tmp_log
       where WAREHOUSE_NO = strWAREHOUSE_NO and enterprise_no=strEnterPriseNo
         and owner_no = strOwner_No
         and S_Check_No = strS_Check_No
         and label_no = strLabel_No
         and article_no = strArticle_no
         and barcode = strBarcode
         and packing_qty = nPack_Qty
         and Quality = strQuality
         and status = '10'
         and stock_type = strStockType
         and stock_value = strStockValue
         and sub_label_no = strsub_Label_No
         and lot_no = strLotNo
         and produce_date = dtProduceDate
         and expire_date = dtExpireDate
         and rsv_batch1=strRSV_BATCH1
         and rsv_batch2=strRSV_BATCH2
         and rsv_batch3=strRSV_BATCH3
         and rsv_batch4=strRSV_BATCH4
         and rsv_batch5=strRSV_BATCH5
         and rsv_batch6=strRSV_BATCH6
         and rsv_batch7=strRSV_BATCH7
         and rsv_batch8=strRSV_BATCH8
         and supplier_no = strSupplierNo
         and untread_type = strUntreadType
         and rgst_name = strWorker_No
         and batch_no=strBatchNo
         and wave_no=strWaveNo
         and device_no=strDeviceNo
         and quality_flag=strQualityFlag;

      insert into ridata_check_pal_tmp_log
        (enterprise_no,row_id,warehouse_no,Owner_No,S_Check_No,s_untread_no,
         Article_No,Quality,Produce_Date,Expire_Date,
         Lot_No,Barcode,Packing_Qty,Check_Qty,
         Label_No,status,
         Business_Type,Fixpal_Flag,printer_group_no,Dock_No,
         Stock_Type,Stock_Value,Sub_Label_No,
         RSV_BATCH1,RSV_BATCH2,RSV_BATCH3,RSV_BATCH4,
         RSV_BATCH5,RSV_BATCH6,RSV_BATCH7,RSV_BATCH8,
         check_tools,untread_type,supplier_no,cell_no,
         rgst_name,rgst_date,wave_no,batch_no,device_no,quality_flag,label_id)
      values
        (strEnterPriseNo,intRowId,strWAREHOUSE_NO,strOwner_No,strS_Check_No,strsUntreadNo,
         strArticle_No,strQuality,dtProduceDate,dtExpireDate,
         strLotNo,strBarcode,nPack_Qty,nCheck_Qty,
         strLabel_No,'10',
         strBusiness_Type,strFixpal_Flag,strPrintGroup,strDock_No,
         strStockType,strStockValue,strSub_Label_No,
         strRSV_BATCH1,strRSV_BATCH2,strRSV_BATCH3,strRSV_BATCH4,
         strRSV_BATCH5,strRSV_BATCH6,strRSV_BATCH7,strRSV_BATCH1,
         strCheck_Tools,strUntreadType,strSupplierNo,strCellNo,
         strWorker_No,sysdate,strWaveNo,strBatchNo,strDeviceNo,strQualityFlag,strLabelId);
    else
        --更新不了则新增
        update ridata_check_pal_tmp_log
           set Check_Qty = check_qty + nCheck_Qty
         where WAREHOUSE_NO = strWAREHOUSE_NO and enterprise_no=strEnterPriseNo
           and owner_no = strOwner_No
           and S_Check_No = strS_Check_No
           and label_no = strLabel_No
           and article_no = strArticle_no
           and barcode = strBarcode
           and packing_qty = nPack_Qty
           and Quality = strQuality
           and status = '10'
           and stock_type = strStockType
           and stock_value = strStockValue
           and sub_label_no = strsub_Label_No
           and lot_no = strLotNo
           and produce_date = dtProduceDate
           and expire_date = dtExpireDate
           and rsv_batch1=strRSV_BATCH1
           and rsv_batch2=strRSV_BATCH2
           and rsv_batch3=strRSV_BATCH3
           and rsv_batch4=strRSV_BATCH4
           and rsv_batch5=strRSV_BATCH5
           and rsv_batch6=strRSV_BATCH6
           and rsv_batch7=strRSV_BATCH7
           and rsv_batch8=strRSV_BATCH8
           and supplier_no = strSupplierNo
           and untread_type = strUntreadType
           and rgst_name = strWorker_No
           and batch_no=strBatchNo
           and wave_no=strWaveNo and device_no=strDeviceNo
           and quality_flag=strQualityFlag;
        if sql%rowcount <= 0 then

          --取最大的row_id
          begin
            select max(row_id) + 1
              into intRowId
              from ridata_check_pal_tmp_log
             where WAREHOUSE_NO = strWAREHOUSE_NO and enterprise_no=strEnterPriseNo
               and owner_no = strOwner_No
               and S_Check_No = strS_Check_No
               and label_no = strLabel_No;
          exception
            when no_data_found then
              intRowId := 1;
          end;
          if (intRowId is null) then
            intRowId := 1;
          end if;

          insert into ridata_check_pal_tmp_log
            (enterprise_no,row_id,warehouse_no,Owner_No,S_Check_No,s_untread_no,
             Article_No,Quality,Produce_Date,Expire_Date,
             Lot_No,Barcode,Packing_Qty,Check_Qty,
             Label_No,status,
             Business_Type,Fixpal_Flag,printer_group_no,Dock_No,
             Stock_Type,Stock_Value,Sub_Label_No,
             RSV_BATCH1,RSV_BATCH2,RSV_BATCH3,RSV_BATCH4,
             RSV_BATCH5,RSV_BATCH6,RSV_BATCH7,RSV_BATCH8,
             check_tools,untread_type,supplier_no,cell_no,
             rgst_name,rgst_date,wave_no,batch_no,device_no,quality_flag,label_id)
          values
            (strEnterPriseNo,intRowId,strWAREHOUSE_NO,strOwner_No,strS_Check_No,strsUntreadNo,
             strArticle_No,strQuality,dtProduceDate,dtExpireDate,
             strLotNo,strBarcode,nPack_Qty,nCheck_Qty,
             strLabel_No,'10',
             strBusiness_Type,strFixpal_Flag,strPrintGroup,strDock_No,
             strStockType,strStockValue,strSub_Label_No,
             strRSV_BATCH1,strRSV_BATCH2,strRSV_BATCH3,strRSV_BATCH4,
             strRSV_BATCH5,strRSV_BATCH6,strRSV_BATCH7,strRSV_BATCH1,
             strCheck_Tools,strUntreadType,strSupplierNo,strCellNo,
             strWorker_No,sysdate,strWaveNo,strBatchNo,strDeviceNo,strQualityFlag,strLabelId);
          end if;
    end if;
    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_InsertPalTmp_Log;

  /*
   作者:luozhiling
   日期:  2013-10-02
   功能: 返配单对象：将临时板数据写入板明细、汇总返配明细、返配明细
  */
  procedure p_InsertCheckNo(strEnterPriseNo       in ridata_check_pal_tmp.enterprise_no%type,
                            strWareHouseNo        in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                            strOwnerNo            in ridata_check_pal_tmp.owner_no%type, --委托业主
                            strUntreadNo          in ridata_check_m.untread_no%type, --返配单号
                            strsCheckNo           in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                            strWorkerNo           in ridata_check_pal_tmp.rgst_name%type, --操作人
                            strLabelNo            in ridata_check_pal_tmp.label_no%type, --老板号
                            strNewLabelNo         in ridata_check_pal_tmp.label_no%type, --新板号
                            strContainNo          in ridata_check_pal.container_no%type, --内部容器号
                            intCheckQty           in ridata_check_pal_tmp.check_qty%type, --验收数量
                            intRowId              in ridata_check_pal_tmp.row_id%type, --临时板id
                            strResult             out varchar2) is

    strCheck_No       ridata_check_m.check_no%type;
    strSubLabelNoTmp ridata_check_pal.sub_label_no%type; --接收尾箱标签
    nCheckRowId       ridata_check_pal.check_row_id%type;

  begin
    strResult := 'N|[p_InsertCheckNo]';
    for P in (select *
                from ridata_check_pal_tmp
               where WAREHOUSE_NO = strWareHouseNo and enterprise_no=strEnterPriseNo
                 and owner_no = strOwnerNo
                 and s_check_no = strsCheckNo
                 and label_no = strLabelNo
                 and row_id = intRowId) loop

      if (p.business_type = 3 or p.business_type = 6) then
        strsubLabelNoTmp := p.sub_label_no;
      else
        strsubLabelNoTmp := strNewLabelNo;
      end if;

      --取验收单号
      begin
        select check_no
          into strCheck_No
          from ridata_check_m
         where WAREHOUSE_NO = strWareHouseNo and enterprise_no=strEnterPriseNo
           and owner_no = strOwnerNo
           and untread_no = strUntreadNo;
      exception
        when no_data_found then
          strResult := 'N|[E24203]'; --查询验收单号为空!
          return;
          if (strCheck_No is null) then
            strResult := 'N|[E24203]';
            return;
          end if;
      end;

      --获取CHECK_ROW_ID
      begin
        select row_id
          into nCheckRowId
          from ridata_check_d t
         where t.WAREHOUSE_NO = strWareHouseNo and t.enterprise_no=strEnterPriseNo
           and t.owner_no = strOwnerNo
           and t.check_no = strCheck_No
           and t.article_no = p.article_no
           and t.barcode = p.barcode
           and t.packing_qty = p.packing_qty
           and t.lot_no = p.lot_no
           and t.produce_date = p.produce_date
           and t.expire_date = p.expire_date
           and t.quality = p.quality
           and t.rsv_batch1 = p.rsv_batch1
           and t.rsv_batch2 = p.rsv_batch2
           and t.rsv_batch3 = p.rsv_batch3
           and t.rsv_batch4 = p.rsv_batch4
           and t.rsv_batch5 = p.rsv_batch5
           and t.rsv_batch6 = p.rsv_batch6
           and t.rsv_batch7 = p.rsv_batch7
           and t.rsv_batch8 = p.rsv_batch8
           and t.check_worker = strWorkerNo;
      exception
        when no_data_found then
          --若不存着属性相同的明细,
          strResult := 'N|[E24204]'; --查询验收明细为空!
          return;
      end;
      --更新返配单数量
      update ridata_untread_d
         set check_qty = check_qty + intCheckQty, status = '12'
       where WAREHOUSE_NO = strWareHouseNo and enterprise_no=strEnterPriseNo
         and owner_no = strOwnerNo
         and untread_no = strUntreadNo
         and article_no = p.article_no
         and packing_qty = p.packing_qty;
      if (sql%rowcount <= 0) then
        strResult := 'N|[E24205]'; --回写返配数量错误!
        return;
      end if;

      --更新/写入板明细

      update ridata_check_pal
         set check_qty = check_qty + intCheckQty,updt_name=strWorkerNo,updt_date=sysdate
       where WAREHOUSE_NO = strWareHouseNo and enterprise_no=strEnterPriseNo
         and owner_no = strOwnerNo
         and Check_No = strCheck_No
         and check_row_id = nCheckRowId
         and label_no = strNewLabelNo
         and container_no = strContainNo
         AND sub_label_no = strsubLabelNoTmp;

      if (sql%rowcount <= 0) then

        insert into ridata_check_pal
          (enterprise_no,WAREHOUSE_NO,owner_no,label_no,
           check_no,check_row_id,
           article_no,packing_qty,
           check_qty,status,
           printer_group_no,dock_no,
           container_no,fixpal_flag,
           QUALITY,Sub_LABEL_NO,
           BUSINESS_TYPE,CELL_NO,batch_no,wave_no,device_no,FIRSTCHECK_LABEL_NO,
           rgst_name,rgst_date,updt_name,updt_date,untread_type,class_type)
        values
          (strEnterPriseNo,strWareHouseNo,strOwnerNo,strNewLabelNo,
           strCheck_No,nCheckRowId,
           p.article_no,p.packing_qty,
           intCheckQty,'10',
           p.printer_group_no,p.dock_no,
           strContainNo,p.fixpal_flag,
           p.quality_flag,strSubLabelNoTmp,
           p.business_type,p.cell_no,p.batch_no,p.wave_no,p.device_no,p.label_id,
           strWorkerNo,sysdate,strWorkerNo,sysdate,p.untread_type,p.class_type);
      end if;
    end loop;
    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_InsertCheckNo;
  /*************************************************************************************
   作者:luozhiling
   日期:  2014-11-09
   功能: 返配单对象：将临时板数据写入板明细、汇总返配明细、返配明细,超量
  **************************************************************************************/
  procedure p_OverSkuInsertCheckNo(strEnterPriseNo in ridata_check_pal_tmp.enterprise_no%type,
                                   strWareHouseNo in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                   strOwnerNo     in ridata_check_pal_tmp.owner_no%type, --委托业主
                                   strUntreadNo   in ridata_check_m.untread_no%type, --返配单号
                                   strsCheckNo    in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                   strWorkerNo    in ridata_check_pal_tmp.rgst_name%type, --操作人
                                   strLabelNo     in ridata_check_pal_tmp.label_no%type, --老板号
                                   strNewLabelNo  in ridata_check_pal_tmp.label_no%type, --新板号
                                   strContainNo   in ridata_check_pal.container_no%type, --内部容器号
                                   intCheckQty    in ridata_check_pal_tmp.check_qty%type, --验收数量
                                   intRowId       in ridata_check_pal_tmp.row_id%type, --临时板id
                                   strResult      out varchar2) is

    strCheck_No       ridata_check_m.check_no%type;
    strSubLabelNoTmp ridata_check_pal.sub_label_no%type; --接收尾箱标签
    nCheckRowId       ridata_check_pal.check_row_id%type;
    nPoId             ridata_untread_d.po_id%type;
  begin
    strResult := 'N|[p_InsertCheckNo]';
    for P in (select *
                from ridata_check_pal_tmp
               where WAREHOUSE_NO = strWareHouseNo and enterprise_no=strEnterPriseNo
                 and owner_no = strOwnerNo
                 and s_check_no = strsCheckNo
                 and label_no = strLabelNo
                 and row_id = intRowId) loop

      if (p.business_type = 3 or p.business_type = 6) then
        strsubLabelNoTmp := p.sub_label_no;
      else
        strsubLabelNoTmp := strNewLabelNo;
      end if;

      --取验收单号
      begin
        select check_no
          into strCheck_No
          from ridata_check_m
         where WAREHOUSE_NO = strWareHouseNo and enterprise_no=strEnterPriseNo
           and owner_no = strOwnerNo
           and untread_no = strUntreadNo;
      exception
        when no_data_found then
          strResult := 'N|[E24203]'; --查询验收单号为空!
          return;
          if (strCheck_No is null) then
            strResult := 'N|[E24203]';
            return;
          end if;
      end;

      --获取CHECK_ROW_ID
      begin
        select row_id
          into nCheckRowId
          from ridata_check_d t
         where t.WAREHOUSE_NO = strWareHouseNo and enterprise_no=strEnterPriseNo
           and t.owner_no = strOwnerNo
           and t.check_no = strCheck_No
           and t.article_no = p.article_no
           and t.barcode = p.barcode
           and t.packing_qty = p.packing_qty
           and t.lot_no = p.lot_no
           and t.produce_date = p.produce_date
           and t.expire_date = p.expire_date
           and t.quality = p.quality
           and t.rsv_batch1 = p.rsv_batch1
           and t.rsv_batch2 = p.rsv_batch2
           and t.rsv_batch3 = p.rsv_batch3
           and t.rsv_batch4 = p.rsv_batch4
           and t.rsv_batch5 = p.rsv_batch5
           and t.rsv_batch6 = p.rsv_batch6
           and t.rsv_batch7 = p.rsv_batch7
           and t.rsv_batch8 = p.rsv_batch8
           and t.check_worker = strWorkerNo;
      exception
        when no_data_found then
          --若不存着属性相同的明细,
          strResult := 'N|[E24204]'; --查询验收明细为空!
          return;
      end;
      --更新返配单数量
      update ridata_untread_d
         set check_qty = check_qty + intCheckQty, status = '12'
       where WAREHOUSE_NO = strWareHouseNo and enterprise_no=strEnterPriseNo
         and owner_no = strOwnerNo
         and untread_no = strUntreadNo
         and article_no = p.article_no
         and packing_qty = p.packing_qty;
      if (sql%rowcount <= 0) then
         --写返配单数据
         --获取最大的PO_ID
         select nvl(max(po_id)+1,1) into nPoId from ridata_untread_d where warehouse_no=strWareHouseNo
                and owner_no=strOwnerNo and untread_no=strUntreadNo and enterprise_no=strEnterPriseNo;
         insert into ridata_untread_d(enterprise_no,warehouse_no,owner_no,untread_no,po_id,supplier_no,
                article_no,packing_qty,untread_qty,check_qty,check_name,check_date,status)
                values(strEnterPriseNo,strWareHouseNo,strOwnerNo,strUntreadNo,nPoId,p.supplier_no,
                p.article_no,p.packing_qty,0,intCheckQty,strWorkerNo,sysdate,'12');
      end if;

      --更新/写入板明细

      update ridata_check_pal
         set check_qty = check_qty + intCheckQty,updt_name=strWorkerNo,updt_date=sysdate
       where WAREHOUSE_NO = strWareHouseNo and enterprise_no=strEnterPriseNo
         and owner_no = strOwnerNo
         and Check_No = strCheck_No
         and check_row_id = nCheckRowId
         and label_no = strNewLabelNo
         and container_no = strContainNo
         AND sub_label_no = strsubLabelNoTmp;

      if (sql%rowcount <= 0) then

        insert into ridata_check_pal
          (enterprise_no,WAREHOUSE_NO,owner_no,label_no,
           check_no,check_row_id,
           article_no,packing_qty,
           check_qty,status,
           printer_group_no,dock_no,
           container_no,fixpal_flag,
           QUALITY,Sub_LABEL_NO,
           BUSINESS_TYPE,CELL_NO,batch_no,wave_no,device_no,FIRSTCHECK_LABEL_NO,
           rgst_name,rgst_date,updt_name,updt_date,untread_type,class_type)
        values
          (strEnterPriseNo,strWareHouseNo,strOwnerNo,strNewLabelNo,
           strCheck_No,nCheckRowId,
           p.article_no,p.packing_qty,
           intCheckQty,'10',
           p.printer_group_no,p.dock_no,
           strContainNo,p.fixpal_flag,
           p.quality_flag,strSubLabelNoTmp,
           p.business_type,p.cell_no,p.batch_no,p.wave_no,p.device_no,p.label_id,
           strWorkerNo,sysdate,strWorkerNo,sysdate,p.untread_type,p.class_type);
      end if;
    end loop;
    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_OverSkuInsertCheckNo;

  /*
   作者:luozhiling
   日期:  2013-10-04
   功能: 写返配验收单头档并返回汇总单号
  */
  procedure p_InsertImCheckMaster(strEnterPriseNo        in ridata_check_m.enterprise_no%type,
                                  strWAREHOUSE_NO        in ridata_check_m.WAREHOUSE_NO%type, --仓库编码
                                  strOwnerNo             in ridata_check_m.owner_no%type, --委托业主编码
                                  strSImportNo           in ridata_untread_mm.s_untread_no%type, --返配汇总单号
                                  strDockNo              in ridata_check_m.dock_no%type, --码头号
                                  strWorkerNo            in ridata_check_m.check_worker%type, --操作人
                                  strPrintGroup          in ridata_check_m.printer_group_no%type, --打印机组
                                  strCheckTools          in ridata_check_m.check_tools%type, --验收工具
                                  strSCheckNo            out ridata_check_m.s_check_no%type, --汇总验收单号
                                  strResult              out varchar2) is--返回结果

    /*
     作者:luozhiling
     日期:  2013-10-04
     功能: 写验收单头档并返回汇总单号
    */
    strCheckNo ridata_check_m.check_no%type; --验收单号
    strMsg     varchar2(200);
  begin
    strResult := 'N|[p_ridata_InsertImCheckMaster]';

    --取汇总验收单号
    begin
      PKLG_WMS_BASE.p_getsheetno(strEnterPriseNo,strWAREHOUSE_NO,
                                 'SC',
                                 strSCheckNo,
                                 strMsg);
      if (strSCheckNo is null or substr(strMsg, 1, 1) = 'N') then
        strResult := 'N|[E24206]'; --取汇总验收单号错误!
        return;
      end if;
    end;

    --循环返配单号写入验收单号
    begin
      for A in (select distinct iim.untread_no, iim.untread_type
                  from ridata_untread_sm ism, ridata_untread_m iim
                 where ism.WAREHOUSE_NO = iim.WAREHOUSE_NO and ism.enterprise_no=iim.enterprise_no
                   and ism.enterprise_no=strEnterPriseNo and ism.owner_no = iim.owner_no
                   and ism.untread_no = iim.untread_no
                   and ism.WAREHOUSE_NO = strWAREHOUSE_NO
                   and ism.owner_no = strOwnerNo
                   and ism.s_untread_no = strSImportNo
                   and ism.status <> '16'
                   and ism.status <> '13') loop
        --取验收单号
        begin
          strCheckNo := '';
          strMsg     := '';
          PKLG_WMS_BASE.p_getsheetno(strEnterPriseNo,strWAREHOUSE_NO,
                                     'IC',
                                     strCheckNo,
                                     strMsg);
          if (strCheckNo is null or substr(strMsg, 1, 1) = 'N') then
            strResult := 'N|[E24207]'; --取验收单号错误!
            return;
          end if;
        end;

        --写入验收单头档
        begin
          Insert into ridata_check_m
            (enterprise_no,WAREHOUSE_NO,
             owner_no,
             check_no,
             s_check_no,
             untread_type,
             s_untread_no,
             untread_no,
             dock_no,
             check_worker,
             status,
             check_start_date,
             check_end_date,
             rgst_name,
             rgst_date,
             PRINTER_GROUP_NO,
             check_tools)
          values
            (strEnterPriseNo,strWAREHOUSE_NO,
             strOwnerNo,
             strCheckNo,
             strSCheckNo,
             a.untread_type,
             strSImportNo,
             a.untread_no,
             strDockNo,
             strWorkerNo,
             '12',
             sysdate,
             sysdate,
             strWorkerNo,
             sysdate,
             strPrintGroup,
             strCheckTools);
          if (sql%rowcount <= 0) then
            strResult := 'N|[E24208]'; --写入验收单头档错误!
            return;
          end if;
        end;

      end loop;
    end;
    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_InsertImCheckMaster;

  /*****************************************************************************************************
  Luozhiling
  2013-10-10
  功能：更新返配单状态
  *******************************************************************************************************/
  procedure P_UpdateIdata(strEnterPriseNo      in ridata_check_m.enterprise_no%type,
                          strWareHouseNo       in ridata_check_m.warehouse_no%type,
                          strOwnerNo           in ridata_check_m.owner_no%type,
                          strUntreadNo         in ridata_untread_sm.s_untread_no%type,
                          strResult            out varchar2) is--返回结果
  begin
    strResult := 'N|[P_UpdateIdata]';

    update ridata_untread_m t
       set t.status = '12'
     where exists (select 1
              from ridata_untread_sm ism
             where ism.enterprise_no=strEnterPriseNo and ism.warehouse_no = strWareHouseNo
               and ism.owner_no = strOwnerNo
               and ism.untread_no = t.untread_no
               and ism.warehouse_no = t.warehouse_no
               and ism.owner_no = t.owner_no
               and ism.s_untread_no = strUntreadNo)
       and t.status = '10';

  end P_UpdateIdata;

  /*************************************************************************************
   作者:luozhiling
   日期:  2014-11-09
   功能: 返配单对象：将临时板数据写入板明细、汇总返配明细、返配明细,超量
  **************************************************************************************/
  procedure p_InsertCheckD(strEnterPriseNo       in ridata_check_pal_tmp.enterprise_no%type,
                           strWareHouseNo        in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                           strOwnerNo            in ridata_check_pal_tmp.owner_no%type, --委托业主
                           strsUntreadNo         in ridata_untread_sm.s_untread_no%type, --返配汇总单号
                           strSCheckNo           in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                           strUntreadNo          in ridata_check_pal_tmp.s_check_no%type,
                           strWorkerNo           in ridata_check_pal_tmp.rgst_name%type, --操作人
                           nCheckQty             in ridata_check_pal_tmp.check_qty%type,
                           intRowId              in ridata_check_pal_tmp.row_id%type,
                           strLabelNo            in ridata_check_pal_tmp.label_no%type,
                           strResult             out varchar2) is

    intCheck_row_id ridata_check_pal.check_row_id%type; --板rowid
    v_strCheckNo    ridata_check_pal.check_no%type;
    v_price         stock_article_info.price%type;--单价
  begin
    strResult := 'N|[p_InsertCheckD]';

    --获取验收单号

    begin
      select check_no
        into v_strCheckNo
        from ridata_check_m
       where wareHouse_no = strWareHouseno and enterprisE_no=strEnterPriseNo
         and owner_no = strOwnerNo
         and untread_no = strUntreadNo
         and s_check_no = strsCheckNo;
    exception
      when no_data_found then
        strResult := 'N|[E24203]'; --查询验收单号为空!
        return;
    end;

    if (v_strCheckNo is null) then
      strResult := 'N|[E24203]';
      return;
    end if;

    for P in (select *
                from ridata_check_pal_tmp
               where WAREHOUSE_NO = strWareHouseNo and enterprise_no=strEnterPriseNo
                 and owner_no = strOwnerNo
                 and s_untread_no = strsUntreadNo
                 and s_check_no = strSCheckNo
                 and label_no = strLabelNo
                 and row_id = intRowId) loop

      --若已经存着属性相同的明细，累加数量
      begin
        select row_id
          into intCheck_row_id
          from ridata_check_d t
         where t.WAREHOUSE_NO = strWareHouseNo and enterprise_no=strEnterPriseNo
           and t.owner_no = strOwnerNo
           and t.check_no = v_strCheckNo
           and t.article_no = p.article_no
           and t.barcode = p.barcode
           and t.packing_qty = p.packing_qty
           and t.lot_no = p.lot_no
           and t.produce_date = p.produce_date
           and t.expire_date = p.expire_date
           and t.quality = p.quality
           and t.rsv_batch1 = p.rsv_batch1
           and t.rsv_batch2 = p.rsv_batch2
           and t.rsv_batch3 = p.rsv_batch3
           and t.rsv_batch4 = p.rsv_batch4
           and t.rsv_batch5 = p.rsv_batch5
           and t.rsv_batch6 = p.rsv_batch6
           and t.rsv_batch7 = p.rsv_batch7
           and t.rsv_batch8 = p.rsv_batch8
           and t.check_worker = strWorkerNo;

        --更新返配单数量
        update ridata_check_d t
           set t.check_qty    = t.check_qty + nCheckQty,
               check_end_date = sysdate
         where t.WAREHOUSE_NO = strWareHouseNo and t.enterprise_no=strEnterPriseNo
           and t.owner_no = strOwnerNo
           and t.check_no = v_strCheckNo
           and t.article_no = p.article_no
           and t.barcode = p.barcode
           and t.packing_qty = p.packing_qty
           and t.lot_no = p.lot_no
           and t.produce_date = p.produce_date
           and t.expire_date = p.expire_date
           and t.rsv_batch1 = p.rsv_batch1
           and t.rsv_batch2 = p.rsv_batch2
           and t.rsv_batch3 = p.rsv_batch3
           and t.rsv_batch4 = p.rsv_batch4
           and t.rsv_batch5 = p.rsv_batch5
           and t.rsv_batch6 = p.rsv_batch6
           and t.rsv_batch7 = p.rsv_batch7
           and t.rsv_batch8 = p.rsv_batch8
           and t.quality = p.quality
           and t.check_worker = strWorkerNo;

      exception
        when no_data_found then
          --若不存着属性相同的明细，新增明细
          --获取最大的CHECK_row_id
          begin
            select nvl(max(t.row_id), 0) + 1
              into intCheck_row_id
              from ridata_check_d t
             where t.WAREHOUSE_NO = strWareHouseNo and t.enterprise_no=strEnterPriseNo
               and t.owner_no = strOwnerNo
               and t.check_no = v_strCheckNo;
          exception
            when no_data_found then
              intCheck_row_id := 1;
          end;
          --取该商品的单价，写入验收明细表
          --如果是超品 则 单据默认为0 huangb 20160815
          begin
            select distinct t.unit_cost into v_price from ridata_untread_d t where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo
            and t.article_no=p.article_no
            and t.untread_no = (select m.untread_no from ridata_check_m m where m.check_no=v_strCheckNo
            and m.enterprise_no=strEnterPriseNo and m.warehouse_no=strWareHouseNo);
          exception
            when no_data_found then
              v_price := 0;
          end;

          --写验收明细
          insert into ridata_check_d
            (enterprise_no,WAREHOUSE_NO,owner_no,check_no,
             article_no,barcode,packing_qty,check_qty,
             lot_no,produce_date,expire_date,quality,
             check_worker,dept_no,
             rsv_batch1,rsv_batch2,rsv_batch3,rsv_batch4,
             rsv_batch5,rsv_batch6,rsv_batch7,rsv_batch8,
             check_end_date,supplier_no,row_id,price)
          values
            (strEnterPriseNo,strWareHouseNo,strOwnerNo,v_strCheckNo,
             p.article_no,p.barcode,p.packing_qty,nCheckQty,
             p.lot_no,p.produce_date,p.expire_date,p.quality,
             strWorkerNo,p.dept_no,
             P.rsv_batch1,p.rsv_batch2,p.rsv_batch3,p.rsv_batch4,
             p.rsv_batch5,p.rsv_batch6,p.rsv_batch7,p.rsv_batch8,
             sysdate,p.supplier_no,intCheck_row_id,v_price);
      end;
    end loop;

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_InsertCheckD;

  /******************************************************************************************************************
   修改人：luozhiling
   日期:2013-11-8
   功能：验收确认
  *******************************************************************************************************************/
  procedure P_CloseCheck(strEnterPriseNo      in ridata_untread_m.enterprise_no%type,
                         strWAREHOUSE_NO      in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码)
                         strsUntreadNo        in ridata_untread_sm.s_untread_no%type, --返配汇总单号
                         strS_Check_no        in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                         strDockNo            in pntset_printer_workstation.workstation_no%type, --工作站号
                         strWorkerNo          in ridata_check_pal_tmp.rgst_name%type, --操作人
                         strResult            Out varchar2) is
  begin
    strResult := 'N|[P_CloseCheck]';



    --更新验收单状态
    update ridata_check_m icm
       set icm.status    = '13',
           icm.updt_name = strWorkerNo,
           icm.updt_date = sysdate
     where icm.enterprise_no=strEnterPriseNo and icm.warehouse_no = strWAREHOUSE_NO
       and icm.s_check_no = strS_Check_no
       and icm.status in ('10', '12')
       and icm.untread_no in
           (select untread_no
              from ridata_untread_sm
             where s_untread_no = strsUntreadNo);

    if sql%notfound then
      strResult := 'N|[E24209]';
      return;
    end if;

    update ridata_untread_sm
       set status = '13', updt_name = strWorkerNo, updt_date = sysdate
     where enterprise_no=strEnterPriseNo and warehouse_no = strWAREHOUSE_NO
       and s_untread_no = strsUntreadNo
       and status not in ('13', '16');
    if sql%notfound then
      strResult := 'N|[E24210]';
      return;
    end if;

    --更新返配汇总头档状态
    update ridata_untread_mm iim
       set status = '13', updt_name = strWorkerNo, updt_date = sysdate
     where enterprise_no=strEnterPriseNo and warehouse_no = strWAREHOUSE_NO
       and s_untread_no = strsUntreadNo
       and status not in ('13', '16');
    if sql%notfound then
      strResult := 'N|[E24211]';
      return;
    end if;

    strResult := 'Y|';

  end P_CloseCheck;

  /******************************************************************************************************************
   修改人：luozhiling
   日期:2013-11-8
   功能：对返配单做结案
  *******************************************************************************************************************/
  procedure P_CloseImport(strEnterPriseNo        in ridata_check_pal_tmp.enterprise_no%type,
                          strWAREHOUSE_NO        in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码)
                          strsCheckNo            in ridata_check_pal_tmp.s_untread_no%type, --返配汇总单号
                          strWorkerNo            in ridata_check_pal_tmp.rgst_name%type, --操作人
                          strResult              Out varchar2) is
  begin
    strResult := 'N|[P_CloseImport]';

    --更新返配单明细状态
    update ridata_untread_d
       set status = '13'
     where enterprise_no=strEnterPriseNo and warehouse_no = strWAREHOUSE_NO
       and untread_no in (select rcm.untread_no
              from ridata_check_m rcm, ridata_untread_sm rus
             where rcm.enterprise_no=rus.enterprise_no and rcm.enterprise_no=strEnterPriseNo and rcm.untread_no = rus.untread_no
               and rcm.warehouse_no = rus.warehouse_no
               and rcm.warehouse_no = strWAREHOUSE_NO
               and rcm.s_check_no = strsCheckNo
               and rcm.status = '13')
       and status not in ('13', '16');



    --更新返配头档状态
    update ridata_untread_m
       set status = '13', updt_name = strWorkerNo, updt_date = sysdate
     where enterprise_no=strEnterPriseNo and warehouse_no = strWAREHOUSE_NO
     and untread_no in (select rcm.untread_no
              from ridata_check_m rcm, ridata_untread_sm rus
             where rcm.enterprise_no=rus.enterprise_no and rcm.enterprise_no=strEnterPriseNo and rcm.untread_no = rus.untread_no
               and rcm.warehouse_no = rus.warehouse_no
               and rcm.warehouse_no = strWAREHOUSE_NO
               and rcm.s_check_no = strsCheckNo
               and rcm.status = '13')
       and status not in ('13', '16');
    if sql%notfound then
      strResult := 'N|[E24212]';
      return;
    end if;
    strResult := 'Y|';

  end P_CloseImport;

  ------------------------------------【上架发单】------------------------------------------------------------
  /***********************************************************************************************************
   作者:luozhiling
   日期:  2013-10-18
   功能: 写上架明细
   根据配置写打印任务 huangb 20160804
  **********************************************************************************************************/

  procedure P_insertInstock(strEnterPriseNo       in ridata_check_m.enterprise_no%type,
                            strWareHouseNo        in ridata_instock_direct.warehouse_no%type, --仓别
                            strWorkerNo           in ridata_instock_direct.rgst_name%type, --操作人
                            strLocateNo           in ridata_instock_direct.locate_no%type,
                            strDockNo             in ridata_check_m.dock_no%type,
                            strPrintFlag          in job_printtask_m.reprint_flag%type,--打印标识:0-不打印;1-打印上架清单;2-打印上架标签
                            strInstockNo          out ridata_instock_d.instock_no%type, --上架单号
                            strResult             out varchar2) is
    v_strPrtTask job_printtask_m.task_no%type;
    v_iCount     integer;
    v_reportType pntset_module_report.report_type%type := 'N'; --打印类型 huangb 20160804
    v_ReportId   pntset_module_report.report_id%type := 'N'; --报表ID huangb 20160804
  begin

    strResult := 'N|[P_insertInstock]';

    --
    select count(*) into v_iCount from ridata_instock_direct iid
       where iid.enterprise_no=strEnterPriseNo and iid.warehouse_no = strWareHouseNo
         and iid.locate_no = strLocateNo
         and iid.status = '10';
    if v_iCount=0 then
       strResult := 'Y|';
       return;
    end if;

    --取上架单号
    begin
      strInstockNo := '';
      PKLG_WMS_BASE.p_getsheetno(strEnterPriseNo,strWareHouseNo,
                                 'IP',
                                 strInstockNo,
                                 strResult);
      if (strInstockNo is null or substr(strResult, 1, 1) = 'N') then
        strResult := 'N|[E24401]'; --取验收单号错误!
        return;
      end if;
    end;

    --打印上架清单
    if strPrintFlag = '1' then
      v_reportType := 'L';
    end if;
    --打印上架标签
    if strPrintFlag = '2' then
      v_reportType := 'M';
    end if;

    if strPrintFlag <> '0' then

      --取报表ID
      PKLG_WMS_Public.p_GetReportId
      (strEnterPriseNo,strWareHouseNo,CONST_REPORT_TYPE.RIDATAUM,v_reportType,strInstockNo,v_ReportId,strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;

      --写打印任务
      PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterPriseNo,strWareHouseNo,
                                          strInstockNo,
                                          0,
                                          v_ReportId,
                                          strDockNo,
                                          0,
                                          strWorkerNo,
                                          v_strPrtTask,
                                          strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;

    end if;
    --huangb 20160804 改为通过配置写打印任务
    /*if strPrintFlag='1' then
        PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterPriseNo,strWareHouseNo,
                                            strInstockNo,
                                            0,
                                            CONST_REPORTID.RPT_UM_INSTOCK,
                                            strDockNo,
                                            0,
                                            strWorkerNo,
                                            v_strPrtTask,
                                            strResult);
        if substr(strResult, 1, 1) <> 'Y' then
          return;
        end if;
    end if;*/

/*    if strPrintFlag='2' then
        PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterPriseNo,strWareHouseNo,
                                            strInstockNo,
                                            0,
                                            CONST_REPORTID.RPT_UM_INSTOCKB,
                                            strDockNo,
                                            0,
                                            strWorkerNo,
                                            v_strPrtTask,
                                            strResult);
        if substr(strResult, 1, 1) <> 'Y' then
          return;
        end if;
    end if;*/

    --写上架单头档
    insert into ridata_instock_m
      (enterprise_no,warehouse_no,
       owner_no,
       instock_no,
       operate_type,
       auto_locate_flag,
       status,
       rgst_name,
       rgst_date,quality_flag,untread_type,class_type)
      select distinct strEnterPriseNo,strWareHouseNo,
                      iid.owner_no,
                      strInstockNo,
                      iid.operate_type,
                      iid.auto_locate_flag,
                      '10',
                      strWorkerNo,
                      sysdate,iid.quality_flag,iid.untread_type,iid.class_type
        from ridata_instock_direct iid
       where iid.enterprise_no=strEnterPriseNo and iid.warehouse_no = strWareHouseNo
         and iid.locate_no = strLocateNo
         and iid.status = '10';

    --写上架单明细档
    insert into RIDATA_INSTOCK_D
      (enterprise_no,warehouse_no,
       OWNER_NO,
       INSTOCK_NO,
       INSTOCK_ID,
       CELL_NO,
       CELL_ID,
       ARTICLE_NO,
       ARTICLE_ID,
       PACKING_QTY,
       DEST_CELL_NO,
       DEST_CELL_ID,
       ARTICLE_QTY,
       REAL_CELL_NO,
       label_no,
       sub_label_no,
       REAL_QTY,
       SOURCE_NO,
       STATUS,
       INSTOCK_NAME,
       INSTOCK_DATE,
       ASSIGN_NAME,
       BUSINESS_TYPE,
       direct_serial,supplier_no,batch_no,operate_date,wave_no,locate_no)
      select iid.enterprise_no,iid.warehouse_no,
             iid.owner_no,
             strInstockNo,
             rownum,
             iid.cell_no,
             iid.cell_id,
             iid.article_no,
             iid.article_id,
             iid.packing_qty,
             iid.dest_cell_no,
             iid.dest_cell_id,
             iid.instock_qty,
             iid.dest_cell_no,
             iid.label_no,
             iid.sub_label_no,
             0,
             iid.source_no,
             '10',
             strWorkerNo,
             sysdate,
             strWorkerNo,
             iid.business_type,
             iid.row_id,iid.supplier_no,iid.batch_no,iid.operate_date,iid.wave_no,iid.locate_no
        from ridata_instock_direct iid
       where iid.enterprise_no=strEnterPriseNo and iid.warehouse_no = strWareHouseNo
         and iid.locate_no = strLocateNo
         and iid.status = '10';

    --更新上架指示状态
    update ridata_instock_direct iid
       set iid.status = '13'
     where iid.enterprise_no=strEnterPriseNo and iid.warehouse_no = strWareHouseNo
       and iid.locate_no = strLocateNo
       and iid.status = '10';

    if sql%rowcount <= 0 then
      strResult := 'N|[E24402]';
    end if;

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_insertInstock;

  /*************************************************************************
  luozhiling
  2013/10/23
  说明：上架回单
  ****************************************************************************************************/
  procedure P_UpdateInstock(strEnterPriseNo         in ridata_instock_m.enterprise_no%type,
                            strWareHouseNo          in ridata_instock_m.warehouse_no%type,
                            strInstockNo            in ridata_instock_m.instock_no%type,
                            strInstockId            in ridata_instock_d.instock_id%type,
                            strInstockCellNo        in ridata_instock_d.real_cell_no%type,
                            nRealQty                in ridata_instock_d.real_qty%type,
                            strUserId               in ridata_instock_m.rgst_name%type, --上架人
                            strPaperUserId          in ridata_instock_m.rgst_name%type, --回单人
                            strSataus               in ridata_instock_d.status%type,
                            strResult               out varchar2) is
    v_iCount integer;
  begin
    strResult := 'N|[P_UpdateInstock]';

    v_iCount := 0;

    --更新上架单头档和明细
    update ridata_instock_d iid
       set iid.status       = strSataus,
           iid.real_cell_no = strInstockCellNo,
           iid.real_qty     = nRealQty,
           iid.instock_name   = strUserId,
           iid.instock_date = sysdate
     where iid.enterprise_no=strEnterPriseNo and iid.warehouse_no = strWareHouseNo
       AND iid.instock_no = strInstockno
       and iid.instock_id = strInstockId;

    if sql%rowcount <= 0 then
      strResult := 'N|[E24403]';
    end if;

    select count(*)
      into v_iCount
      from ridata_instock_d iid
     where enterprise_no=strEnterPriseNo and warehouse_no = strWareHouseNo
       AND iid.instock_no = strInstockno
       and iid.status in ('12', '10','11');

    if v_iCount = 0 then
      --若整单上架完成，修改上架单状态

      update ridata_instock_m iim
         set iim.status    = '13',
             iim.updt_name = strPaperUserId,
             iim.updt_date = sysdate
       where iim.enterprise_no=strEnterPriseNo and iim.wareHouse_no = strWareHouseNo
         and iim.instock_no = strInstockNo;

      if sql%rowcount <= 0 then
        strResult := 'N|[E24404]';
      end if;
    end if;
    strResult := 'Y';

  end P_UpdateInstock;


  /*************************************************************************
  luozhiling
  2014/6/21
  说明：DPS返配上架更新上架明细，需要写实际上架的标签号
  ****************************************************************************************************/
  procedure P_UpdateDPSInstock(strEnterPriseNo      in ridata_instock_m.enterprise_no%type,
                               strWareHouseNo       in ridata_instock_m.warehouse_no%type,
                               strInstockNo         in ridata_instock_m.instock_no%type,
                               strInstockId         in ridata_instock_d.instock_id%type,
                               strInstockCellNo     in ridata_instock_d.real_cell_no%type,
                               strRealLabelNo       in ridata_instock_d.real_label_no%type,
                               strRealSubLabelNo    in   ridata_instock_d.real_sub_label_no%type,
                               nRealQty             in ridata_instock_d.real_qty%type,
                               strUserId            in ridata_instock_m.rgst_name%type, --上架人
                               strPaperUserId       in ridata_instock_m.rgst_name%type, --回单人
                               strResult            out varchar2) is
    v_iCount integer;
  begin
    strResult := 'N|[P_UpdateDPSInstock]';

    v_iCount := 0;

    --更新上架单头档和明细
    update ridata_instock_d iid
       set iid.real_cell_no = strInstockCellNo,
           iid.real_qty     = iid.real_qty+ nRealQty,
           iid.real_label_no= strRealLabelNo,
           iid.real_sub_label_no = strRealSubLabelNo,
           iid.instock_name   = strUserId,
           iid.instock_date = sysdate,
           iid.status='11'
     where iid.enterprise_no=strEnterPriseNo and iid.warehouse_no = strWareHouseNo
       AND iid.instock_no = strInstockno
       and iid.instock_id = strInstockId;

    if sql%rowcount <= 0 then
      strResult := 'N|[E24403]';
    end if;

    strResult := 'Y';

  end P_UpdateDPSInstock;

  /*
   作者:luozhiling
   日期:  2013-11-11
   功能: 上架指示转历史
  */
  procedure P_InstockToHty(strEnterPriseNo      in ridata_instock_m.enterprise_no%type,
                           strWareHouseNo       in ridata_instock_m.warehouse_no%type, --仓库代码
                           strInstockNo         in ridata_instock_m.instock_no%type, --上架单号
                           strResult            out varchar2) is

  begin
    strResult := 'N|[P_InstockToHty]';

    --将上架单对应的定位指示转历史
    insert into ridata_locate_directhty
      (enterprise_no,warehouse_no,row_id,owner_no,locate_no,
       auto_locate_flag,source_no,cell_no,cell_id,operate_type,
       article_no,article_id,packing_qty,qty,dock_no,
       printer_group_no,exclude_cell_no,status,
       sub_label_no,label_no,business_type,
       rgst_name,rgst_date,updt_name,updt_date,
       batch_no,supplier_no,operate_date,quality_flag,wave_no,untread_type,class_type)
      select distinct ild.enterprise_no,ild.warehouse_no,ild.row_id,ild.owner_no,ild.locate_no,
             ild.auto_locate_flag,ild.source_no,ild.cell_no,ild.cell_id,ild.operate_type,
             ild.article_no,ild.article_id,ild.packing_qty,ild.qty,ild.dock_no,
             ild.printer_group_no,ild.exclude_cell_no,ild.status,
             ild.sub_label_no,ild.label_no,ild.business_type,
             ild.rgst_name,ild.rgst_date,ild.updt_name,ild.updt_date,
             ild.batch_no,ild.supplier_no,ild.operate_date,ild.quality_flag,ild.wave_no,
             ild.untread_type,ild.class_type
        from ridata_locate_direct ild,
             ridata_instock_d      iid
       where ild.enterprise_no=iid.enterprise_no
         and ild.enterprise_no=strEnterPriseNo
         and iid.warehouse_no=ild.warehouse_no and iid.warehouse_no=strWareHouseNo
         and ild.owner_no = iid.owner_no
         and ild.label_no = iid.label_no
         and ild.sub_label_no = iid.sub_label_no
         and ild.cell_no = iid.cell_no
         and ild.source_no = iid.source_no
         and ild.cell_id = iid.cell_id
         and iid.instock_no = strInstockNo
         and ild.wave_no=iid.wave_no
         and iid.locate_no=iid.locate_no
         and ild.status in ('13', '16');

    --删除上架单对应的定位指示数据

    delete from ridata_locate_direct ild
     where ild.enterprise_no=strEnterPriseNo and ild.warehouse_no = strWareHouseNo
       and (ild.source_no, ild.label_no, ild.sub_label_no,
            ild.cell_no, ild.cell_id,ild.locate_no,ild.wave_no) in
           (select iid.source_no,iid.label_no,iid.sub_label_no,
                   iid.cell_no,iid.cell_id,iid.locate_no,iid.wave_no
              from ridata_instock_m iim, ridata_instock_d iid
             where iim.enterprise_no=iid.enterprise_no and iim.enterprise_no=strEnterPriseNo
               and iim.warehouse_no = iid.warehouse_no and iim.warehouse_no=strWareHouseNo
               and iim.instock_no=iid.instock_no
               and iim.instock_no = strInstockNo
               and iim.status in ('13', '16'))
       and ild.status in ('13', '16');

    --将上架单对应的上架指示写历史表
    insert into ridata_instock_directhty
      (enterprise_no,row_id,source_no,auto_locate_flag,
       warehouse_no,owner_no,operate_type,
       cell_no,cell_id,
       article_no,article_id,packing_qty,dest_cell_no,dest_cell_id,
       instock_qty,status,sub_label_no,label_no,business_type,
       rgst_name,rgst_date,updt_name,updt_date,
       locate_no,batch_no,operate_date,supplier_no,wave_no,quality_flag,untread_type,class_type)
      select distinct t.enterprise_no,t.row_id,t.source_no,t.auto_locate_flag,
             t.warehouse_no,t.owner_no,t.operate_type,
             t.cell_no,t.cell_id,
             t.article_no,t.article_id,t.packing_qty,t.dest_cell_no,t.dest_cell_id,
             t.instock_qty,t.status,t.sub_label_no,t.label_no,t.business_type,
             t.rgst_name,t.rgst_date,t.updt_name,t.updt_date,
             t.locate_no,t.batch_no,t.operate_date,t.supplier_no,t.wave_no,t.quality_flag,
             T.untread_type,t.class_type
        from ridata_instock_direct t, ridata_instock_d iid
       where t.enterprise_no=iid.enterprise_no and t.enterprise_no=strEnterPriseNo
         and t.warehouse_no = iid.warehouse_no
         and t.owner_no = iid.owner_no
         and t.warehouse_no = strWareHouseNo
         and t.row_id = iid.direct_serial
         and iid.instock_no = strInstockNo
         and iid.status in ('13', '16');

    --删除上架指示
    delete from ridata_instock_direct iid
     where iid.enterprise_no=strEnterPriseNo and iid.warehouse_no = strWareHouseNo
           and (iid.locate_no,iid.row_id,iid.wave_no) in
           (select t.locate_no,t.direct_serial,t.wave_no from ridata_instock_d t
           where t.enterprise_no=strEnterpriseNo and t.warehouse_no=strWareHouseNo
           and t.instock_no=strInstockNo and iid.status in ('13', '16'));

    --将上架单明细档转历史
    insert into ridata_instock_dhty
      (enterprise_no,warehouse_no,OWNER_NO,
       INSTOCK_NO,INSTOCK_ID,direct_serial,CELL_NO,CELL_ID,
       ARTICLE_NO,ARTICLE_ID,PACKING_QTY,
       DEST_CELL_NO,DEST_CELL_ID,
       ARTICLE_QTY,REAL_CELL_NO,label_no,sub_label_no,
       REAL_QTY,SOURCE_NO,STATUS,
       INSTOCK_NAME,INSTOCK_DATE,ASSIGN_NAME,
       BUSINESS_TYPE,batch_no,supplier_no,operate_date,real_label_no,real_sub_label_no,
       wave_no,locate_no)
      select iid.enterprise_no,iid.warehouse_no,iid.owner_no,
             iid.instock_no,iid.instock_id,iid.direct_serial,iid.cell_no,iid.cell_id,
             iid.article_no,iid.article_id,iid.packing_qty,
             iid.dest_cell_no,iid.dest_cell_id,
             iid.article_qty,iid.real_cell_no,iid.label_no,iid.sub_label_no,
             iid.real_qty,iid.source_no,iid.status,
             iid.instock_name,iid.instock_date,iid.ASSIGN_NAME,
             iid.business_type,iid.batch_no,iid.supplier_no,iid.operate_date,iid.real_label_no,iid.real_sub_label_no,
             iid.wave_no,iid.locate_no
        from ridata_instock_d iid, ridata_instock_m iim
       where iid.enterprise_no=iim.enterprise_no and iid.enterprise_no=strEnterPriseNo
         and iid.warehouse_no = strWareHouseNo
         and iid.instock_no = strInstockNo
         and iid.warehouse_no = iim.warehouse_no
         and iim.instock_no = iid.instock_no
         and iim.status = '13';

    --删除上架单明细档
    delete from ridata_instock_d iid
     where iid.enterprise_no=strEnterPriseNo and iid.warehouse_no = strWareHouseNo
       and iid.instock_no = strInstockNo
       and exists (select 'x'
              from ridata_instock_m
             where instock_no = strInstockNo
               and warehouse_no = strWareHouseNo and enterprise_no=strEnterPriseNo);

    --将上架单头档转历史
    insert into ridata_instock_mhty
      (enterprise_no,warehouse_no,owner_no,instock_no,
       operate_type,auto_locate_flag,status,
       rgst_name,rgst_date,updt_name,updt_date,quality_flag,untread_type,class_type,
       --huangb 20160509
       REPORT_UP_SERIAL)
      select iim.enterprise_no,iim.warehouse_no,iim.owner_no,iim.instock_no,
             iim.operate_type,iim.auto_locate_flag,iim.status,
             iim.rgst_name,iim.rgst_date,iim.updt_name,iim.updt_date,iim.quality_flag,iim.untread_type,iim.class_type,
             --huangb 20160509
             REPORT_UP_SERIAL
        from ridata_instock_m iim
       where iim.enterprise_no=strEnterPriseNo and iim.warehouse_no = strWareHouseNo
         and iim.instock_no = strInstockNo
         and iim.status = '13';

    delete from ridata_instock_m iim
     where iim.enterprise_no=strEnterPriseNo and iim.warehouse_no = strWareHouseNo
       and iim.instock_no = strInstockNo
       and iim.status = '13';

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_InstockToHty;

  /******************************************************************************************************************
   修改人：luozhiling
   日期:2013-11-8
   功能：将返配汇总单转历史
  *******************************************************************************************************************/
  procedure P_untreadToHty(strEnterPriseNo        in ridata_check_pal_tmp.enterprise_no%type,
                           strWAREHOUSE_NO        in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码)
                           strsUntreadNo          in ridata_untread_sm.s_untread_no%type, --返配汇总单号
                           strResult              Out varchar2) is
  begin
    strResult := 'N|[P_untreadToHty]';

    --将返配汇总单对应关系转历史
    insert into ridata_untread_smhty
      (enterprise_no,warehouse_no,
       owner_no,
       untread_type,
       s_untread_no,
       untread_no,
       po_no,
       po_type,
       status,
       rgst_name,
       rgst_date,
       updt_name,
       updt_date,
       order_operate_name,
       real_operate_name,
       --huangb 20160509
       REPORT_UP_SERIAL)
      select t.enterprise_no,t.warehouse_no,
             t.owner_no,
             t.untread_type,
             t.s_untread_no,
             t.untread_no,
             t.po_no,
             t.po_type,
             t.status,
             t.rgst_name,
             t.rgst_date,
             t.updt_name,
             t.updt_date,
             t.order_operate_name,
             t.real_operate_name,
             --huangb 20160509
             REPORT_UP_SERIAL
        from ridata_untread_sm t
       where t.enterprise_no=strEnterPriseNo and t.warehouse_no = strWAREHOUSE_NO
         and t.s_untread_no = strsUntreadNo;
    delete from ridata_untread_sm
     where enterprise_no=strEnterPriseNo and warehouse_no = strWAREHOUSE_NO
       and s_untread_no = strsUntreadNo;

    --将返配汇总单头档转历史
    insert into ridata_untread_mmhty
      (enterprise_no,warehouse_no,
       s_untread_no,
       owner_no,
       s_po_no,
       cust_no,
       class_type,
       status,
       serial_no,
       print_flag,
       carplate,
       track_no,
       boardnum,
       stock_type,
       stock_value,
       printer_name,
       printer_date,
       car_plan_no,
       rgst_name,
       rgst_date,
       updt_name,
       updt_date,wave_no,device_no,quality,
       --huangb 20160509
       REPORT_UP_SERIAL)
      select t.enterprise_no,t.warehouse_no,
             t.s_untread_no,
             t.owner_no,
             t.s_po_no,
             t.cust_no,
             t.class_type,
             t.status,
             t.serial_no,
             t.print_flag,
             t.carplate,
             t.track_no,
             t.boardnum,
             t.stock_type,
             t.stock_value,
             t.printer_name,
             t.printer_date,
             t.car_plan_no,
             t.rgst_name,
             t.rgst_date,
             t.updt_name,
             t.updt_date,t.wave_no,t.device_no,quality,
             --huangb 20160509
             REPORT_UP_SERIAL
        from ridata_untread_mm t
       where t.enterprise_no=strEnterPriseNo and t.warehouse_no = strWAREHOUSE_NO
         and t.s_untread_no = strsUntreadNo;
    delete from ridata_untread_mm
     where enterprise_no=strEnterPriseNo and warehouse_no = strWAREHOUSE_NO
       and s_untread_no = strsUntreadNo;

    delete from ridata_untread_sm
     where enterprise_no=strEnterPriseNo and warehouse_no = strWAREHOUSE_NO
       and s_untread_no = strsUntreadNo;

    strResult := 'Y|';

  end P_untreadToHty;


  /**********************************************************************************************
   作者:lich
   日期:  2014-05-06
   功能: 上架回单  拆笔新增上架明细
  ************************************************************************************************/
  procedure p_Insert_Instock_D(strEnterPriseNo      in ridata_instock_m.enterprise_no%type,
                               strWareHouseNo       in ridata_check_m.WAREHOUSE_NO%type, --仓库编码
                               strOwnerNo           in ridata_instock_m.owner_no%type, --委托业主
                               strInstockNo         in ridata_instock_m.instock_no%type, --进货汇总单号
                               strInstockId         in ridata_instock_d.instock_id%type,
                               nRealQty             in ridata_instock_d.real_qty%type,
                               strUserId            in ridata_instock_m.rgst_name%type, --上架人
                               strSataus            in ridata_instock_d.status%type,
                               strResult            out varchar2) is

  v_strRowId ridata_instock_d.instock_id%type;

  begin
    strResult := 'N|[p_Insert_Instock_D]';

    select
      nvl(max(instock_id), 0) + 1
    into
      v_strRowId
    from
      ridata_instock_d
    where enterprise_no =strEnterPriseNo
      and warehouse_no = strWareHouseNo
      and owner_no = strOwnerNo
      and instock_no = strInstockNo;

    insert into ridata_instock_d
    (enterprise_no,warehouse_no, OWNER_NO,INSTOCK_NO,INSTOCK_ID,
       CELL_NO,CELL_ID, ARTICLE_NO,ARTICLE_ID,
       PACKING_QTY,DEST_CELL_NO,DEST_CELL_ID,
       ARTICLE_QTY,REAL_CELL_NO,label_no,sub_label_no,
       REAL_QTY,SOURCE_NO,STATUS,
       INSTOCK_NAME,INSTOCK_DATE,ASSIGN_NAME,
       BUSINESS_TYPE,stock_type,stock_value,
       direct_serial,supplier_no,batch_no,operate_date,wave_no,locate_no)
    select enterprise_no,warehouse_no, OWNER_NO,INSTOCK_NO,v_strRowId,
       CELL_NO,CELL_ID,ARTICLE_NO,ARTICLE_ID,
       PACKING_QTY,DEST_CELL_NO,DEST_CELL_ID,
       nRealQty,REAL_CELL_NO,label_no,sub_label_no,
       0,SOURCE_NO,STATUS,
       INSTOCK_NAME,INSTOCK_DATE,ASSIGN_NAME,
       BUSINESS_TYPE,stock_type,stock_value,
       direct_serial,supplier_no,batch_no,operate_date,wave_no,locate_no
    from
      ridata_instock_d iid
    where
      iid.enterprise_no=strEnterPriseNo and iid.warehouse_no=strWareHouseNo
      and iid.instock_no=strInstockNo
      and iid.owner_no=strOwnerNo
      and iid.instock_id=strInstockId;

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_Insert_Instock_D;

--试算扫描墙资源
PROCEDURE p_scan_calculate(strEnterPriseNo       in ridata_check_m.enterprise_no%type,
                              strwarehouse_no    in ridata_untread_sm.warehouse_no%type, --仓别
                              strSUntreadNo      in ridata_untread_sm.s_untread_no%type, --返配汇总单号
                              --strDockNo          in ridata_check_m.dock_no%type,--扫描台
                              strDeviceNo        in device_divide_m.device_no%type,--扫描墙号
                              strWAVE_TYPE       in BSET_WAVE_MANAGE.Wave_Type%type ,
                              strQualityFlag     in ridata_untread_m.quality%type,--品质类型
                              strUser_Id         in ridata_untread_sm.rgst_name%type, --操作人员
                              str_ri_wave_no     in ridata_untread_mm.wave_no%type,--当前返配单已分配的波次号
                              n_stockNum         in device_divide_m.cust_qty%type,--用来判断滞销品、过季品是不是按区或按巷道来分配分播墙格子号,0为区，其它为巷道
                              n_add_LabelNum     out number,--需要在扫描墙上增加的临时格子数,要返回到程序中。
                              strOutMsg          out varchar2) is
      v_iCount                integer;
      v_strStatus             ridata_untread_mm.status%type;
      --n_count       number(10); --循环行数
      nAddBatchFlag integer;--是否新增批次 0: 不新增；1：新增
      n_OldBatchNo             cset_cell_supplier.batch_no%type; --批次号
      s_wave_no    cset_cell_supplier.wave_no%type; --波次号
      s_wave_no_today    cset_cell_supplier.wave_no%type; --当天最大波次号
      n_batch_no    cset_cell_supplier.batch_no%type; --批次号
      n_batch_no_today    cset_cell_supplier.batch_no%type; --当天最大批次号
      n_cell_no     cset_cell_supplier.cell_no%type; --可用储位
      n_cell_num    number(10); --可用储位数
      s_Label_Id      varchar2(10);
      n_LabelNum    number(2) ;
      n_dps_batch_no  cset_cell_supplier.batch_no%type; --已分播的批次号
      v_strDpsDevice   device_divide_m.device_no%type;

  begin
    strOutMsg     := 'N|[p_RI_SupperAllotCell]';
    v_iCount:=0;

    --锁ridata_untread_mm
    update ridata_untread_mm t set status=status
    where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strwarehouse_no
           and t.s_untread_no=strSUntreadNo;

    --如果strWAVE_TYPE=5，6，不判断电子标签储位信息，否则判断是否存在可用的电子标签储位
    if strWAVE_TYPE='3' or strWAVE_TYPE='4' then
      select count(1)
        into n_cell_num
        from cdef_defcell_dps cdd, cdef_defcell cdc
       where cdd.enterprise_no=cdc.enterprise_no
         and cdd.enterprise_no=strEnterPriseNo and cdd.warehouse_no = cdc.warehouse_no
         and cdd.cell_no = cdc.cell_no
         and cdd.warehouse_no = strwarehouse_no
         and cdc.cell_status = '0'
         and cdd.use_type='7';

      if n_cell_num = 0 then
        strOutMsg := 'N|[E24221]';
        return;
      end if;
    end if ;

    n_cell_num := 0;
    n_cell_no  := 'N';
    n_add_LabelNum :=0 ;

    --锁定波次表,防止分配资源时，其它功能对该表做结案
    update Bset_wave_manage bwm set bwm.status=bwm.status
         where bwm.wave_type=strWAVE_TYPE and bwm.status='0'
          and bwm.enterprise_no=strEnterPriseNo and  bwm.warehouse_no=strwarehouse_no ;

    --取有效的最大波次号
    select  nvl(max(wave_no),'0') into s_wave_no from Bset_wave_manage bwm where bwm.wave_type=strWAVE_TYPE and bwm.status='0'
    and bwm.enterprise_no=strEnterPriseNo and  bwm.warehouse_no=strwarehouse_no ;

    --取最大波次对应的最大批次号
    select nvl(max(curr_batch),0) into n_batch_no from Bset_wave_manage bwm where bwm.wave_type=strWAVE_TYPE and bwm.status='0'
           and bwm.enterprise_no=strEnterPriseNo and  bwm.warehouse_no=strwarehouse_no
           and wave_no =s_wave_no   ;

    --判断“返配单的已分配波次号”跟“波次表中有效的波次号” 是否一致;
    --如果一致，说明不要再重新进行分配
    if str_ri_wave_no = s_wave_no  then
       strOutMsg:='Y|成功';
       return ;
    end if ;



    --*********************************清场=3的处理方法***********************************************
    --清场的要加款式的判断
    if strWAVE_TYPE='3' then
        --获取返配商品供应商、款式信息
        for i_untread in (select distinct rus.warehouse_no,
                                          rus.owner_no,
                                          bda.supplier_no,
                                          bda.rsv_attr2 style
                            from ridata_untread_sm rus,
                                 ridata_untread_d  rud,
                                 bdef_defarticle   bda
                           where rus.enterprise_no=rud.enterprise_no
                             and rus.enterprise_no=bda.enterprise_no
                             and rus.enterprise_no=strEnterPriseNo and rud.warehouse_no = rus.warehouse_no
                             and rud.owner_no = rus.owner_no
                             and rud.untread_no = rus.untread_no
                             and bda.owner_no = rud.owner_no
                             and bda.article_no = rud.article_no
                             and rus.status in ('10', '11','12')
                             and rud.status in ('10', '11','12')
                             and rus.warehouse_no = strwarehouse_no
                             and rus.s_untread_no = strSUntreadNo
                             and rud.untread_qty-rud.check_qty>0
                             and not exists
                           (select 'X'
                                    from ridata_box ccs
                                   where ccs.enterprise_no=rus.enterprise_no
                                     and ccs.warehouse_no = rus.warehouse_no
                                     and ccs.owner_no = bda.owner_no
                                     and ccs.supplier_no = bda.supplier_no
                                     /*and ccs.use_type = '1'*/ and ccs.style=bda.rsv_attr2
                                     and ccs.status = '1'
                                     and ccs.wave_no=s_wave_no and ccs.device_no=strDeviceNo)
                                     order by rus.warehouse_no,
                                          rus.owner_no,
                                          bda.supplier_no) loop




          p_allot_supp_dpscell(strEnterPriseNo,strwarehouse_no,s_wave_no,n_batch_no,v_strDpsDevice,n_cell_no,strWAVE_TYPE,
                               i_untread.owner_no,i_untread.supplier_no,i_untread.style,strUser_Id,strOutMsg);
          if substr(strOutMsg,1,1) = 'N' then
                strOutMsg := 'N|[E24222]';
                return;
          end if;

            --获取当前波批、当前批次、当前扫描墙设备,当前分播的电子标签设备的箱号
            --begin
            select nvl(max(label_id),'') into s_Label_Id from ridata_box rb
                   where rb.enterprise_no=strEnterPriseNo and rb.warehouse_no=strwarehouse_no
                   --and dock_no=strDockNo
                   and rb.wave_no=s_wave_no  and rb.batch_no=n_batch_no
                   AND rb.device_no=strDeviceNo
                   and status='1' and  exists (select 1 from cset_cell_supplier ccs
                   where  rb.enterprise_no = ccs.enterprise_no and rb.warehouse_no=ccs.warehouse_no
                   and rb.owner_no=ccs.owner_no and rb.dps_cell_no=ccs.cell_no
                   and ccs.wave_no=s_wave_no  and ccs.batch_no=n_batch_no
                   AND  ccs.device_no=v_strDpsDevice);

            --exception when no_data_found then
            if s_Label_Id is null or s_Label_Id ='' then
                --如果没有找到对应的扫描墙格子，那么重新找一个新的格子
                begin
                select label_id into s_Label_Id from (select * from (
                       select ddd.device_cell_no label_id,pick_order cell_order--decode(ddd.stock_y,2,1,3,2,1,3) cell_order
                          from device_divide_d ddd,device_divide_group ddg
                         where ddg.enterprise_no=ddd.enterprise_no and ddg.warehouse_no=ddd.warehouse_no
                           and ddg.use_type='2'
                           and ddd.enterprise_no=strEnterPriseNo
                           and ddd.warehouse_no = i_untread.warehouse_no
                           and ddd.status='1'
                           and ddd.device_no=strDeviceNo
                           and ddd.device_cell_no not in
                               (select label_id
                                  from ridata_box
                                 where enterprise_no=strEnterPriseNo and warehouse_no = i_untread.warehouse_no
                                   and owner_no = i_untread.owner_no
                                   and device_no=strDeviceNo
                                   and status = '1')
                         order by cell_order,label_id) where  rownum=1  ) ;
                --如果获取不到新的扫描格子号，那么要临时增加相应的格子数；
                --判断当前ridata_box中是否有增加的格子编号
                exception when no_data_found then
                   --n_LabelNum := 0 ;
                   --begin
                   select max(to_number(label_id)) into s_Label_Id from ridata_box
                     where enterprise_no=strEnterPriseNo and warehouse_no = i_untread.warehouse_no
                     and owner_no = i_untread.owner_no
                     and device_no=strDeviceNo
                     and status = '1'
                     and label_id not in (select device_cell_no from device_divide_d ddd,device_divide_group ddg
                                           where ddg.enterprise_no=ddd.enterprise_no and ddg.warehouse_no=ddd.warehouse_no
                                             and ddg.use_type='2'
                                             and ddd.enterprise_no=strEnterPriseNo
                                             and ddd.warehouse_no = i_untread.warehouse_no
                                             and ddd.device_no=strDeviceNo ) ;
                  --if sql%notfound then
                  --exception when no_data_found then
                  if s_Label_Id is null then
                     n_add_LabelNum:=n_add_LabelNum+1 ;
                     s_Label_Id :='1' ;
                     --n_LabelNum := 1 ;
                 else
                     n_add_LabelNum:=n_add_LabelNum+1 ;
                     s_Label_Id :=to_number(s_Label_Id)+1 ;
                  end if ;


                end  ;
            end  if ;


            insert into ridata_box(enterprise_no,warehouse_no,owner_no,operate_date,label_id,
                   wave_no,batch_no,device_no,supplier_no,style,rgst_name,rgst_date,status,dps_cell_no,quality,WAVE_TYPE)
                values(strEnterPriseNo,strwarehouse_no,i_untread.owner_no,trunc(sysdate),s_Label_Id,
                s_wave_no,n_batch_no,strDeviceNo,i_untread.supplier_no,i_untread.style,strUser_Id,sysdate,'1',
                n_cell_no,strQualityFlag,strWAVE_TYPE);

            n_OldBatchNo:=n_batch_no;

        end loop;
    end if ;

    --*********************************质量=4的处理方法***********************************************
    --质量返配的不加款式的判断
    if strWAVE_TYPE='4' then
        --获取返配商品供应商信息
        for i_untread in (select distinct rus.warehouse_no,
                                          rus.owner_no,
                                          bda.supplier_no,
                                          'N' style
                            from ridata_untread_sm rus,
                                 ridata_untread_d  rud,
                                 bdef_defarticle   bda
                           where rus.enterprise_no=rud.enterprise_no
                             and rus.enterprise_no=bda.enterprise_no
                             and rus.enterprise_no=strEnterPriseNo and rud.warehouse_no = rus.warehouse_no
                             and rud.owner_no = rus.owner_no
                             and rud.untread_no = rus.untread_no
                             and bda.owner_no = rud.owner_no
                             and bda.article_no = rud.article_no
                             and rus.status in ('10', '11','12')
                             and rud.status in ('10', '11','12')
                             and rus.warehouse_no = strwarehouse_no
                             and rus.s_untread_no = strSUntreadNo
                             and rud.untread_qty-rud.check_qty>0
                             and not exists
                           (select 'X'
                                    from ridata_box ccs
                                   where ccs.enterprise_no=rus.enterprise_no
                                     and ccs.warehouse_no = rus.warehouse_no
                                     and ccs.owner_no = bda.owner_no
                                     and ccs.supplier_no = bda.supplier_no
                                     --and ccs.use_type = '1'
                                     and ccs.status = '1'
                                     and ccs.wave_no=s_wave_no  and ccs.device_no=strDeviceNo ) order by rus.warehouse_no,
                                          rus.owner_no,
                                          bda.supplier_no) loop


          p_allot_supp_dpscell(strEnterPriseNo,strwarehouse_no,s_wave_no,n_batch_no,v_strDpsDevice,n_cell_no,strWAVE_TYPE,
                               i_untread.owner_no,i_untread.supplier_no,i_untread.style,strUser_Id,strOutMsg);
          if substr(strOutMsg,1,1) = 'N' then
                strOutMsg := 'N|[E24222]';
                return;
          end if;

            --获取当前波批、当前批次、当前扫描墙设备,当前分播的电子标签设备的箱号

            select nvl(max(label_id),'') into s_Label_Id from ridata_box rb
                   where rb.enterprise_no=strEnterPriseNo and rb.warehouse_no=strwarehouse_no
                   --and dock_no=strDockNo
                   and rb.wave_no=s_wave_no  and rb.batch_no=n_batch_no
                   AND rb.device_no=strDeviceNo
                   and status='1' and  exists (select 1 from cset_cell_supplier ccs
                   where  rb.enterprise_no = ccs.enterprise_no and rb.warehouse_no=ccs.warehouse_no
                   and rb.owner_no=ccs.owner_no and rb.dps_cell_no=ccs.cell_no
                   and ccs.wave_no=s_wave_no  and ccs.batch_no=n_batch_no
                   AND ccs.device_no=v_strDpsDevice);


            --exception when no_data_found then
            if s_Label_Id is null then
                --如果没有找到对应的扫描墙格子，那么重新找一个新的格子
                begin
                select label_id into s_Label_Id from (select * from (
                       select ddd.device_cell_no label_id,pick_order cell_order--decode(ddd.stock_y,2,1,3,2,1,3) cell_order
                          from device_divide_d ddd,device_divide_group ddg
                         where ddg.enterprise_no=ddd.enterprise_no and ddg.warehouse_no=ddd.warehouse_no
                           and ddg.use_type='2'
                           and ddd.enterprise_no=strEnterPriseNo
                           and ddd.warehouse_no = i_untread.warehouse_no
                           and ddd.status='1'
                           and ddd.device_no=strDeviceNo
                           and ddd.device_cell_no not in
                               (select label_id
                                  from ridata_box
                                 where enterprise_no=strEnterPriseNo and warehouse_no = i_untread.warehouse_no
                                   and owner_no = i_untread.owner_no
                                   and device_no=strDeviceNo
                                   and status = '1')
                         order by cell_order,label_id) where  rownum=1  ) ;
                --如果获取不到新的扫描格子号，那么要临时增加相应的格子数；
                --判断当前ridata_box中是否有增加的格子编号
                exception when no_data_found then
                   /*n_LabelNum :=0 ;
                   begin*/
                   select max(to_number(label_id)) into s_Label_Id from ridata_box
                     where enterprise_no=strEnterPriseNo and warehouse_no = i_untread.warehouse_no
                     and owner_no = i_untread.owner_no
                     and device_no=strDeviceNo
                     and status = '1'
                     and label_id not in (select device_cell_no from device_divide_d ddd,device_divide_group ddg
                                           where ddg.enterprise_no=ddd.enterprise_no and ddg.warehouse_no=ddd.warehouse_no
                                             and ddg.use_type='2'
                                             and ddd.enterprise_no=strEnterPriseNo
                                             and ddd.warehouse_no = i_untread.warehouse_no
                                             and ddd.device_no=strDeviceNo ) ;
                  --if sql%notfound then
                  --exception when no_data_found then
                  if s_Label_Id is null then
                     n_add_LabelNum:=n_add_LabelNum+1 ;
                     s_Label_Id :='1' ;
                   else
                     n_add_LabelNum:=n_add_LabelNum+1 ;
                     s_Label_Id :=to_number(s_Label_Id)+1 ;
                  end if ;


                end  ;
            end  if ;
            /*if n_batch_no<>n_OldBatchNo then
               nLabelId:=nLabelId+1;
            end if;*/

            insert into ridata_box(enterprise_no,warehouse_no,owner_no,operate_date,label_id,
                   wave_no,batch_no,device_no,supplier_no,style,rgst_name,rgst_date,status,dps_cell_no,quality,WAVE_TYPE)
                values(strEnterPriseNo,strwarehouse_no,i_untread.owner_no,trunc(sysdate),s_Label_Id,
                s_wave_no,n_batch_no,strDeviceNo,i_untread.supplier_no,i_untread.style,strUser_Id,sysdate,'1'
                ,n_cell_no,strQualityFlag,strWAVE_TYPE);

            n_OldBatchNo:=n_batch_no;

        end loop;
    end if ;

    --*********************************滞销=5和过季=6的处理方法***********************************************
    --5、6类型不上电子标签分播
    if strWAVE_TYPE='5' or strWAVE_TYPE='6' then
       select count(*) into v_iCount from ridata_untread_sm rus,ridata_untread_d t
       where rus.enterprise_no=t.enterprise_no and rus.warehouse_no=t.warehouse_no
       and rus.untread_no=t.untread_no and (t.cell_no is null or t.cell_no='N')
       and rus.enterprise_no=strEnterPriseNo
       and rus.warehouse_no = strwarehouse_no
       and rus.s_untread_no = strSUntreadNo;
       if v_iCount>0 then
          strOutMsg:='N|[该返配单没有做上架预定位]';
          return;
       end if;
       if n_stockNum = 0 then
            --获取返配商品拣货区信息,没有拣货区的商品分播到异常区。
            for i_untread in (select * from ( select distinct rus.enterprise_no,rus.warehouse_no,
                                              rus.owner_no,
                                              cd.ware_no||cd.area_no area_no,
                                              'N' style
                                from ridata_untread_sm rus,
                                     ridata_untread_d  rud,
                                     cdef_defcell cd
                               where rus.enterprise_no=rud.enterprise_no
                                 and rud.enterprise_no=cd.enterprise_no
                                 and rud.warehouse_no = rus.warehouse_no
                                 and rud.warehouse_no = cd.warehouse_no
                                 and rud.cell_no = cd.cell_no
                                 and rud.untread_no = rus.untread_no
                                 and rus.status in ('10', '11','12')
                                 and rud.status in ('10', '11','12')
                                 and rus.enterprise_no=strEnterPriseNo
                                 and rus.warehouse_no = strwarehouse_no
                                 and rus.s_untread_no = strSUntreadNo
                                 and rud.untread_qty-rud.check_qty>0) rus
                                 where  not exists
                               (select 'X'
                                        from ridata_box rb
                                       where rb.enterprise_no=rus.enterprise_no
                                         and rb.warehouse_no = rus.warehouse_no
                                         and rb.owner_no = rus.owner_no
                                         and rb.dps_cell_no = rus.area_no
                                         and rb.status <= '2'
                                         and rb.wave_no=s_wave_no  and rb.device_no=strDeviceNo) order by enterprise_no,warehouse_no,
                                              owner_no,area_no) loop


              if s_wave_no ='0' then
                 nAddBatchFlag:='1';
                 n_cell_num:=1;
                 --取当天最大的波次号
                 select  nvl(max(wave_no),'0')  wave_no into s_wave_no_today  from Bset_wave_manage bwm where bwm.wave_type=strWAVE_TYPE
                           and bwm.enterprise_no=strEnterPriseNo and  bwm.warehouse_no=strwarehouse_no
                           and trunc(bwm.rgst_date)=trunc(sysdate) ;


                 --新增加波次号,批次从1取
                 if s_wave_no_today='0' then
                    s_wave_no:=to_char(sysdate,'yyyymmdd')||strWAVE_TYPE||'1' ;
                 else
                     s_wave_no:=to_char(sysdate,'yyyymmdd')||strWAVE_TYPE||to_char(to_number(substr(s_wave_no_today,10))+1);
                 end if ;
                 n_batch_no:=1;
              end if;

              --begin
              update Bset_wave_manage t set t.status=t.status, t.CURR_BATCH=n_batch_no
               where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strwarehouse_no
               and t.wave_no= s_wave_no and t.wave_type=strWAVE_TYPE ;

               --exception when no_data_found then
               if sql%notfound then
                 --新增批次表
                    insert into Bset_wave_manage
                      (enterprise_no,warehouse_no,WAVE_NO,start_time,rgst_name,
                       rgst_date,status,operate_date,CURR_BATCH,WAVE_TYPE)
                    values
                      (strEnterPriseNo,strwarehouse_no,s_wave_no,to_char(sysdate, 'hh24:mi'),strUser_Id,
                       sysdate,'0',trunc(sysdate),n_batch_no,strWAVE_TYPE);
                    if sql%notfound then
                      strOutMsg := 'N|[E24225]';
                      return;
                    end if;
               end if ;


                --获取当前波批、当前批次、当前设备的箱号
                begin
                select label_id into s_Label_Id from (select * from
                       (select ddd.device_cell_no label_id,pick_order cell_order--decode(ddd.stock_y,2,1,3,2,1,3) cell_order
                          from device_divide_d ddd,device_divide_group ddg
                         where ddg.enterprise_no=ddd.enterprise_no and ddg.warehouse_no=ddd.warehouse_no
                           and ddg.use_type='2'
                           and ddd.enterprise_no=strEnterPriseNo
                           and ddd.warehouse_no = i_untread.warehouse_no
                           and ddd.status='1'
                           and ddd.device_no=strDeviceNo
                           and ddd.device_cell_no not in
                               (select label_id
                                  from ridata_box
                                 where enterprise_no=strEnterPriseNo and warehouse_no = i_untread.warehouse_no
                                   and owner_no = i_untread.owner_no
                                   and device_no=strDeviceNo
                                   and status = '1')
                         order by cell_order,label_id) where  rownum=1  )  ;
                --如果获取不到新的扫描格子号，那么要临时增加相应的格子数；
                --判断当前ridata_box中是否有增加的格子编号
                exception when no_data_found then
                  --n_LabelNum :=0 ;
                  --begin
                   select max(to_number(label_id)) into s_Label_Id from ridata_box
                     where enterprise_no=strEnterPriseNo and warehouse_no = i_untread.warehouse_no
                     and owner_no = i_untread.owner_no
                     and device_no=strDeviceNo
                     and status = '1'
                     and label_id not in (select device_cell_no from device_divide_d ddd,device_divide_group ddg
                                           where ddg.enterprise_no=ddd.enterprise_no and ddg.warehouse_no=ddd.warehouse_no
                                             and ddg.use_type='2'
                                             and ddd.enterprise_no=strEnterPriseNo
                                             and ddd.warehouse_no = i_untread.warehouse_no
                                             and ddd.device_no=strDeviceNo ) ;
                  --if sql%notfound then
                  --exception when no_data_found then
                  if s_Label_Id is null then
                     n_add_LabelNum:=n_add_LabelNum+1 ;
                     s_Label_Id :='1' ;
                  else
                     n_add_LabelNum:=n_add_LabelNum+1 ;
                     s_Label_Id :=to_number(s_Label_Id)+1 ;
                  end if ;


                end  ;

                /*if n_batch_no<>n_OldBatchNo then
                   nLabelId:=nLabelId+1;
                end if;*/

                insert into ridata_box(enterprise_no,warehouse_no,owner_no,operate_date,label_id,
                       wave_no,batch_no,device_no,supplier_no,style,rgst_name,rgst_date,status,dps_cell_no,quality,WAVE_TYPE)
                    values(strEnterPriseNo,strwarehouse_no,i_untread.owner_no,trunc(sysdate),s_Label_Id,
                    s_wave_no,n_batch_no,strDeviceNo,'N',i_untread.style,strUser_Id,sysdate,'1',i_untread.area_no
                    ,strQualityFlag,strWAVE_TYPE);

                n_OldBatchNo:=n_batch_no;

            end loop;
        else
            --获取返配商品拣货巷道信息,没有拣货区的商品分播到异常区。
            for i_untread in (select * from ( select distinct rus.enterprise_no,rus.warehouse_no,
                                              rus.owner_no,
                                              cd.ware_no||cd.area_no||to_char(floor((to_number(cd.stock_no)-1)/n_stockNum)) area_no,
                                              'N' style
                                from ridata_untread_sm rus,
                                     ridata_untread_d  rud,
                                     cdef_defcell cd
                               where rus.enterprise_no=rud.enterprise_no
                                 and rud.enterprise_no=cd.enterprise_no
                                 and rud.warehouse_no = rus.warehouse_no
                                 and rud.warehouse_no = cd.warehouse_no
                                 and rud.cell_no = cd.cell_no
                                 and rud.untread_no = rus.untread_no
                                 and rus.status in ('10', '11','12')
                                 and rud.status in ('10', '11','12')
                                 and rus.enterprise_no=strEnterPriseNo
                                 and rus.warehouse_no = strwarehouse_no
                                 and rus.s_untread_no = strSUntreadNo
                                 and rud.untread_qty-rud.check_qty>0) rus
                                 where  not exists
                               (select 'X'
                                        from ridata_box rb
                                       where rb.enterprise_no=rus.enterprise_no
                                         and rb.warehouse_no = rus.warehouse_no
                                         and rb.owner_no = rus.owner_no
                                         and rb.dps_cell_no = rus.area_no
                                         and rb.status <= '2'
                                         and rb.wave_no=s_wave_no  and rb.device_no=strDeviceNo) order by enterprise_no,warehouse_no,
                                              owner_no,area_no) loop

              --n_count := n_count + 1;


              if s_wave_no ='0' then
                 nAddBatchFlag:='1';
                 n_cell_num:=1;
                 --取当天最大的波次号
                 select  nvl(max(wave_no),'0')  wave_no into s_wave_no_today  from Bset_wave_manage bwm where bwm.wave_type=strWAVE_TYPE
                           and bwm.enterprise_no=strEnterPriseNo and  bwm.warehouse_no=strwarehouse_no
                           and trunc(bwm.rgst_date)=trunc(sysdate) ;


                 --新增加波次号,批次从1取
                 if s_wave_no_today='0' then
                    s_wave_no:=to_char(sysdate,'yyyymmdd')||strWAVE_TYPE||'1' ;
                 else
                     s_wave_no:=to_char(sysdate,'yyyymmdd')||strWAVE_TYPE||to_char(to_number(substr(s_wave_no_today,10))+1);
                 end if ;
                 n_batch_no:=1;
              end if;

              --begin
              update Bset_wave_manage t set t.status=t.status, t.CURR_BATCH=n_batch_no
               where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strwarehouse_no
               and t.wave_no= s_wave_no and t.wave_type=strWAVE_TYPE ;

               --exception when no_data_found then
               if sql%notfound then
                 --新增批次表
                    insert into Bset_wave_manage
                      (enterprise_no,warehouse_no,WAVE_NO,start_time,rgst_name,
                       rgst_date,status,operate_date,CURR_BATCH,WAVE_TYPE)
                    values
                      (strEnterPriseNo,strwarehouse_no,s_wave_no,to_char(sysdate, 'hh24:mi'),strUser_Id,
                       sysdate,'0',trunc(sysdate),n_batch_no,strWAVE_TYPE);
                    if sql%notfound then
                      strOutMsg := 'N|[E24225]';
                      return;
                    end if;
               end if ;


                --获取当前波批、当前批次、当前设备的箱号
                begin
                select label_id into s_Label_Id from (select * from
                       (select ddd.device_cell_no label_id,pick_order cell_order--decode(ddd.stock_y,2,1,3,2,1,3) cell_order
                          from device_divide_d ddd,device_divide_group ddg
                         where ddg.enterprise_no=ddd.enterprise_no and ddg.warehouse_no=ddd.warehouse_no
                           and ddg.use_type='2'
                           and ddd.enterprise_no=strEnterPriseNo
                           and ddd.warehouse_no = i_untread.warehouse_no
                           and ddd.status='1'
                           and ddd.device_no=strDeviceNo
                           and ddd.device_cell_no not in
                               (select label_id
                                  from ridata_box
                                 where enterprise_no=strEnterPriseNo and warehouse_no = i_untread.warehouse_no
                                   and owner_no = i_untread.owner_no
                                   and device_no=strDeviceNo
                                   and status = '1')
                         order by cell_order,label_id) where  rownum=1  )  ;
                --如果获取不到新的扫描格子号，那么要临时增加相应的格子数；
                --判断当前ridata_box中是否有增加的格子编号
                exception when no_data_found then
                  --n_LabelNum :=0 ;
                  --begin
                   select max(to_number(label_id)) into s_Label_Id from ridata_box
                     where enterprise_no=strEnterPriseNo and warehouse_no = i_untread.warehouse_no
                     and owner_no = i_untread.owner_no
                     and device_no=strDeviceNo
                     and status = '1'
                     and label_id not in (select device_cell_no from device_divide_d ddd,device_divide_group ddg
                                           where ddg.enterprise_no=ddd.enterprise_no and ddg.warehouse_no=ddd.warehouse_no
                                             and ddg.use_type='2'
                                             and ddd.enterprise_no=strEnterPriseNo
                                             and ddd.warehouse_no = i_untread.warehouse_no
                                             and ddd.device_no=strDeviceNo ) ;
                  --if sql%notfound then
                  --exception when no_data_found then
                  if s_Label_Id is null then
                     n_add_LabelNum:=n_add_LabelNum+1 ;
                     s_Label_Id :='1' ;
                  else
                     n_add_LabelNum:=n_add_LabelNum+1 ;
                     s_Label_Id :=to_number(s_Label_Id)+1 ;
                  end if ;


                end  ;


                insert into ridata_box(enterprise_no,warehouse_no,owner_no,operate_date,label_id,
                       wave_no,batch_no,device_no,supplier_no,style,rgst_name,rgst_date,status,dps_cell_no,quality,WAVE_TYPE)
                    values(strEnterPriseNo,strwarehouse_no,i_untread.owner_no,trunc(sysdate),s_Label_Id,
                    s_wave_no,n_batch_no,strDeviceNo,'N',i_untread.style,strUser_Id,sysdate,'1',i_untread.area_no
                    ,strQualityFlag,strWAVE_TYPE);

                n_OldBatchNo:=n_batch_no;

            end loop;
        end if ;
    end if ;

    --更新汇总单头档的试算日期
    update ridata_untread_mm t set t.wave_no=s_wave_no,t.status='15',t.Device_No=strDeviceNo
    where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strwarehouse_no
           and t.s_untread_no=strSUntreadNo;

    strOutMsg := 'Y|';
  end p_scan_calculate;

  /**********************************************************************************************
   作者:hekl
   日期:2015-07-24
   功能:扫描墙资源表转历史（ridata_boxhty）
  ************************************************************************************************/
  procedure p_Insert_box_hty(strEnterPriseNo      in ridata_check_pal_tmp.enterprise_no%type,
                          strWareHouseNo       in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                          strWaveNo            in ridata_check_pal_tmp.wave_no%type, --波次号
                          strDeviceNo          in ridata_check_pal_tmp.device_no%type,--扫描墙号
                          strLabelId           in ridata_check_pal_tmp.label_id%type,--扫描墙储位（格子号）
                          strResult            out varchar2)is

  begin
    strResult := 'N|[p_Insert_box_hty]';

    --如果格子号为N，则是转该波次下的扫描墙下的所有；不为N，则是转该波次下的扫描墙下的格子
    if strLabelId='N' then
        insert into ridata_boxhty(enterprise_no, warehouse_no,
          owner_no, operate_date, wave_no, batch_no,
          label_id, device_no, supplier_no, style,
          status, dps_cell_no, quality, rgst_name,
          rgst_date, updt_name, updt_date, wave_type)
        select iid.enterprise_no,iid.warehouse_no,
          iid.owner_no,iid.operate_date,iid.wave_no,iid.batch_no,
          iid.label_id,iid.device_no,iid.supplier_no,iid.style,
          iid.status,iid.dps_cell_no,iid.quality,iid.rgst_name,
          iid.rgst_date,iid.updt_name,iid.updt_date,iid.wave_type
        from
          ridata_box iid
       where
          iid.enterprise_no=strEnterPriseNo and iid.warehouse_no=strWareHouseNo
          and iid.wave_no=strWaveNo and iid.device_no=strDeviceNo and iid.status ='3';

       --删除扫描墙资源表
       delete from ridata_box where enterprise_no=strEnterPriseNo  and warehouse_no=strWareHouseNo
       and wave_no=strWaveNo and device_no=strDeviceNo and status='3';

    else
        insert into ridata_boxhty(enterprise_no, warehouse_no,
          owner_no, operate_date, wave_no, batch_no,
          label_id, device_no, supplier_no, style,
          status, dps_cell_no, quality, rgst_name,
          rgst_date, updt_name, updt_date, wave_type)
        select iid.enterprise_no,iid.warehouse_no,
          iid.owner_no,iid.operate_date,iid.wave_no,iid.batch_no,
          iid.label_id,iid.device_no,iid.supplier_no,iid.style,
          iid.status,iid.dps_cell_no,iid.quality,iid.rgst_name,
          iid.rgst_date,iid.updt_name,iid.updt_date,iid.wave_type
        from
          ridata_box iid
        where
          iid.enterprise_no=strEnterPriseNo and iid.warehouse_no=strWareHouseNo
          and iid.wave_no=strWaveNo and iid.device_no=strDeviceNo
          and iid.label_id=strLabelId and iid.status ='3';


         --删除扫描墙资源表
         delete from ridata_box where enterprise_no=strEnterPriseNo  and warehouse_no=strWareHouseNo
         and wave_no=strWaveNo and device_no=strDeviceNo and status='3' and label_id=strLabelId;
    end if;


    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_Insert_box_hty;


    /**********************************************************************************************
   作者:lizhiping
   日期:2016-01-08
   功能:分配分播墙
  ************************************************************************************************/
  procedure p_allot_supp_dpscell(strEnterPriseNo      in cset_cell_supplier.enterprise_no%type,
                          strWareHouseNo       in cset_cell_supplier.WAREHOUSE_NO%type, --仓库编码
                          strWaveNo            in out cset_cell_supplier.wave_no%type, --波次
                          nBatchNo             in out cset_cell_supplier.batch_no%type,
                          strDpsDeviceNo       in out cset_cell_supplier.device_no%type,
                          strDpsCellNo         in out cset_cell_supplier.cell_no%type,
                          strWaveType          in varchar2,
                          strOwnerNo           in cset_cell_supplier.owner_no%type,
                          strSupplierNo        in cset_cell_supplier.supplier_no%type,
                          strStyle             in cset_cell_supplier.style%type,
                          strUserID            in cset_cell_supplier.rgst_name%type,
                          strOutMsg            out varchar2)is

    v_strAddBatchFlag varchar2(1);
    v_nCellNum number;
    v_strPrefix        varchar2(20);
    v_strTempWaveNo Bset_wave_manage.Wave_No%type;
    v_nTempBatchNo   cset_cell_supplier.batch_no%type;
  begin
  --锁定电子标签储位表
          update cdef_defcell_dps t set t.use_type=t.use_type
          where t.use_type='7'
            and t.enterprise_no = strEnterPriseNo
            and t.warehouse_no = strWareHouseNo;

          if strWaveNo ='0' then
             v_strAddBatchFlag:='1';
             v_nCellNum:=1;
             --取当天最大的波次号
             select  nvl(max(wave_no),'0')  wave_no into v_strTempWaveNo  from Bset_wave_manage bwm where bwm.wave_type=strWaveType
                       and bwm.enterprise_no=strEnterPriseNo and  bwm.warehouse_no=strWareHouseNo
                       and trunc(bwm.rgst_date)=trunc(sysdate) ;


             --新增加波次号,批次从1取
             v_strPrefix := to_char(sysdate,'yyyymmdd')||strWaveType;
             if v_strTempWaveNo='0' then
                strWaveNo:=v_strPrefix|| lpad('1',2,'0') ;
             else
                 strWaveNo:=v_strPrefix || lpad(to_char(to_number(substr(v_strTempWaveNo,length(v_strPrefix) + 1)) + 1),2,'0');
             end if ;
             nBatchNo:=1;
          end if;

         --判断是不是当前款都已经分播了电子标签分播储位
         select nvl(max(ccs.device_no) ,''),nvl(max(ccs.batch_no),'0'),nvl(max(ccs.cell_no),'N')
                into strDpsDeviceNo,v_nTempBatchNo,strDpsCellNo
            from cset_cell_supplier ccs
           where ccs.enterprise_no=strEnterPriseNo
             and ccs.warehouse_no = strWareHouseNo
             and ccs.owner_no = strOwnerNo
             and ccs.supplier_no = strSupplierNo
             and ccs.style=strStyle
             and ccs.use_type = '1'
             and ccs.status = '1'
             and ccs.wave_no=strWaveNo and rownum=1 ;
         if  v_nTempBatchNo ='0' then
             --取最大波次对应的最大批次号
             select nvl(max(curr_batch),1) into nBatchNo from Bset_wave_manage bwm where bwm.wave_type=strWaveType and bwm.status='0'
                     and bwm.enterprise_no=strEnterPriseNo and  bwm.warehouse_no=strWareHouseNo
                     and wave_no =strWaveNo   ;
         else
             nBatchNo:= v_nTempBatchNo ;
         end if ;

          if strWaveNo<>'0' then
              --已经分配电子标签分播储位，不用再重新取值
              if strDpsDeviceNo is null or strDpsDeviceNo='' then
                  --获取空储位数
                  select count(1)
                    into v_nCellNum
                    from cdef_defcell_dps cdd, cdef_defcell cdc,device_divide_m  ddm
                   where cdd.enterprise_no=cdc.enterprise_no
                     and cdd.enterprise_no=strEnterPriseNo and cdd.warehouse_no = cdc.warehouse_no
                     and cdd.cell_no = cdc.cell_no
                     and cdd.warehouse_no = strWareHouseNo
                     and cdd.enterprise_no=ddm.enterprise_no
                     and cdd.warehouse_no = ddm.warehouse_no
                     and cdd.device_no=ddm.device_no
                     and ddm.status='0'
                     and cdc.cell_status = '0'
                     and cdd.use_type='7'
                     and cdd.cell_no not in
                         (select cell_no
                            from cset_cell_supplier
                           where enterprise_no=strEnterPriseNo and warehouse_no = strWareHouseNo
                             and batch_no = nBatchNo
                             and wave_no=strWaveNo
                             and use_type = '1'
                             and status = '1');

                  --如果有空储位 且 批次使用次数要小于可用储位数 则 获取空储位
                  if v_nCellNum=0 then
                     v_strAddBatchFlag:='1';
                     nBatchNo:=nBatchNo+1;
                     v_nCellNum:=1;
                  end if;
              else
                  v_nCellNum:=0;
              end if ;
          end if;

          if v_nCellNum > 0 and (strDpsDeviceNo='' or strDpsDeviceNo is null) then

            select cell_no,work_station
              into strDpsCellNo,strDpsDeviceNo
              from (select cdc.cell_no,cdd.DEVICE_NO work_station,decode(cdc.stock_y,2,1,3,2,1,3) cell_id
                      from cdef_defcell_dps cdd, cdef_defcell cdc,device_divide_m  ddm
                     where cdd.enterprise_no=cdc.enterprise_no and cdd.enterprise_no=strEnterPriseNo
                       and cdd.warehouse_no = cdc.warehouse_no
                       and cdd.cell_no = cdc.cell_no
                       and cdd.warehouse_no = strWareHouseNo
                       and cdd.enterprise_no=ddm.enterprise_no
                       and cdd.warehouse_no = ddm.warehouse_no
                       and cdd.device_no=ddm.device_no
                       and ddm.status='0'
                       and cdc.cell_status = '0'
                       and cdd.use_type='7'
                       and cdd.cell_no not in
                           (select cell_no
                              from cset_cell_supplier
                             where enterprise_no=strEnterPriseNo and warehouse_no = strWareHouseNo
                               and owner_no = strOwnerNo
                               and batch_no = nBatchNo
                               and wave_no=strWaveNo
                               and use_type = '1'
                               and status = '1')
                     order by cell_id,cdd.DEVICE_NO,cell_no)
             where rownum = 1;

              --新增储位供应商对应关系
              insert into cset_cell_supplier
                (enterprise_no,warehouse_no,owner_no,operate_date,wave_no,batch_no,DEVICE_NO,
                 cell_no,supplier_no,style,use_type,status,rgst_name,rgst_date)
              values
                (strEnterPriseNo,strWareHouseNo,strOwnerNo,trunc(sysdate),strWaveNo,nBatchNo,strDpsDeviceNo,
                 strDpsCellNo,strSupplierNo,strStyle,'1','1',strUserID,sysdate);
              if sql%rowcount <= 0 then
                strOutMsg := 'N|[E24222]';
                return;
              end if;
          end if;

          --begin
          update Bset_wave_manage t set t.status=t.status, t.CURR_BATCH=nBatchNo
           where t.enterprise_no=strEnterPriseNo  and t.warehouse_no=strWareHouseNo
           and t.wave_no= strWaveNo and t.wave_type=strWaveType ;

           --exception when no_data_found then
           if sql%notfound then
             --新增批次表
                insert into Bset_wave_manage
                  (enterprise_no,warehouse_no,WAVE_NO,start_time,rgst_name,
                   rgst_date,status,operate_date,CURR_BATCH,WAVE_TYPE)
                values
                  (strEnterPriseNo,strWareHouseNo,strWaveNo,to_char(sysdate, 'hh24:mi'),strUserID,
                   sysdate,'0',trunc(sysdate),nBatchNo,strWaveType);
                if sql%notfound then
                  strOutMsg := 'N|[E24225]';
                  return;
                end if;
           end if ;
   strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_allot_supp_dpscell;

  /*******************************************************************************************************
  创建人：huangb
  创建时间：2016.05.18
  功能说明：返配单、返配验收单、返配验收板明细转历史
  ********************************************************************************************************/
  procedure P_Ridata_UnteradCheckHTY(strEnterPriseNo in  ridata_check_mhty.enterprise_no%type,
                                     strWAREHOUSE_NO in  ridata_check_mhty.WAREHOUSE_NO%type, --仓库编码)
                                     strOwnerNo      in  ridata_check_mhty.owner_no%type,
                                     strSuntreadNo   in  ridata_check_mhty.S_UNTREAD_NO%type, --返配汇总单号
                                     strWorkerNo     in  ridata_check_mhty.rgst_name%type, --操作人
                                     strOutMsg       Out varchar2) is
  begin
   strOutMsg := 'N|[P_Ridata_UnteradCheckHTY]';

   --返配单头档转历史
   insert into ridata_untread_mhty
     (warehouse_no, owner_no, untread_type, untread_no, po_type, po_no, class_type
     , cust_no, untread_date, request_date, status, create_flag, untread_remark, untread_flag
     , cust_address_code, stock_type, stock_value, dept_no, send_flag, rgst_name, rgst_date
     , updt_name, updt_date, enterprise_no, exp_no, quality, org_no, take_type
     , rsv_varod1, rsv_varod2, rsv_varod3, rsv_varod4, rsv_varod5, rsv_varod6, rsv_varod7
     , rsv_varod8, rsv_num1, rsv_num2, rsv_num3, rsv_date1, rsv_date2, rsv_date3
     , car_plan_no, report_up_serial)
   select rum.warehouse_no, rum.owner_no, rum.untread_type, rum.untread_no, rum.po_type, rum.po_no, rum.class_type
     , rum.cust_no, rum.untread_date, rum.request_date, rum.status, rum.create_flag, rum.untread_remark, rum.untread_flag
     , rum.cust_address_code, rum.stock_type, rum.stock_value, rum.dept_no, rum.send_flag, rum.rgst_name, rum.rgst_date
     , strWorkerNo, sysdate, rum.enterprise_no, rum.exp_no, rum.quality, rum.org_no, rum.take_type
     , rum.rsv_varod1, rum.rsv_varod2, rum.rsv_varod3, rum.rsv_varod4, rum.rsv_varod5, rum.rsv_varod6, rum.rsv_varod7
     , rum.rsv_varod8, rum.rsv_num1, rum.rsv_num2, rum.rsv_num3, rum.rsv_date1, rum.rsv_date2, rum.rsv_date3
     , rum.car_plan_no, rum.report_up_serial
   from ridata_untread_m rum
   where rum.enterprise_no = strEnterPriseNo
     and rum.warehouse_no = strWAREHOUSE_NO
     and rum.owner_no = strOwnerNo
     and rum.untread_no in
        (select rcm.untread_no from ridata_check_m rcm
          where rcm.enterprise_no = strEnterPriseNo
            and rcm.warehouse_no = strWAREHOUSE_NO
            and rcm.owner_no = strOwnerNo
            and rcm.S_UNTREAD_NO = strSuntreadNo);

   --返配单明细转历史
   insert into ridata_untread_dhty
     (warehouse_no, owner_no, untread_no, po_id, supplier_no, article_no, packing_qty
     , untread_qty, check_qty, unit_cost, check_name, check_date, status, lot_no
     , quality, produce_date, expire_date, enterprise_no, recede_no, cell_no)
   select rud.warehouse_no, rud.owner_no, rud.untread_no, rud.po_id, rud.supplier_no, rud.article_no, rud.packing_qty
     , rud.untread_qty, rud.check_qty, rud.unit_cost, rud.check_name, rud.check_date, rud.status, rud.lot_no
     , rud.quality, rud.produce_date, rud.expire_date, rud.enterprise_no, rud.recede_no, rud.cell_no
   from ridata_untread_d rud
   where rud.enterprise_no = strEnterPriseNo
     and rud.warehouse_no = strWAREHOUSE_NO
     and rud.owner_no = strOwnerNo
     and rud.untread_no in
        (select rcm.untread_no from ridata_check_m rcm
          where rcm.enterprise_no = strEnterPriseNo
            and rcm.warehouse_no = strWAREHOUSE_NO
            and rcm.owner_no = strOwnerNo
            and rcm.S_UNTREAD_NO = strSuntreadNo);

   --返配验收板明细转历史
   insert into ridata_check_palhty
     (enterprise_no, warehouse_no, owner_no, label_no, check_no, check_row_id, article_no
     , packing_qty, check_qty, status, printer_group_no, dock_no, container_no, fixpal_flag
     , sub_label_no, business_type, cell_no, firstcheck_label_no, device_no, wave_no, batch_no
     , quality, rgst_name, rgst_date, updt_name, updt_date, class_type, untread_type)
   select rcp.enterprise_no, rcp.warehouse_no, rcp.owner_no, rcp.label_no, rcp.check_no, rcp.check_row_id, rcp.article_no
     , rcp.packing_qty, rcp.check_qty, rcp.status, rcp.printer_group_no, rcp.dock_no, rcp.container_no, rcp.fixpal_flag
     , rcp.sub_label_no, rcp.business_type, rcp.cell_no, rcp.firstcheck_label_no, rcp.device_no, rcp.wave_no, rcp.batch_no
     , rcp.quality, rcp.rgst_name, rcp.rgst_date, strWorkerNo, sysdate, rcp.class_type, rcp.untread_type
   from ridata_check_pal rcp
   where rcp.enterprise_no = strEnterPriseNo
     and rcp.warehouse_no = strWAREHOUSE_NO
     and rcp.owner_no = strOwnerNo
     and rcp.check_no in
        (select rcm.check_no from ridata_check_m rcm
          where rcm.enterprise_no = strEnterPriseNo
            and rcm.warehouse_no = strWAREHOUSE_NO
            and rcm.owner_no = strOwnerNo
            and rcm.S_UNTREAD_NO = strSuntreadNo);

   --返配验收单明细转历史
   insert into ridata_check_dhty
     (warehouse_no, owner_no, check_no, row_id, article_no, barcode, packing_qty
     , lot_no, produce_date, expire_date, quality, rsv_batch1, rsv_batch2, rsv_batch3
     , rsv_batch4, rsv_batch5, rsv_batch6, rsv_batch7, rsv_batch8, stock_type, stock_value
     , dept_no, check_qty, check_worker, supplier_no, check_start_date, check_end_date, check_type
     , enterprise_no, price)
   select rcd.warehouse_no, rcd.owner_no, rcd.check_no, rcd.row_id, rcd.article_no, rcd.barcode, rcd.packing_qty
     , rcd.lot_no, rcd.produce_date, rcd.expire_date, rcd.quality, rcd.rsv_batch1, rcd.rsv_batch2, rcd.rsv_batch3
     , rcd.rsv_batch4, rcd.rsv_batch5, rcd.rsv_batch6, rcd.rsv_batch7, rcd.rsv_batch8, rcd.stock_type, rcd.stock_value
     , rcd.dept_no, rcd.check_qty, rcd.check_worker, rcd.supplier_no, rcd.check_start_date, rcd.check_end_date, rcd.check_type
     , rcd.enterprise_no, rcd.price
   from ridata_check_d rcd
   where rcd.enterprise_no = strEnterPriseNo
     and rcd.warehouse_no = strWAREHOUSE_NO
     and rcd.owner_no = strOwnerNo
     and rcd.check_no in
        (select rcm.check_no from ridata_check_m rcm
          where rcm.enterprise_no = strEnterPriseNo
            and rcm.warehouse_no = strWAREHOUSE_NO
            and rcm.owner_no = strOwnerNo
            and rcm.S_UNTREAD_NO = strSuntreadNo);

   --返配验收单头档转历史
   insert into ridata_check_mhty
     (enterprise_no, warehouse_no, owner_no, check_no, s_check_no, untread_type, s_untread_no
     , untread_no, dock_no, check_worker, status, check_start_date, check_end_date, printer_group_no
     , check_tools, send_flag, print_times, rgst_name, rgst_date, updt_name, updt_date, report_up_serial)
   select rcm.enterprise_no, rcm.warehouse_no, rcm.owner_no, rcm.check_no, rcm.s_check_no, rcm.untread_type, rcm.s_untread_no
     , rcm.untread_no, rcm.dock_no, rcm.check_worker, rcm.status, rcm.check_start_date, rcm.check_end_date, rcm.printer_group_no
     , rcm.check_tools, rcm.send_flag, rcm.print_times, rcm.rgst_name, rcm.rgst_date, strWorkerNo, sysdate, rcm.report_up_serial
   from ridata_check_m rcm
   where rcm.enterprise_no = strEnterPriseNo
     and rcm.warehouse_no = strWAREHOUSE_NO
     and rcm.owner_no = strOwnerNo
     and rcm.S_UNTREAD_NO = strSuntreadNo;

   --删除正表数据
   delete ridata_untread_m rum
    where rum.enterprise_no = strEnterPriseNo
      and rum.warehouse_no = strWAREHOUSE_NO
      and rum.owner_no = strOwnerNo
      and rum.untread_no in
         (select rcm.untread_no from ridata_check_m rcm
           where rcm.enterprise_no = strEnterPriseNo
             and rcm.warehouse_no = strWAREHOUSE_NO
             and rcm.owner_no = strOwnerNo
             and rcm.S_UNTREAD_NO = strSuntreadNo);

   delete ridata_untread_d rud
    where rud.enterprise_no = strEnterPriseNo
      and rud.warehouse_no = strWAREHOUSE_NO
      and rud.owner_no = strOwnerNo
      and rud.untread_no in
         (select rcm.untread_no from ridata_check_m rcm
           where rcm.enterprise_no = strEnterPriseNo
             and rcm.warehouse_no = strWAREHOUSE_NO
             and rcm.owner_no = strOwnerNo
             and rcm.S_UNTREAD_NO = strSuntreadNo);

   delete ridata_check_pal rcp
    where rcp.enterprise_no = strEnterPriseNo
      and rcp.warehouse_no = strWAREHOUSE_NO
      and rcp.owner_no = strOwnerNo
      and rcp.check_no in
         (select rcm.check_no from ridata_check_m rcm
           where rcm.enterprise_no = strEnterPriseNo
             and rcm.warehouse_no = strWAREHOUSE_NO
             and rcm.owner_no = strOwnerNo
             and rcm.S_UNTREAD_NO = strSuntreadNo);

   delete ridata_check_d rcd
    where rcd.enterprise_no = strEnterPriseNo
      and rcd.warehouse_no = strWAREHOUSE_NO
      and rcd.owner_no = strOwnerNo
      and rcd.check_no in
         (select rcm.check_no from ridata_check_m rcm
           where rcm.enterprise_no = strEnterPriseNo
             and rcm.warehouse_no = strWAREHOUSE_NO
             and rcm.owner_no = strOwnerNo
             and rcm.S_UNTREAD_NO = strSuntreadNo);

   delete ridata_check_m rcm
    where rcm.enterprise_no = strEnterPriseNo
      and rcm.warehouse_no = strWAREHOUSE_NO
      and rcm.owner_no = strOwnerNo
      and rcm.S_UNTREAD_NO = strSuntreadNo;


  strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|P_Ridata_UnteradCheckHTY' || SQLERRM ||
            substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end P_Ridata_UnteradCheckHTY;

  --获取返配单据类型
  function f_get_untread_type(strQuality in ridata_untread_m.quality%type,
                            strClasstype  in ridata_untread_m.class_type%type)
    return varchar2 is

    v_strReturn ridata_untread_m.quality%type := '0';
  begin

      select case when strQuality='2' and  strClasstype='1' then '3'
                when strQuality='A' and  strClasstype='0' then '4'
                when strQuality='0' and  strClasstype='0' then '5'
                when strQuality='1' and  strClasstype='0' then '6'  else '0'
                end
        into v_strReturn
        from dual;

    return v_strReturn;
  exception
    when others then
      return v_strReturn;
  end;

end pkobj_Ridata;

/

