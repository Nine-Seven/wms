create package        PKOBJ_ODATA_EXPCANCEL is
/****************************************************************************************************
     创建人：hcx
     2015.4.27
     病单处理
    ******************************************************************************************************/

  --写病单处理指示
  procedure P_InOdataExpCancelDirect(
             strEnterpriseNo        in          odata_exp_cancel_direct.enterprise_no%type,
             strWareHouseNo         in          odata_exp_cancel_direct.warehouse_no%type,
             strOwnerNo             in          odata_exp_cancel_direct.owner_no%type,
             strExpNo               in          odata_exp_cancel_direct.exp_no%type,
             strSourceType          in          odata_exp_cancel_direct.source_type%type,
             strUserId              in          odata_exp_cancel_direct.rgst_name%type,
             strResult              out         varchar2);

  --写病单处理单头档
   procedure P_InsertOdataExpCancelM(
               strEnterpriseNo        in          odata_exp_cancel_m.enterprise_no%type,
               strWareHouseNo         in          odata_exp_cancel_m.warehouse_no%type,
               strCanCelNo             in          odata_exp_cancel_m.cancel_no%type,
               strOwnerNo             in          odata_exp_cancel_m.owner_no%type,
               strExpNo               in          odata_exp_cancel_m.exp_no%type,
               strSourceType          in          odata_exp_cancel_direct.source_type%type,
               strUserId              in          odata_exp_cancel_m.rgst_name%type,
               strResult              out         varchar2);

   --写病单处理单明细
   procedure P_InsertOdataExpCancelD(
               strEnterpriseNo        in          odata_exp_cancel_d.enterprise_no%type,
               strWareHouseNo         in          odata_exp_cancel_d.warehouse_no%type,
               strOwnerNo             in          odata_exp_cancel_d.cancel_no%type,
               strCanCelNo             in          odata_exp_cancel_d.cancel_no%type,
               strExpNo               in          odata_exp_cancel_d.exp_no%type,
               strSourceType          in          odata_exp_cancel_direct.source_type%type,
               strUserId              in          odata_exp_cancel_d.rgst_name%type,
               strResult              out         varchar2);

    --写病单标签明细
   procedure P_InOdataExpCancelLabelItem(
               strEnterpriseNo        in          odata_exp_cancel_label_item.enterprise_no%type,
               strWareHouseNo         in          odata_exp_cancel_label_item.warehouse_no%type,
               strCancelNo            in          odata_exp_cancel_label_item.cancel_no%type,
               strExpNo               in          odata_exp_cancel_label_item.exp_no%type,
               strUserId              in          odata_exp_cancel_label_item.rgst_name%type,
               strResult              out         varchar2);

   --病单处理指示转历史
    procedure p_RemoveOdataExpCancelDirect(
               strEnterpriseNo        in     odata_exp_cancel_direct.Enterprise_No%type,
               strWarehouseNo         in     odata_exp_cancel_direct.Warehouse_No%type,
               strExpNo               in     odata_exp_cancel_direct.exp_no%type,
               strSourceType          in    odata_exp_cancel_direct.source_type%type,
               strResult              out    varchar2);
  /*****************************************************************************************************************
   hekangli
  20150430
  功能说明：病单审核，病单头档明细表转历史
  ***************************************************************************************************************/
  procedure proc_RemoveCancel(
                         strEnterpriseNo          in     Odata_Exp_Cancel_m.Enterprise_No%type,
                         strWarehouseNo           in     ODATA_EXP_CANCEL_M.Warehouse_No%type,
                         strCancelNo              in     odata_exp_cancel_m.cancel_no%type,
                         strResult                out    varchar2);

 /*****************************************************************************************************************
  hekangli
  20150430
  功能说明：病单审核，病单标签明细转历史
  ***************************************************************************************************************/
  procedure proc_RemoveCancelLabel(
                         strEnterpriseNo          in     Odata_Exp_Cancel_m.Enterprise_No%type,
                         strWarehouseNo           in     ODATA_EXP_CANCEL_M.Warehouse_No%type,
                         strCancelNo              in     odata_exp_cancel_m.cancel_no%type,
                         strResult                out    varchar2);

end PKOBJ_ODATA_EXPCANCEL;


/

