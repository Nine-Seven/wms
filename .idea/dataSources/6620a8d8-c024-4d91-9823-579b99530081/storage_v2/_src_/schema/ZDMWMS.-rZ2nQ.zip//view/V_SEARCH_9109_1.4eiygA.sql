create view V_SEARCH_9109_1 as
select
  a.enterprise_no,
  a.warehouse_no,
  a.owner_no,
  iim.po_no,
  a.check_no,
  a.check_worker1,
  b.worker_name,
  operate_date,
  count(distinct a.article_no) articleCount,
  sum(a.check_qty) check_qty,
  trunc(sum(a.check_qty/a.packing_qty)) Checkbox,
  sum(mod(a.check_qty,a.packing_qty)) checkDis,
  sum(volumn) volumn,
  sum(weight) weight
from (
    select
    m.enterprise_no,
    m.warehouse_no,
    m.owner_no,
    m.check_no,
    m.import_no,
    d.check_worker1,
    d.article_no,
    d.packing_qty,
    vapvw.packing_volumn,
    vapvw.packing_weight,
    to_char(m.rgst_date,'yyyy-mm-dd') operate_date,
    sum(d.check_qty) check_qty,
    trunc(sum(d.check_qty/d.packing_qty)) Checkbox,
    sum(mod(d.check_qty,d.packing_qty)) checkDis,
    trunc(sum(d.check_qty/d.packing_qty))*vapvw.packing_volumn volumn,
    trunc(sum(d.check_qty/d.packing_qty))*vapvw.packing_weight weight
  from
    idata_check_m m,
    idata_check_d d,
    v_article_pack_volumn_weight vapvw
  where
    m.check_no=d.check_no
    and m.warehouse_no=d.warehouse_no
    and d.enterprise_no=vapvw.enterprise_no
    and d.article_no=vapvw.article_no
    and d.packing_qty=vapvw.packing_qty
    and m.enterprise_no = d.enterprise_no
  group by
    m.enterprise_no,
    m.warehouse_no,
    m.owner_no,
    m.check_no,
    m.import_no,
    d.check_worker1,
    d.article_no,
    d.packing_qty,
    vapvw.packing_volumn,
    vapvw.packing_weight,
    to_char(m.rgst_date,'yyyy-mm-dd')
  )a,
  idata_import_m iim,
  bdef_defworker b
where
  a.import_no=iim.import_no
  and a.check_worker1=b.worker_no
  and a.warehouse_no=b.warehouse_no
  and a.enterprise_no=iim.enterprise_no
   and a.warehouse_no=iim.warehouse_no
  and a.enterprise_no=b.enterprise_no
group by
  a.enterprise_no,
  a.warehouse_no,
  a.owner_no,
  iim.po_no,
  a.check_no,
  a.check_worker1,
  b.worker_name,
  operate_date
order by a.check_no desc


/

