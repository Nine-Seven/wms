create view V_SEARCH_9101_4 as
select cdw.enterprise_no,cdw.warehouse_no,cdw.ware_no,cdw.ware_name,
       cda.area_no,cda.area_name,
       cdc.cell_no,cdc.disp_cell_no,b1.worker_name as rgst_name,cdc.rgst_date,
       b2.worker_name as updt_name,cdc.updt_date
 from cdef_defware cdw,cdef_defarea cda, cdef_defcell cdc
 left join bdef_defworker b1 on b1.enterprise_no=cdc.enterprise_no and b1.worker_no=cdc.rgst_name
 left join bdef_defworker b2 on b2.enterprise_no=cdc.enterprise_no and b2.worker_no=cdc.updt_name
where cdw.enterprise_no=cda.enterprise_no
  and cdw.warehouse_no=cda.warehouse_no
  and cdw.ware_no=cda.ware_no
  and cda.enterprise_no=cdc.enterprise_no
  and cda.warehouse_no=cdc.warehouse_no
  and cda.ware_no=cdc.ware_no
  and cda.area_no=cdc.area_no order by cdw.ware_no,cda.area_no,cdc.cell_no

/

