create package body BR_WMS_JK is
  /*****************************************************************************************
  功能：取wms仓别
  Modify By hcx AT 2016-02-25
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure P_WAREHOUSENO_GET(strEnterPriseNo in bdef_defloc.enterprise_no%type,
                              strWareHouseNo  in bdef_defloc.warehouse_no%type, --ERP仓别
                              nWareHouseNo    out varchar2, --返回WMS仓别
                              strOutMsg       out varchar2) is --返回 执行结果
  begin
    strOutMsg := 'Y|';
    begin
      select wareHouse_no
        into nWareHouseNo
        from LOC_SET@zdmwms_JK
       where enterprise_no = strEnterpriseNo
         and erp_warehouse_no = strWareHouseNo;
    exception
      when no_data_found then
        strOutMsg := 'N|';
    end;

  end P_WAREHOUSENO_GET;
  /*****************************************************************************************
  功能：取wms货主
  Modify By hcx AT 2016-02-25
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure P_OWNERNO_GET(strEnterPriseNo in bdef_defowner.enterprise_no%type,
                          strOwnerNo      in bdef_defowner.owner_no%type, --ERP货主
                          nOwnerNo        out varchar2, --返回WMS货主
                          strOutMsg       out varchar2) is --返回 执行结果
  begin
    strOutMsg := 'Y';
    begin
      select owner_no
        into nOwnerNo
        from OWNER_SET@zdmwms_JK
       where enterprise_no = strEnterpriseNo
         and erp_owner_no = strOwnerNo;
    exception
      when no_data_found then
        strOutMsg := 'N';
    end;

  end P_OWNERNO_GET;
  /*****************************************************************************************
  功能：取wms机构
  Modify By hcx AT 2016-02-25
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure P_ORG_GET(strEnterPriseNo in idata_import_m.enterprise_no%type,
                      strOrgNo        in idata_import_m.org_no%type, --ERP机构
                      nOrgNo          out varchar2, --返回WMS机构
                      strOutMsg       out varchar2) is --返回 执行结果
  begin

    strOutMsg := 'Y';
    begin
      select org_no
        into nOrgNo
        from ORG_SET@zdmwms_JK
       where enterprise_no = strEnterpriseNo
         and erp_org_no = strOrgNo;
    exception
      when no_data_found then
        strOutMsg := 'N';
    end;

  end P_ORG_GET;
  /*****************************************************************************************
    功能：接口，上传WMS手建报损单
   Modify By hcx AT 2016-03-01
   pragma autonomous_transaction;
  *****************************************************************************************/
  procedure P_SODATA_WASTE_AUDIT is
    pragma autonomous_transaction;
    OUTMSG           varchar2(300);
    v_strWarehouseNo bdef_defloc.warehouse_no%type; --仓别
    v_strOrgNo       Idata_Import_M.Org_No%type; --机构号
  begin

    update sodata_waste_m m
       set m.send_flag = '11'
     where m.status = '11'
       and m.send_flag = '10';

    declare
      cursor Get_SODATA_WASTE_AUDIT is
        select m.*
          from sodata_waste_m m
         where m.send_flag = '11'
           and m.status = '11'
           and m.enterprise_no = '8888';

      ii Get_SODATA_WASTE_AUDIT%rowtype; ---定义游标变量
    begin
      open Get_SODATA_WASTE_AUDIT;
      loop
        Fetch Get_SODATA_WASTE_AUDIT
          into ii;
        Exit when Get_SODATA_WASTE_AUDIT%notfound;

        select wareHouse_no
          into v_strWarehouseNo
          from LOC_SET@zdmwms_JK
         where enterprise_no = ii.enterprise_no
           and warehouse_no = ii.warehouse_no;

        if v_strWarehouseNo is null then
          v_strWarehouseNo := ii.warehouse_no;
        end if;

        select org_no
          into v_strOrgNo
          from ORG_SET@zdmwms_JK
         where enterprise_no = ii.enterprise_no
           and org_no = ii.org_no;

        if v_strOrgNo is null then
          v_strOrgNo := ii.org_no;
        end if;
        insert into WMS_WASTE@zdmwms_jk
          (sheetid,
           warehouse_no,
           owner_article_no,
           qty,
           sdate,
           shop_no,
           status,
           pkcount)
          select swd.waste_no,
                 v_strWarehouseNo,
                 bd.owner_article_no,
                 swd.waste_qty,
                 swm.waste_date,
                 v_strOrgNo,
                 '0',
                 swd.packing_qty
            from sodata_waste_d swd, sodata_waste_m swm, bdef_defarticle bd
           where swd.enterprise_no = swm.enterprise_no
             and swd.warehouse_no = swm.warehouse_no
             and swd.owner_no = swm.owner_no
             and swd.waste_no = swm.waste_no
             and swd.enterprise_no = bd.enterprise_no
             and swd.owner_no = bd.owner_no
             and swd.article_no = bd.article_no
             and swd.enterprise_no = ii.enterprise_no
             and swd.warehouse_no = ii.warehouse_no
             and swd.owner_no = ii.owner_no
             and swd.waste_no = ii.waste_no;

      end loop;

      close Get_SODATA_WASTE_AUDIT;
    end;
    update sodata_waste_m m
       set m.send_flag = '13',
           m.updt_name = 'admin_interface',
           m.updt_date = sysdate
     where m.status = '11'
       and m.send_flag = '11';
    commit;
  exception
    when others then
      rollback;
      OUTMSG := 'N| ' || SQLERRM ||
                substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_SODATA_WASTE_AUDIT;
  /*****************************************************************************************
  功能：接口，接收供应商资料
  Modify By hcx AT 2016-02-29
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure P_BDEF_DEFSUPPLIER_DOWN is
    pragma autonomous_transaction;
    OUTMSG       varchar2(300);
    v_strOwnerNo bdef_defowner.owner_no%type;
    v_nCount     integer;
  begin
    for a in (select distinct enterprise_no, owner_no, sheetid
                from WMS_SUPPLIER@zdmwms_jk
               order by sheetid) loop
      --取wms货主
      P_OWNERNO_GET(a.enterprise_no,
                              a.owner_no,
                              v_strOwnerNo,
                              OUTMSG);
      if v_strOwnerNo is null then
        goto nest;
      end if;
      begin
        --按sheetid 更新供应商
        --锁数据
        update WMS_SUPPLIER@zdmwms_jk
           set owner_no = v_strOwnerNo
         where owner_no = a.owner_no
           and sheetid = a.sheetid
           and enterprise_no = a.enterprise_no;
        v_nCount := 0;
        for p in (select *
                    from WMS_SUPPLIER@zdmwms_jk
                   where owner_no = v_strOwnerNo
                     and sheetid = a.sheetid
                     and enterprise_no = a.enterprise_no) loop
          v_nCount := 1;
          --更新供应商
          UPDATE bdef_defsupplier bd
             SET supplier_name      = p.supplier_name,
                 real_supplier_name = p.supplier_name,
                 supplier_alias     = p.supplier_name,
                 supplier_address1  = nvl(p.address, 'N'),
                 supplier_phone1    = nvl(p.phone, 'N'),
                 supplier_fax1      = nvl(p.FAX, 'N'),
                 supplier1          = nvl(p.linkman, 'N'),
                 supplier_remark    = nvl(p.Notes, 'N'),
                 status             = nvl(p.status, '1'),
                 updt_name          = 'admin_interface',
                 updt_date          = sysdate
           WHERE bd.owner_no = p.owner_no
             and bd.real_supplier_no = p.supplier_no;
          if (sql%rowcount = 0) then
            --更新不到则新增
            insert into Bdef_DEFSUPPLIER
              (owner_no,
               supplier_no,
               real_supplier_no,
               real_supplier_name,
               supplier_name,
               supplier_alias,
               supplier_address1,
               supplier_phone1,
               supplier_fax1,
               supplier1,
               supplier_remark,
               status,
               create_flag,
               rgst_name,
               rgst_date)
            values
              (p.owner_no,
               p.supplier_no,
               p.supplier_no,
               p.supplier_name,
               p.supplier_name,
               p.supplier_name,
               nvl(p.address, 'N'),
               nvl(p.phone, 'N'),
               nvl(p.FAX, 'N'),
               nvl(p.linkman, 'N'),
               nvl(p.Notes, 'N'),
               nvl(p.status, '1'),
               1,
               'admin_interface',
               sysdate);
          end if;
        end loop;
        if v_nCount = 1 then
          --转历史，删除已经处理的数据
          insert into WMS_SUPPLIERbak@zdmwms_jk
            select *
              from WMS_SUPPLIER@zdmwms_jk
             where owner_no = v_strOwnerNo
               and sheetid = a.sheetid
               and enterprise_no = a.enterprise_no;
          delete from WMS_SUPPLIER@zdmwms_jk
           where owner_no = v_strOwnerNo
             and sheetid = a.sheetid
             and enterprise_no = a.enterprise_no;
          commit;
        else
          rollback;
        end if;
      end;

      <<nest>>
      null;
    end loop;
  exception
    when others then
      rollback;
      OUTMSG := 'O| ' || SQLERRM ||
                substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_BDEF_DEFSUPPLIER_DOWN;

  /*****************************************************************************************
   功能：接口，接收客户资料
  Modify By hcx AT 2016-02-29
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure P_BDEF_DEFCUST_DOWN is
    pragma autonomous_transaction;
    OUTMSG       varchar2(300);
    v_strOwnerNo bdef_defowner.owner_no%type;
    v_nCount     integer;
  begin
    for a in (select distinct enterprise_no, owner_no, sheetid
                from WMS_CUST@zdmwms_jk) loop
      --取wms货主
      P_OWNERNO_GET(a.enterprise_no,
                              a.owner_no,
                              v_strOwnerNo,
                              OUTMSG);
      if v_strOwnerNo is null then
        goto nest;
      end if;
      begin
        --锁定数据
        update WMS_CUST@zdmwms_jk
           set owner_no = v_strOwnerNo
         where owner_no = a.owner_no
           and sheetid = a.sheetid
           and enterprise_no = a.enterprise_no;
        v_nCount := 0;
        for p in (select *
                    from WMS_CUST@zdmwms_jk
                   where owner_no = v_strOwnerNo
                     and sheetid = a.sheetid
                     and enterprise_no = a.enterprise_no) loop
          v_nCount := 1;
          update Bdef_DEFCUST bd
             set cust_name       = p.cust_name,
                 cust_flag       = '0',
                 cust_type       = p.cust_type,
                 shipping_method = '2',
                 cust_address    = p.address,
                 cust_postcode   = p.zipcode,
                 cust_phone2     = p.tele,
                 cust_fax2       = p.fax,
                 cust_email2     = p.e_mail,
                 contactor_name1 = p.manager,
                 contactor_name2 = p.linkman,
                 status          = p.status,
                 cust_dept       = p.department_no,
                 cust_province   = p.province,
                 cust_city       = p.city,
                 cust_zone       = p.zone,
                 cust_notecode   = p.notes,
                 updt_name       = 'admin_interface',
                 updt_date       = sysdate
           WHERE bd.owner_no = v_strOwnerNo
             and bd.owner_cust_no = p.owner_cust_no;
          if (sql%rowcount = 0) then
            --更新不到则新增
            insert into bdef_defcust
              (owner_no,
               owner_cust_no,
               cust_no,
               cust_flag,
               cust_type,
               shipping_method,
               box_deliver,
               cust_name,
               cust_address,
               cust_postcode,
               cust_phone2,
               cust_fax2,
               cust_email2,
               contactor_name1,
               contactor_name2,
               status,
               create_flag,
               cust_dept,
               cust_province,
               cust_city,
               cust_zone,
               cust_notecode,
               rgst_name,
               rgst_date)
            values
              (p.owner_no,
               p.owner_cust_no,
               p.owner_cust_no,
               '0',
               nvl(p.cust_type, '0'),
               '2',
               0,
               p.cust_name,
               nvl(p.address, 'N'),
               nvl(p.zipcode, 'N'),
               nvl(p.tele, 'N'),
               nvl(p.fax, 'N'),
               nvl(p.e_mail, 'N'),
               nvl(p.manager, 'N'),
               nvl(p.linkman, 'N'),
               p.status,
               1,
               nvl(p.department_no, 'N'),
               nvl(p.province, 'N'),
               nvl(p.city, 'N'),
               nvl(p.zone, 'N'),
               nvl(p.notes, 'N'),
               'admin_interface',
               sysdate);
          end if;
        end loop;
        if v_nCount = 1 then
          --转历史，删除已经处理的数据
          insert into WMS_CUSTBAK@zdmwms_jk
            select *
              from WMS_CUST@zdmwms_jk
             where owner_no = v_strOwnerNo
               and sheetid = a.sheetid
               and enterprise_no = a.enterprise_no;
          delete from WMS_CUST@zdmwms_jk
           where owner_no = v_strOwnerNo
             and sheetid = a.sheetid
             and enterprise_no = a.enterprise_no;

          commit;
        else
          rollback;
        end if;
      end;
      <<nest>>
      null;
    end loop;
  exception
    when others then
      rollback;
      OUTMSG := 'O| ' || SQLERRM ||
                substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_BDEF_DEFCUST_DOWN;
  /*****************************************************************************************
   功能：接口，接收商品类别
  Modify By hcx AT 2016-02-29
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure P_BDEF_ARTICLE_GROUP_DOWN is
    OUTMSG          varchar2(300);
    v_strOwnerNo    bdef_defowner.owner_no%type;
    v_strLevelid    varchar2(1); --类别级别
    v_strMGroupName varchar2(45); --中类名称
    v_strLGroupNo   varchar2(20); --大类编码
    v_strLGroupName varchar2(45); --大类名称
  begin
    for a in (select distinct enterprise_no, owner_no, sheetid
                from WMS_ARTICLEGROUP@zdmwms_jk) loop
      --取wms货主
      P_OWNERNO_GET(a.enterprise_no,
                              a.owner_no,
                              v_strOwnerNo,
                              OUTMSG);
      if v_strOwnerNo is not null then
        --锁定数据
        --从ERP的类别资料取1，2，3级做为WMS中的大，中，小类。
        update WMS_ARTICLEGROUP@zdmwms_jk
           set owner_no = v_strOwnerNo
         where levelid in ('1', '2', '3')
           and owner_no = a.owner_no
           and sheetid = a.sheetid
           and enterprise_no = a.enterprise_no;

        for bm in (select *
                     from WMS_ARTICLEGROUP@zdmwms_jk m
                    where m.owner_no = v_strOwnerNo
                      and m.levelid in ('1', '2', '3')
                      and m.sheetid = a.sheetid
                      and m.enterprise_no = a.enterprise_no
                    order by levelid) loop
          begin
            if bm.levelid = '1' then
              v_strLevelid := '2';
            end if;
            if bm.levelid = '2' then
              v_strLevelid := '1';
            end if;
            if bm.levelid = '3' then
              v_strLevelid := '0';
            end if;
            --获取大类
            if v_strLevelid = '2' then
              --如果有记录则更新
              update bdef_article_group
                 set GROUP_NAME   = bm.GROUP_NAME,
                     L_GROUP_NAME = bm.GROUP_NAME,
                     UPDT_NAME    = 'admin_interface',
                     UPDT_DATE    = sysdate
               where owner_no = v_strOwnerNo
                 and group_no = bm.group_no
                 and group_level = v_strLevelid
                 and group_no = bm.group_no;
              if (sql%rowcount = 0) then
                insert into bdef_article_group
                  (owner_no,
                   group_no,
                   group_name,
                   L_group_no,
                   L_group_name,
                   group_level,
                   batch_id,
                   create_flag,
                   turn_over_rule,
                   rgst_name,
                   rgst_date)
                values
                  (v_strOwnerNo,
                   bm.group_no,
                   bm.group_name,
                   bm.group_no,
                   bm.group_name,
                   v_strLevelid,
                   'N',
                   '1',
                   'FIFO',
                   'admin_interface',
                   sysdate);
              end if;
            end if;
            --获取中类
            if v_strLevelid = '1' then
              update bdef_article_group
                 set GROUP_NAME = bm.GROUP_NAME,
                     UPDT_NAME  = 'admin_interface',
                     UPDT_DATE  = sysdate
               where group_no = bm.group_no
                 and owner_no = v_strOwnerNo
                 and group_level = v_strLevelid;
              if (sql%rowcount = 0) then
                select bag.l_Group_Name
                  into v_strLGroupName
                  from bdef_article_group bag
                 where bag.owner_no = v_strOwnerNo
                   and bag.group_no = bm.headgroup_no;
                insert into bdef_article_group
                  (owner_no,
                   group_no,
                   group_name,
                   m_group_no,
                   m_group_name,
                   l_group_no,
                   l_group_name,
                   group_level,
                   batch_id,
                   create_flag,
                   turn_over_rule,
                   rgst_name,
                   rgst_date)
                values
                  (v_strOwnerNo,
                   bm.group_no,
                   bm.group_name,
                   bm.group_no,
                   bm.group_name,
                   bm.headgroup_no,
                   v_strLGroupName,
                   v_strLevelid,
                   'N',
                   '1',
                   'FIFO',
                   'admin_interface',
                   sysdate);
              end if;
            end if;
            --获取小类
            if v_strLevelid = '0' then
              update bdef_article_group
                 set GROUP_NAME = bm.GROUP_NAME,
                     UPDT_NAME  = 'admin_interface',
                     UPDT_DATE  = sysdate
               where owner_no = v_strOwnerNo
                 and group_no = bm.group_no
                 and group_level = v_strLevelid;
              if (sql%rowcount = 0) then
                select bag.m_Group_Name, bag.l_group_no, bag.l_Group_Name
                  into v_strMGroupName, v_strLGroupNo, v_strLGroupName
                  from bdef_article_group bag
                 where bag.owner_no = v_strOwnerNo
                   and bag.group_no = bm.headgroup_no;

                insert into bdef_article_group
                  (owner_no,
                   group_no,
                   group_name,
                   m_group_no,
                   m_group_name,
                   l_group_no,
                   l_group_name,
                   group_level,
                   batch_id,
                   create_flag,
                   turn_over_rule,
                   rgst_name,
                   rgst_date)
                values
                  (v_strOwnerNo,
                   bm.group_no,
                   bm.group_name,
                   bm.group_no,
                   v_strMGroupName,
                   v_strLGroupNo,
                   v_strLGroupName,
                   v_strLevelid,
                   'N',
                   '1',
                   'FIFO',
                   'admin_interface',
                   sysdate);
              end if;
            end if;
          end;
        end loop;

        --转历史，删除已经处理的数据
        insert into WMS_ARTICLEGROUPBAK@zdmwms_jk
          select *
            from WMS_ARTICLEGROUP@zdmwms_jk
           where owner_no = v_strOwnerNo
             and levelid in ('1', '2', '3')
             and sheetid = a.sheetid
             and enterprise_no = a.enterprise_no;
        delete from WMS_ARTICLEGROUP@zdmwms_jk
         where owner_no = v_strOwnerNo
           and levelid in ('1', '2', '3')
           and sheetid = a.sheetid
           and enterprise_no = a.enterprise_no;

        commit;
      end if;
    end loop;
  exception
    when others then
      rollback;
      OUTMSG := 'O| ' || SQLERRM ||
                substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_BDEF_ARTICLE_GROUP_DOWN;
  /*****************************************************************************************
   功能：接口，接收商品主档
  Modify By hcx AT 2016-02-29
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure P_BDEF_DEFARTICLE_DOWN is
    OUTMSG       varchar2(300);
    newarticleNO bdef_defarticle.article_no%type;
    v_strOwnerNo bdef_defowner.owner_no%type; --货主;
    v_nCount     integer;
  begin
    for a in (select distinct enterprise_no, owner_no, sheetid
                from wms_article@zdmwms_jk
               order by sheetid) loop
      --取wms货主
      P_OWNERNO_GET(a.enterprise_no,
                              a.owner_no,
                              v_strOwnerNo,
                              OUTMSG);
      if v_strOwnerNo is not null then
        --锁定数据
        update wms_article@zdmwms_jk m
           set m.owner_no = v_strOwnerNo, m.group_no = '999999' --暂是所有的商品类别都刷成999999
         where owner_no = a.owner_no
           and sheetid = a.sheetid
           and enterprise_no = a.enterprise_no;
        /*and exists (select 1
        from bdef_article_group bag
         where m.group_no = bag.group_no
          and bag.group_level = 0
          and bag.owner_no = v_strOwnerNo)
           */
        v_nCount := 0;
        for bm in (select m.*
                     from WMS_ARTICLE@zdmwms_jk m
                    where m.owner_no = v_strOwnerNo
                      and m.sheetid = a.sheetid
                      and m.enterprise_no = a.enterprise_no
                    order by m.owner_article_no, m.packing_qty) loop
          v_nCount     := 1;
          newarticleNO := bm.owner_article_no;
          update Bdef_DEFARTICLE b
             set b.article_name              = bm.article_name,
                 b.article_ename             = bm.ename,
                 b.article_oname             = bm.article_name,
                 b.article_alias             = bm.article_name,
                 b.group_no                  = bm.group_no,
                 b.article_identifier        = bm.article_identifier,
                 b.expiry_days               = nvl(bm.expiry_days, -1),
                 b.abc                       = nvl(bm.abcid, 'C'),
                 b.spec                      = bm.spec,
                 b.sell_price                = bm.price,
                 b.unit                      = bm.unit,
                 b.barcode                   = bm.barcode,
                 b.updt_name                 = 'admin_interface',
                 b.updt_date                 = sysdate,
                 b.supplier_no               = bm.supplier_no,
                 b.status                    = nvl(bm.status,'0'),
                 b.qmin_operate_packing      = bm.qmin_operate_packing,
                 b.qmin_operate_packing_unit = bm.qmin_operate_unit
           where b.OWNER_NO = v_strOwnerNo
             and b.OWNER_ARTICLE_NO = to_char(bm.owner_article_no);
          if (sql%rowcount = 0) then
            --记录不存在则新增商品主档
            --newarticleNO := ean13(bm.owner_no, bm.owner_article_no);
            insert into bdef_defarticle
              (owner_no,
               qmin_operate_packing,
               qmin_operate_packing_unit,
               owner_article_no,
               article_no,
               article_name,
               article_ename,
               article_oname,
               article_alias,
               group_no,
               article_identifier,
               unit,
               expiry_days,
               abc,
               spec,
               sell_price,
               status,
               create_flag,
               turn_over_rule,
               rgst_name,
               rgst_date,
               supplier_no,
               barcode,
               operate_type,
               print_flag,
               lot_type --,
               --Unit_Volumn,
               --unit_weight,
               --cumulative_volumn
               )
            values
              (bm.owner_no,
               bm.qmin_operate_packing,
               bm.qmin_operate_unit,
               bm.owner_article_no,
               newArticleNo,
               bm.article_name,
               bm.ename,
               bm.article_name,
               bm.article_name,
               bm.group_no,
               bm.article_identifier, --ERP的货号下传到助记码字段
               bm.packing_unit,
               nvl(bm.expiry_days, -1),
               nvl(bm.abcid, 'C'),
               bm.spec,
               bm.price,
               nvl(bm.status, '0'),
               '1',
               'FIFO',
               'admin_interface',
               sysdate,
               nvl(bm.supplier_no, 'N'),
               bm.Barcode,
               'B',
               '1',
               '2' --,
               --1,
               --1,
               --1
               );
          end if;

          if bm.packing_qty > 0 then
            update bdef_article_packing b
               set b.packing_unit = bm.packing_unit,
                   b.spec         = bm.packing_spec,
                   --b.a_length       = bm.length,
                   --b.a_width        = bm.width,
                   --b.a_height       = bm.height,
                   --b.packing_weight = bm.weight,
                   b.updt_name = 'admin_interface',
                   b.updt_date = sysdate
             where b.article_no = newarticleNO
               and b.packing_qty = bm.packing_qty
               and b.enterprise_no = bm.enterprise_no;
            if (sql%rowcount = 0) then
              --写入包装数据
              insert into Bdef_ARTICLE_PACKING
                (ARTICLE_NO,
                 PACKING_QTY,
                 PACKING_UNIT,
                 SPEC,
                 --A_LENGTH,
                 --A_WIDTH,
                 --A_HEIGHT,
                 --PACKING_WEIGHT,
                 SORTER_FLAG,
                 --PAL_BASE_QBOX,
                 --PAL_HEIGHT_QBOX,
                 --QPALETTE,
                 CREATE_FLAG,
                 RGST_NAME,
                 RGST_DATE)
              values
                (newarticleNO,
                 bm.packing_qty,
                 bm.packing_unit,
                 bm.packing_spec,
                 --bm.length,
                 --bm.width,
                 --bm.height,
                 --bm.weigth,
                 1,
                 --1,
                 --1,
                 --1,
                 '1',
                 'admin_interface',
                 sysdate);
            end if;
          end if;

        end loop;
        if v_nCount = 1 then
          --转历史，删除已经处理的数据
          insert into WMS_ARTICLEBAK@zdmwms_jk
            select *
              from wms_article@zdmwms_jk
             where owner_no = v_strOwnerNo
               and sheetid = a.sheetid
               and enterprise_no = a.enterprise_no;
          delete from wms_article@zdmwms_jk
           where owner_no = v_strOwnerNo
             and sheetid = a.sheetid
             and enterprise_no = a.enterprise_no;
          commit;
        else
          rollback;
        end if;
      end if;
    end loop;
  exception
    when others then
      rollback;
      OUTMSG := 'O| ' || SQLERRM ||
                substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_BDEF_DEFARTICLE_DOWN;

  /*****************************************************************************************
   功能：接口，接收商品条码
  Modify By hcx AT 2016-02-29
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure P_BDEF_ARTICLE_BARCODE_DOWN is
    OUTMSG           varchar2(300);
    hasvalue2        number;
    --v_strPrimaryFlag varchar2(1); --助条码标识
    v_strBarcode     bdef_defarticle.barcode%type; --条码
    v_strOwnerNo     bdef_defowner.owner_no%type; --货主
    v_nCount         integer;
  begin
    for a in (select distinct enterprise_no, owner_no, sheetid
                from WMS_BARCODE@zdmwms_jk) loop
      --取wms货主
      P_OWNERNO_GET(a.enterprise_no,
                              a.owner_no,
                              v_strOwnerNo,
                              OUTMSG);
      if v_strOwnerNo is not null then
        --锁定数据
        update WMS_BARCODE@zdmwms_jk b
           set b.owner_no = v_strOwnerNo
         where b.owner_no = a.owner_no
           and b.sheetid = a.sheetid
           and b.enterprise_no = a.enterprise_no;
        /*and not exists
        (select 1
                 from bdef_defarticle bd
                where bd.owner_article_no = a.owner_article_no
                  and bd.barcode = a.barcode)*/
        v_nCount := 0;
        for bm in (select c.*, b.article_no
                     from WMS_BARCODE@zdmwms_jk c, bdef_defarticle b
                    where c.owner_article_no = b.owner_article_no
                      and c.enterprise_no = b.enterprise_no
                      and c.owner_no = b.owner_no
                      and c.owner_no = v_strOwnerNo
                      and c.sheetid = a.sheetid
                    order by c.sheetid) loop
          begin
            v_nCount := 1;
            update bdef_article_packing a
               set a.packing_unit = bm.packing_unit,
                   a.spec         = bm.spec,
                   --a.a_length       = bm.length,
                   --a.a_width        = bm.width,
                   --a.a_height       = bm.height,
                   --a.packing_weight = bm.weight,
                   a.updt_name = 'admin_interface',
                   a.updt_date = sysdate
             where a.article_no = bm.article_no
               and a.packing_qty = bm.packing_qty
               and a.enterprise_no = bm.enterprise_no;
            if (sql%rowcount = 0) then
              --如果没记录则新增
              insert into BDEF_ARTICLE_PACKING
                (ARTICLE_NO,
                 PACKING_QTY,
                 PACKING_UNIT,
                 SPEC,
                 --A_LENGTH,
                 --A_WIDTH,
                 --A_HEIGHT,
                 --PACKING_WEIGHT,
                 SORTER_FLAG,
                 --PAL_BASE_QBOX,
                 --PAL_HEIGHT_QBOX,
                 --QPALETTE,
                 CREATE_FLAG,
                 RGST_NAME,
                 RGST_DATE)
              values
                (bm.article_no,
                 bm.packing_qty,
                 bm.packing_unit,
                 bm.spec,
                 --bm.length,
                 --bm.width,
                 --bm.height,
                 --bm.weight,
                 1,
                 --1,
                 --1,
                 --1,
                 '1',
                 'admin_interface',
                 sysdate);
            end if;
            --写入条码数据=
            select count(*)
              into hasvalue2
              from bdef_article_barcode bab
             where bab.article_no = bm.article_no
               and bab.barcode = bm.barcode;
            if hasvalue2 = 0 then
              select bd.barcode
                into v_strBarcode
                from bdef_defarticle bd
               where bd.owner_article_no = bm.owner_article_no
                 and bd.enterprise_no = bm.enterprise_no
                 and bd.owner_no = v_strOwnerNo;
              --非主条码 写条码标
              if v_strBarcode <> bm.barcode then
                --v_strPrimaryFlag := '0';
                insert into bdef_article_barcode
                  (barcode,
                   owner_no,
                   article_no,
                   packing_qty,
                   create_flag,
                   rgst_name,
                   rgst_date)
                values
                  (bm.barcode,
                   v_strOwnerNo,
                   bm.article_no,
                   bm.packing_qty,
                   1,
                   'admin_interface',
                   sysdate);
              end if;
            end if;
          end;
        end loop;
        if v_nCount = 1 then
          --转历史，删除已经处理的数据
          insert into WMS_BARCODEBAK@zdmwms_jk
            select a.*
              from WMS_BARCODE@zdmwms_jk a
             where owner_no = v_strOwnerNo
               and sheetid = a.sheetid
               and enterprise_no = a.enterprise_no;
          delete from WMS_BARCODE@zdmwms_jk
           where owner_no = v_strOwnerNo
             and sheetid = a.sheetid
             and enterprise_no = a.enterprise_no;
          commit;
        else
          rollback;
        end if;
      end if;
    end loop;
  exception
    when others then
      rollback;
      OUTMSG := 'O| ' || SQLERRM ||
                substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_BDEF_ARTICLE_BARCODE_DOWN;

  /*****************************************************************************************
   功能：接口，接收进货手建单主档
  Modify By hcx AT 2016-02-29
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure P_IDATA_IMPORT_DOWN is
    OUTMSG           varchar2(300);
    v_strPoType      idata_import_m.po_type%type; --单据类型
    v_strImportNo    idata_import_m.import_no%type; --进货单号
    v_strWarehouseNo idata_import_m.warehouse_no%type; --仓别
    v_strOwnerNo     bdef_defowner.owner_no%type; --货主 --货主
    v_strClassType   idata_import_m.class_type%type; --是否直通单，0：存储，1：直通
    --v_strArticleNo   VARCHAR2(15); --商品编码
    --v_strSImportNo   Idata_Import_Mm.S_IMPORT_NO%type; --汇总进货单号
    n_count_allot number(10);
    v_orgNo       Idata_Import_M.Org_No%type; --机构号
    v_nCount      integer;
  begin
    for a in (select distinct '8888' as enterprise_no,
                              palletzone,
                              customid,
                              shop_no,
                              sheetid
                from WMS_PURCHASE@zdmwms_jk) loop
      --取wms仓别
      P_WAREHOUSENO_GET(a.enterprise_no,
                                  a.palletzone,
                                  v_strWarehouseNo,
                                  OUTMSG);
      if v_strWarehouseNo is null then
        goto nest;
      end if;
      --取wms机构
      P_ORG_GET(a.enterprise_no, a.shop_no, v_orgNo, OUTMSG);
      if v_strWarehouseNo is null then
        goto nest;
      end if;
      --取wms货主
      P_OWNERNO_GET(a.enterprise_no,
                              a.customid,
                              v_strOwnerNo,
                              OUTMSG);
      if v_strOwnerNo is null then
        goto nest;
      else
        --锁数据
        update WMS_PURCHASE@zdmwms_jk wp
           set wp.palletzone = v_strWarehouseNo, wp.customid = v_strOwnerNo
         WHERE wp.palletzone = a.palletzone
           and wp.customid = a.customid
           and wp.sheetid = a.sheetid
           and (exists (select '1'
                          from WMS_RATIONNOTE@zdmwms_jk wr
                         where wp.sheetid = wr.refsheetid
                           and wp.type = '1') or (wp.type = '0'));
        v_nCount := 0;
        for bm in (select wp.*
                   --,ROW_NUMBER() OVER(PARTITION BY wp.SHEETID ORDER BY wp.GOODSID) SHEET_ROWNUM
                     from WMS_PURCHASE@zdmwms_jk wp
                    where wp.palletzone = v_strWarehouseNo
                      and wp.customid = v_strOwnerNo
                      and wp.sheetid = a.sheetid) loop
          begin
            v_nCount := 1;
            if bm.type = '0' then
              v_strPoType    := CONST_DOCUMENTTYPE.IDATAIMPORTIS;
              v_strClassType := '0';
              n_count_allot  := 0;
            elsif bm.type = '1' then
              v_strPoType    := CONST_DOCUMENTTYPE.IDATAIMPORTID;
              v_strClassType := '1';
              n_count_allot  := 1; --表示是直接型，要写配量表。
            end if;
            --查找进货单号
            select nvl(max(iim.import_no), 'N')
              into v_strImportNo
              from idata_import_m iim
             where upper(iim.po_no) = upper(bm.sheetid)
               and iim.warehouse_no = v_strWarehouseNo
               and iim.owner_no = v_strOwnerNo;
            --判断进货单号是否存在
            if v_strImportNo = 'N' then
              --获取WMS进货单号
              PKLG_WMS_BASE.p_getsheetno(a.enterprise_no,
                                         v_strWarehouseNo,
                                         v_strPoType,
                                         v_strImportNo,
                                         OUTMSG);
              --写进货单头档
              insert into idata_import_m
                (warehouse_no,
                 owner_no,
                 import_type,
                 import_no,
                 po_type,
                 po_no,
                 supplier_no,
                 order_date,
                 request_date,
                 status,
                 create_flag,
                 import_remark,
                 end_date,
                 class_type,
                 order_end_date,
                 rgst_name,
                 rgst_date,
                 org_no)
              values
                (v_strWarehouseNo,
                 v_strOwnerNo,
                 v_strPoType,
                 v_strImportNo,
                 v_strPoType,
                 bm.sheetid,
                 bm.venderid,
                 case when bm.sdate is null then sysdate else bm.sdate end,
                 case when bm.purdate is null then sysdate else bm.purdate end,
                 '10',
                 '1',
                 case when bm.notes is null then 'N' else bm.notes end,
                 case when bm.validdate is null then 7 else
                 (select TRUNC(BM.validdate) - TRUNC(SYSDATE) from DUAL) end,
                 '1',
                 case when bm.validdate is null then
                 (select SYSDATE + 3 from DUAL a) else bm.validdate end,
                 'admin_interface',
                 sysdate,
                 v_orgNo);
            end if;

            --写进货单明细
            insert into idata_import_d
              (warehouse_no,
               owner_no,
               import_no,
               article_no,
               packing_qty,
               po_qty,
               import_qty,
               po_id,
               status)
            values
              (v_strWarehouseNo,
               v_strOwnerNo,
               v_strImportNo,
               bm.goodsid,
               bm.pkcount,
               bm.qty,
               0,
               bm.serialid,
               '10');

            insert into Idata_import_Lot
              (Warehouse_No,
               Owner_No,
               Import_No,
               Po_No,
               Article_No,
               Lot_No,
               Qty,
               Remark)
            values
              (v_strWarehouseNo,
               v_strOwnerNo,
               v_strImportNo,
               bm.sheetid,
               bm.goodsid,
               '0',
               bm.qty,
               bm.notes);

            if v_strPoType = CONST_DOCUMENTTYPE.IDATAIMPORTID and
               n_count_allot > 0 then
              --增加是不是写配量数据的判断
              --锁数据
              update wMS_RATIONNOTE@zdmwms_jk h
                 set h.customid = bm.customid
               where h.customid = a.customid
                    --and bm.type='1'
                 and h.palletzone = bm.palletzone
                 and h.refsheetid = bm.sheetid;
              --写进货直通配量
              insert into idata_import_allot
                (warehouse_no,
                 owner_no,
                 import_no,
                 article_no,
                 packing_qty,
                 po_qty,
                 allot_qty,
                 status,
                 sub_cust_no,
                 cust_no,
                 rgst_name,
                 rgst_date,
                 po_no)
                select v_strWarehouseNo,
                       v_strOwnerNo,
                       v_strImportNo,
                       h.goodsid,
                       h.pkcount,
                       h.planqty,
                       0,
                       '10',
                       h.shopid,
                       h.shopid,
                       'admin_interface',
                       sysdate,
                       h.sheetid
                  from wMS_RATIONNOTE@zdmwms_jk h
                 where h.customid = bm.customid
                   and h.palletzone = bm.palletzone
                   and h.refsheetid = bm.sheetid
                   and h.goodsid = bm.goodsid;
              --and h.pkcount=bm.pkcount
              --and bm.type='1';

            end if;
          end;
        end loop;
        if v_nCount = 1 then
          --转历史，删除已经处理的数据
          insert into WMS_PURCHASEBAK@zdmwms_jk
            select *
              from WMS_PURCHASE@zdmwms_jk h
             where h.customid = v_strOwnerNo
               and h.palletzone = v_strWarehouseNo
               and h.sheetid = a.sheetid;
          delete from WMS_PURCHASE@zdmwms_jk h
           where h.customid = v_strOwnerNo
             and h.palletzone = v_strWarehouseNo
             and h.sheetid = a.sheetid;
          --转历史，删除已经处理的数据
          insert into WMS_RATIONNOTEBAK@zdmwms_jk
            select *
              from wMS_RATIONNOTE@zdmwms_jk h
             where h.customid = v_strOwnerNo
               and h.palletzone = v_strWarehouseNo
               and h.refsheetid = a.sheetid;
          delete from wMS_RATIONNOTE@zdmwms_jk h
           where h.customid = v_strOwnerNo
             and h.palletzone = v_strWarehouseNo
             and h.refsheetid = a.sheetid;
          commit;
        else
          rollback;
        end if;
      end if;
      <<nest>>
      null;
    end loop;
  exception
    when others then
      rollback;
      OUTMSG := 'O| ' || SQLERRM ||
                substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_IDATA_IMPORT_DOWN;
  /*****************************************************************************************
   功能：接口，接收出货手建单
  Modify By hcx AT 2016-02-29
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure P_ODATA_EXP_DOWN is
    OUTMSG           varchar2(300);
    v_strPushResult  wms_rationnote.pushresult%type;
    v_strWarehouseNo bdef_defloc.warehouse_no%type; --仓别
    v_strOwnerNo     bdef_defowner.owner_no%type; --货主
    v_strExpNo       odata_exp_m.exp_no%type; --出货单号
    v_strPoNo        odata_package_m.po_no%type;--包裹号
    v_expType        odata_exp_m.exp_type%type; --单据类型
    ncount           number(2); --用来判断是不是有插入的数据，如果没有，就不转历。
    v_nCount         number(2);
    v_nArticleCount  number(2);
    v_unknownGoodsid varchar2(200);
    v_orgNo          odata_exp_m.Org_No%type; --机构号
    v_blSucc   boolean; --成功标识
    
  begin
    for a in (select distinct '8888' as enterprise_no,
                              palletzone,
                              customid,
                              shop_no,
                              sheetid
                from WMS_RATIONNOTE@zdmwms_jk) loop
       
      v_blSucc := false;
      --取wms仓别
      P_WAREHOUSENO_GET(a.enterprise_no,
                                  a.palletzone,
                                  v_strWarehouseNo,
                                  OUTMSG);
      if v_strWarehouseNo is null then
        v_strPushResult := '该仓库号不存在！';
        v_blSucc := false;
        goto ending;
        exit;
      end if;
      --取wms机构
      P_ORG_GET(a.enterprise_no, a.shop_no, v_orgNo, OUTMSG);
      if v_orgNo is null then
        v_strPushResult := '该机构代码未开通接口传输权限!';
        v_blSucc := false;
        goto ending;
        exit;
      end if;
      --取wms货主
      P_OWNERNO_GET(a.enterprise_no,
                              a.customid,
                              v_strOwnerNo,
                              OUTMSG);
      if v_strOwnerNo is null then
        v_strPushResult := '该货主代码未开通接口传输权限!';
        v_blSucc := false;
        goto ending;
        exit;
      end if;
      --锁数据,直通单不用写出货表数据
      ncount := 0;
      update WMS_RATIONNOTE@zdmwms_jk b
         set b.palletzone = v_strWarehouseNo, b.customid = v_strOwnerNo,b.shop_no = v_orgNo
       WHERE b.palletzone = a.palletzone
         and b.customid = a.customid
         and b.sheetid = a.sheetid
         and b.shop_no = a.shop_no;
         --and nvl(b.refsheetid, 'N') in ('N');
      for bm in (select distinct sheetid,
                                 customid,
                                 palletzone,
                                 shopid,
                                 type,
                                 shop_no,
                                 sdate，
                                 notes,
                                 rtype,
                                 refsheetid,
                                 leveltype,
                                 po_no,
                                 jh_type,
                                 shipper_no,
                                 shipper_deliver_no,
                                 order_source,
                                 rsv_varod3,
                                 send_address,
                                 send_name,
                                 send_company_name,
                                 send_postcode,
                                 send_mobile_phone,
                                 send_telephone,
                                 send_province,
                                 send_city,
                                 send_zone,
                                 send_country,
                                 cust_address,
                                 contactor_name,
                                 cust_phone,
                                 cust_mail,
                                 receive_province,
                                 receive_city,
                                 receive_zone,
                                 receive_country,
                                 zt_flag,
                                 order_batch,
                                 deliver_address
                   from WMS_RATIONNOTE@zdmwms_jk m
                  where m.palletzone = v_strWarehouseNo
                    and m.customid = v_strOwnerNo
                   and m.sheetid = a.sheetid
                    and m.shop_no = v_orgNo
                    and m.status='1') loop
        begin
          ncount    := 1;
          if bm.rtype = '0' then
             v_expType := 'OE';
          elsif bm.rtype = '1' then
             v_expType := 'ID';
          elsif bm.rtype = '2' then
             v_expType := 'B2C';
          elsif bm.rtype = '3' then
             v_expType := 'JH';
          elsif bm.rtype = '4' then
             v_expType := 'OHQ';
          else
             v_strPushResult := '未知出货类型';
             v_expType := 'N';
          end if;
          if v_expType = 'JH' then--集货类型
            --查找包裹单号
              select count(*) into v_nCount
                from odata_package_m oem
               where oem.po_no = bm.po_no
                 and oem.warehouse_no = v_strWarehouseNo
                 and oem.owner_no = v_strOwnerNo;
             --判断包裹单号是否存在
            if v_nCount <= 0 then
              --插入包裹单头
              insert into odata_package_m
                     (enterprise_no,
                      warehouse_no,
                      owner_no,
                      po_no,
                      po_type,
                      exp_date,
                      create_flag,
                      status,
                      remark,
                      rgst_name,
                      rgst_date)
                values
                     ('8888',
                      v_strWarehouseNo,
                      v_strOwnerNo,
                      bm.po_no,
                      bm.jh_type,
                      bm.sdate,
                      '1',
                      '10',
                      bm.notes,
                      'admin_interface',
                      sysdate);
              else
                v_strPushResult := '集货包裹单头档已存在';        
              end if ;
              --插入包裹明细
              insert into odata_package_d (
                      enterprise_no,
                      warehouse_no,
                      owner_no,
                      owner_cust_no,
                      cust_no,
                      sub_cust_no,
                      po_no,
                      sourceexp_no,
                      exp_date,
                      status,
                      rgst_name,
                      rgst_date,
                      cust_address,
                      contactor_name,
                      cust_phone,
                      cust_mail,
                      shipper_no,
                      shipper_deliver_no,
                      org_no,
                      send_address,
                      send_name,
                      send_company_name,
                      send_postcode,
                      send_mobile_phone,
                      send_telephone,
                      send_province,
                      send_city,
                      send_zone,
                      send_country,
                      receive_province,
                      receive_city,
                      receive_zone,
                      receive_country,
                      print_flag,
                      envoice_print_status,
                      waybill_print_status,
                      packlist_print_status)
               select DISTINCT '8888',
                      v_strWarehouseNo,
                      v_strOwnerNo,
                      bm.shopid,
                      bm.shopid,
                      bm.shopid,
                      bm.po_no,
                      bm.sheetid,
                      bm.sdate,
                      '10',
                      'admin_interface',
                      sysdate,
                      bm.cust_address,
                      bm.contactor_name,
                      bm.cust_phone,
                      bm.cust_mail,
                      bm.shipper_no,
                      bm.shipper_deliver_no,
                      v_orgNo,
                      bm.send_address,
                      bm.send_name,
                      bm.send_company_name,
                      bm.send_postcode,
                      bm.send_mobile_phone,
                      bm.send_telephone,
                      bm.send_province,
                      bm.send_city,
                      bm.send_zone,
                      bm.send_country,
                      bm.receive_province,
                      bm.receive_city,
                      bm.receive_zone,
                      bm.receive_country,
                      '0','0','0','0'
                 from wMS_RATIONNOTE@zdmwms_jk wr
                 where wr.sheetid = bm.sheetid
                   and wr.po_no = bm.po_no
                   and wr.shipper_deliver_no = bm.shipper_deliver_no
                   and wr.status='1'
                   and not exists (select 'X' from odata_package_d opd 
                   where opd.warehouse_no = v_strWarehouseNo
                   and opd.owner_no = v_strOwnerNo
                   and opd.shipper_deliver_no = bm.shipper_deliver_no
                   and opd.po_no = bm.po_no 
                   and opd.sourceexp_no = bm.sheetid);
          v_blSucc := true;
          elsif v_expType not in('ID') then
           -- v_expType := CONST_DOCUMENTTYPE.ODATAOE;
            --查找出货单号
            select nvl(max(oem.exp_no), null)
              into v_strExpNo
              from odata_exp_m oem
             where oem.sourceexp_no = bm.sheetid
               and oem.warehouse_no = v_strWarehouseNo
               and oem.owner_no = v_strOwnerNo;
            --判断出货单号是否存在
            if v_strExpNo is null then
              --获取WMS出货单号
              PKLG_WMS_BASE.p_getsheetno('8888',
                                         v_strWarehouseNo,
                                         CONST_DOCUMENTTYPE.ODATAOE,
                                         v_strExpNo,
                                         OUTMSG);
              --写出货单头档
              insert into odata_exp_m
                (warehouse_no,
                 owner_no,
                 exp_type,
                 exp_no,
                 owner_cust_no,
                 cust_no,
                 sub_cust_no,
                 sourceexp_type,
                 sourceexp_no,
                 fast_flag,
                 status,
                 cust_address,
                 contactor_name,
                 cust_phone,
                 cust_mail,
                 create_flag,
                 exp_date,
                 exp_remark,
                 rgst_name,
                 rgst_date,
                 shipper_no,
                 shipper_deliver_no,
                 order_source,
                 org_no,
                 rsv_varod3,
                 rsv_varod4,
                 take_type,
                 send_address,
                 send_name,
                 send_company_name,
                 send_postcode,
                 send_mobile_phone,
                 send_telephone,
                 send_province,
                 send_city,
                 send_zone,
                 send_country,
                 receive_province,
                 receive_city,
                 receive_zone,
                 receive_country,
                 skucount,
                 deliver_address)
              values
                (v_strWarehouseNo,
                 v_strOwnerNo,
                 v_expType,
                 v_strExpNo,
                 v_strOwnerNo,
                 v_strOwnerNo,
                 v_strOwnerNo,
                 v_expType,
                 bm.sheetid,
                 bm.type,
                 '-1', --modify by wyy 170907
                 bm.cust_address,
                 bm.contactor_name,
                 bm.cust_phone,
                 bm.cust_mail,
                 '1',
                 bm.sdate,
                 bm.notes,
                 'admin_interface',
                 sysdate,
                 bm.shipper_no,
                 bm.shipper_deliver_no,
                 bm.order_source,
                 v_orgNo,
                 bm.rsv_varod3,
                 bm.order_batch,
                 bm.zt_flag,
                 bm.send_address,
                 bm.send_name,
                 bm.send_company_name,
                 bm.send_postcode,
                 bm.send_mobile_phone,
                 bm.send_telephone,
                 bm.send_province,
                 bm.send_city,
                 bm.send_zone,
                 bm.send_country,
                 bm.receive_province,
                 bm.receive_city,
                 bm.receive_zone,
                 bm.receive_country,
                 0,
                 bm.deliver_address);
                 
                select  count(1) into v_nArticleCount from wMS_RATIONNOTE@zdmwms_jk wr
                where not exists(select 'x' from bdef_defarticle bda 
                where  wr.goodsid = bda.owner_article_no)
                   and wr.sheetid = bm.sheetid
                   and wr.customid = v_strOwnerNo
                   and wr.palletzone = v_strWarehouseNo
                   and wr.shop_no = v_orgNo;
                   
               if v_nArticleCount>0 then
                  select  wm_concat(wr.goodsid) into v_unknownGoodsid  from wMS_RATIONNOTE@zdmwms_jk wr
                  where not exists(select 'x' from bdef_defarticle bda 
                   where  wr.goodsid = bda.owner_article_no)
                   and wr.sheetid = bm.sheetid
                   and wr.customid = v_strOwnerNo
                   and wr.palletzone = v_strWarehouseNo
                   and wr.shop_no = v_orgNo
                   and rownum <5;
                 v_strPushResult := '内件商品ID为'||v_unknownGoodsid||'的商品基础资料缺失！';
                 v_blSucc := false;
                 exit;
               end if;
               
              --写出货单明细
              insert into odata_exp_d
                (warehouse_no,
                 owner_no,
                 exp_no,
                 ROW_ID,
                 article_no,
                 packing_qty,
                 article_qty,
                 unit_cost,
                 owner_article_no,
                 status,
                 rgst_date,
                 exp_date,
                 item_type)
                select v_strWarehouseNo,
                       v_strOwnerNo,
                       v_strExpNo,
                       ROW_NUMBER() OVER(PARTITION BY wr.SHEETID ORDER BY wr.GOODSID) SHEET_ROWNUM,
                       bda.article_no,
                       wr.pkcount,
                       wr.planqty,
                       wr.cost,
                       bda.owner_article_no,
                       '10',
                       sysdate,
                       sysdate,
                       wr.item_type
                  from wMS_RATIONNOTE@zdmwms_jk wr, bdef_defarticle bda
                 where wr.sheetid = bm.sheetid
                   and wr.customid = v_strOwnerNo
                   and wr.goodsid = bda.owner_article_no
                   and wr.status='1';
                --回写出货单头档品项数
                PKLG_ODISPATCH.P_LOCATECHECK_UPDATESKU('8888',
                                                       v_strWarehouseNo,
                                                       v_strOwnerNo,
                                                       v_strExpNo,
                                                       OUTMSG);
                
                 --写出货单状态跟踪表
                PKOBJ_ODISPATCH.P_Insert_Odata_Exp_Trace('8888',
                           v_strWarehouseNo, v_strExpNo, '00','admin_interface',OUTMSG);
                
                v_blSucc := true;
            else
              v_strPushResult := '该B2C单据已存在！';
            end if;
          end if;
        end;
      end loop;
      --转历史，删除已经处理的数据
      <<ending>>
      if ncount = 1 and v_blSucc then
        insert into WMS_RATIONNOTEBAK@zdmwms_jk
          select *
            from WMS_RATIONNOTE@zdmwms_jk
           where palletzone = v_strWarehouseNo
             and customid = v_strOwnerNo
             and shop_no = v_orgNo
             and sheetid = a.sheetid;
        delete from WMS_RATIONNOTE@zdmwms_jk
         where palletzone = v_strWarehouseNo
           and customid = v_strOwnerNo
           and shop_no = v_orgNo
           and sheetid = a.sheetid;
        commit;
      else
        rollback;
         update wms_rationnote@zdmwms_jk c
         set c.pushresult = v_strPushResult
       WHERE c.palletzone = a.palletzone
         and c.customid = a.customid
         and c.sheetid = a.sheetid
         and c.shop_no = a.shop_no;
         commit;
      end if;
      null;
    end loop;
    
    --删除过期打印任务
    DELETE job_printtask_m WHERE TRUNC(rgst_date) < TRUNC(SYSDATE);
    COMMIT;
  exception
    when others then
    DBMS_OUTPUT.put_line('sqlcode : ' ||sqlcode); 
    DBMS_OUTPUT.put_line('sqlerrm : ' ||sqlerrm); 
      rollback;
      OUTMSG := 'O| ' || SQLERRM ||
                substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_ODATA_EXP_DOWN;
  
  /*****************************************************************************************
   功能：接口，接收退厂手建单
  Modify By hcx AT 2016-02-29
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure P_RODATA_RECEDE_DOWN is
    pragma autonomous_transaction;
    OUTMSG           varchar2(300);
    v_strWarehouseNo rodata_recede_m.warehouse_no%type; --仓别
    v_strOwnerNo     rodata_recede_m.owner_no%type; --货主
    v_strRecedeType  rodata_recede_m.recede_type%type; --单据类型
    v_strRecedeNo    rodata_recede_m.untread_no%type; --返配单号
    v_strClassType   rodata_recede_m.class_type%type; --是否直通单，0：存储，1：直通
    v_strPo_type     rodata_recede_m.po_type%type;
    v_strOrgNo       rodata_recede_m.org_no%type; --机构
    ncount           number(2); --用来判断是不是有插入的数据，如果没有，就不转历。
  begin
    for a in (select distinct '8888' as enterprise_no,
                              palletzone,
                              shop_no,
                              customid,
                              sheetid
                from WMS_RET@zdmwms_jk) loop
      --取wms仓别
      P_WAREHOUSENO_GET(a.enterprise_no,
                        a.palletzone,
                        v_strWarehouseNo,
                        OUTMSG);
      if v_strWarehouseNo is null then
        goto nest;
      end if;
      --取wms货主
      P_OWNERNO_GET(a.enterprise_no, a.customid, v_strOwnerNo, OUTMSG);
      if v_strOwnerNo is null then
        goto nest;
      end if;
      --取wms机构
      P_ORG_GET(a.enterprise_no, a.shop_no, v_strOrgNo, OUTMSG);
      if v_strOrgNo is null then
        goto nest;
      end if;
      --锁数据
      ncount := 0;
      update WMS_RET@zdmwms_jk
         set palletzone = v_strWarehouseNo, customid = v_strOwnerNo
       WHERE palletzone = a.palletzone
         and customid = a.customid
         and sheetid = a.sheetid;
      for bm in (select distinct b.sheetid,
                                 b.venderid,
                                 b.po_type,
                                 b.palletzone,
                                 b.sdate,
                                 b.shop_no
                   from WMS_RET@zdmwms_jk b
                  where b.palletzone = v_strWarehouseNo
                    and b.customid = v_strOwnerNo
                    and b.sheetid = a.sheetid) loop
        begin
          ncount         := 1;
          v_strClassType := '1';
          v_strPo_type   := 'RE';

          v_strRecedeType := CONST_DOCUMENTTYPE.RODATARE;
          --查找退货单号
          select nvl(max(rrm.recede_no), null)
            into v_strRecedeNo
            from rodata_recede_m rrm
           where rrm.po_no = bm.sheetid
             and rrm.warehouse_no = v_strWarehouseNo;
          --判断退货单号是否存在
          if v_strRecedeNo is null then
            --获取WMS退货单号
            PKLG_WMS_BASE.p_getsheetno('8888',
                                       v_strWarehouseNo,
                                       v_strRecedeType,
                                       v_strRecedeNo,
                                       OUTMSG);
            --写退货单头档
            insert into rodata_recede_m
              (warehouse_no,
               owner_no,
               recede_type,
               recede_no,
               po_type,
               po_no,
               supplier_no,
               class_type,
               recede_date,
               status,
               create_flag,
               request_date,
               rgst_name,
               rgst_date,
               org_no)
            values
              (v_strWarehouseNo,
               v_strOwnerNo,
               v_strPo_type,
               v_strRecedeNo,
               v_strPo_type,
               bm.sheetid,
               bm.venderid,
               v_strClassType,
               bm.sdate,
               '10',
               '1',
               bm.sdate,
               'admin_interface',
               sysdate,
               v_strOrgNo);
            --写退货单明细
            insert into rodata_recede_d
              (warehouse_no,
               owner_no,
               recede_no,
               owner_article_no,
               article_no,
               packing_qty,
               recede_qty,
               ref_recede_qty,
               po_id,
               status)
              select v_strWarehouseNo,
                     v_strOwnerNo,
                     v_strRecedeNo,
                     wr.goodsid,
                     bda.article_no,
                     wr.pkcount,
                     wr.realqty,
                     wr.realqty,
                     ROW_NUMBER() OVER(PARTITION BY wr.SHEETID ORDER BY wr.GOODSID) SHEET_ROWNUM,
                     '10'
                from WMS_RET@zdmwms_jk wr, bdef_defarticle bda
               where wr.sheetid = bm.sheetid
                 and wr.goodsid = bda.owner_article_no;
          end if;
        end;
      end loop;
      --转历史，删除已经处理的数据
      if ncount = 1 then
        insert into WMS_RETBAK@zdmwms_jk
          select *
            from WMS_RET@zdmwms_jk
           where palletzone = v_strWarehouseNo
             and customid = v_strOwnerNo;
        delete from WMS_RET@zdmwms_jk
         where palletzone = v_strWarehouseNo
           and customid = v_strOwnerNo;
        commit;
      else
        rollback;
      end if;
      <<nest>>
      null;
    end loop;
  exception
    when others then
      rollback;
      OUTMSG := 'O| ' || SQLERRM ||
                substr(dbms_utility.format_error_backtrace, 1, 256);
      /*P_write_log('P_RODATA_RECEDE_DOWN', OUTMSG);*/
  end P_RODATA_RECEDE_DOWN;
  /*****************************************************************************************
   功能：接口，接收返配手建单
  Modify By hcx AT 2016-02-29
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure P_RIDATA_UNTREAD_DOWN is
    OUTMSG            varchar2(300);
    v_strWarehouseNo  ridata_untread_m.warehouse_no%type; --仓别
    v_strOwnerNo      ridata_untread_m.owner_no%type; --货主
    v_strUntreadType  ridata_untread_m.UNTREAD_TYPE%type; --单据类型
    v_strOldUntreadNo ridata_untread_m.UNTREAD_NO%type; --返配单号
    v_strUntreadNo    ridata_untread_m.UNTREAD_NO%type; --返配单号
    v_strSUntreadNo   ridata_untread_sm.s_untread_no%type; --返配汇总单号
    v_strClassType    ridata_untread_m.class_type%type; --是否直通单
    v_strOrgNo        ridata_untread_m.org_no%type; --机构
    hasVm             number;
    newVm             varchar2(20); --新的返配汇总单号
    ncount            number(2); --用来判断是不是有插入的数据，如果没有，就不转历。

  begin
    for a in (select distinct '8888' as enterprise_no,
                              palletzone,
                              customid,
                              shop_no,
                              sheetid
                from WMS_RETRATION@zdmwms_jk) loop
      --取wms仓别
      P_WAREHOUSENO_GET(a.enterprise_no,
                        a.palletzone,
                        v_strWarehouseNo,
                        OUTMSG);
      if v_strWarehouseNo is null then
        goto nest;
      end if;
      --取wms机构
      P_ORG_GET(a.enterprise_no, a.shop_no, v_strOrgNo, OUTMSG);
      if v_strOrgNo is null then
        goto nest;
      end if;
      --取wms货主
      P_OWNERNO_GET(a.enterprise_no, a.customid, v_strOwnerNo, OUTMSG);
      if v_strOwnerNo is null then
        goto nest;
      else
        --锁数据
        ncount := 0;
        update WMS_RETRATION@zdmwms_jk
           set palletzone = v_strWarehouseNo, customid = v_strOwnerNo
         where palletzone = a.palletzone
           and customid = a.customid
           and sheetid = a.sheetid
           and planqty > 0;

        for bm in (select b.sheetid,
                          b.rtype,
                          b.palletzone,
                          b.customid,
                          b.shopid,
                          max(b.sdate) sdate,
                          b.venderid,
                          b.notes,
                          b.shop_no
                     from WMS_RETRATION@zdmwms_jk b
                    where b.palletzone = v_strWarehouseNo
                      and b.customid = v_strOwnerNo
                      and b.sheetid = a.sheetid
                    group by b.sheetid,
                             b.rtype,
                             b.palletzone,
                             b.customid,
                             b.shopid,
                             b.venderid,
                             b.notes,
                             b.shop_no) loop
          begin
            ncount           := 1;
            v_strUntreadType := CONST_DOCUMENTTYPE.RIDATAUM;
            v_strClassType   := '0';
            select count(0)
              into hasVm
              from ridata_UNTREAD_MM mm
             where mm.s_po_no = bm.sheetid
                or mm.s_untread_no = bm.sheetid;
            if (hasvm = 0) then
              --取返配汇总单号
              /*PKLG_WMS_BASE.p_getsheetno('8888',
              v_strWarehouseNo,
              CONST_DOCUMENTTYPE.RIDATAVM,
              v_strSUntreadNo,
              OUTMSG); --获取单号*/
              v_strSUntreadNo := bm.sheetid;
            else
              select S_UNTREAD_NO
                into newVm
                from ridata_UNTREAD_MM mm
               where mm.s_po_no = bm.sheetid
                  or mm.s_untread_no = bm.sheetid;
              v_strSUntreadNo := newVm;
            end if;

            begin
              select rum.untread_no
                into v_strOldUntreadNo
                from ridata_untread_m rum
               where rum.po_no = bm.sheetid
                 and rum.warehouse_no = v_strWarehouseNo;
            exception
              when no_data_found then
                v_strOldUntreadNo := 'N';
                --取返配单号
                PKLG_WMS_BASE.p_getsheetno('8888',
                                           v_strWarehouseNo,
                                           v_strUntreadType,
                                           v_strUntreadNo,
                                           OUTMSG); --获取WMS进货单号
            end;

            if v_strOldUntreadNo <> 'N' then
              goto nest;
            end if;
            --写返配单头档
            insert into ridata_untread_m
              (warehouse_no,
               owner_no,
               untread_type,
               untread_no,
               po_type,
               po_no,
               class_type,
               cust_no,
               untread_date,
               request_date,
               status,
               create_flag,
               untread_remark,
               untread_flag,
               rgst_name,
               rgst_date,
               org_no,
               quality)
            values
              (v_strWarehouseNo,
               v_strOwnerNo,
               v_strUntreadType,
               v_strUntreadNo,
               'UM',
               bm.sheetid,
               v_strClassType,
               bm.shopid,
               bm.sdate,
               bm.sdate,
               '10',
               '1',
               bm.notes,
               '0',
               'admin_interface',
               sysdate,
               v_strOrgNo,
               'A');
            if (hasvm = 0) then
              --返配汇总单头档
              insert into ridata_untread_mm
                (warehouse_no,
                 owner_no,
                 s_untread_no,
                 s_po_no,
                 cust_no,
                 class_type,
                 status,
                 rgst_name,
                 rgst_date,
                 quality,
                 serial_no)
              values
                (v_strWarehouseNo,
                 v_strOwnerNo,
                 v_strSUntreadNo,
                 bm.sheetid,
                 bm.shopid,
                 v_strClassType,
                 '10',
                 'admin_interface',
                 sysdate,
                 'A',
                 SEQ_RIDATA_UNTREAD_MM.Nextval);
            end if;
            --返配汇总单关系
            insert into ridata_untread_sm
              (warehouse_no,
               owner_no,
               s_untread_no,
               untread_type,
               untread_no,
               po_type,
               po_no,
               status,
               rgst_name,
               rgst_date)
            values
              (v_strWarehouseNo,
               v_strOwnerNo,
               case when hasvm = 0 then v_strSUntreadNo else newVm end,
               v_strUntreadType,
               v_strUntreadNo,
               'UM',
               bm.sheetid,
               '10',
               'admin_interface',
               sysdate);
            --返配汇总单明细
            insert into ridata_untread_d
              (warehouse_no,
               owner_no,
               untread_no,
               po_id,
               supplier_no,
               article_no,
               packing_qty,
               untread_qty,
               status,
               quality)
              select v_strWarehouseNo,
                     v_strOwnerNo,
                     v_strUntreadNo,
                     ROW_NUMBER() OVER(PARTITION BY wr.SHEETID ORDER BY wr.GOODSID) SHEET_ROWNUM,
                     nvl(bda.supplier_no, 'N'),
                     bda.article_no,
                     decode(nvl(wr.pkcount, 1), 0, 1, nvl(wr.pkcount, 1)),
                     wr.planqty,
                     '10',
                     'A'
                from WMS_RETRATION@zdmwms_jk wr, bdef_defarticle bda
               where wr.sheetid = bm.sheetid
                 and wr.goodsid = bda.owner_article_no
                 and wr.customid = '001';

          end;
        end loop;
        --转历史，删除已经处理的数据
        if ncount = 1 then
          insert into WMS_RETRATIONBAK@zdmwms_jk
            select *
              from WMS_RETRATION@zdmwms_jk
             where palletzone = v_strWarehouseNo
               and customid = v_strOwnerNo
               and sheetid = a.sheetid;
          delete from WMS_RETRATION@zdmwms_jk
           where palletzone = v_strWarehouseNo
             and customid = v_strOwnerNo
             and sheetid = a.sheetid;
          commit;
        else
          rollback;
        end if;
      end if;
      <<nest>>
      null;
    end loop;
  exception
    when others then
      rollback;
      OUTMSG := 'O| ' || SQLERRM ||
                substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_RIDATA_UNTREAD_DOWN;
  /*****************************************************************************************
   功能：接口，接收盘点计划单
  Modify By hcx AT 2016-02-29
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure P_FCDATA_PLAN_DOWN is
    OUTMSG           varchar2(300);
    v_strWarehouseNo fcdata_plan_m.warehouse_no%type; --仓别
    v_strOwnerNo     fcdata_plan_m.owner_no%type; --货主
    v_strPlanNo      fcdata_plan_m.plan_no%type; --盘点单号
    ncount           number(2); --用来判断是不是有插入的数据，如果没有，就不转历。
    v_strOrgNo       fcdata_plan_m.org_no%type; --机构
  begin
    for a in (select distinct '8888' as enterprise_no,
                              palletzone,
                              shop_no,
                              customid,
                              sheetid
                from WMS_PD@zdmwms_jk) loop
      --取wms仓别
      P_WAREHOUSENO_GET(a.enterprise_no,
                        a.palletzone,
                        v_strWarehouseNo,
                        OUTMSG);
      if v_strWarehouseNo is null then
        goto nest;
      end if;
      --取wms机构
      P_ORG_GET(a.enterprise_no, a.shop_no, v_strOrgNo, OUTMSG);
      if v_strOrgNo is null then
        goto nest;
      end if;
      --取wms货主
      P_OWNERNO_GET(a.enterprise_no, a.customid, v_strOwnerNo, OUTMSG);
      if v_strOwnerNo is null then
        goto nest;
      end if;
      ncount := 0;
      --锁数据
      update WMS_PD@zdmwms_jk
         set palletzone = v_strWarehouseNo, customid = v_strOwnerNo
       where palletzone = a.palletzone
         and customid = a.customid
         and sheetid = a.sheetid;

      for bm in (select m.sheetid,
                        m.customid,
                        m.palletzone,
                        m.pdtype,
                        max(m.sdate) sdate,
                        m.shop_no
                   from WMS_PD@zdmwms_jk m
                  where m.customid = v_strOwnerNo
                    and m.palletzone = v_strWarehouseNo
                    and m.sheetid = a.sheetid
                  group by m.sheetid,
                           m.customid,
                           m.palletzone,
                           m.pdtype,
                           m.shop_no) loop
        begin
          ncount := 1;
          --查找盘点计划单号
          select nvl(max(fpm.plan_no), null)
            into v_strPlanNo
            from fcdata_plan_m fpm
           where upper(fpm.source_plan_no) = upper(bm.sheetid)
             and fpm.warehouse_no = v_strWarehouseNo
             and fpm.owner_no = v_strOwnerNo;

          --判断盘点计划单号是否存在
          if v_strPlanNo is null then
            --获取WMS盘点计划单号
            PKLG_WMS_BASE.p_getsheetno('8888',
                                       v_strWarehouseNo,
                                       CONST_DOCUMENTTYPE.FCDATACP,
                                       v_strPlanNo,
                                       OUTMSG);
            --pdtype=1为储位盘,其它都为商品盘
            if bm.pdtype = '1' then
              --写盘点计划单头档
              insert into fcdata_plan_m
                (warehouse_no,
                 owner_no,
                 plan_type,
                 fcdata_type,
                 source_plan_no,
                 plan_no,
                 plan_date,
                 begin_date,
                 end_date,
                 status,
                 create_flag,
                 rgst_name,
                 rgst_date,
                 org_no)
              values
                (v_strWarehouseNo,
                 v_strOwnerNo,
                 case when bm.pdtype = '1' then '1' else '0' end,
                 '1',
                 bm.sheetid,
                 v_strPlanNo,
                 bm.sdate,
                 bm.sdate,
                 bm.sdate,
                 '10',
                 '1',
                 'admin_interface',
                 sysdate,
                 v_strOrgNo);

              --写盘点计划单明细
              insert into fcdata_plan_d
                (warehouse_no,
                 owner_no,
                 plan_no,
                 plan_id,
                 ware_no,
                 area_no,
                 stock_no,
                 article_no,
                 group_no,
                 cell_no)
                select v_strWarehouseNo,
                       v_strOwnerNo,
                       v_strPlanNo,
                       ROW_NUMBER() OVER(PARTITION BY wp.SHEETID ORDER BY wp.shop_no) SHEET_ROWNUM,
                       'ALL',
                       'ALL',
                       'ALL',
                       'N',
                       'N',
                       'ALL'
                  from WMS_PD@zdmwms_jk wp
                 where wp.sheetid = bm.sheetid;
            else
              --写盘点计划单头档
              insert into fcdata_plan_m
                (warehouse_no,
                 owner_no,
                 plan_type,
                 fcdata_type,
                 source_plan_no,
                 plan_no,
                 plan_date,
                 begin_date,
                 end_date,
                 status,
                 create_flag,
                 rgst_name,
                 rgst_date,
                 org_no)
              values
                (v_strWarehouseNo,
                 v_strOwnerNo,
                 case when bm.pdtype = '1' then '1' else '0' end,
                 '1',
                 bm.sheetid,
                 v_strPlanNo,
                 bm.sdate,
                 bm.sdate,
                 bm.sdate,
                 '10',
                 '1',
                 'admin_interface',
                 sysdate,
                 v_strOrgNo);

              --写盘点计划单明细
              insert into fcdata_plan_d
                (warehouse_no,
                 owner_no,
                 plan_no,
                 plan_id,
                 ware_no,
                 area_no,
                 stock_no,
                 article_no,
                 group_no,
                 cell_no)
                select v_strWarehouseNo,
                       v_strOwnerNo,
                       v_strPlanNo,
                       ROW_NUMBER() OVER(PARTITION BY wp.SHEETID ORDER BY wp.goodsid) SHEET_ROWNUM,
                       'N',
                       'N',
                       'N',
                       bda.article_no,
                       bda.group_no,
                       'N'
                  from WMS_PD@zdmwms_jk wp, bdef_defarticle bda
                 where wp.sheetid = bm.sheetid
                   and wp.goodsid = bda.owner_article_no;
            end if;
          end if;
        end;
      end loop;

      --转历史，删除已经处理的数据
      if ncount = 1 then
        insert into WMS_PDBAK@zdmwms_jk
          select *
            from WMS_PD@zdmwms_jk
           where palletzone = v_strWarehouseNo
             and customid = v_strOwnerNo
             and sheetid = a.sheetid;
        delete from WMS_PD@zdmwms_jk
         where palletzone = v_strWarehouseNo
           and customid = v_strOwnerNo
           and sheetid = a.sheetid;
        commit;
      else
        rollback;
      end if;
      <<nest>>
      null;
    end loop;
  exception
    when others then
      rollback;
      OUTMSG := 'O| ' || SQLERRM ||
                substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_FCDATA_PLAN_DOWN;
  /*****************************************************************************************
   功能：接口，接收库存调账单
  Modify By hcx AT 2016-02-29
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure P_STOCK_PLAN_DOWN is
    pragma autonomous_transaction;
    OUTMSG           varchar2(300);
    v_strWarehouseNo STOCK_PLAN_M.warehouse_no%type; --仓别
    v_strOwnerNo     fcdata_plan_m.owner_no%type; --货主
    v_strPlanNo      STOCK_PLAN_M.Plan_No%type; --调账单号
    ncount           number(2); --用来判断是不是有插入的数据，如果没有，就不转历。
    v_strOrgNo       fcdata_plan_m.org_no%type; --机构
  begin
    for a in (select distinct '8888' as enterprise_no,
                              warehouse_no,
                              sheetid,
                              shop_no,
                              owner_no
                from WMS_ADJUST@zdmwms_jk) loop
      --取wms仓别
      P_WAREHOUSENO_GET(a.enterprise_no,
                        a.warehouse_no,
                        v_strWarehouseNo,
                        OUTMSG);
      if v_strWarehouseNo is null then
        goto nest;
      end if;
      --取wms机构
      P_ORG_GET(a.enterprise_no, a.shop_no, v_strOrgNo, OUTMSG);

      if v_strOrgNo is null then
        goto nest;
      end if;
      --取wms货主
      P_OWNERNO_GET(a.enterprise_no, a.owner_no, v_strOwnerNo, OUTMSG);
      if v_strOwnerNo is null then
        goto nest;
      end if;
      ncount := 0;
      --锁数据
      update WMS_ADJUST@zdmwms_jk
         set warehouse_no = v_strWarehouseNo, owner_no = v_strOwnerNo
       where warehouse_no = a.warehouse_no
         and owner_no = a.owner_no
         and sheetid = a.sheetid;

      for bm in (select m.sheetid,
                        m.rtype,
                        m.notes,
                        m.enterprise_no,
                        m.owner_no,
                        m.shop_no,
                        m.warehouse_no
                   from WMS_ADJUST@zdmwms_jk m
                  where m.warehouse_no = v_strWarehouseNo
                    and m.owner_no = v_strOwnerNo
                  group by m.sheetid,
                           m.rtype,
                           m.notes,
                           m.enterprise_no,
                           m.owner_no,
                           m.shop_no,
                           m.warehouse_no) loop
        begin
          ncount := 1;
          select nvl(max(spm.plan_no), '')
            into v_strPlanNo
            from stock_plan_m spm
           where spm.po_no = bm.sheetid
             and spm.owner_no = bm.owner_no
             and spm.warehouse_no = bm.warehouse_no;

          if v_strPlanNo is null then
            --获取WMS调帐单号
            PKLG_WMS_BASE.p_getsheetno('8888',
                                       v_strWarehouseNo,
                                       CONST_DOCUMENTTYPE.STOCKPLAN,
                                       v_strPlanNo,
                                       OUTMSG); --获取WMS调帐单号
            insert into stock_plan_m
              (warehouse_no,
               owner_no,
               plan_type,
               plan_no,
               po_no,
               plan_date,
               status,
               create_flag,
               org_no,
               rgst_name,
               rgst_date)
            values
              (v_strWarehouseNo,
               bm.owner_no,
               bm.rtype,
               v_strPlanNo,
               bm.sheetid,
               sysdate,
               '10',
               '1',
               v_strOrgNo,
               'admin_interface',
               sysdate);

            insert into stock_plan_d
              (warehouse_no,
               owner_no,
               plan_no,
               row_id,
               article_no,
               packing_qty,
               cell_no,
               plan_qty， rgst_name,
               rgst_date)
              select v_strWarehouseNo,
                     v_strOwnerNo,
                     v_strPlanNo,
                     ROW_NUMBER() OVER(PARTITION BY wd.SHEETID ORDER BY wd.owner_article_no) SHEET_ROWNUM,
                     bda.article_no,
                     wd.pkcount,
                     'N',
                     wd.planqty,
                     'admin_interface',
                     sysdate
                from WMS_ADJUST@zdmwms_jk wd, bdef_defarticle bda
               where wd.sheetid = bm.sheetid
                 and wd.owner_article_no = bda.owner_article_no;
          end if;
        end;
      end loop;

      --转历史，删除已经处理的数据
      if ncount = 1 then
        insert into WMS_ADJUSTBAK@zdmwms_jk
          select *
            from WMS_ADJUST@zdmwms_jk wad
           where wad.warehouse_no = v_strWarehouseNo
             and wad.owner_no = v_strOwnerNo
             and wad.sheetid = a.sheetid;
        delete WMS_ADJUST@zdmwms_jk wad
         where wad.warehouse_no = v_strWarehouseNo
           and wad.owner_no = v_strOwnerNo
           and wad.sheetid = a.sheetid;
        commit;
      else
        rollback;
      end if;
      <<nest>>
      null;
    end loop;
  exception
    when others then
      rollback;
      OUTMSG := 'O| ' || SQLERRM ||
                substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_STOCK_PLAN_DOWN;

  /*****************************************************************************************
   功能：接口，回传出货配送
  Modify By hcx AT 2016-02-29
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure P_ODATA_DELIVER_UP is
    pragma autonomous_transaction;
    cursor Get_ODATA_DELIVER is
      select *
        from Odata_DELIVER_M dm
       where dm.send_flag = '11'
         and dm.status = '13'
         and dm.enterprise_no = '8888';

    OUTMSG varchar2(300);
    ncount number;
  begin
    update odata_deliver_m dm
       set Send_flag = '11'
     where Send_flag = '10'
       and status = '13'
       and exists (select 1
              from odata_exp_m m, odata_deliver_d d
             where dm.enterprise_no = d.enterprise_no
               and dm.warehouse_no = d.warehouse_no
               and dm.owner_no = d.owner_no
               and dm.deliver_no = d.deliver_no
               and d.enterprise_no = m.enterprise_no
               and d.warehouse_no = m.warehouse_no
               and d.owner_no = m.owner_no
               and d.exp_no = m.exp_no
               and m.create_flag = '1');

    for om in Get_ODATA_DELIVER loop
      select count(*)
        into ncount
        from erp_exp@zdmwms_jk m
       where m.sheetid = om.deliver_no;

      if ncount = 0 then
        insert into erp_exp@zdmwms_jk
          (sheetid,
           sourceexp_no,
           loadpropose_no,
           box_no,
           warehouse_no,
           owner_article_no,
           article_qty,
           real_qty,
           owner_cust_no,
           sdate,
           prodate,
           volumn,
           weight,
           pkcount)
          select /*to_char(trunc(odm.rgst_date), 'yymmdd') || odd.label_no sheetid, --*/odd.deliver_no,
                 case
                   when (select count(1)
                           from odata_exp_m oem
                          where oem.enterprise_no = odd.enterprise_no
                            and oem.warehouse_no = odd.warehouse_no
                            and oem.exp_no = odd.exp_no --and oem.exp_type=odd.exp_type
                         ) > 0 then
                    (select oem.sourceexp_no
                       from odata_exp_m oem
                      where oem.exp_no = odd.exp_no
                        and oem.enterprise_no = odd.enterprise_no
                        and oem.warehouse_no = odd.warehouse_no)
                   else
                    odd.exp_no
                 end sourceexp_no, --取原单号
                 odm.loadpropose_no,
                 odd.label_no,
                 odd.warehouse_no,
                 bda.owner_article_no,
                 0,
                 sum(odd.qty),
                 case
                   when (select count(1)
                           from odata_exp_m oem
                          where oem.enterprise_no = odd.enterprise_no
                            and oem.warehouse_no = odd.warehouse_no
                            and oem.exp_no = odd.exp_no) > 0 then
                    (select max(oem.cust_no)
                       from odata_exp_m oem
                      where oem.exp_no = odd.exp_no
                        and oem.enterprise_no = odd.enterprise_no
                        and oem.warehouse_no = odd.warehouse_no)
                   else
                    (select max(iia.cust_no)
                       from idata_import_allot iia
                      where iia.enterprise_no = odd.enterprise_no
                        and iia.warehouse_no = odd.warehouse_no
                        and iia.po_no = odd.exp_no)
                 end cust_no, --取门店号
                 trunc(odm.rgst_date),
                 odd.produce_date,
                 sum(odd.qty * bda.unit_volumn) volumn,
                 sum(odd.qty * bda.unit_weight) weight,
                 odd.packing_qty
            from odata_deliver_d odd,
                 odata_deliver_m odm,
                 bdef_defarticle bda
           where odd.enterprise_no = odm.enterprise_no
             and odd.warehouse_no = odm.warehouse_no
             and odd.deliver_no = odm.deliver_no
             and odd.article_no = bda.article_no
             and odd.deliver_no = odm.deliver_no
             and odm.deliver_no = om.deliver_no
             and odd.enterprise_no = bda.enterprise_no
             and odd.owner_no = bda.owner_no
           group by odd.deliver_no,
                    odd.exp_no,
                    odm.loadpropose_no,
                    odd.label_no,
                    odd.warehouse_no,
                    bda.owner_article_no,
                    --odd.barcode,
                    odd.article_no,
                    odd.packing_qty,
                    odd.produce_date,
                    --odm.cust_no,
                    trunc(odm.rgst_date),
                    odd.enterprise_no,
                    odd.owner_no,
                    bda.unit_weight,
                    bda.unit_volumn;
      end if;
    end loop;
    update odata_deliver_m a
       set send_flag = '13',
           updt_name = 'admin_interface',
           updt_date = sysdate
     where send_flag = '11';
    commit;
  exception
    when others then
      rollback;
      OUTMSG := 'N| ' || SQLERRM ||
                substr(dbms_utility.format_error_backtrace, 1, 256);
      /* P_write_log('P_ODATA_DELIVER_UP', outmsg);*/
  end P_ODATA_DELIVER_UP;
  /*****************************************************************************************
   功能：接口，回传退厂配送
  Modify By hcx AT 2016-02-29
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure P_RODATA_DELIVER_UP is
    pragma autonomous_transaction;
    OUTMSG varchar2(300);
  begin
    --修改状态
    update RODATA_DELIVER_M m
       set send_flag = '11'
     where send_flag = '10'
       and status = '13'
       and exists (select 1
              from rodata_recede_m c, rodata_deliver_d d
             where d.enterprise_no = c.enterprise_no
               and d.warehouse_no = c.warehouse_no
               and d.owner_no = c.owner_no
               and d.recede_no = c.recede_no
               and c.create_flag = '1'
               and d.enterprise_no = m.enterprise_no
               and d.warehouse_no = m.warehouse_no
               and d.owner_no = m.owner_no
               and d.deliver_no = m.deliver_no);

    declare
      cursor Get_RODATA_DELIVER is
        SELECT *
          FROM RODATA_DELIVER_M
         where send_flag = '11'
           and status = '13'
           and enterprise_no = '8888';
      ii Get_RODATA_DELIVER%rowtype; ---定义游标变量
    begin
      open Get_RODATA_DELIVER;
      loop
        Fetch Get_RODATA_DELIVER
          into ii;
        Exit when Get_RODATA_DELIVER%notfound;

        insert into erp_recede@zdmwms_jk
          (sheetid,
           po_no,
           warehouse_no,
           owner_article_no,
           recede_qty,
           realqty,
           supplier_no,
           sdate,
           notes,
           prodate,
           volumn,
           weight,
           pkcount)
          select odd.deliver_no,
                 rrm.po_no,
                 odd.warehouse_no,
                 odd.owner_article_no,
                 0,
                 odd.real_qty,
                 rrm.supplier_no,
                 odd.rgst_date,
                 'N',
                 odd.produce_date,
                 odd.volumn,
                 odd.weight,
                 odd.packing_qty
            from (select rdm.enterprise_no,
                         rdm.warehouse_no,
                         rdm.owner_no,
                         rdd.deliver_no,
                         rdd.recede_no,
                         rdd.article_no,
                         v.owner_article_no,
                         rdd.produce_date,
                         sum(rdd.real_qty) real_qty,
                         sum(rdd.real_qty * v.unit_volumn) volumn,
                         sum(rdd.real_qty * v.unit_weight) weight,
                         rdd.packing_qty,
                         trunc(rdm.rgst_date) rgst_date
                    from RODATA_DELIVER_d rdd,
                         RODATA_DELIVER_M rdm,
                         bdef_defarticle  v
                   where rdd.warehouse_no = rdm.warehouse_no
                     and rdd.deliver_no = rdm.deliver_no
                     and rdd.enterprise_no = rdm.enterprise_no
                     and rdd.deliver_no = ii.deliver_no
                     and rdd.enterprise_no = v.enterprise_no
                     and rdd.owner_no = v.owner_no
                     and rdd.article_no = v.article_no
                   group by rdm.enterprise_no,
                            rdm.warehouse_no,
                            rdm.owner_no,
                            rdd.deliver_no,
                            rdd.recede_no,
                            rdd.article_no,
                            v.owner_article_no,
                            rdd.packing_qty,
                            rdd.produce_date,
                            v.unit_volumn,
                            v.unit_weight,
                            trunc(rdm.rgst_date)) odd,
                 rodata_recede_m rrm
           where odd.enterprise_no = rrm.enterprise_no
             and odd.warehouse_no = rrm.warehouse_no
             and odd.owner_no = rrm.owner_no
             and odd.recede_no = rrm.recede_no;

      end loop;

      close Get_RODATA_DELIVER;
    end;
    update RODATA_DELIVER_M a
       set send_flag = '13',
           updt_name = 'admin_interface',
           updt_date = sysdate
     where send_flag = '11';
    commit;
  exception
    when others then
      rollback;
      OUTMSG := 'N| ' || SQLERRM ||
                substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_RODATA_DELIVER_UP;
  /*****************************************************************************************
   功能：接口，回传返配验收
  Modify By hcx AT 2016-02-29
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure P_RIDATA_CHECK_UP is
    pragma autonomous_transaction;
    OUTMSG varchar2(300);
  begin

    update ridata_check_m m
       set m.send_flag = '11'
     where m.status = '13'
       and m.send_flag = '10'
       and exists (select 1
              from ridata_untread_m um
             where m.enterprise_no = um.enterprise_no
               and m.owner_no = um.owner_no
               and m.warehouse_no = um.warehouse_no
               and m.untread_no = um.untread_no
               and um.create_flag = '1');

    declare
      cursor Get_RIDATA_Check is
        select m.*
          from RIDATA_CHECK_M m, ridata_untread_m um
         where m.send_flag = '11'
           and m.status = '13'
           and m.enterprise_no = '8888'
           and m.enterprise_no = um.enterprise_no
           and m.owner_no = um.owner_no
           and m.warehouse_no = um.warehouse_no
           and m.untread_no = um.untread_no
           and um.create_flag = '1';

      ii Get_RIDATA_Check%rowtype; ---定义游标变量
    begin
      open Get_RIDATA_Check;
      loop
        Fetch Get_RIDATA_Check
          into ii;
        Exit when Get_RIDATA_Check%notfound;

        insert into erp_untread@zdmwms_jk
          (sheetid,
           warehouse_no,
           po_no,
           owner_article_no,
           plan_qty,
           real_qty,
           cust_no,
           sdate,
           notes,
           prodate,
           volumn,
           weight,
           pkcount)
          select rcd.check_no,
                 rcd.warehouse_no,
                 rum.po_no,
                 bda.owner_article_no,
                 0,
                 sum(rcd.check_qty),
                 rum.cust_no,
                 trunc(rcm.rgst_date),
                 'N',
                 rcd.produce_date,
                 sum(rcd.check_qty * bda.unit_volumn),
                 sum(rcd.check_qty * bda.unit_weight),
                 rcd.packing_qty
            from ridata_check_d   rcd,
                 ridata_check_m   rcm,
                 ridata_untread_m rum,
                 bdef_defarticle  bda
           where rcd.enterprise_no = rcm.enterprise_no
             and rcd.warehouse_no = rcm.warehouse_no
             and rcd.check_no = rcm.check_no
             and rcd.owner_no = rcm.owner_no
             and rcm.enterprise_no = rum.enterprise_no
             and rcm.warehouse_no = rum.warehouse_no
             and rcm.owner_no = rum.owner_no
             and rcm.untread_no = rum.untread_no
             and rcd.article_no = bda.article_no
             and rcd.owner_no = bda.owner_no
             and rcd.warehouse_no = ii.warehouse_no
             and rcd.check_no = ii.check_no
             and rum.create_flag = '1'
           group by rcd.check_no,
                    rcd.warehouse_no,
                    rum.po_no,
                    bda.owner_article_no,
                    rcd.article_no,
                    rcd.packing_qty,
                    rcd.produce_date,
                    bda.unit_volumn,
                    bda.unit_weight,
                    rum.cust_no,
                    trunc(rcm.rgst_date);
      end loop;

      close Get_RIDATA_Check;
    end;
    update ridata_CHECK_M m
       set m.send_flag = '13',
           m.updt_name = 'admin_interface',
           m.updt_date = sysdate
     where m.status = '13'
       and m.send_flag = '11';
    commit;
  exception
    when others then
      rollback;
      OUTMSG := 'N| ' || SQLERRM ||
                substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_RIDATA_CHECK_UP;
  /*****************************************************************************************
   功能：接口，回传盘点结果
  Modify By hcx AT 2016-02-29
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure P_FCDATA_PD_UP is
    pragma autonomous_transaction;
    OUTMSG varchar2(300);
  begin

    update fcdata_pd_m m
       set m.send_flag = '11'
     where m.status = '13'
       and m.send_flag = '10';

    declare
      cursor Get_FCDATA_PD is
        select m.*
          from fcdata_pd_m m
         where m.send_flag = '11'
           and m.status = '13'
           and m.enterprise_no = '8888';
      ii Get_FCDATA_PD%rowtype; ---定义游标变量
    begin
      open Get_FCDATA_PD;
      loop
        Fetch Get_FCDATA_PD
          into ii;
        Exit when Get_FCDATA_PD%notfound;
        insert into erp_pdplan@zdmwms_jk
          (sheetid,
           source_plan_no,
           warehouse_no,
           owner_article_no,
           stock_qty,
           pd_qty,
           sdate,
           notes,
           prodate,
           volumn,
           weight,
           pkcount)
          select fpd.plan_no,
                 fpm.source_plan_no,
                 fpd.warehouse_no,
                 bda.owner_article_no,
                 0,
                 sum(fpd.real_qty),
                 trunc(fpd.rgst_date),
                 'N',
                 fpd.produce_date,
                 sum((fpd.real_qty) * bda.unit_volumn),
                 sum((fpd.real_qty) * bda.unit_weight),
                 fpd.packing_qty
            from fcdata_pd_d fpd, fcdata_plan_m fpm, bdef_defarticle bda
           where fpd.enterprise_no = fpm.enterprise_no
             and fpd.warehouse_no = fpm.warehouse_no
             and fpd.plan_no = fpm.plan_no
             and fpd.article_no = bda.article_no
             and fpd.plan_no = ii.plan_no
             and fpd.warehouse_no = ii.warehouse_no
             and fpd.enterprise_no = bda.enterprise_no
             and fpd.owner_no = bda.owner_no
             and fpd.article_no = bda.article_no
           group by fpd.plan_no,
                    fpm.source_plan_no,
                    fpd.warehouse_no,
                    bda.owner_article_no,
                    fpd.rgst_date,
                    fpd.produce_date,
                    fpd.packing_qty,
                    bda.unit_volumn,
                    bda.unit_weight;
      end loop;
      close Get_FCDATA_PD;
    end;
    update fcdata_pd_m m
       set m.send_flag = '13',
           m.updt_name = 'admin_interface',
           m.updt_date = sysdate
     where m.status = '13'
       and m.send_flag = '11';

    commit;
  exception
    when others then
      rollback;
      OUTMSG := 'N| ' || SQLERRM ||
                substr(dbms_utility.format_error_backtrace, 1, 256);
      /*P_write_log('P_FCDATA_PD_UP', outmsg);*/
  end P_FCDATA_PD_UP;
  /*****************************************************************************************
   功能：接口，回传库存调账结果
  Modify By hcx AT 2016-02-29
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure P_STOCK_PLAN_UP is
    pragma autonomous_transaction;
    OUTMSG varchar2(300);

  begin

    update stock_confirm_m m
       set m.send_flag = '11'
     where m.status = '13'
       and m.send_flag = '10';

    declare
      cursor Get_STOCK_PLAN is
        select m.*
          from stock_confirm_m m
         where m.send_flag = '11'
           and m.status = '13'
           and m.enterprise_no = '8888';

      ii Get_STOCK_PLAN%rowtype; ---定义游标变量

    begin
      open Get_STOCK_PLAN;
      loop
        Fetch Get_STOCK_PLAN
          into ii;
        Exit when Get_STOCK_PLAN%notfound;

        insert into ERP_ADJUST@zdmwms_jk
          (sheetid,
           lost_no,
           warehouse_no,
           owner_article_no,
           realQty,
           sdate,
           shop_no,
           prodate,
           volumn,
           weight,
           pkcount)
          select scd.confirm_no,
                 scm.plan_no,
                 scd.warehouse_no,
                 bda.owner_article_no,
                 sum(scd.real_qty),
                 trunc(scd.updt_date),
                 spm.org_no,
                 scd.produce_date,
                 sum((scd.real_qty) * bda.unit_volumn),
                 sum((scd.real_qty) * bda.unit_weight),
                 scd.packing_qty
            from stock_confirm_d scd,
                 stock_confirm_m scm,
                 stock_plan_m    spm,
                 bdef_defarticle bda
           where scd.enterprise_no = scm.enterprise_no
             and scd.warehouse_no = scm.warehouse_no
             and scd.confirm_no = scm.confirm_no
             and scd.enterprise_no = spm.enterprise_no
             and scd.warehouse_no = spm.warehouse_no
             and scm.plan_no = spm.plan_no
             and scd.confirm_no = ii.confirm_no
             and scd.warehouse_no = ii.warehouse_no
             and scd.enterprise_no = bda.enterprise_no
             and scd.owner_no = bda.owner_no
             and scd.article_no = bda.article_no
           group by scd.confirm_no,
                    scd.warehouse_no,
                    scm.plan_no,
                    bda.owner_article_no,
                    trunc(scd.updt_date),
                    spm.org_no,
                    scd.produce_date,
                    scd.packing_qty,
                    bda.unit_volumn,
                    bda.unit_weight;

      end loop;

      close Get_STOCK_PLAN;
    end;

    update sodata_waste_m m
       set m.send_flag = '13',
           m.updt_name = 'admin_interface',
           m.updt_date = sysdate
     where m.status = '13'
       and m.send_flag = '11';

    commit;
  exception
    when others then
      rollback;
      OUTMSG := 'N| ' || SQLERRM ||
                substr(dbms_utility.format_error_backtrace, 1, 256);
      /* P_write_log('P_SODATA_WASTE_UP', outmsg);*/

  end P_STOCK_PLAN_UP;
  /*****************************************************************************************
   功能：接口，回传报损结果
  Modify By hcx AT 2016-02-29
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure P_SODATA_WASTE_UP is
    pragma autonomous_transaction;
    OUTMSG varchar2(300);
  begin

    update sodata_waste_m m
       set m.send_flag = '11'
     where m.status = '13'
       and m.send_flag = '10';

    declare
      cursor Get_SODATA_WASTE is
        select m.*
          from sodata_waste_m m
         where m.send_flag = '11'
           and m.status = '13'
           and m.enterprise_no = '8888';
      ii Get_SODATA_WASTE%rowtype; ---定义游标变量
    begin
      open Get_SODATA_WASTE;
      loop
        Fetch Get_SODATA_WASTE
          into ii;
        Exit when Get_SODATA_WASTE%notfound;

        insert into erp_lost@zdmwms_jk
          (sheetid,
           lost_no,
           warehouse_no,
           owner_article_no,
           realQty,
           sdate,
           shop_no,
           prodate,
           volumn,
           weight,
           pkcount)
          select swm.waste_no,
                 swm.po_no,
                 swd.warehouse_no,
                 bda.owner_article_no,
                 sum(swd.real_qty),
                 trunc(swm.request_date),
                 swm.org_no,
                 sai.produce_date,
                 sum((swd.real_qty) * bda.unit_volumn),
                 sum((swd.real_qty) * bda.unit_weight),
                 swd.packing_qty
            from sodata_outstock_dhty swd,
                 sodata_waste_m       swm,
                 bdef_defarticle      bda,
                 stock_article_info   sai
           where swd.enterprise_no = swm.enterprise_no
             and swd.warehouse_no = swm.warehouse_no
             and swd.source_no = swm.waste_no
             and swd.enterprise_no = bda.enterprise_no
             and swd.owner_no = bda.owner_no
             and swd.article_no = bda.article_no
             and swd.enterprise_no = sai.enterprise_no
             and swd.article_no = sai.article_no
             and swd.article_id = sai.article_id
             and swm.waste_no = ii.waste_no
             and swm.warehouse_no = ii.warehouse_no
           group by swm.waste_no,
                    swd.warehouse_no,
                    swm.po_no,
                    bda.owner_article_no,
                    trunc(swm.request_date),
                    swm.org_no,
                    sai.produce_date,
                    swd.packing_qty,
                    bda.unit_volumn,
                    bda.unit_weight;

      end loop;

      close Get_SODATA_WASTE;
    end;

    update sodata_waste_m m
       set m.send_flag = '13',
           m.updt_name = 'admin_interface',
           m.updt_date = sysdate
     where m.status = '13'
       and m.send_flag = '11';
    commit;
  exception
    when others then
      rollback;
      OUTMSG := 'N| ' || SQLERRM ||
                substr(dbms_utility.format_error_backtrace, 1, 256);
      /* P_write_log('P_SODATA_WASTE_UP', outmsg);*/
  end P_SODATA_WASTE_UP;
  /*****************************************************************************************
   功能：接口，回传品质转换结果
  Modify By hcx AT 2016-02-29
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure P_WMS_QUATITY_CHANGE_UP is
    pragma autonomous_transaction;
    OUTMSG varchar2(300);
  begin

    update org_quality_change_m m
       set m.send_flag = '11'
     where m.status = '13'
       and m.send_flag = '10';

    declare
      cursor Get_WMS_QUATITY_CHANGE is
        select m.*
          from org_quality_change_m m
         where m.send_flag = '11'
           and m.status = '13'
           and m.enterprise_no = '8888';

      ii Get_WMS_QUATITY_CHANGE%rowtype; ---定义游标变量
    begin
      open Get_WMS_QUATITY_CHANGE;
      loop
        Fetch Get_WMS_QUATITY_CHANGE
          into ii;
        Exit when Get_WMS_QUATITY_CHANGE%notfound;
        insert into erp_quatity_change@zdmwms_jk
          (sheetid,
           change_no,
           s_quatity_type,
           d_quatity_type,
           owner_article_no,
           planqty,
           sdate,
           enterprise_no,
           owner_no,
           warehouse_no,
           createtime,
           prodate,
           pkcount)
          select oqcd.change_no,
                 oqcd.change_no,
                 oqcd.s_org_no,
                 oqcd.d_org_no,
                 bda.owner_article_no,
                 sum(oqcd.real_qty),
                 trunc(oqcm.rgst_date),
                 oqcm.enterprise_no,
                 oqcm.owner_no,
                 oqcm.warehouse_no,
                 sysdate,
                 oqcd.produce_date,
                 oqcd.packing_qty
            from org_quality_change_d oqcd,
                 org_quality_change_m oqcm,
                 bdef_defarticle      bda
           where oqcd.enterprise_no = oqcm.enterprise_no
             and oqcd.warehouse_no = oqcm.warehouse_no
             and oqcd.change_no = oqcm.change_no
             and oqcd.enterprise_no = oqcm.enterprise_no
             and oqcd.article_no = bda.article_no
             and oqcd.change_no = ii.change_no
             and oqcd.warehouse_no = ii.warehouse_no
           group by oqcd.change_no,
                    oqcd.change_no,
                    oqcd.s_org_no,
                    oqcd.d_org_no,
                    bda.owner_article_no,
                    trunc(oqcm.rgst_date),
                    oqcm.enterprise_no,
                    oqcm.owner_no,
                    oqcm.warehouse_no,
                    sysdate,
                    oqcd.produce_date,
                    oqcd.packing_qty;
      end loop;
      close Get_WMS_QUATITY_CHANGE;
    end;

    update org_quality_change_m m
       set m.send_flag = '13',
           m.updt_name = 'admin_interface',
           m.updt_date = sysdate
     where m.status = '13'
       and m.send_flag = '11';
    commit;
  exception
    when others then
      rollback;
      OUTMSG := 'N| ' || SQLERRM ||
                substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_WMS_QUATITY_CHANGE_UP;
  
  /*****************************************************************************************
   功能：接口，回传出货单状态
  Modify By JCL AT 2017-06-26
  pragma autonomous_transaction;
  *****************************************************************************************/
  PROCEDURE P_ODATA_EXP_STATUS_UP IS 
  pragma autonomous_transaction;
    cursor Get_ODATA_DELIVER is
      select *
        from Odata_DELIVER_M dm
       where dm.send_flag = '11'
         and dm.status = '13'
         and dm.enterprise_no = '8888'
         and exists (select 1
              from OWNER_SET_RETURN@zdmwms_jk m 
             where dm.enterprise_no = m.enterprise_no
               and dm.owner_no = m.owner_no);

    OUTMSG varchar2(300);
    ncount number;
  begin
    update odata_deliver_m dm
       set Send_flag = '11'
     where Send_flag = '10'
       and status = '13'
       and exists (select 1
              from OWNER_SET_RETURN@zdmwms_jk m 
             where dm.enterprise_no = m.enterprise_no
               and dm.owner_no = m.owner_no);

    for om in Get_ODATA_DELIVER loop
      select count(*)
        into ncount
        from ERP_EXP_STATUS@zdmwms_jk m
       where m.sheetid = om.deliver_no;

      if ncount = 0 then
        insert into ERP_EXP_STATUS@zdmwms_jk
          (sheetid,
          enterprise_no,
          warehouse_no,
          exp_no,
          owner_no,
          owner_return_url,
           sourceexp_no,
           shipper_deliver_no,
           status,
           rgst_date,
           rgst_name)
          SELECT odd.deliver_no,
                 odm.enterprise_no,
                 odm.warehouse_no,
                 em.exp_no,
                 em.owner_no,
                 osr.owner_return_url,
                  em.sourceexp_no, --取原单号
                  em.shipper_deliver_no,
                 '4',
                 SYSDATE,
                 'admin_interface'            
            from odata_deliver_d odd,
                 odata_deliver_m odm,
                 odata_exp_m em,
                 OWNER_SET_RETURN@zdmwms_jk osr
           where odd.enterprise_no = odm.enterprise_no
             and odd.warehouse_no = odm.warehouse_no
             and odd.deliver_no = odm.deliver_no
             AND odm.enterprise_no = om.enterprise_no
             AND odm.warehouse_no = om.warehouse_no
             and odm.deliver_no = om.deliver_no             
             AND em.exp_no = odd.exp_no
            and em.enterprise_no = odd.enterprise_no
            and em.warehouse_no = odd.warehouse_no
            and em.owner_no = osr.owner_no
           group by odd.deliver_no,
                 odm.enterprise_no,
                 odm.warehouse_no,
                 em.exp_no,
                 em.owner_no,
                 osr.owner_return_url,
                  em.sourceexp_no, 
                  em.shipper_deliver_no;
                  
         update odata_deliver_m a
         set send_flag = '13',
             updt_name = 'admin_interface',
             updt_date = sysdate
         where send_flag = '11'
         AND a.enterprise_no = om.enterprise_no
         AND a.warehouse_no = om.warehouse_no
         and a.deliver_no = om.deliver_no;         
      end if;     
    end loop;    
    commit;    
    EXCEPTION
      when others then
      rollback;
      OUTMSG := 'N| ' || SQLERRM ||
                substr(dbms_utility.format_error_backtrace, 1, 256);   
  end P_ODATA_EXP_STATUS_UP;
  
  --单据下传存储过程调用
  PROCEDURE PROC_JK_JOB_DOWN IS
    MSGNUM NUMBER;
  BEGIN
    MSGNUM := 0;
    --接收供应商资料
    /*BEGIN
      P_BDEF_DEFSUPPLIER_DOWN();
      --COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        MSGNUM := MSGNUM + 1;
    END;
    --接收门店资料
    BEGIN
      P_BDEF_DEFCUST_DOWN();
      --COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        MSGNUM := MSGNUM + 1;
    END;

    --接收类别资料
    BEGIN
      P_BDEF_ARTICLE_GROUP_DOWN();
      --COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        MSGNUM := MSGNUM + 1;
    END;

    --接收商品资料
    BEGIN
      P_BDEF_DEFARTICLE_DOWN();
      --COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        MSGNUM := MSGNUM + 1;
    END;
    --接收商品多条码
    BEGIN
      P_BDEF_ARTICLE_BARCODE_DOWN();
      --COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        MSGNUM := MSGNUM + 1;
    END;
    --接收进货单
    BEGIN
      P_IDATA_IMPORT_DOWN();
      --XZ_WMS_JK.test_wyf();
      --COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        MSGNUM := MSGNUM + 1;
    END;*/
    ---接收出货单
    BEGIN
      P_ODATA_EXP_DOWN();
      --COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        MSGNUM := MSGNUM + 1;
    END;
    --接收退厂单
    /*BEGIN
      P_RODATA_RECEDE_DOWN();
      --COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        MSGNUM := MSGNUM + 1;
    END;
    --接收返配单
    BEGIN
      P_RIDATA_UNTREAD_DOWN();
      --COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        MSGNUM := MSGNUM + 1;
    END;
    --接收盘点单
    BEGIN
      P_FCDATA_PLAN_DOWN();
      --COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        MSGNUM := MSGNUM + 1;
    END;
    --接收库存调账单
    BEGIN
      P_STOCK_PLAN_DOWN();
      --COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        MSGNUM := MSGNUM + 1;
    END;*/

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      /*PROC_WRITE_LOG('PROC_JK_JOB_DOWN',
      'O| ' || SQLERRM ||
      SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256));*/
  END PROC_JK_JOB_DOWN;

  --单据上传存储过程调用
  PROCEDURE PROC_JK_JOB_UP IS
    MSGNUM NUMBER;
  BEGIN
     BEGIN
      P_ODATA_EXP_STATUS_UP();
      --COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        MSGNUM := MSGNUM + 1;
    END;
    ---进货单                 上传(审核)
/*    BEGIN
      P_SODATA_WASTE_AUDIT();
      --COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        MSGNUM := MSGNUM + 1;
    END;
    ---进货单                 上传
    BEGIN
      P_IDATA_CHECK_UP();
      --COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        MSGNUM := MSGNUM + 1;
    END;
    ---出货单                 上传
    BEGIN
      P_ODATA_DELIVER_UP();
      --COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        MSGNUM := MSGNUM + 1;
    END;
    ---退厂单                上传
    BEGIN
      P_RODATA_DELIVER_UP();
      --COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        MSGNUM := MSGNUM + 1;
    END;
    ---返配单                 上传
    BEGIN
      P_RIDATA_CHECK_UP();
      --COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        MSGNUM := MSGNUM + 1;
    END;
    ---盘点                 上传
    BEGIN
      P_FCDATA_PD_UP();
      --COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        MSGNUM := MSGNUM + 1;
    END;
    ---库存调账                 上传
    BEGIN
      P_STOCK_PLAN_UP();
      --COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        MSGNUM := MSGNUM + 1;
    END;
    ---报损单                 上传
    BEGIN
      P_SODATA_WASTE_UP();
      --COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        MSGNUM := MSGNUM + 1;
    END;
    ---品质转换单                 上传
    BEGIN
      P_WMS_QUATITY_CHANGE_UP();
      --COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        MSGNUM := MSGNUM + 1;
    END;*/

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;

  END PROC_JK_JOB_UP;

  /*procedure test_wyf is
    OUTMSG varchar2(300);
  begin
    for p in (select distinct c.warehouse_no,
                              c.owner_no,
                              c.import_no,
                              c.po_no as sheetid
                from WMS_RATIONNOTE@zdmwms_jk a, idata_import_m c
               where a.refsheetid = c.po_no) loop
      insert into idata_import_allot
        (warehouse_no,
         owner_no,
         import_no,
         article_no,
         packing_qty,
         po_qty,
         allot_qty,
         status,
         sub_cust_no,
         cust_no,
         rgst_name,
         rgst_date,
         po_no)
        select p.warehouse_no,
               p.owner_no,
               p.import_no,
               h.goodsid,
               h.pkcount,
               h.planqty,
               0,
               '10',
               h.shopid,
               h.shopid,
               'admin_interface',
               sysdate,
               h.sheetid
          from WMS_RATIONNOTE@zdmwms_jk h
         where h.refsheetid = p.sheetid;

      --转历史，删除已经处理的数据
      insert into WMS_RATIONNOTEBAK@zdmwms_jk
        select *
          from WMS_RATIONNOTE@zdmwms_jk h
         where h.refsheetid = p.sheetid;
      delete from WMS_RATIONNOTE@zdmwms_jk h where h.refsheetid = p.sheetid;
    end loop;
    commit;
  exception
    when others then
      rollback;
      OUTMSG := 'O| ' || SQLERRM ||
                substr(dbms_utility.format_error_backtrace, 1, 256);
  end test_wyf;*/
  /*****************************************************************************************
   功能：接口，接收进货手建单主档
  Modify By hcx AT 2016-02-29
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure P_IDATA_IMPORT_DOWN_t(OUTMSG out varchar2) is
    /*  OUTMSG           varchar2(300);*/
    v_strPoType      idata_import_m.po_type%type; --单据类型
    v_strImportNo    idata_import_m.import_no%type; --进货单号
    v_strWarehouseNo idata_import_m.warehouse_no%type; --仓别
    v_strOwnerNo     idata_import_m.owner_no%type; --货主
    v_strClassType   idata_import_m.class_type%type; --是否直通单，0：存储，1：直通
    --v_strArticleNo   VARCHAR2(15); --商品编码
    --v_strSImportNo   Idata_Import_Mm.S_IMPORT_NO%type; --汇总进货单号
    n_count_allot number(10);
    v_orgNo       Idata_Import_M.Org_No%type; --机构号
  begin
    for a in (select distinct '8888' as enterprise_no,
                              palletzone,
                              customid,
                              shop_no,
                              sheetid
                from WMS_PURCHASE@zdmwms_jk) loop
      --取wms仓别
      P_WAREHOUSENO_GET(a.enterprise_no,
                                  a.palletzone,
                                  v_strWarehouseNo,
                                  OUTMSG);
      if v_strWarehouseNo is null then
        goto nest;
      end if;
      --取wms机构
      P_ORG_GET(a.enterprise_no, a.shop_no, v_orgNo, OUTMSG);
      if v_strWarehouseNo is null then
        goto nest;
      end if;
      --取wms货主
      P_OWNERNO_GET(a.enterprise_no,
                              a.customid,
                              v_strOwnerNo,
                              OUTMSG);
      if v_strOwnerNo is null then
        goto nest;
      else
        --锁数据
        update WMS_PURCHASE@zdmwms_jk wp
           set wp.palletzone = v_strWarehouseNo, wp.customid = v_strOwnerNo
         WHERE wp.palletzone = a.palletzone
           and wp.customid = a.customid
           and wp.sheetid = a.sheetid
           and (exists (select '1'
                          from WMS_RATIONNOTE@zdmwms_jk wr
                         where wp.sheetid = wr.refsheetid
                           and wp.type = '1') or (wp.type = '0'));
        for bm in (select wp.*
                   --,
                   --              ROW_NUMBER() OVER(PARTITION BY wp.SHEETID ORDER BY wp.GOODSID) SHEET_ROWNUM
                     from WMS_PURCHASE@zdmwms_jk wp
                    where wp.palletzone = v_strWarehouseNo
                      and wp.customid = v_strOwnerNo
                      and wp.sheetid = a.sheetid) loop
          begin

            if bm.type = '0' then
              v_strPoType    := CONST_DOCUMENTTYPE.IDATAIMPORTIS;
              v_strClassType := '0';
              n_count_allot  := 0;
            elsif bm.type = '1' then
              v_strPoType    := CONST_DOCUMENTTYPE.IDATAIMPORTID;
              v_strClassType := '1';
              n_count_allot  := 1; --表示是直接型，要写配量表。
            end if;
            --查找进货单号
            select nvl(max(iim.import_no), 'N')
              into v_strImportNo
              from idata_import_m iim
             where upper(iim.po_no) = upper(bm.sheetid)
               and iim.warehouse_no = v_strWarehouseNo
               and iim.owner_no = v_strOwnerNo;
            --判断进货单号是否存在
            if v_strImportNo = 'N' then
              --获取WMS进货单号
              PKLG_WMS_BASE.p_getsheetno(a.enterprise_no,
                                         v_strWarehouseNo,
                                         v_strPoType,
                                         v_strImportNo,
                                         OUTMSG);
              --写进货单头档
              insert into idata_import_m
                (warehouse_no,
                 owner_no,
                 import_type,
                 import_no,
                 po_type,
                 po_no,
                 supplier_no,
                 order_date,
                 request_date,
                 status,
                 create_flag,
                 import_remark,
                 end_date,
                 class_type,
                 order_end_date,
                 rgst_name,
                 rgst_date,
                 org_no)
              values
                (v_strWarehouseNo,
                 v_strOwnerNo,
                 v_strPoType,
                 v_strImportNo,
                 v_strPoType,
                 bm.sheetid,
                 bm.venderid,
                 case when bm.sdate is null then sysdate else bm.sdate end,
                 case when bm.purdate is null then sysdate else bm.purdate end,
                 '10',
                 '1',
                 case when bm.notes is null then 'N' else bm.notes end,
                 case when bm.validdate is null then 7 else
                 (select TRUNC(BM.validdate) - TRUNC(SYSDATE) from DUAL) end,
                 '1',
                 case when bm.validdate is null then
                 (select SYSDATE + 3 from DUAL a) else bm.validdate end,
                 'admin_interface',
                 sysdate,
                 v_orgNo);
            end if;

            --写进货单明细
            insert into idata_import_d
              (warehouse_no,
               owner_no,
               import_no,
               article_no,
               packing_qty,
               po_qty,
               import_qty,
               po_id,
               status)
            values
              (v_strWarehouseNo,
               v_strOwnerNo,
               v_strImportNo,
               bm.goodsid,
               bm.pkcount,
               bm.qty,
               0,
               bm.serialid,
               '10');

            insert into Idata_import_Lot
              (Warehouse_No,
               Owner_No,
               Import_No,
               Po_No,
               Article_No,
               Lot_No,
               Qty,
               Remark)
            values
              (v_strWarehouseNo,
               v_strOwnerNo,
               v_strImportNo,
               bm.sheetid,
               bm.goodsid,
               '0',
               bm.qty,
               bm.notes);

            if v_strPoType = CONST_DOCUMENTTYPE.IDATAIMPORTID and
               n_count_allot > 0 then
              --增加是不是写配量数据的判断
              --锁数据
              update wMS_RATIONNOTE@zdmwms_jk h
                 set h.customid = bm.customid
               where h.customid = a.customid
                    --and bm.type='1'
                 and h.palletzone = bm.palletzone
                 and h.refsheetid = bm.sheetid;
              --写进货直通配量
              insert into idata_import_allot
                (warehouse_no,
                 owner_no,
                 import_no,
                 article_no,
                 packing_qty,
                 po_qty,
                 allot_qty,
                 status,
                 sub_cust_no,
                 cust_no,
                 rgst_name,
                 rgst_date,
                 po_no)
                select v_strWarehouseNo,
                       v_strOwnerNo,
                       v_strImportNo,
                       h.goodsid,
                       h.pkcount,
                       h.planqty,
                       0,
                       '10',
                       h.shopid,
                       h.shopid,
                       'admin_interface',
                       sysdate,
                       h.sheetid
                  from wMS_RATIONNOTE@zdmwms_jk h
                 where h.customid = bm.customid
                   and h.palletzone = bm.palletzone
                   and h.refsheetid = bm.sheetid
                   and h.goodsid = bm.goodsid;
              --and h.pkcount=bm.pkcount
              --and bm.type='1';

            end if;
          end;
        end loop;
        --转历史，删除已经处理的数据
        insert into WMS_PURCHASEBAK@zdmwms_jk
          select *
            from WMS_PURCHASE@zdmwms_jk h
           where h.customid = v_strOwnerNo
             and h.palletzone = v_strWarehouseNo
             and h.refsheetid = a.sheetid;
        delete from WMS_PURCHASE@zdmwms_jk h
         where h.customid = v_strOwnerNo
           and h.palletzone = v_strWarehouseNo
           and h.refsheetid = a.sheetid;
        --转历史，删除已经处理的数据
        insert into WMS_RATIONNOTEBAK@zdmwms_jk
          select *
            from wMS_RATIONNOTE@zdmwms_jk h
           where h.customid = v_strOwnerNo
             and h.palletzone = v_strWarehouseNo
             and h.refsheetid = a.sheetid;
        delete from wMS_RATIONNOTE@zdmwms_jk h
         where h.customid = v_strOwnerNo
           and h.palletzone = v_strWarehouseNo
           and h.refsheetid = a.sheetid;
        commit;
      end if;
      <<nest>>
      null;
    end loop;
  exception
    when others then
      rollback;
      OUTMSG := 'O| ' || SQLERRM ||
                substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_IDATA_IMPORT_DOWN_t;

  /*****************************************************************************************
   功能：接口，接收出货手建单
  Modify By hcx AT 2016-02-29
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure P_ODATA_EXP_DOWN_t(OUTMSG out varchar2) is
    /*    OUTMSG           varchar2(300);
    */
    v_strWarehouseNo varchar2(5); --仓别
    v_strOwnerNo     varchar2(3); --货主
    v_strExpNo       odata_exp_m.exp_no%type; --出货单号
    v_expType        odata_exp_m.exp_type%type; --单据类型
    ncount           number(2); --用来判断是不是有插入的数据，如果没有，就不转历。
    v_orgNo          odata_exp_m.Org_No%type; --机构号
  begin
    for a in (select distinct '8888' as enterprise_no,
                              palletzone,
                              customid,
                              shop_no,
                              sheetid
                from WMS_RATIONNOTE@zdmwms_jk) loop
      --取wms仓别
      P_WAREHOUSENO_GET(a.enterprise_no,
                                  a.palletzone,
                                  v_strWarehouseNo,
                                  OUTMSG);
      if v_strWarehouseNo is null then
        goto nest;
      end if;
      --取wms机构
      P_ORG_GET(a.enterprise_no, a.shop_no, v_orgNo, OUTMSG);
      if v_orgNo is null then
        goto nest;
      end if;
      --取wms货主
      P_OWNERNO_GET(a.enterprise_no,
                              a.customid,
                              v_strOwnerNo,
                              OUTMSG);
      if v_strOwnerNo is null then
        goto nest;
      end if;
      --锁数据,直通单不用写出货表数据
      ncount := 0;
      update WMS_RATIONNOTE@zdmwms_jk b
         set b.palletzone = v_strWarehouseNo, b.customid = v_strOwnerNo
       WHERE b.palletzone = a.palletzone
         and b.customid = a.customid
         and b.sheetid = a.sheetid
         and nvl(b.refsheetid, 'N') in ('N');

      for bm in (select distinct sheetid,
                                 customid,
                                 palletzone,
                                 shopid,
                                 type,
                                 shop_no,
                                 sdate,
                                 notes
                   from WMS_RATIONNOTE@zdmwms_jk m
                  where m.palletzone = v_strWarehouseNo
                    and m.customid = v_strOwnerNo
                    and m.sheetid = a.sheetid) loop
        begin

          ncount    := 1;
          v_expType := CONST_DOCUMENTTYPE.ODATAOE;
          --查找出货单号
          select nvl(max(oem.exp_no), null)
            into v_strExpNo
            from odata_exp_m oem
           where oem.sourceexp_no = bm.sheetid
             and oem.warehouse_no = v_strWarehouseNo
             and oem.owner_no = v_strOwnerNo;
          --判断出货单号是否存在
          if v_strExpNo is null then
            --获取WMS出货单号
            PKLG_WMS_BASE.p_getsheetno('8888',
                                       v_strWarehouseNo,
                                       v_expType,
                                       v_strExpNo,
                                       OUTMSG);
            --写出货单头档
            insert into odata_exp_m
              (exp_type,
               warehouse_no,
               exp_no,
               owner_no,
               owner_cust_no,
               cust_no,
               sub_cust_no,
               sourceexp_type,
               sourceexp_no,
               fast_flag,
               status,
               create_flag,
               exp_date,
               exp_remark,
               rgst_name,
               rgst_date,
               org_no)
            values
              (v_expType,
               v_strWarehouseNo,
               v_strExpNo,
               v_strOwnerNo,
               bm.shopid,
               bm.shopid,
               bm.shopid,
               v_expType,
               bm.sheetid,
               bm.type,
               '10',
               '1',
               bm.sdate,
               bm.notes,
               'admin_interface',
               sysdate,
               v_orgNo);
            --写出货单明细
            insert into odata_exp_d
              (warehouse_no,
               owner_no,
               exp_no,
               ROW_ID,
               article_no,
               packing_qty,
               article_qty,
               unit_cost,
               owner_article_no,
               status,
               rgst_date,
               exp_date)
              select v_strWarehouseNo,
                     v_strOwnerNo,
                     v_strExpNo,
                     ROW_NUMBER() OVER(PARTITION BY wr.SHEETID ORDER BY wr.GOODSID) SHEET_ROWNUM,
                     bda.article_no,
                     wr.pkcount,
                     wr.planqty,
                     wr.cost,
                     bda.owner_article_no,
                     '10',
                     sysdate,
                     sysdate
                from wMS_RATIONNOTE@zdmwms_jk wr, bdef_defarticle bda
               where wr.sheetid = bm.sheetid
                 and wr.goodsid = bda.owner_article_no;

          end if;
        end;
      end loop;
      --转历史，删除已经处理的数据
      if ncount = 1 then
        insert into WMS_RATIONNOTEBAK@zdmwms_jk
          select *
            from wMS_RATIONNOTE@zdmwms_jk
           where palletzone = v_strWarehouseNo
             and customid = v_strOwnerNo;
        delete from wMS_RATIONNOTE@zdmwms_jk
         where palletzone = v_strWarehouseNo
           and customid = v_strOwnerNo;
        commit;
      end if;
      <<nest>>
      null;
    end loop;
  exception
    when others then
      rollback;
      OUTMSG := 'O| ' || SQLERRM ||
                substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_ODATA_EXP_DOWN_t;
  

end BR_WMS_JK;

/

