create package body        PKLG_ADJ is

/***********************************************************************************************************
创建人：luozhiling
创建时间：2014.12.30
功能说明：
*************************************************************************************************************/
  procedure P_SaveStockAdj(
         strEnterpriseNo      in        stock_adj_m.enterprise_no%type,
         strWareHouseNo       in        stock_adj_m.warehouse_no%type,
         strOwnerNo           in        stock_adj_m.owner_no%type,
         strAdjType           in        stock_adj_m.adj_type%type,
         strArticleNo         in        stock_adj_d.article_no%type,
         strBarcode           in        stock_adj_d.barcode%type,
         nPackingQty          in        stock_adj_d.packing_qty%type,
         dtProduceDate        in        stock_adj_d.produce_date%type,
         dtExpireDate         in        stock_adj_d.expire_date%type,
         strQuality           in        stock_adj_d.quality%type,
         strLotNo             in        stock_adj_d.lot_no%type,
         strRsvBatch1         in        stock_adj_d.rsv_batch1%type,
         strRsvBatch2         in        stock_adj_d.rsv_batch1%type,
         strRsvBatch3         in        stock_adj_d.rsv_batch1%type,
         strRsvBatch4         in        stock_adj_d.rsv_batch1%type,
         strRsvBatch5         in        stock_adj_d.rsv_batch1%type,
         strRsvBatch6         in        stock_adj_d.rsv_batch1%type,
         strRsvBatch7         in        stock_adj_d.rsv_batch1%type,
         strRsvBatch8         in        stock_adj_d.rsv_batch1%type,
         strCellNo            in        stock_adj_d.cell_no%type,
         nPlanQty             in        stock_adj_d.plan_qty%type,
         strStockType         in        stock_adj_d.stock_type%type,
         strStockValue        in        stock_adj_d.stock_value%type,
         strLabelNo           in        stock_adj_d.label_no%type,
         strUserId            in        stock_adj_m.rgst_name%type,
         strsAdjNo            in        stock_adj_m.adj_no%type,--
         strAdjNo             out        stock_adj_m.adj_no%type,--
         strResult            out       varchar2) is

      v_strAdjNo   stock_adj_m.adj_no%type;
      cursor v_GetStockInf is
        select sai.import_batch_no,sai.barcode,sai.produce_date,sai.expire_date,sai.lot_no,sai.rsv_batch1,sai.rsv_batch2,sai.rsv_batch3,
               sai.rsv_batch4,sai.rsv_batch5,sai.rsv_batch6,sai.rsv_batch7,sai.rsv_batch8,sc.*
               from stock_content sc,stock_article_info sai where sc.enterprise_no=strEnterpriseNo
                and sc.warehouse_no=strWareHouseNo and  sc.enterprise_no= sai.enterprise_no
                and sc.article_no=sai.article_no and sc.article_id=sai.article_id and sai.article_no=strArticleNo
                and sc.packing_qty=nPackingQTY and sai.produce_date=dtProduceDate and sai.expire_date=dtExPireDate
                and sc.stock_type=strStockType and sc.stock_value=strStockVAlue and sai.rsv_batch1=strRsvBatch1
                and sai.rsv_batch2=strRsvBatch2 and sai.rsv_batch3=strRsvBatch3 and sai.rsv_batch3=strRsvBatch3
                and sai.rsv_batch4=strRsvBatch4 and sai.rsv_batch5=strRsvBatch5 and sai.rsv_batch6=strRsvBatch6
                and sai.rsv_batch7=strRsvBatch7 and sai.rsv_batch8=strRsvBatch8 and sc.label_no=strLabelNo
                and sc.qty-sc.outstock_qty>0 and sai.lot_no=strLotNo
                and sc.cell_no=strCellNo order by sai.import_batch_no;
       RemainQty       stock_adj_d.plan_qty%type;--剩余计划调整量
       ncurQty          stock_adj_d.plan_qty%type;--当前调整数量
       iCount           integer;
  begin
       strResult:='N|[P_SaveStockAdj]';
        RemainQty:=nPlanQty;
        ncurQty:=0;
       iCount:=0;


      if strsAdjNo = 'N' then
        --写虚拟移库头档
        pkobj_adj.p_InsertStockAdj_m(strEnterpriseNo,strWareHouseNo,strOwnerNo,strAdjType,strUserId,v_strAdjNo,strResult);
        if substr(strResult, 1, 1) = 'N' then
          return;
        end if;
        strAdjNo := v_strAdjNo;
      else
        v_strAdjNo := strsAdjNo;
        strAdjNo   := strsAdjNo;
      end if;

      if nPlanQty>0 then
         --写虚拟移库单明细
         pkobj_adj.P_insertStockAdj_d(strEnterpriseNo,strWareHouseNo,strOwnerNo,strAdjType,v_strAdjNo,strArticleNo,-1,
                   nPackingQty,dtProduceDate,dtExpireDate,strQuality,strLotNo,strRsvBatch1,strRsvBatch2,strRsvBatch3,
                   strRsvBatch4,strRsvBatch5,strRsvBatch6,strRsvBatch7,strRsvBatch8,strCellNo,nPlanQty,0,
                   strBarcode,strStockType,strStockValue,strLabelNo,strResult);
         if substr(strResult, 1, 1) = 'N' then
            return;
         end if;
      end if;

      if nPlanQty<0 THEN

          --写虚拟明细
          for GetStockContent in v_GetStockInf loop
             iCount:=iCount+1;
             if -RemainQty>=GetStockContent.qty-GetStockContent.outstock_qty then
                ncurQty:=-GetStockContent.qty+GetStockContent.outstock_qty;
             else
                ncurQty:=RemainQty;
             end if;
             RemainQty:=RemainQty-ncurQty;

             --写虚拟移库单明细

             pkobj_adj.P_insertStockAdj_d(strEnterpriseNo,strWareHouseNo,strOwnerNo,strAdjType,v_strAdjNo,strArticleNo,GetStockContent.article_id,
                       nPackingQty,dtProduceDate,dtExpireDate,strQuality,strLotNo,strRsvBatch1,strRsvBatch2,strRsvBatch3,
                       strRsvBatch4,strRsvBatch5,strRsvBatch6,strRsvBatch7,strRsvBatch8,strCellNo,ncurQty,0,
                       GetStockContent.barcode,strStockType,strStockValue,strLabelNo,strResult);
             if substr(strResult, 1, 1) = 'N' then
                return;
             end if;

             if RemainQty=0 then
                exit;
             end if;
          end loop;
      end if;

      strResult:='Y|[成功]';
  end P_SaveStockAdj;


  procedure P_ComfireAdj(
           strEnterpriseNo      in        stock_adj_d.enterprise_no%type,
           strWareHouseNo         in          stock_adj_d.warehouse_no%type,
           strOwnerNo                           in          stock_adj_m.owner_no%type,
           strAdjNo                             in          stock_adj_m.adj_no%type,
           strUserId                            in          stock_adj_m.rgst_name%type,
           strResult                            out         varchar2)is
      v_nCellID                  stock_content.cell_id%type;
      n_VScell_No  stock_content.cell_no%type; --库存调账虚拟区储位
      v_nArticleId stock_content.article_id%type;
      v_price      stock_article_info.price%type;
  begin
       strResult:='N|[P_ComfireAdj]';

  -------------------------获取虚拟区储位----------------------------------------
       begin
        select CDC.CELL_NO into n_VScell_No
          FROM cdef_defarea CDA, cdef_defcell CDC
         WHERE CDA.ENTERPRISE_NO = CDC.ENTERPRISE_NO
           AND CDA.warehouse_no = CDC.warehouse_no
           AND CDA.WARE_NO = CDC.WARE_NO
           AND CDA.AREA_NO = CDC.AREA_NO
           AND CDA.AREA_ATTRIBUTE = '4'
          AND CDA.ATTRIBUTE_TYPE = '0'
           AND CDC.CELL_STATUS = '0'
           AND CDC.CHECK_STATUS = '0'
           AND CDA.ENTERPRISE_NO=strEnterpriseNo
           AND CDC.warehouse_no =strWareHouseNo
           and rownum=1
         ORDER BY CDA.ATTRIBUTE_TYPE DESC, CDC.cell_no ;
      exception
        when no_data_found then
          strResult := 'N|[E28008]';
          return;
      end;

       for GetAdjItem in (select * from stock_adj_d where enterprise_no=strEnterpriseNo and warehouse_no=strWareHouseNo and adj_no=strAdjNo
           and status='10') loop
           --

           --更新虚拟移库单
           pkobj_adj.P_UpdateStockAdj_d(strEnterpriseNo,strWareHouseNo,strOwnerNo,strAdjNo,GetAdjItem.row_id,GetAdjItem.plan_qty,strResult);
            if (substr(strResult, 1, 1) <> 'Y') then
              return;
            end if;

           if GetAdjItem.plan_qty>0 then --增加来源储位库存，虚拟区增加负库存

             --取该商品在商品属性表id最大的单价,没有则给0
               begin
                select info.price into v_price from stock_article_info info where info.enterprise_no=strEnterPriseNo
                   and info.article_no=GetAdjItem.article_no and info.article_id=(select distinct max(article_id)
                     from stock_article_info where article_no=GetAdjItem.article_no and enterprise_no=strEnterPriseNo);
               exception
               when no_data_found then
                 v_price := 0;
               end;
              --获取商品属性ID
              PKLG_WMS_BASE.p_getArticleID(GetAdjItem.enterprise_no,
                                           GetAdjItem.article_no,
                                           GetAdjItem.barcode,
                                           GetAdjItem.lot_no,
                                           GetAdjItem.Produce_Date,
                                           GetAdjItem.expire_date,
                                           GetAdjItem.quality,
                                           GetAdjItem.rsv_batch1,
                                           GetAdjItem.rsv_batch2,
                                           GetAdjItem.rsv_batch3,
                                           GetAdjItem.rsv_batch4,
                                           GetAdjItem.rsv_batch5,
                                           GetAdjItem.rsv_batch6,
                                           GetAdjItem.rsv_batch7,GetAdjItem.rsv_batch8,
                                           strAdjNo,
                                           '0',
                                           strUserId,v_price,
                                           v_nArticleId,
                                           strResult);

              if (substr(strResult, 1, 1) <> 'Y') then
                return;
              end if;
              --更新来源储位库存

              PKobj_stock.p_InstContent_qtyByCellNo(strEnterpriseNo,
                                                    strWareHouseNo,
                                                    GetAdjItem.owner_no,
                                                    'N',
                                                    GetAdjItem.article_no,
                                                    v_nArticleId,
                                                    GetAdjItem.cell_no,
                                                    GetAdjItem.cell_no,
                                                    GetAdjItem.packing_qty,
                                                    GetAdjItem.plan_qty,
                                                    GetAdjItem.label_no,
                                                    GetAdjItem.label_no,
                                                    GetAdjItem.stock_type,
                                                    GetAdjItem.stock_value,
                                                    strUserId,
                                                    strAdjNo,
                                                    '1',
                                                    '1',
                                                    v_nCellID,
                                                    strResult);
              if (substr(strResult, 1, 1) <> 'Y') then
                return;
              end if;

            --虚拟区增加负库存

              PKobj_stock.p_InstContent_qtyByCellNo(strEnterpriseNo,
                                                    strWareHouseNo,
                                                    GetAdjItem.owner_no,
                                                    'N',
                                                    GetAdjItem.article_no,
                                                    v_nArticleId,
                                                    n_VScell_No,
                                                    n_VScell_No,
                                                    GetAdjItem.packing_qty,
                                                    -GetAdjItem.plan_qty,
                                                    GetAdjItem.label_no,
                                                    GetAdjItem.label_no,
                                                    GetAdjItem.stock_type,
                                                    GetAdjItem.stock_value,
                                                    strUserId,
                                                    strAdjNo,
                                                    '1',
                                                    '1',
                                                    v_nCellID,
                                                    strResult);
              if (substr(strResult, 1, 1) <> 'Y') then
                return;
              end if;

              --储位库存盘盈

           end if;

           if GetAdjItem.plan_qty<0 then
              --扣减源储位库存，增加虚拟储位库存
              PKobj_stock.p_UpdtContent_qtyByCellNo(strEnterpriseNo,
                                                    strWareHouseNo,
                                                    GetAdjItem.owner_no,
                                                    GetAdjItem.article_no,
                                                    GetAdjItem.article_id,
                                                    GetAdjItem.cell_no,
                                                    GetAdjItem.cell_no,
                                                    GetAdjItem.packing_qty,
                                                    -GetAdjItem.plan_qty,
                                                    GetAdjItem.label_no,
                                                    GetAdjItem.stock_type,
                                                    GetAdjItem.stock_value,
                                                    strUserId,
                                                    strAdjNo,
                                                    '1',
                                                    strResult);

              if (substr(strResult, 1, 1) <> 'Y') then
                return;
              end if;


              --新增虚拟储位库存
              PKobj_stock.p_InstContent_qtyByCellNo( GetAdjItem.enterprise_no,--企业
                                              GetAdjItem.warehouse_no, --仓别
                                              GetAdjItem.Owner_No, --委托业主
                                              'N',
                                              GetAdjItem.Article_No, --商品编号
                                              GetAdjItem.Article_Id, --商品属性ID
                                              n_VScell_No, --储位
                                              n_VScell_No, --关系储位
                                              GetAdjItem.Packing_Qty, --商品包装
                                              -GetAdjItem.plan_qty, --数量
                                              GetAdjItem.Label_no, --标签号
                                              GetAdjItem.Label_no, --标签号
                                              GetAdjItem.Stock_Type, --存储类型
                                              GetAdjItem.stock_value, --对应存储值
                                              strUserId, --操作人员
                                              strAdjNo, --操作单号
                                              '1', --操作设备
                                              '1', --是否可手工移库 0:不允许手工移库；1：可手工移库
                                              v_nCellID,
                                              strResult); --返回 执行结果
              if (substr(strResult, 1, 1) <> 'Y') then
                return;
              end if;
           end if;
       end loop;

       pkobj_adj.P_UpdateStockAdj_m(strEnterpriseNo,strWareHouseNo,strOwnerNo,strAdjNo,strUserId,strResult);

        if (substr(strResult, 1, 1) <> 'Y') then
          return;
        end if;
       strResult:='Y|[成功]';
  end P_ComfireAdj;

  /*************************************************************************************
   创建人：huangsq
   创建时间:2015.7.20
   功能说明：更新品质转换单
  ****************************************************************************************/
  procedure P_Comfire_QU_Change(
           strEnterpriseNo      in          ORG_QUALITY_CHANGE_D.enterprise_no%type,
           strWareHouseNo       in          ORG_QUALITY_CHANGE_D.warehouse_no%type,
           strOwnerNo           in          ORG_QUALITY_CHANGE_D.owner_no%type,
           strChange_No         in          ORG_QUALITY_CHANGE_D.Change_No%type,
           strArticleNo         in          ORG_QUALITY_CHANGE_D.article_no%type,
           nRealQty             in          ORG_QUALITY_CHANGE_d.real_qty%type,
           nRow_ID              in          ORG_QUALITY_CHANGE_D.ROW_ID%type,
           strUserId            in          ORG_QUALITY_CHANGE_M.rgst_name%type,
           strResult            out         varchar2)is
  nCount             number;
  begin
       strResult:='N|[P_Comfire_QU_Change]';

       --更新品质转换单
       /*****************20160606 wyf 添加ROW_ID条件**********************/
       pkobj_adj.P_Update_QUALITY_CHANGE_d(strEnterpriseNo,strWareHouseNo,strOwnerNo,strChange_No,strArticleNo,
       nRealQty,nRow_ID,strResult);
        if (substr(strResult, 1, 1) <> 'Y') then
          return;
        end if;

       --判断明细表是不是全部更新完成
       select count(*) into nCount from ORG_QUALITY_CHANGE_d t
        where t.enterprise_no=strEnterpriseNo and t.warehouse_no=strWareHouseNo and t.owner_no=strOwnerNo and t.change_no=strChange_No
             and t.status='10';
       if nCount<=0 then
           pkobj_adj.P_Update_QUALITY_CHANGE_m(strEnterpriseNo,strWareHouseNo,strOwnerNo,strChange_No,strUserId,strResult);
            if (substr(strResult, 1, 1) <> 'Y') then
              return;
            end if;
        end if ;
       strResult:='Y|[成功]';
  end P_Comfire_QU_Change;
  /*********************************************************************************************888
   功能说明：建立库存调整计划单
   2015.7.24
  *****************************************************************************************************/
  procedure P_saveStockPlan(strEnterpriseNo      in        stock_adj_m.enterprise_no%type,
         strWareHouseNo       in        stock_plan_d.warehouse_no%type,
         strOwnerNo           in        stock_plan_d.owner_no%type,
         strPlanType          in        stock_plan_m.plan_type%type,
         strPoNo              in        stock_plan_m.po_no%type,
         strArticleNo         in        stock_plan_d.article_no%type,
         nPackingQty          in        stock_plan_d.packing_qty%type,
         dtProduceDate        in        stock_plan_d.produce_date%type,
         dtExpireDate         in        stock_plan_d.expire_date%type,
         strQuality           in        stock_plan_d.quality%type,
         strLotNo             in        stock_plan_d.lot_no%type,
         strImportBatchNo     in        stock_plan_d.import_batch_no%type,
         strRsvBatch1         in        stock_plan_d.rsv_batch1%type,
         strRsvBatch2         in        stock_plan_d.rsv_batch1%type,
         strRsvBatch3         in        stock_plan_d.rsv_batch1%type,
         strRsvBatch4         in        stock_plan_d.rsv_batch1%type,
         strRsvBatch5         in        stock_plan_d.rsv_batch1%type,
         strRsvBatch6         in        stock_plan_d.rsv_batch1%type,
         strRsvBatch7         in        stock_plan_d.rsv_batch1%type,
         strRsvBatch8         in        stock_plan_d.rsv_batch1%type,
         strCellNo            in        stock_plan_d.cell_no%type,
         nPlanQty             in        stock_plan_d.plan_qty%type,
         strStockType         in        stock_plan_d.stock_type%type,
         strStockValue        in        stock_plan_d.stock_value%type,
         strLabelNo           in        stock_plan_d.label_no%type,
         strUserId            in        stock_plan_d.rgst_name%type,
         strCreateFlag        in        stock_plan_m.create_flag%type,--1:下传，0：自建
         strOrgNo             in        stock_plan_m.org_no%type,--机构代码
         strsPlanNo           in        stock_plan_d.plan_no%type,--
         strsRemark           in        stock_plan_m.remark%type,
         strPlanNo            out       stock_plan_d.plan_no%type,--
         strResult            out       varchar2) is
    v_strPlanNo               stock_plan_m.plan_no%type;
  begin
      strResult:='N|[P_saveStockPlan]';

      if strsPlanNo = 'N' then
        --写虚拟移库头档
        pkobj_adj.P_InsertStockPlan_m(strEnterpriseNo,strWareHouseNo,strOwnerNo,strPlanType,strPoNo,
             strCreateFlag,strOrgNo,strUserId,strsRemark,v_strPlanNo,strResult);
        if substr(strResult, 1, 1) = 'N' then
          return;
        end if;
        strPlanNo := v_strPlanNo;
      else
        v_strPlanNo := strsPlanNo;
        strPlanNo   := strsPlanNo;
      end if;

      pkobj_adj.P_InsertStockPlan_d(strEnterpriseNo,strWareHouseNo,strOwnerNo,v_strPlanNo,strArticleNo,
             nPackingQty,dtProduceDate,dtExpireDate,strQuality,strLotNo,strImportBatchNo,strRsvBatch1,
             strRsvBatch2,strRsvBatch3,strRsvBatch4,strRsvBatch5,strRsvBatch6,strRsvBatch7,strRsvBatch8,
             strCellNo,nPlanQty,strStockType,strStockValue,strLabelNo,strUserID,strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;

      strResult:='Y|[]';
  end P_saveStockPlan;
/*******************************************************************************************************
 创建人：luozhiling
 时间:2016.3.14
 功能：库存调账计划单取消
********************************************************************************************************/
  procedure P_PlanCancel(strEnterPriseNo           in    stock_plan_d.enterprise_no%type,
                         strWareHouseNo            in    stock_plan_d.warehouse_no%type,--仓库编码
                         strOwnerNo                in    stock_plan_m.owner_no%type,
                         strPlanNo                 in   stock_plan_d.plan_no%type,--移库计划头档
                         strUserId                 in   stock_plan_d.rgst_name%type,
                         strResult                 OUT    varchar2)is
      v_strStatus        stock_plan_m.status%type;
  begin
       strResult:='N|[P_PlanCancel]';

       update stock_plan_m  set status=status
       where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo
            and owner_no=strOwnerNo and plan_no=strPlanNo;

       if sql%notfound then
           strResult:='N|[找不到对应的计划单]';
           return;
       end if;

        select status into v_strStatus from stock_plan_m
        where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo
        and owner_no=strOwnerNo and plan_no=strPlanNo;

        if v_strStatus<>'10' then
           strResult:='N|[已进行过定位的单，不可取消]';
           return;
        end if;

       update stock_plan_m t set t.status='16',t.updt_name=strUserId,t.updt_date=sysdate
       where t.enterprise_no=strEnterPriseNo
       and t.warehouse_no=strWareHouseNo
        and t.owner_no=strOwnerNo and t.plan_no=strPlanNo;

        update stock_plan_d  set status='16'
        where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo
            and owner_no=strOwnerNo and plan_no=strPlanNo;

       strResult:='Y|[]';
  end P_PlanCancel;
 /*****************************************************************************************************
   创建人：luozhiling
   时间：2015.7.24
   功能: 库存调账定位找库存

	 注：strCellNo允许传N，传N则改用计划表明细的CellNO字段 update by sunl 2016年8月1日
 ****************************************************************************************************/
  procedure P_StockPlanfoundStock(strEnterPriseNo           in    stock_plan_d.enterprise_no%type,
                                 strWareHouseNo            in    stock_plan_d.warehouse_no%type,--仓库编码
                                 strOwnerNo                in    stock_plan_m.owner_no%type,
                                 strPlanNo                 in   stock_plan_d.plan_no%type,--移库计划头档
                                 strCellNo                 in   stock_plan_d.cell_no%type,
                                 strUserId                 in   stock_plan_d.rgst_name%type,
                                 strResult                 OUT    varchar2)is
      icount                     integer;
      v_strConfirmNo             stock_confirm_d.confirm_no%type;
      v_nArticleId               stock_article_info.article_id%type;
      RemainQty                  stock_adj_d.plan_qty%type;--剩余计划调整量
      ncurQty                    stock_adj_d.plan_qty%type;--当前调整数量
      v_strShortQtyAdj         WMS_DEFBASE.Sdefine%type; --参数的字符性值
      v_nShortQtyAdj         WMS_DEFBASE.Ndefine%type; --参数的整数值
      v_iCount               integer;
      v_price                stock_article_info.price%type;

			V_recordCount          INTEGER;--记录数
			V_CellNo               stock_plan_d.cell_no%TYPE;--当前使用货位
  begin
       strResult:='N|[P_StockPlanfoundStock]';

       --锁定调账计划单
       update stock_plan_m t set t.status=status where t.enterprise_no=strEnterPriseNo
       and t.warehouse_no=strWareHouseNo and t.plan_no=strPlanNo;

       --写库存调整确认单头档；

        pkobj_adj.P_InsertStockConfirmHead(strEnterpriseNo,strWareHouseNo,strOwnerNo,strPlanNo,strUserId,
           v_strConfirmNo,strResult);
        if substr(strResult, 1, 1) = 'N' then
          return;
        end if;

       for GetStockPlanInf in (select m.org_no,t.row_id,t.article_no,t.packing_qty,
           nvl(t.produce_date,to_date('19000101','yyyymmdd')) produce_date,
           nvl(t.expire_date,to_date('19000101','yyyymmdd')) expire_date,nvl(t.quality,'0') quality,
           nvl(t.lot_no,'N') lot_no,strPlanNo,
           nvl(t.rsv_batch1,'N') rsv_batch1,nvl(t.rsv_batch2,'N') rsv_batch2,nvl(t.rsv_batch3,'N') rsv_batch3,
           nvl(t.rsv_batch4,'N') rsv_batch4,nvl(t.rsv_batch5,'N') rsv_batch5,nvl(t.rsv_batch6,'N')  rsv_batch6,
           nvl(t.rsv_batch7,'N') rsv_batch7,nvl(t.rsv_batch8,'N') rsv_batch8,t.plan_qty,
           t.stock_type,t.stock_value,nvl(t.label_no,'N') label_no,bd.barcode,t.cell_no
        from stock_plan_d t,stock_plan_m m ,bdef_defarticle bd
           where t.enterprise_no=m.enterprise_no and t.warehouse_no=m.warehouse_no
           and t.enterprise_no=bd.enterprise_no and t.article_no=bd.article_no
           and t.plan_no=m.plan_no and t.enterprise_no=strEnterPriseNo
           and t.warehouse_no=strWareHouseNo and t.plan_no=strPlanNo and t.status='10' order by t.article_no ) loop

				  --add by sunl 2016年8月1日
					if(strCellNo = 'N') THEN

						IF(GetStockPlanInf.Cell_No IS NULL OR GetStockPlanInf.Cell_No = '') THEN
								strResult := 'N|货位不能为空！';
								RETURN;
						ELSE
              if GetStockPlanInf.plan_qty<0 then --扣库存
                V_recordCount := 0;
                --校验当前的储位是否有当前的商品,且该商品是否有库存
                SELECT COUNT(0) INTO V_recordCount FROM stock_content t
                where t.enterprise_no=strEnterPriseNo and t.article_no=GetStockPlanInf.article_no
               /* and t.packing_qty=GetStockPlanInf.packing_qty*/ AND t.cell_no = GetStockPlanInf.Cell_No
                AND t.qty-t.outstock_qty>0 ;

                IF(V_recordCount = 0) THEN
                  strResult := 'N|货位' || GetStockPlanInf.Cell_No || '上不存在品项' || GetStockPlanInf.article_no || '的库存信息。';
                  RETURN;
                END IF;
              end if;
              V_CellNo := GetStockPlanInf.Cell_No;--取明细的货位
						END IF;
					ELSE
						V_CellNo := strCellNo; --取前台传的货位
				  END IF;

					--锁定此商品的库存
          update stock_content set status=status
            where enterprise_no=strEnterPriseNo and article_no=GetStockPlanInf.article_no
            and packing_qty=GetStockPlanInf.packing_qty;


          if GetStockPlanInf.plan_qty>0 then --新增库存

              --取该商品在商品属性表id最大的单价,没有取到则给0
             begin
               select info.price into v_price from stock_article_info info where info.enterprise_no=strEnterPriseNo
                and info.article_no=GetStockPlanInf.article_no and info.article_id=(select distinct max(article_id)
                   from stock_article_info where article_no=GetStockPlanInf.article_no and enterprise_no=strEnterPriseNo);
             exception
             when no_data_found then
                v_price := 0;
             end;
             --产生新的商品属性ID
             --设置商品属性表
              pklg_wms_base.p_getArticleID(strEnterPriseNo,GetStockPlanInf.article_no,
                                           GetStockPlanInf.barcode,
                                           GetStockPlanInf.lot_no,
                                           GetStockPlanInf.produce_date,
                                           GetStockPlanInf.expire_date,
                                           GetStockPlanInf.quality,
                                           GetStockPlanInf.Rsv_Batch1,
                                           GetStockPlanInf.Rsv_Batch2,
                                           GetStockPlanInf.Rsv_Batch3,
                                           GetStockPlanInf.Rsv_Batch4,
                                           GetStockPlanInf.Rsv_Batch5,
                                           GetStockPlanInf.Rsv_Batch6,
                                           GetStockPlanInf.Rsv_Batch7,
                                           GetStockPlanInf.Rsv_Batch8,
                                           strPlanNo,
                                           '0',
                                           strUserId,v_price,
                                           v_nArticleId,
                                           strResult);
              if (substr(strResult, 1, 1) <> 'Y') then
                return;
              end if;

              Pkobj_Adj.P_InsertStockConfirmItem(strEnterpriseNo,strWareHouseNo,strOwnerNo,v_strConfirmNo,strPlanNo,
                 GetStockPlanInf.article_no,v_nArticleId,GetStockPlanInf.packing_qty,GetStockPlanInf.produce_date,
                 GetStockPlanInf.expire_date,GetStockPlanInf.quality,GetStockPlanInf.lot_no,strPlanNo,
                 GetStockPlanInf.rsv_batch1,GetStockPlanInf.rsv_batch2,GetStockPlanInf.rsv_batch3,GetStockPlanInf.rsv_batch4,
                 GetStockPlanInf.rsv_batch5,GetStockPlanInf.rsv_batch6,GetStockPlanInf.rsv_batch7,GetStockPlanInf.rsv_batch8,
                 V_CellNo
								 ,GetStockPlanInf.plan_qty,GetStockPlanInf.stock_type,
                 GetStockPlanInf.stock_value,GetStockPlanInf.label_no,strUserId, strResult);
              if (substr(strResult, 1, 1) <> 'Y') then
                return;
              end if;
          end if;

          if  GetStockPlanInf.plan_qty<0 then --减少WMS储位库存
              RemainQty:=GetStockPlanInf.plan_qty;

              --循环库存
              for GetStock in(select sc.*,sai.lot_no,sai.produce_date,sai.expire_date,
                 sai.quality,sai.import_batch_no,sai.rsv_batch1,sai.rsv_batch2,
                 sai.rsv_batch3,sai.rsv_batch4,sai.rsv_batch5,sai.rsv_batch6,sai.rsv_batch7,sai.rsv_batch8
                  from stock_content sc,stock_article_info sai,cdef_defcell cd
                 where sc.enterprise_no = sai.enterprise_no and sc.enterprise_no = cd.enterprise_no
                   and sc.enterprise_no = strEnterPriseNo and sc.warehouse_no = cd.warehouse_no
                   and sc.warehouse_no = strWareHouseNo
                   and sc.article_no = sai.article_no and sc.article_id = sai.article_id
                   and sc.cell_no = cd.cell_no
                   and (GetStockPlanInf.lot_no is null or
                       (GetStockPlanInf.lot_no is not null and sai.lot_no = GetStockPlanInf.lot_no))
                   and (GetStockPlanInf.quality is null or
                       (GetStockPlanInf.quality is not null and sai.quality = GetStockPlanInf.quality))
                   and (GetStockPlanInf.produce_date is null or
                       (GetStockPlanInf.produce_date is not null and sai.produce_date >= GetStockPlanInf.produce_date))
                   /*and (GetStockPlanInf.expire_date is null or
                       (GetStockPlanInf.expire_date is not null and sai.expire_date = GetStockPlanInf.expire_date))*/
                   and sc.cell_no=V_CellNo
                   and cd.cell_status <> '1'  and sc.qty - sc.outstock_qty > 0
                   and sc.stock_type = GetStockPlanInf.stock_type
                   and sc.stock_value = GetStockPlanInf.stock_value
                   and sc.article_no = GetStockPlanInf.article_no
                 order by sai.produce_date, sc.cell_no) loop

                 iCount:=iCount+1;
                 if -RemainQty>=GetStock.qty-GetStock.outstock_qty then
                    ncurQty:=-GetStock.qty+GetStock.outstock_qty;
                 else
                    ncurQty:=RemainQty;
                 end if;
                 RemainQty:=RemainQty-ncurQty;

                 --写库存调账确认明细

                Pkobj_Adj.P_InsertStockConfirmItem(strEnterpriseNo,strWareHouseNo,strOwnerNo,v_strConfirmNo,strPlanNo,
                   GetStock.article_no,GetStock.article_id,GetStock.packing_qty,GetStock.produce_date,
                   GetStock.expire_date,GetStock.quality,GetStock.lot_no,GetStock.import_batch_no,
                   GetStock.rsv_batch1,GetStock.rsv_batch2,GetStock.rsv_batch3,GetStock.rsv_batch4,
                   GetStock.rsv_batch5,GetStock.rsv_batch6,GetStock.rsv_batch7,GetStock.rsv_batch8,
                   V_CellNo
									 ,ncurQty,GetStock.stock_type,
                   GetStock.stock_value,GetStock.label_no,strUserId, strResult);
                if (substr(strResult, 1, 1) <> 'Y') then
                  return;
                end if;

                --更新调账计划单明细数量
                update stock_plan_d t set t.real_qty=t.real_qty+ncurQty
                where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo
                and t.article_no=GetStock.article_no and t.plan_no=strPlanNo
                and t.row_id=GetStockPlanInf.row_id;

                 if RemainQty=0 then
                    exit;
                 end if;
              end loop;
          end if;

          --更新调账计划单明细状态
          update stock_plan_d t set t.status='11' ,t.updt_name=strUserId,t.updt_date=sysdate
          where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo
          and t.plan_no=strPlanNo and t.row_id=GetStockPlanInf.row_id;

       end loop;

       --更新调账计划单明细状态
       update stock_plan_m t set t.status='11' ,t.updt_name=strUserId,t.updt_date=sysdate
          where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo
          and t.plan_no=strPlanNo;

      --读取系统参数判断是否需要做缺量处理
      PKLG_WMS_BASE.p_GetBasePara(strEnterpriseNo,
                                  strWareHouseNo,
                                  strOwnerNo,
                                  'ShortQtyAdj',
                                  'Adj',
                                  'ADJ_LOCATE',
                                  v_strShortQtyAdj,
                                  v_nShortQtyAdj,
                                  strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      if v_strShortQtyAdj='0' then --对于调亏的库存不允许缺量
         select count(*) into v_iCount from stock_plan_d t where t.enterprise_no=strEnterPriseNo
         and t.warehouse_no=strWareHouseNo and t.plan_no=strPlanNo and t.plan_qty<0
         and t.plan_qty<>t.real_qty;

         if v_iCount>0 then
            strResult:='N|[定位缺量，请检查库存]';
            return;
         end if;
      end if;
       strResult:='Y|[]';

  end P_StockPlanfoundStock;

  /******************************************************************************************************
  功能说明：库存调账单回单
  2015.7.25

  ******************************************************************************************************/
  procedure P_ComfireStockPlan(
           strEnterpriseNo      in        stock_confirm_m.enterprise_no%type,
           strWareHouseNo       in        stock_confirm_m.warehouse_no%type,
           strOwnerNo           in          stock_confirm_m.owner_no%type,
           strConfirmNo         in          stock_confirm_m.confirm_no%type,
           strUserId            in          stock_confirm_m.rgst_name%type,
           strDockNo            in          bdef_defdock.dock_no%type,
           strPrintFlag         in          stock_plan_m.plan_type%type,--是否打印，1-打印；0：不打印
           strResult            out         varchar2)is
      v_nCellID                  stock_content.cell_id%type;
      n_VScell_No  stock_content.cell_no%type; --库存调账虚拟区储位
      v_nArticleId stock_content.article_id%type;
     RemainQty       stock_confirm_d.real_Qty%type;--剩余计划调整量
     ncurQty          stock_confirm_d.real_Qty%type;--当前调整数量
     iCount           integer;
     v_strPlanNo      stock_plan_m.plan_no%type;
     v_PrintTaskNo    job_printtask_m.task_no%type;
  begin
       strResult:='N|[P_ComfireStockPlan]';

       for GetComfireItem in (select m.plan_no,bd.barcode,d.* from stock_confirm_d d,stock_confirm_m m,bdef_defarticle bd
           where m.enterprise_no=d.enterprise_no and m.warehouse_no=d.warehouse_no
           and m.enterprise_no=strEnterpriseNo and d.article_no=bd.article_no
           and m.warehouse_no=strWareHouseNo and m.confirm_no=strConfirmNo
           and m.confirm_no=d.confirm_no
           and m.status='10') loop
           --
           v_strPlanNo:=GetComfireItem.plan_no;
           --更新库存调账单
           pkobj_adj.P_updateStockConfirmItem(strEnterpriseNo,strWareHouseNo,strOwnerNo,strConfirmNo,
                  GetComfireItem.row_id,GetComfireItem.article_qty,strUserId,strResult);
           if (substr(strResult, 1, 1) <> 'Y') then
              return;
           end if;

           if GetComfireItem.article_qty>0 then --增加储位库存
              pkobj_stock.p_InstContent_qtyByCellNo(strEnterpriseNo,
                                                    strWareHouseNo,
                                                    GetComfireItem.owner_no,
                                                    'N',
                                                    GetComfireItem.article_no,
                                                    GetComfireItem.article_id,
                                                    GetComfireItem.cell_no,
                                                    GetComfireItem.cell_no,
                                                    GetComfireItem.packing_qty,
                                                    GetComfireItem.article_qty,
                                                    GetComfireItem.label_no,
                                                    GetComfireItem.label_no,
                                                    GetComfireItem.stock_type,
                                                    GetComfireItem.stock_value,
                                                    strUserId,
                                                    strConfirmNo,
                                                    '1',
                                                    '1',
                                                    v_nCellID,
                                                    strResult);
              if (substr(strResult, 1, 1) <> 'Y') then
                return;
              end if;

              --写商品批次库存帐
              pkobj_stock.P_insertImportBatchStock(strEnterPriseNo,strWareHouseNo,GetComfireItem.owner_no,'N',
                   GetComfireItem.article_no,GetComfireItem.quality,GetComfireItem.Import_Batch_No,GetComfireItem.produce_date,
                   GetComfireItem.expire_date,GetComfireItem.lot_no,GetComfireItem.rsv_batch1,GetComfireItem.rsv_batch2,
                   GetComfireItem.rsv_batch3,GetComfireItem.rsv_batch4,GetComfireItem.rsv_batch5,GetComfireItem.rsv_batch6,
                   GetComfireItem.rsv_batch7,GetComfireItem.rsv_batch8,GetComfireItem.barcode,GetComfireItem.packing_qty,
                   GetComfireItem.article_qty,GetComfireItem.stock_type,GetComfireItem.stock_value,strUserId,strResult);

              if (substr(strResult, 1, 1) = 'N') then
                return;
              end if;

              --写库存三级帐
              pkobj_stock.P_InsertArticleStockList(strEnterPriseNo,strWareHouseNo,GetComfireItem.owner_no,'N',
                   GetComfireItem.article_no,GetComfireItem.quality,GetComfireItem.produce_date,GetComfireItem.expire_date,
                   GetComfireItem.lot_no,GetComfireItem.rsv_batch1,GetComfireItem.rsv_batch2,GetComfireItem.rsv_batch3,
                   GetComfireItem.rsv_batch4,GetComfireItem.rsv_batch5,GetComfireItem.rsv_batch6,GetComfireItem.rsv_batch7,
                   GetComfireItem.rsv_batch8,GetComfireItem.barcode,GetComfireItem.packing_qty,GetComfireItem.article_qty,
                   GetComfireItem.stock_type,GetComfireItem.stock_value,1,CONST_DOCUMENTTYPE.STOCKPLAN,GetComfireItem.Source_No,
                   strUserId,GetComfireItem.Import_Batch_No,strResult);

              if (substr(strResult, 1, 1) = 'N') then
                return;
              end if;

           end if;

           if GetComfireItem.article_qty<0 then
              RemainQty:=GetComfireItem.article_qty;
              --循环扣减库存
              for GetStock in (select * from stock_content sc
                   where sc.enterprise_no = strEnterPriseNo and sc.warehouse_no = strWareHouseNo
                     and sc.article_no=GetComfireItem.article_no and sc.article_id = GetComfireItem.article_id
                     and sc.cell_no=GetComfireItem.cell_no
                     and sc.stock_type = GetComfireItem.stock_type
                     and sc.stock_value = GetComfireItem.stock_value
                     and sc.qty - sc.outstock_qty > 0) loop

                   iCount:=iCount+1;
                   if -RemainQty>=GetStock.qty-GetStock.outstock_qty then
                      ncurQty:=-GetStock.qty+GetStock.outstock_qty;
                   else
                      ncurQty:=RemainQty;
                   end if;
                   RemainQty:=RemainQty-ncurQty;

                    --扣减储位库存
                    PKobj_stock.p_UpdtContent_qtyByCellNo(strEnterpriseNo,
                                                          strWareHouseNo,
                                                          GetStock.owner_no,
                                                          GetStock.article_no,
                                                          GetStock.article_id,
                                                          GetStock.cell_no,
                                                          GetStock.cell_no,
                                                          GetStock.packing_qty,
                                                          -ncurQty,
                                                          GetStock.label_no,
                                                          GetStock.stock_type,
                                                          GetStock.stock_value,
                                                          strUserId,
                                                          strConfirmNo,
                                                          '1',
                                                          strResult);

                    if (substr(strResult, 1, 1) <> 'Y') then
                      return;
                    end if;


                     --写商品批次库存帐
                    pkobj_stock.P_insertImportBatchStock(strEnterPriseNo,strWareHouseNo,GetStock.owner_no,'N',
                         GetStock.article_no,GetComfireItem.quality,GetComfireItem.import_batch_no,GetComfireItem.produce_date,
                         GetComfireItem.expire_date,GetComfireItem.lot_no,GetComfireItem.rsv_batch1,GetComfireItem.rsv_batch2,
                         GetComfireItem.rsv_batch3,GetComfireItem.rsv_batch4,GetComfireItem.rsv_batch5,GetComfireItem.rsv_batch6,
                         GetComfireItem.rsv_batch7,GetComfireItem.rsv_batch8,GetComfireItem.barcode,GetComfireItem.packing_qty,
                         ncurQty,GetComfireItem.stock_type,GetComfireItem.stock_value,strUserId,strResult);

                    if (substr(strResult, 1, 1) = 'N') then
                      return;
                    end if;

                    --写库存三级帐
                    pkobj_stock.P_InsertArticleStockList(strEnterPriseNo,strWareHouseNo,GetStock.owner_no,'N',
                         GetStock.article_no,GetComfireItem.quality,GetComfireItem.produce_date,GetComfireItem.expire_date,
                         GetComfireItem.lot_no,GetComfireItem.rsv_batch1,GetComfireItem.rsv_batch2,GetComfireItem.rsv_batch3,
                         GetComfireItem.rsv_batch4,GetComfireItem.rsv_batch5,GetComfireItem.rsv_batch6,GetComfireItem.rsv_batch7,
                         GetComfireItem.rsv_batch8,GetComfireItem.barcode,GetComfireItem.packing_qty,ncurQty,
                         GetComfireItem.stock_type,GetComfireItem.stock_value,1,CONST_DOCUMENTTYPE.STOCKPLAN,GetComfireItem.Source_No,
                         strUserId,GetComfireItem.import_batch_no,strResult);

                    if (substr(strResult, 1, 1) = 'N') then
                      return;
                    end if;

                   if RemainQty=0 then
                      exit;
                   end if;
              end loop;
           end if;
       end loop;

      if strPrintFlag='1' then--写打印任务
            --写打印任务
          PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterPriseNo,strWareHouseNo,
                                              strConfirmNo,
                                              '0',
                                              CONST_REPORTID.rpt_stockConfirm,
                                              strDockNo,
                                              '0',
                                              strUserId,
                                              v_PrintTaskNo,
                                              strResult);

           if substr(strResult, 1, 1) <> 'Y' then
             strResult:='N|[写打印任务失败]';
             return;
           end if;
      end if;

       --更新库存调账单头档
       pkobj_adj.P_UpdateStockConfirmHead(strEnterpriseNo,strWareHouseNo,strOwnerNo,strConfirmNo,
              strUserId,strResult);
       if (substr(strResult, 1, 1) <> 'Y') then
          return;
       end if;

       --商品库存三级帐

       pkobj_adj.P_UpdateStockAdj_m(strEnterpriseNo,strWareHouseNo,strOwnerNo,strConfirmNo,strUserId,strResult);

        if (substr(strResult, 1, 1) <> 'Y') then
          return;
        end if;

        --更新调账单头档和明细状态

          update stock_plan_d t set t.status='13'
          where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo
          and t.plan_no=v_strPlanNo and t.status='11';

          update stock_plan_m t set t.status='13'
          where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo
          and t.plan_no=v_strPlanNo and t.status='11';

       strResult:='Y|[成功]';
  end P_ComfireStockPlan;

  /***********************************************************************************************
  功能：1、对库存调账单进行定位
        2、对库存调账单进行确认
        2015.9.9
  ***********************************************************************************************/
  procedure P_stockLocateComfire(strEnterPriseNo           in    stock_plan_d.enterprise_no%type,
                                 strWareHouseNo            in    stock_plan_d.warehouse_no%type,--仓库编码
                                 strOwnerNo                in    stock_plan_m.owner_no%type,
                                 strPlanNo                 in   stock_plan_d.plan_no%type,--移库计划头档
                                 strCellNo                 in   stock_plan_d.cell_no%type,
                                 strUserId                 in   stock_plan_d.rgst_name%type,
                                 strDockNo            in          bdef_defdock.dock_no%type,
                                 strPrintFlag         in          stock_plan_m.plan_type%type,--是否打印，1-打印；0：不打印
                                 strResult                 OUT    varchar2)is
       v_strComfireNo            stock_confirm_m.confirm_no%type;
  begin
       strResult:='N|[P_stockLocateComfire]';
       --对计划单进行定位

       P_StockPlanfoundStock(strEnterPriseNo,strWareHouseNo,strOwnerNo,strPlanNo,strCellNo,strUserId,strResult);
        if (substr(strResult, 1, 1) <> 'Y') then
          return;
        end if;
       --获取确认单；

       begin
            select t.confirm_no into v_strComfireNo from stock_confirm_m t where t.enterprise_no=strEnterPriseNo
            and t.warehouse_no=strWareHouseNo and t.plan_no=strPlanNo;
       exception when no_data_found then
            strResult:='N|[找不到对应的确认单]';
            return;
       end;

       P_ComfireStockPlan(strEnterpriseNo,strWareHouseNo,strOwnerNo,v_strComfireNo,strUserId,strDockNo,strPrintFlag,strResult);
        if (substr(strResult, 1, 1) <> 'Y') then
          return;
        end if;

       strResult:='Y|[]';
  end P_stockLocateComfire;

end PKLG_ADJ;

/

