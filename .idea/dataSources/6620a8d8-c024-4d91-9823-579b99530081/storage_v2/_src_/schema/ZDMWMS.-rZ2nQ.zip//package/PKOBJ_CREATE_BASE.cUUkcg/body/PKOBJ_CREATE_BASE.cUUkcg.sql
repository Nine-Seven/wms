create package body pkobj_Create_base is

  /**********************************************************************************************************
    csr
    2015.10.09
    功能：导入货主资料
  ***********************************************************************************************************/
  procedure p_insertOwner(strEnterpriseNo in tmp_formexcel_owner.enterprise_no%type,
                          strUserId       in bdef_defworker.worker_no%type,
                          strRowid        out tmp_formexcel_owner.row_id%type,
                          strOutMsg       out varchar2) is
    v_icount integer;
  begin
    strOutMsg := 'N|[p_insertOwner]';
    --锁表
    update tmp_formexcel_owner t
       set t.status = '11'
     where t.enterprise_no = strEnterpriseNo
       and t.status = '10';

    --循环临时表
    for m in (select *
                from tmp_formexcel_owner t
               where t.enterprise_no = strEnterpriseNo
                 and t.status = '11') loop

      strRowid := m.row_id;
      --检查数据权限类型是否正确
      if m.authority_type not in ('1', '2') then
        strOutMsg := 'N|[数据权限类型只能是1 或 2]';
        return;
      end if;

      --判断储位管理类型
      if m.cell_manager_type not in ('0', '1') then
        strOutMsg := 'N|[储位管理类型只能是0 或 1]';
        return;
      end if;

      if m.cell_manager_type = '0' and m.type_value is not null then
        strOutMsg := 'N|[储位管理类型为0 时，默认储位为空]';
        return;
      end if;

      if m.cell_manager_type = '1' and m.type_value is null then
        strOutMsg := 'N|[储位管理类型为1 时，默认储位不能为空]';
        return;
      end if;

      if m.cell_manager_type = '1' then
        select count(*)
          into v_icount
          from Cdef_Defcell a, Cdef_Defarea b
         where a.cell_status <> 1
           and a.ware_no = b.ware_no
           and a.area_no = b.area_no
           and a.warehouse_no = b.warehouse_no
           and a.enterprise_no = strEnterpriseNo
           and a.enterprise_no = b.enterprise_no
           and b.area_attribute = 0
           and b.area_usetype in ('1', '5', '6')
           and a.cell_no = m.type_value;

        if v_icount = 0 then
          strOutMsg := 'N|[输入储位不存在]';
          return;
        end if;

      end if;

      --货主编码不能为空
      if m.owner_no is null then
        strOutMsg := 'N|[货主编码不能为空]';
        return;
      end if;

      --检查货主是否存在，存在更新，不存在新增
      select count(*)
        into v_icount
        from bdef_defowner t
       where t.enterprise_no = strEnterpriseNo
         and t.owner_no = m.owner_no;
      if v_icount <> 0 then
        update bdef_defowner a
           set a.owner_name        = m.owner_name,
               a.owner_alias       = m.owner_alias,
               a.owner_address     = m.owner_address,
               a.owner_phone       = m.owner_phone,
               a.owner_fax         = m.owner_fax,
               a.owner_contact     = m.owner_contact,
               a.authority_type    = m.authority_type,
               a.cell_manager_type = m.cell_manager_type,
               a.type_value        = m.type_value,
               rsv_var1            = m.rsv_varod1,                  --7-18 添加
               rsv_var2            = m.rsv_varod2,
               rsv_var3            = m.rsv_varod3,
               rsv_var4            = m.rsv_varod4,
               rsv_var5            = m.rsv_varod5,
               rsv_var6            = m.rsv_varod6,
               rsv_var7            = m.rsv_varod7,
               rsv_var8            = m.rsv_varod8,
               rsv_num1            = m.rsv_num1,
               rsv_num2            = m.rsv_num2,
               rsv_num3            = m.rsv_num3,
               rsv_date1           = m.rsv_date1,
               rsv_date2           = m.rsv_date2,
               rsv_date3           = m.rsv_date3

         where a.enterprise_no = strEnterpriseNo
           and a.owner_no = m.owner_no;
      else
        insert into bdef_defowner
          (enterprise_no,
           owner_no,
           owner_name,
           owner_alias,
           owner_address,
           owner_phone,
           owner_fax,
           owner_contact,
           authority_type,
           status,
           turn_over_rule,
           fixedcell_flag,
           i_strategy,
           o_strategy,
           m_strategy,
           ri_strategy,
           ro_strategy,
           fc_strategy,
           rgst_name,
           rgst_date,
           cell_manager_type,
           type_value,
           rsv_var1,         --7-18 添加
           rsv_var2,
           rsv_var3,
           rsv_var4,
           rsv_var5,
           rsv_var6,
           rsv_var7,
           rsv_var8,
           rsv_num1,
           rsv_num2,
           rsv_num3,
           rsv_date1,
           rsv_date2,
           rsv_date3)
        values
          (strEnterpriseNo,
           m.owner_no,
           m.owner_name,
           m.owner_alias,
           m.owner_address,
           m.owner_phone,
           m.owner_fax,
           m.owner_contact,
           m.authority_type,
           '1',
           'FEFO',
           '0',
           '1',
           '1',
           '1',
           '1',
           '1',
           '1',
           strUserId,
           sysdate,
           m.cell_manager_type,
           m.type_value, m.rsv_varod1,       --7-8 添加
           m.rsv_varod2,
           m.rsv_varod3,
           m.rsv_varod4,
           m.rsv_varod5,
           m.rsv_varod6,
           m.rsv_varod7,
           m.rsv_varod8,
           m.rsv_num1,
           m.rsv_num2,
           m.rsv_num3,
           m.rsv_date1,
           m.rsv_date2,
           m.rsv_date3);
      end if;

      --修改临时表状态
      update tmp_formexcel_owner t
         set t.status = '13'
       where t.owner_no = m.owner_no
         and t.status = '11'
         and t.enterprise_no = strEnterpriseNo
         and t.row_id = m.row_id;

    end loop;
    --删除临时表数据
    delete from tmp_formexcel_owner t
     where t.status = '13'
       and t.enterprise_no = strEnterpriseNo;

    strOutMsg := 'Y|';

  end p_insertOwner;

  /**********************************************************************************************************
     luozhiling
     2015.04.20
     功能：导入商品类别资料
  ***********************************************************************************************************/
  procedure P_insertArticleGroup(strEnterpriseNo in bdef_article_group.enterprise_no%type,
                                 dtOperateDate   in Tmp_FormExcel_ARTICLE_GROUP.Operate_Date%type,
                                 strUserId       in bdef_defworker.worker_no%type,
                                 strOutMsg       out varchar2) is
    v_iCount integer;
  begin
    strOutMsg := 'N|[P_insertArticleGroup]';

    --锁表
    update Tmp_FormExcel_ARTICLE_GROUP t
       set t.status = '11'
     where t.status = '10'
       and t.operate_date = dtOperateDate
       and t.enterprise_no = strEnterpriseNo;

    for GetInfo in (select a.owner_no,
                           a.group_no,
                           a.group_name,
                           a.m_group_no,
                           a.m_group_name,
                           a.l_group_no,
                           a.l_group_name,
                           a.row_id,
                           a.rgst_name
                      from Tmp_FormExcel_ARTICLE_GROUP a
                     where a.enterprise_no = strEnterpriseNo
                       and a.operate_date = dtOperateDate
                     order by a.row_id) loop

      --检查货主是否存在
      select count(*)
        into v_iCount
        from bdef_defowner bdo
       where bdo.owner_no = GetInfo.Owner_No
         and bdo.enterprise_no = strEnterpriseNo;
      if v_iCount = 0 then
        strOutMsg := 'N|[第' || GetInfo.Row_Id || '条货主不存在]';
        return;
      end if;

      --检查货主是否有权限
      select count(*)
        into v_icount
        from (select distinct b.owner_no
                from bdef_defowner b, bdef_defworker d
               where b.enterprise_no = d.enterprise_no
                 and d.worker_no = strUserId
                 and b.authority_type = '1'
                 and b.enterprise_no = strEnterpriseNo
              union
              select distinct b.owner_no
                from bset_worker_owner b, bdef_defworker d
               where b.enterprise_no = d.enterprise_no
                 and b.worker_no = d.worker_no
                 and b.worker_no = strUserId
                 and b.enterprise_no = strEnterpriseNo) a
       where a.owner_no = GetInfo.owner_no;

      if v_icount = 0 then
        strOutMsg := 'N|[该用户没有' || GetInfo.owner_no || '货主权限]';
        return;
      end if;

      --检查此商品大类是否存在
      select count(*)
        into v_iCount
        from bdef_article_group bag
       where bag.owner_no = GetInfo.Owner_No
         and bag.l_group_no = GetInfo.l_group_no
         and bag.group_level = '2'
         and bag.enterprise_no = strEnterpriseNo;

      if v_iCount = 0 then
        --新增商品大类
        insert into bdef_article_group
          (owner_no,
           group_no,
           group_name,
           m_group_no,
           m_group_name,
           l_group_no,
           l_group_name,
           group_level,
           batch_id,
           status,
           create_flag,
           alarmrate,
           freezerate,
           TURN_OVER_RULE,
           rgst_name,
           rgst_date,
           updt_name,
           updt_date,
           enterprise_no)
        values
          (GetInfo.Owner_No,
           GetInfo.l_group_no,
           GetInfo.l_group_name,
           '',
           '',
           GetInfo.l_group_no,
           GetInfo.l_group_name,
           '2',
           1,
           '1',
           '1',
           25,
           5,
           'FIFO',
           strUserId,
           sysdate,
           strUserId,
           sysdate,
           strEnterpriseNo);

      end if;

      --检查此商品中类别是否存在
      select count(*)
        into v_iCount
        from bdef_article_group bag
       where bag.owner_no = GetInfo.Owner_No
         and bag.m_group_no = GetInfo.m_group_no
         and bag.l_group_no = GetInfo.l_group_no
         and bag.group_level = '1'
         and bag.enterprise_no = strEnterpriseNo;

      if v_iCount = 0 then
        --新增中类
        insert into bdef_article_group
          (owner_no,
           group_no,
           group_name,
           m_group_no,
           m_group_name,
           l_group_no,
           l_group_name,
           group_level,
           batch_id,
           status,
           create_flag,
           alarmrate,
           freezerate,
           TURN_OVER_RULE,
           rgst_name,
           rgst_date,
           updt_name,
           updt_date,
           enterprise_no)
        values
          (GetInfo.Owner_No,
           GetInfo.m_group_no,
           GetInfo.m_group_name,
           GetInfo.m_group_no,
           GetInfo.m_group_name,
           GetInfo.l_group_no,
           GetInfo.l_group_name,
           '1',
           1,
           '1',
           '1',
           75,
           50,
           'FIFO',
           strUserId,
           sysdate,
           strUserId,
           sysdate,
           strEnterpriseNo);

      end if;

      --检查此商品小类是否存在

      select count(*)
        into v_iCount
        from bdef_article_group bag
       where bag.owner_no = GetInfo.Owner_No
         and bag.m_group_no = GetInfo.m_group_no
         and bag.l_group_no = GetInfo.l_group_no
         and bag.group_no = GetInfo.group_no
         and bag.group_level = '0'
         and bag.enterprise_no = strEnterpriseNo;

      if v_iCount = 0 then
        insert into bdef_article_group
          (owner_no,
           group_no,
           group_name,
           m_group_no,
           m_group_name,
           l_group_no,
           l_group_name,
           group_level,
           batch_id,
           status,
           create_flag,
           alarmrate,
           freezerate,
           TURN_OVER_RULE,
           rgst_name,
           rgst_date,
           updt_name,
           updt_date,
           enterprise_no)
        values
          (GetInfo.Owner_No,
           GetInfo.group_no,
           GetInfo.group_name,
           GetInfo.m_group_no,
           GetInfo.m_group_name,
           GetInfo.l_group_no,
           GetInfo.l_group_name,
           '0',
           1,
           '1',
           '1',
           75,
           50,
           'FIFO',
           strUserId,
           sysdate,
           strUserId,
           sysdate,
           strEnterpriseNo);
      else
        strOutMsg := 'N|[第' || GetInfo.Row_Id || '条小类编码已存在]';
        return;
      end if;

      update Tmp_FormExcel_ARTICLE_GROUP t
         set t.status = '13'
       where t.owner_no = GetInfo.Owner_No
         and t.status = '11'
         and t.group_no = GetInfo.group_no
         and t.operate_date = dtOperateDate
         and t.enterprise_no = strEnterpriseNo;

    end loop;

    delete from Tmp_FormExcel_ARTICLE_GROUP
     where status = '13'
       and operate_date = dtOperateDate
       and enterprise_no = strEnterpriseNo;

    strOutMsg := 'Y|';

  end P_insertArticleGroup;
  /**********************************************************************************************************
     luozhiling
     2015.04.20
     功能：导入商品资料（导入规则：货主商品编码是否为空，为空新增，不为空修改，修改不到新增）
  ***********************************************************************************************************/
  procedure p_insertdefarticle(strEnterpriseNo in bdef_article_group.enterprise_no%type,
                               dtOperateDate   in Tmp_FormExcel_ARTICLE_GROUP.Operate_Date%type,
                               strFlag         in varchar2,--1， 表示普通格式，2：商品名称=货主编码+商品名称
                               strUserId       in bdef_defworker.worker_no%type,
                               strOutMsg       out varchar2) IS
    v_iCOUNT          integer;
    newarticleNO      bdef_defarticle.article_no%type;
    newarticleOwnerNO bdef_defarticle.owner_article_no%type;
    cSheetNo          bdef_defarticle.article_no%type;
    v_strInsertFlag   varchar2(1);   --0:修改；1：新增
  begin
    strOutMsg := 'N|[p_insertdefarticle]';

    --锁表
    update Tmp_Formexcel_Article t
       set t.status = '11'
     where t.status = '10'
       and t.operate_date = dtOperateDate
       and t.enterprise_no = strEnterpriseNo;

    --校验商品资料
    p_Checkarticle(strEnterpriseNo,dtOperateDate,strUserId,strOutMsg);

    if  instr(strOutMsg,'N',1,1) = 1 then
       return;
    end if;

    for GetArticleInf in (select *  from Tmp_Formexcel_Article a
                           where a.enterprise_no = strEnterpriseNo
                             and a.status = '11'
                           order by a.row_id) loop

        v_strInsertFlag:='0';

        --Owner_Article_No不为空修改，修改不到新增
        if GetArticleInf.Owner_Article_No is null then
          --货主商品编码为空，新增商品
          PKLG_WMS_BASE.p_getBaseNo(strEnterpriseNo,
                                    GetArticleInf.Owner_No,
                                    CONST_DOCUMENTTYPE.ARTICLE,
                                    cSheetNo,
                                    strOutMsg);
          if substr(strOutMsg, 1, 1) = 'N|' then
            return;
          end if;

          newarticleNO      := cSheetNo;
          newarticleOwnerNO := cSheetNo;
          v_strInsertFlag:='1';
        end if;

        if GetArticleInf.Owner_Article_No is not null then
          --检查商品资料是否存在
          select count(*)
            into v_iCount
            from bdef_defarticle t
           where t.owner_article_no = GetArticleInf.owner_article_no
             and t.owner_no = GetArticleInf.Owner_No
             and t.enterprise_no = strEnterpriseNo;
          --新增商品
          if v_iCount = 0 then
              PKLG_WMS_BASE.p_getBaseNo(strEnterpriseNo,
                                        GetArticleInf.Owner_No,
                                        CONST_DOCUMENTTYPE.ARTICLE,
                                        cSheetNo,
                                        strOutMsg);
              if substr(strOutMsg, 1, 1) = 'N|' then
                return;
              end if;

            newarticleNO := cSheetNo;
            newarticleOwnerNO:=GetArticleInf.Owner_Article_No;
            v_strInsertFlag:='1';
          end if;
        end if;

        if v_strInsertFlag='1' then--新增

            insert into bdef_defarticle
              (owner_no,owner_article_no,article_no,
               article_name,article_alias,group_no,
               unit,qmin_operate_packing,expiry_days,
               alarmrate,freezerate,unit_volumn,unit_weight,cumulative_volumn,
               spec,turn_over_rule,rgst_name,rgst_date,
               enterprise_no,status,barcode,Operate_Type,lot_type,
               supplier_no,temperature_flag,rule_flag,
               article_identifier,unit_packing,qmin_operate_packing_unit)
              select GetArticleInf.Owner_No,newarticleOwnerNO,newArticleNo,
                     case when strFlag ='2' then '[' || GetArticleInf.owner_article_no || ']' ||
                   GetArticleInf.article_name else GetArticleInf.article_name end,
                   GetArticleInf.Article_Alias,GetArticleInf.group_no,
                     GetArticleInf.Unit,GetArticleInf.qmin_operate_packing,GetArticleInf.Expiry_Days,
                     25,5,GetArticleInf.Unit_Volumn,GetArticleInf.Unit_Weight,GetArticleInf.Unit_Volumn,
                     GetArticleInf.Spec,bd.turn_over_rule,GetArticleInf.Rgst_Name,sysdate,
                     strEnterpriseNo,'0',
                     case
                       when GetArticleInf.Barcode is null then
                        newArticleNo
                       ELSE
                        GetArticleInf.Barcode
                     END,
                     'C',GetArticleInf.Lot_Type,
                     case
                       when GetArticleInf.Supplier_No IS null then
                        'N'
                       else
                        GetArticleInf.Supplier_No
                     end,
                     GetArticleInf.Temperature_Flag,GetArticleInf.Rule_Flag,
                     case
                       when GetArticleInf.article_identifier IS null then
                        GetArticleInf.owner_article_no
                       else
                        GetArticleInf.article_identifier
                     end,
                     GetArticleInf.Unit_Packing,GetArticleInf.Qmin_Operate_Packing_Unit
                from bdef_defowner bd
               where bd.owner_no = GetArticleInf.Owner_No
                 and bd.enterprise_no = strEnterpriseNo;

            --包装为0代表导入模板包装为空
            if GetArticleInf.Packing_Qty>0 and GetArticleInf.PACKING_UNIT is not null then
              -- 写包装表（和商品资料表的包装数一致）
              insert into bdef_article_packing
                (article_no,packing_qty,packing_unit,
                 spec,a_length,a_width,a_height,packing_weight,
                 sorter_flag,create_flag,rgst_name,rgst_date,
                 enterprise_no,pal_base_qbox,pal_height_qbox,qpalette)
              values
                (newArticleNo,GetArticleInf.Packing_Qty,GetArticleInf.Packing_Unit,
                 GetArticleInf.Packing_Spec,GetArticleInf.a_Length,GetArticleInf.a_Width,
                 GetArticleInf.a_Height,GetArticleInf.a_Weight,
                 0,1,GetArticleInf.Rgst_Name,sysdate,
                 strEnterpriseNo,GetArticleInf.Pal_Base_Qbox,GetArticleInf.Pal_Height_Qbox,
                 GetArticleInf.Pal_Base_Qbox * GetArticleInf.Pal_Height_Qbox *
                 GetArticleInf.Packing_Qty);
            end if;

            --写箱条码 (商品的多条码)
            if GetArticleInf.box_no is not NULL and  GetArticleInf.Packing_Qty>0 then
              insert into bdef_article_barcode
                (barcode,owner_no,article_no,
                 packing_qty,create_flag,rgst_name,
                 rgst_date,enterprise_no)
              values
                (GetArticleInf.box_no,
                 GetArticleInf.Owner_No,
                 newArticleNo,
                 GetArticleInf.Packing_Qty,1,
                 GetArticleInf.Rgst_Name,
                 sysdate,strEnterpriseNo);
            end if;
        else
            --修改
            --取商品编号
            select t.article_no
              into newarticleNO
              from bdef_defarticle t
             where t.owner_article_no = GetArticleInf.owner_article_no
               and t.owner_no = GetArticleInf.Owner_No
               and t.enterprise_no = strEnterpriseNo;

            --修改商品主档
            update bdef_defarticle
               set article_name              = GetArticleInf.Article_Name,
                   article_alias             = GetArticleInf.Article_Alias,
                   group_no                  = GetArticleInf.Group_No,
                   unit                      = GetArticleInf.Unit,
                   expiry_days               = GetArticleInf.Expiry_Days,
                   unit_volumn               = GetArticleInf.Unit_Volumn,
                   unit_weight               = GetArticleInf.Unit_Weight,
                   cumulative_volumn         = GetArticleInf.Unit_Volumn,
                   spec                      = GetArticleInf.Spec,
                   updt_name                 = GetArticleInf.Rgst_Name,
                   rgst_date                 = sysdate,
                   rule_flag                 = GetArticleInf.rule_flag,
                   barcode = case
                               when GetArticleInf.Barcode is null then
                                newarticleNO
                               else
                                GetArticleInf.Barcode
                             end,
                   lot_type                  = GetArticleInf.Lot_Type,
                   supplier_no = case
                                   when GetArticleInf.Supplier_No IS null then
                                    'N'
                                   else
                                    GetArticleInf.Supplier_No
                                 end,
                   Temperature_Flag          = GetArticleInf.Temperature_Flag,
                   article_identifier = case
                                          when GetArticleInf.article_identifier IS null then
                                           GetArticleInf.Owner_Article_No
                                          else
                                           GetArticleInf.article_identifier
                                        end,
                   unit_packing              = GetArticleInf.Unit_Packing,
                   qmin_operate_packing_unit = GetArticleInf.Qmin_Operate_Packing_Unit,
                   qmin_operate_packing      = GetArticleInf.Qmin_Operate_Packing
             where article_no = newarticleNO
               and enterprise_no = GetArticleInf.Enterprise_No;
            --写log表
            insert into bdef_defarticle_log
              (enterprise_no,owner_no,owner_article_no,
               article_no,article_name,article_ename,article_oname,article_alias,
               group_no,article_identifier,unit,
               qmin_operate_packing,expiry_days,alarmrate,freezerate,abc,
               unit_volumn,unit_weight,cumulative_volumn,a_out,
               rule_flag,spec,sell_price,status,create_flag,
               virtual_flag,turn_over_rule,check_excess,um_check_excess,
               pick_excess,divide_excess,temperature_flag,
               measure_mode,scan_flag,check_qty_flag,check_qty_rate,
               check_weight_flag,check_weight_rate,
               qc_flag,qc_rate,mix_flag,double_check,code_type,divide_box,
               deliver_type,dept_no,
               i_strategy,o_strategy,m_strategy,ri_strategy,ro_strategy,fc_strategy,
               rsv_strategy1,rsv_strategy2,rsv_strategy3,rsv_strategy4,
               rsv_strategy5,rsv_strategy6,
               rsv_attr1,rsv_attr2,rsv_attr3,rsv_attr4,
               rsv_attr5,rsv_attr6,rsv_attr7,rsv_attr8,
               rsv_attr9,rsv_attr10,rsv_attr11,rsv_attr12,
               rsv_attr13,rsv_attr14,rsv_attr15,rsv_attr16,
               rsv_attr17,rsv_attr18,rsv_attr19,rsv_attr20,
               rgst_name,rgst_date,updt_name,updt_date,
               print_flag,lot_type,supplier_no,
               barcode,operate_type,row_id,
               batch_id,unit_packing,qmin_operate_packing_unit)
              select enterprise_No,owner_no,owner_article_no,
                     article_no,article_name,article_ename,article_oname,article_alias,
                     group_no,article_identifier,unit,qmin_operate_packing,expiry_days,alarmrate,freezerate,abc,
                     unit_volumn,unit_weight,cumulative_volumn,a_out,
                     rule_flag,spec, sell_price,status,create_flag,
                     virtual_flag,turn_over_rule,check_excess,um_check_excess,
                     pick_excess,divide_excess,temperature_flag,
                     measure_mode,scan_flag,check_qty_flag,check_qty_rate,
                     check_weight_flag,check_weight_rate,
                     qc_flag,qc_rate,mix_flag,double_check,code_type,divide_box,
                     deliver_type,dept_no,
                     i_strategy,o_strategy,m_strategy,ri_strategy,ro_strategy,fc_strategy,
                     rsv_strategy1,rsv_strategy2,rsv_strategy3,rsv_strategy4,
                     rsv_strategy5,rsv_strategy6,
                     rsv_attr1,rsv_attr2,rsv_attr3,rsv_attr4,
                     rsv_attr5,rsv_attr6,rsv_attr7,rsv_attr8,
                     rsv_attr9,rsv_attr10,rsv_attr11,rsv_attr12,
                     rsv_attr13,rsv_attr14,rsv_attr15,rsv_attr16,
                     rsv_attr17,rsv_attr18,rsv_attr19,rsv_attr20,
                     rgst_name,rgst_date,strUserId,sysdate,
                     print_flag,lot_type,supplier_no,barcode,operate_type,
                     row_id,batch_id,unit_packing,qmin_operate_packing_unit
                from bdef_defarticle
               where article_no = newarticleNO
                 and enterprise_no = GetArticleInf.Enterprise_No;

            --修改包装，如果导入箱包装，且包装表没有该商品的包装则新增；
            --如果导入模板的包装在包装表存在则修改该包装(导入的包装存在与包装表中)；2

            if GetArticleInf.Packing_Qty>0 then
                select count(*)
                  into v_iCount
                  from bdef_article_packing g
                 where g.article_no = newarticleNO
                   and g.enterprise_no = GetArticleInf.Enterprise_No
                   and g.packing_qty =GetArticleInf.packing_qty;
                if v_iCount=0 then
                    insert into bdef_article_packing
                      (article_no,packing_qty,packing_unit,
                       spec,a_length,a_width,a_height,packing_weight,
                       sorter_flag,create_flag,rgst_name,rgst_date,
                       enterprise_no,pal_base_qbox,pal_height_qbox,qpalette)
                    values
                      (newArticleNo,GetArticleInf.Packing_Qty,GetArticleInf.Packing_Unit,
                       GetArticleInf.Packing_Spec,GetArticleInf.a_Length,GetArticleInf.a_Width,
                       GetArticleInf.a_Height,GetArticleInf.a_Weight,
                       0,1,GetArticleInf.Rgst_Name,sysdate,
                       strEnterpriseNo,GetArticleInf.Pal_Base_Qbox,GetArticleInf.Pal_Height_Qbox,
                       GetArticleInf.Pal_Base_Qbox * GetArticleInf.Pal_Height_Qbox *
                       GetArticleInf.Packing_Qty);
                else
                    update bdef_article_packing g
                       set packing_unit    = GetArticleInf.Packing_Unit,
                           spec            = GetArticleInf.Packing_Spec,
                           a_length        = GetArticleInf.a_Length,
                           a_width         = GetArticleInf.a_Width,
                           a_height        = GetArticleInf.a_Height,
                           packing_weight  = GetArticleInf.a_Weight,
                           updt_name       = GetArticleInf.Rgst_Name,
                           updt_date       = sysdate,
                           pal_base_qbox   = GetArticleInf.Pal_Base_Qbox,
                           pal_height_qbox = GetArticleInf.Pal_Height_Qbox,
                           qpalette        = GetArticleInf.Pal_Base_Qbox *
                                             GetArticleInf.Pal_Height_Qbox *
                                             GetArticleInf.Packing_Qty
                     where g.article_no = newarticleNO
                       and g.enterprise_no = GetArticleInf.Enterprise_No
                       and g.packing_qty = GetArticleInf.Packing_Qty;

                    insert into BDEF_ARTICLE_PACKING_LOG
                       (enterprise_no,article_no,packing_qty,packing_unit,
                       spec,a_length,a_width,a_height,packing_weight,
                       sorter_flag,create_flag,pal_base_qbox,pal_height_qbox,qpalette,row_id ,
                       rgst_name,rgst_date,updt_name,updt_date)
                      select enterprise_no,article_no,packing_qty,packing_unit,
                         spec,a_length,a_width,a_height,packing_weight,
                         sorter_flag,create_flag,pal_base_qbox,pal_height_qbox,qpalette,row_id ,
                         rgst_name,rgst_date,strUserId,sysdate
                         from bdef_article_packing
                         where article_no = newarticleNO
                         and enterprise_no = GetArticleInf.Enterprise_No
                         and packing_qty = GetArticleInf.Packing_Qty;
                end if;
            end if;

            --修改包装，如果导入箱包装，且包装表没有该商品的包装则新增；
            --如果导入模板的包装在包装表存在则修改该包装(导入的包装存在与包装表中)；
            if GetArticleInf.Packing_Qty>0 and GetArticleInf.barcode is not null then
               select count(*) into v_iCount
                  from bdef_article_barcode g
                 where g.article_no = newarticleNO
                   and g.enterprise_no = GetArticleInf.Enterprise_No
                   and g.packing_qty=GetArticleInf.packing_qty
                   and g.barcode=GetArticleInf.barcode;

               if v_iCOUNT=0 then
                  insert into bdef_article_barcode
                    (barcode,owner_no,
                     article_no,packing_qty,
                     create_flag,rgst_name,
                     rgst_date,enterprise_no)
                  values
                    (GetArticleInf.box_no,
                     GetArticleInf.Owner_No,
                     newArticleNo,
                     GetArticleInf.Packing_Qty,1,
                     GetArticleInf.Rgst_Name,
                     sysdate,strEnterpriseNo);
                end if;
            end if;

        end if;

      update Tmp_Formexcel_Article
         set status = '13'
       where owner_no = GetArticleInf.Owner_No
         and owner_article_no = GetArticleInf.owner_article_no
         and operate_date = dtOperateDate
         and status = '11'
         and enterprise_no = strEnterpriseNo;

    end loop;

    delete from Tmp_Formexcel_Article
     where status = '13'
       and operate_date = dtOperateDate
       and enterprise_no = strEnterpriseNo;

    strOutMsg := 'Y|';
  END p_insertdefarticle;

  /**********************************************************************************************************
    hekl
    2015.04.24
    功能：导入客户资料
  ***********************************************************************************************************/
  procedure p_insertdefcust(strEnterpriseNo in tmp_formexcel_cust.enterprise_no%type,
                            strUserId       in bdef_defworker.worker_no%type,
                            strRowid        out tmp_formexcel_cust.row_id%type,
                            strOutMsg       out varchar2) is
    v_icount      integer;
    v_icount1     integer;
    v_newcustNo   bdef_defcust.cust_no%type;
    v_ownerCustNo bdef_defcust.owner_cust_no%type;
  begin
    strOutMsg := 'N|[p_insetdefcust]';
    --锁表
    update tmp_formexcel_cust t
       set t.status = '11'
     where t.enterprise_no = strEnterpriseNo
       and t.status = '10';

    --循环临时表
    for m in (select *
                from tmp_formexcel_cust t
               where t.enterprise_no = strEnterpriseNo
                 and t.status = '11'
               order by t.row_id) loop

      strRowid := m.row_id;
      --检查货主是否存在
      select count(*)
        into v_icount
        from bdef_defowner t
       where t.enterprise_no = strEnterpriseNo
         and t.owner_no = m.owner_no;

      if v_icount = 0 then
        strOutMsg := 'N|[货主不存在]';
        return;
      end if;

      --检查货主是否有权限
      select count(*)
        into v_icount
        from (select distinct b.owner_no
                from bdef_defowner b, bdef_defworker d
               where b.enterprise_no = d.enterprise_no
                 and d.worker_no = strUserId
                 and b.authority_type = '1'
                 and b.enterprise_no = strEnterpriseNo
              union
              select distinct b.owner_no
                from bset_worker_owner b, bdef_defworker d
               where b.enterprise_no = d.enterprise_no
                 and b.worker_no = d.worker_no
                 and b.worker_no = strUserId
                 and b.enterprise_no = strEnterpriseNo) a
       where a.owner_no = m.owner_no;

      if v_icount = 0 then
        strOutMsg := 'N|[该用户没有货主权限]';
        return;
      end if;

      --校验
      if m.control_type not in ('0', '1', '2') then
        strOutMsg := 'N|[生产日期管理类型只能是0、1或 2]';
        return;
      end if;

      if m.control_type = '0' and m.control_value <> 0 then
        strOutMsg := 'N|[生产日期管理类型为0时，其管理值只能为0或为空]';
        return;
      end if;

      if m.control_type in ('1', '2') and m.control_value = 0 then
        strOutMsg := 'N|[生产日期管理类型为1或2时，其管理值不能为0且不为空]';
        return;
      end if;

      --根据检查客户是否存在,存在则更新，否则新增
      select count(*)
        into v_icount
        from bdef_defcust t
       where t.enterprise_no = strEnterpriseNo
         and t.owner_no = m.owner_no
         and t.owner_cust_no = m.owner_cust_no;

      if v_icount <> 0 then
        update bdef_defcust a
           set a.cust_name        = m.cust_name,
               a.cust_alias       = m.cust_alias,
               a.cust_address     = m.cust_address,
               a.delivery_address = m.delivery_address,
               a.contactor_name1  = m.contactor_name1,
               a.cust_phone1      = m.cust_phone1,
               a.cust_province    = m.cust_province,
               a.cust_city        = m.cust_city,
               a.cust_zone        = m.cust_zone,
               a.control_type     = m.control_type,
               a.control_value    = m.control_value
         where a.enterprise_no = strEnterpriseNo
           and a.owner_no = m.owner_no
           and a.owner_cust_no = m.owner_cust_no;

      else
        --取客户编码
        loop
          v_newcustNo := m.owner_no ||
                         ean14(strEnterpriseNo, m.owner_no, 2); --1货主商品编号；2客户编号；3供应商编号
          select count(*)
            into v_icount
            from bdef_defcust t
           where t.enterprise_no = strEnterpriseNo
             and t.owner_no = m.owner_no
             and t.cust_no = v_newcustNo;

          if m.owner_cust_no is null then
            v_ownerCustNo := v_newcustNo;
            select count(*)
              into v_icount1
              from bdef_defcust t
             where t.enterprise_no = strEnterpriseNo
               and t.owner_no = m.owner_no
               and t.owner_cust_no = v_ownerCustNo;
          else
            v_ownerCustNo := m.owner_cust_no;
          end if;

          exit when v_iCount <= 0 and m.owner_cust_no is not null or v_iCount <= 0 and v_iCount1 <= 0;
        end loop;
        --insert bdef_defcust_log
        insert into bdef_defcust_log
          (serialid,
           modiattr,
           moditime,
           modiopid,
           owner_no,
           owner_cust_no,
           cust_no,
           cust_flag,
           cust_type,
           shipping_method,
           box_deliver,
           cust_name,
           cust_alias,
           cust_address,
           delivery_address,
           cust_phone1,
           contactor_name1,
           status,
           create_flag,
           cust_province,
           cust_city,
           cust_zone,
           trade_flag,
           only_date_flag,
           collect_flag,
           container_material,
           rgst_name,
           rgst_date,
           prio_type,
           enterprise_no)
        values
          (seq_bdef_defcust_log.nextval,
           'U',
           sysdate,
           strUserId,
           m.owner_no,
           v_ownerCustNo,
           v_newcustNo,
           '0',
           0,
           '2',
           '0',
           m.cust_name,
           m.cust_alias,
           m.cust_address,
           m.delivery_address,
           m.cust_phone1,
           m.contactor_name1,
           1,
           '0',
           m.cust_province,
           m.cust_city,
           m.cust_zone,
           '0',
           '0',
           '1',
           '11',
           strUserId,
           sysdate,
           0,
           strEnterpriseNo);
        --新增
        insert into bdef_defcust
          (owner_no,
           owner_cust_no,
           cust_no,
           cust_flag,
           cust_type,
           shipping_method,
           box_deliver,
           cust_name,
           cust_alias,
           cust_address,
           delivery_address,
           cust_phone1,
           contactor_name1,
           status,
           create_flag,
           cust_province,
           cust_city,
           cust_zone,
           trade_flag,
           only_date_flag,
           collect_flag,
           container_material,
           rgst_name,
           rgst_date,
           prio_level,
           prio_type,
           control_type,
           control_value,
           enterprise_no,
           rsv_var1,
           rsv_var2,
           rsv_var3,
           rsv_var4,
           rsv_var5,
           rsv_var6,
           rsv_var7,
           rsv_var8,
           rsv_num1,
           rsv_num2,
           rsv_num3,
           rsv_date1,
           rsv_date2,
           rsv_date3)
        values
          (m.owner_no,
           v_ownerCustNo,
           v_newcustNo,
           '0',
           0,
           '2',
           '0',
           m.cust_name,
           m.cust_alias,
           m.cust_address,
           m.delivery_address,
           m.cust_phone1,
           m.contactor_name1,
           1,
           '0',
           m.cust_province,
           m.cust_city,
           m.cust_zone,
           '0',
           '0',
           '1',
           '11',
           strUserId,
           sysdate,
           0,
           0,
           m.control_type,
           m.control_value,
           strEnterpriseNo,
           m.rsv_varod1,
           m.rsv_varod2,
           m.rsv_varod3,
           m.rsv_varod4,
           m.rsv_varod5,
           m.rsv_varod6,
           m.rsv_varod7,
           m.rsv_varod8,
           m.rsv_num1,
           m.rsv_num2,
           m.rsv_num3,
           m.rsv_date1,
           m.rsv_date2,
           m.rsv_date3);
      end if;

      --修改临时表状态
      update Tmp_Formexcel_Cust t
         set t.status = '13'
       where t.status = '11'
         and t.owner_cust_no = m.owner_cust_no
         and t.enterprise_no = strEnterpriseNo
         and t.row_id = m.row_id;

    end loop;
    --删除临时表数据
    delete from Tmp_Formexcel_Cust
     where status = '13'
       and enterprise_no = strEnterpriseNo;
    strOutMsg := 'Y|';

  end p_insertdefcust;

  /**********************************************************************************************************
    hekl
    2015.04.24
    功能：导入供应商资料
  ***********************************************************************************************************/
  procedure p_insertdefsupplier(strEnterpriseNo in bdef_defsupplier.enterprise_no%type,
                                strUserId       in bdef_defworker.worker_no%type,
                                strRowid        out tmp_fromexcel_supplier.row_id%type,
                                strOutMsg       out varchar2) is
    v_iCount      integer;
    newSupplierNo bdef_defsupplier.supplier_no%type;
  begin
    strOutMsg := 'N|[p_insetdefsupplier]';
    --锁表
    update tmp_fromexcel_supplier t
       set t.status = '11'
     where t.enterprise_no = strEnterpriseNo
       and t.status = '10';

    --循环临时表
    for m in (select *
                from tmp_fromexcel_supplier t
               where t.enterprise_no = strEnterpriseNo
                 and t.status = '11'
               order by t.supplier_no) loop

      strRowid := m.row_id;

      --检查货主是否存在
      select count(*)
        into v_iCount
        from bdef_defowner t
       where t.enterprise_no = strEnterpriseNo
         and t.owner_no = m.owner_no;

      if v_iCount = 0 then
        strOutMsg := 'N|[货主不存在]';
        return;
      end if;

      --检查货主是否有权限
      select count(*)
        into v_icount
        from (select distinct b.owner_no
                from bdef_defowner b, bdef_defworker d
               where b.enterprise_no = d.enterprise_no
                 and d.worker_no = strUserId
                 and b.authority_type = '1'
                 and b.enterprise_no = strEnterpriseNo
              union
              select distinct b.owner_no
                from bset_worker_owner b, bdef_defworker d
               where b.enterprise_no = d.enterprise_no
                 and b.worker_no = d.worker_no
                 and b.worker_no = strUserId
                 and b.enterprise_no = strEnterpriseNo) a
       where a.owner_no = m.owner_no;

      if v_icount = 0 then
        strOutMsg := 'N|[该用户没有货主权限]';
        return;
      end if;

      --检查卸货标识是否正常
      if m.unload_flag not in ('0', '1') then
        strOutMsg := 'N|[卸货标识只能0或1]';
        return;
      end if;

      if m.supplier_no is null then
        --取供应商编码，如果存在，则重新取号
        loop
          newSupplierNo := ean14(strEnterpriseNo, m.owner_no, 3); --1货主商品编号；2客户编号；3供应商编号

          select count(*)
            into v_icount
            from bdef_defsupplier t
           where t.enterprise_no = strEnterpriseNo
             and t.owner_no = m.owner_no
             and t.supplier_no = newSupplierNo;
          exit when v_iCount <= 0;
        end loop;
      else
        newSupplierNo := m.supplier_no;
      end if;

      --检查供应商是否存在
      select count(*)
        into v_icount
        from bdef_defsupplier t
       where t.enterprise_no = strEnterpriseNo
         and t.owner_no = m.owner_no
         and t.supplier_no = newSupplierNo;

      --供应商存在，写记录表 7-8 添加
      if v_iCount <> 0 then
        insert into bdef_defsupplier_log
          (  owner_no,
             supplier_no,
             supplier_name,
             supplier_alias,
             supplier_address1,
             supplier_phone1,
             supplier1,
             status,
             unload_flag,
             create_flag,
             rgst_name,
             rgst_date,
             enterprise_no,
             rsv_var1,
             rsv_var2,
             rsv_var3,
             rsv_var4,
             rsv_var5,
             rsv_var6,
             rsv_var7,
             rsv_var8,
             rsv_num1,
             rsv_num2,
             rsv_num3,
             rsv_date1,
             rsv_date2,
             rsv_date3,
             dept_no,
             serialid,
             modiattr,
             moditime,
             modiopid)
        values
          (m.owner_no,
           newSupplierNo,
           m.supplier_name,
           m.Supplier_Name,
           m.supplier_address1,
           m.supplier_phone1,
           m.supplier1,
           1,
           m.unload_flag,
           1,
           strUserId,
           sysdate,
           strEnterpriseNo,
           m.rsv_varod1,
           m.rsv_varod2,
           m.rsv_varod3,
           m.rsv_varod4,
           m.rsv_varod5,
           m.rsv_varod6,
           m.rsv_varod7,
           m.rsv_varod8,
           m.rsv_num1,
           m.rsv_num2,
           m.rsv_num3,
           m.rsv_date1,
           m.rsv_date2,
           m.rsv_date3,
           'N',
           SEQ_BDEF_DEFSUPPLIER_LOG.nextval,
           'U',
           sysdate,
           strUserId);

      end if;

      if v_iCount <> 0 then
        delete from bdef_defsupplier a
         where a.enterprise_no = strEnterpriseNo
           and a.owner_no = m.owner_no
           and a.supplier_no = newSupplierNo;
      end if;

      --添加供应商
      insert into bdef_defsupplier
        (owner_no,
         supplier_no,
         supplier_name,
         supplier_alias,
         supplier_address1,
         supplier_phone1,
         supplier1,
         status,
         unload_flag,
         create_flag,
         rgst_name,
         rgst_date,
         enterprise_no,
         rsv_var1,         --7-8 添加
         rsv_var2,
         rsv_var3,
         rsv_var4,
         rsv_var5,
         rsv_var6,
         rsv_var7,
         rsv_var8,
         rsv_num1,
         rsv_num2,
         rsv_num3,
         rsv_date1,
         rsv_date2,
         rsv_date3)
      values
        (m.owner_no,
         newSupplierNo,
         m.supplier_name,
         m.Supplier_Name,
         m.supplier_address1,
         m.supplier_phone1,
         m.supplier1,
         1,
         m.unload_flag,
         1,
         strUserId,
         sysdate,
         strEnterpriseNo,
         m.rsv_varod1,       --7-8 添加
         m.rsv_varod2,
         m.rsv_varod3,
         m.rsv_varod4,
         m.rsv_varod5,
         m.rsv_varod6,
         m.rsv_varod7,
         m.rsv_varod8,
         m.rsv_num1,
         m.rsv_num2,
         m.rsv_num3,
         m.rsv_date1,
         m.rsv_date2,
         m.rsv_date3);

      --写供应商记录表

      --修改临时表状态
      update Tmp_Fromexcel_Supplier t
         set t.status = '13'
       where t.owner_no = m.owner_no
         and t.status = '11'
         and t.supplier_no = m.supplier_no
         and t.enterprise_no = strEnterpriseNo
         and t.row_id = m.row_id;

    end loop;

    --删除临时表数据
    delete from Tmp_Fromexcel_Supplier
     where status = '13'
       and enterprise_no = strEnterpriseNo;

    strOutMsg := 'Y|';
  end p_insertdefsupplier;
  /**********************************************************************************************************
     hekl
    2015.04.24
    功能：导入商品储位对照关系
  ***********************************************************************************************************/
  procedure p_insertCsetCellArticle(strEnterpriseNo in bdef_article_group.enterprise_no%type,
                                    strWareHouseNo  in cset_cell_article.warehouse_no%type,
                                    strUserId       in bdef_defworker.worker_no%type,
                                    strOutMsg       out varchar2) is
    v_dtOperateDate  Tmp_FormExcel_ARTICLE_GROUP.Operate_Date%type;
    v_count          number;
    v_count_1        number;
    v_article_no     bdef_defarticle.article_no%type;
    v_mix_owner      cdef_defcell.mix_owner%type;
    v_mix_flag       cdef_defcell.mix_flag%type;
    v_fixedcell_flag bdef_defowner.fixedcell_flag%type;
    v_line_id        cset_area_backup_m.line_id%type;
  begin
    strOutMsg := 'N|[p_insertCsetCellArticle]';

    --锁表
    update tmp_fromexcelcsetcell t
       set t.status = '11'
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWareHouseNo
       and t.status = '10';

    for tmp in (select t.*, ca.o_type
                  from tmp_fromexcelcsetcell t,
                       cdef_defcell          cd,
                       cdef_defarea          ca
                 where t.enterprise_no = strEnterpriseNo
                   and t.warehouse_no = strWareHouseNo
                   and t.status = '11'
                   and t.cell_no = cd.cell_no
                   and t.enterprise_no = cd.enterprise_no
                   and t.warehouse_no = cd.warehouse_no
                   and cd.enterprisE_no = ca.enterprise_no
                   and cd.warehouse_no = ca.warehouse_no
                   and cd.ware_no = ca.ware_no
                   and cd.area_no = ca.area_no
                 order by t.enterprise_no, t.warehouse_no, t.barcode) loop
      --判断货主是否存在
      select count(1)
        into v_count
        from bdef_defowner
       where owner_no = tmp.owner_no
         and enterprise_no = strEnterpriseNo;
      if v_count = 0 then
        strOutMsg := 'N|[请检查第' || tmp.Row_Id || '条货主]'; --货主不存在
        return;
      end if;

      --检查货主是否有权限
      select count(*)
        into v_count
        from (select distinct b.owner_no
                from bdef_defowner b, bdef_defworker d
               where b.enterprise_no = d.enterprise_no
                 and d.worker_no = strUserId
                 and b.authority_type = '1'
                 and b.enterprise_no = strEnterpriseNo
              union
              select distinct b.owner_no
                from bset_worker_owner b, bdef_defworker d
               where b.enterprise_no = d.enterprise_no
                 and b.worker_no = d.worker_no
                 and b.worker_no = strUserId
                 and b.enterprise_no = strEnterpriseNo) a
       where a.owner_no = tmp.owner_no;
      if v_count = 0 then
        strOutMsg := 'N|[第' || tmp.row_id || '条数据，用户没有货主权限]';
        return;
      end if;

      --检查该商品是否存在(临时表中的条码字段的数据为货主商品编码)
      begin
        select article_no
          into v_article_no
          from bdef_defarticle
         where owner_article_no = tmp.barcode
           and enterprise_no = tmp.enterprise_no
           and owner_no = tmp.owner_no;
      exception
        when no_data_found then
          strOutMsg := 'N|[第' || tmp.Row_Id || '条货主商品编码不存在]';
          return;
      end;

      --检查商品包装是否存在
      IF tmp.packing_qty <> 1 then
        select count(1)
          into v_count
          from BDEF_ARTICLE_PACKING
         where article_no = v_article_no
           and packing_qty = tmp.packing_qty
           and enterprise_no = strEnterpriseNo;
        if v_count = 0 then
          strOutMsg := 'N|[第' || tmp.Row_Id || '条商品包装不存在]';
          return;
        end if;
      end if;

      --检查储位不存在的数据
      select count(*)
        into v_count
        from cdef_defarea cd, cdef_defcell cc
       where cd.enterprise_no = cc.enterprise_no
         and cd.warehouse_no = cc.warehouse_no
         and cd.ware_no = cc.ware_no
         and cd.area_no = cc.area_no
         and cd.area_attribute = '0'
         and cd.area_pick = '1'
         and cc.enterprise_no = strEnterpriseNo
         and cc.warehouse_no = strWareHouseNo
         and cc.cell_no = tmp.cell_no;
      if v_count = 0 then
        strOutMsg := 'N|[第' || tmp.Row_Id || '条储位不存在或不是拣货区的储位]';
        return;
      end if;

      --检查拣货位是否已存在
      select count(*)
        into v_count
        from cset_cell_article e
       where e.enterprise_no = strEnterpriseNo
         and e.warehouse_no = strWareHouseNo
         and e.article_no = v_article_no
         and e.packing_qty = tmp.packing_qty
         and e.pick_type = tmp.o_type;
      if v_count > 0 then
        strOutMsg := 'N|[第' || tmp.Row_Id || '条拣货位已存在]';
        return;
      end if;

      --判断货主是否绑定储位0不绑定；1绑定货位
      --当货主是绑定储位时，设置拣货位只能设定该货主所绑定的检货位
      --当货主是不绑定储位时,则需要做混货主的判断
      select r.fixedcell_flag
        into v_fixedcell_flag
        from bdef_defowner r
       where r.enterprise_no = strEnterpriseNo
         and r.owner_no = tmp.owner_no;

      --判断该货位的混属性和混货主状态
      select l.mix_flag, l.mix_owner
        into v_mix_flag, v_mix_owner
        from cdef_defcell l
       where l.enterprise_no = strEnterpriseNo
         and l.warehouse_no = strWareHouseNo
         and l.cell_no = tmp.cell_no;

      if v_fixedcell_flag = 1 then
        --绑定储位时，设置拣货位只能设定该货主所绑定的检货位
        select count(*)
          into v_count
          from cset_owner_cell l
         where l.enterprise_no = strEnterpriseNo
           and l.warehouse_no = strWareHouseNo
           and l.cell_no = tmp.cell_no
           and l.owner_no = tmp.owner_no;
        if v_count = 0 then
          strOutMsg := 'N|[第' || tmp.Row_Id || '条的货位不是该货主绑定的货位,请检查该货位]';
          return;
        end if;

      else
        --不绑定储位时,则需要做混货主的判断
        if v_mix_owner = 0 then
          select count(*)
            into v_count
            from cset_cell_article e
           where e.enterprise_no = strEnterpriseNo
             and e.warehouse_no = strWareHouseNo
             and e.cell_no = tmp.cell_no
             and e.owner_no <> tmp.owner_no;
          if v_count > 0 then
            strOutMsg := 'N|[第' || tmp.Row_Id || '条的货位是不可混货主，请检查该货位]';
            return;
          end if;
        end if;
      end if;

      if v_mix_flag = 0 or v_mix_flag = 1 then
        select count(*)
          into v_count
          from cset_cell_article e
         where e.enterprise_no = strEnterpriseNo
           and e.warehouse_no = strWareHouseNo
           and e.cell_no = tmp.cell_no
           and e.article_no <> v_article_no;
        if v_count > 0 then
          strOutMsg := 'N|[第' || tmp.Row_Id || '条的货位是不可混商品货位，请检查该货位]';
          return;
        end if;
      end if;

      --当保拣线为空时，取默认保拣线，若未找到默认保拣线，系统给与拦截
      if tmp.line_id = -1 then
        begin
          select m.line_id
            into v_line_id
            from Cset_Area_Backup_M m
           where m.default_flag = '1'
             and m.warehouse_no = strWareHouseNo
             and m.enterprise_no = strEnterpriseNo
             and m.s_area_no =
                 (select l.area_no
                    from cdef_defcell l
                   where l.enterprise_no = strEnterpriseNo
                     and l.warehouse_no = strWareHouseNo
                     and l.cell_no = tmp.cell_no)
             and m.s_ware_no =
                 (select l.ware_no
                    from cdef_defcell l
                   where l.enterprise_no = strEnterpriseNo
                     and l.warehouse_no = strWareHouseNo
                     and l.cell_no = tmp.cell_no);
        exception
          when no_data_found then
            strOutMsg := 'N|[第' || tmp.Row_Id || '条没有默认保拣线，请检查保拣线]';
            return;
        end;

      else
        v_line_id := tmp.line_id;
      end if;

      insert into cset_cell_article
        (enterprise_no,
         warehouse_no,
         owner_no,
         ware_no,
         area_no,
         stock_no,
         a_stock_no,
         stock_x,
         cell_no,
         article_no,
         packing_qty,
         line_id,
         max_qty_a,
         alert_qty_a,
         supp_qty_a,
         max_qty_na,
         alert_qty_na,
         supp_qty_na,
         keep_cells,
         pick_type,
         keep_cells_a,
         rgst_name,
         rgst_date)
        select strEnterpriseNo,
               strWareHouseNo,
               tmp.owner_no,
               cd.ware_no,
               cd.area_no,
               cd.stock_no,
               cd.ware_no || cd.area_no || cd.stock_no,
               cd.stock_x,
               tmp.cell_no,
               v_article_no,
               tmp.packing_qty,
               v_line_id,
               tmp.max_qty,
               tmp.alert_qty,
               0,
               tmp.max_qty,
               tmp.alert_qty,
               0,
               tmp.keep_cells,
               ca.o_type,
               tmp.keep_cells,
               strUserId,
               sysdate
          from cdef_defcell cd, cdef_defarea ca
         where cd.enterprise_no = ca.enterprise_no
           and cd.warehouse_no = ca.warehouse_no
           and cd.enterprise_no = tmp.enterprise_no
           and cd.warehouse_no = tmp.warehouse_no
           and cd.ware_no = ca.ware_no
           and cd.area_no = ca.area_no
           and cd.cell_no = tmp.cell_no
           and tmp.status = '11';
      if sql%rowcount <= 0 then
        strOutMsg := 'N|[第' || tmp.Row_Id || '条写商品拣货位关系表失败]';
        return;
      end if;

      update tmp_fromexcelcsetcell t
         set t.status = '13'
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.status = '11';

    end loop;

    --判断是否有货位匹配
    select count(*)
          into v_count
          from tmp_fromexcelcsetcell e
         where e.enterprise_no = strEnterpriseNo
           and e.warehouse_no = strWareHouseNo
           and e.status='11';
        if v_count > 0 then
          strOutMsg := 'N|[导入失败,无货位匹配！]';
          return;
        end if;

    --删除临时表数据
    delete from tmp_fromexcelcsetcell
     where status = '13'
       and enterprise_no = strEnterpriseNo
       and warehouse_no = strWareHouseNo;

    strOutMsg := 'Y|[成功]';
  end p_insertCsetCellArticle;
  /*************************************************************************************************
    创建人：chensr
    修改人：hekl
    修改人：huangcx 2015/10/15
    修改人：czh     2016/5/18
    创建时间：2014.12.19
    功能说明：存储进货手建单的导入
  **************************************************************************************************/
  procedure P_idata_import(strEnterpriseNo in idata_import_tmp.enterprise_no%type,
                           strWareHouseNo  in idata_import_tmp.warehouse_no%type,
                           strUserId       in bdef_defworker.worker_no%type,
                           strResult       out varchar2) is
    v_count                number;
    v_count_1              number;
    v_endDate              number;
    v_import_no            varchar2(20);
    v_article_no           varchar2(20);
    v_strFlag              wms_defbase.sdefine%type;
    v_nFlag                wms_defbase.sdefine%type;
    v_strNewS_Import_No    Idata_Import_Mm.S_IMPORT_NO%type;
    v_result               varchar2(20);
    n_qmin_operate_packing number;
  begin
    strResult := 'Y|[P_idata_import]';
    --锁表
    update idata_import_tmp
       set status = '11'
     where warehouse_no = strWareHouseNo
       and enterprise_no = strEnterpriseNo;

    for m in (select enterprise_no,
                     wareHouse_no,
                     owner_no,
                     po_type,
                     take_type,
                     po_no,
                     supplier_no,
                     order_date,
                     request_date,
                     import_remark,
                     end_date,
                     rsv_varod1,
                     rsv_varod2,
                     rsv_varod3,
                     rsv_varod4,
                     rsv_varod5,
                     rsv_varod6,
                     rsv_varod7,
                     rsv_varod8,
                     rsv_num1,
                     rsv_num2,
                     rsv_num3,
                     rsv_date1,
                     rsv_date2,
                     rsv_date3
                from idata_import_tmp
               where warehouse_no = strWareHouseNo
                 and status = '11'
                 and enterprise_no = strEnterpriseNo
               group by enterprise_no,
                        wareHouse_no,
                        owner_no,
                        po_type,
                        take_type,
                        po_no,
                        supplier_no,
                        order_date,
                        request_date,
                        import_remark,
                        end_date,
                        rsv_varod1,
                        rsv_varod2,
                        rsv_varod3,
                        rsv_varod4,
                        rsv_varod5,
                        rsv_varod6,
                        rsv_varod7,
                        rsv_varod8,
                        rsv_num1,
                        rsv_num2,
                        rsv_num3,
                        rsv_date1,
                        rsv_date2,
                        rsv_date3) loop

      --判断货主是否存在
      select count(1)
        into v_count
        from bdef_defowner
       where owner_no = m.owner_no
         and enterprise_no = strEnterpriseNo;
      if v_count = 0 then
        strResult := 'N|[请检查' || m.owner_no || '货主不存在]'; --货主不存在
        --更新临时表状态
        update idata_import_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and owner_no = m.owner_no
           and status = '11';
        return;
      end if;

      --检查货主是否有权限
      select count(*)
        into v_count
        from (select distinct b.owner_no
                from bdef_defowner b, bdef_defworker d
               where b.enterprise_no = d.enterprise_no
                 and d.worker_no = strUserId
                 and b.authority_type = '1'
                 and b.enterprise_no = strEnterpriseNo
              union
              select distinct b.owner_no
                from bset_worker_owner b, bdef_defworker d
               where b.enterprise_no = d.enterprise_no
                 and b.worker_no = d.worker_no
                 and b.worker_no = strUserId
                 and b.enterprise_no = strEnterpriseNo) a
       where a.owner_no = m.owner_no;

      if v_count = 0 then
        strResult := 'N|[' || m.owner_no || '货主，用户没有货主权限]';
        return;
      end if;

      --检查同一货主同一采购单的供应商编码、单据类型、提货类型、采购发单日、预计到货日、到期日是否一样
      select count(*)
        into v_count
        from (select t.warehouse_no, t.owner_no, t.po_no
                from idata_import_tmp t
               where t.enterprise_no = m.enterprise_no
                 and t.warehouse_no = m.warehouse_no
                 and t.owner_no = t.owner_no
                 and t.po_no = m.po_no
               group by t.warehouse_no,
                        t.owner_no,
                        t.po_no,
                        t.po_type,
                        t.take_type,
                        t.request_date,
                        t.order_date,
                        t.end_date,
                        rsv_varod1,
                        rsv_varod2,
                        rsv_varod3,
                        rsv_varod4,
                        rsv_varod5,
                        rsv_varod6,
                        rsv_varod7,
                        rsv_varod8,
                        rsv_num1,
                        rsv_num2,
                        rsv_num3,
                        rsv_date1,
                        rsv_date2,
                        rsv_date3);
      if v_count >= 2 then
        strResult := 'N|[单号为' || m.po_no ||
                     '的供应商编码、单据类型、提货类型、采购发单日、预计到货日、到期日、卸货方式不一样]';
        --更新临时表状态
        update idata_import_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and status = '11';
        return;
      end if;

      --检查同一货主同一采购单的商品是否重复
      select count(*)
        into v_count
        from (select t.warehouse_no,
                     t.owner_no,
                     t.po_no,
                     t.po_type,
                     t.request_date,
                     t.order_date,
                     t.end_date,
                     t.owner_article_no,
                     t.packing_qty
                from idata_import_tmp t
               where t.enterprise_no = m.enterprise_no
                 and t.warehouse_no = m.warehouse_no
                 and t.owner_no = t.owner_no
                 and t.po_no = m.po_no
               group by t.warehouse_no,
                        t.owner_no,
                        t.po_no,
                        t.po_type,
                        t.request_date,
                        t.order_date,
                        t.end_date,
                        t.owner_article_no,
                        t.packing_qty);

      select count(*)
        into v_count_1
        from (select t.warehouse_no, t.owner_no, t.po_no
                from idata_import_tmp t
               where t.enterprise_no = m.enterprise_no
                 and t.warehouse_no = m.warehouse_no
                 and t.owner_no = t.owner_no
                 and t.po_no = m.po_no);

      if v_count < v_count_1 then
        strResult := 'N|[单号为' || m.po_no || '的同一货主商品编码同一包装有重复数据，请检查]';
        --更新临时表状态
        update idata_import_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and status = '11';
        return;
      end if;

      --检查原单号是否已存在
      select count(1)
        into v_count
        from idata_import_m
       where po_no = m.po_no
         and enterprise_no = strEnterpriseNo
         and warehouse_no = strWareHouseNo;
      if v_count > 0 then
        strResult := 'N|[请检查' || m.po_no || '原单号已存在]'; --原单号已存在
        --更新临时表状态
        update idata_import_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and owner_no = m.owner_no
           and status = '11';
        return;
      end if;

      --判断供应商是否存在
      select count(1)
        into v_count
        from bdef_defsupplier
       where supplier_no = m.supplier_no
         and enterprise_no = strEnterpriseNo
         and owner_no = m.owner_no;
      if v_count = 0 then
        strResult := 'N|[' || m.supplier_no || '供应商不存在]'; --供应商不存在
        --更新临时表状态
        update idata_import_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and owner_no = m.owner_no
           and status = '11';
        return;
      end if;

      --检查单据类型是否存在
      select count(1) into v_count from wms_idatatype t where t.enterprise_no=strEnterpriseNo
      and t.class_type='0' and t.import_type=m.po_type;

      if v_count = 0 then
        strResult := 'N|[' || m.po_type || '单据类型不是存储类型]';
        --更新临时表状态
        update idata_import_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and owner_no = m.owner_no
           and status = '11';
        return;
      end if;

      --检查提货类型是否存在
      select count(1)
        into v_count
        from wms_deffieldval
       where table_name = 'N'
         and colname = 'TAKE_TYPE'
         and value = m.take_type
         and status = '1';

      if v_count = 0 then
        strResult := 'N|[' || m.take_type || '提货类型不存在]';
        --更新临时表状态
        update idata_import_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and owner_no = m.owner_no
           and status = '11';
        return;
      end if;

     --add by huangcx 20160614
      if m.rsv_varod1 is not null or m.rsv_varod1<>''  then
         --检查卸货方式是否存在
        select count(1) into v_count
          from wms_deffieldval
         where table_name='N'
           and colname='UNLOAD_TYPE'
           and value=m.rsv_varod1 and status='1';

        if v_count = 0 then
          strResult:= 'N|[' || m.take_type || '卸货方式不存在]';
          --更新临时表状态
          update idata_import_tmp set status='16' where enterprise_no=strEnterpriseNo and warehouse_no=strWareHouseNo
          and po_no=m.po_no and owner_no=m.owner_no and status='11';
          return;
        end if;
      end if;
      --end add

      --检查采购发单日
      if m.request_date < m.order_date then
        strResult := 'N|[单号为' || m.po_no || '的进货单预订到货日小于采购发单日]';
        --更新临时表状态
        update idata_import_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and owner_no = m.owner_no
           and status = '11';
        return;
      end if;

      --到期日
      v_endDate := m.end_date;
      if v_endDate <= 0 then
        strResult := 'N|[单号为' || m.po_no || '的进货单到期日小于或等于0，请检查]'; --到期日不能小于或等于0
        --更新临时表状态
        update idata_import_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and owner_no = m.owner_no
           and status = '11';
        return;
      end if;

      for a in (select *
                  from idata_import_tmp rrt
                 where rrt.enterprise_no = strEnterpriseNo
                   and rrt.warehouse_no = strWareHouseNo
                   and rrt.owner_no = m.owner_no
                   and rrt.po_no = m.po_no) loop
        --检查该商品是否存在
        select count(1)
          into v_count
          from bdef_defarticle
         where owner_article_no = a.owner_article_no
           and enterprise_no = strEnterpriseNo
           and owner_no = a.owner_no;
        if v_count = 0 then
          strResult := 'N|[第' || a.Row_Id || '条货主商品编码[' ||
                       a.owner_article_no || ']不存在]'; --商品不存在
          --更新临时表状态
          update idata_import_tmp
             set status = '16'
           where enterprise_no = strEnterpriseNo
             and warehouse_no = strWareHouseNo
             and po_no = m.po_no
             and row_id = a.row_id
             and status = '11';
          return;
        else
          select article_no
            into v_article_no
            from bdef_defarticle
           where owner_article_no = a.owner_article_no
             and enterprise_no = strEnterpriseNo
             and owner_no = a.owner_no;

        end if;

        --检查商品包装是否存在
        if a.packing_qty = 0 then
          strResult := 'N|[单号为' || m.po_no || '的数据中有商品包装为0，请检查]';
          --更新临时表状态
          update idata_import_tmp
             set status = '16'
           where enterprise_no = strEnterpriseNo
             and warehouse_no = strWareHouseNo
             and po_no = m.po_no
             and row_id = a.row_id
             and status = '11'
             and packing_qty = 0;
          return;
        end if;

        if a.packing_qty <> 1 then
          --校验包装是否存在
          select count(1)
            into v_count
            from BDEF_ARTICLE_PACKING
           where article_no = v_article_no
             and packing_qty = a.packing_qty
             and enterprise_no = a.enterprise_no;
          if v_count = 0 then
            --不存在则调用自动产生包装的过程
            P_idata_import_article(strEnterpriseNo,
                                   strWareHouseNo,
                                   a.owner_no,
                                   v_article_no,
                                   a.packing_qty,
                                   strUserId,
                                   strResult);
            if strResult <> 'Y' then
              strResult := 'N|[第' || a.Row_Id || '商品【' || v_article_no ||
                           '】自动插入包装错误！]';
              --更新临时表状态
              update idata_import_tmp
                 set status = '16'
               where enterprise_no = strEnterpriseNo
                 and warehouse_no = strWareHouseNo
                 and po_no = m.po_no
                 and row_id = a.row_id
                 and status = '11';
              return;
            end if;

            --校验包装是否存在（如果货主表配置的是不自动产生包装，则要判断）
            select count(1)
              into v_count
              from bdef_article_packing b
             where b.article_no = v_article_no
               and b.enterprise_no = strEnterpriseNo
               and b.packing_qty = a.packing_qty;
            if v_count = 0 then
              select count(1) --是否为最小操作包装数
                into n_qmin_operate_packing
                from bdef_defarticle b
               where b.enterprise_no = strEnterpriseNo
                 and b.owner_no = a.owner_no
                 and b.owner_article_no = a.owner_article_no
                 and b.qmin_operate_packing=a.packing_qty;
                 if n_qmin_operate_packing =0 then
              strResult := 'N|[第' || a.Row_Id || '条商品【' || v_article_no ||
                           '】包装不存在]'; --商品包装不存在
              --更新临时表状态
              update idata_import_tmp
                 set status = '16'
               where enterprise_no = strEnterpriseNo
                 and warehouse_no = strWareHouseNo
                 and po_no = m.po_no
                 and row_id = a.row_id
                 and status = '11';
              return;
              end if;
            end if;
          end if;
        end if;
        --检查商品退货量是否大于0
        if a.po_qty <= 0 then
          strResult := 'N|[第' || a.Row_Id || '的数据商品数量小于等于0，请检查]';
          --更新临时表状态
          update idata_import_tmp
             set status = '16'
           where enterprise_no = strEnterpriseNo
             and warehouse_no = strWareHouseNo
             and po_no = m.po_no
             and row_id = a.row_id
             and status = '11';
          return;
        end if;
      end loop;
      --取进货单号
      PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                 strWareHouseNo,
                                 CONST_DOCUMENTTYPE.IDATAIMPORTIS,
                                 v_import_no,
                                 v_result);

      --插入单头
      insert into idata_import_m
        (enterprise_no,
         warehouse_no,
         owner_no,
         import_type,
         import_no,
         po_type,
         take_type,
         po_no,
         supplier_no,
         order_date,
         request_date,
         status,
         create_flag,
         import_remark,
         end_date,
         order_end_date,
         with_code_flag,
         rgst_name,
         rgst_date,
         rsv_varod1,
         rsv_varod2,
         rsv_varod3,
         rsv_varod4,
         rsv_varod5,
         rsv_varod6,
         rsv_varod7,
         rsv_varod8,
         rsv_num1,
         rsv_num2,
         rsv_num3,
         rsv_date1,
         rsv_date2,
         rsv_date3)
      values
        (strEnterpriseNo,
         strWareHouseNo,
         m.owner_no,
         m.po_type,
         v_import_no,
         m.po_type,
         m.take_type,
         m.po_no,
         m.supplier_no,
         m.order_date,
         m.request_date,
         10,
         0,
         m.import_remark,
         m.end_date,
         m.order_date + m.end_date,
         0,
         strUserId,
         sysdate,
         m.rsv_varod1,
         m.rsv_varod2,
         m.rsv_varod3,
         m.rsv_varod4,
         m.rsv_varod5,
         m.rsv_varod6,
         m.rsv_varod7,
         m.rsv_varod8,
         m.rsv_num1,
         m.rsv_num2,
         m.rsv_num3,
         m.rsv_date1,
         m.rsv_date2,
         m.rsv_date3);
      if sql%rowcount <= 0 then
        strResult := 'N|[E20501]'; --插入单头失败];
        return;
      end if;
      --插入明细
      --规则：无散数直接插入数据,有散数再去判断是否可以被商品表最小操作包装数整除，不可以则报异常，可以则插入两条数据
   /*   for iit in (select *
                    from idata_import_tmp rrt
                   where rrt.enterprise_no = strEnterpriseNo
                     and rrt.warehouse_no = strWareHouseNo
                     and rrt.owner_no = m.owner_no) loop
        if (mod(iit.po_qty, iit.packing_qty) = 0) then
          insert into idata_import_d
            (enterprise_no,
             warehouse_no,
             owner_no,
             import_no,
             article_no,
             packing_qty,
             po_qty,
             import_qty,
             po_id,
             status,
             unit_cost)
            select strEnterpriseNo,
                   strWareHouseNo,
                   iit.owner_no,
                   v_import_no,
                   bd.article_no,
                   iit.packing_qty,
                   iit.po_qty,
                   0,
                   ROW_NUMBER() OVER(PARTITION BY iit.po_no ORDER BY iit.owner_article_no) po_id,
                   '10',
                   iit.unit_cost
              from bdef_defarticle bd
             where iit.enterprise_no = bd.enterprise_no
               and iit.owner_no = bd.owner_no
               and iit.owner_article_no = bd.owner_article_no
               and iit.po_no = m.po_no;

          if sql%rowcount <= 0 then
            strResult := 'N|[E23211]'; --插入明细失败
          end if;
        else
          select qmin_operate_packing
            into n_qmin_operate_packing
            from bdef_defarticle a
           where a.enterprise_no = strEnterpriseNo
             and a.owner_no = iit.owner_no
             and a.owner_article_no = iit.owner_article_no;
          if (mod(mod(iit.po_qty, iit.packing_qty), n_qmin_operate_packing) != 0) then

            strResult := 'N|[第' || iit.Row_Id || '的散数不能被最小操作包装整除，请检查]';
            return;
          else
            insert into idata_import_d
              (enterprise_no,
               warehouse_no,
               owner_no,
               import_no,
               article_no,
               packing_qty,
               po_qty,
               import_qty,
               po_id,
               status,
               unit_cost)
              select strEnterpriseNo,
                     strWareHouseNo,
                     iit.owner_no,
                     v_import_no,
                     bd.article_no,
                     iit.packing_qty,
                     trunc(iit.po_qty, iit.packing_qty) * iit.packing_qty,
                     0,
                     ROW_NUMBER() OVER(PARTITION BY iit.po_no ORDER BY iit.owner_article_no) po_id,
                     '10',
                     iit.unit_cost
                from bdef_defarticle bd
               where iit.enterprise_no = bd.enterprise_no
                 and iit.owner_no = bd.owner_no
                 and iit.owner_article_no = bd.owner_article_no
                 and iit.po_no = m.po_no;

            if sql%rowcount <= 0 then
              strResult := 'N|[E23211]'; --插入明细失败
            end if;
            insert into idata_import_d
              (enterprise_no,
               warehouse_no,
               owner_no,
               import_no,
               article_no,
               packing_qty,
               po_qty,
               import_qty,
               po_id,
               status,
               unit_cost)
              select strEnterpriseNo,
                     strWareHouseNo,
                     iit.owner_no,
                     v_import_no,
                     bd.article_no,
                     n_qmin_operate_packing,
                     mod(iit.po_qty, iit.packing_qty),
                     0,
                     ROW_NUMBER() OVER(PARTITION BY iit.po_no ORDER BY iit.owner_article_no) po_id,
                     '10',
                     iit.unit_cost
                from bdef_defarticle bd
               where iit.enterprise_no = bd.enterprise_no
                 and iit.owner_no = bd.owner_no
                 and iit.owner_article_no = bd.owner_article_no
                 and iit.po_no = m.po_no;

            if sql%rowcount <= 0 then
              strResult := 'N|[E23211]'; --插入明细失败
            end if;
          end if;
        end if;
      end loop;
    */
      insert into idata_import_d(
             enterprise_no,
             warehouse_no,
             owner_no,
             import_no,
             article_no,
             packing_qty,
             po_qty,
             import_qty,
             po_id,
             status,
             unit_cost)
      select strEnterpriseNo,
             strWareHouseNo,
             iit.owner_no,
             v_import_no,
             bd.article_no,
             case when iit.packing_qty=1 then (select nvl(max(bap.packing_qty),1) from bdef_article_packing bap
             where bap.article_no=bd.article_no and bap.enterprise_no=bd.enterprise_no) else iit.packing_qty end,
             iit.po_qty,
             0,
             ROW_NUMBER() OVER(PARTITION BY iit.po_no ORDER BY iit.owner_article_no) po_id,
             '10',
             iit.unit_cost
       from idata_import_tmp iit,
            bdef_defarticle bd
       where iit.enterprise_no=bd.enterprise_no
         and iit.owner_no=bd.owner_no
         and iit.owner_article_no=bd.owner_article_no
         and iit.po_no=m.po_no;

      if sql%rowcount <= 0 then
        strResult := 'N|[E23211]';--插入明细失败
      end if;

      --获取进货配置 判断是否自动集单
      PKLG_WMS_Public.P_GetIdataOrder(strEnterpriseNo,  strWareHouseNo,
              m.owner_no,m.po_type, 'AUTOCOLLECTORDER', v_strFlag,strResult);

      if substr(strResult, 1, 1) = 'N' then
        strResult := 'N|获取进货配置错误';
        return;
      end if;

      if v_strFlag = '1' then
        --自动集单
        v_strNewS_Import_No := 'N';
        pklg_idata.p_single_set(strEnterpriseNo,
                                strWareHouseNo,
                                v_import_no,
                                v_strNewS_Import_No, --原汇总单号,没有则传N
                                strUserId,
                                v_strNewS_Import_No, --返回的汇总单号
                                strResult);
        if substr(strResult, 1, 1) <> 'Y' then
          return;
        end if;

      end if;
      --商品导入成功，修改临时表状态为13（成功）
      update idata_import_tmp
         set status = '13'
       where enterprise_no = strEnterpriseNo
         and warehouse_no = strWareHouseNo
         and po_no = m.po_no
         and owner_no = m.owner_no
         and status = '11';
    end loop;

    delete from idata_import_tmp
     where warehouse_no = strWareHouseNo
       and status = '13'
       and enterprise_no = strEnterpriseNo;

    strResult := 'Y|导入成功';
  end P_idata_import;
  /*************************************************************************************************
   创建人：hekl
   创建时间：2015.11.30
   修改人：czh     2016/5/18
   功能说明：直通进货手建单excel导入
  **************************************************************************************************/
  procedure P_idata_import_id(strEnterpriseNo in idata_import_tmp.enterprise_no%type,
                              strWareHouseNo  in idata_import_tmp.warehouse_no%type,
                              strUserId       in bdef_defworker.worker_no%type,
                              strResult       out varchar2) is
    v_count                number;
    v_count_1              number;
    nRowID                 number;
    v_import_no            varchar2(50);
    v_odataexp_no          varchar2(50);
    v_article_no           varchar2(20);
    v_strCustNo            bdef_defcust.cust_no%type;
    v_strPoNo              IDATA_IMPORT_ALLOT.PO_NO%TYPE;
    v_strNewS_Import_No    idata_import_mm.s_import_no%type;
    v_strFlag              wms_defbase.sdefine%type;
    v_nFlag                wms_defbase.ndefine%type;
    n_qmin_operate_packing number;
  begin
    update idata_import_tmp i
       set i.status = '11'
     where i.enterprise_no = strEnterpriseNo
       and i.warehouse_no = strWareHouseNo;

    --检查进货单是否有重复单号
    select count(*)
      into v_count_1
      from idata_import_m m, idata_import_tmp tm
     where m.po_no = tm.po_no
       and m.enterprise_no = tm.enterprise_no
       and m.enterprise_no = strEnterpriseNo;
    if v_count_1 > 0 then
      select po_no
        into v_strPoNo
        from (select tm.po_no
                from idata_import_m m, idata_import_tmp tm
               where m.po_no = tm.po_no
                 and m.enterprise_no = tm.enterprise_no
                 and m.enterprise_no = strEnterpriseNo)
       where rownum = 1;
      strResult := 'N|[该' || v_strPoNo || '采购单号已存在，请检查！]';
      return;
    end if;

    --检查出货原单号是否存在
    select count(*)
      into v_count_1
      from idata_import_allot m, idata_import_tmp tm
     where m.po_no = tm.odataexp_no
       and m.enterprise_no = tm.enterprise_no
       and m.enterprise_no = strEnterpriseNo;
    if v_count_1 > 0 then
      select odataexp_no
        into v_strPoNo
        from (select tm.odataexp_no
                from idata_import_allot m, idata_import_tmp tm
               where m.po_no = tm.odataexp_no
                 and m.enterprise_no = tm.enterprise_no
                 and m.enterprise_no = strEnterpriseNo)
       where rownum = 1;
      strResult := 'N|[该' || v_strPoNo || '出货原单号已存在，请检查！]';
      return;
    end if;
    --获取临时表数据
    for tmp in (select *
                  from idata_import_tmp a
                 where a.enterprise_no = strEnterpriseNo
                   and a.warehouse_no = strWareHouseNo
                   and a.status = '11'
                 order by a.po_no, a.owner_article_no, a.cust_no

                ) loop
      --判断货主是否存在
      select count(1)
        into v_count
        from bdef_defowner
       where owner_no = tmp.owner_no
         and enterprise_no = strEnterpriseNo;
      if v_count = 0 then
        strResult := 'N|[请检查第' || tmp.Row_Id || '条货主]'; --货主不存在
        return;
      end if;

      --检查货主是否有权限
      select count(*)
        into v_count
        from (select distinct b.owner_no
                from bdef_defowner b, bdef_defworker d
               where b.enterprise_no = d.enterprise_no
                 and d.worker_no = strUserId
                 and b.authority_type = '1'
                 and b.enterprise_no = strEnterpriseNo
              union
              select distinct b.owner_no
                from bset_worker_owner b, bdef_defworker d
               where b.enterprise_no = d.enterprise_no
                 and b.worker_no = d.worker_no
                 and b.worker_no = strUserId
                 and b.enterprise_no = strEnterpriseNo) a
       where a.owner_no = tmp.owner_no;
      if v_count = 0 then
        strResult := 'N|[第' || tmp.row_id || '条数据，用户没有货主权限]';
        return;
      end if;

      --判断供应商是否存在
      select count(1)
        into v_count
        from bdef_defsupplier
       where supplier_no = tmp.supplier_no
         and owner_no = tmp.owner_no
         and enterprise_no = strEnterpriseNo;
      if v_count = 0 then
        strResult := 'N|[第' || tmp.Row_Id || '条供应商不存在]'; --供应商不存在
        return;
      end if;

      --判断客户是否存在
      select count(1)
        into v_count
        from bdef_defcust
       where owner_cust_no = tmp.cust_no
         and owner_no = tmp.owner_no
         and enterprise_no = strEnterpriseNo;
      if v_count = 0 then
        strResult := 'N|[第' || tmp.Row_Id || '条货主客户编号不存在]'; --客户不存在
        return;
      else
        select cust_no
          into v_strCustNo
          from bdef_defcust
         where owner_cust_no = tmp.cust_no
           and owner_no = tmp.owner_no
           and enterprise_no = strEnterpriseNo;
      end if;

      --检查直通单据类型是否存在
      select count(1) into v_count from wms_idatatype t where t.enterprise_no=strEnterpriseNo
         and t.class_type='1' and t.import_type=tmp.po_type;

      if v_count = 0 then
        strResult := 'N|[第' || tmp.Row_Id || '条单据类型不是直通类型]';
        return;
      end if;

      --检查提货类型是否存在
      select count(1)
        into v_count
        from wms_deffieldval
       where table_name = 'N'
         and colname = 'TAKE_TYPE'
         and value = tmp.take_type
         and status = '1';
      if v_count = 0 then
        strResult := 'N|[第' || tmp.Row_Id || '条提货类型不存在]';
        return;
      end if;

      --检查提货类型是否存在
      select count(1)
        into v_count
        from wms_deffieldval
       where table_name = 'N'
         and colname = 'TAKE_TYPE'
         and value = tmp.allot_take_type
         and status = '1';
      if v_count = 0 then
        strResult := 'N|[第' || tmp.Row_Id || '条配送提货类型不存在]';
        return;
      end if;
      --add by huangcx 20160614
      if tmp.rsv_varod1 is not null or tmp.rsv_varod1<>''  then
        --检查卸货方式是否存在
        select count(1) into v_count
          from wms_deffieldval
         where table_name='N'
           and colname='UNLOAD_TYPE'
           and value=tmp.rsv_varod1 and status='1';

        if v_count = 0 then
          strResult:= 'N|[' || tmp.take_type || '卸货方式不存在]';
          return;
        end if;
      end if;
      -- end add
      --检查采购发单日
      if tmp.request_date < tmp.order_date then
        strResult := 'N|[第' || tmp.Row_Id || '条预订到货日小于采购发单日]';
        return;
      end if;

      --到期日
      if tmp.end_date <= 0 then
        strResult := 'N|[请检查第' || tmp.Row_Id || '条到期日，到期日不能小于或等于0]'; --到期日不能小于或等于0
        return;
      end if;

      --检查同一货主同一采购单的供应商编码、单据类型、提货类型、采购发单日、预计到货日、到期日是否一样
      select count(*)
        into v_count
        from (select m.warehouse_no, m.owner_no, m.po_no
                from idata_import_tmp m
               where tmp.enterprise_no = m.enterprise_no
                 and tmp.warehouse_no = m.warehouse_no
                 and tmp.owner_no = m.owner_no
                 and tmp.po_no = m.po_no
               group by m.warehouse_no,
                        m.owner_no,
                        m.po_no,
                        m.po_type,
                        m.take_type,
                        m.request_date,
                        m.order_date,
                        m.end_date,
                        m.rsv_varod1,
                        m.rsv_varod2,
                        m.rsv_varod3,
                        m.rsv_varod4,
                        m.rsv_varod5,
                        m.rsv_varod6,
                        m.rsv_varod7,
                        m.rsv_varod8,
                        m.rsv_num1,
                        m.rsv_num2,
                        m.rsv_num3,
                        m.rsv_date1,
                        m.rsv_date2,
                        m.rsv_date3);
      if v_count >= 2 then
        strResult := 'N|[单号为' || tmp.po_no ||
                     '的供应商编码、单据类型、提货类型、采购发单日、预计到货日、到期日、卸货方式不一样]';
        return;
      end if;

      --检查同一货主同一采购单的一个商品的采购量、采购价格是否一样
      select count(*)
        into v_count
        from (select m.warehouse_no, m.owner_no, m.po_no
                from idata_import_tmp m
               where tmp.enterprise_no = m.enterprise_no
                 and tmp.warehouse_no = m.warehouse_no
                 and tmp.owner_no = m.owner_no
                 and tmp.po_no = m.po_no
                 and tmp.owner_article_no = m.owner_article_no
               group by m.warehouse_no,
                        m.owner_no,
                        m.po_no,
                        m.po_type,
                        m.owner_article_no,
                        m.po_qty,
                        m.unit_cost);
      if v_count >= 2 then
        strResult := 'N|[单号为' || tmp.po_no || '【' || tmp.owner_article_no || '】' ||
                     '的采购量、采购价格不一样]';
        return;
      end if;

      --检查同一个客户的出货单号、配送提货类型是否一样
      select count(*)
        into v_count
        from (select m.warehouse_no, m.owner_no, m.po_no
                from idata_import_tmp m
               where tmp.enterprise_no = m.enterprise_no
                 and tmp.warehouse_no = m.warehouse_no
                 and tmp.owner_no = m.owner_no
                 and tmp.po_no = m.po_no
                 and m.cust_no = tmp.cust_no
               group by m.warehouse_no,
                        m.owner_no,
                        m.po_no,
                        m.po_type,
                        m.cust_no,
                        m.odataexp_no,
                        m.allot_take_type);
      if v_count >= 2 then
        strResult := 'N|[第' || tmp.row_id || '行【' || tmp.cust_no || '】' ||
                     '的出货单号、配送提货类型是不一样]';
        return;
      end if;

      --检查该商品是否存在
      begin
        select article_no
          into v_article_no
          from bdef_defarticle
         where owner_article_no = tmp.owner_article_no
           and enterprise_no = tmp.enterprise_no
           and owner_no = tmp.owner_no;
      exception
        when no_data_found then
          strResult := 'N|[第' || tmp.Row_Id || '条商品编码不存在]';
          return;
      end;

      --检查商品包装
      IF tmp.packing_qty <> 1 then

        --校验包装是否存在
        select count(1)
          into v_count
          from BDEF_ARTICLE_PACKING
         where article_no = v_article_no
           and packing_qty = tmp.packing_qty
           and enterprise_no = tmp.enterprise_no;
        if v_count = 0 then
          --（不存在则写包装）自动插入包装
          P_idata_import_article(strEnterpriseNo,
                                 strWareHouseNo,
                                 tmp.owner_no,
                                 v_article_no,
                                 tmp.packing_qty,
                                 strUserId,
                                 strResult);
          if strResult <> 'Y' then
            strResult := 'N|[第' || tmp.Row_Id || '自动插入包装错误！]';
            return;
          end if;

          --校验包装是否存在（如果配置的是不自动插入包装则要校验该包装是否存在）
          select count(1)
            into v_count
            from BDEF_ARTICLE_PACKING
           where article_no = v_article_no
             and packing_qty = tmp.packing_qty
             and enterprise_no = tmp.enterprise_no;
          if v_count = 0 then
            select count(1) --是否为最小操作包装数
                into n_qmin_operate_packing
                from bdef_defarticle b
               where b.enterprise_no = strEnterpriseNo
                 and b.owner_no = tmp.owner_no
                 and b.owner_article_no = tmp.owner_article_no
                 and b.qmin_operate_packing=tmp.packing_qty;
                 if n_qmin_operate_packing =0 then
            strResult := 'N|[第' || tmp.Row_Id || '条商品包装不存在]';
            return;
            end if;
          end if;

        end if;
      end if;

      --检查商品采购量或配量是否大于0
      if tmp.po_qty <= 0 or tmp.allot_qty <= 0 then
        strResult := 'N|[单号为' || tmp.po_no || '的数据中有数量小于等于0，请检查]';
        return;
      end if;

      --判断单号是否已经存在
      select count(1)
        into v_count
        from idata_import_m
       where po_no = tmp.po_no
         and warehouse_no = strWareHouseNo
         and enterprise_no = strEnterpriseNo
         and status < '13';
      if v_count = 0 then

        PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                   strWareHouseNo,
                                   CONST_DOCUMENTTYPE.IDATAIMPORTID,
                                   v_import_no,
                                   strResult);

        insert into idata_import_m
          (enterprise_no,
           warehouse_no,
           owner_no,
           import_type,
           import_no,
           po_type,
           take_type,
           po_no,
           supplier_no,
           order_date,
           request_date,
           status,
           create_flag,
           import_remark,
           end_date,
           order_end_date,
           with_code_flag,
           rgst_name,
           rgst_date,
           rsv_varod1,
           rsv_varod2,
           rsv_varod3,
           rsv_varod4,
           rsv_varod5,
           rsv_varod6,
           rsv_varod7,
           rsv_varod8,
           rsv_num1,
           rsv_num2,
           rsv_num3,
           rsv_date1,
           rsv_date2,
           rsv_date3,class_type)
        values
          (strEnterpriseNo,
           strWareHouseNo,
           tmp.owner_no,
           tmp.po_type,
           v_import_no,
           tmp.po_type,
           tmp.take_type,
           tmp.po_no,
           tmp.supplier_no,
           tmp.order_date,
           tmp.request_date,
           10,
           0,
           tmp.import_remark,
           tmp.end_date,
           tmp.order_date + tmp.end_date,
           0,
           strUserId,
           sysdate,
           tmp.rsv_varod1,
           tmp.rsv_varod2,
           tmp.rsv_varod3,
           tmp.rsv_varod4,
           tmp.rsv_varod5,
           tmp.rsv_varod6,
           tmp.rsv_varod7,
           tmp.rsv_varod8,
           tmp.rsv_num1,
           tmp.rsv_num2,
           tmp.rsv_num3,
           tmp.rsv_date1,
           tmp.rsv_date2,
           tmp.rsv_date3,'1');

        if sql%rowcount <= 0 then
          strResult := 'N|[第' || tmp.Row_Id || '条写入单头错误]';
          return;
        end if;

      end if;

      --判断该单的该商品是否在明细表已经存在，已存在不新增明细
      select count(1)
        into v_count
        from idata_import_d
       where import_no = v_import_no
         and article_no = v_article_no
         and warehouse_no = strWareHouseNo
         and enterprise_no = strEnterpriseNo
         and status = '10';

      if v_count = 0 then

        --写明细
        --规则：无散数直接插入数据,有散数再去判断是否可以被商品表最小操作包装数整除，不可以则报异常，可以则插入两条数据
       /* select nvl(max(po_id) + 1, 1)
          into nRowID
          from idata_import_d d
         where d.warehouse_no = strWareHouseNo
           and d.enterprise_no = strEnterpriseNo
           and d.owner_no = tmp.owner_no
           and d.import_no = v_import_no;
        if (mod(tmp.po_qty, tmp.packing_qty) = 0) then
          insert into idata_import_d
            (warehouse_no,
             owner_no,
             import_no,
             article_no,
             packing_qty,
             po_qty,
             import_qty,
             status,
             out_stock_flag,
             item_type,
             qc_status,
             qc_flag,
             po_id,
             enterprise_no,
             unit_cost)
          values
            (strWareHouseNo,
             tmp.owner_no,
             v_import_no,
             v_article_no,
             TMP.PACKING_QTY,
             tmp.po_qty,
             '0',
             '10',
             '0',
             '0',
             '0',
             '0',
             nRowID,
             strEnterpriseNo,
             tmp.unit_cost);
        else
          select qmin_operate_packing
            into n_qmin_operate_packing
            from bdef_defarticle a
           where a.enterprise_no = strEnterpriseNo
             and a.owner_no = tmp.owner_no
             and a.owner_article_no = tmp.owner_article_no;
        end if;
        if (mod(mod(tmp.po_qty, tmp.packing_qty), n_qmin_operate_packing) != 0) then
          strResult := 'N|[第' || tmp.Row_Id || '的散数不能被最小操作包装整除，请检查]';
          return;
        else
          insert into idata_import_d
            (enterprise_no,
             warehouse_no,
             owner_no,
             import_no,
             article_no,
             packing_qty,
             po_qty,
             import_qty,
             po_id,
             status,
             unit_cost)
            select strEnterpriseNo,
                   strWareHouseNo,
                   tmp.owner_no,
                   v_import_no,
                   bd.article_no,
                   tmp.packing_qty,
                   trunc(tmp.po_qty, tmp.packing_qty) * tmp.packing_qty,
                   0,
                   ROW_NUMBER() OVER(PARTITION BY tmp.po_no ORDER BY tmp.owner_article_no) po_id,
                   '10',
                   tmp.unit_cost
              from bdef_defarticle bd
             where tmp.enterprise_no = bd.enterprise_no
               and tmp.owner_no = bd.owner_no
               and tmp.owner_article_no = bd.owner_article_no;

          if sql%rowcount <= 0 then
            strResult := 'N|[E23211]'; --插入明细失败
          end if;
          insert into idata_import_d
            (enterprise_no,
             warehouse_no,
             owner_no,
             import_no,
             article_no,
             packing_qty,
             po_qty,
             import_qty,
             po_id,
             status,
             unit_cost)
            select strEnterpriseNo,
                   strWareHouseNo,
                   tmp.owner_no,
                   v_import_no,
                   bd.article_no,
                   n_qmin_operate_packing,
                   mod(tmp.po_qty, tmp.packing_qty),
                   0,
                   ROW_NUMBER() OVER(PARTITION BY tmp.po_no ORDER BY tmp.owner_article_no) po_id,
                   '10',
                   tmp.unit_cost
              from bdef_defarticle bd
             where tmp.enterprise_no = bd.enterprise_no
               and tmp.owner_no = bd.owner_no
               and tmp.owner_article_no = bd.owner_article_no;

          if sql%rowcount <= 0 then
            strResult := 'N|[E23211]'; --插入明细失败
          end if;
        end if;*/
        --写明细
        select nvl(max(po_id) + 1, 1)
          into nRowID
          from idata_import_d d
         where d.warehouse_no = strWareHouseNo
           and d.enterprise_no = strEnterpriseNo
           and d.owner_no = tmp.owner_no
           and d.import_no = v_import_no;

        insert into idata_import_d
          (warehouse_no,
           owner_no,
           import_no,
           article_no,
           packing_qty,
           po_qty,
           import_qty,
           status,
           out_stock_flag,
           item_type,
           qc_status,
           qc_flag,
           po_id,
           enterprise_no,
           unit_cost)
        values
          (strWareHouseNo,
           tmp.owner_no,
           v_import_no,
           v_article_no,
           TMP.PACKING_QTY,
           tmp.po_qty,
           '0',
           '10',
           '0',
           '0',
           '0',
           '0',
           nRowID,
           strEnterpriseNo,
           tmp.unit_cost);

      end if;

      --写配量出货单号新取号
      /*   if v_strCustNo<>tmp.cust_no then
                   pklg_wms_base.p_getsheetno(strEnterpriseNo,strWareHouseNo,
                                            CONST_DOCUMENTTYPE.ODATAOE,
                                            v_strPoNo,
                                            strResult);
                end if;
      */
      --写配量，更新不到则新增
      /* update idata_import_allot o
      set o.po_qty = o.po_qty+TMP.ALLOT_QTY
      where o.warehouse_no = strWareHouseNo
      AND O.ENTERPRISE_NO=strEnterpriseNo
      and o.owner_no = TMP.OWNER_NO
      and o.import_no = v_import_no
      and o.article_no = v_article_no
      and o.packing_qty = TMP.PACKING_QTY
      and o.cust_no = v_strCustNo
      and o.po_no=tmp.odataexp_no;


      if sql%notfound then
          insert into idata_import_allot
             (ENTERPRISE_NO,
             warehouse_no,
              owner_no,
              import_no,
              article_no,
              packing_qty,
              po_qty,
              allot_qty,
              status,
              sub_cust_no,
              cust_no,
              rgst_name,
              rgst_date,
              po_no)
          values
             (strEnterpriseNo,
             strWareHouseNo,
              TMP.OWNER_NO,
              v_import_no,
              v_article_no,
              TMP.PACKING_QTY,
              TMP.ALLOT_QTY,
              '0',
              '10',
              v_strCustNo,
              v_strCustNo,
              strUserId,
              sysdate,
              tmp.odataexp_no);

      end  if;*/

      --判断该单的该客户的该商品是否在已经存在，已存在拦截
      select count(1)
        into v_count
        from idata_import_allot
       where import_no = v_import_no
         and article_no = v_article_no
         and cust_no = v_strCustNo
         and warehouse_no = strWareHouseNo
         and enterprise_no = strEnterpriseNo
         and status = '10';
      if v_count > 0 then
        strResult := 'N|[第' || tmp.Row_Id || '行的原单号的客户的商品重复]';
        return;
      end if;

      insert into idata_import_allot
        (ENTERPRISE_NO,
         warehouse_no,
         owner_no,
         import_no,
         article_no,
         packing_qty,
         po_qty,
         allot_qty,
         status,
         sub_cust_no,
         cust_no,
         rgst_name,
         rgst_date,
         po_no,
         take_type)
      values
        (strEnterpriseNo,
         strWareHouseNo,
         TMP.OWNER_NO,
         v_import_no,
         v_article_no,
         TMP.PACKING_QTY,
         TMP.ALLOT_QTY,
         '0',
         '10',
         v_strCustNo,
         v_strCustNo,
         strUserId,
         sysdate,
         tmp.odataexp_no,
         tmp.allot_take_type);

      --导入成功，修改临时表状态为13（成功）
      update idata_import_tmp
         set status = '13'
       where enterprise_no = strEnterpriseNo
         and warehouse_no = strWareHouseNo
         and po_no = tmp.po_no
         and row_id = tmp.row_id
         and status = '11';

    end loop;

    for import in (select m.owner_no, m.import_no,m.import_type
                     from idata_import_m m, idata_import_tmp tmp
                    where m.po_no = tmp.po_no
                      and m.enterprise_no = tmp.enterprise_no
                      and m.warehouse_no = tmp.warehouse_no) loop
     --获取进货配置 判断是否自动集单
      PKLG_WMS_Public.P_GetIdataOrder(strEnterpriseNo,  strWareHouseNo,
              import.owner_no,import.import_type, 'AUTOCOLLECTORDER', v_strFlag,strResult);

      if substr(strResult, 1, 1) = 'N' then
        strResult := 'N|获取进货配置错误';
        return;
      end if;

      if v_strFlag = '1' then
        --自动集单
        pklg_idata.p_single_set(strEnterpriseNo,
                                strWareHouseNo,
                                import.import_no,
                                'N', --原汇总单号,没有传N
                                strUserId,
                                v_strNewS_Import_No, --返回的汇总单号
                                strResult);
        if substr(strResult, 1, 1) <> 'Y' then
          return;
        end if;

      end if;

    end loop;

    delete from idata_import_tmp
     where warehouse_no = strWareHouseNo
       and status = '13'
       and enterprise_no = strEnterpriseNo;

    strResult := 'Y|导入成功';

  end P_idata_import_id;
 /****************************************************************************************************
     创建人：chensr
     修改人：hekl
     2014.12.3
     修改人：czh     2016/5/18
     将Excel数据导入出货订单
     修改人：huangcx  2016/5/27 添加指定生产日期出货、生产日期条件判断、货位判断
  ******************************************************************************************************/
  procedure p_odata_exp(strCurrEnterpriseNo in odata_exp_tmp.enterprise_no%type,
                        strWareHouseNo      in odata_exp_tmp.warehouse_no%type,
                        strUserId           in bdef_defworker.worker_no%type,
                        strResult           out varchar2) is
    v_count                number;
    v_exp_no               varchar2(50);
    v_shipper_deliver_no   varchar2(50);
    v_result               varchar2(50);
    v_count_tmp            number;
    v_count_tmp1           number;
    v_article_no           varchar2(50);
    v_strCustNo            varchar2(50);
    n_qmin_operate_packing number;
  begin
    strResult := 'N|[P_odata_exp]';
    --查询临时表中有多少条数据
    select count(1)
      into v_count_tmp
      from odata_exp_tmp
     where enterprise_no = strCurrEnterpriseNo;

    update odata_exp_tmp
       set status = '11'
     where warehouse_no = strWareHouseNo
       and enterprise_no = strCurrEnterpriseNo;

    --检查出货单是否有重复单号
    select count(*)
      into v_count
      from odata_exp_m m, odata_exp_tmp tm
     where m.sourceexp_no = tm.sourceexp_no
       and m.enterprise_no = tm.enterprise_no
       and m.owner_no=tm.owner_no --Add BY QZH AT 2017-9-6
       and m.enterprise_no = strCurrEnterpriseNo;
    if v_count > 0 then
      select sourceexp_no
        into v_exp_no
        from (select tm.sourceexp_no
                from odata_exp_m m, odata_exp_tmp tm
               where m.sourceexp_no = tm.sourceexp_no
                 and m.enterprise_no = tm.enterprise_no
                 and m.owner_no=tm.owner_no --Add BY QZH AT 2017-9-6
                 and m.enterprise_no = strCurrEnterpriseNo)
       where rownum = 1;
      strResult := 'N|[该' || v_exp_no || '原单号已存在，请检查！]';
      return;
    end if;
     --检查出货单是否有重复快递单号
     /*select count(shipper_deliver_no),shipper_deliver_no
     into v_count, v_shipper_deliver_no
     from   odata_exp_tmp
     where enterprise_no = strCurrEnterpriseNo
     group by   shipper_deliver_no;
     if v_count > 1 then
      strResult := 'N|[该' || v_shipper_deliver_no || '快递单号有重复，请检查！]';
      return;
    end if;*/
    select count(*)
      into v_count
      from odata_exp_m m, odata_exp_tmp tm
     where m.shipper_deliver_no = tm.shipper_deliver_no
       and m.enterprise_no = tm.enterprise_no
       and m.enterprise_no = strCurrEnterpriseNo;
    if v_count > 0 then
      select shipper_deliver_no
        into v_shipper_deliver_no
        from (select tm.shipper_deliver_no
                from odata_exp_m m, odata_exp_tmp tm
               where m.shipper_deliver_no = tm.shipper_deliver_no
                 and m.enterprise_no = tm.enterprise_no
                 and m.enterprise_no = strCurrEnterpriseNo)
       where rownum = 1;
      strResult := 'N|[该' || v_shipper_deliver_no || '快递单号已存在，请检查！]';
      return;
    end if;
    for m in (select *
                from odata_exp_tmp
               where warehouse_no = strWareHouseNo
                 and enterprise_no = strCurrEnterpriseNo
                 and status = '11'
               order by sourceexp_no, owner_article_no) loop

            --检查客户电话格式
          IF instr(m.cust_phone,'.') > 0 THEN
            strResult := 'N|[第' || m.Row_Id || '条客户电话格式不正确]';
            return;
          END IF;

          --检查面单号格式
          IF instr(m.shipper_deliver_no,'.') > 0 THEN
            strResult := 'N|[第' || m.Row_Id || '条面单号格式不正确]';
            return;
          END IF;

          --检查订单号格式
          IF instr(m.sourceexp_no,'.') > 0 THEN
            strResult := 'N|[第' || m.Row_Id || '条订单号格式不正确]';
            return;
          END IF;

      --检查货主是否存在
      select count(*)
        into v_count
        from bdef_defowner bdo
       where bdo.owner_no = M.Owner_No
         and bdo.enterprise_no = strCurrEnterpriseNo;
      if v_count = 0 then
        strResult := 'N|[第' || M.Row_Id || '条货主不存在]';
        return;
      end if;

      --检查货主是否有权限
      select count(*)
        into v_count
        from (select distinct b.owner_no
                from bdef_defowner b, bdef_defworker d
               where b.enterprise_no = d.enterprise_no
                 and d.worker_no = strUserId
                 and b.authority_type = '1'
                 and b.enterprise_no = strCurrEnterpriseNo
              union
              select distinct b.owner_no
                from bset_worker_owner b, bdef_defworker d
               where b.enterprise_no = d.enterprise_no
                 and b.worker_no = d.worker_no
                 and b.worker_no = strUserId
                 and b.enterprise_no = strCurrEnterpriseNo) a
       where a.owner_no = m.owner_no;

      if v_count = 0 then
        strResult := 'N|[该用户没有' || m.owner_no || '货主权限]';
        return;
      end if;

      --判断客户是否存在
      select count(1)
        into v_count
        from bdef_defcust
       where owner_cust_no = m.cust_no
         and owner_no = m.owner_no
         and enterprise_no = strCurrEnterpriseNo;
      if v_count = 0 then
        strResult := 'N|[第' || m.Row_Id || '条货主客户编号不存在]'; --客户不存在
        return;
      else
        select cust_no
          into v_strCustNo
          from bdef_defcust
         where owner_cust_no = m.cust_no
           and owner_no = m.owner_no
           and enterprise_no = strCurrEnterpriseNo;
      end if;

      --出货单别是否存在
      select count(1)
        into v_count
        from wms_deffieldval
       where table_name = 'N'
         and colname = 'EXP_TYPE'
         and value = m.exp_type
         and status = '1';
      if v_count = 0 then
        strResult := 'N|[第' || M.Row_Id || '条出货单别不存在]';
        return;
      end if;

      --检查提货类型是否存在
      select count(1)
        into v_count
        from wms_deffieldval
       where table_name = 'N'
         and colname = 'TAKE_TYPE'
         and value = m.take_type
         and status = '1';
      if v_count = 0 then
        strResult := 'N|[第' || m.Row_Id || '条提货类型不存在]';
        return;
      end if;

      --是否急单是否存在
      select count(1)
        into v_count
        from wms_deffieldval
       where table_name = 'ODATA_EXP_M'
         and colname = 'FAST_FLAG'
         and value = m.fast_flag
         and status = '1';
      if v_count = 0 then
        strResult := 'N|[第' || M.Row_Id || '条是否紧急标识不存在]';
        return;
      end if;

      --检查承运商是否存在
      if m.shipper_no is not null then
         select count(1)
            into v_count
            from bdef_defshipper
           where warehouse_no=m.warehouse_no
             and enterprise_no=m.enterprise_no
             and status = '1'
             and shipper_no=m.shipper_no;
          if v_count = 0 then
            strResult := 'N|[第' || M.Row_Id || '条承运商不存在]';
            return;
          end if;

       end if;

      --检查同一货主同一原单号的客户编号、出货单别、提货方式、是否紧急、最晚出货日期是否一样
      select count(*)
        into v_count
        from (select m.warehouse_no, m.owner_no, m.sourceexp_no
                from odata_exp_tmp tmp
               where tmp.enterprise_no = m.enterprise_no
                 and tmp.warehouse_no = m.warehouse_no
                 and tmp.owner_no = m.owner_no
                 and tmp.sourceexp_no = m.sourceexp_no
               group by tmp.warehouse_no,
                        m.owner_no,
                        tmp.sourceexp_no,
                        tmp.cust_no,
                        tmp.exp_type,
                        tmp.take_type,
                        tmp.fast_flag,
                        tmp.exp_date,
                        tmp.shipper_no,
                        tmp.contactor_name,
                        tmp.shipper_deliver_no
                        );
      if v_count >= 2 then
        strResult := 'N|[单号为' || m.sourceexp_no ||
                     '的客户编号、出货单别、提货方式、是否紧急、最晚出货日期、承运商、收货人、快递单号不一样]';
        return;
      end if;

      --检查该商品是否存在
      begin
        select article_no
          into v_article_no
          from bdef_defarticle
         where owner_article_no = m.owner_article_no
           and enterprise_no = m.enterprise_no
           and owner_no = m.owner_no;
      exception
        when no_data_found then
          strResult := 'N|[第' || M.Row_Id || '条商品编码不存在]';
          return;
      end;

      --检查商品包装是否存在
    --  IF m.packing_qty <> 1 then
        select count(1)
          into v_count
          from BDEF_ARTICLE_PACKING
         where article_no = v_article_no
           and packing_qty = m.packing_qty
           and enterprise_no = m.enterprise_no;
        if v_count = 0 then
          select count(1) --是否为最小操作包装数
                into n_qmin_operate_packing
                from bdef_defarticle b
               where b.enterprise_no = m.enterprise_no
                 and b.article_no = v_article_no
                 and b.qmin_operate_packing = m.packing_qty;
          if n_qmin_operate_packing =0 then
            strResult := 'N|[第' || M.Row_Id || '条商品包装不为箱包装也不为最小操作包装，请检查，该包装是否存在]';
            return;
          end if;
        end if;
    --  end if;


      --add by hcx at  2016/5/26
      --检查商品生产日期条件是否存在
      if m.produce_condition is not null or m.produce_condition<>'' then
         select count(1) into v_count
           from wms_deffieldval
          where table_name='ODATA_EXP_D'
            and colname='PRODUCE_CONDITION'
            and value=m.produce_condition and status='1';
          if v_count = 0 then
             strResult:= 'N|[第' || m.Row_Id || '条生产日期条件不存在]';
             return;
          end if;
       end if;
       --检查货位1是否存在
       if m.specify_value1 is not null or m.specify_value1<>'' then
          select count(1) into v_count
            from cdef_defcell cd,cdef_defarea cdf
           where cd.enterprise_no=cdf.enterprise_no
             and cd.warehouse_no=cdf.warehouse_no
             and cd.ware_no=cdf.ware_no
             and cd.area_no=cdf.area_no
             and cd.cell_no=m.specify_value1
             and cd.enterprise_no=m.enterprise_no
             and cdf.area_usetype='1'
             and cdf.attribute_type='0';
          if v_count = 0 then
             strResult:= 'N|[第' || m.Row_Id || '条货位1不存在]';
             return;
          end if;
        end if;
        --检查货位2是否存在
        if m.specify_value2 is not null or m.specify_value2<>'' then
            select count(1) into v_count
            from cdef_defcell cd,cdef_defarea cdf
           where cd.enterprise_no=cdf.enterprise_no
             and cd.warehouse_no=cdf.warehouse_no
             and cd.ware_no=cdf.ware_no
             and cd.area_no=cdf.area_no
             and cd.cell_no=m.specify_value1
             and cd.enterprise_no=m.enterprise_no
             and cdf.area_usetype='1'
             and cdf.attribute_type='0';
          if v_count = 0 then
             strResult:= 'N|[第' || m.Row_Id || '条货位2不存在]';
             return;
          end if;
        end if;
      --end add

      --判断单号是否已经存在
      select count(1)
        into v_count
        from odata_exp_m
       where sourceexp_no = m.sourceexp_no
         and warehouse_no = strWareHouseNo
         and owner_no=m.owner_no --Add BY QZH AT 2017-9-6
         and enterprise_no = strCurrEnterpriseNo;
         --and status = '10'; Modify BY QZH AT 2017-9-6 
        
      if v_count = 0 then
        /* strResult:='N|[第' || M.Row_Id || '条单号已存在]';
            return;
           select count(1) into v_count_1 from odata_exp_m where sourceexp_no=m.sourceexp_no and enterprise_no=m.enterprise_no and status ='10';
           if v_count_1>0 then
               select exp_no into v_exp_no from odata_exp_m where sourceexp_no=m.sourceexp_no and warehouse_no=strWareHouseNo and enterprise_no=strCurrEnterpriseNo;
           else
               strResult:='N|[第' || M.Row_Id || '条单号已存在]';
               return;
           end if;
        else*/
        PKLG_WMS_BASE.p_getsheetno(strCurrEnterpriseNo,
                                   strWareHouseNo,
                                   CONST_DOCUMENTTYPE.ODATAOE,
                                   v_exp_no,
                                   v_result);

        --插入单头
        insert into odata_exp_m
          (enterprise_no,
           warehouse_no,
           exp_no,
           exp_type,
           owner_no,
           owner_cust_no,
           cust_no,
           sub_cust_no,
           sourceexp_type,
           sourceexp_no,
           last_custsend_date,
           fast_flag,
           status,
           exp_status,
           batch_no,
           line_no,
           stock_type,
           priority,
           add_exp_no,
           deliver_type,
           transport_type,
           create_flag,
           return_flag,
           belong_flag,
           send_flag,
           special_article_group,
           exp_remark,
           dept_no,
           contactor_name,
           --cust_phone,
           cust_mail,
           cust_address,
           rgst_name,
           rgst_date, /*rsv_varod1,*/
           rsv_varod2, --预留字段1已被占用
           rsv_varod3,--布控状态
           rsv_varod4,--海关订单批次号
           order_source,--电商平台代码
           send_name,--发货人  add by czh 2016.08.17
           send_mobile_phone,--发货人手机
           send_telephone,--发货人固定电话
           send_address,--发货人地址
           cust_phone,--收货人电话
           receive_province,--收货省份
           receive_city,--收货市
           receive_zone,--收货区
        /*   rsv_varod3,
           rsv_varod4,
           rsv_varod5,
           rsv_varod6,
           rsv_varod7,
           rsv_varod8,
           rsv_num1,
           rsv_num2,
           rsv_num3,
           rsv_date1,
           rsv_date2,
           rsv_date3,*/
           take_type,erpoperate_date,shipper_no,skucount,shipper_deliver_no)
          select m.enterprise_no,
                 m.warehouse_no,
                 v_exp_no,
                 m.exp_type,
                 m.owner_no,
                 n.owner_cust_no,
                 v_strCustNo,
                 v_strCustNo,
                 m.exp_type,
                 m.sourceexp_no,
                 m.exp_date,
                 m.fast_flag,
               --  case when m.shipper_no is null or m.shipper_no ='' then '10'
               --  else '-1'  end ,
                '10' ,   --modify wyy 2017/9/4
                 '00',
                 'N',
                 'N',
                 '1',
                 '100',
                 'N',
                 '2',
                 '1',
                 '0',
                 '0',
                 '0',
                 '10',
                 '0',
                 m.exp_remark,
                 'N',
                 m.contactor_name,
                 --n.cust_phone1,
                 n.cust_email1,
                 --m.cust_address,
                 case when m.cust_address is null then n.cust_address else m.cust_address end,
                 strUserId,
                 sysdate, /*m.rsv_varod1,*/
                 m.rsv_varod1, --模板用的预留字段1对应出货单预留字段2
                 m.rsv_varod3,--布控状态
                 m.rsv_varod4,--海关订单批次号
                 '0',--电商平台代码
                 m.send_name,--发货人  add by czh 2016.08.17
                 m.send_mobile_phone,--发货人手机
                 m.send_telephone,--发货人固定电话
                 m.send_address,--发货人地址
                 m.cust_phone,--收货人电话
                 m.receive_province,--收货省份
                 m.receive_city,--收货市
                 m.receive_zone,--收货区
              /*   case when m.rsv_varod2 is null then '0' end,--模板用的预留字段2对应出货单预留字段3,默认为0
                 m.rsv_varod4,
                 m.rsv_varod5,
                 m.rsv_varod6,
                 m.rsv_varod7,
                 m.rsv_varod8,
                 m.rsv_num1,
                 m.rsv_num2,
                 m.rsv_num3,
                 m.rsv_date1,
                 m.rsv_date2,
                 m.rsv_date3,*/
                 m.take_type,sysdate,m.shipper_no,0,m.shipper_deliver_no
            from bdef_defcust n
           where n.owner_no = m.owner_no
             and n.cust_no = v_strCustNo
             and n.enterprise_no = m.enterprise_no;

        if sql%rowcount <= 0 then
          strResult := 'N|[第' || M.Row_Id || '条写入出货单头档错误]';
          return;
        end if;

        --写出货单状态跟踪表
        PKOBJ_ODISPATCH.P_Insert_Odata_Exp_Trace(m.enterprise_no,
                   m.warehouse_no, v_exp_no, '00',strUserId,strResult);
        if substr(strResult, 1, 1) <> 'Y' then
           strResult := 'N|[回出货单状态跟踪表失败！]';
        return;

      end if;

      end if;

      --判断明细中是否有这个商品
      select count(1)
        into v_count
        from odata_exp_d
       where enterprise_no = m.enterprise_no
         and article_no = v_article_no
         and exp_no = v_exp_no
         and packing_qty = m.packing_qty
         and nvl(unit_cost, 0) = (case
               when (m.unit_cost is null or m.unit_cost = '') then
                0
               else
                m.unit_cost
             end)
         and nvl(lotno_value1, 'N') = (case
               when (m.lotno_value1 is null or m.lotno_value1 = '') then
                'N'
               else
                m.lotno_value1
             end)
         and nvl(lotno_value2, 'N') = (case when(m.lotno_value2 is null or m.lotno_value2 = '' ）then 'N' else m.lotno_value2 end）;
      if v_count > 0 then
        strResult := 'N|[第' || M.Row_Id || '条商品在该单已存在]';
        return;
      end if;

      select count(1)
        into v_count
        from odata_exp_d
       where exp_no = v_exp_no
         and enterprise_no = strCurrEnterpriseNo;

      --插入明细
      insert into odata_exp_d
        (enterprise_no,
         warehouse_no,
         owner_no,
         exp_no,
         article_no,
         packing_qty,
         article_qty,
         schedule_qty,
         locate_qty,
         real_qty,
         unit_cost,
         error_status,
         rgst_date,
         owner_article_no,
         status,
         produce_condition,
         produce_value1,
         produce_value2,
         expire_condition,
         expire_value1,
         expire_value2,
         quality_condition,
         quality_value1,
         quality_value2,
         lotno_condition,
         lotno_value1,
         lotno_value2,
         rsvbatch1_condition,
         rsvbatch2_condition,
         rsvbatch3_condition,
         rsvbatch4_condition,
         rsvbatch5_condition,
         rsvbatch6_condition,
         rsvbatch7_condition,
         rsvbatch8_condition,
         SPECIFY_FIELD,
         specify_condition,
         specify_value1,
         specify_value2,
         row_id)
      values
        (m.enterprise_no,
         m.warehouse_no,
         m.owner_no,
         v_exp_no,
         v_article_no,
         m.packing_qty,
         m.article_qty,
         0,
         0,
         0,
         m.unit_cost,
         '000',
         sysdate,
         m.owner_article_no,
         '10',
         'N',
         to_date('1900-01-01', 'yyyy/MM/dd'),
         to_date('1900-01-01', 'yyyy/MM/dd'),
         'N',
         to_date('1900-01-01', 'yyyy/MM/dd'),
         to_date('1900-01-01', 'yyyy/MM/dd'),
         'N',
         'N',
         'N',
         m.lotno_condition,
         m.lotno_value1,
         m.lotno_value2,
         'N',
         'N',
         'N',
         'N',
         'N',
         'N',
         'N',
         'N',
         'cell_no',
         m.specify_condition,
         m.specify_value1,
         m.specify_value2,
         v_count);

      if sql%rowcount <= 0 then
        strResult := 'N|[第' || M.Row_Id || '条写入出货单明细错误]';
        return;
      end if;


      --商品导入成功，修改临时表状态为13（成功）
      update odata_exp_tmp
         set status = '13'
       where enterprise_no = strCurrEnterpriseNo
         and warehouse_no = strWareHouseNo
         and sourceexp_no = m.sourceexp_no
         and row_id = m.row_id
         and status = '11';

    end loop;
     --回写品项数（总数）
      PKLG_ODISPATCH.P_LOCATECHECK_UPDATESKU(strCurrEnterpriseNo,
                 strWareHouseNo,'ALL','ALL',strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        strResult := 'N|[回写头档品项数失败！]';
        return;
      end if;



    --删除状态为13导入成功的数据
    delete from odata_exp_tmp
     where warehouse_no = strWareHouseNo
       and enterprise_no = strCurrEnterpriseNo
       and status = '13';

    --查询导入成功多少条记录
    select count(1)
      into v_count_tmp1
      from odata_exp_tmp
     where enterprise_no = strCurrEnterpriseNo;
    v_count := v_count_tmp - v_count_tmp1;

    strResult := 'Y|[成功导入' || v_count || '条数据]';
  end p_odata_exp;

  /*************************************************************************************************
   创建人：hkl
   创建时间：2015.09.15
   修改人：czh     2016/5/18
   功能说明：excel报损手建单导入
  **************************************************************************************************/
  procedure P_sodata_waste(strEnterpriseNo in idata_import_tmp.enterprise_no%type,
                           strWareHouseNo  in idata_import_tmp.warehouse_no%type,
                           strUserId       in bdef_defworker.worker_no%type,
                           strResult       out varchar2) is
    v_count      number;
    v_count_1    number;
    v_waste_no   varchar2(20);
    v_result     varchar2(20);
    v_count_tmp  number;
    v_count_tmp1 number;
    v_article_no varchar2(20);
    n_qmin_operate_packing number;

  begin
    strResult := 'N|[P_odata_exp]';
    --查询临时表中有多少条数据
    select count(1)
      into v_count_tmp
      from SODATA_WASTE_TMP
     where enterprise_no = strEnterpriseNo;

    update SODATA_WASTE_TMP
       set status = '11'
     where warehouse_no = strWareHouseNo
       and enterprise_no = strEnterpriseNo;

    for m in (select *
                from SODATA_WASTE_TMP
               where warehouse_no = strWareHouseNo
                 and enterprise_no = strEnterpriseNo
                 and status = '11'
               order by po_no, owner_article_no) loop

      --判断货主是否存在
      select count(1)
        into v_count
        from bdef_defowner
       where owner_no = m.owner_no
         and enterprise_no = m.enterprise_no;
      if v_count = 0 then
        strResult := 'N|[E31011]';
        goto top;
      end if;

      --检查货主是否有权限
      select count(*)
        into v_count
        from (select distinct b.owner_no
                from bdef_defowner b, bdef_defworker d
               where b.enterprise_no = d.enterprise_no
                 and d.worker_no = strUserId
                 and b.authority_type = '1'
                 and b.enterprise_no = strEnterpriseNo
              union
              select distinct b.owner_no
                from bset_worker_owner b, bdef_defworker d
               where b.enterprise_no = d.enterprise_no
                 and b.worker_no = d.worker_no
                 and b.worker_no = strUserId
                 and b.enterprise_no = strEnterpriseNo) a
       where a.owner_no = m.owner_no;

      if v_count = 0 then
        strResult := 'N|[该用户没有' || m.owner_no || '货主权限]';
        return;
      end if;
      --检查该商品是否存在
      select article_no
        into v_article_no
        from bdef_defarticle
       where owner_article_no = m.owner_article_no
         and enterprise_no = m.enterprise_no
         and owner_no = m.owner_no;

      --检查该商品是否存在
      select count(1)
        into v_count
        from bdef_defarticle
       where article_no = v_article_no
         and enterprise_no = m.enterprise_no;
      if v_count = 0 then
        strResult := 'N|[E31014]';
        goto top;
      end if;

      --判断单号是否已经存在
      select count(1)
        into v_count
        from sodata_waste_m
       where po_no = m.po_no
         and warehouse_no = strWareHouseNo
         and enterprise_no = strEnterpriseNo;
      if v_count > 0 then
        select count(1)
          into v_count_1
          from sodata_waste_m
         where po_no = m.po_no
           and enterprise_no = m.enterprise_no
           and status = '10';
        if v_count_1 > 0 then
          select waste_no
            into v_waste_no
            from sodata_waste_m
           where po_no = m.po_no
             and warehouse_no = strWareHouseNo
             and enterprise_no = strEnterpriseNo;
        else
          strResult := 'N|[E20501]'; --插入单头失败];
          return;
        end if;
      else
        PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                   strWareHouseNo,
                                   CONST_DOCUMENTTYPE.SOPLAN,
                                   v_waste_no,
                                   v_result);

        --插入单头
        insert into sodata_waste_m
          (enterprise_no,
           warehouse_no,
           owner_no,
           waste_type,
           waste_no,
           po_type,
           po_no,
           waste_date,
           request_date,
           status,
           create_flag,
           send_flag,
           stock_type,
           stock_value,
           org_no,
           rgst_name,
           rgst_date)
        values
          (strEnterpriseNo,
           strWareHouseNo,
           m.owner_no,
           CONST_DOCUMENTTYPE.SOPLAN,
           v_waste_no,
           CONST_DOCUMENTTYPE.SOPLAN,
           m.po_no,
           sysdate,
           sysdate,
           10,
           0,
           10,
           1,
           'N',
           m.org_no,
           strUserId,
           sysdate);

        if sql%rowcount <= 0 then
          strResult := 'N|[E20501]'; --插入单头失败];
          return;
        end if;

      end if;

      --判断明细中是否有这个商品
      select count(1)
        into v_count
        from sodata_waste_d
       where enterprise_no = m.enterprise_no
         and article_no = v_article_no
         and WASTE_NO = v_waste_no
         and packing_qty = m.packing_qty;
      if v_count > 0 then
        strResult := 'N|[E23211]'; --插入明细失败
        goto top;
      end if;

      select count(1)
        into v_count
        from sodata_waste_d
       where WASTE_NO = v_waste_no
         and enterprise_no = strEnterpriseNo;

      --插入明细
      --规则：无散数直接插入数据,有散数则插入两条数据
      if (mod(m.waste_qty, m.packing_qty) = 0) then
        insert into sodata_waste_d
          (enterprise_no,
           warehouse_no,
           owner_no,
           waste_no,
           po_id,
           article_no,
           packing_qty,
           lot_no,
           quality,
           waste_qty)
        values
          (strEnterpriseNo,
           strWareHouseNo,
           m.owner_no,
           v_waste_no,
           v_count,
           v_article_no,
           m.packing_qty,
           'N',
           0,
           m.waste_qty);

        if sql%rowcount <= 0 then
          strResult := 'N|[E23211]'; --插入明细失败
          goto top;
        end if;
      else
        insert into sodata_waste_d
          (enterprise_no,
           warehouse_no,
           owner_no,
           waste_no,
           po_id,
           article_no,
           packing_qty,
           lot_no,
           quality,
           waste_qty)
        values
          (strEnterpriseNo,
           strWareHouseNo,
           m.owner_no,
           v_waste_no,
           v_count,
           v_article_no,
           m.packing_qty,
           'N',
           0,
           trunc(m.waste_qty, m.packing_qty) * m.packing_qty);

        if sql%rowcount <= 0 then
          strResult := 'N|[E23211]'; --插入明细失败
          goto top;
        end if;
        insert into sodata_waste_d
          (enterprise_no,
           warehouse_no,
           owner_no,
           waste_no,
           po_id,
           article_no,
           packing_qty,
           lot_no,
           quality,
           waste_qty)
        values
          (strEnterpriseNo,
           strWareHouseNo,
           m.owner_no,
           v_waste_no,
           v_count,
           v_article_no,
           '1',
           'N',
           0,
           mod(m.waste_qty, m.packing_qty));

        if sql%rowcount <= 0 then
          strResult := 'N|[E23211]'; --插入明细失败
          goto top;
        end if;
      end if;
      /*--插入明细
      insert into sodata_waste_d
        (enterprise_no,
         warehouse_no,
         owner_no,
         waste_no,
         po_id,
         article_no,
         packing_qty,
         lot_no,
         quality,
         waste_qty)
      values
        (strEnterpriseNo,
         strWareHouseNo,
         m.owner_no,
         v_waste_no,
         v_count,
         v_article_no,
         m.packing_qty,
         'N',
         0,
         m.waste_qty);

      if sql%rowcount <= 0 then
        strResult := 'N|[E23211]'; --插入明细失败
        goto top;
      end if;*/

      --商品导入成功，修改临时表状态为13（成功）
      update SODATA_WASTE_TMP
         set status = '13'
       where enterprise_no = strEnterpriseNo
         and warehouse_no = strWareHouseNo
         and po_no = m.po_no
         and row_id = m.row_id
         and status = '11';

      <<top>>
      null;
      --导入失败后添加临时表错误信息至备注
      update SODATA_WASTE_TMP
         set REMARK = strResult
       where enterprise_no = strEnterpriseNo
         and warehouse_no = strWareHouseNo
         and po_no = m.po_no
         and row_id = m.row_id
         and status = '11';

      v_count := 0;
    end loop;
    --删除状态为13导入成功的数据
    delete from SODATA_WASTE_TMP
     where warehouse_no = strWareHouseNo
       and enterprise_no = strEnterpriseNo
       and status = '13';

    --查询导入成功多少条记录
    select count(1)
      into v_count_tmp1
      from SODATA_WASTE_TMP
     where enterprise_no = strEnterpriseNo;
    v_count := v_count_tmp - v_count_tmp1;

    strResult := 'Y|[成功导入' || v_count || '条数据]';
  end P_sodata_waste;

  /*************************************************************************************************
    创建人：hekl
    创建时间：2015.07.09
    修改人：czh     2016/5/18
    功能说明：移库人工移库手建单的导入
  **************************************************************************************************/

  procedure P_mdata_planUpLoad(strEnterpriseNo in mdata_plan_m.enterprise_no%type,
                               strWareHouseNo  in mdata_plan_m.warehouse_no%type,
                               strWorkerNo     in mdata_plan_m.rgst_name%type,
                               strResult       out varchar2) is
    v_count      number;
    v_PlanNo     varchar2(20) := 'N';
    v_article_no varchar2(20);
    v_count_tmp  number;
    v_count_tmp1 number;
    v_owner      varchar2(20);
    v_RemainQty  mdata_plan_d.origin_qty%type; --剩余计划移库量
    v_ncurQty    mdata_plan_d.origin_qty%type; --当前移库数量
    n_qmin_operate_packing number;

  begin
    strResult := 'Y|[P_idata_import]';
    v_ncurQty := 0;

    --查询临时表中有多少条数据
    select count(1)
      into v_count_tmp
      from mdata_plan_tmp
     where enterprise_no = strEnterpriseNo;

    update mdata_plan_tmp
       set status = '11'
     where warehouse_no = strWareHouseNo
       and enterprise_no = strEnterpriseNo;

    for m in (select *
                from mdata_plan_tmp
               where warehouse_no = strWareHouseNo
                 and status = '11'
                 and enterprise_no = strEnterpriseNo
                 and origin_qty > 0
               order by owner_article_no) loop

      v_owner := m.owner_no;

      --判断货主是否存在
      select count(1)
        into v_count
        from bdef_defowner
       where owner_no = m.owner_no
         and enterprise_no = strEnterpriseNo;
      if v_count = 0 then
        strResult := 'N|[第' || m.row_id || '条货主不存在]';
        return;
      end if;
      --检查货主是否有权限
      select count(*)
        into v_count
        from (select distinct b.owner_no
                from bdef_defowner b, bdef_defworker d
               where b.enterprise_no = d.enterprise_no
                 and d.worker_no = strWorkerNo
                 and b.authority_type = '1'
                 and b.enterprise_no = strEnterpriseNo
              union
              select distinct b.owner_no
                from bset_worker_owner b, bdef_defworker d
               where b.enterprise_no = d.enterprise_no
                 and b.worker_no = d.worker_no
                 and b.worker_no = strWorkerNo
                 and b.enterprise_no = strEnterpriseNo) a
       where a.owner_no = m.owner_no;

      if v_count = 0 then
        strResult := 'N|[没有第' || m.row_id || '条货主的权限]';
        return;
      end if;
      --检查该商品是否存在
      begin

        select article_no
          into v_article_no
          from bdef_defarticle
         where owner_article_no = m.owner_article_no
           and enterprise_no = strEnterpriseNo
           and owner_no = m.owner_no;
      exception
        when no_data_found then
          strResult := 'N|[第' || m.row_id || '条商品不存在]';
          return;
      end;
      --检查该商品是否存在
      select count(1)
        into v_count
        from bdef_defarticle
       where article_no = v_article_no
         and enterprise_no = strEnterpriseNo;
      if v_count = 0 then
        strResult := 'N|[第' || m.row_id || '条商品不存在]';
        return;
      end if;

      --新增移库单头档
      if v_PlanNo = 'N' then
        --写移库头档
        pkobj_mdata.P_mdata_PlanHead(strEnterPriseNo,
                                     strWareHouseNo,
                                     M.OWNER_NO,
                                     strWorkerNo,
                                     '1',
                                     '4',
                                     v_PlanNo,
                                     strResult);
        if substr(strResult, 1, 1) = 'N' then
          strResult := 'N|[第' || m.row_id || '条写头档数据失败]';
          return;
        end if;
        v_PlanNo := v_PlanNo;
      end if;

      --判断明细中是否有这个商品
      select count(1)
        into v_count
        from mdata_plan_d t, stock_article_info sai
       where t.article_no = v_article_no
         and t.plan_no = v_PlanNo
         and t.enterprise_no = strEnterpriseNo
         and t.s_cell_no = m.s_cell_no
         and t.article_no = sai.article_no
         and t.article_id = sai.article_id
         and sai.produce_date = m.produce_date
         and sai.expire_date = m.expire_date
         and sai.quality = m.quality
         and sai.lot_no = m.lot_no;
      if v_count > 0 then
        strResult := 'N|[第' || m.row_id || '条商品数据重复]';
        return;
      end if;

      --校验目的储位
      --校验目的储位
      Pkobj_stock.CheckMoveDestCell(strEnterpriseNo,
                                       strWareHouseNo,
                                       m.owner_no,
                                       v_article_no,
                                       m.produce_date,
                                       m.expire_date,
                                       m.quality,
                                       m.lot_no,
                                       m.rsv_batch1,
                                       m.rsv_batch2,
                                       m.rsv_batch3,
                                       m.rsv_batch4,
                                       m.rsv_batch5,
                                       m.rsv_batch6,
                                       m.rsv_batch7,
                                       m.rsv_batch8,
                                       m.d_cell_no,
                                       strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --判断是否有来源储位(如果没有来源储位则要根据商品和数量找库存)
      if m.s_cell_no = 'N' then
        v_RemainQty := m.origin_qty;
        for con in (select t.*, f.produce_date, f.expire_date
                      from stock_content t, stock_article_info f
                     where t.enterprise_no = f.enterprise_no
                       and t.article_no = f.article_no
                       and t.article_id = f.article_id
                       and t.enterprise_no = strEnterPriseNo
                       and t.warehouse_no = strWareHouseNo
                       and t.owner_no = m.owner_no
                       and t.article_no = v_article_no
                       and t.packing_qty = m.packing_qty
                       and f.produce_date = m.produce_date
                       and f.expire_date = m.expire_date
                       and f.lot_no = m.lot_no
                       and f.quality = m.quality
                       and f.rsv_batch1 = m.rsv_batch1
                       and f.rsv_batch2 = m.rsv_batch2
                       and f.rsv_batch3 = m.rsv_batch3
                       and f.rsv_batch4 = m.rsv_batch4
                       and f.rsv_batch5 = m.rsv_batch5
                       and f.rsv_batch6 = m.rsv_batch6
                       and f.rsv_batch7 = m.rsv_batch7
                       and f.rsv_batch8 = m.rsv_batch8
                       and t.status = '0'
                       and t.qty - t.outstock_qty > 0
                       and t.cell_no in
                           (select l.cell_no
                              from cdef_defcell l,
                                   cdef_defarea a,
                                   cdef_defware ware
                             where l.enterprise_no = a.enterprise_no
                               and l.enterprise_no = ware.enterprise_no
                               and l.enterprise_no = strEnterPriseNo
                               and l.warehouse_no = a.warehouse_no
                               and l.warehouse_no = ware.warehouse_no
                               and l.warehouse_no = strWareHouseNo
                               and l.ware_no = a.ware_no
                               and l.area_no = a.area_no
                               and a.ware_no = ware.ware_no
                               and ware.org_no = m.org_no
                               and a.area_attribute = '0'
                               AND A.AREA_USETYPE IN ('1', '5', '6'))) loop
          if v_RemainQty >= con.qty - con.outstock_qty then
            v_ncurQty := con.qty - con.outstock_qty;
          else
            v_ncurQty := v_RemainQty;
          end if;
          v_RemainQty := v_RemainQty - v_ncurQty;
          --判断包装表里是否有包装
          select count(1)
          into v_count
          from BDEF_ARTICLE_PACKING
         where article_no = v_article_no
           and packing_qty = m.packing_qty
           and enterprise_no = m.enterprise_no;
           if v_count = 0 then
          strResult := 'N|[第' || m.Row_Id || '条商品包装不存在]';
          return;
          else
            select count(1)
            into v_count
  from stock_content sc, stock_article_info sai
 where sc.enterprise_no = sai.enterprise_no
   and sc.article_no = sai.article_no
   and sc.article_id = sai.article_id
   and sc.qty-sc.outstock_qty>0
   and sai.article_no=v_article_no
   and sc.mv_Hand_Flag='1'
   and sc.packing_qty=m.packing_qty;
   if v_count=0 then
     strResult := 'N|[第' || m.Row_Id || '条商品包装无库存]';
          return;
     end if;
          end if;
          --写移库明细
          --规则：无散数直接插入数据,有散数则插入两条数据
          /*if (mod(m.quality, con.packing_qty) = 0) then
            pkobj_mdata.P_mdata_PlanItem(strEnterPriseNo,
                                         strWareHouseNo,
                                         m.owner_no,
                                         v_PlanNo,
                                         v_article_no,
                                         con.produce_date,
                                         con.expire_date,
                                         con.packing_qty,
                                         m.quality,
                                         m.lot_no,
                                         m.rsv_batch1,
                                         m.rsv_batch2,
                                         m.rsv_batch3,
                                         m.rsv_batch4,
                                         m.rsv_batch5,
                                         m.rsv_batch6,
                                         m.rsv_batch7,
                                         m.rsv_batch8,
                                         v_ncurQty,
                                         '1',
                                         'N',
                                         con.cell_no,
                                         con.label_no,
                                         con.sub_label_no,
                                         m.d_cell_no,
                                         strResult);

            if substr(strResult, 1, 1) = 'N' then
              strResult := 'N|[第' || m.row_id || '条写商品明细失败]';
              return;
            end if;

            if v_RemainQty = 0 then
              exit;
            end if;
          else
            pkobj_mdata.P_mdata_PlanItem(strEnterPriseNo,
                                         strWareHouseNo,
                                         m.owner_no,
                                         v_PlanNo,
                                         v_article_no,
                                         con.produce_date,
                                         con.expire_date,
                                         con.packing_qty,
                                         trunc(m.quality, con.packing_qty) *
                                         con.packing_qty,
                                         m.lot_no,
                                         m.rsv_batch1,
                                         m.rsv_batch2,
                                         m.rsv_batch3,
                                         m.rsv_batch4,
                                         m.rsv_batch5,
                                         m.rsv_batch6,
                                         m.rsv_batch7,
                                         m.rsv_batch8,
                                         v_ncurQty,
                                         '1',
                                         'N',
                                         con.cell_no,
                                         con.label_no,
                                         con.sub_label_no,
                                         m.d_cell_no,
                                         strResult);

            if substr(strResult, 1, 1) = 'N' then
              strResult := 'N|[第' || m.row_id || '条写商品明细失败]';
              return;
            end if;

            if v_RemainQty = 0 then
              exit;
            end if;
            pkobj_mdata.P_mdata_PlanItem(strEnterPriseNo,
                                         strWareHouseNo,
                                         m.owner_no,
                                         v_PlanNo,
                                         v_article_no,
                                         con.produce_date,
                                         con.expire_date,
                                         '1',
                                         mod(m.quality, con.packing_qty),
                                         m.lot_no,
                                         m.rsv_batch1,
                                         m.rsv_batch2,
                                         m.rsv_batch3,
                                         m.rsv_batch4,
                                         m.rsv_batch5,
                                         m.rsv_batch6,
                                         m.rsv_batch7,
                                         m.rsv_batch8,
                                         v_ncurQty,
                                         '1',
                                         'N',
                                         con.cell_no,
                                         con.label_no,
                                         con.sub_label_no,
                                         m.d_cell_no,
                                         strResult);

            if substr(strResult, 1, 1) = 'N' then
              strResult := 'N|[第' || m.row_id || '条写商品明细失败]';
              return;
            end if;

            if v_RemainQty = 0 then
              exit;
            end if;
          end if;*/
          --写移库明细
        pkobj_mdata.P_mdata_PlanItem(strEnterPriseNo,
                                               strWareHouseNo,
                                               m.owner_no,
                                               v_PlanNo,
                                               v_article_no,
                                               con.produce_date,
                                               con.expire_date,
                                               con.packing_qty,
                                               m.quality,
                                               m.lot_no,
                                               m.rsv_batch1,
                                               m.rsv_batch2,
                                               m.rsv_batch3,
                                               m.rsv_batch4,
                                               m.rsv_batch5,
                                               m.rsv_batch6,
                                               m.rsv_batch7,
                                               m.rsv_batch8,
                                               v_ncurQty,
                                               '1',
                                               'N',
                                               con.cell_no,
                                               con.label_no,
                                               con.sub_label_no,
                                               m.d_cell_no,
                                               strResult);

                  if substr(strResult, 1, 1) = 'N' then
                    strResult := 'N|[第' || m.row_id || '条写商品明细失败]';
                    return;
                  end if;

                  if v_RemainQty = 0 then
                    exit;
                  end if;
        end loop;
      else
        v_RemainQty := m.origin_qty;
        for com in (select t.*, f.produce_date, f.expire_date
                      from stock_content t, stock_article_info f
                     where t.enterprise_no = f.enterprise_no
                       and t.article_no = f.article_no
                       and t.article_id = f.article_id
                       and t.enterprise_no = strEnterPriseNo
                       and t.warehouse_no = strWareHouseNo
                       and t.owner_no = m.owner_no
                       and t.article_no = v_article_no
                       and t.packing_qty = m.packing_qty
                       and f.produce_date = m.produce_date
                       and f.expire_date = m.expire_date
                       and f.lot_no = m.lot_no
                       and f.quality = m.quality
                       and f.rsv_batch1 = m.rsv_batch1
                       and f.rsv_batch2 = m.rsv_batch2
                       and f.rsv_batch3 = m.rsv_batch3
                       and f.rsv_batch4 = m.rsv_batch4
                       and f.rsv_batch5 = m.rsv_batch5
                       and f.rsv_batch6 = m.rsv_batch6
                       and f.rsv_batch7 = m.rsv_batch7
                       and f.rsv_batch8 = m.rsv_batch8
                       and t.status = '0'
                       and t.qty - t.outstock_qty > 0
                       and t.cell_no = m.s_cell_no) loop
          if v_RemainQty >= com.qty - com.outstock_qty then
            v_ncurQty := com.qty - com.outstock_qty;
          else
            v_ncurQty := v_RemainQty;
          end if;
          v_RemainQty := v_RemainQty - v_ncurQty;
          --写移库明细
          --规则：无散数直接插入数据,有散数则插入两条数据
          /*if (mod(m.quality, m.packing_qty) = 0) then
            pkobj_mdata.P_mdata_PlanItem(strEnterPriseNo,
                                         strWareHouseNo,
                                         m.owner_no,
                                         v_PlanNo,
                                         v_article_no,
                                         com.produce_date,
                                         com.expire_date,
                                         com.packing_qty,
                                         m.quality,
                                         m.lot_no,
                                         m.rsv_batch1,
                                         m.rsv_batch2,
                                         m.rsv_batch3,
                                         m.rsv_batch4,
                                         m.rsv_batch5,
                                         m.rsv_batch6,
                                         m.rsv_batch7,
                                         m.rsv_batch8,
                                         v_ncurQty,
                                         '1',
                                         'N',
                                         com.cell_no,
                                         com.label_no,
                                         com.sub_label_no,
                                         m.d_cell_no,
                                         strResult);

            if substr(strResult, 1, 1) = 'N' then
              strResult := 'N|[第' || m.row_id || '条写商品明细]';
              return;
            end if;
            if v_RemainQty = 0 then
              exit;
            end if;
          else
            pkobj_mdata.P_mdata_PlanItem(strEnterPriseNo,
                                         strWareHouseNo,
                                         m.owner_no,
                                         v_PlanNo,
                                         v_article_no,
                                         com.produce_date,
                                         com.expire_date,
                                         com.packing_qty,
                                         trunc(m.quality, m.packing_qty) *
                                         m.packing_qty,
                                         m.lot_no,
                                         m.rsv_batch1,
                                         m.rsv_batch2,
                                         m.rsv_batch3,
                                         m.rsv_batch4,
                                         m.rsv_batch5,
                                         m.rsv_batch6,
                                         m.rsv_batch7,
                                         m.rsv_batch8,
                                         v_ncurQty,
                                         '1',
                                         'N',
                                         com.cell_no,
                                         com.label_no,
                                         com.sub_label_no,
                                         m.d_cell_no,
                                         strResult);

            if substr(strResult, 1, 1) = 'N' then
              strResult := 'N|[第' || m.row_id || '条写商品明细]';
              return;
            end if;
            if v_RemainQty = 0 then
              exit;
            end if;
            pkobj_mdata.P_mdata_PlanItem(strEnterPriseNo,
                                         strWareHouseNo,
                                         m.owner_no,
                                         v_PlanNo,
                                         v_article_no,
                                         com.produce_date,
                                         com.expire_date,
                                         '1',
                                         mod(m.quality, com.packing_qty),
                                         m.lot_no,
                                         m.rsv_batch1,
                                         m.rsv_batch2,
                                         m.rsv_batch3,
                                         m.rsv_batch4,
                                         m.rsv_batch5,
                                         m.rsv_batch6,
                                         m.rsv_batch7,
                                         m.rsv_batch8,
                                         v_ncurQty,
                                         '1',
                                         'N',
                                         com.cell_no,
                                         com.label_no,
                                         com.sub_label_no,
                                         m.d_cell_no,
                                         strResult);

            if substr(strResult, 1, 1) = 'N' then
              strResult := 'N|[第' || m.row_id || '条写商品明细]';
              return;
            end if;
            if v_RemainQty = 0 then
              exit;
            end if;
          end if;*/
          --写移库明细
        pkobj_mdata.P_mdata_PlanItem(strEnterPriseNo,
                                               strWareHouseNo,
                                               m.owner_no,
                                               v_PlanNo,
                                               v_article_no,
                                               com.produce_date,
                                               com.expire_date,
                                               com.packing_qty,
                                               m.quality,
                                               m.lot_no,
                                               m.rsv_batch1,
                                               m.rsv_batch2,
                                               m.rsv_batch3,
                                               m.rsv_batch4,
                                               m.rsv_batch5,
                                               m.rsv_batch6,
                                               m.rsv_batch7,
                                               m.rsv_batch8,
                                               v_ncurQty,
                                               '1',
                                               'N',
                                               com.cell_no,
                                               com.label_no,
                                               com.sub_label_no,
                                               m.d_cell_no,
                                               strResult);

                  if substr(strResult, 1, 1) = 'N' then
                    strResult := 'N|[第' || m.row_id || '条写商品明细]';
                    return;
                  end if;
                  if v_RemainQty = 0 then
                    exit;
                  end if;
        end loop;

      end if;

      --商品导入成功，修改临时表状态为13（成功）
      update mdata_plan_tmp
         set status = '13'
       where enterprise_no = strEnterpriseNo
         and warehouse_no = strWareHouseNo
         and row_id = m.row_id
         and status = '11';

      v_count := 0;
    end loop;
    --定位
    pklg_mdata.P_mdata_Locate_Main(strEnterPriseNo,
                                   strWareHouseNo,
                                   v_owner,
                                   v_PlanNo,
                                   strWorkerNo,
                                   strResult);
    if substr(strResult, 1, 1) = 'N' then
      strResult := 'N|[E3201905]'; --定位失败
      return;
    end if;

    delete from mdata_plan_tmp
     where warehouse_no = strWareHouseNo
       and status = '13'
       and enterprise_no = strEnterpriseNo;

    --查询导入成功多少条记录
    select count(1)
      into v_count_tmp1
      from mdata_plan_tmp
     where enterprise_no = strEnterpriseNo;
    v_count := v_count_tmp - v_count_tmp1;

    strResult := 'Y|成功导入' || v_count || '条数据]';
  end P_mdata_planUpLoad;
  /**********************************************************************************************************
    hcx
    2015.11.30
    修改人：czh     2016/5/18
    功能：返配手建单导入
  ***********************************************************************************************************/

  procedure P_ridata_untread(strEnterpriseNo in ridata_untread_tmp.enterprise_no%type,
                             strWareHouseNo  in ridata_untread_tmp.warehouse_no%type,
                             strWorkSpaceNo  in ridata_check_m.dock_no%type,
                             strUserId       in bdef_defworker.worker_no%type,
                             strResult       out varchar2) is
    v_count        number;
    v_count_1      number;
    v_untread_no   varchar2(20);
    v_SUntreadNo   varchar2(20);
    v_article_no   varchar2(20);
    v_cust_no      bdef_defcust.cust_no%type;
    v_strPrtTask   varchar2(24);
    v_result       varchar2(20);
    v_strPrintFlag wms_defbase.sdefine%type;
    v_nPrintFlag   wms_defbase.sdefine%type;
    n_qmin_operate_packing number;

  begin
    strResult := 'Y|[P_ridata_untread]';

    --锁表
    update ridata_untread_tmp
       set status = '11'
     where warehouse_no = strWareHouseNo
       and enterprise_no = strEnterpriseNo;

    for m in (select t.enterprise_no,
                     t.wareHouse_no,
                     t.owner_no,
                     t.po_type,
                     t.po_no,
                     t.cust_no,
                     t.untread_flag,
                     t.class_type,
                     t.quality,
                     t.request_date,
                     t.untread_date,
                     t.org_no,
                     t.take_type,
                     t.untread_remark,
                     t.car_plan_no,
                     t.rsv_varod1,
                     t.rsv_varod2,
                     t.rsv_varod3,
                     t.rsv_varod4,
                     t.rsv_varod5,
                     t.rsv_varod6,
                     t.rsv_varod7,
                     t.rsv_varod8,
                     t.rsv_num1,
                     t.rsv_num2,
                     t.rsv_num3,
                     t.rsv_date1,
                     t.rsv_date2,
                     t.rsv_date3
                from ridata_untread_tmp t
               where t.warehouse_no = strWareHouseNo
                 and t.status = '11'
                 and t.enterprise_no = strEnterpriseNo
               group by t.enterprise_no,
                        t.wareHouse_no,
                        t.owner_no,
                        t.po_type,
                        t.po_no,
                        t.cust_no,
                        t.untread_flag,
                        t.class_type,
                        t.quality,
                        t.request_date,
                        t.untread_date,
                        t.org_no,
                        t.take_type,
                        t.untread_remark,
                        t.car_plan_no,
                        t.rsv_varod1,
                        t.rsv_varod2,
                        t.rsv_varod3,
                        t.rsv_varod4,
                        t.rsv_varod5,
                        t.rsv_varod6,
                        t.rsv_varod7,
                        t.rsv_varod8,
                        t.rsv_num1,
                        t.rsv_num2,
                        t.rsv_num3,
                        t.rsv_date1,
                        t.rsv_date2,
                        t.rsv_date3) loop

      --判断货主是否存在
      select count(1)
        into v_count
        from bdef_defowner
       where owner_no = m.owner_no
         and enterprise_no = strEnterpriseNo;
      if v_count = 0 then
        strResult := 'N|[请检查' || m.owner_no || '货主不存在]'; --货主不存在
        --更新临时表状态
        update ridata_untread_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and status = '11';
        return;
      end if;

      --检查货主是否有权限
      select count(*)
        into v_count
        from (select distinct b.owner_no
                from bdef_defowner b, bdef_defworker d
               where b.enterprise_no = d.enterprise_no
                 and d.worker_no = strUserId
                 and b.authority_type = '1'
                 and b.enterprise_no = strEnterpriseNo
              union
              select distinct b.owner_no
                from bset_worker_owner b, bdef_defworker d
               where b.enterprise_no = d.enterprise_no
                 and b.worker_no = d.worker_no
                 and b.worker_no = strUserId
                 and b.enterprise_no = strEnterpriseNo) a
       where a.owner_no = m.owner_no;

      if v_count = 0 then
        strResult := 'N|[' || m.owner_no || '货主，用户没有货主权限]';
        return;
      end if;

      --检查同一货主同一返配单的客户编码、返配标识、单据类型、是否直通单、
      --质量类型、返配建单日期、返配发单日期、机构代码、提货类型、备注是否一样
      select count(*)
        into v_count
        from (select t.warehouse_no, t.owner_no, t.po_no
                from ridata_untread_tmp t
               where t.enterprise_no = m.enterprise_no
                 and t.warehouse_no = m.warehouse_no
                 and t.owner_no = m.owner_no
                 and t.po_no = m.po_no
               group by t.warehouse_no,
                        t.owner_no,
                        t.po_no,
                        t.cust_no,
                        t.untread_flag,
                        t.po_type,
                        t.class_type,
                        t.quality,
                        t.untread_date,
                        t.request_date,
                        t.org_no,
                        t.take_type,
                        t.untread_remark,
                        t.car_plan_no);
      if v_count >= 2 then
        strResult := 'N|[单号为' || m.po_no ||
                     '的货主客户编码、返配标识、单据类型、是否直通单、质量类型、返配建单日期、返配发单日期、机构代码、提货类型、派车单号、备注不一样]';
        --更新临时表状态
        update ridata_untread_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and status = '11';
        return;
      end if;

      --检查同一货主同一原返配单的商品是否重复
      select count(*)
        into v_count
        from (select t.warehouse_no, t.owner_no, t.po_no
                from ridata_untread_tmp t
               where t.enterprise_no = m.enterprise_no
                 and t.warehouse_no = m.warehouse_no
                 and t.owner_no = t.owner_no
                 and t.po_no = m.po_no
               group by t.warehouse_no,
                        t.owner_no,
                        t.po_no,
                        t.po_type,
                        t.owner_article_no,
                        t.packing_qty);

      select count(*)
        into v_count_1
        from (select t.warehouse_no, t.owner_no, t.po_no
                from ridata_untread_tmp t
               where t.enterprise_no = m.enterprise_no
                 and t.warehouse_no = m.warehouse_no
                 and t.owner_no = t.owner_no
                 and t.po_no = m.po_no);

      if v_count < v_count_1 then
        strResult := 'N|[单号为' || m.po_no || '的同一货主商品编码同一包装有重复数据，请检查]';
        --更新临时表状态
        update ridata_untread_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and status = '11';
        return;
      end if;

      --检查原返配单号是否已存在
      select count(1)
        into v_count
        from ridata_untread_m
       where po_no = m.po_no
         and enterprise_no = strEnterpriseNo
         and warehouse_no = strWareHouseNo;
      if v_count > 0 then
        strResult := 'N|[请检查' || m.po_no || '原返配单号已存在]'; --原单号已存在
        --更新临时表状态
        update ridata_untread_m
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and owner_no = m.owner_no
           and status = '11';
        return;
      end if;

      --判断客户是否存在
      select count(1)
        into v_count
        from bdef_defcust
       where owner_cust_no = m.cust_no
         and enterprise_no = strEnterpriseNo
         and owner_no = m.owner_no;
      if v_count = 0 then
        /*   strResult:= 'N|[原单号为' || m.po_no || '的客户编码'|| m.cust_no ||'不存在]';--客户不存在*/
        strResult := 'N|[' || m.cust_no || '货主客户编码不存在]'; --客户不存在
        --更新临时表状态
        update ridata_untread_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and owner_no = m.owner_no
           and status = '11';
        return;
      else
        select cust_no
          into v_cust_no
          from bdef_defcust
         where owner_cust_no = m.cust_no
           and enterprise_no = strEnterpriseNo
           and owner_no = m.owner_no;
      end if;

      --检查返配标识是否存在
      select count(1)
        into v_count
        from wms_deffieldval
       where table_name = 'RIDATA_UNTREAD_M'
         and colname = 'UNTREAD_FLAG'
         and value = m.untread_flag
         and status = '1';

      if v_count = 0 then
        strResult := 'N|[' || m.untread_flag || '返配标识不存在]';
        --更新临时表状态
        update ridata_untread_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and owner_no = m.owner_no
           and status = '11';
        return;
      end if;

      --检查单据类型是否存在
      select count(1)
        into v_count
        from wms_deffieldval
       where table_name = 'RIDATA_UNTREAD_M'
         and colname = 'UNTREAD_TYPE'
         and value = m.po_type
         and status = '1';

      if v_count = 0 then
        strResult := 'N|[' || m.po_type || '单据类型不存在]';
        --更新临时表状态
        update ridata_untread_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and owner_no = m.owner_no
           and status = '11';
        return;
      end if;

      --检查是否直通单是否存在
      select count(1)
        into v_count
        from wms_deffieldval
       where table_name = 'RIDATA_UNTREAD_M'
         and colname = 'CLASS'
         and value = m.class_type
         and status = '1';

      if v_count = 0 then
        strResult := 'N|[' || m.class_type || '是否直通单不存在]';
        --更新临时表状态
        update ridata_untread_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and owner_no = m.owner_no
           and status = '11';
        return;
      end if;

      --检查质量类型是否存在
      /*select count(1)
        into v_count
        from wms_deffieldval
       where table_name = 'RIDATA_UNTREAD_M'
         and colname = 'QUALITY'
         and value = m.quality
         and status = '1';*/
         select count(1)
        into v_count
        from wms_deffieldval
       where table_name = 'RIDATA_CHECK_PAL'
         and colname = 'QUALITY_FLAG'
         and value = m.quality
         and status = '1';

      if v_count = 0 then
        strResult := 'N|[第' || m.quality || '条质量类型不存在]';
        --更新临时表状态
        update ridata_untread_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and owner_no = m.owner_no
           and status = '11';
        return;
      end if;

      --检查返配建单日期
      if m.request_date < m.untread_date then

        strResult := 'N|[单号为' || m.po_no || '的返配单号返配发单日期小于返配建单日期]';
        --更新临时表状态
        update ridata_untread_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and owner_no = m.owner_no
           and status = '11';
        return;
      end if;

      --检查机构代码是否存在
      select count(1)
        into v_count
        from wms_deffieldval
       where table_name = 'N'
         and colname = 'ORG_NO'
         and value = m.org_no
         and status = '1';

      if v_count = 0 then
        strResult := 'N|[' || m.org_no || '机构代码不存在]';
        --更新临时表状态
        update ridata_untread_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and owner_no = m.owner_no
           and status = '11';
        return;
      end if;

      --检查提货类型是否存在
      select count(1)
        into v_count
        from wms_deffieldval
       where table_name = 'RIDATA_UNTREAD_M'
         and colname = 'TAKE_TYPE'
         and value = m.take_type
         and status = '1';

      if v_count = 0 then
        strResult := 'N|[' || m.take_type || '提货类型不存在]';
        --更新临时表状态
        update ridata_untread_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and owner_no = m.owner_no
           and status = '11';
        return;
      end if;

      for a in (select *
                  from ridata_untread_tmp rrt
                 where rrt.enterprise_no = strEnterpriseNo
                   and rrt.warehouse_no = strWareHouseNo
                   and rrt.owner_no = m.owner_no
                   and rrt.po_no = m.po_no) loop
        --检查该商品是否存在
        select count(1)
          into v_count
          from bdef_defarticle
         where owner_article_no = a.owner_article_no
           and enterprise_no = strEnterpriseNo
           and owner_no = a.owner_no;
        if v_count = 0 then
          strResult := 'N|[第' || a.Row_Id || '条货主商品编码不存在]'; --商品不存在
          --更新临时表状态
          update ridata_untread_tmp
             set status = '16'
           where enterprise_no = strEnterpriseNo
             and warehouse_no = strWareHouseNo
             and po_no = m.po_no
             and status = '11';
          return;
        else
          select article_no
            into v_article_no
            from bdef_defarticle
           where owner_article_no = a.owner_article_no
             and enterprise_no = strEnterpriseNo
             and owner_no = a.owner_no;

        end if;

        --检查商品包装是否存在
        if a.packing_qty = 0 then
          strResult := 'N|[单号为' || a.row_id || '条数据的商品包装为0，请检查]';
          --更新临时表状态
          update ridata_untread_tmp
             set status = '16'
           where enterprise_no = strEnterpriseNo
             and warehouse_no = strWareHouseNo
             and po_no = m.po_no
             and row_id = a.row_id
             and status = '11'
             and packing_qty = 0;
          return;
        end if;

        if a.packing_qty <> 1 then
          select count(1)
            into v_count
            from (select b.packing_qty
                    from bdef_article_packing b
                   where b.article_no = v_article_no
                     and b.enterprise_no = strEnterpriseNo
                     and b.packing_qty = a.packing_qty);
          if v_count = 0 then
            select qmin_operate_packing
          into n_qmin_operate_packing
          from bdef_defarticle d
         where d.enterprise_no = a.enterprise_no
           and d.owner_no = a.owner_no
           and d.owner_article_no = a.owner_article_no;
           if n_qmin_operate_packing = 0 then
            strResult := 'N|[第' || a.Row_Id || '条商品包装不存在]'; --商品包装不存在
            --更新临时表状态
            update ridata_untread_tmp
               set status = '16'
             where enterprise_no = strEnterpriseNo
               and warehouse_no = strWareHouseNo
               and po_no = m.po_no
               and row_id = a.row_id
               and status = '11';
            return;
            end if;
          end if;
        end if;
        --检查商品退货量是否大于0
        if a.po_qty <= 0 then
          strResult := 'N|[第' || a.Row_Id || '的数据商品数量小于等于0，请检查]';
          --更新临时表状态
          update ridata_untread_tmp
             set status = '16'
           where enterprise_no = strEnterpriseNo
             and warehouse_no = strWareHouseNo
             and po_no = m.po_no
             and row_id = a.row_id
             and status = '11';
          return;
        end if;
      end loop;
      --取返配单号
      PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                 strWareHouseNo,
                                 CONST_DOCUMENTTYPE.RIDATAUM,
                                 v_untread_no,
                                 v_result);

      --插入单头
      insert into ridata_untread_m
        (enterprise_no,
         warehouse_no,
         owner_no,
         untread_type,
         untread_no,
         po_type,
         po_no,
         class_type,
         cust_no,
         untread_date,
         request_date,
         status,
         create_flag,
         untread_remark,
         untread_flag,
         stock_type,
         stock_value,
         dept_no,
         send_flag,
         rgst_name,
         rgst_date,
         exp_no,
         quality,
         org_no,
         take_type,
         car_plan_no,
         rsv_varod1,
         rsv_varod2,
         rsv_varod3,
         rsv_varod4,
         rsv_varod5,
         rsv_varod6,
         rsv_varod7,
         rsv_varod8,
         rsv_num1,
         rsv_num2,
         rsv_num3,
         rsv_date1,
         rsv_date2,
         rsv_date3)
      values
        (strEnterpriseNo,
         strWareHouseNo,
         m.owner_no,
         m.po_type,
         v_untread_no,
         m.po_type,
         m.po_no,
         m.class_type,
         v_cust_no,
         m.untread_date,
         m.request_date,
         '10',
         1,
         m.untread_remark,
         m.untread_flag,
         '1',
         'N',
         'N',
         '10',
         strUserId,
         sysdate,
         '0',
         m.quality,
         m.org_no,
         m.take_type,
         m.car_plan_no,
         m.rsv_varod1,
         m.rsv_varod2,
         m.rsv_varod3,
         m.rsv_varod4,
         m.rsv_varod5,
         m.rsv_varod6,
         m.rsv_varod7,
         m.rsv_varod8,
         m.rsv_num1,
         m.rsv_num2,
         m.rsv_num3,
         m.rsv_date1,
         m.rsv_date2,
         m.rsv_date3);
      if sql%rowcount <= 0 then
        strResult := 'N|[E20501]'; --插入单头失败];
        return;
      end if;

      /*--插入明细
      --规则：无散数直接插入一条数据,有散数插入两条数据
      for rut in (select *
                    from ridata_untread_tmp rut
                   where rut.enterprise_no = strEnterpriseNo
                     and rut.warehouse_no = strWareHouseNo
                     and rut.owner_no = m.owner_no
                     and rut.po_no = m.po_no) loop

        if (mod(rut.po_qty, rut.packing_qty) = 0) then
          insert into ridata_untread_d
            (enterprise_no,
             warehouse_no,
             owner_no,
             untread_no,
             po_id,
             supplier_no,
             article_no,
             packing_qty,
             untread_qty,
             unit_cost,
             status)
            select strEnterpriseNo,
                   strWareHouseNo,
                   rut.owner_no,
                   v_untread_no,
                   ROW_NUMBER() OVER(PARTITION BY rut.po_no ORDER BY rut.owner_article_no) po_id,
                   case
                     when bd.supplier_no is null then
                      'N'
                     else
                      bd.supplier_no
                   end,
                   bd.article_no,
                   rut.packing_qty,
                   rut.po_qty,
                   rut.unit_cost,
                   '10'
              from ridata_untread_tmp rut, bdef_defarticle bd
             where rut.enterprise_no = bd.enterprise_no
               and rut.owner_no = bd.owner_no
               and rut.owner_article_no = bd.owner_article_no
               and rut.po_no = m.po_no;

          if sql%rowcount <= 0 then
            strResult := 'N|[E23211]'; --插入明细失败
          end if;
        else
          insert into ridata_untread_d
            (enterprise_no,
             warehouse_no,
             owner_no,
             untread_no,
             po_id,
             supplier_no,
             article_no,
             packing_qty,
             untread_qty,
             unit_cost,
             status)
            select strEnterpriseNo,
                   strWareHouseNo,
                   rut.owner_no,
                   v_untread_no,
                   ROW_NUMBER() OVER(PARTITION BY rut.po_no ORDER BY rut.owner_article_no) po_id,
                   case
                     when bd.supplier_no is null then
                      'N'
                     else
                      bd.supplier_no
                   end,
                   bd.article_no,
                   rut.packing_qty,
                   trunc(rut.po_qty, rut.packing_qty) * rut.packing_qty,
                   rut.unit_cost,
                   '10'
              from ridata_untread_tmp rut, bdef_defarticle bd
             where rut.enterprise_no = bd.enterprise_no
               and rut.owner_no = bd.owner_no
               and rut.owner_article_no = bd.owner_article_no
               and rut.po_no = m.po_no;

          if sql%rowcount <= 0 then
            strResult := 'N|[E23211]'; --插入明细失败
          end if;
          insert into ridata_untread_d
            (enterprise_no,
             warehouse_no,
             owner_no,
             untread_no,
             po_id,
             supplier_no,
             article_no,
             packing_qty,
             untread_qty,
             unit_cost,
             status)
            select strEnterpriseNo,
                   strWareHouseNo,
                   rut.owner_no,
                   v_untread_no,
                   ROW_NUMBER() OVER(PARTITION BY rut.po_no ORDER BY rut.owner_article_no) po_id,
                   case
                     when bd.supplier_no is null then
                      'N'
                     else
                      bd.supplier_no
                   end,
                   bd.article_no,
                   '1',
                   mod(rut.po_qty, rut.packing_qty),
                   rut.unit_cost,
                   '10'
              from ridata_untread_tmp rut, bdef_defarticle bd
             where rut.enterprise_no = bd.enterprise_no
               and rut.owner_no = bd.owner_no
               and rut.owner_article_no = bd.owner_article_no
               and rut.po_no = m.po_no;

          if sql%rowcount <= 0 then
            strResult := 'N|[E23211]'; --插入明细失败
          end if;
        end if;

      end loop;*/

      --插入明细
      insert into ridata_untread_d
        (enterprise_no,
         warehouse_no,
         owner_no,
         untread_no,
         po_id,
         supplier_no,
         article_no,
         packing_qty,
         untread_qty,
         unit_cost,
         status)
        select strEnterpriseNo,
               strWareHouseNo,
               rut.owner_no,
               v_untread_no,
               ROW_NUMBER() OVER(PARTITION BY rut.po_no ORDER BY rut.owner_article_no) po_id,
               case
                 when bd.supplier_no is null then
                  'N'
                 else
                  bd.supplier_no
               end,
               bd.article_no,
               rut.packing_qty,
               rut.po_qty,
               rut.unit_cost,
               '10'
          from ridata_untread_tmp rut, bdef_defarticle bd
         where rut.enterprise_no = bd.enterprise_no
           and rut.owner_no = bd.owner_no
           and rut.owner_article_no = bd.owner_article_no
           and rut.po_no = m.po_no;

      if sql%rowcount <= 0 then
        strResult := 'N|[E23211]'; --插入明细失败
      end if;

      /*  --取返配汇总单号
      PKLG_WMS_BASE.p_getsheetno(m.enterprise_no,m.warehouse_no,CONST_DOCUMENTTYPE.RIDATAVM,v_SUntreadNo,v_result);--获取单号


      --返配汇总单头档
      insert into ridata_untread_mm(
                              enterprise_no,
                              warehouse_no,
                              owner_no,
                              s_untread_no,
                              s_po_no,
                              cust_no,
                              class_type,
                              status,
                              rgst_name,
                              rgst_date,
                              quality,
                              serial_no)
                      values(
                              strEnterpriseNo,
                              strWareHouseNo,
                              m.owner_no,
                              v_SUntreadNo,
                              m.po_no,
                              m.cust_no,
                              m.class_type,
                              '10',
                              strUserId,
                              sysdate,
                              m.quality,
                              SEQ_RIDATA_UNTREAD_MM.Nextval
                       );

       --返配汇总单关系
       insert into ridata_untread_sm(
                              enterprise_no,
                              warehouse_no,
                              owner_no,
                              s_untread_no,
                              untread_type,
                              untread_no,
                              po_type,
                              po_no,
                              status,
                              rgst_name,
                              rgst_date)
                       values(
                              strEnterpriseNo,
                              strWareHouseNo,
                              m.owner_no,
                              v_SUntreadNo,
                              m.po_type,
                              v_untread_no,
                              m.po_type,
                              m.po_no,
                              '10',
                              strUserId,
                              sysdate
               );*/
      --获取系统参数 判断是否打印返配预计验收单
      /*     PKLG_WMS_BASE.p_GetBasePara(strEnterpriseNo,
                                 strWareHouseNo,
                                 m.owner_no,
                                 'PrintCheckPlan',
                                 'RI',
                                 'RI_PRINT',
                                 v_strPrintFlag,
                                 v_nPrintFlag,
                                 strResult);
        if substr(strResult, 1, 1) = 'N' then
           strResult := 'N|[E30025]';
           return;
        end if;
      if v_strPrintFlag='1' then
         --写打印任务
         PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterPriseNo,
                                       strWareHouseNo,
                                       v_SUntreadNo,
                                       0,
                                       CONST_REPORTID.RPT_UM_READY_CHECK,
                                       strWorkSpaceNo,
                                       0,
                                       strUserId,
                                       v_strPrtTask,
                                       strResult);
          if substr(strResult, 1, 1) <> 'Y' then
             return;
          end if;

        end if; */

      --商品导入成功，修改临时表状态为13（成功）
      update ridata_untread_tmp
         set status = '13'
       where enterprise_no = strEnterpriseNo
         and warehouse_no = strWareHouseNo
         and po_no = m.po_no
         and owner_no = m.owner_no
         and status = '11';
    end loop;

    delete from ridata_untread_tmp
     where warehouse_no = strWareHouseNo
       and status = '13'
       and enterprise_no = strEnterpriseNo;

    strResult := 'Y|导入成功';

  end P_ridata_untread;
  /**********************************************************************************************************
    hcx
    2015.12.01
    修改人：czh     2016/5/18
    功能：退厂手建单导入
  ***********************************************************************************************************/
  procedure P_rodata_recede(strEnterpriseNo in ridata_untread_tmp.enterprise_no%type,
                            strWareHouseNo  in ridata_untread_tmp.warehouse_no%type,
                            strUserId       in bdef_defworker.worker_no%type,
                            strResult       out varchar2) is
    v_count      number;
    v_count_1    number;
    v_recede_no  varchar2(20);
    v_article_no varchar2(20);
    v_result     varchar2(20);
    n_qmin_operate_packing number;

  begin
    strResult := 'Y|[P_ridata_untread]';

    --锁表
    update rodata_recede_tmp
       set status = '11'
     where warehouse_no = strWareHouseNo
       and enterprise_no = strEnterpriseNo;

    for m in (select t.enterprise_no,
                     t.wareHouse_no,
                     t.owner_no,
                     t.po_type,
                     t.po_no,
                     t.supplier_no,
                     t.recede_date,
                     t.request_date,
                     t.org_no,
                     t.recede_remark,
                     t.class_type,
                     t.dept_no,
                     t.take_type,
                     t.rsv_varod1,
                     t.rsv_varod2,
                     t.rsv_varod3,
                     t.rsv_varod4,
                     t.rsv_varod5,
                     t.rsv_varod6,
                     t.rsv_varod7,
                     t.rsv_varod8,
                     t.rsv_num1,
                     t.rsv_num2,
                     t.rsv_num3,
                     t.rsv_date1,
                     t.rsv_date2,
                     t.rsv_date3
                from rodata_recede_tmp t
               where t.warehouse_no = strWareHouseNo
                 and t.status = '11'
                 and t.enterprise_no = strEnterpriseNo
               group by t.enterprise_no,
                        t.wareHouse_no,
                        t.owner_no,
                        t.po_type,
                        t.po_no,
                        t.supplier_no,
                        t.recede_date,
                        t.request_date,
                        t.org_no,
                        t.recede_date,
                        t.recede_remark,
                        t.class_type,
                        t.dept_no,
                        t.take_type,
                        t.rsv_varod1,
                        t.rsv_varod2,
                        t.rsv_varod3,
                        t.rsv_varod4,
                        t.rsv_varod5,
                        t.rsv_varod6,
                        t.rsv_varod7,
                        t.rsv_varod8,
                        t.rsv_num1,
                        t.rsv_num2,
                        t.rsv_num3,
                        t.rsv_date1,
                        t.rsv_date2,
                        t.rsv_date3) loop

      --判断货主是否存在
      select count(1)
        into v_count
        from bdef_defowner
       where owner_no = m.owner_no
         and enterprise_no = strEnterpriseNo;
      if v_count = 0 then
        strResult := 'N|[请检查' || m.owner_no || '货主不存在]'; --货主不存在
        --更新临时表状态
        update rodata_recede_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and status = '11';
        return;
      end if;

      --检查货主是否有权限
      select count(*)
        into v_count
        from (select distinct b.owner_no
                from bdef_defowner b, bdef_defworker d
               where b.enterprise_no = d.enterprise_no
                 and d.worker_no = strUserId
                 and b.authority_type = '1'
                 and b.enterprise_no = strEnterpriseNo
              union
              select distinct b.owner_no
                from bset_worker_owner b, bdef_defworker d
               where b.enterprise_no = d.enterprise_no
                 and b.worker_no = d.worker_no
                 and b.worker_no = strUserId
                 and b.enterprise_no = strEnterpriseNo) a
       where a.owner_no = m.owner_no;

      if v_count = 0 then
        strResult := 'N|[' || m.owner_no || '货主，用户没有货主权限]';
        return;
      end if;

      --检查同一货主同一退货单的供应商编码、退货单类型、退货发单日期、预定退货日期、
      --退货类型、机构代码、提货类型、备注是否一样
      select count(*)
        into v_count
        from (select t.warehouse_no, t.owner_no, t.po_no
                from rodata_recede_tmp t
               where t.enterprise_no = m.enterprise_no
                 and t.warehouse_no = m.warehouse_no
                 and t.owner_no = t.owner_no
                 and t.po_no = m.po_no
               group by t.warehouse_no,
                        t.owner_no,
                        t.po_no,
                        t.supplier_no,
                        t.po_type,
                        t.class_type,
                        t.recede_date,
                        t.request_date,
                        t.org_no,
                        t.take_type,
                        t.recede_remark);
      if v_count >= 2 then
        strResult := 'N|[单号为' || m.po_no ||
                     '的供应商编码、退货单类型、退货发单日期、预定退货日期、机构代码、退货类型、提货类型、备注不一样]';
        --更新临时表状态
        update rodata_recede_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and status = '11';
        return;
      end if;

      --检查同一货主同一原退货单的商品是否重复
      select count(*)
        into v_count
        from (select t.warehouse_no, t.owner_no, t.po_no
                from rodata_recede_tmp t
               where t.enterprise_no = m.enterprise_no
                 and t.warehouse_no = m.warehouse_no
                 and t.owner_no = t.owner_no
                 and t.po_no = m.po_no
               group by t.warehouse_no,
                        t.owner_no,
                        t.po_no,
                        t.po_type,
                        t.owner_article_no,
                        t.packing_qty);

      select count(*)
        into v_count_1
        from (select t.warehouse_no, t.owner_no, t.po_no
                from rodata_recede_tmp t
               where t.enterprise_no = m.enterprise_no
                 and t.warehouse_no = m.warehouse_no
                 and t.owner_no = t.owner_no
                 and t.po_no = m.po_no);

      if v_count < v_count_1 then
        strResult := 'N|[单号为' || m.po_no || '的同一货主商品编码同一包装有重复数据，请检查]';
        --更新临时表状态
        update rodata_recede_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and status = '11';
        return;
      end if;

      --检查原退货单号是否已存在
      select count(1)
        into v_count
        from rodata_recede_m
       where po_no = m.po_no
         and enterprise_no = strEnterpriseNo
         and warehouse_no = strWareHouseNo;
      if v_count > 0 then
        strResult := 'N|[请检查' || m.po_no || '原退货单号已存在]'; --原单号已存在
        --更新临时表状态
        update rodata_recede_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and owner_no = m.owner_no
           and status = '11';
        return;
      end if;

      --判断供应商是否存在
      select count(1)
        into v_count
        from bdef_defsupplier
       where supplier_no = m.supplier_no
         and enterprise_no = strEnterpriseNo
         and owner_no = m.owner_no;
      if v_count = 0 then
        strResult := 'N|[' || m.supplier_no || '供应商不存在]'; --供应商不存在
        --更新临时表状态
        update rodata_recede_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and owner_no = m.owner_no
           and status = '11';
        return;
      end if;

      --检查退货单类型是否存在
      select count(1)
        into v_count
        from wms_deffieldval
       where table_name = 'RODATA_RECEDE_M'
         and colname = 'RECEDE_TYPE'
         and value = m.po_type
         and status = '1';

      if v_count = 0 then
        strResult := 'N|[' || m.po_type || '退货单类型不存在]';
        --更新临时表状态
        update rodata_recede_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and owner_no = m.owner_no
           and status = '11';
        return;
      end if;

      --检查退货发单日期
      if m.request_date < m.recede_date then

        strResult := 'N|[单号为' || m.po_no || '的退货单预定退货日期小于退货发单日期]';
        --更新临时表状态
        update rodata_recede_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and owner_no = m.owner_no
           and status = '11';
        return;
      end if;

      --检查机构代码是否存在
      select count(1)
        into v_count
        from wms_deffieldval
       where table_name = 'N'
         and colname = 'ORG_NO'
         and value = m.org_no
         and status = '1';

      if v_count = 0 then
        strResult := 'N|[' || m.org_no || '机构代码不存在]';
        --更新临时表状态
        update rodata_recede_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and owner_no = m.owner_no
           and status = '11';
        return;
      end if;

      --检查退货类型是否存在
      select count(1)
        into v_count
        from wms_deffieldval
       where table_name = 'N'
         and colname = 'CLASS_TYPE'
         and value = m.class_type
         and status = '1';

      if v_count = 0 then
        strResult := 'N|[' || m.class_type || '退货类型不存在]';
        --更新临时表状态
        update rodata_recede_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and owner_no = m.owner_no
           and status = '11';
        return;
      end if;

      --检查提货类型是否存在
      select count(1)
        into v_count
        from wms_deffieldval
       where table_name = 'N'
         and colname = 'TAKE_TYPE'
         and value = m.take_type
         and status = '1';

      if v_count = 0 then
        strResult := 'N|[' || m.take_type || '提货类型不存在]';
        --更新临时表状态
        update rodata_recede_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and owner_no = m.owner_no
           and status = '11';
        return;
      end if;

      for a in (select *
                  from rodata_recede_tmp rrt
                 where rrt.enterprise_no = strEnterpriseNo
                   and rrt.warehouse_no = strWareHouseNo
                   and rrt.owner_no = m.owner_no
                   and rrt.po_no = m.po_no) loop
        --检查该商品是否存在
        select count(1)
          into v_count
          from bdef_defarticle
         where owner_article_no = a.owner_article_no
           and enterprise_no = strEnterpriseNo
           and owner_no = a.owner_no;
        if v_count = 0 then
          strResult := 'N|[第' || a.Row_Id || '条货主商品编码不存在]'; --商品不存在
          --更新临时表状态
          update rodata_recede_tmp
             set status = '16'
           where enterprise_no = strEnterpriseNo
             and warehouse_no = strWareHouseNo
             and po_no = m.po_no
             and row_id = a.row_id
             and status = '11';
          return;
        else
          select article_no
            into v_article_no
            from bdef_defarticle
           where owner_article_no = a.owner_article_no
             and enterprise_no = strEnterpriseNo
             and owner_no = a.owner_no;

        end if;

        --检查商品包装是否存在
        if a.packing_qty = 0 then
          strResult := 'N|[第' || a.row_id || '条数据的商品包装为0，请检查]';
          --更新临时表状态
          update rodata_recede_tmp
             set status = '16'
           where enterprise_no = strEnterpriseNo
             and warehouse_no = strWareHouseNo
             and po_no = m.po_no
             and row_id = a.row_id
             and status = '11';
          return;
        end if;

        if a.packing_qty <> 1 then
          select count(1)
            into v_count
            from (select b.packing_qty
                    from bdef_article_packing b
                   where b.article_no = v_article_no
                     and b.enterprise_no = strEnterpriseNo
                     and b.packing_qty = a.packing_qty);
          if v_count = 0 then
            select count(1) --是否为最小操作包装数
                into n_qmin_operate_packing
                from bdef_defarticle b
               where b.enterprise_no = strEnterpriseNo
                 and b.owner_no = a.owner_no
                 and b.owner_article_no = a.owner_article_no;
                 if n_qmin_operate_packing = 0 then
            strResult := 'N|[第' || a.Row_Id || '条商品包装不存在]'; --商品包装不存在
            --更新临时表状态
            update rodata_recede_tmp
               set status = '16'
             where enterprise_no = strEnterpriseNo
               and warehouse_no = strWareHouseNo
               and po_no = m.po_no
               and row_id = a.row_id
               and status = '11';
            return;
            end if;
          end if;
        end if;
        --检查商品退货量是否大于0
        if a.po_qty <= 0 then
          strResult := 'N|[第' || a.Row_Id || '的数据商品数量小于等于0，请检查]';
          --更新临时表状态
          update rodata_recede_tmp
             set status = '16'
           where enterprise_no = strEnterpriseNo
             and warehouse_no = strWareHouseNo
             and po_no = m.po_no
             and row_id = a.row_id
             and status = '11';
          return;
        end if;
      end loop;

      --取退货单号
      PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                 strWareHouseNo,
                                 CONST_DOCUMENTTYPE.RODATARE,
                                 v_recede_no,
                                 v_result);

      --插入单头
      insert into rodata_recede_m
        (enterprise_no,
         warehouse_no,
         owner_no,
         recede_type,
         recede_no,
         po_type,
         po_no,
         supplier_no,
         class_type,
         recede_date,
         status,
         recede_remark,
         request_date,
         rgst_name,
         rgst_date,
         org_no,
         create_flag,
         dept_no,
         take_type,
         rsv_varod1,
         rsv_varod2,
         rsv_varod3,
         rsv_varod4,
         rsv_varod5,
         rsv_varod6,
         rsv_varod7,
         rsv_varod8,
         rsv_num1,
         rsv_num2,
         rsv_num3,
         rsv_date1,
         rsv_date2,
         rsv_date3)
      values
        (strEnterpriseNo,
         strWareHouseNo,
         m.owner_no,
         m.po_type,
         v_recede_no,
         m.po_type,
         m.po_no,
         m.supplier_no,
         m.class_type,
         m.recede_date,
         '10',
         m.recede_remark,
         m.request_date,
         strUserId,
         sysdate,
         m.org_no,
         '0',
         m.dept_no,
         m.take_type,
         m.rsv_varod1,
         m.rsv_varod2,
         m.rsv_varod3,
         m.rsv_varod4,
         m.rsv_varod5,
         m.rsv_varod6,
         m.rsv_varod7,
         m.rsv_varod8,
         m.rsv_num1,
         m.rsv_num2,
         m.rsv_num3,
         m.rsv_date1,
         m.rsv_date2,
         m.rsv_date3);
      if sql%rowcount <= 0 then
        strResult := 'N|[E20501]'; --插入单头失败];
        return;
      end if;
      /*--插入明细
      --规则：无散数直接插入一条数据,有散数插入两条数据
      for rut in (select *
                    from idata_import_tmp rut
                   where rut.owner_no = m.owner_no
                     and rut.enterprise_no = strEnterpriseNo
                     and rut.po_no = m.po_no) loop
        if (mod(rut.po_qty, rut.packing_qty) = 0) then
          insert into rodata_recede_d
            (enterprise_no,
             warehouse_no,
             owner_no,
             recede_no,
             owner_article_no,
             article_no,
             packing_qty,
             recede_qty,
             po_id,
             unit_cost,
             status)
            select strEnterpriseNo,
                   strWareHouseNo,
                   rut.owner_no,
                   v_recede_no,
                   bd.owner_article_no,
                   bd.article_no,
                   rut.packing_qty,
                   rut.po_qty,
                   ROW_NUMBER() OVER(PARTITION BY rut.po_no ORDER BY rut.owner_article_no) po_id,
                   rut.unit_cost,
                   '10'
              from bdef_defarticle bd
             where rut.enterprise_no = bd.enterprise_no
               and rut.owner_no = bd.owner_no
               and rut.owner_article_no = bd.owner_article_no
               and rut.po_no = m.po_no;

          if sql%rowcount <= 0 then
            strResult := 'N|[E23211]'; --插入明细失败
          end if;
        else
          insert into rodata_recede_d
            (enterprise_no,
             warehouse_no,
             owner_no,
             recede_no,
             owner_article_no,
             article_no,
             packing_qty,
             recede_qty,
             po_id,
             unit_cost,
             status)
            select strEnterpriseNo,
                   strWareHouseNo,
                   rut.owner_no,
                   v_recede_no,
                   bd.owner_article_no,
                   bd.article_no,
                   rut.packing_qty,
                   trunc(rut.po_qty, rut.packing_qty) * rut.packing_qty,
                   ROW_NUMBER() OVER(PARTITION BY rut.po_no ORDER BY rut.owner_article_no) po_id,
                   rut.unit_cost,
                   '10'
              from bdef_defarticle bd
             where rut.enterprise_no = bd.enterprise_no
               and rut.owner_no = bd.owner_no
               and rut.owner_article_no = bd.owner_article_no
               and rut.po_no = m.po_no;

          if sql%rowcount <= 0 then
            strResult := 'N|[E23211]'; --插入明细失败
          end if;
          insert into rodata_recede_d
            (enterprise_no,
             warehouse_no,
             owner_no,
             recede_no,
             owner_article_no,
             article_no,
             packing_qty,
             recede_qty,
             po_id,
             unit_cost,
             status)
            select strEnterpriseNo,
                   strWareHouseNo,
                   rut.owner_no,
                   v_recede_no,
                   bd.owner_article_no,
                   bd.article_no,
                   '1',
                   mod(rut.po_qty, rut.packing_qty),
                   ROW_NUMBER() OVER(PARTITION BY rut.po_no ORDER BY rut.owner_article_no) po_id,
                   rut.unit_cost,
                   '10'
              from bdef_defarticle bd
             where rut.enterprise_no = bd.enterprise_no
               and rut.owner_no = bd.owner_no
               and rut.owner_article_no = bd.owner_article_no
               and rut.po_no = m.po_no;

          if sql%rowcount <= 0 then
            strResult := 'N|[E23211]'; --插入明细失败
          end if;
        end if;
      end loop;*/
      --插入明细
      insert into rodata_recede_d
        (enterprise_no,
         warehouse_no,
         owner_no,
         recede_no,
         owner_article_no,
         article_no,
         packing_qty,
         recede_qty,
         po_id,
         unit_cost,
         status)
        select strEnterpriseNo,
               strWareHouseNo,
               rut.owner_no,
               v_recede_no,
               bd.owner_article_no,
               bd.article_no,
               rut.packing_qty,
               rut.po_qty,
               ROW_NUMBER() OVER(PARTITION BY rut.po_no ORDER BY rut.owner_article_no) po_id,
               rut.unit_cost,
               '10'
          from rodata_recede_tmp rut, bdef_defarticle bd
         where rut.enterprise_no = bd.enterprise_no
           and rut.owner_no = bd.owner_no
           and rut.owner_article_no = bd.owner_article_no
           and rut.po_no = m.po_no;

      if sql%rowcount <= 0 then
        strResult := 'N|[E23211]'; --插入明细失败
      end if;

      --商品导入成功，修改临时表状态为13（成功）
      update rodata_recede_tmp
         set status = '13'
       where enterprise_no = strEnterpriseNo
         and warehouse_no = strWareHouseNo
         and po_no = m.po_no
         and owner_no = m.owner_no
         and status = '11';
    end loop;
    delete from rodata_recede_tmp
     where warehouse_no = strWareHouseNo
       and status = '13'
       and enterprise_no = strEnterpriseNo;

    strResult := 'Y|导入成功';
  end P_rodata_recede;

  /**********************************************************************************************************
   chensr
    2015.08.11
    功能：储位导入
  ***********************************************************************************************************/
  procedure p_insertDefcell(strEnterpriseNo in tmp_formexcel_defcell.enterprise_no%type,
                            strWarehouseNo  in tmp_formexcel_defcell.warehouse_no%type,
                            strUserId       in bdef_defworker.worker_no%type,
                            strRowid        out tmp_formexcel_defcell.row_id%type,
                            strOutMsg       out varchar2) is
    v_iCount       integer;
    v_stockLength  number; --通道长度
    v_stockXLength number; --格长度
    v_bayXLength   number; --位长度
    v_stockNo      tmp_formexcel_defcell.stock_no%type; --通道
    v_stockX       tmp_formexcel_defcell.stock_x%type; --储格
    v_bayX         tmp_formexcel_defcell.bay_x%type; --储位
    v_defcellNo    tmp_formexcel_defcell.cell_no%type; --储位编码
    v_maxLength    number; --用于储位表中记录通道、格、位的最大值
  begin
    strOutMsg := 'N|找不到对应的数据';
    --锁数据
    update tmp_formexcel_defcell tfd
       set tfd.status = '11'
     where tfd.enterprise_no = strEnterpriseNo
       and tfd.warehouse_no = strWarehouseNo
       and tfd.status = '10';

    for m in (select *
                from tmp_formexcel_defcell a
               where a.enterprise_no = strEnterpriseNo
                 and a.warehouse_no = strWarehouseNo
                 and a.status = '11') loop
      strRowid := m.row_id;

      if m.prefix <> '#' then
        v_defcellNo := m.prefix;
      else
        v_defcellNo := '';
      end if;

      --检验库区和储区
      select count(1)
        into v_iCount
        from cdef_defarea cda
       where cda.enterprise_no = strEnterpriseNo
         and cda.warehouse_no = strWarehouseNo
         and cda.ware_no = m.ware_no
         and cda.area_no = m.area_no;

      if v_iCount = 0 then
        select count(1)
          into v_iCount
          from cdef_defware cdf
         where cdf.enterprise_no = strEnterpriseNo
           and cdf.warehouse_no = strWarehouseNo
           and cdf.ware_no = m.ware_no;

        if v_iCount = 0 then
          strOutMsg := 'N|库区不存在';
        else
          strOutMsg := 'N|储区不存在';
        end if;
        return;
      end if;

      --检验储位编码是否已经存在
      select count(1)
        into v_iCount
        from cdef_defcell cdc
       where cdc.enterprise_no = strEnterpriseNo
         and cdc.warehouse_no = strWarehouseNo
         and cdc.ware_no = m.ware_no
         and cdc.area_no = m.area_no
         and cdc.cell_no = m.cell_no;
      if v_iCount >= 1 then
        strOutMsg := 'N|储位编码已经存在';
        return;
      end if;

      --获取临时表储区通道的长度
      select nvl(max(a.stock_no), 0)
        into v_stockNo
        from tmp_formexcel_defcell a
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWarehouseNo
         and a.ware_no = m.ware_no
         and a.area_no = m.area_no;
      if v_stockNo < 1 and v_stockNo <> -1 then
        strOutMsg := 'N|通道不能小于1,不能为空';
        return;
      end if;

      if m.stock_no = -1 then
        --不维护通道
        v_stockLength := 1;
      else
        --获取储位表储区通道的长度
        select nvl(max(to_number(a.stock_no)), 0)
          into v_maxLength
          from cdef_defcell a
         where a.enterprise_no = strEnterpriseNo
           and a.warehouse_no = strWarehouseNo
           and a.ware_no = m.ware_no
           and a.area_no = m.area_no
           and a.stock_no <> '-';
        --比较，并得到通道的长度
        if v_stockNo < v_maxLength then
          if v_maxLength >= 10 then
            v_stockLength := 2;
          else
            v_stockLength := 1;
          end if;
        else
          if v_stockNo >= 10 and v_maxLength >= 10 and v_maxLength <> 0 then
            v_stockLength := 2;
          elsif v_stockNo >= 10 and v_maxLength < 10 then
            strOutMsg := 'N|通道设置长度与原有通道长度不符合';
            return;
          else
            v_stockLength := 1;
          end if;
        end if;
        --拼接储位编码
        v_defcellNo := v_defcellNo || lpad(m.stock_no, v_stockLength, '0');
      end if;

      --获取临时表储区下通道的储格的长度
      select nvl(max(a.stock_x), 0)
        into v_stockX
        from tmp_formexcel_defcell a
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWarehouseNo
         and a.ware_no = m.ware_no
         and a.area_no = m.area_no
         and a.stock_no = m.stock_no;
      if v_stockX < 1 then
        strOutMsg := 'N|储格不能小于1';
        return;
      end if;
      --获取储位表储区下通道的出格的长度
      if m.stock_no <> -1 then
        select nvl(max(to_number(a.stock_x)), 0)
          into v_maxLength
          from cdef_defcell a
         where a.enterprise_no = strEnterpriseNo
           and a.warehouse_no = strWarehouseNo
           and a.ware_no = m.ware_no
           and a.area_no = m.area_no
           and a.stock_no = m.stock_x;
      else
        select nvl(max(to_number(a.stock_x)), 0)
          into v_maxLength
          from cdef_defcell a
         where a.enterprise_no = strEnterpriseNo
           and a.warehouse_no = strWarehouseNo
           and a.ware_no = m.ware_no
           and a.area_no = m.area_no;
      end if;

      --比较获取储格长度
      if v_stockX < v_maxLength then
        if v_maxLength >= 10 then
          v_stockXLength := 2;
        else
          v_stockXLength := 1;
        end if;
      else
        if (v_stockX >= 10 and v_maxLength >= 10) or
           (v_stockX >= 10and v_maxLength = 0) then
          v_stockXLength := 2;
        elsif v_stockX >= 10 and v_maxLength < 10 and v_maxLength <> 0 then
          strOutMsg := 'N|储格设置长度与原有储格长度不符合';
          return;
        else
          v_stockXLength := 1;
        end if;
      end if;
      --拼接储位编码
      v_defcellNo := v_defcellNo || lpad(m.stock_x, v_stockXLength, '0');

      --获取临时表储位的长度
      select nvl(max(a.bay_x), 0)
        into v_bayX
        from tmp_formexcel_defcell a
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWarehouseNo
         and a.ware_no = m.ware_no
         and a.area_no = m.area_no
         and a.stock_no = m.stock_no
         and a.stock_x = m.stock_x;

      if v_bayX < 1 and v_bayX <> -1 then
        strOutMsg := 'N|储位不能小于1';
        return;
      end if;

      if v_bayX = -1 then
        v_bayXLength := 1;
      else
        --获取储位表储位长度
        select nvl(max(to_number(a.bay_x)), 0)
          into v_maxLength
          from cdef_defcell a
         where a.enterprise_no = strEnterpriseNo
           and a.warehouse_no = strWarehouseNo
           and a.ware_no = m.ware_no
           and a.area_no = m.area_no
           and a.stock_no = m.stock_x
           and a.stock_x = m.stock_no;

        --比较获取储位长度
        if v_bayX < v_maxLength then
          if v_maxLength >= 10 then
            v_bayXLength := 2;
          else
            v_bayXLength := 2;
          end if;
        else
          if (v_bayX >= 10 and v_maxLength >= 10) or
             (v_bayX >= 10 and v_maxLength = 0) then
            v_bayXLength := 2;
          elsif v_bayX >= 10 and v_maxLength < 10 and v_maxLength <> 0 then
            strOutMsg := 'N|储位设置长度与原有储位长度不符合';
            return;
          else
            v_bayXLength := 1;
          end if;
        end if;
        --拼接储位编码
        v_defcellNo := v_defcellNo || lpad(m.bay_x, v_bayXLength, '0');
      end if;
      --储位层判断，不高于10层
      if m.stock_y > 0 and m.stock_y < 10 then
        v_defcellNo := v_defcellNo || m.stock_y;
      else
        strOutMsg := 'N|层数应该在1到9之间';
        return;
      end if;

      if v_defcellNo <> m.cell_no then
        strOutMsg := 'N|储位编码与设置信息不符合';
        return;
      end if;

      --新增储位
      insert into cdef_defcell
        (warehouse_no,
         ware_no,
         area_no,
         stock_no,
         stock_x,
         bay_x,
         stock_y,
         cell_no,
         mix_flag,
         mix_supplier,
         max_qty,
         max_weight,
         max_volume,
         max_case,
         limit_type,
         limit_rate,
         b_pick,
         cell_status,
         check_status,
         a_flag,
         pick_flag,
         rgst_name,
         rgst_date,
         enterprise_no,
         prefix,
         pick_order)

        select strWareHouseNo,
               m.ware_no,
               m.area_no,
               case
                 when m.stock_no = -1 then
                  '-1'
                 else
                  lpad(m.stock_no, v_stockLength, '0')
               end,
               lpad(to_char(m.stock_x), v_stockXLength, '0'),
               case
                 when m.bay_x = -1 then
                  '1'
                 else
                  lpad(to_char(m.bay_x), v_bayXLength, '0')
               end,
               m.stock_y,
               m.cell_no,
               m.mix_flag,
               m.mix_supplier,
               m.max_qty,
               m.max_weight,
               m.max_volume,
               m.max_case,
               a.limit_type,
               a.limit_rate,
               a.b_pick,
               m.cell_status,
               '0',
               a.a_flag,
               a.pick_flag,
               strUserId,
               sysdate,
               m.enterprise_no,
               m.prefix,
               m.pick_order
          from cdef_defarea a
         where a.enterprise_no = strEnterpriseNo
           and a.warehouse_no = strWarehouseNo
           and a.ware_no = m.ware_no
           and a.area_no = m.area_no;

      --更新临时表数据
      update tmp_formexcel_defcell tfd
         set tfd.status = '13'
       where tfd.enterprise_no = strEnterpriseNo
         and tfd.warehouse_no = strWarehouseNo
         and tfd.ware_no = m.ware_no
         and tfd.area_no = m.area_no
         and tfd.cell_no = m.cell_no
         and tfd.status = '11';

    end loop;
    delete from tmp_formexcel_defcell a
     where a.enterprise_no = strEnterpriseNo
       and a.warehouse_no = strWarehouseNo
       and a.status = '13';
    strOutMsg := 'Y|导入成功';
    /*exception
    when others then
         strOutMsg := 'N|' || SQLERRM ||
         substr(dbms_utility.format_error_backtrace, 1, 256);*/
  end p_insertDefcell;
  /*************************************************************************************************
    创建人：huangcx
    创建时间：2015.10.27
    功能说明：计费项目导入
  **************************************************************************************************/

  procedure P_bill_formulaset(strEnterpriseNo in bill_formulaset_tmp.enterprise_no%type,
                              strWareHouseNo  in bill_formulaset_tmp.warehouse_no%type,
                              strUserId       in bill_formulaset.rgst_name%type,
                              strResult       out varchar2) is
    v_count      number;
    v_count_tmp  number;
    v_count_tmp1 number;

  begin
    strResult := 'Y|[P_idata_import]';
    --临时加的测试
    if strWareHouseNo is null then
      strResult := 'N|[仓别为空，请检查]';
      return;
    end if;
    --临时加的测试
    --查询临时表中有多少条数据
    select count(1)
      into v_count_tmp
      from bill_formulaset_tmp
     where enterprise_no = strEnterpriseNo;

    update bill_formulaset_tmp
       set status = '11'
     where warehouse_no = strWareHouseNo
       and enterprise_no = strEnterpriseNo;

    for m in (select *
                from bill_formulaset_tmp
               where warehouse_no = strWareHouseNo
                 and status = '11'
                 and enterprise_no = strEnterpriseNo) loop
      --检查同一货主项目编码是否重复
      select count(*)
        into v_count
        from (select t.warehouse_no, t.owner_no, t.billing_project
                from bill_formulaset_tmp t
               where t.enterprise_no = m.enterprise_no
                 and t.warehouse_no = m.warehouse_no
                 and t.owner_no = m.owner_no
                 and t.billing_project = m.billing_project);
      if v_count >= 2 then
        strResult := 'N|[(' || m.owner_no || ')货主下项目编号为(' ||
                     m.billing_project || ')的数据重复]';

        update bill_formulaset_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and owner_no = m.owner_no
           and billing_project = m.billing_project
           and status = '11';
        return;
      end if;

      --判断货主是否存在
      select count(1)
        into v_count
        from bdef_defowner
       where owner_no = m.owner_no
         and enterprise_no = strEnterpriseNo;
      if v_count = 0 then
        strResult := 'N|[请检查第' || m.Row_Id || '条货主]'; --货主不存在

        update bill_formulaset_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and owner_no = m.owner_no
           and billing_project = m.billing_project
           and row_id = m.row_id
           and status = '11';
        return;
      end if;

      --检查项目编码是否已存在
      select count(1)
        into v_count
        from bill_formulaset
       where billing_project = m.billing_project
         and enterprise_no = strEnterpriseNo
         and owner_no = m.owner_no
         and warehouse_no = strWareHouseNo;
      if v_count > 0 then
        strResult := 'N|[(第' || m.Row_Id || '条项目编码已存在]'; --项目编码已存在

        update bill_formulaset_tmp
           set status = '16'
         where row_id = m.row_id;
        return;
      end if;

      --检查项目类型是否存在
      select count(1)
        into v_count
        from wms_deffieldval t
       where t.table_name = 'BILL_FORMULASET'
         and t.colname = 'BILLING_TYPE'
         and t.value = m.billing_type
         and status = '1';
      if v_count = 0 then
        strResult := 'N|[第' || m.Row_Id || '条计费类型不存在]';

        update bill_formulaset_tmp
           set status = '16'
         where row_id = m.row_id;
        return;
      end if;

      if m.family_no is not null then
        --检查商品群组是否存在
        select count(1)
          into v_count
          from bdef_article_family_m t
         where t.enterprise_no = m.enterprise_no
           and t.owner_no = m.owner_no
           and t.family_no = m.family_no;
        if v_count = 0 then
          strResult := 'N|[第' || m.Row_Id || '条商品群组不存在]';

          update bill_formulaset_tmp
             set status = '16'
           where row_id = m.row_id;
          return;
        end if;
      end if;

      --检查计费方式是否存在
      select count(1)
        into v_count
        from wms_deffieldval t
       where t.table_name = 'BILL_FORMULASET'
         and t.colname = 'BILLING_FLAG'
         and t.value = m.billing_flag
         and status = '1';
      if v_count = 0 then
        strResult := 'N|[第' || m.Row_Id || '条计费方式不存在]';

        update bill_formulaset_tmp
           set status = '16'
         where row_id = m.row_id;
        return;
      end if;

      --检查计费单位是否存在
      select count(1)
        into v_count
        from wms_deffieldval t
       where t.table_name = 'BILL_FORMULASET'
         and t.colname = 'BILLING_UNIT'
         and t.value = m.billing_unit
         and status = '1';
      if v_count = 0 then
        strResult := 'N|[第' || m.Row_Id || '条计费单位不存在]';

        update bill_formulaset_tmp
           set status = '16'
         where row_id = m.row_id;
        return;
      end if;
      --动态费用检查取值方式是否存在
      if m.billing_flag = '2' then
        select count(1)
          into v_count
          from WMS_Billing_RULE t
         where t.enterprise_no = m.enterprise_no
           and t.billing_type = m.billing_type
           and t.billing_unit = m.billing_unit
           and t.rule_id = m.billing_flag;
        if v_count = 0 then
          strResult := 'N|[第' || m.Row_Id || '条取值方式不存在]';

          update bill_formulaset_tmp
             set status = '16'
           where row_id = m.row_id;
          return;
        end if;
      end if;

      --检查计费周期是否存在
      select count(1)
        into v_count
        from wms_deffieldval t
       where t.table_name = 'BILL_FORMULASET'
         and t.colname = 'BILLING_CYCLE'
         and t.value = m.billing_cycle
         and status = '1';
      if v_count = 0 then
        strResult := 'N|[第' || m.Row_Id || '条计费周期不存在]';

        update bill_formulaset_tmp
           set status = '16'
         where row_id = m.row_id;
        return;
      end if;

      --检查附加条件是否存在
      select count(1)
        into v_count
        from wms_deffieldval t
       where t.table_name = 'BILL_FORMULASET'
         and t.colname = 'APPEND_CONDITION'
         and t.value = m.append_condition
         and status = '1';
      if v_count = 0 then
        strResult := 'N|[第' || m.Row_Id || '条附加条件不存在]';

        update bill_formulaset_tmp
           set status = '16'
         where row_id = m.row_id;
        return;
      end if;
      --检查附加值1是否为空
      if m.append_condition in ('1', '2') then
        select count(1)
          into v_count
          from bill_formulaset_tmp t
         where t.enterprise_no = strEnterpriseNo
           and t.warehouse_no = strWareHouseNo
           and t.billing_project = m.billing_project
           and m.append_value1 = 0;
        if v_count > 0 then
          strResult := 'N|[第' || m.Row_Id || '条"附加值1"不能为空或者0]';

          update bill_formulaset_tmp
             set status = '16'
           where row_id = m.row_id;
          return;
        end if;
      end if;
      --检查附加值1、附加值2是否为空
      if m.append_condition in ('3') then
        select count(1)
          into v_count
          from bill_formulaset_tmp t
         where t.enterprise_no = strEnterpriseNo
           and t.warehouse_no = strWareHouseNo
           and t.billing_project = m.billing_project
           and t.append_value1 <= 0
           and t.append_value2 <= 0;
        if v_count = 0 then
          strResult := 'N|[第' || m.Row_Id || '条"附加值1"和"附加值2"都不能为空或者小于等于0]';

          update bill_formulaset_tmp
             set status = '16'
           where row_id = m.row_id;
          return;
        end if;
      end if;
      --计费周期为‘周’时检查结算时间是否存在
      if m.billing_cycle in ('2') then
        select count(1)
          into v_count
          from wms_deffieldval t
         where t.table_name = 'BILL_FORMULASET'
           and t.colname = 'BALANCE_DAY'
           and t.value = m.balance_day
           and status = '1';
        if v_count = 0 then
          strResult := 'N|[第' || m.Row_Id || '条结算时间不存在]';

          update bill_formulaset_tmp
             set status = '16'
           where row_id = m.row_id;
          return;
        end if;
      end if;
      --计费周期为‘月’时检查结算时间是否小于‘31’
      if m.billing_cycle in ('3') then
        if m.balance_day > '31' then
          strResult := 'N|[第' || m.Row_Id || '条结算时间不能大于31]';

          update bill_formulaset_tmp
             set status = '16'
           where row_id = m.row_id;
          return;
        end if;
      end if;
      --检查截止日期是否小于当天
      if m.end_date < sysdate then
        strResult := 'N|[第' || m.Row_Id || '条截止日期小于当天]';

        update bill_formulaset_tmp
           set status = '16'
         where row_id = m.row_id;
        return;
      end if;

    end loop;

    --检查临时表中是否所有状态都为11
    select count(1)
      into v_count
      from bill_formulaset_tmp
     where status = '16';
    if v_count > 0 then
      return;
    else
      --更新临时表固定费用计费单位、取值方式为空，默认单价为1
      update bill_formulaset_tmp t
         set t.billing_unit = null, t.value_flag = null, t.unit_price = 1
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.status = '11'
         and t.billing_flag = '1';
      --更新临时表动态费用固定值为空
      update bill_formulaset_tmp t
         set t.fixed_value = null
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.status = '11'
         and t.billing_flag = '2';
      --更新临时表附加条件为‘0’，‘值1’、‘值2’为0
      update bill_formulaset_tmp t
         set t.append_value1 = 0, t.append_value2 = 0
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.status = '11'
         and t.append_condition = '0';
      --更新临时表附加条件为'1'或'2'时,附加值2为‘0’
      update bill_formulaset_tmp t
         set t.append_value2 = 0
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.status = '11'
         and t.append_condition in ('1', '2');
      --更新临时表计费周期为‘天’时,结算时间为空
      update bill_formulaset_tmp t
         set t.balance_day = null
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.status = '11'
         and t.billing_cycle in ('1');

      --插入计费项目表
      insert into bill_formulaset
        (enterprise_no,
         warehouse_no,
         owner_no,
         billing_project,
         project_name,
         billing_type,
         billing_cycle,
         billing_flag,
         billing_unit,
         unit_price,
         fixed_value,
         value_flag,
         append_condition,
         append_value1,
         append_value2,
         remark,
         status,
         end_date,
         balance_day,
         rgst_name,
         rgst_date)
        select enterprise_no,
               warehouse_no,
               owner_no,
               billing_project,
               project_name,
               billing_type,
               billing_cycle,
               billing_flag,
               billing_unit,
               unit_price,
               fixed_value,
               value_flag,
               append_condition,
               append_value1,
               append_value2,
               remark,
               '0',
               end_date,
               balance_day,
               strUserId,
               sysdate
          from bill_formulaset_tmp iit
         where iit.enterprise_no = strEnterpriseNo
           and iit.status = '11';

      if sql%rowcount <= 0 then
        strResult := 'N|[新增计费项目失败]'; --新增计费项目失败

      end if;
      select count(*)
        into v_count
        from bill_formulaset_tmp t
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.status = '11'
         and t.family_no is not null;
      if v_count > 0 then
        --
        insert into bill_Family_Unit_Price
          (enterprise_no,
           warehouse_no,
           owner_no,
           family_no,
           billing_project,
           billing_unit,
           unit_price,
           append_condition,
           append_value1,
           append_value2,
           rgst_name,
           rgst_date)
          select enterprise_no,
                 warehouse_no,
                 owner_no,
                 family_no,
                 billing_project,
                 billing_unit,
                 unit_price,
                 append_condition,
                 append_value1,
                 append_value2,
                 strUserId,
                 sysdate
            from bill_formulaset_tmp iit
           where iit.enterprise_no = strEnterpriseNo
             and iit.warehouse_no = strWareHouseNo
             and iit.status = '11'
             and iit.family_no is not null;
      end if;

      --导入成功，修改临时表状态为13（成功）
      update bill_formulaset_tmp
         set status = '13'
       where enterprise_no = strEnterpriseNo
         and warehouse_no = strWareHouseNo
         and status = '11';

    end if;

    delete from bill_formulaset_tmp
     where warehouse_no = strWareHouseNo
       and status = '13'
       and enterprise_no = strEnterpriseNo;

    --查询导入成功多少条记录
    select count(1)
      into v_count_tmp1
      from bill_formulaset_tmp
     where enterprise_no = strEnterpriseNo;
    v_count := v_count_tmp - v_count_tmp1;

    strResult := 'Y|成功导入' || v_count || '条数据]';
  end P_bill_formulaset;
  /**********************************************************************************************************
   hkl
  2016.01.29
  功能：判断该货主的进货单是否能自动生成包装
  ***********************************************************************************************************/

  procedure P_idata_import_article(strEnterpriseNo in idata_import_m.enterprise_no%type,
                                   strWareHouseNo  in idata_import_m.warehouse_no%type,
                                   strOwnerNo      in idata_import_m.owner_no%type,
                                   strArticleNo    in idata_import_d.article_no%type,
                                   strPackingQty   in idata_import_d.packing_qty%type,
                                   strUserId       in bill_formulaset.rgst_name%type,
                                   strResult       out varchar2) is
    v_rsv_var1 bdef_defowner.rsv_var1%type;
  begin

    strResult := '[P_idata_import_article]';

    --取货主表里面的是否能自动产生包装的参数（用的预留字段1）
    select t.rsv_var1
      into v_rsv_var1
      from bdef_defowner t
     where t.enterprise_no = strEnterpriseNo
       and t.owner_no = strOwnerNo;
    if v_rsv_var1 = '1' then
      insert into bdef_article_packing
        (article_no,
         packing_qty,
         packing_unit,
         spec,
         a_length,
         a_width,
         a_height,
         packing_weight,
         sorter_flag,
         create_flag,
         rgst_name,
         rgst_date,
         enterprise_no,
         pal_base_qbox,
         pal_height_qbox,
         qpalette)
      values
        (strArticleNo,
         strPackingQty,
         strPackingQty || '每箱',
         '1*' || strPackingQty,
         0,
         0,
         0,
         0,
         0,
         1,
         strUserId,
         sysdate,
         strEnterpriseNo,
         999,
         999,
         999 * 999 * strPackingQty);
    end if;

    strResult := 'Y';
  end P_idata_import_article;
 /**********************************************************************************************************
   hcx
  2016.07.05
  功能：商品与商品群组关系导入
  ***********************************************************************************************************/
  procedure P_bdef_article_family(
                           strEnterpriseNo  in    idata_import_tmp.enterprise_no%type,
                           strUserId        in    bdef_defworker.worker_no%type,
                           strResult        out   varchar2) is
  v_count          number;
  v_ownerNo        bdef_article_family_tmp.owner_no%type;
  v_familyName     bdef_article_family_tmp.family_name%type;
  v_ownerArticleNo bdef_article_family_tmp.owner_article_no%type;
  begin
    strResult:='Y|[P_bdef_article_family]';
    --锁表
    update bdef_article_family_tmp set status='11' where enterprise_no=strEnterpriseNo;

    --检查同一货主同一商品是否属于多个群组
    select count(*) into v_count from (select owner_no, owner_article_no
               from bdef_article_family_tmp
              where enterprise_no=strEnterpriseNo
                and status='11'
              group by enterprise_no,
                       owner_no,
                       owner_article_no
                       having count(owner_article_no)>1);
    if v_count>0 then
       select owner_no,owner_article_no into v_ownerNo,v_ownerArticleNo from (select owner_no, owner_article_no
               from bdef_article_family_tmp
              where enterprise_no=strEnterpriseNo
                and status='11'
              group by enterprise_no,
                       owner_no,
                       owner_article_no
                       having count(owner_article_no)>1) where rownum=1;
       if v_ownerArticleNo is not null or v_ownerArticleNo<>'' then
          strResult:= 'N|['||v_ownerNo ||'货主' || v_ownerArticleNo || '商品属于不同群组，请检查]';
          return;
       end if;
    end if;
    for m in (select enterprise_no,owner_no,family_no,family_name,use_type
                    from bdef_article_family_tmp
                     where enterprise_no=strEnterpriseNo
                       and status='11'
                group by enterprise_no,
                         owner_no,
                         family_no,
                         family_name,
                         use_type) loop
       --检查同一货主同一商品群组的群组名称、用途是否一样
       select count(*) into v_count
         from(select enterprise_no,owner_no,family_no,family_name,use_type
                    from bdef_article_family_tmp
                     where enterprise_no=strEnterpriseNo
                       and owner_no=m.owner_no
                       and family_no=m.family_no
                       and status='11'
                group by enterprise_no,
                         owner_no,
                         family_no,
                         family_name,
                         use_type);
       if v_count >=2 then
         strResult:= 'N|['||m.owner_no ||'货主商品群组为' || m.family_no || '的群组名称或用途不一致，请检查]';
         return;
       end if;
       --判断货主是否存在
       select count(1) into v_count from bdef_defowner where owner_no=m.owner_no and enterprise_no=strEnterpriseNo;
         if v_count = 0 then
            strResult:= 'N|[请检查' || m.owner_no || '货主不存在]';
            --更新临时表状态
            return;
         end if;

        --检查货主是否有权限
        select count(*) into v_count
          from (select distinct b.owner_no from  bdef_defowner b,bdef_defworker d
                where b.enterprise_no=d.enterprise_no
                  and d.worker_no=strUserId
                  and b.authority_type='1'
                  and b.enterprise_no=strEnterpriseNo
               union
               select distinct b.owner_no from bset_worker_owner b,bdef_defworker d
                where b.enterprise_no=d.enterprise_no
                  and b.worker_no=d.worker_no
                  and b.worker_no=strUserId
                  and b.enterprise_no=strEnterpriseNo) a
         where a.owner_no=m.owner_no;

       if v_count = 0 then
         strResult:='N|[' ||m.owner_no||'货主，用户没有货主权限]';
         return;
       end if;

       for n in(select * from bdef_article_family_tmp where enterprise_no=strEnterpriseNo
             and owner_no=m.owner_no and family_no=m.family_no) loop
           --检查商品是否已维护群组关系
           select count(*) into v_count
             from( select * from bdef_article_family_tmp a
                     where enterprise_no=strEnterpriseNo
                       and owner_no=n.owner_no
                       and owner_article_no=n.owner_article_no
                       and owner_article_no in(
                           select b.owner_article_no
                             from bdef_article_family_d a,bdef_defarticle b
                            where a.enterprise_no=b.enterprise_no
                              and a.owner_no=b.owner_no
                              and a.article_no=b.article_no
                              and a.enterprise_no=strEnterpriseNo
                              and a.owner_no=n.owner_no
                              and a.family_no<>n.family_no));
           if v_count>0 then
              strResult:= 'N|['||n.owner_no ||'货主' || n.owner_article_no || '商品已维护商品群组，请检查]';
              return;
           end if;
           --检查商品是否存在
           select count(*) into v_count
             from bdef_defarticle
             where enterprise_no=strEnterpriseNo
               and owner_no=n.owner_no
               and owner_article_no=n.owner_article_no;
           if v_count=0 then
              strResult:= 'N|['||n.owner_no ||'货主' || n.owner_article_no || '商品不存在，请检查]';
              return;
           end if;
       end loop;

       --检查商品群组是否已存在
       select count(*) into v_count
           from bdef_article_family_m a
                where a.enterprise_no=strEnterpriseNo
                  and a.owner_no=m.owner_no
                  and a.family_no=m.family_no;

       if v_count = 0 then
          select family_name
              into v_familyName
              from bdef_article_family_tmp
             where enterprise_no = m.enterprise_no
               and owner_no = m.owner_no
               and family_no=m.family_no;

           if v_familyName is null or v_familyName='' then
              strResult:= 'N|['||m.owner_no ||'货主' || m.family_no || '群组为新增群组，群组名称不能为空]';
              return;
           end if;

           --写商品群组头档
           insert into bdef_article_family_m(
               enterprise_no,
               owner_no,
               family_no,
               family_name,
               rgst_name,
               rgst_date,
               use_type)
            values(
               strEnterpriseNo,
               m.owner_no,
               m.family_no,
               m.family_name,
               strUserId,
               sysdate,
               m.use_type);
       end if;

       --写商品群组明细
       insert into bdef_article_family_d(
              enterprise_no,
              owner_no,
              family_no,
              article_no,
              rgst_name,
              rgst_date)
       select strEnterpriseNo,
              a.owner_no,
              a.family_no,
              b.article_no,
              strUserId,
              sysdate
         from bdef_article_family_tmp a,bdef_defarticle b
        where a.enterprise_no=b.enterprise_no
          and a.owner_no=b.owner_no
          and a.owner_article_no=b.owner_article_no
          and a.enterprise_no=strEnterpriseNo
          and a.owner_no=m.owner_no
          and a.family_no=m.family_no
          and b.article_no not in(
              select article_no
                from bdef_article_family_d
               where enterprise_no=strEnterpriseNo
                 and owner_no=m.owner_no
                 and family_no=m.family_no);

       --导入成功，修改临时表状态为13（成功）
       update bdef_article_family_tmp set status='13' where enterprise_no=strEnterpriseNo
       and owner_no=m.owner_no and family_no=m.family_no and status='11';
    end loop;

    delete from bdef_article_family_tmp where status='13' and enterprise_no=strEnterpriseNo;

    strResult:='Y|导入成功';

  end P_bdef_article_family;


/**********************************************************************************************************
    czh
    2016.7.26
    功能：集货作业导入
  ***********************************************************************************************************/

  procedure P_odata_package(strEnterpriseNo in odata_package_tmp.enterprise_no%type,
                             strWareHouseNo  in odata_package_tmp.warehouse_no%type,
                             strUserId       in bdef_defworker.worker_no%type,
                             strResult       out varchar2) is
    v_count        number;
    v_count_1      number;
    v_result       varchar2(20);

  begin
    strResult := 'Y|[P_odata_package]';

    --锁表
    update odata_package_tmp
       set status = '11'
     where warehouse_no = strWareHouseNo
       and enterprise_no = strEnterpriseNo;

    for m in (select t.enterprise_no,
                     t.wareHouse_no,
                     t.owner_no,
                     t.po_type,
                     t.po_no,
                     t.sourceexp_no,
                     t.exp_date,
                     t.shipper_no,
                     t.shipper_deliver_no,
                     t.cust_address,
                     t.cust_phone,
                     t.contactor_name,
                     t.send_address,
                     t.send_mobile_phone,
                     t.send_name,
                     t.foreign_express_no,
                     t.large_package_no
                from odata_package_tmp t
               where t.warehouse_no = strWareHouseNo
                 and t.status = '11'
                 and t.enterprise_no = strEnterpriseNo
               group by t.enterprise_no,
                     t.wareHouse_no,
                     t.owner_no,
                     t.po_type,
                     t.po_no,
                     t.sourceexp_no,
                     t.exp_date,
                     t.shipper_no,
                     t.shipper_deliver_no,
                     t.cust_address,
                     t.cust_phone,
                     t.contactor_name,
                     t.send_address,
                     t.send_mobile_phone,
                     t.send_name,
                     t.foreign_express_no,
                     t.large_package_no) loop

      --判断货主是否存在
      select count(1)
        into v_count
        from bdef_defowner
       where owner_no = m.owner_no
         and enterprise_no = strEnterpriseNo;
      if v_count = 0 then
        strResult := 'N|[请检查' || m.owner_no || '货主不存在]'; --货主不存在
        --更新临时表状态
        update odata_package_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and status = '11';
        return;
      end if;

      --检查货主是否有权限
      select count(*)
        into v_count
        from (select distinct b.owner_no
                from bdef_defowner b, bdef_defworker d
               where b.enterprise_no = d.enterprise_no
                 and d.worker_no = strUserId
                 and b.authority_type = '1'
                 and b.enterprise_no = strEnterpriseNo
              union
              select distinct b.owner_no
                from bset_worker_owner b, bdef_defworker d
               where b.enterprise_no = d.enterprise_no
                 and b.worker_no = d.worker_no
                 and b.worker_no = strUserId
                 and b.enterprise_no = strEnterpriseNo) a
       where a.owner_no = m.owner_no;

      if v_count = 0 then
        strResult := 'N|[' || m.owner_no || '货主，用户没有货主权限]';
        return;
      end if;

      --检查同一货主同一提单的订单号、快递单号是否一样
      /*select count(*)
        into v_count
        from (select t.warehouse_no, t.owner_no, t.po_no
                from odata_package_tmp t
               where t.enterprise_no = m.enterprise_no
                 and t.warehouse_no = m.warehouse_no
                 and t.owner_no = m.owner_no
                 and t.po_no = m.po_no
               group by t.warehouse_no,
                        t.owner_no,
                        t.po_no,
                        t.cust_no,
                        t.sourceexp_no,
                        t.shipper_deliver_no);
      if v_count >= 2 then
        strResult := 'N|[单号为' || m.po_no ||
                     '的订单号、快递单号不一样]';
        --更新临时表状态
        update ridata_untread_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and status = '11';
        return;
      end if;*/

      --检查同一货主同一提单的订单号、快递单号是否重复
      select count(*)
        into v_count
        from (select t.warehouse_no, t.owner_no, t.po_no
                from odata_package_tmp t
               where t.enterprise_no = m.enterprise_no
                 and t.warehouse_no = m.warehouse_no
                 and t.owner_no = t.owner_no
                 and t.po_no = m.po_no
               group by t.warehouse_no,
                        t.owner_no,
                        t.po_no,
                        t.po_type,
                        t.sourceexp_no,
                        t.shipper_deliver_no);

      select count(*)
        into v_count_1
        from (select t.warehouse_no, t.owner_no, t.po_no
                from odata_package_m t
               where t.enterprise_no = m.enterprise_no
                 and t.warehouse_no = m.warehouse_no
                 and t.owner_no = t.owner_no
                 and t.po_no = m.po_no);

      if v_count < v_count_1 then
        strResult := 'N|[提单号为' || m.po_no || '的同一货主订单号快递单号有重复数据，请检查]';
        --更新临时表状态
        update odata_package_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and status = '11';
        return;
      end if;

      --检查提单号是否已存在
      /*select count(1)
        into v_count
        from odata_package_m
       where po_no = m.po_no
         and enterprise_no = strEnterpriseNo
         and warehouse_no = strWareHouseNo;
      if v_count > 0 then
        strResult := 'N|[请检查' || m.po_no || '提单号已存在]'; --提单号已存在
        --更新临时表状态
        update odata_package_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and owner_no = m.owner_no
           and status = '11';
        return;
      end if;*/


      --检查货物类型是否存在
      select count(1)
        into v_count
        from wms_deffieldval
       where table_name = 'ODATA_PACKAGE_M'
         and colname = 'PO_TYPE'
         and value = m.po_type
         and status = '1';

      if v_count = 0 then
        strResult := 'N|[' || m.po_type || '货物类型不存在]';
        --更新临时表状态
        update odata_package_tmp
           set status = '16'
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and po_no = m.po_no
           and owner_no = m.owner_no
           and status = '11';
        return;
      end if;

      --判断单号是否已经存在
      select count(1)
        into v_count
        from odata_package_m
       where po_no = m.po_no
         and warehouse_no = strWareHouseNo
         and enterprise_no = strEnterpriseNo;
      if v_count = 0 then

      --插入单头
      insert into odata_package_m
        (enterprise_no,
         warehouse_no,
         owner_no,
         po_no,
         po_type,
         exp_date,
         status,
         remark,
         rgst_name,
         rgst_date)
      values
        (strEnterpriseNo,
         strWareHouseNo,
         m.owner_no,
         m.po_no,
         m.po_type,
         m.exp_date,
         '10',
         '',
         strUserId,
         sysdate);
      if sql%rowcount <= 0 then
        strResult := 'N|[E20501]'; --插入单头失败];
        return;
      end if;
      --插入明细
      insert into odata_package_d (
              enterprise_no,
              warehouse_no,
              owner_no,
              po_no,
              sourceexp_no,
              shipper_deliver_no,
              shipper_no,
              cust_address,
              cust_phone,
              contactor_name,
              send_address,
              send_mobile_phone,
              send_name,
              status,
              rgst_name,
              rgst_date,
              foreign_express_no,
              large_package_no,
              forbid_flag)
       select strEnterpriseNo,
              strWareHouseNo,
              a.owner_no,
              a.po_no,
              a.sourceexp_no,
              a.shipper_deliver_no,
              a.shipper_no,
              a.cust_address,
              a.cust_phone,
              a.contactor_name,
              a.send_address,
              a.send_mobile_phone,
              a.send_name,
              '10',
              strUserId,
              sysdate,
              a.foreign_express_no,
              a.large_package_no,
              '0'
         from odata_package_tmp a
        where a.enterprise_no=strEnterpriseNo
          and a.owner_no=m.owner_no
          and a.po_no=m.po_no;

      if sql%rowcount <= 0 then
        strResult := 'N|[E23211]'; --插入明细失败
      end if;
      end if;



      --导入成功，修改临时表状态为13（成功）
      update odata_package_tmp
         set status = '13'
       where enterprise_no = strEnterpriseNo
         and warehouse_no = strWareHouseNo
         and po_no = m.po_no
         and owner_no = m.owner_no
         and status = '11';
    end loop;

    delete from odata_package_tmp
     where warehouse_no = strWareHouseNo
       and status = '13'
       and enterprise_no = strEnterpriseNo;

    strResult := 'Y|导入成功';

  end P_odata_package;

  /**********************************************************************************************************
     校验商品资料临时表的资料是否正确，
     20160815
     商品导入判断商品小类是否存在  20160919 update by czh
  ***********************************************************************************************************/
  procedure p_Checkarticle(strEnterpriseNo in bdef_article_group.enterprise_no%type,
                           dtOperateDate   in Tmp_FormExcel_ARTICLE_GROUP.Operate_Date%type,
                           strUserId       in bdef_defworker.worker_no%type,
                           strOutMsg       out varchar2) IS
    v_iCOUNT          integer;
    newarticleNO      bdef_defarticle.article_no%type;
    newarticleOwnerNO bdef_defarticle.owner_article_no%type;
    cSheetNo          bdef_defarticle.article_no%type;
  begin
    strOutMsg := 'N|[p_insertdefarticle]';


    for GetArticleInf in (select *  from Tmp_Formexcel_Article a
                           where a.enterprise_no = strEnterpriseNo
                             and a.status = '11'
                           order by a.owner_no,a.group_no,a.row_id) loop

      --检查货主是否存在
      select count(*)
        into v_iCount
        from bdef_defowner bdo
       where bdo.owner_no = GetArticleInf.Owner_No
         and bdo.enterprise_no = strEnterpriseNo;
      if v_iCount = 0 then
        strOutMsg := 'N|[第' || GetArticleInf.row_id || '行记录' || GetArticleInf.owner_no || '货主不存在]';
        return;
      end if;

      --检查货主是否有权限
      select count(*)
        into v_icount
        from (select distinct b.owner_no
                from bdef_defowner b, bdef_defworker d
               where b.enterprise_no = d.enterprise_no
                 and d.worker_no = strUserId
                 and b.authority_type = '1'
                 and b.enterprise_no = strEnterpriseNo
              union
              select distinct b.owner_no
                from bset_worker_owner b, bdef_defworker d
               where b.enterprise_no = d.enterprise_no
                 and b.worker_no = d.worker_no
                 and b.worker_no = strUserId
                 and b.enterprise_no = strEnterpriseNo) a
       where a.owner_no = GetArticleInf.owner_no;

      if v_icount = 0 then
        strOutMsg := 'N|[该用户没有' || GetArticleInf.owner_no || '货主权限]';
        return;
      end if;

      -- 检查该商品对应的类别是否存在
      select count(*)
        into v_iCOUNT
        from bdef_article_group
       where owner_no = GetArticleInf.Owner_No
         and group_no = GetArticleInf.group_no
         and enterprise_no = strEnterpriseNo
         and group_level='0';--add by czh 20160919

      if v_iCOUNT = 0 THEN
        strOutMsg := 'N|[第' || GetArticleInf.row_id || '行记录'|| GetArticleInf.group_no || '小类编码不存在]';
        return;
      end if;

      --检查供应商是否存在
      if GetArticleInf.Supplier_No is not null THEN
        select count(*)
          into v_iCOUNT
          from bdef_defsupplier
         where owner_no = GetArticleInf.Owner_No
           and Supplier_No = GetArticleInf.Supplier_No
           and enterprise_no = strEnterpriseNo;
        if v_iCOUNT = 0 then
          strOutMsg := 'N|[第' || GetArticleInf.row_id || '行记录'|| GetArticleInf.Supplier_No || '供应商编码不存在]';
          return;
        end if;

      end if;

      --Owner_Article_No不为空修改，修改不到新增
      if GetArticleInf.Owner_Article_No is not null then
         --校验商品是否重复,首先判断临时表的数据是否重复
         select count(*) into v_iCount from Tmp_Formexcel_Article
         where enterprise_no=strEnterpriseNo and owner_no=GetArticleInf.owner_no
         and owner_article_no=GetArticleInf.owner_article_no;

         if v_iCOUNT>1 then
            strOutMsg := 'N|[第' || GetArticleInf.row_id || '行记录'|| GetArticleInf.owner_article_no || '商品重复]';
            return;
         end if;
      end if;

    end loop;

    strOutMsg := 'Y|';
  END p_Checkarticle;

   /****************************************************************************************************
     2016.12.22
     将Excel数据导入出货订单
     JCL
  ******************************************************************************************************/
  PROCEDURE P_CREATE_STOCK(strEnterpriseNo in stock_plan_m.enterprise_no%type,
                                              strWareHouseNo  in stock_plan_m.warehouse_no%type,
                                              strUserId       in bdef_defworker.worker_no%type,
                                              strOutMsg       out varchar2) IS
  n_count           number(10);
  n_RowID           number(15);
  v_strOwnerNo      stock_content.owner_no%type;
  v_strCheckNo      fcdata_check_m.check_no%type;
  v_strOwnerArticle bdef_defarticle.owner_article_no%type;
  v_strCellNo       cdef_defcell.cell_no%type;
  v_strPlanNo       fcdata_plan_m.plan_no%type;
  n_BeginQty        stock_content.qty%type;
  n_EndQty          stock_content.qty%type;

BEGIN
  strOutMsg    := 'N|[P_CREATE_STOCK]!';
  n_count      := 0;
  n_RowID      := 0;
  v_strOwnerNo := 'N';

  --根据到期日刷生产日期
  update CREATE_STOCK_TMP t
     set t.produce_date =
         (select t.expire_date - a.expiry_days
            from bdef_defarticle a
           where t.owner_article_no = a.owner_article_no
             and a.expiry_days > 0)
   where t.produce_date is null
     and t.expire_date is not NULL;
     --and t.expire_date <> '0';

  --根据生产日期刷到期日
  update CREATE_STOCK_TMP t
     set t.expire_date =
         (select t.produce_date + a.expiry_days
            from bdef_defarticle a
           where t.owner_article_no = a.owner_article_no
             and a.expiry_days > 0)
   where t.produce_date is not null
     and t.expire_date is NULL;
     --and t.produce_date <> '0';

  --为空生产日期默认今天
  update CREATE_STOCK_TMP t
     set t.produce_date = trunc(sysdate)
   where t.produce_date is null;
  update CREATE_STOCK_TMP t
     set t.expire_date = trunc(sysdate)
   where t.expire_date is null;

  --库存委托业主和商品委托业主不一致
  v_strOwnerArticle := 'N';
  BEGIN
  select t.owner_article_no
    into v_strOwnerArticle
    from CREATE_STOCK_TMP t
    left join bdef_defarticle b
      on t.owner_article_no = b.owner_article_no
   where t.owner_no <> b.owner_no
     and rownum = 1;

  if v_strOwnerArticle <> 'N' then
    strOutMsg := 'N|商品[' || v_strOwnerArticle || ']货主和WMS商品货主不一致';
    return;
  end if;
  EXCEPTION
     when no_data_found THEN
       NULL;
    end;

  --包装品质不能为空
  update CREATE_STOCK_TMP set packing_qty = 1 where packing_qty is null;
  update CREATE_STOCK_TMP set quality = '0' where quality is null;

  --商品不存在
  v_strOwnerArticle := 'N';
  BEGIN
  select t.owner_article_no
    into v_strOwnerArticle
    from CREATE_STOCK_TMP t
   where not exists (select 'x'
            from bdef_defarticle b
           where t.owner_article_no = b.owner_article_no)
     and rownum = 1;
  if v_strOwnerArticle <> 'N' then
    strOutMsg := 'N|商品[' || v_strOwnerArticle || ']不存在商品资料';
    return;
  end if;
  EXCEPTION
   when no_data_found THEN
     NULL;
  end;

  --检查是否有未维护的货位
  BEGIN
  select a.cell_no
    into v_strCellNo
    from CREATE_STOCK_TMP a
   where not exists
   (select 1 from cdef_defcell c where c.cell_no = a.cell_no)
     and rownum = 1;

  if v_strCellNo <> 'N' then
    strOutMsg := 'N|货位[' || v_strCellNo || ']资料不存在';
    return;
  end if;
   EXCEPTION
   when no_data_found THEN
     NULL;
  end;

  --获取盘点计划单号
  pklg_wms_base.p_getsheetno(strEnterpriseNo,
                             strWareHouseNo,
                             'CP',
                             v_strPlanNo,
                             strOutMsg);

  for t in (select a.cell_no,
                   a.owner_article_no,
                   a.packing_qty,
                   b.EXPIRY_DAYS,
                   a.produce_date,
                   a.expire_date,
                   a.article_qty,
                   a.owner_no,
                   b.article_no,
                   b.BARCODE
              from CREATE_STOCK_TMP a, v_bdef_defarticle b
             where a.owner_no = b.owner_no
               and a.owner_article_no = b.owner_article_no
             order by a.owner_no, a.cell_no) loop

    n_count := 0;
    n_RowID := n_RowID + 1;

    if t.owner_no <> v_strOwnerNo then

      pklg_wms_base.p_getsheetno(strEnterpriseNo,
                                 strWareHouseNo,
                                 'CH',
                                 v_strCheckNo,
                                 strOutMsg);

      --盘点头档
      insert into fcdata_check_m
        (enterprise_no,
         warehouse_no,
         owner_no,
         plan_no,
         request_no,
         check_no,
         check_date,
         request_date,
         assign_no,
         real_no,
         status,
         serial_no,
         fcdata_type,
         check_type,
         rgst_name,
         rgst_date)
      values
        (strEnterpriseNo,
         strWareHouseNo,
         t.owner_no,
         v_strPlanNo,
         v_strCheckNo,
         v_strCheckNo,
         trunc(sysdate),
         trunc(sysdate),
         strUserId,
         strUserId,
         '13',
         '0',
         1,
         1,
         strUserId,
         sysdate);

    end if;

    v_strOwnerNo := t.owner_no;

    insert into fcdata_check_d
      (enterprise_no,
       warehouse_no,
       owner_no,
       check_no,
       row_id,
       cell_no,
       article_no,
       order_id,
       sub_order_id,
       barcode,
       packing_qty,
       produce_date,
       expire_date,
       quality,
       lot_no,
       article_qty,
       check_qty,
       real_qty,
       status,
       check_type,
       check_worker,
       check_date,
       different_flag)
    values
      (strEnterpriseNo,
       strWareHouseNo,
       v_strOwnerNo,
       v_strCheckNo,
       n_RowID,
       t.cell_no,
       t.article_no,
       n_RowID,
       n_RowID,
       t.barcode,
       t.packing_qty,
       case when t.expiry_days > 0 then t.produce_date else
       trunc(to_date('19000101', 'yyyymmdd')) end,
       case when t.expiry_days > 0 then t.expire_date else
       trunc(to_date('19000101', 'yyyymmdd')) end,
       '0',
       'N',
       0,
       t.article_qty,
       t.article_qty,
       '13',
       '1',
       strUserId,
       sysdate,
       '1');
  end loop;

  for a in (select owner_no, CHECK_NO
              from fcdata_check_m
             where enterprise_no = strEnterpriseNo
               and warehouse_no = strWareHouseNo
               and plan_no = v_strPlanNo) loop

    --根据盘点单写库存
    Pkobj_Stock.P_fcdata_insetStock(strEnterpriseNo,
                                    strWareHouseNo,
                                    a.owner_no,
                                    A.CHECK_NO,
                                    strUserId,
                                    n_count,
                                    strOutMsg);
    if substr(strOutMsg, 1, 1) = 'N' then
      return;
    end if;

  end loop;

  --写库存日结表
  insert into stock_content_rj
    (enterprise_no,
     warehouse_no,
     owner_no,
     dept_no,
     article_no,
     jc_date,
     qc_qty,
     qty,
     out_qty,
     in_qty,
     rgst_name,
     rgst_date,
     packing_qty,
     import_batch_no)
    select strEnterpriseNo,
           t.warehouse_no,
           t.owner_no,
           'N',
           t.article_no,
           trunc(sysdate),
           0,
           sum(t.real_qty),
           0,
           0,
           strUserId,
           sysdate,
           t.packing_qty,
           t.CHECK_NO
      from fcdata_check_d t, fcdata_check_m fcm
     where t.warehouse_no = strWareHouseNo
       and t.enterprise_no = fcm.enterprise_no
       and t.check_no = fcm.check_no
       and fcm.plan_no = v_strPlanNo
     group by t.enterprise_no,
              t.check_no,
              t.warehouse_no,
              t.owner_no,
              t.article_no,
              t.packing_qty,
              t.CHECK_NO;

  --总库存比对
/*  select a.qty, b.qty
    into n_EndQty, n_BeginQty
    from (select sum(qty) qty from stock_content WHERE owner_no = v_strOwnerNo AND warehouse_no = strWareHouseNo) a,
         (select sum(article_qty) qty from CREATE_STOCK_TMP) b;

  if n_EndQty <> n_BeginQty then
    strOutMsg := 'N|临时表库存[' || n_BeginQty || ']和导入后库存[' || n_EndQty ||
                 ']不一致';
    return;
  end if;*/

  --单品库存对比
  /*for v_GetDiffStock in (select n.owner_article_no, n.import_qty, n.qty
                           from (select a.owner_no,
                                        a.owner_article_no,
                                        nvl(a.qty, 0) import_qty,
                                        nvl(b.qty, 0) qty
                                   from (select t.owner_no,
                                                t.owner_article_no,
                                                sum(article_qty) qty
                                           from CREATE_STOCK_TMP t
                                          group by t.owner_no,
                                                   t.owner_article_no) a
                                   left join (select a.owner_no,
                                                    a.owner_article_no,
                                                    sum(qty) qty
                                               from stock_content   c,
                                                    bdef_defarticle a
                                              where c.article_no =
                                                    a.article_no
                                                    AND c.owner_no = v_strOwnerNo
                                                    AND c.warehouse_no = strWareHouseNo
                                              group by a.owner_no,
                                                       a.owner_article_no) b
                                     on a.owner_no = b.owner_no
                                    and a.owner_article_no =
                                        b.owner_article_no) n
                          where n.import_qty <> n.qty) loop
    strOutMsg := 'N|商品[' || v_GetDiffStock.owner_article_no || ']临时表库存[' ||
                 v_GetDiffStock.import_qty || ']和导入后库存[' ||
                 v_GetDiffStock.qty || ']不一致';
    return;
  end loop;*/

  strOutMsg := 'Y|库存导入成功!';
exception
  when others then
    strOutMsg := 'N|' || SQLERRM || n_RowID ||
                 substr(dbms_utility.format_error_backtrace, 1, 256);
END P_CREATE_STOCK;

end pkobj_Create_base;
/

