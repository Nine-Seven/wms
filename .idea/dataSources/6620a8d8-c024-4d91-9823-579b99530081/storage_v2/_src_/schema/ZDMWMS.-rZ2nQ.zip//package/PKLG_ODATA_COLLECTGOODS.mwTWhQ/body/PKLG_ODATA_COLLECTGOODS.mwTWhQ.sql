create package body        PKLG_ODATA_COLLECTGOODS is

    /*****************************************************************************************
     功能：集货作业（入库，出库）扫描PONO
     ADD BY SUNL 20160715
  *****************************************************************************************/
  PROCEDURE P_COLLECTGOODS_SCANPONO(STRENTERPRISENO IN ODATA_PACKAGE_M.ENTERPRISE_NO%TYPE, --企业
                                    STRWAREHOUSENO  IN ODATA_PACKAGE_M.WAREHOUSE_NO%TYPE, --仓别
                                    STRPONO         IN ODATA_PACKAGE_M.PO_NO%TYPE, --提单号
                                    STRTYPE         IN VARCHAR2, --类型: 1，入库；2：出库
                                    STROWNERNO      OUT ODATA_PACKAGE_M.OWNER_NO%TYPE, --货主(RF上获取不到！)
                                    STRRESULT       OUT VARCHAR2) IS
    NUM_RECORDCOUNT NUMBER; --当前记录数
  BEGIN
    STRRESULT := 'N|P_COLLECTGOODS_SCANPONO';
    --校验提单号是否存在
    NUM_RECORDCOUNT := 0;
    SELECT COUNT(0)
      INTO NUM_RECORDCOUNT
      FROM ODATA_PACKAGE_M M
     WHERE M.ENTERPRISE_NO = STRENTERPRISENO
       AND M.WAREHOUSE_NO = STRWAREHOUSENO
          --AND M.OWNER_NO = STROWNERNO
       AND M.PO_NO = STRPONO;
    IF (NUM_RECORDCOUNT = 0) THEN
      STRRESULT := 'N|当前提货单号' || STRPONO || '无效！';
      RETURN;
    END IF;
    --校验提单号是否已出库完成
    NUM_RECORDCOUNT := 0;
    IF (STRTYPE = '1') THEN
      SELECT COUNT(0)
        INTO NUM_RECORDCOUNT
        FROM ODATA_PACKAGE_M M
       WHERE M.ENTERPRISE_NO = STRENTERPRISENO
         AND M.WAREHOUSE_NO = STRWAREHOUSENO
            --AND M.OWNER_NO = STROWNERNO
         AND M.PO_NO = STRPONO
         AND M.STATUS IN ('10', '12'); --入库时，状态10和12均有效
      IF (NUM_RECORDCOUNT = 0) THEN
        STRRESULT := 'N|当前提货单号' || STRPONO || '已出库完成，不能做入库操作！';
        RETURN;
      END IF;
    ELSE
      SELECT COUNT(0)
        INTO NUM_RECORDCOUNT
        FROM ODATA_PACKAGE_M M
       WHERE M.ENTERPRISE_NO = STRENTERPRISENO
         AND M.WAREHOUSE_NO = STRWAREHOUSENO
            --AND M.OWNER_NO = STROWNERNO
         AND M.PO_NO = STRPONO
         AND M.STATUS IN ('12'); --出库时，只有12状态有效
      IF (NUM_RECORDCOUNT = 0) THEN
        STRRESULT := 'N|当前提货单号' || STRPONO || '不在验收中，不能出库！';
        RETURN;
      END IF;
    END IF;

    --获取头档对应的货主
    SELECT m.owner_no
      INTO STROWNERNO
      FROM ODATA_PACKAGE_M M
     WHERE M.ENTERPRISE_NO = STRENTERPRISENO
       AND M.WAREHOUSE_NO = STRWAREHOUSENO
       AND M.PO_NO = STRPONO;

    STRRESULT := 'Y|P_COLLECTGOODS_SCANPONO';
  EXCEPTION
    WHEN OTHERS THEN
      STRRESULT := 'N|' || SQLERRM ||
                   SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
  END P_COLLECTGOODS_SCANPONO;

  /*****************************************************************************************
     功能：集货作业（入库，出库）扫描 SOURCEEXPNO
     ADD BY SUNL 20160715
  *****************************************************************************************/
  PROCEDURE P_COLLECTGOODS_SCANSOURCEEXPNO(STRENTERPRISENO IN ODATA_PACKAGE_M.ENTERPRISE_NO%TYPE, --企业
                                           STRWAREHOUSENO  IN ODATA_PACKAGE_M.WAREHOUSE_NO%TYPE, --仓别
                                           STROWNERNO      IN ODATA_PACKAGE_M.OWNER_NO%TYPE, --货主
                                           STRPONO         IN ODATA_PACKAGE_M.PO_NO%TYPE, --提单号
                                           STRSOURCEEXPNO  IN ODATA_PACKAGE_D.SOURCEEXP_NO%TYPE, --订单号
                                           STRUpdt_Name    IN ODATA_PACKAGE_D.Updt_Name%TYPE, --操作人
                                           STRTYPE         IN VARCHAR2, --类型: 1，入库；2：出库
                                           STRRESULT       OUT VARCHAR2) IS
    NUM_RECORDCOUNT NUMBER; --当前记录数
    STR_STATUS      ODATA_PACKAGE_D.STATUS%TYPE; --状态
    str_ownerNO     ODATA_PACKAGE_M.OWNER_NO%TYPE;
  BEGIN
    STRRESULT := 'N|P_COLLECTGOODS_SCANSOURCEEXPNO';
    --校验提单号
    P_COLLECTGOODS_SCANPONO(STRENTERPRISENO,
                            STRWAREHOUSENO,
                            STRPONO,
                            STRTYPE,
                            str_ownerNO,
                            STRRESULT);
    IF SUBSTR(STRRESULT, 1, 1) <> 'Y' THEN
      RETURN;
    END IF;

    IF (STROWNERNO <> str_ownerNO) THEN
      STRRESULT := 'N|当前提货单号(' || STRPONO || ')下订单号(' || STRSOURCEEXPNO ||
                   ')数据异常！';
      RETURN;
    END IF;

    --校验订单号
    NUM_RECORDCOUNT := 0;
    SELECT COUNT(0)
      INTO NUM_RECORDCOUNT
      FROM ODATA_PACKAGE_D D
     WHERE D.ENTERPRISE_NO = STRENTERPRISENO
       AND D.WAREHOUSE_NO = STRWAREHOUSENO
       AND D.OWNER_NO = STROWNERNO
       AND D.PO_NO = STRPONO
       AND D.SOURCEEXP_NO = STRSOURCEEXPNO;
    IF (NUM_RECORDCOUNT = 0) THEN
      STRRESULT := 'N|当前提货单号(' || STRPONO || ')下不存在订单号(' || STRSOURCEEXPNO || ')';
      RETURN;
    END IF;

    STR_STATUS := '';
    SELECT D.STATUS
      INTO STR_STATUS
      FROM ODATA_PACKAGE_D D
     WHERE D.ENTERPRISE_NO = STRENTERPRISENO
       AND D.WAREHOUSE_NO = STRWAREHOUSENO
       AND D.OWNER_NO = STROWNERNO
       AND D.PO_NO = STRPONO
       AND D.SOURCEEXP_NO = STRSOURCEEXPNO;

    IF (STRTYPE = '1') THEN
      IF (STR_STATUS = '13') THEN
        STRRESULT := 'N|当前提货单号(' || STRPONO || ')下订单(' || STRSOURCEEXPNO ||
                     ')已出库完成，不能做入库操作！';
        RETURN;
      END IF;
      IF (STR_STATUS = '12') THEN
        STRRESULT := 'N|当前提货单号(' || STRPONO || ')下订单(' || STRSOURCEEXPNO ||
                     ')已入库，不能做入库操作！';
        RETURN;
      END IF;

      --这里表示状态是10，可以做入库操作
      IF (STR_STATUS = '10') THEN
        UPDATE ODATA_PACKAGE_D D
           SET D.STATUS       = '12',
               d.updt_date    = SYSDATE,
               d.updt_name    = STRUpdt_Name,
               d.instock_date = SYSDATE,
               d.instock_name = STRUpdt_Name
         WHERE D.ENTERPRISE_NO = STRENTERPRISENO
           AND D.WAREHOUSE_NO = STRWAREHOUSENO
           AND D.OWNER_NO = STROWNERNO
           AND D.PO_NO = STRPONO
           AND D.SOURCEEXP_NO = STRSOURCEEXPNO
           AND D.STATUS = '10';
        IF (SQL%ROWCOUNT <> 1) THEN
          STRRESULT := 'N|数据异常！当前提货单号(' || STRPONO || ')下订单(' ||
                       STRSOURCEEXPNO || ')入库失败！';
          RETURN;
        END IF;
        --这里更新头档状态为12 (只要一个订单做了入库，头档状态都要更新成12)
        UPDATE ODATA_PACKAGE_M M
           SET M.STATUS    = '12',
               m.updt_date = SYSDATE,
               m.updt_name = STRUpdt_Name
         WHERE M.ENTERPRISE_NO = STRENTERPRISENO
           AND M.WAREHOUSE_NO = STRWAREHOUSENO
           AND M.OWNER_NO = STROWNERNO
           AND M.PO_NO = STRPONO;
      END IF;
    ELSE
      IF (STR_STATUS = '13') THEN
        STRRESULT := 'N|当前提货单号(' || STRPONO || ')下订单(' || STRSOURCEEXPNO ||
                     ')已出库完成，不能做出库操作！';
        RETURN;
      END IF;
      IF (STR_STATUS = '10') THEN
        STRRESULT := 'N|当前提货单号(' || STRPONO || ')下订单(' || STRSOURCEEXPNO ||
                     ')未入库，不能做出库操作！';
        RETURN;
      END IF;

      --这里表示状态是12，可以做出库操作
      IF (STR_STATUS = '12') THEN
        UPDATE ODATA_PACKAGE_D D
           SET D.STATUS        = '13',
               d.updt_date     = SYSDATE,
               d.updt_name     = STRUpdt_Name,
               d.outstock_date = SYSDATE,
               d.outstock_name = STRUpdt_Name
         WHERE D.ENTERPRISE_NO = STRENTERPRISENO
           AND D.WAREHOUSE_NO = STRWAREHOUSENO
           AND D.OWNER_NO = STROWNERNO
           AND D.PO_NO = STRPONO
           AND D.SOURCEEXP_NO = STRSOURCEEXPNO
           AND D.STATUS = '12';
        IF (SQL%ROWCOUNT <> 1) THEN
          STRRESULT := 'N|数据异常！当前提货单号(' || STRPONO || ')下订单(' ||
                       STRSOURCEEXPNO || ')出库失败！';
          RETURN;
        END IF;

        --这里更新头档状态为13 (需要判断当前提货单下所有订单是否都已经出货完成)
        NUM_RECORDCOUNT := 0;
        SELECT COUNT(0)
          INTO NUM_RECORDCOUNT
          FROM ODATA_PACKAGE_D D
         WHERE D.ENTERPRISE_NO = STRENTERPRISENO
           AND D.WAREHOUSE_NO = STRWAREHOUSENO
           AND D.OWNER_NO = STROWNERNO
           AND D.PO_NO = STRPONO
           AND D.STATUS <> '13';
        IF (NUM_RECORDCOUNT = 0) THEN
          --如果所有订单都已出货完成，则更新头档状态
          UPDATE ODATA_PACKAGE_M M
             SET M.STATUS    = '13',
                 m.updt_date = SYSDATE,
                 m.updt_name = STRUpdt_Name
           WHERE M.ENTERPRISE_NO = STRENTERPRISENO
             AND M.WAREHOUSE_NO = STRWAREHOUSENO
             AND M.OWNER_NO = STROWNERNO
             AND M.PO_NO = STRPONO;
        END IF;

      END IF;
    END IF;

    STRRESULT := 'Y|P_COLLECTGOODS_SCANSOURCEEXPNO';
  EXCEPTION
    WHEN OTHERS THEN
      STRRESULT := 'N|' || SQLERRM ||
                   SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
  END P_COLLECTGOODS_SCANSOURCEEXPNO;

  /*****************************************************************************************
     功能：集货作业（入库，出库）整单确认 CONFIRMPONO
     ADD BY CZH 20160829
  *****************************************************************************************/
  PROCEDURE P_COLLECTGOODS_CONFIRMPONO(STRENTERPRISENO IN ODATA_PACKAGE_M.ENTERPRISE_NO%TYPE, --企业
                                           STRWAREHOUSENO  IN ODATA_PACKAGE_M.WAREHOUSE_NO%TYPE, --仓别
                                           STROWNERNO      IN ODATA_PACKAGE_M.OWNER_NO%TYPE, --货主
                                           STRPONO         IN ODATA_PACKAGE_M.PO_NO%TYPE, --提单号
                                           STRUpdt_Name    IN ODATA_PACKAGE_D.Updt_Name%TYPE, --操作人
                                           STRTYPE         IN VARCHAR2, --类型: 1，入库；2：出库
                                           STRRESULT       OUT VARCHAR2) IS
  BEGIN
    STRRESULT := 'N|P_COLLECTGOODS_CONFIRMPONO';
    for curSourceExpNo in (
      select D.* from ODATA_PACKAGE_D D
      where D.Enterprise_No = STRENTERPRISENO
      and D.Warehouse_No = STRWAREHOUSENO
      and D.OWNER_NO = STROWNERNO
      and D.PO_NO = STRPONO
      and D.Status <> '13') loop
      P_COLLECTGOODS_SCANSOURCEEXPNO(STRENTERPRISENO,
                                     STRWAREHOUSENO,
                                     STROWNERNO,
                                     STRPONO,
                                     curSourceExpNo.Sourceexp_No,
                                     STRUpdt_Name,
                                     STRTYPE,
                                     STRRESULT);
      IF SUBSTR(STRRESULT, 1, 1) <> 'Y' THEN
      RETURN;
      END IF;
    END loop;
    STRRESULT := 'Y|P_COLLECTGOODS_CONFIRMPONO';

  END P_COLLECTGOODS_CONFIRMPONO;


end PKLG_ODATA_COLLECTGOODS;

/

