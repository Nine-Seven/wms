create view V_BYMOUTLIST as
select to_date(to_char(m.updt_date,'yyyy-MM-dd'),'yyyy-MM-dd') updt_data,iim.sourceexp_no,atc.owner_article_no,atc.article_name,
d.packing_qty,atcp.packing_unit,to_char(d.produce_date,'yyyyMMdd') produce_date,
 sum(d.qty) NRM,0.00 as DM,0.00 as NR,0.00 QA,sum(d.qty) sumQty
 from odata_deliver_d m,odata_deliver_d d,odata_exp_m iim,bdef_defarticle atc,bdef_article_packing atcp
 where m.warehouse_no = d.warehouse_no
   and m.deliver_no = d.deliver_no
   and m.warehouse_no = iim.warehouse_no
   and m.exp_no = iim.exp_no
   and d.owner_no = atc.owner_no
   and d.article_no = atc.article_no
   and atc.article_no = atcp.article_no
   and d.packing_qty = atcp.packing_qty
   and m.warehouse_no in ('001','003')
   and m.owner_no = '001'
   and m.status = '13'
   group by to_date(to_char(m.updt_date,'yyyy-MM-dd'),'yyyy-MM-dd'),iim.sourceexp_no,atc.owner_article_no,
   atc.article_name,d.packing_qty,atcp.packing_unit,to_char(d.produce_date,'yyyyMMdd')
 union all
 select to_date(to_char(rcm.updt_date,'yyyy-MM-dd'),'yyyy-MM-dd') updt_date,rum.po_no sourceexp_no,
 atc.owner_article_no,atc.article_name,rcd.packing_qty,atcp.packing_unit,
 to_char(rcd.produce_date,'yyyyMMdd') produce_date,sum(rcd.real_qty) NRM,0.00 as DM,0.00 as NR,0.00 QA,sum(rcd.real_qty) sumQty
 from rodata_deliver_m rcm,rodata_deliver_d rcd,rodata_recede_m rum,bdef_defarticle atc,bdef_article_packing atcp
 where rcm.warehouse_no = rcd.warehouse_no
   and rcm.deliver_no = rcd.deliver_no
   and rcd.recede_no = rum.recede_no
   and rcd.warehouse_no = rum.warehouse_no
   and rcd.owner_no = atc.owner_no
   and rcd.article_no = atc.article_no
   and atc.article_no = atcp.article_no
   and rcd.packing_qty = atcp.packing_qty
   and rcm.owner_no = '001'
   and rcm.warehouse_no in ('001','003')
   and rcm.status =13
   group by to_date(to_char(rcm.updt_date,'yyyy-MM-dd'),'yyyy-MM-dd'),rum.po_no,atc.owner_article_no,
   atc.article_name,rcd.packing_qty,atcp.packing_unit,to_char(rcd.produce_date,'yyyyMMdd')

/

