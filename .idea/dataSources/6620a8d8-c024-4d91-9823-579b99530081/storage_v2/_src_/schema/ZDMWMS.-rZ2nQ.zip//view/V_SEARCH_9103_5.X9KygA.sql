create view V_SEARCH_9103_5 as
select b.enterprise_no,
       b.WAREHOUSE_NO,
       b.OWNER_NO,
       to_char(a.operate_date, 'yyyy-mm-dd') operate_date,
       a.outstock_no,
       b.cust_no,
       c.cust_name,
       b.ASSIGN_NAME,
       d.worker_name,
       a.operate_type,
       a.status,
       f_get_fieldtext('ODATA_OUTSTOCK_M', 'STATUS', a.status) statusText,
       f_get_fieldtext('ODATA_OUTSTOCK_M', 'OUTSTOCK_TYPE', a.outstock_type) outstock_typeText,
       a.outstock_type,
       b.planArticleCount,
       nvl(e.realArticleCount, 0) realArticleCount,
       b.ARTICLE_QTY,
       b.REAL_QTY,
       b.realBox,
       b.realDis,
       b.planBox,
       b.planDis,
       a.rgst_name rgst_no,
       f.worker_name rgst_name,
       a.rgst_date,
       a.updt_date,
       ROUND(TO_NUMBER(a.updt_date - a.rgst_date) * 24) as asf
  from odata_outstock_mhty a
  left join bdef_defworker f
    on a.rgst_name = f.worker_no
    and a.enterprise_no = f.enterprise_no,
 (select a.enterprise_no,
               a.WAREHOUSE_NO,
               a.OWNER_NO,
               a.OUTSTOCK_NO,
               a.CUST_NO,
               count(distinct a.ARTICLE_NO) planArticleCount,
               sum(a.ARTICLE_QTY) ARTICLE_QTY,
               sum(a.REAL_QTY) REAL_QTY,
               sum(trunc(a.REAL_QTY / a.packing_qty)) realBox,
               sum(mod(a.REAL_QTY, a.packing_qty)) realDis,
               sum(trunc(a.article_Qty / a.packing_qty)) planBox,
               sum(mod(a.article_Qty, a.packing_qty)) planDis,
               a.ASSIGN_NAME
          from odata_outstock_dhty a
         group by a.enterprise_no,
                  a.WAREHOUSE_NO,
                  a.OWNER_NO,
                  a.OUTSTOCK_NO,
                  a.CUST_NO,
                  a.ASSIGN_NAME) b
  left join bdef_defworker d
    on b.ASSIGN_NAME = d.worker_no
    and b.enterprise_no = d.enterprise_no
  left join (select a.enterprise_no,
                    a.WAREHOUSE_NO,
                    a.OWNER_NO,
                    a.OUTSTOCK_NO,
                    a.CUST_NO,
                    count(distinct a.ARTICLE_NO) realArticleCount
               from odata_outstock_dhty a
              where a.real_qty > 0
              group by a.enterprise_no,a.WAREHOUSE_NO, a.OWNER_NO, a.OUTSTOCK_NO, a.CUST_NO) e
    on b.outstock_no = e.outstock_no and b.enterprise_no = e.enterprise_no, bdef_defcust c
 where a.outstock_no = b.outstock_no
   and a.enterprise_no = b.enterprise_no
   and a.outstock_type = 0
   and b.cust_no = c.cust_no
   and b.enterprise_no = c.enterprise_no
 order by a.outstock_no


/

