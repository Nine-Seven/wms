create view V_SEARCH_9101_1 as
SELECT vbd.enterprise_no,
       BDO.OWNER_NO,
       BDO.OWNER_NAME,
       BDO.OWNER_ALIAS,
       su.supplier_no,
       su.supplier_name,
       VBD.OWNER_ARTICLE_NO, --货主商品ID
       VBD.ARTICLE_NO, --商品编码
       VBD.BARCODE, --商品条码
       VBD.ARTICLE_IDENTIFIER, --商品备案号
       VBD.ARTICLE_NAME, --商品名称
       VBD.SPEC, --规格
       VBD.UNIT, --单位
       VBD.ALARMRATE, --报警比率
       VBD.FREEZERATE, --冻结比率
       VBD.EXPIRY_DAYS, --保质期
       case VBD.TEMPERATURE_FLAG
         when '0' then
          '无温度限制'
         when '1' then
          '有温度限制'
       end TEMPERATURE_FLAG,
       case VBD.Lot_Type
         when '1' then
          '只管批次'
         when '2' then
          '只管生产日期'
         when '3' then
          '管生产日期和批次'
         when '4' then
          '都不管'
       end Lot_Type,
       case VBD.Rule_Flag
         when '1' then
          '是'
         when '0' then
          '否'
       end RULE_FLAG,
       VBD.UNIT_VOLUMN, --单位材积
       VBD.UNIT_WEIGHT, --重量
       nvl(BAP.PACKING_QTY, 1) PACKING_QTY,
       vbd.A_LENGTH AS LENGTH, --长
       vbd.A_WIDTH AS WIDTH, --宽
       vbd.A_HEIGHT AS HEIGHT, --高
       CCA.CELL_NO,
       BAG.GROUP_NO,
       bag.group_name,
       vbd.status,
       case vbd.status
         when '0' then
          '正常'
         when '1' then
          '停用'
       end statusText
  FROM BDEF_DEFARTICLE VBD
 INNER JOIN BDEF_DEFOWNER BDO
    ON BDO.OWNER_NO = VBD.OWNER_NO
   and bdo.enterprise_no = vbd.enterprise_no
  left JOIN BDEF_ARTICLE_PACKING BAP
    ON BAP.ARTICLE_NO = VBD.ARTICLE_NO
   and bap.enterprise_no = VBD.enterprise_no
  LEFT JOIN BDEF_Article_Group BAG
    ON VBD.GROUP_NO = BAG.GROUP_NO
   AND VBD.OWNER_NO = BAG.OWNER_NO
   and vbd.enterprise_no = bag.enterprise_no
  LEFT JOIN CSET_CELL_ARTICLE CCA
    ON cca.enterprise_no = VBD.enterprise_no
   and cca.owner_no = VBD.owner_no
   AND CCA.ARTICLE_NO = VBD.ARTICLE_NO
  left join bdef_defsupplier SU
    on VBD.enterprise_no = su.enterprise_no
   and VBD.owner_no = su.owner_no
   and VBD.supplier_no = su.supplier_no


/

