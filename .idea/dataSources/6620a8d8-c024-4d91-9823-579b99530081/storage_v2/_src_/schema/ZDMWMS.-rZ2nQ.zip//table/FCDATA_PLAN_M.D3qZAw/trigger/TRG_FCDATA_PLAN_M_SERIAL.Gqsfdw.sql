create trigger TRG_FCDATA_PLAN_M_SERIAL
    before insert
    on FCDATA_PLAN_M
    for each row
declare
  i_report_up_SERIAL NUMBER;
begin
  select SEQ_FCDATA_PLAN_M.NEXTVAL into i_report_up_SERIAL from dual;
  :NEW.REPORT_UP_SERIAL := i_report_up_SERIAL;
end TRG_FCDATA_PLAN_M_SERIAL;


/

