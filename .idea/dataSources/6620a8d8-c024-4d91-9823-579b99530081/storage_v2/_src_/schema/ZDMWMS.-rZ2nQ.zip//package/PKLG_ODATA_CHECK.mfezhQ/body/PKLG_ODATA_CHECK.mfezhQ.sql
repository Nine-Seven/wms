create package body PKLG_ODATA_CHECK is

  /*************************************************************************************
  /*复核逻辑包
  luozhiling
  2016.9.27
  新增存储过程(P_RecheckExistsLabelNo:外复核--检查待复核板标签是否能复核) huangb 20161123
  新增存储过程(P_InsertRecheckOrder:外复核--新增外复核单据信息) huangb 20161126
  新增存储过程(P_SaveRecheckWeight:外复核--称重保存) huangb 20161127
  修改存储过程(P_SaveCheckFromArticle:外复核回单) 增加工作流调用 huangb 20161214
  ************************************************************************************************/

  /*****************************************************************************************
   功能：用于电商复核打包的写标签头（电商特殊功能，一复核单对应多个配送对象，按复核标签明细的信息产生标签号
   1、根据复核单上的配送对象循环写标签头

  20160605
  *****************************************************************************************/

  procedure P_DeliverObjLableNo(strEnterpriseNo  in stock_label_m.enterprise_no%type,
                                strWarehouseNo   in stock_label_m.warehouse_no%type, --仓别
                                strCheckNo       in stock_label_m.label_no%type, --源容器号
                                strDeliverObj    in stock_label_m.deliver_obj%type,
                                strContainerType in stock_label_m.container_type%type, ----P：栈板；B物流箱
                                strUserId        in bdef_defworker.worker_no%type,
                                strResult        out varchar2) is
    v_strDcontainerNo      stock_label_m.container_no%type;
    v_strSessionId         varchar2(256);
    v_iCount               integer := 0;
    v_strContainerMaterial wms_defcontainer.container_material%type;
    v_strReportId          job_printtask_m.report_id%type;
    v_strLabelNo           stock_label_m.label_no%type;
  begin
    select count(1)
      into v_iCount
      from stock_label_m slm
     where slm.source_no = strCheckNo
       and slm.deliver_obj = strDeliverObj
       and slm.enterprise_no = strEnterpriseNo
       and slm.warehouse_no = strWarehouseNo;

    if v_iCount > 0 then
      strResult := 'Y|';
      return;
    end if;

    v_iCount := 0;

    for GetCheckLabel in (select slm.trunck_cell_no,
                                 slm.a_sorter_chute_no,
                                 slm.check_chute_no,
                                 slm.owner_cell_no,
                                 sld.*
                            from odata_check_label_d ood,
                                 stock_label_d       sld,
                                 stock_label_m       slm
                           where ood.enterprise_no = sld.enterprise_no
                             and ood.warehouse_no = sld.warehouse_no
                             and sld.enterprise_no = slm.enterprise_no
                             and sld.warehouse_no = slm.warehouse_no
                             and sld.container_no = slm.container_no
                             and ood.container_no = sld.container_no
                             and ood.enterprise_no = strEnterPriseNo
                             and ood.warehouse_no = strWareHouseNo
                             and ood.check_no = strCheckNo
                             and sld.article_no = ood.article_no
                             and ood.deliver_obj = strDeliverObj
                             and sld.divide_id = ood.divide_id
                             and sld.article_id = ood.article_id
                             and sld.packing_qty = ood.packing_qty
                             and sld.exp_no = ood.exp_no
                             and rownum = 1) loop

      v_iCount := v_iCount + 1;

      pklg_wms_base.p_get_ContainerNoBase(strEnterPriseNo,
                                          strWareHouseNo,
                                          strContainerType,
                                          strUserId,
                                          'D',
                                          1,
                                          '2',
                                          v_strContainerMaterial,
                                          v_strLabelNo,
                                          v_strDcontainerNo,
                                          v_strSessionId,
                                          strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      v_strReportId := CONST_REPORTID.B_CLOSEExpBOX;

      pkobj_label.proc_Insert_LabelMaster(strEnterPriseNo,
                                          strWareHouseNo,
                                          GetCheckLabel.batch_no,
                                          strCheckNo,
                                          strDeliverObj,
                                          v_strDcontainerNo,
                                          strContainerType,
                                          'N',
                                          GetCheckLabel.owner_cell_no,
                                          GetCheckLabel.CUST_NO,
                                          GetCheckLabel.TRUNCK_CELL_NO,
                                          GetCheckLabel.a_sorter_chute_no,
                                          GetCheckLabel.CHECK_CHUTE_NO,
                                          strDeliverObj,
                                          CLabelUseType.CUSTOMER_LABEL,
                                          GetCheckLabel.line_no,
                                          'N',
                                          'N',
                                          strUserId,
                                          v_strReportId,
                                          'N',
                                          'N',
                                          '1',
                                          '0',
                                          v_strDcontainerNo,
                                          CLABELSTATUS.NEW_LABEL_NO,
                                          '0',
                                          GetCheckLabel.wave_no,
                                          strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

    end loop;

    if v_iCOUNT = 0 THEN
      --找不到对应的分播数据
      strResult := 'N|[找不到对应的复核数据]';
      return;
    end if;

    strResult := 'Y|[成功]'; --成功
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_DeliverObjLableNo;
  /******************************************************************************************
  复核源标签号检验、只有状态为6A的标签才可以做复核
  Modify By lich AT 2014-11-10
  *****************************************************************************************/
  procedure p_check_SLabelNo(strEnterpriseNo in stock_label_m.enterprise_no%type,
                             strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                             strLabelNo      in stock_label_m.label_no%type, --源容器号
                             strResult       out varchar2) is
    v_sStatus     stock_label_m.status%type; --源容器状态
    v_sStatusName wms_deflabel_status.status_name%type;
    v_sDeliverObj stock_label_m.deliver_obj%type; --源容器配送对象
    v_sUseType    stock_label_m.use_type%type; --源容器标签
    v_sLineNo     stock_label_m.line_no%type; --源容器线路
  begin
    strResult := 'N|[p_check_SLabelNo]';

    --获取来源容器的配送对象和状态
    begin
      select slm.status, b.status_name, slm.use_type
        into v_sStatus, v_sStatusName, v_sUseType
        from stock_label_m slm， wms_deflabel_status b
       where slm.status = b.status_type
         and slm.warehouse_no = strWarehouseNo
         and slm.enterprise_no = strEnterpriseNo
         and slm.label_no = strLabelNo;
    exception
      when no_data_found then
        strResult := 'N|[E23207]'; --无此容器号
        return;
    end;

    --判断标签状态在可允许的范围
    if v_sStatus <> CLabelStatus.INNER_CHECKING then
      strResult := 'N|[' || strLabelNo || '状态为' || v_sStatusName ||
                   ',不允许做复核]';
      return;
    end if;

    if v_sUseType <> '1' then
      strResult := 'N|[E23208]'; --标签状态必须要为客户标签
      return;
    end if;

    strResult := 'Y|[成功]'; --成功
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_check_SLabelNo;

  /***********************************************************************************************
   功能说明 ：
            1、根据任务号/箱号或快递单写复核单，目前用于电商的复核；
            2、免检商品需到免检区扣库存；
            电商复核，写复核单的时候需考虑原始订单数量
  ***********************************************************************************************/

  procedure p_creat_odata_check(strEnterpriseNo in odata_check_m.enterprise_no%type,
                                strWareHouseNo  in odata_check_m.warehouse_no%type,
                                strCheckChuteNo in odata_check_m.check_chute_no%type, --复核台滑道号
                                strTaksNo       in stock_label_m.source_no%type, --任务号，没有则传N
                                --strBoxNo        in stock_label_m.label_no%type, --箱号/ 快递单号
                                strCheckType in varchar2, --复核类型：1:按任务复核或按箱号,2:快递单号复核
                                strUserId    in odata_check_m.rgst_name%type,
                                strCheckNo   out odata_check_m.check_no%type,
                                strResult    out varchar2) is
    v_strCheckNo odata_check_m.check_no%type;
    --v_strCheckStatus odata_check_m.status%type;
    v_Article_QTY    odata_exp_d.article_qty%type;
    v_Source_No      stock_label_m.source_no%type;
    v_Label_No       stock_label_m.label_no%type;
    v_Container_No   stock_label_m.container_no%type;
    v_Container_Type stock_label_d.container_type%type;
    v_Status         stock_label_m.status%type;
    --v_Wave_No        stock_label_m.wave_no%type;
    v_Exp_No odata_exp_m.exp_no%type := 'N';
    v_iCount integer := 0;
  begin
    strResult := 'N|[p_creat_odata_check]';

    --按任务复核
    if strCheckType = '1' then

      for GetExpInfo in (select sum(oed.article_qty) article_qty,
                                oed.exp_no,
                                oed.article_no,
                                oem.enterprise_no,
                                oem.warehouse_no,
                                oem.owner_no
                           from odata_exp_m oem, odata_exp_d oed
                          where oem.enterprise_no = oed.enterprise_no
                            and oem.warehouse_no = oed.warehouse_no
                            and oem.exp_no = oed.exp_no
                            and oed.item_type = '1' --免拣品
                            and exists
                          (select 'x'
                                   from stock_label_m slm, stock_label_d sld
                                  where slm.enterprise_no = strEnterpriseNo
                                    and slm.warehouse_no = strWareHouseNo
                                    and slm.source_no = strTaksNo
                                    and slm.use_type =
                                        CLabelUseType.CUSTOMER_LABEL
                                    and slm.status between
                                        CLabelStatus.PICK_END and
                                        CLabelStatus.WAIT_LOAD_CAR
                                    and slm.container_no = sld.container_no
                                    and slm.enterprise_no = sld.enterprise_no
                                    and slm.warehouse_no = sld.warehouse_no
                                    and sld.exp_no = oem.exp_no
                                    and sld.exp_type = oem.exp_type
                                    and sld.enterprise_no = oem.enterprise_no
                                    and sld.warehouse_no = oem.warehouse_no)
                          group by oed.exp_no,
                                   oed.article_no,
                                   oem.enterprise_no,
                                   oem.warehouse_no,
                                   oem.owner_no) loop

        select slm.source_no,
               slm.label_no,
               slm.container_no,
               slm.container_type,
               slm.status --,
        --slm.wave_no,
        --slm.batch_no
          into v_Source_No,
               v_Label_No,
               v_Container_No,
               v_Container_Type,
               v_Status --,
        --v_wave_No,
        --v_batch_No
          from stock_label_m slm, stock_label_d sld
         where slm.enterprise_no = strEnterpriseNo
           and slm.warehouse_no = strWareHouseNo
           and slm.source_no = strTaksNo
           and slm.use_type = CLabelUseType.CUSTOMER_LABEL
           and slm.status between CLabelStatus.PICK_END and
               CLabelStatus.WAIT_LOAD_CAR
           and slm.container_no = sld.container_no
           and slm.enterprise_no = sld.enterprise_no
           and slm.warehouse_no = sld.warehouse_no
           and sld.exp_no = GetExpInfo.Exp_No
           and sld.enterprise_no = GetExpInfo.Enterprise_No
           and sld.warehouse_no = GetExpInfo.Warehouse_No
           and sld.owner_no = GetExpInfo.Owner_No
           and rownum = 1;

        --免拣品定位，并写标签明细
        pklg_olocate.P_Locate_SpecialArea(strEnterpriseNo,
                                          strWareHouseNo,
                                          strUserId,
                                          GetExpInfo.Article_No,
                                          GetExpInfo.Article_Qty,
                                          '1',
                                          'N',
                                          v_Source_No,
                                          GetExpInfo.Exp_No,
                                          v_Label_No,
                                          v_Container_No,
                                          v_Container_Type,
                                          v_Status,
                                          '1',
                                          v_Article_QTY,
                                          strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        if v_Article_QTY <> GetExpInfo.Article_Qty then
          strResult := 'N|赠品不允许缺量定位！';
          return;
        end if;
      end loop;

      for GetLabelNo in (select distinct slm.batch_no,
                                         slm.cust_no,
                                         slm.line_no,
                                         slm.curr_area,
                                         sld.deliver_obj,
                                         sld.owner_no,
                                         slm.label_no,
                                         slm.container_no,
                                         sld.exp_no
                           from stock_label_m slm, stock_label_d sld
                          where slm.enterprise_no = strEnterpriseNo
                            and slm.warehouse_no = strWareHouseNo
                            and (slm.source_no = strTaksNo or
                                slm.label_no = strTaksNo)
                            and slm.use_type = CLabelUseType.CUSTOMER_LABEL
                               --Modify BY QZH AT 2016-09-22
                            and slm.status = CLabelStatus.INNER_CHECKING
                            and slm.container_no = sld.container_no
                            and slm.enterprise_no = sld.enterprise_no
                            and slm.warehouse_no = sld.warehouse_no
                            and not exists
                          (select 'x'
                                   from odata_check_label_d t
                                  where t.enterprise_no = slm.enterprise_no
                                    and t.warehouse_no = slm.warehouse_no
                                    and t.lable_no = slm.label_no
                                    and t.container_no = slm.container_no)
                          order by sld.exp_no, slm.container_no) loop

        if v_iCount = 0 then
          --取复核单头档单号
          PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                     strWareHouseNo,
                                     CONST_DOCUMENTTYPE.ODATAOC,
                                     v_strCheckNo,
                                     strResult);
          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;
          --新增复核单头档
          PKOBJ_ODATA_CHECK.p_insert_Odata_check_m(strEnterpriseNo,
                                                   strWarehouseNo,
                                                   v_strCheckNo,
                                                   GetLabelNo.owner_no,
                                                   GetLabelNo.batch_no,
                                                   GetLabelNo.cust_no,
                                                   '10',
                                                   strCheckChuteNo,
                                                   'N',
                                                   GetLabelNo.line_no,
                                                   GetLabelNo.curr_area,
                                                   strUserId,
                                                   strResult);
          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;

          --新增复核单明细
          insert into odata_check_d
            (enterprise_no,
             warehouse_no,
             owner_no,
             check_no,
             exp_no,
             exp_id,
             exp_type,
             exp_date,
             article_no,
             packing_qty,
             plan_qty,
             article_qty,
             real_qty,
             status,
             rgst_name,
             rgst_date,
             deliver_obj)
            select a.enterprise_no,
                   a.warehouse_no,
                   a.owner_no,
                   v_strCheckNo,
                   a.exp_no,
                   a.exp_id,
                   a.exp_type,
                   a.exp_date,
                   a.article_no,
                   a.packing_qty,
                   oed.article_qty,
                   a.article_qty,
                   0,
                   '10',
                   strUserId,
                   sysdate,
                   a.deliver_obj
              from (select a.enterprise_no,
                           a.warehouse_no,
                           a.owner_no,
                           a.exp_no,
                           a.exp_id,
                           a.exp_type,
                           a.exp_date,
                           a.article_no,
                           a.packing_qty,
                           sum(a.qty) article_qty,
                           a.deliver_obj
                      from stock_label_d a, stock_label_m t
                     where a.enterprise_no = t.enterprise_no
                       and a.warehouse_no = t.warehouse_no
                       and a.container_no = t.container_no
                       and a.enterprise_no = strEnterpriseNo
                       and a.warehouse_no = strWareHouseNo
                       and (t.source_no = strTaksNo or
                           t.label_no = strTaksNo)
                       and not exists
                     (select 'x'
                              from odata_check_label_d d
                             where t.enterprise_no = d.enterprise_no
                               and t.warehouse_no = d.warehouse_no
                               and t.label_no = d.lable_no
                               and t.container_no = d.container_no)
                     group by a.enterprise_no,
                              a.warehouse_no,
                              a.owner_no,
                              a.exp_no,
                              a.exp_id,
                              a.article_no,
                              a.packing_qty,
                              a.exp_type,
                              a.exp_date,
                              a.deliver_obj) a,
                   odata_exp_d oed
             where a.exp_no = oed.exp_no
                  --and a.article_no = oed.article_no
               and a.exp_id = oed.row_id
               and a.warehouse_no = oed.warehouse_no
               and a.enterprise_no = oed.enterprise_no;

        end if;

        -- 复核标签单明细
        PKOBJ_ODATA_CHECK.p_insert_checkLabelD_by_label(strEnterpriseNo,
                                                        strWarehouseNo,
                                                        v_strCheckNo,
                                                        GetLabelNo.container_no,
                                                        strUserId,
                                                        strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        --更新来源标签的复核台
        update stock_label_m t
           set t.check_chute_no = strCheckChuteNo
         where t.enterprise_no = strEnterpriseNo
           and t.warehouse_no = strWareHouseNo
           and t.label_no = GetLabelNo.label_no;

        if v_Exp_No <> GetLabelNo.Exp_No then
          --单据状态跟踪，开始复核
          PKOBJ_ODISPATCH.P_Insert_Odata_Exp_Trace(strEnterPriseNo,
                                                   strWarehouseNo,
                                                   GetLabelNo.Exp_No,
                                                   COdataExpStatus.ExpTracPartCheck,
                                                   strUserId,
                                                   strResult);
          if substr(strResult, 1, 1) <> 'Y' then
            return;
          end if;
        end if;

        v_Exp_No := GetLabelNo.Exp_No;

        v_iCount := v_iCount + 1;

      end loop;
    end if;

    --按快递单号
    if strCheckType = '2' then
      for GetExpInfo in (select sum(oed.article_qty) article_qty,
                                oed.exp_no,
                                oed.article_no,
                                oem.enterprise_no,
                                oem.warehouse_no,
                                oem.owner_no
                           from odata_exp_m oem, odata_exp_d oed
                          where oem.enterprise_no = oed.enterprise_no
                            and oem.warehouse_no = oed.warehouse_no
                            and oem.exp_no = oed.exp_no
                            and oem.shipper_deliver_no = strTaksNo
                            and oed.item_type = '1' --免拣品
                            and exists
                          (select 'x'
                                   from stock_label_m slm, stock_label_d sld
                                  where slm.enterprise_no = strEnterpriseNo
                                    and slm.warehouse_no = strWareHouseNo
                                    and slm.use_type =
                                        CLabelUseType.CUSTOMER_LABEL
                                    and slm.status between
                                        CLabelStatus.PICK_END and
                                        CLabelStatus.WAIT_LOAD_CAR
                                    and slm.container_no = sld.container_no
                                    and slm.enterprise_no = sld.enterprise_no
                                    and slm.warehouse_no = sld.warehouse_no
                                    and sld.exp_no = oem.exp_no
                                    and sld.exp_type = oem.exp_type
                                    and sld.enterprise_no = oem.enterprise_no
                                    and sld.warehouse_no = oem.warehouse_no)
                          group by oed.exp_no,
                                   oed.article_no,
                                   oem.enterprise_no,
                                   oem.warehouse_no,
                                   oem.owner_no) loop

        select slm.source_no,
               slm.label_no,
               slm.container_no,
               slm.container_type,
               slm.status --,
        --slm.wave_no,
        --slm.batch_no
          into v_Source_No,
               v_Label_No,
               v_Container_No,
               v_Container_Type,
               v_Status --,
        --v_wave_No,
        --v_batch_No
          from stock_label_m slm, stock_label_d sld
         where slm.enterprise_no = strEnterpriseNo
           and slm.warehouse_no = strWareHouseNo
           and exists (select 'x'
                  from odata_exp_m oem
                 where oem.shipper_deliver_no = strTaksNo
                   and oem.enterprise_no = strEnterpriseNo
                   and oem.warehouse_no = strWareHouseNo
                   and oem.exp_no = sld.exp_no
                   and oem.exp_type = sld.exp_type
                   and oem.status <> '16')
           and slm.use_type = CLabelUseType.CUSTOMER_LABEL
           and slm.status between CLabelStatus.PICK_END and
               CLabelStatus.WAIT_LOAD_CAR
           and slm.container_no = sld.container_no
           and slm.enterprise_no = sld.enterprise_no
           and slm.warehouse_no = sld.warehouse_no
           and sld.exp_no = GetExpInfo.Exp_No
           and sld.enterprise_no = GetExpInfo.Enterprise_No
           and sld.warehouse_no = GetExpInfo.Warehouse_No
           and sld.owner_no = GetExpInfo.Owner_No
           and rownum = 1;

        --免拣品定位，并写标签明细
        pklg_olocate.P_Locate_SpecialArea(strEnterpriseNo,
                                          strWareHouseNo,
                                          strUserId,
                                          GetExpInfo.Article_No,
                                          GetExpInfo.Article_Qty,
                                          '1',
                                          'N',
                                          v_Source_No,
                                          GetExpInfo.Exp_No,
                                          v_Label_No,
                                          v_Container_No,
                                          v_Container_Type,
                                          v_Status,
                                          '1',
                                          v_Article_QTY,
                                          strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        if v_Article_QTY <> GetExpInfo.Article_Qty then
          strResult := 'N|赠品不允许缺量定位！';
          return;
        end if;
      end loop;

      for GetLabelNo in (select distinct slm.batch_no,
                                         slm.cust_no,
                                         slm.line_no,
                                         slm.curr_area,
                                         sld.deliver_obj,
                                         sld.owner_no,
                                         slm.label_no,
                                         sld.container_no,
                                         sld.exp_no
                           from stock_label_m slm, stock_label_d sld
                          where slm.enterprise_no = strEnterpriseNo
                            and slm.warehouse_no = strWareHouseNo
                            and exists
                          (select 'x'
                                   from odata_exp_m oem
                                  where oem.shipper_deliver_no = strTaksNo
                                    and oem.enterprise_no = strEnterpriseNo
                                    and oem.warehouse_no = strWareHouseNo
                                    and oem.exp_no = sld.exp_no
                                    and oem.exp_type = sld.exp_type
                                    and oem.status <> '16')
                            and slm.use_type = CLabelUseType.CUSTOMER_LABEL
                               --Modify BY QZH AT 2016-09-22
                            and slm.status = CLabelStatus.INNER_CHECKING
                            and slm.container_no = sld.container_no
                            and slm.enterprise_no = sld.enterprise_no
                            and slm.warehouse_no = sld.warehouse_no
                          order by sld.exp_no, sld.container_no) loop

        if v_iCount = 0 then
          --取复核单头档单号
          PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                     strWareHouseNo,
                                     CONST_DOCUMENTTYPE.ODATAOC,
                                     v_strCheckNo,
                                     strResult);
          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;

          --新增复核单头档
          PKOBJ_ODATA_CHECK.p_insert_Odata_check_m(strEnterpriseNo,
                                                   strWarehouseNo,
                                                   v_strCheckNo,
                                                   GetLabelNo.owner_no,
                                                   GetLabelNo.batch_no,
                                                   GetLabelNo.cust_no,
                                                   '10',
                                                   strCheckChuteNo,
                                                   'N',
                                                   GetLabelNo.line_no,
                                                   GetLabelNo.curr_area,
                                                   strUserId,
                                                   strResult);
          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;

          --新增复核单明细
          insert into odata_check_d
            (enterprise_no,
             warehouse_no,
             owner_no,
             check_no,
             exp_no,
             exp_id,
             exp_type,
             exp_date,
             article_no,
             packing_qty,
             plan_qty,
             article_qty,
             real_qty,
             status,
             rgst_name,
             rgst_date,
             deliver_obj)
            select a.enterprise_no,
                   a.warehouse_no,
                   a.owner_no,
                   v_strCheckNo,
                   a.exp_no,
                   a.exp_id,
                   a.exp_type,
                   a.exp_date,
                   a.article_no,
                   a.packing_qty,
                   oed.article_qty,
                   a.article_qty,
                   0,
                   '10',
                   strUserId,
                   sysdate,
                   a.deliver_obj
              from (select a.enterprise_no,
                           a.warehouse_no,
                           a.owner_no,
                           a.exp_no,
                           a.exp_id,
                           a.exp_type,
                           a.exp_date,
                           a.article_no,
                           a.packing_qty,
                           sum(a.qty) article_qty,
                           a.deliver_obj
                      from stock_label_d a, stock_label_m t
                     where a.enterprise_no = t.enterprise_no
                       and a.warehouse_no = t.warehouse_no
                       and a.container_no = t.container_no
                       and a.enterprise_no = strEnterpriseNo
                       and a.warehouse_no = strWareHouseNo
                       and exists
                     (select 'x'
                              from odata_exp_m oem
                             where oem.shipper_deliver_no = strTaksNo
                               and oem.enterprise_no = strEnterpriseNo
                               and oem.warehouse_no = strWareHouseNo
                               and oem.exp_no = a.exp_no
                               and oem.exp_type = a.exp_type
                               and oem.status <> '16')
                     group by a.enterprise_no,
                              a.warehouse_no,
                              a.owner_no,
                              a.exp_no,
                              a.exp_id,
                              a.article_no,
                              a.packing_qty,
                              a.exp_type,
                              a.exp_date,
                              a.deliver_obj) a,
                   odata_exp_d oed
             where a.exp_no(+) = oed.exp_no
               and a.exp_id(+) = oed.row_id
                  -- and a.article_no(+) = oed.article_no
               and a.warehouse_no = oed.warehouse_no;

        end if;

        -- 复核标签单明细
        PKOBJ_ODATA_CHECK.p_insert_checkLabelD_by_label(strEnterpriseNo,
                                                        strWarehouseNo,
                                                        v_strCheckNo,
                                                        GetLabelNo.container_no,
                                                        strUserId,
                                                        strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        --更新来源标签的复核台
        update stock_label_m t
           set t.check_chute_no = strCheckChuteNo
         where t.enterprise_no = strEnterpriseNo
           and t.warehouse_no = strWareHouseNo
           and t.label_no = GetLabelNo.label_no;

        if v_Exp_No <> GetLabelNo.Exp_No then
          --单据状态跟踪，开始复核
          PKOBJ_ODISPATCH.P_Insert_Odata_Exp_Trace(strEnterPriseNo,
                                                   strWarehouseNo,
                                                   GetLabelNo.Exp_No,
                                                   COdataExpStatus.ExpTracPartCheck,
                                                   strUserId,
                                                   strResult);
          if substr(strResult, 1, 1) <> 'Y' then
            return;
          end if;
        end if;

        v_Exp_No := GetLabelNo.Exp_No;

        v_iCount := v_iCount + 1;
      end loop;

    end if;

    if v_iCount <= 0 then
      strResult := 'N|[扫描的单号无效]'; --成功
      return;
    end if;

    strCheckNo := v_strCheckNo;

    strResult := 'Y|[成功]'; --成功
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_creat_odata_check;
  /***********************************************************************************************
   --根据箱号写复核单数据，传统行业的复核建单
   直接按标签明细产生复核单和明细，与订单无关
  ***********************************************************************************************/

  procedure p_creat_odata_check_by_label(strEnterpriseNo in odata_check_m.enterprise_no%type,
                                         strWareHouseNo  in odata_check_m.warehouse_no%type,
                                         strlabelNo      in stock_label_m.label_no%type, --箱号
                                         strCheckChuteNo in odata_check_m.check_chute_no%type, --复核台滑道号
                                         strUserId       in odata_check_m.rgst_name%type,
                                         strResult       out varchar2) is

    v_strCheckNo     odata_check_m.check_no%type;
    v_strBatchNo     odata_check_m.batch_no%type;
    v_strCustNo      odata_check_m.cust_no%type;
    v_strLineNo      odata_check_m.line_no%type;
    v_strCurrArea    odata_check_m.curr_area%type;
    v_deliverObj     stock_label_m.deliver_obj%type;
    v_ownerNo        stock_label_d.owner_no%type;
    v_containerNo    stock_label_d.container_no%type;
    v_strCheckStatus odata_check_m.status%type;
  begin
    --获取标签信息
    begin
      select slm.batch_no,
             slm.cust_no,
             slm.line_no,
             slm.curr_area,
             slm.deliver_obj,
             sld.owner_no,
             slm.container_no
        into v_strBatchNo,
             v_strCustNo,
             v_strLineNo,
             v_strCurrArea,
             v_deliverObj,
             v_ownerNo,
             v_containerNo
        from stock_label_m slm, stock_label_d sld
       where slm.enterprise_no = strEnterpriseNo
         and slm.warehouse_no = strWareHouseNo
         and slm.label_no = strlabelNo
         and slm.use_type = CLabelUseType.CUSTOMER_LABEL
         and slm.status between CLabelStatus.PICK_END and
             CLabelStatus.WAIT_LOAD_CAR
         and slm.container_no = sld.container_no
         and slm.enterprise_no = sld.enterprise_no
         and slm.warehouse_no = sld.warehouse_no
         and rownum = 1;
    exception
      when no_data_found then
        strResult := 'N|[p_creat_odata_check]';
        return;
    end;

    --判断此标签是否有对应的复核单
    begin
      select a.status, a.check_no
        into v_strCheckStatus, v_strCheckNo
        from odata_check_label_d t, odata_check_m a
       where t.enterprise_no = a.enterprise_no
         and t.warehouse_no = a.warehouse_no
         and t.check_no = a.check_no
         and t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.lable_no = strlabelNo
         and rownum = 1;
    exception
      when no_data_found then
        v_strCheckStatus := '';
    end;

    if v_strCheckStatus = '12' then
      strResult := 'N|[该标签已经做复核回单]';
      return;
    end if;

    --取复核单头档单号
    PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                               strWareHouseNo,
                               CONST_DOCUMENTTYPE.ODATAOC,
                               v_strCheckNo,
                               strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    --新增复核单头档
    PKOBJ_ODATA_CHECK.p_insert_Odata_check_m(strEnterpriseNo,
                                             strWarehouseNo,
                                             v_strCheckNo,
                                             v_ownerNo,
                                             v_strBatchNo,
                                             v_strCustNo,
                                             '10',
                                             strCheckChuteNo,
                                             v_deliverObj,
                                             v_strLineNo,
                                             v_strCurrArea,
                                             strUserId,
                                             strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    --新增复核单明细
    PKOBJ_ODATA_CHECK.p_insert_Odata_checkD_by_label(strEnterpriseNo,
                                                     strWareHouseNo,
                                                     v_strCheckNo,
                                                     v_containerNo,
                                                     strUserId,
                                                     strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    -- 复核标签单明细
    PKOBJ_ODATA_CHECK.p_insert_checkLabelD_by_label(strEnterpriseNo,
                                                    strWarehouseNo,
                                                    v_strCheckNo,
                                                    v_containerNo,
                                                    strUserId,
                                                    strResult);

    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    --更新来源标签的复核台
    update stock_label_m t
       set t.check_chute_no = strCheckChuteNo
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWareHouseNo
       and t.label_no = strlabelNo;

    strResult := 'Y|[成功]'; --成功
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_creat_odata_check_by_label;

  /************************************************************************************************
  功能说明：：用于电商的复核建单
           1、若跳过拣货标识为Y，则对未拣货回单的标签进行自动拣货回单；
           2、校验单号是否可进行复核，若存在返回复核单号，
           2、若不存在复核单，则创建复核单
  ************************************************************************************************/
  procedure P_CheckAndCreate(strEnterpriseNo in odata_check_m.enterprise_no%type,
                             strWareHouseNo  in odata_check_m.warehouse_no%type,
                             strCheckChuteNo in odata_check_m.check_chute_no%type, --复核台滑道号
                             strTaksNo       in stock_label_m.source_no%type, --任务号，没有则传N
                             strBoxNo        in stock_label_m.label_no%type, --箱号/ 快递单号
                             strCheckType    in varchar2, --复核类型：1:按任务复核\按箱号；2：快递单号复核
                             strUserId       in odata_check_m.rgst_name%type,
                             strAutoOutstock in varchar2, --是否可自动下架回单:Y-可以,N-不可以
                             strCheckNo      out odata_check_m.check_no%type,
                             strResult       out varchar2) is
    v_strCheckNo odata_check_m.check_no%type;

  begin
    strResult := 'N|[P_CheckAndCreate]';

    --自动拣货回单
    if strAutoOutstock = 'Y' then
      if strCheckType = '1' then

        --任务单号
        for curOutstockInfo in (select slm.label_no as stock_label_no,
                                       oom.task_type,
                                       --ood.*,
                                       ood.article_no,
                                       ood.outstock_no,
                                       ood.packing_qty,
                                       ood.s_cell_no,
                                       sum(ood.article_qty) article_qty,
                                       sum(ood.real_qty) real_qty,
                                       sai.quality,
                                       sai.produce_date,
                                       sai.expire_date,
                                       sai.lot_no,
                                       sai.rsv_batch1,
                                       sai.rsv_batch2,
                                       sai.rsv_batch3,
                                       sai.rsv_batch4,
                                       sai.rsv_batch5,
                                       sai.rsv_batch6,
                                       sai.rsv_batch7,
                                       sai.rsv_batch8
                                  from stock_label_m      slm,
                                       odata_outstock_d   ood,
                                       odata_outstock_m   oom,
                                       stock_article_info sai
                                 where oom.outstock_no = ood.outstock_no
                                   and oom.enterprise_no = ood.enterprise_no
                                   and oom.warehouse_no = ood.warehouse_no
                                   and oom.enterprise_no = strEnterpriseNo
                                   and oom.warehouse_no = strWareHouseNo
                                   and slm.source_no = oom.outstock_no
                                   and slm.enterprise_no = oom.enterprise_no
                                   and slm.warehouse_no = oom.warehouse_no
                                   and slm.status =
                                       CLABELSTATUS.INNER_CHECKING
                                   and sai.article_no = ood.article_no
                                   and sai.article_id = ood.article_id
                                   and sai.enterprise_no = ood.enterprise_no
                                   and ood.status < '13'
                                 group by slm.label_no,
                                          oom.task_type,
                                          --ood.*,
                                          ood.article_no,
                                          ood.outstock_no,
                                          ood.packing_qty,
                                          ood.s_cell_no,

                                          sai.quality,
                                          sai.produce_date,
                                          sai.expire_date,
                                          sai.lot_no,
                                          sai.rsv_batch1,
                                          sai.rsv_batch2,
                                          sai.rsv_batch3,
                                          sai.rsv_batch4,
                                          sai.rsv_batch5,
                                          sai.rsv_batch6,
                                          sai.rsv_batch7,
                                          sai.rsv_batch8) loop

          --流水标签
          if curOutstockInfo.Task_Type = '0' then
            PKLG_ODATA_LICH.P_SerialLabel_Save(strEnterpriseNo,
                                               strWareHouseNo,
                                               curOutstockInfo.Outstock_No,
                                               curOutstockInfo.stock_label_no,
                                               curOutstockInfo.Article_No,
                                               curOutstockInfo.Packing_Qty,
                                               curOutstockInfo.s_Cell_No,
                                               curOutstockInfo.Article_Qty -
                                               curOutstockInfo.Real_Qty,
                                               curOutstockInfo.Quality,
                                               curOutstockInfo.Produce_Date,
                                               curOutstockInfo.Expire_Date,
                                               curOutstockInfo.Lot_No,
                                               curOutstockInfo.Rsv_Batch1,
                                               curOutstockInfo.Rsv_Batch2,
                                               curOutstockInfo.Rsv_Batch3,
                                               curOutstockInfo.Rsv_Batch4,
                                               curOutstockInfo.Rsv_Batch5,
                                               curOutstockInfo.Rsv_Batch6,
                                               curOutstockInfo.Rsv_Batch7,
                                               curOutstockInfo.Rsv_Batch8,
                                               strUserId,
                                               strUserId,
                                               strUserId,
                                               strResult);

            if (substr(strResult, 1, 1) = 'N') then
              return;
            end if;
          end if;

          --任务标签
          if curOutstockInfo.Task_Type = '2' then
            PKLG_ODATA_LICH.P_TaskLabelSave_Odata_Outstock(strEnterpriseNo,
                                                           strWareHouseNo,
                                                           curOutstockInfo.Outstock_No,
                                                           curOutstockInfo.stock_label_no,
                                                           curOutstockInfo.stock_label_no,
                                                           curOutstockInfo.Article_No,
                                                           curOutstockInfo.Packing_Qty,
                                                           curOutstockInfo.s_Cell_No,
                                                           curOutstockInfo.Article_Qty -
                                                           curOutstockInfo.Real_Qty,
                                                           curOutstockInfo.Article_Qty -
                                                           curOutstockInfo.Real_Qty,
                                                           curOutstockInfo.Quality,
                                                           curOutstockInfo.Produce_Date,
                                                           curOutstockInfo.Expire_Date,
                                                           curOutstockInfo.Lot_No,
                                                           curOutstockInfo.Rsv_Batch1,
                                                           curOutstockInfo.Rsv_Batch2,
                                                           curOutstockInfo.Rsv_Batch3,
                                                           curOutstockInfo.Rsv_Batch4,
                                                           curOutstockInfo.Rsv_Batch5,
                                                           curOutstockInfo.Rsv_Batch6,
                                                           curOutstockInfo.Rsv_Batch7,
                                                           curOutstockInfo.Rsv_Batch8,
                                                           strCheckChuteNo,
                                                           strUserId,
                                                           strUserId,
                                                           strUserId,
                                                           strResult);
            if (substr(strResult, 1, 1) = 'N') then
              return;
            end if;
          end if;
        end loop;
      end if;
      --面单号
      if strCheckType = '2' then
        for curOutstockInfo in (select slm.label_no stock_label_no,
                                       oom.task_type,
                                       --ood.*,
                                       ood.article_no,
                                       ood.outstock_no,
                                       ood.packing_qty,
                                       ood.s_cell_no,
                                       sum(ood.article_qty) article_qty,
                                       sum(ood.real_qty) real_qty,
                                       sai.quality,
                                       sai.produce_date,
                                       sai.expire_date,
                                       sai.lot_no,
                                       sai.rsv_batch1,
                                       sai.rsv_batch2,
                                       sai.rsv_batch3,
                                       sai.rsv_batch4,
                                       sai.rsv_batch5,
                                       sai.rsv_batch6,
                                       sai.rsv_batch7,
                                       sai.rsv_batch8
                                  from stock_label_m      slm,
                                       odata_outstock_d   ood,
                                       odata_outstock_m   oom,
                                       stock_article_info sai,
                                       odata_exp_m        oem
                                 where oem.shipper_deliver_no = strTaksNo
                                   and oem.enterprise_no = ood.enterprise_no
                                   and oem.warehouse_no = oom.warehouse_no

                                   and oom.enterprise_no = ood.enterprise_no
                                   and oem.exp_no = ood.exp_no
                                   and oem.exp_type = ood.exp_type
                                   and oem.warehouse_no = ood.warehouse_no
                                   and oom.outstock_no = ood.outstock_no
                                   and slm.source_no = oom.outstock_no
                                   and slm.enterprise_no = oom.enterprise_no
                                   and slm.warehouse_no = oom.warehouse_no
                                   and slm.status =
                                       CLABELSTATUS.PICK_HAND_OUT
                                   and sai.article_no = ood.article_no
                                   and sai.article_id = ood.article_id
                                   and ood.status < '13'
                                 group by slm.label_no,
                                          oom.task_type,
                                          --ood.*,
                                          ood.article_no,
                                          ood.outstock_no,
                                          ood.packing_qty,
                                          ood.s_cell_no,
                                          sai.quality,
                                          sai.produce_date,
                                          sai.expire_date,
                                          sai.lot_no,
                                          sai.rsv_batch1,
                                          sai.rsv_batch2,
                                          sai.rsv_batch3,
                                          sai.rsv_batch4,
                                          sai.rsv_batch5,
                                          sai.rsv_batch6,
                                          sai.rsv_batch7,
                                          sai.rsv_batch8) loop

          --流水标签
          if curOutstockInfo.Task_Type = '0' then
            PKLG_ODATA_LICH.P_SerialLabel_Save(strEnterpriseNo,
                                               strWareHouseNo,
                                               curOutstockInfo.Outstock_No,
                                               curOutstockInfo.stock_label_no,
                                               curOutstockInfo.Article_No,
                                               curOutstockInfo.Packing_Qty,
                                               curOutstockInfo.s_Cell_No,
                                               curOutstockInfo.Article_Qty -
                                               curOutstockInfo.Real_Qty,
                                               curOutstockInfo.Quality,
                                               curOutstockInfo.Produce_Date,
                                               curOutstockInfo.Expire_Date,
                                               curOutstockInfo.Lot_No,
                                               curOutstockInfo.Rsv_Batch1,
                                               curOutstockInfo.Rsv_Batch2,
                                               curOutstockInfo.Rsv_Batch3,
                                               curOutstockInfo.Rsv_Batch4,
                                               curOutstockInfo.Rsv_Batch5,
                                               curOutstockInfo.Rsv_Batch6,
                                               curOutstockInfo.Rsv_Batch7,
                                               curOutstockInfo.Rsv_Batch8,
                                               strUserId,
                                               strUserId,
                                               strUserId,
                                               strResult);

            if (substr(strResult, 1, 1) = 'N') then
              return;
            end if;
          end if;
          --任务标签
          if curOutstockInfo.Task_Type = '2' then
            PKLG_ODATA_LICH.P_TaskLabelSave_Odata_Outstock(strEnterpriseNo,
                                                           strWareHouseNo,
                                                           curOutstockInfo.Outstock_No,
                                                           curOutstockInfo.stock_label_no,
                                                           curOutstockInfo.stock_label_no,
                                                           curOutstockInfo.Article_No,
                                                           curOutstockInfo.Packing_Qty,
                                                           curOutstockInfo.s_Cell_No,
                                                           curOutstockInfo.Article_Qty -
                                                           curOutstockInfo.Real_Qty,
                                                           curOutstockInfo.Article_Qty -
                                                           curOutstockInfo.Real_Qty,
                                                           curOutstockInfo.Quality,
                                                           curOutstockInfo.Produce_Date,
                                                           curOutstockInfo.Expire_Date,
                                                           curOutstockInfo.Lot_No,
                                                           curOutstockInfo.Rsv_Batch1,
                                                           curOutstockInfo.Rsv_Batch2,
                                                           curOutstockInfo.Rsv_Batch3,
                                                           curOutstockInfo.Rsv_Batch4,
                                                           curOutstockInfo.Rsv_Batch5,
                                                           curOutstockInfo.Rsv_Batch6,
                                                           curOutstockInfo.Rsv_Batch7,
                                                           curOutstockInfo.Rsv_Batch8,
                                                           strCheckChuteNo,
                                                           strUserId,
                                                           strUserId,
                                                           strUserId,
                                                           strResult);
            if (substr(strResult, 1, 1) = 'N') then
              return;
            end if;
          end if;
        end loop;
      end if;
    end if;

    P_TaskAndBoxCheck(strEnterpriseNo,
                      strWareHouseNo,
                      strCheckChuteNo,
                      strTaksNo,
                      strTaksNo,
                      strCheckType,
                      v_strCheckNo,
                      strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    if v_strCheckNo = 'N' or v_strCheckNo is null then

      --创建复核单
      p_creat_odata_check(strEnterpriseNo,
                          strWareHouseNo,
                          strCheckChuteNo,
                          strTaksNo,
                          --strTaksNo,
                          strCheckType,
                          strUserId,
                          v_strCheckNo,
                          strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
    end if;

    strCheckNo := v_strCheckNo;

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_CheckAndCreate;

  /************************************************************************************************
  功能说明：复核单校验：
           1、支持按任务号校验；
           2、支持按箱号校验
  ************************************************************************************************/
  procedure P_TaskAndBoxCheck(strEnterpriseNo in odata_check_m.enterprise_no%type,
                              strWareHouseNo  in odata_check_m.warehouse_no%type,
                              strCheckChuteNo in odata_check_m.check_chute_no%type, --复核台滑道号
                              strTaksNo       in stock_label_m.source_no%type, --任务号，没有则传N
                              strBoxNo        in stock_label_m.label_no%type, --箱号/ 快递单号
                              strCheckType    in varchar2, --复核类型：1:按任务复核或按箱号；2：快递单号复核
                              strCheckNo      out odata_check_m.check_no%type,
                              strResult       out varchar2) is
    v_strCheckNo      odata_check_m.check_no%type;
    v_strCheckChuteNo odata_check_m.check_chute_no%type;
    --v_strStatus       stock_label_m.status%type;
    --v_strUseType      stock_label_m.use_type%type;
    v_Count       integer := 0;
    v_Check_Level WMS_CHECK_STRATEGY.Check_Level%type; --复核级别

  begin
    strResult := 'N|[P_TaskAndBoxCheck]';

    --按面单进行复核
    if strCheckType = '2' then
      begin
        select t.check_no, ocm.check_chute_no
          into v_strCheckNo, v_strCheckChuteNo
          from odata_check_label_d t, stock_label_m slm, odata_check_m ocm
         where t.enterprise_no = ocm.enterprise_no
           and t.warehouse_no = ocm.warehouse_no
           and t.check_no = ocm.check_no
           and t.enterprise_no = slm.enterprise_no
           and t.warehouse_no = slm.warehouse_no
           and t.enterprise_no = strEnterpriseNo
           and t.warehouse_no = strWareHouseNo
           and t.lable_no = slm.label_no

           and exists (select 'x'
                  from odata_exp_m oem
                 where oem.shipper_deliver_no = strTaksNo
                   and oem.enterprise_no = strEnterpriseNo
                   and oem.warehouse_no = strWareHouseNo
                   and oem.exp_no = t.exp_no
                   and oem.exp_type = t.exp_type
                   and oem.status <> '16')
              --and slm.status not in ('C0', '50', 'A0', 'A1')
           and slm.status = '6A'
           and rownum = 1;
      exception
        when no_data_found then
          strCheckNo := 'N';
      end;
    end if;

    if strCheckType = '1' then
      --获取复核单号
      begin
        select t.check_no, ocm.check_chute_no
          into v_strCheckNo, v_strCheckChuteNo
          from odata_check_label_d t, stock_label_m slm, odata_check_m ocm
         where t.enterprise_no = ocm.enterprise_no
           and t.warehouse_no = ocm.warehouse_no
           and t.check_no = ocm.check_no
           and t.enterprise_no = slm.enterprise_no
           and t.warehouse_no = slm.warehouse_no
           and t.enterprise_no = strEnterpriseNo
           and t.warehouse_no = strWareHouseNo
           and t.lable_no = slm.label_no
           and slm.status = '6A'
           and (slm.source_no = strTaksNo or slm.label_no = strTaksNo)
           and rownum = 1;
      exception
        when no_data_found then
          --没有复核单号
          strCheckNo := 'N';
      end;
    end if;

    --判断标签是否存在
    select count(1)
      into v_Count
      from stock_label_m slm
     where slm.enterprise_no = strEnterpriseNo
       and slm.warehouse_no = strWareHouseNo
       and slm.status = '6A'
       and slm.use_type = '1'
       and (slm.source_no = strTaksNo or slm.label_no = strTaksNo);
    if v_Count <= 0 then
      strResult := 'N|[' || strTaksNo || '该任务不存在]';
      return;
    end if;

    if v_strCheckChuteNo <> strCheckChuteNo then
      strResult := 'N|[该单已在' || v_strCheckChuteNo || '复核台扫描过]';
      return;
    end if;

    --
    select t.check_level
      into v_Check_Level
      from WMS_CHECK_STRATEGY t
     where t.check_type = 'B'
       and exists
     (select 'x'
              from odata_locate_batch olb, stock_label_m slm
             where olb.b_check_strategy_id = t.check_strategy_id
               and olb.enterprise_no = t.enterprise_no
               and slm.enterprise_no = strEnterpriseNo
               and slm.warehouse_no = strWareHouseNo
               and (slm.source_no = strTaksNo or slm.label_no = strTaksNo)
               and slm.wave_no = olb.wave_no
               and slm.batch_no = olb.batch_no
               and slm.warehouse_no = olb.warehouse_no
               and slm.enterprise_no = olb.enterprise_no);

    --按单复核
    if v_Check_Level = '2' then
      select count(1)
        into v_Count
        from stock_label_m a, stock_label_d b
       where a.enterprise_no = b.enterprise_no
         and a.warehouse_no = b.warehouse_no
         and a.container_no = b.container_no
         and a.status < '6A'
         and exists
       (select 'x'
                from stock_label_m c, stock_label_d d
               where c.enterprise_no = strEnterpriseNo
                 and c.warehouse_no = strWareHouseNo
                 and c.enterprise_no = d.enterprise_no
                 and c.warehouse_no = d.warehouse_no
                 and c.container_no = d.container_no
                 and b.enterprise_no = d.enterprise_no
                 and b.warehouse_no = d.warehouse_no
                 and b.exp_no = d.exp_no
                 and b.exp_type = d.exp_type
                 and (c.source_no = strTaksNo or c.label_no = strTaksNo));
    end if;

    --按批次
    if v_Check_Level = '3' then
      select count(1)
        into v_Count
        from stock_label_m a, stock_label_d b
       where a.enterprise_no = b.enterprise_no
         and a.warehouse_no = b.warehouse_no
         and a.container_no = b.container_no
         and a.status < '6A'
         and exists
       (select 'x'
                from stock_label_m c, stock_label_d d
               where c.enterprise_no = strEnterpriseNo
                 and c.warehouse_no = strWareHouseNo
                 and c.enterprise_no = d.enterprise_no
                 and c.warehouse_no = d.warehouse_no
                 and c.container_no = d.container_no
                 and b.enterprise_no = d.enterprise_no
                 and b.warehouse_no = d.warehouse_no
                 and b.batch_no = d.batch_no
                 and (c.source_no = strTaksNo or c.label_no = strTaksNo));
    end if;

    if v_Count > 0 then
      strResult := 'N|[该任务' || strTaksNo || '还未完成！]';
      return;
    end if;

    strCheckNo := v_strCheckNo;

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_TaskAndBoxCheck;

  /***********************************************************************************************
   --扫描商品条码-整理容器（电商）
   功能说明：根据复核单里的商品进行复核，需循环按商品抓取标签号再进行处理
   chensr
   2015.5.5
  ***********************************************************************************************/
  procedure P_CheckArticle(strEnterpriseNo in odata_check_m.enterprise_no%type,
                           strWareHouseNo  in odata_check_m.warehouse_no%type,
                           strCheckNo      in odata_check_m.check_no%type,
                           strDeliverObj   in odata_check_m.deliver_obj%type,
                           strArticle_No   in odata_check_d.article_no%type, --商品编码
                           nPacking_QTY    in odata_check_d.packing_qty%type, --包装数量
                           strQuality      in stock_article_info.quality%type, --品质
                           dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                           dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                           strLotNo        in stock_article_info.lot_no%type, --批次号
                           strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                           strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                           strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                           strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                           strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                           strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                           strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                           strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                           strBarcode      in stock_article_info.barcode%type,
                           strsLabelNo     in stock_label_m.label_no%type,
                           strDLabelNo     in stock_label_m.label_no%type, --目的标签
                           nRealQty        in odata_check_d.real_qty%type, --回单数量
                           strUserId       in odata_check_m.rgst_name%type,
                           strResult       out varchar2) is

    v_nCurrQty odata_check_d.real_qty%type;
    --v_nSumQty    odata_check_d.real_qty%type;
    v_nRemainQty odata_check_d.real_qty%type;
    v_iCount     integer := 0;
  begin
    strResult := 'N|[P_CheckArticle]';

    v_nRemainQty := nRealQty;
    if v_nRemainQty < 0 then
      v_nRemainQty := v_nRemainQty * -1;
    end if;

    for GetOdataCheckItem in (select ocd.*
                                from odata_check_label_d ocd,
                                     stock_article_info  sai
                               where ocd.enterprise_no = sai.enterprise_no
                                 and ocd.article_no = sai.article_no
                                 and ocd.article_id = sai.article_id
                                 and ocd.enterprise_no = strEnterpriseNo
                                 and ocd.warehouse_no = strWareHouseNo
                                 and ocd.check_no = strCheckNo
                                 and ocd.lable_no = strsLabelNo
                                 and ocd.article_no = strArticle_No
                                 and ocd.packing_qty = nPacking_QTY
                                 and sai.produce_date = dtProduceDate
                                 and sai.expire_date = dtExpireDate
                                 and sai.lot_no = strLotNo
                                 and sai.quality = strQuality
                                 and sai.rsv_batch1 = strRSV_BATCH1
                                 and sai.rsv_batch2 = strRSV_BATCH2
                                 and sai.rsv_batch3 = strRSV_BATCH3
                                 and sai.rsv_batch4 = strRSV_BATCH4
                                 and sai.rsv_batch5 = strRSV_BATCH5
                                 and sai.rsv_batch6 = strRSV_BATCH6
                                 and sai.rsv_batch7 = strRSV_BATCH7
                                 and sai.rsv_batch8 = strRSV_BATCH8
                                 and ocd.deliver_obj = strDeliverObj
                                 and ocd.status in ('10', '11')
                               order by ocd.container_no, ocd.article_id) loop

      v_iCount := v_iCount + 1;

      if nRealQty > 0 then
        --
        v_nCurrQty := GetOdataCheckItem.article_qty -
                      GetOdataCheckItem.real_qty;
        if v_nCurrQty > v_nRemainQty then
          v_nCurrQty := v_nRemainQty;
        end if;

        v_nRemainQty := v_nRemainQty - v_nCurrQty;
      else

        v_nCurrQty := GetOdataCheckItem.real_qty;
        if v_nCurrQty > v_nRemainQty then
          v_nCurrQty := v_nRemainQty;
        end if;

        v_nRemainQty := v_nRemainQty - v_nCurrQty;

        v_nCurrQty := v_nCurrQty * -1;

      end if;

      --更新复核标签明细
      PKOBJ_ODATA_CHECK.P_UpdateOdataCheckLabelD(strEnterpriseNo,
                                                 strWareHouseNo,
                                                 strCheckNo,
                                                 GetOdataCheckItem.container_no,
                                                 strDLabelNo,
                                                 GetOdataCheckItem.row_id,
                                                 v_nCurrQty,
                                                 strUserId,
                                                 strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --更新复核单明细
      pkobj_odata_check.P_UpdtaOdataCheckD(strEnterpriseNo,
                                           strWareHouseNo,
                                           strCheckNo,
                                           GetOdataCheckItem.Exp_No,
                                           GetOdataCheckItem.Exp_Id,
                                           GetOdataCheckItem.article_no,
                                           GetOdataCheckItem.packing_qty,
                                           v_nCurrQty,
                                           strUserId,
                                           strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      if v_nRemainQty = 0 then
        exit;
      end if;

    end loop;

    if v_nRemainQty > 0 then
      strResult := 'N|[库存扣减超量]';
      return;

    end if;

    if v_iCount = 0 then
      strResult := 'N|[找不到要复核的标签明细]';
      return;
    end if;

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_CheckArticle;
  /**************************************************************************************************
  功能说明：复核转病单
  luozhiling
  2015.5.5
  **************************************************************************************************/
  procedure P_DiffCheckSave(strEnterpriseNo in odata_check_m.enterprise_no%type,
                            strWareHouseNo  in odata_check_m.warehouse_no%type,
                            strCheckNo      in odata_check_m.check_no%type,
                            strDeliverObj   in odata_check_m.deliver_obj%type,
                            strUserId       in odata_check_m.updt_name%type,
                            strResult       out varchar2) is

    v_Exp_No odata_exp_m.exp_no%type := 'N';
  begin
    strResult := 'N|[P_DiffCheckSave]';

    --对复核单里未回单的明细进行回单；

    update odata_check_label_d t
       set t.status     = '13',
           t.check_name = strUserId,
           t.check_date = sysdate
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWareHouseNo
       and t.check_no = strCheckNo
       and t.deliver_obj = strDeliverObj
       and t.status = '10';

    --对复核单明细进行回单
    update odata_check_d t
       set t.status     = '13',
           t.check_name = strUserId,
           t.check_date = sysdate
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWareHouseNo
       and t.check_no = strCheckNo
       and t.deliver_obj = strDeliverObj
       and t.status = '10';

    --对有差异的原标签做转病单
    for GetLabel in (select distinct owner_no,
                                     lable_no,
                                     container_no,
                                     exp_no
                       from odata_check_label_d
                      where enterprise_no = strEnterpriseNo
                        and warehouse_no = strWareHouseNo
                        and check_no = strCheckNo
                        and deliver_obj = strDeliverObj
                        and article_qty <> real_qty
                      order by exp_no, lable_no) loop

      if v_Exp_No <> GetLabel.Exp_No then
        --转病单
        PKLG_ODATA_EXPCANCEL.P_TurnOdataExpCancel(strEnterPriseNo,
                                                  strWarehouseNo,
                                                  GetLabel.Owner_No,
                                                  GetLabel.Exp_No,
                                                  '3', --复核转病单
                                                  strUserId,
                                                  strResult);
        if substr(strResult, 1, 1) <> 'Y' then
          return;
        end if;

        --单据状态跟踪，转病单
        PKOBJ_ODISPATCH.P_Insert_Odata_Exp_Trace(strEnterPriseNo,
                                                 strWarehouseNo,
                                                 GetLabel.Exp_No,
                                                 COdataExpStatus.ExpTracAllIllness,
                                                 strUserId,
                                                 strResult);
        if substr(strResult, 1, 1) <> 'Y' then
          return;
        end if;
      end if;

      --标签跟踪
      pkobj_label.p_updt_label_status(strEnterpriseNo,
                                      strWarehouseNo,
                                      GetLabel.Container_No,
                                      strUserId,
                                      'C0',
                                      strResult);
      if (substr(strResult, 1, 1) <> 'Y') then
        return;
      end if;

      v_Exp_No := GetLabel.Exp_No;
    end loop;

    --更新复核单头档
    pkobj_odata_check.P_UpdateOdataCheckM(strEnterpriseNo,
                                          strWareHouseNo,
                                          strCheckNo,
                                          strUserId,
                                          strResult);

    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    --复核单转历史
    PKOBJ_ODATA_CHECK.p_insert_Odata_check_log(strEnterpriseNo,
                                               strWareHouseNo,
                                               strCheckNo,
                                               strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    strResult := 'Y|[成功]';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_DiffCheckSave;

  /***********************************************************************************************
   --扫描商品条码-整理容器（电商）--自动封箱，转病单
   功能说明：按复核单上的商品进行复核
   chensr
   2015.5.5
   功能描述：1、根据条码取订单；
             2、若此订单未产生复核标签，新取号
             3、若此订单已有复核标签，复核保存
             4、若整订单扫描完成，自动封箱

  ***********************************************************************************************/
  procedure p_scanArticle_cutBox_sickOrder(strEnterpriseNo  in odata_check_m.enterprise_no%type,
                                           strWareHouseNo   in odata_check_m.warehouse_no%type,
                                           strCheckNo       in odata_check_m.check_no%type,
                                           strTaksNo        in stock_label_m.source_no%type, --任务号或快递单号
                                           strDeliverObj    in odata_check_m.deliver_obj%type, --第一次传N，后面用返回的值
                                           strArticle_No    in odata_check_d.article_no%type, --商品编码
                                           nRealQty         in odata_check_d.real_qty%type, --回单数量
                                           strUserId        in odata_check_m.rgst_name%type,
                                           strDockNo        in ridata_check_m.dock_no%type,
                                           strPrintWayBill  in odata_outstock_m.task_type%type, --是否打印快递面单，0：不打印，1：打印
                                           strPrintPackList in odata_outstock_m.task_type%type, --是否打印装箱清单，0：不打印，1：打印
                                           strPrintInVoice  in odata_outstock_m.task_type%type, --是否打印发票，0：不打印，1：打印
                                           strCheckType     in varchar2, --复核类型：1:按任务复核或箱号；2：快递单号复核
                                           strCloseFlag     out varchar2, --封箱标识，'Y' 完成；‘N'未完成
                                           strOutDeliverObj out stock_label_m.deliver_obj%type,
                                           strOutLabelNo    out stock_label_m.label_no%type,
                                           strPackMateMsg   out bdef_defarticle.article_name%type, --提示的包材名称
                                           strOutFinishFlag out varchar2, --复核完成标识，'Y' 完成；‘N'未完成
                                           strResult        out varchar2) is
    v_iCount          integer := 0;
    v_strDeliverOBJ   odata_check_m.deliver_obj%type := 'N';
    v_Exp_No          odata_exp_m.exp_no%type;
    v_nCurrQty        odata_check_d.real_qty%type;
    v_nRemainQty      odata_check_d.real_qty%type := abs(nRealQty);
    v_QMinPack        bdef_defarticle.qmin_operate_packing%type;
    v_Task_No         varchar2(100) := 'N';
    v_D_Label_No      stock_label_m.label_no%type;
    strPromptPackmate varchar2(1) := '0';
    v_PackMateNo      bdef_defarticle.article_no%type;
    v_CheckStrage     wms_check_strategy.check_strategy_id%type;

    --发票
    v_Print_InVoice_Flag odata_exp_m.print_bill_flag%type;
    v_Print_InVoiceCount odata_exp_m.ENVOICE_PRINT_STATUS%type;

    --清单
    v_Print_PackList_Flag ODATA_LOCATE_BATCH.PRINT_PACKLIST%type;
    v_Print_PackListCount odata_exp_m.packlist_print_status%type;

    --面单
    v_Print_WayBill_Flag ODATA_LOCATE_BATCH.PRINT_WAYBILL%type;
    v_Print_WayBillCount odata_exp_m.waybill_print_status%type;

  begin
    strResult := 'N|[p_scanArticle_cutBox_sickOrder]';

    begin
      select bda.qmin_operate_packing
        into v_QMinPack
        from bdef_defarticle bda
       where bda.enterprise_no = strEnterpriseNo
         and bda.article_no = strArticle_No;
    exception
      when no_data_found then
        strResult := 'N|找不到商品资料-' || strArticle_No;
        return;
    end;

    if nvl(v_QMinPack, 0) <= 0 then
      v_QMinPack := 1;
    end if;

    --换算成最小单位
    v_nRemainQty := v_nRemainQty * v_QMinPack;

    --直接按商品配给任一单
    for GetCheckLabel in (select ocd.deliver_obj,
                                 ocd.article_no,
                                 ocd.packing_qty,
                                 ocd.row_id,
                                 ocd.container_no,
                                 ocd.d_label_no,
                                 sai.barcode,
                                 sai.quality,
                                 sai.produce_date,
                                 sai.expire_date,
                                 sai.lot_no,
                                 sai.rsv_batch1,
                                 sai.rsv_batch2,
                                 sai.rsv_batch3,
                                 sai.rsv_batch4,
                                 sai.rsv_batch5,
                                 sai.rsv_batch6,
                                 sai.rsv_batch7,
                                 sai.rsv_batch8,
                                 ocd.lable_no,
                                 ocd.exp_no,
                                 ocd.exp_id,
                                 ocd.exp_type,
                                 oem.status                exp_status,
                                 oem.print_bill_flag       Print_InVoice_Flag,
                                 OLB.PRINT_PACKLIST        Print_PackList_Flag,
                                 OLB.PRINT_WAYBILL         Print_WayBill_Flag,
                                 OLB.INDUSTRY_FLAG,
                                 OLB.B_CHECK_STRATEGY_ID,
                                 OEM.SHIPPER_DELIVER_NO,
                                 oem.ENVOICE_PRINT_STATUS  Print_InVoiceCount,
                                 oem.PACKLIST_PRINT_STATUS Print_PackListCount,
                                 oem.waybill_print_status  Print_WayBillCount,
                                 ocd.article_qty,
                                 ocd.real_qty
                            from odata_check_label_d ocd,
                                 stock_article_info  sai,
                                 odata_exp_m         oem,
                                 ODATA_LOCATE_BATCH  OLB
                           where olb.enterprise_no = oem.enterprise_no
                             and olb.warehouse_no = oem.warehouse_no
                             and olb.wave_no = oem.wave_no
                             and olb.batch_no = oem.batch_no
                             and ocd.exp_no = oem.exp_no
                             and ocd.exp_type = oem.exp_type
                             and ocd.enterprise_no = sai.enterprise_no
                             and ocd.article_no = sai.article_no
                             and ocd.article_id = sai.article_id
                             and ocd.enterprise_no = strEnterpriseNo
                             and ocd.warehouse_no = strWareHouseNo
                             and ocd.check_no = strCheckNo
                             and ocd.article_no = strArticle_No
                             and ocd.article_qty - ocd.real_qty >= nRealQty
                             and ocd.status < '13'
                             and (strDeliverObj = 'N' or
                                 (strDeliverObj <> 'N' and
                                 ocd.deliver_obj = strDeliverObj))
                           order by ocd.status desc,
                                    oem.status,
                                    ocd.deliver_obj,
                                    oem.print_bill_flag,
                                    OLB.PRINT_PACKLIST,
                                    OLB.PRINT_WAYBILL,
                                    oem.ENVOICE_PRINT_STATUS,
                                    oem.PACKLIST_PRINT_STATUS,
                                    oem.waybill_print_status,
                                    ocd.article_no,
                                    ocd.packing_qty,
                                    sai.barcode,
                                    sai.quality,
                                    sai.produce_date,
                                    sai.expire_date,
                                    sai.lot_no,
                                    sai.rsv_batch1,
                                    sai.rsv_batch2,
                                    sai.rsv_batch3,
                                    sai.rsv_batch4,
                                    sai.rsv_batch5,
                                    sai.rsv_batch6,
                                    sai.rsv_batch7,
                                    sai.rsv_batch8,
                                    ocd.lable_no,
                                    ocd.exp_no,
                                    ocd.exp_type) loop

      --判断单据是否取消
      if GetCheckLabel.exp_status = '16' then
        strResult := 'N|订单' || GetCheckLabel.exp_no || '已取消！';
        return;
      end if;

      if v_iCount = 0 and strDeliverObj = 'N' and
         GetCheckLabel.Industry_Flag = '1' --传统行业
       then
        --新取号
        P_DeliverObjLableNo(strEnterpriseNo,
                            strWareHouseNo,
                            strCheckNo,
                            GetCheckLabel.deliver_obj,
                            'B',
                            strUserId,
                            strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;
      end if;

      --电商行业
      if GetCheckLabel.Industry_Flag = '2' then
        v_D_Label_No := GetCheckLabel.Shipper_Deliver_No;
      else
        v_D_Label_No := GetCheckLabel.Deliver_Obj;
      end if;

      v_iCount := v_iCount + 1;

      --Add BY QZH AT 2016-6-24 一次只处理一个配送对象
      if v_strDeliverOBJ <> GetCheckLabel.deliver_obj and
         v_strDeliverOBJ <> 'N' then
        exit;
      end if;

      strOutLabelNo        := v_D_Label_No;
      v_strDeliverOBJ      := GetCheckLabel.deliver_obj;
      v_Exp_No             := GetCheckLabel.exp_No;
      v_Print_InVoice_Flag := GetCheckLabel.Print_InVoice_Flag;
      v_Print_InVoiceCount := GetCheckLabel.Print_InVoiceCount;

      v_Print_PackList_Flag := GetCheckLabel.Print_PackList_Flag;
      v_Print_PackListCount := GetCheckLabel.Print_PackListCount;

      v_Print_WayBill_Flag := GetCheckLabel.Print_WayBill_Flag;
      v_Print_WayBillCount := GetCheckLabel.Print_WayBillCount;
      v_CheckStrage        := GetCheckLabel.B_CHECK_STRATEGY_ID;

      if nRealQty > 0 then
        --正常扫描，取差异量
        v_nCurrQty := GetCheckLabel.article_qty - GetCheckLabel.real_qty;
        if v_nCurrQty > v_nRemainQty then
          v_nCurrQty := v_nRemainQty;
        end if;

        v_nRemainQty := v_nRemainQty - v_nCurrQty;
      else
        --取消扫描，取已扫描量
        v_nCurrQty := GetCheckLabel.real_qty;

        if v_nCurrQty > v_nRemainQty then
          v_nCurrQty := v_nRemainQty;
        end if;

        v_nRemainQty := v_nRemainQty - v_nCurrQty;
        v_nCurrQty   := v_nCurrQty * -1;
      end if;

      --更新复核标签明细
      PKOBJ_ODATA_CHECK.P_UpdateOdataCheckLabelD(strEnterpriseNo,
                                                 strWareHouseNo,
                                                 strCheckNo,
                                                 GetCheckLabel.container_no,
                                                 v_D_Label_No,
                                                 GetCheckLabel.Row_Id,
                                                 v_nCurrQty,
                                                 strUserId,
                                                 strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --更新复核单明细
      pkobj_odata_check.P_UpdtaOdataCheckD(strEnterpriseNo,
                                           strWareHouseNo,
                                           strCheckNo,
                                           GetCheckLabel.Exp_No,
                                           GetCheckLabel.Exp_Id,
                                           GetCheckLabel.Article_No,
                                           GetCheckLabel.Packing_Qty,
                                           v_nCurrQty,
                                           strUserId,
                                           strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      if v_nRemainQty = 0 then
        exit;
      end if;
    end loop;

    if v_iCount = 0 then
      strResult := 'N|[当前任务不存在此条码]';
      return;
    end if;

    if v_nRemainQty > 0 then
      strResult := 'N|[库存扣减超量]';
      return;
    end if;

    --判断此配送对象是否全部回单
    select count(*)
      into v_iCount
      from odata_check_d ood
     where ood.enterprise_no = strEnterpriseNo
       and ood.warehouse_no = strWareHouseNo
       and ood.check_no = strCheckNo
       and ood.deliver_obj = v_strDeliverOBJ
       and ood.status < '13';

    strOutDeliverObj := v_strDeliverOBJ;
    if v_iCount = 0 then
      --复核完成
      strCloseFlag := 'Y';
      --对此配送对象自动封箱
      P_CLOSEBOX(strEnterPriseNo,
                 strWareHouseNo,
                 strUserId,
                 v_D_Label_No,
                 --strPrinterGroupNo,
                 strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --打印发票
      if v_Print_InVoiceCount <= 0 then
        if v_Print_InVoice_Flag > '0' or strPrintInVoice = '1' then
          PKLG_WMS_Public.p_Insert_SpecialReportTask(strEnterPriseNo,
                                                     strWareHouseNo,
                                                     CREPORT_TYPE.TYPE_INV,
                                                     v_Exp_No, --v_strDeliverOBJ,
                                                     strDockNo,
                                                     '0',
                                                     strUserId,
                                                     v_Task_No,
                                                     strResult);
        end if;
      end if;

      --装箱清单
      if v_Print_PackListCount <= 0 then
        if v_Print_PackList_Flag > '0' or strPrintPackList = '1' then

          PKLG_WMS_Public.p_Insert_SpecialReportTaskExt(strEnterPriseNo,
                                                        strWareHouseNo,
                                                        CREPORT_TYPE.TYPE_BOX,
                                                        v_Exp_No, --v_strDeliverOBJ,
                                                        strDockNo,
                                                        '0',
                                                        strUserId,
                                                        '3', --复核时打印
                                                        'N',
                                                        'N',
                                                        'N',
                                                        'N',
                                                        'N',
                                                        'N',
                                                        'N',
                                                        v_Task_No,
                                                        strResult);
        end if;
      end if;

      --打印面单
      if v_Print_WayBillCount <= 0 then
        if --strCheckType = '1' and
         (v_Print_WayBill_Flag > '0' or strPrintWayBill = '1') then
          --不是按面单扫描
          PKLG_WMS_Public.p_Insert_SpecialReportTask(strEnterPriseNo,
                                                     strWareHouseNo,
                                                     CREPORT_TYPE.TYPE_WAY,
                                                     v_Exp_No, --v_strDeliverOBJ,
                                                     strDockNo,
                                                     '0',
                                                     strUserId,
                                                     v_Task_No,
                                                     strResult);
        end if;
      end if;

      --单据状态跟踪
      PKOBJ_ODISPATCH.P_Insert_Odata_Exp_Trace(strEnterPriseNo,
                                               strWareHouseNo,
                                               v_Exp_No,
                                               COdataExpStatus.ExpTracAllCheck,
                                               strUserID,
                                               strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;
    else
      strCloseFlag := 'N';
      --单据状态跟踪
      PKOBJ_ODISPATCH.P_Insert_Odata_Exp_Trace(strEnterPriseNo,
                                               strWareHouseNo,
                                               v_Exp_No,
                                               COdataExpStatus.ExpTracPartCheck,
                                               strUserID,
                                               strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;
    end if;

    --是否提示建议包材
    begin
      select t.pack_advance
        into strPromptPackmate
        from wms_check_strategy t
       where t.enterprise_no = strEnterpriseNo
         and t.check_type = 'B'
         and t.check_strategy_id = v_CheckStrage;

      if strPromptPackmate = '1' then
        p_getPackMate(strEnterPriseNo,
                      strWareHouseNo,
                      v_D_Label_No,
                      v_PackMateNo,
                      strPackMateMsg,
                      v_iCount, --借用
                      v_Task_No); --借用
      end if;
    end;

    strOutFinishFlag := 'N';
    --判断当前任务是否复核完成

    select count(1)
      into v_iCount
      from stock_label_m m
     where m.source_no = strTaksNo
       and m.enterprise_no = strEnterpriseNo
       and m.warehouse_no = strWareHouseNo;

    --按拣货任务号
    if v_iCount > 0 then
      select count(*)
        into v_iCount
        from odata_check_label_d ocd
       where ocd.enterprise_no = strEnterpriseNo
         and ocd.warehouse_no = strWareHouseNo
         and exists (select 'x'
                from stock_label_d d
               where d.enterprise_no = ocd.enterprise_no
                 and d.warehouse_no = ocd.warehouse_no
                 and d.source_no = strTaksNo
                 and d.exp_no = ocd.exp_no
                 and d.exp_type = ocd.exp_type)
         and ocd.status < '13';
    else
      select count(*)
        into v_iCount
        from odata_check_label_d ocd
       where ocd.enterprise_no = strEnterpriseNo
         and ocd.warehouse_no = strWareHouseNo
         and ocd.lable_no = strTaksNo
         and ocd.status < '13';
    end if;

    if v_iCount <= 0 then
      strOutFinishFlag := 'Y';
    end if;

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_scanArticle_cutBox_sickOrder;

  /*订单取消*/
  procedure p_OrderCancel(strEnterpriseNo in odata_check_m.enterprise_no%type,
                          strWareHouseNo  in odata_check_m.warehouse_no%type,
                          strCheckNo      in odata_check_m.check_no%type, --复核单号
                          strSource_No    in odata_exp_m.shipper_deliver_no%type, --面单号或原订单号
                          strCheckType    in varchar2, --复核类型：1:按原订单号；2：快递单号复核
                          strUserID       in odata_check_m.rgst_name%type,
                          strResult       out varchar2) is
    strExpStatus odata_exp_m.status%type;
  begin

    strResult := 'N|p_OrderCancel';

    --按面单号
    if strCheckType = '2' then
      begin
        select oem.status
          into strExpStatus
          from odata_exp_m oem
         where oem.warehouse_no = strWareHouseNo
           and oem.enterprise_no = strEnterpriseNo
           and oem.shipper_deliver_no = strSource_No;
      exception
        when no_data_found then
          strResult := 'N|面单号' || strSource_No || '不存在';
          return;
      end;

      if strExpStatus <> '16' then
        strResult := 'N|面单号' || strSource_No || '未取消';
        return;
      end if;

      update odata_check_d ocd
         set ocd.status = '16'
       where ocd.warehouse_no = strWareHouseNo
         and ocd.enterprise_no = strEnterpriseNo
         and ocd.check_no = strCheckNo
         and exists
       (select 'x'
                from odata_exp_m oem
               where oem.enterprise_no = ocd.enterprise_no
                 and oem.warehouse_no = ocd.warehouse_no
                 and oem.exp_type = ocd.exp_type
                 and oem.exp_no = ocd.exp_no
                 and oem.shipper_deliver_no = strSource_No);

      if sql%rowcount > 0 then

        insert into odata_check_dhty
          (enterprise_no,
           warehouse_no,
           owner_no,
           exp_no,
           exp_type,
           exp_date,
           check_no,
           article_no,
           packing_qty,
           plan_qty,
           article_qty,
           real_qty,
           status,
           rgst_name,
           rgst_date,
           check_name,
           check_date,
           deliver_obj)
          select enterprise_no,
                 warehouse_no,
                 owner_no,
                 exp_no,
                 exp_type,
                 exp_date,
                 check_no,
                 article_no,
                 packing_qty,
                 plan_qty,
                 article_qty,
                 real_qty,
                 status,
                 rgst_name,
                 rgst_date,
                 check_name,
                 check_date,
                 deliver_obj
            from odata_check_d ocd
           where ocd.warehouse_no = strWareHouseNo
             and ocd.enterprise_no = strEnterpriseNo
             and ocd.check_no = strCheckNo
             and ocd.status = '16'
             and exists
           (select 'x'
                    from odata_exp_m oem
                   where oem.enterprise_no = ocd.enterprise_no
                     and oem.warehouse_no = ocd.warehouse_no
                     and oem.exp_type = ocd.exp_type
                     and oem.exp_no = ocd.exp_no
                     and oem.shipper_deliver_no = strSource_No);

        delete from odata_check_d ocd
         where ocd.warehouse_no = strWareHouseNo
           and ocd.enterprise_no = strEnterpriseNo
           and ocd.check_no = strCheckNo
           and ocd.status = '16'
           and exists
         (select 'x'
                  from odata_exp_m oem
                 where oem.enterprise_no = ocd.enterprise_no
                   and oem.warehouse_no = ocd.warehouse_no
                   and oem.exp_type = ocd.exp_type
                   and oem.exp_no = ocd.exp_no
                   and oem.shipper_deliver_no = strSource_No);

      end if;

      update odata_check_label_d ocd
         set ocd.status = '16'
       where ocd.warehouse_no = strWareHouseNo
         and ocd.enterprise_no = strEnterpriseNo
         and ocd.check_no = strCheckNo
         and exists
       (select 'x'
                from odata_exp_m oem
               where oem.enterprise_no = ocd.enterprise_no
                 and oem.warehouse_no = ocd.warehouse_no
                 and oem.exp_type = ocd.exp_type
                 and oem.exp_no = ocd.exp_no
                 and oem.shipper_deliver_no = strSource_No);

      if sql%rowcount > 0 then

        insert into odata_check_label_dhty
          (enterprise_no,
           warehouse_no,
           owner_no,
           check_no,
           row_id,
           lable_no,
           divide_id,
           container_no,
           exp_no,
           exp_type,
           exp_date,
           article_no,
           packing_qty,
           article_id,
           article_qty,
           real_qty,
           status,
           check_name,
           check_date,
           d_label_no,
           deliver_obj,
           rgst_date) --添加rgst_date字段 2016-9-22 heym
          select enterprise_no,
                 warehouse_no,
                 owner_no,
                 check_no,
                 row_id,
                 lable_no,
                 divide_id,
                 container_no,
                 exp_no,
                 exp_type,
                 exp_date,
                 article_no,
                 packing_qty,
                 article_id,
                 article_qty,
                 real_qty,
                 status,
                 check_name,
                 check_date,
                 d_label_no,
                 deliver_obj,
                 rgst_date --添加rgst_date字段 2016-9-22 heym
            from odata_check_label_d ocd
           where ocd.warehouse_no = strWareHouseNo
             and ocd.enterprise_no = strEnterpriseNo
             and ocd.check_no = strCheckNo
             and ocd.status = '16'
             and exists
           (select 'x'
                    from odata_exp_m oem
                   where oem.enterprise_no = ocd.enterprise_no
                     and oem.warehouse_no = ocd.warehouse_no
                     and oem.exp_type = ocd.exp_type
                     and oem.exp_no = ocd.exp_no
                     and oem.shipper_deliver_no = strSource_No);

        delete from odata_check_label_d ocd
         where ocd.warehouse_no = strWareHouseNo
           and ocd.enterprise_no = strEnterpriseNo
           and ocd.check_no = strCheckNo
           and ocd.status = '16'
           and exists
         (select 'x'
                  from odata_exp_m oem
                 where oem.enterprise_no = ocd.enterprise_no
                   and oem.warehouse_no = ocd.warehouse_no
                   and oem.exp_type = ocd.exp_type
                   and oem.exp_no = ocd.exp_no
                   and oem.shipper_deliver_no = strSource_No);

      end if;

      for curLabel in (select distinct slm.label_no
                         from stock_label_d sld, stock_label_m slm
                        where slm.enterprise_no = sld.enterprise_no
                          and slm.warehouse_no = sld.warehouse_no
                          and slm.container_no = sld.container_no
                          and exists
                        (select 'x'
                                 from odata_exp_m oem
                                where oem.shipper_deliver_no = strSource_No
                                  and oem.enterprise_no = strEnterpriseNo
                                  and oem.warehouse_no = strWareHouseNo
                                  and oem.enterprise_no = sld.enterprise_no
                                  and oem.warehouse_no = sld.warehouse_no
                                  and oem.exp_type = sld.exp_type
                                  and oem.exp_no = sld.exp_no)) loop

        PKLG_ODATA_EXPCANCEL.P_Cancel_LabeltoMove(strEnterpriseNo,
                                                  strWareHouseNo,
                                                  curLabel.label_no,
                                                  strUserID,
                                                  strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;
      end loop;
    end if;

    --按原单号
    if strCheckType = '1' then
      begin
        select oem.status
          into strExpStatus
          from odata_exp_m oem
         where oem.warehouse_no = strWareHouseNo
           and oem.enterprise_no = strEnterpriseNo
           and oem.exp_no = strSource_No;
      exception
        when no_data_found then
          strResult := 'N|订单号' || strSource_No || '不存在';
          return;
      end;

      if strExpStatus <> '16' then
        strResult := 'N|订单号' || strSource_No || '未取消';
        return;
      end if;

      update odata_check_d ocd
         set ocd.status = '16'
       where ocd.warehouse_no = strWareHouseNo
         and ocd.enterprise_no = strEnterpriseNo
         and ocd.check_no = strCheckNo
         and ocd.exp_no = strSource_No;

      if sql%rowcount > 0 then
        insert into odata_check_dhty
          (enterprise_no,
           warehouse_no,
           owner_no,
           exp_no,
           exp_type,
           exp_date,
           check_no,
           article_no,
           packing_qty,
           plan_qty,
           article_qty,
           real_qty,
           status,
           rgst_name,
           rgst_date,
           check_name,
           check_date,
           deliver_obj)
          select enterprise_no,
                 warehouse_no,
                 owner_no,
                 exp_no,
                 exp_type,
                 exp_date,
                 check_no,
                 article_no,
                 packing_qty,
                 plan_qty,
                 article_qty,
                 real_qty,
                 status,
                 rgst_name,
                 rgst_date,
                 check_name,
                 check_date,
                 deliver_obj
            from odata_check_d ocd
           where ocd.warehouse_no = strWareHouseNo
             and ocd.enterprise_no = strEnterpriseNo
             and ocd.check_no = strCheckNo
             and ocd.exp_no = strSource_No
             and ocd.status = '16';

        delete from odata_check_d ocd
         where ocd.warehouse_no = strWareHouseNo
           and ocd.enterprise_no = strEnterpriseNo
           and ocd.check_no = strCheckNo
           and ocd.exp_no = strSource_No
           and ocd.status = '16';
      end if;

      update odata_check_label_d ocd
         set ocd.status = '16'
       where ocd.warehouse_no = strWareHouseNo
         and ocd.enterprise_no = strEnterpriseNo
         and ocd.check_no = strCheckNo
         and ocd.exp_no = strSource_No;

      if sql%rowcount > 0 then

        insert into odata_check_label_dhty
          (enterprise_no,
           warehouse_no,
           owner_no,
           check_no,
           row_id,
           lable_no,
           divide_id,
           container_no,
           exp_no,
           exp_type,
           exp_date,
           article_no,
           packing_qty,
           article_id,
           article_qty,
           real_qty,
           status,
           check_name,
           check_date,
           d_label_no,
           deliver_obj,
           rgst_date) --添加rgst_date字段 2016-9-22 heym
          select enterprise_no,
                 warehouse_no,
                 owner_no,
                 check_no,
                 row_id,
                 lable_no,
                 divide_id,
                 container_no,
                 exp_no,
                 exp_type,
                 exp_date,
                 article_no,
                 packing_qty,
                 article_id,
                 article_qty,
                 real_qty,
                 status,
                 check_name,
                 check_date,
                 d_label_no,
                 deliver_obj,
                 rgst_date --添加rgst_date字段 2016-9-22 heym
            from odata_check_label_d ocd
           where ocd.warehouse_no = strWareHouseNo
             and ocd.enterprise_no = strEnterpriseNo
             and ocd.check_no = strCheckNo
             and ocd.exp_no = strSource_No
             and ocd.status = '16';

        delete from odata_check_label_d ocd
         where ocd.warehouse_no = strWareHouseNo
           and ocd.enterprise_no = strEnterpriseNo
           and ocd.check_no = strCheckNo
           and ocd.exp_no = strSource_No
           and ocd.status = '16';
      end if;

      for curLabel in (select distinct slm.label_no
                         from stock_label_d sld, stock_label_m slm
                        where slm.enterprise_no = sld.enterprise_no
                          and slm.warehouse_no = sld.warehouse_no
                          and slm.container_no = sld.container_no
                          and sld.exp_no = strSource_No
                          and slm.enterprise_no = strEnterpriseNo
                          and slm.warehouse_no = strWarehouseNo) loop

        PKLG_ODATA_EXPCANCEL.P_Cancel_LabeltoMove(strEnterpriseNo,
                                                  strWareHouseNo,
                                                  curLabel.label_no,
                                                  strUserID,
                                                  strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;
      end loop;
    end if;
    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_OrderCancel;

  /***********************************************************************************************
   对转病单的标签进行解锁
   chensr
   2015.5.5
  ***********************************************************************************************/
  procedure P_UnlockLabel(strEnterpriseNo in stock_label_m.Enterprise_No%type,
                          strWarehouseNo  in stock_label_m.Warehouse_No%type,
                          strDeliverObj   in stock_label_m.source_no%type,
                          strWorkerNo     in stock_label_m.rgst_name%type,
                          strResult       out varchar2) is
  begin
    strResult := 'N|[P_UnlockLabel]';

    for GetLabelNo in (select container_no
                         from stock_label_m
                        where enterprise_no = strEnterPriseNo
                          and warehouse_no = strWareHouseNo
                          AND deliver_obj = strDeliverObj
                          and status = CLabelStatus.OM_CANCEL_Lock) loop
      --更新标签明细表状态
      PKOBJ_label.p_updt_labelDetail_status(strEnterPriseNo,
                                            strWarehouseNo,
                                            GetLabelNo.container_no,
                                            strWorkerNo,
                                            CLabelStatus.INNER_CHECKING,
                                            strResult);

      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;

      --更新标签头档表状态
      PKOBJ_label.p_updt_label_status(strEnterPriseNo,
                                      strWarehouseNo,
                                      GetLabelNo.container_no,
                                      strWorkerNo,
                                      CLabelStatus.INNER_CHECKING,
                                      strResult);

      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;
    end loop;

    strResult := 'Y|[P_UnlockLabel]';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_UnlockLabel;
  /*****************************************************************************************
   功能：传统行业复核出货整理扫描条码保存商品(根据箱号)
  chensr 2015-06-26
  1、扫描时只做复核回单，
  2、当整单扫描完成后，系统需自动封箱，并打印封箱标签
  调用 P_CheckArticle 增加返回错误 huangb 20160602
  *****************************************************************************************/
  procedure P_scanArticle_by_labelNo(strEnterpriseNo in odata_check_m.enterprise_no%type,
                                     strWareHouseNo  in odata_check_m.warehouse_no%type,
                                     strCheckNo      in odata_check_m.check_no%type,
                                     strArticle_No   in odata_check_d.article_no%type, --商品编码
                                     nPacking_QTY    in odata_check_d.packing_qty%type, --包装数量
                                     strQuality      in stock_article_info.quality%type, --品质
                                     dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                                     dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                                     strLotNo        in stock_article_info.lot_no%type, --批次号
                                     strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                                     strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                                     strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                                     strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                                     strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                                     strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                                     strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                                     strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                                     strBarcode      in stock_article_info.barcode%type,
                                     strsLabelNo     in stock_label_m.label_no%type, --来源标签
                                     strDLabelNo     in stock_label_m.label_no%type, --目的标签
                                     nRealQty        in odata_check_d.real_qty%type, --回单数量
                                     strUserId       in odata_check_m.rgst_name%type,
                                     strDockNo       in bdef_defdock.dock_no%type,
                                     strResult       out varchar2) is
    v_iCount         integer;
    v_strCheckStatus odata_check_m.status%type;
    v_strDeliverObj  odata_check_m.deliver_obj%type;
    v_QMinPack       bdef_defarticle.qmin_operate_packing%type;
    v_nRemainQty     odata_check_d.real_qty%type := nRealQty;
  begin
    strResult := 'N|[P_scanArticle_by_labelNo]';

    --校验复核单状态
    begin
      select status, deliver_obj
        into v_strCheckStatus, v_strDeliverObj
        from odata_check_m
       where enterprise_no = strEnterpriseNo
         and warehouse_no = strWareHouseNo
         and check_no = strCheckNo;
      if v_strCheckStatus = '12' then
        strResult := 'N[已回单的复核单不可扫描]';
        return;
      end if;
    exception
      when no_data_found then
        strResult := 'N|[找不到复核单]';
        return;
    end;

    begin
      select bda.qmin_operate_packing
        into v_QMinPack
        from bdef_defarticle bda
       where bda.enterprise_no = strEnterpriseNo
         and bda.article_no = strArticle_No;
    exception
      when no_data_found then
        strResult := 'N|找不到商品资料-' || strArticle_No;
        return;
    end;

    if nvl(v_QMinPack, 0) <= 0 then
      v_QMinPack := 1;
    end if;

    --换算成最小单位
    v_nRemainQty := v_nRemainQty * v_QMinPack;

    --校验原标签是否可复核到目的标签
    PKLG_ODATA_MOVE_JUN.P_check_SAndDLabel(strEnterpriseNo,
                                           strWarehouseNo,
                                           strSLabelNo,
                                           strDLabelNo,
                                           strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    --整理容器
    P_CheckArticle(strEnterpriseNo,
                   strWareHouseNo,
                   strCheckNo,
                   v_strDeliverObj,
                   strArticle_No,
                   nPacking_QTY,
                   strQuality,
                   dtProduceDate,
                   dtExpireDate,
                   strLotNo,
                   strRSV_BATCH1,
                   strRSV_BATCH2,
                   strRSV_BATCH3,
                   strRSV_BATCH4,
                   strRSV_BATCH5,
                   strRSV_BATCH6,
                   strRSV_BATCH7,
                   strRSV_BATCH8,
                   strBarcode,
                   strSLabelNo,
                   strDLabelNo,
                   v_nRemainQty,
                   strUserId,
                   strResult);
    if (substr(strResult, 1, 1) <> 'Y') then
      return;
    end if;

    --判断复核单是否全部回单
    select count(*)
      into v_iCount
      from odata_check_label_d ocd
     where ocd.enterprise_no = strEnterpriseNo
       and ocd.warehouse_no = strWareHouseNo
       and ocd.check_no = strCheckNo
       and ocd.article_qty > ocd.real_Qty;

    --将复核单转历史
    if v_iCount = 0 then
      --此复核单全部扫描完成
      update odata_check_m t
         set t.status = '12'
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.check_no = strCheckNo;
    end if;
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_scanArticle_by_labelNo;

  /*****************************************************************************************
    功能：传统行业复核的取消扫描、只能在未封箱之前做
    201511.05
  *****************************************************************************************/
  procedure p_CancelScanLabel(strEnterPriseNo in stock_label_m.enterprise_no%type,
                              strWareHouseNo  in stock_label_m.warehouse_no%type, --仓别
                              strUserId       in stock_label_m.rgst_name%type, --封箱人
                              strCheckNo      in odata_check_m.check_no%type,
                              strLabelNo      in stock_label_m.label_no%type, --标签号
                              strResult       out varchar2) is
    v_iCount integer := 0;
  begin
    strResult := 'N|[p_CancelScanLabel]';
    --

    select count(*)
      into v_iCount
      from odata_check_m t
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWareHouseNo
       and t.check_no = strCheckNo
       and t.status = '12';

    if v_iCount = 1 then
      strResult := 'N|[该标签对应的复核单已回单，不可重扫]';
      return;
    end if;

    select count(*)
      into v_iCount
      from odata_check_label_d t
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWareHouseNo
       and t.Lable_No = strLabelNo
       and t.check_no <> strCheckNo;

    if v_iCount > 0 then
      strResult := 'N|[此标签已存在多张复核单的商品，不可重扫]';
      return;
    end if;

    for GetLabelItem in (select *
                           from odata_check_label_d t
                          where t.enterprise_no = strEnterPriseNo
                            and t.warehouse_no = strWareHouseNo
                            and t.d_label_no = strLabelNo
                            and t.check_no = strCheckNo
                            and status < '13') loop
      v_iCount := v_iCount + 1;

      update odata_check_label_d t
         set t.real_qty = t.real_qty - GetLabelItem.real_qty
       where t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strWareHouseNo
         and t.check_no = strCheckNo
         and t.row_id = GetLabelItem.row_id
         and t.d_label_no = strLabelNo;

      update odata_check_d t
         set t.status     = '10',
             t.real_qty   = t.real_qty - GetLabelItem.real_qty,
             t.check_name = strUserId
       where t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strWareHouseNo
         and t.check_no = strCheckNo
         and t.owner_no = GetLabelItem.owner_no
         and t.exp_no = GetLabelItem.exp_no
         and t.article_no = GetLabelItem.article_no
         and t.packing_qty = GetLabelItem.packing_qty;

    end loop;

    if v_iCount = 0 then
      strResult := 'N|找不到标签明细';
      return;
    end if;
    strResult := 'Y|[]';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_CancelScanLabel;

  /*****************************************************************************************
    功能：复核封箱后打标签（天天惠）、
    20150703
    chensr
    修改说明：2015.11.4,转移标签明细和库存
  *****************************************************************************************/
  procedure P_ODATA_CHECK_CUTBOX(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                 strWareHouseNo  in stock_label_m.warehouse_no%type, --仓别
                                 strUserId       in stock_label_m.rgst_name%type, --封箱人
                                 strLabelNo      in stock_label_m.label_no%type, --标签号
                                 strDockNo       in ridata_check_m.dock_no%type,
                                 strResult       out varchar2) is
    v_strPrtTask ridata_instock_d.instock_no%type;
    --v_iCount     integer := 0;
    --v_UpdateFlag boolean := false;
  begin
    strResult := 'N|[P_ODATA_CHECK_CUTBOX]';

    P_ODATA_CHECK_CLOSEBOX(strEnterPriseNo,
                           strWareHouseNo,
                           strUserId,
                           strLabelNo,
                           --strPrinterGroupNo,
                           strResult);

    if substr(strResult, 1, 1) <> 'Y' then
      return;
    end if;

    --写打印任务头档
    PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterPriseNo,
                                        strWareHouseNo,
                                        strLabelNo,
                                        0,
                                        CONST_REPORTID.B_CLOSECustBOX,
                                        strDockNo,
                                        0,
                                        strUserId,
                                        v_strPrtTask,
                                        strResult);
    if substr(strResult, 1, 1) <> 'Y' then
      return;
    end if;

    --写打印任务头档
    PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterPriseNo,
                                        strWareHouseNo,
                                        strLabelNo,
                                        0,
                                        CONST_REPORTID.RPT_BOXITEM,
                                        strDockNo,
                                        0,
                                        strUserId,
                                        v_strPrtTask,
                                        strResult);
    if substr(strResult, 1, 1) <> 'Y' then
      return;
    end if;

    strResult := 'Y|[成功]';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_ODATA_CHECK_CUTBOX;

  /*****************************************************************************************
    功能：复核封箱-电商，写标签和库存
  *****************************************************************************************/
  procedure P_CLOSEBOX(strEnterPriseNo in stock_label_m.enterprise_no%type,
                       strWareHouseNo  in stock_label_m.warehouse_no%type, --仓别
                       strUserId       in stock_label_m.rgst_name%type, --封箱人
                       strLabelNo      in stock_label_m.label_no%type, --标签号
                       strResult       out varchar2) is
    v_strContainerNo     stock_label_m.container_no%type; --容器号
    v_dContainer_No      stock_label_m.container_no%type; --容器号
    v_strLabelNo         stock_label_m.label_no%type; --板号
    v_strStockValue      stock_content.stock_value%type;
    v_strCellId          stock_content.cell_id%type;
    v_iCount             integer := 0;
    v_dStatus            stock_label_m.status%type;
    v_strOwner_No        bdef_defowner.owner_no%type;
    v_ExpType            odata_exp_m.exp_type%type;
    v_sStatus            stock_label_m.status%type;
    v_strFlowFlag        wms_outorder_flow_d.flow_flag%type;
    v_strScontainerNo    stock_label_m.container_no%type;
    v_strAutoFlag        wms_deflabel_status.must_run%type;
    v_strCheck_No        odata_check_d.check_no%type;
    v_CheckStrage        wms_check_strategy.check_strategy_id%type;
    v_strAutoComfireFlag wms_check_strategy.auto_comfire_flag%type;
  begin

    --更新标签明细状态
    update odata_check_label_d t
       set t.status = '13'
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWareHouseNo
       and t.d_label_no = strLabelNo;

    --循环复核单明细
    for i_MoveLabel_Info in (select slm.container_no        as s_container_no,
                                    slml.enterprise_no,
                                    slml.warehouse_no,
                                    slml.owner_no,
                                    slml.exp_type,
                                    slml.article_no,
                                    slml.check_no,
                                    slml.article_id,
                                    slml.row_id,
                                    slml.real_qty,
                                    slml.packing_qty,
                                    slm.owner_cell_no       as s_owner_cell_no,
                                    dlm.owner_cell_no       as d_owner_cell_no,
                                    slm.container_type,
                                    dlm.cust_no,
                                    slm.label_no            as s_label_no,
                                    dlm.label_no            as d_label_no,
                                    dlm.container_no        as d_container_no,
                                    dlm.status              as d_label_status,
                                    slm.status              as s_label_status,
                                    dlm.stock_type,
                                    slm.hm_manual_flag,
                                    olb.b_check_strategy_id
                               from odata_check_label_d slml,
                                    stock_label_m       slm,
                                    stock_label_m       dlm,
                                    odata_locate_batch  olb
                              where slml.warehouse_no = slm.warehouse_no
                                and slml.enterprise_no = slm.enterprise_no
                                and slml.container_no = slm.container_no
                                and slml.warehouse_no = dlm.warehouse_no
                                and slml.enterprise_no = dlm.enterprise_no
                                and slml.d_label_no = dlm.label_no
                                and slm.enterprise_no = olb.enterprise_no
                                and slm.warehouse_no = olb.warehouse_no
                                and slm.wave_no = olb.wave_no
                                and slm.batch_no = olb.batch_no
                                and slm.enterprise_no = strEnterpriseNo
                                and dlm.label_no = strLabelNo) loop

      -------------------是否储位库存，------------------------------
      if i_MoveLabel_Info.Hm_Manual_Flag = '1' then
        v_strContainerNo := 'N'; --储位库存
        v_strLabelNo     := 'N'; --储位库存
      else
        v_strContainerNo := i_MoveLabel_Info.s_Container_No; --标签库存
        v_strLabelNo     := i_MoveLabel_Info.s_Label_No; --标签库存
      end if;

      if (i_MoveLabel_Info.Stock_Type = 2) then
        --客户别数据 库存表需要写n_Stock_Value值
        v_strStockValue := i_MoveLabel_Info.Cust_No;
      else
        v_strStockValue := 'N';
      end if;

      if i_MoveLabel_Info.s_Container_No <> i_MoveLabel_Info.d_Container_No then

        --增加目的库存 没有预上数量
        PKOBJ_STOCK.p_InstContent_qtyByCellNo(i_MoveLabel_Info.Enterprise_No, --
                                              i_MoveLabel_Info.Warehouse_No, --仓别
                                              i_MoveLabel_Info.Owner_No, --货主
                                              'N', --部门
                                              i_MoveLabel_Info.Article_No, --商品编码
                                              i_MoveLabel_Info.Article_Id, --商品ID
                                              i_MoveLabel_Info.d_Owner_Cell_No, --目的储位
                                              i_MoveLabel_Info.s_Owner_Cell_No, --源储位
                                              i_MoveLabel_Info.Packing_Qty, --包装数量
                                              i_MoveLabel_Info.Real_Qty, --转移数量
                                              i_MoveLabel_Info.d_Label_No, --目的标签
                                              i_MoveLabel_Info.d_Label_No, --目的标签
                                              i_MoveLabel_Info.Stock_Type, --存储类型
                                              v_strStockValue, --存储类型的值
                                              strUserId, --操作人
                                              i_MoveLabel_Info.Check_No, --复核单号
                                              '1', --操作工具
                                              0, --是否可手工移库 0:不允许手工移库；1：可手工移库
                                              v_strCellId, --返回的储位ID
                                              strResult --返回的结果
                                              );
        if (substr(strResult, 1, 1) <> 'Y') then
          return;
        end if;

        --扣减源库存 循环扣减, 不处理预约上下架量，直接扣减库存
        PKOBJ_STOCK.p_UpdtContent_qtyByCellNo(i_MoveLabel_Info.Enterprise_No, --
                                              i_MoveLabel_Info.Warehouse_No, --仓别
                                              i_MoveLabel_Info.Owner_No, --货主
                                              i_MoveLabel_Info.Article_No, --商品编码
                                              i_MoveLabel_Info.Article_Id, --商品ID
                                              i_MoveLabel_Info.s_Owner_Cell_No, --源储位
                                              i_MoveLabel_Info.d_Owner_Cell_No, --目的储位
                                              i_MoveLabel_Info.Packing_Qty, --包装数量
                                              i_MoveLabel_Info.Real_Qty, --转移数量
                                              i_MoveLabel_Info.s_Label_No, --源标签
                                              i_MoveLabel_Info.Stock_Type, --存储类型
                                              v_strStockValue, --存储类型的值
                                              strUserId, --操作人
                                              i_MoveLabel_Info.Check_No, --整理单号
                                              '1', --操作工具
                                              strResult); --返回结果
        if (substr(strResult, 1, 1) <> 'Y') then
          return;
        end if;

        --标签明细转移
        pkobj_label.proc_om_ArrangeByCheck_No(i_MoveLabel_Info.Enterprise_No,
                                              i_MoveLabel_Info.Warehouse_No,
                                              i_MoveLabel_Info.Owner_No,
                                              i_MoveLabel_Info.check_no,
                                              i_MoveLabel_Info.s_Container_No,
                                              i_MoveLabel_Info.Real_Qty,
                                              i_MoveLabel_Info.Row_Id,
                                              strUserId,
                                              strResult);

        if (substr(strResult, 1, 1) <> 'Y') then
          return;
        end if;
      end if;

      v_strScontainerNo := i_MoveLabel_Info.s_Container_No;
      v_strOwner_No     := i_MoveLabel_Info.Owner_No;
      v_dContainer_No   := i_MoveLabel_Info.d_Container_No;
      v_ExpType         := i_MoveLabel_Info.Exp_Type;
      v_dStatus         := i_MoveLabel_Info.d_Label_Status;
      v_sStatus         := i_MoveLabel_Info.s_label_Status;
      v_strCheck_No     := i_MoveLabel_Info.Check_No;
      v_CheckStrage     := i_MoveLabel_Info.B_CHECK_STRATEGY_ID;

      v_iCount := v_iCount + 1;
    end loop;

    if v_iCount <= 0 then
      strResult := 'N|找不到需要封箱的库存';
      return;
    end if;

    --获取是否自动确认配置
    begin
      select t.auto_comfire_flag
        into v_strAutoComfireFlag
        from wms_check_strategy t
       where t.enterprise_no = strEnterpriseNo
         and t.check_type = 'B'
         and t.check_strategy_id = v_CheckStrage;
    exception
      when no_data_found then
        strResult := 'N|[读取不到复核策略]';
        return;
    end;

    --if v_dStatus = CLabelStatus.NEW_LABEL_NO then
    --判断当前工作流是否执行状态
    if v_strAutoComfireFlag = '1' then

      PKOBJ_WorkFlow.p_getlabelnoFlow(strEnterPriseNo,
                                      strWarehouseNo,
                                      v_strOwner_No,
                                      v_ExpType,
                                      v_strScontainerNo,
                                      v_strFlowFlag,
                                      strResult);
      if (substr(strResult, 1, 1) <> 'Y') then
        return;
      end if;

      if v_strFlowFlag = '0' then
        v_dStatus := v_sStatus;
      else
        PKOBJ_WorkFlow.p_GetLabelStatusFromWorkflow(strEnterPriseNo,
                                                    strWarehouseNo,
                                                    v_strOwner_No,
                                                    v_ExpType,
                                                    v_strScontainerNo,
                                                    v_dStatus,
                                                    v_strAutoFlag,
                                                    strResult);
        if (substr(strResult, 1, 1) <> 'Y') then
          return;
        end if;
      end if;
    else
      v_dStatus := CLabelStatus.INNER_CHECKED;
    end if;

    --更新标签状态
    pkobj_label.p_updt_label_status(strEnterpriseNo,
                                    strWarehouseNo,
                                    v_dContainer_No,
                                    strUserId,
                                    v_dStatus,
                                    strResult);
    if (substr(strResult, 1, 1) <> 'Y') then
      return;
    end if;

    pkobj_label.p_updt_labelDetail_status(strEnterpriseNo,
                                          strWarehouseNo,
                                          v_dContainer_No,
                                          strUserId,
                                          v_dStatus,
                                          strResult);
    if (substr(strResult, 1, 1) <> 'Y') then
      return;
    end if;



    --销毁空标签头
    PKOBJ_LABEL.proc_OM_Destory_NullLabel(strEnterpriseNo,
                                          strWarehouseNo, --仓别
                                          v_strScontainerNo, --容器号
                                          strUserId, --操作人
                                          strResult --返回结果
                                          );
    if (substr(strResult, 1, 1) <> 'Y') then
      return;
    end if;

    select count(*)
      into v_iCount
      from odata_check_label_d t
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWareHouseNo
       and t.check_no = v_strCheck_No
       and t.status < '13';

    if v_iCount <= 0 then

      PKOBJ_ODATA_CHECK.P_UpdateOdataCheckM(strEnterpriseNo,
                                            strWareHouseNo,
                                            v_strCheck_No,
                                            strUserId,
                                            strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      PKOBJ_ODATA_CHECK.p_insert_Odata_check_log(strEnterpriseNo,
                                                 strWareHouseNo,
                                                 v_strCheck_No,
                                                 strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
    end if;

    strResult := 'Y|[成功]';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_CLOSEBOX;

  /*****************************************************************************************
    功能：复核封箱
          1、将已复核的数据和未复核数据剥离开，并对已复核数据置复核完成状态；
          2、根据目的标签号写库存和标签，并更新标签状态
  *****************************************************************************************/
  procedure P_ODATA_CHECK_CLOSEBOX(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                   strWareHouseNo  in stock_label_m.warehouse_no%type, --仓别
                                   strUserId       in stock_label_m.rgst_name%type, --封箱人
                                   strLabelNo      in stock_label_m.label_no%type, --标签号
                                   --strPrinterGroupNo in ridata_check_m.printer_group_no%type,
                                   strResult out varchar2) is
    --v_strPrtTask ridata_instock_d.instock_no%type;
    v_iCount     integer := 0;
    v_UpdateFlag boolean := false;
  begin
    strResult := 'N|[P_ODATA_CHECK_CLOSEBOX]';

    --剥离标签明细
    for GetLableItem in (select *
                           from odata_check_label_d t
                          where t.enterprisE_no = strEnterPriseNo
                            and t.warehouse_no = strWareHouseNo
                            and t.d_label_no = strLabelNo
                            and t.status < '13'
                            and t.real_qty > 0
                            and t.article_qty - t.real_qty > 0) loop

      PKOBJ_ODATA_CHECK.P_SaveOdataCheckLabelD(strEnterpriseNo,
                                               strWareHouseNo,
                                               GetLableItem.check_no,
                                               GetLableItem.container_no,
                                               strLabelNo,
                                               GetLableItem.row_id,
                                               GetLableItem.article_qty -
                                               GetLableItem.real_qty,
                                               strUserId,
                                               strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      update odata_check_label_d t
         set t.article_qty = GetLableItem.real_qty
       where enterprise_no = strEnterPriseNo
         and warehouse_no = strWareHouseNo
         and check_no = GetLableItem.check_no
         and row_id = GetLableItem.row_id;

    end loop;

    P_CLOSEBOX(strEnterPriseNo,
               strWareHouseNo,
               strUserId,
               strLabelNo,
               strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    --更新复核明细
    update odata_check_label_d t
       set t.status = '13'
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWareHouseNo
       and t.d_label_no = strLabelNo
       and t.d_label_no <> 'N'
       and t.real_qty > 0;

    --循环处理复核单
    for GetCheck in (select ocm.check_no, ocm.status
                       from odata_check_m ocm
                      where ocm.enterprise_no = strEnterpriseNo
                        and ocm.warehouse_no = strWareHouseNo
                        and exists
                      (select 'x'
                               from odata_check_label_d ocd
                              where ocd.check_no = ocm.check_no
                                and enterprise_no = strEnterPriseNo
                                and warehouse_no = strWareHouseNo
                                and d_label_no = strLabelNo)) loop

      v_UpdateFlag := false;
      --首先该单判断是否全部完成
      if GetCheck.Status = '12' then
        v_UpdateFlag := True;

        update odata_check_label_d t
           set t.status = '13'
         where t.status < '13'
           and t.enterprise_no = strEnterPriseNo
           and t.warehouse_no = strWareHouseNo
           and t.check_no = GetCheck.check_no;

      else
        select count(*)
          into v_iCount
          from odata_check_label_d t
         where t.enterprise_no = strEnterPriseNo
           and t.warehouse_no = strWareHouseNo
           and t.check_no = GetCheck.check_no
           and t.status < '13';

        if v_iCount = 0 then
          v_UpdateFlag := True;
        end if;
      end if;

      if v_UpdateFlag = true then
        PKOBJ_ODATA_CHECK.P_UpdateOdataCheckM(strEnterpriseNo,
                                              strWareHouseNo,
                                              GetCheck.check_no,
                                              strUserId,
                                              strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        PKOBJ_ODATA_CHECK.p_insert_Odata_check_log(strEnterpriseNo,
                                                   strWareHouseNo,
                                                   GetCheck.check_no,
                                                   strResult);
        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;
      end if;
    end loop;

    strResult := 'Y|[成功]';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_ODATA_CHECK_CLOSEBOX;

  /*****************************************************************************************
    功能：复核封箱回单（天天惠）
    20151010
    chensr
  *****************************************************************************************/
  procedure P_PROC_Receipt(strEnterPriseNo in stock_label_m.enterprise_no%type,
                           strWareHouseNo  in stock_label_m.warehouse_no%type, --仓别
                           strCheckNo      in odata_check_m.check_no%type,
                           strResult       out varchar2) is
    v_iCount integer := 0;
  begin
    strResult := 'Y|';
    --判断是否整单都已做封箱
    select count(*)
      into v_iCount
      from odata_check_label_d t
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWareHouseNo
       and t.check_no = strCheckNo
       and t.real_qty > 0
       and t.d_label_no <> 'N'
       and t.status < '13';

    if v_iCount > 0 then
      --更新复核单头档--扫描完成
      update odata_check_m t
         set t.status = '12', t.updt_date = sysdate
       where t.status = '10'
         and t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strWareHouseNo
         and t.check_no = strCheckNo;
    else
      --全部做封箱

      --转历史
      insert into odata_check_label_dhty
        (enterprise_no,
         warehouse_no,
         owner_no,
         check_no,
         row_id,
         lable_no,
         divide_id,
         container_no,
         exp_no,
         exp_type,
         exp_date,
         article_no,
         packing_qty,
         article_id,
         article_qty,
         real_qty,
         status,
         check_name,
         check_date,
         d_label_no,
         rgst_date) --添加rgst_date字段 2016-9-22 heym
        select a.enterprise_no,
               a.warehouse_no,
               a.owner_no,
               a.check_no,
               a.row_id,
               a.lable_no,
               a.divide_id,
               a.container_no,
               a.exp_no,
               a.exp_type,
               a.exp_date,
               a.article_no,
               a.packing_qty,
               a.article_id,
               a.article_qty,
               a.real_qty,
               '13',
               a.check_name,
               a.check_date,
               a.d_label_no,
               a.rgst_date --添加rgst_date字段 2016-9-22 heym
          from odata_check_label_d a
         where a.enterprise_no = strEnterPriseNo
           and a.warehouse_no = strWareHouseNo
           and a.check_no = strCheckNo;

      insert into odata_check_dhty
        (enterprise_no,
         warehouse_no,
         owner_no,
         exp_no,
         exp_type,
         exp_date,
         check_no,
         article_no,
         packing_qty,
         plan_qty,
         article_qty,
         real_qty,
         status,
         rgst_name,
         rgst_date,
         check_name,
         check_date)
        select a.enterprise_no,
               a.warehouse_no,
               a.owner_no,
               a.exp_no,
               a.exp_type,
               a.exp_date,
               a.check_no,
               a.article_no,
               a.packing_qty,
               a.plan_qty,
               a.article_qty,
               a.real_qty,
               '13',
               a.rgst_name,
               a.rgst_date,
               a.check_name,
               a.check_date
          from odata_check_d a
         where a.enterprise_no = strEnterPriseNo
           and a.warehouse_no = strWareHouseNo
           and a.check_no = strCheckNo;

      insert into odata_check_mhty
        (enterprise_no,
         warehouse_no,
         owner_no,
         check_no,
         operate_date,
         batch_no,
         cust_no,
         status,
         check_chute_no,
         deliver_obj,
         line_no,
         curr_area,
         rgst_name,
         rgst_date,
         updt_name,
         updt_date)
        select a.enterprise_no,
               a.warehouse_no,
               a.owner_no,
               a.check_no,
               a.operate_date,
               a.batch_no,
               a.cust_no,
               '13',
               a.check_chute_no,
               a.deliver_obj,
               a.line_no,
               a.curr_area,
               a.rgst_name,
               a.rgst_date,
               a.updt_name,
               a.updt_date
          from odata_check_m a
         where a.enterprise_no = strEnterPriseNo
           and a.warehouse_no = strWareHouseNo
           and a.check_no = strCheckNo;

      --删除数据
      delete from odata_check_label_d a
       where a.enterprise_no = strEnterPriseNo
         and a.warehouse_no = strWareHouseNo
         and a.check_no = strCheckNo;

      delete from odata_check_d a
       where a.enterprise_no = strEnterPriseNo
         and a.warehouse_no = strWareHouseNo
         and a.check_no = strCheckNo;

      delete from odata_check_m a
       where a.enterprise_no = strEnterPriseNo
         and a.warehouse_no = strWareHouseNo
         and a.check_no = strCheckNo;
    end if;
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_PROC_Receipt;

  /*=====================================================================================
  功能说明：包材处理
           1、根据快递面单写库存调帐单；
           2、根据库存调帐单定位并回单；

  ======================================================================================*/
  PROCEDURE P_strPackMateDeal(strEnterpriseNo in STOCK_LABEL_M.enterprise_no%type, --企业号
                              strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                              strLabelNo      in stock_label_m.label_no%type, --快递面单，电商的快递面单等于标签
                              strArticlNo     in stock_label_d.article_no%type, --包材编码=商品编码
                              nRealQty        in stock_content.qty%type, --包材出货数量
                              strUserId       in stock_label_m.rgst_name%type, --操作人员
                              strOutMsg       out varchar2) is

    v_Count    number(10) := 0; --循环行数
    v_strOrgNo odata_exp_m.org_no%type;
    v_strExpNo odata_exp_m.exp_no%type;
    nCurQty    stock_content.qty%type := 0; --当前数量
    nRemainQty stock_content.qty%type := nRealQty; --剩余数量
    --nTotalQty    stock_content.qty%type := nRealQty; --总数量
    v_strPlanNo  stock_plan_m.plan_no%type;
    v_strOwnerNo bdef_defowner.owner_no%type;
  begin
    strOutMsg := 'N|[P_strPackMateDeal]';

    select count(*)
      into v_Count
      from bdef_defarticle bd
     where bd.article_no = strArticlNo
       and bd.VIRTUAL_FLAG = '2';

    if v_Count = 0 then
      strOutMsg := 'N|[找不到商品资料或不是包材商品]';
      return;
    end if;

    --获取机构号和出货单号
    begin
      select org_no, exp_no
        into v_strOrgNo, v_strExpNo
        from odata_exp_m t
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWarehouseNo
         and t.SHIPPER_DELIVER_NO = strLabelNo;
    exception
      when no_data_found then
        strOutMsg := 'N|[找不到对应的出货单]';
        return;
    end;

    v_Count := 0;

    --根据快递面单写库存调帐单
    --读取库存
    for GetStock in (select sc.cell_no,
                            sai.*,
                            sc.owner_no,
                            sc.packing_qty,
                            sc.stock_type,
                            sc.stock_value,
                            sc.label_no,
                            (sc.qty - sc.outstock_qty) qty
                       from stock_content sc, stock_article_info sai
                      where sc.enterprise_no = sai.enterprise_no
                        and sc.article_no = sai.article_no
                        and sc.article_id = sai.article_id
                        and sc.enterprise_no = strEnterpriseNo
                        and sc.warehouse_no = strWarehouseNo
                        and sc.article_no = strArticlNo
                        and sc.qty > sc.outstock_qty
                      order by sc.cell_no,
                               sc.owner_no,
                               sai.article_no,
                               sc.packing_qty,
                               sc.stock_type,
                               sc.stock_value,
                               sc.label_no) loop

      v_strOwnerNo := GetStock.owner_no;

      v_Count := v_Count + 1;

      if nRemainQty >= GetStock.qty then
        nCurQty := GetStock.qty;
      else
        nCurQty := nRemainQty;
      end if;

      nRemainQty := nRemainQty - nCurQty;

      pklg_adj.P_saveStockPlan(strEnterpriseNo,
                               strWarehouseNo,
                               GetStock.owner_no,
                               '4', --包材管理
                               v_strExpNo,
                               strArticlNo,
                               GetStock.packing_qty,
                               GetStock.Produce_Date,
                               GetStock.Expire_Date,
                               GetStock.Quality,
                               GetStock.Lot_No,
                               GetStock.Import_Batch_No,
                               GetStock.Rsv_Batch1,
                               GetStock.Rsv_Batch2,
                               GetStock.Rsv_Batch3,
                               GetStock.Rsv_Batch4,
                               GetStock.Rsv_Batch5,
                               GetStock.Rsv_Batch6,
                               GetStock.Rsv_Batch7,
                               GetStock.Rsv_Batch8,
                               GetStock.cell_no,
                               -nCurQty,
                               GetStock.stock_type,
                               GetStock.stock_value,
                               GetStock.label_no,
                               strUserId,
                               '0',
                               v_strOrgNo,
                               'N',
                               strLabelNo,
                               v_strPlanNo,
                               strOutMsg);

      if substr(strOutMsg, 1, 1) = 'N' then
        return;
      end if;

      if nRemainQty <= 0 then
        exit;
      end if;
    end loop;

    if v_Count = 0 then
      strOutMsg := 'N|[该商品无库存]';
      return;
    end if;

    pklg_adj.P_stockLocateComfire(strEnterPriseNo,
                                  strWareHouseNo,
                                  v_strOwnerNo,
                                  v_strPlanNo,
                                  'N',
                                  strUserId,
                                  'N',
                                  '0',
                                  strOutMsg);

    if substr(strOutMsg, 1, 1) = 'N' then
      return;
    end if;
    strOutMsg := 'Y|';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end P_strPackMateDeal;


  /*=====================================================================================
  外复核--检查待复核板标签是否能复核
  huangb 20161123
  ======================================================================================*/
  PROCEDURE P_RecheckExistsLabelNo(strEnterpriseNo in STOCK_LABEL_M.enterprise_no%type, --企业号
                                   strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                                   strLabelNo      in stock_label_m.label_no%type, --待复核标签
                                   strOutMsg       out varchar2) is
  v_Count            number(10) := 0;
  v_WaveNo           stock_label_m.wave_no%type; --波次号
  v_CustNo           stock_label_m.cust_no%type; --客户编号
  v_UseType          stock_label_m.status%type; --标签用途
  v_Status           stock_label_m.status%type; --标签状态
  v_StatusDesc       wms_deffieldval.text%type; --标签状态描述
  v_ContainerNo      stock_label_m.container_no%type; --系统内部容器号
  v_OwnerContainerNo stock_label_m.owner_container_no%type; --所属容器号
  begin
    strOutMsg := 'N|[P_RecheckExistsLabelNo]';

    --检查标签的状态,类型,是否为被并板标签
    begin
      select slm.wave_no, slm.cust_no, slm.use_type, slm.status
             , f_get_fieldtext('STOCK_LABEL_M','STATUS',slm.status)
             , slm.container_no, slm.owner_container_no
        into v_WaveNo, v_CustNo, v_UseType, v_Status
             , v_StatusDesc
             , v_ContainerNo, v_OwnerContainerNo
        from stock_label_m slm
       where slm.enterprise_no = strEnterpriseNo
         and slm.warehouse_no = strWarehouseNo
         and slm.label_no = strLabelNo;
    exception
      when no_data_found then
        strOutMsg := 'N|[标签['|| strLabelNo ||']不存在]';
        return;
    end;

    if v_Status <> '6F' then
      strOutMsg := 'N|[标签状态为['|| v_StatusDesc ||']不允许外复核]';
      return;
    end if;

    if v_UseType <> '1' then
      strOutMsg := 'N|[标签不为客户标签,不允许外复核]';
      return;
    end if;

    if v_ContainerNo <> v_OwnerContainerNo then
      strOutMsg := 'N|[当前标签已被并板,不能外复核]';
      return;
    end if;

    --检查当前标签是否有明细
    v_Count := 0;
    select count(1) into v_Count
      from stock_label_m slm
     inner join stock_label_m slmm
        on slmm.enterprise_no = slm.enterprise_no
       and slmm.warehouse_no = slm.warehouse_no
       and slmm.owner_container_no = slm.container_no
     inner join stock_label_d sld
        on sld.enterprise_no = slmm.enterprise_no
       and sld.warehouse_no = slmm.warehouse_no
       and sld.container_no = slmm.container_no
     where slm.enterprise_no = strEnterpriseNo
       and slm.warehouse_no = strWarehouseNo
       and slm.label_no = strLabelNo;
    if v_Count <= 0 then
      strOutMsg := 'N|[标签['|| strLabelNo ||']不存在明细]';
      return;
    end if;

    --检查标签对应的波次和客户是否还有位定位完成数据
    v_Count := 0;
    select count(1) into v_Count
      from odata_locate_d ld
     where ld.enterprise_no = strEnterpriseNo
       and ld.warehouse_no = strWarehouseNo
       and ld.wave_no = v_WaveNo
       and ld.cust_no = v_CustNo;
    if v_Count > 0 then
      strOutMsg := 'N|[波次['|| v_WaveNo ||']客户['|| v_CustNo ||']还有单据未调度完成]';
      return;
    end if;

    --检查标签对应的波次和客户是否还有未发单数据
    select count(1) into v_Count
      from odata_outstock_direct ood
     where ood.enterprise_no = strEnterpriseNo
       and ood.warehouse_no = strWarehouseNo
       and ood.wave_no = v_WaveNo
       and ood.cust_no = v_CustNo
       and ood.status not in ('13','16');
    if v_Count > 0 then
      strOutMsg := 'N|[波次['|| v_WaveNo ||']客户['|| v_CustNo ||']还有单据未发单完成]';
      return;
    end if;

    --检查标签对应的波次和客户是否还有未回单数据
    select count(1) into v_Count
      from odata_outstock_d ood
     where ood.enterprise_no = strEnterpriseNo
       and ood.warehouse_no = strWarehouseNo
       and ood.wave_no = v_WaveNo
       and ood.cust_no = v_CustNo
       and ood.status not in ('13','16');
    if v_Count > 0 then
      strOutMsg := 'N|[波次['|| v_WaveNo ||']客户['|| v_CustNo ||']还有单据未下架完成]';
      return;
    end if;

    --检查标签对应的波次和客户是否还有未分播数据
    select count(1) into v_Count
      from odata_divide_d odd
     where odd.enterprise_no = strEnterpriseNo
       and odd.warehouse_no = strWarehouseNo
       and odd.wave_no = v_WaveNo
       and odd.cust_no = v_CustNo
       and odd.status not in ('13','16');
    if v_Count > 0 then
      strOutMsg := 'N|[波次['|| v_WaveNo ||']客户['|| v_CustNo ||']还有单据未分播完成]';
      return;
    end if;

    strOutMsg := 'Y|P_RecheckExistsLabelNo';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end P_RecheckExistsLabelNo;

  /*=====================================================================================
  外复核--新增外复核单据信息
  huangb 20161126
  ======================================================================================*/
  PROCEDURE P_InsertRecheckOrder(strEnterpriseNo in STOCK_LABEL_M.enterprise_no%type, --企业号
                                 strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                                 strLabelNo      in stock_label_m.label_no%type, --待复核标签
                                 strUserId       in odata_recheck_m.rgst_name%type, --操作人员
                                 strOutRecheckNo out odata_recheck_m.recheck_no%type, --返回外复核单号
                                 strOutMsg       out varchar2) is
  v_Count      number(10) := 0;
  v_WaveNo     stock_label_m.wave_no%type; --波次号
  v_BatchNo    stock_label_m.batch_no%type; --批次号
  v_OwnerNo    stock_label_d.owner_no%type; --委托业主
  v_CustNo     stock_label_m.cust_no%type; --客户编号
  v_DeliverObj stock_label_m.deliver_obj%type; --配送对象
  v_LineNo     stock_label_m.line_no%type; --线路
  v_CheckLevel wms_check_strategy.check_level%type; --外复核等级
  v_RecheckNo  odata_recheck_d.recheck_no%type; --外复核单号
  begin
    strOutMsg       := 'N|[P_InsertRecheckOrder]';
    strOutRecheckNo := 'N';

    --获取标签信息
    begin
      select slm.wave_no, slm.batch_no, sld.owner_no, slm.cust_no
             , slm.deliver_obj, slm.line_no
        into v_WaveNo, v_BatchNo, v_OwnerNo, v_CustNo
             , v_DeliverObj, v_LineNo
       from stock_label_m slm
      inner join stock_label_m slmm
         on slmm.enterprise_no = slm.enterprise_no
        and slmm.warehouse_no = slm.warehouse_no
        and slmm.owner_container_no = slm.container_no
      inner join stock_label_d sld
         on sld.enterprise_no = slmm.enterprise_no
        and sld.warehouse_no = slmm.warehouse_no
        and sld.container_no = slmm.container_no
      where slm.enterprise_no = strEnterpriseNo
        and slm.warehouse_no = strWarehouseNo
        and slm.label_no = strLabelNo
        and rownum = 1;
    exception
      when no_data_found then
        strOutMsg := 'N|[标签['|| strLabelNo ||']不存在]';
        return;
    end;

    --获取产生外复核单据等级
    --复核级别：1：按标签；2：按单；3：按批次；4：波次+客户
    begin
      select nvl(wcs.check_level,'N') into v_CheckLevel
        from odata_locate_batch olb
       inner join wms_check_strategy wcs
          on wcs.enterprise_no = olb.enterprise_no
         and wcs.check_type = 'C'
         and wcs.check_strategy_id = olb.c_check_strategy_id
       where olb.enterprise_no = strEnterpriseNo
         and olb.warehouse_no = strWarehouseNo
         and olb.wave_no = v_WaveNo
         and olb.batch_no = v_BatchNo;
    exception
      when no_data_found then
        strOutMsg := 'N|[波次['|| v_WaveNo ||']批次['|| v_BatchNo ||']不存在外复核配置]';
        return;
    end;

    if v_CheckLevel = 'N' then
      strOutMsg := 'N|[波次['|| v_WaveNo ||']批次['|| v_BatchNo ||']外复核等级为空]';
      return;
    end if;

    /*根据外复核等级新增外复核单据信息
      1：按标签；2：按单；3：按批次；4：波次+客户
    */

    --4:按波次+客户产生外复核单据
    if v_CheckLevel = '4' then
      --判断当前波次和客户是否存在外复核单据
      v_Count := 0;
      begin
        select orm.recheck_no into v_RecheckNo
          from odata_recheck_m orm
         where orm.enterprise_no = strEnterpriseNo
           and orm.warehouse_no = strWarehouseNo
           and orm.wave_no = v_WaveNo
           and orm.cust_no = v_CustNo;
      exception
        when no_data_found then
          v_RecheckNo := 'N';
      end;

      --如果当前波次和客户不存在外复核单据 则新增外复核单据
      if v_RecheckNo = 'N' then
        --取外复核单号
        PKLG_WMS_BASE.p_getsheetno(strEnterPriseNo,
                                   strWarehouseNo,
                                   CONST_DOCUMENTTYPE.ODATARC,
                                   v_RecheckNo,
                                   strOutMsg);
        if instr(strOutMsg, 'N', 1, 1) = 1 then
          return;
        end if;

        --新增外复核单头档信息
        PKOBJ_ODATA_CHECK.p_InsertRecheckM
        (strEnterpriseNo, strWareHouseNo, v_OwnerNo, v_RecheckNo
         , v_WaveNo, v_BatchNo, v_DeliverObj, v_LineNo
         , v_CustNo, v_CustNo, '10', 'N'
         , trunc(sysdate), 0, 0, 0
         , strUserId, strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;

        --根据波次+客户产生外复核明细
        PKOBJ_ODATA_CHECK.p_InsertRecheckDByWaveCust(strEnterpriseNo,
                                                     strWareHouseNo,
                                                     v_OwnerNo,
                                                     v_RecheckNo,
                                                     v_WaveNo,
                                                     v_CustNo,
                                                     '10',
                                                     strUserId,
                                                     strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
      end if;
      strOutRecheckNo := v_RecheckNo;
    end if;

    strOutMsg := 'Y|P_InsertRecheckOrder';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end P_InsertRecheckOrder;

  /**********************************************************************************************
  功能说明：校验此标签是否可做外复核扫描
  1、不可直接扫主标签复核；
  2、校验子标签是否存在此单；
  luozhiling
  2016.11.25
  ***********************************************************************************************/
   procedure P_CheckArticleAndLabelNo(strEnterpriseNo in odata_recheck_m.enterprise_no%type,
                           strWareHouseNo  in odata_recheck_m.warehouse_no%type,
                           strReCheckNo    in odata_recheck_m.recheck_no%type,
                           strLabelNo      in odata_recheck_d.label_no%type, --主标签
                           strSubLabelNo   in odata_recheck_d.sub_label_no%type,--子标签
                           strResult       out varchar2) is
        v_iCount           integer;
   begin
        strResult:='N|[P_CheckArticleAndLabelNo]';

        if strLabelNo=strSubLabelNo then
           strResult:='N|[不能直接扫描板标签进行计数]';
           return;
        end if;

        select count(*) into v_iCount from odata_recheck_d ord where ord.enterprise_no=strEnterpriseNo
        and ord.warehouse_no=strWareHouseNo and ord.recheck_no=strReCheckNo
        and ord.sub_label_no=strSubLabelNo;

        if v_iCount=0 then
           strResult:='子标签不存在或已扫描';
           return;
        end if;

        strResult:='Y|[]';
   end P_CheckArticleAndLabelNo;
  /***********************************************************************************************
   功能说明:外复核回单，有两种类型：
   1、扫描外箱码循环累加复核数量，对于拆零扫描拆零标签，直接根据标签明细抓取商品信息进行复核回单
   2、扫描商品条码输入复核数量；
   本功能适用于按商品和数量进行回单
     luozhiling
   2016.11.24
  ***********************************************************************************************/
  procedure P_SaveCheckFromArticle(strEnterpriseNo in odata_recheck_m.enterprise_no%type,
                           strWareHouseNo          in odata_recheck_m.warehouse_no%type,
                           strReCheckNo            in odata_recheck_m.recheck_no%type,
                           strArticle_No           in odata_recheck_d.article_no%type, --商品编码
                           nPacking_QTY            in odata_recheck_d.packing_qty%type, --包装数量
                           strLabelNo              in odata_recheck_d.label_no%type,--标签
                           strSubLabelNo           in odata_recheck_d.sub_label_no%type,--子标签--
                           nRealQty                in odata_recheck_d.real_qty%type, --回单数量
                           strUserId               in odata_recheck_d.rgst_name%type,
                           strResult               out varchar2) is

    v_nCurrQty odata_recheck_d.real_qty%type;
    v_nRemainQty odata_recheck_d.real_qty%type;
    v_iCount     integer := 0;
  begin
    strResult := 'N|[P_SaveCheckFromArticle]';

    v_nRemainQty := nRealQty;
    if v_nRemainQty < 0 then
      v_nRemainQty := v_nRemainQty * -1;
    end if;

    for GetReCheckItem in (select ord.*
                                from odata_recheck_d ord,
                                     stock_article_info  sai
                               where ord.enterprise_no = sai.enterprise_no
                                 and ord.article_no = sai.article_no
                                 and ord.article_id = sai.article_id
                                 and ord.enterprise_no = strEnterpriseNo
                                 and ord.warehouse_no = strWareHouseNo
                                 and ord.recheck_no = strReCheckNo
                                 and ord.label_no = strLabelNo
                                 and ord.sub_label_no= strSubLabelNo
                                 and ord.article_no = strArticle_No
                                 and ord.packing_qty = nPacking_QTY
                                 and ord.status in ('10', '11')
                               order by ord.container_no, ord.article_id) loop

      v_iCount := v_iCount + 1;

      if nRealQty > 0 then
        --
        v_nCurrQty := GetReCheckItem.article_qty - GetReCheckItem.real_qty;
        if v_nCurrQty > v_nRemainQty then
          v_nCurrQty := v_nRemainQty;
        end if;

        v_nRemainQty := v_nRemainQty - v_nCurrQty;
      else

        v_nCurrQty := GetReCheckItem.real_qty;
        if v_nCurrQty > v_nRemainQty then
          v_nCurrQty := v_nRemainQty;
        end if;

        v_nRemainQty := v_nRemainQty - v_nCurrQty;

        v_nCurrQty := v_nCurrQty * -1;

      end if;

      --更新复核标签明细
      PKOBJ_ODATA_CHECK.P_UpdateReCheckD(strEnterpriseNo,
                                                 strWareHouseNo,
                                                 strReCheckNo,
                                                 GetReCheckItem.container_no,
                                                 GetReCheckItem.row_id,
                                                 v_nCurrQty,
                                                 strUserId,
                                                 strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      if v_nRemainQty = 0 then
        exit;
      end if;

    end loop;

    if v_nRemainQty > 0 then
      strResult := 'N|[外复核扣减超量]';
      return;

    end if;

    if v_iCount = 0 then
      strResult := 'N|[找不到要外复核的明细]';
      return;
    end if;

    select count(*) into v_iCount from odata_recheck_d t where t.enterprise_no=strEnterpriseNo
           and t.warehouse_no=strWareHouseNo and t.recheck_no=strReCheckNo
           and t.status<'13';

    if v_iCount=0 then
      --调用工作流 huangb 20161214
      for t in (select distinct ord.owner_no,ord.exp_type,ord.container_no
                  from odata_recheck_d ord
                 where ord.enterprise_no=strEnterpriseNo
                   and ord.warehouse_no=strWareHouseNo
                   and ord.recheck_no=strReCheckNo) loop

        --调用工作流
        PKOBJ_WorkFlow.p_OM_OutWorkflow(
                       strEnterpriseNo, --企业号
                       strWareHouseNo, --仓别
                       t.owner_no,
                       t.exp_type,
                       t.container_no, --系统内部容器号
                       strUserId, --操作人员
                       'N', --自动封车打印使用，若不需要则传'N'
                       strResult);
        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

      end loop;
      --更新外复核头档状态
      PKOBJ_ODATA_CHECK.P_UpdateReCheckM(strEnterpriseNo,strWareHouseNo,strReCheckNo,strUserId,strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
      --转历史
      PKOBJ_ODATA_CHECK.p_Insert_Recheck_log(strEnterpriseNo,strWareHouseNo,strReCheckNo,strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
    end if;


    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_SaveCheckFromArticle;

  /*************************************************************************************************8
  功能说明：扫描标签进行复核回单，首先根据标签查询标签表数据，若查询到数据，根据标签明细写外复核明显，
            若找不到,查询条码表是否有此扫描数据，若有根据条码对应的数量进行外复核回单。
  luozhiling
  2016.11.24
  *************************************************************************************************/
  procedure P_SaveLabelItem(strEnterpriseNo in odata_recheck_m.enterprise_no%type,
                           strWareHouseNo   in odata_recheck_m.warehouse_no%type,
                           strReCheckNo     in odata_recheck_m.recheck_no%type,
                           strLabelNo       in odata_recheck_d.label_no%type,
                           strSubLabelNo    in odata_recheck_d.sub_label_no%type,
                           strUserId        in odata_recheck_d.rgst_name%type,
                           strResult        out varchar2) is
         v_iCount          integer;
         nPackingQty       bdef_article_packing.packing_qty%type;
         v_strArticleNo    bdef_defarticle.article_no%type;
  begin
       strResult:='N|[P_SaveLabelItem]';

       for GetLabelItem in(select slm.label_no,slm.owner_container_no,sld.deliver_obj,sld.article_no,
           sld.packing_qty,sum(sld.qty) qty
           from stock_label_m slm,
           stock_label_d sld where slm.enterprise_no=sld.enterprise_no
           and slm.warehouse_no=sld.warehouse_no and slm.container_no=sld.container_no
           and slm.enterprise_no=strEnterPriseNo and slm.warehouse_no=strWareHouseNo
           and slm.label_no=strSubLabelNo
           group by slm.label_no,slm.owner_container_no,sld.deliver_obj,sld.article_no,sld.packing_qty) loop

           v_iCount:=v_iCount+1;

           P_SaveCheckFromArticle(strEnterPriseNo,strWareHouseNo,strReCheckNo,
                    GetLabelItem.article_no,GetLabelItem.packing_qty,strLabelNo,strSubLabelNo,GetLabelItem.qty,strUserId,strResult);

           if (substr(strResult, 1, 1) = 'N') then
              return;
           end if;
       end loop;

       if v_iCount=0 then--若找不到标签，即表示外箱条码
          --根据外箱码获取数量，目前只支持商品条码
          select nvl(bap.packing_qty,0) into nPackingQty from bdef_article_packing bap,odata_recheck_d ord
          where bap.enterprise_no=ord.enterprise_no and bap.article_no=ord.article_no
          and bap.packing_qty=ord.packing_qty and rownum=1;

          if nPackingQty=0 then --此外箱条码不存在
             strResult:='N|[此外箱条码不存在]';
             return;
          end if;


         P_SaveCheckFromArticle(strEnterPriseNo,strWareHouseNo,strReCheckNo,
                  v_strArticleNo,nPackingQty,strLabelNo,strSubLabelNo,nPackingQty,strUserId,strResult);

         if (substr(strResult, 1, 1) = 'N') then
            return;
         end if;
       end if;

       strResult:='Y|[]';
  end P_SaveLabelItem;

  /*=====================================================================================
  外复核--称重保存
  huangb 20161126
  ======================================================================================*/
  PROCEDURE P_SaveRecheckWeight(strEnterpriseNo in STOCK_LABEL_M.enterprise_no%type, --企业号
                                strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                                strLabelNo      in stock_label_m.label_no%type, --称重标签
                                nWeight         in stock_label_m.weight%type, --重量
                                strUserId       in odata_recheck_m.rgst_name%type, --操作人员
                                strOutMsg       out varchar2) is
  v_Count      number(10) := 0;
  begin
    strOutMsg       := 'N|[P_SaveRecheckWeight]';

    update stock_label_m slm
       set slm.weight = nWeight, slm.updt_name = strUserId, slm.updt_date = sysdate
     where slm.enterprise_no = strEnterpriseNo
       and slm.warehouse_no = strWarehouseNo
       and exists (select 'X'
              from stock_label_m slmm
             where slmm.enterprise_no = slm.enterprise_no
               and slmm.warehouse_no = slm.warehouse_no
               and slmm.wave_no = slm.wave_no
               and slmm.cust_no = slm.cust_no
               and slmm.label_no = strLabelNo);
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[称重失败(更新0行)]';
      return;
    end if;

    strOutMsg := 'Y|P_SaveRecheckWeight';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end P_SaveRecheckWeight;

end PKLG_ODATA_CHECK;

/

