create package body PKLG_ODATA_DELIVER is

  /**********************************************************************************************************
     lich
     2014.07.15
     功能：表单装车（多选装车）
  ***********************************************************************************************************/
  procedure P_odata_CloseCar(strEnterpriseNo in odata_loadpropose_m.enterprise_no%type, --企业编码
                             strWareHouseNo  in odata_loadpropose_m.warehouse_no%type, --仓库编码
                             strDeliverObj   in odata_divide_d.deliver_obj%type, --配送对象（客户编码、单号）
                             strShipperNo    in odata_loadpropose_m.shipper_no%type, --承运商编码
                             strLineNo       in odata_loadpropose_m.line_no%type, --线路
                             strCarNo        in bdef_defcar.car_no%type, ---车辆编码
                             strUserId       in odata_loadpropose_m.rgst_name%type,
                             strDockNo       in odata_loadpropose_m.dock_no%type,
                             strDivideTrunk  in odata_loadpropose_m.divide_truck%type, --分车编号
                             strcarPlanNo    IN odata_loadpropose_m.car_plan_no%type, --派车计划单
                             strSealNo       in Odata_Loadpropose_m.Seal_No%type, --封条号
                             strLoadType     in odata_loadpropose_m.loadtype%type, --装车类型：1：按承运商；2：线路；3：配送对象（客户\单）
                             --strContainerNo            in    odata_loadpropose_d.container_no%type,
                             strPaperUserId   in odata_loadpropose_m.rgst_name%type,
                             strTmpId         in odata_loadcar_tmp.tmp_id%type, --标识
                             strLoadProposeNo out varchar2,
                             strResult        OUT varchar2) is
    strProposeNo odata_loadpropose_m.loadpropose_no%type;
    v_iCount     integer;

  begin
    strResult := 'N|[P_odata_CloseCar]';
    v_iCount  := 0;
    for p in (select distinct a.container_no, a.label_no
                from odata_loadcar_tmp a
               where a.tmp_id = strTmpId
                 and a.warehouse_no = strWareHouseNo
                 and a.enterprise_no = strEnterpriseNo) loop
      v_iCount := v_iCount + 1;
      if v_iCount = 1 then
        --校验能否装车
        p_CheckCanLoadCar(strEnterpriseNo,
                          strWareHouseNo,
                          strTmpId,
                          strResult);
        if substr(strResult, 1, 1) = 'N' then
          return;
        end if;

        --写建议单头档
        PKOBJ_ODATA_DELIVER.P_odata_loadcarHead(strEnterpriseNo,
                                                strWareHouseNo,
                                                strDeliverObj,
                                                strShipperNo,
                                                strLineNo,
                                                strCarNo,
                                                strUserId,
                                                strDockNo,
                                                strDivideTrunk,
                                                strcarPlanNo,
                                                strSealNo,
                                                strLoadType,
                                                strProposeNo,
                                                strResult);
        if substr(strResult, 1, 1) = 'N' then
          return;
        end if;
      end if;

      --写建议单明细档
      PKOBJ_ODATA_DELIVER.P_odata_loadcarItem(strEnterpriseNo,
                                              strWareHouseNo,
                                              strProposeNo,
                                              p.label_no, --strContainerNo,
                                              strUserId,
                                              strPaperUserId,
                                              strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;

    end loop;

    if v_iCount = 0 then
      strResult := 'N|[E22914]';
      return;
    end if;

    --删除临时表
    delete from odata_loadcar_tmp a
     where a.tmp_id = strTmpId
       and a.enterprise_no = strEnterpriseNo
       and a.warehouse_no = strWareHouseNo;

    strLoadProposeNo := strProposeNo;
    strResult        := 'Y|';
  end P_odata_CloseCar;
  /**********************************************************************************************************
       hkl
     2015.10.27
     功能：表单装车（单选装车）
  ***********************************************************************************************************/
  procedure P_odata_CloseCar_One(strEnterpriseNo in odata_loadpropose_m.enterprise_no%type, --企业编码
                                 strWareHouseNo  in odata_loadpropose_m.warehouse_no%type, --仓库编码
                                 strDeliverObj   in odata_divide_d.deliver_obj%type, --配送对象（客户编码、单号）
                                 strShipperNo    in odata_loadpropose_m.shipper_no%type, --承运商编码
                                 strLineNo       in odata_loadpropose_m.line_no%type, --线路
                                 strCarNo        in bdef_defcar.car_no%type, ---车辆编码
                                 strUserId       in odata_loadpropose_m.rgst_name%type,
                                 strDockNo       in odata_loadpropose_m.dock_no%type,
                                 strDivideTrunk  in odata_loadpropose_m.divide_truck%type, --分车编号
                                 strcarPlanNo    IN odata_loadpropose_m.car_plan_no%type, --派车计划单
                                 strSealNo       in Odata_Loadpropose_m.Seal_No%type, --封条号
                                 strLoadType     in odata_loadpropose_m.loadtype%type, --装车类型：1：按承运商；2：线路；3：配送对象（客户\单）
                                 --strContainerNo            in    odata_loadpropose_d.container_no%type,
                                 strPaperUserId   in odata_loadpropose_m.rgst_name%type,
                                 strTmpId         in odata_loadcar_tmp.tmp_id%type, --标识
                                 strLoadProposeNo out varchar2,
                                 strResult        OUT varchar2) is
    strProposeNo odata_loadpropose_m.loadpropose_no%type;
    strExpNo     odata_exp_m.exp_no%type;
    v_iCount     integer;

  begin
    strResult := 'N|[P_odata_CloseCar]';
    v_iCount  := 0;

    begin
      select m.exp_no
        into strExpNo
        from odata_exp_m m
       where m.enterprise_no = strEnterpriseNo
         and m.warehouse_no = strWareHouseNo
         and m.sourceexp_no = strDeliverObj;
    exception
      when no_data_found then
        strResult := '该单号不存在！';
        return;
    end;

    for p in (select distinct a.container_no, a.label_no
                from stock_label_m a
               where a.deliver_obj = strExpNo
                 and a.warehouse_no = strWareHouseNo
                 and a.enterprise_no = strEnterpriseNo) loop
      v_iCount := v_iCount + 1;
      if v_iCount = 1 then
        --校验能否装车
        p_CheckCanLoadCar(strEnterpriseNo,
                          strWareHouseNo,
                          strTmpId,
                          strResult);
        if substr(strResult, 1, 1) = 'N' then
          return;
        end if;

        --写建议单头档
        PKOBJ_ODATA_DELIVER.P_odata_loadcarHead(strEnterpriseNo,
                                                strWareHouseNo,
                                                strDeliverObj,
                                                strShipperNo,
                                                strLineNo,
                                                strCarNo,
                                                strUserId,
                                                strDockNo,
                                                strDivideTrunk,
                                                strcarPlanNo,
                                                strSealNo,
                                                strLoadType,
                                                strProposeNo,
                                                strResult);
        if substr(strResult, 1, 1) = 'N' then
          return;
        end if;
      end if;

      --写建议单明细档
      PKOBJ_ODATA_DELIVER.P_odata_loadcarItem(strEnterpriseNo,
                                              strWareHouseNo,
                                              strProposeNo,
                                              p.label_no, --strContainerNo,
                                              strUserId,
                                              strPaperUserId,
                                              strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;

    end loop;

    if v_iCount = 0 then
      strResult := 'N|[E22914]';
      return;
    end if;

    strLoadProposeNo := strProposeNo;
    strResult        := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_odata_CloseCar_One;

  /**********************************************************************************************************
     功能说明：1、根据码头号新建或获取建议单号；
              2、可支持根据派车单号新增或获取建议单号；
              规则：一个码头或一张派车单对应一个装车建议单；
                    一张装车建议单对应多个客户
                    目前天天惠按码头装车，铁越按派车单装车
  ************************************************************************************************************/
  procedure P_CreateLoadPropose(strEnterpriseNo in odata_loadpropose_m.enterprise_no%type, --企业编码
                                strWareHouseNo  in odata_loadpropose_m.warehouse_no%type, --仓库编码
                                strDeliverObj   in stock_label_m.deliver_obj%type, --配送对象（客户编码、单号）
                                strShipperNo    in odata_loadpropose_m.shipper_no%type, --承运商编码
                                strLineNo       in odata_loadpropose_m.line_no%type, --线路
                                strCarNo        in bdef_defcar.car_no%type, ---车辆编码
                                strUserId       in odata_loadpropose_m.rgst_name%type,
                                strDockNo       in odata_loadpropose_m.dock_no%type,
                                strDivideTrunk  in odata_loadpropose_m.divide_truck%type, --分车编号
                                strcarPlanNo    IN odata_loadpropose_m.car_plan_no%type, --派车计划单
                                strSealNo       in Odata_Loadpropose_m.Seal_No%type, --封条号
                                strLoadType     in odata_loadpropose_m.loadtype%type, --装车类型：1：按承运商；2：线路；3：配送对象（客户\单）5，按码头6：派车单
                                strPaperUserId  in odata_loadpropose_m.rgst_name%type,

                                strProposeNo    out odata_loadpropose_m.loadpropose_no%type,
                                strResult       OUT varchar2) is
    v_strProposeNo odata_loadpropose_m.loadpropose_no%type := 'N';

    v_nCount number;
  begin
    strResult := 'N|[P_CreateLoadPropose]';

    if strLoadType = '5' then
      --首先根据码头号获取装车建议单号
      begin
        select olm.loadpropose_no
          into v_strProposeNo
          from odata_loadpropose_m olm
         where olm.enterprise_no = strEnterpriseNo
           and olm.warehouse_no = strWareHouseNo
           and olm.loadtype = strLoadType
           and olm.dock_no = strDockNo
           and olm.status = '10';

      exception
        when no_data_found then

          --
          v_strProposeNo := 'N';
          v_nCount       := 0;
          select count(1)
            into v_nCount
            from pntset_printer_workstation ppd
           where ppd.enterprise_no = strEnterpriseNo
             and ppd.warehouse_no = strWareHouseNo
             and ppd.workstation_no = strDockNo;

          if v_nCount <= 0 then
            strResult := 'N|[没有设定打印机组]';
            return;
          end if;
      end;
    end if;

    if strLoadType = '6' and strcarPlanNo <> 'N' then
      --首先根据派车单号获取装车建议单号
      begin
        select olm.loadpropose_no
          into v_strProposeNo
          from odata_loadpropose_m olm
         where olm.enterprise_no = strEnterpriseNo
           and olm.warehouse_no = strWareHouseNo
           and olm.loadtype = strLoadType
           and olm.car_plan_no = strcarPlanNo
           and olm.status = '10';

      exception
        when no_data_found then
          v_strProposeNo := 'N';
      end;
    end if;

    --若查询不到数据，需要新建装车建议单
    --新建装车建议单
    if v_strProposeNo = 'N' then
      pkobj_odata_deliver.P_odata_loadcarHead(strEnterpriseNo,
                                              strWareHouseNo,
                                              strDeliverObj,
                                              strShipperNo,
                                              strLineNo,
                                              strCarNo,
                                              strUserId,
                                              strDockNo,
                                              strDivideTrunk,
                                              strcarPlanNo,
                                              strSealNo,
                                              strLoadType,
                                              v_strProposeNo,
                                              strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;
    end if;

    if v_strProposeNo = 'N' then
      strResult := 'N|[装车类型暂不支持]';
      return;
    end if;

    strProposeNo := v_strProposeNo;

    strResult := 'Y|[成功]';
  end P_CreateLoadPropose;

  /*************************************************************************************************************
    功能说明：RF扫描标签时校验此标签能否装车
               1、根据装车类型进行校验；
               2、判断标签状态是否可装车；
  ***********************************************************************************************************/
  procedure P_CheckCanLoadLabel(strEnterpriseNo in odata_loadpropose_m.enterprise_no%type, --企业编码
                                strWareHouseNo  in odata_loadpropose_m.warehouse_no%type, --仓库编码
                                strProposeNo    in odata_loadpropose_m.loadpropose_no%type,
                                strCustNo       in odata_loadpropose_m.cust_no%type, --当前装车客户
                                strLabelNo      in stock_label_m.label_no%type,
                                strResult       OUT varchar2) is
    v_strLoadType      odata_loadpropose_m.loadtype%type; --装车类型
    v_strsShipperNo    odata_loadpropose_m.shipper_no%type; --原承运商
    v_strsLineNo       odata_loadpropose_m.line_NO%type; --原线路编码
    v_strsCustNo       odata_loadpropose_m.cust_no%type; --原客户
    v_strDestCustNo    odata_loadpropose_m.cust_no%type; --目的客户
    v_strStatus        stock_label_m.status%type;
    v_strContainer     stock_label_m.container_no%type;
    v_strDestShipperNo oset_shipper_line.shipper_no%type;
    v_strDestLineNo    oset_shipper_line.line_no%type;
    v_strDeliverObj    stock_label_m.deliver_obj%type;
    --v_strLoadStatus    odata_loadpropose_m.status%type;
    v_iCount       integer;
    v_strOtherCust odata_loadpropose_m.cust_no%type;
    v_strCarPlanNO odata_loadpropose_m.car_plan_no%type;
    v_strExpNo     odata_carplan_volume.exp_no%type;
  begin
    strResult := 'N|[P_CheckCanLoadLabel]';

    --判断此装车建议单状态是否正常
    select count(*)
      into v_iCount
      from odata_loadpropose_m t
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWareHouseNo
       and t.loadpropose_no = strProposeNo
       and t.status < '13';

    if v_iCount = 0 then
      strResult := 'N|[找不到对应的装车建议单]';
      return;
    end if;

    --校验是否是当前客户

    begin
      select olm.loadType,
             olm.shipper_no,
             olm.line_no,
             olm.cust_no,
             olm.car_plan_no
        into v_strLoadType,
             v_strsShipperNo,
             v_strsLineNo,
             v_strsCustNo,
             v_strCarPlanNO
        from odata_loadpropose_m olm
       where olm.warehouse_no = strWareHouseNo
         and olm.loadpropose_no = strProposeNo
         and olm.enterprise_no = strEnterpriseNo;
    exception
      when no_data_found then
        strResult := 'N|[E22903]';
        return;
    end;

    --预留
    if v_strLoadType = '1' then
      --校验扫描的标签是否是该承运商
      begin
        select slm.cust_no, osl.shipper_no, status, container_no
          into v_strdestCustNo,
               v_strDestShipperNo,
               v_strStatus,
               v_strContainer
          from stock_label_m slm, oset_shipper_line osl
         where slm.line_no = osl.line_no
           and slm.label_no = strLabelNo
           and slm.warehouse_NO = strWareHouseNo
           and slm.enterprise_no = strEnterpriseNo;
      exception
        when no_data_found then
          strResult := 'N|[E22904]';
          return;
      end;
      if v_strStatus not in (clabelstatus.WAIT_LOAD_CAR) then
        strResult := 'N|[E22905]';
        return;
      end if;

      if v_strDestShipperNo <> v_strsShipperNo then
        strResult := 'N|[E22904]';
        return;
      end if;
    elsif v_strLoadType = '2' then
      --校验扫描的标签是否是该线路
      begin
        select slm.cust_no, slm.line_no, status, container_no
          into v_strdestCustNo,
               v_strDestLineNo,
               v_strStatus,
               v_strContainer
          from stock_label_m slm
         where slm.label_no = strLabelNo
           and slm.warehouse_NO = strWareHouseNo
           and slm.enterprise_no = strEnterpriseNo;
      exception
        when no_data_found then
          strResult := 'N|[E22904]';
          return;
      end;
      if v_strStatus not in (clabelstatus.WAIT_LOAD_CAR) then
        strResult := 'N|[E22905]';
        return;
      end if;

      if v_strDestLineNo <> v_strsLineNo then
        strResult := 'N|[E22906]';
        return;
      end if;
    elsif v_strLoadType = '3' then
      --校验扫描的标签是否是该客户
      begin
        select cust_no, status, container_no, deliver_obj
          into v_strdestCustNo,
               v_strStatus,
               v_strContainer,
               v_strDeliverObj
          from stock_label_m slm
         where slm.label_no = strLabelNo
           and slm.warehouse_NO = strWareHouseNo
           and slm.enterprise_no = strEnterpriseNo;
      exception
        when no_data_found then
          strResult := 'N|[E22904]';
          return;
      end;
      if v_strStatus not in (clabelstatus.WAIT_LOAD_CAR) then
        strResult := 'N|[E22905]';
        return;
      end if;

      if v_strDeliverObj <> v_strsCustNo then
        strResult := 'N|[E35008]'; --标签与建议单不是同一客户;
        return;
      end if;
    elsif v_strLoadType = '5' then
      --校验此门店是否可装车
      --校验扫描的标签是否是该客户
      begin
        select cust_no, status, deliver_obj
          into v_strdestCustNo, v_strStatus, v_strDeliverObj
          from stock_label_m slm
         where slm.label_no = strLabelNo
           and slm.warehouse_NO = strWareHouseNo
           and slm.enterprise_no = strEnterpriseNo;
      exception
        when no_data_found then
          strResult := 'N|[E22904]';
          return;
      end;

      if v_strStatus = clabelstatus.LOADED_IN_CAR then
        strResult := 'N|[该标签已装车]';
        return;
      end if;

      if v_strStatus not in (clabelstatus.WAIT_LOAD_CAR) then
        strResult := 'N|[E22905]';
        return;
      end if;

      if v_strdestCustNo <> strCustNo then
        strResult := 'N|[E35008]'; --标签与当前客户不一致;
        return;
      end if;

      --首先检查此门店的状态
      begin

        select count(1)
          into v_iCount
          from odata_loadpropose_d t
         where t.enterprise_no = strEnterpriseNo
           and t.warehouse_no = strWareHouseNo
           and t.loadpropose_no = strProposeNo
           and t.deliver_obj = v_strDeliverObj
           and status = '12';

        if v_iCount > 0 then
          strResult := 'N|[此车上当前配送对象已经扫描结束]';
          return;
        end if;

        --检查是否有其他未完成的配送对象
        begin
          select deliver_obj
            into v_strOtherCust
            from odata_loadpropose_d t
           where t.enterprise_no = strEnterpriseNo
             and t.warehouse_no = strWareHouseNo
             and t.loadpropose_no = strProposeNo
             and t.status = '10'
             and t.deliver_obj <> v_strDeliverObj
             and rownum <= 1;
        exception
          when no_data_found then
            v_strOtherCust := 'N';
        end;

        IF v_strOtherCust <> 'N' then
          strResult := 'N|[' || v_strOtherCust || '没有扫描结束]';
          return;
        end if;
      end;
    elsif v_strLoadType = '6' then
      --校验此门店是否可装车
      --校验扫描的标签是否是该客户
      begin
        select cust_no, status, deliver_obj
          into v_strdestCustNo, v_strStatus, v_strDeliverObj
          from stock_label_m slm
         where slm.label_no = strLabelNo
           and slm.warehouse_NO = strWareHouseNo
           and slm.enterprise_no = strEnterpriseNo;
      exception
        when no_data_found then
          strResult := 'N|[E22904]';
          return;
      end;

      begin
        select a.deliver_OBJ
          into v_strExpNo
          from (select ocv.deliver_OBJ
                  from odata_carplan_volume ocv
                 where ocv.enterprise_no = strEnterpriseNo
                   and ocv.warehouse_no = strWareHouseNo
                   and ocv.car_plan_no = v_strCarPlanNo
                   and ocv.status in ('10', '11')
                 order by ocv.load_order) a
         where rownum = 1;

      exception
        when no_data_found then
          strResult := 'N|[找不到对应的派车单]';
          return;
      end;

      if v_strExpNo <> v_strDeliverObj then
        strResult := 'N|[该标签不属于该单]';
        return;
      end if;

      if v_strStatus = clabelstatus.LOADED_IN_CAR then
        strResult := 'N|[该标签已装车]';
        return;
      end if;

      if v_strStatus not in (clabelstatus.WAIT_LOAD_CAR) then
        strResult := 'N|[E22905]';
        return;
      end if;

      if v_strdestCustNo <> strCustNo then
        strResult := 'N|[E35008]'; --标签与当前客户不一致;
        return;
      end if;

      --首先检查此门店的状态
      begin

        select count(1)
          into v_iCount
          from odata_loadpropose_d t
         where t.enterprise_no = strEnterpriseNo
           and t.warehouse_no = strWareHouseNo
           and t.loadpropose_no = strProposeNo
           and t.deliver_obj = v_strDeliverObj
           and t.cust_no = strCustNo
           and status = '12';

        if v_iCount > 0 then
          strResult := 'N|[此车上当前配送对象已经扫描结束]';
          return;
        end if;

      end;

    end if;

    strResult := 'Y|[成功]';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_CheckCanLoadLabel;
  /******************************************************************************************************
  功能说明：1、校验派车单是否可装车

  *******************************************************************************************************/
  procedure P_GetCarPlan(strEnterpriseNo  in odata_carplan_volume.enterprise_no%type, --企业编码
                         strWareHouseNo   in odata_carplan_volume.warehouse_no%type, --仓库编码
                         strCarPlanNo     in odata_carplan_volume.car_plan_no%type,
                         strOutCustNo     out odata_carplan_volume.cust_no%type,
                         strOutDeliverObj out stock_label_m.deliver_obj%type,
                         strCloseFlag     out odata_loadpropose_m.loadtype%type, --封车标识，1：可封车；0：不可封车
                         strResult        OUT varchar2) is
    v_nLoadOrder integer;
    v_iCount     integer;
  begin
    strResult    := 'N|[P_GetCarPlan]';
    strCloseFlag := '0';
    --首先判断是否有单
    select count(*)
      into v_iCount
      from odata_carplan_volume ocv
     where ocv.enterprise_no = strEnterpriseNo
       and ocv.warehouse_no = strWareHouseNo
       and ocv.car_plan_no = strCarPlanNo
       and ocv.status < '13';
    if v_iCount = 0 then
      strResult := 'N|[此派车单不存在或没有要装车的数据]';
      return;
    else
      begin
        select a.load_order, a.cust_no, a.deliver_obj
          into v_nLoadOrder, strOutCustNo, strOutDeliverObj
          from (select ocv.load_order, ocv.cust_no, ocv.deliver_obj
                  from odata_carplan_volume ocv
                 where ocv.enterprise_no = strEnterpriseNo
                   and ocv.warehouse_no = strWareHouseNo
                   and ocv.car_plan_no = strCarPlanNo
                   and ocv.status in ('10', '11')
                 order by ocv.load_order) a
         where rownum = 1;
      exception
        when no_data_found then
          strCloseFlag := '1';
      end;
    end if;

    strResult := 'Y|[]';
  end P_GetCarPlan;
  /******************************************************************************************************
  功能说明：1、读取派车单号，返回首先要装车的单和客户
            2、校验此客户是否可装车
            此功能适用于配送对象按单的处理方式。

  *******************************************************************************************************/
  procedure P_GetCarPlanAndCheck(strEnterpriseNo  in odata_carplan_volume.enterprise_no%type, --企业编码
                                 strWareHouseNo   in odata_carplan_volume.warehouse_no%type, --仓库编码
                                 strCarPlanNo     in odata_carplan_volume.car_plan_no%type, --派车单号
                                 strUserId        in odata_loadpropose_m.rgst_name%type, --用户
                                 strDockNo        in odata_loadpropose_m.dock_no%type, --码头
                                 strDivideTrunk   in odata_loadpropose_m.divide_truck%type, -- 分车编号，若没有写N
                                 strLoadType      in odata_loadpropose_m.loadtype%type, -- --装车类型：1：按承运商；2：线路；3：配送对象（客户\单）5，按码头6：派车单
                                 strProposeNo     out odata_loadpropose_m.loadpropose_no%type, --返回的装车建议单号
                                 strOutCustNo     out odata_carplan_volume.cust_no%type, --返回的客户
                                 strOutDeliverObj out stock_label_m.deliver_obj%type,
                                 strCloseFlag     out odata_loadpropose_m.loadtype%type, --封车标识，1：可封车；0：不可封车
                                 strResult        OUT varchar2) is
    --v_nLoadOrder   integer;
    v_strLineNo    odata_carplan_volume.line_no%type;
    v_strShipperNo odata_carplan_volume.shipper_no%type;
    v_strCarNo     odata_carplan_volume.car_no%type;
    v_Owner_No     bdef_defowner.owner_no%type;
    v_Wave_No      odata_locate_m.wave_no%type;
    v_ManyRows     boolean := false;
  begin
    strResult := 'N|[P_GetCarPlanAndCheck]';

    --锁派车单号
    update odata_carplan_volume t
       set t.status = status
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWareHouseNo
       and t.car_plan_no = strCarPlanNo;

    --校验此派车单是否可装车
    P_GetCarPlan(strEnterpriseNo,
                 strWareHouseNo,
                 strCarPlanNo,
                 strOutCustNo,
                 strOutDeliverObj,
                 strCloseFlag,
                 strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    begin
      select distinct b.owner_no, b.wave_no
        into v_Owner_No, v_Wave_No
        from odata_exp_m b, odata_carplan_volume m
       where m.enterprise_no = strEnterpriseNo
         and m.car_plan_no = strCarPlanNo
         and m.warehouse_no = strWareHouseNo
         and b.warehouse_no = m.warehouse_no
         and b.enterprise_no = m.enterprise_no
         and b.exp_type = m.exp_type
         and b.exp_no = m.exp_no;
    exception
      when no_data_found then
        strResult := 'N|[找不装车计划单号]-' || strCarPlanNo;
        return;
      when TOO_MANY_ROWS then
        v_ManyRows := true;
    end;

    --判断此配送对象是否可装车
    --Modify BY QZH AT 2016-7-26
    if v_ManyRows = false then
      P_CheckCanLoadCarFromExp(strEnterpriseNo,
                               strWareHouseNo,
                               v_Owner_No,
                               v_Wave_No,
                               strOutDeliverObj,
                               strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;
    end if;

    --获取派车单上的信息
    begin
      select ocv.line_no, ocv.shipper_no, ocv.car_no
        into v_strLineNo, v_strShipperNo, v_strCarNo
        from odata_carplan_volume ocv
       where ocv.enterprise_no = strEnterpriseNo
         and ocv.warehouse_no = strWareHouseNo
         and ocv.car_plan_no = strCarPlanNo
         and rownum = 1;
    exception
      when no_data_found then
        strResult := 'N|[找不到对应的派车单]';
        return;
    end;

    --读取或新建装车建议单
    P_CreateLoadPropose(strEnterpriseNo,
                        strWareHouseNo,
                        'N',
                        v_strShipperNo,
                        v_strLineNo,
                        v_strCarNo,
                        strUserId,
                        strDockNo,
                        strDivideTrunk,
                        strcarPlanNo,
                        'N',
                        strLoadType,
                        strUserId,
                        strProposeNo,
                        strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    strResult := 'Y|[]';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_GetCarPlanAndCheck;

  /******************************************************************************************************
  功能说明：扫描标签装车；
          处理：1、判断此门店是否已结束扫描，若结束扫描，系统给予拦截；
                2、若是扫描中状态状态，则写装车数据
  ******************************************************************************************************/
  procedure P_CreateLoadItem(strEnterpriseNo in odata_loadpropose_m.enterprise_no%type, --企业编码
                             strWareHouseNo  in odata_loadpropose_m.warehouse_no%type, --仓库编码
                             strProposeNo    in odata_loadpropose_m.loadpropose_no%type,
                             strCustNo       in odata_loadpropose_m.cust_no%type,
                             strLabelNo      in stock_label_m.label_no%type,
                             strUserId       in odata_loadpropose_m.rgst_name%type,
                             strResult       OUT varchar2) is
    v_Owner_No      bdef_defowner.owner_no%type;
    v_Wave_No       odata_locate_m.wave_no%type;
    v_strDeliverObj odata_loadpropose_d.deliver_obj%type;
    v_ManyRows      boolean := false;
  begin
    strResult := 'N|[P_CreateLoadItem]';

    --锁装车建议单号
    update odata_loadpropose_m t
       set t.status = t.status
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWareHouseNo
       and t.loadpropose_no = strProposeNo;

    if sql%notfound then
      --
      strResult := 'N|[找不到对应的装车建议单号]';
      return;
    end if;

    begin
      select b.owner_no
        into v_Owner_No
        from bdef_defcust b
       where b.enterprise_no = strEnterpriseNo
         and b.cust_no = strCustNo;
    exception
      when no_data_found then
        strResult := 'N|[客户资料不存在-' || strCustNo;
        return;
        return;
    end;

    --获取配送对象
    begin
      select m.deliver_obj, m.wave_no
        into v_strDeliverObj, v_Wave_No
        from stock_label_m m
       where enterprise_no = strEnterpriseNo
         and warehouse_no = strWareHouseNo
         and label_no = strLabelNo;
    exception
      when no_data_found then
        strResult := 'N|[找不到对应的标签-' || strLabelNo;
        return;
      when TOO_MANY_ROWS then
        v_ManyRows := true;
    end;

    --判断此配送对象是否可装车
    --Modify BY QZH AT 2016-7-26
    if v_ManyRows = false then
      P_CheckCanLoadCarFromExp(strEnterpriseNo,
                               strWareHouseNo,
                               v_Owner_No,
                               v_Wave_No,
                               v_strDeliverObj,
                               strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;
    end if;

    --判断此--校验
    P_CheckCanLoadLabel(strEnterpriseNo,
                        strWareHouseNo,
                        strProposeNo,
                        strCustNo,
                        strLabelNo,
                        strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    PKOBJ_ODATA_DELIVER.P_odata_loadcarItem(strEnterpriseNo,
                                            strWareHouseNo,
                                            strProposeNo,
                                            strLabelNo,
                                            strUserId,
                                            strUserId,
                                            strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;
    strResult := 'Y|[]';
  end P_CreateLoadItem;

  /***********************************************************************************************8***
  功能说明：1、校验此单是否可装车；
            2、校验此容器是否可装车；
            3、写装车建议单明细；
            4、返回要装车的客户和单号

  *******************************************************************************************************/
  procedure P_SaveLoadItem(strEnterpriseNo  in odata_loadpropose_m.enterprise_no%type, --企业编码
                           strWareHouseNo   in odata_loadpropose_m.warehouse_no%type, --仓库编码
                           strProposeNo     in odata_loadpropose_m.loadpropose_no%type,
                           strCarPlanNo     in odata_loadpropose_m.car_plan_no%type, --派车单号，若无记N
                           strCustNo        in odata_loadpropose_m.cust_no%type,
                           strDeliverObj    in odata_exp_m.exp_no%type, --当前配送对象
                           strLabelNo       in stock_label_m.label_no%type,
                           strUserId        in odata_loadpropose_m.rgst_name%type,
                           strOutCustNo     out odata_loadpropose_m.cust_no%type, --下一客户
                           strOutDeliverObj out odata_loadpropose_d.deliver_obj%type, --下一配送对象
                           strCloseFlag     out odata_loadpropose_m.loadtype%type, --封车标识，1：可封车；0：不可封车
                           strResult        OUT varchar2) is
    v_Owner_No bdef_defowner.owner_no%type;
    v_Wave_No  odata_locate_m.wave_no%type;
    v_ManyRows boolean := false;
  begin
    strResult := 'N|[P_SaveLoadItem]';

    --锁装车建议单号
    update odata_loadpropose_m t
       set t.status = t.status
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWareHouseNo
       and t.loadpropose_no = strProposeNo;

    begin
      select distinct b.owner_no, m.wave_no
        into v_Owner_No, v_Wave_No
        from bdef_defcust b, stock_label_m m
       where b.enterprise_no = strEnterpriseNo
         and b.cust_no = strCustNo
         and m.enterprise_no = strEnterpriseNo
         and m.warehouse_no = strWareHouseNo
         and m.label_no = strLabelNo
         and m.enterprise_no = b.enterprise_no
         and m.cust_no = b.cust_no;
    exception
      when no_data_found then
        strResult := 'N|[找不到对应的标签-' || strLabelNo;
        return;
      when TOO_MANY_ROWS then
        v_ManyRows := true;
    end;

    --判断此配送对象是否可装车
    --Modify BY QZH AT 2016-7-26
    if v_ManyRows = false then
      P_CheckCanLoadCarFromExp(strEnterpriseNo,
                               strWareHouseNo,
                               v_Owner_No,
                               v_Wave_No,
                               strDeliverObj,
                               strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;
    end if;

    --校验此容器是否可装车
    P_CheckCanLoadLabel(strEnterpriseNo,
                        strWareHouseNo,
                        strProposeNo,
                        strCustNo,
                        strLabelNo,
                        strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;
    --写装车明细

    PKOBJ_ODATA_DELIVER.P_odata_loadcarItem(strEnterpriseNo,
                                            strWareHouseNo,
                                            strProposeNo,
                                            strLabelNo,
                                            strUserId,
                                            strUserId,
                                            strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    --获取
    P_CloseExp(strEnterpriseNo,
               strWareHouseNo,
               strProposeNo,
               strCustNo,
               strDeliverObj,
               strCarPlanNo,
               strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    --获取要装车的客户和配送对象

    P_GetCarPlan(strEnterpriseNo,
                 strWareHouseNo,
                 strCarPlanNo,
                 strOutCustNo,
                 strOutDeliverObj,
                 strCloseFlag,
                 strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;
    strResult := 'Y|[]';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_SaveLoadItem;

  /********************************************************************************************************
  功能说明：1、判断单据是否扫描完，若扫描完
            2。1更新装车建议单装车
            2。2更新派车单装车

           此过程适用于按配送对象是出货单的情况
  ********************************************************************************************************/
  procedure P_CloseExp(strEnterpriseNo in odata_loadpropose_m.enterprise_no%type, --企业编码
                       strWareHouseNo  in odata_loadpropose_m.warehouse_no%type, --仓库编码
                       strProposeNo    in odata_loadpropose_m.loadpropose_no%type,
                       strCustNo       in odata_loadpropose_m.cust_no%type,
                       strDeliverObj   in odata_loadpropose_d.deliver_obj%type,
                       srrCarPlanNo    in odata_loadpropose_m.car_plan_no%type,
                       strResult       OUT varchar2) is
    v_iCount integer;
  begin
    strResult := 'N|[P_CloseCust]';
    --判断此装车建议单状态是否正常

    update odata_loadpropose_m
       set status = status
     where enterprise_no = strEnterpriseNo
       and warehouse_no = strWareHouseNo
       and loadpropose_no = strProposeNo
       and status < '13';

    if sql%notfound then
      strResult := 'N|[找不到对应的装车建议单]';
      return;
    end if;

    --检查此配送对象是否还有未装车的标签
    select count(*)
      into v_iCount
      from stock_label_m slm
     where slm.deliver_obj = strDeliverObj
       and slm.enterprise_no = strEnterpriseNo
       and slm.warehouse_no = strWareHouseNo
       and (slm.status <> 'A1' and slm.status <> '60')
       and slm.cust_no = strCustNo;
    if v_iCount > 0 then
      strResult := 'Y|[]';
      return;
    else
      --结束扫描
      update odata_loadpropose_d t
         set t.status = '12'
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.loadpropose_no = strProposeNo
         and t.cust_no = strCustNo
         and t.deliver_obj = strDeliverObj
         and t.status = '10';

      --更新派车单上此配送对象的状态
      update odata_carplan_volume t
         set t.status = '12'
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.cust_no = strCustNo
         and t.car_plan_no = srrCarPlanNo
         and t.deliver_obj = strDeliverObj
         and t.status in ('10', '11');

    end if;
    strResult := 'Y|[]';

  end P_CloseExp;

  /********************************************************************************************************
  功能说明：1、客户扫描完成
            处理：1
  ********************************************************************************************************/
  procedure P_CloseCust(strEnterpriseNo in odata_loadpropose_m.enterprise_no%type, --企业编码
                        strWareHouseNo  in odata_loadpropose_m.warehouse_no%type, --仓库编码
                        strProposeNo    in odata_loadpropose_m.loadpropose_no%type,
                        strCustNo       in odata_loadpropose_m.cust_no%type,
                        strDeliverObj   in odata_loadpropose_d.deliver_obj%type, --配送对象
                        strUserId       in odata_loadpropose_m.updt_name%type, --装车人
                        strResult       OUT varchar2) is
    v_iCount integer;
  begin
    strResult := 'N|[P_CloseCust]';
    --判断此装车建议单状态是否正常

    update odata_loadpropose_m
       set status = status
     where enterprise_no = strEnterpriseNo
       and warehouse_no = strWareHouseNo
       and loadpropose_no = strProposeNo
       and status < '13';

    if sql%notfound then
      strResult := 'N|[找不到对应的装车建议单]';
      return;
    end if;

    --检查此客户是否已扫描完成
    select count(*)
      into v_iCount
      from odata_loadpropose_d t
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWareHouseNo
       and t.loadpropose_no = strProposeNo
       and t.cust_no = strCustNo
       and t.deliver_obj = strDeliverObj
       and t.status = '12';

    if v_iCount > 0 then
      strResult := 'N|[该配送已扫描完成]';
      return;
    end if;

    P_CheckCanDeliver(strEnterpriseNo,
                      strWareHouseNo,
                      strProposeNo,
                      strDeliverObj,
                      strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    --结束扫描
    update odata_loadpropose_d t
       set t.status = '12'
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWareHouseNo
       and t.loadpropose_no = strProposeNo
       and t.deliver_obj = strDeliverObj
       and t.cust_no = strCustNo
       and t.status = '10';
    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_CloseCust;
  /**********************************************************************************************************
     luozhiling
     2013.11.10
     功能：整单封车
     打印根据配置来 huangb 20160804
  ***********************************************************************************************************/
  procedure P_odata_deliver(strEnterpriseNo in odata_loadpropose_m.enterprise_no%type, --企业编码
                            strWareHouseNo  in odata_loadpropose_m.warehouse_no%type, --仓库编码
                            strProposeNo    in odata_loadpropose_m.loadpropose_no%type,
                            strUserId       in odata_loadpropose_m.updt_name%type, --装车人
                            strPaperUserId  in odata_loadpropose_m.updt_name%type, --单据人
                            strDeliverNo    out odata_deliver_m.deliver_no%type, --配送单号
                            strResult       OUT varchar2) is
    v_strLineNo    odata_loadpropose_m.line_no%type; --线路
    v_strShipperno odata_loadpropose_m.shipper_no%type; --承运商
    v_strCustNo    odata_loadpropose_m.Cust_No%type; --配送对象
    v_strLoadType  odata_loadpropose_m.loadtype%type; --装车类型
    v_strDockNo odata_loadpropose_m.dock_no%type;
    v_strPrtTask job_printtask_m.task_no%type;
    v_count      integer;
    v_strTotalReport    wms_outloadcar_strategy.totalprint_flag%type;--配送总单打印标识
    v_strLoadCarPrintBox        wms_outloadcar_strategy.boxitemprint_flag%type;
    v_strTotalDeliverPrint wms_outloadcar_strategy.totaldeliverprint_flag%type;--huangb 20160817配送总单2（含明细）
    v_strPrintDeliver   wms_outloadcar_strategy.deliverprint_flag%type;--huangb 20160817配送清单打印标识
    v_strWaveNo                 odata_locate_batch.wave_no%type;
    v_reportId           pntdef_report.report_id%type := 'N'; --报表ID huangb 20160804

  begin
    strResult := 'N|[P_odata_deliver]';
    --检查该客户对应的出货单是否都全部完成
    begin
      select olm.line_no, olm.shipper_no, olm.cust_no, loadtype, dock_no
        into v_strLineNo,
             v_strShipperno,
             v_strCustNo,
             v_strLoadType,
             v_strDockNo
        from odata_loadpropose_m olm
       where warehouse_no = strWareHouseNo
         and olm.enterprise_no = strEnterpriseNo
         and loadpropose_no = strProposeNo
         and status = '10';
    exception
      when no_data_found then
        strResult := 'N|[E22903]';
        return;
    end;

    --查检数据
    select count(*),max(slm.wave_no)
      into v_count,v_strWaveNo
      from odata_loadpropose_d a, stock_label_m slm
     where a.enterprise_no = slm.enterprise_no
       and a.warehouse_no = slm.warehouse_no
       and slm.owner_container_no = a.container_no
       and a.warehouse_no = strWareHouseNo
       and a.enterprise_no = strEnterpriseNo
       and a.status < '13'
       and a.loadpropose_no = strProposeNo;
    if v_count = 0 then
      strResult := 'N|[E22915]';
      return;
    End if;

    --获取策略对应的配置
    begin
        select wos.TotalPrint_flag,DeliverPrint_flag,TotalDeliverPrint_flag,BoxItemPrint_flag
               into v_strTotalReport,v_strPrintDeliver,v_strTotalDeliverPrint,v_strLoadCarPrintBox
         from odata_locate_batch olb,wms_outloadcar_strategy wos
        where olb.enterprise_no=wos.enterprise_no and olb.wave_no=v_strWaveNo
        and olb.LOAD_STRATEGY_ID=wos.LOADCAR_STRATEGY_ID
        and rownum=1;
    exception when no_data_found then
      strResult := 'N|[读取不到对应的装车策略]';
      return;
    end;


    for p in (select distinct d.deliver_obj
                from odata_loadpropose_d d
               where d.warehouse_no = strWareHouseNo
                 and d.enterprise_no = strEnterpriseNo
                 and d.status < '13'
                 and d.loadpropose_no = strProposeNo) loop

      P_CheckCanDeliver(strEnterpriseNo,
                        strWareHouseNo,
                        strProposeNo,
                        p.deliver_obj,
                        strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;
    end loop;

    --按配送对象循环产生装车单
    for p in (select d.deliver_obj,bd.owner_no, sum(d.box_num) box_num
                from odata_loadpropose_d d,bdef_defcust bd
               where d.warehouse_no = strWareHouseNo
                 and d.enterprise_no = strEnterpriseNo
                 and d.status < '13'
                 and d.loadpropose_no = strProposeNo
                 and d.cust_no=bd.cust_no
               group by d.deliver_obj,bd.owner_no) loop
        --新增出货配送单头档
        PKOBJ_ODATA_DELIVER.P_Insert_Odata_Deliver_M(strEnterpriseNo,
                                                     strWareHouseNo,
                                                     p.owner_no,
                                                     strProposeNo,
                                                     p.deliver_obj,
                                                     strUserId,
                                                     strDeliverNo,
                                                     strResult);
        if substr(strResult, 1, 1) <> 'Y' then
          return;
        end if;

        --写配送单明细
        PKOBJ_ODATA_DELIVER.P_Insert_Odata_Deliver_D(strEnterpriseNo,
                                                     strWareHouseNo,
                                                     strDeliverNo,
                                                     strProposeNo,
                                                     p.deliver_obj,
                                                     strUserId,
                                                     strResult);
        if substr(strResult, 1, 1) <> 'Y' then
          return;
        end if;

        if v_strPrintDeliver = '1' then --写配送清单打印任务
            --获取报表ID huangb 20160804
            PKLG_WMS_Public.p_GetReportId
            (strEnterPriseNo,strWarehouseNo,CONST_REPORT_TYPE.ODATAOD,
             'L',strDeliverNo,v_reportId,strResult);
            if substr(strResult, 1, 1) <> 'Y' then
              return;
            end if;

            --写打印任务 CONST_REPORTID.RPT_OM_Deliver 出货配送总单
            PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterpriseNo,
                                                strWareHouseNo,
                                                strDeliverNo,
                                                0,
                                                v_reportId,
                                                v_strDockNo,
                                                0,
                                                strUserId,
                                                v_strPrtTask,
                                                strResult);
            if substr(strResult, 1, 1) <> 'Y' then
              return;
            end if;
        end if;

    end loop;


    --处理库存
    PKOBJ_STOCK.proc_OM_deliver_DelContent(strEnterpriseNo,
                                           strWareHouseNo,
                                           strProposeNo,
                                           '1',
                                           strUserId,
                                           strResult);
    if Substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    --更新标签状态；
    update stock_label_m t
       set t.status  = clabelstatus.DELIVERIED,
           updt_name = strUserId,
           updt_date = sysdate
     where t.warehouse_no = strWareHouseNo
       and t.enterprise_no = strEnterpriseNo
       AND t.CONTAINER_NO in
           (select container_no
              from odata_loadpropose_d
             where warehouse_no = strWareHouseNo
               and enterprise_no = strEnterpriseNo
               and loadpropose_no = strProposeNo);

    ------------新增标签日志----------------
    insert into STOCK_LABEL_LOG
      (enterprise_no,
       warehouse_no,
       LABEL_NO,
       CONTAINER_NO,
       OWNER_CELL_NO,
       CONTAINER_TYPE,
       OWNER_CONTAINER_NO,
       STATUS,
       RGST_NAME,
       RGST_DATE)
      select m.enterprise_no,
             m.warehouse_no,
             m.label_no,
             m.container_no,
             m.owner_cell_no,
             m.container_type,
             m.owner_container_no,
             CLabelStatus.ARRANGE_COMPLETE,
             strUserId,
             sysdate
        from STOCK_LABEL_M m
       where m.warehouse_no = strWareHouseNo
         and m.enterprise_no = strEnterpriseNo
         AND m.CONTAINER_NO in
             (select container_no
                from odata_loadpropose_d
               where warehouse_no = strWareHouseNo
                 and enterprise_no = strEnterpriseNo
                 and loadpropose_no = strProposeNo);


    for p in (select distinct container_no
                from odata_loadpropose_d
               where warehouse_no = strWareHouseNo
                 and enterprise_no = strEnterpriseNo
                 and loadpropose_no = strProposeNo) loop

      --打印箱明细任务 CONST_REPORTID.RPT_OM_Container_List 出货容器明细（配送箱明细）
      if v_strLoadCarPrintBox = '1' then
        --获取报表ID huangb 20160818
        PKLG_WMS_Public.p_GetReportId
        (strEnterPriseNo,strWarehouseNo,CONST_REPORT_TYPE.ODATAODBOX,
         'L',p.container_no,v_reportId,strResult);
        if substr(strResult, 1, 1) <> 'Y' then
          return;
        end if;

        PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterpriseNo,
                                            strWareHouseNo,
                                            p.container_no,
                                            0,
                                            v_reportId,
                                            v_strDockNo,
                                            0,
                                            strUserId,
                                            v_strPrtTask,
                                            strResult);
        if substr(strResult, 1, 1) <> 'Y' then
          return;
        end if;
      end if;

      --将扫描日志转历史
      --将此装车单上对应的扫描日志数据转历史
      insert into bdef_scan_loghty
        (enterprise_no,
         warehouse_no,
         scan_barcode,
         source_no,
         article_no,
         cell_no,
         label_no,
         qty,
         rgst_name,
         rgst_date,
         check_type,
         operate_date,
         merge_box_no,
         dept_no)
        select enterprise_no,
               warehouse_no,
               t.scan_barcode,
               t.source_no,
               t.article_no,
               t.cell_no,
               t.label_no,
               t.qty,
               t.rgst_name,
               t.rgst_date,
               t.check_type,
               t.operate_date,
               t.merge_box_no,
               t.dept_no
          from bdef_scan_log t
         where t.label_no in
               (select distinct label_no
                  from odata_loadpropose_d ol, stock_label_m slm
                 where ol.warehouse_no = slm.warehouse_no
                   and ol.enterprise_no = slm.enterprise_no
                   and ol.containeR_no = slm.owner_containeR_no
                   and ol.warehouse_no = strWareHouseNo
                   and ol.enterprise_no = strEnterpriseNo
                   and ol.loadpropose_no = strProposeNo);

      --删除扫描日志表数据
      delete from bdef_scan_log
       where label_no in
             (select distinct label_no
                from odata_loadpropose_d ol, stock_label_m slm
               where ol.warehouse_no = slm.warehouse_no
                 and ol.containeR_no = slm.owner_containeR_no
                 and ol.warehouse_no = strWareHouseNo
                 and ol.loadpropose_no = strProposeNo
                 and ol.enterprise_no = strEnterpriseNo);
      -------------标签转历史
      PKOBJ_LABEL.proc_RemoveLabel(strEnterpriseNo,
                                   strwarehouseno,
                                   p.container_no,
                                   strResult);
      if instr(strResult, 'N', 1, 1) = 1 then
        return;
      end if;
    end loop;

    if v_strTotalReport = '1' then
      --获取报表ID huangb 20160804
      v_reportId := 'N';
      PKLG_WMS_Public.p_GetReportId
      (strEnterPriseNo,strWarehouseNo,CONST_REPORT_TYPE.ODATAOL,
       'L',strProposeNo,v_reportId,strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;

      --写装车汇总单 CONST_REPORTID.RPT_OM_LoadTotalReport 出货装车汇总单
      PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterpriseNo,
                                          strWareHouseNo,
                                          strProposeNo,
                                          0,
                                          v_reportId,
                                          v_strDockNo,
                                          0,
                                          strUserId,
                                          v_strPrtTask,
                                          strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;
    end if;

    --根据装车单打印交运总单（含清单） huangb 20160817
    if v_strTotalDeliverPrint = '1' then
      --获取报表ID
      v_reportId := 'N';
      PKLG_WMS_Public.p_GetReportId
      (strEnterPriseNo,strWarehouseNo,CONST_REPORT_TYPE.ODATAOL1,
       'L',strProposeNo,v_reportId,strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;

      --写打印任务
      PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterpriseNo,
                                          strWareHouseNo,
                                          strProposeNo,
                                          0,
                                          v_reportId,
                                          v_strDockNo,
                                          0,
                                          strUserId,
                                          v_strPrtTask,
                                          strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;
    end if;

    --更新装车建议单头档
    update odata_loadpropose_m
       set status = '13', updt_name = strUserId, updt_date = sysdate
     where loadpropose_no = strProposeNo
       AND warehouse_no = strWareHouseNo
       and enterprise_no = strEnterpriseNo;

    --更新装车建议单明细
    update odata_loadpropose_d
       set status = '13'
     where loadpropose_no = strProposeNo
       AND warehouse_no = strWareHouseNo
       and enterprise_no = strEnterpriseNo;

    -- update  by sl 20151230 这里更新出货单状态需要循环所有的配送单
    for p in (select distinct deliver_no
                from odata_deliver_m
               where warehouse_no = strWareHouseNo
                 and enterprise_no = strEnterpriseNo
                 and loadpropose_no = strProposeNo) loop
      --更新出货单状态
      P_Exp_Over(strEnterpriseNo, strWareHouseNo, p.deliver_no, strUserId,strResult);
      if instr(strResult, 'N', 1, 1) = 1 then
        return;
      end if;
    END LOOP;

    --建议单头和明细转历史,预留
    --更新派车单状态
    update odata_carplan_volume t
       set t.status = '13'
     where t.enterprisE_no = strEnterpriseNo
       and t.warehouse_no = strWareHouseNo
       and t.car_plan_no in
           (select car_plan_no
              from odata_loadpropose_m
             where enterprise_no = strEnterpriseNo
               and warehouse_no = strWareHouseNo
               and loadpropose_no = strProposeNo);

    --释放月台资源
    FOR p IN (SELECT distinct d.exp_type, m.deliver_obj, d.wave_no, m.owner_no
                FROM ODATA_DELIVER_D d, odata_deliver_m m
               WHERE m.enterprise_no = d.enterprise_no
                 and m.warehouse_no = d.warehouse_no
                 and m.deliver_no = d.deliver_no
                 and m.loadpropose_no = strProposeNo
                 AND m.enterprise_no = strEnterPriseNo
                 AND m.warehouse_no = strWareHouseNo) LOOP

      PKLG_BUFFER_CALCULATE.P_Clear_DeliverArea_Cal(strEnterPriseNo,
                                                    strWareHouseNo,
                                                    p.owner_no,
                                                    p.wave_no,
                                                    p.deliver_obj,
                                                    p.exp_type,
                                                    strResult);
      if Substr(strResult, 1, 1) = 'N' then
        return;
      end if;
    END LOOP;

    --现在不写临时表。。。物流箱数直接从装车建议单明细取
    INSERT INTO odata_car_receipt
      (enterprise_no,
       warehouse_no,
       owner_no,
       wave_no,
       deliver_no,
       cust_no,
       deliver_box,
       car_no,
       status,
       rgst_name,
       rgst_date)
      SELECT DISTINCT strEnterPriseNo,
                      strWareHouseNo,
                      m.owner_no,
                      d.wave_no,
                      m.deliver_obj,
                      m.cust_no,
                      m.logbox_num,
                      m.car_plate,
                      '10',
                      strUserID,
                      SYSDATE
        FROM odata_deliver_m m, odata_deliver_d d
       WHERE m.warehouse_no = d.warehouse_no
         AND m.enterprise_no = d.enterprise_no
         AND m.deliver_no = d.deliver_no
         AND m.loadpropose_no = strProposeNo
         AND m.enterprise_no = strEnterPriseNo
         AND m.warehouse_no = strWareHouseNo
         AND m.logbox_num > 0;

  /*  --封车单据转历史(出货单和装车单据转历史) huangb 20160517
    PKOBJ_ODATA_DELIVER.P_Deliver_InsertHTY(strEnterpriseNo, --企业编码
                                            strWareHouseNo, --仓库编码
                                            strProposeNo,
                                            strUserID,
                                            strResult);
    if substr(strResult, 1, 1) <> 'Y' then
      return;
    end if;*/

    --更新配送单头档状态
    update odata_deliver_m
       set status = '13', updt_name = strUserId, updt_date = sysdate
     where LOADPROPOSE_NO = strProposeNo
       AND warehouse_no = strWareHouseNo
       and enterprise_no = strEnterpriseNo;

    --更新配送单明细状态
    update odata_deliver_d
       set status = '13', updt_name = strUserId, updt_date = sysdate
     where warehouse_no = strWareHouseNo
       and enterprise_no = strEnterpriseNo
       and deliver_no in
           (select deliver_no
              from odata_deliver_m
             where LOADPROPOSE_NO = strProposeNo
               AND warehouse_no = strWareHouseNo
               and enterprise_no = strEnterpriseNo);

    strResult := 'Y';

  end P_odata_deliver;

  /********************************************************************************************************
   功能说明：1、校验此标签是否能封车
                目前适用于天天惠模式

  **********************************************************************************************************/
  procedure P_CloseCar(strEnterpriseNo in odata_loadpropose_m.enterprise_no%type, --企业编码
                       strWareHouseNo  in odata_loadpropose_m.warehouse_no%type, --仓库编码
                       strProposeNo    in odata_loadpropose_m.loadpropose_no%type,
                       strUserId       in odata_loadpropose_m.updt_name%type, --装车人
                       strPaperUserId  in odata_loadpropose_m.updt_name%type, --单据人
                       strDeliverNo    out odata_deliver_m.deliver_no%type, --配送单号
                       strResult       OUT varchar2) is
    v_iCount       integer;
    v_strCustNo    odata_loadpropose_d.cust_no%type;
    v_strCarPlanNo odata_loadpropose_m.car_plan_no%type;
  begin
    strResult := 'N|[P_CloseCar_tth]';

    --检查是否此装车建议单可封车
    update odata_loadpropose_m t
       set t.status = status
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWareHouseNo
       and t.loadpropose_no = strProposeNo
       and t.status < '13';
    if sql%notfound then
      strResult := 'N|[此单已做封车]';
    end if;

    --查询派车单号
    begin
      select car_plan_no
        into v_strCarPlanNo
        from odata_loadpropose_m
       where enterprise_no = strEnterpriseNo
         and warehouse_no = strWareHouseNo
         and loadpropose_no = strProposeNo;
    exception
      when no_data_found then
        strResult := 'N|[找不到装车建议单]';
        return;
    end;

    select count(*)
      into v_iCount
      from odata_carplan_volume t
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWareHouseNo
       and t.car_plan_no = v_strCarPlanNo
       and t.status < '12';

    if v_iCount > 0 THEN
      strResult := 'N|[还有未装车的单，不能封车]';
      return;
    end if;

    --预留：此处需要增加参数，门店是否需要分别封车
    --检查此装车建议单上的门店是否都已扫描完成
    begin
      select t.cust_no
        into v_strCustNo
        from odata_loadpropose_d t
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.loadpropose_no = strProposeNo
         AND t.status = '10'
         and rownum <= 1;
    exception
      when no_data_found then
        v_strCustNo := 'N';
    end;

    if v_strCustNo <> 'N' then
      strResult := 'N|[' || v_strCustNo || '没有扫描结束]';
      return;
    end if;

    P_Odata_Deliver(strEnterpriseNo,
                    strWareHouseNo,
                    strProposeNo,
                    strUserId,
                    strPaperUserId,
                    strDeliverNo,
                    strResult);
    if substr(strResult, 1, 1) <> 'Y' then
      return;
    end if;
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_CloseCar;

  /**********************************************************************************************************
     lich
     2014.06.05
     功能：校验此配送对象能否装车完成
  ***********************************************************************************************************/
  procedure P_CheckCanDeliver(strEnterpriseNo in odata_loadpropose_m.enterprise_no%type, --企业编码
                              strWareHouseNo  in odata_loadpropose_m.warehouse_no%type, --仓库编码
                              strProposeNo    in odata_loadpropose_m.loadpropose_no%type,
                              strDeliverObj   in odata_loadpropose_d.deliver_obj%type, --
                              strResult       OUT varchar2) is
    v_iCount         integer;
    v_strCanLoadFlag wms_defbase.sdefine%type;
    v_nCanLoadFlag   wms_defbase.sdefine%type;
    v_strOwnerNo     bdef_defowner.owner_no%type := 'N';
    --v_strCustNo      bdef_defcust.cust_no%type;
    v_strLabelNo stock_label_m.label_no%type;
  begin
    strResult := 'N|[P_CheckCanDeliver]';

    --Modify BY QZH AT 2016-7-26
    for curLoadPropose in (select distinct b.owner_no, b.wave_no
                             from odata_loadpropose_d a, stock_label_d b
                            where a.enterprise_no = strEnterpriseNo
                              and a.warehouse_no = strWareHouseNo
                              and a.loadpropose_no = strProposeNo
                              and a.deliver_obj = strDeliverObj
                              and a.enterprise_no = b.enterprise_no
                              and a.warehouse_no = b.warehouse_no
                              and a.container_no = b.container_no) loop

      if v_strOwnerNo <> curLoadPropose.Owner_No then
        v_strOwnerNo := curLoadPropose.Owner_No;
        --获取系统参数 判断是否需要校验订单完成才扫描结束
        PKLG_WMS_BASE.p_GetBasePara(strEnterpriseNo,
                                    strWareHouseNo,
                                    v_strOwnerNo,
                                    'CanLoad_Flag',
                                    'O',
                                    'O_LOADCAR',
                                    v_strCanLoadFlag,
                                    v_nCanLoadFlag,
                                    strResult);
        if substr(strResult, 1, 1) = 'N' then
          strResult := 'N|[E30025]';
          return;
        end if;

        if v_strCanLoadFlag = '0' then
          --不校验
          goto next_loop;
        end if;
      end if;

      --*******************装车类型承运商**************
      select count(*)
        into v_icount
        from odata_exp_d t
       where t.exp_no in
             (select distinct sld.exp_no
                from odata_loadpropose_d ol, stock_label_d sld
               where ol.warehouse_no = sld.warehouse_no
                 and ol.containeR_no = sld.container_no
                 and ol.status in ('10')
                 and sld.wave_no = curLoadPropose.Wave_No
                 and ol.warehouse_no = strWareHouseNo
                 and ol.loadpropose_no = strProposeNo
                 and ol.deliver_obj = strDeliverObj)
         and t.warehouse_no = strWareHouseNo
         and t.status <'12'
         and t.enterprise_no = strEnterpriseNo;

      if v_iCount > 0 then
        strResult := 'N|[E22519]';
        return;
      end if;

      select count(*)
        into v_icount
        from odata_locate_d t
       where t.deliver_obj = strDeliverObj
         and t.warehouse_no = strWareHouseNo
         and t.status <'13'
         and t.enterprise_no = strEnterpriseNo
         and t.wave_no = curLoadPropose.Wave_No;

      if v_iCount > 0 then
        strResult := 'N|[E22519]';
        return;
      end if;

      --检查此装车单上的订单是否还有拣货指示未发单
      select count(*)
        into v_iCount
        from odata_outstock_direct T
       where t.deliver_obj = strDeliverObj
         and t.warehouse_no = strWareHouseNo
         and t.status <'13'
         and t.enterprise_no = strEnterpriseNo
         and t.wave_no = curLoadPropose.Wave_No;
      if v_iCount > 0 then
        strResult := 'N|[E22520]';
        return;
      end if;

      --检查此承运商是否还有拣货单未回单
      select count(*)
        into v_iCount
        from odata_outstock_d t
       where t.deliver_obj = strDeliverObj
         and t.warehouse_no = strWareHouseNo
         and t.enterprise_no = strEnterpriseNo
         and t.wave_no = curLoadPropose.Wave_No
         and t.status < '13';
      if v_iCount > 0 then
        strResult := 'N|[E22521]';
        return;
      end if;

      --检查此承运商是否还有分播未回单
      select count(*)
        into v_iCount
        from odata_divide_d t
       where t.deliver_obj = strDeliverObj
         and t.warehouse_no = strWareHouseNo
         and t.enterprise_no = strEnterpriseNo
         and t.wave_no = curLoadPropose.Wave_No
         and t.status < '13';
      if v_iCount > 0 then
        strResult := 'N|[E22522]';
        return;
      end if;

      --检查次配送对象是否还有未装车的标签
      begin
        select t.label_no
          into v_strLabelNo
          from stock_label_m t
         where t.enterprise_no = strEnterpriseNo
           and t.warehouse_no = strWareHouseNo
           and t.deliver_obj = strDeliverObj
           and t.status < 'A1'
              --排除已经做了装并板的箱子（装车不改子标签的状态）
           AND t.container_no = t.owner_container_no
           and t.status <> clabelstatus.NEW_LABEL_NO
           and t.wave_no = curLoadPropose.Wave_No
           and rownum = 1;

        strResult := 'N|' || v_strLabelNo || '[标签未装车]';
        return;
      exception
        when no_data_found then
          strResult := 'Y|';
      end;

      <<next_loop>>
      null;
    end loop;
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_CheckCanDeliver;

  /**********************************************************************************************************
     lich
     2014.06.05
     功能：前台界面校验能否装车,根据里临时表的数据
  ***********************************************************************************************************/
  procedure P_CheckCanLoadCar(strEnterpriseNo in odata_loadcar_tmp.enterprise_no%type, --企业编码
                              strWareHouseNo  in odata_loadcar_tmp.warehouse_no%type, --仓库编码
                              strTmpId        in odata_loadcar_tmp.tmp_id%type, --标识
                              strResult       OUT varchar2) is
    v_iCount integer;
    --v_strCanLoadFlag wms_defbase.sdefine%type;
    --v_nCanLoadFlag   wms_defbase.sdefine%type;
    --v_strOwnerNo     stock_label_d.owner_no%type;
    --v_strLabeNo      stock_label_m.label_no%type;
  begin
    strResult := 'N|[P_CheckCanLoadCar]';

    select count(*)
      into v_iCount
      from odata_loadcar_tmp a, stock_label_d b, odata_locate_d c
     where a.container_no = b.container_no
       and b.exp_no = c.exp_no
       and b.enterprise_no = c.enterprise_no
       and b.warehouse_no = c.warehouse_no
       and a.tmp_id = strTmpId
       and a.enterprise_no = strEnterpriseNo
       and a.warehouse_no = strWareHouseNo;
    if v_iCount > 0 then
      strResult := 'N|[E22519]';
      return;
    end if;
    --检查是否还有拣货指示未发单
    select count(*)
      into v_iCount
      from odata_loadcar_tmp a, stock_label_d b, odata_outstock_direct c
     where a.container_no = b.container_no
       and a.enterprise_no = b.enterprise_no
       and a.warehouse_no = b.warehouse_no
       and b.exp_no = c.exp_no
       and a.tmp_id = strTmpId
       and c.enterprise_no = strEnterpriseNo
       and c.warehouse_no = strWareHouseNo
       and c.status < '13';
    if v_iCount > 0 then
      strResult := 'N|[E22520]';
      return;
    end if;

    --检查此线路是否还有拣货单未回单
    select count(*)
      into v_iCount
      from odata_loadcar_tmp a, stock_label_d b, odata_outstock_d c
     where a.container_no = b.container_no
       and a.warehouse_no = b.warehouse_no
       and a.enterprise_no = b.enterprise_no
       and b.exp_no = c.exp_no
       and b.enterprise_no = c.enterprise_no
       and b.warehouse_no = c.warehouse_no
       and a.tmp_id = strTmpId
       and c.warehouse_no = strWareHouseNo
       and c.enterprise_no = strEnterpriseNo
       and c.status < '13';
    if v_iCount > 0 then
      strResult := 'N|[E22521]';
      return;
    end if;

    --检查是否还有分播未回单
    select count(*)
      into v_iCount
      from odata_loadcar_tmp a, stock_label_d b, odata_divide_d c
     where a.container_no = b.container_no
       and a.warehouse_no = b.warehouse_no
       and a.enterprise_no = b.enterprise_no
       and b.exp_no = c.exp_no
       and b.enterprise_no = c.enterprise_no
       and b.warehouse_no = c.warehouse_no
       and a.tmp_id = strTmpId
       and c.warehouse_no = strWareHouseNo
       and c.enterprise_no = strEnterpriseNo
       and c.status < '13';
    if v_iCount > 0 then
      strResult := 'N|[E22522]';
      return;
    end if;

    --所有标签必须为A0
    select count(*)
      into v_iCount
      from odata_loadcar_tmp a, stock_label_m b
     where a.container_no = b.container_no
       and a.warehouse_no = b.warehouse_no
       and a.enterprise_no = b.enterprise_no
       and (b.status <> clabelstatus.WAIT_LOAD_CAR and
           b.status <> clabelstatus.NEW_LABEL_NO)
       and a.tmp_id = strTmpId
       and a.enterprise_no = strEnterpriseNo
       and a.warehouse_no = strWareHouseNo;
    if v_iCount > 0 then
      strResult := 'N|[E22523]';
      return;
    end if;

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_CheckCanLoadCar;

  /**********************************************************************************************************
     lich
     2014.06.05
     功能：校验能否装车，按单做校验
     修改配送对象为客户 则 获取从客户表中取 huangb 20160709
  ***********************************************************************************************************/
  procedure P_CheckCanLoadCarFromExp(strEnterpriseNo in odata_loadcar_tmp.enterprise_no%type, --企业编码
                                     strWareHouseNo  in odata_loadcar_tmp.warehouse_no%type, --仓库编码
                                     strOwner_No     in bdef_defowner.owner_no%type,
                                     strWave_No      in odata_deliver_d.wave_no%type,
                                     strDeliver_Obj  in odata_deliver_m.deliver_obj%type, --配送对象
                                     strResult       OUT varchar2) is
    v_iCount         integer;
    v_strCanLoadFlag wms_defbase.sdefine%type;
    v_nCanLoadFlag   wms_defbase.sdefine%type;
    --v_strOwnerNo     bdef_defowner.owner_no%type;
  begin
    strResult := 'N|[P_CheckCanLoadCarFromExp]';

    --获取系统参数 判断是否需要校验订单完成才扫描结束
    PKLG_WMS_BASE.p_GetBasePara(strEnterpriseNo,
                                strWareHouseNo,
                                strOwner_No,
                                'CanLoad_Flag',
                                'O',
                                'O_LOADCAR',
                                v_strCanLoadFlag,
                                v_nCanLoadFlag,
                                strResult);
    if substr(strResult, 1, 1) = 'N' then
      strResult := 'N|[E30025]';
      return;
    end if;

    if v_strCanLoadFlag = '0' then
      strResult := 'Y|[]';
      return;
    end if;

    select count(*)
      into v_iCount
      from stock_label_d b, odata_locate_d c
     where b.enterprise_no = c.enterprise_no
       and b.warehouse_no = c.warehouse_no
       and b.exp_no = c.exp_no
       and b.article_no = c.article_no
       and b.enterprise_no = strEnterpriseNo
       and b.warehouse_no = strWareHouseNo
       and b.wave_no = strWave_No
       and b.deliver_obj = strDeliver_Obj;
    if v_iCount > 0 then
      strResult := 'N|[E22519]';
      return;
    end if;
    --检查是否还有拣货指示未发单
    select count(*)
      into v_iCount
      from stock_label_d b, odata_outstock_direct c
     where b.enterprise_no = c.enterprise_no
       and b.warehouse_no = c.warehouse_no
       and b.exp_no = c.exp_no
       and b.article_no = c.article_no
       and b.enterprise_no = strEnterpriseNo
       and b.warehouse_no = strWareHouseNo
       and c.status < '13'
       and b.wave_no = strWave_No
       and b.deliver_obj = strDeliver_Obj;
    if v_iCount > 0 then
      strResult := 'N|[E22520]';
      return;
    end if;

    --检查此线路是否还有拣货单未回单
    select count(*)
      into v_iCount
      from stock_label_d b, odata_outstock_d c
     where b.enterprise_no = c.enterprise_no
       and b.warehouse_no = c.warehouse_no
       and b.exp_no = c.exp_no
       and b.article_no = c.article_no
       and b.enterprise_no = strEnterpriseNo
       and b.warehouse_no = strWareHouseNo
       and b.deliver_obj = strDeliver_Obj
       and b.wave_no = strWave_No
       and c.status < '13';
    if v_iCount > 0 then
      strResult := 'N|[E22521]';
      return;
    end if;

    --检查是否还有分播未回单
    select count(*)
      into v_iCount
      from stock_label_d b, odata_divide_d c
     where b.enterprise_no = c.enterprise_no
       and b.warehouse_no = c.warehouse_no
       and b.exp_no = c.exp_no
       and b.article_no = c.article_no
       and b.enterprise_no = strEnterpriseNo
       and b.warehouse_no = strWareHouseNo
       and b.deliver_obj = strDeliver_Obj
       and b.wave_no = strWave_No
       and c.status < '13';
    if v_iCount > 0 then
      strResult := 'N|[E22522]';
      return;
    end if;

    --所有标签必须为A0
    select count(*)
      into v_iCount
      from stock_label_d a, stock_label_m b
     where a.container_no = b.container_no
       and a.warehouse_no = b.warehouse_no
       and a.enterprise_no = b.enterprise_no
       and b.status < clabelstatus.WAIT_LOAD_CAR
       and b.status <> clabelstatus.NEW_LABEL_NO
       and a.enterprise_no = strEnterpriseNo
       and a.warehouse_no = strWareHouseNo
       and a.wave_no = strWave_No
       and a.deliver_obj = strDeliver_Obj;
    if v_iCount > 0 then
      strResult := 'N|[该配送对象还有标签未完成]';
      return;
    end if;

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_CheckCanLoadCarFromExp;

  /**********************************************************************************************************
     wyf
     2015.08.21
     功能：更新出货单状态
  ***********************************************************************************************************/
  procedure P_Exp_Over(strEnterpriseNo in odata_deliver_d.enterprise_no%type, --企业编码
                       strWareHouseNo  in odata_deliver_d.warehouse_no%type, --仓库编码
                       strDeliverNo    in odata_deliver_d.deliver_no%type,
                       strUserID       in bdef_defworker.worker_no%type,
                       strResult       OUT varchar2) is
    v_nCount integer;
  begin
    strResult := 'N|[P_Exp_Over]';
    for p in (select distinct t.exp_no
                from odata_exp_m t
               where t.warehouse_no = strWareHouseNo
                 and t.enterprise_no = strEnterpriseNo
                 and exists
               (select 1
                        from odata_deliver_d odd
                       where odd.warehouse_no = t.warehouse_no
                         and odd.enterprise_no = t.enterprise_no
                         and odd.owner_no = t.owner_no
                         and odd.exp_no = t.exp_no
                         AND odd.deliver_no = strDeliverNo)) loop
      --校验出货单状态是否为12已定位
      select count(1)
        into v_nCount
        from odata_exp_m t
       where t.warehouse_no = strWareHouseNo
         and t.enterprise_no = strEnterpriseNo
         and t.exp_no = p.exp_no
         and t.status = '12';
      if v_nCount = 0 then
        goto NextExp;
      end if;
      --校验出货单下架指示状态
      select count(1)
        into v_nCount
        from odata_outstock_direct ood
       where ood.warehouse_no = strWareHouseNo
         and ood.exp_no = p.exp_no
         and ood.status<'13'
         and ood.enterprise_no = strEnterpriseNo;
      if v_nCount > 0 then
        goto NextExp;
      end if;
      --校验出货单拣货单状态
      select count(1)
        into v_nCount
        from odata_outstock_d ood
       where ood.warehouse_no = strWareHouseNo
         and ood.exp_no = p.exp_no
         and ood.status<'13'
         and ood.enterprise_no = strEnterpriseNo;
      if v_nCount > 0 then
        goto NextExp;
      end if;
      --校验出货单分播状态
      select count(1)
        into v_nCount
        from odata_divide_d ood
       where ood.warehouse_no = strWareHouseNo
         and ood.exp_no = p.exp_no
         and ood.status<'13'
         and ood.enterprise_no = strEnterpriseNo;
      if v_nCount > 0 then
        goto NextExp;
      end if;
      --校验出货单装车状态
      select count(1)
        into v_nCount
        from stock_label_d t
       where t.warehouse_no = strWareHouseNo
         and t.enterprise_no = strEnterpriseNo
         and t.exp_no = p.exp_no;
      if v_nCount > 0 then
        goto NextExp;
      end if;
      --更新出货单状态
      update odata_exp_m t
         set t.status = '13', t.exp_status = '50'
       where t.warehouse_no = strWareHouseNo
         and t.enterprise_no = strEnterpriseNo
         and t.exp_no = p.exp_no;

      --Add BY QZH AT 2016-8-20单据状态跟踪
      PKOBJ_ODISPATCH.P_Insert_Odata_Exp_Trace(strEnterPriseNo,
                                               strWareHouseNo,
                                               p.exp_no,
                                               COdataExpStatus.ExpTracAllDeliver,--已封车
                                               strUserID,
                                               strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;

      <<NextExp>>
      null;
    end loop;
    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_Exp_Over;

  /**********************************************************************************************************************
  功能：自动封车,只适用于配送对象是出货单的情况
       luozhiling
  2015.6.1
  *********************************************************************************************************************/
  procedure P_AutoCloseCar(strEnterPriseNo in odata_outstock_m.enterprise_no%type, --企业号
                           strWareHouseNo  in odata_outstock_m.warehouse_no%type, --仓别
                           strExpNo        in odata_outstock_m.outstock_no%type, --下架单号
                           strDock_No      in odata_outstock_m.dock_no%type, --工作站
                           strUserID       in odata_outstock_m.rgst_name%type, --回单人
                           strOutMsg       out varchar2) is
    v_iCount         integer;
  --  v_strExpNo       odata_outstock_d.exp_no%type;
    v_strProposeNo   odata_loadpropose_m.loadpropose_no%type; --建议单号
    v_strDeliverNo   odata_loadpropose_m.loadpropose_no%type; --配送单号
    v_Wave_No        odata_exp_m.wave_no%type;
    v_strCanLoadFlag wms_defbase.sdefine%type;
    v_nCanLoadFlag   wms_defbase.sdefine%type;
    v_strOwnerNo     stock_label_d.owner_no%type;
  begin
    strOutMsg := 'Y|[]';

    --获取货主
    begin
      select t.owner_no, t.wave_no
        into v_strOwnerNo, v_Wave_No
        from odata_exp_m t
       where t.exp_no = strExpNo
         and t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strWareHouseNo;
    exception
      when no_data_found then
        strOutMsg := 'N|[找不到对应的出货单号-' || strExpNo;
        return;
    end;

    --获取系统参数 判断是否需要校验订单完成才装车
    PKLG_WMS_BASE.p_GetBasePara(strEnterpriseNo,
                                strWareHouseNo,
                                v_strOwnerNo,
                                'CanLoad_Flag',
                                'O',
                                'O_LOADCAR',
                                v_strCanLoadFlag,
                                v_nCanLoadFlag,
                                strOutMsg);
    if substr(strOutMsg, 1, 1) = 'N' then
      strOutMsg := 'N|[E30025]';
      return;
    end if;

    /*Modify BY QZH AT 2016-7-26*/
    if v_strCanLoadFlag = '1' then
      P_CheckCanLoadCarFromExp(strEnterpriseNo,
                               strWareHouseNo,
                               v_strOwnerNo,
                               v_Wave_No,
                               strExpNo,
                               strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
    end if;

    --写建议单明细

    for p in (select distinct slm.container_no, slm.label_no,slm.deliver_obj
                from stock_label_d sld, stock_label_m slm
               where slm.enterprise_no = sld.enterprise_no
                 and slm.warehouse_no = sld.warehouse_no
                 and slm.container_no = sld.container_no
                 and slm.warehouse_no = strWareHouseNo
                 and slm.enterprise_no = strEnterpriseNo
                 and sld.exp_no = strExpNo) loop
      v_iCount := v_iCount + 1;
      if v_iCount=1 then
           --写建议单头档
          PKOBJ_ODATA_DELIVER.P_odata_loadcarHead(strEnterpriseNo,
                                                  strWareHouseNo,
                                                  p.deliver_obj,
                                                  'N',
                                                  'N',
                                                  'N',
                                                  strUserId,
                                                  strDock_No,
                                                  strUserId,
                                                  'N',
                                                  strUserId,
                                                  '4',
                                                  v_strProposeNo,
                                                  strOutMsg);
          if substr(strOutMsg, 1, 1) = 'N' then
            return;
          end if;
      end if;
      --写建议单明细档
      PKOBJ_ODATA_DELIVER.P_odata_loadcarItem(strEnterpriseNo,
                                              strWareHouseNo,
                                              v_strProposeNo,
                                              p.label_no, --strContainerNo,
                                              strUserId,
                                              strUserId,
                                              strOutMsg);
      if substr(strOutMsg, 1, 1) = 'N' then
        return;
      end if;
    end loop;

    if v_iCount=0 then
       strOutMsg:='N|[没有找到对应的装车数据，请检查]';
       return;
    end if;

    --封车
    if v_iCount > 0 then
      pklg_odata_deliver.P_odata_deliver(strEnterpriseNo,
                                         strWareHouseNo,
                                         v_strProposeNo,
                                         strUserId,
                                         strUserId,
                                         v_strDeliverNo,
                                         strOutMsg);
      if substr(strOutMsg, 1, 1) = 'N' then
        return;
      end if;
    end if;

    strOutMsg := 'Y|[成功]';
  end P_AutoCloseCar;

  /**********************************************************************************************************************
  功能：装车，扫描（客户，箱标签，板标签）
       sunl 2016.03.17
  *********************************************************************************************************************/
  procedure P_S_ScanLabelNo(strEnterPriseNo   in stock_label_m.enterprise_no%type, --企业号
                            strWareHouseNo    in stock_label_m.warehouse_no%type, --仓别
                            strScanNo         in stock_label_m.label_no%type, --扫描数据
                            strProposeNo      in odata_loadpropose_m.loadpropose_no%type, --装车建议单
                            strDeliverObj     out varchar2, --配送对象
                            strWaveNo         out varchar2, --波次
                            strBufferNo       out varchar2, --暂存区
                            strScanLabelCount out number, --已扫数量
                            strNotScanCount   out number, --未扫数量
                            strCustNo         out varchar2, --客户编码
                            strCustName       out varchar2, --客户名称
                            strOutMsg         out varchar2) IS
    v_hasConfirm    NUMBER; --标记当前是否可以继续操作
    v_scanNo        stock_label_m.label_no%type;
    v_oldDeliverObj stock_label_m.deliver_obj%TYPE;
    v_oldCustNo     stock_label_m.cust_no%TYPE;
  BEGIN
    strOutMsg         := 'N|[P_S_ScanLabelNo]';
    strDeliverObj     := '';
    strWaveNo         := '';
    strBufferNo       := '';
    strCustNo         := '';
    strCustName       := '';
    strScanLabelCount := 0;
    strNotScanCount   := 0;
    v_scanNo          := upper(strScanNo);
    v_oldDeliverObj   := '';
    v_oldCustNo       := '';

    --校验当前扫描的数据是否有效
    BEGIN
      strCustNo := '';
      --1. 校验是否是客户
      BEGIN
        SELECT c.cust_no
          INTO strCustNo
          FROM bdef_defcust c
         WHERE c.cust_no = v_scanNo;
      exception
        when no_data_found then
          --2. 校验是否是标签
          BEGIN
            SELECT m.cust_no
              INTO strCustNo
              FROM stock_label_m m
             WHERE m.label_no = v_scanNo
               AND m.warehouse_no = strWareHouseNo
               AND m.enterprise_no = strEnterPriseNo;
          exception
            when no_data_found then
              strCustNo := '';
          END;
      END;
      IF (strCustNo IS NULL) THEN
        strOutMsg := 'N|[不是有效的客户或标签]';
        RETURN;
      END IF;
      v_hasConfirm := 0;
      --3. 校验当前的客户是否有待装车状态的标签
      SELECT COUNT(0)
        INTO v_hasConfirm
        FROM stock_label_m m
       WHERE m.warehouse_no = strWareHouseNo
         AND m.enterprise_no = strEnterPriseNo
         AND m.cust_no = strCustNo
         AND m.status = 'A0'
         AND m.hm_manual_flag = '0';
      IF (v_hasConfirm = 0) THEN
        strOutMsg := 'N|[当前的客户或标签没有待装车的数据]';
        RETURN;
      END IF;
    END;
    IF (strCustNo = v_scanNo) THEN
      ---获取返回数据
      SELECT c.wave_no, f.buffer_name, dc.cust_name, m.deliver_obj
        INTO strWaveNo, strBufferNo, strCustName, strDeliverObj
        FROM stock_label_m             m,
             odata_send_area_calculate c,
             oset_buffer               f,
             bdef_defcust              dc
       WHERE m.warehouse_no = c.warehouse_no
         AND m.enterprise_no = c.enterprise_no
         AND m.deliver_obj = c.deliver_obj
         AND c.warehouse_no = f.warehouse_no
         AND c.enterprise_no = f.enterprise_no
         AND c.ware_no = f.ware_no
         AND c.area_no = f.area_no
         AND c.stock_no = f.stock_no
         AND c.cell_no = f.cell_no
         AND m.cust_no = dc.cust_no
         AND m.warehouse_no = strWareHouseNo
         AND m.enterprise_no = strEnterPriseNo
         AND m.cust_no = strCustNo
         AND rownum = 1;
    ELSE
      SELECT c.wave_no, f.buffer_name, dc.cust_name, m.deliver_obj
        INTO strWaveNo, strBufferNo, strCustName, strDeliverObj
        FROM stock_label_m             m,
             odata_send_area_calculate c,
             oset_buffer               f,
             bdef_defcust              dc
       WHERE m.warehouse_no = c.warehouse_no
         AND m.enterprise_no = c.enterprise_no
         AND m.deliver_obj = c.deliver_obj
         AND c.warehouse_no = f.warehouse_no
         AND c.enterprise_no = f.enterprise_no
         AND c.ware_no = f.ware_no
         AND c.area_no = f.area_no
         AND c.stock_no = f.stock_no
         AND c.cell_no = f.cell_no
         AND m.cust_no = dc.cust_no
         AND m.warehouse_no = strWareHouseNo
         AND m.enterprise_no = strEnterPriseNo
         AND m.cust_no = strCustNo
         AND m.label_no = v_scanNo
         AND rownum = 1;
    END IF;

    --5. 校验当前的装车建议单是否有未做确认的建议单明细信息
    --如果有，则校验未确认的配送对象与扫描的客户或标签的配送对象是否一致，不一致返回AAAAA提示。
    BEGIN
      SELECT d.deliver_obj, d.cust_no
        INTO v_oldDeliverObj, v_oldCustNo
        FROM odata_loadpropose_d d
       WHERE d.warehouse_no = strWareHouseNo
         AND d.enterprise_no = strEnterPriseNo
         AND d.loadpropose_no = strProposeNo
         AND d.status = '10'
         AND d.deliver_obj <> strDeliverObj;
      IF (v_oldDeliverObj IS NOT NULL OR v_oldDeliverObj <> '') THEN
        strOutMsg := 'AAAAA' || v_oldDeliverObj || ',' || v_oldCustNo;
        RETURN;
      END IF;
    exception
      when no_data_found then
        v_oldDeliverObj := '';
        v_oldCustNo     := '';
    end;

    SELECT COUNT(0)
      INTO strNotScanCount
      FROM stock_label_m m
     WHERE m.container_no = m.owner_container_no
       AND m.deliver_obj = strDeliverObj
       AND m.warehouse_no = strWareHouseNo
       AND m.enterprise_no = strEnterPriseNo
       AND m.status = 'A0'
       AND m.hm_manual_flag = '0'
       AND m.hm_manual_flag = '0';

    SELECT COUNT(0)
      INTO strScanLabelCount
      FROM stock_label_m m
     WHERE m.container_no = m.owner_container_no
       AND m.deliver_obj = strDeliverObj
       AND m.warehouse_no = strWareHouseNo
       AND m.enterprise_no = strEnterPriseNo
       AND m.status = 'A1'
       AND m.hm_manual_flag = '0'
       AND m.hm_manual_flag = '0';

    strOutMsg := 'Y|[成功]';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_S_ScanLabelNo;

  /**********************************************************************************************************************
  功能：装车，扫描（板标签）,输入（物流箱数）
       sunl 2016.03.17
  *********************************************************************************************************************/
  procedure P_S_LoadCar(strEnterPriseNo   in stock_label_m.enterprise_no%type, --企业号
                        strWareHouseNo    in stock_label_m.warehouse_no%type, --仓别
                        strCustNo         in stock_label_m.cust_no%type, --客户
                        strScanNo         in stock_label_m.label_no%type, --扫描数据
                        strBoxCount       in number, --物流箱数
                        strProposeNo      in odata_loadpropose_m.loadpropose_no%type, --装车建议单
                        strUserID         in stock_label_m.rgst_name%type, --装车人
                        strWaveNo         IN VARCHAR2, --波次号
                        strScanLabelCount out number, --已扫数量
                        strNotScanCount   out number, --未扫数量
                        strOutMsg         out varchar2) IS
    v_hasConfirm    NUMBER;
    v_strDeliverObj stock_label_m.deliver_obj%type;
    v_scanNo        stock_label_m.label_no%type;
    v_containerNo   stock_label_m.container_no%type;
  BEGIN
    strOutMsg := 'N|[P_S_LoadCar]';
    v_scanNo  := upper(strScanNo);
    --1. 校验当前扫描的标签号是否是有效的
    SELECT COUNT(0)
      INTO v_hasConfirm
      FROM stock_label_m m
     WHERE m.warehouse_no = strWareHouseNo
       AND m.enterprise_no = strEnterPriseNo
       AND m.cust_no = strCustNo
       AND m.label_no = v_scanNo
       AND m.status = 'A0'
       AND m.container_no = m.owner_container_no;
    IF (v_hasConfirm = 0) THEN
      strOutMsg := 'N|[当前扫描的标签不能装车]';
      RETURN;
    END IF;
    v_hasConfirm := 0;
    SELECT COUNT(0)
      INTO v_hasConfirm
      FROM stock_label_m m
     WHERE m.warehouse_no = strWareHouseNo
       AND m.enterprise_no = strEnterPriseNo
       AND m.cust_no = strCustNo
       AND m.label_no = v_scanNo
       AND m.status = 'A0'
       AND m.container_no = m.owner_container_no
       AND m.hm_manual_flag = '1';
    IF (v_hasConfirm = 0) THEN
      strOutMsg := 'N|[请先做装并板]';
      RETURN;
    END IF;

    --2. 调装车
    P_CreateLoadItem(strEnterpriseNo,
                     strWareHouseNo,
                     strProposeNo,
                     strCustNo,
                     v_scanNo,
                     strUserID,
                     strOutMsg);
    if substr(strOutMsg, 1, 1) = 'N' then
      return;
    end if;

     --获取配送对象
    SELECT m.deliver_obj, m.container_no
      into v_strDeliverObj, v_containerNo
      FROM stock_label_m m
     WHERE m.label_no = v_scanNo
       AND m.warehouse_no = strWareHouseNo
       AND m.enterprise_no = strEnterPriseNo;

    ---现在不写临时表，将当前的物流箱数，写入装车建议单明细表
    UPDATE odata_loadpropose_d d
       SET d.box_num = strBoxCount --+  d.box_num
     WHERE d.loadpropose_no = strProposeNo
       AND d.warehouse_no = strWareHouseNo
       AND d.enterprise_no = strEnterPriseNo
       AND d.deliver_obj = v_strDeliverObj
       and d.container_no = v_containerNo;


    --5. 返回信息
    SELECT COUNT(0)
      INTO strNotScanCount
      FROM stock_label_m m
     WHERE m.container_no = m.owner_container_no
       AND m.deliver_obj = v_strDeliverObj
       AND m.warehouse_no = strWareHouseNo
       AND m.enterprise_no = strEnterPriseNo
       AND m.status = 'A0'
       AND m.hm_manual_flag = '0';

    SELECT COUNT(0)
      INTO strScanLabelCount
      FROM stock_label_m m
     WHERE m.container_no = m.owner_container_no
       AND m.deliver_obj = v_strDeliverObj
       AND m.warehouse_no = strWareHouseNo
       AND m.enterprise_no = strEnterPriseNo
       AND m.status = 'A1'
       AND m.hm_manual_flag = '0';

    strOutMsg := 'Y|[成功]';
  END P_S_LoadCar;

  /**********************************************************************************************************************
  功能：封车，输入（车辆编码）
       sunl 2016.03.17
  *********************************************************************************************************************/
  procedure P_S_CloseCar(strEnterPriseNo in stock_label_m.enterprise_no%type, --企业号
                         strWareHouseNo  in stock_label_m.warehouse_no%type, --仓别
                         strCarNo        in stock_label_m.label_no%type, --车辆编码
                         strProposeNo    in odata_loadpropose_m.loadpropose_no%type, --装车建议单
                         strDriverWorker in bdef_defcar.driver_worker%type, --司机
                         strUserID       in stock_label_m.rgst_name%type, --封车人
                         strOutMsg       out varchar2) IS
    v_iCount       integer;
    strDeliverNo   odata_deliver_m.deliver_no%TYPE;
    v_strCarPlanNo odata_loadpropose_m.car_plan_no%type;
    v_strCustNo    odata_loadpropose_d.cust_no%type;
    v_car_plate    bdef_defcar.car_plate%type;
    v_DriverWorker bdef_defcar.driver_worker%type := 'N'; --司机
  BEGIN
    strOutMsg := 'N|[P_S_CloseCar]';

    ---这个封车需要重新处理！！！sunl 2016年3月18日
    --注意事项：1. 可能会出现，板已装车，但未做客户扫描完成（装车后直接退出RF界面）的情况，需要提示用户是否强制封车
    --         2.参照现有的封车的过程，重新写一个，配送单明细需要按标签明细处理

    --1.封车
    BEGIN
      --判断司机是否合法
      begin
        select DISTINCT t.worker_no
          into v_DriverWorker
          from bdef_defworker t
         where t.enterprise_no = strEnterPriseNo
           --and t.warehouse_no = strWareHouseNo
           and upper(t.worker_no) = upper(strDriverWorker);
      exception
        when no_data_found then
          stroutmsg := 'N|[输入的司机不存在]';
          return;
      end;
      --检查是否此装车建议单可封车
      update odata_loadpropose_m t
         set t.status = status
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.loadpropose_no = strProposeNo
         and t.status < '13';
      if sql%notfound then
        strOutMsg := 'N|[此单已做封车]';
      end if;

      --查询派车单号
      begin
        select car_plan_no
          into v_strCarPlanNo
          from odata_loadpropose_m
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and loadpropose_no = strProposeNo;
      exception
        when no_data_found then
          strOutMsg := 'N|[找不到装车建议单]';
          return;
      end;

      select count(*)
        into v_iCount
        from odata_carplan_volume t
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.car_plan_no = v_strCarPlanNo
         and t.status < '12';

      if v_iCount > 0 THEN
        strOutMsg := 'N|[还有未装车的单，不能封车]';
        return;
      end if;

      --预留：此处需要增加参数，门店是否需要分别封车
      --检查此装车建议单上的门店是否都已扫描完成
      begin
        select t.cust_no
          into v_strCustNo
          from odata_loadpropose_d t
         where t.enterprise_no = strEnterpriseNo
           and t.warehouse_no = strWareHouseNo
           and t.loadpropose_no = strProposeNo
           AND t.status = '10'
           and rownum <= 1;
      exception
        when no_data_found then
          v_strCustNo := 'N';
      end;

      if v_strCustNo <> 'N' then
        strOutMsg := 'N|[' || v_strCustNo || '没有扫描结束]';
        return;
      end if;
      v_car_plate := '';
      begin
        --获取车牌号
        SELECT c.car_plate
          into v_car_plate
          FROM bdef_defcar c
         WHERE c.car_no = strCarNo
         and c.enterprise_no=strEnterPriseNo
         and c.warehouse_no=strWareHouseNo;

        --更新当前的车辆编码到装车建议单头档
        update odata_loadpropose_m t
           set t.car_plate = v_car_plate
         where t.enterprise_no = strEnterpriseNo
           and t.warehouse_no = strWareHouseNo
           and t.loadpropose_no = strProposeNo
           and t.status < '13';
        if sql%notfound then
          strOutMsg := 'N|[此单已做封车]';
        end if;
      exception
        when no_data_found then
          v_car_plate := 'N';
          --现场现在未维护车辆信息
          strOutMsg := 'N|[未找到车辆信息]';
          --return;
      end;

      ---新封车处理逻辑
      P_odata_Deliver(strEnterpriseNo,
                      strWareHouseNo,
                      strProposeNo,
                      strUserId,
                      strUserId,
                      strDeliverNo,
                      strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
      --更新封车单发货人员
      update odata_deliver_m
         set send_name = v_DriverWorker
       where enterprise_no = strEnterPriseNo
         and warehouse_no = strWareHouseNo
         and loadpropose_no = strProposeNo;
      if sql%notfound then
        strOutMsg := 'N|[未产生配送单据]';
        return;
      end if;
    END;

    strOutMsg := 'Y|[成功]';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  END P_S_CloseCar;

  /**********************************************************************************************************
   hb insert to 20160606
   装车-根据承运商装车
  ************************************************************************************************************/
  procedure P_CreateLoadMByShipper(strEnterpriseNo   in odata_loadpropose_m.enterprise_no%type, --企业编码
                                   strWareHouseNo    in odata_loadpropose_m.warehouse_no%type, --仓库编码
                                   strDeliverObj     in stock_label_m.deliver_obj%type, --配送对象（客户编码、单号）
                                   strShipperNo      in odata_loadpropose_m.shipper_no%type, --承运商编码
                                   strLineNo         in odata_loadpropose_m.line_no%type, --线路
                                   strCarNo          in bdef_defcar.car_no%type, ---车辆编码
                                   strUserId         in odata_loadpropose_m.rgst_name%type,
                                   strDockNo         in odata_loadpropose_m.dock_no%type,
                                   strDivideTrunk    in odata_loadpropose_m.divide_truck%type, --分车编号
                                   strcarPlanNo      IN odata_loadpropose_m.car_plan_no%type, --派车计划单
                                   strSealNo         in Odata_Loadpropose_m.Seal_No%type, --封条号
                                   strLoadType       in odata_loadpropose_m.loadtype%type, --装车类型：1：按承运商；2：线路；3：配送对象（客户\单）5，按码头6：派车单
                                   strProposeNo      out odata_loadpropose_m.loadpropose_no%type,
                                   strShipperName    out bdef_defshipper.shipper_name%type, --返回承运商名称
                                   strScanLabelCount out number, --当前建议单已扫数量
                                   strResult         OUT varchar2) is

    v_strProposeNo   odata_loadpropose_m.loadpropose_no%type := 'N';
    v_ShipperName    bdef_defshipper.shipper_name%type := 'N';
    v_ScanLabelCount number;
    v_nCount         number;
  begin
    strResult := 'N|[P_CreateLoadByShipper]';

    if strLoadType = '1' then
      --首先根据承运商获取装车建议单号
      begin
        select olm.loadpropose_no
          into v_strProposeNo
          from odata_loadpropose_m olm
         where olm.enterprise_no = strEnterpriseNo
           and olm.warehouse_no = strWareHouseNo
           and olm.loadtype = strLoadType
           and olm.shipper_no = strShipperNo
           and olm.status = '10';
      exception
        when no_data_found then
          v_strProposeNo := 'N';
          v_nCount       := 0;
          select count(1)
            into v_nCount
            from pntset_printer_workstation ppd
           where ppd.enterprise_no = strEnterpriseNo
             and ppd.warehouse_no = strWareHouseNo
             and ppd.workstation_no = strDockNo;
          if v_nCount <= 0 then
            strResult := 'N|[没有设定打印机组]';
            return;
          end if;
      end;

      --获取承运商名称
      begin
        select bds.shipper_name
          into v_ShipperName
          from bdef_defshipper bds
         where bds.enterprise_no = strEnterpriseNo
           and bds.warehouse_no = strWareHouseNo
           and bds.shipper_no = strShipperNo;
      exception
        when no_data_found then
          v_ShipperName := 'N';
          strResult     := 'N|[获取承运商名称失败]';
          return;
      end;

    end if;

    --若查询不到数据，需要新建装车建议单
    if v_strProposeNo = 'N' then
      pkobj_odata_deliver.P_odata_loadcarHead(strEnterpriseNo,
                                              strWareHouseNo,
                                              strDeliverObj,
                                              strShipperNo,
                                              strLineNo,
                                              strCarNo,
                                              strUserId,
                                              strDockNo,
                                              strDivideTrunk,
                                              strcarPlanNo,
                                              strSealNo,
                                              strLoadType,
                                              v_strProposeNo,
                                              strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;
    end if;

    if v_strProposeNo = 'N' then
      strResult := 'N|[装车类型暂不支持]';
      return;
    end if;

    select count(distinct container_no)
      into v_ScanLabelCount
      from odata_loadpropose_d
     where enterprise_no = strEnterpriseNo
       and warehouse_no = strWareHouseNo
       and LOADPROPOSE_NO = v_strProposeNo;

    strScanLabelCount := v_ScanLabelCount;
    strProposeNo      := v_strProposeNo;
    strShipperName    := v_ShipperName;

    strResult := 'Y|[成功]';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_CreateLoadMByShipper;

  /******************************************************************************************************
   hb insert to 20160606
   装车-根据承运商新增装车建议单单明细
   增加具体标签状态提示 huangb 20160831
  ******************************************************************************************************/
  procedure P_CreateLoadDByShipper(strEnterpriseNo   in odata_loadpropose_m.enterprise_no%type, --企业编码
                                   strWareHouseNo    in odata_loadpropose_m.warehouse_no%type, --仓库编码
                                   strProposeNo      in odata_loadpropose_m.loadpropose_no%type,
                                   strLabelNo        in stock_label_m.label_no%type,
                                   strUserId         in odata_loadpropose_m.rgst_name%type,
                                   strScanLabelCount out number, --当前建议单已扫数量
                                   strOutMsg         out varchar2) is

    v_strDeliverObj   odata_loadpropose_d.deliver_obj%type;
    v_ScanLabelCount  number;
    v_hasConfirm      NUMBER;
    v_scanNo          stock_label_m.label_no%type;
    v_weight          stock_label_m.weight%type; --重量
    v_ContainerNo     stock_label_m.container_no%type;
    v_checkWeightFlag WMS_OUTLOADCAR_STRATEGY.Check_Package_Weight%type;

    v_Exp_No          odata_exp_m.exp_no%type;
    v_loadShipperNo   odata_loadpropose_m.shipper_no%type;
    v_loadShipperName bdef_defshipper.shipper_name%type;
    v_LabelStatus     stock_label_m.status%type; --标签状态 huangb 20160831
    v_LabelStatusDesc wms_deflabel_status.status_name%type; --标签状态描述 huangb 20160831
  begin
    strOutMsg := 'N|[P_CreateLoadDByShipper]';

    v_scanNo := strLabelNo; --upper(strLabelNo);
    --获取配送对象
    begin
      select slm.deliver_obj, slm.weight, slm.container_no, slm.status, wds.status_name
        into v_strDeliverObj, v_weight, v_ContainerNo, v_LabelStatus, v_LabelStatusDesc
        from stock_label_m slm
       inner join wms_deflabel_status wds
          on wds.status_type = slm.status
       where slm.enterprise_no = strEnterpriseNo
         and slm.warehouse_no = strWareHouseNo
         and slm.label_no = v_scanNo;
    exception
      when no_data_found then
        strOutMsg := 'N|[找不到对应的标签]';
        return;
    end;

    if v_LabelStatus <> 'A0' then
      strOutMsg := 'N|[当前标签状态为【'|| v_LabelStatusDesc ||'】,不能装车]';
      RETURN;
    end if;

    --1. 校验当前扫描的标签号是否是有效的
    /*SELECT COUNT(0)
      INTO v_hasConfirm
      FROM stock_label_m m
     WHERE m.warehouse_no = strWareHouseNo
       AND m.enterprise_no = strEnterPriseNo
       AND m.label_no = v_scanNo
       AND m.status = 'A0'
       AND m.container_no = m.owner_container_no;
    IF (v_hasConfirm = 0) THEN
      strOutMsg := 'N|[当前扫描的标签不能装车]';
      RETURN;
    END IF;*/

    v_hasConfirm := 0;
    SELECT COUNT(0)
      INTO v_hasConfirm
      FROM stock_label_m m
     WHERE m.warehouse_no = strWareHouseNo
       AND m.enterprise_no = strEnterPriseNo
       AND m.label_no = v_scanNo
       AND m.status = 'A0'
       AND m.container_no = m.owner_container_no
       AND m.hm_manual_flag = '0';
    IF (v_hasConfirm = 0) THEN
      strOutMsg := 'N|[请先做装并板]';
      RETURN;
    END IF;

    --Add BY QZH AT 2016-8-20
    if nvl(v_weight, 0) <= 0 then
      begin
        select check_package_weight
          into v_checkWeightFlag
          from (select w.check_package_weight
                  from WMS_OUTLOADCAR_STRATEGY w
                 where exists
                 (select 'x'
                          from odata_locate_batch olb, stock_label_d sld
                         where olb.enterprise_no = sld.enterprise_no
                           and olb.warehouse_no = sld.warehouse_no
                           and olb.batch_no = sld.batch_no
                           and olb.wave_no = sld.wave_no
                           and olb.enterprise_no = w.enterprise_no
                           and olb.load_strategy_id = w.loadcar_strategy_id
                           and sld.container_no = v_ContainerNo)
                   and w.check_package_weight > '0'
                 order by w.check_package_weight desc)
         where rownum <= 1;
      exception
        when no_data_found then
          v_checkWeightFlag := '0';
      end;

      if v_checkWeightFlag = '2' then
        strOutMsg := 'N|[' || strLabelNo || ']未称重!';
        return;
      end if;

      --此处需界面确认
      if v_checkWeightFlag = '1' then
        strOutMsg := 'W|[' || strLabelNo || ']未称重，是否继续?';
        return;
      end if;
    end if;

    --锁装车建议单号
    update odata_loadpropose_m t
       set t.status = t.status
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWareHouseNo
       and t.loadpropose_no = strProposeNo;

    if sql%notfound then
      strOutMsg := 'N|[找不到对应的装车建议单号]';
      return;
    end if;

    --获取装车建议单的承运商
    begin
      select olm.shipper_no, bds.shipper_name
        into v_loadShipperNo, v_loadShipperName
        from odata_loadpropose_m olm, bdef_defshipper bds
       where bds.enterprise_no = olm.enterprise_no
         and bds.warehouse_no = olm.warehouse_no
         and bds.shipper_no = olm.shipper_no
         and olm.enterprise_no = strEnterpriseNo
         and olm.warehouse_no = strWareHouseNo
         and olm.loadpropose_no = strProposeNo;
    exception
      when no_data_found then
        strOutMsg := 'N|[获取装车单承运商信息失败]';
        return;
    end;

    --获取出货单号的承运商 以作比较
    v_hasConfirm := 0;
    for expShipper in (select distinct oem.owner_no,
                                       oem.wave_no,
                                       oem.exp_no, --Add BY QZH AT 2016-8-20
                                       oem.shipper_no,
                                       bds.shipper_name,
                                       slm.deliver_obj
                         from odata_exp_m     oem,
                              stock_label_m   slm,
                              stock_label_d   sld,
                              bdef_defshipper bds
                        where sld.container_no = slm.container_no
                          and sld.enterprise_no = slm.enterprise_no
                          and sld.warehouse_no = slm.warehouse_no
                          and oem.exp_no = sld.exp_no
                          and oem.enterprise_no = sld.enterprise_no
                          and oem.warehouse_no = sld.warehouse_no
                          and oem.owner_no = sld.owner_no
                          and bds.shipper_no = oem.shipper_no
                          and bds.enterprise_no = oem.enterprise_no
                          and bds.warehouse_no = oem.warehouse_no
                          and slm.warehouse_no = strWareHouseNo
                          AND slm.enterprise_no = strEnterPriseNo
                          AND slm.label_no = v_scanNo) loop
      v_hasConfirm := v_hasConfirm + 1;

      --判断当前容器的承运商是否和装车建议单的承运商一致
      if expShipper.Shipper_No <> v_loadShipperNo then
        strOutMsg := 'N|[包裹对应得承运商(' || expShipper.Shipper_No ||
                     ')和建议单对应的承运商(' || v_loadShipperNo || ')不一致]';
        return;
      end if;

      --Modify BY QZH AT 2016-7-26 判断此配送对象
      P_CheckCanLoadCarFromExp(strEnterpriseNo,
                               strWareHouseNo,
                               expShipper.Owner_No,
                               expShipper.Wave_No,
                               expShipper.Deliver_Obj,
                               strOutMsg);
      if substr(strOutMsg, 1, 1) = 'N' then
        return;
      end if;

      v_Exp_No := expShipper.Exp_No;

    end loop;
    if v_hasConfirm <= 0 then
      strOutMsg := 'N|[获取出货单承运商信息失败]';
      return;
    end if;

    PKOBJ_ODATA_DELIVER.P_odata_loadcarItem(strEnterpriseNo,
                                            strWareHouseNo,
                                            strProposeNo,
                                            v_scanNo,
                                            strUserId,
                                            strUserId,
                                            strOutMsg);
    if substr(strOutMsg, 1, 1) = 'N' then
      return;
    end if;

    --Add BY QZH AT 2016-8-20单据状态跟踪
    PKOBJ_ODISPATCH.P_Insert_Odata_Exp_Trace(strEnterPriseNo,
                                             strWareHouseNo,
                                             v_Exp_No,
                                             COdataExpStatus.ExpTracAllLoad, --已装车
                                             strUserID,
                                             strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    select count(distinct container_no)
      into v_ScanLabelCount
      from odata_loadpropose_d
     where enterprise_no = strEnterpriseNo
       and warehouse_no = strWareHouseNo
       and LOADPROPOSE_NO = strProposeNo;

    strScanLabelCount := v_ScanLabelCount;
    strOutMsg         := 'Y|[]';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end P_CreateLoadDByShipper;

  /**********************************************************************************************************************
   hb insert to 20160606
   装车-根据承运商封车
  *********************************************************************************************************************/
  procedure P_DeliverCarByShipper(strEnterPriseNo in stock_label_m.enterprise_no%type, --企业号
                                  strWareHouseNo  in stock_label_m.warehouse_no%type, --仓别
                                  strProposeNo    in odata_loadpropose_m.loadpropose_no%type, --装车建议单
                                  strUserID       in stock_label_m.rgst_name%type, --封车人
                                  strOutMsg       out varchar2) IS
    v_count      number;
    strDeliverNo odata_deliver_m.deliver_no%TYPE;
    v_labelNo    varchar(200);
  BEGIN
    strOutMsg := 'N|[P_DeliverCarByShipper]';

    --检查是否此装车建议单可封车
    update odata_loadpropose_m t
       set t.status = status
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWareHouseNo
       and t.loadpropose_no = strProposeNo
       and t.status < '13';
    if sql%notfound then
      strOutMsg := 'N|[此单已做封车]';
    end if;

    --判断所有容器所对应的出货单是否已经全部装车
    v_count := 0;
    for notLoadCar in (select distinct slm.label_no
                         from (select sld.exp_no,
                                      sld.owner_no,
                                      sld.warehouse_no,
                                      sld.enterprise_no
                                 from stock_label_d       sld,
                                      odata_loadpropose_d od
                                where sld.container_no = od.container_no
                                  and sld.enterprise_no = od.enterprise_no
                                  and sld.warehouse_no = od.warehouse_no
                                  and od.enterprise_no = strEnterpriseNo
                                  and od.warehouse_no = strWareHouseNo
                                  and od.loadpropose_no = strProposeNo) t,
                              stock_label_d sld,
                              stock_label_m slm
                        where sld.container_no = slm.container_no
                          and sld.enterprise_no = slm.enterprise_no
                          and sld.warehouse_no = slm.warehouse_no
                          and sld.exp_no = t.exp_no
                          and sld.enterprise_no = t.enterprise_no
                          and sld.warehouse_no = t.warehouse_no
                          and slm.status not like 'F%'
                          and not exists
                        (select 'X'
                                 from odata_loadpropose_d od
                                where sld.container_no = od.container_no
                                  and sld.enterprise_no = od.enterprise_no
                                  and sld.warehouse_no = od.warehouse_no
                                  and od.enterprise_no = strEnterpriseNo
                                  and od.warehouse_no = strWareHouseNo
                                  and od.loadpropose_no = strProposeNo)) loop

      v_count   := v_count + 1;
      v_labelNo := v_labelNo || v_labelNo || ',';

      --一次只提示5个包裹
      if v_count = 5 then
        exit;
      end if;
    end loop;

    if v_count <> 0 then
      strOutMsg := 'N|[以下包裹(' || v_labelNo || ')]还未装进当前承运商中';
      return;
    end if;

    --新封车处理逻辑
    P_odata_Deliver(strEnterpriseNo,
                    strWareHouseNo,
                    strProposeNo,
                    strUserId,
                    strUserId,
                    strDeliverNo,
                    strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    strOutMsg := 'Y|[成功]';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  END P_DeliverCarByShipper;

  /**********************************************************************************************************************
  功能：按客户波次装车检查扫描数据(客户或客户标签)的合法性
  huangb 20160707
  *********************************************************************************************************************/
  procedure P_Check_ScanDataByWaveNo(strEnterPriseNo in stock_label_m.enterprise_no%type, --企业号
                                     strWareHouseNo  in stock_label_m.warehouse_no%type, --仓别
                                     strScanNo       in stock_label_m.label_no%type, --扫描数据
                                     strOutCustNo    out bdef_defcust.cust_no%type, --客户编号
                                     strOutMsg       out varchar2) IS
    v_Count  number;
    v_CustNo bdef_defcust.cust_no%type;
    v_scanNo stock_label_m.label_no%type := upper(strScanNo);
  begin
    strOutMsg := 'N|[P_Check_ScanDataByWave]';

    --校验是否是客户
    begin
      select c.cust_no
        into v_CustNo
        from bdef_defcust c
       where c.cust_no = v_scanNo;
    exception
      when no_data_found then
        --校验是否是标签
        begin
          select m.cust_no
            into v_CustNo
            from stock_label_m m
           where m.enterprise_no = strEnterPriseNo
             and m.warehouse_no = strWareHouseNo
             and m.label_no = v_scanNo;
        exception
          when no_data_found then
            stroutmsg := 'N|[不是有效的客户或标签]';
            return;
        end;
    end;

    --校验当前的客户是否有待装车状态的标签
    select count(0)
      into v_Count
      from stock_label_m m
     where m.enterprise_no = strEnterPriseNo
       and m.warehouse_no = strWareHouseNo
       and m.cust_no = v_CustNo
       and m.status = 'A0'
       and m.hm_manual_flag = '0';
    if (v_Count = 0) then
      stroutmsg := 'N|[当前的客户或标签没有待装车的数据]';
      return;
    end if;

    strOutCustNo := v_CustNo;
    strOutMsg    := 'Y|[成功]';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end P_Check_ScanDataByWaveNo;

  /**********************************************************************************************************************
  功能：按客户波次装车
  huangb 20160707
  *********************************************************************************************************************/
  procedure P_LoadCarByWaveNo(strEnterPriseNo in stock_label_m.enterprise_no%type,--企业号
                              strWareHouseNo  in stock_label_m.warehouse_no%type,--仓别
                              strCustNo       in stock_label_m.cust_no%type,--客户
                              strBoxCount     in number,--物流箱数
                              strProposeNo    in odata_loadpropose_m.loadpropose_no%type,--装车建议单
                              strUserID       in stock_label_m.rgst_name%type,--装车人
                              strWaveNo       IN stock_label_m.wave_no%type,--波次号
                              strOutMsg       out varchar2) IS
		v_hasConfirm NUMBER := 0;
    v_iCount     number := 0;

	BEGIN
    strOutMsg:='N|[P_LoadCarByWave]';

    --循环当前波次下的标签
    for t in (select slm.enterprise_no,
                     slm.warehouse_no,
                     slm.label_no,
                     slm.container_no,
                     slm.deliver_obj,
                     slm.wave_no,
                     slm.cust_no
                from stock_label_m slm
               where slm.enterprise_no = strEnterPriseNo
                 and slm.warehouse_no = strWareHouseNo
                 and slm.cust_no = strCustNo
                 and slm.wave_no = strWaveNo
                 and slm.status = 'A0'
                 and slm.hm_manual_flag = '0') loop
      v_hasConfirm := v_hasConfirm + 1;

      select count(*)
        into v_iCount
        from odata_locate_d c
       where c.enterprise_no = strEnterpriseNo
         and c.warehouse_no = strWareHouseNo
         and c.cust_no = t.cust_no
         and c.wave_no = t.wave_no;
      if v_iCount > 0 then
        strOutMsg := 'N|[E22519]';
        return;
      end if;

      --检查是否还有拣货指示未发单
      select count(*)
        into v_iCount
        from odata_outstock_direct c
       where c.enterprise_no = strEnterpriseNo
         and c.warehouse_no = strWareHouseNo
         and c.cust_no = t.cust_no
         and c.wave_no = t.wave_no
         and c.status < '13';
      if v_iCount > 0 then
        strOutMsg := 'N|[E22520]';
        return;
      end if;

      --检查是否还有拣货单未回单
      select count(*)
        into v_iCount
        from odata_outstock_d c
       where c.warehouse_no = strWareHouseNo
         and c.enterprise_no = strEnterpriseNo
         and c.cust_no = t.cust_no
         and c.wave_no = t.wave_no
         and c.status < '13';
      if v_iCount > 0 then
        strOutMsg := 'N|[E22521]';
        return;
      end if;

      --检查是否还有分播未回单
      select count(*)
        into v_iCount
        from odata_divide_d c
       where c.warehouse_no = strWareHouseNo
         and c.enterprise_no = strEnterpriseNo
         and c.cust_no = t.cust_no
         and c.wave_no = t.wave_no
         and c.status < '13';
      if v_iCount > 0 then
        strOutMsg := 'N|[E22522]';
        return;
      end if;

      --新增装车明细
      PKOBJ_ODATA_DELIVER.P_odata_loadcarItem(strEnterpriseNo,
                                              strWareHouseNo,
                                              strProposeNo,
                                              t.label_no,
                                              strUserId,
                                              strUserId,
                                              strOutMsg);
      if substr(strOutMsg, 1, 1) = 'N' then
        return;
      end if;

      --更改标签明细物流箱数
      UPDATE odata_loadpropose_d d SET d.box_num = strBoxCount
       WHERE d.loadpropose_no = strProposeNo
         AND d.warehouse_no = strWareHouseNo
         AND d.enterprise_no = strEnterPriseNo
         AND d.deliver_obj = t.deliver_obj
         and d.container_no=t.container_no;
      if sql%notfound then
         strOutMsg:='N|[更改标签明细物流箱数失败]';
         return;
      end if;

    end loop;

    if v_hasConfirm <= 0 then
      strOutMsg:='N|[按波次获取标签失败]';
      return;
    end if;

    strOutMsg:='Y|[成功]';
    exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
 END P_LoadCarByWaveNo;

  /**********************************************************************************************************************
  功能：按客户波次封车
  huangb 20160708
  *********************************************************************************************************************/
  procedure P_DeliverCarByWaveNo(strEnterPriseNo in stock_label_m.enterprise_no%type, --企业号
                                 strWareHouseNo  in stock_label_m.warehouse_no%type, --仓别
                                 strProposeNo    in odata_loadpropose_m.loadpropose_no%type, --装车建议单
                                 strCarNo        in bdef_defcar.car_no%type, --车辆编码
                                 strDriverWorker in bdef_defcar.driver_worker%type, --司机
                                 strUserID       in odata_deliver_m.rgst_name%type, --操作人员
                                 strOutMsg       out varchar2) IS
    v_Count        number := 0;
    v_CarNo        bdef_defcar.car_no%type := 'N'; --车辆编码
    v_DriverWorker bdef_defcar.driver_worker%type := 'N'; --司机
    v_DeliverNo    odata_deliver_m.deliver_no%type; --封车编码
    v_CarPlate     bdef_defcar.car_plate%type := 'N'; --车牌号
  BEGIN
    strOutMsg := 'N|[P_DeliverCarByWaveNo]';

    --判断车辆编码是否合法
    begin
      select bdc.car_no, bdc.car_plate
        into v_CarNo, v_CarPlate
        from bdef_defcar bdc
       where bdc.enterprise_no = strEnterPriseNo
         and bdc.warehouse_no = strWareHouseNo
         and upper(bdc.car_no) = upper(strCarNo);
    exception
      when no_data_found then
        stroutmsg := 'N|[输入的车辆编码不存在]';
        return;
    end;

    --判断司机是否合法
    begin
      select t.worker_no
        into v_DriverWorker
        from bdef_defworker t
       where t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strWareHouseNo
         and upper(t.worker_no) = upper(strDriverWorker);
    exception
      when no_data_found then
        stroutmsg := 'N|[输入的司机不存在]';
        return;
    end;

    --修改装车建议单头档信息
    update odata_loadpropose_m
       set cartype_no = v_CarNo, car_plate = v_CarPlate
     where enterprise_no = strEnterPriseNo
       and warehouse_no = strWareHouseNo
       and loadpropose_no = strProposeNo
       and status < '13';
    if sql%notfound then
      strOutMsg := 'N|[修改装车单的车辆信息失败]';
      return;
    end if;

    --判断当前装车单是否存在明细
    select count(1)
      into v_Count
      from odata_loadpropose_d
     where enterprise_no = strEnterpriseNo
       and warehouse_no = strWareHouseNo
       and loadpropose_no = strProposeNo
       AND status = '10';
    if v_Count <= 0 then
      strOutMsg := 'N|[当前装车建议单[' || strProposeNo || ']不存在明细]';
      return;
    end if;

    --封车
    P_odata_Deliver(strEnterpriseNo,
                    strWareHouseNo,
                    strProposeNo,
                    strUserId,
                    strUserId,
                    v_DeliverNo,
                    strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    --更新封车单发货人员
    update odata_deliver_m
       set send_name = v_DriverWorker
     where enterprise_no = strEnterPriseNo
       and warehouse_no = strWareHouseNo
       and loadpropose_no = strProposeNo;
    if sql%notfound then
      strOutMsg := 'N|[未产生配送单据]';
      return;
    end if;

    strOutMsg := 'Y|[成功]';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  END P_DeliverCarByWaveNo;

end PKLG_ODATA_DELIVER;

/

