create view V_SEARCH_9106_1 as
select iim.enterprise_no,
       iim.warehouse_no,
       iim.owner_no,
       ow.owner_name,
       icm.check_no,
       icm.s_check_no,
       iim.supplier_no,
       a.supplier_name,
       icm.import_no,
       iim.po_no,
       icm.s_import_no,
       imm.serial_no,
       bda.owner_article_no,
       bda.article_no,
       bda.article_name,
       bda.article_identifier,
       bda.BARCODE,
       bda.UNIT,
       t.packing_unit,
       to_char(icd.produce_date, 'yyyy-mm-dd') produce_date,
       to_char(icd.expire_date, 'yyyy-mm-dd') expire_date,
       icd.packing_qty,
       iid.po_qty,
       icd.check_qty,
       icd.lot_no,
       f_get_fieldtext('N', 'QUALITY', icd.quality) quality,
       bag.l_group_no,
       bag.l_group_name,
       bda.GROUP_NO,
       bag.GROUP_NAME,
       f_get_fieldtext('N', 'STATUS', icm.status) status,
       icd.check_start_date as check_date,
       icm.updt_date as check_end_date,
       b.worker_name,
       (icd.check_qty / icd.packing_qty * bda.unit_volumn / 1000000 ) volume,
       (icd.check_qty / icd.packing_qty * bda.unit_weight) PACKING_WEIGHT
  from idata_check_m icm,
       idata_check_d icd,
       idata_import_m iim,
       idata_import_d iid,
       (SELECT enterprise_no,
               WAREHOUSE_NO,
               owner_no,
               s_import_no,
               serial_no,
               supplier_no
          FROM IDATA_import_mm
        UNION
        SELECT enterprise_no,
               WAREHOUSE_NO,
               owner_no,
               s_import_no,
               serial_no,
               supplier_no
          FROM IDATA_import_mmhty) imm,
       bdef_defarticle bda,
       v_article_pack_volumn_weight t,
       bdef_defsupplier a,
       bdef_article_group bag,
       bdef_defworker b,
       bdef_defowner ow
 where icm.enterprise_no = icd.enterprise_no
   and icm.warehouse_no = icd.warehouse_no
   and icm.check_no = icd.check_no
   and iim.enterprise_no = iid.enterprise_no
   and iim.warehouse_no = iid.warehouse_no
   and iim.import_no = iid.import_no
   AND iim.owner_no = iid.owner_no
   and icm.enterprise_no = iim.enterprise_no
   and icm.import_no = iim.import_no
   and icm.warehouse_no = iim.warehouse_no
   AND icm.owner_no = iim.owner_no
   and icm.enterprise_no = imm.enterprise_no
   and icm.warehouse_no = imm.warehouse_no
   and icm.s_import_no = imm.s_import_no
   and icd.enterprise_no = bda.enterprise_no
   and icd.article_no = bda.ARTICLE_NO
   and icd.enterprise_no = t.enterprise_no
   and icd.article_no = t.article_no
   and icd.owner_no=t.owner_no
   and a.enterprise_no = iim.enterprise_no
   AND a.owner_no = iim.owner_no
   and a.supplier_no = iim.supplier_no
   and bag.enterprise_no = bda.enterprise_no
   AND bag.owner_no = bda.owner_no
   and bag.group_no = bda.GROUP_NO
   AND bag.group_level = '0'
   and b.enterprise_no = icd.enterprise_no
   and b.worker_no = icd.check_worker1
   and icd.enterprise_no = iid.enterprise_no
   and icd.article_no = iid.article_no
   and icd.packing_qty = iid.packing_qty
   and icd.enterprise_no = bda.enterprise_no
   and icd.article_no = bda.article_no
   AND icm.enterprise_no = ow.enterprise_no
   AND icm.owner_no = ow.owner_no
 ORDER BY icm.warehouse_no, icm.owner_no, icm.check_no, icd.article_no


/

