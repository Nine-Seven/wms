create package        PKOBJ_ODISPATCH is
  --出货定位对象

  /*--新增出货定位指示头
  procedure p_Ins_O_LOCATE_M(v_warehouse_No   in odata_locate_m.warehouse_no%type,
                             v_wave_No        in odata_locate_m.wave_no%type,
                             v_EXP_TYPE       in odata_locate_m.EXP_TYPE%type,
                             v_LOCATE_NAME    in odata_locate_m.locate_name%type,
                             v_LOCATE_DATE    in odata_locate_m.locate_date%type,
                             v_DIVIDE_FLAG    in odata_locate_m.DIVIDE_FLAG%type,
                             v_SPECIFY_CELL   in odata_locate_m.SPECIFY_CELL%type,
                             --v_HM_MANUAL_FLAG in odata_locate_m.HM_MANUAL_FLAG%type,
                             v_TASK_BATCH     in odata_locate_m.TASK_BATCH%type,
                             v_SOURCE_TYPE    in odata_locate_m.SOURCE_TYPE%type,
                             v_OutMsg         out varchar2);

  --新增出货定位指示明细
  procedure p_Ins_O_LOCATE_D(v_warehouse_No in odata_locate_d.warehouse_no%type,
                             v_wave_No      in odata_locate_d.wave_no%type,
                             v_Exp_Type     in odata_exp_m.exp_type%type,
                             v_EXP_NO       in odata_locate_d.EXP_NO%type,
                             v_OutMsg       out varchar2);*/
  --定位明细转历史
  procedure p_close_locate_d(strEnterpriseNo in odata_locate_m.enterprise_no%type,
                             strWareHouseNo  in varchar2, --仓库代码
                             strWaveNo       in varchar2, --定位号
                             nGroupNo        in number, --出货组号
                             strWorkNo       in varchar2, --员工代码
                             strErrorMsg     out varchar2);
  --关闭定位单头档
  procedure p_close_locate_m(strEnterpriseNo in odata_locate_m.enterprise_no%type,
                             strWareHouseNo  in varchar2, --仓库代码
                             strWaveNo       in varchar2, --定位号
                             strWorkNo       in varchar2, --员工代码
                             strErrorMsg     out varchar2);

  /*****************************************************************************************
     功能：新增出货定位指示头 （按波次）
  *****************************************************************************************/
  PROCEDURE P_INS_O_LOCATE_M(STRENTERPRISENO IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                             STRWAREHOUSENO  IN ODATA_LOCATE_M.WAREHOUSE_NO%TYPE, --仓别
                             STROWNERNO      IN ODATA_LOCATE_M.OWNER_NO%TYPE, --货主
                             STROrg_No       IN ODATA_LOCATE_M.Org_No%TYPE, --机构
                             STRWAVENO       IN ODATA_LOCATE_M.WAVE_NO%TYPE, --波次号
                             STREXPTYPE      IN ODATA_LOCATE_M.EXP_TYPE%TYPE, --类型
                             STRLOCATENAME   IN ODATA_LOCATE_M.LOCATE_NAME%TYPE, --集单人
                             STRSOURCETYPE   IN ODATA_LOCATE_M.SOURCE_TYPE%TYPE, --
                             STRIndustry_Flag     IN ODATA_LOCATE_M.Industry_Flag%TYPE, --行业标识
                             STRRESULT       OUT VARCHAR2);

  /*****************************************************************************************
     功能：新增出货定位指示头 （按波次）
  *****************************************************************************************/
  PROCEDURE P_INS_O_LOCATE_D(STRENTERPRISENO IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                             STRWAREHOUSENO  IN ODATA_LOCATE_D.WAREHOUSE_NO%TYPE,
                             STRWAVENO       IN ODATA_LOCATE_D.WAVE_NO%TYPE,
                             STREXPTYPE      IN ODATA_EXP_M.EXP_TYPE%TYPE,
                             STRIP           IN VARCHAR2,
                             STRRESULT       OUT VARCHAR2);

  /**********************************************************************************************************
  chensr
  2015.1.19
  功能：根据出货单号添加临时表数据
  ***********************************************************************************************************/
  procedure P_Insert_TmpLocateForExpNo(strTmpId            in odata_tmp_locate_select.tmp_id%type,
                                       strCurrEnterpriseNo in odata_tmp_locate_select.enterprise_no%type,
                                       strWareHouseNo      in odata_tmp_locate_select.warehouse_no%type,
                                       strOwnerNo          in odata_tmp_locate_select.owner_no%type,
                                       strLineNo           in odata_tmp_locate_select.line_no%type,
                                       strBatchNo          in odata_tmp_locate_select.batch_no%type,
                                       strExpNo            in odata_tmp_locate_select.exp_no%type,
                                       strVolume           in odata_tmp_locate_select.volume%type,
                                       strWeigth           in odata_tmp_locate_select.weight%type,
                                       strQbox             in odata_tmp_locate_select.qbox%type,
                                       strResult           out varchar2);

  /**********************************************************************************************************
  chensr
  2015.1.19
  功能：根据客户添加临时表数据
  ***********************************************************************************************************/
  procedure P_Insert_TmpLocateForCust(strTmpId            in odata_tmp_locate_select.tmp_id%type,
                                      strCurrEnterpriseNo in odata_tmp_locate_select.enterprise_no%type,
                                      strWareHouseNo      in odata_tmp_locate_select.warehouse_no%type,
                                      strOwnerNo          in odata_tmp_locate_select.owner_no%type,
                                      strLineNo           in odata_tmp_locate_select.line_no%type,
                                      strBatchNo          in odata_tmp_locate_select.batch_no%type,
                                      strCustNo           in varchar2,
                                      strVolume           in odata_tmp_locate_select.volume%type,
                                      strWeigth           in odata_tmp_locate_select.weight%type,
                                      strQbox             in odata_tmp_locate_select.qbox%type,
                                      strResult           out varchar2);

  /**********************************************************************************************************
  chensr
  2015.1.19
  功能：根据出货单号删除临时表数据
  ***********************************************************************************************************/
  procedure P_Delete_TmpLocateForExpNo(strTmpId            in odata_tmp_locate_select.tmp_id%type,
                                       strCurrEnterpriseNo in odata_tmp_locate_select.enterprise_no%type,
                                       strWareHouseNo      in odata_tmp_locate_select.warehouse_no%type,
                                       strOwnerNo          in odata_tmp_locate_select.owner_no%type,
                                       strLineNo           in odata_tmp_locate_select.line_no%type,
                                       strBatchNo          in odata_tmp_locate_select.batch_no%type,
                                       strExpNo            in odata_tmp_locate_select.exp_no%type,
                                       strResult           out varchar2);

  /**********************************************************************************************************
  chensr
  2015.1.19
  功能：根据客户删除临时表数据
  ***********************************************************************************************************/
  procedure P_Delete_TmpLocateForCust(strTmpId            in odata_tmp_locate_select.tmp_id%type,
                                      strCurrEnterpriseNo in odata_tmp_locate_select.enterprise_no%type,
                                      strWareHouseNo      in odata_tmp_locate_select.warehouse_no%type,
                                      strOwnerNo          in odata_tmp_locate_select.owner_no%type,
                                      strLineNo           in odata_tmp_locate_select.line_no%type,
                                      strBatchNo          in odata_tmp_locate_select.batch_no%type,
                                      strCustNo           in varchar2,
                                      strResult           out varchar2);

  /***********************************************************************************************************
  功能说明：更新出货通知单头档
  luozhiling
  2015.04.27
  ***********************************************************************************************************/
  procedure P_Update_Odata_exp_m(strEnterpriseNo in odata_exp_m.enterprise_no%type,
                                 strWareHouseNo  in odata_exp_m.warehouse_no%type,
                                 strExpNo        in odata_exp_m.exp_no%type,
                                 strOldStatus    in odata_exp_m.status%type, --更新前状态
                                 strNewStatus    in odata_exp_m.status%type, --更新后状态
                                 strExpStatus    in odata_exp_m.exp_status%type,
                                 strWorkNo       in varchar2, --员工代码
                                 strErrorMsg     out varchar2);

  /***********************************************************************************************************
  功能说明：更新出货通知单明细档
  luozhiling
  2015.04.27
  ***********************************************************************************************************/
  procedure P_Update_Odata_exp_d(strEnterpriseNo in odata_exp_d.enterprise_no%type,
                                 strWareHouseNo  in odata_exp_d.warehouse_no%type,
                                 strExpNo        in odata_exp_d.exp_no%type,
                                 strNewStatus    in odata_exp_d.status%type, --更新后状态
                                 strWorkNo       in varchar2, --员工代码
                                 strErrorMsg     out varchar2);
  /***********************************************************************************************************
  功能说明：出货通知单状态跟踪
  jiangchenglong
  2016.06.29
  ***********************************************************************************************************/
  procedure P_Insert_Odata_Exp_Trace(strEnterpriseNo in odata_exp_m.enterprise_no%type,
                                     strWareHouseNo  in odata_exp_m.warehouse_no%type,
                                     strExpNo        in odata_exp_m.exp_no%type,
                                     strExpStatus    in odata_exp_m.exp_status%type, --单据状态
                                     strWorkNo       in varchar2, --员工代码
                                     strErrorMsg     out varchar2);
  /***********************************************************************************************************
  功能说明：更新病单头档
  hekl
  2015.04.28
  ***********************************************************************************************************/
  procedure P_Update_Odata_exp_cancel_m(strEnterpriseNo in odata_exp_m.enterprise_no%type,
                                        strWareHouseNo  in odata_exp_m.warehouse_no%type,
                                        strCancelNo     in odata_exp_cancel_m.cancel_no%type,
                                        strOldStatus    in odata_exp_m.status%type, --更新前状态
                                        strNewStatus    in odata_exp_m.status%type, --更新后状态
                                        strWorkNo       in varchar2, --员工代码
                                        strErrorMsg     out varchar2);
  /***********************************************************************************************************
  功能说明：更新病单明细
  hekl
  2015.04.28
  ***********************************************************************************************************/
  procedure P_Update_Odata_exp_cancel_d(strEnterpriseNo in odata_exp_d.enterprise_no%type,
                                        strWareHouseNo  in odata_exp_d.warehouse_no%type,
                                        strCancelNo     in odata_exp_cancel_d.cancel_no%type,
                                        strNewStatus    in odata_exp_d.status%type, --更新后状态
                                        strWorkNo       in varchar2, --员工代码
                                        strErrorMsg     out varchar2);
  /***********************************************************************************************************
  功能说明：自动集单添加明细
  chensr
  2015.05.13
  ***********************************************************************************************************/
  procedure p_Ins_AUTO_LOCATE_D(strEnterpriseNo in odata_locate_m.enterprise_no%type, --企业
                                strWarehouseNo  in odata_locate_d.warehouse_no%type,
                                strWaveNo       in odata_locate_d.wave_no%type,
                                strExpType      in odata_exp_m.exp_type%type,
                                strExpNo        in odata_exp_m.EXP_NO%type,
                                strResult       out varchar2);
end PKOBJ_ODISPATCH;


/

