create view V_SEARCH_9102_6 as
select pal.enterprise_no,pal.warehouse_no,pal.device_no,pal.label_no,el.ARTICLE_NO,el.BARCODE,el.ARTICLE_NAME,
pal.check_qty, um.po_no,f_get_fieldtext('RIDATA_UNTREAD_M','QUALITY',um.quality) quality
from ridata_check_pal pal,ridata_check_m cm,ridata_untread_m um
,v_bdef_defarticle el
where pal.enterprise_no=cm.ENTERPRISE_NO
and pal.warehouse_no=cm.warehouse_no
and pal.check_no=cm.check_no
and cm.untread_no=um.untread_no
and cm.enterprise_no=um.enterprise_no
and cm.warehouse_no=um.warehouse_no
and pal.enterprise_no=el.ENTERPRISE_NO
and pal.article_no=el.ARTICLE_NO
order by pal.enterprise_no,pal.warehouse_no,pal.device_no,pal.label_no

/

