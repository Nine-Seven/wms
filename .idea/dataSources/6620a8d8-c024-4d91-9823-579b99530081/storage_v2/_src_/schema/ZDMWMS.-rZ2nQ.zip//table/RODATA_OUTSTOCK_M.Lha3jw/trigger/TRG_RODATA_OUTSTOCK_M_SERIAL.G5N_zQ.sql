create trigger TRG_RODATA_OUTSTOCK_M_SERIAL
    before insert
    on RODATA_OUTSTOCK_M
    for each row
declare
  i_report_up_SERIAL NUMBER;
begin
  select SEQ_RODATA_OUTSTOCK_M.NEXTVAL into i_report_up_SERIAL from dual;
  :NEW.REPORT_UP_SERIAL := i_report_up_SERIAL;
end TRG_RODATA_OUTSTOCK_M_SERIAL;


/

