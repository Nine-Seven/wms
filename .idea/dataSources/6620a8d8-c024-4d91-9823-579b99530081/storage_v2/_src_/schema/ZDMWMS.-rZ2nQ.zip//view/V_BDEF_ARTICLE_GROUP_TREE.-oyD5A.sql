create view V_BDEF_ARTICLE_GROUP_TREE as
select a.enterprise_no, a.owner_no, a.group_no as id ,a.group_name as text,'0' as parentId
from bdef_article_group a  where a.group_level=2
union all
select a.enterprise_no, a.owner_no, a.group_no as id ,a.group_name as text,a.l_group_no as parentId
from bdef_article_group a  where a.group_level=1

/

