create package        PKLG_ODATA_DIVIDE is

  /*   \**********************************************************************************************
  MM
  20140623
  功能说明：直通分播发单
  ***********************************************************************************************\
  procedure P_O_ODATA_DIVIDE_BEGIN(strEnterPriseNo   in ODATA_DIVIDE_D.Enterprise_No%type,--企业号
                                   strwarehouse_no   in ODATA_DIVIDE_D.warehouse_no%type, --仓别
                                   strOWNER_NO       in ODATA_DIVIDE_D.OWNER_NO%type, --委托业主
                                   strDockNo         in bdef_defdock.dock_no%type, --码头
                                   strSource_No      in odata_divide_direct.source_no%type, --来源单号
                                   strLable_NO       in STOCK_LABEL_M.Label_No%type, --板号
                                   strAssign_No      in odata_divide_d.assign_name%type, --预定分播人员
                                   strUserID         in bdef_defworker.worker_no%type, --系统操作人员
                                   strPrint_Flag     in varchar,--是否打印 0=否 1=是
                                   strOutMsg         out varchar2);*/

  /**********************************************************************************************8
  lich
  20140521
  功能说明：写分播单
  ***********************************************************************************************/
  procedure P_OutStock_Divide(strEnterPriseNo   in ODATA_DIVIDE_D.Enterprise_No%type, --企业号
                              strwarehouse_no   in ODATA_DIVIDE_D.warehouse_no%type, --仓别
                              strOWNER_NO       in ODATA_DIVIDE_D.OWNER_NO%type, --委托业主
                              strDockNo         in bdef_defdock.dock_no%type, --码头
                              strSource_No      in odata_divide_direct.source_no%type, --来源单号
                              strS_CONTAINER_NO in odata_divide_direct.S_CONTAINER_NO%type, --来源容器
                              strAssign_No      in odata_divide_d.assign_name%type, --预定分播人员
                              strUserID         in bdef_defworker.worker_no%type, --系统操作人员
                              strPrint_Flag     in varchar, --是否打印
                              strOutMsg         out varchar2);

  /**********************************************************************************************8
  quzhihui
  20160621
  功能说明：按来源单号写分播单，并返回分播单号
  ***********************************************************************************************/
  procedure P_WriteOutStock_Divide(strEnterPriseNo in ODATA_DIVIDE_D.Enterprise_No%type, --企业号
                                   strwarehouse_no in ODATA_DIVIDE_D.warehouse_no%type, --仓别
                                   strSource_No    in odata_divide_direct.source_no%type, --来源单号
                                   strAssign_No    in odata_divide_d.assign_name%type, --预定分播人员
                                   strUserID       in bdef_defworker.worker_no%type, --系统操作人员
                                   --strPrint_Flag   in varchar, --是否打印
                                   strDivide_No out odata_divide_m.divide_no%type, --分播单号
                                   strOutMsg    out varchar2); --返回值
  /*****************************************************************************************
    luozhiling
    20141023
    功能：分播回单功能，拆分分播明细
  *****************************************************************************************/
  procedure p_DpsDiveSave(strEnterPriseNo in odata_divide_d.enterprise_no%type,
                          strWareHouseNo  in odata_divide_d.warehouse_no%type, --仓别
                          strDivideNo     in odata_divide_d.divide_no%type, --分播单号
                          strArticleNo    in odata_divide_d.article_no%type, --商品编号
                          strDpsCellNo    in odata_divide_d.dps_cell_no%type,
                          strBarcode      in stock_article_info.barcode%type,
                          nRealQty        in odata_divide_d.real_qty%type,
                          strDivideName   in odata_divide_d.divide_name%type,
                          strCustNo       in odata_divide_d.cust_no%type,
                          strLabelNo      in stock_label_m.label_no%type, --来源箱号
                          strAddFlag      in odata_divide_m.divide_type%type, --1：按数量回单；2：按记录数回单
                          strResult       out varchar2);

  /*****************************************************************************************
    luozhiling
    20141027
    功能：分播取消
  *****************************************************************************************/
  procedure p_DpsDiveCancel(strEnterPriseNo in odata_divide_d.enterprise_no%type,
                            strWareHouseNo  in odata_divide_d.warehouse_no%type, --仓别
                            strDivideNo     in odata_divide_d.divide_no%type, --分播单号
                            strDivideName   in odata_divide_d.divide_name%type,
                            strAddFlag      in odata_divide_m.divide_type%type, --1：按数量回单；2：按记录数回单
                            strResult       out varchar2);
  /*****************************************************************************************
    lich
    20141028
    功能：封箱
  *****************************************************************************************/
  procedure P_ODATA_DIVIDE_CUTBOX(strEnterPriseNo   in odata_divide_d.enterprise_no%type,
                                  strWareHouseNo    in odata_divide_d.warehouse_no%type, --仓别
                                  strCellNo         in dps_stock_label.dps_cell_no%type, --储位
                                  strUserId         in Ridata_instock_m.rgst_name%type, --上架人
                                  strPaperUserId    in Ridata_instock_m.rgst_name%type, --回单人
                                  strTools          in stock_content_move.terminal_flag%type,
                                  strPrinterGroupNo in ridata_check_m.printer_group_no%type,
                                  strResult         out varchar2);
  /*****************************************************************************************
  2015.12.4
  功能说明：1、根据分播标签的分播信息进行取号
            2、打印
  ******************************************************************************************/
  procedure GetCustLabelAndPrint(strEnterPriseNo  in ODATA_DIVIDE_D.Enterprise_No%type, --企业号
                                 strWareHouseNo   in ODATA_DIVIDE_D.warehouse_no%type, --仓别
                                 strDivideNo      in odata_divide_d.divide_no%type, --
                                 strsLabelNo      in stock_label_m.label_no%type, --来源标签号
                                 strCustNo        in stock_label_m.cust_no%type, --客户
                                 strArticleNo     in stock_label_d.article_no%type, --商品编码
                                 strDockNo        in bdef_defdock.dock_no%type, --工作站
                                 strContainerType in stock_label_m.container_type%type, --P：栈板；
                                 strUserId        in stock_label_m.rgst_name%type,
                                 strDLabelNo      out stock_label_m.label_no%type, --目的标签号
                                 strOutMsg        out varchar2);
  /*****************************************************************************************
  2015.12.4
  功能说明：根据分播标签的客户进行取号
  ******************************************************************************************/
  procedure GetCustLabel(strEnterPriseNo  in ODATA_DIVIDE_D.Enterprise_No%type, --企业号
                         strWareHouseNo   in ODATA_DIVIDE_D.warehouse_no%type, --仓别
                         strDivideNo      in odata_divide_d.divide_no%type, --
                         strsLabelNo      in stock_label_m.label_no%type, --来源标签号
                         strDeliver_Obj   in stock_label_m.cust_no%type, --配送对象
                         strArticleNo     in stock_label_d.article_no%type, --商品编码
                         strContainerType in stock_label_m.container_type%type, --P：栈板；
                         strUserId        in stock_label_m.rgst_name%type,
                         strDLabelNo      out stock_label_m.label_no%type, --目的标签号
                         strOutMsg        out varchar2);
  /*****************************************************************************************
    lich
    20140529
    功能：分播回单功能
  *****************************************************************************************/
  procedure p_Save_Odata_divide(strEnterPriseNo   in ODATA_DIVIDE_D.Enterprise_No%type, --企业号
                                strwarehouse_no   in ODATA_DIVIDE_D.warehouse_no%type, --仓别
                                strOWNER_NO       in ODATA_DIVIDE_D.OWNER_NO%type, --委托业主
                                strDIVIDE_NO      in ODATA_DIVIDE_D.DIVIDE_NO%type, --分播单号
                                strARTICLE_NO     in ODATA_DIVIDE_D.ARTICLE_NO%type, --商品编码
                                strDLabelNo       in ODATA_DIVIDE_D.CUST_CONTAINER_NO%type, --目的容器
                                nArticleQty       in odata_divide_d.article_qty%type, --计划量
                                nREAL_QTY         in ODATA_DIVIDE_D.REAL_QTY%type, --实际分播数量
                                strDIVIDE_NAME    in ODATA_DIVIDE_D.DIVIDE_NAME%type, --实际分播人
                                strBATCH_NO       in ODATA_DIVIDE_D.BATCH_NO%type, --批次号
                                strQuality        in idata_check_d.quality%type, --品质
                                dtProduceDate     in stock_article_info.produce_date%type, --生产日期
                                dtExpireDate      in stock_article_info.expire_date%type, --到期日期
                                strLotNo          in stock_article_info.lot_no%type, --批号
                                strRSV_BATCH1     in stock_article_info.rsv_batch1%type, --预留批属性1
                                strRSV_BATCH2     in stock_article_info.rsv_batch2%type, --预留批属性2
                                strRSV_BATCH3     in stock_article_info.rsv_batch3%type, --预留批属性3
                                strRSV_BATCH4     in stock_article_info.rsv_batch4%type, --预留批属性4
                                strRSV_BATCH5     in stock_article_info.rsv_batch5%type, --预留批属性5
                                strRSV_BATCH6     in stock_article_info.rsv_batch6%type, --预留批属性6
                                strRSV_BATCH7     in stock_article_info.rsv_batch7%type, --预留批属性7
                                strRSV_BATCH8     in stock_article_info.rsv_batch8%type, --预留批属性8
                                strS_CELL_NO      in ODATA_DIVIDE_D.S_CELL_NO%type, --来源储位编码
                                strS_CONTAINER_NO in ODATA_DIVIDE_D.S_CONTAINER_NO%type, --来源容器
                                strCUST_NO        in ODATA_DIVIDE_D.CUST_NO%type, --客户
                                strDelvierObj     in odata_divide_d.deliver_obj%type, --配送对象
                                strUPDT_NAME      in ODATA_DIVIDE_M.UPDT_NAME%type, --更新人员
                                strAddFlag        in odata_divide_m.divide_type%type, --1：按数量回单；2：按记录数回单
                                strContainerType  in wms_defcontainer.container_type%type,
                                strOutMsg         out varchar2);
  /***********************************************************************************************
  整单分播回单功能
  2016.3.9
  **********************************************************************************************/
  procedure p_AllSaveDivide(strEnterPriseNo in ODATA_DIVIDE_D.Enterprise_No%type, --企业号
                            strwarehouse_no in ODATA_DIVIDE_D.warehouse_no%type, --仓别
                            strOWNER_NO     in ODATA_DIVIDE_D.OWNER_NO%type, --委托业主
                            strDIVIDE_NO    in ODATA_DIVIDE_D.DIVIDE_NO%type, --分播单号
                            strUPDT_NAME    in ODATA_DIVIDE_M.UPDT_NAME%type, --更新人员
                            strOutMsg       out varchar2);
  /*****************************************************************************************
    lich
    20150129
    功能：RF分播回单，调用目的标签校验，再调用p_Save_Odata_divide
  *****************************************************************************************/
  procedure p_SaveDivide(strEnterPriseNo   in ODATA_DIVIDE_D.Enterprise_No%type, --企业号
                         strwarehouse_no   in ODATA_DIVIDE_D.warehouse_no%type, --仓别
                         strOWNER_NO       in ODATA_DIVIDE_D.OWNER_NO%type, --委托业主
                         strDIVIDE_NO      in ODATA_DIVIDE_D.DIVIDE_NO%type, --分播单号
                         strARTICLE_NO     in ODATA_DIVIDE_D.ARTICLE_NO%type, --商品编码
                         strdLabelNo       in stock_label_m.label_no%type, --目的标签
                         nArticleQty       in odata_divide_d.article_qty%type,
                         nREAL_QTY         in ODATA_DIVIDE_D.REAL_QTY%type, --实际分播数量
                         strDIVIDE_NAME    in ODATA_DIVIDE_D.DIVIDE_NAME%type, --实际分播人
                         strBATCH_NO       in ODATA_DIVIDE_D.BATCH_NO%type, --批次号
                         strQuality        in idata_check_d.quality%type, --品质
                         dtProduceDate     in stock_article_info.produce_date%type, --生产日期
                         dtExpireDate      in stock_article_info.expire_date%type, --到期日期
                         strLotNo          in stock_article_info.lot_no%type, --批号
                         strRSV_BATCH1     in stock_article_info.rsv_batch1%type, --预留批属性1
                         strRSV_BATCH2     in stock_article_info.rsv_batch2%type, --预留批属性2
                         strRSV_BATCH3     in stock_article_info.rsv_batch3%type, --预留批属性3
                         strRSV_BATCH4     in stock_article_info.rsv_batch4%type, --预留批属性4
                         strRSV_BATCH5     in stock_article_info.rsv_batch5%type, --预留批属性5
                         strRSV_BATCH6     in stock_article_info.rsv_batch6%type, --预留批属性6
                         strRSV_BATCH7     in stock_article_info.rsv_batch7%type, --预留批属性7
                         strRSV_BATCH8     in stock_article_info.rsv_batch8%type, --预留批属性8
                         strS_CELL_NO      in ODATA_DIVIDE_D.S_CELL_NO%type, --来源储位编码
                         strS_CONTAINER_NO in ODATA_DIVIDE_D.S_CONTAINER_NO%type, --来源容器
                         strCUST_NO        in ODATA_DIVIDE_D.CUST_NO%type, --客户
                         strDelvierObj     in odata_divide_d.deliver_obj%type, --配送对象
                         strUPDT_NAME      in ODATA_DIVIDE_M.UPDT_NAME%type, --更新人员
                         strAddFlag        in odata_divide_m.divide_type%type, --1：按数量回单；2：按记录数回单
                         strContainerType  in wms_defcontainer.container_type%type,
                         strOutMsg         out varchar2);

  /*****************************************************************************************
    wyf
    20150718
    功能：RF分播回单，分播到电子标签储位，现获取电子标签储位上的箱标签，再调用p_SaveDivide做RF分播回单
  *****************************************************************************************/
  procedure p_SaveDivide_dps(strEnterPriseNo   in ODATA_DIVIDE_D.Enterprise_No%type, --企业号
                             strwarehouse_no   in ODATA_DIVIDE_D.warehouse_no%type, --仓别
                             strOWNER_NO       in ODATA_DIVIDE_D.OWNER_NO%type, --委托业主
                             strDIVIDE_NO      in ODATA_DIVIDE_D.DIVIDE_NO%type, --分播单号
                             strARTICLE_NO     in ODATA_DIVIDE_D.ARTICLE_NO%type, --商品编码
                             strDpsCellNo      in cdef_defcell_dps.cell_no%type, --电子标签储位号
                             nArticleQty       in oDATA_DIVIDE_D.article_qty%type,
                             nREAL_QTY         in ODATA_DIVIDE_D.REAL_QTY%type, --实际分播数量
                             strDIVIDE_NAME    in ODATA_DIVIDE_D.DIVIDE_NAME%type, --实际分播人
                             strBATCH_NO       in ODATA_DIVIDE_D.BATCH_NO%type, --批次号
                             strQuality        in idata_check_d.quality%type, --品质
                             dtProduceDate     in stock_article_info.produce_date%type, --生产日期
                             dtExpireDate      in stock_article_info.expire_date%type, --到期日期
                             strLotNo          in stock_article_info.lot_no%type, --批号
                             strRSV_BATCH1     in stock_article_info.rsv_batch1%type, --预留批属性1
                             strRSV_BATCH2     in stock_article_info.rsv_batch2%type, --预留批属性2
                             strRSV_BATCH3     in stock_article_info.rsv_batch3%type, --预留批属性3
                             strRSV_BATCH4     in stock_article_info.rsv_batch4%type, --预留批属性4
                             strRSV_BATCH5     in stock_article_info.rsv_batch5%type, --预留批属性5
                             strRSV_BATCH6     in stock_article_info.rsv_batch6%type, --预留批属性6
                             strRSV_BATCH7     in stock_article_info.rsv_batch7%type, --预留批属性7
                             strRSV_BATCH8     in stock_article_info.rsv_batch8%type, --预留批属性8
                             strS_CELL_NO      in ODATA_DIVIDE_D.S_CELL_NO%type, --来源储位编码
                             strS_CONTAINER_NO in ODATA_DIVIDE_D.S_CONTAINER_NO%type, --来源容器
                             strCUST_NO        in ODATA_DIVIDE_D.CUST_NO%type, --客户
                             strDelvierObj     in odata_divide_d.deliver_obj%type, --配送对象
                             strUPDT_NAME      in ODATA_DIVIDE_M.UPDT_NAME%type, --更新人员
                             strAddFlag        in odata_divide_m.divide_type%type, --1：按数量回单；2：按记录数回单
                             strContainerType  in wms_defcontainer.container_type%type,
                             strOutMsg         out varchar2);
  /**********************************************************************************************8
  lich
  20140521
  功能说明：扫描拣货标签写分播单
  ***********************************************************************************************/
  procedure p_Wall_Send_odata_Divide(strEnterPriseNo  in ODATA_DIVIDE_D.Enterprise_No%type, --企业号
                                     strwarehouse_no  in ODATA_DIVIDE_D.warehouse_no%type, --仓别
                                     strDockNo        in bdef_defdock.dock_no%type, --码头
                                     strDeviceNo      in odata_divide_direct.device_no%type, --来源单号
                                     strSLabel_No     in stock_label_m.label_no%type,
                                     strAssign_No     in odata_divide_d.assign_name%type, --预定分播人员
                                     strUserID        in bdef_defworker.worker_no%type, --系统操作人员
                                     strPrintWayBill  in odata_outstock_m.task_type%type, --是否打印快递面单，0：不打印，1：打印
                                     strPrintPackList in odata_outstock_m.task_type%type, --是否打印装箱清单，0：不打印，1：打印
                                     strPrintInVoice  in odata_outstock_m.task_type%type, --是否打印发票，0：不打印，1：打印
                                     strOutDivide_No  out odata_divide_m.divide_no%type,
                                     strOutMsg        out varchar2);

  /*****************************************************************************************
    lich
    20150529
    功能：分播墙回单
  *****************************************************************************************/
  procedure p_Wall_Save_odata_Divide(strEnterPriseNo in ODATA_DIVIDE_D.Enterprise_No%type, --企业号
                                     strWarehouseNo  in ODATA_DIVIDE_D.warehouse_no%type, --仓别
                                     strDivide_No    in ODATA_DIVIDE_M.Divide_No%type, --分播设备
                                     strArticleNo    in ODATA_DIVIDE_D.ARTICLE_NO%type, --商品编码
                                     strDivideName   in ODATA_DIVIDE_D.DIVIDE_NAME%type, --实际分播人
                                     strUpdtName     in ODATA_DIVIDE_M.UPDT_NAME%type, --更新人员
                                     strDpsCellNo    out ODATA_DIVIDE_D.DPS_CELL_NO%type, --分播储位
                                     strFinishFlag   out ODATA_DIVIDE_M.STATUS%type, --分播单完成标志：Y-完成；N—未完成
                                     strOutMsg       out varchar2); --返回值

  /*****************************************************************************************
    lich
    20150529
    功能：分播墙回单释放单号
  *****************************************************************************************/
  procedure p_Wall_Sure_odata_Divide(strEnterPriseNo in ODATA_DIVIDE_D.Enterprise_No%type, --企业号
                                     strWarehouseNo  in ODATA_DIVIDE_D.warehouse_no%type, --仓别
                                     strDeviceNo     in ODATA_DIVIDE_M.device_no%type, --分播组号
                                     strDivideName   in ODATA_DIVIDE_D.DIVIDE_NAME%type, --实际分播人
                                     strUpdtName     in ODATA_DIVIDE_M.UPDT_NAME%type, --更新人员
                                     strOutMsg       out varchar2);
end PKLG_ODATA_DIVIDE;


/

