create view V_SEARCH_9120_004 as
SELECT A.yhzs,a.wmzsl,(a.yhzs-a.wmzsl)/nvl(a.yhzs,1) * 100 ||'%' YHMZL FROM (
--门店要货满足率（KPI4）标准值为 99%
--门店要货满足率=（期间门店要货项目行总数–期间门店要货未满足项目行数）/（期间门店要货项目行总数）*100%
--注：因北京华联未下达供应商订单或供应商未及时送货导致库存不足除外。
 SELECT ( SELECT COUNT(0) FROM odata_exp_d d WHERE d.rgst_date >= TRUNC( to_date('20160113','YYYYMMDD'))  AND d.rgst_date <= TRUNC( to_date('20160114','YYYYMMDD'))) YHZS,
 (SELECT COUNT(0) FROM odata_exp_d d WHERE d.article_qty <> d.locate_qty AND d.rgst_date >= TRUNC( to_date('20160113','YYYYMMDD'))  AND d.rgst_date <= TRUNC( to_date('20160114','YYYYMMDD'))) WMZSL
 FROM dual) A

/

