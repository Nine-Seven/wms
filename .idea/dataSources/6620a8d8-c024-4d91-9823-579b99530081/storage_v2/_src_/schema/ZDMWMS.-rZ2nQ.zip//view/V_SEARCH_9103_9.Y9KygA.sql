create view V_SEARCH_9103_9 as
select "UPDT_DATA","SOURCEEXP_NO","CUST_NAME","OWNER_ARTICLE_NO","ARTICLE_NAME","PACKING_QTY","PACKING_UNIT","PRODUCE_DATE","LOT_NO","NRM","DM","NR","QA","SUMQTY","WAREHOUSE_NO","OWNER_NO","ENTERPRISE_NO"
  from (select to_date(to_char(m.updt_date, 'yyyy-MM-dd'), 'yyyy-MM-dd') updt_data,
               iim.sourceexp_no,
               '[' || dc.owner_cust_no || ']' || dc.cust_name Cust_Name,
               atc.owner_article_no,
               atc.article_name,
               d.packing_qty,
               atcp.packing_unit,
               to_char(d.produce_date, 'yyyyMMdd') produce_date,
               d.lot_no,
               sum(case when QUALITY='0' then floor(d.qty/d.packing_qty) else 0 end) NRM,
               sum(case when QUALITY='B' then d.qty else 0 end) as DM,
               sum(case when QUALITY='0' then mod(d.qty,d.packing_qty) else 0 end) as NR,
               sum(case when QUALITY='A' then d.qty else 0 end) QA,
               sum(d.qty) sumQty,
               m.warehouse_no,
               m.owner_no,
               m.enterprise_no
          from odata_deliver_m      m,
               odata_deliver_d      d,
               odata_exp_m          iim,
               bdef_defarticle      atc,
               bdef_article_packing atcp,
               bdef_defcust         dc
         where m.warehouse_no = d.warehouse_no
           and m.enterprise_no =d.enterprise_no
           and m.deliver_no = d.deliver_no
           and m.enterprise_no = iim.enterprise_no
           and m.warehouse_no = iim.warehouse_no
           and d.exp_no = iim.exp_no
           and d.enterprise_no = atc.enterprise_no
           and d.owner_no = atc.owner_no
           and d.article_no = atc.article_no
           and d.enterprise_no = atcp.enterprise_no
           and atc.article_no = atcp.article_no
           and d.packing_qty = atcp.packing_qty
           and iim.enterprise_no =dc.enterprise_no
           and iim.cust_no = dc.cust_no
           and iim.owner_no = dc.owner_no
           and m.warehouse_no in ('001', '004')
           and m.owner_no = '001'
           and m.status = '13'
         group by to_date(to_char(m.updt_date, 'yyyy-MM-dd'), 'yyyy-MM-dd'),
                  iim.sourceexp_no,
                  atc.owner_article_no,
                  atc.article_name,
                  d.packing_qty,
                  atcp.packing_unit,
                  to_char(d.produce_date, 'yyyyMMdd'),
                  d.lot_no,
                  m.enterprise_no,
                  m.warehouse_no,
                  m.owner_no,
                  dc.owner_cust_no,
                  dc.cust_name
        union all
        select to_date(to_char(rcm.updt_date, 'yyyy-MM-dd'), 'yyyy-MM-dd') updt_date,
               rum.po_no sourceexp_no,
               '[' || ds.supplier_no || ']' || ds.supplier_name Cust_Name,
               atc.owner_article_no,
               atc.article_name,
               rcd.packing_qty,
               atcp.packing_unit,
               to_char(rcd.produce_date, 'yyyyMMdd') produce_date,
               rcd.lot_no,
               sum(rcd.real_qty) NRM,
               0.00 as DM,
               0.00 as NR,
               0.00 QA,
               sum(rcd.real_qty) sumQty,
               rcm.warehouse_no,
               rcm.owner_no,
               rcm.enterprise_no
          from rodata_deliver_m     rcm,
               rodata_deliver_d     rcd,
               rodata_recede_m      rum,
               bdef_defarticle      atc,
               bdef_article_packing atcp,
               bdef_defsupplier     ds
         where rcm.warehouse_no = rcd.warehouse_no
           and rcm.enterprise_no =rcd.enterprise_no
           and rcm.deliver_no = rcd.deliver_no
           and rcd.enterprise_no = rum.enterprise_no
           and rcd.recede_no = rum.recede_no
           and rcd.warehouse_no = rum.warehouse_no
           and rcd.enterprise_no = atc.enterprise_no
           and rcd.owner_no = atc.owner_no
           and rcd.article_no = atc.article_no
           and atc.enterprise_no = atcp.enterprise_no
           and atc.article_no = atcp.article_no
           and rcd.packing_qty = atcp.packing_qty
           and rum.enterprise_no =ds.enterprise_no
           and rum.supplier_no = ds.supplier_no
           and rcm.owner_no = ds.owner_no
           and rcm.owner_no = '001'
           and rcm.warehouse_no in ('001', '004')
           and rcm.status = 13
         group by to_date(to_char(rcm.updt_date, 'yyyy-MM-dd'), 'yyyy-MM-dd'),
                  rum.po_no,
                  atc.owner_article_no,
                  atc.article_name,
                  rcd.packing_qty,
                  atcp.packing_unit,
                  to_char(rcd.produce_date, 'yyyyMMdd'),
                  rcd.lot_no,
                  rcm.warehouse_no,
                  rcm.owner_no,
                  rcm.enterprise_no,
                  ds.supplier_no,
                  ds.supplier_name)
 order by updt_data desc, sourceexp_no desc, cust_name


/

