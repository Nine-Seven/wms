create package        PKOBJ_ODATA_CHECK is
  /*************************************************************************************************
       功能：生产复核单头档
       chensr 2015.4.27

  *************************************************************************************************/
  procedure p_insert_Odata_check_m(strEnterpriseNo in odata_check_m.enterprise_no%type,
                                   strWareHouseNo  in odata_check_m.warehouse_no%type,
                                   strCheckNo      in odata_check_m.check_no%type,
                                   strOwnerNo      in odata_check_m.owner_no%type,
                                   strBatchNo      in odata_check_m.batch_no%type,
                                   strCustNo       in odata_check_m.cust_no%type,
                                   strStatus       in odata_check_m.status%type,
                                   strCheckChuteNo in odata_check_m.check_chute_no%type,
                                   strDliverObj    in odata_check_m.deliver_obj%type,
                                   strLineNo       in odata_check_m.line_no%type,
                                   strCurrArea     in odata_check_m.curr_area%type,
                                   strUseId        in odata_check_m.rgst_name%type,
                                   strResult       out varchar2);

  /*************************************************************************************************
       功能：根据箱号生产复核单标签明细
       chensr 2015.6.25
  *************************************************************************************************/
  procedure p_insert_checkLabelD_by_label(strEnterpriseNo in odata_check_label_d.enterprise_no%type,
                                          strWareHouseNo  in odata_check_label_d.warehouse_no%type,
                                          strCheckNo      in odata_check_label_d.check_no%type,
                                          strContainerNo  in odata_check_label_d.container_no%type,
                                          strUserId       in odata_check_label_d.check_name%type,
                                          strResult       out varchar2);
  /*************************************************************************************************
       功能：根据箱号生产复核单明细
       chensr 2015.6.25
  *************************************************************************************************/
  procedure p_insert_Odata_checkD_by_label(strEnterpriseNo in odata_check_d.enterprise_no%type,
                                           strWareHouseNo  in odata_check_d.warehouse_no%type,
                                           strCheckNo      in odata_check_d.check_no%type,
                                           strContainerNo  in stock_label_m.container_no%type,
                                           strUserId       in odata_check_d.check_name%type,
                                           strResult       out varchar2);
  /*************************************************************************************************
       功能：更新复核单头档
       chensr 2015.4.30
  *************************************************************************************************/
  procedure P_UpdateOdataCheckM(strEnterpriseNo in odata_check_m.enterprise_no%type,
                                strWareHouseNo  in odata_check_m.warehouse_no%type,
                                strCheckNo      in odata_check_m.check_no%type,
                                strUserId       in odata_check_m.updt_name%type,
                                strResult       out varchar2);
  /*************************************************************************************************
  功能说明：更新复核单明细

  **************************************************************************************************/
  procedure P_UpdtaOdataCheckD(strEnterpriseNo in odata_check_d.enterprise_no%type,
                               strWareHouseNo  in odata_check_m.warehouse_no%type,
                               strCheckNo      in odata_check_m.check_no%type,
                               strExp_No       in odata_check_d.exp_no%type,
                               strArticleNo    in odata_check_d.article_no%type,
                               nPackingQty     in odata_check_d.packing_qty%type,
                               nRealQty        in odata_check_label_d.real_qty%type,
                               strUserId       in odata_check_m.updt_name%type,
                               strResult       out varchar2);
  /*************************************************************************************************
       功能：复核标签明细回单
       chensr 2015.4.30
  *************************************************************************************************/
  procedure P_UpdateOdataCheckLabelD(strEnterpriseNo in odata_check_d.enterprise_no%type,
                                     strWareHouseNo  in odata_check_m.warehouse_no%type,
                                     strCheckNo      in odata_check_m.check_no%type,
                                     strContainerNo  in odata_check_label_d.lable_no%type,
                                     strDLableNo     in odata_check_label_d.lable_no%type, --目的标签号
                                     nRowId          in odata_check_label_d.row_id%type,
                                     nRealQty        in odata_check_label_d.real_qty%type,
                                     strUserId       in odata_check_m.updt_name%type,
                                     strResult       out varchar2);
  /*************************************************************************************************
       功能：复核标签表回单，将目的容器号回写复核标签明细表，若复核数量<标签明细的数量，需要进行拆记录。
       luozhiling
       2015.11.4
  *************************************************************************************************/
  procedure P_SaveOdataCheckLabelD(strEnterpriseNo in odata_check_d.enterprise_no%type,
                                   strWareHouseNo  in odata_check_m.warehouse_no%type,
                                   strCheckNo      in odata_check_m.check_no%type,
                                   strContainerNo  in odata_check_label_d.container_no%type, -- 来源标签内部容器号
                                   strDLableNo     in odata_check_label_d.lable_no%type, --目的标签号
                                   nRowId          in odata_check_label_d.row_id%type,
                                   nRealQty        in odata_check_label_d.real_qty%type,
                                   strUserId       in odata_check_m.updt_name%type,
                                   strResult       out varchar2);
  /*************************************************************************************************
       功能：生产复核单转历史表
       chensr 2015.4.30
  *************************************************************************************************/
  procedure p_insert_Odata_check_log(strEnterpriseNo in odata_check_d.enterprise_no%type,
                                     strWareHouseNo  in odata_check_d.warehouse_no%type,
                                     strCheckNo      in odata_check_d.check_no%type,
                                     strResult       out varchar2);

end PKOBJ_ODATA_CHECK;


/

