create trigger UPDATE_TRIGGER_CDEF_DEFAREA
    before update
    on CDEF_DEFAREA
    for each row
declare
-- local variables here
  n_count        number(10); --记录数，以做判断;
  --nLen_wareno    number(10); --记录wms_code_ref表中的ware_no长度
  --I              number(10); --用来循环记录巷道的次数
  --strStock_No    varchar2(10);--记录巷道的信息

--  strOutMsg      varchar(500) ;
begin
    n_count:=0;
    --nLen_wareno:=0 ;
    --判断仓别是否正确
    begin
      select count(*) into n_count from BDEF_DEFLOC
       where enterprise_no=:old.enterprise_no
         and Warehouse_No =:old.warehouse_no;
    exception
    when no_data_found then
      RAISE_APPLICATION_ERROR(-20004,'N|录入的仓库编码不正确！');
      --strOutMsg:='N|录入的仓别不正确！';
    end;

    if n_count=0 then
      RAISE_APPLICATION_ERROR(-20004,'N|录入的仓库编码不正确！');
    end if ;

    --判断录入strWareName的长度
    if (length(:new.AREA_NAME)=0) then
        RAISE_APPLICATION_ERROR(-20004,'N|录入的储区名称不能为空！');
    end if;

    --判断录入AREA_TYPE的长度
    if (length(:new.AREA_TYPE)=0) then
        RAISE_APPLICATION_ERROR(-20004,'N|录入的储区类型不能为空！');
    end if;

    --判断录入AREA_USETYPE的长度
    if (length(:new.AREA_USETYPE)=0) then
        RAISE_APPLICATION_ERROR(-20004,'N|录入的储区用途不能为空！');
    end if;

    --判断录入AREA_QUALITY的长度
    if (length(:new.AREA_QUALITY)=0) then
        RAISE_APPLICATION_ERROR(-20004,'N|录入的储区品质不能为空！');
    end if;

   --判断录入MIX_FLAG的长度
    if (length(:new.MIX_FLAG)=0) then
        RAISE_APPLICATION_ERROR(-20004,'N|录入的混载标识不能为空！');
    end if;


    --判断录入MAX_QTY的长度
    if (length(:new.MAX_QTY)=0) then
        RAISE_APPLICATION_ERROR(-20004,'N|录入的最大板数不能为空！');
    end if;

    --判断录入STOCK_NUM的长度
    if (length(:new.STOCK_NUM)=0) then
        RAISE_APPLICATION_ERROR(-20004,'N|录入的巷道数不能为空！');
    end if;

    --判断录入B_DIVIDE_FLAG的长度
    if (length(:new.B_DIVIDE_FLAG)=0) then
        RAISE_APPLICATION_ERROR(-20004,'N|录入的物流箱播种标识不能为空！');
    end if;

    --判断录入AREA_ATTRIBUTE的长度
    if (length(:new.AREA_ATTRIBUTE)=0) then
        RAISE_APPLICATION_ERROR(-20004,'N|录入的储区属性不能为空！');
    end if;

    --判断录入ATTRIBUTE_TYPE的长度
    if (length(:new.ATTRIBUTE_TYPE)=0) then
        RAISE_APPLICATION_ERROR(-20004,'N|录入的属性类型不能为空！');
    end if;
   --增加通道数据
   --***********************beggin增加通道数据的处理************************
   --判断当前修改的储区对应的储位是否有库存，如果存在库存，那么不让修改。
    select count(1) into n_count from  cdef_defcell cc,stock_content sc
      where cc.enterprise_no=sc.enterprise_no and cc.warehouse_no=sc.warehouse_no
     and cc.cell_no=sc.cell_no
      and cc.enterprise_no=:old.enterprise_no and cc.warehouse_no=:old.warehouse_no
      and cc.ware_no=:old.ware_no and cc.area_no=:old.area_no and cc.stock_no>'1' ;
    if n_count>0 then
      RAISE_APPLICATION_ERROR(-20004,'N|修改储区对应的储位有库存，不允许修改！');
    end if ;

    --调整储区的值，修改相应的巷道，储位信息
    if (:old.area_type<>:new.area_type)    or (:old.mix_flag<>:new.mix_flag)
                  or (:old.max_qty<>:new.max_qty)    or (:old.limit_type<>:new.limit_type)
                  or (:old.limit_rate<>:new.limit_rate)    or (:old.b_pick<>:new.b_pick)
                  or (:old.area_pick<>:new.area_pick)    or (:old.MIX_SUPPLIER<>:new.MIX_SUPPLIER)
                  or (:old.MAX_CASE<>:new.MAX_CASE)    or (:old.a_flag<>:new.a_flag)
                  or (:old.PICK_FLAG<>:new.PICK_FLAG) or (:old.keep_label_flag<>:new.keep_label_flag)
                  or (:old.max_weight<>:new.max_weight) or (:old.max_volume<>:new.max_volume) then

   --修改储位的信息
        update cdef_defcell set MIX_FLAG=:new.MIX_FLAG,MIX_SUPPLIER=:new.MIX_SUPPLIER,max_qty=:new.max_qty,MAX_CASE=:new.MAX_CASE,
        limit_type=:new.limit_type,limit_rate=:new.limit_rate,a_flag=:new.a_flag,keep_label_flag=:new.keep_label_flag,
         max_weight=:new.max_weight,max_volume=:new.max_volume
        where enterprise_no=:old.enterprise_no and Warehouse_No =:old.warehouse_no
          and ware_no=:old.ware_no and area_no=:old.area_no ;

    end if ;

end update_trigger_CDEF_DEFAREA;


/

