create package body        pkobj_label is
  --标签
  -------------------------------------------------【公共begin】-------------------------------------------
  /*****************************************************************************************
   功能：新增标签日志
  Modify By YanJunFeng AT 2013-03-19
  *****************************************************************************************/
  procedure proc_InsertLabel_Log(strEnterprise_no in STOCK_LABEL_M.enterprise_no%type, --企业
                                 strwarehouse_no  in STOCK_LABEL_M.warehouse_no%type, --仓别
                                 strLableNo       in STOCK_LABEL_M.Label_No%type, --板号
                                 /*strContainerNo  in STOCK_LABEL_M.container_no%type, --容器号*/
                                 strUSER_ID   in STOCK_LABEL_M.updt_name%type, --员工ID
                                 blInsertFlag in number, --标签跟踪非插入时,要判断新状态是否与老状态一致,如一致不新增日志
                                 strSTATUS    in STOCK_LABEL_M.status%type, --状态
                                 strOutMsg    out varchar2) --返回值
   is
  begin
    strOutMsg := 'N|[proc_InsertLabel_Log]';
    if (blInsertFlag = 0) then
      insert into STOCK_LABEL_LOG
        (enterprise_no,
         warehouse_no,
         LABEL_NO,
         CONTAINER_NO,
         OWNER_CELL_NO,
         CONTAINER_TYPE,
         OWNER_CONTAINER_NO,
         STATUS,
         RGST_NAME,
         RGST_DATE)
        select m.enterprise_no,
               m.warehouse_no,
               m.label_no,
               m.container_no,
               m.owner_cell_no,
               m.container_type,
               m.owner_container_no,
               strSTATUS,
               strUSER_ID,
               sysdate
          from STOCK_LABEL_M m
         where m.warehouse_no = strwarehouse_no
              /*and m.container_no = strContainerNo;*/
           and m.label_no = strLableNo
           and m.enterprise_no = strEnterprise_no;
      if sql%notfound then
        strOutMsg := 'N|[E22115]';
        return;
      end if;
    else
      insert into STOCK_LABEL_LOG
        (enterprise_no,
         warehouse_no,
         LABEL_NO,
         CONTAINER_NO,
         OWNER_CELL_NO,
         CONTAINER_TYPE,
         OWNER_CONTAINER_NO,
         STATUS,
         RGST_NAME,
         RGST_DATE)
        select m.enterprise_no,
               m.warehouse_no,
               m.label_no,
               m.container_no,
               m.owner_cell_no,
               m.container_type,
               m.owner_container_no,
               m.status,
               strUSER_ID,
               sysdate
          from STOCK_LABEL_M m
         where m.warehouse_no = strwarehouse_no
              /*and m.container_no = strContainerNo*/
           and m.label_no = strLableNo
           and m.STATUS <> strSTATUS
           and m.enterprise_no = strEnterprise_no;
    end if;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end proc_InsertLabel_Log;

  /*****************************************************************************************
   功能：更新标签头状态
  *****************************************************************************************/
  procedure p_updt_label_status(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                strwarehouse_no in STOCK_LABEL_M.warehouse_no%type, --仓别
                                strContainerNo  in STOCK_LABEL_M.container_no%type, --容器号
                                strUSER_ID      in STOCK_LABEL_M.updt_name%type, --员工ID
                                strSTATUS       in STOCK_LABEL_M.status%type, --状态
                                strOutMsg       out varchar2) is
  begin
    strOutMsg := 'Y|';
    --如果新修改的状态与原状态不一样，则写日志
    insert into STOCK_LABEL_LOG
      (enterprise_no,
       warehouse_no,
       LABEL_NO,
       CONTAINER_NO,
       OWNER_CELL_NO,
       CONTAINER_TYPE,
       OWNER_CONTAINER_NO,
       STATUS,
       RGST_NAME,
       RGST_DATE)
      select m.enterprise_no,
             m.warehouse_no,
             m.label_no,
             m.container_no,
             m.owner_cell_no,
             m.container_type,
             m.owner_container_no,
             strSTATUS,
             strUSER_ID,
             sysdate
        from STOCK_LABEL_M m
       where m.warehouse_no = strwarehouse_no
         and m.enterprise_no = strEnterPriseNo
         and m.container_no = strContainerNo
         and m.STATUS <> strSTATUS;

    --更新标签状态
    update stock_label_m sm
       set sm.status    = strSTATUS,
           sm.updt_date = sysdate,
           sm.updt_name = strUSER_ID
     where sm.container_no = strContainerNo
       and sm.enterprise_no = strEnterPriseNo
       and sm.warehouse_no = strwarehouse_no;

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_updt_label_status;

  /**************************************************************************************
  功能：更新标签明细表状态
  luozhiling
  2015.04.30
  ***************************************************************************************/
  procedure p_updt_labelDetail_status(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                      strwarehouse_no in STOCK_LABEL_M.warehouse_no%type, --仓别
                                      strContainerNo  in STOCK_LABEL_M.container_no%type, --容器号
                                      strUSER_ID      in STOCK_LABEL_M.updt_name%type, --员工ID
                                      strSTATUS       in STOCK_LABEL_M.status%type, --状态
                                      strOutMsg       out varchar2) is
  begin
    strOutMsg := 'Y|';
    --如果新修改的状态与原状态不一样，则写日志

    --更新标签状态
    update stock_label_d sm
       set sm.status    = strSTATUS,
           sm.updt_date = sysdate,
           sm.updt_name = strUSER_ID
     where sm.container_no = strContainerNo
       and sm.enterprise_no = strEnterPriseNo
       and sm.warehouse_no = strwarehouse_no;

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_updt_labelDetail_status;

  /*****************************************************************************************
   功能：标签日志 转历史
  Modify By YanJunFeng AT 2013-03-20
  *****************************************************************************************/
  procedure proc_InsertLabel_LogHTY(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                    strwarehouse_no in STOCK_LABEL_M.warehouse_no%type, --仓别
                                    strContainerNo  in STOCK_LABEL_M.container_no%type, --容器号
                                    strUSER_ID      in STOCK_LABEL_M.updt_name%type, --员工ID
                                    strOutMsg       out varchar2) --返回值
   is
  begin

    strOutMsg := 'N|[proc_InsertLabel_LogHTY]';
    INSERT INTO STOCK_LABEL_LOGHTY
      (enterprise_no,
       warehouse_no,
       LABEL_NO,
       CONTAINER_NO,
       OWNER_CELL_NO,
       CONTAINER_TYPE,
       OWNER_CONTAINER_NO,
       STATUS,
       RGST_NAME,
       RGST_DATE,
       ROW_ID)
      SELECT cllh.enterprise_no,
             CLLH.warehouse_no,
             CLLH.LABEL_NO,
             CLLH.CONTAINER_NO,
             CLLH.OWNER_CELL_NO,
             CLLH.CONTAINER_TYPE,
             CLLH.OWNER_CONTAINER_NO,
             CLLH.STATUS,
             strUSER_ID,
             sysdate,
             ROW_ID
        FROM STOCK_LABEL_LOG CLLH
       where CLLH.warehouse_no = strwarehouse_no
         and cllh.enterprise_no = strEnterPriseNo
         and CLLH.container_no = strContainerNo;
    DELETE STOCK_LABEL_LOG
     WHERE warehouse_no = strwarehouse_no
       and enterprise_no = strEnterPriseNo
       and container_no = strContainerNo;
    if sql%notfound then
      strOutMsg := 'N|[E22306]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end proc_InsertLabel_LogHTY;

  /*****************************************************************************************
     功能：新增标签号
  *****************************************************************************************/
  procedure proc_Insert_LabelMaster(strEnterprise_no      in STOCK_LABEL_M.enterprise_no%type, --企业
                                    strwarehouse_no       in STOCK_LABEL_M.warehouse_no%type, --仓别
                                    strBATCH_NO           in STOCK_LABEL_M.BATCH_NO%type, --批次
                                    strSOURCE_NO          in STOCK_LABEL_M.SOURCE_NO%type, --来源单号
                                    strLABEL_NO           in STOCK_LABEL_M.LABEL_NO%type, --标签号
                                    strCONTAINER_NO       in STOCK_LABEL_M.CONTAINER_NO%type, --内部容器号
                                    strCONTAINER_TYPE     in STOCK_LABEL_M.CONTAINER_TYPE%type, --容器类型
                                    strDELIVER_AREA       in STOCK_LABEL_M.DELIVER_AREA%type, --发货区储位
                                    strOWNER_CELL_NO      in STOCK_LABEL_M.OWNER_CELL_NO%type, --最后并入储位
                                    strCUST_NO            in STOCK_LABEL_M.CUST_NO%type, --客户编号
                                    strTRUNCK_CELL_NO     in STOCK_LABEL_M.TRUNCK_CELL_NO%type, --笼车上储位编码
                                    strA_SORTER_CHUTE_NO  in STOCK_LABEL_M.A_SORTER_CHUTE_NO%type, --大分拣机滑道号
                                    strCHECK_CHUTE_NO     in STOCK_LABEL_M.CHECK_CHUTE_NO%type, --复核台滑道号
                                    strDELIVER_OBJ        in STOCK_LABEL_M.DELIVER_OBJ%type, --配送对象
                                    strUSE_TYPE           in STOCK_LABEL_M.USE_TYPE%type, --标签用途
                                    strLINE_NO            in STOCK_LABEL_M.LINE_NO%type, --线路
                                    strCURR_AREA          in STOCK_LABEL_M.CURR_AREA%type, --当前位置
                                    strDeviceNo           in STOCK_LABEL_M.DEVICE_NO%type, --设备类型
                                    strRGST_NAME          in STOCK_LABEL_M.RGST_NAME%type, --添加人员
                                    strREPORT_ID          in STOCK_LABEL_M.REPORT_ID%type, --报表ID
                                    strMID_LABEL_NO       in STOCK_LABEL_M.MID_LABEL_NO%type, --出货物流箱号
                                    strBIG_EXP_NO_FLAG    in STOCK_LABEL_M.BIG_EXP_NO_FLAG%type, --大批量出货单标识
                                    strSTOCK_TYPE         in STOCK_LABEL_M.STOCK_TYPE%type, --存储类型
                                    strCHUTE_LABEL_FLAG   in STOCK_LABEL_M.CHUTE_LABEL_FLAG%type, --是否大分拣机滑道口取号标签，可用于并板，0：不是；1：是
                                    strOWNER_CONTAINER_NO in STOCK_LABEL_M.OWNER_CONTAINER_NO%type, --最后并入容器号
                                    strstatus             in STOCK_LABEL_M.status%type, --状态
                                    strHm_Manual_Flag     in STOCK_LABEL_M.Hm_Manual_Flag%type, --是否储位库存 1储位库存，0标签库存
                                    strWaveNo             in stock_label_m.wave_no%type, --若没有波次，写为N
                                    strOutMsg             out varchar2) --返回 执行结果
   is
  begin
    strOutMsg := 'N|[proc_Insert_LabelMaster]';

    ------------1新增标签头挡---------------------------------------------------
    insert into STOCK_LABEL_M
      (warehouse_no,
       REPORT_ID,
       BATCH_NO,
       SOURCE_NO,
       LABEL_NO,
       CONTAINER_NO,
       CONTAINER_TYPE,
       DELIVER_AREA,
       STATUS,
       OWNER_CELL_NO,
       BIG_EXP_NO_FLAG,
       OWNER_CONTAINER_NO,
       CUST_NO,
       TRUNCK_CELL_NO,
       A_SORTER_CHUTE_NO,
       CHECK_CHUTE_NO,
       RGST_NAME,
       RGST_DATE,
       STOCK_TYPE,
       mid_label_no,
       DELIVER_OBJ,
       USE_TYPE,
       LINE_NO,
       DEVICE_NO,
       CURR_AREA,
       CHUTE_LABEL_FLAG,
       Hm_Manual_Flag,
       updt_name,
       updt_date,
       ENTERPRISE_NO,
       wave_no)
    values
      (strwarehouse_no,
       strREPORT_ID,
       strBATCH_NO,
       strSOURCE_NO,
       strLABEL_NO,
       strCONTAINER_NO,
       strCONTAINER_TYPE,
       strDELIVER_AREA,
       strstatus,
       strOWNER_CELL_NO,
       strBIG_EXP_NO_FLAG,
       strOWNER_CONTAINER_NO,
       strCUST_NO,
       strTRUNCK_CELL_NO,
       strA_SORTER_CHUTE_NO,
       strCHECK_CHUTE_NO,
       strRGST_NAME,
       sysdate,
       strSTOCK_TYPE,
       strmid_label_no,
       strDELIVER_OBJ,
       strUSE_TYPE,
       strLINE_NO,
       strDeviceNo,
       strCURR_AREA,
       strCHUTE_LABEL_FLAG,
       strHm_Manual_Flag,
       strRGST_NAME,
       sysdate,
       strEnterprise_no,
       strWaveNo);
    if sql%rowcount <= 0 then
      --新增失败
      strOutMsg := 'N|[E00006]';
      return;
    end if;
    ------------2新增标签日志---------------------------------------------------
    proc_InsertLabel_Log(strEnterprise_no,
                         strwarehouse_no,
                         strLABEL_NO,
                         strRGST_NAME,
                         0,
                         strstatus,
                         strOutMsg);
    if (substr(strOutMsg, 1, 1) <> 'Y') then
      return;
    end if;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end proc_Insert_LabelMaster;

  procedure proc_Insert_LabelDetail(strEnterPriseNo    in stock_label_m.enterprise_no%type,
                                    strWAREHOUSE_NO    in STOCK_LABEL_D.WAREHOUSE_NO%TYPE,
                                    strBATCH_NO        in STOCK_LABEL_D.BATCH_NO%TYPE,
                                    strOWNER_NO        in stock_label_d.owner_no%type,
                                    strSOURCE_NO       in stock_label_d.source_no%type,
                                    strCONTAINER_NO    in stock_label_d.container_no%type,
                                    strCONTAINER_TYPE  in stock_label_d.container_type%type,
                                    strARTICLE_NO      in stock_label_d.article_no%type,
                                    nARTICLE_ID        in stock_label_d.article_id%type,
                                    nPACKING_QTY       in stock_label_d.packing_qty%type,
                                    nQTY               in stock_label_d.qty%type,
                                    strEXP_NO          in stock_label_d.exp_no%type,
                                    strWaveNo          in stock_label_d.wave_no%type,
                                    strCUST_NO         in stock_label_d.CUST_NO%type,
                                    strSUB_CUST_NO     in stock_label_d.SUB_CUST_NO%type,
                                    strLINE_NO         in stock_label_d.LINE_NO%type,
                                    strSTATUS          in stock_label_d.STATUS%type,
                                    nDIVIDE_ID         in stock_label_d.DIVIDE_ID%type,
                                    strEXP_TYPE        in stock_label_d.EXP_TYPE%type,
                                    strDPS_CELL_NO     in stock_label_d.DPS_CELL_NO%type,
                                    strUserID          in stock_label_d.RGST_NAME%type,
                                    strDELIVER_OBJ     in stock_label_d.DELIVER_OBJ%type,
                                    strDeliverObjOrder in stock_label_d.deliverobj_order%type,
                                    dEXP_DATE          in stock_label_d.EXP_DATE%type,
                                    strADVANCE_CELL_NO in stock_label_d.ADVANCE_CELL_NO%type,
                                    strADVANCE_STATUS  in stock_label_d.ADVANCE_STATUS%type,
                                    strOutMsg          out varchar2) is
    v_RowID integer := 1;
  begin
    strOutMsg := 'N|[proc_Insert_LabelDetail]';

    update stock_label_d d
       set d.status = d.status
     where d.warehouse_no = strWAREHOUSE_NO
       and d.enterprise_no = strEnterPriseNo
       and d.container_no = strCONTAINER_NO;

    v_RowID := v_RowID + sql%rowcount;

    insert into stock_label_d
      (enterprise_no,
       warehouse_no,
       batch_no,
       owner_no,
       source_no,
       container_no,
       container_type,
       article_no,
       article_id,
       packing_qty,
       qty,
       exp_no,
       wave_no,
       cust_no,
       sub_cust_no,
       line_no,
       status,
       divide_id,
       row_id,
       exp_type,
       dps_cell_no,
       rgst_name,
       rgst_date,
       updt_name,
       updt_date,
       deliver_obj,
       exp_date,
       advance_cell_no,
       advance_status,
       deliverobj_order)
    values
      (strEnterPriseNo,
       strWAREHOUSE_NO,
       strBATCH_NO,
       strOWNER_NO,
       strSOURCE_NO,
       strCONTAINER_NO,
       strCONTAINER_TYPE,
       strARTICLE_NO,
       nARTICLE_ID,
       nPACKING_QTY,
       nQTY,
       strEXP_NO,
       strWaveNo,
       strCUST_NO,
       strSUB_CUST_NO,
       strLINE_NO,
       strSTATUS,
       nDIVIDE_ID,
       v_RowID,
       strEXP_TYPE,
       strDPS_CELL_NO,
       strUserID,
       sysdate,
       strUserID,
       sysdate,
       strDELIVER_OBJ,
       dEXP_DATE,
       strADVANCE_CELL_NO,
       '10',
       strDeliverObjOrder);

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end proc_Insert_LabelDetail;

  /*****************************************************************************************
   功能：标签转历史
   新增总量转历史 huangb 20160818
  *****************************************************************************************/
  procedure proc_RemoveLabel(strEnterPriseNo in stock_label_m.enterprise_no%type,
                             strwarehouse_no in STOCK_LABEL_M.warehouse_no%type, --仓别
                             strContainerNo  in STOCK_LABEL_M.container_no%type, --容器号
                             strOutMsg       out varchar2) --返回值
   is
  begin
    strOutMsg := 'N|[proc_RemoveLabel]';
    -----------------------------标签主档转历史-----------------------------------------------------------
    INSERT INTO STOCK_LABEL_MHTY
      (enterprise_no,
       A_SORTER_CHUTE_NO,
       BATCH_NO,
       BIG_EXP_NO_FLAG,
       CHECK_CHUTE_INSTATUS,
       CHECK_CHUTE_NO,
       CONTAINER_NO,
       CONTAINER_TYPE,
       CURR_AREA,
       CUST_NO,
       DELIVER_AREA,
       DELIVER_OBJ,
       DEVICE_NO,
       HEIGHT,
       LABEL_NO,
       LENGTH,
       LINE_NO,
       LOAD_CONTAINER_NO,
       warehouse_no,
       MID_LABEL_NO,
       OWNER_CELL_NO,
       OWNER_CONTAINER_NO,
       RECHECK_NO,
       REPORT_ID,
       RGST_DATE,
       RGST_NAME,
       SEQ_VALUE,
       SOURCE_NO,
       STATUS,
       TRUNCK_CELL_NO,
       UPDT_DATE,
       UPDT_NAME,
       USE_TYPE,
       WIDTH,
       STOCK_TYPE,
       EXP_DATE,
       Hm_Manual_Flag,
       wave_no,
       --huangb 20160509
       REPORT_UP_SERIAL,
       --huangb 20160818
       weight)
      SELECT enterprise_no,
             A_SORTER_CHUTE_NO,
             BATCH_NO,
             BIG_EXP_NO_FLAG,
             CHECK_CHUTE_INSTATUS,
             CHECK_CHUTE_NO,
             CONTAINER_NO,
             CONTAINER_TYPE,
             CURR_AREA,
             CUST_NO,
             DELIVER_AREA,
             DELIVER_OBJ,
             DEVICE_NO,
             HEIGHT,
             LABEL_NO,
             LENGTH,
             LINE_NO,
             LOAD_CONTAINER_NO,
             warehouse_no,
             MID_LABEL_NO,
             OWNER_CELL_NO,
             OWNER_CONTAINER_NO,
             RECHECK_NO,
             REPORT_ID,
             RGST_DATE,
             RGST_NAME,
             SEQ_VALUE,
             SOURCE_NO,
             STATUS,
             TRUNCK_CELL_NO,
             UPDT_DATE,
             UPDT_NAME,
             USE_TYPE,
             WIDTH,
             STOCK_TYPE,
             EXP_DATE,
             Hm_Manual_Flag,
             wave_no,
             --huangb 20160509
             REPORT_UP_SERIAL,
             --huangb 20160818
             weight
        FROM STOCK_LABEL_M
       WHERE warehouse_no = strwarehouse_no
         and enterprise_no = strEnterPriseNo
         and (CONTAINER_NO = strContainerNo or
             OWNER_CONTAINER_NO = strContainerNo);
    -----------------------------标签明细转历史-----------------------------------------------------------
    INSERT INTO STOCK_LABEL_DHTY
      (enterprise_no,
       UPDT_DATE,
       UPDT_NAME,
       RGST_DATE,
       RGST_NAME,
       DPS_CELL_NO,
       EXP_TYPE,
       ROW_ID,
       DIVIDE_ID,
       STATUS,
       LINE_NO,
       SUB_CUST_NO,
       CUST_NO,
       wave_no,
       EXP_NO,
       QTY,
       PACKING_QTY,
       ARTICLE_ID,
       ARTICLE_NO,
       CONTAINER_TYPE,
       CONTAINER_NO,
       SOURCE_NO,
       OWNER_NO,
       BATCH_NO,
       warehouse_no,
       ADVANCE_STATUS,
       ADVANCE_CELL_NO,
       EXP_DATE,
       DELIVER_OBJ)
      SELECT enterprise_no,
             UPDT_DATE,
             UPDT_NAME,
             RGST_DATE,
             RGST_NAME,
             DPS_CELL_NO,
             EXP_TYPE,
             ROW_ID,
             DIVIDE_ID,
             STATUS,
             LINE_NO,
             SUB_CUST_NO,
             CUST_NO,
             wave_no,
             EXP_NO,
             QTY,
             PACKING_QTY,
             ARTICLE_ID,
             ARTICLE_NO,
             CONTAINER_TYPE,
             CONTAINER_NO,
             SOURCE_NO,
             OWNER_NO,
             BATCH_NO,
             warehouse_no,
             ADVANCE_STATUS,
             ADVANCE_CELL_NO,
             EXP_DATE,
             DELIVER_OBJ
        FROM STOCK_LABEL_D d
       WHERE warehouse_no = strwarehouse_no
         and enterprise_no = strEnterPriseNo
         and CONTAINER_NO in
             (select distinct CONTAINER_NO
                from STOCK_LABEL_M
               WHERE warehouse_no = strwarehouse_no
                 and enterprise_no = strEnterPriseNo
                 and (CONTAINER_NO = strContainerNo or
                     OWNER_CONTAINER_NO = strContainerNo));
    -----------------------------标签日志转历史-----------------------------------------------------------
    Insert into STOCK_LABEL_LOGhty
      (enterprise_no,
       ROW_ID,
       warehouse_no,
       LABEL_NO,
       CONTAINER_NO,
       CONTAINER_TYPE,
       OWNER_CONTAINER_NO,
       STATUS,
       RGST_NAME,
       RGST_DATE,
       OWNER_CELL_NO,
       CURR_AREA)
      select enterprise_no,
             ROW_ID,
             warehouse_no,
             LABEL_NO,
             CONTAINER_NO,
             CONTAINER_TYPE,
             OWNER_CONTAINER_NO,
             STATUS,
             RGST_NAME,
             RGST_DATE,
             OWNER_CELL_NO,
             CURR_AREA
        from STOCK_LABEL_LOG
       WHERE warehouse_no = strwarehouse_no
         and enterprise_no = strEnterPriseNo
         and CONTAINER_NO in
             (select distinct CONTAINER_NO
                from STOCK_LABEL_M
               WHERE warehouse_no = strwarehouse_no
                 and enterprise_no = strEnterPriseNo
                 and (CONTAINER_NO = strContainerNo or
                     OWNER_CONTAINER_NO = strContainerNo));
    -----------------------------删除标签日志-----------------------------------------------------------
    delete STOCK_LABEL_LOG
     WHERE warehouse_no = strwarehouse_no
       and enterprise_no = strEnterPriseNo
       and CONTAINER_NO in
           (select distinct CONTAINER_NO
              from STOCK_LABEL_M
             WHERE warehouse_no = strwarehouse_no
               and enterprise_no = strEnterPriseNo
               and (CONTAINER_NO = strContainerNo or
                   OWNER_CONTAINER_NO = strContainerNo));
    -----------------------------删除标签明细-----------------------------------------------------------
    delete STOCK_LABEL_D
     WHERE warehouse_no = strwarehouse_no
       and enterprise_no = strEnterPriseNo
       and CONTAINER_NO in
           (select distinct CONTAINER_NO
              from STOCK_LABEL_M
             WHERE warehouse_no = strwarehouse_no
               and enterprise_no = strEnterPriseNo
               and (CONTAINER_NO = strContainerNo or
                   OWNER_CONTAINER_NO = strContainerNo));
    -----------------------------删除标签头挡-----------------------------------------------------------
    delete STOCK_LABEL_M
     WHERE warehouse_no = strwarehouse_no
       and enterprise_no = strEnterPriseNo
       and (CONTAINER_NO = strContainerNo or
           OWNER_CONTAINER_NO = strContainerNo);
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end proc_RemoveLabel;

  -------------------------------------------------【公共end】-------------------------------------------------------

  -------------------------------------------------【出货begin】-------------------------------------------------

  /*****************************************************************************************
   功能：销毁空标签头 容器整理使用
  Modify By YanJunFeng AT 2013-03-20
  *****************************************************************************************/

  procedure proc_OM_Destory_NullLabel(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                      strwarehouse_no in STOCK_LABEL_M.warehouse_no%type, --仓别
                                      strContainerNo  in STOCK_LABEL_M.container_no%type, --容器号
                                      strUSER_ID      in STOCK_LABEL_M.updt_name%type, --员工ID
                                      strOutMsg       out varchar2) --是否成功
   is
    n_count number(10); --获取行数，以做判断;
  begin
    strOutMsg := 'N|[proc_OM_Destory_NullLabel]';
    ------查询是否有标签明细-----
    select count(*)
      into n_count
      from STOCK_LABEL_D ld
     where ld.warehouse_no = strwarehouse_no
       and ld.enterprise_no = strEnterPriseNo
       and ld.container_no = strContainerNo;
    if (n_count = 0) then
      ------------修改状态--------------------
      UPDATE STOCK_LABEL_M LM
         SET LM.STATUS    = CLabelStatus.ARRANGE_COMPLETE,
             LM.UPDT_NAME = strUSER_ID,
             LM.UPDT_DATE = SYSDATE
       WHERE LM.warehouse_no = strwarehouse_no
         and lm.enterprise_no = strEnterPriseNo
         AND LM.CONTAINER_NO = strContainerNo;
      ------------新增标签日志----------------
      insert into STOCK_LABEL_LOG
        (enterprise_no,
         warehouse_no,
         LABEL_NO,
         CONTAINER_NO,
         OWNER_CELL_NO,
         CONTAINER_TYPE,
         OWNER_CONTAINER_NO,
         STATUS,
         RGST_NAME,
         RGST_DATE)
        select m.enterprise_no,
               m.warehouse_no,
               m.label_no,
               m.container_no,
               m.owner_cell_no,
               m.container_type,
               m.owner_container_no,
               CLabelStatus.ARRANGE_COMPLETE,
               strUSER_ID,
               sysdate
          from STOCK_LABEL_M m
         where m.warehouse_no = strwarehouse_no
           and m.enterprise_no = strEnterPriseNo
           and m.container_no = strContainerNo;
      -------------------标签转历史-----------------
      insert into STOCK_LABEL_Mhty
        (enterprise_no,
         warehouse_no,
         BATCH_NO,
         SOURCE_NO,
         LABEL_NO,
         CONTAINER_NO,
         CONTAINER_TYPE,
         DELIVER_AREA,
         STATUS,
         LOAD_CONTAINER_NO,
         OWNER_CONTAINER_NO,
         OWNER_CELL_NO,
         CUST_NO,
         TRUNCK_CELL_NO,
         A_SORTER_CHUTE_NO,
         CHECK_CHUTE_NO,
         DELIVER_OBJ,
         USE_TYPE,
         LINE_NO,
         CURR_AREA,
         SEQ_VALUE,
         LENGTH,
         WIDTH,
         HEIGHT,
         DEVICE_NO,
         RGST_NAME,
         RGST_DATE,
         UPDT_NAME,
         UPDT_DATE,
         REPORT_ID,
         RECHECK_NO,
         MID_LABEL_NO,
         BIG_EXP_NO_FLAG,
         CHECK_CHUTE_INSTATUS,
         STOCK_TYPE,
         EXP_DATE,
         CHUTE_LABEL_FLAG,
         wave_no,
         --huangb 20160509
         REPORT_UP_SERIAL)
        select enterprise_no,
               warehouse_no,
               BATCH_NO,
               SOURCE_NO,
               LABEL_NO,
               CONTAINER_NO,
               CONTAINER_TYPE,
               DELIVER_AREA,
               STATUS,
               LOAD_CONTAINER_NO,
               OWNER_CONTAINER_NO,
               OWNER_CELL_NO,
               CUST_NO,
               TRUNCK_CELL_NO,
               A_SORTER_CHUTE_NO,
               CHECK_CHUTE_NO,
               DELIVER_OBJ,
               USE_TYPE,
               LINE_NO,
               CURR_AREA,
               SEQ_VALUE,
               LENGTH,
               WIDTH,
               HEIGHT,
               DEVICE_NO,
               RGST_NAME,
               RGST_DATE,
               UPDT_NAME,
               UPDT_DATE,
               REPORT_ID,
               RECHECK_NO,
               MID_LABEL_NO,
               BIG_EXP_NO_FLAG,
               CHECK_CHUTE_INSTATUS,
               STOCK_TYPE,
               EXP_DATE,
               CHUTE_LABEL_FLAG,
               wave_no,
               --huangb 20160509
               REPORT_UP_SERIAL
          from STOCK_LABEL_M m
         where m.warehouse_no = strwarehouse_no
           and m.enterprise_no = strEnterPriseNo
           and m.container_no = strContainerNo;
      -----------------删除标签表记录-------------
      delete STOCK_LABEL_M m
       where m.warehouse_no = strwarehouse_no
         and m.enterprise_no = strEnterPriseNo
         and m.container_no = strContainerNo;
      ---------------标签日志转历史-------------
      INSERT INTO STOCK_LABEL_LOGHTY
        (enterprise_no,
         warehouse_no,
         LABEL_NO,
         CONTAINER_NO,
         OWNER_CELL_NO,
         CONTAINER_TYPE,
         OWNER_CONTAINER_NO,
         STATUS,
         RGST_NAME,
         RGST_DATE,
         ROW_ID)
        SELECT cllh.enterprise_no,
               CLLH.warehouse_no,
               CLLH.LABEL_NO,
               CLLH.CONTAINER_NO,
               CLLH.OWNER_CELL_NO,
               CLLH.CONTAINER_TYPE,
               CLLH.OWNER_CONTAINER_NO,
               CLLH.STATUS,
               strUSER_ID,
               sysdate,
               ROW_ID
          FROM STOCK_LABEL_LOG CLLH
         where CLLH.warehouse_no = strwarehouse_no
           and cllh.enterprise_no = strEnterPriseNo
           and CLLH.container_no = strContainerNo;

      delete from stock_label_log
       where warehouse_no = strwarehouse_no
         and enterprise_no = strEnterPriseNo
         and container_no = strContainerNo;
    else
      strOutMsg := 'Y|';
      return;
    end if;

    if sql%notfound then
      strOutMsg := 'N|[E00010]';
      return;
    end if;
    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end proc_OM_Destory_NullLabel;

  /*=====================================================================================
  snake insert to 20130325
  容器整理----标签转移
  ======================================================================================*/
  PROCEDURE proc_OM_ArrangeMoveLabelInfo(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                         strwarehouse_no in STOCK_LABEL_M.warehouse_no%type, --仓别
                                         strArrange_No   in STOCK_LABEL_Move_log.arrange_no%type, --整理单据号
                                         strUser_Id      in STOCK_LABEL_M.rgst_name%type,
                                         strOutMsg       out varchar2) is
    n_arrange_count number(10); --获取整理数据明细行数，以做判断
    strD_Status     STOCK_LABEL_M.status%type; --目的标签明细状态
    v_strAutoFlag   wms_deflabel_status.must_run%type;
    n_RowID         STOCK_LABEL_D.row_id%type; --新增的目的容器ID
  begin
    strOutMsg       := 'N|[proc_OM_ArrangeMoveLabelInfo]';
    n_arrange_count := 0;
    --STOCK_LABEL_Move_log表中的信息，除了d_container_no，其余的信息都来源于源标签明细信息
    for i_ArrangeInfo in (select clml.*,
                                 d_clm.container_type as d_Container_Type,
                                 d_clm.status         as d_status
                            from STOCK_LABEL_Move_log clml,
                                 STOCK_LABEL_M        d_clm
                           where d_clm.warehouse_no = clml.warehouse_no
                             and d_clm.enterprise_no = clml.enterprise_no
                             and d_clm.enterprise_no = strEnterPriseNo
                             and d_clm.container_no = clml.d_container_no
                             and clml.warehouse_no = strwarehouse_no
                             and clml.arrange_no = strArrange_No) loop
      n_arrange_count := n_arrange_count + 1;
      --如果目的标签头档的状态为新取号，则明细的状态改为61（整理中），否则状态和源容器一致
      if i_ArrangeInfo.d_Status = CLabelStatus.NEW_LABEL_NO then
        --strD_Status := i_ArrangeInfo.d_Status;
        PKOBJ_HB.p_GetLabelStatusFromWorkflow(strEnterPriseNo,
                                              strwarehouse_no,
                                              i_ArrangeInfo.Owner_No,
                                              i_ArrangeInfo.Exp_Type,
                                              i_ArrangeInfo.s_containeR_no,
                                              strD_Status,
                                              v_strAutoFlag,
                                              strOutMsg);
        if (substr(strOutMsg, 1, 1) <> 'Y') then
          return;
        end if;

        --取工作流
      else
        strD_Status := i_ArrangeInfo.d_Status;
      end if;

      /*
      1：扣减源标签的量
      2：检查目的标签中是否已存在要整理的商品
         如果目的标签不存在则修改量，否则新增目的标签明细
      */
      --扣减源标签的量
      update STOCK_LABEL_D cld
         set cld.qty       = cld.qty - i_ArrangeInfo.Move_Qty,
             cld.updt_name = strUser_Id,
             cld.updt_date = sysdate
       where cld.warehouse_no = strwarehouse_no
         and cld.enterprise_no = strEnterPriseNo
         and cld.container_no = i_ArrangeInfo.s_Container_No
         and cld.article_no = i_ArrangeInfo.Article_No
         and cld.article_id = i_ArrangeInfo.Article_Id
         and cld.divide_id = i_ArrangeInfo.Divide_Id
         and cld.row_id = i_ArrangeInfo.Row_Id;
      if sql%rowcount <= 0 then
        strOutMsg := 'N|[E22701]';
        return;
      end if;

      --更新目的标签明细量
      update STOCK_LABEL_D cld
         set cld.qty       = cld.qty + i_ArrangeInfo.Move_Qty,
             cld.updt_name = strUser_Id,
             cld.updt_date = sysdate
       where cld.warehouse_no = strwarehouse_no
         and cld.enterprise_no = strEnterPriseNo
         and cld.container_no = i_ArrangeInfo.d_Container_No
         and cld.article_no = i_ArrangeInfo.Article_No
         and cld.article_id = i_ArrangeInfo.Article_Id
         and cld.divide_id = i_ArrangeInfo.Divide_Id
         and cld.batch_no = i_ArrangeInfo.Batch_No
         and cld.owner_no = i_ArrangeInfo.Owner_No
         and cld.source_no = i_ArrangeInfo.Source_No
         and cld.packing_qty = i_ArrangeInfo.Packing_Qty
         and cld.exp_no = i_ArrangeInfo.Exp_No
         and cld.exp_type = i_ArrangeInfo.Exp_Type
         and cld.wave_no = i_ArrangeInfo.wave_no
         and cld.line_no = i_ArrangeInfo.Line_No
         and cld.cust_no = i_ArrangeInfo.Cust_No
         and cld.sub_cust_no = i_ArrangeInfo.Sub_Cust_No
         and rownum = 1; --由于不能带主键中的row_id，所以为了保证数据的正确性，每次更新只能更新一条数据

      if sql%rowcount <= 0 then
        --获取目的标签最大的row_id
        select nvl(max(d_cld.row_id), 0) + 1
          into n_RowID
          from STOCK_LABEL_D d_cld
         where d_cld.warehouse_no = strwarehouse_no
           and d_cld.enterprise_no = strEnterPriseNo
           and d_cld.container_no = i_ArrangeInfo.d_Container_No;

        --新增目的标签明细数据
        insert into STOCK_LABEL_D
          (enterprise_no,
           warehouse_no,
           BATCH_NO,
           OWNER_NO,
           SOURCE_NO,
           CONTAINER_NO,
           CONTAINER_TYPE,
           ARTICLE_NO,
           ARTICLE_ID,
           PACKING_QTY,
           QTY,
           EXP_NO,
           WAVE_NO,
           CUST_NO,
           SUB_CUST_NO,
           LINE_NO,
           STATUS,
           DIVIDE_ID,
           ROW_ID,
           EXP_TYPE,
           DPS_CELL_NO,
           RGST_NAME,
           RGST_DATE,
           UPDT_NAME,
           UPDT_DATE,
           DELIVER_OBJ,
           EXP_DATE,
           ADVANCE_CELL_NO,
           ADVANCE_STATUS)
          select enterprise_no,
                 warehouse_no,
                 BATCH_NO,
                 OWNER_NO,
                 SOURCE_NO,
                 i_ArrangeInfo.d_Container_No,
                 i_ArrangeInfo.d_Container_Type,
                 ARTICLE_NO,
                 ARTICLE_ID,
                 PACKING_QTY,
                 i_ArrangeInfo.Move_Qty,
                 EXP_NO,
                 WAVE_NO,
                 CUST_NO,
                 SUB_CUST_NO,
                 LINE_NO,
                 strD_Status,
                 DIVIDE_ID,
                 n_RowID,
                 EXP_TYPE,
                 DPS_CELL_NO,
                 RGST_NAME,
                 sysdate,
                 strUser_Id,
                 sysdate,
                 DELIVER_OBJ,
                 EXP_DATE,
                 ADVANCE_CELL_NO,
                 ADVANCE_STATUS
            from STOCK_LABEL_D s_cld
           where s_cld.warehouse_no = strwarehouse_no
             and s_cld.enterprise_no = strEnterPriseNo
             and s_cld.container_no = i_ArrangeInfo.s_Container_No
             and s_cld.article_no = i_ArrangeInfo.Article_No
             and s_cld.article_id = i_ArrangeInfo.Article_Id
             and s_cld.divide_id = i_ArrangeInfo.Divide_Id
             and s_cld.row_id = i_ArrangeInfo.Row_Id;
        if sql%rowcount <= 0 then
          strOutMsg := 'N|[E22702]';
          return;
        end if;
      end if;

      --删除标签数量为“0”的源标签明细
      delete STOCK_LABEL_D
       where warehouse_no = strwarehouse_no
         and enterprise_no = strEnterPriseNo
         and container_no = i_ArrangeInfo.s_Container_No
         and article_no = i_ArrangeInfo.Article_No
         and article_id = i_ArrangeInfo.Article_Id
         and divide_id = i_ArrangeInfo.Divide_Id
         and qty = 0;

    end loop;

    if (n_arrange_count <= 0) then
      strOutMsg := 'N|[E22703]';
      return;
    end if;

    strOutMsg := 'Y|转移标签数据成功！';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end proc_OM_ArrangeMoveLabelInfo;

  /*标签信息转移*/
  PROCEDURE proc_om_ArrangeByCheck_No(strEnterPriseNo   in stock_label_m.enterprise_no%type,
                                      strwarehouse_no   in STOCK_LABEL_M.warehouse_no%type, --仓别
                                      strOwner_no       in odata_check_label_d.owner_no%type,
                                      strCheck_No       in odata_check_m.check_no%type, --复核单号
                                      strS_Container_No in odata_check_label_d.container_no%type,
                                      nRealQty          in odata_check_label_d.real_qty%type,
                                      nS_RowID          in odata_check_label_d.row_id%type,
                                      strUser_Id        in STOCK_LABEL_M.rgst_name%type,
                                      strOutMsg         out varchar2) is
      v_nCurrQty                      odata_check_d.real_qty%type:=0;
      v_nRemainQty                     odata_check_d.real_qty%type:=nRealQty;
  begin

    strOutMsg := 'N|[proc_om_ArrangeByCheck_No]';

    for GetLabelItem in(select m.status as sSTATUS,m.container_no as sContianer_no,m.container_type as s_container_type,
         sd.* from odata_check_label_d d, stock_label_m m, stock_label_d sd
        where d.enterprise_no = strEnterPriseNo
         and d.warehouse_no = strwarehouse_no
         and d.owner_no = strOwner_no
         and d.check_no = strCheck_No

         and sd.container_no = d.container_no
         and sd.article_no = d.article_no
         and sd.article_id=d.article_id
         and sd.enterprise_no = d.enterprise_no
         and sd.warehouse_no = d.warehouse_no
         and d.divide_id=sd.divide_id

         and d.container_no = strS_Container_No
         and m.label_no = d.d_label_no
         and m.enterprise_no = d.enterprise_no
         and m.warehouse_no = d.warehouse_no
         and d.row_id = nS_RowID) loop


        if v_nRemainQty > GetLabelItem.qty then
          v_nCurrQty := GetLabelItem.qty;
        else
          v_nCurrQty := v_nRemainQty;
        end if;

        v_nRemainQty := v_nRemainQty - v_nCurrQty;

        insert into stock_label_d(warehouse_no, batch_no, owner_no, source_no,
           container_no,container_type,article_no,article_id,packing_qty,
           qty,exp_no,wave_no,cust_no,sub_cust_no,line_no,
           status,divide_id,row_id,exp_type,dps_cell_no,deliver_obj,exp_date,
           advance_cell_no,advance_status,rgst_name,rgst_date,
           updt_name,updt_date,enterprise_no,deliverobj_order)
          select t.warehouse_no,t.batch_no,t.owner_no,strCheck_No,
                 GetLabelItem.sContianer_no, GetLabelItem.s_container_type,t.article_no,t.article_id,t.packing_qty,
                 v_nCurrQty,t.exp_no,t.wave_no,t.cust_no,t.sub_cust_no,t.line_no,
                 GetLabelItem.sSTATUS,t.divide_id,t.row_id,t.exp_type,t.dps_cell_no,t.deliver_obj,t.exp_date,
                 t.advance_cell_no,t.advance_status,t.rgst_name,sysdate,
                 t.updt_name,sysdate,t.enterprise_no,t.deliverobj_order
            from stock_label_d t
           where t.enterprise_no = strEnterPriseNo
             and t.warehouse_no = strwarehouse_no
             and t.container_no = GetLabelItem.container_no
             and t.row_id = GetLabelItem.row_id;

        update stock_label_d t set t.qty=t.qty-v_nCurrQty
        where t.enterprise_no = strEnterPriseNo
             and t.warehouse_no = strwarehouse_no
             and t.container_no = GetLabelItem.container_no
             and t.row_id = GetLabelItem.row_id;

        if sql%notfound then
           strOutMsg:='N|[更新不到标签明细]';
           return;
        end if;

        delete from stock_label_d sd
         where sd.enterprise_no = strEnterPriseNo
           and sd.warehouse_no = strwarehouse_no
           and sd.container_no = strS_Container_No and sd.qty=0;

         if v_nRemainQty=0 then
            exit;
         end if;
     end loop;

    strOutMsg := 'Y|';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end proc_om_ArrangeByCheck_No;

  /*=====================================================================================
  snake insert to 20130418
  拆板----新增目的标签明细
  ======================================================================================*/
  PROCEDURE proc_OM_SplitInsertLabelDetail(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                           strwarehouse_no in STOCK_LABEL_M.warehouse_no%type, --仓别
                                           strArrange_No   in STOCK_LABEL_Move_log.arrange_no%type, --整理单据号
                                           strUser_Id      in STOCK_LABEL_M.rgst_name%type,
                                           strOutMsg       out varchar2) is

    n_arrange_count number(10); --获取整理数据明细行数，以做判断
    n_RowID         STOCK_LABEL_D.row_id%type; --新增的目的容器ID

  begin
    strOutMsg       := 'N|[proc_OM_SplitInsertLabelDetail]';
    n_arrange_count := 0;
    --STOCK_LABEL_Move_log表中的信息，除了d_container_no，其余的信息都来源于源标签明细信息
    for i_ArrangeInfo in (select clml.*,
                                 d_clm.container_type as d_Container_Type,
                                 d_clm.status         as d_status
                            from STOCK_LABEL_Move_log clml,
                                 STOCK_LABEL_M        d_clm
                           where d_clm.warehouse_no = clml.warehouse_no
                             and d_clm.enterprise_no = clml.enterprise_no
                             and d_clm.enterprise_no = strEnterPriseNo
                             and d_clm.container_no = clml.d_container_no
                             and clml.warehouse_no = strwarehouse_no
                             and clml.arrange_no = strArrange_No) loop

      n_arrange_count := n_arrange_count + 1;

      --获取目的标签最大的row_id
      select nvl(max(d_cld.row_id), 0) + 1
        into n_RowID
        from STOCK_LABEL_D d_cld
       where d_cld.warehouse_no = strwarehouse_no
         and d_cld.enterprise_no = strEnterPriseNo
         and d_cld.container_no = i_ArrangeInfo.d_Container_No;

      --新增目的标签明细数据
      insert into STOCK_LABEL_D
        (enterprise_no,
         warehouse_no,
         BATCH_NO,
         OWNER_NO,
         SOURCE_NO,
         CONTAINER_NO,
         CONTAINER_TYPE,
         ARTICLE_NO,
         ARTICLE_ID,
         PACKING_QTY,
         QTY,
         EXP_NO,
         WAVE_NO,
         CUST_NO,
         SUB_CUST_NO,
         LINE_NO,
         STATUS,
         DIVIDE_ID,
         ROW_ID,
         EXP_TYPE,
         DPS_CELL_NO,
         RGST_NAME,
         RGST_DATE,
         UPDT_NAME,
         UPDT_DATE,
         DELIVER_OBJ,
         EXP_DATE,
         ADVANCE_CELL_NO,
         ADVANCE_STATUS,
         deliverobj_order)
        select enterprise_no,
               warehouse_no,
               BATCH_NO,
               OWNER_NO,
               SOURCE_NO,
               i_ArrangeInfo.d_Container_No,
               i_ArrangeInfo.d_Container_Type,
               ARTICLE_NO,
               ARTICLE_ID,
               PACKING_QTY,
               i_ArrangeInfo.Move_Qty,
               EXP_NO,
               WAVE_NO,
               CUST_NO,
               SUB_CUST_NO,
               LINE_NO,
               i_ArrangeInfo.d_Status,
               DIVIDE_ID,
               n_RowID,
               EXP_TYPE,
               DPS_CELL_NO,
               strUser_Id,
               sysdate,
               strUser_Id,
               sysdate,
               DELIVER_OBJ,
               EXP_DATE,
               ADVANCE_CELL_NO,
               ADVANCE_STATUS,
               deliverobj_order
          from STOCK_LABEL_D s_cld
         where s_cld.warehouse_no = strwarehouse_no
           and s_cld.enterprise_no = strEnterPriseNo
           and s_cld.container_no = i_ArrangeInfo.s_Container_No
           and s_cld.article_no = i_ArrangeInfo.Article_No
           and s_cld.article_id = i_ArrangeInfo.Article_Id
           and s_cld.divide_id = i_ArrangeInfo.Divide_Id
           and s_cld.row_id = i_ArrangeInfo.Row_Id;
      if sql%rowcount <= 0 then
        strOutMsg := 'N|[E22701]';
        return;
      end if;

    end loop;

    if (n_arrange_count <= 0) then
      strOutMsg := 'N|[E22702]';
      return;
    end if;

    strOutMsg := 'Y|转移标签数据成功！';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end proc_OM_SplitInsertLabelDetail;
  -------------------------------------------------【出货end】-------------------------------------------------------

  /*****************************************************************************************
  修改人：lich
  日期：2013-05-16
  功能：更新上架回单子标签状态
  *****************************************************************************************/
  procedure p_Updt_InStock_Label(strEnterPriseNo in stock_label_d.enterprise_no%type, --企业编码,
                                 strWareHouseNo  in STOCK_LABEL_M.warehouse_no%type, --仓别
                                 strInstockNo    in idata_instock_m.instock_no%type, --上架单号
                                 strLabelNo      in STOCK_LABEL_M.Label_No%type, --标签号
                                 strUserId       in STOCK_LABEL_M.updt_name%type, --员工ID
                                 strOutMsg       out varchar2) is

    v_strContainerNo STOCK_LABEL_M.container_no%type; --容器号
  begin
    strOutMsg := 'Y|';
    --子标签追踪
    update stock_label_m slm
       set slm.status = 'F1'
     where slm.warehouse_no = strWareHouseNo
       and slm.enterprise_no = strEnterPriseNo
       and slm.status = '26'
       and slm.label_no = strLabelNo;

    if sql%rowcount > 0 then
      --子标签跟踪
      proc_InsertLabel_Log(strEnterPriseNo,
                           strWareHouseNo,
                           strLabelNo,
                           strUserId,
                           0,
                           'F1',
                           strOutMsg);
      if substr(strOutMsg, 1, 1) = 'N' then
        return;
      end if;

      select slm.container_no
        into v_strContainerNo
        from stock_label_m slm
       where slm.warehouse_no = strWareHouseNo
         and slm.enterprise_no = strEnterPriseNo
         and slm.label_no = strLabelNo
         and rownum < 2;

      --子标签转历史
      proc_RemoveLabel(strEnterPriseNo,
                       strWareHouseNo,
                       v_strContainerNo, --strLabelNo,
                       strOutMsg);

      if substr(strOutMsg, 1, 1) = 'N' then
        return;
      end if;
    end if;

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_Updt_InStock_Label;

  /*****************************************************************************************
  修改人：lich
  日期：2013-05-26
  功能：更新下架回单子标签状态
  *****************************************************************************************/
  procedure P_Updt_OutStock_Label(strEnterPriseNo in stock_label_d.enterprise_no%type, --企业编码
                                  strwarehouse_no in stock_label_d.warehouse_no%type, --仓别
                                  strOwnerNo      in stock_label_d.owner_no%type, --货主
                                  strSourceNo     in stock_label_d.source_no%type, --来源单号
                                  strLabelNo      in stock_label_m.label_no%type, --标签号
                                  strRealQty      in stock_label_d.qty%type, --实际回单量
                                  strDCellNo      in odata_outstock_d.d_cell_no%type, --目的储位
                                  strDivideId     in stock_label_d.divide_id%type, --序列号
                                  strUserID       in stock_label_d.rgst_name%type, --操作人员
                                  --strOutStockType     in odata_outstock_m.outstock_type%type,--下架类型
                                  strOutMsg out varchar2) --返回值
   is
    strMove varchar2(1); --是否移库 1  是 0 否

    strLabelDetail varchar2(1); --标签明细是否转历史
    nLabelDetail   number(10); -----当前标签未回单的明细记录
    nContainerNo   number(10); --数量
    strContainerNo varchar2(24); --内部容器号
    n_count        number(10);
    strStatus      stock_label_m.status%type;
    strUseType     stock_label_m.use_type%type;

  begin
    n_count    := 0;
    strOutMsg  := 'N|[P_Updt_OutStock_Label]';
    strMove    := '1';
    strStatus  := 'N';
    strUseType := 'N';

    nContainerNo := 0;

    select slm.container_no, slm.use_type
      into strContainerNo, strUseType
      from stock_label_m slm
     where slm.warehouse_no = strwarehouse_no
       and slm.enterprise_no = strEnterPriseNo
       and slm.label_no = strLabelNo
       and slm.source_no = strSourceNo;

    -----------------更新标签明细------------------
    select case strUseType
             when '3' then
              'F1'
             when '2' then
              '52'
             else
              '52'
           end
      into strStatus
      from stock_label_d sld
     where sld.warehouse_no = strwarehouse_no
       and sld.enterprise_no = strEnterPriseNo
       and sld.owner_no = strOwnerNo
       and (sld.Status = clabelstatus.MOVE_HAND_OUT --40移库发单
           or sld.Status = clabelstatus.OUTSTOCKING --41移库下架
           or sld.Status = clabelstatus.PICK_HAND_OUT --'50'拣货发单                        --
           )
       AND EXISTS (SELECT 'X'
              FROM stock_label_m slm
             WHERE slm.Container_No = sld.Container_No
               AND slm.SOURCE_NO = sld.SOURCE_NO
               AND slm.warehouse_no = sld.warehouse_no
               and slm.enterprise_no = sld.enterprise_no
               AND slm.LABEL_NO = strLabelNo)
       and sld.Divide_Id = strDivideId
       and sld.Source_No = strSourceNo;

    UPDATE stock_label_d sld
       SET sld.UPDT_DATE = SYSDATE,
           sld.Updt_Name = strUserID,
           sld.Status    = strStatus,
           sld.Qty       = strRealQty
     where sld.warehouse_no = strwarehouse_no
       and sld.enterprise_no = strEnterPriseNo
       and sld.owner_no = strOwnerNo
       and (sld.Status = clabelstatus.MOVE_HAND_OUT --40移库发单
           or sld.Status = clabelstatus.OUTSTOCKING --41移库下架
           or sld.Status = clabelstatus.PICK_HAND_OUT --'50'拣货发单
           )
       AND EXISTS (SELECT 'X'
              FROM stock_label_m slm
             WHERE slm.Container_No = sld.Container_No
               AND slm.SOURCE_NO = sld.SOURCE_NO
               AND slm.warehouse_no = sld.warehouse_no
               and slm.enterprise_no = sld.enterprise_no
               AND slm.LABEL_NO = strLabelNo)
       and sld.Divide_Id = strDivideId
       and sld.Source_No = strSourceNo;

    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E22113]';
      return;
    end if;

    -------------------------删除 标签明细为 0  的数据--------------------------
    DELETE stock_label_d
     WHERE warehouse_no = strwarehouse_no
       and enterprise_no = strEnterPriseNo
       AND CONTAINER_NO = strContainerNo
       and QTY = 0;

    ------------更新标签头-------------
    --如果整个标签没有0回，且都回单完成，更新标签头为回单状态
    select count(1)
      into n_count
      from stock_label_m slm
     where NOT EXISTS (SELECT 'X'
              FROM stock_label_d sld
             WHERE sld.Container_No = slm.Container_No
               AND sld.warehouse_no = slm.warehouse_no
               AND sld.Container_Type = slm.Container_Type
               AND (sld.STATUS = CLabelStatus.MOVE_HAND_OUT --移库发单
                   OR sld.STATUS = CLabelStatus.OUTSTOCKING --移库下架
                   OR sld.STATUS = clabelstatus.PICK_HAND_OUT) --拣货发单
            )
       AND EXISTS (SELECT 'X'
              FROM stock_label_d sld
             WHERE sld.Container_No = slm.Container_No
               AND sld.warehouse_no = slm.warehouse_no
               and sld.enterprise_no = slm.enterprise_no
               AND sld.Container_Type = slm.Container_Type
               AND sld.QTY > 0
               AND sld.STATUS <> 'FF')
       AND slm.warehouse_no = strwarehouse_no
       and slm.enterprise_no = strEnterPriseNo
       And slm.Label_No = strLabelNo;

    if n_count <> 0 then
      --移库标签回单完则为销毁状态，出货标签为下架回单状态
      UPDATE stock_label_m slm
         SET slm.UPDT_DATE     = SYSDATE,
             slm.updt_name     = strUserID,
             slm.Owner_Cell_No = strDCellNo,
             slm.STATUS = (CASE
                            WHEN slm.USE_TYPE = '3' then
                             'F1'
                            else
                             '52'
                          end)
       WHERE slm.warehouse_no = strwarehouse_no
         and slm.enterprise_no = strEnterPriseNo
         And slm.Label_No = strLabelNo;

      if sql%rowcount <= 0 then
        strOutMsg := 'N|[E22116]';
        return;
      end if;
    else

      --如果不存在初始状态的标签明细，且回单数都是0或者状态都是F，则改标签头为取消状态
      select count(1)
        into n_count
        from stock_label_m slm
       where NOT EXISTS
       (SELECT 'X'
                FROM stock_label_d sld
               WHERE sld.Container_No = slm.Container_No
                 AND sld.warehouse_no = slm.warehouse_no
                 and sld.enterprise_no = slm.enterprise_no
                 AND sld.SOURCE_NO = slm.SOURCE_NO
                 AND sld.Container_Type = slm.Container_Type
                 AND (sld.Status = clabelstatus.MOVE_HAND_OUT --40移库发单
                     or sld.Status = clabelstatus.OUTSTOCKING --41移库下架
                     or sld.Status = clabelstatus.PICK_HAND_OUT --'50'拣货发单
                     ))
         AND (not EXISTS (SELECT 'X'
                            FROM stock_label_d sld
                           WHERE sld.Container_No = slm.Container_No
                             AND sld.warehouse_no = slm.warehouse_no
                             and sld.enterprise_no = slm.enterprise_no
                             AND sld.SOURCE_NO = slm.SOURCE_NO
                             AND sld.Container_Type = slm.Container_Type
                             AND sld.QTY > 0) or NOT EXISTS
              (SELECT 'X'
                 FROM stock_label_d sld
                WHERE sld.Container_No = slm.Container_No
                  AND sld.warehouse_no = slm.warehouse_no
                  and sld.enterprise_no = slm.enterprise_no
                  AND sld.SOURCE_NO = slm.SOURCE_NO
                  AND sld.Container_Type = slm.Container_Type
                  AND sld.STATUS not like 'F%'))
         AND slm.warehouse_no = strwarehouse_no
         and slm.enterprise_no = strEnterPriseNo
         And slm.Label_No = strLabelNo;

      if n_count <> 0 then
        --标签明细都0回或者都销毁，则标签头档为销毁状态
        UPDATE stock_label_m slm
           SET slm.UPDT_DATE     = SYSDATE,
               slm.Owner_Cell_No = strDCellNo,
               slm.STATUS       =
               (CASE slm.USE_TYPE
                 WHEN '1' then
                  'FF'
                 when '2' then
                  'FF'
                 when '3' then
                  'F1'
               end)
         WHERE slm.warehouse_no = strwarehouse_no
           and slm.enterprise_no = strEnterPriseNo
           And slm.Label_No = strLabelNo;

        if sql%rowcount <= 0 then
          strOutMsg := 'N|[E22116]';
          return;
        end if;
      end if;

    end if;

    -------------当前标签明细未回单的记录数--------------
    select count(cld.Container_No)
      into nLabelDetail
      from stock_label_d cld, stock_label_m clm
     where cld.Container_No = clm.Container_No
       and cld.warehouse_no = clm.warehouse_no
       and cld.enterprise_no = clm.enterprise_no
       and cld.status < '52'
       and clm.warehouse_no = strwarehouse_no
       and clm.enterprise_no = strEnterPriseNo
       and clm.label_no = strLabelNo;

    if nLabelDetail <= 0 then
      --------写标签日志---------
      INSERT INTO stock_label_LOG
        (warehouse_no,
         LABEL_NO,
         Container_No,
         Container_TYPE,
         owner_Container_No,
         STATUS,
         RGST_NAME,
         RGST_DATE,
         OWNER_CELL_NO,
         CURR_AREA,
         Enterprise_No)
        SELECT warehouse_no,
               LABEL_NO,
               Container_No,
               Container_Type,
               owner_Container_No,
               STATUS,
               RGST_NAME,
               RGST_DATE,
               OWNER_CELL_NO,
               CURR_AREA,
               Enterprise_No
          FROM stock_label_M
         WHERE warehouse_no = strwarehouse_no
           and enterprise_no = strEnterPriseNo
           AND LABEL_NO = strLabelNo
           AND SOURCE_NO = strSourceNo
           AND STATUS NOT IN ('40', '50');

      if sql%rowcount <= 0 then
        strOutMsg := 'N|[E22115]';
        return;
      end if;
    end if;

    if strMove = '1' then
      ---------------查询标签明细----------------
      select count(cld.Container_No)
        into nContainerNo
        from stock_label_d cld
       inner join stock_label_m clm
          on cld.warehouse_no = clm.warehouse_no
         and cld.Container_No = clm.Container_No
       where cld.warehouse_no = strwarehouse_no
         and cld.enterprise_no = strEnterPriseNo
         and cld.Container_No = strContainerNo
         and cld.status not like 'F%';

      strLabelDetail := '0'; --默认
      if nContainerNo > 0 then
        strLabelDetail := '1';
      end if;
      if strLabelDetail = '0' then
        -------------标签转历史
        proc_RemoveLabel(strEnterPriseNo,
                         strwarehouse_no,
                         strContainerNo,
                         strOutMsg);
        if instr(strOutMsg, 'N', 1, 1) = 1 then
          return;
        end if;
      end if;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_Updt_OutStock_Label;

  /*****************************************************************************************
  修改人：lich
  日期：2013-05-26
  功能：流水标签状态取消回单
  *****************************************************************************************/
  procedure P_UpdtCancelOutStock_Label(strEnterPriseNo in stock_label_d.enterprise_no%type, --企业编码
                                       strwarehouse_no in stock_label_d.warehouse_no%type, --仓别
                                       strSourceNo     in stock_label_d.source_no%type, --来源单号
                                       strLabelNo      in stock_label_m.label_no%type, --标签号
                                       strRealQty      in stock_label_d.qty%type, --实际回单量
                                       strDivideId     in stock_label_d.divide_id%type, --序列号
                                       strUserID       in stock_label_d.rgst_name%type, --操作人员
                                       strOutMsg       out varchar2) --返回值
   is

    strLabelDetail varchar2(1); --标签明细是否转历史
    nLabelDetail   number(10); -----当前标签未回单的明细记录
    nContainerNo   number(10); --数量
    strContainerNo varchar2(24); --内部容器号
    n_count        number(10);
    strStatus      stock_label_m.status%type;
    v_iCount       integer;
  begin
    n_count   := 0;
    strOutMsg := 'N|[P_UpdtCancelOutStock_Label]';

    select slm.container_no
      into strContainerNo
      from stock_label_m slm
     where slm.warehouse_no = strwarehouse_no
       and slm.enterprise_no = strEnterPriseNo
       and slm.label_no = strLabelNo
       and slm.source_no = strSourceNo;

    --增加目的标签明细
    update stock_label_d sld
       set sld.updt_name = strUserId,
           sld.updt_date = sysdate,
           sld.status    = 'FC'
     where sld.warehouse_no = strwarehouse_no
       and sld.enterprise_no = strEnterPriseNo
       and sld.container_no = strContainerNo
       and sld.source_no = strSourceNo
       and sld.divide_id = strDivideId;

    -------------------------删除 标签明细为 0  的数据--------------------------
    DELETE stock_label_d
     WHERE warehouse_no = strwarehouse_no
       and enterprise_no = strEnterPriseNo
       AND CONTAINER_NO = strContainerNo
       and QTY = 0;

    ------------更新标签头-------------
    --如果整个标签没有0回，且都回单完成，更新标签头为回单状态
    select nvl(sum(sld.qty), 0)
      into n_count
      from stock_label_d sld
     where sld.warehouse_no = strwarehouse_no
       and sld.enterprise_no = strEnterPriseNo
       And sld.CONTAINER_NO = strContainerNo
       and sld.status = '50';

    if n_count = 0 then
      --移库标签回单完则为销毁状态，出货标签为下架回单状态
      UPDATE stock_label_m slm
         SET slm.UPDT_DATE = SYSDATE,
             slm.updt_name = strUserID,
             slm.STATUS    = 'FC'
       WHERE slm.warehouse_no = strwarehouse_no
         and slm.enterprise_no = strEnterPriseNo
         And slm.Label_No = strLabelNo;

      if sql%rowcount <= 0 then
        strOutMsg := 'N|[E22116]';
        return;
      end if;

      --------写标签日志---------
      INSERT INTO stock_label_LOG
        (warehouse_no,
         LABEL_NO,
         Container_No,
         Container_TYPE,
         owner_Container_No,
         STATUS,
         RGST_NAME,
         RGST_DATE,
         OWNER_CELL_NO,
         CURR_AREA,
         Enterprise_No)
        SELECT warehouse_no,
               LABEL_NO,
               Container_No,
               Container_Type,
               owner_Container_No,
               STATUS,
               RGST_NAME,
               RGST_DATE,
               OWNER_CELL_NO,
               CURR_AREA,
               Enterprise_No
          FROM stock_label_M
         WHERE warehouse_no = strwarehouse_no
           and enterprise_no = strEnterPriseNo
           AND LABEL_NO = strLabelNo
           AND SOURCE_NO = strSourceNo
           AND STATUS NOT IN ('40', '50');

      if sql%rowcount <= 0 then
        strOutMsg := 'N|[E22115]';
        return;
      end if;

      -------------标签转历史
      proc_RemoveLabel(strEnterPriseNo,
                       strwarehouse_no,
                       strContainerNo,
                       strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        return;
      end if;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_UpdtCancelOutStock_Label;

  /**************************************************************************************************8
  创建人：luozhiling
  创建时间：2014.11.3
  功能说明：扣减标签明细数据
  ***************************************************************************************************/
  Procedure P_UpdtLabelItme(strEnterPriseNo in stock_label_m.enterprise_no%type,
                            strWareHouseNo  in stock_label_m.warehouse_no%type, --仓别
                            strContainerNo  in stock_label_m.container_no%type, --容器号
                            strUSER_ID      in stock_label_m.updt_name%type,
                            nDivideId       in stock_label_d.divide_id%type,
                            strArticleNo    in stock_label_d.article_no%type,
                            nArticleId      in stock_label_d.article_id%type,
                            nQty            in stock_label_d.qty%type,
                            nRowId          in stock_label_d.row_id%type,
                            strOutMsg       out varchar2) is
  begin
    strOutMsg := 'N|[P_UpdtLabelItme]';

    update stock_label_d t
       set t.qty       = t.qty - nQty,
           t.updt_name = strUSER_ID,
           t.updt_date = sysdate
     where warehouse_no = strWareHouseNo
       and enterprise_no = strEnterPriseNo
       and t.container_no = strContainerNo
       and t.divide_id = nDivideId
       and t.article_no = strArticleNo
       and t.article_id = nArticleId
       and t.row_id = nRowId
       and t.qty >= nQty;
    delete from stock_label_d t
     where t.warehouse_no = strWareHouseNo
       and enterprise_no = strEnterPriseNo
       and t.article_no = strArticleNo
       and t.container_no = strContainerNo
       and t.article_id = nArticleId
       and t.divide_id = nDivideId
       and t.row_id = nRowId
       and t.qty = 0;

    strOutMsg := 'Y|[成功]';
  end P_UpdtLabelItme;

end pkobj_label;

/

