create package body        PKOBJ_ODATA_CHECK is

  /*************************************************************************************************
       功能：生产复核单头档
       chensr 2015.4.27

  *************************************************************************************************/
  procedure p_insert_Odata_check_m(strEnterpriseNo in odata_check_m.enterprise_no%type,
                                   strWareHouseNo  in odata_check_m.warehouse_no%type,
                                   strCheckNo      in odata_check_m.check_no%type,
                                   strOwnerNo      in odata_check_m.owner_no%type,
                                   strBatchNo      in odata_check_m.batch_no%type,
                                   strCustNo       in odata_check_m.cust_no%type,
                                   strStatus       in odata_check_m.status%type,
                                   strCheckChuteNo in odata_check_m.check_chute_no%type,
                                   strDliverObj    in odata_check_m.deliver_obj%type,
                                   strLineNo       in odata_check_m.line_no%type,
                                   strCurrArea     in odata_check_m.curr_area%type,
                                   strUseId        in odata_check_m.rgst_name%type,
                                   strResult       out varchar2) is
  begin

    strResult := 'Y|';

    insert into odata_check_m
      (enterprise_no,
       warehouse_no,
       owner_no,
       check_no,
       operate_date,
       batch_no,
       cust_no,
       status,
       check_chute_no,
       deliver_obj,
       line_no,
       curr_area,
       rgst_name,
       rgst_date)
    values
      (strEnterpriseNo,
       strWareHouseNo,
       strOwnerNo,
       strCheckNo,
       trunc(sysdate),
       strBatchNo,
       strCustNo,
       strStatus,
       strCheckChuteNo,
       strDliverObj,
       strLineNo,
       strCurrArea,
       strUseId,
       sysdate);
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end p_insert_Odata_check_m;
  /*************************************************************************************************
       功能：根据箱号生产复核单标签明细
       chensr 2015.6.25
  *************************************************************************************************/
  procedure p_insert_checkLabelD_by_label(strEnterpriseNo in odata_check_label_d.enterprise_no%type,
                                          strWareHouseNo  in odata_check_label_d.warehouse_no%type,
                                          strCheckNo      in odata_check_label_d.check_no%type,
                                          strContainerNo  in odata_check_label_d.container_no%type,
                                          strUserId       in odata_check_label_d.check_name%type,
                                          strResult       out varchar2) is
  begin
    strResult := 'Y|';

    insert into odata_check_label_d
      (enterprise_no,
       warehouse_no,
       owner_no,
       check_no,
       row_id,
       exp_no,
       exp_type,
       exp_date,
       lable_no,
       container_no,
       divide_id,
       article_no,
       packing_qty,
       article_id,
       article_qty,
       real_qty,
       status,
       d_label_no,
       check_name,
       check_date,
       deliver_obj)
      select strEnterpriseNo,
             strWareHouseNo,
             sld.owner_no,
             strCheckNo,
             sld.row_id,
             sld.exp_no,
             sld.exp_type,
             sld.exp_date,
             slm.label_no,
             slm.container_no,
             sld.divide_id,
             sld.article_no,
             sld.packing_qty,
             sld.article_id,
             sld.qty,
             0,
             '10',
             slm.label_no,
             strUserId,
             sysdate,
             sld.deliver_obj
        from stock_label_d sld, stock_label_m slm
       where slm.enterprise_no = sld.enterprise_no
         and slm.warehouse_no = sld.warehouse_no
         and slm.container_no = sld.container_no
         and slm.enterprise_no = strEnterpriseNo
         and slm.warehouse_no = strWareHouseNo
         and slm.container_no = strContainerNo;

  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_insert_checkLabelD_by_label;

  /* \*************************************************************************************************
       功能：生产复核单明细
       chensr 2015.4.27
  *************************************************************************************************\
  procedure p_insert_Odata_check_d(strEnterpriseNo   in odata_check_d.enterprise_no%type,
                                   strWareHouseNo    in odata_check_d.warehouse_no%type,
                                   strCheckNo        in odata_check_d.check_no%type,
                                   strWaveNo         in stock_label_d.wave_no%type,
                                   strDeliverObj     in stock_label_d.deliver_obj%type,
                                   strUserId         in odata_check_d.check_name%type,
                                   strResult        out varchar2
                                  ) is
  begin
    strResult :='Y|';

    insert into odata_check_d(enterprise_no, warehouse_no,owner_no,check_no,
          exp_no, exp_type,exp_date,article_no,packing_qty,plan_qty,article_qty,real_qty,status,
          rgst_name,rgst_date,deliver_obj)
        select a.enterprise_no,a.warehouse_no,a.owner_no,strCheckNo,
        a.exp_no,a.exp_type,a.exp_date,a.article_no,
        case when b.packing_qty is null then a.packing_qty  else b.packing_qty end packing_qty,
        a.plan_qty,nvl(b.qty,0),nvl(c.real_qty,0),'10',
        strUserId,sysdate from
        (select oem.exp_type,oem.exp_date,oem.enterprise_no,oem.warehouse_no,oem.owner_no,oem.exp_no,
        oed.article_no,oed.packing_qty,sum(oed.article_qty) plan_qty
        from odata_exp_d oed,odata_exp_m oem
        where oem.enterprise_no=oed.enterprise_no and oem.warehouse_no=oed.warehouse_no
        and oem.exp_no=oed.exp_no and oem.exp_no=strDeliverObj and oem.enterprise_no=strEnterpriseNo
        and oem.warehouse_no=strWareHouseNo
        group by oem.exp_type,oem.exp_date,oem.enterprise_no,oem.warehouse_no,oem.owner_no,oem.exp_no,
        oed.article_no,oed.packing_qty)a,
        (select sld.exp_no,sld.article_no,sld.packing_qty,sum(sld.qty) qty
        from stock_label_d sld where sld.enterprise_no=strEnterpriseNo and sld.warehouse_no=strWareHouseNo
        and sld.deliver_obj=strDeliverObj group by sld.exp_no,sld.article_no,sld.packing_qty)b,
        (select sld.exp_no,sld.article_no,sld.packing_qty,sum(sld.qty) real_qty
        from stock_label_d sld where sld.enterprise_no=strEnterpriseNo and sld.warehouse_no=strWareHouseNo
        and sld.wave_no<>strWaveNo
        and sld.deliver_obj=strDeliverObj group by sld.exp_no,sld.article_no,sld.packing_qty)c
        where a.article_no=b.article_no(+)\* and a.packing_qty=b.packing_qty(+)*\ and a.exp_no=b.exp_no(+)
        and a.article_no=c.article_no(+) \*and a.packing_qty=c.packing_qty(+)*\ and a.exp_no=c.exp_no(+)
        and a.enterprise_no=strEnterpriseNo and a.warehouse_no=strWareHouseNo;

     exception
        when others then
          strResult := 'N|' || SQLERRM ||
                       substr(dbms_utility.format_error_backtrace, 1, 256);
          return;
  end p_insert_Odata_check_d;*/
  /*************************************************************************************************
       功能：根据箱号生产复核单明细
       chensr 2015.4.27
  *************************************************************************************************/
  procedure p_insert_Odata_checkD_by_label(strEnterpriseNo in odata_check_d.enterprise_no%type,
                                           strWareHouseNo  in odata_check_d.warehouse_no%type,
                                           strCheckNo      in odata_check_d.check_no%type,
                                           strContainerNo  in stock_label_m.container_no%type,
                                           strUserId       in odata_check_d.check_name%type,
                                           strResult       out varchar2) is
  begin
    strResult := 'Y|';

    insert into odata_check_d
      (enterprise_no,
       warehouse_no,
       owner_no,
       check_no,
       exp_no,
       exp_type,
       exp_date,
       article_no,
       packing_qty,
       plan_qty,
       article_qty,
       real_qty,
       status,
       rgst_name,
       rgst_date,
       deliver_obj)
      select a.enterprise_no,
             a.warehouse_no,
             a.owner_no,
             strCheckNo,
             a.exp_no,
             a.exp_type,
             a.exp_date,
             a.article_no,
             a.packing_qty,
             sum(a.qty),
             sum(a.qty),
             0,
             '10',
             strUserId,
             sysdate,
             a.deliver_obj
        from stock_label_d a
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWareHouseNo
         and a.container_no = strContainerNo
       group by a.enterprise_no,
                a.warehouse_no,
                a.owner_no,
                a.exp_no,
                a.article_no,
                a.packing_qty,
                a.exp_type,
                a.exp_date,
                a.deliver_obj;

  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_insert_Odata_checkD_by_label;
  /*************************************************************************************************
       功能：更新复核单头档
       chensr 2015.4.30
  *************************************************************************************************/
  procedure P_UpdateOdataCheckM(strEnterpriseNo in odata_check_m.enterprise_no%type,
                                strWareHouseNo  in odata_check_m.warehouse_no%type,
                                strCheckNo      in odata_check_m.check_no%type,
                                strUserId       in odata_check_m.updt_name%type,
                                strResult       out varchar2) is
    v_iCount integer;
  begin
    strResult := 'Y|';

    --
    select count(*)
      into v_iCount
      from odata_check_label_d ocd
     where ocd.enterprise_no = strEnterpriseNo
       and ocd.warehouse_no = strWareHouseNo
       and ocd.check_no = strCheckNo
       and ocd.status < '13';

    if v_iCount = 0 then

      --更新复核明细
      update odata_check_d t
         set t.status     = '13',
             t.check_name = strUserId,
             t.check_date = sysdate
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.check_no = strCheckNo;

      update odata_check_m t
         set t.status    = '13',
             t.updt_name = strUserId,
             t.updt_date = sysdate
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.check_no = strCheckNo;
    end if;

  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_UpdateOdataCheckM;

  /*************************************************************************************************
  功能说明：更新复核单明细

  **************************************************************************************************/
  procedure P_UpdtaOdataCheckD(strEnterpriseNo in odata_check_d.enterprise_no%type,
                               strWareHouseNo  in odata_check_m.warehouse_no%type,
                               strCheckNo      in odata_check_m.check_no%type,
                               strExp_No       in odata_check_d.exp_no%type,
                               strArticleNo    in odata_check_d.article_no%type,
                               nPackingQty     in odata_check_d.packing_qty%type,
                               nRealQty        in odata_check_label_d.real_qty%type,
                               strUserId       in odata_check_m.updt_name%type,
                               strResult       out varchar2) is
    --v_iCount integer;
  begin
    strResult := 'N|[P_UpdtaOdataCheckD]';

    --先更新复核明细的数量
    if nRealQty >= 0 then
      update odata_check_d t
         set t.real_qty   = t.real_qty + nRealQty,
             t.check_name = strUserId,
             t.check_date = sysdate
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.check_no = strCheckNo
         and t.article_no = strArticleNo
         and t.packing_qty = nPackingQty
         and t.article_qty >= t.real_qty + nRealQty
         and t.exp_no = strExp_No
         and t.status < '13';

      if sql%notfound then
        strResult := 'N|[EEEE]'; --找不到对应的复核明细
      end if;

      update odata_check_d t
         set t.status = '13'
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.check_no = strCheckNo
         and t.article_qty <= t.real_qty
         and t.exp_no = strExp_No
         and t.status < '13';
    else
      update odata_check_d t
         set t.real_qty   = t.real_qty + nRealQty,
             t.check_name = strUserId,
             t.status     = '11',
             t.check_date = sysdate
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.check_no = strCheckNo
         and t.article_no = strArticleNo
         and t.packing_qty = nPackingQty
         and t.exp_no = strExp_No
         and t.real_qty >= abs(nRealQty);
      if sql%notfound then
        strResult := 'N|[EEEE]'; --找不到对应的复核明细
      end if;
    end if;

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_UpdtaOdataCheckD;
  /*************************************************************************************************
       功能：复核标签表回单，将目的容器号回写复核标签明细表，若复核数量<标签明细的数量，需要进行拆记录。
       luozhiling
       2015.11.4
  *************************************************************************************************/
  procedure P_SaveOdataCheckLabelD(strEnterpriseNo in odata_check_d.enterprise_no%type,
                                   strWareHouseNo  in odata_check_m.warehouse_no%type,
                                   strCheckNo      in odata_check_m.check_no%type,
                                   strContainerNo  in odata_check_label_d.container_no%type, -- 来源标签内部容器号
                                   strDLableNo     in odata_check_label_d.lable_no%type, --目的标签号
                                   nRowId          in odata_check_label_d.row_id%type,
                                   nRealQty        in odata_check_label_d.real_qty%type,
                                   strUserId       in odata_check_m.updt_name%type,
                                   strResult       out varchar2) is
    --v_iCount       integer;
    v_nRowId integer;
    --v_strArticleNo stock_article_info.article_no%type;
    --v_strArticleId stock_article_info.article_id%type;
  begin
    strResult := 'N|[P_SaveOdataCheckLabelD]';

    --获取最大的ROW_ID
    select nvl(max(row_id), 0)
      into v_nRowId
      from odata_check_label_d t
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWareHouseNo
       and t.check_no = strCheckNo;

    --新增标签明细
    insert into odata_check_label_d
      (enterprise_no,
       warehouse_no,
       owner_no,
       check_no,
       row_id,
       exp_no,
       exp_type,
       exp_date,
       lable_no,
       container_no,
       divide_id,
       article_no,
       packing_qty,
       article_id,
       article_qty,
       real_qty,
       status,
       d_label_no,
       DELIVER_OBJ,
       check_name,
       check_date)
      select t.enterprise_no,
             t.warehouse_no,
             t.owner_no,
             t.check_no,
             v_nRowId + 1,
             t.exp_no,
             t.exp_type,
             t.exp_date,
             t.lable_no,
             t.container_no,
             t.divide_id,
             t.article_no,
             t.packing_qty,
             t.article_id,
             nRealQty,
             0,
             '10',
             'N',
             t.deliver_obj,--ADD BY QZH AT 2016-7-14
             strUserId,
             sysdate
        from odata_check_label_d t
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.check_no = strCheckNo
         and t.container_no = strContainerNo
         and t.row_id = nRowId;

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_SaveOdataCheckLabelD;

  /*************************************************************************************************
       功能：复核标签明细回单
       chensr 2015.4.30
  *************************************************************************************************/
  procedure P_UpdateOdataCheckLabelD(strEnterpriseNo in odata_check_d.enterprise_no%type,
                                     strWareHouseNo  in odata_check_m.warehouse_no%type,
                                     strCheckNo      in odata_check_m.check_no%type,
                                     strContainerNo  in odata_check_label_d.lable_no%type,
                                     strDLableNo     in odata_check_label_d.lable_no%type, --目的标签号
                                     nRowId          in odata_check_label_d.row_id%type,
                                     nRealQty        in odata_check_label_d.real_qty%type,
                                     strUserId       in odata_check_m.updt_name%type,
                                     strResult       out varchar2) is
    --v_iCount integer;
  begin
    strResult := 'N|[P_UpdateOdataCheckD]';

    if nRealQty > 0 then

      --更新复核明细的数量
      update odata_check_label_d t
         set t.d_label_no = strDLableNo,
             t.real_qty   = t.real_qty + nRealQty,
             t.check_name = strUserId,
             t.check_date = sysdate
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.check_no = strCheckNo
         and t.container_no = strContainerNo
         and t.row_id = nRowId
         and t.status < '13'
         and t.article_qty - t.real_qty >= nRealQty;

      if sql%rowcount <= 0 then
        strResult := 'N|[EEEE]'; --找不到对应的复核明细
        return;
      end if;

      update odata_check_label_d t
         set t.status = /*case
                          when real_qty >= article_qty then
                           '13'
                          else*/
                           '11'
/*                        end*/
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.check_no = strCheckNo
         and t.container_no = strContainerNo
         and t.row_id = nRowId;

    else
      --更新复核明细的数量
      update odata_check_label_d t
         set t.real_qty   = t.real_qty + nRealQty,
             t.check_name = strUserId,
             t.check_date = sysdate,
             t.status     = '11'
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.check_no = strCheckNo
         and t.container_no = strContainerNo
         and t.row_id = nRowId
            --and t.status < '13'
         and t.real_qty >= abs(nRealQty);

      if sql%rowcount <= 0 then
        strResult := 'N|[EEEE]'; --找不到对应的复核明细
        return;
      end if;
    end if;

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_UpdateOdataCheckLabelD;

  /*************************************************************************************************
       功能：生产复核单转历史表
       chensr 2015.4.30
  *************************************************************************************************/
  procedure p_insert_Odata_check_log(strEnterpriseNo in odata_check_d.enterprise_no%type,
                                     strWareHouseNo  in odata_check_d.warehouse_no%type,
                                     strCheckNo      in odata_check_d.check_no%type,
                                     strResult       out varchar2) is
  begin
    strResult := 'Y|';

    insert into odata_check_mhty
      (Enterprise_No,
       Warehouse_No,
       owner_no,
       Check_No,
       operate_date,
       batch_no,
       cust_no,
       status,
       check_chute_no,
       deliver_obj,
       line_no,
       curr_area,
       rgst_name,
       rgst_date,
       updt_name,
       updt_date)
      select Enterprise_No,
             Warehouse_No,
             owner_no,
             Check_No,
             operate_date,
             batch_no,
             cust_no,
             status,
             check_chute_no,
             deliver_obj,
             line_no,
             curr_area,
             rgst_name,
             rgst_date,
             updt_name,
             updt_date
        from odata_check_m
       where enterprise_no = strEnterpriseNo
         and warehouse_no = strWareHouseNo
         and check_no = strCheckNo
         and status = '13';
    if sql%rowcount > 0 then
      delete from odata_check_m a
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWareHouseNo
         and a.check_no = strCheckNo;

      --转复核标签明细为历史
      insert into odata_check_label_dhty
        (enterprise_no,
         warehouse_no,
         owner_no,
         check_no,
         row_id,
         lable_no,
         divide_id,
         container_no,
         exp_no,
         exp_type,
         exp_date,
         article_no,
         packing_qty,
         article_id,
         article_qty,
         real_qty,
         status,
         d_label_no,
         check_name,
         check_date,
         deliver_obj)
        select a.enterprise_no,
               a.warehouse_no,
               a.owner_no,
               a.check_no,
               a.row_id,
               a.lable_no,
               a.divide_id,
               a.container_no,
               a.exp_no,
               a.exp_type,
               a.exp_date,
               a.article_no,
               a.packing_qty,
               a.article_id,
               a.article_qty,
               a.real_qty,
               a.status,
               a.d_label_no,
               a.check_name,
               a.check_date,
               a.deliver_obj
          from odata_check_label_d a
         where a.enterprise_no = strEnterpriseNo
           and a.warehouse_no = strWareHouseNo
           and a.check_no = strCheckNo;
      if sql%rowcount <= 0 then
        return;
      end if;

      delete from odata_check_label_d a
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWareHouseNo
         and a.check_no = strCheckNo;
      if sql%rowcount <= 0 then
        return;
      end if;

      --转复核明细
      insert into odata_check_dhty
        (enterprise_no,
         warehouse_no,
         owner_no,
         check_no,
         exp_no,
         exp_type,
         exp_date,
         article_no,
         packing_qty,
         plan_qty,
         article_qty,
         real_qty,
         status,
         rgst_name,
         rgst_date,
         check_name,
         check_date,
         deliver_obj)
        select t.enterprise_no,
               t.warehouse_no,
               t.owner_no,
               t.check_no,
               t.exp_no,
               t.exp_type,
               t.exp_date,
               t.article_no,
               t.packing_qty,
               t.plan_qty,
               t.article_qty,
               t.real_qty,
               t.status,
               t.rgst_name,
               t.rgst_date,
               t.check_name,
               t.check_date,
               t.deliver_obj
          from odata_check_d t
         where t.enterprise_no = strEnterpriseNo
           and t.warehouse_no = strWareHouseNo
           and t.check_no = strCheckNo;

      if sql%rowcount <= 0 then
        return;
      end if;

      delete from odata_check_d a
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWareHouseNo
         and a.check_no = strCheckNo;
      if sql%rowcount <= 0 then
        return;
      end if;
    end if;

  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_insert_Odata_check_log;

end PKOBJ_ODATA_CHECK;

/

