create package body        PKOBJ_MDATA is

/**********************************************************************************************************
   luozhiling
   2013.11.16
   功能：新增移库计划单单头
***********************************************************************************************************/
    procedure P_mdata_PlanHead(strEnterPriseNo           in    mdata_plan_m.enterprise_no%type,
                               strWareHouseNo            in    mdata_plan_m.warehouse_no%type,--仓库编码
                               strOwnerNo                in    mdata_plan_m.owner_no%type,
                               strUserId                 in    mdata_plan_m.rgst_name%type,
                               strSouceType              in    mdata_plan_m.source_type%type,--移库类型；1:商品移库；2：标签移库
                               strOutstockType           in    mdata_plan_m.outstock_type%type,--下架类型：3：安全量补货；4:人工移库
                               strPlanNo                 out   mdata_plan_m.plan_no%type,--移库计划头档
                               strResult                 OUT    varchar2)is
    begin
      strResult := 'N|[P_mdata_PlanHead]';


      --获取建议单号
      PKLG_WMS_BASE.p_getsheetno(strEnterPriseNo,strWareHouseNo,CONST_DOCUMENTTYPE.MDATAHC,strPlanNo,strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --新增移库计划单头档
      insert into mdata_plan_m(enterprise_no,warehouse_no,owner_no,plan_no,source_type,outstock_type,
             status,move_date,rgst_name,rgst_date)
         values(strEnterPriseNo,strWareHouseNo,strOwnerNo,strPlanNo,strSouceType,strOutstockType,'10',
             trunc(sysdate),strUserId,sysdate);

      strResult:='Y|';

    end P_mdata_PlanHead;

 /*****************************************************************************************************
   创建人：luozhiling
   时间：2013.11.16
   功能: 移库手建单明细
 ****************************************************************************************************/
    procedure P_mdata_PlanItem(strEnterPriseNo           in    mdata_plan_m.enterprise_no%type,
                               strWareHouseNo            in    mdata_plan_m.warehouse_no%type,--仓库编码
                               strOwnerNo                in    mdata_plan_m.owner_no%type,
                               strPlanNo                 in    mdata_plan_m.plan_no%type,--移库计划头档
                               strArticleNo              in    mdata_plan_d.article_no%type,--商品编码
                               dtProduceDate             in    stock_article_info.produce_date%type,--生产日期
                               dtExPireDate              in    stock_article_info.expire_date%type,--到期日
                               nPackingQty               in    mdata_plan_d.packing_qty%type,
                               strQUALITY                in    stock_article_info.quality%type,
                               strLotNo                  in    stock_article_info.lot_no%type, --批次号
                               strRSV_BATCH1             in    stock_article_info.rsv_batch1%type, --预留批属性1
                               strRSV_BATCH2             in    stock_article_info.rsv_batch2%type, --预留批属性2
                               strRSV_BATCH3             in    stock_article_info.rsv_batch3%type, --预留批属性3
                               strRSV_BATCH4             in    stock_article_info.rsv_batch4%type, --预留批属性4
                               strRSV_BATCH5             in    stock_article_info.rsv_batch5%type, --预留批属性5
                               strRSV_BATCH6             in    stock_article_info.rsv_batch6%type, --预留批属性6
                               strRSV_BATCH7             in    stock_article_info.rsv_batch7%type, --预留批属性7
                               strRSV_BATCH8             in    stock_article_info.rsv_batch8%type, --预留批属性8
                               nPlanQty                  in    mdata_plan_d.origin_qty%type,--计划移库量
                               strStockType              in    mdata_plan_d.stock_type%type,
                               strStockVAlue             in    mdata_plan_d.stock_value%type,
                               strsCellNo                in    mdata_plan_d.s_cell_no%type,--来源储位
                               strLabelNo                in    mdata_plan_d.s_label_no%type, --来源标签号
                               strSubLabelNo             in    mdata_plan_d.s_sub_label_no%type, --来源子标签号
                               strDestCellNo             in    mdata_plan_d.d_cell_no%type,--目的储位
                               strResult                 OUT    varchar2)is
         Cursor v_GetStockItem is
         select sc.* from stock_content sc,stock_article_info sai
         where sc.warehouse_no=strWareHouseNo and sc.enterprise_no=sai.enterprise_no
         and sc.enterprise_no=strEnterPriseNo and sc.article_no=sai.article_no
         and sc.article_id=sai.article_id and sc.article_no=strArticleNo
         and sc.packing_qty=nPackingQty
         and sai.produce_date=dtProduceDate and sai.expire_date=dtExPireDate
         and sai.lot_no=strLotNo and sai.quality=strQUALITY
         and sai.rsv_batch1=strRSV_BATCH1 and sai.rsv_batch2=strRSV_BATCH2
         and sai.rsv_batch3=strRSV_BATCH3 and sai.rsv_batch4=strRSV_BATCH4
         and sai.rsv_batch5=strRSV_BATCH5 and sai.rsv_batch6=strRSV_BATCH6
         and sai.rsv_batch7=strRSV_BATCH7 and sai.rsv_batch8=strRSV_BATCH8
         and sc.stock_type=strStockType
         and sc.stock_value=strStockVAlue and sc.qty-sc.outstock_qty>0
         and sc.cell_no=strsCellNo;

         RemainQty       mdata_plan_d.origin_qty%type;--剩余计划移库量
         ncurQty          mdata_plan_d.origin_qty%type;--当前移库数量
         v_iCount         integer;
         nRowId           integer;
         v_strOutstockType        mdata_plan_m.outstock_type%type;
    begin
      strResult := 'N|[P_mdata_PlanItem]';
      v_iCount:=0;
      RemainQty:=nPlanQty;
      ncurQty:=0;

      --获取移库类型
      begin
          select outstock_type into v_strOutstockType from mdata_plan_m where warehouse_no=strWareHouseNo
          and enterprise_no=strEnterPriseNo and plan_no=strPlanNo;
      exception when no_data_found then
         strResult := 'N|[E26001]';
         return;
      end;

      if v_strOutstockType=4 then --人工移库
          for GetStockItem in v_GetStockItem loop
             v_iCount:=v_iCount+1;

             if RemainQty>=GetStockItem.qty-GetStockItem.outstock_qty then
                ncurQty:=GetStockItem.qty-GetStockItem.outstock_qty;
             else
                ncurQty:=RemainQty;
             end if;
             RemainQty:=RemainQty-ncurQty;

             select nvl(count(*),0) into nRowId from mdata_plan_d where warehouse_no=strWareHouseNo AND owner_no=strOwnerNo
              and enterprise_no=strEnterPriseNo and plan_no=strPlanNo;

             insert into mdata_plan_d(enterprise_no,warehouse_no,owner_no,plan_no,row_id,article_no,article_id,
                   origin_qty,s_cell_no,s_label_no,s_sub_label_no,d_cell_no,move_date,
                   stock_type,stock_value,packing_qty)
                values(strEnterPriseNo,strWareHouseNo,strOwnerNo,strPlanNo,nRowId+1,GetStockItem.article_no,GetStockItem.article_id,
                  ncurQty,GetStockItem.cell_no,strLabelNo,strSubLabelNo,strDestCellNo,
                  trunc(sysdate),strStockType,strStockVAlue,nPackingQty);


             if RemainQty=0 then
                exit;
             end if;
          end loop;
          if v_iCount=0 then
             strResult:='N|[E26002]';
             return;
          end if;
      end if;


      if v_strOutstockType='3' then --安全量补货
         select nvl(count(*),0) into nRowId from mdata_plan_d where warehouse_no=strWareHouseNo AND owner_no=strOwnerNo
          and enterprise_no=strEnterPriseNo and plan_no=strPlanNo;
         insert into mdata_plan_d(enterprise_no,warehouse_no,owner_no,plan_no,row_id,article_no,article_id,
                   origin_qty,s_cell_no,s_label_no,s_sub_label_no,d_cell_no,move_date,
                   stock_type,stock_value,packing_qty)
            values(strEnterPriseNo,strWareHouseNo,strOwnerNo,strPlanNo,nRowId+1,strArticleNO,-1,
              nPlanQty,strsCellNo,strLabelNo,strSubLabelNo,strDestCellNo,
              trunc(sysdate),strStockType,strStockVAlue,nPackingQty);
      end if;
      strResult:='Y|';

    end P_mdata_PlanItem;


 /*****************************************************************************************************
   创建人：luozhiling
   时间：2013.11.16
   功能: 移库写定位指示
 ****************************************************************************************************/
    procedure P_mdata_locateDiect(strEnterPriseNo           in    mdata_plan_m.enterprise_no%type,
                                  strWareHouseNo            in    mdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo                in    mdata_plan_m.owner_no%type,
                                  strPlanNo                 in   mdata_plan_m.plan_no%type,--移库计划头档
                                  strUserId                 in   mdata_plan_m.rgst_name%type,
                                  strResult                 OUT    varchar2)is

    begin
      strResult := 'N|[P_mdata_locateDiect]';

      --写移库定位指示
      insert into mdata_locate_direct(enterprise_no,warehouse_no,owner_no,plan_no,outstock_type,status,article_no,
             article_id,origin_qty,s_label_no,s_cell_no,s_sub_label_no,d_cell_no,source_type,
             move_date,stock_type,stock_value,ROW_ID,packing_qty)
          select strEnterPriseNo,strWareHouseNo,strOwnerNo,strPlanNo,mpm.outstock_type,'10',mpd.article_no,
          mpd.article_id,mpd.origin_qty,mpd.s_label_no,mpd.s_cell_no,mpd.s_sub_label_no,mpd.d_cell_no,
          mpm.source_type,mpd.move_date,mpd.stock_type,mpd.stock_value,mpd.row_id,mpd.packing_qty
          from mdata_plan_m mpm,mdata_plan_d mpd
          where mpm.enterprise_no=mpd.enterprise_no and mpm.enterprise_no=strEnterPriseNo
          and mpm.warehouse_no=mpd.warehouse_no and mpm.plan_no=mpd.plan_no
          and mpm.warehouse_no=strWareHouseNo and mpm.status='10'
          and mpm.plan_no=strPlanNo;

      update mdata_plan_m set status='13' ,updt_name=strUserId,updt_date=sysdate
             where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo and plan_no=strPlanNo;

      --移库计划单转历史 huangb 20160518
      P_mdata_PlanInsertHTY(strEnterPriseNo,strWareHouseNo,strOwnerNo,strPlanNo,strUserId,strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;

      strResult:='Y|';

    end P_mdata_locateDiect;

 /*****************************************************************************************************
   创建人：luozhiling
   时间：2013.11.16
   功能: 人工移库定位指示找库存
 ****************************************************************************************************/
    procedure P_mdata_foundStock(strEnterPriseNo           in    mdata_plan_m.enterprise_no%type,
                                 strWareHouseNo            in    mdata_plan_m.warehouse_no%type,--仓库编码
                                 strPlanNo                 in   mdata_plan_m.plan_no%type,--移库计划头档
                                 strUserId                 in   mdata_plan_m.rgst_name%type,
                                 strResult                 OUT    varchar2)is
        cursor v_GetLocateItem is
        select * from mdata_locate_direct mld
        where mld.enterprise_no=strEnterPriseNo and mld.warehouse_no=strWareHouseNo and mld.plan_no=strPlanNo;
        v_iCount integer;
        icount   integer;
        nCurQty  stock_content.qty%type;--当前移库数量
        nRemainQty  stock_content.qty%type;--剩余移库数量
        nTotalQty   stock_content.qty%type;--总移库数量
        destCellID  stock_content.cell_id%type;
    begin
      strResult := 'N|[P_mdata_foundStock]';
      v_iCount:=0;
      icount:=0;
      for GetLocateItem in v_GetLocateItem loop
          v_iCount:=1;
          nTotalQty:=GetLocateItem.origin_qty;
          nRemainQty:=GetLocateItem.origin_qty;
          nCurQty:=0;
          --锁定此商品的库存
          update stock_content set status=status
            where enterprise_no=strEnterPriseNo and article_no=GetLocateItem.article_no and cell_no=GetLocateItem.s_cell_no;
          --循环库存
          for GetStock in(select t.* from stock_content t where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo
              and t.owner_no=GetLocateItem.owner_no and t.cell_no=GetLocateItem.s_cell_no
              and t.label_no=GetLocateItem.s_label_no
              and t.sub_label_no=GetLocateItem.s_sub_label_no
              and t.article_no=GetLocateItem.article_no and t.article_id=GetLocateItem.article_id
              and t.packing_qty=GetLocateItem.packing_qty
              and t.qty-t.outstock_qty>0) loop

              icount:=1;

              if nRemainQty>=GetStock.qty-GetStock.outstock_qty then
                 nCurQty:=GetStock.qty-GetStock.outstock_qty;
              else
                 nCurQty:=nRemainQty;
              end if;

              nRemainQty:=nRemainQty-nCurQty;

              --写库存
              pkobj_stock.p_UpdtContent_Reservation(strEnterPriseNo,strWareHouseNo,GetStock.cell_no,GetStock.cell_id,
                  GetLocateItem.d_cell_no,GetLocateItem.s_label_no,GetLocateItem.s_sub_label_no,nCurQty,
                  '0',strUserId,destCellID,strResult);

              -- 写下架指示
              insert into odata_outstock_direct(enterprise_no,warehouse_no,owner_no,outstock_type,operate_type,operate_date,
                     pick_type,wave_no,exp_no,article_no,article_id,packing_qty,
                     s_cell_no,s_cell_id,s_container_no,
                     d_cell_no,d_cell_id,locate_qty,
                     status,exp_date,stock_type,label_no,source_type,rgst_name,rgst_date)
                  values(strEnterPriseNo,strWareHouseNo,GetStock.owner_no,GetLocateItem.outstock_type,'C',trunc(sysdate),
                     '0',GetLocateItem.plan_no,GetLocateItem.plan_no,GetStock.article_no,GetStock.article_id,GetStock.packing_qty,
                     GetStock.cell_no,GetStock.cell_id,'N',
                     GetLocateItem.d_cell_no,destCellID,nCurQty,
                     '10',GetLocateItem.move_date,GetStock.stock_type,GetStock.label_no,GetLocateItem.source_type,strUserId,sysdate);
              if nRemainQty=0 then
                 exit;
              end if;
          end loop;

          if icount=0 then
             strResult:='N|[E26002]';
             return;
          end if;
      end loop;

      update mdata_locate_direct t set t.status='13'
        where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo and t.plan_no=strPlanNo;

      if v_iCount=0 then
         strResult:='N|[E26003]';
         return;
      end if;

      strResult:='Y|';

    end P_mdata_foundStock;
/***********************************************************************************************************
   创建人：lich
   时间：2014.07.16
   功能：Rf移库下架 更新状态
  ***********************************************************************************************************/
  procedure P_mdata_RfOut(strEnterPriseNo   in odata_outstock_m.enterprise_no%type,
                          strWareHouseNo    in odata_outstock_m.warehouse_no%type, --仓库编码
                          strOutstock_No    in odata_outstock_m.outstock_no%type,--下架单号
                          strArticleNo      in odata_outstock_d.article_no%type, --商品编码
                          nPacking_QTY      in odata_outstock_d.packing_qty%type,--包装数量
                          strQuality        in idata_check_d.quality%type,--品质
                          dtProduceDate     in stock_article_info.produce_date%type,--生产日期
                          dtExpireDate      in stock_article_info.expire_date%type,--到期日期
                          strLotNo          in stock_article_info.lot_no%type,--批次号
                          strRSV_BATCH1     in stock_article_info.rsv_batch1%type, --预留批属性1
                          strRSV_BATCH2     in stock_article_info.rsv_batch2%type, --预留批属性2
                          strRSV_BATCH3     in stock_article_info.rsv_batch3%type, --预留批属性3
                          strRSV_BATCH4     in stock_article_info.rsv_batch4%type, --预留批属性4
                          strRSV_BATCH5     in stock_article_info.rsv_batch5%type, --预留批属性5
                          strRSV_BATCH6     in stock_article_info.rsv_batch6%type, --预留批属性6
                          strRSV_BATCH7     in stock_article_info.rsv_batch7%type, --预留批属性7
                          strRSV_BATCH8     in stock_article_info.rsv_batch8%type, --预留批属性8
                          nQty              in odata_outstock_d.real_qty%type, --下架库量
                          strsCellNo        in odata_outstock_d.s_cell_no%type, --来源储位
                          strDestCellNo     in odata_outstock_d.d_cell_no%type, --目的储位
                          strLabelNo        in odata_outstock_d.label_no%type, --来源标签号
                          strUserId         in odata_outstock_m.rgst_name%type, --下架人
                          strResult         OUT varchar2) is
    v_iCount integer;
  begin

    strResult := 'N|[P_mdata_RfOut]';

    for GetHmInf in (select ood.* from odata_outstock_d ood,odata_outstock_m oom,
        stock_article_info sai,stock_label_d sld
       where oom.enterprise_no=ood.enterprise_no and oom.enterprise_no=sai.enterprise_no
             and oom.enterprise_no=sld.enterprise_no and oom.enterprise_no=strEnterPriseNo
             and oom.warehouse_no=ood.warehouse_no and oom.outstock_no=ood.outstock_no
             and oom.outstock_no=sld.source_no and oom.warehouse_no=sld.warehouse_no
             and oom.outstock_no=strOutstock_No and ood.article_no=strArticleNo
             and ood.packing_qty=nPacking_QTY and sai.quality=strQuality
             and ood.article_no=sai.article_no and ood.article_id=sai.article_id
             and sai.produce_date=dtProduceDate and sai.expire_date=dtExpireDate
             and sai.lot_no=strLotNo and sai.rsv_batch1=strRSV_BATCH1 and sai.rsv_batch2=strRSV_BATCH2
             and sai.rsv_batch3=strRSV_BATCH3 and sai.rsv_batch4=strRSV_BATCH4
             and sai.rsv_batch5=strRSV_BATCH5 and sai.rsv_batch6=strRSV_BATCH6
             and sai.rsv_batch7=strRSV_BATCH7 and sai.rsv_batch8=strRSV_BATCH8
             and ood.outstock_no=sld.source_no and ood.warehouse_no=sld.warehouse_no
             and ood.divide_id=sld.divide_id and ood.article_no=sld.article_no
             and ood.s_cell_no=strsCellNo AND OOD.d_Cell_No=strDestCellNo
             and ood.article_id=sld.article_id and ood.status='10' and sld.status=CLabelStatus.MOVE_HAND_OUT
             ) loop
        --更新移库明细状态
        update
          odata_outstock_d d
        set
          d.outstock_name=strUserId ,D.outstock_date=sysdate
        where
          d.enterprise_no=strEnterPriseNo and d.warehouse_no = strWareHouseNo
          and d.outstock_no = strOutstock_No
          and d.article_no = strArticleNo
          and d.packing_qty = nPacking_QTY
          and d.s_cell_no = strsCellNo
          and d.d_cell_no = strDestCellNo;

        if sql%notfound then
          strResult := 'N|[E26401]';--;
          return;
        end if;


        --更新对应标签状态
        update
          stock_label_d d
        set
          d.status = clabelstatus.OUTSTOCKING,d.updt_name=strUserId ,d.updt_date=sysdate
        where
          d.enterprise_no=strEnterPriseNo and d.warehouse_no = strWareHouseNo
          and d.article_no = strArticleNo
          and d.article_id = GetHmInf.article_id
          and d.divide_id=GetHmInf.divide_id
          and d.container_no = (select
                                  m.container_no
                                from
                                  stock_label_m m
                                where
                                  m.enterprise_no=strEnterPriseNo and m.warehouse_no = strWareHouseNo
                                  and m.label_no = strLabelNo
                                  and m.use_type=CLabelUseType.MOVE_STOCK_LABEL
                                );
        if sql%notfound then
          strResult := 'N|[E26401]';--更新状态失败;
          return;
        end if;


        --若整任务都移库下架，将标签头状态改为41

        select count(*) into v_iCount from stock_label_d sld,stock_label_m slm
        where slm.enterprise_no=sld.enterprise_no and slm.enterprise_no=strEnterPriseNo
        and slm.warehouse_no=sld.warehouse_no and slm.warehouse_no=strWareHouseNo
        and slm.label_no=strLabelNo and slm.source_no=sld.source_no
        and slm.source_no=strOutstock_No and sld.status=clabelstatus.MOVE_HAND_OUT;

        if v_iCOUNT=0 then
            update stock_label_m set status = clabelstatus.OUTSTOCKING,updt_name=strUserId ,updt_date=sysdate
             where enterprise_no=strEnterPriseNo and warehouse_no = strWareHouseNo and source_no=strOutstock_No
             and label_no=strLabelNo ;
        end if;

 end loop;

    strResult := 'Y';

  end P_mdata_RfOut;

  /***************************************************************************************************************
  功能说明：将标签库存回库写下架明细
  创建人:luozhiling
  创建时间：2014.12.4
  ***************************************************************************************************************/
  procedure Proc_Insert_LabelBackCellItem
  (strEnterPriseNo      IN                stock_content.enterprise_no%type,
   strWarehouseNo       in                stock_content.warehouse_no%type,
   strOutstockNo        in                odata_outstock_m.outstock_no%type,
   strOwnerNo           in                odata_outstock_d.owner_no%type,
   strsCellNo           in                stock_content.cell_no%type,--来源储位
   strLabelNo           in                stock_content.label_no%type,--来源标签
   strSubLabelNo        in                stock_content.sub_label_no%type,
   strSourceNo          in                stock_label_m.source_no%type,
   strArticleNo         in                stock_content.article_no%type,
   nDivideId            in                stock_label_d.divide_id%type,
   nArticleId           in                stock_content.article_id%type,
   nPackingQty          in                stock_content.packing_qty%type,
   NRealQty             in                stock_content.qty%type,
   strUserID            in                stock_content.rgst_name%type,
   strOutMsg            out               varchar2) is

    n_count        number(10); --记录数，以做判断;
    v_strDCellNo               odata_outstock_d.d_cell_no%type;
    n_Dcell_id stock_content.cell_id%type; --目的储位ID
    n_MoveSumQty stock_content.Qty%type; --转移总数量
    n_MoveQty    stock_content.Qty%type; --转移数量
    v_strOwnerNo stock_content.owner_no%type;
    v_nDIVIDEID  odata_outstock_d.divide_id%type;
  begin
    strOutMsg := 'N|[proc_SaveMoveCell]';
    n_count   := 0;
    n_MoveSumQty := NRealQty;
    --获取回库储位
    begin
         select s_cell_no into v_strDCellNo from odata_outstock_dhty t where t.enterprise_no=strEnterPriseNo
                and t.warehouse_no=strWarehouseNo /*and t.outstock_no=strSourceNo */and t.divide_id=nDivideId;
    exception when no_data_found then
        strOutMsg:='N|[EEEE]';
    end;

    ----------------------------------获取商品库存信息-------------------------------------------
    for i_Content_Info in (select sc.* from stock_content sc
                           where sc.warehouse_no=strWarehouseNo  and sc.enterprise_no=strEnterPriseNo
                                and sc.article_no=strArticleNo and sc.cell_no=strsCellNo
                                and sc.article_id=nArticleId and sc.sub_label_no=strSubLabelNo
                                and sc.label_no=strLabelNo and sc.packing_qty=nPackingQty
                                and sc.qty-sc.outstock_qty >0) loop
          n_count:=n_count+1; --判断是否进了循环
          ------------------------当总转移数量等于0时，跳出本次循环
          if (n_MoveSumQty <= 0 or i_Content_Info.Qty <= 0) then
          ------------------------跳出本次循环，
            goto CutContentEnd;
          end if;
          --------循环配量-------------------
          if (i_Content_Info.Qty - i_Content_Info.outstock_qty >= n_MoveSumQty) then
            n_MoveQty := n_MoveSumQty;
          else
            n_MoveQty := i_Content_Info.Qty - i_Content_Info.outstock_qty;
          end if;
          n_MoveSumQty := n_MoveSumQty - n_MoveQty;
          ----------------------------------写库存预下预上数量-------------------------------------------
          pkobj_stock.p_UpdtContent_Reservation(strEnterPriseNo,strWarehouseNo,strsCellNo,i_Content_Info.cell_id,
                      v_strDCellNo,strLabelNo,i_Content_Info.sub_label_no,n_MoveQty,i_Content_Info.instock_type,
                      strUserID,n_Dcell_id,strOutMsg);
           if (substr(strOutMsg, 1, 1) <> 'Y') then
            return;
          end if;
          ----------------------------------添加移库下架明细---------------------------------------------
          v_nDIVIDEID:=SEQ_ODATA_OUTSTOCK_DIRECT.NEXTVAL;
          insert into odata_outstock_d(enterprise_no,warehouse_no,owner_no,outstock_no,divide_id,operate_date,exp_type,
                 exp_no,wave_no,cust_no,sub_cust_no,article_no,article_id,packing_qty,s_cell_no,s_cell_id,
                 s_container_no,d_cell_no,d_cell_id,article_qty,real_qty,status,deliver_obj,
                 assign_name,exp_date,label_no,sub_label_no)
                values(strEnterPriseNo,strWarehouseNo,strOwnerNo,strOutstockNo,v_nDIVIDEID,trunc(sysdate),'N',
                strOutstockNo,strOutstockNo,'N','N',strArticleNo,i_Content_Info.article_id,nPackingQTY,strsCellNo,i_Content_info.cell_id,
                'N',v_strDCellNo,n_Dcell_id,n_MoveQty,n_MoveQty,'10','N',
                strUserID,trunc(sysdate),strLabelNo,i_Content_Info.sub_label_no);
      <<CutContentEnd>>
      null;
    end loop;

      if (n_MoveSumQty > 0 ) then

         strOutMsg := 'N|[E01866]';
       return;
      end if;


    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM || substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end Proc_Insert_LabelBackCellItem;

  /*******************************************************************************************************
  创建人：huangb
  创建时间：2016.05.18
  功能说明：移库计划单转历史
  ********************************************************************************************************/
  procedure P_mdata_PlanInsertHTY(strEnterPriseNo           in  mdata_plan_m.enterprise_no%type,
                                  strWareHouseNo            in  mdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo                in  mdata_plan_m.owner_no%type,
                                  strPlanNo                 in  mdata_plan_m.plan_no%type,--移库计划单号
                                  strUserId                 in  mdata_plan_m.rgst_name%type,
                                  strOutMsg                 OUT varchar2) is
  begin
   strOutMsg := 'N|[P_mdata_PlanInsertHTY]';

   --移库计划单头档转历史
   insert into mdata_plan_mhty
     (warehouse_no, owner_no, plan_no, source_type, outstock_type, status, move_date
     , rgst_name, rgst_date, updt_name, updt_date, enterprise_no, report_up_serial)
   select mpm.warehouse_no, mpm.owner_no, mpm.plan_no, mpm.source_type, mpm.outstock_type, mpm.status, mpm.move_date
     , mpm.rgst_name, mpm.rgst_date, strUserId, sysdate, mpm.enterprise_no, mpm.report_up_serial
   from mdata_plan_m mpm
   where mpm.enterprise_no = strEnterPriseNo
     and mpm.warehouse_no = strWareHouseNo
     and mpm.owner_no = strOwnerNo
     and mpm.plan_no = strPlanNo;

   --移库计划单明细转历史
   insert into mdata_plan_dhty
     (warehouse_no, owner_no, plan_no, row_id, article_no, article_id, origin_qty
     , s_cell_no, s_label_no, s_sub_label_no, d_cell_no, move_date, label_no, stock_type
     , stock_value, enterprise_no, packing_qty)
   select mpd.warehouse_no, mpd.owner_no, mpd.plan_no, mpd.row_id, mpd.article_no, mpd.article_id, mpd.origin_qty
     , mpd.s_cell_no, mpd.s_label_no, mpd.s_sub_label_no, mpd.d_cell_no, mpd.move_date, mpd.label_no, mpd.stock_type
     , mpd.stock_value, mpd.enterprise_no, mpd.packing_qty
   from mdata_plan_d mpd
   where mpd.enterprise_no = strEnterPriseNo
     and mpd.warehouse_no = strWareHouseNo
     and mpd.owner_no = strOwnerNo
     and mpd.plan_no = strPlanNo;

   --删除正表数据
   delete mdata_plan_m mpm
    where mpm.enterprise_no = strEnterPriseNo
      and mpm.warehouse_no = strWareHouseNo
      and mpm.owner_no = strOwnerNo
      and mpm.plan_no = strPlanNo;

   delete mdata_plan_d mpd
    where mpd.enterprise_no = strEnterPriseNo
      and mpd.warehouse_no = strWareHouseNo
      and mpd.owner_no = strOwnerNo
      and mpd.plan_no = strPlanNo;

  strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|P_mdata_PlanInsertHTY' || SQLERRM ||
            substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end P_mdata_PlanInsertHTY;

end PKOBJ_MDATA;

/

