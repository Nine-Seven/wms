create view V_SEARCH_9103_023 as
select d.owner_no,
       d.enterprise_no,
       d.po_no,
       d.large_package_no,
       d.sourceexp_no,
       d.shipper_deliver_no,
       d.shipper_no,
       d.send_address,
       d.send_name,
       d.send_mobile_phone,
       d.cust_address,
       d.contactor_name,
       d.cust_phone,
       d.foreign_express_no,
      -- d.updt_name,
       d.outstock_date,
       d.warehouse_no,
       d.exp_date,
       d.cust_no,
       d.instock_date,
       m.rgst_name,
       m.rgst_date,
       to_char(m.rgst_date, 'yyyy-mm-dd') create_date,
       f_get_fieldtext('ODATA_PACKAGE_M', 'PO_TYPE', m.po_type) po_type,--集货类型
       m.status,
       f_get_fieldtext('ODATA_PACKAGE_M', 'STATUS', m.status) STATUS_TEXT,--状态描述
       c.owner_alias,
       bc.cust_name,
       b.shipper_name,
       bw.worker_name as updt_name
  from odata_package_d d
  left join odata_package_m m
    on m.po_no = d.po_no
   and m.enterprise_no = d.enterprise_no
   and m.warehouse_no = d.warehouse_no
  left join bdef_defshipper b
    on b.shipper_no = d.shipper_no
   and b.enterprise_no = d.enterprise_no
   and b.warehouse_no = d.warehouse_no
  left join bdef_defowner c
    on c.owner_no = d.owner_no
   and c.enterprise_no = d.enterprise_no
  left join bdef_defcust bc
    on bc.cust_no = d.cust_no
   and bc.enterprise_no = d.enterprise_no
  left join bdef_defworker bw
    on bw.worker_no = d.updt_name
    and bw.enterprise_no = d.enterprise_no
  order by d.po_no,d.sourceexp_no

/

