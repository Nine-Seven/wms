create package        PKOBJ_BDEF is

/**********************************************************************************************************
   MM
   2014.04.16
   功能：写入商品批号管理
***********************************************************************************************************/
    procedure p_bdef_insertarticlelot(strARTICLENO    in    BDEF_ARTICLE_LOT_MANAGE.ARTICLE_NO%type,--
                                  strLOTNO                  in    BDEF_ARTICLE_LOT_MANAGE.LOT_NO%type,
                                  dtPRODUCEDATE             in    BDEF_ARTICLE_LOT_MANAGE.PRODUCE_DATE%type,
                                  dtEXPIREDATE              in   BDEF_ARTICLE_LOT_MANAGE.EXPIRE_DATE%type,--
                                  intEXPIRYDAYS             in  BDEF_ARTICLE_LOT_MANAGE.EXPIRY_DAYS%type,--
                                  strUserId                 in BDEF_ARTICLE_LOT_MANAGE.RGST_NAME%type,
                                  douPRICE                  in BDEF_ARTICLE_LOT_MANAGE.PRICE%type,
                                  strResult                 OUT    varchar2);

/**********************************************************************************************************
  hekl
  2015.07.03
  功能：新增保存或者修改保存商品类别资料
***********************************************************************************************************/
    procedure saveOrUpdateGroup(
                        strEnterpriseNo         in bdef_article_group.enterprise_no%type,
                        strOwnerNo              in bdef_article_group.owner_no%type,
                        strGroupNo              in bdef_article_group.group_no%type,
                        strGroupLevel           in bdef_article_group.group_level%type,
                        strGroupName            in bdef_article_group.group_name%type,
                        strMGroupNo             in bdef_article_group.m_group_no%type,
                        strMGroupName           in bdef_article_group.m_group_name%type,
                        strLGroupNo             in bdef_article_group.l_group_no%type,
                        strLGroupName           in bdef_article_group.l_group_name%type,
                        strAlarmrate            in bdef_article_group.alarmrate%type,
                        strCheckExcess          in bdef_article_group.check_excess%type,
                        strCheckQtyFlag         in bdef_article_group.check_qty_flag%type,
                        strCheckQtyRate         in bdef_article_group.check_qty_rate%type,
                        strCheckWeightFlag      in bdef_article_group.check_weight_flag%type,
                        strCheckWeightRate      in bdef_article_group.check_weight_rate%type,
                        strDivideExcess         in bdef_article_group.divide_excess%type,
                        strDoubleCheck          in bdef_article_group.double_check%type,
                        strFcStrategy           in bdef_article_group.fc_strategy%type,
                        strFreezerate           in bdef_article_group.freezerate%type,
                        strTurnOverRule         in bdef_article_group.turn_over_rule%type,
                        strUmCheckExcess        in bdef_article_group.um_check_excess%type,
                        strPickExcess           in bdef_article_group.pick_excess%type,
                        strTemperatureFlag      in bdef_article_group.temperature_flag%type,
                        strScanFlag             in bdef_article_group.scan_flag%type,
                        strMeasureMode          in bdef_article_group.measure_mode%type,
                        strMixFlag              in bdef_article_group.mix_flag%type,
                        strQcFlag               in bdef_article_group.qc_flag%type,
                        strQcRate               in bdef_article_group.qc_rate%type,
                        strIStrategy            in bdef_article_group.i_strategy%type,
                        strOStrategy            in bdef_article_group.o_strategy%type,
                        strMStrategy            in bdef_article_group.m_strategy%type,
                        strRiStrategy           in bdef_article_group.ri_strategy%type,
                        strRoStrategy           in bdef_article_group.ro_strategy%type,
                        strPrintFlag            in bdef_article_group.print_flag%type,
                        strRgstName             IN BDEF_ARTICLE_GROUP.RGST_NAME%TYPE,
                        strStatus               IN BDEF_ARTICLE_GROUP.Status%TYPE,
                        strRsvStrategy1         in bdef_article_group.rsv_strategy1%type,
                        strRsvStrategy2         in bdef_article_group.rsv_strategy1%type,
                        strRsvStrategy3         in bdef_article_group.rsv_strategy1%type,
                        strRsvStrategy4         in bdef_article_group.rsv_strategy1%type,
                        strRsvStrategy5         in bdef_article_group.rsv_strategy1%type,
                        strRsvStrategy6         in bdef_article_group.rsv_strategy1%type,
                        strFalg                 in varchar2,
                        strOutMsg               out varchar2);
/**********************************************************************************************************
   hcx
   2015.11.19
   功能：校验客户与电子标签储位对应关系是否可以解除
***********************************************************************************************************/

   procedure P_CheckDeliverCustNo(strEnterpriseNo in cset_cust_dpscell.enterprise_no%type,
                                             strWarehouseNo  in cset_cust_dpscell.warehouse_no%type,
                                             strOwnerNo     in cset_cust_dpscell.owner_no%type,
                                             strCustNo    in cset_cust_dpscell.cust_no%type,
                                             strResult       out varchar2);

end PKOBJ_BDEF;


/

