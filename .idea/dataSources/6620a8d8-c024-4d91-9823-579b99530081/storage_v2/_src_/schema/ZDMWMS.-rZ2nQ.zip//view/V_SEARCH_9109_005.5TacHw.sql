create view V_SEARCH_9109_005 as
select i."ENTERPRISE_NO",i."WAREHOUSE_NO",i."WORKER_NO",i."WORKER_NAME",i."OPERATE_DATE",i."SUMQTY",i."STARTTIME",i."ENDTIME",floor((endtime - starttime) * 24 * 60) -
       case when to_char(starttime,'hh24:mi:ss') >= '13:00:00'  then 0 else
       case when to_char(endtime,'hh24:mi:ss') <= '12:30:00' then 0 else 90 end end
       as work_duration,
       floor(((sum(sumqty) over (partition by worker_no,operate_date))/(floor((endtime - starttime) * 24 * 60) -
       case when to_char(starttime,'hh24:mi:ss') >= '13:00:00'  then 0 else
       case when to_char(endtime,'hh24:mi:ss') <= '12:30:00' then 0 else 90 end end))*60) qty_per_hour from
(select t.enterprise_no,
               t.warehouse_no,
               t.worker_no,
       t.worker_name,
       t.operate_date,
       t.sumqty,
       min(starttime) over (partition by t.worker_no,t.operate_date) as starttime,
       max(endtime) over (partition by t.worker_no,t.operate_date) as endtime
  from (select icd.enterprise_no,
               icd.warehouse_no,
               b.worker_no,
               b.worker_name,
               trunc(icd.outstock_date) as operate_date,
               min(icd.outstock_date) starttime,
               max(icd.outstock_date) endtime,
               sum(icd.real_qty) as sumqty
          from (select * from odata_outstock_d
          where outstock_no like 'HO%' union select * from odata_outstock_dhty where outstock_no like 'HO%' ) icd, bdef_defworker b,bdef_defarticle bda
         where bda.enterprise_no=icd.enterprise_no
         and bda.article_no=icd.article_no
         and b.enterprise_no=icd.enterprise_no
         and b.worker_no = icd.outstock_name
         group by icd.enterprise_no,icd.warehouse_no,b.worker_no, b.worker_name, trunc(icd.outstock_date)
         having sum(icd.real_qty)>0) t) i
 order by worker_no,operate_date

/

