create view V_SEARCH_9108_3 as
select fcd.enterprise_no,
       fcd.warehouse_no,
       fcd.owner_no,
       fcm.plan_no,
       to_char( fcm.check_date, 'yyyy-mm-dd') check_date,
       fcd.article_no,
       bd.owner_article_no,
       fcd.barcode,
       bd.article_name,
       fcd.packing_qty,
       sum(fcd.article_qty) article_qty,
       sum(fcd.check_qty) check_qty,
       sum(fcd.recheck_qty) recheck_qty,
       sum(fcd.third_qty) third_qty
from fcdata_check_m fcm,
     fcdata_check_d fcd,
     bdef_defarticle bd
where fcm.warehouse_no=fcd.warehouse_no
  and fcm.enterprise_no = fcd.enterprise_no
  and fcm.check_no=fcd.check_no
    and fcd.enterprise_no=bd.enterprise_no
  and fcd.article_no=bd.article_no
group by fcd.enterprise_no,
         fcd.warehouse_no,
         fcd.owner_no,
         fcm.plan_no,
         fcm.check_date,
         fcd.article_no,
         bd.owner_article_no,
         fcd.barcode,
         bd.article_name,
         fcd.packing_qty

/

