create package body        PKOBJ_BILL is
    v_nValue bill_base_amount.value%type := 0; --基础消费值
    /***********************************************************************************************
    wyf
    20150630
    功能说明：根据取值策略生成消费清单
    ***********************************************************************************************/
    procedure P_GENERATE_CONSUMERLIST(strEnterprise_no bill_formulaset.enterprise_no%type, --企业
                                      strWarehouse_no  bill_formulaset.warehouse_no%type, --仓别
                                      strOwner_no      bill_formulaset.owner_no%type, --货主
                                      dtDate           bill_expenses_list.begin_date%type, --生成日期
                                      strFlag          varchar2, --0:代表正常日结生成，1：代表重算
                                      strOutMsg        out varchar2) --返回值
     IS
      intCount           integer := 0;
      dtBeginDate        bill_formulaset.rgst_date%type;
      dtEndDate          bill_formulaset.rgst_date%type;
      dtCurMonthFirstDay bill_formulaset.rgst_date%type; --当前月第一天
      dtCurMonthLastDay  bill_formulaset.rgst_date%type; --当前月最后一天
      dtCurDay           bill_formulaset.rgst_date%type; --当天
      v_strWeek  varchar2(10); --星期
      v_maxWeek  varchar2(10); --星期
      v_week   varchar2(10);
      v_weekBegin  date;
      v_weekEnd  date;
      v_strDay  varchar2(10);--当前时间所在月第几天
      v_strDay2  varchar2(10);
      v_maxDay  varchar2(10);
      v_endDate  date;--结算日期
      v_lastDay  date;
      v_maxEndDate date;
      nday number;
      nday2 number;
      v_count number;
    BEGIN
      strOutMsg := 'N|[P_Generate_ConsumerList]';
      nday :=0;
      v_count := 0;
      for p in (select a.*
                  from bill_formulaset a
                 where a.status = '0'
                   and a.enterprise_no = strEnterprise_no
                   and a.warehouse_no = strWarehouse_no
                   and a.owner_no = strOwner_no) loop
        intCount := intCount + 1;

        --计费周期：1-天；2-周；3-月；4-季度（预留）；5-年（预留）
        if trunc(dtDate)>trunc(p.end_date) then
           goto over;
        else
         if p.balance_day is null then

           if p.billing_cycle = '1' then
              if strFlag = '0' then
                 dtBeginDate := dtDate - 1;
                 dtEndDate   := dtDate - 1;
              else
                 --检查要重算的消费清单对应的费用是否上缴或取消
                 select count(1) into v_count
                  from bill_expenses_list bel,bill_cost_list bcl
                 where bcl.enterprise_no=bcl.enterprise_no
                   and bel.warehouse_no=bcl.warehouse_no
                   and bel.owner_no=bcl.owner_no
                   and bel.billing_project=bcl.billing_project
                   and trunc(bel.end_date)=trunc(bcl.billing_date)
                   and bel.enterprise_no=p.enterprise_no
                   and bel.warehouse_no=p.warehouse_no
                   and bel.owner_no=p.owner_no
                   and bel.billing_project=p.billing_project
                   and bel.billing_type=p.billing_type
                   and trunc(bel.begin_date)=trunc(dtDate)
                   and trunc(bel.end_date)=trunc(dtDate)
                   and bcl.status>'10';

                 if v_count=0 then
                    dtBeginDate := dtDate;
                    dtEndDate   := dtDate;
                 else
                    goto over;
                 end if;

              end if;
           elsif p.billing_cycle = '2' then
                --今天
                select trunc(dtDate) into dtCurDay from dual;
                --获取dtDate所在的周的开始日期
                select trunc(dtDate,'IW') into v_weekBegin from dual;

                --获取dtDate所在的周的结束日期
                v_weekEnd:=v_weekBegin+6;

                if strFlag = '0' and dtCurDay = v_weekBegin then
                   dtBeginDate := dtDate - 7;
                   dtEndDate   := dtDate - 1;
                elsif strFlag = '1' and dtCurDay = v_weekEnd then

                   --检查要重算的消费清单对应的费用是否上缴或取消
                   select count(1) into v_count
                     from bill_expenses_list bel,bill_cost_list bcl
                    where bcl.enterprise_no=bcl.enterprise_no
                      and bel.warehouse_no=bcl.warehouse_no
                      and bel.owner_no=bcl.owner_no
                      and bel.billing_project=bcl.billing_project
                      and trunc(bel.end_date)=trunc(bcl.billing_date)
                      and bel.enterprise_no=p.enterprise_no
                      and bel.warehouse_no=p.warehouse_no
                      and bel.owner_no=p.owner_no
                      and bel.billing_project=p.billing_project
                      and bel.billing_type=p.billing_type
                      and trunc(bel.begin_date)=trunc(v_weekBegin)
                      and trunc(bel.end_date)=trunc(v_weekEnd)
                      and bcl.status>'10';

                   if v_count=0 then
                      dtBeginDate := v_weekBegin;
                      dtEndDate   := v_weekEnd;
                   else
                      goto over;
                   end if;

                else
                   goto over;
                end if;
            elsif p.billing_cycle = '3' then
                --今天
                select trunc(dtDate) into dtCurDay from dual;
                --当前月第一天
                select trunc(add_months(last_day(dtDate), -1) + 1)
                into dtCurMonthFirstDay
                from dual;
                --当前月最后一天
                select trunc(last_day(dtDate)) into dtCurMonthLastDay from dual;

                --如果是月结日（每月第一天）
                if strFlag = '0' and dtCurDay = dtCurMonthFirstDay then
                   dtBeginDate := add_months(dtDate, -1);
                   dtEndDate   := dtDate - 1;
                elsif strFlag = '1' and dtCurDay = dtCurMonthLastDay then
                   --检查要重算的消费清单对应的费用是否上缴或取消
                   select count(1) into v_count
                     from bill_expenses_list bel,bill_cost_list bcl
                    where bcl.enterprise_no=bcl.enterprise_no
                      and bel.warehouse_no=bcl.warehouse_no
                      and bel.owner_no=bcl.owner_no
                      and bel.billing_project=bcl.billing_project
                      and trunc(bel.end_date)=trunc(bcl.billing_date)
                      and bel.enterprise_no=p.enterprise_no
                      and bel.warehouse_no=p.warehouse_no
                      and bel.owner_no=p.owner_no
                      and bel.billing_project=p.billing_project
                      and bel.billing_type=p.billing_type
                      and trunc(bel.begin_date)=trunc(dtCurMonthFirstDay)
                      and trunc(bel.end_date)=trunc(dtCurMonthLastDay)
                      and bcl.status>'10';

                   if v_count=0 then
                      dtBeginDate := dtCurMonthFirstDay;
                      dtEndDate   := dtCurMonthLastDay;
                   else
                      goto over;
                   end if;

                else
                   goto over;
                end if;
             end if;
        else
           if p.billing_cycle = '2' then
              --dtDat所属星期几
              select to_char(dtDate ,'d')-1 into v_strWeek    from dual;
              --取最后一笔清单产生的结束时间
              begin
                  select max(bel.end_date)
                    into v_maxEndDate
                    from bill_expenses_list bel
                   where bel.billing_project =p.billing_project
                     and bel.owner_no=strOwner_no
                     and bel.warehouse_no=strWarehouse_no
                     and bel.enterprise_no = strEnterprise_no;
              exception
                when no_data_found then

                   if p.balance_day = v_strWeek then
                      --周开始日期
                      v_weekBegin:=dtDate-7;
                      --周结束日期
                      v_weekEnd:=dtDate-1;
                   else

                      if p.balance_day=0 then
                         --今天与结算日相差天数
                         nday := v_strWeek - 7;
                      else
                         --今天与结算日相差天数
                         nday := v_strWeek - p.balance_day;

                      end if;

                      --周开始日期
                      select trunc(dtDate)-nday into v_weekBegin from dual;
                      --周结束日期
                      v_weekEnd:=v_weekBegin+6;

                    end if;

               end;
               --v_maxEndDate所属星期几
               select to_char(v_maxEndDate ,'d')-1 into v_maxWeek from dual;
               if p.balance_day='0' then
                  v_week:=p.balance_day+7;
               else
                  v_week:=p.balance_day;
               end if;
               if v_maxWeek+1 != v_week then
                  v_weekBegin := v_maxEndDate+1;
                  --v_weekBegin与结算日相差天数
                  nday2 := v_maxWeek +1- p.balance_day;
                  if nday2<0 then
                     v_weekEnd := v_weekBegin-nday2-1;
                  else
                     v_weekEnd := v_weekBegin+6-nday2;
                  end if;
               else
                  if p.balance_day = v_strWeek then
                      --周开始日期
                      v_weekBegin:=dtDate-7;
                      --周结束日期
                      v_weekEnd:=dtDate-1;
                   else

                      if p.balance_day=0 then
                         --今天与结算日相差天数
                         nday := v_strWeek - 7;
                      else
                         --今天与结算日相差天数
                         nday := v_strWeek - p.balance_day;

                      end if;

                      --周开始日期
                      select trunc(dtDate)-nday into v_weekBegin from dual;
                      --周结束日期
                      v_weekEnd:=v_weekBegin+6;

                    end if;
               end if;
               if dtDate=v_weekEnd+1 then
                       --检查要重算的消费清单对应的费用是否上缴或取消
                       select count(1) into v_count
                         from bill_expenses_list bel,bill_cost_list bcl
                        where bcl.enterprise_no=bcl.enterprise_no
                          and bel.warehouse_no=bcl.warehouse_no
                          and bel.owner_no=bcl.owner_no
                          and bel.billing_project=bcl.billing_project
                          and trunc(bel.end_date)=trunc(bcl.billing_date)
                          and bel.enterprise_no=p.enterprise_no
                          and bel.warehouse_no=p.warehouse_no
                          and bel.owner_no=p.owner_no
                          and bel.billing_project=p.billing_project
                          and bel.billing_type=p.billing_type
                          and trunc(bel.begin_date)=trunc(v_weekBegin)
                          and trunc(bel.end_date)=trunc(v_weekEnd)
                          and bcl.status>'10';

                        if v_count=0 then
                           dtBeginDate := v_weekBegin;
                           dtEndDate   := v_weekEnd;
                        else
                           goto over;
                        end if;
                     else
                        goto over;
                     end if;

           elsif p.billing_cycle = '3' then
              --dtDate所在月第几天
              select to_char(dtDate ,'DD') into v_strDay from dual;
              nday := v_strDay-p.balance_day;
              --今天
              select trunc(dtDate) into dtCurDay from dual;
              --结算日期
              select trunc(dtCurDay-nday) into v_endDate from dual;
              --结算日期上月对应日期
              select trunc(add_months(v_endDate,-1)) into v_lastDay from dual;

              --结算日期上月对应日期所在月第几天
              select to_char(v_lastDay ,'DD') into v_strDay2 from dual;

              --取最后一笔清单产生的结束时间
              begin
                  select max(bel.end_date)
                    into v_maxEndDate
                    from bill_expenses_list bel
                   where bel.billing_project =p.billing_project
                     and bel.owner_no=strOwner_no
                     and bel.warehouse_no=strWarehouse_no
                     and bel.enterprise_no = strEnterprise_no;
              exception
                when no_data_found then

                   if to_number(v_strDay2) < p.balance_day then
                   --结算开始日期
                      dtCurMonthFirstDay := v_lastDay+1;
                   else
                      dtCurMonthFirstDay := v_lastDay;
                   end if;
                      --结算结束日期
                   select trunc(v_endDate-1) into dtCurMonthLastDay from dual;

               end;

              --v_maxEndDate所在月第几天
              select to_char(v_maxEndDate ,'DD') into v_maxDay from dual;
              if v_maxDay+1 != p.balance_day then
                  dtCurMonthFirstDay := v_maxEndDate+1;
                  --dtCurMonthFirstDay与结算日相差天数
                  nday2 := v_maxDay +1- p.balance_day;
                  if nday2<0 then

                     dtCurMonthLastDay := dtCurMonthFirstDay-nday2-1;
                  else

                    dtCurMonthLastDay :=trunc(last_day(dtCurMonthFirstDay))+1+p.balance_day-2;

                  end if;
               else

                   if to_number(v_strDay2) < p.balance_day then
                   --结算开始日期
                      dtCurMonthFirstDay := v_lastDay+1;
                   else
                      dtCurMonthFirstDay := v_lastDay;
                   end if;
                      --结算结束日期
                   select trunc(v_endDate-1) into dtCurMonthLastDay from dual;
               end if;

              --如果是月结日(结算时间)
              if dtCurDay = dtCurMonthLastDay+1 then
                 --检查要重算的消费清单对应的费用是否上缴或取消
                 select count(1) into v_count
                  from bill_expenses_list bel,bill_cost_list bcl
                 where bcl.enterprise_no=bcl.enterprise_no
                   and bel.warehouse_no=bcl.warehouse_no
                   and bel.owner_no=bcl.owner_no
                   and bel.billing_project=bcl.billing_project
                   and trunc(bel.end_date)=trunc(bcl.billing_date)
                   and bel.enterprise_no=p.enterprise_no
                   and bel.warehouse_no=p.warehouse_no
                   and bel.owner_no=p.owner_no
                   and bel.billing_project=p.billing_project
                   and bel.billing_type=p.billing_type
                   and trunc(bel.begin_date)=trunc(dtCurMonthFirstDay)
                   and trunc(bel.end_date)=trunc(dtCurMonthLastDay)
                   and bcl.status>'10';

                  if v_count=0 then
                     dtBeginDate := dtCurMonthFirstDay;
                     dtEndDate   := dtCurMonthLastDay;
                  else
                     goto over;
                  end if;

              else
                 goto over;
              end if;
            end if;
        end if;
        end if;
        --计费方式：1：固定费用；2：动态费用
        --固定费用
        if p.Billing_Flag = '1' then
          P_GCLD_FIXED(p.enterprise_no,
                       p.warehouse_no,
                       p.owner_no,
                       p.billing_project,
                       p.billing_type,
                       dtBeginDate,
                       dtEndDate,
                       strOutMsg);
        else
          --动态费用
          P_GCLD_DYNAMIC(p.enterprise_no,
                         p.warehouse_no,
                         p.owner_no,
                         p.billing_project,
                         p.billing_type,
                         dtBeginDate,
                         dtEndDate,
                         strOutMsg);
        end if;
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
        <<over>>
        null;
      end loop;
      strOutMsg := 'Y';
    exception
      when others then
        strOutMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
        return;
    END P_GENERATE_CONSUMERLIST;

    /***********************************************************************************************
    wyf
    20150630
    功能说明：根据取值策略生成固定费用类型的消费清单
    ***********************************************************************************************/
    procedure P_GCLD_FIXED(strEnterprise_no   bill_formulaset.enterprise_no%type, --企业
                           strWarehouse_no    bill_formulaset.warehouse_no%type, --仓别
                           strOwner_no        bill_formulaset.owner_no%type, --货主
                           strBilling_project bill_formulaset.billing_project%type, --计费项目
                           strBillingType     bill_formulaset.billing_type%type, --计费项目类型
                           dtBeginDate        bill_formulaset.rgst_date%type, --开始日期
                           dtEndDate          bill_formulaset.rgst_date%type, --开始日期
                           strOutMsg          out varchar2) --返回值
     IS
      intCount integer := 0;
    BEGIN
      strOutMsg := 'N|[P_GCLD_FIXED]';
      for p in (select *
                  from bill_formulaset a
                 where a.enterprise_no = strEnterprise_no
                   and a.warehouse_no = strWarehouse_no
                   and a.owner_no = strOwner_no
                   and a.billing_project = strBilling_project
                   and a.billing_type = strBillingType
                   and a.billing_flag = '1') loop
        intCount := intCount + 1;
        --删除
        delete from bill_expenses_list a
         where a.enterprise_no = p.enterprise_no
           and a.warehouse_no = p.warehouse_no
           and a.owner_no = p.owner_no
           and a.billing_project = p.billing_project
           and a.billing_type = p.billing_type
           and trunc(a.begin_date) = trunc(dtBeginDate)
           and trunc(a.end_date) = trunc(dtEndDate);

        --消费清单表
        insert into bill_expenses_list
          (enterprise_no,
           warehouse_no,
           owner_no,
           billing_project,
           billing_type,
           group_no,
           begin_date,
           end_date,
           qty,
           serial_no,
           flag)
        values
          (p.enterprise_no,
           p.warehouse_no,
           p.owner_no,
           p.billing_project,
           p.billing_type,
           'N', --c.group_no,
           trunc(dtBeginDate),
           trunc(dtEndDate),
           p.fixed_value,
           seq_bill_expenses_list.nextval,
           '0');
      END LOOP;
      if intCount = 0 then
        strOutMsg := 'N|[设费项目设置错误，请核实!]';
        return;
      end if;
      strOutMsg := 'Y';
    exception
      when others then
        strOutMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
        return;
    END P_GCLD_FIXED;

    /***********************************************************************************************
    wyf
    20150630
    功能说明：根据取值策略生成动态费用类型的消费清单
    ***********************************************************************************************/
    procedure P_GCLD_DYNAMIC(strEnterprise_no   bill_formulaset.enterprise_no%type, --企业
                             strWarehouse_no    bill_formulaset.warehouse_no%type, --仓别
                             strOwner_no        bill_formulaset.owner_no%type, --货主
                             strBilling_project bill_formulaset.billing_project%type, --计费项目
                             strBillingType     bill_formulaset.billing_type%type, --计费项目类型
                             dtBeginDate        bill_formulaset.rgst_date%type, --开始日期
                             dtEndDate          bill_formulaset.rgst_date%type, --开始日期
                             strOutMsg          out varchar2) --返回值
     IS
      intCount integer := 0;
      nQty     bill_expenses_list.qty%type;
      nVolume  bill_expenses_list.volume%type;
      nWeight  bill_expenses_list.weight%type;

    BEGIN
      strOutMsg := 'N|[P_GCLD_DYNAMIC]';
      for p in (select a.*, nvl(b.family_no, 'N') family_no
                  from bill_formulaset a
                  left join BILL_FAMILY_UNIT_PRICE b
                    on a.warehouse_no = b.warehouse_no
                   and a.owner_no = b.owner_no
                   and a.enterprise_no = b.enterprise_no
                   and a.billing_project = b.billing_project
                 where a.enterprise_no = strEnterprise_no
                   and a.warehouse_no = strWarehouse_no
                   and a.owner_no = strOwner_no
                   and a.billing_project = strBilling_project
                   and a.billing_type = strBillingType) loop
        intCount := intCount + 1;
        --删除
        delete from bill_expenses_list a
         where a.enterprise_no = strEnterprise_no
           and a.warehouse_no = strWarehouse_no
           and a.owner_no = strOwner_no
           and a.billing_project = strBilling_project
           and a.billing_type = p.billing_type
           and trunc(a.begin_date) = trunc(dtBeginDate)
           and trunc(a.end_date) = trunc(dtEndDate);

        --获取基本费用清单数值
        if p.billing_cycle = '1' then
          select nvl(sum(a.value), 0)
            into v_nValue
            from bill_base_amount a
           where a.enterprise_no = p.enterprise_no
             and a.warehouse_no = p.warehouse_no
             and a.owner_no = p.owner_no
             and a.billing_project = p.billing_project
             and trunc(a.amount_date) = trunc(dtEndDate);
        elsif p.billing_cycle in ('2','3') then
          select nvl(sum(a.value), 0)
            into v_nValue
            from bill_base_amount a
           where a.enterprise_no = p.enterprise_no
             and a.warehouse_no = p.warehouse_no
             and a.owner_no = p.owner_no
             and a.billing_project = p.billing_project
             and trunc(a.amount_date) >= trunc(dtBeginDate)
             and trunc(a.amount_date) <= trunc(dtEndDate);
       /* elsif p.billing_cycle = '3' then
          select nvl(sum(a.value), 0)
            into v_nValue
            from bill_base_amount a
           where a.enterprise_no = p.enterprise_no
             and a.warehouse_no = p.warehouse_no
             and a.owner_no = p.owner_no
             and a.billing_project = p.billing_project
             and trunc(a.amount_date, 'MM') = trunc(dtEndDate, 'MM');*/
        else
          v_nValue := 0;
        end if;
        --原有：LO:装卸;IC:验收;IN:上架;HO:拣货;PA:打包;AR:整理；RIC:验收;RIN:上架;RO:退货;MV:移库；FC:盘点
        --新增：INC:入库处理费，LCF:冷藏费，BASE:基础费用
        --已实现：IC:验收，IN:上架，HO:拣货，RIC:验收，LO:装卸，ALL:仓租
        if strBillingType = 'IC' then
          --验收
          P_GETICGCLD(strEnterprise_no,
                      strWarehouse_no,
                      strOwner_no,
                      p.billing_unit,
                      p.value_flag,
                      dtBeginDate,
                      dtEndDate,
                      p.family_no,
                      nQty,
                      nVolume,
                      nWeight,
                      strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        elsif strBillingType = 'IN' then
          --上架
          P_GETINGCLD(strEnterprise_no,
                      strWarehouse_no,
                      strOwner_no,
                      p.billing_unit,
                      p.value_flag,
                      dtBeginDate,
                      dtEndDate,
                      p.family_no,
                      nQty,
                      nVolume,
                      nWeight,
                      strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;

        elsif strBillingType = 'HO' then
          --拣货
          P_GETHOGCLD(strEnterprise_no,
                      strWarehouse_no,
                      strOwner_no,
                      p.billing_unit,
                      p.value_flag,
                      dtBeginDate,
                      dtEndDate,
                      p.family_no,
                      nQty,
                      nVolume,
                      nWeight,
                      strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;

        elsif strBillingType = 'RIC' then
          --返配验收
          P_GETRICGCLD(strEnterprise_no,
                       strWarehouse_no,
                       strOwner_no,
                       p.billing_unit,
                       p.value_flag,
                       dtBeginDate,
                       dtEndDate,
                       p.family_no,
                       nQty,
                       nVolume,
                       nWeight,
                       strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;

        elsif strBillingType = 'LOC' then
          --装卸
          P_GETLOCGCLD(strEnterprise_no,
                       strWarehouse_no,
                       strOwner_no,
                       p.billing_unit,
                       p.value_flag,
                       dtBeginDate,
                       dtEndDate,
                       p.family_no,
                       nQty,
                       nVolume,
                       nWeight,
                       strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;

        elsif strBillingType = 'ALL' then
          --仓租
          P_ALLGCLD(strEnterprise_no,
                    strWarehouse_no,
                    strOwner_no,
                    p.billing_unit,
                    p.value_flag,
                    dtBeginDate,
                    dtEndDate,
                    p.family_no,
                    nQty,
                    nVolume,
                    nWeight,
                    strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;

        elsif strBillingType = 'INC' then
          --入库处理费
          P_GETICGCLD(strEnterprise_no,
                      strWarehouse_no,
                      strOwner_no,
                      p.billing_unit,
                      p.value_flag,
                      dtBeginDate,
                      dtEndDate,
                      p.family_no,
                      nQty,
                      nVolume,
                      nWeight,
                      strOutMsg);

          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        elsif strBillingType = 'LCF' then
          --冷藏费
          P_GETLCFGCLD(strEnterprise_no,
                       strWarehouse_no,
                       strOwner_no,
                       p.billing_unit,
                       p.value_flag,
                       dtBeginDate,
                       dtEndDate,
                       p.family_no,
                       nQty,
                       nVolume,
                       nWeight,
                       strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        elsif strBillingType = 'BS' then
          --基础费用
          if p.value_flag = '2' and p.billing_unit = '0' then
            nQty := v_nValue;
          end if;
        end if;

        --新增消费明细
        insert into bill_expenses_list
          (enterprise_no,
           warehouse_no,
           owner_no,
           billing_project,
           billing_type,
           group_no,
           begin_date,
           end_date,
           qty,
           weight,
           volume,
           serial_no,
           flag)
        values
          (p.Enterprise_No,
           p.warehouse_no,
           p.owner_no,
           p.billing_project,
           p.billing_type,
           'N', --c.group_no,
           trunc(dtBeginDate),
           trunc(dtEndDate),
           nvl(nQty, 0),
           nvl(nWeight, 0) / 1000, --转换为吨
           nvl(nVolume, 0) / 1000000, --转换为立方米
           seq_bill_expenses_list.nextval,
           '0');
         --更新基础费用清单费用产生标识
         update bill_base_amount bba set bba.flag='1' where bba.enterprise_no=strEnterprise_no
            and bba.warehouse_no=strWarehouse_no and bba.owner_no=strOwner_no
            and bba.billing_project=strBilling_project
            and bba.amount_date>=dtBeginDate
            and bba.amount_date<=dtEndDate;
      end loop;
      if intCount = 0 then
        strOutMsg := 'N|[设费项目设置错误，请核实!]';
        return;
      end if;
      strOutMsg := 'Y';
    exception
      when others then
        strOutMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
        return;
    END P_GCLD_DYNAMIC;

    /***********************************************************************************************
    wyf
    20150630
    功能说明：获取验收相关消费数据
    ***********************************************************************************************/
    procedure P_GETICGCLD(strEnterprise_no bill_formulaset.enterprise_no%type, --企业
                          strWarehouse_no  bill_formulaset.warehouse_no%type, --仓别
                          strOwner_no      bill_formulaset.owner_no%type, --货主
                          strBilling_unit  bill_formulaset.billing_unit%type, --计费单位
                          strValue_flag    bill_formulaset.Value_Flag%type, --取值方式
                          dtBeginDate      bill_formulaset.rgst_date%type, --开始日期
                          dtEndDate        bill_formulaset.rgst_date%type, --开始日期
                          strFamilyNo      bill_family_unit_price.family_no%type, --商品群组
                          nQty             OUT bill_expenses_list.qty%type, --数量
                          nVolume          OUT bill_expenses_list.volume%type, --体积
                          nWeight          OUT bill_expenses_list.weight%type, --重量
                          strOutMsg        out varchar2) --返回值
     IS
      --nValue bill_base_amount.value%type := 0; --基础消费值

      v_nQty    bill_expenses_list.qty%type; --数量
      v_nVolume bill_expenses_list.volume%type; --体积
      v_nWeight bill_expenses_list.weight%type; --重量
    BEGIN
      strOutMsg := 'N|[P_GETICGCLD]';
      /*    --获取基本费用清单数值
      if p.billing_cycle = '1' then
        select nvl(sum(a.value), 0)
          into nValue
          from bill_base_amount a
         where a.enterprise_no = p.enterprise_no
           and a.warehouse_no = p.warehouse_no
           and a.owner_no = p.owner_no
           and a.billing_project = p.billing_project
           and trunc(a.amount_date) = trunc(dtEndDate);
      elsif p.billing_cycle = '3' then
        select nvl(sum(a.value), 0)
          into nValue
          from bill_base_amount a
         where a.enterprise_no = p.enterprise_no
           and a.warehouse_no = p.warehouse_no
           and a.owner_no = p.owner_no
           and a.billing_project = p.billing_project
           and trunc(a.amount_date, 'MM') = trunc(dtEndDate, 'MM');
      else
        nValue := 0;
      end if;*/
      --计费单位：1-天；2-面积（平方米）3-托盘 4-件数 5-体积（立方米）6-重量（吨）,目前暂时支持4，5，6
      /********************************
      strFamilyNo 商品群组
      计费项目维护到商品群组
      则未维护的需要排除已维护的商品计算值
      有维护的直接按维护的商品计算值
      *********************************/
      if strBilling_unit = '4' then
        --件数
        if strFamilyNo = 'N' then
          select nvl(sum(ceil(b.check_qty / b.packing_qty)), 0)
            into v_nQty
            from idata_check_m a, idata_check_d b
           where a.check_no = b.check_no
             and a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and a.enterprise_no = strEnterprise_no
             and a.warehouse_no = strWarehouse_no
             and a.owner_no = strOwner_no
             and trunc(a.check_end_date) >= trunc(dtBeginDate)
             and trunc(a.check_end_date) <= trunc(dtEndDate)
             and a.status = '13'
             and not exists (select 1
                    from bdef_article_family_d d
                   where d.enterprise_no = b.enterprise_no
                     and d.owner_no = b.owner_no
                     and b.article_no = d.article_no);
        else
          select nvl(sum(ceil(b.check_qty / b.packing_qty)), 0)
            into v_nQty
            from idata_check_m a, idata_check_d b
           where a.check_no = b.check_no
             and a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and a.enterprise_no = strEnterprise_no
             and a.warehouse_no = strWarehouse_no
             and a.owner_no = strOwner_no
             and trunc(a.check_end_date) >= trunc(dtBeginDate)
             and trunc(a.check_end_date) <= trunc(dtEndDate)
             and a.status = '13'
             and exists (select 1
                    from bdef_article_family_d d
                   where d.enterprise_no = b.enterprise_no
                     and d.owner_no = b.owner_no
                     and b.article_no = d.article_no
                     and d.family_no = strFamilyNo);
        end if;
        if strValue_flag = '1' then
          nQty := v_nQty;
        elsif strValue_flag = '2' then
          nQty := v_nQty * v_nValue;
        end if;
      elsif strBilling_unit = '5' then
        --体积
        if strFamilyNo = 'N' then
          select nvl(sum(ceil(b.check_qty / b.packing_qty) * c.packing_volumn),
                     0)
            into v_nVolume
            from idata_check_m                a,
                 idata_check_d                b,
                 v_article_pack_volumn_weight c
           where a.check_no = b.check_no
             and a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and b.enterprise_no = c.enterprise_no
             and b.article_no = c.article_no
             and b.packing_qty = c.packing_qty
             and a.enterprise_no = strEnterprise_no
             and a.warehouse_no = strWarehouse_no
             and a.owner_no = strOwner_no
             and trunc(a.check_end_date) >= trunc(dtBeginDate)
             and trunc(a.check_end_date) <= trunc(dtEndDate)
             and a.status = '13'
             and not exists (select 1
                    from bdef_article_family_d d
                   where d.enterprise_no = b.enterprise_no
                     and d.owner_no = b.owner_no
                     and b.article_no = d.article_no);
        else
          select nvl(sum(ceil(b.check_qty / b.packing_qty) * c.packing_volumn),
                     0)
            into v_nVolume
            from idata_check_m                a,
                 idata_check_d                b,
                 v_article_pack_volumn_weight c
           where a.check_no = b.check_no
             and a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and b.enterprise_no = c.enterprise_no
             and b.article_no = c.article_no
             and b.packing_qty = c.packing_qty
             and a.enterprise_no = strEnterprise_no
             and a.warehouse_no = strWarehouse_no
             and a.owner_no = strOwner_no
             and trunc(a.check_end_date) >= trunc(dtBeginDate)
             and trunc(a.check_end_date) <= trunc(dtEndDate)
             and a.status = '13'
             and exists (select 1
                    from bdef_article_family_d d
                   where d.enterprise_no = b.enterprise_no
                     and d.owner_no = b.owner_no
                     and b.article_no = d.article_no
                     and d.family_no = strFamilyNo);
        end if;
        if strValue_flag = '1' then
          nVolume := v_nVolume;
        elsif strValue_flag = '2' then
          nVolume := v_nVolume * v_nValue;
        end if;
      elsif strBilling_unit = '6' then
        --重量（吨）
        if strFamilyNo = 'N' then
          select nvl(sum(ceil(b.check_qty / b.packing_qty) * c.packing_weight),
                     0)
            into v_nWeight
            from idata_check_m                a,
                 idata_check_d                b,
                 v_article_pack_volumn_weight c
           where a.check_no = b.check_no
             and a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and b.enterprise_no = c.enterprise_no
             and b.article_no = c.article_no
             and b.packing_qty = c.packing_qty
             and a.enterprise_no = strEnterprise_no
             and a.warehouse_no = strWarehouse_no
             and a.owner_no = strOwner_no
             and trunc(a.check_end_date) >= trunc(dtBeginDate)
             and trunc(a.check_end_date) <= trunc(dtEndDate)
             and a.status = '13'
             and not exists (select 1
                    from bdef_article_family_d d
                   where d.enterprise_no = b.enterprise_no
                     and d.owner_no = b.owner_no
                     and b.article_no = d.article_no);
        else
          select nvl(sum(ceil(b.check_qty / b.packing_qty) * c.packing_weight),
                     0)
            into v_nWeight
            from idata_check_m                a,
                 idata_check_d                b,
                 v_article_pack_volumn_weight c
           where a.check_no = b.check_no
             and a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and b.enterprise_no = c.enterprise_no
             and b.article_no = c.article_no
             and b.packing_qty = c.packing_qty
             and a.enterprise_no = strEnterprise_no
             and a.warehouse_no = strWarehouse_no
             and a.owner_no = strOwner_no
             and trunc(a.check_end_date) >= trunc(dtBeginDate)
             and trunc(a.check_end_date) <= trunc(dtEndDate)
             and a.status = '13'
             and exists (select 1
                    from bdef_article_family_d d
                   where d.enterprise_no = b.enterprise_no
                     and d.owner_no = b.owner_no
                     and b.article_no = d.article_no
                     and d.family_no = strFamilyNo);
        end if;
        if strValue_flag = '1' then
          nWeight := v_nWeight;
        elsif strValue_flag = '2' then
          nWeight := v_nWeight * v_nValue;
        end if;
      end if;
      strOutMsg := 'Y';
    exception
      when others then
        strOutMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
        return;
    END P_GETICGCLD;

    /***********************************************************************************************
    wyf
    20150630
    功能说明：获取上架相关消费数据
    ***********************************************************************************************/
    procedure P_GETINGCLD(strEnterprise_no bill_formulaset.enterprise_no%type, --企业
                          strWarehouse_no  bill_formulaset.warehouse_no%type, --仓别
                          strOwner_no      bill_formulaset.owner_no%type, --货主
                          strBilling_unit  bill_formulaset.billing_unit%type, --计费单位
                          strValue_flag    bill_formulaset.Value_Flag%type, --取值方式
                          dtBeginDate      bill_formulaset.rgst_date%type, --开始日期
                          dtEndDate        bill_formulaset.rgst_date%type, --开始日期
                          strFamilyNo      bill_family_unit_price.family_no%type, --商品群组
                          nQty             OUT bill_expenses_list.qty%type, --数量
                          nVolume          OUT bill_expenses_list.volume%type, --体积
                          nWeight          OUT bill_expenses_list.weight%type, --重量
                          strOutMsg        out varchar2) --返回值
     IS
      v_nQty    bill_expenses_list.qty%type; --数量
      v_nVolume bill_expenses_list.volume%type; --体积
      v_nWeight bill_expenses_list.weight%type; --重量
    BEGIN
      strOutMsg := 'N|[P_GETINGCLD]';
      --计费单位：1-天；2-面积（平方米）3-托盘 4-件数 5-体积（立方米）6-重量（吨）,目前暂时支持4，5，6
      /********************************
      strFamilyNo 商品群组
      计费项目维护到商品群组
      则未维护的需要排除已维护的商品计算值
      有维护的直接按维护的商品计算值
      *********************************/
      if strBilling_unit = '4' then
        --件数
        if strFamilyNo = 'N' then
          select nvl(sum(ceil(b.real_qty / b.packing_qty)), 0) qty
            into v_nQty
            from idata_instock_mhty a,
                 idata_instock_dhty b,
                 bdef_defarticle    c
           where a.instock_no = b.instock_no
             and a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and a.enterprise_no = c.enterprise_no
             and b.article_no = c.article_no
             and a.enterprise_no = strEnterprise_no
             and a.warehouse_no = strWarehouse_no
             and a.owner_no = strOwner_no
             and trunc(a.instock_date) >= trunc(dtBeginDate)
             and trunc(a.instock_date) <= trunc(dtEndDate)
             and a.status = '13'
             and not exists (select 1
                    from bdef_article_family_d d
                   where d.enterprise_no = b.enterprise_no
                     and d.owner_no = b.owner_no
                     and b.article_no = d.article_no);
        else
          select nvl(sum(ceil(b.real_qty / b.packing_qty)), 0) qty
            into v_nQty
            from idata_instock_mhty a,
                 idata_instock_dhty b,
                 bdef_defarticle    c
           where a.instock_no = b.instock_no
             and a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and a.enterprise_no = c.enterprise_no
             and b.article_no = c.article_no
             and a.enterprise_no = strEnterprise_no
             and a.warehouse_no = strWarehouse_no
             and a.owner_no = strOwner_no
             and trunc(a.instock_date) >= trunc(dtBeginDate)
             and trunc(a.instock_date) <= trunc(dtEndDate)
             and a.status = '13'
             and exists (select 1
                    from bdef_article_family_d d
                   where d.enterprise_no = b.enterprise_no
                     and d.owner_no = b.owner_no
                     and b.article_no = d.article_no
                     and d.family_no = strFamilyNo);
        end if;
        if strValue_flag = '1' then
          nQty := v_nQty;
        elsif strValue_flag = '2' then
          nQty := v_nQty * v_nValue;
        end if;
      elsif strBilling_unit = '5' then
        --体积
        if strFamilyNo = 'N' then
          select nvl(sum(ceil(b.real_qty / b.packing_qty) * c.packing_volumn),
                     0) volume
            into nVolume
            from idata_instock_mhty           a,
                 idata_instock_dhty           b,
                 v_article_pack_volumn_weight c
           where a.instock_no = b.instock_no
             and a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and b.enterprise_no = c.enterprise_no
             and b.article_no = c.article_no
             and b.packing_qty = c.packing_qty
             and a.enterprise_no = strEnterprise_no
             and a.warehouse_no = strWarehouse_no
             and a.owner_no = strOwner_no
             and trunc(a.instock_date) >= trunc(dtBeginDate)
             and trunc(a.instock_date) <= trunc(dtEndDate)
             and a.status = '13'
             and not exists (select 1
                    from bdef_article_family_d d
                   where d.enterprise_no = b.enterprise_no
                     and d.owner_no = b.owner_no
                     and b.article_no = d.article_no);
        else
          select nvl(sum(ceil(b.real_qty / b.packing_qty) * c.packing_volumn),
                     0) volume
            into nVolume
            from idata_instock_mhty           a,
                 idata_instock_dhty           b,
                 v_article_pack_volumn_weight c
           where a.instock_no = b.instock_no
             and a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and b.enterprise_no = c.enterprise_no
             and b.article_no = c.article_no
             and b.packing_qty = c.packing_qty
             and a.enterprise_no = strEnterprise_no
             and a.warehouse_no = strWarehouse_no
             and a.owner_no = strOwner_no
             and trunc(a.instock_date) >= trunc(dtBeginDate)
             and trunc(a.instock_date) <= trunc(dtEndDate)
             and a.status = '13'
             and exists (select 1
                    from bdef_article_family_d d
                   where d.enterprise_no = b.enterprise_no
                     and d.owner_no = b.owner_no
                     and b.article_no = d.article_no
                     and d.family_no = strFamilyNo);
        end if;
        if strValue_flag = '1' then
          nVolume := v_nVolume;
        elsif strValue_flag = '2' then
          nVolume := v_nVolume * v_nValue;
        end if;
      elsif strBilling_unit = '6' then
        --重量（吨）
        if strFamilyNo = 'N' then
          select nvl(sum(ceil(b.real_qty / b.packing_qty) * c.packing_weight),
                     0) weight
            into v_nWeight
            from idata_instock_mhty           a,
                 idata_instock_dhty           b,
                 v_article_pack_volumn_weight c
           where a.instock_no = b.instock_no
             and a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and b.enterprise_no = c.enterprise_no
             and b.article_no = c.article_no
             and b.packing_qty = c.packing_qty
             and a.enterprise_no = strEnterprise_no
             and a.warehouse_no = strWarehouse_no
             and a.owner_no = strOwner_no
             and trunc(a.instock_date) >= trunc(dtBeginDate)
             and trunc(a.instock_date) <= trunc(dtEndDate)
             and a.status = '13'
             and not exists (select 1
                    from bdef_article_family_d d
                   where d.enterprise_no = b.enterprise_no
                     and d.owner_no = b.owner_no
                     and b.article_no = d.article_no);
        else
          select nvl(sum(ceil(b.real_qty / b.packing_qty) * c.packing_weight),
                     0) weight
            into v_nWeight
            from idata_instock_mhty           a,
                 idata_instock_dhty           b,
                 v_article_pack_volumn_weight c
           where a.instock_no = b.instock_no
             and a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and b.enterprise_no = c.enterprise_no
             and b.article_no = c.article_no
             and b.packing_qty = c.packing_qty
             and a.enterprise_no = strEnterprise_no
             and a.warehouse_no = strWarehouse_no
             and a.owner_no = strOwner_no
             and trunc(a.instock_date) >= trunc(dtBeginDate)
             and trunc(a.instock_date) <= trunc(dtEndDate)
             and a.status = '13'
             and exists (select 1
                    from bdef_article_family_d d
                   where d.enterprise_no = b.enterprise_no
                     and d.owner_no = b.owner_no
                     and b.article_no = d.article_no
                     and d.family_no = strFamilyNo);
        end if;
        if strValue_flag = '1' then
          nWeight := v_nWeight;
        elsif strValue_flag = '2' then
          nWeight := v_nWeight * v_nValue;
        end if;
      end if;
      strOutMsg := 'Y';
    exception
      when others then
        strOutMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
        return;
    END P_GETINGCLD;

    /***********************************************************************************************
    wyf
    20150630
    功能说明：获取拣货相关消费数据
    ***********************************************************************************************/
    procedure P_GETHOGCLD(strEnterprise_no bill_formulaset.enterprise_no%type, --企业
                          strWarehouse_no  bill_formulaset.warehouse_no%type, --仓别
                          strOwner_no      bill_formulaset.owner_no%type, --货主
                          strBilling_unit  bill_formulaset.billing_unit%type, --计费单位
                          strValue_flag    bill_formulaset.Value_Flag%type, --取值方式
                          dtBeginDate      bill_formulaset.rgst_date%type, --开始日期
                          dtEndDate        bill_formulaset.rgst_date%type, --开始日期
                          strFamilyNo      bill_family_unit_price.family_no%type, --商品群组
                          nQty             OUT bill_expenses_list.qty%type, --数量
                          nVolume          OUT bill_expenses_list.volume%type, --体积
                          nWeight          OUT bill_expenses_list.weight%type, --重量
                          strOutMsg        out varchar2) --返回值
     IS
      v_nQty    bill_expenses_list.qty%type; --数量
      v_nVolume bill_expenses_list.volume%type; --体积
      v_nWeight bill_expenses_list.weight%type; --重量
    BEGIN
      strOutMsg := 'N|[P_GETHOGCLD]';

      --计费单位：1-天；2-面积（平方米）3-托盘 4-件数 5-体积（立方米）6-重量（吨）,目前暂时支持4，5，6
      if strBilling_unit = '4' then
        --件数
        if strFamilyNo = 'N' then
          select nvl(sum(ceil(b.real_qty / b.packing_qty)), 0) qty
            into v_nQty
            from odata_outstock_mhty a,
                 odata_outstock_dhty b,
                 bdef_defarticle     c
           where a.outstock_no = b.outstock_no
             and a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and a.outstock_type = '0'
             and b.enterprise_no = c.enterprise_no
             and b.article_no = c.article_no
             and a.enterprise_no = strEnterprise_no
             and a.warehouse_no = strWarehouse_no
             and a.owner_no = strOwner_no
             and trunc(a.operate_date) >= trunc(dtBeginDate)
             and trunc(a.operate_date) <= trunc(dtEndDate)
             and a.status = '13'
             and not exists (select 1
                    from bdef_article_family_d d
                   where d.enterprise_no = b.enterprise_no
                     and d.owner_no = b.owner_no
                     and b.article_no = d.article_no);
        else
          select nvl(sum(ceil(b.real_qty / b.packing_qty)), 0) qty
            into v_nQty
            from odata_outstock_mhty a,
                 odata_outstock_dhty b,
                 bdef_defarticle     c
           where a.outstock_no = b.outstock_no
             and a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and a.outstock_type = '0'
             and b.enterprise_no = c.enterprise_no
             and b.article_no = c.article_no
             and a.enterprise_no = strEnterprise_no
             and a.warehouse_no = strWarehouse_no
             and a.owner_no = strOwner_no
             and trunc(a.operate_date) >= trunc(dtBeginDate)
             and trunc(a.operate_date) <= trunc(dtEndDate)
             and a.status = '13'
             and exists (select 1
                    from bdef_article_family_d d
                   where d.enterprise_no = b.enterprise_no
                     and d.owner_no = b.owner_no
                     and b.article_no = d.article_no
                     and d.family_no = strFamilyNo);
        end if;
        if strValue_flag = '1' then
          nQty := v_nQty;
        elsif strValue_flag = '2' then
          nQty := v_nQty * v_nValue;
        end if;
      elsif strBilling_unit = '5' then
        --体积
        if strFamilyNo = 'N' then
          select nvl(sum(ceil(b.real_qty / b.packing_qty) * c.packing_volumn),
                     0) volume
            into nVolume
            from odata_outstock_mhty          a,
                 odata_outstock_dhty          b,
                 v_article_pack_volumn_weight c
           where a.outstock_no = b.outstock_no
             and a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and a.outstock_type = '0'
             and b.enterprise_no = c.enterprise_no
             and b.article_no = c.article_no
             and b.packing_qty = c.packing_qty
             and a.enterprise_no = strEnterprise_no
             and a.warehouse_no = strWarehouse_no
             and a.owner_no = strOwner_no
             and trunc(a.operate_date) >= trunc(dtBeginDate)
             and trunc(a.operate_date) <= trunc(dtEndDate)
             and a.status = '13'
             and not exists (select 1
                    from bdef_article_family_d d
                   where d.enterprise_no = b.enterprise_no
                     and d.owner_no = b.owner_no
                     and b.article_no = d.article_no);
        else
          select nvl(sum(ceil(b.real_qty / b.packing_qty) * c.packing_volumn),
                     0) volume
            into nVolume
            from odata_outstock_mhty          a,
                 odata_outstock_dhty          b,
                 v_article_pack_volumn_weight c
           where a.outstock_no = b.outstock_no
             and a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and a.outstock_type = '0'
             and b.enterprise_no = c.enterprise_no
             and b.article_no = c.article_no
             and b.packing_qty = c.packing_qty
             and a.enterprise_no = strEnterprise_no
             and a.warehouse_no = strWarehouse_no
             and a.owner_no = strOwner_no
             and trunc(a.operate_date) >= trunc(dtBeginDate)
             and trunc(a.operate_date) <= trunc(dtEndDate)
             and a.status = '13'
             and exists (select 1
                    from bdef_article_family_d d
                   where d.enterprise_no = b.enterprise_no
                     and d.owner_no = b.owner_no
                     and b.article_no = d.article_no
                     and d.family_no = strFamilyNo);
        end if;
        if strValue_flag = '1' then
          nVolume := v_nVolume;
        elsif strValue_flag = '2' then
          nVolume := v_nVolume * v_nValue;
        end if;
      elsif strBilling_unit = '6' then
        --重量（吨）
        if strFamilyNo = 'N' then
          select nvl(sum(ceil(b.real_qty / b.packing_qty) * c.packing_weight),
                     0) weight
            into v_nWeight
            from odata_outstock_mhty          a,
                 odata_outstock_dhty          b,
                 v_article_pack_volumn_weight c
           where a.outstock_no = b.outstock_no
             and a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and a.outstock_type = '0'
             and b.enterprise_no = c.enterprise_no
             and b.article_no = c.article_no
             and b.packing_qty = c.packing_qty
             and a.enterprise_no = strEnterprise_no
             and a.warehouse_no = strWarehouse_no
             and a.owner_no = strOwner_no
             and trunc(a.operate_date) >= trunc(dtBeginDate)
             and trunc(a.operate_date) <= trunc(dtEndDate)
             and a.status = '13'
             and not exists (select 1
                    from bdef_article_family_d d
                   where d.enterprise_no = b.enterprise_no
                     and d.owner_no = b.owner_no
                     and b.article_no = d.article_no);
        else
          select nvl(sum(ceil(b.real_qty / b.packing_qty) * c.packing_weight),
                     0) weight
            into v_nWeight
            from odata_outstock_mhty          a,
                 odata_outstock_dhty          b,
                 v_article_pack_volumn_weight c
           where a.outstock_no = b.outstock_no
             and a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and a.outstock_type = '0'
             and b.enterprise_no = c.enterprise_no
             and b.article_no = c.article_no
             and b.packing_qty = c.packing_qty
             and a.enterprise_no = strEnterprise_no
             and a.warehouse_no = strWarehouse_no
             and a.owner_no = strOwner_no
             and trunc(a.operate_date) >= trunc(dtBeginDate)
             and trunc(a.operate_date) <= trunc(dtEndDate)
             and a.status = '13'
             and exists (select 1
                    from bdef_article_family_d d
                   where d.enterprise_no = b.enterprise_no
                     and d.owner_no = b.owner_no
                     and b.article_no = d.article_no
                     and d.family_no = strFamilyNo);
        end if;
        if strValue_flag = '1' then
          nWeight := v_nWeight;
        elsif strValue_flag = '2' then
          nWeight := v_nWeight * v_nValue;
        end if;
      end if;
      strOutMsg := 'Y';
    exception
      when others then
        strOutMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
        return;
    END P_GETHOGCLD;

    /***********************************************************************************************
    wyf
    20150630
    功能说明：获取返配验收相关消费数据
    ***********************************************************************************************/
    procedure P_GETRICGCLD(strEnterprise_no bill_formulaset.enterprise_no%type, --企业
                           strWarehouse_no  bill_formulaset.warehouse_no%type, --仓别
                           strOwner_no      bill_formulaset.owner_no%type, --货主
                           strBilling_unit  bill_formulaset.billing_unit%type, --计费单位
                           strValue_flag    bill_formulaset.Value_Flag%type, --取值方式
                           dtBeginDate      bill_formulaset.rgst_date%type, --开始日期
                           dtEndDate        bill_formulaset.rgst_date%type, --开始日期
                           strFamilyNo      bill_family_unit_price.family_no%type, --商品群组
                           nQty             OUT bill_expenses_list.qty%type, --数量
                           nVolume          OUT bill_expenses_list.volume%type, --体积
                           nWeight          OUT bill_expenses_list.weight%type, --重量
                           strOutMsg        out varchar2) --返回值
     IS
      v_nQty    bill_expenses_list.qty%type; --数量
      v_nVolume bill_expenses_list.volume%type; --体积
      v_nWeight bill_expenses_list.weight%type; --重量
    BEGIN
      strOutMsg := 'N|[P_GETRICGCLD]';

      --计费单位：1-天；2-面积（平方米）3-托盘 4-件数 5-体积（立方米）6-重量（吨）,目前暂时支持4，5，6
      if strBilling_unit = '4' then
        --件数
        if strFamilyNo = 'N' then
          select nvl(sum(ceil(b.check_qty / b.packing_qty)), 0) qty
            into v_nQty
            from ridata_check_m a, ridata_check_d b, bdef_defarticle c
           where a.check_no = b.check_no
             and a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and b.enterprise_no = c.enterprise_no
             and b.article_no = c.article_no
             and a.enterprise_no = strEnterprise_no
             and a.warehouse_no = strWarehouse_no
             and a.owner_no = strOwner_no
             and trunc(a.check_end_date) >= trunc(dtBeginDate)
             and trunc(a.check_end_date) <= trunc(dtEndDate)
             and a.status = '13'
             and not exists (select 1
                    from bdef_article_family_d d
                   where d.enterprise_no = b.enterprise_no
                     and d.owner_no = b.owner_no
                     and b.article_no = d.article_no);
        else
          select nvl(sum(ceil(b.check_qty / b.packing_qty)), 0) qty
            into v_nQty
            from ridata_check_m a, ridata_check_d b, bdef_defarticle c
           where a.check_no = b.check_no
             and a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and b.enterprise_no = c.enterprise_no
             and b.article_no = c.article_no
             and a.enterprise_no = strEnterprise_no
             and a.warehouse_no = strWarehouse_no
             and a.owner_no = strOwner_no
             and trunc(a.check_end_date) >= trunc(dtBeginDate)
             and trunc(a.check_end_date) <= trunc(dtEndDate)
             and a.status = '13'
             and exists (select 1
                    from bdef_article_family_d d
                   where d.enterprise_no = b.enterprise_no
                     and d.owner_no = b.owner_no
                     and b.article_no = d.article_no
                     and d.family_no = strFamilyNo);
        end if;
        if strValue_flag = '1' then
          nQty := v_nQty;
        elsif strValue_flag = '2' then
          nQty := v_nQty * v_nValue;
        end if;
      elsif strBilling_unit = '5' then
        --体积
        if strFamilyNo = 'N' then
          select nvl(sum(ceil(b.check_qty / b.packing_qty) * c.packing_volumn),
                     0) volume
            into nVolume
            from ridata_check_m               a,
                 ridata_check_d               b,
                 v_article_pack_volumn_weight c
           where a.check_no = b.check_no
             and a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and b.enterprise_no = c.enterprise_no
             and b.article_no = c.article_no
             and b.packing_qty = c.packing_qty
             and a.enterprise_no = strEnterprise_no
             and a.warehouse_no = strWarehouse_no
             and a.owner_no = strOwner_no
             and trunc(a.check_end_date) >= trunc(dtBeginDate)
             and trunc(a.check_end_date) <= trunc(dtEndDate)
             and a.status = '13'
             and not exists (select 1
                    from bdef_article_family_d d
                   where d.enterprise_no = b.enterprise_no
                     and d.owner_no = b.owner_no
                     and b.article_no = d.article_no);
        else
          select nvl(sum(ceil(b.check_qty / b.packing_qty) * c.packing_volumn),
                     0) volume
            into nVolume
            from ridata_check_m               a,
                 ridata_check_d               b,
                 v_article_pack_volumn_weight c
           where a.check_no = b.check_no
             and a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and b.enterprise_no = c.enterprise_no
             and b.article_no = c.article_no
             and b.packing_qty = c.packing_qty
             and a.enterprise_no = strEnterprise_no
             and a.warehouse_no = strWarehouse_no
             and a.owner_no = strOwner_no
             and trunc(a.check_end_date) >= trunc(dtBeginDate)
             and trunc(a.check_end_date) <= trunc(dtEndDate)
             and a.status = '13'
             and exists (select 1
                    from bdef_article_family_d d
                   where d.enterprise_no = b.enterprise_no
                     and d.owner_no = b.owner_no
                     and b.article_no = d.article_no
                     and d.family_no = strFamilyNo);
        end if;
        if strValue_flag = '1' then
          nVolume := v_nVolume;
        elsif strValue_flag = '2' then
          nVolume := v_nVolume * v_nValue;
        end if;
      elsif strBilling_unit = '6' then
        --重量（吨）
        if strFamilyNo = 'N' then
          select nvl(sum(ceil(b.check_qty / b.packing_qty) * c.packing_weight),
                     0) weight
            into v_nWeight
            from ridata_check_m               a,
                 ridata_check_d               b,
                 v_article_pack_volumn_weight c
           where a.check_no = b.check_no
             and a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and b.enterprise_no = c.enterprise_no
             and b.article_no = c.article_no
             and b.packing_qty = c.packing_qty
             and a.enterprise_no = strEnterprise_no
             and a.warehouse_no = strWarehouse_no
             and a.owner_no = strOwner_no
             and trunc(a.check_end_date) >= trunc(dtBeginDate)
             and trunc(a.check_end_date) <= trunc(dtEndDate)
             and a.status = '13'
             and not exists (select 1
                    from bdef_article_family_d d
                   where d.enterprise_no = b.enterprise_no
                     and d.owner_no = b.owner_no
                     and b.article_no = d.article_no);
        else
          select nvl(sum(ceil(b.check_qty / b.packing_qty) * c.packing_weight),
                     0) weight
            into v_nWeight
            from ridata_check_m               a,
                 ridata_check_d               b,
                 v_article_pack_volumn_weight c
           where a.check_no = b.check_no
             and a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and b.enterprise_no = c.enterprise_no
             and b.article_no = c.article_no
             and b.packing_qty = c.packing_qty
             and a.enterprise_no = strEnterprise_no
             and a.warehouse_no = strWarehouse_no
             and a.owner_no = strOwner_no
             and trunc(a.check_end_date) >= trunc(dtBeginDate)
             and trunc(a.check_end_date) <= trunc(dtEndDate)
             and a.status = '13'
             and exists (select 1
                    from bdef_article_family_d d
                   where d.enterprise_no = b.enterprise_no
                     and d.owner_no = b.owner_no
                     and b.article_no = d.article_no
                     and d.family_no = strFamilyNo);
        end if;
        if strValue_flag = '1' then
          nWeight := v_nWeight;
        elsif strValue_flag = '2' then
          nWeight := v_nWeight * v_nValue;
        end if;
      end if;
      strOutMsg := 'Y';
    exception
      when others then
        strOutMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
        return;
    END P_GETRICGCLD;

    /***********************************************************************************************
    wyf
    20150630
    功能说明：获取装卸相关消费数据
    ***********************************************************************************************/
    procedure P_GETLOCGCLD(strEnterprise_no bill_formulaset.enterprise_no%type, --企业
                           strWarehouse_no  bill_formulaset.warehouse_no%type, --仓别
                           strOwner_no      bill_formulaset.owner_no%type, --货主
                           strBilling_unit  bill_formulaset.billing_unit%type, --计费单位
                           strValue_flag    bill_formulaset.Value_Flag%type, --取值方式
                           dtBeginDate      bill_formulaset.rgst_date%type, --开始日期
                           dtEndDate        bill_formulaset.rgst_date%type, --开始日期
                           strFamilyNo      bill_family_unit_price.family_no%type, --商品群组
                           nQty             OUT bill_expenses_list.qty%type, --数量
                           nVolume          OUT bill_expenses_list.volume%type, --体积
                           nWeight          OUT bill_expenses_list.weight%type, --重量
                           strOutMsg        out varchar2) --返回值
     IS
      nInQty    bill_expenses_list.qty%type; --卸货数量
      nInVolume bill_expenses_list.volume%type; --卸货体积
      nInWeight bill_expenses_list.weight%type; --卸货重量
      v_nQty    bill_expenses_list.qty%type; --数量
      v_nVolume bill_expenses_list.volume%type; --体积
      v_nWeight bill_expenses_list.weight%type; --重量
    BEGIN
      strOutMsg := 'N|[P_GETLOCGCLD]';
      --获取入库卸货数量
      P_GETICGCLD(strEnterprise_no,
                  strWarehouse_no,
                  strOwner_no,
                  strBilling_unit,
                  strValue_flag,
                  dtBeginDate,
                  dtEndDate,
                  strFamilyNo,
                  nInQty,
                  nInVolume,
                  nInWeight,
                  strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --计费单位：1-天；2-面积（平方米）3-托盘 4-件数 5-体积（立方米）6-重量（吨）,目前暂时支持4，5，6
      if strBilling_unit = '4' then
        --件数
        if strFamilyNo = 'N' then
          select nvl(sum(ceil(d.qty / d.packing_qty)), 0)
            into v_nQty
            from odata_loadpropose_m a,
                 odata_loadpropose_d b,
                 stock_label_mhty    c,
                 stock_label_dhty    d
           where a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and a.loadpropose_no = b.loadpropose_no
             and b.enterprise_no = c.enterprise_no
             and b.container_no = c.container_no
             and b.warehouse_no = c.warehouse_no
             and c.enterprise_no = d.enterprise_no
             and c.warehouse_no = d.warehouse_no
             and c.container_no = d.container_no
             and a.enterprise_no = strEnterprise_no
             and a.warehouse_no = strWarehouse_no
             and d.owner_no = strOwner_no
             and trunc(a.operate_date) >= trunc(dtBeginDate)
             and trunc(a.operate_date) <= trunc(dtEndDate)
             and a.status = '13'
             and not exists (select 1
                    from bdef_article_family_d s
                   where s.enterprise_no = d.enterprise_no
                     and s.owner_no = d.owner_no
                     and s.article_no = d.article_no);
        else
          select nvl(sum(ceil(d.qty / d.packing_qty)), 0)
            into v_nQty
            from odata_loadpropose_m a,
                 odata_loadpropose_d b,
                 stock_label_mhty    c,
                 stock_label_dhty    d
           where a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and a.loadpropose_no = b.loadpropose_no
             and b.enterprise_no = c.enterprise_no
             and b.container_no = c.container_no
             and b.warehouse_no = c.warehouse_no
             and c.enterprise_no = d.enterprise_no
             and c.warehouse_no = d.warehouse_no
             and c.container_no = d.container_no
             and a.enterprise_no = strEnterprise_no
             and a.warehouse_no = strWarehouse_no
             and d.owner_no = strOwner_no
             and trunc(a.operate_date) >= trunc(dtBeginDate)
             and trunc(a.operate_date) <= trunc(dtEndDate)
             and a.status = '13'
             and exists (select 1
                    from bdef_article_family_d s
                   where s.enterprise_no = d.enterprise_no
                     and s.owner_no = d.owner_no
                     and s.article_no = d.article_no
                     and s.family_no = strFamilyNo);
        end if;
        if strValue_flag = '1' then
          nQty := v_nQty + nInQty;
        elsif strValue_flag = '2' then
          nQty := (v_nQty + nInQty) * v_nValue;
        end if;
      elsif strBilling_unit = '5' then
        --体积
        if strFamilyNo = 'N' then
          select nvl(sum(ceil(d.qty / d.packing_qty) * e.packing_volumn), 0)
            into nVolume
            from odata_loadpropose_m          a,
                 odata_loadpropose_d          b,
                 stock_label_mhty             c,
                 stock_label_dhty             d,
                 v_article_pack_volumn_weight e
           where a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and a.loadpropose_no = b.loadpropose_no
             and b.enterprise_no = c.enterprise_no
             and b.container_no = c.container_no
             and b.warehouse_no = c.warehouse_no
             and c.enterprise_no = d.enterprise_no
             and c.warehouse_no = d.warehouse_no
             and c.container_no = d.container_no
             and d.enterprise_no = e.enterprise_no
             and d.article_no = e.article_no
             and d.packing_qty = e.packing_qty
             and a.enterprise_no = strEnterprise_no
             and a.warehouse_no = strWarehouse_no
             and d.owner_no = strOwner_no
             and trunc(a.operate_date) >= trunc(dtBeginDate)
             and trunc(a.operate_date) <= trunc(dtEndDate)
             and a.status = '13'
             and not exists (select 1
                    from bdef_article_family_d s
                   where s.enterprise_no = d.enterprise_no
                     and s.owner_no = d.owner_no
                     and s.article_no = d.article_no);
        else
          select nvl(sum(ceil(d.qty / d.packing_qty) * e.packing_volumn), 0)
            into nVolume
            from odata_loadpropose_m          a,
                 odata_loadpropose_d          b,
                 stock_label_mhty             c,
                 stock_label_dhty             d,
                 v_article_pack_volumn_weight e
           where a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and a.loadpropose_no = b.loadpropose_no
             and b.enterprise_no = c.enterprise_no
             and b.container_no = c.container_no
             and b.warehouse_no = c.warehouse_no
             and c.enterprise_no = d.enterprise_no
             and c.warehouse_no = d.warehouse_no
             and c.container_no = d.container_no
             and d.enterprise_no = e.enterprise_no
             and d.article_no = e.article_no
             and d.packing_qty = e.packing_qty
             and a.enterprise_no = strEnterprise_no
             and a.warehouse_no = strWarehouse_no
             and d.owner_no = strOwner_no
             and trunc(a.operate_date) >= trunc(dtBeginDate)
             and trunc(a.operate_date) <= trunc(dtEndDate)
             and a.status = '13'
             and exists (select 1
                    from bdef_article_family_d s
                   where s.enterprise_no = d.enterprise_no
                     and s.owner_no = d.owner_no
                     and s.article_no = d.article_no
                     and s.family_no = strFamilyNo);
        end if;
        if strValue_flag = '1' then
          nVolume := v_nVolume + nInVolume;
        elsif strValue_flag = '2' then
          nVolume := (v_nVolume + nInVolume) * v_nValue;
        end if;
      elsif strBilling_unit = '6' then
        --重量（吨）
        if strFamilyNo = 'N' then
          select nvl(sum(ceil(d.qty / d.packing_qty) * e.packing_weight), 0)
            into v_nWeight
            from odata_loadpropose_m          a,
                 odata_loadpropose_d          b,
                 stock_label_mhty             c,
                 stock_label_dhty             d,
                 v_article_pack_volumn_weight e
           where a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and a.loadpropose_no = b.loadpropose_no
             and b.enterprise_no = c.enterprise_no
             and b.container_no = c.container_no
             and b.warehouse_no = c.warehouse_no
             and c.enterprise_no = d.enterprise_no
             and c.warehouse_no = d.warehouse_no
             and c.container_no = d.container_no
             and d.enterprise_no = e.enterprise_no
             and d.article_no = e.article_no
             and d.packing_qty = e.packing_qty
             and a.enterprise_no = strEnterprise_no
             and a.warehouse_no = strWarehouse_no
             and d.owner_no = strOwner_no
             and trunc(a.operate_date) >= trunc(dtBeginDate)
             and trunc(a.operate_date) <= trunc(dtEndDate)
             and a.status = '13'
             and not exists (select 1
                    from bdef_article_family_d s
                   where s.enterprise_no = d.enterprise_no
                     and s.owner_no = d.owner_no
                     and s.article_no = d.article_no);
        else
          select nvl(sum(ceil(d.qty / d.packing_qty) * e.packing_weight), 0)
            into v_nWeight
            from odata_loadpropose_m          a,
                 odata_loadpropose_d          b,
                 stock_label_mhty             c,
                 stock_label_dhty             d,
                 v_article_pack_volumn_weight e
           where a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and a.loadpropose_no = b.loadpropose_no
             and b.enterprise_no = c.enterprise_no
             and b.container_no = c.container_no
             and b.warehouse_no = c.warehouse_no
             and c.enterprise_no = d.enterprise_no
             and c.warehouse_no = d.warehouse_no
             and c.container_no = d.container_no
             and d.enterprise_no = e.enterprise_no
             and d.article_no = e.article_no
             and d.packing_qty = e.packing_qty
             and a.enterprise_no = strEnterprise_no
             and a.warehouse_no = strWarehouse_no
             and d.owner_no = strOwner_no
             and trunc(a.operate_date) >= trunc(dtBeginDate)
             and trunc(a.operate_date) <= trunc(dtEndDate)
             and a.status = '13'
             and exists (select 1
                    from bdef_article_family_d s
                   where s.enterprise_no = d.enterprise_no
                     and s.owner_no = d.owner_no
                     and s.article_no = d.article_no
                     and s.family_no = strFamilyNo);
        end if;
        if strValue_flag = '1' then
          nWeight := v_nWeight + nInWeight;
        elsif strValue_flag = '2' then
          nWeight := (v_nWeight + nInWeight) * v_nValue;
        end if;
      end if;
      strOutMsg := 'Y';
    exception
      when others then
        strOutMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
        return;
    END P_GETLOCGCLD;

    /***********************************************************************************************
    wyf
    20150630
    功能说明：获取冷藏费相关消费数据
    ***********************************************************************************************/
    procedure P_GETLCFGCLD(strEnterprise_no bill_formulaset.enterprise_no%type, --企业
                           strWarehouse_no  bill_formulaset.warehouse_no%type, --仓别
                           strOwner_no      bill_formulaset.owner_no%type, --货主
                           strBilling_unit  bill_formulaset.billing_unit%type, --计费单位
                           strValue_flag    bill_formulaset.Value_Flag%type, --取值方式
                           dtBeginDate      bill_formulaset.rgst_date%type, --开始日期
                           dtEndDate        bill_formulaset.rgst_date%type, --开始日期
                           strFamilyNo      bill_family_unit_price.family_no%type, --商品群组
                           nQty             OUT bill_expenses_list.qty%type, --数量
                           nVolume          OUT bill_expenses_list.volume%type, --体积
                           nWeight          OUT bill_expenses_list.weight%type, --重量
                           strOutMsg        out varchar2) IS
      v_nQty    bill_expenses_list.qty%type; --数量
      v_nVolume bill_expenses_list.volume%type; --体积
      v_nWeight bill_expenses_list.weight%type; --重量
    BEGIN
      strOutMsg := 'N|[P_GETLCFGCLD]';

      --计费单位：1-天；2-面积（平方米）3-托盘 4-件数 5-体积（立方米）6-重量（吨）,目前暂时支持4，5，6
      if strBilling_unit = '4' then
        --件数
        if strFamilyNo = 'N' then
          select nvl(sum(ceil((d.qc_qty) / a.packing_qty)), 0)
            into v_nQty
            from stock_content_rj d, bdef_article_packing a
           where a.enterprise_no = d.enterprise_no
             and a.article_no = d.article_no
             and a.enterprise_no = strEnterprise_no
             and d.warehouse_no = strWarehouse_no
             and d.owner_no = strOwner_no
             and trunc(d.jc_date) >= trunc(dtBeginDate)
             and trunc(d.jc_date) <= trunc(dtEndDate)
             and (a.article_no, a.packing_qty) in
                 (select c.article_no, max(c.packing_qty)
                    from bdef_article_packing c
                   where a.article_no = c.article_no
                   group by c.article_no)
             and not exists (select 1
                    from bdef_article_family_d s
                   where s.enterprise_no = d.enterprise_no
                     and s.owner_no = d.owner_no
                     and s.article_no = d.article_no);
        else
          select nvl(sum(ceil((d.qc_qty) / a.packing_qty)), 0)
            into v_nQty
            from stock_content_rj d, bdef_article_packing a
           where a.enterprise_no = d.enterprise_no
             and a.article_no = d.article_no
             and a.enterprise_no = strEnterprise_no
             and d.warehouse_no = strWarehouse_no
             and d.owner_no = strOwner_no
             and trunc(d.jc_date) >= trunc(dtBeginDate)
             and trunc(d.jc_date) <= trunc(dtEndDate)
             and (a.article_no, a.packing_qty) in
                 (select c.article_no, max(c.packing_qty)
                    from bdef_article_packing c
                   where a.article_no = c.article_no
                   group by c.article_no)
             and exists (select 1
                    from bdef_article_family_d s
                   where s.enterprise_no = d.enterprise_no
                     and s.owner_no = d.owner_no
                     and s.article_no = d.article_no
                     and s.family_no = strFamilyNo);
        end if;
        if strValue_flag = '1' then
          nQty := v_nQty;
        elsif strValue_flag = '2' then
          nQty := v_nQty * v_nValue;
        end if;
      elsif strBilling_unit = '5' then
        --体积
        if strFamilyNo = 'N' then
          select nvl(sum(ceil((d.qc_qty) / a.packing_qty) * e.packing_volumn),
                     0)
            into nVolume
            from stock_content_rj             d,
                 bdef_article_packing         a,
                 v_article_pack_volumn_weight e
           where a.enterprise_no = d.enterprise_no
             and a.article_no = d.article_no
             and a.enterprise_no = e.enterprise_no
             and a.article_no = e.article_no
             and a.packing_qty = e.packing_qty
             and a.enterprise_no = strEnterprise_no
             and d.warehouse_no = strWarehouse_no
             and d.owner_no = strOwner_no
             and trunc(d.jc_date) >= trunc(dtBeginDate)
             and trunc(d.jc_date) <= trunc(dtEndDate)
             and (a.article_no, a.packing_qty) in
                 (select c.article_no, max(c.packing_qty)
                    from bdef_article_packing c
                   where a.article_no = c.article_no
                   group by c.article_no)
             and not exists (select 1
                    from bdef_article_family_d s
                   where s.enterprise_no = d.enterprise_no
                     and s.owner_no = d.owner_no
                     and s.article_no = d.article_no);
        else
          select nvl(sum(ceil((d.qc_qty) / a.packing_qty) * e.packing_volumn),
                     0)
            into nVolume
            from stock_content_rj             d,
                 bdef_article_packing         a,
                 v_article_pack_volumn_weight e
           where a.enterprise_no = d.enterprise_no
             and a.article_no = d.article_no
             and a.enterprise_no = e.enterprise_no
             and a.article_no = e.article_no
             and a.packing_qty = e.packing_qty
             and a.enterprise_no = strEnterprise_no
             and d.warehouse_no = strWarehouse_no
             and d.owner_no = strOwner_no
             and trunc(d.jc_date) >= trunc(dtBeginDate)
             and trunc(d.jc_date) <= trunc(dtEndDate)
             and (a.article_no, a.packing_qty) in
                 (select c.article_no, max(c.packing_qty)
                    from bdef_article_packing c
                   where a.article_no = c.article_no
                   group by c.article_no)
             and exists (select 1
                    from bdef_article_family_d s
                   where s.enterprise_no = d.enterprise_no
                     and s.owner_no = d.owner_no
                     and s.article_no = d.article_no
                     and s.family_no = strFamilyNo);
        end if;
        if strValue_flag = '1' then
          nVolume := v_nVolume;
        elsif strValue_flag = '2' then
          nVolume := v_nVolume * v_nValue;
        end if;
      elsif strBilling_unit = '6' then
        --重量（吨）
        if strFamilyNo = 'N' then
          select nvl(sum(ceil((d.qc_qty) / a.packing_qty) * e.packing_weight),
                     0)
            into v_nWeight
            from stock_content_rj             d,
                 bdef_article_packing         a,
                 v_article_pack_volumn_weight e
           where a.enterprise_no = d.enterprise_no
             and a.article_no = d.article_no
             and a.enterprise_no = e.enterprise_no
             and a.article_no = e.article_no
             and a.packing_qty = e.packing_qty
             and a.enterprise_no = strEnterprise_no
             and d.warehouse_no = strWarehouse_no
             and d.owner_no = strOwner_no
             and trunc(d.jc_date) >= trunc(dtBeginDate)
             and trunc(d.jc_date) <= trunc(dtEndDate)
             and (a.article_no, a.packing_qty) in
                 (select c.article_no, max(c.packing_qty)
                    from bdef_article_packing c
                   where a.article_no = c.article_no
                   group by c.article_no)
             and not exists (select 1
                    from bdef_article_family_d s
                   where s.enterprise_no = d.enterprise_no
                     and s.owner_no = d.owner_no
                     and s.article_no = d.article_no);
        else
          select nvl(sum(ceil((d.qc_qty) / a.packing_qty) * e.packing_weight),
                     0)
            into v_nWeight
            from stock_content_rj             d,
                 bdef_article_packing         a,
                 v_article_pack_volumn_weight e
           where a.enterprise_no = d.enterprise_no
             and a.article_no = d.article_no
             and a.enterprise_no = e.enterprise_no
             and a.article_no = e.article_no
             and a.packing_qty = e.packing_qty
             and a.enterprise_no = strEnterprise_no
             and d.warehouse_no = strWarehouse_no
             and d.owner_no = strOwner_no
             and trunc(d.jc_date) >= trunc(dtBeginDate)
             and trunc(d.jc_date) <= trunc(dtEndDate)
             and (a.article_no, a.packing_qty) in
                 (select c.article_no, max(c.packing_qty)
                    from bdef_article_packing c
                   where a.article_no = c.article_no
                   group by c.article_no)
             and exists (select 1
                    from bdef_article_family_d s
                   where s.enterprise_no = d.enterprise_no
                     and s.owner_no = d.owner_no
                     and s.article_no = d.article_no
                     and s.family_no = strFamilyNo);
        end if;
        if strValue_flag = '1' then
          nWeight := v_nWeight;
        elsif strValue_flag = '2' then
          nWeight := v_nWeight * v_nValue;
        end if;
      end if;
      strOutMsg := 'Y';
    exception
      when others then
        strOutMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
        return;
    END P_GETLCFGCLD;

    /***********************************************************************************************
    lich
    20140729
    功能说明：仓租根据取值策略生成消费清单
    ***********************************************************************************************/
    procedure P_ALLGCLD(strEnterprise_no bill_formulaset.enterprise_no%type, --企业
                        strWarehouse_no  bill_formulaset.warehouse_no%type, --仓别
                        strOwner_no      bill_formulaset.owner_no%type, --货主
                        strBilling_unit  bill_formulaset.billing_unit%type, --计费单位
                        strValue_flag    bill_formulaset.Value_Flag%type, --取值方式
                        dtBeginDate      bill_formulaset.rgst_date%type, --开始日期
                        dtEndDate        bill_formulaset.rgst_date%type, --开始日期
                        strFamilyNo      bill_family_unit_price.family_no%type, --商品群组
                        nQty             OUT bill_expenses_list.qty%type, --数量
                        nVolume          OUT bill_expenses_list.volume%type, --体积
                        nWeight          OUT bill_expenses_list.weight%type, --重量
                        strOutMsg        out varchar2) --返回值
     IS
      v_nQty    bill_expenses_list.qty%type; --数量
      v_nVolume bill_expenses_list.volume%type; --体积
      v_nWeight bill_expenses_list.weight%type; --重量
    BEGIN
      strOutMsg := 'N|[P_ALLGCLD]';
      --计费单位：1-天；2-面积（平方米）3-托盘 4-件数 5-体积（立方米）6-重量（吨）,目前暂时支持4，5，6
      if strBilling_unit = '4' then
        --件数
        if strFamilyNo = 'N' then
          select nvl(sum(ceil((d.qc_qty) / a.packing_qty)), 0)
            into v_nQty
            from stock_content_rj d, bdef_article_packing a
           where a.enterprise_no = d.enterprise_no
             and a.article_no = d.article_no
             and a.enterprise_no = strEnterprise_no
             and d.warehouse_no = strWarehouse_no
             and d.owner_no = strOwner_no
             and trunc(d.jc_date) >= trunc(dtBeginDate)
             and trunc(d.jc_date) <= trunc(dtEndDate)
             and (a.article_no, a.packing_qty) in
                 (select c.article_no, max(c.packing_qty)
                    from bdef_article_packing c
                   where a.article_no = c.article_no
                   group by c.article_no)
             and not exists (select 1
                    from bdef_article_family_d s
                   where s.enterprise_no = d.enterprise_no
                     and s.owner_no = d.owner_no
                     and s.article_no = d.article_no);
        else
          select nvl(sum(ceil((d.qc_qty) / a.packing_qty)), 0)
            into v_nQty
            from stock_content_rj d, bdef_article_packing a
           where a.enterprise_no = d.enterprise_no
             and a.article_no = d.article_no
             and a.enterprise_no = strEnterprise_no
             and d.warehouse_no = strWarehouse_no
             and d.owner_no = strOwner_no
             and trunc(d.jc_date) >= trunc(dtBeginDate)
             and trunc(d.jc_date) <= trunc(dtEndDate)
             and (a.article_no, a.packing_qty) in
                 (select c.article_no, max(c.packing_qty)
                    from bdef_article_packing c
                   where a.article_no = c.article_no
                   group by c.article_no)
             and exists (select 1
                    from bdef_article_family_d s
                   where s.enterprise_no = d.enterprise_no
                     and s.owner_no = d.owner_no
                     and s.article_no = d.article_no
                     and s.family_no = strFamilyNo);
        end if;
        if strValue_flag = '1' then
          nQty := v_nQty;
        elsif strValue_flag = '2' then
          nQty := v_nQty * v_nValue;
        end if;
      elsif strBilling_unit = '5' then
        --体积
        if strFamilyNo = 'N' then
          select nvl(sum(ceil((d.qc_qty) / a.packing_qty) * e.packing_volumn),
                     0)
            into nVolume
            from stock_content_rj             d,
                 bdef_article_packing         a,
                 v_article_pack_volumn_weight e
           where a.enterprise_no = d.enterprise_no
             and a.article_no = d.article_no
             and a.enterprise_no = e.enterprise_no
             and a.article_no = e.article_no
             and a.packing_qty = e.packing_qty
             and a.enterprise_no = strEnterprise_no
             and d.warehouse_no = strWarehouse_no
             and d.owner_no = strOwner_no
             and trunc(d.jc_date) >= trunc(dtBeginDate)
             and trunc(d.jc_date) <= trunc(dtEndDate)
             and (a.article_no, a.packing_qty) in
                 (select c.article_no, max(c.packing_qty)
                    from bdef_article_packing c
                   where a.article_no = c.article_no
                   group by c.article_no)
             and not exists (select 1
                    from bdef_article_family_d s
                   where s.enterprise_no = d.enterprise_no
                     and s.owner_no = d.owner_no
                     and s.article_no = d.article_no);
        else
          select nvl(sum(ceil((d.qc_qty) / a.packing_qty) * e.packing_volumn),
                     0)
            into nVolume
            from stock_content_rj             d,
                 bdef_article_packing         a,
                 v_article_pack_volumn_weight e
           where a.enterprise_no = d.enterprise_no
             and a.article_no = d.article_no
             and a.enterprise_no = e.enterprise_no
             and a.article_no = e.article_no
             and a.packing_qty = e.packing_qty
             and a.enterprise_no = strEnterprise_no
             and d.warehouse_no = strWarehouse_no
             and d.owner_no = strOwner_no
             and trunc(d.jc_date) >= trunc(dtBeginDate)
             and trunc(d.jc_date) <= trunc(dtEndDate)
             and (a.article_no, a.packing_qty) in
                 (select c.article_no, max(c.packing_qty)
                    from bdef_article_packing c
                   where a.article_no = c.article_no
                   group by c.article_no)
             and exists (select 1
                    from bdef_article_family_d s
                   where s.enterprise_no = d.enterprise_no
                     and s.owner_no = d.owner_no
                     and s.article_no = d.article_no
                     and s.family_no = strFamilyNo);
        end if;
        if strValue_flag = '1' then
          nVolume := v_nVolume;
        elsif strValue_flag = '2' then
          nVolume := v_nVolume * v_nValue;
        end if;
      elsif strBilling_unit = '6' then
        --重量（吨）
        if strFamilyNo = 'N' then
          select nvl(sum(ceil((d.qc_qty) / a.packing_qty) * e.packing_weight),
                     0)
            into v_nWeight
            from stock_content_rj             d,
                 bdef_article_packing         a,
                 v_article_pack_volumn_weight e
           where a.enterprise_no = d.enterprise_no
             and a.article_no = d.article_no
             and a.enterprise_no = e.enterprise_no
             and a.article_no = e.article_no
             and a.packing_qty = e.packing_qty
             and a.enterprise_no = strEnterprise_no
             and d.warehouse_no = strWarehouse_no
             and d.owner_no = strOwner_no
             and trunc(d.jc_date) >= trunc(dtBeginDate)
             and trunc(d.jc_date) <= trunc(dtEndDate)
             and (a.article_no, a.packing_qty) in
                 (select c.article_no, max(c.packing_qty)
                    from bdef_article_packing c
                   where a.article_no = c.article_no
                   group by c.article_no)
             and not exists (select 1
                    from bdef_article_family_d s
                   where s.enterprise_no = d.enterprise_no
                     and s.owner_no = d.owner_no
                     and s.article_no = d.article_no);
        else
          select nvl(sum(ceil((d.qc_qty) / a.packing_qty) * e.packing_weight),
                     0)
            into v_nWeight
            from stock_content_rj             d,
                 bdef_article_packing         a,
                 v_article_pack_volumn_weight e
           where a.enterprise_no = d.enterprise_no
             and a.article_no = d.article_no
             and a.enterprise_no = e.enterprise_no
             and a.article_no = e.article_no
             and a.packing_qty = e.packing_qty
             and a.enterprise_no = strEnterprise_no
             and d.warehouse_no = strWarehouse_no
             and d.owner_no = strOwner_no
             and trunc(d.jc_date) >= trunc(dtBeginDate)
             and trunc(d.jc_date) <= trunc(dtEndDate)
             and (a.article_no, a.packing_qty) in
                 (select c.article_no, max(c.packing_qty)
                    from bdef_article_packing c
                   where a.article_no = c.article_no
                   group by c.article_no)
             and exists (select 1
                    from bdef_article_family_d s
                   where s.enterprise_no = d.enterprise_no
                     and s.owner_no = d.owner_no
                     and s.article_no = d.article_no
                     and s.family_no = strFamilyNo);
        end if;
        if strValue_flag = '1' then
          nWeight := v_nWeight;
        elsif strValue_flag = '2' then
          nWeight := v_nWeight * v_nValue;
        end if;
      end if;
      strOutMsg := 'Y';
    exception
      when others then
        strOutMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
        return;
    END P_ALLGCLD;
    /***********************************************************************************************
    lich
    20140729
    功能说明：根据消费清单生成费用明细表
    ***********************************************************************************************/
    procedure P_GENERATE_COST_DETAILS(strEnterprise_no bill_formulaset.enterprise_no%type, --企业
                                      strWarehouse_no  bill_formulaset.warehouse_no%type, --仓别
                                      strOwner_no      bill_formulaset.owner_no%type, --货主
                                      dtBilling_date   bill_formulaset.rgst_date%type, --开始日期
                                      strOutMsg        out varchar2) --返回值
     IS
      nTempQty bill_expenses_list.qty%type;
      nRealQty bill_expenses_list.qty%type;
      v_count number;
    BEGIN
      strOutMsg := 'N|[P_Generate_Cost_Details]';
      v_count := 0;
      for p in (select a.*,
                       b.unit_price,
                       b.billing_cycle,
                       b.billing_unit,
                       b.append_condition,
                       nvl(b.append_value1, 0) append_value1,
                       nvl(b.append_value2, 0) append_value2
                  from bill_expenses_list a, bill_formulaset b
                 where a.enterprise_no = b.enterprise_no
                   and a.warehouse_no = b.warehouse_no
                   and a.owner_no = b.owner_no
                   and a.billing_project = b.billing_project
                   and a.billing_type = b.billing_type
                   and a.enterprise_no = strEnterprise_no
                   and a.warehouse_no = strWarehouse_no
                   and a.owner_no = strOwner_no
                   and a.end_date = dtBilling_date) loop
        --检查要重算的费用是否上缴或取消
        select count(1) into v_count
                  from bill_cost_list bcl
                 where bcl.enterprise_no=p.enterprise_no
                   and bcl.warehouse_no=p.warehouse_no
                   and bcl.owner_no=p.owner_no
                   and bcl.billing_project=p.billing_project
                   and trunc(bcl.billing_date)=trunc(dtBilling_date)
                   and bcl.status>'10';
        if v_count=0 then
          --计费单位：1-天；2-面积（平方米）3-托盘 4-件数 5-体积（立方米）6-重量（吨）,目前暂时支持4，5，6
          if p.billing_unit = '4' then
             nTempQty := p.qty;
          elsif p.billing_unit = '5' then
             nTempQty := p.volume;
          elsif p.billing_unit = '6' then
             nTempQty := p.weight;
          else
             nTempQty := p.qty;
          end if;
          --未计算附件条件
          nRealQty := nTempQty;

          --附加条件（0：无）
          if p.append_condition = '1' then
             --1：只对超出“附加条件值1”部分计费
             if nTempQty > p.append_value1 then
                nRealQty := nTempQty - p.append_value1;
             else
                nRealQty := 0;
             end if;
             elsif p.append_condition = '2' then
                --2：不足“附加条件值1”按“附加条件值1”算
                if nTempQty < p.append_value1 then
                   nRealQty := p.append_value1;
                end if;
             elsif p.append_condition = '3' then
                --3：结果超出“附加条件值1”按“附加条件值2”打折
                if nTempQty > p.append_value1 then
                   nRealQty := nTempQty * p.append_value2;
                end if;
             end if;
             --先删除
             delete from bill_cost_list a
              where a.enterprise_no = p.enterprise_no
                and a.warehouse_no = p.warehouse_no
                and a.owner_no = p.owner_no
                and a.billing_project = p.billing_project
                and a.billing_date = dtBilling_date;

             --费用明细表
             insert into bill_cost_list
                  (enterprise_no,
                   warehouse_no,
                   owner_no,
                   billing_project,
                   billing_unit,
                   unit_price,
                   billing_date,
                   amount,
                   serial_no,
                   append_condition,
                   append_value1,
                   append_value2,
                   qty)
              values
                  (strEnterprise_no,
                   strWarehouse_no,
                   strOwner_no,
                   p.billing_project,
                   p.billing_unit,
                   p.unit_price,
                   trunc(dtBilling_date),
                   nRealQty * p.unit_price,
                   p.serial_no,
                   p.append_condition,
                   p.append_value2,
                   p.append_value2,
                   nRealQty);
        else
            goto over;
        end if;
        <<over>>
          null;
      end loop;
      strOutMsg := 'Y';
    exception
      when others then
        strOutMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
        return;
    END P_GENERATE_COST_DETAILS;
    /***********************************************************************************************
    lich
    20140729
    功能说明：根据消费清单生成账单
    ***********************************************************************************************/
    procedure P_GENERATE_FINANCIAL_DETAILS(strEnterprise_no bill_formulaset.enterprise_no%type, --企业
                                           strWarehouse_no  bill_formulaset.warehouse_no%type, --仓别
                                           strOwner_no      bill_formulaset.owner_no%type, --货主
                                           strMonth         varchar, --月份
                                           strOutMsg        out varchar2) --返回值
     IS
      v_nAmount            bill_cost_list.amount%type; --按消费清单算出的金额
      v_nDiscountAmount    bill_cost_list.amount%type; --优惠后的金额
      v_nDiscountProAmount bill_cost_list.amount%type; --优惠计费项目的金额
      nRowID               NUMBER; --行号
      nMidValue            NUMBER; --中间值
      nMidDisAmount        NUMBER; --优惠金额
      strMidPro            VARCHAR2(3000);
      strMidFlag           VARCHAR2(3000);
    BEGIN
      strOutMsg := 'N|[P_Generate_Financial_Details]';
      for p in (select distinct a.*
                  from bill_account_m a, bill_account_d b
                 where a.enterprise_no = b.enterprise_no
                   and a.warehouse_no = b.warehouse_no
                   and a.owner_no = b.owner_no
                   and a.account_no = b.account_no
                   and a.enterprise_no = strEnterprise_no
                   and a.warehouse_no = strWarehouse_no
                   and a.owner_no = strOwner_no) loop
        --删除
        delete from bill_financial a
         where a.enterprise_no = p.enterprise_no
           and a.warehouse_no = p.warehouse_no
           and a.owner_no = p.owner_no
           and a.account_no = p.account_no
           and a.billing_month = strMonth;

        select nvl(sum(a.amount), 0)
          into v_nAmount
          from bill_cost_list a, bill_account_d b
         where a.enterprise_no = b.enterprise_no
           and a.warehouse_no = b.warehouse_no
           and a.owner_no = b.owner_no
           and a.billing_project = b.billing_project
           and b.enterprise_no = p.enterprise_no
           and b.warehouse_no = p.warehouse_no
           and b.owner_no = p.owner_no
           and b.account_no = p.account_no
           and to_char(a.billing_date, 'yyyymm') = strMonth
           and a.flag = 0;
        v_nDiscountAmount := v_nAmount;
        nMidDisAmount     := 0;
        nMidValue         := v_nAmount;
        strMidPro         := ' ';
        strMidFlag        := ' ';
        --获取科目定义表 根据优惠阶梯计算优惠后价格
        nRowID := 0;
        for L in ( --获取科目定义表需要按优惠阶梯排序升序
                  select *
                    from bill_account a
                   where a.enterprise_no = p.enterprise_no
                     and a.warehouse_no = p.warehouse_no
                     and a.owner_no = p.owner_no
                     and a.account_no = p.account_no
                   order by a.ACCOUNT_LADDER desc) loop
          nRowID := nRowID + 1;
          if L.DISCOUNT_FLAG = '1' then
            --1  超出“值1”按“值2”打折
            if v_nAmount > L.VALUE1 then
              if nvl(instr(strMidFlag, '#' || L.DISCOUNT_FLAG || '#'), 0) = 0 then
                v_nDiscountAmount := v_nDiscountAmount * L.VALUE2;
                strMidFlag        := strMidFlag || '#' || L.DISCOUNT_FLAG || '#';
              end if;
            end if;
          elsif L.DISCOUNT_FLAG = '2' then
            --2  超出“值1”送“值2”
            if v_nAmount > L.VALUE1 then
              if nvl(instr(strMidFlag, '#' || L.DISCOUNT_FLAG || '#'), 0) = 0 then
                v_nDiscountAmount := v_nDiscountAmount - L.VALUE2;
                strMidFlag        := strMidFlag || '#' || L.DISCOUNT_FLAG || '#';
              end if;
            end if;
          elsif L.DISCOUNT_FLAG = '3' then
            --3  超出“值1”送“优惠计费项目”
            if v_nAmount > L.VALUE1 then
              if nvl(instr(strMidPro, '#' || L.discount_account_no || '#'), 0) = 0 then
                select nvl(sum(a.amount), 0)
                  into v_nDiscountProAmount
                  from bill_cost_list a, bill_account_d b
                 where a.enterprise_no = b.enterprise_no
                   and a.warehouse_no = b.warehouse_no
                   and a.owner_no = b.owner_no
                   and a.billing_project = b.billing_project
                   and b.enterprise_no = p.enterprise_no
                   and b.warehouse_no = p.warehouse_no
                   and b.owner_no = p.owner_no
                   and b.account_no = p.account_no
                   and to_char(a.billing_date, 'yyyymm') = strMonth
                   and b.billing_project = L.discount_account_no
                   and a.flag = 0;

                v_nDiscountAmount := v_nDiscountAmount - v_nDiscountProAmount;

                strMidPro := strMidPro || '#' || L.DISCOUNT_ACCOUNT_NO || '#';
              end if;
            end if;
          elsif L.DISCOUNT_FLAG = '4' then
            --4  超出“值1”，“优惠计费项目”按“值2”打折
            if v_nAmount > L.VALUE1 then
              if instr(strMidPro, '#' || L.discount_account_no || '#') = 0 then
                select nvl(sum(a.amount), 0)
                  into v_nDiscountProAmount
                  from bill_cost_list a, bill_account_d b
                 where a.enterprise_no = b.enterprise_no
                   and a.warehouse_no = b.warehouse_no
                   and a.owner_no = b.owner_no
                   and a.billing_project = b.billing_project
                   and b.enterprise_no = p.enterprise_no
                   and b.warehouse_no = p.warehouse_no
                   and b.owner_no = p.owner_no
                   and b.account_no = p.account_no
                   and to_char(a.billing_date, 'yyyymm') = strMonth
                   and b.billing_project = L.discount_account_no
                   and a.flag = 0;

                v_nDiscountAmount := v_nDiscountAmount -
                                     v_nDiscountProAmount * (1 - L.VALUE2);

                strMidPro := strMidPro || '#' || L.DISCOUNT_ACCOUNT_NO || '#';
              end if;
            end if;
          elsif L.DISCOUNT_FLAG = '5' then
            --5  超出“值1”的部分，按“值2”打折
            if v_nAmount > L.VALUE1 then
              nMidDisAmount     := nMidDisAmount +
                                   (nMidValue - L.VALUE1) * L.VALUE2;
              v_nDiscountAmount := v_nAmount - nMidDisAmount;
            end if;
          end if;
          nMidValue := L.VALUE1;
        end loop;

        --未设置科目定义表 则直接按科目定义头档表的优惠方式计算优惠后价格
        if nRowID = 0 then
          --优惠方式
          --0：无
          if p.discount_flag = '0' or p.discount_flag is null then
            v_nDiscountAmount := v_nAmount;
          elsif p.discount_flag = '1' then
            --1：直接按“值1”打折
            v_nDiscountAmount := v_nAmount * p.value1;
          elsif p.discount_flag = '2' then
            --2：超出“值1”按“值2”打折
            if v_nAmount > p.value1 then
              v_nDiscountAmount := v_nAmount * p.value2;
            end if;
          elsif p.discount_flag = '3' then
            --3：超出“值1”送“值2”
            if v_nAmount > p.value1 then
              v_nDiscountAmount := v_nAmount - p.value2;
            end if;
          elsif p.discount_flag = '4' then
            --4：超出“值1”送“优惠项目代码”
            if v_nAmount > p.value1 then
              select nvl(sum(a.amount), 0)
                into v_nDiscountProAmount
                from bill_cost_list a, bill_account_d b
               where a.enterprise_no = b.enterprise_no
                 and a.warehouse_no = b.warehouse_no
                 and a.owner_no = b.owner_no
                 and a.billing_project = b.billing_project
                 and b.enterprise_no = p.enterprise_no
                 and b.warehouse_no = p.warehouse_no
                 and b.owner_no = p.owner_no
                 and b.account_no = p.account_no
                 and to_char(a.billing_date, 'yyyymm') = strMonth
                 and b.billing_project = p.discount_account_no
                 and a.flag = 0;
              v_nDiscountAmount := v_nAmount - v_nDiscountProAmount;
            end if;
          elsif p.discount_flag = '5' then
            --5：超出“值1”，“优惠项目代码”按“值2”打折）
            if v_nAmount > p.value1 then
              select nvl(sum(a.amount), 0)
                into v_nDiscountProAmount
                from bill_cost_list a, bill_account_d b
               where a.enterprise_no = b.enterprise_no
                 and a.warehouse_no = b.warehouse_no
                 and a.owner_no = b.owner_no
                 and a.billing_project = b.billing_project
                 and b.enterprise_no = p.enterprise_no
                 and b.warehouse_no = p.warehouse_no
                 and b.owner_no = p.owner_no
                 and b.account_no = p.account_no
                 and to_char(a.billing_date, 'yyyymm') = strMonth
                 and b.billing_project = p.discount_account_no
                 and a.flag = 0;
              v_nDiscountAmount := v_nAmount -
                                   v_nDiscountProAmount * (1 - p.value2);
            end if;
          end if;
        end if;
        --写入财务表
        insert into bill_financial
          (enterprise_no,
           warehouse_no,
           owner_no,
           billing_month,
           account_no,
           amount,
           discount_amount)
        values
          (p.enterprise_no,
           p.warehouse_no,
           p.owner_no,
           strMonth,
           p.account_no,
           v_nDiscountAmount,
           decode(sign(v_nAmount - v_nDiscountAmount),
                  -1,
                  0,
                  v_nAmount - v_nDiscountAmount));

        --更新费用明细表
        update bill_cost_list a
           set a.flag = 1
         where to_char(a.billing_date, 'yyyymm') = '201412'
           and a.flag = 0
           and exists (select 1
                  from bill_account_d c
                 where a.enterprise_no = c.enterprise_no
                   and a.warehouse_no = c.warehouse_no
                   and a.owner_no = c.owner_no
                   and a.billing_project = c.billing_project
                   and c.enterprise_no = p.enterprise_no
                   and c.warehouse_no = p.warehouse_no
                   and c.owner_no = p.owner_no
                   and c.account_no = p.account_no);
      end loop;
      strOutMsg := 'Y';
    exception
      when others then
        strOutMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
        return;
    END P_GENERATE_FINANCIAL_DETAILS;
    /***********************************************************************************************
    wyf
    20150727
    功能说明：生成计费
    ***********************************************************************************************/
    procedure P_GENERATE_BILL is
      /*strEnterprise_no bill_formulaset.enterprise_no%type, --企业
      strWarehouse_no  bill_formulaset.warehouse_no%type, --仓别*/
      v_strOutMsg varchar2(255);
      --v_strEnterprise_no bill_formulaset.enterprise_no%type; --企业
      --v_strWarehouse_no  bill_formulaset.warehouse_no%type; --仓别
      --v_strOwnerNo       bill_formulaset.owner_no%type;
      dtCurMonthFirstDay bill_formulaset.rgst_date%type; --当前月第一天
      dtCurDay           bill_formulaset.rgst_date%type; --当天
    BEGIN
      --v_strOutMsg := 'N|[P_GENERATE_BILL]';

      for p in (select distinct c.enterprise_no, c.warehouse_no, c.owner_no
                  from bill_formulaset c
                 order by c.enterprise_no, c.warehouse_no, c.owner_no) loop
        --生成消费清单
        P_GENERATE_CONSUMERLIST(p.enterprise_no,
                                p.warehouse_no,
                                p.owner_no,
                                trunc(sysdate),
                                '0',
                                v_strOutMsg);
        --生成费用明细
        P_GENERATE_COST_DETAILS(p.enterprise_no,
                                p.warehouse_no,
                                p.owner_no,
                                trunc(sysdate - 1),
                                v_strOutMsg);
        --今天
        select trunc(sysdate) into dtCurDay from dual;
        --当前月第一天
        select trunc(add_months(last_day(sysdate), -1) + 1)
          into dtCurMonthFirstDay
          from dual;

        --如果是月结日（每月第一天）
        if dtCurDay = dtCurMonthFirstDay then
          --生成账单
          P_GENERATE_FINANCIAL_DETAILS(p.enterprise_no,
                                       p.warehouse_no,
                                       p.owner_no, --货主
                                       trunc(add_months(sysdate, -1),
                                             'yyyymm'), --月份
                                       v_strOutMsg);
        end if;
      end loop;
      /*    v_strOutMsg := 'Y';
      exception
        when others then
          v_strOutMsg := 'N|' || SQLERRM ||
                       substr(dbms_utility.format_error_backtrace, 1, 256);
          return;*/
    END P_GENERATE_BILL;
    /***********************************************************************************************
    hcx
    20151108
    功能说明：基础费用校验结算日期
    ***********************************************************************************************/

    procedure P_AmountDateCheck(strEnterpriseNo   bill_base_amount.enterprise_no%type, --企业
                           strWarehouseNo    bill_base_amount.warehouse_no%type, --仓别
                           strOwnerNo        bill_base_amount.owner_no%type, --货主
                           strBillingProject bill_base_amount.billing_project%type, --计费项目
                           strBillingCycle     bill_formulaset.billing_cycle%type, --计费周期
                           dtAmountDate       bill_base_amount.amount_date%type, --结算日期
                           strResult          out varchar2) is
   dtBeginDate        bill_formulaset.rgst_date%type;
   dtEndDate          bill_formulaset.rgst_date%type;
   dtBalanceDay       bill_formulaset.balance_day%type;
   v_strWeek  varchar2(10); --星期
   v_maxWeek  varchar2(10); --星期
   v_week   varchar2(10);
   v_strDay  varchar2(10);--当前时间所在月第几天
   v_maxDay  varchar2(10);
   v_endDate  date;--结算日期
   v_lastDay  date;
   v_strDay2  varchar2(2);
   v_nestDay  date;
   v_maxEndDate date;
   v_strDay3  varchar2(2);
   nday2 number;
   nday number;
   v_Count            integer := 0;
   v_Count1            integer := 0;
 begin
  strResult := 'N|[P_AmountDateCheck]';

  if strBillingCycle in('1') then

     select count(*)
        into v_Count
       from (select a.amount_date from bill_base_amount a
              where trunc(a.amount_date) =dtAmountDate
				        and a.warehouse_no=strWarehouseNo
                and a.enterprise_no=strEnterpriseNo
				        and a.owner_no=strOwnerNo
                and a.billing_project = strBillingProject );
      if v_Count>0 then
            strResult := 'N|[该费用清单下的结算日期已存在，请重新选择]';
            return;
      end if;
   elsif strBillingCycle in('2') then

     select count(*)
        into v_Count
       from (select a.amount_date from bill_base_amount a
              where a.warehouse_no=strWarehouseNo
                and a.enterprise_no=strEnterpriseNo
				        and a.owner_no=strOwnerNo
                and a.billing_project = strBillingProject );
      if v_Count>0 then
          --检查结算日期是否已存在
          select count(*)
             into v_Count1
           from (select a.amount_date from bill_base_amount a
              where a.warehouse_no=strWarehouseNo
                and a.enterprise_no=strEnterpriseNo
				        and a.owner_no=strOwnerNo
                and a.billing_project = strBillingProject
                and trunc(a.amount_date)= dtAmountDate);
          if v_Count1>0 then
             strResult := 'N|[该费用清单下的结算日期已存在，请重新选择]';
             return;
          end if;
         for m in( select a.* from bill_base_amount a
              where a.warehouse_no=strWarehouseNo
                and a.enterprise_no=strEnterpriseNo
				        and a.owner_no=strOwnerNo
                and a.billing_project = strBillingProject
                and trunc(a.amount_date)>= trunc(dtAmountDate-7)
                and trunc(a.amount_date)<= trunc(dtAmountDate+7))loop

              begin
                  select bf.balance_day
                    into dtBalanceDay
                    from bill_formulaset bf
                   where bf.billing_project =strBillingProject
                     and bf.owner_no=strOwnerNo
                     and bf.warehouse_no=strWarehouseNo
                     and bf.enterprise_no = strEnterpriseNo;
              exception
                when no_data_found then
                    --获取dtDate所在的周的开始日期
                    select trunc(m.amount_date,'IW') into dtBeginDate from dual;

                    --获取dtDate所在的周的结束日期
                    dtEndDate:=dtBeginDate+6;
               end;

               select to_char(m.amount_date ,'d')-1 into v_strWeek    from dual;

              --取最后一笔清单产生的结束时间
              begin
                  select max(bel.end_date)
                    into v_maxEndDate
                    from bill_expenses_list bel
                   where bel.billing_project =m.billing_project
                     and bel.owner_no=strOwnerNo
                     and bel.warehouse_no=strWarehouseNo
                     and bel.enterprise_no = strEnterpriseNo;
              exception
                when no_data_found then

                  if dtBalanceDay=0 then
                     --今天与结算日相差天数
                     nday := v_strWeek - 7;
                  else
                     --今天与结算日相差天数
                     nday := v_strWeek - dtBalanceDay;

                  end if;
                  if nday<0 then
                     --周开始日期
                     select trunc(m.amount_date)-nday-7 into dtBeginDate from dual;

                  else
                    dtBeginDate:=m.amount_date;

                  end if;
                  --周结束日期
                  dtEndDate:=dtBeginDate+6;

               end;
                --v_maxEndDate所属星期几
               select to_char(v_maxEndDate ,'d')-1 into v_maxWeek from dual;
               if dtBalanceDay='0' then
                  v_week:=dtBalanceDay+7;
               else
                  v_week:=dtBalanceDay;
               end if;
               if v_maxWeek+1 != v_week then
                  dtBeginDate := v_maxEndDate+1;
                  --v_weekBegin与结算日相差天数
                  nday2 := v_maxWeek +1- dtBalanceDay;
                  if nday2<0 then
                     dtEndDate := dtBeginDate-nday2-1;
                  else
                     dtEndDate := dtBeginDate+6-nday2;
                  end if;
                  if m.amount_date>=dtBeginDate and m.amount_date<=dtEndDate then
                     if dtAmountDate>=dtBeginDate and dtAmountDate<=dtEndDate then
                        strResult := 'N|[该费用清单下的结算日期已存在，请重新选择]';
                        return;
                     end if;
                  else
                     goto over;
                  end if;
               else
                  if dtBalanceDay=0 then
                     --今天与结算日相差天数
                     nday := v_strWeek - 7;
                  else
                     --今天与结算日相差天数
                     nday := v_strWeek - dtBalanceDay;

                  end if;
                  if nday<0 then
                     --周开始日期
                     select trunc(m.amount_date)-nday-7 into dtBeginDate from dual;

                  else
                    dtBeginDate:=m.amount_date;

                  end if;

               end if;

                  --周结束日期
                  dtEndDate:=dtBeginDate+6;
                  if dtAmountDate>=dtBeginDate and dtAmountDate<=dtEndDate then
                     strResult := 'N|[该费用清单下的结算日期已存在，请重新选择]';
                     return;
                  end if;
            <<over>>
            null;
         end loop;
      end if;

    elsif strBillingCycle in('3') then
       select count(*)
        into v_Count
       from (select a.amount_date from bill_base_amount a
              where a.warehouse_no=strWarehouseNo
                and a.enterprise_no=strEnterpriseNo
				        and a.owner_no=strOwnerNo
                and a.billing_project = strBillingProject );
      if v_Count>0 then
         --检查结算日期是否已存在
          select count(*)
             into v_Count1
           from (select a.amount_date from bill_base_amount a
              where a.warehouse_no=strWarehouseNo
                and a.enterprise_no=strEnterpriseNo
				        and a.owner_no=strOwnerNo
                and a.billing_project = strBillingProject
                and trunc(a.amount_date)= dtAmountDate);
          if v_Count1>0 then
             strResult := 'N|[该费用清单下的结算日期已存在，请重新选择]';
             return;
          end if;
         for n in( select a.* from bill_base_amount a
              where a.warehouse_no=strWarehouseNo
                and a.enterprise_no=strEnterpriseNo
				        and a.owner_no=strOwnerNo
                and a.billing_project = strBillingProject
                and trunc(a.amount_date)>= trunc(dtAmountDate-31)
                and trunc(a.amount_date)<= trunc(dtAmountDate+31))loop
              begin
                  select bf.balance_day
                    into dtBalanceDay
                    from bill_formulaset bf
                   where bf.billing_project =strBillingProject
                     and bf.owner_no=strOwnerNo
                     and bf.warehouse_no=strWarehouseNo
                     and bf.enterprise_no = strEnterpriseNo;
              exception
                when no_data_found then
                    select count(*)
                      into v_Count
                      from (select a.amount_date from bill_base_amount a
                     where to_char(a.amount_date,'yyyymm') =to_char(dtAmountDate,'yyyymm')
				               and a.warehouse_no=strWarehouseNo
                       and a.enterprise_no=strEnterpriseNo
				               and a.owner_no=strOwnerNo
                       and a.billing_project = strBillingProject );
                    if v_Count>0 then
                       strResult := 'N|[该费用清单下的结算日期已存在，请重新选择]';
                       return;
                    end if;
                end;
                --a.amount_date所在月第几天
                select to_char(n.amount_date ,'DD') into v_strDay from dual;
                nday := v_strDay-dtBalanceDay;

                --结算日期
                select trunc(n.amount_date-nday) into v_endDate from dual;
                --结算日期上月对应日期
                select trunc(add_months(v_endDate,-1)) into v_lastDay from dual;

                begin
                  select max(bel.end_date)
                    into v_maxEndDate
                    from bill_expenses_list bel
                   where bel.billing_project =n.billing_project
                     and bel.owner_no=strOwnerNo
                     and bel.warehouse_no=strWarehouseNo
                     and bel.enterprise_no = strEnterpriseNo;
              exception
                when no_data_found then

                if nday<0 then
                   --结算日期上月对应日期所在月第几天
                   select to_char(v_lastDay ,'DD') into v_strDay2 from dual;

                   if to_number(v_strDay2) < dtBalanceDay then
                      --结算开始日期
                      dtBeginDate := v_lastDay+1;
                   else
                      dtBeginDate := v_lastDay;
                   end if;
                   --结算结束日期
                   select trunc(v_endDate-1) into dtEndDate from dual;
                else
                   --结算开始日期
                   dtBeginDate := v_endDate;
                   --结算日期下月对应日期
                   select trunc(add_months(v_endDate,1)) into v_nestDay from dual;
                   --结算日期下月对应日期所在月第几天
                   select to_char(v_nestDay ,'DD') into v_strDay3 from dual;
                   if to_number(v_strDay2) < dtBalanceDay then
                      dtEndDate :=v_nestDay;
                   else
                      dtEndDate :=v_nestDay-1;
                   end if;
                end if;

               end;

                select to_char(v_maxEndDate ,'DD') into v_maxDay from dual;
              if v_maxDay+1 != dtBalanceDay then
                  dtBeginDate := v_maxEndDate+1;
                  --dtCurMonthFirstDay与结算日相差天数
                  nday2 := v_maxDay +1-dtBalanceDay;
                  if nday2<0 then

                     dtEndDate := dtBeginDate-nday2-1;
                  else

                    dtEndDate :=trunc(last_day(dtBeginDate))+1+dtBalanceDay-2;

                  end if;
                  if n.amount_date>=dtBeginDate and n.amount_date<=dtEndDate then
                     if dtAmountDate>=dtBeginDate and dtAmountDate<=dtEndDate then
                        strResult := 'N|[该费用清单下的结算日期已存在，请重新选择]';
                        return;
                     end if;
                  else
                     goto a;
                  end if;
               else

                    if nday<0 then
                   --结算日期上月对应日期所在月第几天
                   select to_char(v_lastDay ,'DD') into v_strDay2 from dual;

                   if to_number(v_strDay2) < dtBalanceDay then
                      --结算开始日期
                      dtBeginDate := v_lastDay+1;
                   else
                      dtBeginDate := v_lastDay;
                   end if;
                   --结算结束日期
                   select trunc(v_endDate-1) into dtEndDate from dual;
                else
                   --结算开始日期
                   dtBeginDate := v_endDate;
                   --结算日期下月对应日期
                   select trunc(add_months(v_endDate,1)) into v_nestDay from dual;
                   --结算日期下月对应日期所在月第几天
                   select to_char(v_nestDay ,'DD') into v_strDay3 from dual;
                   if to_number(v_strDay2) < dtBalanceDay then
                      dtEndDate :=v_nestDay;
                   else
                      dtEndDate :=v_nestDay-1;
                   end if;
                end if;
               end if;

                if dtAmountDate>=dtBeginDate and dtAmountDate<=dtEndDate then
                     strResult := 'N|[该费用清单下的结算日期已存在，请重新选择]';
                     return;
                end if;
          <<a>>
          null;
         end loop;
      end if;

   end if;

   strResult := 'Y';

   exception
     when others then
       strResult := 'N|' || SQLERRM ||
                  substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_AmountDateCheck;
  end PKOBJ_BILL;

/

