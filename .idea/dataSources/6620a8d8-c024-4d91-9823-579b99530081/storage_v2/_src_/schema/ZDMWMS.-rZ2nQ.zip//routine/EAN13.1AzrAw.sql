create function        EAN13(EnterpriseNo VARCHAR2,OWNER VARCHAR2, ART_NO VARCHAR2) return varchar2 is
    Result varchar2(13);
    ean    integer;
    artno  char(7);
  begin
    begin
      select
        nvl(t.serialno, 0) + 1
      into ean
      from
        JK_OwnerArticleSerialNo t
      where t.enterprise_no = EnterpriseNo
        and t.owner_no=OWNER;
    exception
      when no_data_found then
        insert into
          JK_OwnerArticleSerialNo(enterprise_no,Owner_No, Serialno)
        values(EnterpriseNo,OWNER,0);

        ean := 1;
    end;

    select
      OWNER || LPAD (to_char(ean) , 7 , '0')
    INTO RESULT
    FROM DUAL;

    update
      JK_OwnerArticleSerialNo t
    set
      t.serialno=t.serialno+1
    where t.enterprise_no=EnterpriseNo
      and t.owner_no=OWNER;
    commit;

    return(Result);
  end EAN13;


/

