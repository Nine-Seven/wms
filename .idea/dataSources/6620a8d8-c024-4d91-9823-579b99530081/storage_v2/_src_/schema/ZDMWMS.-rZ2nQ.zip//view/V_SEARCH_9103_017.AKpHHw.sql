create view V_SEARCH_9103_017 as
select "ENTERPRISE_NO","WAREHOUSE_NO","OWNER_NO","RGST_DATE","LOADPROPOSE_NO","CUST_NO","CUST_NAME","LABEL_NO" from (
 select distinct odm.enterprise_no,odm.warehouse_no,odm.owner_no, trunc(odm.rgst_date) rgst_date,odm.loadpropose_no,odm.cust_no,bdc.cust_name,odd.label_no
 from odata_deliver_d odd,
              odata_deliver_m odm,
              bdef_defcust bdc
        where odd.enterprise_no=odm.enterprise_no
          and odd.warehouse_no=odm.warehouse_no
          and odd.owner_no=odm.owner_no
          and odd.deliver_no=odm.deliver_no
          and odm.enterprise_no=bdc.enterprise_no
          and odm.owner_no=bdc.owner_no
          and odm.cust_no=bdc.cust_no )
          order by loadpropose_no,cust_no,label_no

/

