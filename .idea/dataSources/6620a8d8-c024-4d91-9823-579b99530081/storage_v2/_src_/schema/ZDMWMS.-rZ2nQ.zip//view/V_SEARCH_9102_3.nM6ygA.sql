create view V_SEARCH_9102_3 as
select m.enterprise_no,m.warehouse_no,m.owner_no, m.po_no,m.untread_no,
    f_get_fieldtext('RIDATA_UNTREAD_M','QUALITY',m.quality) quality,
    m.class_type,m.cust_no,m.untread_date,d.supplier_no,
    d.article_no,art.ARTICLE_NAME,art.BARCODE,
    d.packing_qty,d.untread_qty,d.check_qty,d.untread_qty-d.check_qty as defferenceQty,
    d.produce_date,d.expire_date,t.cust_name,m.untread_remark,m.status,trunc(m.rgst_date) rgst_date,
     f_get_fieldtext('N','STATUS',m.status) statusText
    from ridata_untread_m m,ridata_untread_d d,v_bdef_defarticle art,bdef_defcust t
    where m.enterprise_no=d.enterprise_no
    and m.warehouse_no=d.warehouse_no
    and m.owner_no=d.owner_no
    and m.untread_no=d.untread_no
    and d.article_no=art.ARTICLE_NO
    and m.enterprise_no=t.enterprise_no
    and m.cust_no=t.cust_no
    and d.supplier_no=art.SUPPLIER_NO
    order by m.po_no,m.untread_no,m.quality, d.article_no


/

