create package        PKLG_WMS_BASE is

  /*****************************************************************************************
   功能：产生单号
  Modify By LZL AT 2013-9-28
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure p_getsheetno(strEnterPriseNo  in   bdef_paperno.enterprise_no%type,
                         strWareHouseNo in bdef_paperno.warehouse_no%type, --仓别
                         SheetType      in bdef_paperno.papertype%type, --单头
                         cSheetNo       out varchar2, --返回单号
                         strOutMsg      out varchar2); --返回 执行结果

  /*****************************************************************************************
   功能：产生基础资料编码
  Modify By wyf AT 2015-11-03
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure p_getBaseNo(strEnterPriseNo in bdef_paperno.enterprise_no%type,
                       strOwnerNo      bdef_paperno.warehouse_no%type, --货主编码
                       SheetType       in bdef_paperno.papertype%type, --类型 SKU：商品，CUST：客户，SUP：供应商
                       cSheetNo        out varchar2, --返回编码
                       strOutMsg       out varchar2);
  /*****************************************************************************************
   功能：读取系统参数
  Modify By luozhiling AT 2013-10-4
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure p_GetBasePara(strEnterpriseNo  in wms_warehouse_owner_base.enterprise_no%type,
                          strWareHouseNo   in wms_warehouse_owner_base.warehouse_no%type, --仓别
                          strOwner_NO      in wms_warehouse_owner_base.owner_no%type, --委托业主
                          strCOLNAME       in WMS_DEFBASE.Colname%type, --参数名
                          strGROUP_NO      in WMS_DEFBASE.Group_No%type, --模块号
                          strsubgroup_no    in WMS_DEFBASE.SUB_GROUP_NO%type, --子模块号
                          Outsdefine       out WMS_DEFBASE.Sdefine%type, --参数的字符性值
                          Outndefine       out WMS_DEFBASE.Ndefine%type, --参数的整数值
                          strOutMsg        out varchar2); --返回 执行结果

  /*****************************************************************************************
   功能：读取系统参数
  add  By lizhiping AT 2015-7-9
  pragma autonomous_transaction;
  *****************************************************************************************/
  function  f_GetBaseParaStr(strEnterpriseNo  in wms_warehouse_owner_base.enterprise_no%type,
                          strWareHouseNo   in wms_warehouse_owner_base.warehouse_no%type, --仓别
                          strOwner_NO      in wms_warehouse_owner_base.owner_no%type, --委托业主
                          strCOLNAME       in WMS_DEFBASE.Colname%type, --参数名
                          strGROUP_NO      in WMS_DEFBASE.Group_No%type, --模块号
                          strsubgroup_no    in WMS_DEFBASE.SUB_GROUP_NO%type) return varchar2;

   /*****************************************************************************************
   功能：读取系统参数
  add  By lizhiping AT 2015-7-9
  pragma autonomous_transaction;
  *****************************************************************************************/
  function  f_GetBaseParaInt(strEnterpriseNo  in wms_warehouse_owner_base.enterprise_no%type,
                          strWareHouseNo   in wms_warehouse_owner_base.warehouse_no%type, --仓别
                          strOwner_NO      in wms_warehouse_owner_base.owner_no%type, --委托业主
                          strCOLNAME       in WMS_DEFBASE.Colname%type, --参数名
                          strGROUP_NO      in WMS_DEFBASE.Group_No%type, --模块号
                          strsubgroup_no    in WMS_DEFBASE.SUB_GROUP_NO%type) return number;

  /*****************************************************************************************
   功能：获取商品属性ID
  Modify By YJF AT 2009-11-1 增加新事务功能，提交不影响父存储过程的事务
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure p_getArticleID(strEnterpriseNo    in stock_article_info.enterprise_no%type,
                           strArticle_No      in stock_article_info.Article_No%type, --商品编号
                           strBarcode         in stock_article_info.Barcode%type, --条码
                           strlot_no          in stock_article_info.lot_no%type, --批号
                           nProduce_Date      in stock_article_info.Produce_Date%type, --生产日期
                           nexpire_date       in stock_article_info.expire_date%type, --到期日期
                           --stritem_type       in stock_article_info.item_type%type, --类型
                           strquality         in stock_article_info.quality%type, --品质
                           --strbatch_serial_no in stock_article_info.batch_serial_no%type, --批次流水号
                           --strSupplier_No     in stock_article_info.Supplier_No%type, --供应商
                           strRSV_BATCH1     in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                           strRSV_BATCH2     in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                           strRSV_BATCH3     in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                           strRSV_BATCH4     in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                           strRSV_BATCH5     in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                           strRSV_BATCH6     in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                           strRSV_BATCH7     in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                           strRSV_BATCH8     in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                           strimport_batch_no in stock_article_info.import_batch_no%type, --验收批次号
                           blInsertFlag       IN varchar2, --不存在是否新增Article_id 0:新增，1不新增
                           strUserId          in stock_article_info.rgst_name%type,
                           strPrice           in stock_article_info.price%type,
                           nArticle_id        out stock_article_info.article_id%type, --商品属性ID
                           strOutMsg          out varchar2); --返回 执行结果

  /*****************************************************************************************
   功能：获取容器号
   luozhiling
   2013-10-10
  *****************************************************************************************/
  procedure p_get_ContainerNoBase(strEnterpriseNo       in wms_defcontainer.enterprise_no%type,
                                  strWareHouseNo        in WMS_DEFCONTAINER.warehouse_no%type, --仓别
                                  strPaperType          in WMS_DEFCONTAINER.CONTAINER_TYPE%type, --类型
                                  strUser_ID            in WMS_DEFCONTAINER.rgst_name%type, --添加人员
                                  strGetType            in varchar2, --返回类型，为'T'时，不返回标签号，直接写入container_no_loc表
                                  nGetNum               in number, --产生容器号数量
                                  strUse_Type           in WMS_DEFCONTAINER.use_type%type, --标签用途
                                  strContainer_Material in WMS_DEFCONTAINER.Container_Material%type, --容器材质
                                  strOutLabelNo         out stock_label_m.label_no%type, --返回标签号
                                  strOutContainerNo     out stock_label_m.container_no%type, --返回容器号
                                  strSESSION_ID         out varchar2, --不返回标签号时，返回sessionID号
                                  strOutMsg             out varchar2);

/**********************************************************************************************************
  lich
  2015.05.21
  功能：高阶查询的预处理
***********************************************************************************************************/
      procedure p_exce_beforeTreatment(
                         strPgmId                in wms_defsearch_m.pgm_id%type,
                         nFlag                   number,
                         strOutMsg               out varchar2);

end PKLG_WMS_BASE;


/

