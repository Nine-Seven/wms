create package        PKLG_ALLOT_DIVIDE_DEVICE is

  -- Author  : Lizhiping
  -- Created : 2015-07-20 20:00:00
  -- Purpose : 分播资源试算

  procedure P_Divide_Device_Main(strEnterPriseNo IN odata_outstock_direct.enterprise_no%TYPE, --企业
                                 strWarehouseNo  IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
                                 strWaveNo       IN ODATA_OUTSTOCK_DIRECT.WAVE_NO%TYPE, --波次号
                                 strUserId       IN ODATA_OUTSTOCK_DIRECT.UPDT_NAME%TYPE, --员工ID
                                 strErrorMsg     OUT VARCHAR2);

  /***零散分播设备试算***/
  /******/
  PROCEDURE P_B_DIVIDE_DEVICE(strEnterPriseNo IN odata_outstock_direct.enterprise_no%TYPE, --企业
                              strWarehouseNo  IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
                              strWaveNo       IN ODATA_OUTSTOCK_DIRECT.WAVE_NO%TYPE, --波次号
                              strUserId       IN ODATA_OUTSTOCK_DIRECT.UPDT_NAME%TYPE, --员工ID
                              strErrorMsg     OUT VARCHAR2);

  /***整箱分播设备试算***/
  /******/
  PROCEDURE P_C_DIVIDE_DEVICE(strEnterPriseNo IN odata_outstock_direct.enterprise_no%TYPE, --企业
                              strWarehouseNo  IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
                              strWaveNo       IN ODATA_OUTSTOCK_DIRECT.WAVE_NO%TYPE, --波次号
                              strUserId       IN ODATA_OUTSTOCK_DIRECT.UPDT_NAME%TYPE, --员工ID
                              strErrorMsg     OUT VARCHAR2);

  /***分播设备试算***/
  PROCEDURE P_SET_DIVIDE_DEVICE(strEnterPriseNo IN odata_outstock_direct.enterprise_no%TYPE, --企业
                                strWarehouseNo  IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
                                strWaveNo       IN ODATA_OUTSTOCK_DIRECT.WAVE_NO%TYPE, --波次号
                                strOperateType  IN ODATA_OUTSTOCK_DIRECT.OPERATE_TYPE%TYPE, --作业类型
                                strUserId       IN ODATA_OUTSTOCK_DIRECT.UPDT_NAME%TYPE, --员工ID
                                strErrorMsg     OUT VARCHAR2);

  /***零散分播设备试算***/
  /******/
  PROCEDURE P_B_DIVIDE_DPS(strEnterPriseNo IN odata_outstock_direct.enterprise_no%TYPE, --企业
                           strWarehouseNo  IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
                           strWaveNo       IN ODATA_OUTSTOCK_DIRECT.WAVE_NO%TYPE, --波次号
                           strUserId       IN ODATA_OUTSTOCK_DIRECT.UPDT_NAME%TYPE, --员工ID
                           strErrorMsg     OUT VARCHAR2);
  /***零散分播更换设备***/
  /******/
  PROCEDURE P_B_CHG_DIVIDE_DEVICEGRP(strEnterPriseNo IN odata_outstock_direct.enterprise_no%TYPE, --企业
                                     strWarehouseNo  IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
                                     strLabelNo      IN stock_label_m.label_no%TYPE, --物流箱号
                                     strGroupNo      in device_divide_m.device_group_no%type, --组号
                                     strErrorMsg     OUT VARCHAR2);

  /***分播手工设备试算***/
  /******/
  PROCEDURE P_DIVIDE_HANDLE(strEnterPriseNo IN odata_outstock_direct.enterprise_no%TYPE, --企业
                            strWarehouseNo  IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
                            strWaveNo       IN ODATA_OUTSTOCK_DIRECT.WAVE_NO%TYPE, --波次号
                            strUserId       IN ODATA_OUTSTOCK_DIRECT.UPDT_NAME%TYPE, --员工ID
                            strErrorMsg     OUT VARCHAR2);

  /***分播墙试算***/
  /******/
  procedure P_B_DIVIDE_WALL(strEnterPriseNo IN odata_outstock_direct.enterprise_no%TYPE, --企业
                            strWarehouseNo  IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
                            strWaveNo       IN ODATA_OUTSTOCK_DIRECT.WAVE_NO%TYPE, --波次号
                            strDeviceGroup  in device_divide_m.device_group_no%type,
                            strOperateType  in device_divide_m.operate_type%type,
                            strDeviceType   in device_divide_m.device_type%type,
                            strUserId       IN ODATA_OUTSTOCK_DIRECT.UPDT_NAME%TYPE, --员工ID
                            strErrorMsg     OUT VARCHAR2);

  /***获取配送对象分播设备储位***/
  /******/
  procedure P_GetCellByDeliverObj(strEnterPriseNo IN odata_outstock_direct.enterprise_no%TYPE, --企业
                                  strWarehouseNo  IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
                                  strWaveNo       IN ODATA_OUTSTOCK_DIRECT.WAVE_NO%TYPE, --波次号
                                  strBatchNo      in ODATA_OUTSTOCK_DIRECT.Batch_No%type,
                                  strDeliverObj   in ODATA_OUTSTOCK_DIRECT.Deliver_Obj%type,
                                  strUserId       IN ODATA_OUTSTOCK_DIRECT.UPDT_NAME%TYPE, --员工ID
                                  strDeviceNo     in ODATA_OUTSTOCK_DIRECT.Device_No%type,
                                  strDpsCellNo    out ODATA_OUTSTOCK_DIRECT.Dps_Cell_No%type,
                                  strErrorMsg     OUT VARCHAR2);
end PKLG_ALLOT_DIVIDE_DEVICE;


/

