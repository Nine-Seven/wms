create view V_SEARCH_9104_2 as
    select a.enterprise_no,a.warehouse_no,a.row_id,a.label_no,a.container_no,a.container_type,
a.owner_container_no,a.status, f_get_fieldtext('STOCK_LABEL_M', 'STATUS', a.status)as statusText,
a.owner_cell_no,a.rgst_name,a.rgst_date
from stock_label_log a
union all
select a.enterprise_no,a.warehouse_no,a.row_id,a.label_no,a.container_no,a.container_type,
a.owner_container_no,a.status,f_get_fieldtext('STOCK_LABEL_M', 'STATUS', a.status)as statusText,
a.owner_cell_no,a.rgst_name,a.rgst_date
from stock_label_loghty a


/

