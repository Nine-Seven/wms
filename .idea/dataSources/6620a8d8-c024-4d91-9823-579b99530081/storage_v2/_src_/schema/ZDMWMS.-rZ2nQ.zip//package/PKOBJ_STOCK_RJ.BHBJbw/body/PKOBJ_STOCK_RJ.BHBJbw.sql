create package body PKOBJ_STOCK_RJ is
  /****************************************************
  重算日结库存账 wyf 2016-10-09
  ****************************************************/
  procedure P_RETRY_STOCK_CONTENT_RJ(dtStart   in date, --开始时间
                                     dtEnd     in date, --结束时间 结束日期最大为今天日期
                                     strResult out varchar2) is
    ndays    number;
    v_dtDate date;
  begin
    strResult := 'N|';
    --初始库存06-14   dtStart:= "06-16" dtEnd:="11-11"
    ndays := trunc(dtEnd) - trunc(dtStart);
    for p in 0 .. ndays loop
      v_dtDate := dtStart + p - 1;
      delete from stock_content_rj a where a.jc_date = trunc(v_dtDate);
      insert into stock_content_rj
        (warehouse_no,
         owner_no,
         dept_no,
         article_no,
         packing_qty,
         jc_date,
         qc_qty,
         in_qty,
         out_qty,
         qty,
         rgst_name,
         rgst_date,
         import_batch_no
         )
        select a.warehouse_no,
               a.owner_no,
               a.dept_no,
               a.article_no,
               a.packing_qty,
               trunc(v_dtDate),
               sum(a.qcqty),
               sum(a.inqty),
               sum(a.outqty),
               sum(a.qcqty) + sum(a.inqty) - sum(a.outqty),
               'admin',
               sysdate,
               a.import_batch_no
          from (select scr.warehouse_no,
                       scr.owner_no,
                       scr.dept_no,
                       scr.article_no,
                       scr.packing_qty,
                       sum(scr.qty) qcqty,
                       0 inqty,
                       0 outqty,
                       scr.import_batch_no
                  from stock_content_rj scr
                 where scr.jc_date = trunc(v_dtDate - 1)
                   and scr.qty <> 0 --包含未结案，就出货的库存
                 group by scr.warehouse_no,
                          scr.owner_no,
                          scr.dept_no,
                          scr.article_no,
                          scr.packing_qty,
                          scr.import_batch_no --将前天的库存量作为昨天的期初库存
                          
                union
                select sad.warehouse_no,
                       sad.owner_no,
                       sad.dept_no,
                       sad.article_no,
                       sad.packing_qty,
                       0 qcqty,
                       sum(sad.move_qty) inqty,
                       0 outqty,
                       sad.import_batch_no
                  from stock_content_list sad
                 where sad.paper_date = trunc(v_dtDate)
                   and sad.move_qty > 0
                 group by sad.warehouse_no,
                          sad.owner_no,
                          sad.dept_no,
                          sad.article_no,
                          sad.packing_qty,
                          sad.import_batch_no
                union
                select sad.warehouse_no,
                       sad.owner_no,
                       sad.dept_no,
                       sad.article_no,
                       sad.packing_qty,
                       0 qcqty,
                       0 inqty,
                       -sum(sad.move_qty) Outqty,
                       sad.import_batch_no
                  from stock_content_list sad
                 where sad.paper_date = trunc(v_dtDate)
                   and sad.move_qty < 0
                 group by sad.warehouse_no,
                          sad.owner_no,
                          sad.dept_no,
                          sad.article_no,
                          sad.packing_qty,
                          sad.import_batch_no) a
         group by a.warehouse_no,
                  a.owner_no,
                  a.dept_no,
                  a.article_no,
                  a.packing_qty,
                  a.import_batch_no;
    end loop;
    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_RETRY_STOCK_CONTENT_RJ;
  /****************************************************
  生成昨天的库存日结账 wyf 2016-10-09
  ****************************************************/
  procedure P_STOCK_CONTENT_RJ IS
  BEGIN
    insert into stock_content_rj
      (warehouse_no,
       owner_no,
       dept_no,
       article_no,
       packing_qty,
       jc_date,
       qc_qty,
       in_qty,
       out_qty,
       qty,
       rgst_name,
       rgst_date,
       import_batch_no)
      select a.warehouse_no,
             a.owner_no,
             a.dept_no,
             a.article_no,
             a.packing_qty,
             trunc(sysdate - 1),
             sum(a.qcqty),
             sum(a.inqty),
             sum(a.outqty),
             sum(a.qcqty) + sum(a.inqty) - sum(a.outqty),
             'admin',
             sysdate,
             a.import_batch_no
        from (select scr.warehouse_no,
                     scr.owner_no,
                     scr.dept_no,
                     scr.article_no,
                     scr.packing_qty,
                     sum(scr.qty) qcqty,
                     0 inqty,
                     0 outqty,
                     scr.import_batch_no
                from stock_content_rj scr
               where scr.jc_date = trunc(sysdate - 2)
                 and scr.qty <> 0
               group by scr.warehouse_no,
                        scr.owner_no,
                        scr.dept_no,
                        scr.article_no,
                        scr.packing_qty,
                        scr.import_batch_no --将前天的库存量作为昨天的期初库存
              union
              select sad.warehouse_no,
                     sad.owner_no,
                     sad.dept_no,
                     sad.article_no,
                     sad.packing_qty,
                     0 qcqty,
                     sum(sad.move_qty) inqty,
                     0 outqty,
                     sad.import_batch_no
                from stock_content_list sad
               where sad.paper_date = trunc(sysdate - 1)
                 and sad.move_qty > 0
               group by sad.warehouse_no,
                        sad.owner_no,
                        sad.dept_no,
                        sad.article_no,
                        sad.packing_qty,
                        sad.import_batch_no
              union
              select sad.warehouse_no,
                     sad.owner_no,
                     sad.dept_no,
                     sad.article_no,
                     sad.packing_qty,
                     0 qcqty,
                     0 inqty,
                     -sum(sad.move_qty) Outqty,
                     sad.import_batch_no
                from stock_content_list sad
               where sad.paper_date = trunc(sysdate - 1)
                 and sad.move_qty < 0
               group by sad.warehouse_no,
                        sad.owner_no,
                        sad.dept_no,
                        sad.article_no,
                        sad.packing_qty,
                        sad.import_batch_no) a
       group by a.warehouse_no,
                a.owner_no,
                a.dept_no,
                a.article_no,
                a.packing_qty,
                a.import_batch_no;

       P_comp_Owner_Usedcell;

  END P_STOCK_CONTENT_RJ;

  procedure P_comp_Owner_Usedcell is
    v_Count number;

  begin

    select count(1)
      into v_count
      from CDEF_DEFCELL_OWNERUSED t
     where t.operate_date = trunc(sysdate);

    if v_count > 0 then
      return;
    else
      insert into CDEF_DEFCELL_OWNERUSED
        (enterprise_no,
         warehouse_no,
         owner_no,
         CELL_NO,
         operate_date,
         rgst_name,
         rgst_date)
        select distinct sc.enterprise_no,
               sc.warehouse_no,
               sc.owner_no,
               sc.cell_no ,
               trunc(sysdate),
               'admin',
               sysdate
          from stock_content sc, cdef_defcell cdc, cdef_defarea cda
         where sc.enterprise_no = cdc.enterprise_no
           and sc.warehouse_no = cdc.warehouse_no
           and sc.cell_no = cdc.cell_no
           and cdc.enterprise_no = cda.enterprise_no
           and cdc.warehouse_no = cda.warehouse_no
           and cdc.ware_no = cda.ware_no
           and cdc.area_no = cda.area_no
           and cda.area_attribute in ('0', '1', '3') /*作业区，暂存区，问题区，虚拟区*/
           and sc.qty > 0;
    end if;

  end P_comp_Owner_Usedcell;


  
  /*****************************************************************************************************
  功能说明：进货验收的三级帐处理
  luozhiling
  2017.3.6
  *****************************************************************************************************/
  procedure P_IdataCheckAcount(strEnterprise_No in idata_check_m.enterprise_no%type, --企业
                              strWAREHOUSE_NO  in idata_check_m.WAREHOUSE_NO%type, --仓库编码)
                              strOwnerNo       in idata_check_m.owner_no%type,
                              strS_import_no   in idata_check_m.s_import_no%type, --进货汇总单号
                              strS_Check_no    in idata_check_m.s_check_no%type, --验收汇总单号
                              strWorkerNo      in idata_check_m.rgst_name%type, --操作人
                              strResult        Out varchar2) is
    v_strCellManageType       bdef_defowner.cell_manager_type%type;
  begin
       strResult:='N|[P_IdataCheckAcount]';

        --根据验收明细写库存三级帐
        for GetCheckItem in (select icm.import_type, icd.*
                               from idata_check_m icm, idata_check_d icd
                              where icm.enterprise_no = icd.enterprise_no
                                and icm.warehouse_no = icd.warehouse_no
                                and icm.check_no = icd.check_no
                                and icm.enterprise_no = strEnterprise_No
                                and icm.warehouse_no = strWAREHOUSE_NO
                                and icm.s_check_no = strS_Check_no
                                and icm.s_import_no = strS_import_no) loop

          --写商品批次库存帐
          pkobj_stock.P_insertImportBatchStock(strEnterprise_No,
                                               strWAREHOUSE_NO,
                                               strOwnerNo,
                                               GetCheckItem.dept_no,
                                               GetCheckItem.article_no,
                                               GetCheckItem.quality,
                                               GetCheckItem.check_no,
                                               GetCheckItem.produce_date,
                                               GetCheckItem.expire_date,
                                               GetCheckItem.lot_no,
                                               GetCheckItem.rsv_batch1,
                                               GetCheckItem.rsv_batch2,
                                               GetCheckItem.rsv_batch3,
                                               GetCheckItem.rsv_batch4,
                                               GetCheckItem.rsv_batch5,
                                               GetCheckItem.rsv_batch6,
                                               GetCheckItem.rsv_batch7,
                                               GetCheckItem.rsv_batch8,
                                               GetCheckItem.barcode,
                                               GetCheckItem.packing_qty,
                                               GetCheckItem.check_qty,
                                               GetCheckItem.stock_type,
                                               GetCheckItem.stock_value,
                                               strWorkerNo,
                                               strResult);

          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;
          --写库存三级帐
          pkobj_stock.P_InsertArticleStockList(strEnterprise_No,
                                               strWAREHOUSE_NO,
                                               strOwnerNo,
                                               GetCheckItem.dept_no,
                                               GetCheckItem.article_no,
                                               GetCheckItem.quality,
                                               GetCheckItem.produce_date,
                                               GetCheckItem.expire_date,
                                               GetCheckItem.lot_no,
                                               GetCheckItem.rsv_batch1,
                                               GetCheckItem.rsv_batch2,
                                               GetCheckItem.rsv_batch3,
                                               GetCheckItem.rsv_batch4,
                                               GetCheckItem.rsv_batch5,
                                               GetCheckItem.rsv_batch6,
                                               GetCheckItem.rsv_batch7,
                                               GetCheckItem.rsv_batch8,
                                               GetCheckItem.barcode,
                                               GetCheckItem.packing_qty,
                                               GetCheckItem.check_qty,
                                               GetCheckItem.stock_type,
                                               GetCheckItem.stock_value,
                                               1,
                                               GetCheckItem.import_type,
                                               GetCheckItem.check_no,
                                               strWorkerNo,
                                               GetCheckItem.check_no,
                                               strResult);

          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;

        end loop;
       strResult:='Y|[]';

  end P_IdataCheckAcount;

end PKOBJ_STOCK_RJ;
/

