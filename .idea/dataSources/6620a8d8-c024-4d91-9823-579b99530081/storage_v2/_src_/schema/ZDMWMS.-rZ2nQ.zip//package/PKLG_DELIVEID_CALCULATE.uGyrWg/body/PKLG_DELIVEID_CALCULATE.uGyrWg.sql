create package body        pklg_Deliveid_calculate is
  /*****************************************************************************************************************
  luozhiling
  20160308
  月台存放序号：按日期产生，每天从1还是往上累加
  ***************************************************************************************************************/
  procedure P_Deliver_calculate(strEnterpriseNo    in     odata_outstock_m.enterprise_no%type,
                               strWarehouseNo     in     stock_label_m.warehouse_no%type,
                               strOwnerNo         in     odata_exp_m.owner_no%type,
                               strWaveNo          in     odata_wave_trace.wave_no%type,
                               strOutMsg         out varchar2) is
  v_Count                  integer:=0;
  v_nPalQty                odata_exp_d.article_qty%type;--板数
  begin
      strOutMsg := 'N|[P_Deliver_calculate]';
      for p in(select distinct ood.exp_no  from
                 odata_outstock_direct ood
                 where ood.enterprise_no=strEnterpriseNo
                 and ood.warehouse_no=strWarehouseNo
                 and ood.wave_no=strWaveNo and ood.status='N'
                 and ood.outstock_type='0' order by ood.exp_no) loop
            --取月台存放序号
            p_getExpOrderid(strEnterpriseNo,strOwnerNo,'YTH',v_Count,strOutMsg);
            if instr(strOutMsg, 'N', 1, 1) = 1 then
              return;
            end if;

            --计算商品的采集
            select nvl(ceil(sum(oed.article_qty /
            nvl(case when bap.qpalette = 0 then 1 else bap.qpalette end,1))),1) into v_nPalQty
            from odata_exp_d oed
            inner join
            (select oed.enterprise_no,oed.article_no,max(nvl(bap.packing_qty,1)) as packing_qty from odata_exp_d oed
            left join bdef_article_packing bap
            on bap.enterprise_no=oed.enterprise_no
            and bap.article_no=oed.article_no
            where oed.enterprise_no=strEnterpriseNo
              and oed.warehouse_no=strWarehouseNo
              and oed.exp_no=p.exp_no
            group by oed.enterprise_no,oed.article_no) d
            on d.enterprise_no=oed.enterprise_no
            and d.article_no=oed.article_no
            left join bdef_article_packing bap
            on bap.enterprise_no=oed.enterprise_no
            and bap.article_no=oed.article_no
            and bap.packing_qty=d.packing_qty
            where oed.enterprise_no=strEnterpriseNo
              and oed.warehouse_no=strWarehouseNo
              and oed.exp_no=p.exp_no;

            --更新下架指示的月台序号
            update odata_outstock_direct ood
                   set ood.deliver_area=v_Count||'-'||v_nPalQty
            where ood.enterprise_no=strEnterpriseNo
            and ood.warehouse_no=strWarehouseNo and ood.wave_no=strWaveNo
            and ood.status='N' and ood.exp_no=p.exp_no;
            --更新出货单的月台序号
            update odata_exp_m t set t.rsv_varod1=v_Count||'-'||v_nPalQty
            where t.enterprise_no=strEnterpriseNo and t.warehouse_no=strWarehouseNo
            and t.exp_no=p.exp_no;

      end loop;

      strOutMsg:='Y|';

  end P_Deliver_calculate;

  /*****************************************************************************************
   功能：产生月台序号 编码
  Modify By wyf AT 2015-11-03
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure p_getExpOrderid(strEnterPriseNo in bdef_paperno.enterprise_no%type,
                       strOwnerNo      bdef_paperno.warehouse_no%type, --货主编码
                       SheetType       in bdef_paperno.papertype%type, --类型YTH:月台序号
                       cSheetNo        out varchar2, --返回编码
                       strOutMsg       out varchar2) --返回 执行结果
   is
    pragma autonomous_transaction;
    v_strPaperType bdef_paperno.papertype%type;
    strDate        char(6);
    nSerialLen     bdef_paperno.length%type;
    serialno       bdef_paperno.serialno%type;
    chgdate        bdef_paperno.chgdate%type;
  begin
    v_strPaperType := UPPER(SheetType);
    strDate        := to_char(sysdate, 'yymmdd');

    begin
      strOutMsg := 'N|[p_getExpOrderid]';
      begin
        select serialno, chgdate, length
          into serialno, chgdate, nSerialLen
          from bdef_paperno
         where papertype = v_strPaperType
           and wareHouse_No = strOwnerNo
           and enterprise_no = strEnterPriseNo
           for update;
      exception
        when no_data_found then
          insert into bdef_paperno
            (enterprise_no,
             warehouse_no,
             papertype,
             serialno,
             length,
             chgdate,
             chgtime)
          values
            (strEnterPriseNo,
             strOwnerNo,
             v_strPaperType,
             '0',
             4,
             to_char(sysdate, 'yymmdd'),
             to_char(sysdate, 'hh24:mi'));

          select serialno, chgdate, length
            into serialno, chgdate, nSerialLen
            from bdef_paperno
           where enterprise_no = strEnterPriseNo
             and papertype = v_strPaperType
             and wareHouse_No = strOwnerNo
             for update;
      end;

      --编码取值
      serialno := serialno + 1;
      cSheetNo :=serialno;

      update bdef_paperno
         set serialno = serialno,
             chgtime  = to_char(sysdate, 'hh24:mi'),
             chgdate  = strDate
       where papertype = v_strPaperType
         and warehouse_no = strOwnerNo
         and enterprise_no = strEnterPriseNo;
      if sql%notfound then
        rollback;
        strOutMsg := 'N|[E00012]';
        return;
      end if;
      strOutMsg := 'Y';
      commit;
    end;
  end p_getExpOrderid;
end pklg_Deliveid_calculate;

/

