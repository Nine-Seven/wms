create view V_SEARCH_9104_6 as
select m.enterprise_no,m.warehouse_no,'001' as owner_no,m.label_no,r.worker_name,m.rgst_date
 from (select * from stock_label_m union select * from stock_label_mhty) m,bdef_defworker r
 where m.status in('A1','A2') and m.enterprise_no=r.enterprise_no and m.updt_name=r.worker_no
 and m.warehouse_no=r.warehouse_no order by r.worker_name,m.rgst_date desc


/

