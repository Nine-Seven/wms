create view V_SEARCH_9108_1 as
select m.enterprise_no,
       m.warehouse_no,
       m.serial_no,
       m.check_no,
       m.check_date,
       m.assign_no,
       d.cell_no,
       d.article_no,
       bda.ARTICLE_NAME,
       bda.SPEC,
       d.barcode,
       to_char(d.produce_date, 'yyyy-mm-dd') produce_date,
       to_char(d.expire_date, 'yyyy-mm-d') expire_date,
       d.quality,
       d.packing_qty,
       d.lot_no,
       floor(sum(d.article_qty) / d.packing_qty) article_box_qty,
       mod(sum(d.article_qty), d.packing_qty) article_retail_qty,
       floor(sum(d.check_qty) / d.packing_qty) check_box_qty,
       mod(sum(d.check_qty), d.packing_qty) check_retail_qty,
       floor(sum(d.check_qty - d.article_qty) / d.packing_qty) diff_box_qty,
       mod(sum(d.check_qty - d.article_qty), d.packing_qty) diff_retail_QTY
  from fcdata_check_m m
 inner join fcdata_check_d d
    on m.warehouse_no = d.warehouse_no
   and m.enterprise_no = d.enterprise_no
   and m.owner_no = d.owner_no
   and m.check_no = d.check_no
  left join bdef_defarticle bda
    on bda.ARTICLE_NO = d.article_no
   and bda.enterprise_no = d.enterprise_no
  left join bdef_article_packing bap
    on bap.article_no = d.article_no
   and bap.packing_qty = d.packing_qty
   and bap.enterprise_no = d.enterprise_no
 where m.check_type = '2'
   and d.article_qty <> d.check_qty
 group by m.serial_no,
          m.check_no,
          m.check_date,
          m.assign_no,
          d.cell_no,
          d.article_no,
          bda.ARTICLE_NAME,
          d.barcode,
          d.produce_date,
          d.expire_date,
          d.quality,
          d.packing_qty,
          d.lot_no,
          bap.packing_unit,
          bda.UNIT,
          bda.SPEC,
          m.warehouse_no,
          m.enterprise_no


/

