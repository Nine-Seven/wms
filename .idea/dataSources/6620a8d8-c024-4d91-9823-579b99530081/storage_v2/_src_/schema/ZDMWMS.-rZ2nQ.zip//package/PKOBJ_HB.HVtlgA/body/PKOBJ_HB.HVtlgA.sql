create package body        PKOBJ_HB is

  /*=====================================================================================
  hb insert to 20140607
  根据 标签获取一下工作流状态，并写业务数据
  ======================================================================================*/
  PROCEDURE p_OM_OutWorkflow(strEnterPriseNo in STOCK_LABEL_M.enterprise_no%type, --企业号
                             strwarehouse_no in STOCK_LABEL_M.warehouse_no%type, --仓别
                             strOwner_No     in bdef_defowner.owner_no%type,
                             strExp_Type     in odata_exp_m.exp_type%type,
                             strContainer_No in stock_label_m.container_no%type, --系统内部容器号
                             strUser_Id      in stock_label_m.rgst_name%type, --操作人员
                             strDockNo       in Bdef_Defdock.dock_no%TYPE, --自动封车打印使用，若不需要则传'N'
                             strOutMsg       out varchar2) is

    n_count          number(10); --获取数据行数
    n_exp_type       stock_label_d.exp_type%type; --出货通知单类型
    n_flow_value     wms_outorder_flow_d.flow_value%type; --工作流内容
    n_status_type    wms_deflabel_status.status_type%type; --状态区间
    v_strAutoFlag    wms_deflabel_status.must_run%type; --
    v_strCanLoadFlag wms_defbase.sdefine%type;
    v_nCanLoadFlag   wms_defbase.sdefine%type;
    v_strExpNo       odata_exp_m.exp_no%type;
  begin
    strOutMsg := 'N|[p_OM_OutWorkflow]';
    n_count   := 0;

    p_GetLabelStatusFromWorkflow(strEnterPriseNo,
                                 strwarehouse_no,
                                 strOwner_No,
                                 strExp_Type,
                                 strContainer_No,
                                 n_status_type,
                                 v_strAutoFlag,
                                 strOutMsg);

    if (substr(strOutMsg, 1, 1) <> 'Y') then
      return;
    end if;

    /*出货工作流*/
    --1：整理
    if n_status_type = '61' then
      --更新标签头档状态
      pkobj_label.p_updt_label_status(strEnterPriseNo,
                                      strwarehouse_no,
                                      strContainer_No,
                                      strUser_Id,
                                      '61',
                                      strOutMsg);
      if (substr(strOutMsg, 1, 1) <> 'Y') then
        return;
      end if;

      --更新标签明细状态(由于有装并板的情况所以不返回错误)
      update stock_label_d sm
         set sm.status    = '61',
             sm.updt_date = sysdate,
             sm.updt_name = strUSER_ID
       where sm.container_no = strContainer_No
         and sm.warehouse_no = strwarehouse_no
         and sm.enterprise_no = strEnterPriseNo;

    end if;

    --2：内复核中
    if n_status_type = '6A' then
      --更新标签头档状态
      pkobj_label.p_updt_label_status(strEnterPriseNo,
                                      strwarehouse_no,
                                      strContainer_No,
                                      strUser_Id,
                                      '6A',
                                      strOutMsg);
      if (substr(strOutMsg, 1, 1) <> 'Y') then
        return;
      end if;

      --更新标签明细状态(由于有装并板的情况所以不返回错误)
      update stock_label_d sm
         set sm.status    = '6A',
             sm.updt_date = sysdate,
             sm.updt_name = strUSER_ID
       where sm.container_no = strContainer_No
         and sm.warehouse_no = strwarehouse_no
         and sm.enterprise_no = strEnterPriseNo;

    end if;

    --3：待外复核
    if n_status_type = '6C' then
      --更新标签头档状态
      pkobj_label.p_updt_label_status(strEnterPriseNo,
                                      strwarehouse_no,
                                      strContainer_No,
                                      strUser_Id,
                                      '6C',
                                      strOutMsg);
      if (substr(strOutMsg, 1, 1) <> 'Y') then
        return;
      end if;

      --更新标签明细状态(由于有装并板的情况所以不返回错误)
      update stock_label_d sm
         set sm.status    = '6C',
             sm.updt_date = sysdate,
             sm.updt_name = strUSER_ID
       where sm.container_no = strContainer_No
         and sm.warehouse_no = strwarehouse_no
         and sm.enterprise_no = strEnterPriseNo;

    end if;

    --4：待转区
    if n_status_type = '90' then
      --更新标签头档状态
      pkobj_label.p_updt_label_status(strEnterPriseNo,
                                      strwarehouse_no,
                                      strContainer_No,
                                      strUser_Id,
                                      '90',
                                      strOutMsg);
      if (substr(strOutMsg, 1, 1) <> 'Y') then
        return;
      end if;

      --更新标签明细状态(由于有装并板的情况所以不返回错误)
      update stock_label_d sm
         set sm.status    = '90',
             sm.updt_date = sysdate,
             sm.updt_name = strUSER_ID
       where sm.container_no = strContainer_No
         and sm.warehouse_no = strwarehouse_no
         and sm.enterprise_no = strEnterPriseNo;

    end if;

    --5：待装车
    if n_status_type = 'A0' then
      --更新标签头档状态
      pkobj_label.p_updt_label_status(strEnterPriseNo,
                                      strwarehouse_no,
                                      strContainer_No,
                                      strUser_Id,
                                      'A0',
                                      strOutMsg);
      if (substr(strOutMsg, 1, 1) <> 'Y') then
        return;
      end if;

      --更新标签明细状态(由于有装并板的情况所以不返回错误)
      update stock_label_d sm
         set sm.status    = 'A0',
             sm.updt_date = sysdate,
             sm.updt_name = strUSER_ID
       where sm.container_no = strContainer_No
         and sm.warehouse_no = strwarehouse_no
         and sm.enterprise_no = strEnterPriseNo;

      if v_strAutoFlag = '1' then
        --获取标签对应的出货单号
        select distinct exp_no
          into v_strExpNo
          from stock_label_d
         where enterprise_no = strEnterPriseNo
           and warehouse_no = strwarehouse_no
           and container_nO = strContainer_No
           and rownum = 1;
        PKLG_ODATA_DELIVER.P_AutoCloseCar(strEnterPriseNo,
                                          strwarehouse_no,
                                          v_strExpNo,
                                          strDockNo,
                                          strUser_Id,
                                          strOutMsg);
        if (substr(strOutMsg, 1, 1) <> 'Y') then
          return;
        end if;
      end if;
    end if;
    strOutMsg := 'Y|成功';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_OM_OutWorkflow;

  /***************************************************************************************************************88888
  功能说明：通过标签当前状态和单据类型取工作量区间值，取下一工作流区间值对应的状态
  luozhiling
  2015.05.14
  *******************************************************************************************************************/
  PROCEDURE p_GetLabelStatusFromWorkflow(strEnterPriseNo in STOCK_LABEL_M.enterprise_no%type, --企业号
                                         strwarehouse_no in STOCK_LABEL_M.warehouse_no%type, --仓别
                                         strOwner_No     in bdef_defowner.owner_no%type,
                                         strExp_Type     in odata_exp_m.exp_type%type,
                                         strContainer_No in stock_label_m.container_no%type, --系统内部容器号
                                         n_status_type   out wms_deflabel_status.status_type%type, --状态区间
                                         strAutoFlag     out wms_deflabel_status.must_run%type, --是否需要自动执行
                                         strOutMsg       out varchar2) is
    --n_exp_type            stock_label_d.exp_type%type; --出货通知单类型
    n_flow_value          wms_outorder_flow_d.flow_value%type; --工作流内容
    v_strAutoFlag         wms_deflabel_status.must_run%type := '0';
    --v_strOwnerNo          bdef_defowner.owner_no%type;
    v_strWorkflowStrategy wms_outorder.workflow_strategy_id%type; --工作流策略ID
  begin
    strOutMsg := 'N|[p_GetLabelStatusFromWorkflow]';

    strAutoFlag := v_strAutoFlag;

    --获取工作流策略
    begin

      select nvl(a.workflow_strategy_id, wo.workflow_strategy_id)
        into v_strWorkflowStrategy
        from wms_outorder wo
        left join (select woo.exp_type,
                          nvl(wao.workflow_strategy_id,
                              woo.workflow_strategy_id) workflow_strategy_id
                     from wms_owner_outorder woo
                     left join wms_warehouse_outorder wao
                       on wao.exp_type = woo.exp_type
                      and wao.enterprise_no = woo.enterprise_no
                      and woo.enterprise_no = strEnterPriseNo
                      and wao.owner_no = woo.owner_no
                      and wao.warehouse_no = strwarehouse_no
                      and woo.owner_no = strOwner_No) a
          on wo.exp_type = a.exp_type
         where wo.enterprise_no = strEnterPriseNo
         and wo.exp_type=strExp_Type;
    exception
      when no_data_found then
        strOutMsg := 'N|[获取不到当前出货单别对应的工作流策略!]';
        return;
    end;

    --获取客户标签状态信息工作流程
    begin
      select distinct wds.flow_value
        into n_flow_value
        from (select owner_lm.enterprise_no,
                     owner_lm.warehouse_no,
                     owner_lm.owner_container_no container_no,
                     owner_lm.status
                from stock_label_m owner_lm, stock_label_m lm
               where owner_lm.enterprise_no = lm.enterprise_no
                 and owner_lm.warehouse_no = lm.warehouse_no
                 and owner_lm.owner_container_no = lm.container_no
                 and owner_lm.container_no = strContainer_No) clm
       inner join wms_deflabel_status wds
          on wds.status_type = clm.status
       where clm.warehouse_no = strwarehouse_no
         and clm.enterprise_no = strEnterPriseNo
         and rownum = 1; --只取一条数据
    exception
      when no_data_found then
        strOutMsg := 'N|[E10000!]';
        return;
    end;

    --获取客户标签工作流程
    begin

      select a.status_type
        into n_status_type
        from (select wds.status_type
                from wms_outorder_flow_d wof
               inner join wms_deflabel_status wds
                  on wds.flow_value = wof.flow_value
                 and wds.flow_flag = '2' --0：为非工作流节点，1：为进货工作流节点，2：为出货工作流节点
               where wof.flow_flag = '1' --标志  0：不执行；1：执行
                 and wof.workflow_strategy_id = v_strWorkflowStrategy
                 and wof.flow_value > n_flow_value
                 and wof.enterprise_no = strEnterPriseNo
               order by wds.status_type) a
       where rownum = 1;
    exception when no_data_found then

        if n_status_type is null or n_status_type = '' then

          strAutoFlag := '1';

          --获取最小的必须执行的工作流步骤

          begin
            select max(a.status_type)
              into n_status_type
              from (select wds.status_type
                      from wms_outorder_flow_d wof
                     inner join wms_deflabel_status wds
                        on wds.flow_value = wof.flow_value
                       and wds.flow_flag = '2' --0：为非工作流节点，1：为进货工作流节点，2：为出货工作流节点
                     where wof.workflow_strategy_id =
                           v_strWorkflowStrategy
                       and wof.flow_value > n_flow_value
                       and wof.enterprise_no = strEnterPriseNo
                       and wds.must_run = '1'
                     order by wds.status_type) a
             where rownum = 1;
          exception
            when no_data_found then
              strOutMsg := 'N|[E10001!]';
              return;
          end;
        end if;
    end;

    strOutMsg := 'Y|[]';
  end p_GetLabelStatusFromWorkflow;

  /************************************************************************************
  功能说明：根据标签获取当前可工作流，并判断此工作流是否处于执行状态
  2015.7.29

  *************************************************************************************/
  PROCEDURE p_getlabelnoFlow(strEnterPriseNo in STOCK_LABEL_M.enterprise_no%type, --企业号
                             strwarehouse_no in STOCK_LABEL_M.warehouse_no%type, --仓别
                             strOwner_No     in bdef_defowner.owner_no%type,
                             strExp_Type     in odata_exp_m.exp_type%type,
                             strContainer_No in stock_label_m.container_no%type, --系统内部容器号
                             strFlowFlag     out wms_outorder_flow_d.flow_flag%type, --状态区间
                             strOutMsg       out varchar2) is
    --n_exp_type            stock_label_d.exp_type%type; --出货通知单类型
    n_flow_value          wms_deflabel_status.flow_value%type;
    --v_strOwnerNo          bdef_defowner.owner_no%type;
    v_strWorkflowStrategy wms_outorder.workflow_strategy_id%type; --工作流策略ID
  begin
    strOutMsg := 'N|[p_getlabelnoFlow]';

    --获取工作流策略
    begin

      select nvl(a.workflow_strategy_id, wo.workflow_strategy_id)
        into v_strWorkflowStrategy
        from wms_outorder wo
        left join (select woo.exp_type,
                          nvl(wao.workflow_strategy_id,
                              woo.workflow_strategy_id) workflow_strategy_id
                     from wms_owner_outorder woo
                     left join wms_warehouse_outorder wao
                       on wao.exp_type = woo.exp_type
                      and wao.enterprise_no = woo.enterprise_no
                      and woo.enterprise_no = strEnterPriseNo
                      and wao.exp_type = strExp_Type
                      and wao.owner_no = woo.owner_no
                      and wao.warehouse_no = strwarehouse_no
                      and woo.owner_no = strOwner_No
                      and woo.exp_type = strExp_Type) a
          on wo.exp_type = a.exp_type
       where wo.exp_type = strExp_Type
         and wo.enterprise_no = strEnterPriseNo;
    exception
      when no_data_found then
        strOutMsg := 'N|[获取不到当前出货单别对应的工作流策略!]';
        return;
    end;

    --获取客户标签状态信息工作流程
    begin
      select distinct wds.flow_value
        into n_flow_value
        from (select owner_lm.enterprise_no,
                     owner_lm.warehouse_no,
                     owner_lm.owner_container_no container_no,
                     owner_lm.status
                from stock_label_m owner_lm, stock_label_m lm
               where owner_lm.enterprise_no = lm.enterprise_no
                 and owner_lm.warehouse_no = lm.warehouse_no
                 and owner_lm.owner_container_no = lm.container_no
                 and owner_lm.container_no = strContainer_No) clm
       inner join wms_deflabel_status wds
          on wds.status_type = clm.status
       where clm.warehouse_no = strwarehouse_no
         and clm.enterprise_no = strEnterPriseNo
         and rownum = 1; --只取一条数据
    exception
      when no_data_found then
        strOutMsg := 'N|[E10000!]';
        return;
    end;

    if n_flow_value = '0' then
      --若为拣货完成的标签状态，执行工作流
      strFlowFlag := '0';
    else
      --获取客户标签工作流程
      begin
        select wof.flow_flag
          into strFlowFlag
          from wms_outorder_flow_d wof
         where wof.workflow_strategy_id = v_strWorkflowStrategy
           and wof.flow_value = n_flow_value
           and wof.enterprise_no = strEnterPriseNo;
      exception
        when no_data_found then
              strOutMsg := 'N|[E10001!]';
              return;
      end;
    end if;

    strOutMsg := 'Y|[]';
  end p_getlabelnoFlow;
  /*=====================================================================================
  hb insert to 20140719
  容器整理确认校验
  ======================================================================================*/
  PROCEDURE p_OM_AerrangeConfirmScanLabel(strEnterPriseNo in STOCK_LABEL_M.enterprise_no%type, --企业号
                                          strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                          strLabel_No     in stock_label_m.label_No%type, --标签号
                                          strOutMsg       out varchar2) is

    n_count                 number(10); --循环行数
    n_status                stock_label_m.status%type; --标签状态
    n_status_desc           wms_deflabel_status.status_type%type; --标签状态备注
    n_use_type              stock_label_m.use_type %type; --标签用途
    v_strCustNo             stock_label_m.cust_no%type;
    v_strOwnerNo            bdef_defowner.owner_No%type;
    v_strArrageComfireLevel WMS_DEFBASE.Sdefine%type; --参数的字符性值
    v_nArrageComfireLevel   WMS_DEFBASE.Ndefine%type; --参数的整数值
    v_strContainerType      stock_label_m.container_type%type;
    v_StrCanArrageComfire   WMS_DEFBASE.Sdefine%type; --参数的字符性值
    v_nCanArrageComfire     WMS_DEFBASE.Sdefine%type; --参数的字符性值
    v_strDeliverObj         stock_label_m.deliver_obj%type;
    v_iCount                integer;
    v_strWaveNo             stock_label_m.wave_no%type;
  begin
    strOutMsg := 'N|[p_OM_AerrangeConfirmScanLabel]';
    n_count   := 0;

    --判断标签是否存在
    begin
      select slm.status,
             slm.use_type,
             wds.status_type,
             slm.cust_no,
             slm.container_type,
             slm.deliver_obj,
             slm.wave_no
        into n_status,
             n_use_type,
             n_status_desc,
             v_strCustNo,
             v_strContainerType,
             v_strDeliverObj,
             v_strWaveNo
        from stock_label_m slm
        left join wms_deflabel_status wds
          on wds.status_type = slm.status
       where slm.warehouse_no = strwarehouse_no
         and slm.label_no = strLabel_No
         and slm.enterprise_no = strEnterPriseNo;
    exception
      when no_data_found then
        strOutMsg := 'N|[E22909]';
        return;
    end;

    --判断标签是否为客户标签
    if (n_use_type <> '1') then
      strOutMsg := 'N|[E22910]';
      return;
    end if;

    --判断标签状态是否正确
    if (n_status = CLabelStatus.CONFIRM or
       n_status = CLabelStatus.LOADED_IN_PAL or
       n_status = CLabelStatus.LOADED_IN_CAR or
       n_status = CLabelStatus.DIVIDE_FROM_PAL or
       n_status = CLabelStatus.WAIT_LOAD_CAR or
       n_status = CLabelStatus.DELIVERIED or
       n_status = CLabelStatus.SORTING_PASS) then
      strOutMsg := 'N|[E22911]';
      return;
    end if;

    select owner_no
      into v_strOwnerNo
      from bdef_defcust
     where enterprise_no = strEnterPriseNo
       and cust_no = v_strCustNo;

    --取系统参数
    PKLG_WMS_BASE.p_GetBasePara(strEnterpriseNo,
                                strwarehouse_no,
                                v_strOwnerNo,
                                'ArrageComfireLevel',
                                'O',
                                'O_Arrage',
                                v_strArrageComfireLevel,
                                v_nArrageComfireLevel,
                                strOutMsg);
    if (substr(strOutMsg, 1, 1) = 'N') then
      return;
    end if;

    if v_strArrageComfireLevel = '1' then

      if v_strContainerType = 'C' then
        strOutMsg := 'N|[整箱标签不能直接整理确认]';
        return;
      end if;

      --检查是否有物流箱数据
      select count(*)
        into v_iCount
        from stock_label_m t
       where t.enteRprise_no = strEnterPriseNo
         and t.warehouse_no = strwarehouse_no
         and t.container_type = 'C'
         and t.deliver_obj = v_strDeliverObj
         and t.wave_no = v_strWaveNo
         and t.status <= '61';
      if v_iCount > 0 then
        strOutMsg := 'N|[还有未处理完的箱标签不能直接整理确认]';
        return;
      end if;
    end if;

    if v_strArrageComfireLevel = '2' then
      --物流箱不能直接整理确认

      if v_strContainerType = 'B' then
        strOutMsg := 'N|[物流箱标签不能直接整理确认]';
        return;
      end if;
      --检查是否有物流箱数据
      select count(*)
        into v_iCount
        from stock_label_m t
       where t.enteRprise_no = strEnterPriseNo
         and t.warehouse_no = strwarehouse_no
         and t.container_type = 'B'
         and t.deliver_obj = v_strDeliverObj
         and t.wave_no = v_strWaveNo
         and t.status <= '61';

      if v_iCount > 0 then
        strOutMsg := 'N|[还有未处理完的物流箱标签不能直接整理确认]';
        return;
      end if;
    end if;

    if v_strArrageComfireLevel = '3' then
      if v_strContainerType = 'B' or v_strContainerType = 'C' then
        strOutMsg := 'N|[ 箱标签不能直接整理确认]';
        return;
      end if;
      --检查是否有物流箱数据
      select count(*)
        into v_iCount
        from stock_label_m t
       where t.enteRprise_no = strEnterPriseNo
         and t.warehouse_no = strwarehouse_no
         and t.container_type in ('B', 'C')
         and t.deliver_obj = v_strDeliverObj
         and t.wave_no = v_strWaveNo
         and t.status <= '61';

      if v_iCount > 0 then
        strOutMsg := 'N|[还有未处理完的物流箱标签不能直接整理确认]';
        return;
      end if;
    end if;

    --取系统参数
    PKLG_WMS_BASE.p_GetBasePara(strEnterpriseNo,
                                strwarehouse_no,
                                v_strOwnerNo,
                                'CanArrageComfire',
                                'O',
                                'O_Arrage',
                                v_StrCanArrageComfire,
                                v_nCanArrageComfire,
                                strOutMsg);
    if (substr(strOutMsg, 1, 1) = 'N') then
      return;
    end if;

    if v_StrCanArrageComfire = '1' then
      --检查是否可整理确认
      select count(*)
        into v_iCount
        from stock_label_d b, odata_locate_d c
       where b.enterprise_no = c.enterprise_no
         and b.warehouse_no = c.warehouse_no
         and b.exp_no = c.exp_no
         and b.article_no = c.article_no
         and b.enterprise_no = strEnterpriseNo
         and b.warehouse_no = strwarehouse_no
         and b.deliver_obj = v_strDeliverObj;
      if v_iCount > 0 then
        strOutMsg := 'N|[E22519]';
        return;
      end if;
      --检查是否还有拣货指示未发单
      select count(*)
        into v_iCount
        from stock_label_d b, odata_outstock_direct c
       where b.enterprise_no = c.enterprise_no
         and b.warehouse_no = c.warehouse_no
         and b.exp_no = c.exp_no
         and b.article_no = c.article_no
         and b.enterprise_no = strEnterpriseNo
         and b.warehouse_no = strWareHouse_No
         and c.status < '13'
         and b.deliver_obj = v_strDeliverObj;
      if v_iCount > 0 then
        strOutMsg := 'N|[E22520]';
        return;
      end if;

      --检查此线路是否还有拣货单未回单
      select count(*)
        into v_iCount
        from stock_label_d b, odata_outstock_d c
       where b.enterprise_no = c.enterprise_no
         and b.warehouse_no = c.warehouse_no
         and b.exp_no = c.exp_no
         and b.article_no = c.article_no
         and b.enterprise_no = strEnterpriseNo
         and b.warehouse_no = strWareHouse_No
         and b.deliver_obj = v_strDeliverObj
         and c.status < '13';
      if v_iCount > 0 then
        strOutMsg := 'N|[E22521]';
        return;
      end if;
    end if;

    --检查是否需要做装并板

    --判断标签是否存在明细
    for i_label_d in (select sld.*
                        from stock_label_m slm,
                             stock_label_m slmm,
                             stock_label_d sld
                       where slmm.warehouse_no = slm.warehouse_no
                         and slmm.owner_container_no = slm.container_no
                         and slmm.enterprise_no = slm.enterprise_no
                         and sld.warehouse_no = slmm.warehouse_no
                         and sld.container_no = slmm.container_no
                         and sld.enterprise_no = slmm.enterprise_no
                         and slm.warehouse_no = strwarehouse_no
                         and slm.enterprise_no = strEnterPriseNo
                         and slm.label_no = strLabel_No) loop

      n_count := n_count + 1;

      if (substr(i_label_d.status, 1, 1) = 'F') then
        strOutMsg := 'N|[E22912]';
        return;
      end if;

    end loop;

    if (n_count <= 0) then
      strOutMsg := 'N|[E22913]';
      return;
    end if;

    strOutMsg := 'Y|';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_OM_AerrangeConfirmScanLabel;

  /*************************************************************************************
  功能说明：
            1、扫描客户、
            2、扫描标签，校验当前标签是否属于当前客户
            2015.9.19
  ************************************************************************************/
  PROCEDURE P_CheckCustLabelScan(strEnterPriseNo in STOCK_LABEL_M.enterprise_no%type, --企业号
                                 strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                 strCurCustNo    in bdef_defcust.cust_no%type, --若没有，则传值为N
                                 strLabel_No     in stock_label_m.label_No%type, --标签号
                                 strOutMsg       out varchar2) is
    v_strCustNo bdef_defcust.cust_no%type;
  begin
    strOutMsg := 'N|[P_CheckCustLabelScan]';
    if strCurCustNo <> 'N' then
      --若没有传客户，则直接校验标签
      --获取当前标签所在客户
      begin
        select cust_no
          into v_strCustNo
          from stock_label_m t
         where t.enterprise_no = strEnterPriseNo
           and t.warehouse_no = strwarehouse_no
           and t.label_no = strLabel_No
           and t.use_type = '1';
      exception
        when no_data_found then
          strOutMsg := 'N|[此标签不存在]';
          return;
      end;

      if v_strCustNo <> strCurCustNo then
        strOutMsg := 'N|[此标签不属于该门店]';
        return;
      end if;
    end if;

    p_OM_AerrangeConfirmScanLabel(strEnterPriseNo,
                                  strwarehouse_no,
                                  strLabel_No,
                                  strOutMsg);

    if (substr(strOutMsg, 1, 1) <> 'Y') then
      return;
    end if;

    strOutMsg := 'Y|[成功]';
  end P_CheckCustLabelScan;

  /*=====================================================================================
  hb insert to 20140719
  容器整理确认
  ======================================================================================*/
  PROCEDURE p_OM_AerrangeConfirm(strEnterPriseNo in STOCK_LABEL_M.enterprise_no%type, --企业号,
                                 strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                 strLabel_No     in stock_label_m.label_No%type, --标签号
                                 strUser_Id      in stock_label_m.rgst_name%type, --操作人员
                                 strOutMsg       out varchar2) is

    n_count        number(10); --循环行数
    n_status       stock_label_m.status%type; --标签状态
    n_container_No stock_label_m.container_no%type;
    n_status_desc  wms_deflabel_status.status_type%type; --标签状态备注
    n_use_type     stock_label_m.use_type %type; --标签用途
    v_strOwnerNo   stock_label_d.owner_no%type;
    v_Exp_Type     odata_exp_m.exp_type%type;
    v_strLabel_No  stock_label_m.label_no%type;
  begin
    strOutMsg     := 'N|[p_OM_AerrangeConfirm]';
    n_count       := 0;
    v_strLabel_No := upper(strLabel_No);
    --判断标签是否存在
    begin
      select slm.status, slm.use_type, wds.status_type, slm.container_no
        into n_status, n_use_type, n_status_desc, n_container_No
        from stock_label_m slm
        left join wms_deflabel_status wds
          on wds.status_type = slm.status
       where slm.warehouse_no = strwarehouse_no
         and slm.label_no = v_strLabel_No
         and slm.enterprise_no = strEnterPriseNo;
    exception
      when no_data_found then
        strOutMsg := 'N|[E22909]';
        return;
    end;

    --判断标签是否为客户标签
    if (n_use_type <> '1') then
      strOutMsg := 'N|[E22910]';
      return;
    end if;

    --判断标签状态是否正确
    if substr(n_status, 1, 1) <> '6' or n_status >= CLabelStatus.CONFIRM then
      strOutMsg := 'N|[E22911] ' || n_status_desc || '';
      return;
    end if;
    if (n_status = CLabelStatus.CONFIRM or
       n_status = CLabelStatus.LOADED_IN_PAL or
       n_status = CLabelStatus.LOADED_IN_CAR or
       n_status = CLabelStatus.DIVIDE_FROM_PAL or
       n_status = CLabelStatus.WAIT_LOAD_CAR or
       n_status = CLabelStatus.DELIVERIED or
       n_status = CLabelStatus.SORTING_PASS) then
      strOutMsg := 'N|[E22911] ' || n_status_desc || '';
      return;
    end if;

    --判断标签是否存在明细
    for i_label_d in (select sld.*
                        from stock_label_m slm,
                             stock_label_m slmm,
                             stock_label_d sld
                       where slmm.warehouse_no = slm.warehouse_no
                         and slmm.owner_container_no = slm.container_no
                         and slmm.enterprise_no = slm.enterprise_no
                         and sld.warehouse_no = slmm.warehouse_no
                         and sld.container_no = slmm.container_no
                         and sld.enterprise_no = slmm.enterprise_no
                         and slm.warehouse_no = strwarehouse_no
                         and slm.enterprise_no = strEnterPriseNo
                         and slm.label_no = v_strLabel_No) loop

      n_count := n_count + 1;

      if (substr(i_label_d.status, 1, 1) = 'F') then
        strOutMsg := 'N|[E22912]';
        return;
      end if;

      if n_count = 1 then
        v_strOwnerNo := i_label_d.owner_no;
        v_Exp_Type:=i_label_d.exp_type;
      end if;
    end loop;

    if (n_count <= 0) then
      strOutMsg := 'N|[E22913]';
      return;
    end if;

    --更新标签头档状态为整理确认
    pkobj_label.p_updt_label_status(strEnterPriseNo,
                                    strwarehouse_no,
                                    n_container_No,
                                    strUser_Id,
                                    CLabelStatus.CONFIRM,
                                    strOutMsg);
    if (substr(strOutMsg, 1, 1) <> 'Y') then
      return;
    end if;

    --更新标签明细状态为整理确认(由于有装并板的情况所以不返回错误)
    update stock_label_d sd
       set sd.status    = CLabelStatus.CONFIRM,
           sd.updt_date = sysdate,
           sd.updt_name = strUSER_ID
     where sd.warehouse_no = strwarehouse_no
       and sd.container_no = n_container_No
       and sd.enterprise_no = strEnterPriseNo;

    --调用工作流
    p_OM_OutWorkflow(strEnterPriseNo,
                     strwarehouse_no,
                     v_strOwnerNo,
                     v_Exp_Type,
                     n_container_No, --系统内部容器号
                     strUser_Id,
                     'N', --操作人员
                     strOutMsg);
    if (substr(strOutMsg, 1, 1) <> 'Y') then
      return;
    end if;

    --写整理确认的工作量
    insert into stock_label_arrange_log
      (enterprise_no,
       warehouse_no,
       owner_no,
       source_no,
       s_label_no,
       label_no,
       row_id,
       article_no,
       packing_qty,
       qty,
       produce_date,
       expire_date,
       rgst_name,
       rgst_date,
       arrange_type)
    values
      (strEnterPriseNo,
       strwarehouse_no,
       v_strOwnerNo,
       'N',
       v_strLabel_No,
       v_strLabel_No,
       1,
       'N',
       1,
       1,
       to_date('19000101', 'yyyymmdd'),
       to_date('19000101', 'yyyymmdd'),
       strUser_Id,
       sysdate,
       '4');

    strOutMsg := 'Y|';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_OM_AerrangeConfirm;
  /*&*********************************************************************************************
  功能：1、自动装并板
        2整理确认
  ************************************************************************************************/
  PROCEDURE P_loadPalAndComfire(strEnterPriseNo in STOCK_LABEL_M.enterprise_no%type, --企业号,
                                strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                strLabelNo      in stock_label_m.label_No%type, --标签号
                                strDeliverObj   in stock_label_m.deliver_obj%type,
                                strWaveNo       in stock_label_m.wave_no%type,
                                strUserId       in stock_label_m.rgst_name%type, --操作人员
                                strOutMsg       out varchar2) is
    v_iCount    integer;
    v_strStatus stock_label_m.status%type; --目的标签状态
    v_strCustNo stock_label_m.cust_no%type;
  begin
    strOutMsg := 'N|[P_loadPalAndComfire]';

    --校验是否可装并板
    select count(*)
      into v_iCount
      from odata_outstock_direct ood
     where ood.enterprise_no = strEnterPriseNo
       and ood.warehouse_no = strwarehouse_no
       and ood.deliver_obj = strDeliverObj
       and ood.wave_no = strWaveNo;

    if v_iCount > 0 then
      strOutMsg := 'N|[还有单未做完，不能装并板]';
      return;
    end if;

    select count(*)
      into v_iCount
      from stock_label_m slm
     where slm.enterprise_no = strEnterPriseNo
       and slm.warehouse_no = strwarehouse_no
       and slm.wave_no = strWaveNo
       and slm.deliver_obj = strDeliverObj
       and slm.status < '61';

    if v_iCount > 0 then
      strOutMsg := 'N|[还有标签状态未完成，不能装并板]';
      return;
    end if;

    select count(*)
      into v_iCount
      from stock_label_m slm
     where slm.enterprise_no = strEnterPriseNo
       and slm.warehouse_no = strwarehouse_no
       and slm.wave_no = strWaveNo
       and slm.deliver_obj = strDeliverObj
       and slm.status IN ('A0', 'A1');

    if v_iCount > 0 then
      strOutMsg := 'N|[此配送对象已做整理确认 ]';
      return;
    end if;

    for GetLabel in (select label_no
                       from stock_label_m slm
                      where slm.enterprise_no = strEnterPriseNo
                        and slm.warehouse_no = strwarehouse_no
                        and slm.wave_no = strWaveNo
                        and slm.deliver_obj = strDeliverObj
                        and slm.status = '61') loop
      /*          pkcheck_odata.P_Check_Mergelabel(strEnterPriseNo,strwarehouse_no,strLabelNo,GetLabel.label_no,
               v_strStatus,v_strCustNo,strOutMsg);

      if substr(strOutMsg,1,1)='N' then
          return;
      end if;   */

      PKLG_ODATA_MOVE_JUN.p_merge_Pal(strEnterpriseNo,
                                      strwarehouse_no,
                                      GetLabel.label_no,
                                      strLabelNo,
                                      strUserId,
                                      strOutMsg);
      if substr(strOutMsg, 1, 1) = 'N' then
        return;
      end if;
    end loop;

    p_OM_AerrangeConfirm(strEnterPriseNo,
                         strwarehouse_no,
                         strLabelNo,
                         strUserId,
                         strOutMsg);
    if substr(strOutMsg, 1, 1) = 'N' then
      return;
    end if;

    strOutMsg := 'Y|[成功]';
  end P_loadPalAndComfire;

  /*=====================================================================================
  hb insert to 20160520
  出库扫描-整单扫描
  ======================================================================================*/
  PROCEDURE p_ODATA_ExpCheckScanOrder(strEnterPriseNo in odata_exp_check_m.enterprise_no%type, --企业号,
                                      strwarehouse_no in odata_exp_check_m.warehouse_no%type, --仓别
                                      strSourceexp_No in odata_exp_check_m.sourceexp_no%type, --出货来源单号
                                      strUser_Id      in odata_exp_check_m.rgst_name%type, --操作人员
                                      strOutMsg       out varchar2) is

    v_exp_no odata_exp_check_m.exp_no%type;
    v_status odata_exp_check_m.status%type;

  begin
    strOutMsg := 'N|[p_ODATA_ExpCheckScanOrder]';
    v_status  := 'N';

    --判断来源单号是否存在
    begin
      select exp_no
        into v_exp_no
        from odata_exp_m
       where enterprise_no = strEnterPriseNo
         and warehouse_no = strwarehouse_no
         and sourceexp_no = strSourceexp_No;
    exception
      when no_data_found then
        strOutMsg := 'N|[单号(' || strSourceexp_No || ')不存在或已转历史]';
        return;
    end;

    --判断当前单据是否已经出货扫描
    begin
      select status
        into v_status
        from odata_exp_check_m
       where enterprise_no = strEnterPriseNo
         and warehouse_no = strwarehouse_no
         and exp_no = v_exp_no;
    exception
      when no_data_found then
        --如未扫描 则新增
        insert into odata_exp_check_m
          (enterprise_no,
           warehouse_no,
           owner_no,
           exp_no,
           owner_cust_no,
           cust_no,
           sub_cust_no,
           sourceexp_no,
           status,
           rgst_name,
           rgst_date)
          select oem.enterprise_no,
                 oem.warehouse_no,
                 oem.owner_no,
                 oem.exp_no,
                 oem.owner_cust_no,
                 oem.cust_no,
                 oem.sub_cust_no,
                 oem.sourceexp_no,
                 '10',
                 strUser_Id,
                 sysdate
            from odata_exp_m oem
           where oem.enterprise_no = strEnterPriseNo
             and oem.warehouse_no = strwarehouse_no
             and oem.exp_no = v_exp_no;
        if sql%rowcount <= 0 then
          strOutMsg := 'N|新增复核单头档数据失败';
          return;
        end if;

        insert into odata_exp_check_d
          (enterprise_no,
           warehouse_no,
           owner_no,
           scan_no,
           exp_no,
           article_no,
           scan_packing_qty,
           packing_qty,
           plan_qty,
           scan_qty,
           status,
           row_id)
          select oed.enterprise_no,
                 oed.warehouse_no,
                 oed.owner_no,
                 'N',
                 oed.exp_no,
                 oed.article_no,
                 oed.packing_qty,
                 oed.packing_qty,
                 oed.article_qty,
                 0,
                 '10',
                 oed.row_id
            from odata_exp_d oed
           where oed.enterprise_no = strEnterPriseNo
             and oed.warehouse_no = strwarehouse_no
             and oed.exp_no = v_exp_no;
        if sql%rowcount <= 0 then
          strOutMsg := 'N|新增复核单明细数据失败';
          return;
        end if;

    end;

    if v_status = '12' then
      strOutMsg := 'N|[单据(' || strSourceexp_No || ')已经扫描完成但未审核]';
      return;
    elsif v_status = '13' then
      strOutMsg := 'N|[单据(' || strSourceexp_No || ')已经扫描完成]';
      return;
    end if;

    strOutMsg := 'Y|';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_ODATA_ExpCheckScanOrder;

  /*=====================================================================================
  hb insert to 20160522
  出库扫描-商品扫描
  ======================================================================================*/
  PROCEDURE p_ODATA_ExpCheckScanArticle(strEnterPriseNo in odata_exp_check_m.enterprise_no%type, --企业号
                                        strwarehouse_no in odata_exp_check_m.warehouse_no%type, --仓别
                                        strSourceexp_No in odata_exp_check_m.sourceexp_no%type, --出货来源单号
                                        strScan_No      in odata_exp_check_d.scan_no%type, --扫描码
                                        strArticle_No   in odata_exp_check_d.article_no%type, --商品编码
                                        nScanPackingQty in odata_exp_check_d.scan_packing_qty%type, --扫描商品所对应的包装
                                        nScanQty        in odata_exp_check_d.scan_qty%type, --扫描量
                                        nRow_Id         in odata_exp_check_d.row_id%type, --出货扫描明细行号
                                        strUser_Id      in odata_exp_check_m.rgst_name%type, --操作人员
                                        strScanFlag     out varchar2, --返回当前单据是否已经全部扫描完成(0-不是；1-是)
                                        strOutMsg       out varchar2) is

    v_count         number(10); --循环行数
    v_exp_no        odata_exp_check_m.exp_no%type; --出货单号
    v_status        odata_exp_check_m.status%type; --出货扫描头档状态
    v_detail_status odata_exp_check_d.status%type; --出货扫描明细状态
    v_planQty       odata_exp_check_d.plan_qty%type; --商品计划扫描量
    v_SanQty        odata_exp_check_d.scan_qty%type; --商品已扫描量

  begin
    strOutMsg   := 'N|[p_ODATA_ExpCheckScanArticle]';
    v_count     := 0;
    v_status    := 'N';
    strScanFlag := '0';

    --判断来源单号状态
    begin
      select status, exp_no
        into v_status, v_exp_no
        from odata_exp_check_m
       where enterprise_no = strEnterPriseNo
         and warehouse_no = strwarehouse_no
         and sourceexp_no = strSourceexp_No;
    exception
      when no_data_found then
        strOutMsg := 'N|[单号(' || strSourceexp_No || ')还未整单扫描]';
        return;
    end;

    if v_status = '12' then
      strOutMsg := 'N|[单据(' || strSourceexp_No || ')已经扫描完成但未审核]';
      return;
    elsif v_status = '13' then
      strOutMsg := 'N|[单据(' || strSourceexp_No || ')已经扫描完成]';
      return;
    end if;

    --获取出货扫描明细 状态，计划量，已扫描量
    begin
      select status, plan_qty, scan_qty
        into v_detail_status, v_planQty, v_SanQty
        from odata_exp_check_d
       where enterprise_no = strEnterPriseNo
         and warehouse_no = strwarehouse_no
         and exp_no = v_exp_no
         and article_no = strArticle_No
         and row_id = nRow_Id;
    exception
      when no_data_found then
        strOutMsg := 'N|[单号(' || strSourceexp_No || ')出货扫描没有明细数据]';
        return;
    end;

    --判断明细状态是否允许扫描
    if v_detail_status = '12' then
      strOutMsg := 'N|[单据(' || strSourceexp_No || ')明细已经扫描完成但未审核]';
      return;
    elsif v_detail_status = '13' then
      strOutMsg := 'N|[单据(' || strSourceexp_No || ')已经扫描完成]';
      return;
    end if;

    --判断明细数量是否超量
    if v_SanQty + nScanQty > v_planQty then
      strOutMsg := 'N|[单据(' || strSourceexp_No || ')已扫量(' || v_SanQty ||
                   ')加上扫描量(' || nScanQty || ')' || '大于计划扫描量(' || v_planQty ||
                   '),不允许超量 ]';
      return;
    end if;

    --修改出货扫描明细 扫描码，扫描包装，扫描数量
    update odata_exp_check_d
       set scan_no          = strScan_No,
           scan_packing_qty = nScanPackingQty,
           scan_qty         = scan_qty + nScanQty,
           status = (case
                      when v_SanQty + nScanQty = v_planQty then
                       '13'
                      else
                       '11'
                    end)
     where enterprise_no = strEnterPriseNo
       and warehouse_no = strwarehouse_no
       and exp_no = v_exp_no
       and article_no = strArticle_No
       and plan_qty >= v_SanQty + nScanQty
       and row_id = nRow_Id;
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[单据(' || strSourceexp_No || ')修改扫描明细失败]';
      return;
    end if;

    --修改头档状态为扫描中
    update odata_exp_check_m
       set status = '11', updt_name = strUser_Id, updt_date = sysdate
     where enterprise_no = strEnterPriseNo
       and warehouse_no = strwarehouse_no
       and exp_no = v_exp_no;
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[单据(' || strSourceexp_No || ')修改扫描单据状态为扫描中失败]';
      return;
    end if;

    --判断是否整单扫描完成
    select count(1)
      into v_count
      from odata_exp_check_d
     where enterprise_no = strEnterPriseNo
       and warehouse_no = strwarehouse_no
       and exp_no = v_exp_no
       and status in ('10', '11');

    --如果整单扫描完成 则修改头档状态
    if v_count <= 0 then
      update odata_exp_check_m
         set status = '13', updt_name = strUser_Id, updt_date = sysdate
       where enterprise_no = strEnterPriseNo
         and warehouse_no = strwarehouse_no
         and exp_no = v_exp_no;
      if sql%rowcount <= 0 then
        strOutMsg := 'N|[单据(' || strSourceexp_No || ')修改扫描单据状态为已审核失败]';
        return;
      end if;

      --单据已经全部扫描完成
      strScanFlag := '1';
    end if;

    strOutMsg := 'Y|';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_ODATA_ExpCheckScanArticle;

  /*=====================================================================================
  hb insert to 20160522
  出库扫描-修改强制整单扫描完成单据复核单据为已审核
  ======================================================================================*/
  PROCEDURE p_ODATA_ExpCheckUpdtMaster(strEnterPriseNo in odata_exp_check_m.enterprise_no%type, --企业号,
                                       strwarehouse_no in odata_exp_check_m.warehouse_no%type, --仓别
                                       strSourceexp_No in odata_exp_check_m.sourceexp_no%type, --出货来源单号
                                       strUser_Id      in odata_exp_check_m.rgst_name%type, --操作人员
                                       strOutMsg       out varchar2) is

    v_exp_no odata_exp_check_m.exp_no%type;
    v_status odata_exp_check_m.status%type;

  begin
    strOutMsg := 'N|[p_ODATA_ExpCheckUpdtMaster]';
    v_status  := 'N';

    --判断来源单号状态
    begin
      select status, exp_no
        into v_status, v_exp_no
        from odata_exp_check_m
       where enterprise_no = strEnterPriseNo
         and warehouse_no = strwarehouse_no
         and sourceexp_no = strSourceexp_No;
    exception
      when no_data_found then
        strOutMsg := 'N|[单号(' || strSourceexp_No || ')还未整单扫描]';
        return;
    end;

    if v_status = '11' then
      strOutMsg := 'N|[单据(' || strSourceexp_No || ')正在扫描中,不允许审核]';
      return;
    elsif v_status = '13' then
      strOutMsg := 'N|[单据(' || strSourceexp_No || ')已经扫描完成且自动审核]';
      return;
    end if;

    --修改出货扫描单据为已审核状态
    update odata_exp_check_m
       set status = '13', updt_name = strUser_Id, updt_date = sysdate
     where enterprise_no = strEnterPriseNo
       and warehouse_no = strwarehouse_no
       and exp_no = v_exp_no;
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[单据(' || strSourceexp_No || ')修改扫描单据状态为已审核失败]';
      return;
    end if;

    strOutMsg := 'Y|';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_ODATA_ExpCheckUpdtMaster;

end PKOBJ_HB;

/

