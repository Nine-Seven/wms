create view V_SEARCH_9109_4 as
select oom.warehouse_no,
       ood.outstock_name,
       bdw.worker_name,
       bag.l_group_no,
       bag.l_group_name,
       bag.m_group_no,
       bag.m_group_name,
       oom.task_type,
       ood.real_qty,
       trunc(ood.real_qty / ood.packing_qty) as real_box,
       oom.source_type,
       oom.operate_date
  from odata_outstock_mhty oom,
       odata_outstock_dhty ood,
       bdef_defarticle     bda,
       bdef_article_group  bag,
       bdef_defworker      bdw
 where oom.outstock_no = ood.outstock_no
   and ood.article_no = bda.article_no
   and bda.group_no = bag.group_no
   and oom.outstock_type = '1'
   and ood.outstock_name = bdw.worker_no


/

