create PACKAGE BODY        PKLG_CONTAINER_CALCULATE IS
  -- Author  : weiyufei
  -- Created : 2015-05-13 16:00:09
  -- Purpose : 物流箱资源试算
  /***客户物流箱试算***/

  /* \******\
    PROCEDURE P_CUST_CONTAINER_CALCULATE(strEnterPriseNo IN odata_outstock_direct.enterprise_no%TYPE, --企业
                                         strWarehouseNo  IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
                                         strWaveNo       IN ODATA_OUTSTOCK_DIRECT.WAVE_NO%TYPE, --波次号
                                         strUserId       IN ODATA_OUTSTOCK_DIRECT.UPDT_NAME%TYPE, --员工ID
                                         strPickBoxFlag  IN VARCHAR2,
                                         strCustBoxFlag  IN VARCHAR2,
                                         strErrorMsg     OUT VARCHAR2) IS
      \*OUTSDEFINE WMS_DEFBASE.SDEFINE%TYPE; --参数的字符性值*\
      v_nOutNdefine WMS_DEFBASE.NDEFINE%TYPE; --参数的整数值

      strOneDeliverOnePickPara WMS_DEFBASE.SDEFINE%TYPE; --拣货物流箱一个配送对象是否一次拣货参数

      blCalcuWeight  BOOLEAN;
      blCalcuVol     BOOLEAN;
      blCalcuPackQTY BOOLEAN;
      blSplitCustBox BOOLEAN;
      blSplitPickBox BOOLEAN;

      nMax_Weight   NUMBER;
      nMax_Vol      NUMBER;
      nMax_PackRate NUMBER;

      --是否需要新取号
      strNewContainerNo VARCHAR2(20);
      strOutLabelNo     VARCHAR2(20);
      strSESSION_ID     VARCHAR2(20);
      --计算范围不同，新取容器号
      strCalculateRange    VARCHAR2(100);
      strCurrCellCondition VARCHAR2(100);
      strCurrCalculateRage VARCHAR2(100);
      strOldBatchNo        VARCHAR2(10);
      strCellCondition     VARCHAR2(100);
      --重量
      nCurr_Weight    NUMBER;
      nUnallot_Weight NUMBER;
      v_Count         integer := 0;
      --材积
      nCurr_Vol    NUMBER;
      nUnAllot_Vol NUMBER;
      --包装量
      nCurr_PackRate    NUMBER;
      nUnAllot_PackRate NUMBER;

      nUseType        NUMBER; --物流箱标识
      strOutstockType VARCHAR2(1); --下架类型

      v_blCutBoxFlag boolean;
    BEGIN
      nMax_PackRate   := 1;
      nUseType        := 0; --客户物流箱
      strOutstockType := '0'; --出货拣货

      --获取拣货物流箱一个配送对象是否一次拣货参数
      PKLG_WMS_BASE.p_GetBasePara(strEnterPriseNo,
                                  strWarehouseNo,
                                  '',
                                  'OneDeliverObjOnePick',
                                  'O',
                                  'O_LOCATE',
                                  strOneDeliverOnePickPara,
                                  v_nOutNdefine,
                                  strErrorMsg);
      IF (SUBSTR(strErrorMsg, 1, 1) = 'N') THEN
        RETURN;
      END IF;

      --获取系统参数
      P_GET_SYS_PARAM(strEnterPriseNo,
                      strWarehouseNo,
                      '',
                      nUseType,
                      blCalcuWeight,
                      blCalcuVol,
                      blCalcuPackQTY,
                      blSplitCustBox,
                      blSplitPickBox,
                      nMax_Vol,
                      nMax_Weight,
                      strErrorMsg);
      IF (SUBSTR(strErrorMsg, 1, 1) = 'N') THEN
        RETURN;
      END IF;
      nUnallot_Weight   := nMax_Weight;
      nUnAllot_Vol      := nMax_Vol;
      nUnAllot_PackRate := nMax_PackRate;

      strCalculateRange := '*';
      strOldBatchNo     := '';
      --获取下架指示
      strCurrCalculateRage := '*';
      FOR v_csOutDirect IN (SELECT OOD.WAREHOUSE_NO,
                                   OOD.OUTSTOCK_TYPE,
                                   OOD.OPERATE_TYPE,
                                   OOD.OPERATE_DATE,
                                   OOD.PICK_TYPE,
                                   OOD.WAVE_NO,
                                   OOD.BATCH_NO,
                                   OOD.PRIORITY,
                                   OOD.CUST_NO,
                                   OOD.EXP_NO,
                                   OOD.EXP_TYPE,
                                   OOD.S_CELL_NO,
                                   OOD.ARTICLE_NO,
                                   OOD.LOCATE_QTY,
                                   OOD.DELIVER_OBJ,
                                   OOD.STATUS,
                                   OOD.DIRECT_SERIAL,
                                   ood.supp_count,
                                   CDA.AREA_TYPE,
                                   --外贸标识
                                   bda.divide_box,
                                   bda.qmin_operate_packing,
                                   bdc.trade_flag,
                                   bdc.CONTAINER_MATERIAL,
                                   bda.cumulative_volumn,
                                   (bda.unit_volumn * ood.locate_qty) SUM_ARTICLE_VOL,
                                   \*                                 (bda.unit_volumn + (ood.locate_qty - 1) *
                                   bda.CUMULATIVE_VOLUMN) SUM_ARTICLE_VOL,*\
                                   (ood.locate_qty * bda.unit_weight) SUM_ARTICLE_WEIGHT,
                                   NVL(ROUND(ood.locate_qty / ood.packing_qty,
                                             4),
                                       0.01) SUM_ARTICLE_PACK,

                                   bda.unit_volumn,
                                   bda.unit_weight,
                                   ood.packing_qty unit_packrate,
                                   CDA.B_PICK,
                                   --1：按储区；2：按通道；3：按储区+层；4：按巷道+层；5：按电子标签区域；
                                   (CASE NVL(otad.ALLOT_RULE, wtr.ALLOT_RULE)
                                     WHEN '0' THEN
                                      CDC.WARE_NO
                                     WHEN '1' THEN
                                      (CDC.WARE_NO || CDC.AREA_NO)
                                     WHEN '2' THEN
                                      (CDC.WARE_NO || CDC.AREA_NO ||
                                      CDC.STOCK_NO)
                                     WHEN '3' THEN
                                      (CDC.WARE_NO || CDC.AREA_NO ||
                                      CDC.STOCK_Y)
                                     WHEN '4' THEN
                                      (CDC.WARE_NO || CDC.AREA_NO ||
                                      CDC.STOCK_NO || CDC.STOCK_Y)
                                     WHEN '5' THEN
                                      TO_CHAR(NVL(CDD.DPS_AREA, 0))
                                     ELSE
                                      ''
                                   END) ROUTE_CUT_MODE,
                                   NVL(CDD.DPS_AREA, 0) DPS_AREA
                              FROM ODATA_OUTSTOCK_DIRECT OOD
                            --商品信息
                             inner join bdef_defarticle bda
                                on ood.enterprise_no = bda.enterprise_no
                               and ood.article_no = bda.article_no
                            --储位
                             INNER JOIN cdef_DEFCELL CDC
                                ON cdc.enterprise_no = ood.enterprise_no
                               and OOD.S_CELL_NO = CDC.CELL_NO
                               AND OOD.WAREHOUSE_NO = CDC.WAREHOUSE_NO
                            --区域类型
                             INNER JOIN cdef_DEFAREA CDA
                                ON cdc.enterprise_no = cda.enterprise_no
                               and CDC.WAREHOUSE_NO = CDA.WAREHOUSE_NO
                               AND CDC.WARE_NO = CDA.WARE_NO
                               AND CDC.AREA_NO = CDA.AREA_NO
                            --电子标签区域
                              LEFT JOIN cdef_DEFCELL_DPS CDD
                                ON cdd.enterprise_no = cdd.enterprise_no
                               and OOD.S_CELL_NO = CDD.CELL_NO
                               AND OOD.WAREHOUSE_NO = CDD.WAREHOUSE_NO
                               AND CDD.USE_TYPE = '1'
                            --零散拣货位
                              left join cset_cell_article cca
                                on ood.enterprise_no = cca.enterprise_no
                               and ood.WAREHOUSE_NO = cca.WAREHOUSE_NO
                               and ood.article_no = cca.ARTICLE_NO
                               and ood.owner_no = cca.owner_no
                               and cca.pick_type = 'B'
                            --客户表
                             inner join bdef_defcust bdc
                                on bdc.enterprise_no = ood.enterprise_no
                               and bdc.owner_no = ood.owner_no
                               and bdc.cust_no = ood.cust_no

                            --拣货切单方式
                             INNER JOIN wms_taskallot_rule wtr
                                on wtr.operate_type = ood.operate_type
                               and wtr.outstock_type = ood.outstock_type
                              left join oset_task_allot_d otad
                                on otad.enterprise_no = ood.enterprise_no
                               and otad.warehouse_no = ood.warehouse_no
                               and otad.outstock_type = ood.outstock_type
                               and otad.source_type = ood.source_type
                               and otad.operate_type = ood.operate_type
                               and otad.task_id = cda.task_id
                             WHERE OOD.TEMP_STATUS < '16'
                               and ood.enterprise_no = strEnterPriseNo
                               AND OOD.WAREHOUSE_NO = strWarehouseNo
                               AND OOD.WAVE_NO = strWaveNo
                               AND OOD.OUTSTOCK_TYPE = strOutstockType
                               AND (OOD.OPERATE_TYPE = 'B' OR
                                   OOD.OPERATE_TYPE = 'D')
                               and NVL(OOD.CUST_CONTAINER_NO, 'N') = 'N'
                             ORDER BY OOD.PRIORITY DESC,
                                      OOD.BATCH_NO,
                                      OOD.OUTSTOCK_TYPE,
                                      OOD.OPERATE_TYPE,
                                      OOD.PICK_TYPE DESC,
                                      case
                                        when strOneDeliverOnePickPara = '0' then
                                         OOD.STATUS
                                        else
                                         '0'
                                      end,
                                      ROUTE_CUT_MODE,
                                      OOD.Deliver_Obj,
                                      cdc.stock_no,
                                      DPS_AREA,
                                      cdc.pick_order,
                                      OOD.S_CELL_NO,
                                      OOD.ARTICLE_NO,
                                      ood.supp_count) LOOP
        BEGIN
          --Add BY QZH AT 2016-4-14
          v_Count := v_Count + 1;
          if v_Count = 1 then
            P_GET_CONTAINER_VOLUMN(strEnterPriseNo,
                                   strWarehouseNo,
                                   'B',
                                   nUseType,
                                   'B',
                                   v_csOutDirect.CONTAINER_MATERIAL,
                                   nMax_Weight,
                                   nMax_Vol,
                                   strErrorMsg);
            IF (SUBSTR(strErrorMsg, 1, 1) = 'N') THEN
              RETURN;
            END IF;

            nUnallot_Weight := nMax_Weight;
            nUnAllot_Vol    := nMax_Vol;
          end if;
          --Add End

          --批次更换
          IF strOldBatchNo <> v_csOutDirect.BATCH_NO or strOldBatchNo is null THEN
            strOldBatchNo := v_csOutDirect.BATCH_NO;
          END IF;

          strCalculateRange := v_csOutDirect.WAREHOUSE_NO ||
                               v_csOutDirect.OUTSTOCK_TYPE ||
                               v_csOutDirect.OPERATE_TYPE ||
                               v_csOutDirect.PICK_TYPE ||
                               v_csOutDirect.BATCH_NO ||
                               v_csOutDirect.WAVE_NO ||
                               v_csOutDirect.PRIORITY ||
                               v_csOutDirect.AREA_TYPE;
          --外贸客户
          IF v_csOutDirect.Trade_Flag = '1' THEN
            strCalculateRange := strCalculateRange ||
                                 v_csOutDirect.DIVIDE_BOX;
          END IF;
          --按配送对象成箱
          strCalculateRange := strCalculateRange || v_csOutDirect.DELIVER_OBJ;
          --同一个配送对象不一次性拣货
          IF strOneDeliverOnePickPara = '0' THEN
            strCalculateRange := strCalculateRange || v_csOutDirect.STATUS;
          END IF;
          --切单区域方式
          strCalculateRange := strCalculateRange ||
                               v_csOutDirect.ROUTE_CUT_MODE;

          ------同一储位同一商品
          strCurrCellCondition := v_csOutDirect.WAREHOUSE_NO ||
                                  v_csOutDirect.WAVE_NO ||
                                  v_csOutDirect.BATCH_NO ||
                                  v_csOutDirect.S_CELL_NO ||
                                  v_csOutDirect.ARTICLE_NO;

          ------当前商品材积等信息
          nCurr_Vol := v_csOutDirect.SUM_ARTICLE_VOL;
          --如果同货位同商品
          IF strCellCondition = strCurrCellCondition THEN
            nCurr_Vol := nCurr_Vol - v_csOutDirect.Unit_Volumn +
                         v_csOutDirect.Cumulative_Volumn;
          end if;
          nCurr_PackRate := v_csOutDirect.SUM_ARTICLE_PACK;
          nCurr_Weight   := v_csOutDirect.SUM_ARTICLE_WEIGHT;

          v_blCutBoxFlag := false;
          --成箱范围一样，进行体积、重量等判断
          IF (strCurrCalculateRage = '*' or --第一条记录或达到切箱范围
             strCurrCalculateRage <> strCalculateRange) then
            v_blCutBoxFlag := true;
          end if;

          if v_blCutBoxFlag = false and
             (v_csOutDirect.B_PICK = '2' and --如果真正物流箱试算
             ((nUnallot_Weight < v_csOutDirect.SUM_ARTICLE_WEIGHT AND --可放重量小于当前商品重量
             blCalcuWeight = TRUE) OR
             (nUnAllot_PackRate < v_csOutDirect.SUM_ARTICLE_PACK AND
             blCalcuPackQTY = TRUE) OR
             (nUnAllot_Vol < v_csOutDirect.SUM_ARTICLE_VOL AND
             blCalcuVol = TRUE))) THEN

            --如果允许拆箱
            IF blSplitCustBox = TRUE THEN
              v_blCutBoxFlag := true;
            else
              --不允许拆箱，且与上一商品不同货位不同商品
              IF strCellCondition <> strCurrCellCondition THEN
                v_blCutBoxFlag := true;
              end if;
            end if;
          end if;

          --减去已装箱的材积
          IF blCalcuWeight = TRUE THEN
            nUnallot_Weight := nUnallot_Weight - nCurr_Weight;

            if nUnallot_Weight < 0 then
              v_blCutBoxFlag := true;
            end if;
          END IF;

          IF blCalcuVol = TRUE THEN
            nUnAllot_Vol := nUnAllot_Vol - nCurr_Vol;
            if nUnAllot_Vol < 0 then
              v_blCutBoxFlag := true;
            end if;
          END IF;

          IF blCalcuPackQTY = TRUE THEN
            nUnAllot_PackRate := nUnAllot_PackRate - nCurr_PackRate;
            if nUnAllot_PackRate < 0 then
              v_blCutBoxFlag := true;
            end if;
          END IF;

          if v_blCutBoxFlag = true then
            pklg_wms_base.p_get_ContainerNoBase(strEnterPriseNo,
                                                strWarehouseNo,
                                                'B',
                                                strUserId,
                                                'D',
                                                1,
                                                nUseType,
                                                '',
                                                strOutLabelNo,
                                                strNewContainerNo,
                                                strSESSION_ID,
                                                strErrorMsg);
            IF (SUBSTR(strErrorMsg, 1, 1) = 'N') THEN
              RETURN;
            END IF;

            --Add BY QZH AT 2016-4-14
            P_GET_CONTAINER_VOLUMN(strEnterPriseNo,
                                   strWarehouseNo,
                                   'B',
                                   nUseType,
                                   'B',
                                   v_csOutDirect.CONTAINER_MATERIAL,
                                   nMax_Weight,
                                   nMax_Vol,
                                   strErrorMsg);
            IF (SUBSTR(strErrorMsg, 1, 1) = 'N') THEN
              RETURN;
            END IF;
            --Add End

            --如果直正物流箱试算，并且同商品可拆箱
            IF v_csOutDirect.B_PICK = '2' and blSplitCustBox = TRUE THEN
              --商品折箱,预留

              P_SPLIT_OUTSTOCKDIRECT(strEnterPriseNo, --企业
                                     strWarehouseNo, --仓别
                                     v_csOutDirect.DIRECT_SERIAL, --指示ID
                                     v_csOutDirect.Locate_Qty,
                                     v_csOutDirect.Qmin_Operate_Packing,
                                     nMax_Weight,
                                     nMax_Vol,
                                     nMax_PackRate,
                                     v_csOutDirect.Unit_Weight,
                                     v_csOutDirect.Unit_Volumn,
                                     v_csOutDirect.Unit_Packrate,
                                     v_csOutDirect.Cumulative_Volumn,
                                     1, --1为客户标签，0为拣货标签
                                     nUseType,
                                     strUserId, --员工ID
                                     blCalcuWeight,
                                     blCalcuVol,
                                     blCalcuPackQTY,
                                     nUnallot_Weight,
                                     nUnAllot_Vol,
                                     nUnAllot_PackRate,
                                     nCurr_Weight,
                                     nCurr_Vol,
                                     nCurr_PackRate,
                                     strNewContainerNo,
                                     strErrorMsg);

            else
              --
              nUnallot_Weight   := nMax_Weight;
              nUnAllot_Vol      := nMax_Vol;
              nUnAllot_PackRate := nMax_PackRate;

            end if;

          end if;

          --修改出货下架指示
          UPDATE ODATA_OUTSTOCK_DIRECT t
             SET t.UPDT_DATE         = SYSDATE,
                 t.UPDT_NAME         = strUserId,
                 t.CUST_CONTAINER_NO = strNewContainerNo,
                 T.PICK_CONTAINER_NO = strNewContainerNo,
                 t.s_container_no    = strNewContainerNo
           WHERE t.enterprise_no = strEnterPriseNo
             and t.WAREHOUSE_NO = strWarehouseNo
             AND t.DIRECT_SERIAL = v_csOutDirect.DIRECT_SERIAL;

          IF SQL%ROWCOUNT <= 0 THEN
            strErrorMsg := 'N|更新指示失败，未更新到数据';
            RETURN;
          END IF;

          --按储位按商品计算
          strCellCondition := strCurrCellCondition;

          --成单范围
          strCurrCalculateRage := strCalculateRange;

        END;
      END LOOP;

      strErrorMsg := 'Y';
    EXCEPTION
      WHEN OTHERS THEN
        strErrorMsg := 'N|' || SQLCODE || ' ' || SQLERRM ||
                       SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
    END P_CUST_CONTAINER_CALCULATE;
  */

  --计算摘果物流箱--支持电商规则 Add BY QZH AT 2016-6-6
  PROCEDURE P_CONTAINER_CALCULATE_PICK(strEnterPriseNo IN odata_outstock_direct.enterprise_no%TYPE, --企业
                                       strWarehouseNo  IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
                                       strWaveNo       IN ODATA_OUTSTOCK_DIRECT.WAVE_NO%TYPE, --波次号
                                       strUserId       IN ODATA_OUTSTOCK_DIRECT.UPDT_NAME%TYPE, --员工ID
                                       --strPickBoxFlag  IN VARCHAR2,
                                       --strCustBoxFlag  IN VARCHAR2,
                                       strErrorMsg OUT VARCHAR2) IS

    blCalcuWeight  BOOLEAN;
    blCalcuVol     BOOLEAN;
    blCalcuPackQTY BOOLEAN;
    blSplitBox     BOOLEAN;
    --blSplitPickBox BOOLEAN;

    nMax_Weight   NUMBER;
    nMax_Vol      NUMBER;
    nMax_PackRate NUMBER;
    v_nMaxOrders  number;

    --v_VolFlag         varchar2(1) := '0';
    v_RuleID      WMS_LOGIBOX_RULE.Allot_Rule%type;
    v_nOrderCount number := 0;
    v_nItems      number := 0;
    nMaxItems     number := 0;
    v_lstExp_No   VARCHAR2(32767);
    --strCurr_ExpNo     odata_exp_m.exp_no%type;
    strCurr_ArticleNo bdef_defarticle.article_no%type;

    --是否需要新取号
    strNewContainerNo VARCHAR2(20);
    strOutLabelNo     VARCHAR2(20);
    strSESSION_ID     VARCHAR2(20);
    --计算范围不同，新取容器号
    strCalculateRange    VARCHAR2(100);
    strCurrCellCondition VARCHAR2(100);
    strCurrCalculateRage VARCHAR2(100);
    strOldBatchNo        VARCHAR2(10);
    strCellCondition     VARCHAR2(100);
    --重量
    nCurr_Weight    NUMBER;
    nUnallot_Weight NUMBER;
    v_Count         integer := 0;
    --材积
    nCurr_Vol    NUMBER;
    nUnAllot_Vol NUMBER;
    --包装量
    nCurr_PackRate    NUMBER;
    nUnAllot_PackRate NUMBER;

    nUseType        NUMBER; --物流箱标识
    strOutstockType VARCHAR2(1); --下架类型

    v_blCutBoxFlag boolean;
  BEGIN
    nMax_PackRate   := 1;
    nUseType        := 0; --客户物流箱
    strOutstockType := '0'; --出货拣货

    --获取系统参数
    P_GET_SYS_PARAM(strEnterPriseNo,
                    strWarehouseNo,
                    '',
                    nUseType,
                    --blCalcuWeight,
                    --blCalcuVol,
                    --blCalcuPackQTY,
                    --blSplitCustBox,
                    --blSplitPickBox,
                    nMax_Vol,
                    nMax_Weight,
                    strErrorMsg);
    IF (SUBSTR(strErrorMsg, 1, 1) = 'N') THEN
      RETURN;
    END IF;

    for cs_BatchRule in (select A.*, b.batch_no
                           from WMS_LOGIBOX_RULE A, ODATA_LOCATE_BATCH B
                          WHERE A.ENTERPRISE_NO = B.ENTERPRISE_NO
                            AND A.RULE_ID = B.CUST_LOGIBOX_RULE_ID --物流箱试算策略
                            and B.WAREHOUSE_NO = strWarehouseNo
                            AND B.ENTERPRISE_NO = strEnterPriseNo
                            and b.wave_no = strWaveNo) loop

      v_lstExp_No   := 'N'; --空值不能用着比较 所以初始值复制为'N' huangb 20160701
      v_nMaxOrders  := cs_BatchRule.Allot_Rule_Value; --多少个订单（配送对象）一个物流箱 huangb 20160701
      nMaxItems     := cs_BatchRule.box_sku_limit;
      blCalcuVol    := false;
      blCalcuWeight := false;
      v_Count       := 0;
      v_RuleID      := cs_BatchRule.Allot_Rule;

      --按区域
      if cs_BatchRule.Allot_Rule = '0' then
        if cs_BatchRule.Vol_Flag = '1' then
          blCalcuVol := true;
        end if;
        if cs_BatchRule.Weight_Flag = '1' then
          blCalcuWeight := true;
        end if;
      end if;

      --按订单数,配送对象，不参考SKU数限制
      if cs_BatchRule.Allot_Rule in ('1', '2') then
        nMaxItems := 0;
      end if;

      if cs_BatchRule.Allot_Rule in ('2') then
         v_nMaxOrders:=1;
      end if;

      --按商品，SKU数强制为1
      if cs_BatchRule.Allot_Rule = '3' then
        nMaxItems := 1;
      end if;

      nUnallot_Weight   := nMax_Weight;
      nUnAllot_Vol      := nMax_Vol;
      nUnAllot_PackRate := nMax_PackRate;

      strCalculateRange := '*';
      strOldBatchNo     := '';

      --是否支持拆箱
      if cs_BatchRule.Splitbox_Flag = '1' then
        blSplitBox := true;
      else
        blSplitBox := true;
      end if;

      --获取下架指示
      strCurrCalculateRage := '*';
      FOR v_csOutDirect IN (SELECT OOD.WAREHOUSE_NO,
                                   OOD.OUTSTOCK_TYPE,
                                   OOD.OPERATE_TYPE,
                                   OOD.OPERATE_DATE,
                                   OOD.PICK_TYPE,
                                   OOD.WAVE_NO,
                                   OOD.BATCH_NO,
                                   OOD.PRIORITY,
                                   OOD.CUST_NO,
                                   OOD.EXP_NO,
                                   OOD.EXP_TYPE,
                                   OOD.S_CELL_NO,
                                   OOD.ARTICLE_NO,
                                   OOD.LOCATE_QTY,
                                   OOD.DELIVER_OBJ,
                                   OOD.STATUS,
                                   OOD.DIRECT_SERIAL,
                                   ood.supp_count,
                                   CDA.AREA_TYPE,
                                   --外贸标识
                                   bda.divide_box,
                                   bda.qmin_operate_packing,
                                   bdc.trade_flag,
                                   bdc.CONTAINER_MATERIAL,
                                   bda.cumulative_volumn,
                                   (bda.unit_volumn +
                                   bda.cumulative_volumn *
                                   (ood.locate_qty -
                                   bda.qmin_operate_packing)) SUM_ARTICLE_VOL,
                                   (ood.locate_qty * bda.unit_weight) SUM_ARTICLE_WEIGHT,
                                   NVL(ROUND(ood.locate_qty /
                                             ood.packing_qty,
                                             4),
                                       0.01) SUM_ARTICLE_PACK,
                                   bda.unit_volumn,
                                   bda.unit_weight,
                                   ood.packing_qty unit_packrate,
                                   CDA.B_PICK,
                                   --1：按仓区；2-按储区；3-按通道；4：按储区+层；5：按巷道+层；6：按电子标签区域；
                                   (CASE cs_BatchRule.Area_Rule
                                     WHEN '1' THEN
                                      CDC.WARE_NO
                                     WHEN '2' THEN
                                      (CDC.WARE_NO || CDC.AREA_NO)
                                     WHEN '3' THEN
                                      (CDC.WARE_NO || CDC.AREA_NO ||
                                      CDC.STOCK_NO)
                                     WHEN '4' THEN
                                      (CDC.WARE_NO || CDC.AREA_NO ||
                                      CDC.STOCK_Y)
                                     WHEN '5' THEN
                                      (CDC.WARE_NO || CDC.AREA_NO ||
                                      CDC.STOCK_NO || CDC.STOCK_Y)
                                     WHEN '6' THEN
                                      TO_CHAR(NVL(CDD.DPS_AREA, 0))
                                     ELSE
                                      ''
                                   END) ROUTE_CUT_MODE,
                                   NVL(CDD.DPS_AREA, 0) DPS_AREA
                              FROM ODATA_OUTSTOCK_DIRECT OOD
                            --商品信息
                             inner join bdef_defarticle bda
                                on ood.enterprise_no = bda.enterprise_no
                               and ood.article_no = bda.article_no
                            --储位
                             INNER JOIN cdef_DEFCELL CDC
                                ON cdc.enterprise_no = ood.enterprise_no
                               and OOD.S_CELL_NO = CDC.CELL_NO
                               AND OOD.WAREHOUSE_NO = CDC.WAREHOUSE_NO
                            --区域类型
                             INNER JOIN cdef_DEFAREA CDA
                                ON cdc.enterprise_no = cda.enterprise_no
                               and CDC.WAREHOUSE_NO = CDA.WAREHOUSE_NO
                               AND CDC.WARE_NO = CDA.WARE_NO
                               AND CDC.AREA_NO = CDA.AREA_NO
                            --电子标签区域
                              LEFT JOIN cdef_DEFCELL_DPS CDD
                                ON cdd.enterprise_no = cdd.enterprise_no
                               and OOD.S_CELL_NO = CDD.CELL_NO
                               AND OOD.WAREHOUSE_NO = CDD.WAREHOUSE_NO
                               AND CDD.USE_TYPE = '1'
                            --客户表
                             inner join bdef_defcust bdc
                                on bdc.enterprise_no = ood.enterprise_no
                               and bdc.owner_no = ood.owner_no
                               and bdc.cust_no = ood.cust_no
                             WHERE OOD.Status < '13'
                               and ood.enterprise_no = strEnterPriseNo
                               AND OOD.WAREHOUSE_NO = strWarehouseNo
                               AND OOD.WAVE_NO = strWaveNo
                               and ood.batch_no = cs_BatchRule.Batch_No
                               AND OOD.OUTSTOCK_TYPE = strOutstockType
                               AND OOD.OPERATE_TYPE = 'B'
                               and NVL(OOD.s_Container_No, 'N') = 'N'
                               AND OOD.PICK_TYPE = '0' --摘果
                             ORDER BY OOD.PRIORITY DESC,
                                      OOD.BATCH_NO,
                                      OOD.OUTSTOCK_TYPE,
                                      OOD.OPERATE_TYPE,
                                      OOD.PICK_TYPE DESC,
                                      CASE cs_BatchRule.Allot_Rule
                                        WHEN '2' THEN --按配送对象
                                         ood.deliver_obj
                                        WHEN '3' THEN --接商品
                                         ood.article_no
                                        else
                                         '0'
                                      end,
                                      case
                                        when cs_BatchRule.Onedeliveronepick = '0' then
                                         OOD.STATUS
                                        else
                                         '0'
                                      end,
                                      ROUTE_CUT_MODE,
                                      OOD.Deliver_Obj,
                                      cdc.stock_no,
                                      DPS_AREA,
                                      cdc.pick_order,
                                      OOD.S_CELL_NO,
                                      OOD.ARTICLE_NO,
                                      ood.supp_count) LOOP

        --Add BY QZH AT 2016-4-14
        v_Count := v_Count + 1;

        --区域是虚拟物流箱计算规则
        if v_csOutDirect.B_PICK = '1' then
          blCalcuVol    := false;
          blCalcuWeight := false;
        end if;

        v_blCutBoxFlag := false;

        if v_Count = 1 then
          P_GET_CONTAINER_VOLUMN(strEnterPriseNo,
                                 strWarehouseNo,
                                 'B',
                                 nUseType,
                                 'B',
                                 v_csOutDirect.CONTAINER_MATERIAL,
                                 nMax_Weight,
                                 nMax_Vol,
                                 strErrorMsg);
          IF (SUBSTR(strErrorMsg, 1, 1) = 'N') THEN
            RETURN;
          END IF;
          v_blCutBoxFlag  := true;
          nUnallot_Weight := nMax_Weight;
          nUnAllot_Vol    := nMax_Vol;
        end if;
        --Add End

        --批次更换
        IF strOldBatchNo <> v_csOutDirect.BATCH_NO or strOldBatchNo is null THEN
          strOldBatchNo := v_csOutDirect.BATCH_NO;
        END IF;

        strCalculateRange := v_csOutDirect.WAREHOUSE_NO ||
                             v_csOutDirect.OUTSTOCK_TYPE ||
                             v_csOutDirect.OPERATE_TYPE ||
                             v_csOutDirect.PICK_TYPE ||
                             v_csOutDirect.BATCH_NO ||
                             v_csOutDirect.WAVE_NO ||
                             v_csOutDirect.PRIORITY;

        case v_RuleID
        --按订单数
          when '1' then
            if instr(v_lstExp_No, '{' || v_csOutDirect.Exp_No || '}') <= 0 then
              v_lstExp_No   := v_lstExp_No || ',' || '{' ||
                               v_csOutDirect.Exp_No || '}';
              v_nOrderCount := v_nOrderCount + 1;
              if v_nOrderCount > v_nMaxOrders then
                v_blCutBoxFlag := true;
                v_lstExp_No    := '{' || v_csOutDirect.Exp_No || '}';
                v_nOrderCount  := 1;
              end if;
            end if;
            --按配送对象
          when '2' then
            if instr(v_lstExp_No, '{' || v_csOutDirect.deliver_obj || '}') <= 0 then
              v_lstExp_No   := v_lstExp_No || ',' || '{' ||
                               v_csOutDirect.deliver_obj || '}';
              v_nOrderCount := v_nOrderCount + 1;
              --配送对象不参考订单数值
              if v_nOrderCount > v_nMaxOrders then
                --if v_nOrderCount > nMaxItems then
                v_blCutBoxFlag := true;
                v_lstExp_No    := '{' || v_csOutDirect.deliver_obj || '}';
                v_nOrderCount  := 1;
              end if;
            end if;
            --按商品
          when '3' then
            if strCurr_ArticleNo <> v_csOutDirect.Article_No then
              v_nItems := v_nItems + 1;
            end if;
            if v_nItems > nMaxItems and nMaxItems > 0 then
              v_blCutBoxFlag    := true;
              strCurr_ArticleNo := v_csOutDirect.Article_No;
              v_nItems          := 1;
            end if;
          else
            null;
        end case;

        --同一个配送对象不需要一次性拣货
        IF cs_BatchRule.Onedeliveronepick = '0' THEN
          strCalculateRange := strCalculateRange || v_csOutDirect.STATUS;
        END IF;

        --参考区域规则
        if cs_BatchRule.Area_Rule > '0' then

          --切单区域方式
          strCalculateRange := strCalculateRange ||
                               v_csOutDirect.ROUTE_CUT_MODE;

          --外贸客户
          IF v_csOutDirect.Trade_Flag = '1' THEN
            strCalculateRange := strCalculateRange ||
                                 v_csOutDirect.DIVIDE_BOX;
          END IF;

          --按客户成箱
          strCalculateRange := strCalculateRange ||
                               v_csOutDirect.Cust_No;

          ------同一储位同一商品
          strCurrCellCondition := v_csOutDirect.WAREHOUSE_NO ||
                                  v_csOutDirect.WAVE_NO ||
                                  v_csOutDirect.BATCH_NO ||
                                  v_csOutDirect.S_CELL_NO ||
                                  v_csOutDirect.ARTICLE_NO;

          ------当前商品材积等信息
          nCurr_Vol := v_csOutDirect.SUM_ARTICLE_VOL;
          --如果同货位同商品
          if strCellCondition = strCurrCellCondition THEN
            nCurr_Vol := nCurr_Vol-v_csOutDirect.Unit_Volumn;
          end if;
          nCurr_PackRate := v_csOutDirect.SUM_ARTICLE_PACK;
          nCurr_Weight   := v_csOutDirect.SUM_ARTICLE_WEIGHT;

          --成箱范围一样，进行体积、重量等判断
          IF (strCurrCalculateRage = '*' or --第一条记录或达到切箱范围
             strCurrCalculateRage <> strCalculateRange) then
            v_blCutBoxFlag := true;
          end if;

          if v_blCutBoxFlag = false and
             (v_csOutDirect.B_PICK = '2' and --如果真正物流箱试算
             ((nUnallot_Weight < v_csOutDirect.SUM_ARTICLE_WEIGHT AND --可放重量小于当前商品重量
             blCalcuWeight = TRUE) OR
             (nUnAllot_PackRate < v_csOutDirect.SUM_ARTICLE_PACK AND
             blCalcuPackQTY = TRUE) OR
             (nUnAllot_Vol < v_csOutDirect.SUM_ARTICLE_VOL AND
             blCalcuVol = TRUE))) THEN

            --如果允许拆箱
            IF blSplitBox = TRUE THEN
              v_blCutBoxFlag := true;
            else
              --不允许拆箱，且与上一商品不同货位不同商品
              IF strCellCondition <> strCurrCellCondition THEN
                v_blCutBoxFlag := true;
              end if;
            end if;
          end if;

          --减去已装箱的材积
          if nUnallot_Weight < 0 then
            v_blCutBoxFlag := true;
          end if;

          if nUnAllot_Vol < 0 then
            v_blCutBoxFlag := true;
          end if;

          if nUnAllot_PackRate < 0 then
            v_blCutBoxFlag := true;
          end if;

        end if;

        if v_blCutBoxFlag = true then
          pklg_wms_base.p_get_ContainerNoBase(strEnterPriseNo,
                                              strWarehouseNo,
                                              'B',
                                              strUserId,
                                              'D',
                                              1,
                                              nUseType,
                                              '',
                                              strOutLabelNo,
                                              strNewContainerNo,
                                              strSESSION_ID,
                                              strErrorMsg);
          IF (SUBSTR(strErrorMsg, 1, 1) = 'N') THEN
            RETURN;
          END IF;

          --Add BY QZH AT 2016-4-14
          P_GET_CONTAINER_VOLUMN(strEnterPriseNo,
                                 strWarehouseNo,
                                 'B',
                                 nUseType,
                                 'B',
                                 v_csOutDirect.CONTAINER_MATERIAL,
                                 nMax_Weight,
                                 nMax_Vol,
                                 strErrorMsg);
          IF (SUBSTR(strErrorMsg, 1, 1) = 'N') THEN
            RETURN;
          END IF;
          --Add End

          /*--如果直正物流箱试算，并且同商品可拆箱
          IF v_csOutDirect.B_PICK = '2' and blSplitBox = TRUE THEN
            --商品折箱,预留

            P_SPLIT_OUTSTOCKDIRECT(strEnterPriseNo, --企业
                                   strWarehouseNo, --仓别
                                   v_csOutDirect.DIRECT_SERIAL, --指示ID
                                   v_csOutDirect.Locate_Qty,
                                   v_csOutDirect.Qmin_Operate_Packing,
                                   nMax_Weight,
                                   nMax_Vol,
                                   nMax_PackRate,
                                   v_csOutDirect.Unit_Weight,
                                   v_csOutDirect.Unit_Volumn,
                                   v_csOutDirect.Unit_Packrate,
                                   v_csOutDirect.Cumulative_Volumn,
                                   --1, --1为客户标签，0为拣货标签
                                   nUseType,
                                   strUserId, --员工ID
                                   blCalcuWeight,
                                   blCalcuVol,
                                   blCalcuPackQTY,
                                   nUnallot_Weight,
                                   nUnAllot_Vol,
                                   nUnAllot_PackRate,
                                   nCurr_Weight,
                                   nCurr_Vol,
                                   nCurr_PackRate,
                                   strNewContainerNo,
                                   strErrorMsg);

          else*/
          --
          v_nOrderCount  := 1;
          v_nItems:=1;
          nUnallot_Weight   := nMax_Weight;
          nUnAllot_Vol      := nMax_Vol;
          nUnAllot_PackRate := nMax_PackRate;
          nCurr_Vol         := v_csOutDirect.SUM_ARTICLE_VOL;
          --end if;
        end if;

        --修改出货下架指示
        UPDATE ODATA_OUTSTOCK_DIRECT t
           SET t.UPDT_DATE      = SYSDATE,
               t.UPDT_NAME      = strUserId,
               t.s_container_no = strNewContainerNo
         WHERE t.enterprise_no = strEnterPriseNo
           and t.WAREHOUSE_NO = strWarehouseNo
           AND t.DIRECT_SERIAL = v_csOutDirect.DIRECT_SERIAL;

        IF SQL%ROWCOUNT <= 0 THEN
          strErrorMsg := 'N|更新指示失败，未更新到数据';
          RETURN;
        END IF;

        --按储位按商品计算
        strCellCondition := strCurrCellCondition;
        --成单范围
        strCurrCalculateRage := strCalculateRange;
        strCurr_ArticleNo    := v_csOutDirect.article_no;

        IF blCalcuPackQTY = TRUE THEN
          nUnAllot_PackRate := nUnAllot_PackRate - nCurr_PackRate;
        end if;
        IF blCalcuWeight = TRUE THEN
          nUnallot_Weight := nUnallot_Weight - nCurr_Weight;
        end if;
        IF blCalcuVol = TRUE THEN
          nUnAllot_Vol := nUnAllot_Vol - nCurr_Vol;
        end if;

      END LOOP;

    end loop;
    strErrorMsg := 'Y';
  EXCEPTION
    WHEN OTHERS THEN
      strErrorMsg := 'N|' || SQLCODE || ' ' || SQLERRM ||
                     SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
  END P_CONTAINER_CALCULATE_PICK;

  PROCEDURE P_GET_SYS_PARAM(strEnterPriseNo IN odata_outstock_direct.enterprise_no%TYPE, --企业
                            strWarehouseNo  IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
                            strOwnerNo      IN ODATA_OUTSTOCK_DIRECT.OWNER_NO%TYPE, --货主
                            nUseType        IN NUMBER, --物流箱类型
                            --blCalcuWeight   OUT BOOLEAN, --是否计算重量
                            --blCalcuVol      OUT BOOLEAN, --是否计算材积
                            --blCalcuPackQTY  OUT BOOLEAN, --是否计算包装量
                            --blSplitCustBox  OUT BOOLEAN, --是否拆分客户物流箱
                            --blSplitPickBox  OUT BOOLEAN, --是否拆分客户物流箱
                            nMax_Vol    OUT NUMBER,
                            nMax_Weight OUT NUMBER,
                            strErrorMsg OUT VARCHAR2) IS
    --OUTSDEFINE    WMS_DEFBASE.SDEFINE%TYPE; --参数的字符性值
    --v_nOutNdefine WMS_DEFBASE.NDEFINE%TYPE; --参数的整数值
  BEGIN
    /*--是否计算重量
    PKLG_WMS_BASE.p_GetBasePara(strEnterPriseNo,
                                strWarehouseNo,
                                strOwnerNo,
                                'BoxCalculateToweight',
                                'O',
                                'O_LOCATE',
                                OUTSDEFINE,
                                v_nOutNdefine,
                                strErrorMsg);
    IF (SUBSTR(strErrorMsg, 1, 1) = 'N') THEN
      RETURN;
    END IF;
    IF OUTSDEFINE = 1 THEN
      blCalcuWeight := true;
    ELSE
      blCalcuWeight := false;
    END IF;*/

    /* --是否计算材积
    PKLG_WMS_BASE.p_GetBasePara(strEnterPriseNo,
                                strWarehouseNo,
                                strOwnerNo,
                                'BoxCalculateTovolumn',
                                'O',
                                'O_LOCATE',
                                OUTSDEFINE,
                                v_nOutNdefine,
                                strErrorMsg);
    IF (SUBSTR(strErrorMsg, 1, 1) = 'N') THEN
      RETURN;
    END IF;
    IF OUTSDEFINE = 1 THEN
      blCalcuVol := true;
    ELSE
      blCalcuVol := false;
    END IF;*/
    /*--是否计算包装量
    PKLG_WMS_BASE.p_GetBasePara(strEnterPriseNo,
                                strWarehouseNo,
                                strOwnerNo,
                                'BoxCalculateToPacking',
                                'O',
                                'O_LOCATE',
                                OUTSDEFINE,
                                v_nOutNdefine,
                                strErrorMsg);
    IF (SUBSTR(strErrorMsg, 1, 1) = 'N') THEN
      RETURN;
    END IF;
    IF OUTSDEFINE = 1 THEN
      blCalcuPackQTY := true;
    ELSE
      blCalcuPackQTY := false;
    END IF;*/
    /* --是否拆分客户物流箱
    PKLG_WMS_BASE.p_GetBasePara(strEnterPriseNo,
                                strWarehouseNo,
                                strOwnerNo,
                                'BoxCusDivide',
                                'O',
                                'O_LOCATE',
                                OUTSDEFINE,
                                v_nOutNdefine,
                                strErrorMsg);
    IF (SUBSTR(strErrorMsg, 1, 1) = 'N') THEN
      RETURN;
    END IF;
    IF OUTSDEFINE = 1 THEN
      blSplitCustBox := true;
    ELSE
      blSplitCustBox := false;
    END IF;
    --是否拆分拣货物流箱
    PKLG_WMS_BASE.p_GetBasePara(strEnterPriseNo,
                                strWarehouseNo,
                                strOwnerNo,
                                'BoxPickDivide',
                                'O',
                                'O_LOCATE',
                                OUTSDEFINE,
                                v_nOutNdefine,
                                strErrorMsg);
    IF (SUBSTR(strErrorMsg, 1, 1) = 'N') THEN
      RETURN;
    END IF;
    IF OUTSDEFINE = 1 THEN
      blSplitPickBox := true;
    ELSE
      blSplitPickBox := false;
    END IF;*/

    --获取拣货物流箱最大材积和重量
    P_GET_CONTAINER_VOLUMN(strEnterPriseNo,
                           strWarehouseNo,
                           'B',
                           nUseType,
                           'B',
                           '11',
                           nMax_Vol,
                           nMax_Weight,
                           strErrorMsg);
    IF (SUBSTR(strErrorMsg, 1, 1) = 'N') THEN
      RETURN;
    END IF;

    strErrorMsg := 'Y';
  EXCEPTION
    WHEN OTHERS THEN
      strErrorMsg := 'N|' || SQLCODE || ' ' || SQLERRM ||
                     SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
  END P_GET_SYS_PARAM;

  PROCEDURE P_GET_CONTAINER_VOLUMN(strEnterPriseNo      IN odata_outstock_direct.enterprise_no%TYPE, --企业
                                   strWarehouseNo       IN WMS_DEFCONTAINER.WAREHOUSE_NO%TYPE, --仓别
                                   strContainerType     IN WMS_DEFCONTAINER.CONTAINER_TYPE%TYPE, --容器类型
                                   strUseType           IN WMS_DEFCONTAINER.USE_TYPE%TYPE, --用途
                                   strLabelPrefix       IN WMS_DEFCONTAINER.LABEL_PREFIX%TYPE, --标签前缀
                                   strContainerMeterial IN WMS_DEFCONTAINER.CONTAINER_MATERIAL%TYPE, --容器材质
                                   nDecVolumn           OUT NUMBER,
                                   nDecWeight           OUT NUMBER,
                                   strErrorMsg          OUT VARCHAR2) IS
  BEGIN
    SELECT BSC.LENGTH * BSC.WIDTH * BSC.HEIGHT * CAPACITY_TOLERANCE / 100 AS MAX_VOLUMN,
           BSC.CONTAINER_CAPACITY AS MAX_WEIGHT
      INTO nDecVolumn, nDecWeight
      FROM WMS_DEFCONTAINER BSC
     WHERE bsc.enterprise_no = strEnterPriseNo
       and BSC.CONTAINER_TYPE = strContainerType
       AND BSC.WAREHOUSE_NO = strWarehouseNo
       AND BSC.USE_TYPE = strUseType
       AND BSC.LABEL_PREFIX = strLabelPrefix
       AND BSC.CONTAINER_MATERIAL = strContainerMeterial
       AND BSC.MANAGE_STATUS = 0;
  EXCEPTION
    WHEN OTHERS THEN
      strErrorMsg := 'N|' || SQLCODE || ' ' || SQLERRM ||
                     SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
  END P_GET_CONTAINER_VOLUMN;
  /***拆下架指示***/
  /******/
  PROCEDURE P_SPLIT_OUTSTOCKDIRECT(strEnterPriseNo    IN odata_outstock_direct.enterprise_no%TYPE, --企业
                                   strWarehouseNo     IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
                                   nSerial            IN ODATA_OUTSTOCK_DIRECT.DIRECT_SERIAL%TYPE, --指示ID
                                   nLocateQty         in ODATA_OUTSTOCK_DIRECT.Locate_Qty%type,
                                   nQMinPackQty       in number,
                                   nMax_Weight        IN NUMBER,
                                   nMax_Vol           IN NUMBER,
                                   nMax_PackRate      IN NUMBER,
                                   nUnit_Weight       IN NUMBER,
                                   nUnit_Vol          IN NUMBER,
                                   nUnit_PackRate     IN NUMBER,
                                   nCumulative_Volumn IN NUMBER,
                                   --nCustFlag          in NUMBER, --1为客户标签，0为拣货标签
                                   nUseType          in number,
                                   strUserId         IN ODATA_OUTSTOCK_DIRECT.UPDT_NAME%TYPE, --员工ID
                                   blCalcuWeight     IN BOOLEAN,
                                   blCalcuVol        IN BOOLEAN,
                                   blCalcuPackQTY    IN BOOLEAN,
                                   nUnallot_Weight   IN OUT NUMBER,
                                   nUnAllot_Vol      IN OUT NUMBER,
                                   nUnAllot_PackRate IN OUT NUMBER,

                                   nCurr_Weight   IN OUT NUMBER,
                                   nCurr_Vol      IN OUT NUMBER,
                                   nCurr_PackRate IN OUT NUMBER,

                                   strContainerNo IN OUT ODATA_OUTSTOCK_DIRECT.s_Container_No%TYPE,
                                   strErrorMsg    OUT VARCHAR2) IS

    v_nTotalLocateQty ODATA_OUTSTOCK_DIRECT.Locate_Qty%type;
    v_nAllotLocateQty ODATA_OUTSTOCK_DIRECT.Locate_Qty%type;
    v_nTempLocateQty  ODATA_OUTSTOCK_DIRECT.Locate_Qty%type;
    v_strOutLabelNo   stock_label_m.label_no%type;

    strSESSION_ID varchar2(20);

    v_nTimes number;

  BEGIN

    strErrorMsg := 'Y';

    v_nTimes          := 0;
    v_nTotalLocateQty := nLocateQty;
    select USERENV('SID') into strSESSION_ID from dual;

    loop

      -------------------计算箱子可装数量
      --计算数量
      v_nAllotLocateQty := 0;
      if blCalcuWeight = true then
        v_nAllotLocateQty := floor(nUnallot_Weight / nUnit_Weight);
      end if;

      if v_nTimes = 0 then
        v_nTempLocateQty := floor(nUnAllot_Vol / nCumulative_Volumn);
      else
        --大于单商品材积时
        if nUnAllot_Vol >= nUnit_Vol then
          v_nTempLocateQty := floor((nUnAllot_Vol - nUnit_Vol) /
                                    nCumulative_Volumn) + 1;
        else
          v_nTempLocateQty := 0;
        end if;
      end if;

      if blCalcuVol = true and v_nTempLocateQty > v_nAllotLocateQty then
        v_nAllotLocateQty := v_nTempLocateQty;
      end if;

      v_nTempLocateQty := floor(nUnit_PackRate * nUnAllot_PackRate);
      if blCalcuPackQTY = true and v_nTempLocateQty > v_nAllotLocateQty then
        v_nAllotLocateQty := v_nTempLocateQty;
      end if;

      --必须拆到最小可操作包装量倍数
      v_nAllotLocateQty := ceil(v_nAllotLocateQty / nQMinPackQty) *
                           nQMinPackQty;

      --超过总量则采用总量
      if v_nAllotLocateQty > v_nTotalLocateQty then
        v_nAllotLocateQty := v_nTotalLocateQty;
      end if;

      --------把总量扣减
      v_nTotalLocateQty := v_nTotalLocateQty - v_nAllotLocateQty;

      --------如果算出来数量已为总量，则不拆退出
      if v_nTotalLocateQty <= 0 then
        exit;
      end if;

      if v_nTimes > 0 and v_nAllotLocateQty = 0 then
        exit;
      end if;

      --------写指示
      if v_nAllotLocateQty > 0 then
        insert into odata_outstock_direct
          (warehouse_no,
           owner_no,
           outstock_type,
           source_type,
           operate_type,
           operate_date,
           pick_type,
           batch_no,
           wave_no,
           exp_type,
           exp_no,
           cust_no,
           sub_cust_no,
           article_no,
           article_id,
           packing_qty,
           s_cell_no,
           s_cell_id,
           s_container_no,
           d_cell_no,
           d_cell_id,
           --pick_container_no,
           --cust_container_no,
           locate_qty,
           status,
           deliver_area,
           line_no,
           priority,
           a_sorter_chute_no,
           check_chute_no,
           deliver_obj,
           supp_count,
           device_no,
           dps_cell_no,
           temp_status,
           exp_date,
           stock_type,
           label_no,
           sub_label_no,
           rgst_name,
           rgst_date,
           updt_name,
           updt_date,
           enterprise_no)
          select warehouse_no,
                 owner_no,
                 outstock_type,
                 source_type,
                 operate_type,
                 operate_date,
                 pick_type,
                 batch_no,
                 wave_no,
                 exp_type,
                 exp_no,
                 cust_no,
                 sub_cust_no,
                 article_no,
                 article_id,
                 packing_qty,
                 s_cell_no,
                 s_cell_id,
                 s_container_no,
                 d_cell_no,
                 d_cell_id,
                 --pick_container_no,
                 --cust_container_no,
                 v_nAllotLocateQty,
                 status,
                 deliver_area,
                 line_no,
                 priority,
                 a_sorter_chute_no,
                 check_chute_no,
                 deliver_obj,
                 supp_count,
                 device_no,
                 dps_cell_no,
                 temp_status,
                 exp_date,
                 stock_type,
                 label_no,
                 sub_label_no,
                 rgst_name,
                 rgst_date,
                 updt_name,
                 updt_date,
                 enterprise_no
            from odata_outstock_direct
           where enterprise_no = strEnterPriseNo
             and warehouse_no = strWarehouseNo
             and DIRECT_SERIAL = nSerial;

        UPDATE ODATA_OUTSTOCK_DIRECT t
           SET t.UPDT_DATE = SYSDATE,
               t.UPDT_NAME = strUserId,
               /* t.Pick_Container_No = case
                                       when nCustFlag = 1 then
                                        t.Pick_Container_No
                                       else
                                        strContainerNo
                                     end,
               t.cust_container_no = case
                                       when nCustFlag = 0 then
                                        t.cust_container_no
                                       else
                                        strContainerNo
                                     end,*/
               t.s_Container_No = strContainerNo,
               t.locate_qty     = t.locate_qty - v_nAllotLocateQty
         WHERE t.enterprise_no = strEnterPriseNo
           and t.WAREHOUSE_NO = strWarehouseNo
           AND t.DIRECT_SERIAL = nSerial;
      end if;
      --------
      nUnallot_Weight   := nMax_Weight;
      nUnAllot_Vol      := nMax_Vol;
      nUnAllot_PackRate := nMax_PackRate;

      -------
      pklg_wms_base.p_get_ContainerNoBase(strEnterPriseNo,
                                          strWarehouseNo,
                                          'B',
                                          strUserId,
                                          'D',
                                          1,
                                          nUseType,
                                          '',
                                          v_strOutLabelNo,
                                          strContainerNo,
                                          strSESSION_ID,
                                          strErrorMsg);
      IF (SUBSTR(strErrorMsg, 1, 1) = 'N') THEN
        RETURN;
      END IF;

      --------
      v_nTimes := v_nTimes + 1;
    end loop;

    if v_nTimes > 0 then
      nCurr_Weight   := v_nAllotLocateQty * nUnit_Weight;
      nCurr_Vol      := (v_nAllotLocateQty - 1) * nCumulative_Volumn +
                        nUnit_Vol;
      nCurr_PackRate := ROUND(v_nAllotLocateQty / nUnit_PackRate, 4);
    end if;

  EXCEPTION
    WHEN OTHERS THEN
      strErrorMsg := 'N|' || SQLCODE || ' ' || SQLERRM ||
                     SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
  END P_SPLIT_OUTSTOCKDIRECT;

  /* \***拣货物流箱试算***\
    \******\
    PROCEDURE P_PICK_CONTAINER_CALCULATE(strEnterPriseNo IN odata_outstock_direct.enterprise_no%TYPE, --企业
                                         strWarehouseNo  IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
                                         strWaveNo       IN ODATA_OUTSTOCK_DIRECT.WAVE_NO%TYPE, --波次号
                                         strUserId       IN ODATA_OUTSTOCK_DIRECT.UPDT_NAME%TYPE, --员工ID
                                         strPickBoxFlag  IN VARCHAR2,
                                         strCustBoxFlag  IN VARCHAR2,
                                         strErrorMsg     OUT VARCHAR2) IS
      \*OUTSDEFINE WMS_DEFBASE.SDEFINE%TYPE; --参数的字符性值*\
      v_nOutNdefine WMS_DEFBASE.NDEFINE%TYPE; --参数的整数值

      strOneDeliverOnePickPara WMS_DEFBASE.SDEFINE%TYPE; --拣货物流箱一个配送对象是否一次拣货参数

      blCalcuWeight  BOOLEAN;
      blCalcuVol     BOOLEAN;
      blCalcuPackQTY BOOLEAN;
      blSplitCustBox BOOLEAN;
      blSplitPickBox BOOLEAN;

      nMax_Weight   NUMBER;
      nMax_Vol      NUMBER;
      nMax_PackRate NUMBER;

      --是否需要新取号
      strNewContainerNo VARCHAR2(20);
      strOutLabelNo     VARCHAR2(20);
      strSESSION_ID     VARCHAR2(20);
      --计算范围不同，新取容器号
      strCalculateRange    VARCHAR2(100);
      strCurrCalculateRage VARCHAR2(100);
      strOldBatchNo        VARCHAR2(10);
      strCellCondition     VARCHAR2(100);
      strCurrCellCondition VARCHAR2(100);
      --重量
      nCurr_Weight    NUMBER;
      nUnallot_Weight NUMBER;
      --材积
      nCurr_Vol    NUMBER;
      nUnAllot_Vol NUMBER;
      --包装量
      nCurr_PackRate    NUMBER;
      nUnAllot_PackRate NUMBER;

      strOutstockType VARCHAR2(1); --下架类型

      nUseType number;

      strArticleNoList VARCHAR2(1000);
      nArticleNum      number;
      v_blCutBoxFlag   boolean;
    BEGIN
      nMax_PackRate   := 1;
      strOutstockType := '0'; --出货拣货
      nUseType        := 1; --拣货物流箱
      --获取拣货物流箱按配送对象成箱参数
      PKLG_WMS_BASE.p_GetBasePara(strEnterPriseNo,
                                  strWarehouseNo,
                                  '',
                                  'OneDeliverObjOnePick',
                                  'O',
                                  'O_LOCATE',
                                  strOneDeliverOnePickPara,
                                  v_nOutNdefine,
                                  strErrorMsg);
      IF (SUBSTR(strErrorMsg, 1, 1) = 'N') THEN
        RETURN;
      END IF;

      P_GET_SYS_PARAM(strEnterPriseNo,
                      strWarehouseNo,
                      '',
                      nUseType,
                      blCalcuWeight,
                      blCalcuVol,
                      blCalcuPackQTY,
                      blSplitCustBox,
                      blSplitPickBox,
                      nMax_Vol,
                      nMax_Weight,
                      strErrorMsg);
      IF (SUBSTR(strErrorMsg, 1, 1) = 'N') THEN
        RETURN;
      END IF;

      strCellCondition     := '*';
      strCurrCalculateRage := '*';
      nArticleNum          := 0;
      strArticleNoList     := '*';
      nCurr_Vol            := 0;
      nCurr_PackRate       := 0;
      nCurr_Weight         := 0;
      nUnallot_Weight      := nMax_Weight;
      nUnAllot_Vol         := nMax_Vol;
      nUnAllot_PackRate    := nMax_PackRate;
      v_blCutBoxFlag       := false;

      select USERENV('SID') into strSESSION_ID from dual;
      --获取下架指示
      FOR v_csOutDirect IN (select *
                              from (SELECT OOD.WAREHOUSE_NO,
                                           OOD.Supp_Count,
                                           OOD.Article_No,
                                           OOD.s_Container_No,
                                           OOD.s_Cell_No,
                                           OOD.Exp_No,
                                           OOD.EXP_DATE,
                                           OOD.Exp_Type,
                                           OOD.Status,
                                           OOD.CUST_NO,
                                           OOD.LOCATE_QTY,
                                           OOD.Operate_Type,
                                           OOD.Outstock_Type,
                                           OOD.Batch_No,
                                           OOD.WAVE_NO,
                                           OOD.Priority,
                                           OOD.PICK_TYPE,
                                           OOD.DELIVER_OBJ,
                                           OOD.DIRECT_SERIAL,
                                           OOD.OPERATE_DATE,
                                           bda.UNIT_WEIGHT,
                                           cda.area_type,
                                           NVL(CDD.DPS_AREA, 0) DPS_AREA,
                                           CDC.Ware_No,
                                           CDC.stock_y,
                                           bda.QMIN_OPERATE_PACKING,
                                           bda.UNIT_VOLUMN,
                                           bda.CUMULATIVE_VOLUMN,
                                           bda.RULE_FLAG,
                                           (bda.unit_volumn +
                                           (ood.locate_qty - 1) *
                                           bda.CUMULATIVE_VOLUMN) SUM_ARTICLE_VOL,
                                           (ood.locate_qty * bda.unit_weight) SUM_ARTICLE_WEIGHT,

                                           NVL(ROUND((ood.locate_qty /
                                                     ood.packing_qty),
                                                     4),
                                               0.01) SUM_ARTICLE_PACK,
                                           ood.packing_qty unit_packrate,
                                           CDA.B_PICK,
                                           --1：按储区；2：按通道；3：按储区+层；4：按巷道+层；5：按电子标签区域;6:按分播设备
                                           (CASE
                                            NVL(otad.ALLOT_RULE, wtr.ALLOT_RULE)
                                             WHEN '0' THEN
                                              CDC.WARE_NO
                                             WHEN '1' THEN
                                              (CDC.WARE_NO || CDC.AREA_NO)
                                             WHEN '2' THEN
                                              (CDC.WARE_NO || CDC.AREA_NO ||
                                              CDC.STOCK_NO)
                                             WHEN '3' THEN
                                              (CDC.WARE_NO || CDC.AREA_NO ||
                                              CDC.STOCK_Y)
                                             WHEN '4' THEN
                                              (CDC.WARE_NO || CDC.AREA_NO ||
                                              CDC.STOCK_NO || CDC.STOCK_Y)
                                             WHEN '5' THEN
                                              TO_CHAR(NVL(CDD.DPS_AREA, 0))
                                             when '6' then
                                              NVL(cdd.DEVICE_NO, 'N')
                                             ELSE
                                              ''
                                           END) ROUTE_CUT_MODE,
                                           ddm.device_no,
                                           nvl(ddm.box_items, 0) as box_items,
                                           cdc.stock_no,
                                           cdc.pick_order
                                      FROM ODATA_OUTSTOCK_DIRECT OOD
                                    --商品信息
                                     INNER JOIN STOCK_ARTICLE_INFO CAI
                                        ON CAI.ARTICLE_NO = OOD.ARTICLE_NO
                                       AND CAI.ARTICLE_ID = OOD.ARTICLE_ID
                                     inner join bdef_defarticle bda
                                        on ood.enterprise_no =
                                           bda.enterprise_no
                                       and ood.article_no = bda.article_no
                                    --储位
                                     INNER JOIN CDEF_DEFCELL CDC
                                        ON ood.enterprise_no =
                                           cdc.enterprise_no
                                       and OOD.S_CELL_NO = CDC.CELL_NO
                                       AND OOD.WAREHOUSE_NO = CDC.WAREHOUSE_NO
                                    --区域类型
                                     INNER JOIN CDEF_DEFAREA CDA
                                        ON cdc.enterprise_no =
                                           cda.enterprise_no
                                       and CDC.WAREHOUSE_NO = CDA.WAREHOUSE_NO
                                       AND CDC.WARE_NO = CDA.WARE_NO
                                       AND CDC.AREA_NO = CDA.AREA_NO
                                       AND CDA.B_PICK in ('1', '2') --实际/虚拟物流箱试算
                                    --设备
                                      left join device_divide_m ddm
                                        on ddm.enterprise_no =
                                           ood.enterprise_no
                                       and ddm.warehouse_no = ood.warehouse_no
                                       and ddm.device_no = ood.device_no
                                    --电子标签区域
                                      LEFT JOIN CDEF_DEFCELL_DPS CDD
                                        ON ood.enterprise_no =
                                           cdd.enterprise_no
                                       and OOD.S_CELL_NO = CDD.CELL_NO
                                       AND OOD.WAREHOUSE_NO = CDD.WAREHOUSE_NO
                                    --零散拣货位
                                      left join cset_cell_article cca
                                        on ood.enterprise_no =
                                           cca.enterprise_no
                                       and ood.WAREHOUSE_NO = cca.WAREHOUSE_NO
                                       and ood.article_no = cca.ARTICLE_NO
                                       and ood.owner_no = cca.owner_no
                                       and cca.pick_type = 'B'
                                    --拣货切单方式
                                     INNER JOIN wms_taskallot_rule wtr
                                        on wtr.operate_type = ood.operate_type
                                      left join oset_task_allot_d otad
                                        on otad.enterprise_no =
                                           ood.enterprise_no
                                       and otad.warehouse_no = ood.warehouse_no
                                       and otad.outstock_type =
                                           ood.outstock_type
                                       and otad.source_type = ood.source_type
                                       and otad.operate_type = ood.operate_type
                                       and otad.task_id = cda.task_id
                                     WHERE OOD.TEMP_STATUS < '16'
                                       and ood.enterprise_no = strEnterPriseNo
                                       AND OOD.WAREHOUSE_NO = strWarehouseNo
                                       AND OOD.WAVE_NO = strWaveNo
                                       AND OOD.OUTSTOCK_TYPE = strOutstockType
                                       AND OOD.OPERATE_TYPE = 'B'
                                       and NVL(OOD.PICK_CONTAINER_NO, 'N') = 'N'
                                          --规则商品判断RULE_FLAG
                                       AND EXISTS
                                     (SELECT 'X'
                                              FROM bdef_DEFARTICLE BDA
                                             WHERE bda.enterprise_no =
                                                   ood.enterprise_no
                                               and BDA.ARTICLE_NO =
                                                   OOD.ARTICLE_NO
                                               AND BDA.RULE_FLAG = '1') --规则商品
                                       AND OOD.PICK_TYPE = '1' --播种
                                    ) D
                             WHERE 1 = 1
                             ORDER BY d.PRIORITY      DESC,
                                      d.WAVE_NO,
                                      d.BATCH_NO,
                                      d.OUTSTOCK_TYPE,
                                      D.OPERATE_TYPE,
                                      D.PICK_TYPE     DESC,
                                      d.device_no,
                                      D.RULE_FLAG,
                                      ROUTE_CUT_MODE,
                                      d.stock_no,
                                      d.pick_order,
                                      D.S_CELL_NO,
                                      D.ARTICLE_NO) LOOP

        --批次更换
        IF strOldBatchNo <> v_csOutDirect.BATCH_NO or strOldBatchNo is null THEN
          strOldBatchNo := v_csOutDirect.BATCH_NO;
        END IF;

        --
        strCalculateRange := v_csOutDirect.WAREHOUSE_NO ||
                             v_csOutDirect.OUTSTOCK_TYPE ||
                             v_csOutDirect.OPERATE_TYPE ||
                             v_csOutDirect.PICK_TYPE ||
                             v_csOutDirect.BATCH_NO || v_csOutDirect.WAVE_NO ||
                             v_csOutDirect.PRIORITY ||
                             v_csOutDirect.AREA_TYPE ||
                             v_csOutDirect.RULE_FLAG ||
                             nvl(v_csOutDirect.device_no, '[]');

        --切单区域方式
        strCalculateRange := strCalculateRange ||
                             v_csOutDirect.ROUTE_CUT_MODE;

        --相同储位不同商品
        strCurrCellCondition := v_csOutDirect.WAREHOUSE_NO ||
                                v_csOutDirect.WAVE_NO ||
                                v_csOutDirect.BATCH_NO ||
                                v_csOutDirect.S_CELL_NO ||
                                v_csOutDirect.ARTICLE_NO;

        --当前商品材积等信息
        nCurr_Vol := v_csOutDirect.SUM_ARTICLE_VOL;
        IF strCellCondition = strCurrCellCondition THEN
          nCurr_Vol := nCurr_Vol - v_csOutDirect.Unit_Volumn +
                       v_csOutDirect.Cumulative_Volumn;
        end if;
        nCurr_PackRate := v_csOutDirect.SUM_ARTICLE_PACK;
        nCurr_Weight   := v_csOutDirect.SUM_ARTICLE_WEIGHT;

        --计算商品数量
        if strArticleNoList = '*' or
           instr(strArticleNoList, '{' || v_csOutDirect.Article_No || '}') < 1 then
          nArticleNum := nArticleNum + 1;
          if strArticleNoList = '*' then
            strArticleNoList := '{' || v_csOutDirect.Article_No || '}';
          else
            strArticleNoList := strArticleNoList || '{' ||
                                v_csOutDirect.Article_No || '}';

          end if;
        end if;

        v_blCutBoxFlag := false;
        --成箱范围一样，进行体积、重量等判断
        IF (strCurrCalculateRage = '*' or --第一条记录或达到切箱范围
           strCurrCalculateRage <> strCalculateRange) then
          v_blCutBoxFlag := true;
        end if;

        if v_blCutBoxFlag = false and
           (v_csOutDirect.Box_Items is not null and --够品项数
           nArticleNum > v_csOutDirect.Box_Items and
           v_csOutDirect.Box_Items > 0 and v_csOutDirect.B_PICK = '2') then
          v_blCutBoxFlag := true;
        end if;

        if v_blCutBoxFlag = false and
           (v_csOutDirect.B_PICK = '2' and --如果真正物流箱试算
           ((nUnallot_Weight < v_csOutDirect.SUM_ARTICLE_WEIGHT AND --可放重量小于当前商品重量
           blCalcuWeight = TRUE) OR
           (nUnAllot_PackRate < v_csOutDirect.SUM_ARTICLE_PACK AND
           blCalcuPackQTY = TRUE) OR
           (nUnAllot_Vol < v_csOutDirect.SUM_ARTICLE_VOL AND
           blCalcuVol = TRUE))) THEN

          --如果允许拆箱
          IF blSplitPickBox = TRUE THEN
            v_blCutBoxFlag := true;
          else
            --不允许拆箱，且与上一商品不同货位不同商品
            IF strCellCondition <> strCurrCellCondition THEN
              v_blCutBoxFlag := true;
            end if;
          end if;
        end if;

        if v_blCutBoxFlag = true then
          pklg_wms_base.p_get_ContainerNoBase(strEnterPriseNo,
                                              strWarehouseNo,
                                              'B',
                                              strUserId,
                                              'D',
                                              1,
                                              nUseType,
                                              '',
                                              strOutLabelNo,
                                              strNewContainerNo,
                                              strSESSION_ID,
                                              strErrorMsg);
          IF (SUBSTR(strErrorMsg, 1, 1) = 'N') THEN
            RETURN;
          END IF;

          --如果直正物流箱试算，并且同商品可拆箱
          IF v_csOutDirect.B_PICK = '2' and blSplitPickBox = TRUE THEN
            --商品折箱,预留

            P_SPLIT_OUTSTOCKDIRECT(strEnterPriseNo, --企业
                                   strWarehouseNo, --仓别
                                   v_csOutDirect.DIRECT_SERIAL, --指示ID
                                   v_csOutDirect.Locate_Qty,
                                   v_csOutDirect.Qmin_Operate_Packing,
                                   nMax_Weight,
                                   nMax_Vol,
                                   nMax_PackRate,
                                   v_csOutDirect.Unit_Weight,
                                   v_csOutDirect.Unit_Volumn,
                                   v_csOutDirect.Unit_Packrate,
                                   v_csOutDirect.Cumulative_Volumn,
                                   0, --1为客户标签，0为拣货标签
                                   nUseType,
                                   strUserId, --员工ID
                                   blCalcuWeight,
                                   blCalcuVol,
                                   blCalcuPackQTY,
                                   nUnallot_Weight,
                                   nUnAllot_Vol,
                                   nUnAllot_PackRate,
                                   nCurr_Weight,
                                   nCurr_Vol,
                                   nCurr_PackRate,
                                   strNewContainerNo,
                                   strErrorMsg);

          else
            --
            nUnallot_Weight   := nMax_Weight;
            nUnAllot_Vol      := nMax_Vol;
            nUnAllot_PackRate := nMax_PackRate;

          end if;
          strArticleNoList := '{' || v_csOutDirect.Article_No || '}';
          nArticleNum      := 1;

        end if;

        UPDATE ODATA_OUTSTOCK_DIRECT t
           SET t.UPDT_DATE         = SYSDATE,
               t.UPDT_NAME         = strUserId,
               t.Pick_Container_No = strNewContainerNo,
               t.s_Container_No    = strNewContainerNo
         WHERE t.enterprise_no = strEnterPriseNo
           and t.WAREHOUSE_NO = strWarehouseNo
           AND t.DIRECT_SERIAL = v_csOutDirect.DIRECT_SERIAL;

        IF SQL%ROWCOUNT <= 0 THEN
          strErrorMsg := 'N|更新指示失败，未更新到数据';
          RETURN;
        END IF;

        --减去已装箱的材积
        IF blCalcuWeight = TRUE THEN
          nUnallot_Weight := nUnallot_Weight - nCurr_Weight;
        END IF;

        IF blCalcuVol = TRUE THEN
          nUnAllot_Vol := nUnAllot_Vol - nCurr_Vol;
        END IF;

        IF blCalcuPackQTY = TRUE THEN
          nUnAllot_PackRate := nUnAllot_PackRate - nCurr_PackRate;
        END IF;

        --按储位按商品计算
        strCellCondition := strCurrCellCondition;

        --成单范围
        strCurrCalculateRage := strCalculateRange;

      END LOOP;

      strErrorMsg := 'Y';
    EXCEPTION
      WHEN OTHERS THEN
        strErrorMsg := 'N|' || SQLCODE || ' ' || SQLERRM ||
                       SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
    END P_PICK_CONTAINER_CALCULATE;
  */
  --分播物流箱--支持电商规则 Add BY QZH AT 2016-6-6
  PROCEDURE P_CONTAINER_CALCULATE_DIVIDE(strEnterPriseNo IN odata_outstock_direct.enterprise_no%TYPE, --企业
                                         strWarehouseNo  IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
                                         strWaveNo       IN ODATA_OUTSTOCK_DIRECT.WAVE_NO%TYPE, --波次号
                                         strUserId       IN ODATA_OUTSTOCK_DIRECT.UPDT_NAME%TYPE, --员工ID
                                         --strPickBoxFlag  IN VARCHAR2,
                                         --strCustBoxFlag  IN VARCHAR2,
                                         strErrorMsg OUT VARCHAR2) IS
    /*OUTSDEFINE WMS_DEFBASE.SDEFINE%TYPE; --参数的字符性值*/
    --v_nOutNdefine WMS_DEFBASE.NDEFINE%TYPE; --参数的整数值

    --strOneDeliverOnePickPara WMS_DEFBASE.SDEFINE%TYPE; --拣货物流箱一个配送对象是否一次拣货参数

    blCalcuWeight  BOOLEAN;
    blCalcuVol     BOOLEAN;
    blCalcuPackQTY BOOLEAN;
    blSplitBox     BOOLEAN;
    --blSplitPickBox BOOLEAN;

    nMax_Weight   NUMBER;
    nMax_Vol      NUMBER;
    nMax_PackRate NUMBER;
    v_nMaxOrders  number;

    --v_VolFlag         varchar2(1) := '0';
    v_RuleID      WMS_LOGIBOX_RULE.Allot_Rule%type;
    v_nOrderCount number := 0;
    v_nItems      number := 0;
    nMaxItems     number := 0;
    v_lstExp_No   VARCHAR2(32767);
    --strCurr_ExpNo     odata_exp_m.exp_no%type;
    strCurr_ArticleNo bdef_defarticle.article_no%type;
    strArticleNoList  VARCHAR2(1000);

    --是否需要新取号
    strNewContainerNo VARCHAR2(20);
    strOutLabelNo     VARCHAR2(20);
    strSESSION_ID     VARCHAR2(20);
    --计算范围不同，新取容器号
    strCalculateRange    VARCHAR2(100);
    strCurrCellCondition VARCHAR2(100);
    strCurrCalculateRage VARCHAR2(100);
    strOldBatchNo        VARCHAR2(10);
    strCellCondition     VARCHAR2(100);
    --重量
    nCurr_Weight    NUMBER;
    nUnallot_Weight NUMBER;
    v_Count         integer := 0;
    --材积
    nCurr_Vol    NUMBER;
    nUnAllot_Vol NUMBER;
    --包装量
    nCurr_PackRate    NUMBER;
    nUnAllot_PackRate NUMBER;

    nUseType        NUMBER; --物流箱标识
    strOutstockType VARCHAR2(1); --下架类型

    v_blCutBoxFlag boolean;
  BEGIN
    nMax_PackRate   := 1;
    nUseType        := 1; --客户物流箱
    strOutstockType := '0'; --出货拣货

    --获取系统参数
    P_GET_SYS_PARAM(strEnterPriseNo,
                    strWarehouseNo,
                    '',
                    nUseType,
                    --blCalcuWeight,
                    --blCalcuVol,
                    --blCalcuPackQTY,
                    --blSplitCustBox,
                    --blSplitPickBox,
                    nMax_Vol,
                    nMax_Weight,
                    strErrorMsg);
    IF (SUBSTR(strErrorMsg, 1, 1) = 'N') THEN
      RETURN;
    END IF;

    for cs_BatchRule in (select A.*, b.Batch_No
                           from WMS_LOGIBOX_RULE A, ODATA_LOCATE_BATCH B
                          WHERE A.ENTERPRISE_NO = B.ENTERPRISE_NO
                            AND A.RULE_ID = B.DIVIDE_LOGIBOX_RULE_ID --物流箱试算策略
                            and B.WAREHOUSE_NO = strWarehouseNo
                            AND B.ENTERPRISE_NO = strEnterPriseNo
                            and B.Wave_No = strWaveNo) loop

      v_lstExp_No   := 'N'; --空值不能用着比较 所以初始值复制为'N' huangb 20160701
      v_nMaxOrders  := cs_BatchRule.Allot_Rule_Value; --多少个订单（配送对象）一个物流箱 huangb 20160701
      nMaxItems     := cs_BatchRule.box_sku_limit;
      blCalcuVol    := false;
      blCalcuWeight := false;
      v_Count       := 0;
      v_RuleID      := cs_BatchRule.Allot_Rule;

      --按区域
      if cs_BatchRule.Allot_Rule = '0' then
        if cs_BatchRule.Vol_Flag = '1' then
          blCalcuVol := true;
        end if;
        if cs_BatchRule.Weight_Flag = '1' then
          blCalcuWeight := true;
        end if;
      end if;

      --按订单数,配送对象，不参考SKU数限制
      if cs_BatchRule.Allot_Rule in ('2') then
        v_nMaxOrders:=1;
        nMaxItems := 0;
      end if;

      if cs_BatchRule.Allot_Rule in ('1') then
        nMaxItems := 0;
      end if;


      --按商品，SKU数强制为1
      if cs_BatchRule.Allot_Rule = '3' then
        nMaxItems := 1;
      end if;

      nUnallot_Weight   := nMax_Weight;
      nUnAllot_Vol      := nMax_Vol;
      nUnAllot_PackRate := nMax_PackRate;

      strCalculateRange := '*';
      strOldBatchNo     := '';

      --是否支持拆箱
      if cs_BatchRule.Splitbox_Flag = '1' then
        blSplitBox := true;
      else
        blSplitBox := true;
      end if;

      --获取下架指示
      strCurrCalculateRage := '*';
      FOR v_csOutDirect IN (SELECT OOD.WAREHOUSE_NO,
                                   OOD.OUTSTOCK_TYPE,
                                   OOD.OPERATE_TYPE,
                                   OOD.OPERATE_DATE,
                                   OOD.PICK_TYPE,
                                   OOD.WAVE_NO,
                                   OOD.BATCH_NO,
                                   OOD.PRIORITY,
                                   OOD.CUST_NO,
                                   OOD.EXP_NO,
                                   OOD.EXP_TYPE,
                                   OOD.S_CELL_NO,
                                   OOD.ARTICLE_NO,
                                   OOD.LOCATE_QTY,
                                   OOD.DELIVER_OBJ,
                                   OOD.STATUS,
                                   OOD.DIRECT_SERIAL,
                                   ood.supp_count,
                                   CDA.AREA_TYPE,
                                   --外贸标识
                                   bda.divide_box,
                                   bda.qmin_operate_packing,
                                   bdc.trade_flag,
                                   bdc.CONTAINER_MATERIAL,
                                   bda.cumulative_volumn,
                                   (bda.unit_volumn +
                                   bda.cumulative_volumn *
                                   (ood.locate_qty -
                                   bda.qmin_operate_packing)) SUM_ARTICLE_VOL,
                                   (ood.locate_qty * bda.unit_weight) SUM_ARTICLE_WEIGHT,
                                   NVL(ROUND(ood.locate_qty /
                                             ood.packing_qty,
                                             4),
                                       0.01) SUM_ARTICLE_PACK,
                                   bda.unit_volumn,
                                   bda.unit_weight,
                                   ood.packing_qty unit_packrate,
                                   CDA.B_PICK,
                                   --1：按仓区；2-按储区；3-按通道；4：按储区+层；5：按巷道+层；6：按电子标签区域；
                                   (CASE cs_BatchRule.Area_Rule
                                     WHEN '1' THEN
                                      CDC.WARE_NO
                                     WHEN '2' THEN
                                      (CDC.WARE_NO || CDC.AREA_NO)
                                     WHEN '3' THEN
                                      (CDC.WARE_NO || CDC.AREA_NO ||
                                      CDC.STOCK_NO)
                                     WHEN '4' THEN
                                      (CDC.WARE_NO || CDC.AREA_NO ||
                                      CDC.STOCK_Y)
                                     WHEN '5' THEN
                                      (CDC.WARE_NO || CDC.AREA_NO ||
                                      CDC.STOCK_NO || CDC.STOCK_Y)
                                     WHEN '6' THEN
                                      TO_CHAR(NVL(CDD.DPS_AREA, 0))
                                     ELSE
                                      ''
                                   END) ROUTE_CUT_MODE,
                                   NVL(CDD.DPS_AREA, 0) DPS_AREA
                              FROM ODATA_OUTSTOCK_DIRECT OOD
                            --商品信息
                             inner join bdef_defarticle bda
                                on ood.enterprise_no = bda.enterprise_no
                               and ood.article_no = bda.article_no
                            --储位
                             INNER JOIN cdef_DEFCELL CDC
                                ON cdc.enterprise_no = ood.enterprise_no
                               and OOD.S_CELL_NO = CDC.CELL_NO
                               AND OOD.WAREHOUSE_NO = CDC.WAREHOUSE_NO
                            --区域类型
                             INNER JOIN cdef_DEFAREA CDA
                                ON cdc.enterprise_no = cda.enterprise_no
                               and CDC.WAREHOUSE_NO = CDA.WAREHOUSE_NO
                               AND CDC.WARE_NO = CDA.WARE_NO
                               AND CDC.AREA_NO = CDA.AREA_NO
                            --电子标签区域
                              LEFT JOIN cdef_DEFCELL_DPS CDD
                                ON cdd.enterprise_no = cdd.enterprise_no
                               and OOD.S_CELL_NO = CDD.CELL_NO
                               AND OOD.WAREHOUSE_NO = CDD.WAREHOUSE_NO
                               AND CDD.USE_TYPE = '1'
                            --客户表
                             inner join bdef_defcust bdc
                                on bdc.enterprise_no = ood.enterprise_no
                               and bdc.owner_no = ood.owner_no
                               and bdc.cust_no = ood.cust_no
                             WHERE OOD.Status < '13'
                               and ood.enterprise_no = strEnterPriseNo
                               AND OOD.WAREHOUSE_NO = strWarehouseNo
                               AND OOD.WAVE_NO = strWaveNo
                               and ood.batch_no = cs_BatchRule.Batch_No
                               AND OOD.OUTSTOCK_TYPE = strOutstockType
                               AND OOD.OPERATE_TYPE = 'B'
                               and NVL(OOD.s_Container_No, 'N') = 'N'
                              /*    --规则商品判断RULE_FLAG
                               AND EXISTS
                             (SELECT 'X'
                                      FROM bdef_DEFARTICLE BDA
                                     WHERE bda.enterprise_no =
                                           ood.enterprise_no
                                       and BDA.ARTICLE_NO = OOD.ARTICLE_NO
                                       AND BDA.RULE_FLAG = '1') --规则商品*/
                               AND OOD.PICK_TYPE >= '1' --播种
                             ORDER BY OOD.PRIORITY DESC,
                                      OOD.BATCH_NO,
                                      OOD.OUTSTOCK_TYPE,
                                      OOD.OPERATE_TYPE,
                                      OOD.PICK_TYPE DESC,
                                      CASE cs_BatchRule.Allot_Rule
                                        WHEN '2' THEN --按配送对象
                                         ood.deliver_obj
                                        WHEN '3' THEN --接商品
                                         ood.article_no
                                        else
                                         '0'
                                      end,
                                      case
                                        when cs_BatchRule.Onedeliveronepick = '0' then
                                         OOD.STATUS
                                        else
                                         '0'
                                      end,
                                      ROUTE_CUT_MODE,
                                      OOD.Deliver_Obj,
                                      cdc.stock_no,
                                      DPS_AREA,
                                      cdc.pick_order,
                                      OOD.S_CELL_NO,
                                      OOD.ARTICLE_NO,
                                      ood.supp_count) LOOP

        --Add BY QZH AT 2016-4-14
        v_Count := v_Count + 1;

        --区域是虚拟物流箱计算规则
        if v_csOutDirect.B_PICK = '1' then
          blCalcuVol    := false;
          blCalcuWeight := false;
        end if;

        v_blCutBoxFlag := false;

        if v_Count = 1 then
          P_GET_CONTAINER_VOLUMN(strEnterPriseNo,
                                 strWarehouseNo,
                                 'B',
                                 nUseType,
                                 'B',
                                 v_csOutDirect.CONTAINER_MATERIAL,
                                 nMax_Weight,
                                 nMax_Vol,
                                 strErrorMsg);
          IF (SUBSTR(strErrorMsg, 1, 1) = 'N') THEN
            RETURN;
          END IF;
          v_blCutBoxFlag  := true;
          nUnallot_Weight := nMax_Weight;
          nUnAllot_Vol    := nMax_Vol;
        end if;
        --Add End

        --批次更换
        IF strOldBatchNo <> v_csOutDirect.BATCH_NO or strOldBatchNo is null THEN
          strOldBatchNo := v_csOutDirect.BATCH_NO;
        END IF;

        strCalculateRange := v_csOutDirect.WAREHOUSE_NO ||
                             v_csOutDirect.OUTSTOCK_TYPE ||
                             v_csOutDirect.OPERATE_TYPE ||
                             v_csOutDirect.PICK_TYPE ||
                             v_csOutDirect.BATCH_NO ||
                             v_csOutDirect.WAVE_NO ||
                             v_csOutDirect.PRIORITY;

        case v_RuleID
        --按订单数
          when '1' then
            if instr(v_lstExp_No, '{' || v_csOutDirect.Exp_No || '}') <= 0 then
              v_lstExp_No   := v_lstExp_No || ',' || '{' ||
                               v_csOutDirect.Exp_No || '}';
              v_nOrderCount := v_nOrderCount + 1;
              if v_nOrderCount > v_nMaxOrders then
                v_blCutBoxFlag := true;
                v_lstExp_No    := '{' || v_csOutDirect.Exp_No || '}';
                v_nOrderCount  := 1;
              end if;
            end if;
            --按配送对象
          when '2' then
            if instr(v_lstExp_No, '{' || v_csOutDirect.deliver_obj || '}') <= 0 then
              v_lstExp_No   := v_lstExp_No || ',' || '{' ||
                               v_csOutDirect.deliver_obj || '}';
              v_nOrderCount := v_nOrderCount + 1;
              --配送对象不参考订单数值
              if v_nOrderCount > v_nMaxOrders then
                --if v_nOrderCount > nMaxItems then
                v_blCutBoxFlag := true;
                v_lstExp_No    := '{' || v_csOutDirect.deliver_obj || '}';
                v_nOrderCount  := 1;
              end if;
            end if;
            --按商品
          when '3' then
            if strCurr_ArticleNo <> v_csOutDirect.Article_No then
              v_nItems := v_nItems + 1;
            end if;
            if v_nItems > nMaxItems and nMaxItems > 0 then
              v_blCutBoxFlag    := true;
              strCurr_ArticleNo := v_csOutDirect.Article_No;
              v_nItems          := 1;
            end if;
          else
            null;
        end case;

        --计算商品数量
        if strArticleNoList = '*' or
           instr(strArticleNoList, '{' || v_csOutDirect.Article_No || '}') < 1 then
          v_nItems := v_nItems + 1;
          if strArticleNoList = '*' then
            strArticleNoList := '{' || v_csOutDirect.Article_No || '}';
          else
            strArticleNoList := strArticleNoList || '{' ||
                                v_csOutDirect.Article_No || '}';

          end if;
        end if;

        --同一个配送对象不需要一次性拣货
        IF cs_BatchRule.Onedeliveronepick = '0' THEN
          strCalculateRange := strCalculateRange || v_csOutDirect.STATUS;
        END IF;

        --参考区域规则
        if cs_BatchRule.Area_Rule > '0' then

          --切单区域方式
          strCalculateRange := strCalculateRange ||
                               v_csOutDirect.ROUTE_CUT_MODE;

          --外贸客户
          IF v_csOutDirect.Trade_Flag = '1' THEN
            strCalculateRange := strCalculateRange ||
                                 v_csOutDirect.DIVIDE_BOX;
          END IF;

          ------同一储位同一商品
          strCurrCellCondition := v_csOutDirect.WAREHOUSE_NO ||
                                  v_csOutDirect.WAVE_NO ||
                                  v_csOutDirect.BATCH_NO ||
                                  v_csOutDirect.S_CELL_NO ||
                                  v_csOutDirect.ARTICLE_NO;

          ------当前商品材积等信息
          nCurr_Vol := v_csOutDirect.SUM_ARTICLE_VOL;
          --如果同货位同商品
          if strCellCondition = strCurrCellCondition THEN
            nCurr_Vol := nCurr_Vol-v_csOutDirect.Unit_Volumn;
          end if;
          nCurr_PackRate := v_csOutDirect.SUM_ARTICLE_PACK;
          nCurr_Weight   := v_csOutDirect.SUM_ARTICLE_WEIGHT;

          --成箱范围一样，进行体积、重量等判断
          IF (strCurrCalculateRage = '*' or --第一条记录或达到切箱范围
             strCurrCalculateRage <> strCalculateRange) then
            v_blCutBoxFlag := true;
          end if;

          if v_blCutBoxFlag = false and
             (v_csOutDirect.B_PICK = '2' and --如果真正物流箱试算
             ((nUnallot_Weight < v_csOutDirect.SUM_ARTICLE_WEIGHT AND --可放重量小于当前商品重量
             blCalcuWeight = TRUE) OR
             (nUnAllot_PackRate < v_csOutDirect.SUM_ARTICLE_PACK AND
             blCalcuPackQTY = TRUE) OR
             (nUnAllot_Vol < v_csOutDirect.SUM_ARTICLE_VOL AND
             blCalcuVol = TRUE))) THEN

            --如果允许拆箱
            IF blSplitBox = TRUE THEN
              v_blCutBoxFlag := true;
            else
              --不允许拆箱，且与上一商品不同货位不同商品
              IF strCellCondition <> strCurrCellCondition THEN
                v_blCutBoxFlag := true;
              end if;
            end if;
          end if;

          if nUnallot_Weight < 0 then
            v_blCutBoxFlag := true;
          end if;

          if nUnAllot_Vol < 0 then
            v_blCutBoxFlag := true;
          end if;

          if nUnAllot_PackRate < 0 then
            v_blCutBoxFlag := true;
          end if;
        end if;

        if v_blCutBoxFlag = true then
          pklg_wms_base.p_get_ContainerNoBase(strEnterPriseNo,
                                              strWarehouseNo,
                                              'B',
                                              strUserId,
                                              'D',
                                              1,
                                              nUseType,
                                              '',
                                              strOutLabelNo,
                                              strNewContainerNo,
                                              strSESSION_ID,
                                              strErrorMsg);
          IF (SUBSTR(strErrorMsg, 1, 1) = 'N') THEN
            RETURN;
          END IF;

          --Add BY QZH AT 2016-4-14
          P_GET_CONTAINER_VOLUMN(strEnterPriseNo,
                                 strWarehouseNo,
                                 'B',
                                 nUseType,
                                 'B',
                                 v_csOutDirect.CONTAINER_MATERIAL,
                                 nMax_Weight,
                                 nMax_Vol,
                                 strErrorMsg);
          IF (SUBSTR(strErrorMsg, 1, 1) = 'N') THEN
            RETURN;
          END IF;
          --Add End

          /*   --如果直正物流箱试算，并且同商品可拆箱
          IF v_csOutDirect.B_PICK = '2' and blSplitBox = TRUE
            THEN
            --商品折箱,预留

            P_SPLIT_OUTSTOCKDIRECT(strEnterPriseNo, --企业
                                   strWarehouseNo, --仓别
                                   v_csOutDirect.DIRECT_SERIAL, --指示ID
                                   v_csOutDirect.Locate_Qty,
                                   v_csOutDirect.Qmin_Operate_Packing,
                                   nMax_Weight,
                                   nMax_Vol,
                                   nMax_PackRate,
                                   v_csOutDirect.Unit_Weight,
                                   v_csOutDirect.Unit_Volumn,
                                   v_csOutDirect.Unit_Packrate,
                                   v_csOutDirect.Cumulative_Volumn,
                                   --0, --1为客户标签，0为拣货标签
                                   nUseType,
                                   strUserId, --员工ID
                                   blCalcuWeight,
                                   blCalcuVol,
                                   blCalcuPackQTY,
                                   nUnallot_Weight,
                                   nUnAllot_Vol,
                                   nUnAllot_PackRate,
                                   nCurr_Weight,
                                   nCurr_Vol,
                                   nCurr_PackRate,
                                   strNewContainerNo,
                                   strErrorMsg);

          else
            --*/

          v_nOrderCount  := 1;
          v_nItems:=1;

          nUnallot_Weight   := nMax_Weight;
          nUnAllot_Vol      := nMax_Vol;
          nUnAllot_PackRate := nMax_PackRate;
          nCurr_Vol         := v_csOutDirect.SUM_ARTICLE_VOL;
          --end if;
        end if;

        --修改出货下架指示
        UPDATE ODATA_OUTSTOCK_DIRECT t
           SET t.UPDT_DATE      = SYSDATE,
               t.UPDT_NAME      = strUserId,
               t.s_container_no = strNewContainerNo
         WHERE t.enterprise_no = strEnterPriseNo
           and t.WAREHOUSE_NO = strWarehouseNo
           AND t.DIRECT_SERIAL = v_csOutDirect.DIRECT_SERIAL;

        IF SQL%ROWCOUNT <= 0 THEN
          strErrorMsg := 'N|更新指示失败，未更新到数据';
          RETURN;
        END IF;

        --按储位按商品计算
        strCellCondition := strCurrCellCondition;
        --成单范围
        strCurrCalculateRage := strCalculateRange;
        strCurr_ArticleNo    := v_csOutDirect.article_no;

        IF blCalcuPackQTY = TRUE THEN
          nUnAllot_PackRate := nUnAllot_PackRate - nCurr_PackRate;
        end if;
        IF blCalcuWeight = TRUE THEN
          nUnallot_Weight := nUnallot_Weight - nCurr_Weight;
        end if;
        IF blCalcuVol = TRUE THEN
          nUnAllot_Vol := nUnAllot_Vol - nCurr_Vol;
        end if;

      END LOOP;

    end loop;
    strErrorMsg := 'Y';
  EXCEPTION
    WHEN OTHERS THEN
      strErrorMsg := 'N|' || SQLCODE || ' ' || SQLERRM ||
                     SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
  END P_CONTAINER_CALCULATE_DIVIDE;

/*\***铁越特殊处理***\
  \******\
  PROCEDURE P_Container_CALCULATE(strEnterPriseNo IN odata_outstock_direct.enterprise_no%TYPE, --企业
                                  strWarehouseNo  IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
                                  strWaveNo       IN ODATA_OUTSTOCK_DIRECT.WAVE_NO%TYPE, --波次号
                                  strUserId       IN ODATA_OUTSTOCK_DIRECT.UPDT_NAME%TYPE, --员工ID
                                  strErrorMsg     OUT VARCHAR2) IS
    strCondition     varchar2(32767) := 'N';
    strOldCondition  varchar2(32767) := 'N';
    v_strLabelNo     stock_label_m.label_no%type;
    v_strContainerNo stock_label_m.container_no%type;
    v_strSESSION_ID  varchar2(100);
  begin
    strErrorMsg := 'N|[P_Container_CALCULATE]';

    --更新此下架指示的作业类型为B
    update odata_outstock_direct ood
       set ood.operate_type      = 'B',
           ood.s_container_no    = 'N',
           ood.pick_container_no = 'N',
           ood.cust_container_no = 'N',
           ood.pick_type         = '1'
     where ood.enterprise_no = strEnterPriseNo
       and ood.warehouse_no = strWarehouseNo
       and ood.wave_no = strWaveNo;
    --获取下架指示
    FOR v_csOutDirect IN (select cdc.ware_no || cdc.area_no area_no,
                                 ood.article_no
                            from ODATA_OUTSTOCK_DIRECT OOD
                           INNER JOIN CDEF_DEFCELL CDC
                              ON ood.enterprise_no = cdc.enterprise_no
                             and OOD.S_CELL_NO = CDC.CELL_NO
                             and ood.warehouse_no = cdc.warehouse_no
                           WHERE OOD.TEMP_STATUS < '16'
                             and ood.enterprise_no = strEnterPriseNo
                             AND OOD.WAREHOUSE_NO = strWarehouseNo
                             AND OOD.WAVE_NO = strWaveNo
                             AND OOD.OUTSTOCK_TYPE = '0'
                             AND OOD.OPERATE_TYPE = 'B'
                             AND OOD.S_CONTAINER_NO = 'N'
                           ORDER BY ood.article_no,
                                    cdc.ware_no || cdc.area_no) LOOP

      strOldCondition := strCondition;
      strCondition    := v_csOutDirect.article_no || v_csOutDirect.area_no;
      if strCondition = 'N' or strOldCondition <> strCondition then
        --取号
        PKLG_WMS_BASE.p_get_ContainerNoBase(strEnterPriseNo,
                                            strWareHouseNo,
                                            'B',
                                            strUserId,
                                            'D',
                                            1,
                                            1,
                                            '',
                                            v_strLabelNo,
                                            v_strContainerNo,
                                            v_strSESSION_ID,
                                            strErrorMsg);
        if substr(strErrorMsg, 1, 2) = 'N|' then
          return;
        end if;

        --更新容器
        update odata_outstock_direct t
           set t.s_container_no    = v_strContainerNo,
               t.pick_container_no = v_strContainerNo,
               t.cust_container_no = v_strContainerNo
         where t.TEMP_STATUS < '16'
           and t.enterprise_no = strEnterPriseNo
           AND t.WAREHOUSE_NO = strWarehouseNo
           AND t.WAVE_NO = strWaveNo
           AND t.OUTSTOCK_TYPE = '0'
           AND t.OPERATE_TYPE = 'B'
           AND T.S_CONTAINER_NO = 'N'
           and t.article_no = v_csOutDirect.article_no
           and t.s_cell_no in
               (select cell_no
                  from cdef_defcell
                 where enterprise_no = strEnterPriseNo
                   and warehouse_no = strWarehouseNo
                   and ware_no || area_no = v_csOutDirect.area_no);
      end if;
    end loop;
    strErrorMsg := 'Y|[]';
  end P_Container_CALCULATE;
*/
END PKLG_CONTAINER_CALCULATE;

/

