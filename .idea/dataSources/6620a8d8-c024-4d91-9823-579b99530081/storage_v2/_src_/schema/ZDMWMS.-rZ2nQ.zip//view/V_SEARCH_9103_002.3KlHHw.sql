create view V_SEARCH_9103_002 as
select "ENTERPRISE_NO","WAREHOUSE_NO","OWNER_NO","OWNER_NAME","WAVE_NO","EXP_NO","SOURCEEXP_NO","GROUP_NO","GROUP_NAME","EXP_TYPE","LOCATE_DATE","DIVERSITY_PLAN_QTY","BATCH_NO","PACKING_QTY","CUST_NO","CUST_NAME","STATUS","ARTICLE_NO","ARTICLE_NAME","ARTICLE_QTY","PLAN_QTY","LOCATED_QTY","LOCATE_QTY","OWNER_ARTICLE_NO","BARCODE" from (select olm.enterprise_no,olm.warehouse_no,olm.owner_no,bdo.owner_name,olm.wave_no,old.exp_no,oem.sourceexp_no,bda.GROUP_NO,bda.GROUP_NAME,
olm.exp_type,trunc(olm.locate_date) locate_date,oed.article_qty-oed.locate_qty diversity_plan_qty,old.batch_no,oed.packing_qty,
old.cust_no,bdc.cust_name,olm.status,oed.article_no,bda.article_name,oed.article_qty,old.plan_qty,old.located_qty,oed.locate_qty,bda.owner_article_no,bda.barcode
from (select * from odata_locate_m union select * from odata_locate_mhty) olm
join (select * from odata_locate_d union select * from odata_locate_dhty) old
on olm.ENTERPRISE_NO=old.ENTERPRISE_NO and olm.WAREHOUSE_NO=old.WAREHOUSE_NO
and olm.OWNER_NO=old.OWNER_NO and olm.WAVE_NO=old.WAVE_NO
join odata_exp_d oed on old.enterprise_no = oed.enterprise_no
and old.warehouse_no = oed.warehouse_no and old.owner_no = oed.owner_no and old.exp_no = oed.exp_no and old.article_no=oed.article_no
join odata_exp_m oem on oem.enterprise_no = oed.enterprise_no
   and oem.warehouse_no = oed.warehouse_no and oem.owner_no = oed.owner_no and oem.exp_no = oed.exp_no
join bdef_defowner bdo on olm.owner_no=bdo.owner_no and olm.enterprise_no=bdo.enterprise_no
join bdef_defcust bdc on old.owner_no=bdc.owner_no and old.enterprise_no=bdc.enterprise_no and old.cust_no=bdc.cust_no
join v_bdef_defarticle bda on oed.owner_no=bda.owner_no and oed.enterprise_no=bda.enterprise_no and oed.article_no=bda.article_no) c


/

