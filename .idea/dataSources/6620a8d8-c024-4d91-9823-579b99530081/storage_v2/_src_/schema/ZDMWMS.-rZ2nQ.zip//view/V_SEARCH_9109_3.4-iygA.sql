create view V_SEARCH_9109_3 as
select b.WAREHOUSE_NO,
       b.OWNER_NO,
       to_char(a.operate_date, 'yyyy-mm-dd') operate_date,
       a.outstock_no,
       oem.sourceexp_no,
       b.ASSIGN_NAME,
       d.worker_name,
       --a.operate_type,
       count(distinct b.article_no) articleCount,
       sum(b.REAL_QTY) REAL_QTY,
       sum(b.realBox) realBox,
       sum(b.realDis) realDis,
       sum(b.NPickAreaQty) NPickAreaQty,
       sum(b.NPickAreaBox) NPickAreaBox,
       sum(b.NPickAreaDis) NPickAreaDis,
       sum(volumn) volumn,
       sum(weight) weight
  from
    odata_outstock_mhty a,
  (
    select
       ood.warehouse_no,
       ood.owner_no,
       ood.outstock_no,
       ood.exp_date,
       ood.outstock_name assign_name ,
       ood.exp_no,
       ood.article_no,
       ood.packing_qty,
       cda.area_pick,
       /*sum(ood.REAL_QTY) REAL_QTY,
       sum(trunc(ood.REAL_QTY / ood.packing_qty)) realBox,
       sum(mod(ood.REAL_QTY, ood.packing_qty)) realDis,*/
       case when cda.area_pick=1 then 0  else sum(ood.REAL_QTY) end NPickAreaQty,
       case when cda.area_pick=1 then 0  else sum(trunc(ood.REAL_QTY / ood.packing_qty))  end  NPickAreaBox,
       case when cda.area_pick=1 then 0  else sum(mod(ood.REAL_QTY, ood.packing_qty)) end NPickAreaDis,
       case when cda.area_pick=1 then  sum(ood.REAL_QTY) else 0 end REAL_QTY,
       case when cda.area_pick=1 then  sum(trunc(ood.REAL_QTY / ood.packing_qty)) else 0 end realBox,
       case when cda.area_pick=1 then sum(mod(ood.REAL_QTY, ood.packing_qty)) else 0 end realDis，
       sum(trunc(ood.REAL_QTY / ood.packing_qty))*vapvw.packing_volumn volumn ,
       sum(trunc(ood.REAL_QTY / ood.packing_qty))*vapvw.packing_weight weight
    FROM
      ODATA_OUTSTOCK_DHTY OOD,
      cdef_defcell cdc,
      cdef_defarea cda,
      v_article_pack_volumn_weight vapvw
    WHERE
      ood.s_cell_no=cdc.cell_no
      and ood.warehouse_no=cdc.warehouse_no
      and cdc.warehouse_no=cda.warehouse_no
      and cdc.ware_no=cda.ware_no
      and cdc.area_no=cda.area_no
      and ood.article_no=vapvw.article_no
      and ood.packing_qty=vapvw.packing_qty
   GROUP BY
     ood.warehouse_no,
     ood.owner_no,
     ood.outstock_no,
     ood.exp_date,
     ood.outstock_name,
     ood.exp_no,
     ood.article_no,
     ood.packing_qty,
     cda.area_pick，
     packing_volumn，
     packing_weight
  ) b
  left join bdef_defworker d
    on b.ASSIGN_NAME = d.worker_no
  left join odata_exp_m oem
    on b.exp_no=  oem.exp_no
 where
   a.outstock_no = b.outstock_no
   and a.outstock_type = 0
 group by
       b.WAREHOUSE_NO,
       b.OWNER_NO,
       to_char(a.operate_date, 'yyyy-mm-dd'),
       a.outstock_no,
       oem.sourceexp_no,
       b.ASSIGN_NAME,
       d.worker_name
 order by a.outstock_no desc

/

