create package        PKOBJ_STOCK is

  -- Author  : ADMINISTRATOR
  -- Created : 2013-09-28
  -- Purpose :  库存对象存储过程包
  ---------------------------------------------------------【公共begin】---------------------------------------------
  /*****************************************************************************************
     功能：扣减源库存 循环扣减
    Modify By luozhiling AT 2013-09-28
  *****************************************************************************************/
  procedure p_UpdtContent_qtyByCellNo(strEnterPriseNo  in stock_content.enterprise_no%type, -- 企业编号
                                      strWAREHOUSE_NO  in stock_content.WAREHOUSE_NO%type, --仓别
                                      strOwner_No      in stock_content.Owner_No%type, --委托业主
                                      strArticle_no    in stock_content.article_no%type, --商品编号
                                      nArticle_id      in stock_content.article_id%type, --商品属性ID
                                      strCell_no       in stock_content.cell_no%type, --储位
                                      strR_cell_no     in stock_content.cell_no%type, --关系储位
                                      nPacking_Qty     in stock_content.Packing_Qty%type, --商品包装
                                      nQty             in stock_content.qty%type, --商品包装
                                      strlabelNo       in stock_content.label_no%type, --商品容器号
                                      strStock_type    in stock_content.stock_type%type, --存储类型
                                      strStock_value   in stock_content.stock_value%type, --对应存储值
                                      strUser_id       in stock_content.Rgst_Name%type, --操作人员
                                      strPAPER_NO      in stock_content_move.PAPER_NO%type, --操作单号
                                      strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                                      strErrorMsg      out varchar2); --返回 执行结果

  /*****************************************************************************************
     功能：扣减源库存  不循环，带cell_ID，没有预下
    Modify By luozhiling AT 2013-09-28
  *****************************************************************************************/
  procedure p_UpdtContent_qtyByCellID(strEnterPriseNo  in stock_content.enterprise_no%type, -- 企业编号
                                      strWAREHOUSE_NO  in stock_content.WAREHOUSE_NO%type, --仓别
                                      strcell_id       in stock_content.cell_id%type, --储位ID
                                      strcell_no       in stock_content.cell_no%type, --储位
                                      strR_cell_no     in stock_content.cell_no%type, --关系储位
                                      nQty             in stock_content.qty%type, --数量
                                      noutstock_qty    in stock_content.outstock_qty%type, --预下数量
                                      strUser_id       in stock_content.Rgst_Name%type, --操作人员
                                      strPAPER_NO      in stock_content_move.PAPER_NO%type, --操作单号
                                      strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                                      strOutMsg        out varchar2); --返回 执行结果

  /*****************************************************************************************
     功能：扣减源库存  不循环，带cell_ID,无预下数量
    Modify By luozhiling AT 2013-09-28
  *****************************************************************************************/
  procedure p_UpdtContentByCellID(strEnterPriseNo  in stock_content.enterprise_no%type, -- 企业编号
                                  strWAREHOUSE_NO  in stock_content.WAREHOUSE_NO%type, --仓库编码
                                  strcell_id       in stock_content.cell_id%type, --储位ID
                                  strcell_no       in stock_content.cell_no%type, --储位
                                  strR_cell_no     in stock_content.cell_no%type, --关系储位
                                  nQty             in stock_content.qty%type, --数量
                                  strUser_id       in stock_content.Rgst_Name%type, --操作人员
                                  strPAPER_NO      in stock_content_move.PAPER_NO%type, --操作单号
                                  strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                                  strOutMsg        out varchar2); --返回 执行结果
  /*****************************************************************************************
     功能：增加目的库存 没有预上数量
    Modify By yanJunFeng AT 2013-03-28
  *****************************************************************************************/
  procedure p_InstContent_qtyByCellNo(strEnterPriseNo  in stock_content.enterprise_no%type, -- 企业编号
                                      strWAREHOUSE_NO  in stock_content.WAREHOUSE_NO%type, --仓别
                                      strOwner_No      in stock_content.Owner_No%type, --委托业主
                                      strDeptNo        in stock_content.dept_no%type, --部门编码
                                      strArticle_no    in stock_content.article_no%type, --商品编号
                                      nArticle_id      in stock_content.article_id%type, --商品属性ID
                                      strCell_no       in stock_content.cell_no%type, --储位
                                      strR_cell_no     in stock_content.cell_no%type, --关系储位
                                      nPacking_Qty     in stock_content.Packing_Qty%type, --商品包装
                                      nQty             in stock_content.qty%type, --数量
                                      strlabel_no      in stock_content.label_no%type, --标签号
                                      strsub_label_no  in stock_content.sub_label_no%type,
                                      strStock_type    in stock_content.stock_type%type, --存储类型
                                      strStock_value   in stock_content.stock_value%type, --对应存储值
                                      strUser_id       in stock_content.Rgst_Name%type, --操作人员
                                      strPAPER_NO      in stock_content_move.PAPER_NO%type, --操作单号
                                      strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                                      nMvHandFlag      in stock_content.mv_hand_flag%type, --是否可手工移库 0:不允许手工移库；1：可手工移库
                                      nOutCellID       out stock_content.cell_id%type, --返回的储位ID
                                      strOutMsg        out varchar2); --返回 执行结果
  /*****************************************************************************************
     功能：增加目的库存 没有预上数量 盘点记帐专用
    midyfy by MM 20140506
  *****************************************************************************************/
  procedure p_InstContent_fcqtyByCellNo(strEnterPriseNo  in stock_content.enterprise_no%type, -- 企业编号
                                        strWAREHOUSE_NO  in stock_content.WAREHOUSE_NO%type, --仓库编码
                                        strOwner_No      in stock_content.Owner_No%type, --委托业主
                                        strDeptNo        in stock_content.dept_no%type, --部门编码
                                        strArticle_no    in stock_content.article_no%type, --商品编号
                                        nArticle_id      in stock_content.article_id%type, --商品属性ID
                                        strCell_no       in stock_content.cell_no%type, --储位
                                        strR_cell_no     in stock_content.cell_no%type, --关系储位
                                        nPacking_Qty     in stock_content.Packing_Qty%type, --商品包装
                                        nQty             in stock_content.qty%type, --数量
                                        strlabel_no      in stock_content.label_no%type, --标签号
                                        strsub_label_no  in stock_content.sub_label_no%type, --子标签号
                                        strStock_type    in stock_content.stock_type%type, --存储类型
                                        strStock_value   in stock_content.stock_value%type, --对应存储值
                                        strUser_id       in stock_content.Rgst_Name%type, --操作人员
                                        strPAPER_NO      in stock_content_move.PAPER_NO%type, --操作单号
                                        strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                                        nMvHandFlag      in stock_content.mv_hand_flag%type, --是否可手工移库 0:不允许手工移库；1：可手工移库
                                        nOutCellID       out stock_content.cell_id%type, --返回的储位ID
                                        strOutMsg        out varchar2);
  /*转换库存STOCK_TYPE,STOCK_VALUE*/
  procedure p_TransContent_qtyByCellID(strEnterPriseNo in stock_content.enterprise_no%type, -- 企业编号
                                       strWAREHOUSE_NO in stock_content.WAREHOUSE_NO%type, --仓库编码
                                       strCell_No      in stock_content.cell_no%type, --储位
                                       nSCell_ID       in stock_content.cell_id%type, --储位ID
                                       nQTY            IN stock_content.qty%type, --数量
                                       strStock_type   in stock_content.stock_type%type, --存储类型
                                       strStock_value  in stock_content.stock_value%type, --对应存储值
                                       strUser_ID      in bdef_defworker.worker_no%type,
                                       nDCell_ID       out stock_content.cell_id%type, --新储位ID
                                       strOutMsg       out varchar2);

  /*****************************************************************************************
     功能：增加目的库存  带cell_ID，有预上数量
    Modify By yanJunFeng AT 2013-03-28
  *****************************************************************************************/
  procedure p_InstContent_qtyByCellID(strEnterPriseNo  in stock_content.enterprise_no%type, -- 企业编号
                                      strWAREHOUSE_NO  in stock_content.WAREHOUSE_NO%type, --仓别
                                      strcell_id       in stock_content.cell_id%type, --储位ID
                                      strcell_no       in stock_content.cell_no%type, --储位
                                      strR_cell_no     in stock_content.cell_no%type, --关系储位
                                      nQty             in stock_content.qty%type, --数量
                                      ninstock_qty     in stock_content.instock_qty%type, --预上数量
                                      strUser_id       in stock_content.Rgst_Name%type, --操作人员
                                      strPAPER_NO      in stock_content_move.PAPER_NO%type, --操作单号
                                      strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                                      strOutMsg        out varchar2); --返回 执行结果

  /*****************************************************************************************
     功能：更新库存表的container_no,label_no
    Modify By luozhiling AT 2014-05-15
  *****************************************************************************************/
  procedure p_UpdtContent_ContainerNo(strEnterPriseNo   in stock_content.enterprise_no%type, -- 企业编号
                                      strWAREHOUSE_NO   in stock_content.WAREHOUSE_NO%type, --仓库编码
                                      strNewLabel_no    in stock_content.label_no%type, --新标签号
                                      strNewSupLabel_no in stock_content.sub_label_no%type, --新子标签号
                                      strCellNo         in stock_content.cell_no%type,
                                      nCellId           in stock_content.cell_id%type, --CellId
                                      strUser_id        in stock_content.Rgst_Name%type, --操作人员
                                      nOutcellId        out stock_content.cell_id%type,
                                      strOutMsg         out varchar2); --返回 执行结果

  /*****************************************************************************************
     功能：更新库存表的可移库标识
    Modify By luozhiling AT 2013-09-29
  *****************************************************************************************/
  procedure p_UpdtContent_Mvflag(strEnterPriseNo in stock_content.enterprise_no%type, -- 企业编号
                                 strWAREHOUSE_NO in stock_content.WAREHOUSE_NO%type, --仓库编码
                                 strCellNo       in stock_content.cell_no%type,
                                 nCellId         in stock_content.cell_id%type,
                                 strMvHandFlag   in stock_content.mv_hand_flag%type,
                                 strUser_id      in stock_content.Rgst_Name%type, --操作人员
                                 strOutMsg       out varchar2);

  /*****************************************************************************************
     功能：写库存预上预下
    Modify By yanJunFeng AT 2013-03-28
  *****************************************************************************************/
  procedure p_UpdtContent_Reservation(strEnterPriseNo in stock_content.enterprise_no%type, -- 企业编号
                                      strWAREHOUSE_NO in stock_content.WAREHOUSE_NO%type, --仓库编码
                                      strS_Cell_no    in stock_content.cell_no%type, --来源储位
                                      strS_Cell_id    in stock_content.cell_id%type, --来源储位ID
                                      strD_cell_no    in stock_content.cell_no%type, --目的储位
                                      strD_Label_No   in stock_content.label_no%type,
                                      strSubLabelNo   in stock_content.sub_label_no%type, --子标签
                                      nQty            in stock_content.qty%type, --商品包装
                                      strInstock_type in stock_content.Instock_type%type, --存储类型
                                      strUser_id      in stock_content.Rgst_Name%type, --操作人员
                                      n_cell_id       in out stock_content.cell_id%type, --储位id
                                      strOutMsg       out varchar2); --返回 执行结果

  --  ------------------------------------------------------【公共end】----------------------------------------------------------------------
  --
  --  /*
  --    功能：根据板明细增加暂存区库存  进货验收封板
  --   作者：luozhiling
  --   日期：2013-10-15
  --  */
  --
  --  procedure p_Idata_InsertPalContent(strWareHouseNo     in idata_check_pal.warehouse_no%type, --仓别
  --                                     strScheckNo        in idata_check_pal.s_check_no%type, --汇总验收单号
  --                                     strTools           in stock_content_move.terminal_flag%type, --操作设备
  --                                     strUser_ID         in idata_check_pal.Rgst_Name%type, --操作人员
  --                                     strLabelNo         in idata_check_pal.label_no%type, --板号
  --                                     strLocateNo        in idata_locate_direct.locate_no%type,
  --                                     strspecify_cell_no IN idata_locate_direct.specify_cell_no%type, --指定储位
  --                                     strOutMsg          out varchar2); --返回 执行结果
  --  /*
  --    功能：根据板明细增加暂存区库存  进货验收封板
  --   作者：luozhiling
  --   日期：2013-10-15
  --  */
  --
  --  procedure p_Idata_InsertScheckContent(strWareHouseNo     in idata_check_pal.warehouse_no%type, --仓别
  --                                        strScheckNo        in idata_check_pal.s_check_no%type, --汇总验收单号
  --                                        strTools           in stock_content_move.terminal_flag%type, --操作设备
  --                                        strUser_ID         in idata_check_pal.Rgst_Name%type, --操作人员
  --                                        strLocateNo        in idata_locate_direct.locate_no%type,
  --                                        strspecify_cell_no IN idata_locate_direct.specify_cell_no%type, --指定储位
  --                                        strOutMsg          out varchar2); --返回 执行结果
  --  /*****************************************************************************************************
  --    功能：根据验收汇总单增加暂存区库存  进货验收封板
  --   作者：luozhiling
  --   日期：2013-11-25
  --  *******************************************************************************************************/
  --
  --  procedure p_Idata_InsertIdStock(strWareHouseNo in idata_check_pal.warehouse_no%type, --仓别
  --                                  strScheckNo    in idata_check_pal.s_check_no%type, --汇总验收单号
  --                                  strTools       in stock_content_move.terminal_flag%type, --操作设备
  --                                  strUser_ID     in idata_check_pal.Rgst_Name%type, --操作人员
  --                                  strCellNo      out stock_content.cell_no%type, --指定储位
  --                                  nCellID        out stock_content.cell_id%type,
  --                                  strOutMsg      out varchar2);
  --
  --  /*****************************************************************************************************
  --    功能：根据验收明细增加暂存区库存  进货验收封板
  --   作者：luozhiling
  --   日期：2013-11-25
  --  *******************************************************************************************************/
  --
  procedure p_Idata_InsertIdStockItem(strEnterPriseNo in stock_content.enterprise_no%type, -- 企业编号
                                      strWareHouseNo  in idata_check_pal.warehouse_no%type, --仓别
                                      strScheckNo     in idata_check_pal.s_check_no%type, --汇总验收单号
                                      strArticleNo    in idata_check_pal.article_no%type,
                                      strContainerNo  in idata_check_pal.container_no%type,
                                      strBarcode      in idata_check_d.barcode%type,
                                      strLotNo        in idata_check_d.lot_no%type,
                                      dtProduceDate   in idata_check_d.produce_date%type,
                                      dtExpireDate    in idata_check_d.expire_date%type,
                                      strQuality      in idata_check_d.quality%type,
                                      nArticleId      in stock_content.article_id%type,
                                      nPackingQty     in stock_content.packing_qty%type,
                                      nRowId          in idata_check_d.row_id%type,
                                      CheckQty        in idata_check_d.check_qty%type,
                                      strCheckNo      in idata_check_pal.check_no%type,
                                      strTools        in stock_content_move.terminal_flag%type, --操作设备
                                      strUser_ID      in idata_check_pal.Rgst_Name%type, --操作人员
                                      strCellNo       in stock_content.cell_no%type, --指定储位
                                      nCellID         out stock_content.cell_id%type,
                                      strOutMsg       out varchar2);

  procedure proc_OM_Receipt_WriteContent(strEnterPriseNo  in stock_content.enterprise_no%type, -- 企业编号
                                         strwarehouse_no  in stock_content.warehouse_no%type, --仓别
                                         strS_cell_id     in stock_content.cell_id%type, --来源储位ID
                                         strS_cell_no     in stock_content.cell_no%type, --来源储位
                                         strD_cell_id     in stock_content.cell_id%type, --来源储位ID
                                         strD_cell_no     in stock_content.cell_no%type, --来源储位
                                         nQty             in stock_content.qty%type, --数量
                                         nArticle_qty     in stock_content.qty%type, --预下数量
                                         strPAPER_NO      in stock_content_move.PAPER_NO%type, --操作单号
                                         strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                                         strUser_ID       in odata_outstock_m.rgst_name%type, --操作人员
                                         strOutMsg        out varchar2);

  /*****************************************************************************************
       功能：根据标签，转移库存（装并板使用）
      Modify By luozhiling AT 2013-11-23
  *****************************************************************************************/
  procedure proc_OM_MoveContent_ByContenNo(strEnterPriseNo  in stock_content.enterprise_no%type, -- 企业编号
                                           strwarehouse_no  in stock_label_m.warehouse_no%type, --仓别
                                           strOustockNo     in stock_label_m.container_no%type, --来源容器
                                           nDivideID        IN stock_label_d.divide_id%type,
                                           strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                                           strUSER_ID       in stock_label_m.rgst_name%type, --员工ID
                                           strOutMsg        out varchar2);

  /*****************************************************************************************
       功能：将分播的储位管理，转移到标签，目前用于直通分播单门店的转门店标签
         Modify By luozhiling AT 2015-12-5
  *****************************************************************************************/
  procedure proc_DivideCellToLabel(strEnterPriseNo  in stock_content.enterprise_no%type, -- 企业编号
                                   strwarehouse_no  in stock_label_m.warehouse_no%type, --仓别
                                   strSourceNo      in stock_label_m.source_no%type,
                                   nDivideID        IN stock_label_d.divide_id%type,
                                   strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                                   strUSER_ID       in stock_label_m.rgst_name%type, --员工ID
                                   strOutMsg        out varchar2);

  /*****************************************************************************************
       功能：封车，直接删除库存（封车使用）
      Modify By yanJunFeng AT 2013-03-20
  *****************************************************************************************/
  procedure proc_OM_deliver_DelContent(strEnterPriseNo  in stock_content.enterprise_no%type, -- 企业编号
                                       strwarehouse_no  in odata_loadpropose_m.warehouse_no%type, --仓别
                                       strLoadproposeNo in odata_loadpropose_m.loadpropose_no%type, --装车建议单
                                       strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                                       strUSER_ID       in stock_content_move.rgst_name%type, --员工ID
                                       strOutMsg        out varchar2);

  ---------------------------------------------------------【出货end】---------------------------------------------
  /*
  作者:luozhiling
   日期:  2013-11-23
   功能: 盘点结案写库存
  */
  procedure P_fcdata_insetStock(strEnterPriseNo in stock_content.enterprise_no%type, -- 企业编号
                                strWareHouseNo  in fcdata_check_m.warehouse_no%type, --仓别
                                strOwner_no     in fcdata_check_m.owner_no%type, --委托业主编码
                                strCheckNo      in fcdata_check_m.plan_no%type, --计划单号
                                strWorkerNo     in fcdata_check_m.rgst_name%type, --操作人
                                v_iCount        out varchar2,
                                strResult       out varchar2);

  --  ---------------------------------------------------------[返配库存处理】------------------------------------------
  /***********************************************************************************************************
    功能：根据验收汇总单增加暂存区库存  返配验收封板
   作者：luozhiling
   日期：2013-11-15
  ***************************************************************************************************************/

  procedure p_Ridata_InsertSCheckStock(strEnterPriseNo    in stock_content.enterprise_no%type, -- 企业编号
                                       strWareHouseNo     in ridata_check_pal.warehouse_no%type, --仓别
                                       strScheckNo        in ridata_check_m.s_check_no%type, --汇总验收单号
                                       strTools           in stock_content_move.terminal_flag%type, --操作设备
                                       strUser_ID         in ridata_check_m.Rgst_Name%type, --操作人员
                                       strLocateNo        in ridata_locate_direct.locate_no%type,
                                       strspecify_cell_no IN ridata_locate_direct.specify_cell_no%type, --指定储位
                                       strOutMsg          out varchar2);
  --  /***********************************************************************************************************
  --    功能：根据验收板号增加暂存区库存  返配验收封板
  --   作者：luozhiling
  --   日期：2013-11-15
  --  ***************************************************************************************************************/

  procedure p_Ridata_InsertPalStock(strEnterPriseNo in stock_content.enterprise_no%type, -- 企业编号
                                    strWareHouseNo  in ridata_check_pal.warehouse_no%type, --仓别
                                    strLabelNo      in ridata_check_pal.label_no%type, --汇总验收单号
                                    strTools        in stock_content_move.terminal_flag%type, --操作设备
                                    strUser_ID      in ridata_check_m.Rgst_Name%type, --操作人员
                                    strLocateNo     in ridata_locate_direct.locate_no%type,
                                    strDestCellNo   in cdef_defcell.cell_no%type,
                                    strOutMsg       out varchar2);
  /**********************************************************************************************************
  MM
  2014.4.17
  功能：写进出帐表
  ***********************************************************************************************************/
  procedure P_stock_Insertaccount(strEnterPriseNo in stock_content.enterprise_no%type, -- 企业编号
                                  strWareHouseNo  in fcdata_check_m.warehouse_no%type, --仓库编码
                                  strOwnerNo      in fcdata_check_m.owner_no%type,
                                  strPlanNo       in fcdata_check_m.plan_no%type, --盘点计划单号
                                  strUserId       in fcdata_plan_m.rgst_name%type,
                                  strResult       OUT varchar2);

  /*****************************************************************************************
     功能：上架回单，分两步更新库存
    Modify By lich AT 2014-05-15
  *****************************************************************************************/
  procedure p_UpdtInstContent_Qty(strEnterPriseNo  in stock_content.enterprise_no%type, -- 企业编号
                                  strWAREHOUSE_NO  in stock_content.WAREHOUSE_NO%type, --仓库编码
                                  strcell_id       in stock_content.cell_id%type, --储位ID
                                  strcell_no       in stock_content.cell_no%type, --储位
                                  strR_cell_no     in stock_content.cell_no%type, --关系储位
                                  nQty             in stock_content.qty%type, --数量
                                  ninstock_qty     in stock_content.instock_qty%type, --预上数量
                                  strUser_id       in stock_content.Rgst_Name%type, --操作人员
                                  strPAPER_NO      in stock_content_move.PAPER_NO%type, --操作单号
                                  strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                                  nOutCellId       out stock_content.cell_id%type,
                                  strOutMsg        out varchar2); --返回 执行结果

  /*****************************************************************************************************
    功能：根据验收汇总单增加暂存区库存  进货验收封板
   作者：luozhiling
   日期：2013-11-25
  *******************************************************************************************************/

  procedure p_Idata_InsertIdStock(strEnterPriseNo in stock_content.enterprise_no%type, -- 企业编号
                                  strWareHouseNo  in idata_check_pal.warehouse_no%type, --仓别
                                  strScheckNo     in idata_check_pal.s_check_no%type, --汇总验收单号
                                  strTools        in stock_content_move.terminal_flag%type, --操作设备
                                  strUser_ID      in idata_check_pal.Rgst_Name%type, --操作人员
                                  strCellNo       out stock_content.cell_no%type, --指定储位
                                  nCellID         out stock_content.cell_id%type,
                                  strOutMsg       out varchar2);
  /*****************************************************************************************
     功能：增加目的库存 没有预上数量,不写储位三级帐
    Modify By luozhiling AT 2014-11-7
  *****************************************************************************************/
  procedure p_InstStockContent(strEnterPriseNo in stock_content.enterprise_no%type, -- 企业编号
                               strWAREHOUSE_NO in stock_content.WAREHOUSE_NO%type, --仓库编码
                               strOwner_No     in stock_content.Owner_No%type, --委托业主
                               strDeptNo       in stock_content.dept_no%type, --部门编码
                               strArticle_no   in stock_content.article_no%type, --商品编号
                               nArticle_id     in stock_content.article_id%type, --商品属性ID
                               strCell_no      in stock_content.cell_no%type, --储位
                               nPacking_Qty    in stock_content.Packing_Qty%type, --商品包装
                               nQty            in stock_content.qty%type, --数量
                               strlabel_no     in stock_content.label_no%type, --标签号
                               strsub_label_no in stock_content.sub_label_no%type, --子标签号
                               strStock_type   in stock_content.stock_type%type, --存储类型
                               strStock_value  in stock_content.stock_value%type, --对应存储值
                               strUser_id      in stock_content.Rgst_Name%type, --操作人员
                               strOutMsg       out varchar2);
  /*****************************************************************************************
     功能：扣减源库存 循环扣减, 不处理预约上下架量，直接扣减库存,不记录储位三级帐
    创建人 luozhiling AT 2014-10-7
  *****************************************************************************************/
  procedure p_UpdateStockContent(strEnterPriseNo in stock_content.enterprise_no%type, -- 企业编号
                                 strWAREHOUSE_NO in stock_content.WAREHOUSE_NO%type, --仓别
                                 strOwner_No     in stock_content.Owner_No%type, --委托业主
                                 strArticle_no   in stock_content.article_no%type, --商品编号
                                 nArticle_id     in stock_content.article_id%type, --商品属性ID
                                 strCell_no      in stock_content.cell_no%type, --储位
                                 nPacking_Qty    in stock_content.Packing_Qty%type, --商品包装
                                 nQty            in stock_content.qty%type, --数量
                                 strlabelNo      in stock_content.label_no%type, --商品容器号
                                 strStock_type   in stock_content.stock_type%type, --存储类型
                                 strStock_value  in stock_content.stock_value%type, --对应存储值
                                 strUser_id      in stock_content.Rgst_Name%type, --操作人员
                                 strErrorMsg     out varchar2);
  /*******************************************************************************************8
  功能说明：根据退货下架单明细更新库存
           1、对整张下架单进行处理
           2015.7.22
  *******************************************************************************************/
  procedure P_WM_Receipt_WriteContent(strEnterPriseNo  in rodata_outstock_m.enterprise_no%type,
                                      strwarehouse_no  in rodata_outstock_m.warehouse_no%type, --仓别
                                      strOutstock_no   in rodata_outstock_m.outstock_no%type, --退货单号
                                      strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                                      strUser_ID       in bdef_defworker.worker_no%type, --操作人员
                                      strOutMsg        out varchar2);
  /********************************************************************************************
  创建人：luozhiling
  创建时间：2014.11.8
  功能说明：退货标签回单库存处理。
  ********************************************************************************************/

  --根据退货下架单明细更新库存
  procedure P_WM_label_stock(strEnterPriseNo  in stock_content.enterprise_no%type, -- 企业编号
                             strwarehouse_no  in rodata_outstock_m.warehouse_no%type, --仓别
                             strOutstock_no   in rodata_outstock_m.outstock_no%type, --退货单号
                             strLabelNo       in rodata_outstock_d.label_no%type, --
                             strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                             strUser_ID       in bdef_defworker.worker_no%type, --操作人员
                             strOutMsg        out varchar2);
  procedure proc_stock_account_log;
  /********************************************************************
   功能说明：产生前一天的库存流水账

  ********************************************************************/
  procedure proc_stock_content_rj;
  /**********************************************************************************************
   作者:lich
   日期:  2014-05-12
   功能: 新增商品批号
  ************************************************************************************************/
  procedure p_Insert_Article_lot_manage(strEnterPriseNo in bdef_article_lot_manage.enterprise_no%type,
                                        strwarehouse_no in bdef_article_lot_manage.warehouse_no%type,
                                        strArticleNo    in bdef_article_lot_manage.article_no%type, --商品编码
                                        strLotNo        in bdef_article_lot_manage.lot_no%type, --批号
                                        dtProduceDate   in bdef_article_lot_manage.produce_date%type, --生产日期
                                        dtExpireDate    in bdef_article_lot_manage.expire_date%type, --有期期
                                        nExpiryDays     in bdef_article_lot_manage.expiry_days%type, --天数
                                        strWorkerNo     in bdef_article_lot_manage.rgst_name%type, --操作人
                                        nPrice          in bdef_article_lot_manage.price%type, --价格
                                        strResult       out varchar2 --返回结果
                                        );
  /**********************************************************************************************
   作者:luozhiling
   日期:  2015-03-16
   功能: 新增商品库存三级帐
  ************************************************************************************************/
  procedure P_InsertArticleStockList(strEnterprise_no in stock_content_list.enterprise_no%type, --企业
                                     strWAREHOUSE_NO  in stock_content_list.WAREHOUSE_NO%type, --仓库编码
                                     strOwner_No      in stock_content_list.owner_no%type, --委托业主编码
                                     strDeptNo        in stock_content_list.dept_no%type,
                                     strArticleNo     in stock_content_list.article_no%type, --商品编码
                                     strQuality       in stock_content_list.quality%type, --品质
                                     dtProduceDate    in stock_content_list.produce_date%type, --生产日期
                                     dtExpireDate     in stock_content_list.expire_date%type, --有效日期
                                     strLotNo         in stock_content_list.lot_no%type, --批号
                                     strRSV_BATCH1    in stock_content_list.rsv_batch1%type, --预留批属性1
                                     strRSV_BATCH2    in stock_content_list.rsv_batch2%type, --预留批属性2
                                     strRSV_BATCH3    in stock_content_list.rsv_batch3%type, --预留批属性3
                                     strRSV_BATCH4    in stock_content_list.rsv_batch4%type, --预留批属性4
                                     strRSV_BATCH5    in stock_content_list.rsv_batch5%type, --预留批属性5
                                     strRSV_BATCH6    in stock_content_list.rsv_batch6%type, --预留批属性6
                                     strRSV_BATCH7    in stock_content_list.rsv_batch7%type, --预留批属性7
                                     strRSV_BATCH8    in stock_content_list.rsv_batch8%type, --预留批属性8
                                     strBarcode       in stock_content_list.barcode%type, --商品条码
                                     nPackQty         in stock_content_list.packing_qty%type, --包装数量
                                     nRealQty         in stock_content_list.qty%type, --验收数量
                                     strStockType     in stock_content_list.stock_type%type, --存储类型
                                     strStockValue    in stock_content_list.stock_value%type, --存储类型对应值
                                     strMoveType      in stock_content_list.move_type%type,
                                     strPaperType     in stock_content_list.paper_type%type,
                                     strPaperNo       in stock_content_list.paper_no%type,
                                     strUserId        in stock_content_list.rgst_name%type, --人员
                                     strImportBatchNo in stock_content_list.import_batch_no%type,
                                     strResult        out varchar2 --返回结果
                                     );

  /**********************************************************************************************
   作者:luozhiling
   日期:  2015-03-16
   功能: 新增商品批次库存
  ************************************************************************************************/
  procedure P_insertImportBatchStock(strEnterpriseNo  in stock_article_cost.enterprise_no%type, --企业
                                     strWAREHOUSENO   in stock_article_cost.WAREHOUSE_NO%type, --仓库编码
                                     strOwnerNo       in stock_article_cost.owner_no%type, --委托业主编码
                                     strDeptNo        in stock_article_cost.dept_no%type,
                                     strArticleNo     in stock_article_cost.article_no%type, --商品编码
                                     strQuality       in stock_article_cost.quality%type, --品质
                                     strImportBatchNo in stock_article_cost.import_batch_no%type,
                                     dtProduceDate    in stock_article_cost.produce_date%type, --生产日期
                                     dtExpireDate     in stock_article_cost.expire_date%type, --有效日期
                                     strLotNo         in stock_article_cost.lot_no%type, --批号
                                     strRSV_BATCH1    in stock_article_cost.rsv_batch1%type, --预留批属性1
                                     strRSV_BATCH2    in stock_article_cost.rsv_batch2%type, --预留批属性2
                                     strRSV_BATCH3    in stock_article_cost.rsv_batch3%type, --预留批属性3
                                     strRSV_BATCH4    in stock_article_cost.rsv_batch4%type, --预留批属性4
                                     strRSV_BATCH5    in stock_article_cost.rsv_batch5%type, --预留批属性5
                                     strRSV_BATCH6    in stock_article_cost.rsv_batch6%type, --预留批属性6
                                     strRSV_BATCH7    in stock_article_cost.rsv_batch7%type, --预留批属性7
                                     strRSV_BATCH8    in stock_article_cost.rsv_batch8%type, --预留批属性8
                                     strBarcode       in stock_article_cost.barcode%type, --商品条码
                                     nPackQty         in stock_article_cost.packing_qty%type, --包装数量
                                     nRealQty         in stock_article_cost.qty%type, --验收数量
                                     strStockType     in stock_article_cost.stock_type%type, --存储类型
                                     strStockValue    in stock_article_cost.stock_value%type, --存储类型对应值
                                     strUserId        in stock_article_cost.rgst_name%type, --人员
                                     strResult        out varchar2 --返回结果
                                     );

  /*****************************************************************************************
       功能：退货确认，直接删除库存（封车使用）
      Modify By luozhiling AT 2015-3-24
  *****************************************************************************************/
  procedure proc_RO_deliver_DelContent(strEnterPriseNo  in stock_content.enterprise_no%type, -- 企业编号
                                       strwarehouse_no  in rodata_deliver_m.warehouse_no%type, --仓别
                                       strDeliverNo     in rodata_deliver_m.deliver_no%type, --装车建议单
                                       strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                                       strUSER_ID       in stock_content_move.rgst_name%type, --员工ID
                                       strOutMsg        out varchar2);

  /*****************************************************************************************
       功能：报损确认，直接删除库存（封车使用）
      Modify By luozhiling AT 2015-7-28
  *****************************************************************************************/
  procedure proc_So_deliver_DelContent(strEnterPriseNo in stock_content.enterprise_no%type, -- 企业编号
                                       strwarehouse_no in sodata_waste_m.warehouse_no%type, --仓别
                                       strWasteNo      in sodata_waste_m.waste_no%type, --报损单
                                       strUSER_ID      in stock_content_move.rgst_name%type, --员工ID
                                       strOutMsg       out varchar2);
  /*************************************************************************************************
  功能说明：1、判断货主是否绑定储位管理；
            2、若不绑定储位，根据是否混货主的标识来更新或者新增储位与货主的对应关系
            3,根据是否混载储位的标识来更新或者新增商品与储位的对应关系。
  ***************************************************************************************************/
  procedure P_InsertOwnerCell(strEnterpriseNo in idata_instock_m.enterprise_no%type,
                              strWareHouseNo  in idata_instock_m.warehouse_no%type,
                              strOwnerNo      in bdef_defowner.owner_no%type,
                              strCellNo       in idata_instock_d.dest_cell_no%type,
                              strArticleNo    in idata_instock_d.article_no%type,
                              strResult       out varchar2);
  /**************************************************************************************************
  功能说明：
          1、上架储位的校验：
          1）、上架的储位必须是作业区的可用储位；
          2）、必须是同机构的储位；（预留）
          3）、查找此货主是否是绑定储位；
          3.1）若绑定储位，只能找绑定关系的储位；且判断是否可混、混商品，货主混属性
          3.2）若不绑定储位，判断目的储位是否是混货主的储位，若不可混货主，则只能是空储位，或存放该货主货品的储位

  2015.12.7
  **************************************************************************************************/
  procedure CheckRealInstockCell(strEnterpriseNo in idata_instock_m.enterprise_no%type,
                                 strWareHouseNo  in idata_instock_m.warehouse_no%type,
                                 strOwnerNo      in bdef_defowner.owner_no%type,
                                 strArticleNo    in idata_instock_d.article_no%type,
                                 dtProduceDate   in idata_check_d.produce_date%type,
                                 dtExpireDate    in idata_check_d.expire_date%type,
                                 strQuality      in idata_check_d.quality%type, --品质
                                 strLotNo        in idata_check_d.lot_no%type, --批次号
                                 strRSV_BATCH1   in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                                 strRSV_BATCH2   in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                                 strRSV_BATCH3   in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                                 strRSV_BATCH4   in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                                 strRSV_BATCH5   in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                                 strRSV_BATCH6   in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                                 strRSV_BATCH7   in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                                 strRSV_BATCH8   in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                                 strDCellNo      in idata_instock_d.real_cell_no%type, --实际上架储位
                                 strResult       out varchar2);
  /**************************************************************************************************
  功能说明：
          1、移库目的储位的校验：
          1）、移库目的储位必须是作业区的可用储位；
          2）、必须是同机构的储位；（预留）
          3）、查找此货主是否是绑定储位；
          3.1）若绑定储位，只能找绑定关系的储位；且判断是否可混、混商品，货主混属性
          3.2）若不绑定储位，判断目的储位是否是混货主的储位，若不可混货主，则只能是空储位，或存放该货主货品的储位

  2015.12.7
  **************************************************************************************************/
  procedure CheckMoveDestCell(strEnterpriseNo in idata_instock_m.enterprise_no%type,
                              strWareHouseNo  in idata_instock_m.warehouse_no%type,
                              strOwnerNo      in bdef_defowner.owner_no%type,
                              strArticleNo    in idata_instock_d.article_no%type,
                              dtProduceDate   in idata_check_d.produce_date%type,
                              dtExpireDate    in idata_check_d.expire_date%type,
                              strQuality      in idata_check_d.quality%type, --品质
                              strLotNo        in idata_check_d.lot_no%type, --批次号
                              strRSV_BATCH1   in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                              strRSV_BATCH2   in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                              strRSV_BATCH3   in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                              strRSV_BATCH4   in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                              strRSV_BATCH5   in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                              strRSV_BATCH6   in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                              strRSV_BATCH7   in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                              strRSV_BATCH8   in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                              strDCellNo      in idata_instock_d.real_cell_no%type, --实际上架储位
                              strResult       out varchar2);

  /*转换库存：C to B */
  procedure p_TransContent_C2B(strEnterPriseNo  in stock_content.enterprise_no%type, -- 企业编号
                               strWAREHOUSE_NO  in stock_content.WAREHOUSE_NO%type, --仓库编码
                               strCell_No       in stock_content.cell_no%type, --储位
                               strCell_ID       in stock_content.cell_id%type,
                               nArticle_QTY     IN stock_content.qty%type, --折零数量
                               nOutstock_QTY    IN stock_content.outstock_qty%type, --预下数量
                               nQMinOperatePack in bdef_defarticle.qmin_operate_packing%type,
                               nOutCell_ID      out stock_content.cell_id%type,
                               strOutMsg        out varchar2);
  /*转换库存: B to C */
  procedure p_TransContent_B2C(strEnterPriseNo in stock_content.enterprise_no%type, -- 企业编号
                               strWAREHOUSE_NO in stock_content.WAREHOUSE_NO%type, --仓库编码
                               strCell_No      in stock_content.cell_no%type, --储位
                               strCell_ID      in stock_content.cell_id%type,
                               strArticle_No   in bdef_defarticle.article_no%type,
                               nArticle_QTY    IN stock_content.qty%type, --数量
                               strOutMsg       out varchar2);
  /*更新库存报警冻结标识 */
  procedure proc_up_container_flag;
    /*界面更新库存FLAG标识*/
procedure proc_up_container_flagUI(strEnterPriseNo  in stock_content.enterprise_no%type, -- 企业编号
                                  strWAREHOUSE_NO  in stock_content.WAREHOUSE_NO%type, --仓库编码
                                  strcell_id       in stock_content.cell_id%type, --储位ID
                                  strcell_no       in stock_content.cell_no%type, --储位
                                  strFlag     in stock_content.flag%type, --库存状态：2-冻结；3-解冻
                                  strUser_id       in stock_content.Rgst_Name%type, --操作人员
                                  strOutMsg        out varchar2); --返回 执行结果
end PKOBJ_STOCK;


/

