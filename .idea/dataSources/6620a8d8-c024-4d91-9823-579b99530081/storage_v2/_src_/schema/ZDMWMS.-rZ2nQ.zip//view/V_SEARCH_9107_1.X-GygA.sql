create view V_SEARCH_9107_1 as
select rom.enterprise_no,
       rom.warehouse_no,
       rom.owner_no,
       to_char(rom.operate_date, 'yyyy-mm-dd') operate_date,
       rom.outstock_no,
       rom.operate_type,
       rod.source_no,
       rrm.supplier_no,
       rod.outstock_name,
       rod.status,
       rod.article_no,
       bda.article_name,
       bab.barcode,
       rod.article_qty,
       rod.real_qty,
       rod.s_cell_no,
       rom.rgst_name,
       to_char(rom.rgst_date, 'yyyy-mm-dd') rgst_date,
       to_char(rom.updt_date, 'yyyy-mm-dd') updt_date
  from rodata_outstock_mhty rom
 inner join rodata_outstock_dhty rod
    on rod.outstock_no = rom.outstock_no
    and rod.warehouse_no = rom.warehouse_no
    and rod.enterprise_no = rom.enterprise_no
 inner join rodata_recede_m rrm
    on rod.source_no = rrm.recede_no
    and rod.warehouse_no = rrm.warehouse_no
    and rod.enterprise_no = rrm.enterprise_no
 inner join bdef_defarticle bda
    on rod.article_no = bda.article_no
    and rod.enterprise_no = bda.enterprise_no
 inner join bdef_article_barcode bab
    on rod.packing_qty = bab.packing_qty
   and rod.article_no = bab.article_no
   and rod.enterprise_no = bab.enterprise_no

/

