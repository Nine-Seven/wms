create package body        PKOBJ_BILL_W is
  /***********************************************************************************************
  wyf
  20151208
  功能说明：根据取值策略生成消费清单
  根据计费项目策略产生的清单（固定费用只在结算日期产生）
  ***********************************************************************************************/
  procedure P_EXPENSES_LIST(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                            strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                            strOwnerNo         cost_formulaset.owner_no%type, --货主
                            strBilling_project cost_formulaset.billing_project%type, --计费项目 支持传空值
                            strBillingType     cost_formulaset.billing_type%type, --计费项目类型 支持传空值
                            dtDate             cost_expenses_list.build_date%type, --生成日期
                            strFlag            cost_expenses_list.flag%type, --是否重算，0:代表正常日结生成，1：代表重算
                            strWorkerNo        cost_expenses_list.rgst_name%type,
                            strOutMsg          out varchar2) --返回值
   IS
    v_nRow   integer := 0;
    v_dtDate cost_expenses_list.build_date%type;
  BEGIN
    strOutMsg := 'N|[P_EXPENSES_LIST]';
    --锁计费项目表
    update cost_formulaset a
       set a.status = a.status
     where a.status = '0'
       and nvl(a.END_DATE, sysdate) >= sysdate
       and a.enterprise_no = strEnterpriseNo
       and a.warehouse_no = strWarehouseNo
       and a.owner_no = strOwnerNo
       and (a.billing_project = strBilling_project or
           strBilling_project is null)
       and (a.billing_type = strBillingType or strBillingType is null);

    v_dtDate := dtDate;
    if strFlag = 1 then
      --重算日期取传入日期
      v_dtDate := dtDate;
    else
      --系统自动计算取传入日期的前一天
      v_dtDate := dtDate - 1;
    end if;

    for p in (select a.*
                from cost_formulaset a
               where a.status = '0'
                 and nvl(a.END_DATE, sysdate) >= sysdate
                 and a.enterprise_no = strEnterpriseNo
                 and a.warehouse_no = strWarehouseNo
                 and a.owner_no = strOwnerNo
                 and (a.billing_project = strBilling_project or
                     strBilling_project is null)
                 and (a.billing_type = strBillingType or
                     strBillingType is null)) loop
      v_nRow := v_nRow + 1;
      if p.Billing_Flag = '1' then
        --计算固定费用清单
        P_GCLD_FIXED(strEnterpriseNo, --企业
                     strWarehouseNo, --仓别
                     strOwnerNo, --货主
                     p.billing_project, --计费项目
                     p.billing_type, --计费项目类型
                     v_dtDate, --开始日期
                     strFlag, --0:代表正常日结生成，1：代表重算
                     strWorkerNo,
                     strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
      else
        --计算动态费用清单
        P_GCLD_DYNAMIC(strEnterpriseNo, --企业
                       strWarehouseNo, --仓别
                       strOwnerNo, --货主
                       p.billing_project, --计费项目
                       p.billing_type, --计费项目类型
                       v_dtDate, --开始日期
                       strFlag, --0:代表正常日结生成，1：代表重算
                       strWorkerNo,
                       strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
      end if;
    end loop;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_EXPENSES_LIST;

  /***********************************************************************************************
  wyf
  20151208
  功能说明：根据取值策略生成固定费用类型的消费清单
  ***********************************************************************************************/
  procedure P_GCLD_FIXED(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                         strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                         strOwnerNo         cost_formulaset.owner_no%type, --货主
                         strBilling_project cost_formulaset.billing_project%type, --计费项目
                         strBillingType     cost_formulaset.billing_type%type, --计费项目类型
                         dtDate             cost_expenses_list.build_date%type, --产生日期
                         strFlag            cost_expenses_list.flag%type, --0:代表正常日结生成，1：代表重算
                         strWorkerNo        cost_expenses_list.rgst_name%type,
                         strOutMsg          out varchar2) --返回值
   IS
    v_nRow     integer := 0;
    v_nCount   integer := 0;
    v_nDay     integer := 1;
    v_nLastDay integer := 0;
    v_dtDate   cost_expenses_list.build_date%type;
  BEGIN
    strOutMsg := 'N|[P_GCLD_FIXED]';
    for p in (select *
                from cost_formulaset a
               where a.enterprise_no = strEnterpriseNo
                 and a.warehouse_no = strWarehouseNo
                 and a.owner_no = strOwnerNo
                 and a.billing_project = strBilling_project
                 and a.billing_type = strBillingType) loop
      v_nRow := v_nRow + 1;
      --计费周期策略
      if p.billing_cycle = '1' then
        --按天
        v_dtDate := dtDate;
      elsif p.billing_cycle = '2' then
        --按周 获取传入日期是周几
        select to_char(dtDate, 'd') into v_nDay from dual;
        if p.balance_day is null then
          --未维护结算日 则默认周天为结算日
          if v_nDay = '1' then
            v_dtDate := dtDate;
          else
            goto nextOne;
          end if;
        else
          --有维护结算日，则比较传入日期是否为结算日
          if v_nDay = p.balance_day then
            v_dtDate := dtDate;
          else
            goto nextOne;
          end if;
        end if;
      elsif p.billing_cycle = '3' then
        --按月 获取传入日期是几号
        select to_char(dtDate, 'dd') into v_nDay from dual;
        --获取传入日期所在月份的最后一天
        select to_char(last_day(dtDate), 'dd') into v_nLastDay from dual;
        if p.balance_day is null then
          --未维护结算日，则默认每月的最后一天为结算日
          if v_nDay = v_nLastDay then
            v_dtDate := dtDate;
          else
            goto nextOne;
          end if;
        else
          --有维护结算日，则比较传入日期是否为结算日
          --若结算日大于传入日期所在月的最后一天，则判断传入日期是否为所在月份的最后一天
          if v_nDay = p.balance_day or
             (p.balance_day > v_nLastDay and v_nDay = v_nLastDay) then
            v_dtDate := dtDate;
          else
            goto nextOne;
          end if;
        end if;
      else
        goto nextOne;
      end if;

      select count(1)
        into v_nCount
        from cost_expenses_list t
       where t.enterprise_no = p.enterprise_no
         and t.warehouse_no = p.warehouse_no
         and t.owner_no = p.owner_no
         and t.billing_project = p.billing_project
         and t.billing_type = p.billing_type
         and trunc(t.build_date) = trunc(dtDate)
         and t.serial_no = 'N'
         and t.status = '10';
      if v_nCount > 0 then
        if strFlag = '1' then
          --重算
          --删除已存在的清单
          delete from cost_expenses_list t
           where t.enterprise_no = p.enterprise_no
             and t.warehouse_no = p.warehouse_no
             and t.owner_no = p.owner_no
             and t.billing_project = p.billing_project
             and t.billing_type = p.billing_type
             and t.build_date = dtDate
             and t.serial_no = 'N'
             and t.status = '10';
        end if;
      end if;

      --消费清单表
      P_INSERT_EXPENSES_LIST(p.enterprise_no,
                             p.warehouse_no,
                             p.owner_no,
                             p.billing_project,
                             p.billing_type,
                             null,
                             'N',
                             trunc(dtDate),
                             'N',
                             p.fixed_value,
                             0,
                             0,
                             strFlag,
                             strWorkerNo,
                             strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
      <<nextOne>>
      null;
    END LOOP;
    if v_nRow = 0 then
      strOutMsg := 'N|[设费项目设置错误，请核实!]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_GCLD_FIXED;

  /***********************************************************************************************
  wyf
  20151208
  功能说明：根据取值策略生成动态费用类型的消费清单
  ***********************************************************************************************/
  procedure P_GCLD_DYNAMIC(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                           strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                           strOwnerNo         cost_formulaset.owner_no%type, --货主
                           strBilling_project cost_formulaset.billing_project%type, --计费项目
                           strBillingType     cost_formulaset.billing_type%type, --计费项目类型
                           dtDate             cost_expenses_list.build_date%type, --生成日期
                           strFlag            cost_expenses_list.flag%type, --是否重算，0:代表正常日结生成，1：代表重算
                           strWorkerNo        cost_expenses_list.rgst_name%type,
                           strOutMsg          out varchar2) --返回值
   IS
    intCount integer := 0;
    v_nCount integer := 0;
  BEGIN
    strOutMsg := 'N|[P_GCLD_DYNAMIC]';
    for p in (select a.*
                from cost_formulaset a
               where a.enterprise_no = strEnterpriseNo
                 and a.warehouse_no = strWarehouseNo
                 and a.owner_no = strOwnerNo
                 and a.billing_project = strBilling_project
                 and a.billing_type = strBillingType) loop
      intCount := intCount + 1;
      select count(1)
        into v_nCount
        from cost_expenses_list t
       where t.enterprise_no = p.enterprise_no
         and t.warehouse_no = p.warehouse_no
         and t.owner_no = p.owner_no
         and t.billing_project = p.billing_project
         and t.billing_type = p.billing_type
         and trunc(t.build_date) = trunc(dtDate)
         and t.serial_no = 'N'
         and t.status = '10';
      if v_nCount > 0 then
        if strFlag = '1' then
          --重算
          --删除已存在的清单
          delete from cost_expenses_list t
           where t.enterprise_no = p.enterprise_no
             and t.warehouse_no = p.warehouse_no
             and t.owner_no = p.owner_no
             and t.billing_project = p.billing_project
             and t.billing_type = p.billing_type
             and t.build_date = dtDate
             and t.serial_no = 'N'
             and t.status = '10';
        end if;
      end if;

      --原有：LO:装卸;IC:验收;IN:上架;HO:拣货;PA:打包;AR:整理；RIC:验收;RIN:上架;RO:退货;MV:移库；FC:盘点
      --已实现：IC:验收，IN:上架，HO:拣货，RD:理货（分播），RIC:返配验收，LO:装车，ALL:仓租，WH:仓储费
      if strBillingType = 'IC' then
        --验收
        P_IC(strEnterpriseNo,
             strWarehouseNo,
             strOwnerNo,
             p.billing_project,
             p.billing_type,
             dtDate,
             strFlag,
             strWorkerNo,
             strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
      elsif strBillingType = 'IN' then
        --上架
        P_IN(strEnterpriseNo,
             strWarehouseNo,
             strOwnerNo,
             p.billing_project,
             p.billing_type,
             dtDate,
             strFlag,
             strWorkerNo,
             strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;

      elsif strBillingType = 'HO' then
        --拣货
        P_HO(strEnterpriseNo,
             strWarehouseNo,
             strOwnerNo,
             p.billing_project,
             p.billing_type,
             dtDate,
             strFlag,
             strWorkerNo,
             strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
      elsif strBillingType = 'RD' then
        --理货（分播）
        P_RD(strEnterpriseNo,
             strWarehouseNo,
             strOwnerNo,
             p.billing_project,
             p.billing_type,
             dtDate,
             strFlag,
             strWorkerNo,
             strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;

      elsif strBillingType = 'RIC' then
        --返配验收
        P_RIC(strEnterpriseNo,
              strWarehouseNo,
              strOwnerNo,
              p.billing_project,
              p.billing_type,
              dtDate,
              strFlag,
              strWorkerNo,
              strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;

      elsif strBillingType = 'LO' then
        --装卸
        if p.value_flag = '1' then
          --验收
          P_IC(strEnterpriseNo,
               strWarehouseNo,
               strOwnerNo,
               p.billing_project,
               p.billing_type,
               dtDate,
               strFlag,
               strWorkerNo,
               strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        elsif p.value_flag = '2' then
          --装车
          P_LO(strEnterpriseNo,
               strWarehouseNo,
               strOwnerNo,
               p.billing_project,
               p.billing_type,
               dtDate,
               strFlag,
               strWorkerNo,
               strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        end if;
      elsif strBillingType = 'ALL' then
        --仓租无动态费用
        /*P_WH(strEnterpriseNo,
                    strWarehouseNo,
                    strOwnerNo,
                    p.billing_project,
                    p.billing_type,
                    dtDate,
                    strFlag,strWorkerNo,
                    strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;*/
        goto nextOne;
      elsif strBillingType = 'WH' then
        if p.value_flag = '1' then
          --仓储费（含当天入库）
          P_WH(strEnterpriseNo,
               strWarehouseNo,
               strOwnerNo,
               p.billing_project,
               p.billing_type,
               dtDate,
               strFlag,
               strWorkerNo,
               strOutMsg);
        elsif p.value_flag = '2' then
          --仓储费（不含当天入库）
          P_WH_WITHIN(strEnterpriseNo,
                      strWarehouseNo,
                      strOwnerNo,
                      p.billing_project,
                      p.billing_type,
                      dtDate,
                      strFlag,
                      strWorkerNo,
                      strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        end if;
      end if;

      <<nextOne>>
      null;
    end loop;
    if intCount = 0 then
      strOutMsg := 'N|[设费项目设置错误，请核实!]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_GCLD_DYNAMIC;

  /***********************************************************************************************
  wyf
  20151208
  功能说明：获取验收相关消费数据
  ***********************************************************************************************/
  procedure P_IC(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                 strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                 strOwnerNo         cost_formulaset.owner_no%type, --货主
                 strBilling_project cost_formulaset.billing_project%type, --计费项目
                 strBillingType     cost_formulaset.billing_type%type, --计费项目类型
                 dtDate             cost_expenses_list.build_date%type, --生成日期
                 strFlag            cost_expenses_list.flag%type, --是否重算，0:代表正常日结生成，1：代表重算
                 strWorkerNo        cost_expenses_list.rgst_name%type,
                 strOutMsg          out varchar2) --返回值
   IS
    v_nQty    cost_expenses_list.qty%type; --数量
    v_nVolume cost_expenses_list.volume%type; --体积
    v_nWeight cost_expenses_list.weight%type; --重量
  BEGIN
    strOutMsg := 'N|[P_IC]';
    for p in (select a.*
                from cost_formulaset a
               where a.enterprise_no = strEnterpriseNo
                 and a.warehouse_no = strWarehouseNo
                 and a.owner_no = strOwnerNo
                 and a.billing_project = strBilling_project
                 and a.billing_type = strBillingType) loop
      --是否为标准策咯：0：否；1：是
      if p.STANDARD_FLAG = '1' then
        for list in (select a.check_no source_no,
                            nvl(sum(ceil(b.check_qty / b.packing_qty)), 0) AS QTY,
                            nvl(sum(ceil(b.check_qty / b.packing_qty) *
                                    c.packing_weight),
                                0) AS WEIGHT,
                            nvl(sum(ceil(b.check_qty / b.packing_qty) *
                                    c.packing_volumn),
                                0) AS VOLUME
                       from idata_check_m                a,
                            idata_check_d                b,
                            v_article_pack_volumn_weight c
                      where a.check_no = b.check_no
                        and a.enterprise_no = b.enterprise_no
                        and a.warehouse_no = b.warehouse_no
                        and a.owner_no = b.owner_no
                        and b.enterprise_no = c.enterprise_no
                        and b.owner_no = c.owner_no
                        and b.article_no = c.article_no
                        and b.packing_qty = c.packing_qty
                        and a.enterprise_no = strEnterpriseNo
                        and a.warehouse_no = strWarehouseNo
                        and a.owner_no = strOwnerNo
                        and trunc(a.check_end_date) = trunc(dtDate)
                        and a.status = '13'
                        and not exists
                      (select 1
                               from bdef_article_family_d      baf,
                                    cost_formula_articlefamily cfa
                              where b.enterprise_no = baf.enterprise_no
                                and b.owner_no = baf.owner_no
                                and b.article_no = baf.article_no
                                and baf.enterprise_no = cfa.enterprise_no
                                and baf.owner_no = cfa.owner_no
                                and b.warehouse_no = cfa.warehouse_no
                                and baf.FAMILY_NO = cfa.FAMILY_NO
                                and cfa.BILLING_TYPE = p.billing_type
                                and cfa.billing_project = p.billing_project)
                      group by a.check_no
                      order by a.check_no) loop

          /*新增费用明细*/
          P_INSERT_EXPENSES_LIST(p.enterprise_no,
                                 p.warehouse_no,
                                 p.owner_no,
                                 p.billing_project,
                                 p.billing_type,
                                 p.billing_unit,
                                 'N',
                                 dtDate,
                                 list.source_no,
                                 v_nQty,
                                 v_nWeight,
                                 v_nVolume,
                                 strFlag,
                                 strWorkerNo,
                                 strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        end loop;
      else
        for list in (select a.check_no source_no,
                            cfa.FAMILY_NO,
                            nvl(sum(ceil(b.check_qty / b.packing_qty)), 0) AS QTY,
                            nvl(sum(ceil(b.check_qty / b.packing_qty) *
                                    c.packing_weight),
                                0) AS WEIGHT,
                            nvl(sum(ceil(b.check_qty / b.packing_qty) *
                                    c.packing_volumn),
                                0) AS VOLUME
                       from idata_check_m                a,
                            idata_check_d                b,
                            v_article_pack_volumn_weight c,
                            bdef_article_family_d        baf,
                            cost_formula_articlefamily   cfa
                      where a.check_no = b.check_no
                        and a.enterprise_no = b.enterprise_no
                        and a.warehouse_no = b.warehouse_no
                        and a.owner_no = b.owner_no
                        and b.enterprise_no = c.enterprise_no
                        and b.owner_no = c.owner_no
                        and b.article_no = c.article_no
                        and b.packing_qty = c.packing_qty
                        and b.enterprise_no = baf.enterprise_no
                        and b.owner_no = baf.owner_no
                        and b.article_no = baf.article_no

                        and baf.enterprise_no = cfa.enterprise_no
                        and b.warehouse_no = cfa.warehouse_no
                        and baf.owner_no = cfa.owner_no
                        and baf.FAMILY_NO = cfa.FAMILY_NO
                        and cfa.BILLING_TYPE = p.billing_type
                        and cfa.billing_project = p.billing_project

                        and a.enterprise_no = strEnterpriseNo
                        and a.warehouse_no = strWarehouseNo
                        and a.owner_no = strOwnerNo
                        and trunc(a.check_end_date) = trunc(dtDate)
                        and a.status = '13'
                      group by a.check_no, cfa.FAMILY_NO
                      order by a.check_no, cfa.FAMILY_NO) loop

          /*新增费用明细*/
          P_INSERT_EXPENSES_LIST(p.enterprise_no,
                                 p.warehouse_no,
                                 p.owner_no,
                                 p.billing_project,
                                 p.billing_type,
                                 p.billing_unit,
                                 list.FAMILY_NO,
                                 dtDate,
                                 list.source_no,
                                 v_nQty,
                                 v_nWeight,
                                 v_nVolume,
                                 strFlag,
                                 strWorkerNo,
                                 strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        end loop;

      end if;

    end loop;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_IC;

  /***********************************************************************************************
  wyf
  20151208
  功能说明：获取上架相关消费数据
  ***********************************************************************************************/
  procedure P_IN(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                 strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                 strOwnerNo         cost_formulaset.owner_no%type, --货主
                 strBilling_project cost_formulaset.billing_project%type, --计费项目
                 strBillingType     cost_formulaset.billing_type%type, --计费项目类型
                 dtDate             cost_expenses_list.build_date%type, --生成日期
                 strFlag            cost_expenses_list.flag%type, --是否重算，0:代表正常日结生成，1：代表重算
                 strWorkerNo        cost_expenses_list.rgst_name%type,
                 strOutMsg          out varchar2) --返回值
   IS
    v_nQty    cost_expenses_list.qty%type; --数量
    v_nVolume cost_expenses_list.volume%type; --体积
    v_nWeight cost_expenses_list.weight%type; --重量
  BEGIN
    strOutMsg := 'N|[P_IN]';

    for p in (select a.*
                from cost_formulaset a
               where a.enterprise_no = strEnterpriseNo
                 and a.warehouse_no = strWarehouseNo
                 and a.owner_no = strOwnerNo
                 and a.billing_project = strBilling_project
                 and a.billing_type = strBillingType) loop
      --是否为标准策咯：0：否；1：是
      if p.STANDARD_FLAG = '1' then
        for list in (select a.instock_no source_no,
                            nvl(sum(ceil(b.real_qty / b.packing_qty)), 0) AS QTY,
                            nvl(sum(ceil(b.real_qty / b.packing_qty) *
                                    c.packing_weight),
                                0) AS WEIGHT,
                            nvl(sum(ceil(b.real_qty / b.packing_qty) *
                                    c.packing_volumn),
                                0) AS VOLUME
                       from idata_instock_mhty           a,
                            idata_instock_dhty           b,
                            v_article_pack_volumn_weight c
                      where a.instock_no = b.instock_no
                        and a.enterprise_no = b.enterprise_no
                        and a.warehouse_no = b.warehouse_no
                        and a.owner_no = b.owner_no
                        and b.enterprise_no = c.enterprise_no
                        and b.owner_no = c.owner_no
                        and b.article_no = c.article_no
                        and b.packing_qty = c.packing_qty
                        and a.enterprise_no = strEnterpriseNo
                        and a.warehouse_no = strWarehouseNo
                        and a.owner_no = strOwnerNo
                        and trunc(a.instock_date) = trunc(dtDate)
                        and a.status = '13'
                        and not exists
                      (select 1
                               from bdef_article_family_d      baf,
                                    cost_formula_articlefamily cfa
                              where b.enterprise_no = baf.enterprise_no
                                and b.owner_no = baf.owner_no
                                and b.article_no = baf.article_no
                                and baf.enterprise_no = cfa.enterprise_no
                                and baf.owner_no = cfa.owner_no
                                and b.warehouse_no = cfa.warehouse_no
                                and baf.FAMILY_NO = cfa.FAMILY_NO
                                and cfa.BILLING_TYPE = p.billing_type
                                and cfa.billing_project = p.billing_project)
                      group by a.instock_no
                      order by a.instock_no) loop

          /*新增费用明细*/
          P_INSERT_EXPENSES_LIST(p.enterprise_no,
                                 p.warehouse_no,
                                 p.owner_no,
                                 p.billing_project,
                                 p.billing_type,
                                 p.billing_unit,
                                 'N',
                                 dtDate,
                                 list.source_no,
                                 v_nQty,
                                 v_nWeight,
                                 v_nVolume,
                                 strFlag,
                                 strWorkerNo,
                                 strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        end loop;
      else
        for list in (select a.instock_no source_no,
                            cfa.FAMILY_NO,
                            nvl(sum(ceil(b.real_qty / b.packing_qty)), 0) AS QTY,
                            nvl(sum(ceil(b.real_qty / b.packing_qty) *
                                    c.packing_weight),
                                0) AS WEIGHT,
                            nvl(sum(ceil(b.real_qty / b.packing_qty) *
                                    c.packing_volumn),
                                0) AS VOLUME
                       from idata_instock_mhty           a,
                            idata_instock_dhty           b,
                            v_article_pack_volumn_weight c,
                            bdef_article_family_d        baf,
                            cost_formula_articlefamily   cfa
                      where a.instock_no = b.instock_no
                        and a.enterprise_no = b.enterprise_no
                        and a.warehouse_no = b.warehouse_no
                        and a.owner_no = b.owner_no
                        and b.enterprise_no = c.enterprise_no
                        and b.owner_no = c.owner_no
                        and b.article_no = c.article_no
                        and b.packing_qty = c.packing_qty
                        and b.enterprise_no = baf.enterprise_no
                        and b.owner_no = baf.owner_no
                        and b.article_no = baf.article_no

                        and baf.enterprise_no = cfa.enterprise_no
                        and b.warehouse_no = cfa.warehouse_no
                        and baf.owner_no = cfa.owner_no
                        and baf.FAMILY_NO = cfa.FAMILY_NO
                        and cfa.BILLING_TYPE = p.billing_type
                        and cfa.billing_project = p.billing_project
                        and a.enterprise_no = strEnterpriseNo
                        and a.warehouse_no = strWarehouseNo
                        and a.owner_no = strOwnerNo
                        and trunc(a.instock_date) = trunc(dtDate)
                        and a.status = '13'

                      group by a.instock_no, cfa.FAMILY_NO
                      order by a.instock_no, cfa.FAMILY_NO) loop

          /*新增费用明细*/
          P_INSERT_EXPENSES_LIST(p.enterprise_no,
                                 p.warehouse_no,
                                 p.owner_no,
                                 p.billing_project,
                                 p.billing_type,
                                 p.billing_unit,
                                 list.FAMILY_NO,
                                 dtDate,
                                 list.source_no,
                                 v_nQty,
                                 v_nWeight,
                                 v_nVolume,
                                 strFlag,
                                 strWorkerNo,
                                 strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        end loop;

      end if;

    end loop;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_IN;

  /***********************************************************************************************
  wyf
  20151208
  功能说明：获取拣货相关消费数据
  ***********************************************************************************************/
  procedure P_HO(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                 strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                 strOwnerNo         cost_formulaset.owner_no%type, --货主
                 strBilling_project cost_formulaset.billing_project%type, --计费项目
                 strBillingType     cost_formulaset.billing_type%type, --计费项目类型
                 dtDate             cost_expenses_list.build_date%type, --生成日期
                 strFlag            cost_expenses_list.flag%type, --是否重算，0:代表正常日结生成，1：代表重算
                 strWorkerNo        cost_expenses_list.rgst_name%type,
                 strOutMsg          out varchar2) --返回值
   IS
    v_nQty    cost_expenses_list.qty%type; --数量
    v_nVolume cost_expenses_list.volume%type; --体积
    v_nWeight cost_expenses_list.weight%type; --重量
  BEGIN
    strOutMsg := 'N|[P_HO]';
    for p in (select a.*
                from cost_formulaset a
               where a.enterprise_no = strEnterpriseNo
                 and a.warehouse_no = strWarehouseNo
                 and a.owner_no = strOwnerNo
                 and a.billing_project = strBilling_project
                 and a.billing_type = strBillingType) loop
      --是否为标准策咯：0：否；1：是
      if p.STANDARD_FLAG = '1' then
        for list in (select a.outstock_no source_no,
                            nvl(sum(ceil(b.real_qty / b.packing_qty)), 0) AS QTY,
                            nvl(sum(ceil(b.real_qty / b.packing_qty) *
                                    c.packing_weight),
                                0) AS WEIGHT,
                            nvl(sum(ceil(b.real_qty / b.packing_qty) *
                                    c.packing_volumn),
                                0) AS VOLUME
                       from odata_outstock_mhty          a,
                            odata_outstock_dhty          b,
                            v_article_pack_volumn_weight c
                      where a.outstock_no = b.outstock_no
                        and a.enterprise_no = b.enterprise_no
                        and a.warehouse_no = b.warehouse_no
                        and a.outstock_type = '0'
                        and a.owner_no = b.owner_no
                        and b.enterprise_no = c.enterprise_no
                        and b.owner_no = c.owner_no
                        and b.article_no = c.article_no
                        and b.packing_qty = c.packing_qty
                        and a.enterprise_no = strEnterpriseNo
                        and a.warehouse_no = strWarehouseNo
                        and a.owner_no = strOwnerNo
                        and trunc(a.operate_date) = trunc(dtDate)
                        and a.status = '13'
                        and not exists
                      (select 1
                               from bdef_article_family_d      baf,
                                    cost_formula_articlefamily cfa
                              where b.enterprise_no = baf.enterprise_no
                                and b.owner_no = baf.owner_no
                                and b.article_no = baf.article_no
                                and baf.enterprise_no = cfa.enterprise_no
                                and baf.owner_no = cfa.owner_no
                                and b.warehouse_no = cfa.warehouse_no
                                and baf.FAMILY_NO = cfa.FAMILY_NO
                                and cfa.BILLING_TYPE = p.billing_type
                                and cfa.billing_project = p.billing_project)
                      group by a.outstock_no
                      order by a.outstock_no) loop
          /*新增费用明细*/
          P_INSERT_EXPENSES_LIST(p.enterprise_no,
                                 p.warehouse_no,
                                 p.owner_no,
                                 p.billing_project,
                                 p.billing_type,
                                 p.billing_unit,
                                 'N',
                                 dtDate,
                                 list.source_no,
                                 v_nQty,
                                 v_nWeight,
                                 v_nVolume,
                                 strFlag,
                                 strWorkerNo,
                                 strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        end loop;
      else
        for list in (select a.outstock_no source_no,
                            cfa.FAMILY_NO,
                            nvl(sum(ceil(b.real_qty / b.packing_qty)), 0) AS QTY,
                            nvl(sum(ceil(b.real_qty / b.packing_qty) *
                                    c.packing_weight),
                                0) AS WEIGHT,
                            nvl(sum(ceil(b.real_qty / b.packing_qty) *
                                    c.packing_volumn),
                                0) AS VOLUME
                       from odata_outstock_mhty          a,
                            odata_outstock_dhty          b,
                            v_article_pack_volumn_weight c,
                            bdef_article_family_d        baf,
                            cost_formula_articlefamily   cfa
                      where a.outstock_no = b.outstock_no
                        and a.enterprise_no = b.enterprise_no
                        and a.warehouse_no = b.warehouse_no
                        and a.outstock_type = '0'
                        and a.owner_no = b.owner_no
                        and b.enterprise_no = c.enterprise_no
                        and b.owner_no = c.owner_no
                        and b.article_no = c.article_no
                        and b.packing_qty = c.packing_qty
                        and b.enterprise_no = baf.enterprise_no
                        and b.owner_no = baf.owner_no
                        and b.article_no = baf.article_no

                        and baf.enterprise_no = cfa.enterprise_no
                        and b.warehouse_no = cfa.warehouse_no
                        and baf.owner_no = cfa.owner_no
                        and baf.FAMILY_NO = cfa.FAMILY_NO
                        and cfa.BILLING_TYPE = p.billing_type
                        and cfa.billing_project = p.billing_project
                        and a.enterprise_no = strEnterpriseNo
                        and a.warehouse_no = strWarehouseNo
                        and a.owner_no = strOwnerNo
                        and trunc(a.operate_date) = trunc(dtDate)
                        and a.status = '13'

                      group by a.outstock_no, cfa.FAMILY_NO
                      order by a.outstock_no, cfa.FAMILY_NO) loop

          /*新增费用明细*/
          P_INSERT_EXPENSES_LIST(p.enterprise_no,
                                 p.warehouse_no,
                                 p.owner_no,
                                 p.billing_project,
                                 p.billing_type,
                                 p.billing_unit,
                                 list.FAMILY_NO,
                                 dtDate,
                                 list.source_no,
                                 v_nQty,
                                 v_nWeight,
                                 v_nVolume,
                                 strFlag,
                                 strWorkerNo,
                                 strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        end loop;

      end if;

    end loop;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_HO;
  /***********************************************************************************************
  wyf
  20151208
  功能说明：获取理货（分播）相关消费数据
  ***********************************************************************************************/
  procedure P_RD(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                 strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                 strOwnerNo         cost_formulaset.owner_no%type, --货主
                 strBilling_project cost_formulaset.billing_project%type, --计费项目
                 strBillingType     cost_formulaset.billing_type%type, --计费项目类型
                 dtDate             cost_expenses_list.build_date%type, --生成日期
                 strFlag            cost_expenses_list.flag%type, --是否重算，0:代表正常日结生成，1：代表重算
                 strWorkerNo        cost_expenses_list.rgst_name%type,
                 strOutMsg          out varchar2) --返回值
   IS
    v_nQty    cost_expenses_list.qty%type; --数量
    v_nVolume cost_expenses_list.volume%type; --体积
    v_nWeight cost_expenses_list.weight%type; --重量
  BEGIN
    strOutMsg := 'N|[P_HO]';
    for p in (select a.*
                from cost_formulaset a
               where a.enterprise_no = strEnterpriseNo
                 and a.warehouse_no = strWarehouseNo
                 and a.owner_no = strOwnerNo
                 and a.billing_project = strBilling_project
                 and a.billing_type = strBillingType) loop
      --是否为标准策咯：0：否；1：是
      if p.STANDARD_FLAG = '1' then
        for list in (select a.divide_no source_no,
                            nvl(sum(ceil(b.real_qty / b.packing_qty)), 0) AS QTY,
                            nvl(sum(ceil(b.real_qty / b.packing_qty) *
                                    c.packing_weight),
                                0) AS WEIGHT,
                            nvl(sum(ceil(b.real_qty / b.packing_qty) *
                                    c.packing_volumn),
                                0) AS VOLUME
                       from odata_divide_mhty            a,
                            odata_divide_dhty            b,
                            v_article_pack_volumn_weight c
                      where a.divide_no = b.divide_no
                        and a.enterprise_no = b.enterprise_no
                        and a.warehouse_no = b.warehouse_no
                        and a.owner_no = b.owner_no
                        and b.enterprise_no = c.enterprise_no
                        and b.owner_no = c.owner_no
                        and b.article_no = c.article_no
                        and b.packing_qty = c.packing_qty
                        and a.enterprise_no = strEnterpriseNo
                        and a.warehouse_no = strWarehouseNo
                        and a.owner_no = strOwnerNo
                        and trunc(a.operate_date) = trunc(dtDate)
                        and a.status = '13'
                        and not exists
                      (select 1
                               from bdef_article_family_d      baf,
                                    cost_formula_articlefamily cfa
                              where b.enterprise_no = baf.enterprise_no
                                and b.owner_no = baf.owner_no
                                and b.article_no = baf.article_no
                                and baf.enterprise_no = cfa.enterprise_no
                                and baf.owner_no = cfa.owner_no
                                and b.warehouse_no = cfa.warehouse_no
                                and baf.FAMILY_NO = cfa.FAMILY_NO
                                and cfa.BILLING_TYPE = p.billing_type
                                and cfa.billing_project = p.billing_project)
                      group by a.divide_no
                      order by a.divide_no) loop

          /*新增费用明细*/
          P_INSERT_EXPENSES_LIST(p.enterprise_no,
                                 p.warehouse_no,
                                 p.owner_no,
                                 p.billing_project,
                                 p.billing_type,
                                 p.billing_unit,
                                 'N',
                                 dtDate,
                                 list.source_no,
                                 v_nQty,
                                 v_nWeight,
                                 v_nVolume,
                                 strFlag,
                                 strWorkerNo,
                                 strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        end loop;
      else
        for list in (select a.divide_no source_no,
                            cfa.FAMILY_NO,
                            nvl(sum(ceil(b.real_qty / b.packing_qty)), 0) AS QTY,
                            nvl(sum(ceil(b.real_qty / b.packing_qty) *
                                    c.packing_weight),
                                0) AS WEIGHT,
                            nvl(sum(ceil(b.real_qty / b.packing_qty) *
                                    c.packing_volumn),
                                0) AS VOLUME
                       from odata_divide_mhty            a,
                            odata_divide_dhty            b,
                            v_article_pack_volumn_weight c,
                            bdef_article_family_d        baf,
                            cost_formula_articlefamily   cfa
                      where a.divide_no = b.divide_no
                        and a.enterprise_no = b.enterprise_no
                        and a.warehouse_no = b.warehouse_no
                        and a.owner_no = b.owner_no
                        and b.enterprise_no = c.enterprise_no
                        and b.owner_no = c.owner_no
                        and b.article_no = c.article_no
                        and b.packing_qty = c.packing_qty
                        and b.enterprise_no = baf.enterprise_no
                        and b.owner_no = baf.owner_no
                        and b.article_no = baf.article_no

                        and baf.enterprise_no = cfa.enterprise_no
                        and b.warehouse_no = cfa.warehouse_no
                        and baf.owner_no = cfa.owner_no
                        and baf.FAMILY_NO = cfa.FAMILY_NO
                        and cfa.BILLING_TYPE = p.billing_type
                        and cfa.billing_project = p.billing_project
                        and a.enterprise_no = strEnterpriseNo
                        and a.warehouse_no = strWarehouseNo
                        and a.owner_no = strOwnerNo
                        and trunc(a.operate_date) = trunc(dtDate)
                        and a.status = '13'

                      group by a.divide_no, cfa.FAMILY_NO
                      order by a.divide_no, cfa.FAMILY_NO) loop

          /*新增费用明细*/
          P_INSERT_EXPENSES_LIST(p.enterprise_no,
                                 p.warehouse_no,
                                 p.owner_no,
                                 p.billing_project,
                                 p.billing_type,
                                 p.billing_unit,
                                 list.FAMILY_NO,
                                 dtDate,
                                 list.source_no,
                                 v_nQty,
                                 v_nWeight,
                                 v_nVolume,
                                 strFlag,
                                 strWorkerNo,
                                 strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        end loop;

      end if;

    end loop;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_RD;
  /***********************************************************************************************
  wyf
  20151208
  功能说明：获取返配验收相关消费数据
  ***********************************************************************************************/
  procedure P_RIC(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                  strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                  strOwnerNo         cost_formulaset.owner_no%type, --货主
                  strBilling_project cost_formulaset.billing_project%type, --计费项目
                  strBillingType     cost_formulaset.billing_type%type, --计费项目类型
                  dtDate             cost_expenses_list.build_date%type, --生成日期
                  strFlag            cost_expenses_list.flag%type, --是否重算，0:代表正常日结生成，1：代表重算
                  strWorkerNo        cost_expenses_list.rgst_name%type,
                  strOutMsg          out varchar2) --返回值
   IS
    v_nQty    cost_expenses_list.qty%type; --数量
    v_nVolume cost_expenses_list.volume%type; --体积
    v_nWeight cost_expenses_list.weight%type; --重量
  BEGIN
    strOutMsg := 'N|[P_RIC]';
    for p in (select a.*
                from cost_formulaset a
               where a.enterprise_no = strEnterpriseNo
                 and a.warehouse_no = strWarehouseNo
                 and a.owner_no = strOwnerNo
                 and a.billing_project = strBilling_project
                 and a.billing_type = strBillingType) loop
      --是否为标准策咯：0：否；1：是
      if p.STANDARD_FLAG = '1' then
        for list in (select a.check_no source_no,
                            nvl(sum(ceil(b.check_qty / b.packing_qty)), 0) AS QTY,
                            nvl(sum(ceil(b.check_qty / b.packing_qty) *
                                    c.packing_weight),
                                0) AS WEIGHT,
                            nvl(sum(ceil(b.check_qty / b.packing_qty) *
                                    c.packing_volumn),
                                0) AS VOLUME
                       from ridata_check_m               a,
                            ridata_check_d               b,
                            v_article_pack_volumn_weight c
                      where a.check_no = b.check_no
                        and a.enterprise_no = b.enterprise_no
                        and a.warehouse_no = b.warehouse_no
                        and a.owner_no = b.owner_no
                        and b.enterprise_no = c.enterprise_no
                        and b.owner_no = c.owner_no
                        and b.article_no = c.article_no
                        and b.packing_qty = c.packing_qty
                        and a.enterprise_no = strEnterpriseNo
                        and a.warehouse_no = strWarehouseNo
                        and a.owner_no = strOwnerNo
                        and trunc(a.check_end_date) = trunc(dtDate)
                        and a.status = '13'
                        and not exists
                      (select 1
                               from bdef_article_family_d      baf,
                                    cost_formula_articlefamily cfa
                              where b.enterprise_no = baf.enterprise_no
                                and b.owner_no = baf.owner_no
                                and b.article_no = baf.article_no
                                and baf.enterprise_no = cfa.enterprise_no
                                and baf.owner_no = cfa.owner_no
                                and b.warehouse_no = cfa.warehouse_no
                                and baf.FAMILY_NO = cfa.FAMILY_NO
                                and cfa.BILLING_TYPE = p.billing_type
                                and cfa.billing_project = p.billing_project)
                      group by a.check_no
                      order by a.check_no) loop

          /*新增费用明细*/
          P_INSERT_EXPENSES_LIST(p.enterprise_no,
                                 p.warehouse_no,
                                 p.owner_no,
                                 p.billing_project,
                                 p.billing_type,
                                 p.billing_unit,
                                 'N',
                                 dtDate,
                                 list.source_no,
                                 v_nQty,
                                 v_nWeight,
                                 v_nVolume,
                                 strFlag,
                                 strWorkerNo,
                                 strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        end loop;
      else
        for list in (select a.check_no source_no,
                            cfa.FAMILY_NO,
                            nvl(sum(ceil(b.check_qty / b.packing_qty)), 0) AS QTY,
                            nvl(sum(ceil(b.check_qty / b.packing_qty) *
                                    c.packing_weight),
                                0) AS WEIGHT,
                            nvl(sum(ceil(b.check_qty / b.packing_qty) *
                                    c.packing_volumn),
                                0) AS VOLUME
                       from ridata_check_m               a,
                            ridata_check_d               b,
                            v_article_pack_volumn_weight c,
                            bdef_article_family_d        baf,
                            cost_formula_articlefamily   cfa
                      where a.check_no = b.check_no
                        and a.enterprise_no = b.enterprise_no
                        and a.warehouse_no = b.warehouse_no
                        and a.owner_no = b.owner_no
                        and b.enterprise_no = c.enterprise_no
                        and b.owner_no = c.owner_no
                        and b.article_no = c.article_no
                        and b.packing_qty = c.packing_qty
                        and b.enterprise_no = baf.enterprise_no
                        and b.owner_no = baf.owner_no
                        and b.article_no = baf.article_no

                        and baf.enterprise_no = cfa.enterprise_no
                        and b.warehouse_no = cfa.warehouse_no
                        and baf.owner_no = cfa.owner_no
                        and baf.FAMILY_NO = cfa.FAMILY_NO
                        and cfa.BILLING_TYPE = p.billing_type
                        and cfa.billing_project = p.billing_project
                        and a.enterprise_no = strEnterpriseNo
                        and a.warehouse_no = strWarehouseNo
                        and a.owner_no = strOwnerNo
                        and trunc(a.check_end_date) = trunc(dtDate)
                        and a.status = '13'

                      group by a.check_no, cfa.FAMILY_NO
                      order by a.check_no, cfa.FAMILY_NO) loop

          /*新增费用明细*/
          P_INSERT_EXPENSES_LIST(p.enterprise_no,
                                 p.warehouse_no,
                                 p.owner_no,
                                 p.billing_project,
                                 p.billing_type,
                                 p.billing_unit,
                                 list.FAMILY_NO,
                                 dtDate,
                                 list.source_no,
                                 v_nQty,
                                 v_nWeight,
                                 v_nVolume,
                                 strFlag,
                                 strWorkerNo,
                                 strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        end loop;

      end if;

    end loop;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_RIC;

  /***********************************************************************************************
  wyf
  20151208
  功能说明：获取装车相关消费数据
  ***********************************************************************************************/
  procedure P_LO(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                 strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                 strOwnerNo         cost_formulaset.owner_no%type, --货主
                 strBilling_project cost_formulaset.billing_project%type, --计费项目
                 strBillingType     cost_formulaset.billing_type%type, --计费项目类型
                 dtDate             cost_expenses_list.build_date%type, --生成日期
                 strFlag            cost_expenses_list.flag%type, --是否重算，0:代表正常日结生成，1：代表重算
                 strWorkerNo        cost_expenses_list.rgst_name%type,
                 strOutMsg          out varchar2) --返回值
   IS
    v_nQty    cost_expenses_list.qty%type; --数量
    v_nVolume cost_expenses_list.volume%type; --体积
    v_nWeight cost_expenses_list.weight%type; --重量
  BEGIN
    strOutMsg := 'N|[P_LO]';

    for p in (select a.*
                from cost_formulaset a
               where a.enterprise_no = strEnterpriseNo
                 and a.warehouse_no = strWarehouseNo
                 and a.owner_no = strOwnerNo
                 and a.billing_project = strBilling_project
                 and a.billing_type = strBillingType) loop
      --是否为标准策咯：0：否；1：是
      if p.STANDARD_FLAG = '1' then
        for list in (select a.DELIVER_NO source_no,
                            nvl(sum(ceil(b.real_qty / b.packing_qty)), 0) AS QTY,
                            nvl(sum(ceil(b.real_qty / b.packing_qty) *
                                    c.packing_weight),
                                0) AS WEIGHT,
                            nvl(sum(ceil(b.real_qty / b.packing_qty) *
                                    c.packing_volumn),
                                0) AS VOLUME
                       from odata_deliver_m              a,
                            odata_deliver_d              b,
                            v_article_pack_volumn_weight c
                      where a.DELIVER_NO = b.DELIVER_NO
                        and a.enterprise_no = b.enterprise_no
                        and a.warehouse_no = b.warehouse_no
                        and a.owner_no = b.owner_no
                        and b.enterprise_no = c.enterprise_no
                        and b.owner_no = c.owner_no
                        and b.article_no = c.article_no
                        and b.packing_qty = c.packing_qty
                        and a.enterprise_no = strEnterpriseNo
                        and a.warehouse_no = strWarehouseNo
                        and a.owner_no = strOwnerNo
                        and trunc(a.OPERATE_DATE) = trunc(dtDate)
                        and a.status = '13'
                        and not exists
                      (select 1
                               from bdef_article_family_d      baf,
                                    cost_formula_articlefamily cfa
                              where b.enterprise_no = baf.enterprise_no
                                and b.owner_no = baf.owner_no
                                and b.article_no = baf.article_no
                                and baf.enterprise_no = cfa.enterprise_no
                                and baf.owner_no = cfa.owner_no
                                and b.warehouse_no = cfa.warehouse_no
                                and baf.FAMILY_NO = cfa.FAMILY_NO
                                and cfa.BILLING_TYPE = p.billing_type
                                and cfa.billing_project = p.billing_project)
                      group by a.DELIVER_NO
                      order by a.DELIVER_NO) loop

          /*新增费用明细*/
          P_INSERT_EXPENSES_LIST(p.enterprise_no,
                                 p.warehouse_no,
                                 p.owner_no,
                                 p.billing_project,
                                 p.billing_type,
                                 p.billing_unit,
                                 'N',
                                 dtDate,
                                 list.source_no,
                                 v_nQty,
                                 v_nWeight,
                                 v_nVolume,
                                 strFlag,
                                 strWorkerNo,
                                 strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        end loop;
      else
        for list in (select a.DELIVER_NO source_no,
                            cfa.FAMILY_NO,
                            nvl(sum(ceil(b.real_qty / b.packing_qty)), 0) AS QTY,
                            nvl(sum(ceil(b.real_qty / b.packing_qty) *
                                    c.packing_weight),
                                0) AS WEIGHT,
                            nvl(sum(ceil(b.real_qty / b.packing_qty) *
                                    c.packing_volumn),
                                0) AS VOLUME
                       from odata_deliver_m              a,
                            odata_deliver_d              b,
                            v_article_pack_volumn_weight c,
                            bdef_article_family_d        baf,
                            cost_formula_articlefamily   cfa
                      where a.DELIVER_NO = b.DELIVER_NO
                        and a.enterprise_no = b.enterprise_no
                        and a.warehouse_no = b.warehouse_no
                        and a.owner_no = b.owner_no
                        and b.enterprise_no = c.enterprise_no
                        and b.owner_no = c.owner_no
                        and b.article_no = c.article_no
                        and b.packing_qty = c.packing_qty
                        and b.enterprise_no = baf.enterprise_no
                        and b.owner_no = baf.owner_no
                        and b.article_no = baf.article_no

                        and baf.enterprise_no = cfa.enterprise_no
                        and b.warehouse_no = cfa.warehouse_no
                        and baf.owner_no = cfa.owner_no
                        and baf.FAMILY_NO = cfa.FAMILY_NO
                        and cfa.BILLING_TYPE = p.billing_type
                        and cfa.billing_project = p.billing_project
                        and a.enterprise_no = strEnterpriseNo
                        and a.warehouse_no = strWarehouseNo
                        and a.owner_no = strOwnerNo
                        and trunc(a.OPERATE_DATE) = trunc(dtDate)
                        and a.status = '13'

                      group by a.DELIVER_NO, cfa.FAMILY_NO
                      order by a.DELIVER_NO, cfa.FAMILY_NO) loop
          /*新增费用明细*/
          P_INSERT_EXPENSES_LIST(p.enterprise_no,
                                 p.warehouse_no,
                                 p.owner_no,
                                 p.billing_project,
                                 p.billing_type,
                                 p.billing_unit,
                                 list.FAMILY_NO,
                                 dtDate,
                                 list.source_no,
                                 v_nQty,
                                 v_nWeight,
                                 v_nVolume,
                                 strFlag,
                                 strWorkerNo,
                                 strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        end loop;

      end if;

    end loop;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_LO;

  /***********************************************************************************************
  wyf
  20151208
  功能说明：获取仓储费（不含当天入库）相关消费数据
  ***********************************************************************************************/
  procedure P_WH_WITHIN(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                        strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                        strOwnerNo         cost_formulaset.owner_no%type, --货主
                        strBilling_project cost_formulaset.billing_project%type, --计费项目
                        strBillingType     cost_formulaset.billing_type%type, --计费项目类型
                        dtDate             cost_expenses_list.build_date%type, --生成日期
                        strFlag            cost_expenses_list.flag%type, --是否重算，0:代表正常日结生成，1：代表重算
                        strWorkerNo        cost_expenses_list.rgst_name%type,
                        strOutMsg          out varchar2) IS
    v_nQty    cost_expenses_list.qty%type; --数量
    v_nVolume cost_expenses_list.volume%type; --体积
    v_nWeight cost_expenses_list.weight%type; --重量
  BEGIN
    strOutMsg := 'N|[P_WH_WITHIN]';
    for p in (select a.*
                from cost_formulaset a
               where a.enterprise_no = strEnterpriseNo
                 and a.warehouse_no = strWarehouseNo
                 and a.owner_no = strOwnerNo
                 and a.billing_project = strBilling_project
                 and a.billing_type = strBillingType) loop
      --是否为标准策咯：0：否；1：是
      if p.STANDARD_FLAG = '1' then
        for list in (select 'N' source_no,
                            nvl(sum(ceil(d.qc_qty / d.packing_qty)), 0) AS QTY,
                            nvl(sum(ceil(d.qc_qty / d.packing_qty) *
                                    c.packing_weight),
                                0) AS WEIGHT,
                            nvl(sum(ceil(d.qc_qty / d.packing_qty) *
                                    c.packing_volumn),
                                0) AS VOLUME
                       from stock_content_rj             d,
                            v_article_pack_volumn_weight c
                      where d.enterprise_no = strEnterpriseNo
                        and d.warehouse_no = strWarehouseNo
                        and d.owner_no = strOwnerNo
                        and trunc(d.jc_date) = trunc(dtDate)
                        and d.article_no = c.article_no
                        and d.enterprise_no = c.enterprise_no
                        and d.packing_qty = c.packing_qty
                        and d.owner_no = c.owner_no
                        and not exists
                      (select 1
                               from bdef_article_family_d      baf,
                                    cost_formula_articlefamily cfa
                              where d.enterprise_no = baf.enterprise_no
                                and d.owner_no = baf.owner_no
                                and d.article_no = baf.article_no
                                and baf.enterprise_no = cfa.enterprise_no
                                and baf.owner_no = cfa.owner_no
                                and d.warehouse_no = cfa.warehouse_no
                                and baf.FAMILY_NO = cfa.FAMILY_NO
                                and cfa.BILLING_TYPE = p.billing_type
                                and cfa.billing_project = p.billing_project)) loop
          /*新增费用明细*/
          P_INSERT_EXPENSES_LIST(p.enterprise_no,
                                 p.warehouse_no,
                                 p.owner_no,
                                 p.billing_project,
                                 p.billing_type,
                                 p.billing_unit,
                                 'N',
                                 dtDate,
                                 list.source_no,
                                 v_nQty,
                                 v_nWeight,
                                 v_nVolume,
                                 strFlag,
                                 strWorkerNo,
                                 strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        end loop;
      else
        for list in (select 'N' source_no,
                            cfa.family_no,
                            nvl(sum(ceil(d.qc_qty / d.packing_qty)), 0) AS QTY,
                            nvl(sum(ceil(d.qc_qty / d.packing_qty) *
                                    c.packing_weight),
                                0) AS WEIGHT,
                            nvl(sum(ceil(d.qc_qty / d.packing_qty) *
                                    c.packing_volumn),
                                0) AS VOLUME
                       from stock_content_rj             d,
                            v_article_pack_volumn_weight c,
                            bdef_article_family_d        baf,
                            cost_formula_articlefamily   cfa
                      where d.enterprise_no = strEnterpriseNo
                        and d.warehouse_no = strWarehouseNo
                        and d.owner_no = strOwnerNo
                        and trunc(d.jc_date) = trunc(dtDate)
                        and d.article_no = c.article_no
                        and d.enterprise_no = c.enterprise_no
                        and d.packing_qty = c.packing_qty
                        and d.owner_no = c.owner_no
                        and d.enterprise_no = baf.enterprise_no
                        and d.owner_no = baf.owner_no
                        and d.article_no = baf.article_no
                        and baf.enterprise_no = cfa.enterprise_no
                        and baf.owner_no = cfa.owner_no
                        and d.warehouse_no = cfa.warehouse_no
                        and baf.FAMILY_NO = cfa.FAMILY_NO
                        and cfa.BILLING_TYPE = p.billing_type
                        and cfa.billing_project = p.billing_project
                      group by cfa.family_no) loop
          /*新增费用明细*/
          P_INSERT_EXPENSES_LIST(p.enterprise_no,
                                 p.warehouse_no,
                                 p.owner_no,
                                 p.billing_project,
                                 p.billing_type,
                                 p.billing_unit,
                                 list.FAMILY_NO,
                                 dtDate,
                                 list.source_no,
                                 v_nQty,
                                 v_nWeight,
                                 v_nVolume,
                                 strFlag,
                                 strWorkerNo,
                                 strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        end loop;
      end if;

    end loop;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_WH_WITHIN;

  /***********************************************************************************************
  lich
  20151208
  功能说明：仓储费（包含当天入库）根据取值策略生成消费清单
  ***********************************************************************************************/
  procedure P_WH(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                 strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                 strOwnerNo         cost_formulaset.owner_no%type, --货主
                 strBilling_project cost_formulaset.billing_project%type, --计费项目
                 strBillingType     cost_formulaset.billing_type%type, --计费项目类型
                 dtDate             cost_expenses_list.build_date%type, --生成日期
                 strFlag            cost_expenses_list.flag%type, --是否重算，0:代表正常日结生成，1：代表重算
                 strWorkerNo        cost_expenses_list.rgst_name%type,
                 strOutMsg          out varchar2) --返回值
   IS
    v_nQty    cost_expenses_list.qty%type; --数量
    v_nVolume cost_expenses_list.volume%type; --体积
    v_nWeight cost_expenses_list.weight%type; --重量
  BEGIN
    strOutMsg := 'N|[P_ALL]';

    for p in (select a.*
                from cost_formulaset a
               where a.enterprise_no = strEnterpriseNo
                 and a.warehouse_no = strWarehouseNo
                 and a.owner_no = strOwnerNo
                 and a.billing_project = strBilling_project
                 and a.billing_type = strBillingType) loop
      --是否为标准策咯：0：否；1：是
      if p.STANDARD_FLAG = '1' then
        for list in (select 'N' source_no,
                            nvl(sum(ceil((d.qc_qty + d.in_qty) /
                                         d.packing_qty)),
                                0) AS QTY,
                            nvl(sum(ceil((d.qc_qty + d.in_qty) /
                                         d.packing_qty) * c.packing_weight),
                                0) AS WEIGHT,
                            nvl(sum(ceil((d.qc_qty + d.in_qty) /
                                         d.packing_qty) * c.packing_volumn),
                                0) AS VOLUME
                       from stock_content_rj             d,
                            v_article_pack_volumn_weight c
                      where d.enterprise_no = strEnterpriseNo
                        and d.warehouse_no = strWarehouseNo
                        and d.owner_no = strOwnerNo
                        and trunc(d.jc_date) = trunc(dtDate)
                        and d.article_no = c.article_no
                        and d.enterprise_no = c.enterprise_no
                        and d.packing_qty = c.packing_qty
                        and d.owner_no = c.owner_no
                        and not exists
                      (select 1
                               from bdef_article_family_d      baf,
                                    cost_formula_articlefamily cfa
                              where d.enterprise_no = baf.enterprise_no
                                and d.owner_no = baf.owner_no
                                and d.article_no = baf.article_no
                                and baf.enterprise_no = cfa.enterprise_no
                                and baf.owner_no = cfa.owner_no
                                and d.warehouse_no = cfa.warehouse_no
                                and baf.FAMILY_NO = cfa.FAMILY_NO
                                and cfa.BILLING_TYPE = p.billing_type
                                and cfa.billing_project = p.billing_project)) loop
          /*新增费用明细*/
          P_INSERT_EXPENSES_LIST(p.enterprise_no,
                                 p.warehouse_no,
                                 p.owner_no,
                                 p.billing_project,
                                 p.billing_type,
                                 p.billing_unit,
                                 'N',
                                 dtDate,
                                 list.source_no,
                                 v_nQty,
                                 v_nWeight,
                                 v_nVolume,
                                 strFlag,
                                 strWorkerNo,
                                 strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        end loop;
      else
        for list in (select 'N' source_no,
                            cfa.family_no,
                            nvl(sum(ceil((d.qc_qty + d.in_qty) /
                                         d.packing_qty)),
                                0) AS QTY,
                            nvl(sum(ceil((d.qc_qty + d.in_qty) /
                                         d.packing_qty) * c.packing_weight),
                                0) AS WEIGHT,
                            nvl(sum(ceil((d.qc_qty + d.in_qty) /
                                         d.packing_qty) * c.packing_volumn),
                                0) AS VOLUME
                       from stock_content_rj             d,
                            v_article_pack_volumn_weight c,
                            bdef_article_family_d        baf,
                            cost_formula_articlefamily   cfa
                      where d.enterprise_no = strEnterpriseNo
                        and d.warehouse_no = strWarehouseNo
                        and d.owner_no = strOwnerNo
                        and trunc(d.jc_date) = trunc(dtDate)
                        and d.article_no = c.article_no
                        and d.enterprise_no = c.enterprise_no
                        and d.packing_qty = c.packing_qty
                        and d.owner_no = c.owner_no
                        and d.enterprise_no = baf.enterprise_no
                        and d.owner_no = baf.owner_no
                        and d.article_no = baf.article_no
                        and baf.enterprise_no = cfa.enterprise_no
                        and baf.owner_no = cfa.owner_no
                        and d.warehouse_no = cfa.warehouse_no
                        and baf.FAMILY_NO = cfa.FAMILY_NO
                        and cfa.BILLING_TYPE = p.billing_type
                        and cfa.billing_project = p.billing_project
                      group by cfa.family_no) loop
          /*新增费用明细*/
          P_INSERT_EXPENSES_LIST(p.enterprise_no,
                                 p.warehouse_no,
                                 p.owner_no,
                                 p.billing_project,
                                 p.billing_type,
                                 p.billing_unit,
                                 list.FAMILY_NO,
                                 dtDate,
                                 list.source_no,
                                 v_nQty,
                                 v_nWeight,
                                 v_nVolume,
                                 strFlag,
                                 strWorkerNo,
                                 strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        end loop;
      end if;

    end loop;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_WH;
  /***********************************************************************************************
  wyf
  20151208
  功能说明：新增消费清单
  ***********************************************************************************************/
  procedure P_INSERT_EXPENSES_LIST(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                                   strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                                   strOwnerNo         cost_formulaset.owner_no%type, --货主
                                   strBilling_project cost_formulaset.billing_project%type, --计费项目 支持传空值
                                   strBillingType     cost_formulaset.billing_type%type, --计费项目类型 支持传空值
                                   strBillingUnit     cost_formulaset.billing_unit%type,
                                   strFamilyNo        cost_formula_articlefamily.family_no%type,
                                   dtDate             cost_formulaset.rgst_date%type, --开始日期
                                   strSourceNo        cost_expenses_list.source_no%type,
                                   nQty               cost_expenses_list.qty%type,
                                   nWeight            cost_expenses_list.weight%type,
                                   nVolume            cost_expenses_list.volume%type,
                                   strFlag            cost_expenses_list.flag%type, --是否重算，0:代表正常日结生成，1：代表重算
                                   strWorkerNo        cost_expenses_list.rgst_name%type,
                                   strOutMsg          out varchar2) IS
    v_NCount integer := 0;

    v_nQty    cost_expenses_list.qty%type; --数量
    v_nVolume cost_expenses_list.volume%type; --体积
    v_nWeight cost_expenses_list.weight%type; --重量
  BEGIN
    strOutMsg := 'N|[P_INSERT_EXPENSES_LIST]';
    if strBillingUnit = '4' then
      --件数
      v_nQty    := nQty;
      v_nVolume := 0;
      v_nWeight := 0;
    elsif strBillingUnit = '5' then
      --体积
      v_nQty    := 0;
      v_nVolume := nVolume / 1000000;
      v_nWeight := 0;
    elsif strBillingUnit = '6' then
      --重量
      v_nQty    := 0;
      v_nVolume := 0;
      v_nWeight := nWeight / 1000;
    elsif strBillingUnit is null then
      v_nQty    := nQty;
      v_nVolume := 0;
      v_nWeight := 0;
    end if;
    select count(1)
      into v_nCount
      from COST_EXPENSES_LIST t
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWarehouseNo
       and t.owner_no = strOwnerNo
       and t.billing_project = strBilling_project
       and t.billing_type = strBillingType
       and t.family_no = strFamilyNo
       and t.source_no = strSourceNo
       and trunc(t.build_date) = trunc(dtDate);
    if v_nCount = 0 then
      INSERT INTO COST_EXPENSES_LIST
        (ENTERPRISE_NO,
         WAREHOUSE_NO,
         OWNER_NO,
         BILLING_PROJECT,
         BILLING_TYPE,
         FAMILY_NO,
         BUILD_DATE,
         SOURCE_NO,
         SERIAL_NO,
         QTY,
         WEIGHT,
         VOLUME,
         STATUS,
         FLAG,
         RGST_NAME,
         RGST_DATE)
      values
        (strEnterpriseNo,
         strWarehouseNo,
         strOwnerNo,
         strBilling_project,
         strBillingType,
         strFamilyNo,
         dtDate,
         strSourceNo,
         'N', --seq_bill_expenses_list.nextval,
         v_nQty,
         v_nWeight,
         v_nVolume,
         '10',
         strFlag,
         strWorkerNo,
         sysdate);
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_INSERT_EXPENSES_LIST;

  /***********************************************************************************************
  wyf
  20151208
  功能说明：根据消费清单生成费用明细表
  ***********************************************************************************************/
  procedure P_COST_DETAILS(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                           strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                           strOwnerNo         cost_formulaset.owner_no%type, --货主
                           strBilling_project cost_formulaset.billing_project%type, --计费项目 支持传空值
                           strBillingType     cost_formulaset.billing_type%type, --计费项目类型 支持传空值
                           dtDate             cost_formulaset.rgst_date%type, --开始日期
                           strFlag            cost_expenses_list.flag%type, --是否重算，0:代表正常日结生成，1：代表重算
                           strWorkerNo        cost_expenses_list.rgst_name%type,
                           strOutMsg          out varchar2) --返回值
   IS
    --v_nRow   integer := 0;
    v_dtDate cost_expenses_list.build_date%type;

    --v_nDay     integer := 1;
    --v_nLastDay integer := 0;
    v_dtStart cost_cost_list.begin_date%type; --起始日期
    v_dtEnd   cost_cost_list.end_date%type; --结束日期

    v_nQty       cost_cost_list.qty%type; --费用明细数量
    v_nAmount    cost_cost_list.amount%type; --费用金额
    v_nFavAmount cost_cost_list.favourable_amount%type; --优惠金额

    /*v_nMidValue     NUMBER; --中间值
    v_nMidFavQty    NUMBER; --中间值
    v_nMidFavAmount NUMBER; --优惠后金额
    v_strMidPro     VARCHAR2(3000);
    v_strMidFlag    VARCHAR2(3000);
    v_nMidDisAmount NUMBER;*/

    v_count       number;
    v_strSerialNo cost_expenses_list.serial_no%type;
    v_strNextFlag varchar2(1); --是否跳过  0：否 ，1：是
  BEGIN
    strOutMsg := 'N|[P_COST_DETAILS]';
    v_count   := 0;
    --锁计费项目表
    update cost_formulaset a
       set a.status = a.status
     where a.status = '0'
       and nvl(a.END_DATE, sysdate) >= sysdate
       and a.enterprise_no = strEnterpriseNo
       and a.warehouse_no = strWarehouseNo
       and a.owner_no = strOwnerNo
       and (a.billing_project = strBilling_project or
           strBilling_project is null)
       and (a.billing_type = strBillingType or strBillingType is null);

    if strFlag = 1 then
      --重算日期取传入日期
      v_dtDate := dtDate;
    else
      --系统自动计算取传入日期的前一天
      v_dtDate := dtDate - 1;
    end if;
    for p in (select a.*
                from cost_formulaset a
               where a.status = '0'
                 and nvl(a.END_DATE, sysdate) >= sysdate
                 and a.enterprise_no = strEnterpriseNo
                 and a.warehouse_no = strWarehouseNo
                 and a.owner_no = strOwnerNo
                 and (a.billing_project = strBilling_project or
                     strBilling_project is null)
                 and (a.billing_type = strBillingType or
                     strBillingType is null)) loop
      --根据周期计算起始时间
      P_GETCYCLE_BEGINTOEND(p.billing_cycle,
                            p.balance_day,
                            v_dtDate,
                            v_dtStart,
                            v_dtEnd,
                            v_strNextFlag,
                            strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
      if v_strNextFlag = '1' then
        goto nextOne;
      end if;
      --重算处理
      --获取已存在的费用明细的SERIAL_NO，把相应的清单的SERIAL_NO置为N，并删除费用明细
      begin
        for S in (select distinct t.serial_no
                    from cost_cost_list t
                   where t.enterprise_no = p.enterprise_no
                     and t.warehouse_no = p.warehouse_no
                     and t.owner_no = p.owner_no
                     and t.billing_project = p.billing_project
                     and t.billing_type = p.billing_type
                     and t.build_date = trunc(v_dtDate)
                     and t.status = '10') loop
          if strFlag = '1' then
            --更新费用清单的serial_no为N
            update cost_expenses_list t
               set t.serial_no = 'N'
             where t.serial_no = S.serial_no;
            --删除费用明细
            delete from cost_cost_list t where t.serial_no = 'N';
          end if;
        end loop;
      end;
      --获取清单的数量
      select case p.billing_unit
               when '4' then
                sum(QTY)
               when '5' then
                sum(VOLUME)
               when '6' then
                sum(WEIGHT)
               else
                sum(QTY)
             end
        into v_nQty
        from cost_expenses_list t
       where t.enterprise_no = p.enterprise_no
         and t.warehouse_no = p.warehouse_no
         and t.owner_no = p.owner_no
         and t.billing_type = p.billing_type
         and t.billing_project = p.billing_project
         and t.build_date between v_dtStart and v_dtEnd
         and t.status = '10'
         and t.serial_no = 'N';
      if p.BILLING_FLAG = '1' then
        --固定费用
        v_nAmount    := p.FIXED_VALUE;
        v_nFavAmount := 0;
      else
        --动态费用
        v_nAmount    := v_nQty * p.unit_price;
        v_nFavAmount := 0;
        /*根据策略计算优惠金额*/
        P_PROJECT_DISCOUNT(strEnterpriseNo,
                           strWarehouseNo,
                           strOwnerNo,
                           p.billing_project,
                           p.billing_type,
                           v_nQty,
                           v_nAmount,
                           v_nFavAmount,
                           strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;

        /*v_nMidFavQty    := '0';
        v_nMidFavAmount := v_nAmount;
        v_strMidPro     := ' ';
        v_strMidFlag    := ' ';
        --费用金额
        v_nMidValue := v_nAmount;
        --获取优惠策略
        for rule in (select *
                       from COST_FORMULA_DISCOUNT a
                      where a.enterprise_no = p.enterprise_no
                        and a.warehouse_no = p.warehouse_no
                        and a.owner_no = p.owner_no
                        and a.billing_type = p.billing_type
                        and a.billing_project = p.billing_project
                      order by a.LADDER desc) loop
          v_nRow := v_nRow + 1;
          --根据优惠策略计算优惠金额
          if rule.discount_flag = '1' then
            --消费值只对超出“值1”部分计费
            if v_nAmount > rule.value1 then
              if nvl(instr(v_strMidFlag, '#' || rule.DISCOUNT_FLAG || '#'),
                     0) = 0 then
                v_nMidFavAmount := v_nAmount - rule.value1;
                v_strMidFlag    := v_strMidFlag || '#' ||
                                   rule.DISCOUNT_FLAG || '#';
              end if;
            else
              v_nMidFavAmount := 0;
            end if;
          elsif rule.discount_flag = '2' then
            --费用不足“值1”，按“值1”算
            if v_nAmount < rule.value1 then
              if nvl(instr(v_strMidFlag, '#' || rule.DISCOUNT_FLAG || '#'),
                     0) = 0 then
                v_nMidFavAmount := rule.value1;
                v_strMidFlag    := v_strMidFlag || '#' ||
                                   rule.DISCOUNT_FLAG || '#';
              end if;
            end if;
          elsif rule.discount_flag = '3' then
            --费用超出“值1”，按“值2”算
            if v_nAmount > rule.value1 then
              if nvl(instr(v_strMidFlag, '#' || rule.DISCOUNT_FLAG || '#'),
                     0) = 0 then
                v_nMidFavAmount := rule.value2;
                v_strMidFlag    := v_strMidFlag || '#' ||
                                   rule.DISCOUNT_FLAG || '#';
              end if;
            end if;
          elsif rule.discount_flag = '4' then
            --费用超出“值1”，按“值2”打折
            if v_nAmount > rule.value1 then
              if nvl(instr(v_strMidFlag, '#' || rule.DISCOUNT_FLAG || '#'),
                     0) = 0 then
                v_nMidFavAmount := v_nAmount * rule.value1;
                v_strMidFlag    := v_strMidFlag || '#' ||
                                   rule.DISCOUNT_FLAG || '#';
              end if;
            end if;
          elsif rule.discount_flag = '5' then
            --费用超出“值1”的部分，按“值2”打折
            if v_nAmount > rule.value1 then
              v_nMidDisAmount := v_nMidDisAmount +
                                 (v_nMidValue - rule.VALUE1) * rule.VALUE2;
              v_nMidFavAmount := v_nAmount - v_nMidDisAmount;
            end if;
          end if;
          v_nMidValue := rule.VALUE1;
        end loop;
        --计算优惠金额
        select decode(sign(v_nAmount - v_nMidFavAmount),
                      -1,
                      0,
                      v_nAmount - v_nMidFavAmount)
          into v_nFavAmount
          from dual;*/
      end if;
      v_strSerialNo := SEQ_BILL_COST_LIST.NEXTVAL;
      insert into cost_cost_list
        (enterprise_no,
         warehouse_no,
         owner_no,
         billing_project,
         billing_type,
         build_date,
         serial_no,
         begin_date,
         end_date,
         qty,
         amount,
         favourable_amount,
         status,
         flag,
         account_no,
         check_no,
         RGST_NAME,
         RGST_DATE)
      values
        (strEnterpriseNo,
         strWarehouseNo,
         strOwnerNo,
         p.billing_project,
         p.billing_type,
         v_dtDate,
         v_strSerialNo, --SEQ_BILL_COST_LIST.NEXTVAL,
         v_dtStart,
         v_dtEnd,
         v_nQty,
         v_nAmount,
         v_nFavAmount,
         '10',
         strFlag,
         'N',
         'N',
         strWorkerNo,
         sysdate);
      update cost_expenses_list t
         set t.serial_no = v_strSerialNo,
             t.status    = '13',
             t.updt_name = strWorkerNo,
             t.updt_date = sysdate
       where t.enterprise_no = p.enterprise_no
         and t.warehouse_no = p.warehouse_no
         and t.owner_no = p.owner_no
         and t.billing_type = p.billing_type
         and t.billing_project = p.billing_project
         and t.build_date between v_dtStart and v_dtEnd
         and t.status = '10'
         and t.serial_no = 'N';
      <<nextOne>>
      null;
    end loop;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_COST_DETAILS;

  /***********************************************************************************************
  wyf
  20151210
  功能说明：通过计费项目优惠策略计算优惠后金额
  ***********************************************************************************************/
  procedure P_PROJECT_DISCOUNT(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                               strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                               strOwnerNo         cost_formulaset.owner_no%type, --货主
                               strBilling_project cost_formulaset.billing_project%type, --计费项目
                               strBillingType     cost_formulaset.billing_type%type, --计费项目类型
                               nQty               cost_cost_list.qty%type,
                               nAmount            cost_cost_list.amount%type,
                               nFavAmount         out cost_cost_list.favourable_amount%type, --优惠金额
                               strOutMsg          out varchar2) IS
    v_nRow    integer := 0;
    v_nQty    cost_cost_list.qty%type; --费用明细数量
    v_nAmount cost_cost_list.amount%type; --费用金额
    --v_nFavAmount    cost_cost_list.favourable_amount%type; --优惠金额
    v_nMidValue NUMBER; --中间值
    --v_nMidFavQty    NUMBER; --中间值
    v_nMidFavAmount NUMBER; --优惠后金额
    --v_strMidPro     VARCHAR2(3000);
    v_strMidFlag    VARCHAR2(3000);
    v_nMidDisAmount NUMBER;
  BEGIN
    strOutMsg := 'N|[P_PROJECT_DISCOUNT]';
    v_nQty    := nQty;
    v_nAmount := nAmount;

    --v_nMidFavQty    := '0';
    v_nMidFavAmount := v_nAmount;
    --v_strMidPro     := ' ';
    v_strMidFlag := ' ';
    --费用金额
    v_nMidValue := v_nAmount;
    --获取优惠策略
    for rule in (select *
                   from COST_FORMULA_DISCOUNT a
                  where a.enterprise_no = strEnterpriseNo
                    and a.warehouse_no = strWarehouseNo
                    and a.owner_no = strOwnerNo
                    and a.billing_type = strBillingType
                    and a.billing_project = strBilling_project
                  order by a.LADDER desc) loop
      v_nRow := v_nRow + 1;
      --根据优惠策略计算优惠金额
      if rule.discount_flag = '1' then
        --消费值只对超出“值1”部分计费
        if v_nAmount > rule.value1 then
          if nvl(instr(v_strMidFlag, '#' || rule.DISCOUNT_FLAG || '#'), 0) = 0 then
            v_nMidFavAmount := v_nAmount - rule.value1;
            v_strMidFlag    := v_strMidFlag || '#' || rule.DISCOUNT_FLAG || '#';
          end if;
        else
          v_nMidFavAmount := 0;
        end if;
      elsif rule.discount_flag = '2' then
        --费用不足“值1”，按“值1”算
        if v_nAmount < rule.value1 then
          if nvl(instr(v_strMidFlag, '#' || rule.DISCOUNT_FLAG || '#'), 0) = 0 then
            v_nMidFavAmount := rule.value1;
            v_strMidFlag    := v_strMidFlag || '#' || rule.DISCOUNT_FLAG || '#';
          end if;
        end if;
      elsif rule.discount_flag = '3' then
        --费用超出“值1”，按“值2”算
        if v_nAmount > rule.value1 then
          if nvl(instr(v_strMidFlag, '#' || rule.DISCOUNT_FLAG || '#'), 0) = 0 then
            v_nMidFavAmount := rule.value2;
            v_strMidFlag    := v_strMidFlag || '#' || rule.DISCOUNT_FLAG || '#';
          end if;
        end if;
      elsif rule.discount_flag = '4' then
        --费用超出“值1”，按“值2”打折
        if v_nAmount > rule.value1 then
          if nvl(instr(v_strMidFlag, '#' || rule.DISCOUNT_FLAG || '#'), 0) = 0 then
            v_nMidFavAmount := v_nAmount * rule.value1;
            v_strMidFlag    := v_strMidFlag || '#' || rule.DISCOUNT_FLAG || '#';
          end if;
        end if;
      elsif rule.discount_flag = '5' then
        --费用超出“值1”的部分，按“值2”打折
        if v_nAmount > rule.value1 then
          v_nMidDisAmount := v_nMidDisAmount +
                             (v_nMidValue - rule.VALUE1) * rule.VALUE2;
          v_nMidFavAmount := v_nAmount - v_nMidDisAmount;
        end if;
      end if;
      v_nMidValue := rule.VALUE1;
    end loop;
    --计算优惠金额
    select decode(sign(v_nAmount - v_nMidFavAmount),
                  -1,
                  0,
                  v_nAmount - v_nMidFavAmount)
      into nFavAmount
      from dual;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_PROJECT_DISCOUNT;
  /***********************************************************************************************
  lich
  20140729
  功能说明：根据消费清单自动生成账单
  ***********************************************************************************************/
  procedure P_FINANCIAL_DETAILS_BYAUTO(strEnterpriseNo bill_formulaset.enterprise_no%type, --企业
                                       strWarehouseNo  bill_formulaset.warehouse_no%type, --仓别
                                       strOwnerNo      bill_formulaset.owner_no%type, --货主
                                       --strMonth         varchar, --月份
                                       dtDate            cost_cost_list.build_date%type,
                                       strAccountGroupNo cost_account_d.account_group_no%type, --科目组编码（允许为空，但重算时必须传）
                                       --strAccountNo      cost_financial.account_no%type, --科目编码（允许为空，但重算时必须传）
                                       strCheckNo  cost_financial.check_no%type, --对账单号（允许为空，但重算时必须传）
                                       strFlag     cost_expenses_list.flag%type, --是否重算 0:自动 , 1:重算
                                       strWorkerNo cost_financial.rgst_name%type,
                                       strOutMsg   out varchar2) --返回值
   IS
    v_dtDate  cost_financial.build_date%type;
    v_dtStart cost_financial.build_date%type;
    v_dtEnd   cost_financial.build_date%type;

    v_strCheckNo cost_financial.check_no%type;
    v_nCount     integer;

    v_strNextFlag varchar2(1); --是否跳过  0：否 ，1：是
  BEGIN
    strOutMsg := 'N|[P_FINANCIAL_DETAILS_BYAUTO]';

    --获取费用明细
    if strFlag = '1' then
      --重算
      v_dtDate     := dtDate;
      v_strCheckNo := strCheckNo;

      select count(1)
        into v_nCount
        from cost_financial a
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWarehouseNo
         and a.owner_no = strOwnerNo
         and a.check_no = v_strCheckNo
         and a.status > '10';
      if v_nCount > 0 then
        strOutMsg := 'N|[已开始缴费的对账单无法重算！]';
        return;
      end if;
      --获取账单起始日期，结束日期，记账日期
      select distinct a.begin_date, a.end_date, a.build_date
        into v_dtStart, v_dtEnd, v_dtDate
        from cost_financial a
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWarehouseNo
         and a.owner_no = strOwnerNo
         and a.check_no = v_strCheckNo;
      --删除账单
      delete from cost_financial a
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWarehouseNo
         and a.owner_no = strOwnerNo
         and a.check_no = v_strCheckNo;
      --更新费用明细状态
      update cost_cost_list a
         set a.status = '10', a.check_no = 'N'
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWarehouseNo
         and a.owner_no = strOwnerNo
         and a.check_no = v_strCheckNo;
      --更新其他费用状态
      update cost_other_list a
         set a.status = '10', a.check_no = 'N'
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWarehouseNo
         and a.owner_no = strOwnerNo
         and a.check_no = v_strCheckNo;
      for acc in (select *
                    from cost_account_d t
                   where t.enterprise_no = strEnterpriseNo
                     and t.warehouse_no = strWarehouseNo
                     and t.owner_no = strOwnerNo
                     and t.account_group_no = strAccountGroupNo
                   order by t.ACCOUNT_ID) loop
        --新增账单
        P_INSERT_FINANCIAL(strEnterpriseNo,
                           strWarehouseNo,
                           strOwnerNo,
                           v_dtDate,
                           v_dtStart,
                           v_dtEnd,
                           acc.account_no,
                           v_strCheckNo,
                           strFlag,
                           strWorkerNo,
                           strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
      end loop;
    else
      --自动
      v_dtDate     := dtDate - 1;
      v_strCheckNo := 'N';
      --获取科目头档
      for p in (select *
                  from cost_account_m t
                 where t.enterprise_no = strEnterpriseNo
                   and t.warehouse_no = strWarehouseNo
                   and t.owner_no = strOwnerNo
                   and t.status = '0') loop
        --根据周期计算起始时间
        P_GETCYCLE_BEGINTOEND(p.ACCOUNT_CYCLE,
                              p.balance_day,
                              v_dtDate,
                              v_dtStart,
                              v_dtEnd,
                              v_strNextFlag,
                              strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
        if v_strNextFlag = '1' then
          goto nextOne;
        end if;
        for acc in (select *
                      from cost_account_d t
                     where t.enterprise_no = p.enterprise_no
                       and t.warehouse_no = p.warehouse_no
                       and t.owner_no = p.owner_no
                       and t.account_group_no = p.account_group_no
                     order by t.ACCOUNT_ID) loop
          --新增账单
          P_INSERT_FINANCIAL(strEnterpriseNo,
                             strWarehouseNo,
                             strOwnerNo,
                             v_dtDate,
                             v_dtStart,
                             v_dtEnd,
                             acc.account_no,
                             v_strCheckNo,
                             strFlag,
                             strWorkerNo,
                             strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        end loop;
        /*--获取科目明细
        for acc in (select *
                      from cost_account_d t
                     where t.enterprise_no = p.enterprise_no
                       and t.warehouse_no = p.warehouse_no
                       and t.owner_no = p.owner_no
                       and t.account_group_no = p.account_group_no
                     order by t.ACCOUNT_ID) loop
          --计算消费明细费用
          select sum(a.amount - a.favourable_amount)
            into v_nAmount
            from cost_cost_list a, cost_account_formula b
           where b.enterprise_no = acc.enterprise_no
             and b.warehouse_no = acc.warehouse_no
             and b.owner_no = acc.owner_no
             and b.account_no = acc.account_no
             and a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and a.owner_no = b.owner_no
             and a.billing_project = b.billing_project
             and a.billing_type = b.billing_type
             and a.build_date between v_dtStart and v_dtEnd
             and a.check_no = 'N'
             and a.status = '10';
          v_nDiscountAmount := v_nAmount;
          --根据策略计算出优惠后金额
          P_ACCOUNT_DISCOUNT(strEnterpriseNo,
                             strWarehouseNo,
                             strOwnerNo,
                             acc.account_no,
                             v_dtStart,
                             v_dtEnd,
                             v_nAmount,
                             v_nDiscountAmount,
                             strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
          --获取记账单号
          if v_strCheckNo is null or v_strCheckNo = 'N' then
            PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                       strWarehouseNo,
                                       CONST_DOCUMENTTYPE.COST,
                                       v_strCheckNo,
                                       strOutMsg);
            if (v_strCheckNo is null or substr(strOutMsg, 1, 1) = 'N') then
              strOutMsg := 'N|取对账单号错误!';
              return;
            end if;
          end if;
          --新增账单
          insert into cost_financial
            (enterprise_no,
             warehouse_no,
             owner_no,
             account_no,
             check_no,
             amount,
             discount_amount,
             real_amount,
             begin_date,
             end_date,
             flag,
             build_date,
             status,
             rgst_name,
             rgst_date,
             create_flag,
             cost_flag)
          values
            (strEnterpriseNo,
             strWarehouseNo,
             strOwnerNo,
             acc.account_no,
             v_strCheckNo,
             v_nAmount,
             decode(sign(v_nAmount - v_nDiscountAmount),
                    -1,
                    0,
                    v_nAmount - v_nDiscountAmount),
             0,
             v_dtStart,
             v_dtEnd,
             strFlag,
             v_dtDate,
             '10',
             strWorkerNo,
             sysdate,
             '0',
             '0');
          --更新费用明细对账单号和状态
          update cost_cost_list t
             set t.status     = '13',
                 t.check_no   = v_strCheckNo,
                 t.account_no = acc.account_no,
                 t.updt_name  = strWorkerNo,
                 t.updt_date  = sysdate
           where t.enterprise_no = strEnterpriseNo
             and t.warehouse_no = strWarehouseNo
             and t.owner_no = strOwnerNo
             and exists (select 1
                    from cost_account_formula b
                   where t.enterprise_no = b.enterprise_no
                     and t.warehouse_no = b.warehouse_no
                     and t.owner_no = b.owner_no
                     and t.billing_project = b.billing_project
                     and t.billing_type = b.billing_type
                     and b.account_no = acc.account_no)
             and t.build_date between v_dtStart and v_dtEnd
             and t.check_no = 'N'
             and t.status = '10';
        end loop;*/

        <<nextOne>>
        null;
        --计算其他费用
        --系统自动生成账单须更新时间区间内未记账的其他费用状态为11，再生成账单
        update cost_other_list t
           set t.status = '11'
         where t.enterprise_no = strEnterpriseNo
           and t.warehouse_no = strWarehouseNo
           and t.owner_no = strOwnerNo
           and t.cost_date between v_dtStart and v_dtEnd
           and t.status = '10';
        P_OTHERCOST_DETAILS(strEnterpriseNo,
                            strWarehouseNo,
                            strOwnerNo,
                            v_dtDate,
                            v_dtStart,
                            v_dtEnd,
                            v_strCheckNo,
                            strFlag,
                            '0',
                            strWorkerNo,
                            strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
        --置对账单号为空
        v_strCheckNo := 'N';
      end loop;

    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_FINANCIAL_DETAILS_BYAUTO;

  /***********************************************************************************************
  wyf
  20151210
  功能说明：手工出对账单
  ***********************************************************************************************/
  procedure P_FINANCIAL_DETAILS_BYHAND(strEnterpriseNo bill_formulaset.enterprise_no%type, --企业
                                       strWarehouseNo  bill_formulaset.warehouse_no%type, --仓别
                                       strOwnerNo      bill_formulaset.owner_no%type, --货主
                                       dtDate          cost_cost_list.build_date%type,
                                       dtStart         cost_cost_list.begin_date%type,
                                       dtEnd           cost_cost_list.end_date%type,
                                       strAccountNo    cost_financial.account_no%type, --科目编码（允许为空，但重算时必须传）
                                       strCheckNo      cost_financial.check_no%type, --对账单号（允许为空，但重算时必须传）
                                       strFlag         cost_expenses_list.flag%type, --是否重算 0:首次出账 , 1:重算
                                       strDiscountFlag varchar2, --是否使用优惠策略--0:不使用，1:使用
                                       strWorkerNo     cost_financial.rgst_name%type,
                                       strOutMsg       out varchar2) --返回值
   IS
    v_nAmount         cost_cost_list.amount%type; --按消费清单算出的金额
    v_nDiscountAmount cost_cost_list.amount%type; --优惠后的金额

    v_nCount     integer;
    v_strCheckNo cost_financial.check_no%type;
  BEGIN
    strOutMsg := 'N|[P_FINANCIAL_DETAILS_BYHAND]';
    v_nCount  := 0;
    if strFlag = '0' then
      v_strCheckNo := 'N';
      --获取已选费用明细
      for p in (select b.account_no,
                       t.billing_project,
                       t.billing_type,
                       nvl(sum(t.qty), 0) qty,
                       nvl(sum(t.amount), 0) amount,
                       nvl(sum(t.favourable_amount), 0) favourable_amount
                  from cost_cost_list t, cost_account_formula b
                 where t.enterprise_no = strEnterpriseNo
                   and t.warehouse_no = strWarehouseNo
                   and t.owner_no = strOwnerNo
                   and t.status = '11'
                   and t.enterprise_no = b.enterprise_no
                   and t.warehouse_no = b.warehouse_no
                   and t.owner_no = b.owner_no
                   and t.billing_type = b.billing_type
                   and t.billing_project = b.billing_project
                 group by b.account_no, t.billing_project, t.billing_type) loop
        for acc in (select *
                      from cost_account_d a
                     where a.enterprise_no = strEnterpriseNo
                       and a.warehouse_no = strWarehouseNo
                       and a.owner_no = strOwnerNo
                       and a.account_no = p.account_no) loop
          --计算消费明细费用
          select sum(a.amount - a.favourable_amount)
            into v_nAmount
            from cost_cost_list a, cost_account_formula b
           where b.enterprise_no = acc.enterprise_no
             and b.warehouse_no = acc.warehouse_no
             and b.owner_no = acc.owner_no
             and b.account_no = acc.account_no
             and a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and a.owner_no = b.owner_no
             and a.billing_project = b.billing_project
             and a.billing_type = b.billing_type
             and a.status = '11';
          if strDiscountFlag = '1' then
            --根据策略计算出优惠后金额
            P_ACCOUNT_DISCOUNT(strEnterpriseNo,
                               strWarehouseNo,
                               strOwnerNo,
                               acc.account_no,
                               dtStart,
                               dtEnd,
                               v_nAmount,
                               v_nDiscountAmount,
                               strOutMsg);
            if substr(strOutMsg, 1, 1) <> 'Y' then
              return;
            end if;
          end if;
          --获取记账单号
          if v_strCheckNo is null or v_strCheckNo = 'N' then
            PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                       strWarehouseNo,
                                       CONST_DOCUMENTTYPE.COST,
                                       v_strCheckNo,
                                       strOutMsg);
            if (v_strCheckNo is null or substr(strOutMsg, 1, 1) = 'N') then
              strOutMsg := 'N|取对账单号错误!';
              return;
            end if;
          end if;
          --新增账单
          insert into cost_financial
            (enterprise_no,
             warehouse_no,
             owner_no,
             account_no,
             check_no,
             amount,
             discount_amount,
             real_amount,
             begin_date,
             end_date,
             flag,
             build_date,
             status,
             rgst_name,
             rgst_date,
             create_flag,
             cost_flag)
          values
            (strEnterpriseNo,
             strWarehouseNo,
             strOwnerNo,
             acc.account_no,
             v_strCheckNo,
             v_nAmount,
             decode(sign(v_nAmount - v_nDiscountAmount),
                    -1,
                    0,
                    v_nAmount - v_nDiscountAmount),
             0,
             dtStart,
             dtEnd,
             strFlag,
             dtDate,
             '10',
             strWorkerNo,
             sysdate,
             '1',
             '0');
          --更新费用明细的对账单号和状态
          update cost_cost_list t
             set t.status     = '13',
                 t.check_no   = v_strCheckNo,
                 t.account_no = acc.account_no,
                 t.updt_name  = strWorkerNo,
                 t.updt_date  = sysdate
           where t.enterprise_no = strEnterpriseNo
             and t.warehouse_no = strWarehouseNo
             and t.owner_no = strOwnerNo
             and exists (select 1
                    from cost_account_formula b
                   where t.enterprise_no = b.enterprise_no
                     and t.warehouse_no = b.warehouse_no
                     and t.owner_no = b.owner_no
                     and t.billing_project = b.billing_project
                     and t.billing_type = b.billing_type
                     and b.account_no = acc.account_no)
             and t.status = '11';

        end loop;

      end loop;
      --计算其他费用
      --手工生成账单在界面勾选确认后须更新其他费用的状态为11
      P_OTHERCOST_DETAILS(strEnterpriseNo,
                          strWarehouseNo,
                          strOwnerNo,
                          dtDate,
                          dtStart,
                          dtEnd,
                          v_strCheckNo,
                          strFlag,
                          '1',
                          strWorkerNo,
                          strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
    else
      --重算则直接删除，返回手工记账界面重新选择
      v_strCheckNo := strCheckNo;
      select count(1)
        into v_nCount
        from cost_financial a
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWarehouseNo
         and a.owner_no = strOwnerNo
         and a.check_no = v_strCheckNo
         and a.status > '10';
      if v_nCount > 0 then
        strOutMsg := 'N|[已开始缴费的对账单无法重算！]';
        return;
      end if;

      delete from cost_financial a
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWarehouseNo
         and a.owner_no = strOwnerNo
         and a.check_no = v_strCheckNo;
      --更新费用明细状态
      update cost_cost_list a
         set a.status = '10', a.check_no = 'N'
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWarehouseNo
         and a.owner_no = strOwnerNo
         and a.check_no = v_strCheckNo;
      --更新其他费用状态
      update cost_other_list a
         set a.status = '10', a.check_no = 'N'
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWarehouseNo
         and a.owner_no = strOwnerNo
         and a.check_no = v_strCheckNo;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_FINANCIAL_DETAILS_BYHAND;

  /***********************************************************************************************
  weiyf
  20151211
  功能说明：根据消费清单自动生成账单
  ***********************************************************************************************/
  procedure P_INSERT_FINANCIAL(strEnterpriseNo bill_formulaset.enterprise_no%type, --企业
                               strWarehouseNo  bill_formulaset.warehouse_no%type, --仓别
                               strOwnerNo      bill_formulaset.owner_no%type, --货主
                               dtDate          cost_cost_list.build_date%type,
                               dtStart         cost_cost_list.begin_date%type,
                               dtEnd           cost_cost_list.end_date%type,
                               strAccountNo    cost_account_d.account_no%type, --科目组编码
                               strCheckNo      in out cost_financial.check_no%type, --对账单号（允许为空，但重算时必须传）
                               strFlag         cost_expenses_list.flag%type, --是否重算 0:自动 , 1:重算
                               strWorkerNo     cost_financial.rgst_name%type,
                               strOutMsg       out varchar2) IS

    v_nAmount         cost_cost_list.amount%type; --按消费清单算出的金额
    v_nDiscountAmount cost_cost_list.amount%type; --优惠后的金额
    v_strCheckNo      cost_financial.check_no%type;
  BEGIN
    strOutMsg    := 'N|[P_INSERT_FINANCIAL]';
    v_strCheckNo := strCheckNo;
    --获取科目明细
    for acc in (select *
                  from cost_account_d t
                 where t.enterprise_no = strEnterpriseNo
                   and t.warehouse_no = strWarehouseNo
                   and t.owner_no = strOwnerNo
                   and t.account_no = strAccountNo
                 order by t.ACCOUNT_ID) loop
      --计算消费明细费用
      select sum(a.amount - a.favourable_amount)
        into v_nAmount
        from cost_cost_list a, cost_account_formula b
       where b.enterprise_no = acc.enterprise_no
         and b.warehouse_no = acc.warehouse_no
         and b.owner_no = acc.owner_no
         and b.account_no = acc.account_no
         and a.enterprise_no = b.enterprise_no
         and a.warehouse_no = b.warehouse_no
         and a.owner_no = b.owner_no
         and a.billing_project = b.billing_project
         and a.billing_type = b.billing_type
         and a.build_date between dtStart and dtEnd
         and a.check_no = 'N'
         and a.status = '10';
      v_nDiscountAmount := v_nAmount;
      --根据策略计算出优惠后金额
      P_ACCOUNT_DISCOUNT(strEnterpriseNo,
                         strWarehouseNo,
                         strOwnerNo,
                         acc.account_no,
                         dtStart,
                         dtEnd,
                         v_nAmount,
                         v_nDiscountAmount,
                         strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
      --获取记账单号
      if v_strCheckNo is null or v_strCheckNo = 'N' then
        PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                   strWarehouseNo,
                                   CONST_DOCUMENTTYPE.COST,
                                   v_strCheckNo,
                                   strOutMsg);
        if (v_strCheckNo is null or substr(strOutMsg, 1, 1) = 'N') then
          strOutMsg := 'N|取对账单号错误!';
          return;
        end if;
      end if;
      --新增账单
      insert into cost_financial
        (enterprise_no,
         warehouse_no,
         owner_no,
         account_no,
         check_no,
         amount,
         discount_amount,
         real_amount,
         begin_date,
         end_date,
         flag,
         build_date,
         status,
         rgst_name,
         rgst_date,
         create_flag,
         cost_flag,
         account_group_no)
      values
        (strEnterpriseNo,
         strWarehouseNo,
         strOwnerNo,
         acc.account_no,
         v_strCheckNo,
         v_nAmount,
         decode(sign(v_nAmount - v_nDiscountAmount),
                -1,
                0,
                v_nAmount - v_nDiscountAmount),
         0,
         dtStart,
         dtEnd,
         strFlag,
         dtDate,
         '10',
         strWorkerNo,
         sysdate,
         '0',
         '0',
         acc.account_group_no);
      --更新费用明细对账单号和状态
      update cost_cost_list t
         set t.status     = '13',
             t.check_no   = v_strCheckNo,
             t.account_no = acc.account_no,
             t.updt_name  = strWorkerNo,
             t.updt_date  = sysdate
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWarehouseNo
         and t.owner_no = strOwnerNo
         and exists (select 1
                from cost_account_formula b
               where t.enterprise_no = b.enterprise_no
                 and t.warehouse_no = b.warehouse_no
                 and t.owner_no = b.owner_no
                 and t.billing_project = b.billing_project
                 and t.billing_type = b.billing_type
                 and b.account_no = acc.account_no)
         and t.build_date between dtStart and dtEnd
         and t.check_no = 'N'
         and t.status = '10';
    end loop;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_INSERT_FINANCIAL;

  /***********************************************************************************************
  wyf
  20151210
  功能说明：其他费用出对账单
  ***********************************************************************************************/
  procedure P_OTHERCOST_DETAILS(strEnterpriseNo bill_formulaset.enterprise_no%type, --企业
                                strWarehouseNo  bill_formulaset.warehouse_no%type, --仓别
                                strOwnerNo      bill_formulaset.owner_no%type, --货主
                                dtDate          cost_cost_list.build_date%type,
                                dtStart         cost_cost_list.begin_date%type,
                                dtEnd           cost_cost_list.end_date%type,
                                strCheckNo      in out cost_financial.check_no%type, --对账单号
                                strFlag         cost_expenses_list.flag%type, --是否重算 0:首次出账 , 1:重算
                                strCreateFlag   cost_financial.create_flag%type, --0:自动出账，1:人工出账
                                strWorkerNo     cost_financial.rgst_name%type,
                                strOutMsg       out varchar2) IS
    v_strCheckNo cost_financial.check_no%type;
  BEGIN
    strOutMsg    := 'N|[P_OTHERCOST_DETAILS]';
    v_strCheckNo := strCheckNo;
    for p in (select nvl(sum(a.cost_value), 0) Amount, a.cost_flag
                from cost_other_list a
               where a.enterprise_no = strEnterpriseNo
                 and a.warehouse_no = strWarehouseNo
                 and a.owner_no = strOwnerNo
                 and a.status = '11'
               group by a.cost_flag) loop
      --获取记账单号
      if v_strCheckNo is null or v_strCheckNo = 'N' then
        PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                   strWarehouseNo,
                                   CONST_DOCUMENTTYPE.COST,
                                   v_strCheckNo,
                                   strOutMsg);
        if (v_strCheckNo is null or substr(strOutMsg, 1, 1) = 'N') then
          strOutMsg := 'N|取对账单号错误!';
          return;
        end if;
      end if;
      --新增账单
      insert into cost_financial
        (enterprise_no,
         warehouse_no,
         owner_no,
         account_no,
         check_no,
         amount,
         discount_amount,
         real_amount,
         begin_date,
         end_date,
         flag,
         build_date,
         status,
         rgst_name,
         rgst_date,
         create_flag,
         cost_flag,
         account_group_no)
      values
        (strEnterpriseNo,
         strWarehouseNo,
         strOwnerNo,
         'N',
         v_strCheckNo,
         p.amount,
         0,
         0,
         dtStart,
         dtEnd,
         strFlag,
         dtDate,
         '10',
         strWorkerNo,
         sysdate,
         strCreateFlag,
         p.cost_flag,
         'N');
      update cost_other_list t
         set t.status    = '13',
             t.check_no  = v_strCheckNo,
             t.updt_name = strWorkerNo,
             t.updt_date = sysdate
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWarehouseNo
         and t.status = '11'
         and t.cost_flag = p.cost_flag;
    end loop;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_OTHERCOST_DETAILS;

  /***********************************************************************************************
  wyf
  20151210
  功能说明：计算周期起始时间
  ***********************************************************************************************/
  procedure P_GETCYCLE_BEGINTOEND(strCycle    cost_formulaset.billing_cycle%type,
                                  strLastDay  cost_formulaset.balance_day%type,
                                  dtDate      cost_cost_list.build_date%type,
                                  dtStart     out cost_cost_list.begin_date%type, --起始日期
                                  dtEnd       out cost_cost_list.end_date%type, --结束日期
                                  strNextFlag out varchar2, --是否跳过  0：否 ，1：是
                                  strOutMsg   out varchar2) IS
    v_dtDate   cost_cost_list.build_date%type;
    v_nDay     integer := 1;
    v_nLastDay integer := 0;
    v_dtStart  cost_cost_list.begin_date%type; --起始日期
    v_dtEnd    cost_cost_list.end_date%type; --结束日期
  BEGIN
    strOutMsg   := 'N|[P_GETCYCLE_BEGINTOEND]';
    v_dtDate    := dtDate;
    strNextFlag := '0';
    if strCycle = '1' then
      --按天
      v_dtDate  := v_dtDate;
      v_dtStart := v_dtDate;
      v_dtEnd   := v_dtDate;
    elsif strCycle = '2' then
      --按周 获取传入日期是周几
      select to_char(v_dtDate, 'd') into v_nDay from dual;
      if strLastDay is null then
        --未维护结算日 则默认周天为结算日
        if v_nDay = '1' then
          v_dtDate  := v_dtDate;
          v_dtStart := v_dtDate - 6;
          v_dtEnd   := v_dtDate;
        else
          strNextFlag := 1;
        end if;
      else
        --有维护结算日，则比较传入日期是否为结算日
        if v_nDay = strLastDay then
          v_dtDate  := v_dtDate;
          v_dtStart := v_dtDate - 6;
          v_dtEnd   := v_dtDate;
        else
          strNextFlag := 1;
        end if;
      end if;
    elsif strCycle = '3' then
      --按月 获取传入日期是几号
      select to_char(v_dtDate, 'dd') into v_nDay from dual;
      --获取传入日期所在月份的最后一天
      select to_char(last_day(v_dtDate), 'dd') into v_nLastDay from dual;
      if strLastDay is null then
        --未维护结算日，则默认每月的最后一天为结算日
        if v_nDay = v_nLastDay then
          v_dtDate := v_dtDate;
          --起始日期为本月1号
          select trunc(add_months(v_dtDate, -1)) + 1
            into v_dtStart
            from dual;
          v_dtEnd := v_dtDate;
        else
          strNextFlag := 1;
        end if;
      else
        --有维护结算日，则比较传入日期是否为结算日
        --若结算日大于传入日期所在月的最后一天，则判断传入日期是否为所在月份的最后一天
        if v_nDay = strLastDay or
           (strLastDay > v_nLastDay and v_nDay = v_nLastDay) then
          v_dtDate := v_dtDate;
          --上个月的结算日为起始日期
          select trunc(add_months(v_dtDate, -1)) + 1
            into v_dtStart
            from dual;
          v_dtEnd := v_dtDate;
        else
          strNextFlag := 1;
        end if;
      end if;
    else
      strNextFlag := 1;
    end if;
    if strNextFlag = '0' then
      dtEnd   := v_dtEnd;
      dtStart := v_dtStart;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_GETCYCLE_BEGINTOEND;
  /***********************************************************************************************
  wyf
  20151210
  功能说明：通过科目优惠策略计算优惠后金额
  ***********************************************************************************************/
  procedure P_ACCOUNT_DISCOUNT(strEnterpriseNo bill_formulaset.enterprise_no%type, --企业
                               strWarehouseNo  bill_formulaset.warehouse_no%type, --仓别
                               strOwnerNo      bill_formulaset.owner_no%type, --货主
                               strAccountNo    cost_financial.account_no%type, --科目编码
                               dtStart         cost_financial.build_date%type,
                               dtEnd           cost_financial.build_date%type,
                               nAmount         cost_cost_list.amount%type,
                               nDiscountAmount out cost_cost_list.amount%type,
                               strOutMsg       out varchar2) IS

    v_nAmount            cost_cost_list.amount%type; --按消费清单算出的金额
    v_nDiscountAmount    cost_cost_list.amount%type; --优惠后的金额
    v_nDiscountProAmount cost_cost_list.amount%type; --优惠计费项目的金额
    nRowID               NUMBER; --行号
    nMidValue            NUMBER; --中间值
    nMidDisAmount        NUMBER; --优惠金额
    strMidPro            VARCHAR2(3000);
    strMidFlag           VARCHAR2(3000);
  BEGIN
    strOutMsg         := 'N|[P_ACCOUNT_DISCOUNT]';
    v_nAmount         := nAmount;
    v_nDiscountAmount := v_nAmount;
    nMidDisAmount     := 0;
    nMidValue         := v_nAmount;
    strMidPro         := ' ';
    strMidFlag        := ' ';
    --获取优惠策略
    for L in (select *
                from cost_account_discount t
               where t.enterprise_no = strEnterpriseNo
                 and t.warehouse_no = strWarehouseNo
                 and t.owner_no = strOwnerNo
                 and t.account_no = strAccountNo
               order by t.ACCOUNT_LADDER desc) loop
      nRowID := nRowID + 1;
      if L.DISCOUNT_FLAG = '1' then
        --1  超出“值1”按“值2”打折
        if v_nAmount > L.VALUE1 then
          if nvl(instr(strMidFlag, '#' || L.DISCOUNT_FLAG || '#'), 0) = 0 then
            v_nDiscountAmount := v_nDiscountAmount * L.VALUE2;
            strMidFlag        := strMidFlag || '#' || L.DISCOUNT_FLAG || '#';
          end if;
        end if;
      elsif L.DISCOUNT_FLAG = '2' then
        --2  超出“值1”送“值2”
        if v_nAmount > L.VALUE1 then
          if nvl(instr(strMidFlag, '#' || L.DISCOUNT_FLAG || '#'), 0) = 0 then
            v_nDiscountAmount := v_nDiscountAmount - L.VALUE2;
            strMidFlag        := strMidFlag || '#' || L.DISCOUNT_FLAG || '#';
          end if;
        end if;
      elsif L.DISCOUNT_FLAG = '3' then
        --3  超出“值1”送“优惠计费项目”
        if v_nAmount > L.VALUE1 then
          if nvl(instr(strMidPro, '#' || L.BILLING_PROJECT || '#'), 0) = 0 then
            select nvl(sum(a.amount), 0)
              into v_nDiscountProAmount
              from cost_cost_list a, cost_account_formula b
             where a.enterprise_no = b.enterprise_no
               and a.warehouse_no = b.warehouse_no
               and a.owner_no = b.owner_no
               and a.billing_project = b.billing_project
               and a.billing_type = b.billing_type
               and b.enterprise_no = strEnterpriseNo
               and b.warehouse_no = strWarehouseNo
               and b.owner_no = strOwnerNo
               and b.account_no = strAccountNo
               and b.billing_project = L.BILLING_PROJECT
               and a.build_date between dtStart and dtEnd
               and a.check_no = 'N'
               and a.status = '10';

            v_nDiscountAmount := v_nDiscountAmount - v_nDiscountProAmount;

            strMidPro := strMidPro || '#' || L.BILLING_PROJECT || '#';
          end if;
        end if;
      elsif L.DISCOUNT_FLAG = '4' then
        --4  超出“值1”，“优惠计费项目”按“值2”打折
        if v_nAmount > L.VALUE1 then
          if instr(strMidPro, '#' || L.BILLING_PROJECT || '#') = 0 then
            select nvl(sum(a.amount), 0)
              into v_nDiscountProAmount
              from cost_cost_list a, cost_account_formula b
             where a.enterprise_no = b.enterprise_no
               and a.warehouse_no = b.warehouse_no
               and a.owner_no = b.owner_no
               and a.billing_project = b.billing_project
               and a.billing_type = b.billing_type
               and b.enterprise_no = strEnterpriseNo
               and b.warehouse_no = strWarehouseNo
               and b.owner_no = strOwnerNo
               and b.account_no = strAccountNo
               and b.billing_project = L.BILLING_PROJECT
               and a.build_date between dtStart and dtEnd
               and a.check_no = 'N'
               and a.status = '10';

            v_nDiscountAmount := v_nDiscountAmount -
                                 v_nDiscountProAmount * (1 - L.VALUE2);

            strMidPro := strMidPro || '#' || L.BILLING_PROJECT || '#';
          end if;
        end if;
      elsif L.DISCOUNT_FLAG = '5' then
        --5  超出“值1”的部分，按“值2”打折
        if v_nAmount > L.VALUE1 then
          nMidDisAmount     := nMidDisAmount +
                               (nMidValue - L.VALUE1) * L.VALUE2;
          v_nDiscountAmount := v_nAmount - nMidDisAmount;
        end if;
      end if;
      nMidValue := L.VALUE1;
    end loop;
    nDiscountAmount := v_nDiscountAmount;
    strOutMsg       := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_ACCOUNT_DISCOUNT;

  /***********************************************************************************************
  wyf
  20150727
  功能说明：生成计费
  ***********************************************************************************************/
  procedure P_GENERATE_BILL is
    v_strOutMsg varchar2(255);
    --dtCurMonthFirstDay bill_formulaset.rgst_date%type; --当前月第一天
    --dtCurDay           bill_formulaset.rgst_date%type; --当天
  BEGIN
    v_strOutMsg := 'N|[P_GENERATE_BILL]';

    for p in (select distinct c.enterprise_no, c.warehouse_no, c.owner_no
                from cost_formulaset c
               order by c.enterprise_no, c.warehouse_no, c.owner_no) loop
      --生成消费清单
      P_EXPENSES_LIST(p.enterprise_no,
                      p.warehouse_no,
                      p.owner_no,
                      null,
                      null,
                      trunc(sysdate),
                      '0',
                      'admin_user',
                      v_strOutMsg);
      --生成费用明细
      P_COST_DETAILS(p.enterprise_no,
                     p.warehouse_no,
                     p.owner_no,
                     null,
                     null,
                     trunc(sysdate),
                     '0',
                     'admin_user',
                     v_strOutMsg);
      --生成账单
      P_FINANCIAL_DETAILS_BYAUTO(p.enterprise_no,
                                 p.warehouse_no,
                                 p.owner_no,
                                 trunc(sysdate),
                                 null,
                                 null,
                                 '0',
                                 'admin_user',
                                 v_strOutMsg);
    end loop;
    v_strOutMsg := 'Y';
  exception
    when others then
      v_strOutMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_GENERATE_BILL;

end PKOBJ_BILL_W;

/

