create PACKAGE        cPickType is

        -- 分播
        BroadCase CONSTANT ODATA_OUTSTOCK_M.PICK_TYPE%type := '1';             --分播

        -- 摘果
        Picking CONSTANT ODATA_OUTSTOCK_M.PICK_TYPE%type := '0';           --摘果

        -- 边拣边分
        PickingDivide CONSTANT ODATA_OUTSTOCK_M.PICK_TYPE%type := '2';       --边拣边分

end cPickType;


/

