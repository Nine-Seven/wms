create PACKAGE        CLabelUseType is


        -- 收货标签
        IMPORT_LABEL CONSTANT STOCK_LABEL_M.Use_Type%type := '0';             --收货标签

        -- 客户标签
        CUSTOMER_LABEL CONSTANT STOCK_LABEL_M.Use_Type%type := '1';           --客户标签

        -- 分播标签
        DIVIDE_LABEL CONSTANT STOCK_LABEL_M.Use_Type%type := '2';             --分播标签

        -- /移库标签
        MOVE_STOCK_LABEL CONSTANT STOCK_LABEL_M.Use_Type%type:= '3';         --移库标签
end CLabelUseType;


/

