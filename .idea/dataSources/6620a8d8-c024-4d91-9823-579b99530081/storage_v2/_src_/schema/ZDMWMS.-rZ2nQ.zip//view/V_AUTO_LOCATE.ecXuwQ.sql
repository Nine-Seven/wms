create view V_AUTO_LOCATE (ENTERPRISE_NO, WAREHOUSE_NO, EXP_NO, OWNER_NO, EXP_TYPE, ROWNO) as
select
                      a.enterprise_no,
                      a.warehouse_no,
                      a.exp_no,
                      a.owner_no,
                      a.exp_type,
                      mod(rank（） over（partition by
                      case when '1'='1' then a.order_source else '' end,
                      case when '1'='1' then a.deliver_type else '' end,
                      case when '1'='0' then a.deliver_address  else '' end,
                      case when '1'='1' then a.shipper_no  else '' end,
                      case when '1'='1' then a.custsend_date  else sysdate end order by a.exp_no
                      ),3)
                       rowNo
                from
                  odata_exp_m a,
                  (
                    select distinct
                      a.enterprise_no,
                      a.warehouse_no,
                      a.exp_no,
                      sum(1) over（partition by a.exp_no  order by a.exp_no) artCount,
                      case when sum(1) over（partition by a.exp_no  order by a.exp_no)=1 then sum(1) over（partition by a.article_no  order by a.article_no) else 0 end repeatCount
                    from
                      odata_exp_d a,
                      odata_exp_m b
                    where
                      a.enterprise_no=b.enterprise_no
                      and a.warehouse_no=b.warehouse_no
                      and a.exp_no=b.exp_no
                      and b.status='10'
                      and b.exp_type='B2C'
                      and b.enterprise_no='8888'
                   ) b
                 where
                   1=1
                   and a.enterprise_no=b.enterprise_no
                   and a.warehouse_no=b.warehouse_no
                   and a.exp_no=b.exp_no
                   and (
                         (b.repeatCount<=0  and b.artcount=1  and '3'='1')
                         or (b.repeatCount>=0  and b.artcount=1  and '3'='2')
                         or (b.artCount>1 and '3'='3')
                        )

/

