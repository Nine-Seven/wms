create package        PKLG_ODATA_LICH is
  /**********************************************************************************************8
  lich
  20150120
  功能说明：RF拣货回单
  ***********************************************************************************************/
  procedure P_OmPickReceipt(strEnterprise_No in odata_outstock_m.enterprise_no%type, --仓别
                            strWarehose_No   in odata_outstock_m.warehouse_no%type, --仓别
                            strOutstock_No   in odata_outstock_m.outstock_no%type, --下架单号
                            strSLabel_No     in odata_outstock_d.label_no%type, --源标签号码
                            strDlabel_No     in odata_outstock_d.label_no%type, --目的标签号码
                            strArticle_No    in odata_outstock_d.article_no%type, --商品编码
                            nPacking_QTY     in odata_outstock_d.packing_qty%type, --包装数量
                            strSCell_No      in odata_outstock_d.s_cell_no%type, --来源储位
                            nArticleQty      in odata_outstock_d.article_qty%type, --计划数量
                            nReal_QTY        in odata_outstock_d.article_qty%type, --下架数量
                            strQuality       in idata_check_d.quality%type, --品质
                            dtProduceDate    in stock_article_info.produce_date%type, --生产日期
                            dtExpireDate     in stock_article_info.expire_date%type, --到期日期
                            strLotNo         in stock_article_info.lot_no%type, --批次号
                            strRSV_BATCH1    in stock_article_info.rsv_batch1%type, --预留批属性1
                            strRSV_BATCH2    in stock_article_info.rsv_batch2%type, --预留批属性2
                            strRSV_BATCH3    in stock_article_info.rsv_batch3%type, --预留批属性3
                            strRSV_BATCH4    in stock_article_info.rsv_batch4%type, --预留批属性4
                            strRSV_BATCH5    in stock_article_info.rsv_batch5%type, --预留批属性5
                            strRSV_BATCH6    in stock_article_info.rsv_batch6%type, --预留批属性6
                            strRSV_BATCH7    in stock_article_info.rsv_batch7%type, --预留批属性7
                            strRSV_BATCH8    in stock_article_info.rsv_batch8%type, --预留批属性8
                            strDock_No       in odata_outstock_m.dock_no%type, --工作站
                            strUserID        in odata_outstock_m.rgst_name%type, --回单人
                            strOutstock_ID   in odata_outstock_d.outstock_name%type, --下架人
                            strInstock_ID    in odata_outstock_d.instock_name%type, --上架人
                            strOutMsg        out varchar2);
  /**********************************************************************************************8
  lich
  20140521
  功能说明：表单拣货回单
  ***********************************************************************************************/
  procedure P_Save_Odata_Outstock(strEnterPriseNo in odata_outstock_m.Enterprise_No%type, --企业号
                                  strWarehose_No  in odata_outstock_m.warehouse_no%type, --仓别
                                  strOutstock_No  in odata_outstock_m.outstock_no%type, --下架单号
                                  strFixLabel_No  in odata_outstock_d.label_no%type, --来源标签号码
                                  strArticle_No   in odata_outstock_d.article_no%type, --商品编码
                                  nPacking_QTY    in odata_outstock_d.packing_qty%type, --包装数量
                                  strSCell_No     in odata_outstock_d.s_cell_no%type, --来源储位
                                  nArticleQty     in odata_outstock_d.article_qty%type, --计划数量
                                  nReal_QTY       in odata_outstock_d.article_qty%type, --下架数量
                                  strQuality      in idata_check_d.quality%type, --品质
                                  dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                                  dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                                  strLotNo        in stock_article_info.lot_no%type, --批次号
                                  strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                                  strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                                  strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                                  strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                                  strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                                  strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                                  strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                                  strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                                  strDock_No      in odata_outstock_m.dock_no%type, --工作站
                                  strUserID       in odata_outstock_m.rgst_name%type, --回单人
                                  strOutstock_ID  in odata_outstock_d.outstock_name%type, --下架人
                                  strInstock_ID   in odata_outstock_d.instock_name%type, --上架人
                                  strOutMsg       out varchar2);
  /**********************************************************************************************8
  lich
  20140521
  功能说明：任务标签拣货回单
  ***********************************************************************************************/
  procedure P_TaskLabelSave_Odata_Outstock(strEnterPriseNo in odata_outstock_m.enterprise_no%type, --企业号
                                           strWarehose_No  in odata_outstock_m.warehouse_no%type, --仓别
                                           strOutstock_No  in odata_outstock_m.outstock_no%type, --下架单号
                                           strFixLabel_No  in odata_outstock_d.label_no%type, --来源标签号码
                                           strDLabelNo     in stock_label_m.label_no%type, --目的标签号，若分播传N，摘果时，按界面录入
                                           strArticle_No   in odata_outstock_d.article_no%type, --商品编码
                                           nPacking_QTY    in odata_outstock_d.packing_qty%type, --包装数量
                                           strSCell_No     in odata_outstock_d.s_cell_no%type, --来源储位
                                           nArticleQty     in odata_outstock_d.article_qty%type, --计划数量
                                           nReal_QTY       in odata_outstock_d.article_qty%type, --下架数量
                                           strQuality      in idata_check_d.quality%type, --品质
                                           dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                                           dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                                           strLotNo        in stock_article_info.lot_no%type, --批次号
                                           strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                                           strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                                           strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                                           strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                                           strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                                           strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                                           strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                                           strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                                           strDock_No      in odata_outstock_m.dock_no%type, --工作站
                                           strUserID       in odata_outstock_m.rgst_name%type, --回单人
                                           strOutstock_ID  in odata_outstock_d.outstock_name%type, --下架人
                                           strInstock_ID   in odata_outstock_d.instock_name%type, --上架人
                                           strOutMsg       out varchar2);

  /**********************************************************************************************8
  luozhiling
  20150702
  功能说明：按标签上的商品进行回单保存数据:
  1、按商品进行下架回单；
  2、更新库存；
  3、更新标签数据
  ***********************************************************************************************/
  procedure P_SerialLabel_Save(strEnterPriseNo in odata_outstock_m.enterprise_no%type, --企业号
                               strWarehose_No  in odata_outstock_m.warehouse_no%type, --仓别
                               strOutstock_No  in odata_outstock_m.outstock_no%type, --下架单号
                               strFixLabel_No  in odata_outstock_d.label_no%type, --来源标签号码
                               strArticle_No   in odata_outstock_d.article_no%type, --商品编码
                               nPacking_QTY    in odata_outstock_d.packing_qty%type, --包装数量
                               strSCell_No     in odata_outstock_d.s_cell_no%type, --来源储位
                               nReal_QTY       in odata_outstock_d.article_qty%type, --下架数量
                               strQuality      in idata_check_d.quality%type, --品质
                               dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                               dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                               strLotNo        in stock_article_info.lot_no%type, --批次号
                               strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                               strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                               strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                               strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                               strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                               strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                               strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                               strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                               strUserID       in odata_outstock_m.rgst_name%type, --回单人
                               strOutstock_ID  in odata_outstock_d.outstock_name%type, --下架人
                               strInstock_ID   in odata_outstock_d.instock_name%type, --上架人
                               strOutMsg       out varchar2);
  /**********************************************************************************************8
  luozhiling
  20150702
  功能说明：按标签上的商品进行回单保存数据:
  1、按商品进行下架回单；
  2、更新库存；
  3、更新标签数据
  ***********************************************************************************************/
  procedure P_SerialLabelCancel(strEnterPriseNo in odata_outstock_m.enterprise_no%type, --企业号
                                strWarehose_No  in odata_outstock_m.warehouse_no%type, --仓别
                                strOutstock_No  in odata_outstock_m.outstock_no%type, --下架单号
                                strFixLabel_No  in odata_outstock_d.label_no%type, --来源标签号码
                                strArticle_No   in odata_outstock_d.article_no%type, --商品编码
                                nPacking_QTY    in odata_outstock_d.packing_qty%type, --包装数量
                                strSCell_No     in odata_outstock_d.s_cell_no%type, --来源储位
                                nReal_QTY       in odata_outstock_d.article_qty%type, --下架数量
                                strQuality      in idata_check_d.quality%type, --品质
                                dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                                dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                                strLotNo        in stock_article_info.lot_no%type, --批次号
                                strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                                strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                                strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                                strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                                strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                                strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                                strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                                strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                                strUserID       in odata_outstock_m.rgst_name%type, --回单人
                                strOutstock_ID  in odata_outstock_d.outstock_name%type, --下架人
                                strInstock_ID   in odata_outstock_d.instock_name%type, --上架人
                                strOutMsg       out varchar2);
  --外部号转内部号
  procedure TransFixNoToSerialNo(strEnterPriseNo     in stock_label_m.Enterprise_No%type, --企业号
                                 strWAREHOUSE_NO     in stock_label_m.warehouse_no%type,
                                 strLabel_No         in stock_label_m.label_no%type,
                                 strUserID           in stock_label_m.rgst_name%type,
                                 strUseType          in stock_label_m.use_type%type,
                                 strDeliverOBJ       in stock_label_m.deliver_obj%type,
                                 strOperateType      in odata_outstock_m.operate_type%type,
                                 strContainer_Type   out stock_label_m.container_type%type,
                                 strContainer_No     out stock_label_m.container_no%type,
                                 strContainerNewFlag out integer,
                                 strOutMsg           out varchar2);
  --检查标签状态
  procedure CheckContainerStatus(strEnterPriseNo   in stock_label_m.enterprise_no%type,
                                 strWAREHOUSE_NO   in stock_label_m.warehouse_no%type,
                                 strLabel_No       in stock_label_m.label_no%type,
                                 strUserID         in stock_label_m.rgst_name%type,
                                 strUseType        in stock_label_m.use_type%type,
                                 strDeliverOBJ     in stock_label_m.deliver_obj%type,
                                 strContainer_Type out stock_label_m.container_type%type,
                                 strContainer_No   out stock_label_m.container_no%type,
                                 strOutMsg         out varchar2);

  /***************************************************************************************************
    功能说明：拣货差异回单处理
    luozhiling
    2015.05.4
  *****************************************************************************************************/
  procedure P_SaveOutstockDiff(strEnterPriseNo in odata_outstock_m.enterprise_no%type,
                               strWareHouseNo  in odata_outstock_m.warehouse_no%type,
                               strWaveNo       in odata_outstock_m.wave_no%type,
                               strBatchNo      in odata_outstock_m.batch_no%type,
                               strOutstockNo   in odata_outstock_m.outstock_no%type,
                               strUserID       in bdef_defworker.worker_no%type, --系统操作人员
                               strOutMsg       out varchar2);

  /**********************************************************************************************8
  luozhiling
  20150702
  功能说明：按标签上的商品进行回单保存数据:
  1、按商品进行下架回单；
  2、更新库存；
  3、更新标签数据
  ***********************************************************************************************/
  procedure P_SaveOutstock(strEnterPriseNo in odata_outstock_m.enterprise_no%type, --企业号
                           strWarehose_No  in odata_outstock_m.warehouse_no%type, --仓别
                           strOutstock_No  in odata_outstock_m.outstock_no%type, --下架单号
                           strFixLabel_No  in odata_outstock_d.label_no%type, --来源标签号码
                           strDLabelNo     in stock_label_m.label_no%type, --目的标签号
                           strArticle_No   in odata_outstock_d.article_no%type, --商品编码
                           nPacking_QTY    in odata_outstock_d.packing_qty%type, --包装数量
                           strSCell_No     in odata_outstock_d.s_cell_no%type, --来源储位
                           nReal_QTY       in odata_outstock_d.article_qty%type, --下架数量
                           strQuality      in idata_check_d.quality%type, --品质
                           dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                           dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                           strLotNo        in stock_article_info.lot_no%type, --批次号
                           strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                           strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                           strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                           strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                           strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                           strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                           strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                           strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                           strUserID       in odata_outstock_m.rgst_name%type, --回单人
                           strOutstock_ID  in odata_outstock_d.outstock_name%type, --下架人
                           strInstock_ID   in odata_outstock_d.instock_name%type, --上架人
                           strOutLabelNo   out stock_label_m.label_no%type,
                           strOutMsg       out varchar2);
  /**********************************************************************************************8
  luozhiling
  20140702
  功能说明：拣货回单对于标签的处理
  ***********************************************************************************************/
  procedure P_SavePickLabel(strEnterPriseNo in odata_outstock_m.enterprise_no%type, --企业号
                            strWarehose_No  in odata_outstock_m.warehouse_no%type, --仓别
                            strWaveNo       in odata_outstock_m.wave_no%type,
                            strBatchNo      in odata_outstock_m.batch_no%type,
                            strOutstock_No  in odata_outstock_m.outstock_no%type, --下架单号
                            strFixLabel_No  in odata_outstock_d.label_no%type, --标签号码
                            strDock_No      in odata_outstock_m.dock_no%type, --工作站
                            strUserID       in odata_outstock_m.rgst_name%type, --拣货人
                            strOutMsg       out varchar2);

  /**********************************************************************************************8
  luozhiling
  20150702
  功能说明：拣货回单整单确认：
            1、更新波次管理表；
            2、更新标签头档状态；
            3、转历史
  ***********************************************************************************************/
  procedure P_ComfireOutstock(strEnterPriseNo in odata_outstock_m.enterprise_no%type, --企业号
                              strWarehose_No  in odata_outstock_m.warehouse_no%type, --仓别
                              strOutstock_No  in odata_outstock_m.outstock_no%type, --下架单号
                              strUserID       in odata_outstock_m.rgst_name%type, --回单人
                              strOutMsg       out varchar2);
  /*************************************************************************************************
  功能说明：1、整单回单
             适用于对于整下架单的所有标签进行无差异回单
  ************************************************************************************************/
  procedure p_Save_all_outstock(strEnterprise_No in odata_outstock_m.enterprise_no%type, --仓别
                                strWarehose_No   in odata_outstock_m.warehouse_no%type, --仓别
                                strOutstock_No   in odata_outstock_m.outstock_no%type, --下架单号
                                strUserID        in odata_outstock_m.rgst_name%type, --回单人
                                strOutstock_ID   in odata_outstock_d.outstock_name%type, --下架人
                                strInstock_ID    in odata_outstock_d.instock_name%type, --上架人
                                strOutMsg        out varchar2);
  /*************************************************************************************************
  功能说明：1、整标签回单
             适用于对于某下架单上的某一标签进行无差异回单
  ************************************************************************************************/
  procedure p_Save_Labelall_outstock(strEnterprise_No in odata_outstock_m.enterprise_no%type, --仓别
                                     strWarehose_No   in odata_outstock_m.warehouse_no%type, --仓别
                                     strOutstock_No   in odata_outstock_m.outstock_no%type, --下架单号
                                     strLabelNo       in stock_label_m.label_no%type,
                                     strUserID        in odata_outstock_m.rgst_name%type, --回单人
                                     strOutstock_ID   in odata_outstock_d.outstock_name%type, --下架人
                                     strInstock_ID    in odata_outstock_d.instock_name%type, --上架人
                                     strOutMsg        out varchar2);
  /*************************************************************************************************
  功能说明：1、整单标签0回单
             适用于对于下架单流水箱标签进行0回单
  ************************************************************************************************/
  procedure P_SaveLabelCancelOutStock(strEnterPriseNo in odata_outstock_m.enterprise_no%type, --企业号
                                      strWarehose_No  in odata_outstock_m.warehouse_no%type, --仓别
                                      strOutstock_No  in odata_outstock_m.outstock_no%type, --下架单号
                                      strDock_No      in odata_outstock_m.dock_no%type, --工作站
                                      strUserID       in odata_outstock_m.rgst_name%type, --拣货人
                                      strOutMsg       out varchar2);

  /*************************************************************************************************
  功能说明：RF索单 Add by sunl 20160526
           1. 校验工作站是否有效
           2. 校验员工是否有效
           3. 校验员工索取任务是否已到上限
           4. 写打印任务
           5. 更新打印状态，索单状态。
  ************************************************************************************************/
  PROCEDURE P_CLAIMORDER(STRENTERPRISENO IN ODATA_OUTSTOCK_M.ENTERPRISE_NO%TYPE, --企业号
                         STRWAREHOSE_NO  IN ODATA_OUTSTOCK_M.WAREHOUSE_NO%TYPE, --仓别
                         STRUSERID       IN ODATA_OUTSTOCK_M.RGST_NAME%TYPE, --索单人
                         STROPERATE_TYPE IN ODATA_OUTSTOCK_M.OPERATE_TYPE%TYPE, --类型 B OR C
                         STRDOCK_NO      IN ODATA_OUTSTOCK_M.DOCK_NO%TYPE, --工作站
                         STROUTMSG       OUT VARCHAR2,
                         STROUTSTOCK_NO  OUT ODATA_OUTSTOCK_M.OUTSTOCK_NO%TYPE --下架单号
                         );

  /**********************************************************************************************8
  Quzhihui
  边拣边分回单
  20160621
  ***********************************************************************************************/
  procedure P_Outstock_PickDivide(strEnterPriseNo in odata_outstock_m.enterprise_no%type, --企业号
                                  strWarehose_No  in odata_outstock_m.warehouse_no%type, --仓别
                                  strOutstock_No  in odata_outstock_m.outstock_no%type, --下架单号
                                  strDivide_No    in odata_divide_m.divide_no%type,  --分播单号
                                  strS_Label_No   in odata_outstock_d.label_no%type, --来源标签号码
                                  strD_Label_No   in odata_outstock_d.d_container_no%type, --目的标签号
                                  strDeliver_Obj  in odata_outstock_d.deliver_obj%type, --配送对象
                                  strArticle_No   in odata_outstock_d.article_no%type, --商品编码
                                  nPacking_QTY    in odata_outstock_d.packing_qty%type, --包装数量
                                  strSCell_No     in odata_outstock_d.s_cell_no%type, --来源储位
                                  nArticleQty     in odata_outstock_d.article_qty%type, -- 计划数量
                                  nReal_QTY       in odata_outstock_d.article_qty%type, --下架数量
                                  strQuality      in idata_check_d.quality%type, --品质
                                  dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                                  dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                                  strLotNo        in stock_article_info.lot_no%type, --批次号
                                  strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                                  strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                                  strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                                  strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                                  strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                                  strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                                  strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                                  strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                                  strUserID       in odata_outstock_m.rgst_name%type, --回单人
                                  strOutstock_ID  in odata_outstock_d.outstock_name%type, --下架人
                                  strInstock_ID   in odata_outstock_d.instock_name%type, --上架人
                                  strOutMsg       out varchar2);
end PKLG_ODATA_LICH;


/

