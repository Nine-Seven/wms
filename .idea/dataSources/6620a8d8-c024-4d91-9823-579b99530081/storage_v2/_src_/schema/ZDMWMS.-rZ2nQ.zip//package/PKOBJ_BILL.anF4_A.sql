create package        PKOBJ_BILL is
  /***********************************************************************************************
  wyf
  20150630
  功能说明：根据取值策略生成消费清单
  ***********************************************************************************************/
  procedure P_GENERATE_CONSUMERLIST(strEnterprise_no bill_formulaset.enterprise_no%type, --企业
                                    strWarehouse_no  bill_formulaset.warehouse_no%type, --仓别
                                    strOwner_no      bill_formulaset.owner_no%type, --货主
                                    dtDate           bill_expenses_list.begin_date%type, --生成日期
                                    strFlag          varchar2, --0:代表正常日结生成，1：代表重算
                                    strOutMsg        out varchar2);

  /***********************************************************************************************
  wyf
  20150630
  功能说明：根据取值策略生成固定费用类型的消费清单
  ***********************************************************************************************/
  procedure P_GCLD_FIXED(strEnterprise_no   bill_formulaset.enterprise_no%type, --企业
                         strWarehouse_no    bill_formulaset.warehouse_no%type, --仓别
                         strOwner_no        bill_formulaset.owner_no%type, --货主
                         strBilling_project bill_formulaset.billing_project%type, --计费项目
                         strBillingType     bill_formulaset.billing_type%type, --计费项目类型
                         dtBeginDate        bill_formulaset.rgst_date%type, --开始日期
                         dtEndDate          bill_formulaset.rgst_date%type, --开始日期
                         strOutMsg          out varchar2);

  /***********************************************************************************************
  wyf
  20150630
  功能说明：根据取值策略生成动态费用类型的消费清单
  ***********************************************************************************************/
  procedure P_GCLD_DYNAMIC(strEnterprise_no   bill_formulaset.enterprise_no%type, --企业
                           strWarehouse_no    bill_formulaset.warehouse_no%type, --仓别
                           strOwner_no        bill_formulaset.owner_no%type, --货主
                           strBilling_project bill_formulaset.billing_project%type, --计费项目
                           strBillingType     bill_formulaset.billing_type%type, --计费项目类型
                           dtBeginDate        bill_formulaset.rgst_date%type, --开始日期
                           dtEndDate          bill_formulaset.rgst_date%type, --开始日期
                           strOutMsg          out varchar2);
  /***********************************************************************************************
  wyf
  20150630
  功能说明：获取验收相关消费数据
  ***********************************************************************************************/
  procedure P_GETICGCLD(strEnterprise_no bill_formulaset.enterprise_no%type, --企业
                        strWarehouse_no  bill_formulaset.warehouse_no%type, --仓别
                        strOwner_no      bill_formulaset.owner_no%type, --货主
                        strBilling_unit  bill_formulaset.billing_unit%type, --计费单位
                        strValue_flag    bill_formulaset.Value_Flag%type, --取值方式
                        dtBeginDate      bill_formulaset.rgst_date%type, --开始日期
                        dtEndDate        bill_formulaset.rgst_date%type, --开始日期
                        strFamilyNo      bill_family_unit_price.family_no%type, --商品群组
                        nQty             OUT bill_expenses_list.qty%type, --数量
                        nVolume          OUT bill_expenses_list.volume%type, --体积
                        nWeight          OUT bill_expenses_list.weight%type, --重量
                        strOutMsg        out varchar2);
  /***********************************************************************************************
  wyf
  20150630
  功能说明：获取上架相关消费数据
  ***********************************************************************************************/
  procedure P_GETINGCLD(strEnterprise_no bill_formulaset.enterprise_no%type, --企业
                        strWarehouse_no  bill_formulaset.warehouse_no%type, --仓别
                        strOwner_no      bill_formulaset.owner_no%type, --货主
                        strBilling_unit  bill_formulaset.billing_unit%type, --计费单位
                        strValue_flag    bill_formulaset.Value_Flag%type, --取值方式
                        dtBeginDate      bill_formulaset.rgst_date%type, --开始日期
                        dtEndDate        bill_formulaset.rgst_date%type, --开始日期
                        strFamilyNo      bill_family_unit_price.family_no%type, --商品群组
                        nQty             OUT bill_expenses_list.qty%type, --数量
                        nVolume          OUT bill_expenses_list.volume%type, --体积
                        nWeight          OUT bill_expenses_list.weight%type, --重量
                        strOutMsg        out varchar2);
  /***********************************************************************************************
  wyf
  20150630
  功能说明：获取拣货相关消费数据
  ***********************************************************************************************/
  procedure P_GETHOGCLD(strEnterprise_no bill_formulaset.enterprise_no%type, --企业
                        strWarehouse_no  bill_formulaset.warehouse_no%type, --仓别
                        strOwner_no      bill_formulaset.owner_no%type, --货主
                        strBilling_unit  bill_formulaset.billing_unit%type, --计费单位
                        strValue_flag    bill_formulaset.Value_Flag%type, --取值方式
                        dtBeginDate      bill_formulaset.rgst_date%type, --开始日期
                        dtEndDate        bill_formulaset.rgst_date%type, --开始日期
                        strFamilyNo      bill_family_unit_price.family_no%type, --商品群组
                        nQty             OUT bill_expenses_list.qty%type, --数量
                        nVolume          OUT bill_expenses_list.volume%type, --体积
                        nWeight          OUT bill_expenses_list.weight%type, --重量
                        strOutMsg        out varchar2);
  /***********************************************************************************************
  wyf
  20150630
  功能说明：获取返配验收相关消费数据
  ***********************************************************************************************/
  procedure P_GETRICGCLD(strEnterprise_no bill_formulaset.enterprise_no%type, --企业
                         strWarehouse_no  bill_formulaset.warehouse_no%type, --仓别
                         strOwner_no      bill_formulaset.owner_no%type, --货主
                         strBilling_unit  bill_formulaset.billing_unit%type, --计费单位
                         strValue_flag    bill_formulaset.Value_Flag%type, --取值方式
                         dtBeginDate      bill_formulaset.rgst_date%type, --开始日期
                         dtEndDate        bill_formulaset.rgst_date%type, --开始日期
                         strFamilyNo      bill_family_unit_price.family_no%type, --商品群组
                         nQty             OUT bill_expenses_list.qty%type, --数量
                         nVolume          OUT bill_expenses_list.volume%type, --体积
                         nWeight          OUT bill_expenses_list.weight%type, --重量
                         strOutMsg        out varchar2);
  /***********************************************************************************************
  wyf
  20150630
  功能说明：获取装卸相关消费数据
  ***********************************************************************************************/
  procedure P_GETLOCGCLD(strEnterprise_no bill_formulaset.enterprise_no%type, --企业
                         strWarehouse_no  bill_formulaset.warehouse_no%type, --仓别
                         strOwner_no      bill_formulaset.owner_no%type, --货主
                         strBilling_unit  bill_formulaset.billing_unit%type, --计费单位
                         strValue_flag    bill_formulaset.Value_Flag%type, --取值方式
                         dtBeginDate      bill_formulaset.rgst_date%type, --开始日期
                         dtEndDate        bill_formulaset.rgst_date%type, --开始日期
                         strFamilyNo      bill_family_unit_price.family_no%type, --商品群组
                         nQty             OUT bill_expenses_list.qty%type, --数量
                         nVolume          OUT bill_expenses_list.volume%type, --体积
                         nWeight          OUT bill_expenses_list.weight%type, --重量
                         strOutMsg        out varchar2);
  /***********************************************************************************************
  wyf
  20150630
  功能说明：获取冷藏费相关消费数据
  ***********************************************************************************************/
  procedure P_GETLCFGCLD(strEnterprise_no bill_formulaset.enterprise_no%type, --企业
                         strWarehouse_no  bill_formulaset.warehouse_no%type, --仓别
                         strOwner_no      bill_formulaset.owner_no%type, --货主
                         strBilling_unit  bill_formulaset.billing_unit%type, --计费单位
                         strValue_flag    bill_formulaset.Value_Flag%type, --取值方式
                         dtBeginDate      bill_formulaset.rgst_date%type, --开始日期
                         dtEndDate        bill_formulaset.rgst_date%type, --开始日期
                         strFamilyNo      bill_family_unit_price.family_no%type, --商品群组
                         nQty             OUT bill_expenses_list.qty%type, --数量
                         nVolume          OUT bill_expenses_list.volume%type, --体积
                         nWeight          OUT bill_expenses_list.weight%type, --重量
                         strOutMsg        out varchar2);
  /***********************************************************************************************
  lich
  20140729
  功能说明：仓租根据取值策略生成消费清单
  ***********************************************************************************************/
  procedure P_ALLGCLD(strEnterprise_no bill_formulaset.enterprise_no%type, --企业
                      strWarehouse_no  bill_formulaset.warehouse_no%type, --仓别
                      strOwner_no      bill_formulaset.owner_no%type, --货主
                      strBilling_unit  bill_formulaset.billing_unit%type, --计费单位
                      strValue_flag    bill_formulaset.Value_Flag%type, --取值方式
                      dtBeginDate      bill_formulaset.rgst_date%type, --开始日期
                      dtEndDate        bill_formulaset.rgst_date%type, --开始日期
                      strFamilyNo      bill_family_unit_price.family_no%type, --商品群组
                      nQty             OUT bill_expenses_list.qty%type, --数量
                      nVolume          OUT bill_expenses_list.volume%type, --体积
                      nWeight          OUT bill_expenses_list.weight%type, --重量
                      strOutMsg        out varchar2); --返回值
  /***********************************************************************************************
  lich
  20140729
  功能说明：根据消费清单生成费用明细表
  ***********************************************************************************************/
  procedure P_GENERATE_COST_DETAILS(strEnterprise_no bill_formulaset.enterprise_no%type, --企业
                                    strWarehouse_no  bill_formulaset.warehouse_no%type, --仓别
                                    strOwner_no      bill_formulaset.owner_no%type, --货主
                                    dtBilling_date   bill_formulaset.rgst_date%type, --开始日期
                                    strOutMsg        out varchar2); --返回值
  /***********************************************************************************************
  lich
  20140729
  功能说明：根据消费清单生成费用明细表
  ***********************************************************************************************/
  procedure P_GENERATE_FINANCIAL_DETAILS(strEnterprise_no bill_formulaset.enterprise_no%type, --企业
                                         strWarehouse_no  bill_formulaset.warehouse_no%type, --仓别
                                         strOwner_no      bill_formulaset.owner_no%type, --货主
                                         strMonth         varchar, --月份
                                         strOutMsg        out varchar2);
  /***********************************************************************************************
  wyf
  20150727
  功能说明：生成计费
  ***********************************************************************************************/
  procedure P_GENERATE_BILL;
  /***********************************************************************************************
   hcx
    20151108
    功能说明：基础费用校验结算日期
  ***********************************************************************************************/

  procedure P_AmountDateCheck(strEnterpriseNo   bill_base_amount.enterprise_no%type, --企业
                           strWarehouseNo    bill_base_amount.warehouse_no%type, --仓别
                           strOwnerNo        bill_base_amount.owner_no%type, --货主
                           strBillingProject bill_base_amount.billing_project%type, --计费项目
                           strBillingCycle     bill_formulaset.billing_cycle%type, --计费周期
                           dtAmountDate       bill_base_amount.amount_date%type, --结算日期
                           strResult          out varchar2);
end PKOBJ_BILL;


/

