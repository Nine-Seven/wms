create package body        PKOBJ_ODISPATCH is

  --------------------------------------------------------
  --定位明细转历史
  procedure p_close_locate_d(strEnterpriseNo in odata_locate_m.enterprise_no%type,
                             strWareHouseNo  in varchar2, --仓库代码
                             strWaveNo       in varchar2, --定位号
                             nGroupNo        in number, --出货组号
                             strWorkNo       in varchar2, --员工代码
                             strErrorMsg     out varchar2) is
  begin
    strErrorMsg := 'N|[p_close_locate_d]';

    insert into ODATA_LOCATE_DHTY
      (enterprise_no,
       warehouse_no,
       owner_no,
       wave_no,
       row_id,
       cust_no,
       sub_cust_no,
       exp_no,
       article_no,
       plan_qty,
       located_qty,
       status,
       line_no,
       batch_no,
       b_out_flag,
       priority,
       add_exp_no,
       produce_condition,
       produce_value1,
       produce_value2,
       expire_condition,
       expire_value1,
       expire_value2,
       quality_condition,
       quality_value1,
       quality_value2,
       lotno_condition,
       lotno_value1,
       lotno_value2,
       rsvbatch1_condition,
       rsvbatch1_value1,
       rsvbatch1_value2,
       rsvbatch2_condition,
       rsvbatch2_value1,
       rsvbatch2_value2,
       rsvbatch3_condition,
       rsvbatch3_value1,
       rsvbatch3_value2,
       rsvbatch4_condition,
       rsvbatch4_value1,
       rsvbatch4_value2,
       rsvbatch5_condition,
       rsvbatch5_value1,
       rsvbatch5_value2,
       rsvbatch6_condition,
       rsvbatch6_value1,
       rsvbatch6_value2,
       rsvbatch7_condition,
       rsvbatch7_value1,
       rsvbatch7_value2,
       rsvbatch8_condition,
       rsvbatch8_value1,
       rsvbatch8_value2,
       specify_field,
       specify_condition,
       specify_value1,
       specify_value2,
       exp_date,
       plan_export_qty,
       export_qty,
       import_no,
       stock_type,
       trans_group_no,
       DELIVER_OBJ)
      select enterprise_no,
             warehouse_no,
             owner_no,
             wave_no,
             row_id,
             cust_no,
             sub_cust_no,
             exp_no,
             article_no,
             plan_qty,
             located_qty,
             13,
             line_no,
             batch_no,
             b_out_flag,
             priority,
             add_exp_no,
             produce_condition,
             produce_value1,
             produce_value2,
             expire_condition,
             expire_value1,
             expire_value2,
             quality_condition,
             quality_value1,
             quality_value2,
             lotno_condition,
             lotno_value1,
             lotno_value2,
             rsvbatch1_condition,
             rsvbatch1_value1,
             rsvbatch1_value2,
             rsvbatch2_condition,
             rsvbatch2_value1,
             rsvbatch2_value2,
             rsvbatch3_condition,
             rsvbatch3_value1,
             rsvbatch3_value2,
             rsvbatch4_condition,
             rsvbatch4_value1,
             rsvbatch4_value2,
             rsvbatch5_condition,
             rsvbatch5_value1,
             rsvbatch5_value2,
             rsvbatch6_condition,
             rsvbatch6_value1,
             rsvbatch6_value2,
             rsvbatch7_condition,
             rsvbatch7_value1,
             rsvbatch7_value2,
             rsvbatch8_condition,
             rsvbatch8_value1,
             rsvbatch8_value2,
             specify_field,
             specify_condition,
             specify_value1,
             specify_value2,
             exp_date,
             plan_export_qty,
             export_qty,
             import_no,
             stock_type,
             trans_group_no,
             DELIVER_OBJ
        from ODATA_LOCATE_D od
       where od.warehouse_no = strWareHouseNo
         and od.enterprise_no = strEnterpriseNo
         and od.wave_no = strWaveNo
         and od.TRANS_GROUP_NO = nGroupNo;

    delete odata_locate_d od
     where od.warehouse_no = strWareHouseNo
       and od.enterprise_no = strEnterpriseNo
       and od.wave_no = strWaveNo
       and od.TRANS_GROUP_NO = nGroupNo;

    strErrorMsg := 'Y|成功!';
  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_close_locate_d;

  --------------------------------------------------------
  --关闭定位单头档
  procedure p_close_locate_m(strEnterpriseNo in odata_locate_m.enterprise_no%type,
                             strWareHouseNo  in varchar2, --仓库代码
                             strWaveNo       in varchar2, --定位号
                             strWorkNo       in varchar2, --员工代码
                             strErrorMsg     out varchar2) is
  begin
    strErrorMsg := 'N|[p_close_locate_m]';

    insert into ODATA_LOCATE_MHTY
      (enterprise_no,
       warehouse_no,
       owner_no,
       wave_no,
       exp_type,
       exp_date,
       status,
       locate_name,
       locate_date,
       source_type,
       org_no,
       INDUSTRY_FLAG)
      SELECT enterprise_no,
             warehouse_no,
             owner_no,
             wave_no,
             exp_type,
             exp_date,
             '13',
             locate_name,
             locate_date,
             source_type,
             org_no,
             INDUSTRY_FLAG
        from odata_locate_m om
       where om.warehouse_no = strWareHouseNo
         and om.enterprise_no = strEnterpriseNo
         and om.wave_no = strWaveNo;

    delete odata_locate_m om
     where om.warehouse_no = strWareHouseNo
       and om.enterprise_no = strEnterpriseNo
       and om.wave_no = strWaveNo;

    strErrorMsg := 'Y|成功!';
  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_close_locate_m;

  /*****************************************************************************************
     功能：新增出货定位指示头 （按波次）
  *****************************************************************************************/
  PROCEDURE P_INS_O_LOCATE_M(STRENTERPRISENO  IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                             STRWAREHOUSENO   IN ODATA_LOCATE_M.WAREHOUSE_NO%TYPE, --仓别
                             STROWNERNO       IN ODATA_LOCATE_M.OWNER_NO%TYPE, --货主
                             STROrg_No        IN ODATA_LOCATE_M.Org_No%TYPE, --机构
                             STRWAVENO        IN ODATA_LOCATE_M.WAVE_NO%TYPE, --波次号
                             STREXPTYPE       IN ODATA_LOCATE_M.EXP_TYPE%TYPE, --类型
                             STRLOCATENAME    IN ODATA_LOCATE_M.LOCATE_NAME%TYPE, --集单人
                             STRSOURCETYPE    IN ODATA_LOCATE_M.SOURCE_TYPE%TYPE, --
                             STRIndustry_Flag IN ODATA_LOCATE_M.Industry_Flag%TYPE, --行业标识
                             STRRESULT        OUT VARCHAR2) IS

  BEGIN
    STRRESULT := 'N|[P_INS_O_LOCATE_M]';

    --锁定出货指示单头
    UPDATE ODATA_LOCATE_M M
       SET M.STATUS = M.STATUS
     WHERE M.WAREHOUSE_NO = STRWAREHOUSENO
       AND M.ENTERPRISE_NO = STRENTERPRISENO
       AND M.WAVE_NO = STRWAVENO;

    --插入出货指示单头
    IF SQL%ROWCOUNT <= 0 THEN
      INSERT INTO ODATA_LOCATE_M
        (ENTERPRISE_NO,
         WAREHOUSE_NO,
         OWNER_NO,
         WAVE_NO,
         EXP_TYPE,
         EXP_DATE,
         STATUS,
         LOCATE_NAME,
         LOCATE_DATE,
         SOURCE_TYPE,
         org_no,
         industry_flag)
      VALUES
        (STRENTERPRISENO,
         STRWAREHOUSENO,
         STROWNERNO,
         STRWAVENO,
         STREXPTYPE,
         TRUNC(SYSDATE),
         '10',
         STRLOCATENAME,
         SYSDATE,
         STRSOURCETYPE,
         STROrg_No,
         STRIndustry_Flag);

      IF SQL%ROWCOUNT <= 0 THEN
        STRRESULT := 'N|[E21702]';
        RETURN;
      END IF;

    END IF;
    STRRESULT := 'Y|[E21701]'; --成功

  EXCEPTION
    WHEN OTHERS THEN
      STRRESULT := 'N|' || SQLERRM ||
                   SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
  END P_INS_O_LOCATE_M;

  /*****************************************************************************************
     功能：新增出货定位指示头 （按波次）
  *****************************************************************************************/
  PROCEDURE P_INS_O_LOCATE_D(STRENTERPRISENO IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                             STRWAREHOUSENO  IN ODATA_LOCATE_D.WAREHOUSE_NO%TYPE,
                             STRWAVENO       IN ODATA_LOCATE_D.WAVE_NO%TYPE,
                             STREXPTYPE      IN ODATA_EXP_M.EXP_TYPE%TYPE,
                             STRIP           IN VARCHAR2,
                             STRRESULT       OUT VARCHAR2) IS
  BEGIN
    STRRESULT := 'N|[P_INS_O_LOCATE_D]';

    --锁定指示明细表
    UPDATE ODATA_LOCATE_M D
       SET D.STATUS = D.STATUS
     WHERE D.WAREHOUSE_NO = STRWAREHOUSENO
       AND D.ENTERPRISE_NO = STRENTERPRISENO
       AND D.WAVE_NO = STRWAVENO;

    --插入指示明细
    INSERT INTO ODATA_LOCATE_D
      (WAREHOUSE_NO,
       OWNER_NO,
       WAVE_NO,
       ROW_ID,
       CUST_NO,
       SUB_CUST_NO,
       EXP_NO,
       ARTICLE_NO,
       PLAN_QTY,
       LOCATED_QTY,
       STATUS,
       LINE_NO,
       BATCH_NO,
       B_OUT_FLAG,
       PRIORITY,
       ADD_EXP_NO,
       PRODUCE_CONDITION,
       PRODUCE_VALUE1,
       PRODUCE_VALUE2,
       EXPIRE_CONDITION,
       EXPIRE_VALUE1,
       EXPIRE_VALUE2,
       QUALITY_CONDITION,
       QUALITY_VALUE1,
       QUALITY_VALUE2,
       LOTNO_CONDITION,
       LOTNO_VALUE1,
       LOTNO_VALUE2,
       RSVBATCH1_CONDITION,
       RSVBATCH1_VALUE1,
       RSVBATCH1_VALUE2,
       RSVBATCH2_CONDITION,
       RSVBATCH2_VALUE1,
       RSVBATCH2_VALUE2,
       RSVBATCH3_CONDITION,
       RSVBATCH3_VALUE1,
       RSVBATCH3_VALUE2,
       RSVBATCH4_CONDITION,
       RSVBATCH4_VALUE1,
       RSVBATCH4_VALUE2,
       RSVBATCH5_CONDITION,
       RSVBATCH5_VALUE1,
       RSVBATCH5_VALUE2,
       RSVBATCH6_CONDITION,
       RSVBATCH6_VALUE1,
       RSVBATCH6_VALUE2,
       RSVBATCH7_CONDITION,
       RSVBATCH7_VALUE1,
       RSVBATCH7_VALUE2,
       RSVBATCH8_CONDITION,
       RSVBATCH8_VALUE1,
       RSVBATCH8_VALUE2,
       SPECIFY_FIELD,
       SPECIFY_CONDITION,
       SPECIFY_VALUE1,
       SPECIFY_VALUE2,
       EXP_DATE,
       PLAN_EXPORT_QTY,
       EXPORT_QTY,
       IMPORT_NO,
       STOCK_TYPE,
       TRANS_GROUP_NO,
       ENTERPRISE_NO,
       DELIVER_OBJ)
      SELECT STRWAREHOUSENO,
             OEM.OWNER_NO,
             STRWAVENO,
             ROWNUM,
             OEM.CUST_NO,
             OEM.SUB_CUST_NO,
             OEM.EXP_NO,
             OED.ARTICLE_NO,
             OED.ARTICLE_QTY,
             OED.LOCATE_QTY,
             10,
             OTLS.LINE_NO,
             OTLS.BATCH_NO,
             1,
             100,
             'N',
             OED.PRODUCE_CONDITION,
             OED.PRODUCE_VALUE1,
             OED.PRODUCE_VALUE2,
             OED.EXPIRE_CONDITION,
             OED.EXPIRE_VALUE1,
             OED.EXPIRE_VALUE2,
             OED.QUALITY_CONDITION,
             OED.QUALITY_VALUE1,
             OED.QUALITY_VALUE2,
             OED.LOTNO_CONDITION,
             OED.LOTNO_VALUE1,
             OED.LOTNO_VALUE2,
             OED.RSVBATCH1_CONDITION,
             OED.RSVBATCH1_VALUE1,
             OED.RSVBATCH1_VALUE2,
             OED.RSVBATCH2_CONDITION,
             OED.RSVBATCH2_VALUE1,
             OED.RSVBATCH2_VALUE2,
             OED.RSVBATCH3_CONDITION,
             OED.RSVBATCH3_VALUE1,
             OED.RSVBATCH3_VALUE2,
             OED.RSVBATCH4_CONDITION,
             OED.RSVBATCH4_VALUE1,
             OED.RSVBATCH4_VALUE2,
             OED.RSVBATCH5_CONDITION,
             OED.RSVBATCH5_VALUE1,
             OED.RSVBATCH5_VALUE2,
             OED.RSVBATCH6_CONDITION,
             OED.RSVBATCH6_VALUE1,
             OED.RSVBATCH6_VALUE2,
             OED.RSVBATCH7_CONDITION,
             OED.RSVBATCH7_VALUE1,
             OED.RSVBATCH7_VALUE2,
             OED.RSVBATCH8_CONDITION,
             OED.RSVBATCH8_VALUE1,
             OED.RSVBATCH8_VALUE2,
             OED.SPECIFY_FIELD,
             OED.SPECIFY_CONDITION,
             OED.SPECIFY_VALUE1,
             OED.SPECIFY_VALUE2,
             SYSDATE,
             0,
             0,
             OEM.IMPORT_NO,
             '1',
             0,
             STRENTERPRISENO,
             'N'
        FROM ODATA_EXP_M OEM, ODATA_EXP_D OED, ODATA_TMP_LOCATE_SELECT OTLS
       WHERE OEM.ENTERPRISE_NO = OED.ENTERPRISE_NO
         AND OEM.WAREHOUSE_NO = OED.WAREHOUSE_NO
         AND OEM.OWNER_NO = OED.OWNER_NO
         AND OEM.EXP_NO = OED.EXP_NO
         AND OEM.EXP_TYPE = STREXPTYPE
         AND OEM.WAREHOUSE_NO = STRWAREHOUSENO
         AND OEM.ENTERPRISE_NO = STRENTERPRISENO
            --AND OEM.EXP_NO = STREXPNO
         AND OEM.STATUS = '10'
         AND OEM.EXP_NO = OTLS.EXP_NO
         AND OEM.WAREHOUSE_NO = OTLS.WAREHOUSE_NO
         AND OEM.ENTERPRISE_NO = OTLS.ENTERPRISE_NO
         AND OEM.OWNER_NO = OTLS.OWNER_NO
         AND OTLS.TMP_ID = STRIP
       GROUP BY STRWAREHOUSENO,
                OEM.OWNER_NO,
                STRWAVENO,
                ROWNUM,
                OEM.CUST_NO,
                OEM.SUB_CUST_NO,
                OEM.EXP_NO,
                OED.ARTICLE_NO,
                OED.ARTICLE_QTY,
                OED.LOCATE_QTY,
                10,
                OTLS.LINE_NO,
                OTLS.BATCH_NO,
                1,
                100,
                'N',
                OED.PRODUCE_CONDITION,
                OED.PRODUCE_VALUE1,
                OED.PRODUCE_VALUE2,
                OED.EXPIRE_CONDITION,
                OED.EXPIRE_VALUE1,
                OED.EXPIRE_VALUE2,
                OED.QUALITY_CONDITION,
                OED.QUALITY_VALUE1,
                OED.QUALITY_VALUE2,
                OED.LOTNO_CONDITION,
                OED.LOTNO_VALUE1,
                OED.LOTNO_VALUE2,
                OED.RSVBATCH1_CONDITION,
                OED.RSVBATCH1_VALUE1,
                OED.RSVBATCH1_VALUE2,
                OED.RSVBATCH2_CONDITION,
                OED.RSVBATCH2_VALUE1,
                OED.RSVBATCH2_VALUE2,
                OED.RSVBATCH3_CONDITION,
                OED.RSVBATCH3_VALUE1,
                OED.RSVBATCH3_VALUE2,
                OED.RSVBATCH4_CONDITION,
                OED.RSVBATCH4_VALUE1,
                OED.RSVBATCH4_VALUE2,
                OED.RSVBATCH5_CONDITION,
                OED.RSVBATCH5_VALUE1,
                OED.RSVBATCH5_VALUE2,
                OED.RSVBATCH6_CONDITION,
                OED.RSVBATCH6_VALUE1,
                OED.RSVBATCH6_VALUE2,
                OED.RSVBATCH7_CONDITION,
                OED.RSVBATCH7_VALUE1,
                OED.RSVBATCH7_VALUE2,
                OED.RSVBATCH8_CONDITION,
                OED.RSVBATCH8_VALUE1,
                OED.RSVBATCH8_VALUE2,
                OED.SPECIFY_FIELD,
                OED.SPECIFY_CONDITION,
                OED.SPECIFY_VALUE1,
                OED.SPECIFY_VALUE2,
                SYSDATE,
                0,
                0,
                OEM.IMPORT_NO,
                '1',
                0,
                STRENTERPRISENO,
                'N';

    IF SQL%ROWCOUNT <= 0 THEN
      STRRESULT := 'N|[E21703]';
      RETURN;
    END IF;

    STRRESULT := 'Y|[E21701]'; --成功

  EXCEPTION
    WHEN OTHERS THEN
      STRRESULT := 'N|' || SQLERRM ||
                   SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);

  END P_INS_O_LOCATE_D;

  /**********************************************************************************************************
    chensr
    2015.1.19
    功能：根据出货单号添加临时表数据
  ***********************************************************************************************************/

  procedure P_Insert_TmpLocateForExpNo(strTmpId            in odata_tmp_locate_select.tmp_id%type,
                                       strCurrEnterpriseNo in odata_tmp_locate_select.enterprise_no%type,
                                       strWareHouseNo      in odata_tmp_locate_select.warehouse_no%type,
                                       strOwnerNo          in odata_tmp_locate_select.owner_no%type,
                                       strLineNo           in odata_tmp_locate_select.line_no%type,
                                       strBatchNo          in odata_tmp_locate_select.batch_no%type,
                                       strExpNo            in odata_tmp_locate_select.exp_no%type,
                                       strVolume           in odata_tmp_locate_select.volume%type,
                                       strWeigth           in odata_tmp_locate_select.weight%type,
                                       strQbox             in odata_tmp_locate_select.qbox%type,
                                       strResult           out varchar2) is
  begin
    strResult := 'Y';
    P_Delete_TmpLocateForExpNo(strTmpId,
                               strCurrEnterpriseNo,
                               strWareHouseNo,
                               strOwnerNo,
                               strLineNo,
                               strBatchNo,
                               strExpNo,
                               strResult);
    insert into odata_tmp_locate_select
      (tmp_id,
       enterprise_no,
       warehouse_no,
       owner_no,
       line_no,
       batch_no,
       exp_no,
       volume,
       weight,
       qbox)
    values
      (strTmpId,
       strCurrEnterpriseNo,
       strWareHouseNo,
       strOwnerNo,
       strLineNo,
       strBatchNo,
       strExpNo,
       strVolume,
       strWeigth,
       strQbox);

    if sql%rowcount <= 0 then
      --新增失败
      strResult := 'N';
      return;
    end if;
    strResult := 'Y';

  end P_Insert_TmpLocateForExpNo;

  /**********************************************************************************************************
  chensr
  2015.1.19
  功能：根据客户添加临时表数据
  ***********************************************************************************************************/
  procedure P_Insert_TmpLocateForCust(strTmpId            in odata_tmp_locate_select.tmp_id%type,
                                      strCurrEnterpriseNo in odata_tmp_locate_select.enterprise_no%type,
                                      strWareHouseNo      in odata_tmp_locate_select.warehouse_no%type,
                                      strOwnerNo          in odata_tmp_locate_select.owner_no%type,
                                      strLineNo           in odata_tmp_locate_select.line_no%type,
                                      strBatchNo          in odata_tmp_locate_select.batch_no%type,
                                      strCustNo           in varchar2,
                                      strVolume           in odata_tmp_locate_select.volume%type,
                                      strWeigth           in odata_tmp_locate_select.weight%type,
                                      strQbox             in odata_tmp_locate_select.qbox%type,
                                      strResult           out varchar2) is
  begin
    strResult := 'Y';
    P_Delete_TmpLocateForCust(strTmpId,
                              strCurrEnterpriseNo,
                              strWareHouseNo,
                              strOwnerNo,
                              strLineNo,
                              strBatchNo,
                              strCustNo,
                              strResult);

    insert into odata_tmp_locate_select
      (tmp_id,
       enterprise_no,
       warehouse_no,
       owner_no,
       line_no,
       batch_no,
       exp_no,
       volume,
       weight,
       qbox)
      select strTmpId,
             strCurrEnterpriseNo,
             strWareHouseNo,
             strOwnerNo,
             strLineNo,
             strBatchNo,
             m.exp_no,
             strVolume,
             strWeigth,
             strQbox
        from odata_exp_m m
       where m.status = '10'
         and m.cust_no = strCustNo
         and m.warehouse_no = strWareHouseNo
         and m.enterprise_no = strCurrEnterpriseNo;

    if sql%rowcount <= 0 then
      --新增失败
      strResult := 'N';
      return;
    end if;
    strResult := 'Y';
  end P_Insert_TmpLocateForCust;

  /**********************************************************************************************************
  chensr
  2015.1.19
  功能：根据出货单号删除临时表数据
  ***********************************************************************************************************/
  procedure P_Delete_TmpLocateForExpNo(strTmpId            in odata_tmp_locate_select.tmp_id%type,
                                       strCurrEnterpriseNo in odata_tmp_locate_select.enterprise_no%type,
                                       strWareHouseNo      in odata_tmp_locate_select.warehouse_no%type,
                                       strOwnerNo          in odata_tmp_locate_select.owner_no%type,
                                       strLineNo           in odata_tmp_locate_select.line_no%type,
                                       strBatchNo          in odata_tmp_locate_select.batch_no%type,
                                       strExpNo            in odata_tmp_locate_select.exp_no%type,
                                       strResult           out varchar2) is
  begin
    strResult := 'Y';

    delete from odata_tmp_locate_select otl
     where otl.tmp_id = strTmpId
       and otl.enterprise_no = strCurrEnterpriseNo
       and otl.warehouse_no = strWareHouseNo
       and otl.owner_no = strOwnerNo
       and otl.line_no = strLineNo
       and otl.batch_no = strBatchNo
       and otl.exp_no = strExpNo;

    if sql%rowcount <= 0 then
      --删除失败
      strResult := 'N';
      return;
    end if;
  end P_Delete_TmpLocateForExpNo;

  /**********************************************************************************************************
  chensr
  2015.1.19
  功能：根据客户删除临时表数据
  ***********************************************************************************************************/
  procedure P_Delete_TmpLocateForCust(strTmpId            in odata_tmp_locate_select.tmp_id%type,
                                      strCurrEnterpriseNo in odata_tmp_locate_select.enterprise_no%type,
                                      strWareHouseNo      in odata_tmp_locate_select.warehouse_no%type,
                                      strOwnerNo          in odata_tmp_locate_select.owner_no%type,
                                      strLineNo           in odata_tmp_locate_select.line_no%type,
                                      strBatchNo          in odata_tmp_locate_select.batch_no%type,
                                      strCustNo           in varchar2,
                                      strResult           out varchar2) is

  begin
    strResult := 'Y';

    delete odata_tmp_locate_select otl
     where otl.tmp_id = strTmpId
       and otl.enterprise_no = strCurrEnterpriseNo
       and otl.warehouse_no = strWareHouseNo
       and otl.owner_no = strOwnerNo
       and otl.line_no = strLineNo
       and otl.batch_no = strBatchNo
       and otl.exp_no in
           (select exp_no
              from odata_exp_m
             where cust_no = strCustNo
               and enterprise_no = strCurrEnterpriseNo
               and warehouse_no = strWareHouseNo);
    if sql%rowcount <= 0 then
      --删除失败
      strResult := 'N';
      return;
    end if;
  end P_Delete_TmpLocateForCust;

  /***********************************************************************************************************
  功能说明：更新出货通知单头档
  luozhiling
  2015.04.27
  ***********************************************************************************************************/
  procedure P_Update_Odata_exp_m(strEnterpriseNo in odata_exp_m.enterprise_no%type,
                                 strWareHouseNo  in odata_exp_m.warehouse_no%type,
                                 strExpNo        in odata_exp_m.exp_no%type,
                                 strOldStatus    in odata_exp_m.status%type, --更新前状态
                                 strNewStatus    in odata_exp_m.status%type, --更新后状态
                                 strExpStatus    in odata_exp_m.exp_status%type,
                                 strWorkNo       in varchar2, --员工代码
                                 strErrorMsg     out varchar2) is
  begin
    strErrorMsg := 'N|[P_Update_Odata_exp_m]';

    update odata_exp_m t
       set t.status     = strNewStatus,
           t.exp_status = strExpStatus,
           t.updt_name  = strWorkNo,
           t.updt_date  = sysdate
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWareHouseNo
       and t.exp_no = strExpNo
       and t.status = strOldStatus;

    if sql%notfound then
      strErrorMsg := 'N|[P_Update_Odata_exp_m]';
      return;
    end if;

    strErrorMsg := 'Y|[成功]';
  end P_Update_Odata_exp_m;

  /***********************************************************************************************************
  功能说明：更新出货通知单明细
  luozhiling
  2015.04.27
  ***********************************************************************************************************/
  procedure P_Update_Odata_exp_d(strEnterpriseNo in odata_exp_d.enterprise_no%type,
                                 strWareHouseNo  in odata_exp_d.warehouse_no%type,
                                 strExpNo        in odata_exp_d.exp_no%type,
                                 strNewStatus    in odata_exp_d.status%type, --更新后状态
                                 strWorkNo       in varchar2, --员工代码
                                 strErrorMsg     out varchar2) is
  begin
    strErrorMsg := 'N|[P_Update_Odata_exp_m]';

    update odata_exp_d t
       set t.status = strNewStatus
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWareHouseNo
       and t.exp_no = strExpNo
       and t.status not in ('13');

    if sql%notfound then
      strErrorMsg := 'N|[P_Update_Odata_exp_m]';
      return;
    end if;

    strErrorMsg := 'Y|[成功]';
  end P_Update_Odata_exp_d;

  /***********************************************************************************************************
  功能说明：出货通知单状态跟踪
  jiangchenglong
  2016.06.29
  ***********************************************************************************************************/
  procedure P_Insert_Odata_Exp_Trace(strEnterpriseNo in odata_exp_m.enterprise_no%type,
                                     strWareHouseNo  in odata_exp_m.warehouse_no%type,
                                     strExpNo        in odata_exp_m.exp_no%type,
                                     strExpStatus    in odata_exp_m.exp_status%type, --单据状态
                                     strWorkNo       in varchar2, --员工代码
                                     strErrorMsg     out varchar2) is

    v_nCount        number;
    v_strCurrStatus odata_exp_m.exp_status%type;

  begin
    strErrorMsg := 'N|[P_Insert_Odata_Exp_Trace]';
    v_nCount    := 0;

    select count(1)
      into v_nCount
      from ODATA_EXP_STATUS t
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWareHouseNo
       and t.exp_no = strExpNo;

    --不存在单据，则新增
    if v_nCount <= 0 then
      insert into ODATA_EXP_STATUS
        (enterprise_no,
         Warehouse_No,
         Owner_No,
         Exp_Type,
         Exp_No,
         Curr_Status,
         Rgst_Name,
         Rgst_Date)
        select strEnterpriseNo,
               strWareHouseNo,
               m.owner_no,
               m.exp_type,
               strExpNo,
               strExpStatus,
               strWorkNo,
               sysdate
          from odata_exp_m m
         where m.enterprise_no = strEnterPriseNo
           and m.warehouse_no = strWareHouseNo
           and m.exp_no = strExpNo;

      if sql%notfound then
        strErrorMsg := 'N|[未查询到单据信息]';
        return;
      end if;
    end if;

    if strExpStatus in ('05', '10') then
      --定位分配库存
      update ODATA_EXP_STATUS S
         set s.curr_status = strExpStatus,
             s.locate_date = sysdate,
             s.locate_name = strWorkNo
       where s.enterprise_no = strEnterPriseNo
         and s.warehouse_no = strWareHouseNo
         and s.exp_no = strExpNo;

      if sql%notfound then
        strErrorMsg := 'N|[未更新到单据跟踪信息]';
        return;
      end if;
    elsif strExpStatus in ('15', '20') then
      --发单
      update ODATA_EXP_STATUS S
         set s.curr_status    = strExpStatus,
             s.send_task_date = sysdate,
             s.send_task_name = strWorkNo
       where s.enterprise_no = strEnterPriseNo
         and s.warehouse_no = strWareHouseNo
         and s.exp_no = strExpNo;

      if sql%notfound then
        strErrorMsg := 'N|[未更新到单据跟踪信息]';
        return;
      end if;
    elsif strExpStatus in ('25', '30') then
      --回单
      update ODATA_EXP_STATUS S
         set s.curr_status   = strExpStatus,
             s.outstock_date = sysdate,
             s.outstock_name = strWorkNo
       where s.enterprise_no = strEnterPriseNo
         and s.warehouse_no = strWareHouseNo
         and s.exp_no = strExpNo;

      if sql%notfound then
        strErrorMsg := 'N|[未更新到单据跟踪信息]';
        return;
      end if;
    elsif strExpStatus in ('35', '40') then
      --分播
      update ODATA_EXP_STATUS S
         set s.curr_status = strExpStatus,
             s.divide_date = sysdate,
             s.divide_name = strWorkNo
       where s.enterprise_no = strEnterPriseNo
         and s.warehouse_no = strWareHouseNo
         and s.exp_no = strExpNo;

      if sql%notfound then
        strErrorMsg := 'N|[未更新到单据跟踪信息]';
        return;
      end if;
    elsif strExpStatus in ('45', '50') then
      --复核
      update ODATA_EXP_STATUS S
         set s.curr_status  = strExpStatus,
             s.b_check_date = sysdate,
             s.b_check_name = strWorkNo
       where s.enterprise_no = strEnterPriseNo
         and s.warehouse_no = strWareHouseNo
         and s.exp_no = strExpNo;

      if sql%notfound then
        strErrorMsg := 'N|[未更新到单据跟踪信息]';
        return;
      end if;
    elsif strExpStatus in ('55', '60') then
      --装车
      update ODATA_EXP_STATUS S
         set s.curr_status  = strExpStatus,
             s.loadcar_date = sysdate,
             s.loadcar_name = strWorkNo
       where s.enterprise_no = strEnterPriseNo
         and s.warehouse_no = strWareHouseNo
         and s.exp_no = strExpNo;

      if sql%notfound then
        strErrorMsg := 'N|[未更新到单据跟踪信息]';
        return;
      end if;
    elsif strExpStatus in ('65', '70') then
      --封车
      update ODATA_EXP_STATUS S
         set s.curr_status = strExpStatus,
             s.close_date  = sysdate,
             s.close_name  = strWorkNo
       where s.enterprise_no = strEnterPriseNo
         and s.warehouse_no = strWareHouseNo
         and s.exp_no = strExpNo;

      if sql%notfound then
        strErrorMsg := 'N|[未更新到单据跟踪信息]';
        return;
      end if;
    elsif strExpStatus in ('90') then
      --取消
      update ODATA_EXP_STATUS S
         set s.curr_status = strExpStatus,
             s.cancle_date = sysdate,
             s.cancle_name = strWorkNo
       where s.enterprise_no = strEnterPriseNo
         and s.warehouse_no = strWareHouseNo
         and s.exp_no = strExpNo;

      if sql%notfound then
        strErrorMsg := 'N|[未更新到单据跟踪信息]';
        return;
      end if;
    elsif strExpStatus in ('98', '99') then
      --转病单
      update ODATA_EXP_STATUS S
         set s.curr_status = strExpStatus,
             s.sick_date   = sysdate,
             s.sick_name   = strWorkNo
       where s.enterprise_no = strEnterPriseNo
         and s.warehouse_no = strWareHouseNo
         and s.exp_no = strExpNo;

      if sql%notfound then
        strErrorMsg := 'N|[未更新到单据跟踪信息]';
        return;
      end if;
    elsif v_nCount > 0 then
      strErrorMsg := 'N|[输入状态[' || strExpStatus || ']不正确]';
      return;
    end if;

    --获取当前出货单状态
   --获取当前出货单状态
    begin
    select t.exp_status
      into v_strCurrStatus
      from odata_exp_m t
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWareHouseNo
       and t.exp_no = strExpNo;
    exception
      when no_data_found then
         strErrorMsg := 'N|单据状态跟踪失败，单号[' || strExpNo || ']不存在';
      return;
    end ;

    --如果新状态大于当前状态，则修改出货单头档状态
    if v_strCurrStatus < strExpStatus or strExpStatus = '00' then
      if strExpStatus <> '00' then
        update odata_exp_m t
           set t.exp_status = strExpStatus,
               t.updt_name  = strWorkNo,
               t.updt_date  = sysdate
         where t.enterprise_no = strEnterPriseNo
           and t.warehouse_no = strWareHouseNo
           and t.exp_no = strExpNo;
      end if;

      --新增状态日志表
      update ODATA_EXP_STATUS_LOG OESL
         SET OESL.RGST_DATE = SYSDATE, OESL.RGST_NAME = strWorkNo
       where oesl.enterprise_no = strEnterpriseNo
         and oesl.warehouse_no = strWareHouseNo
         and oesl.exp_no = strExpNo
         --Add BY QZH AT 2016-7-27
         and oesl.exp_status=strExpStatus;

      if sql%rowcount <= 0 then
        insert into ODATA_EXP_STATUS_LOG
          (enterprise_no,
           Warehouse_No,
           Owner_No,
           Exp_Type,
           Exp_No,
           exp_Status,
           Rgst_Name,
           Rgst_Date)
          select strEnterpriseNo,
                 strWareHouseNo,
                 m.owner_no,
                 m.exp_type,
                 strExpNo,
                 strExpStatus,
                 strWorkNo,
                 sysdate
            from odata_exp_m m
           where m.enterprise_no = strEnterPriseNo
             and m.warehouse_no = strWareHouseNo
             and m.exp_no = strExpNo;

        if sql%notfound then
          strErrorMsg := 'N|[新增状态日志表未查询到单据信息]';
          return;
        end if;
      end if;
    end if;

    strErrorMsg := 'Y|[成功]';
  end P_Insert_Odata_Exp_Trace;

  /***********************************************************************************************************
  功能说明：更新病单头档
  hekl
  2015.04.28
  ***********************************************************************************************************/
  procedure P_Update_Odata_exp_cancel_m(strEnterpriseNo in odata_exp_m.enterprise_no%type,
                                        strWareHouseNo  in odata_exp_m.warehouse_no%type,
                                        strCancelNo     in odata_exp_cancel_m.cancel_no%type,
                                        strOldStatus    in odata_exp_m.status%type, --更新前状态
                                        strNewStatus    in odata_exp_m.status%type, --更新后状态
                                        strWorkNo       in varchar2, --员工代码
                                        strErrorMsg     out varchar2) is
  begin
    strErrorMsg := 'N|[P_Update_Odata_exp_cancel_m]';

    update odata_exp_cancel_m t
       set t.status    = strNewStatus,
           t.updt_name = strWorkNo,
           t.updt_date = sysdate
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWareHouseNo
       and t.cancel_no = strCancelNo
       and t.status = strOldStatus;

    if sql%notfound then
      strErrorMsg := 'N|[P_Update_Odata_exp_cancel_m]';
      return;
    end if;

    strErrorMsg := 'Y|[成功]';
  end P_Update_Odata_exp_cancel_m;

  /***********************************************************************************************************
  功能说明：更新病单明细
  hekl
  2015.04.28
  ***********************************************************************************************************/
  procedure P_Update_Odata_exp_cancel_d(strEnterpriseNo in odata_exp_d.enterprise_no%type,
                                        strWareHouseNo  in odata_exp_d.warehouse_no%type,
                                        strCancelNo     in odata_exp_cancel_d.cancel_no%type,
                                        strNewStatus    in odata_exp_d.status%type, --更新后状态
                                        strWorkNo       in varchar2, --员工代码
                                        strErrorMsg     out varchar2) is
  begin
    strErrorMsg := 'N|[P_Update_Odata_exp_cancel_d]';

    update odata_exp_cancel_d t
       set t.status = strNewStatus
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWareHouseNo
       and t.cancel_no = strCancelNo
       and t.status not in ('13');

    if sql%notfound then
      strErrorMsg := 'N|[P_Update_Odata_exp_cancel_d]';
      return;
    end if;

    strErrorMsg := 'Y|[成功]';
  end P_Update_Odata_exp_cancel_d;
  /***********************************************************************************************************
  功能说明：自动集单添加明细
  chensr
  2015.05.13
  ***********************************************************************************************************/
  procedure p_Ins_AUTO_LOCATE_D(strEnterpriseNo in odata_locate_m.enterprise_no%type, --企业
                                strWarehouseNo  in odata_locate_d.warehouse_no%type,
                                strWaveNo       in odata_locate_d.wave_no%type,
                                strExpType      in odata_exp_m.exp_type%type,
                                strExpNo        in odata_exp_m.EXP_NO%type,
                                strResult       out varchar2) is

  begin
    strResult := 'N|[p_Ins_O_LOCATE_D]';

    --锁定指示明细表
    update odata_locate_m d
       set d.status = d.status
     where d.warehouse_no = strWarehouseNo
       and d.enterprise_no = strEnterpriseNo
       and d.wave_no = strWaveNo;

    --插入指示明细
    insert into odata_locate_d
      (enterprise_no,
       warehouse_no,
       owner_no,
       wave_no,
       row_id,
       cust_no,
       sub_cust_no,
       exp_no,
       article_no,
       plan_qty,
       located_qty,
       status,
       line_no,
       batch_no,
       b_out_flag,
       priority,
       add_exp_no,
       produce_condition,
       produce_value1,
       produce_value2,
       expire_condition,
       expire_value1,
       expire_value2,
       quality_condition,
       quality_value1,
       quality_value2,
       lotno_condition,
       lotno_value1,
       lotno_value2,
       rsvbatch1_condition,
       rsvbatch1_value1,
       rsvbatch1_value2,
       rsvbatch2_condition,
       rsvbatch2_value1,
       rsvbatch2_value2,
       rsvbatch3_condition,
       rsvbatch3_value1,
       rsvbatch3_value2,
       rsvbatch4_condition,
       rsvbatch4_value1,
       rsvbatch4_value2,
       rsvbatch5_condition,
       rsvbatch5_value1,
       rsvbatch5_value2,
       rsvbatch6_condition,
       rsvbatch6_value1,
       rsvbatch6_value2,
       rsvbatch7_condition,
       rsvbatch7_value1,
       rsvbatch7_value2,
       rsvbatch8_condition,
       rsvbatch8_value1,
       rsvbatch8_value2,
       specify_field,
       specify_condition,
       specify_value1,
       specify_value2,
       exp_date,
       plan_export_qty,
       export_qty,
       import_no,
       stock_type,
       trans_group_no)

      select strEnterpriseNo,
             strWarehouseNo,
             oem.owner_no,
             strWaveNo,
             rownum,
             oem.cust_no,
             oem.sub_cust_no,
             oem.exp_no,
             oed.article_no,
             oed.article_qty,
             oed.locate_qty,
             10,
             oem.line_no,
             oem.batch_no,
             1,
             100,
             'N',
             oed.produce_condition,
             oed.produce_value1,
             oed.produce_value2,
             oed.expire_condition,
             oed.expire_value1,
             oed.expire_value2,
             oed.quality_condition,
             oed.quality_value1,
             oed.quality_value2,
             oed.lotno_condition,
             oed.lotno_value1,
             oed.lotno_value2,
             oed.rsvbatch1_condition,
             oed.rsvbatch1_value1,
             oed.rsvbatch1_value2,
             oed.rsvbatch2_condition,
             oed.rsvbatch2_value1,
             oed.rsvbatch2_value2,
             oed.rsvbatch3_condition,
             oed.rsvbatch3_value1,
             oed.rsvbatch3_value2,
             oed.rsvbatch4_condition,
             oed.rsvbatch4_value1,
             oed.rsvbatch4_value2,
             oed.rsvbatch5_condition,
             oed.rsvbatch5_value1,
             oed.rsvbatch5_value2,
             oed.rsvbatch6_condition,
             oed.rsvbatch6_value1,
             oed.rsvbatch6_value2,
             oed.rsvbatch7_condition,
             oed.rsvbatch7_value1,
             oed.rsvbatch7_value2,
             oed.rsvbatch8_condition,
             oed.rsvbatch8_value1,
             oed.rsvbatch8_value2,
             oed.specify_field,
             oed.specify_condition,
             oed.specify_value1,
             oed.specify_value2,
             sysdate,
             0,
             0,
             oem.import_no,
             1,
             0
        from odata_exp_m oem, odata_exp_d oed
       where oem.enterprise_no = oed.enterprise_no
         and oem.warehouse_no = oed.warehouse_no
         and oem.owner_no = oed.owner_no
         and oem.exp_no = oed.exp_no
         and oem.exp_type = strExpType
         and oem.warehouse_no = strWarehouseNo
         and oem.enterprise_no = strEnterpriseNo
         and oem.status = '10'
         and oem.exp_no = strExpNo

       group by strWarehouseNo,
                oem.owner_no,
                strWaveNo,
                rownum,
                oem.cust_no,
                oem.sub_cust_no,
                oem.exp_no,
                oed.article_no,
                oed.article_qty,
                oed.locate_qty,
                10,
                oem.line_no,
                oem.batch_no,
                1,
                100,
                'N',
                oed.produce_condition,
                oed.produce_value1,
                oed.produce_value2,
                oed.expire_condition,
                oed.expire_value1,
                oed.expire_value2,
                oed.quality_condition,
                oed.quality_value1,
                oed.quality_value2,
                oed.lotno_condition,
                oed.lotno_value1,
                oed.lotno_value2,
                oed.rsvbatch1_condition,
                oed.rsvbatch1_value1,
                oed.rsvbatch1_value2,
                oed.rsvbatch2_condition,
                oed.rsvbatch2_value1,
                oed.rsvbatch2_value2,
                oed.rsvbatch3_condition,
                oed.rsvbatch3_value1,
                oed.rsvbatch3_value2,
                oed.rsvbatch4_condition,
                oed.rsvbatch4_value1,
                oed.rsvbatch4_value2,
                oed.rsvbatch5_condition,
                oed.rsvbatch5_value1,
                oed.rsvbatch5_value2,
                oed.rsvbatch6_condition,
                oed.rsvbatch6_value1,
                oed.rsvbatch6_value2,
                oed.rsvbatch7_condition,
                oed.rsvbatch7_value1,
                oed.rsvbatch7_value2,
                oed.rsvbatch8_condition,
                oed.rsvbatch8_value1,
                oed.rsvbatch8_value2,
                oed.specify_field,
                oed.specify_condition,
                oed.specify_value1,
                oed.specify_value2,
                sysdate,
                0,
                0,
                oem.import_no,
                1,
                0;

    if sql%rowcount <= 0 then
      strResult := 'N|[E21703]';
      return;
    end if;

    strResult := 'Y|[E21701]'; --成功

  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_Ins_AUTO_LOCATE_D;
end PKOBJ_ODISPATCH;

/

