create package body        pklg_rodata is
  --退货逻辑

  /*******************************************************************************************
  quzhihui
  功能说明：1、按退货单发单；
            2、调用一次过程产生一张下架单，前台SOURCE传参为N，则按供应商产生下架单，若SOURCE_NO
            传参为退货单号，则一张退货单对应一张捡货单，不区分区域
  ********************************************************************************************/
  --退货发单
  procedure P_RO_OUTSTOCK(strEnterPriseNo  in rodata_outstock_m.enterprise_no%type,
                          strWarehose_No   in rodata_outstock_m.warehouse_no%type,
                          strOwnerNo       in rodata_outstock_m.owner_no%type,
                          strSupplierNo    in rodata_outstock_direct.supplier_no%type,
                          strRecedeType    in rodata_outstock_m.recede_type%type,
                          strClassType     in rodata_outstock_direct.class_type%type,
                          strSourceNo      in rodata_outstock_direct.source_no%type, --来源单号，N-所有单号，其它-退货单号
                          strInOutstockNo  in rodata_outstock_m.outstock_no%type, --传入的单号，传入N，内部取号
                          strDock_No       in bdef_defdock.dock_no%type, --码头号
                          strUserID        in bdef_defworker.worker_no%type,
                          strAssignNo      in bdef_defworker.worker_no%type,
                          strOperateType   in rodata_outstock_m.operate_type%type,
                          strTaskLabelFlag in rodata_outstock_direct.label_pick_flag%type,
                          strDeviceNo      in rodata_outstock_direct.device_no%type,
                          strLocateNo      in rodata_outstock_direct.locate_no%type,
                          strBatchNo       in rodata_outstock_direct.batch_no%type,
                          strPrintFlag     in wms_warehouse_rodataorder.sendprint_type%type, --打印标识，0：不打印，1：打表单，2，打标签，3,表单标签同时打印
                          strOutOutstockNo out rodata_outstock_m.outstock_no%type,
                          strOutMsg        out varchar2) IS
    v_strOutstockNo    rodata_outstock_m.outstock_no%type := 'N';
    v_SourceNo         rodata_outstock_direct.source_no%type := 'N';
    v_PrintTaskNo      job_printtask_m.task_no%type;
  begin
    strOutMsg := 'N|[P_RO_OUTSTOCK]';



    if strSourceNo = 'N' or strSourceNo is null then
      v_SourceNo := '%';
    else
      v_SourceNo := strSourceNo;
    end if;

    update rodata_outstock_direct ood
       set ood.status = ood.status
     where ood.enterprise_no = strEnterPriseNo
       and ood.warehouse_no = strWarehose_No
       and ood.owner_no = strOwnerNo
       and ood.supplier_no = strSupplierNo
       and ood.status = '10'
       and ood.Class_Type = strClassType
       and ood.operate_type = strOperateType
       and ood.source_no like v_SourceNo;

    if sql%rowcount <= 0 then
      strOutMsg := 'N|'; --未找到相关数据
      return;
    end if;

    if strInOutstockNo is not null and strInOutstockNo <> 'N' then
      v_strOutstockNo := strInOutstockNo;
    else
      --取下架单号
      PKLG_WMS_BASE.p_getsheetno(strEnterPriseNo,
                                 strWarehose_No,
                                 CONST_DOCUMENTTYPE.ODATAHO,
                                 v_strOutstockNo,
                                 strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
      --写下架单头
      pkobj_rodata.P_RO_WriteOutStockHead(strEnterPriseNo,
                                          strWarehose_No,
                                          strOwnerNo,
                                          v_strOutstockNo,
                                          strOperateType,
                                          strRecedeType,
                                          strClassType,
                                          strUserID,
                                          strTaskLabelFlag,
                                          strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
    end if;
    strOutOutstockNo := v_strOutstockNo;

    for curOutstockInfor in (select *
                               from rodata_outstock_direct ood
                              where ood.enterprise_no = strEnterPriseNo
                                and ood.warehouse_no = strWarehose_No
                                and ood.owner_no = strOwnerNo
                                and ood.supplier_no = strSupplierNo
                                and ood.status = '10'
                                and ood.Class_Type = strClassType
                                and ood.operate_type = strOperateType
                                and ood.source_no like v_SourceNo
                                and ood.label_pick_flag = strTaskLabelFlag
                                and ood.device_no = strDeviceNo
                                and ood.batch_no = strBatchNo
                                and ood.locate_no = strLocateNo) loop
      pkobj_rodata.P_RO_WriteOutStockItem(strEnterPriseNo,
                                          strWarehose_No,
                                          strOwnerNo,
                                          v_strOutstockNo,
                                          strAssignNo,
                                          curOutstockInfor.Operate_Date,
                                          curOutstockInfor.Direct_Serial,
                                          strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
    end loop;

    --更新退货下架指示
    pkobj_rodata.P_RO_UpdatedOutStockDirect(strEnterPriseNo,
                                            strWarehose_No,
                                            strOwnerNo,
                                            v_strOutstockNo,
                                            strUserID,
                                            strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    --写打印任务

    if strPrintFlag = '1' or strPrintFlag = '3' then
      --打印退货拣货单
      PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterPriseNo,
                                          strWarehose_No,
                                          v_strOutstockNo,
                                          '0',
                                          CONST_REPORTID.RPT_WM_PICK,
                                          strDock_No,
                                          '0',
                                          strUserId,
                                          v_PrintTaskNo,
                                          strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
    end if;

    if strPrintFlag = '2' or strPrintFlag = '3' then
      PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterPriseNo,
                                          strWarehose_No,
                                          v_strOutstockNo,
                                          '0',
                                          CONST_REPORTID.RPT_WM_PICKLabel,
                                          strDock_No,
                                          '0',
                                          strUserId,
                                          v_PrintTaskNo,
                                          strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
    end if;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  END P_RO_OUTSTOCK;

  --退货发单
  /***********************************************************************************************************
  创建人：luozhiling
  创建时间：2014.11.7
  功能说明：退货发单,同一波次下同一供应商按标签和表单两种类型分别分单
  ***********************************************************************************************************/
  procedure P_GetTaskRooutstock(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                                strWarehose_No  in rodata_outstock_m.warehouse_no%type,
                                strOwnerNo      in rodata_outstock_m.owner_no%type,
                                strWaveNo       in rodata_outstock_direct.wave_no%type,
                                strRecedeType   in rodata_recede_m.recede_type%type,
                                strSupplierNo   in rodata_outstock_direct.supplier_no%type,
                                strClassType    in rodata_outstock_direct.class_type%type, --0：清场；1：总仓退货；2：质量问题退货
                                strSourceNo     in rodata_outstock_direct.source_no%type, --来源单号，N-所有单号，其它-退货单号
                                strDock_No      in bdef_defdock.dock_no%type, --码头号
                                strUserID       in bdef_defworker.worker_no%type,
                                strAssignNo     in bdef_defworker.worker_no%type,
                                strOperateType  in rodata_outstock_direct.operate_type%type,
                                strPrintFlag     in wms_warehouse_rodataorder.sendprint_type%type, --打印标识，0：不打印，1：打表单，2，打标签，3,表单标签同时打印
                                strOutMsg       out varchar2) IS
    strOutOutstockNo rodata_outstock_m.outstock_no%type;
  begin
    strOutMsg := 'N|[P_GetTaskRooutstock]';

    for t in (select distinct ood.label_pick_flag,
                              ood.device_no,
                              ood.wave_no,
                              ood.batch_no,
                              ood.locate_no
                from rodata_outstock_direct ood
               where ood.enterprise_no = strEnterPriseNo
                 and ood.warehouse_no = strWarehose_No
                 and ood.wave_no = strWaveNo
                 and ood.supplier_no = strSupplierNo
                 and ood.status = '10'
                 and ((ood.source_no = strSourceNo and strSourceNo <> 'N') or
                     strSourceNo = 'N')) loop
      P_RO_OUTSTOCK(strEnterPriseNo,
                    strWarehose_No,
                    strOwnerNo,
                    strSupplierNo,
                    strRecedeType,
                    strClassType,
                    strSourceNo,
                    'N',
                    strDock_No,
                    strUserID,
                    strAssignNo,
                    strOperateType,
                    t.label_pick_flag,
                    t.device_no,
                    t.locate_no,
                    t.batch_no,strPrintFlag,
                    strOutOutstockNo,
                    strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
    end loop;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  END P_GetTaskRooutstock;

  /************************************************************************************************************
   创建人：2015.7.21
   创建时间：
   功能说明：清场的标签库存系统自动发单，自动回单，天天惠专业，
             清场定位的时候调用
  ************************************************************************************************************/
  procedure P_CleanOutStock(strEnterPriseNo  in rodata_outstock_m.enterprise_no%type,
                            strWarehose_No   in rodata_outstock_m.warehouse_no%type,
                            strOwnerNo       in rodata_outstock_m.owner_no%type,
                            strWaveNo        in rodata_outstock_direct.wave_no%type,
                            strRecedeType    in rodata_recede_m.recede_type%type,
                            strSupplierNo    in rodata_outstock_direct.supplier_no%type,
                            strClassType     in rodata_outstock_direct.class_type%type, --0：清场；1：总仓退货；2：质量问题退货
                            strSourceNo      in rodata_outstock_direct.source_no%type, --来源单号，N-所有单号，其它-退货单号
                            strUserID        in bdef_defworker.worker_no%type,
                            strTERMINAL_FLAG in stock_content_move.terminal_flag%type,
                            strLabePickFlag  in rodata_outstock_direct.label_pick_flag%type,
                            strDeviceNo      in rodata_outstock_direct.device_no%type,
                            strLocateNo      in rodata_outstock_direct.locate_no%type,
                            strBatchNo       in rodata_outstock_direct.batch_no%type,
                            strDock_No       in bdef_defdock.dock_no%type,
                            strPrintFlag     in wms_warehouse_rodataorder.sendprint_type%type, --打印标识，0：不打印，1：打表单，2，打标签，3,表单标签同时打印
                            strOutMsg        out varchar2) is
    v_strOutOutstockNo rodata_outstock_m.outstock_no%type;
  begin
    strOutMsg := 'N|[P_CleanOutStock]';

    P_RO_OUTSTOCK(strEnterPriseNo,
                  strWarehose_No,
                  strOwnerNo,
                  strSupplierNo,
                  strRecedeType,
                  strClassType,
                  strSourceNo,
                  'N',
                  strDock_No,
                  strUserID,
                  strUserID,
                  'C',
                  strLabePickFlag,
                  strDeviceNo,
                  strLocateNo,
                  strBatchNo,strPrintFlag,
                  v_strOutOutstockNo,
                  strOutMsg);

    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    --拣货回单
    for GetOutStock in (select rod.enterprise_no,
                               rod.warehouse_no,
                               rod.outstock_no,
                               rod.article_no,
                               rod.s_label_no,
                               rod.packing_qty,
                               sai.barcode,
                               sai.quality,
                               sai.produce_date,
                               sai.expire_date,
                               sai.lot_no,
                               sai.rsv_batch1,
                               sai.rsv_batch2,
                               sai.rsv_batch3,
                               sai.rsv_batch4,
                               sai.rsv_batch5,
                               sai.rsv_batch6,
                               sai.rsv_batch7,
                               sai.rsv_batch8,
                               rod.s_cell_no,
                               rod.d_cell_no,
                               sum(rod.article_qty) article_qty
                          from rodata_outstock_m  rom,
                               rodata_outstock_d  rod,
                               stock_article_info sai
                         where rom.enterprise_no = rod.enterprise_no
                           and rom.warehouse_no = rod.warehouse_no
                           and rom.outstock_no = rod.outstock_no
                           and rom.enterprise_no = strEnterPriseNo
                           and rom.warehouse_no = strWarehose_No
                           and rod.wave_no = strWaveNo
                           and rom.task_type = '2'
                           and rod.source_no = strSourceNo
                           and rod.status = '10'
                           and rom.class_type = strClassType
                           and rod.article_no = sai.article_no
                           and rod.article_id = sai.article_id
                         group by rod.enterprise_no,
                                  rod.warehouse_no,
                                  rod.outstock_no,
                                  rod.article_no,
                                  rod.s_label_no,
                                  rod.packing_qty,
                                  sai.barcode,
                                  sai.quality,
                                  sai.produce_date,
                                  sai.expire_date,
                                  sai.lot_no,
                                  sai.rsv_batch1,
                                  sai.rsv_batch2,
                                  sai.rsv_batch3,
                                  sai.rsv_batch4,
                                  sai.rsv_batch5,
                                  sai.rsv_batch6,
                                  sai.rsv_batch7,
                                  sai.rsv_batch8,
                                  rod.s_cell_no,
                                  rod.d_cell_no
                         order by rod.s_label_no,
                                  rod.s_cell_no,
                                  rod.article_no) loop
      --

      P_SaveOutstock(strEnterPriseNo,
                     strWarehose_No,
                     strOwnerNo,
                     GetOutStock.outstock_no,
                     GetOutStock.s_label_no,
                     GetOutStock.article_no,
                     GetOutStock.Barcode,
                     GetOutStock.packing_qty,
                     GetOutStock.quality,
                     GetOutStock.produce_date,
                     GetOutStock.expire_date,
                     GetOutStock.lot_no,
                     GetOutStock.rsv_batch1,
                     GetOutStock.rsv_batch2,
                     GetOutStock.rsv_batch3,
                     GetOutStock.rsv_batch4,
                     GetOutStock.rsv_batch5,
                     GetOutStock.rsv_batch6,
                     GetOutStock.rsv_batch7,
                     GetOutStock.rsv_batch8,
                     GetOutStock.s_cell_no,
                     GetOutStock.article_qty,
                     GetOutStock.article_qty,
                     GetOutStock.d_cell_no,
                     strUserID,
                     strUserID,
                     strTERMINAL_FLAG,
                     strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
    end loop;

    strOutMsg := 'Y|[]';
  end P_CleanOutStock;

  /***********************************************************************************************8
  创建人：luozhiling
  创建时间：2014。11.8
  功能说明：按标签做退货回单
  ************************************************************************************************/
  procedure P_RO_LabelSave(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                           strWarehose_No  in rodata_outstock_m.warehouse_no%type,
                           strOwnerNo      in rodata_outstock_m.owner_no%type,
                           strOutStockNo   in rodata_outstock_d.outstock_no%type,
                           strsLabelNo     in rodata_outstock_d.s_label_no%type, --来源标签
                           strOutUserID    in rodata_outstock_d.outstock_name%type,
                           strUserID       in rodata_outstock_d.assign_name%type,
                           strDockNo       in bdef_defdock.dock_no%type,
                           strOutMsg       out varchar2) is

    v_iCount      integer := 0;
    v_PrintTaskNo job_printtask_m.task_no%type;
  begin
    strOutMsg := 'N|[P_RO_OutstockReturn]';
    for curOutstockInfor in (select d.enterprise_no,
                                    d.warehouse_no,
                                    d.owner_no,
                                    d.outstock_no,
                                    sai.barcode,
                                    sai.quality,
                                    sai.produce_date,
                                    sai.expire_date,
                                    sai.lot_no,
                                    sai.rsv_batch1,
                                    sai.rsv_batch2,
                                    sai.rsv_batch3,
                                    sai.rsv_batch4,
                                    sai.rsv_batch5,
                                    sai.rsv_batch6,
                                    sai.rsv_batch7,
                                    sai.rsv_batch8,
                                    d.s_label_no,
                                    d.article_no,
                                    d.packing_qty,
                                    d.s_cell_no,
                                    d.d_cell_no,
                                    sum(d.article_qty) article_qty
                               from rodata_outstock_d  d,
                                    stock_article_info sai
                              where d.enterprise_no = strEnterPriseNo
                                and d.warehouse_no = strWarehose_No
                                and d.owner_no = strOwnerNo
                                and d.outstock_no = strOutStockNo
                                and d.s_label_no = strsLabelNo
                                and d.status = '10'
                                and d.article_no = sai.article_no
                                and d.article_id = sai.article_id
                                and d.enterprise_no = sai.enterprise_no
                              group by d.enterprise_no,
                                       d.warehouse_no,
                                       d.owner_no,
                                       d.outstock_no,
                                       d.s_label_no,
                                       d.article_no,
                                       d.packing_qty,
                                       d.s_cell_no,
                                       d.d_cell_no,
                                       sai.barcode,
                                       sai.quality,
                                       sai.produce_date,
                                       sai.expire_date,
                                       sai.lot_no,
                                       sai.rsv_batch1,
                                       sai.rsv_batch2,
                                       sai.rsv_batch3,
                                       sai.rsv_batch4,
                                       sai.rsv_batch5,
                                       sai.rsv_batch6,
                                       sai.rsv_batch7,
                                       sai.rsv_batch8
                              order by d.s_cell_no, d.article_no) loop

      v_iCount := v_iCount + 1;

      P_SaveOutstock(strEnterPriseNo,
                     strWarehose_No,
                     strOwnerNo,
                     curOutstockInfor.outstock_no,
                     curOutstockInfor.s_label_no,
                     curOutstockInfor.article_no,
                     curOutstockInfor.Barcode,
                     curOutstockInfor.packing_qty,
                     curOutstockInfor.quality,
                     curOutstockInfor.produce_date,
                     curOutstockInfor.expire_date,
                     curOutstockInfor.lot_no,
                     curOutstockInfor.rsv_batch1,
                     curOutstockInfor.rsv_batch2,
                     curOutstockInfor.rsv_batch3,
                     curOutstockInfor.rsv_batch4,
                     curOutstockInfor.rsv_batch5,
                     curOutstockInfor.rsv_batch6,
                     curOutstockInfor.rsv_batch7,
                     curOutstockInfor.rsv_batch8,
                     curOutstockInfor.s_cell_no,
                     curOutstockInfor.article_qty,
                     curOutstockInfor.article_qty,
                     curOutstockInfor.d_cell_no,
                     strOutUserID,
                     strUserID,
                     '1',
                     strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

    end loop;

    if v_iCount = 0 then
      strOutMsg := 'N|[]'; --找不到对应的下架明细
      return;
    end if;

    for p in (select distinct rbm.label_no
                from rodata_box_m rbm, rodata_box_d rbd
               where rbm.enterprise_no = rbd.enterprise_no
                 and rbm.warehouse_no = rbd.warehouse_no
                 and rbm.enterprise_no = strEnterPriseNo
                 and rbm.label_no = rbd.label_no
                 AND rbm.Warehouse_No = strWarehose_No
                 and rbd.outstock_no = strOutStockNo) loop
      --写打印任务
      PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterPriseNo,
                                          strWarehose_No,
                                          p.label_no,
                                          '0',
                                          CONST_REPORTID.RPT_WM_BOXITEM,
                                          strDockNo,
                                          '0',
                                          strUserId,
                                          v_PrintTaskNo,
                                          strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

    end loop;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_RO_LabelSave;

  /***********************************************************************************************8
  功能说明：按商品明细做拣货回单，用于日常的退货拣货回单，不扫描流程
           步骤：1、更新拣货明细；
                 2、更新库存；
  ************************************************************************************************/
  procedure P_SaveOutstock(strEnterPriseNo  in rodata_outstock_m.enterprise_no%type,
                           strWarehose_No   in rodata_outstock_m.warehouse_no%type,
                           strOwnerNo       in rodata_outstock_m.owner_no%type,
                           strOutStockNo    in rodata_outstock_d.outstock_no%type,
                           strsLabelNo      in rodata_outstock_d.s_label_no%type,
                           strArticleNo     in rodata_outstock_d.article_no%type,
                           strBarcode      in stock_article_info.barcode%type,
                           nPackingQTY      in rodata_outstock_d.packing_qty%type,
                           strQuality       in idata_check_d.quality%type, --品质
                           dtProduceDate    in stock_article_info.produce_date%type, --生产日期
                           dtExpireDate     in stock_article_info.expire_date%type, --到期日期
                           strLotNo         in stock_article_info.lot_no%type, --批次号
                           strRSV_BATCH1    in stock_article_info.rsv_batch1%type, --预留批属性1
                           strRSV_BATCH2    in stock_article_info.rsv_batch2%type, --预留批属性2
                           strRSV_BATCH3    in stock_article_info.rsv_batch3%type, --预留批属性3
                           strRSV_BATCH4    in stock_article_info.rsv_batch4%type, --预留批属性4
                           strRSV_BATCH5    in stock_article_info.rsv_batch5%type, --预留批属性5
                           strRSV_BATCH6    in stock_article_info.rsv_batch6%type, --预留批属性6
                           strRSV_BATCH7    in stock_article_info.rsv_batch7%type, --预留批属性7
                           strRSV_BATCH8    in stock_article_info.rsv_batch8%type, --预留批属性8
                           strScellNo       in rodata_outstock_d.s_cell_no%type,
                           nArticleQTY      in rodata_outstock_d.article_qty%type,
                           nRealQTY         in rodata_outstock_d.real_qty%type,
                           strRealCellNo    in rodata_outstock_d.outstock_cell_no%type,
                           strOutUserID     in rodata_outstock_d.outstock_name%type,
                           strUserID        in rodata_outstock_d.assign_name%type,
                           strTERMINAL_FLAG in stock_content_move.terminal_flag%type,
                           strOutMsg        out varchar2) is
    v_TotalArticleQTY rodata_outstock_d.article_qty%type := nArticleQTY;
    v_ArticleQTY      rodata_outstock_d.article_qty%type := 0;
    v_TotalRealQTY    rodata_outstock_d.article_qty%type := nRealQTY;
    v_RealQTY         rodata_outstock_d.article_qty%type := 0;
    v_iCount          integer := 0;
    v_nOldCellID      stock_content.cell_id%type;
  begin
    strOutMsg := 'N|[P_SaveOutstock]';
    for curOutstockInfor in (select oom.recede_type, ood.*
                               from rodata_outstock_m  oom,
                                    rodata_outstock_d  ood,
                                    stock_article_info sai
                              where oom.enterprise_no = ood.enterprise_no
                                and oom.enterprise_no = sai.enterprise_no
                                and oom.warehouse_no = ood.warehouse_no
                                and oom.outstock_no = ood.outstock_no
                                and ood.article_no = sai.article_no
                                and ood.article_id = sai.article_id
                                and oom.enterprise_no = strEnterPriseNo
                                and oom.warehouse_no = strWarehose_No
                                and oom.outstock_no = strOutStockNo
                                and ood.s_label_no = strsLabelNo
                                and ood.article_no = strArticleNo
                                and ood.s_cell_no = strScellNo
                                and ood.packing_qty = nPackingQTY
                                and sai.barcode = strBarcode
                                and sai.produce_date = dtProduceDate
                                and sai.expire_date = dtExpireDate
                                and sai.lot_no = strLotNo
                                and sai.quality = strQuality
                                and sai.rsv_batch1 = strRSV_BATCH1
                                and sai.rsv_batch2 = strRSV_BATCH2
                                and sai.rsv_batch3 = strRSV_BATCH3
                                and sai.rsv_batch4 = strRSV_BATCH4
                                and sai.rsv_batch5 = strRSV_BATCH5
                                and sai.rsv_batch6 = strRSV_BATCH6
                                and sai.rsv_batch7 = strRSV_BATCH7
                                and sai.rsv_batch8 = strRSV_BATCH8
                                and ood.status = '10'
                                for update) loop

      --有拆指示
      if v_TotalArticleQTY < curOutstockInfor.Article_Qty then
        v_ArticleQTY := v_TotalArticleQTY;
        if v_TotalRealQTY < curOutstockInfor.Article_Qty then
          v_RealQTY := v_TotalRealQTY;
        else
          v_RealQTY := v_ArticleQTY;
        end if;
        --修改原明细
        pkobj_rodata.P_RO_UpdatedOutStockItem(strEnterPriseNo,
                                              strWarehose_No,
                                              strOutStockNo,
                                              v_ArticleQTY,
                                              v_RealQTY,
                                              strRealCellNo,
                                              strOwnerNo,
                                              curOutstockInfor.row_id,
                                              curOutstockInfor.s_label_no,
                                              strOutUserID,
                                              '11',
                                              strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
        --新增明细
        pkobj_rodata.P_RO_InsertOutStockItem(strEnterPriseNo,
                                             strWarehose_No,
                                             strOwnerNo,
                                             strOutStockNo,
                                             curOutstockInfor.article_no,
                                             curOutstockInfor.s_cell_no,
                                             curOutstockInfor.s_cell_id,
                                             curOutstockInfor.Article_Qty -
                                             v_ArticleQTY,
                                             v_RealQTY,
                                             strRealCellNo,
                                             curOutstockInfor.s_label_no,
                                             curOutstockInfor.label_no,
                                             curOutstockInfor.row_id,
                                             strUserID,
                                             strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
        v_TotalArticleQTY := v_TotalArticleQTY - v_ArticleQTY;
        v_TotalRealQTY    := v_TotalRealQTY - v_RealQTY;
      else
        if v_TotalRealQTY >= curOutstockInfor.Article_Qty then
          v_RealQTY := curOutstockInfor.Article_Qty;
        else
          v_RealQTY := v_TotalRealQTY;
        end if;
        --修改原明细
        pkobj_rodata.P_RO_UpdatedOutStockItem(strEnterPriseNo,
                                              strWarehose_No,
                                              strOutStockNo,
                                              curOutstockInfor.Article_Qty,
                                              v_RealQTY,
                                              strRealCellNo,
                                              strOwnerNo,
                                              curOutstockInfor.row_id,
                                              curOutstockInfor.s_label_no,
                                              strOutUserID,
                                              '11',
                                              strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
        v_TotalRealQTY := v_TotalRealQTY - v_RealQTY;
      end if;
      --扣减来源储位库存
      -------------------把来源储位预下库存回单-------------------------------
      PKOBJ_STOCK.p_UpdtContent_qtyByCellID(strEnterPriseNo,
                                            curOutstockInfor.warehouse_no, --仓别
                                            curOutstockInfor.s_Cell_Id, --储位ID
                                            curOutstockInfor.s_Cell_No, --储位
                                            curOutstockInfor.d_Cell_No, --关系储位
                                            v_RealQTY, --数量
                                            curOutstockInfor.Article_Qty, --预下数量
                                            strUserID, --操作人员
                                            strOutStockNo, --操作单号
                                            strTERMINAL_FLAG, --操作设备
                                            strOutMsg); --返回 执行结果
      if (substr(strOutMsg, 1, 1) <> 'Y') then
        return;
      end if;

      --增加目的储位库存
      --------------------回写目的储位预上库存----------------------------------
      PKOBJ_STOCK.p_InstContent_qtyByCellID(strEnterPriseNo,
                                            curOutstockInfor.warehouse_no, --仓别
                                            curOutstockInfor.d_Cell_Id, --储位ID
                                            curOutstockInfor.d_Cell_No, --储位
                                            curOutstockInfor.s_Cell_No, --关系储位
                                            v_RealQTY, --数量
                                            curOutstockInfor.Article_Qty, --预下数量
                                            strUserId, --操作人员
                                            strOutStockNo, --操作单号
                                            strTERMINAL_FLAG, --操作设备
                                            strOutMsg); --返回 执行结果
      if (substr(strOutMsg, 1, 1) <> 'Y') then
        return;
      end if;

      v_nOldCellID := curOutstockInfor.d_Cell_Id;

      --------------------是否有修改储位----------------------------------
      if curOutstockInfor.d_Cell_No <> strRealCellNo then
        ----------------增加新储位库存------------------
        PKOBJ_STOCK.p_InstContent_qtyByCellNo(strEnterPriseNo,
                                              curOutstockInfor.warehouse_no, --仓别
                                              curOutstockInfor.Owner_No, --委托业主
                                              'N',
                                              curOutstockInfor.Article_No, --商品编号
                                              curOutstockInfor.Article_Id, --商品属性ID
                                              strRealCellNo, --储位
                                              curOutstockInfor.d_Cell_No, --关系储位
                                              curOutstockInfor.Packing_Qty, --商品包装
                                              v_RealQTY, --数量
                                              'N', --标签号
                                              'N', --子标签号
                                              curOutstockInfor.Stock_Type, --存储类型
                                              curOutstockInfor.Stock_Value, --对应存储值
                                              strUserId, --操作人员
                                              strOutstockNo, --操作单号
                                              strTERMINAL_FLAG, --操作设备
                                              1, --是否可手工移库 0:不允许手工移库；1：可手工移库
                                              v_nOldCellID,
                                              strOutMsg); --返回 执行结果
        if (substr(strOutMsg, 1, 1) <> 'Y') then
          return;
        end if;
        -----------处理目的容器库存----------------------------------
        PKOBJ_STOCK.p_UpdtContent_qtyByCellNo(strEnterPriseNo,
                                              curOutstockInfor.warehouse_no, --仓别
                                              curOutstockInfor.Owner_No, --委托业主
                                              curOutstockInfor.Article_No, --商品编号
                                              curOutstockInfor.Article_Id, --商品属性ID
                                              curOutstockInfor.d_Cell_No, --储位
                                              strRealCellNo, --关系储位
                                              curOutstockInfor.Packing_Qty, --商品包装
                                              v_RealQTY, --数量
                                              curOutstockInfor.label_no, --商品容器号
                                              curOutstockInfor.Stock_Type, --存储类型
                                              curOutstockInfor.Stock_Value, --对应存储值
                                              strUserId, --操作人员
                                              strOutstockNo, --操作单号
                                              strTERMINAL_FLAG, --操作设备
                                              strOutMsg); --返回 执行结果
        if (substr(strOutMsg, 1, 1) <> 'Y') then
          return;
        end if;
      end if;

      if v_RealQTY > 0 then

        --将目的储位的标签号进行转换
        PKOBJ_STOCK.p_UpdtContent_ContainerNo(strEnterPriseNo,
                                              curOutstockInfor.warehouse_no,
                                              curOutstockInfor.label_no,
                                              curOutstockInfor.sub_label_no,
                                              curOutstockInfor.d_cell_no,
                                              curOutstockInfor.d_cell_id,
                                              strUserID,
                                              v_nOldCellID,
                                              strOutMsg); --返回 执行结果
        if (substr(strOutMsg, 1, 1) <> 'Y') then
          return;
        end if;

        --库存转换
        PKOBJ_STOCK.p_TransContent_qtyByCellID(strEnterPriseNo,
                                               curOutstockInfor.warehouse_no,
                                               strRealCellNo,
                                               v_nOldCellID,
                                               v_RealQTY,
                                               '3',
                                               curOutstockInfor.Source_No,
                                               strUserId,
                                               v_nOldCellID,
                                               strOutMsg);

        if (substr(strOutMsg, 1, 1) <> 'Y') then
          return;
        end if;
      end if;

      --将下架指示转历史
      pkobj_rodata.P_RO_InsertOutStockDirectHTY(strEnterPriseNo,
                                                strWarehose_No,
                                                strOwnerNo,
                                                curOutstockInfor.Divide_Id,
                                                strUserID,
                                                strOutMsg);

      update rodata_recede_d d
         set d.outstock_qty = d.outstock_qty + v_RealQTY
       where d.enterprise_no = strEnterPriseNo
         and d.warehouse_no = strWarehose_No
         and d.owner_no = curOutstockInfor.Owner_No
         and d.recede_no = curOutstockInfor.Source_No
         and d.po_id = curOutstockInfor.Po_Id
         and d.article_no = curOutstockInfor.Article_No;

      update rodata_outstock_d d
         set d.status = '13', d.OUTSTOCK_CELL_ID = v_nOldCellID
       where d.status = '11'
         and d.warehouse_no = strWarehose_No
         and d.enterprise_no = strEnterPriseNo
         and d.outstock_no = strOutStockNo
         and d.row_id = curOutstockInfor.ROW_ID;

    end loop;

    --更新退货下架单头
    select count(1)
      into v_iCount
      from rodata_outstock_d d
     where d.status = '10'
       and d.enterprise_no = strEnterPriseNo
       and d.warehouse_no = strWarehose_No
       and d.owner_no = strOwnerNo
       and d.outstock_no = strOutStockNo;
    if v_iCount > 0 then
      return;
    end if;

    --更新下架单头档
    pkobj_rodata.P_RO_UpdateOutStockHeader(strEnterPriseNo,
                                           strWarehose_No,
                                           strOutStockNo,
                                           strOwnerNo,
                                           strUserID,
                                           strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    --写箱明细
    P_CreateRecedeBox(strEnterPriseNo,
                      strWarehose_No,
                      strOwnerNo,
                      strOutStockNo,
                      strUserID,
                      strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    --根据下架单号更新退货单主档
    pkobj_rodata.P_RO_UpdateRecedeHeader(strEnterPriseNo,
                                         strWarehose_No,
                                         strOutStockNo,
                                         strOwnerNo,
                                         strUserID,
                                         '14',
                                         strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    strOutMsg := 'Y|[]';
  end P_SaveOutstock;
  /***********************************************************************************************8
  功能说明： 用于天天惠惠特殊的清场流程处理，不允许修改储位回单
           步骤：1、更新拣货明细；
                 2、更新库存；

  ************************************************************************************************/
  procedure P_SpecialSaveOutstock(strEnterPriseNo  in rodata_outstock_m.enterprise_no%type,
                                  strWarehose_No   in rodata_outstock_m.warehouse_no%type,
                                  strOwnerNo       in rodata_outstock_m.owner_no%type,
                                  strOutStockNo    in rodata_outstock_d.outstock_no%type,
                                  strsLabelNo      in rodata_outstock_d.s_label_no%type,
                                  strArticleNo     in rodata_outstock_d.article_no%type,
                                  nPackingQTY      in rodata_outstock_d.packing_qty%type,
                                  strQuality       in idata_check_d.quality%type, --品质
                                  dtProduceDate    in stock_article_info.produce_date%type, --生产日期
                                  dtExpireDate     in stock_article_info.expire_date%type, --到期日期
                                  strLotNo         in stock_article_info.lot_no%type, --批次号
                                  strRSV_BATCH1    in stock_article_info.rsv_batch1%type, --预留批属性1
                                  strRSV_BATCH2    in stock_article_info.rsv_batch2%type, --预留批属性2
                                  strRSV_BATCH3    in stock_article_info.rsv_batch3%type, --预留批属性3
                                  strRSV_BATCH4    in stock_article_info.rsv_batch4%type, --预留批属性4
                                  strRSV_BATCH5    in stock_article_info.rsv_batch5%type, --预留批属性5
                                  strRSV_BATCH6    in stock_article_info.rsv_batch6%type, --预留批属性6
                                  strRSV_BATCH7    in stock_article_info.rsv_batch7%type, --预留批属性7
                                  strRSV_BATCH8    in stock_article_info.rsv_batch8%type, --预留批属性8
                                  strScellNo       in rodata_outstock_d.s_cell_no%type,
                                  nArticleQTY      in rodata_outstock_d.article_qty%type,
                                  nRealQTY         in rodata_outstock_d.real_qty%type,
                                  strOutUserID     in rodata_outstock_d.outstock_name%type,
                                  strUserID        in rodata_outstock_d.assign_name%type,
                                  strTERMINAL_FLAG in stock_content_move.terminal_flag%type,
                                  strOutMsg        out varchar2) is
    v_TotalArticleQTY rodata_outstock_d.article_qty%type := nArticleQTY;
    v_ArticleQTY      rodata_outstock_d.article_qty%type := 0;
    v_TotalRealQTY    rodata_outstock_d.article_qty%type := nRealQTY;
    v_RealQTY         rodata_outstock_d.article_qty%type := 0;
    v_iCount          integer := 0;
    v_nOldCellID      stock_content.cell_id%type;
    v_strRecedeNo     rodata_recede_m.recede_no%type;
    v_strRsv1         rodata_recede_m.rsv_varod1%type;
  begin
    strOutMsg := 'N|[P_SaveOutstock]';


    --获取是否快速退货标识
    select nvl(t.rsv_varod1,'0') into v_strRsv1 from rodata_recede_m t,rodata_outstock_d rom
    where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWarehose_No
    and t.enterprise_no=rom.enterprise_no and t.warehouse_no=rom.warehouse_no
    and t.recede_no=rom.source_no and rom.outstock_no=strOutStockNo
    and rownum=1;

    for curOutstockInfor in (select oom.recede_type,ood.*
                               from rodata_outstock_m  oom,
                                    rodata_outstock_d  ood,
                                    stock_article_info sai
                              where oom.enterprise_no = ood.enterprise_no
                                and oom.enterprise_no = sai.enterprise_no
                                and oom.warehouse_no = ood.warehouse_no
                                and oom.outstock_no = ood.outstock_no
                                and ood.article_no = sai.article_no
                                and ood.article_id = sai.article_id
                                and oom.enterprise_no = strEnterPriseNo
                                and oom.warehouse_no = strWarehose_No
                                and oom.outstock_no = strOutStockNo
                                and ood.s_label_no = strsLabelNo
                                and ood.article_no = strArticleNo
                                and ood.s_cell_no = strScellNo
                                and ood.packing_qty = nPackingQTY
                                and sai.produce_date = dtProduceDate
                                and sai.expire_date = dtExpireDate
                                and sai.lot_no = strLotNo
                                and sai.quality = strQuality
                                and sai.rsv_batch1 = strRSV_BATCH1
                                and sai.rsv_batch2 = strRSV_BATCH2
                                and sai.rsv_batch3 = strRSV_BATCH3
                                and sai.rsv_batch4 = strRSV_BATCH4
                                and sai.rsv_batch5 = strRSV_BATCH5
                                and sai.rsv_batch6 = strRSV_BATCH6
                                and sai.rsv_batch7 = strRSV_BATCH7
                                and sai.rsv_batch8 = strRSV_BATCH8
                                and ood.status = '10'
                                for update) loop

      --有拆指示
      if v_TotalArticleQTY < curOutstockInfor.Article_Qty then
        v_ArticleQTY := v_TotalArticleQTY;
        if v_TotalRealQTY < curOutstockInfor.Article_Qty then
          v_RealQTY := v_TotalRealQTY;
        else
          v_RealQTY := v_ArticleQTY;
        end if;
        --修改原明细
        pkobj_rodata.P_RO_UpdatedOutStockItem(strEnterPriseNo,
                                              strWarehose_No,
                                              strOutStockNo,
                                              v_ArticleQTY,
                                              v_RealQTY,
                                              curOutstockInfor.d_cell_no,
                                              strOwnerNo,
                                              curOutstockInfor.row_id,
                                              curOutstockInfor.s_label_no,
                                              strOutUserID,
                                              '11',
                                              strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
        --新增明细
        pkobj_rodata.P_RO_InsertOutStockItem(strEnterPriseNo,
                                             strWarehose_No,
                                             strOwnerNo,
                                             strOutStockNo,
                                             curOutstockInfor.article_no,
                                             curOutstockInfor.s_cell_no,
                                             curOutstockInfor.s_cell_id,
                                             curOutstockInfor.Article_Qty -
                                             v_ArticleQTY,
                                             v_RealQTY,
                                             curOutstockInfor.d_cell_no,
                                             curOutstockInfor.s_label_no,
                                             curOutstockInfor.label_no,
                                             curOutstockInfor.row_id,
                                             strUserID,
                                             strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
        v_TotalArticleQTY := v_TotalArticleQTY - v_ArticleQTY;
        v_TotalRealQTY    := v_TotalRealQTY - v_RealQTY;
      else
        if v_TotalRealQTY >= curOutstockInfor.Article_Qty then
          v_RealQTY := curOutstockInfor.Article_Qty;
        else
          v_RealQTY := v_TotalRealQTY;
        end if;
        --修改原明细
        pkobj_rodata.P_RO_UpdatedOutStockItem(strEnterPriseNo,
                                              strWarehose_No,
                                              strOutStockNo,
                                              curOutstockInfor.Article_Qty,
                                              v_RealQTY,
                                              curOutstockInfor.d_cell_no,
                                              strOwnerNo,
                                              curOutstockInfor.row_id,
                                              curOutstockInfor.s_label_no,
                                              strOutUserID,
                                              '11',
                                              strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
        v_TotalRealQTY := v_TotalRealQTY - v_RealQTY;
      end if;
      --扣减来源储位库存
      -------------------把来源储位预下库存回单-------------------------------
      PKOBJ_STOCK.p_UpdtContent_qtyByCellID(strEnterPriseNo,
                                            curOutstockInfor.warehouse_no, --仓别
                                            curOutstockInfor.s_Cell_Id, --储位ID
                                            curOutstockInfor.s_Cell_No, --储位
                                            curOutstockInfor.d_Cell_No, --关系储位
                                            v_RealQTY, --数量
                                            curOutstockInfor.Article_Qty, --预下数量
                                            strUserID, --操作人员
                                            strOutStockNo, --操作单号
                                            strTERMINAL_FLAG, --操作设备
                                            strOutMsg); --返回 执行结果
      if (substr(strOutMsg, 1, 1) <> 'Y') then
        return;
      end if;

      --增加目的储位库存
      --------------------回写目的储位预上库存----------------------------------
      PKOBJ_STOCK.p_InstContent_qtyByCellID(strEnterPriseNo,
                                            curOutstockInfor.warehouse_no, --仓别
                                            curOutstockInfor.d_Cell_Id, --储位ID
                                            curOutstockInfor.d_Cell_No, --储位
                                            curOutstockInfor.s_Cell_No, --关系储位
                                            v_RealQTY, --数量
                                            curOutstockInfor.Article_Qty, --预下数量
                                            strUserId, --操作人员
                                            strOutStockNo, --操作单号
                                            strTERMINAL_FLAG, --操作设备
                                            strOutMsg); --返回 执行结果
      if (substr(strOutMsg, 1, 1) <> 'Y') then
        return;
      end if;

      if v_RealQTY > 0 and v_strRsv1='0' then

        --将目的储位的标签号进行转换
        PKOBJ_STOCK.p_UpdtContent_ContainerNo(strEnterPriseNo,
                                              curOutstockInfor.warehouse_no,
                                              strOutStockNo,
                                              strOutStockNo,
                                              curOutstockInfor.d_cell_no,
                                              curOutstockInfor.d_cell_id,
                                              strUserID,
                                              v_nOldCellID,
                                              strOutMsg); --返回 执行结果
        if (substr(strOutMsg, 1, 1) <> 'Y') then
          return;
        end if;

/*        --库存转换
        PKOBJ_STOCK.p_TransContent_qtyByCellID(strEnterPriseNo,
                                               curOutstockInfor.warehouse_no,
                                               curOutstockInfor.d_cell_no,
                                               v_nOldCellID,
                                               v_RealQTY,
                                               '3',
                                               curOutstockInfor.Source_No,
                                               strUserId,
                                               v_nOldCellID,
                                               strOutMsg);

        if (substr(strOutMsg, 1, 1) <> 'Y') then
          return;
        end if;*/
      end if;

      --将下架指示转历史
      pkobj_rodata.P_RO_InsertOutStockDirectHTY(strEnterPriseNo,
                                                strWarehose_No,
                                                strOwnerNo,
                                                curOutstockInfor.Divide_Id,
                                                strUserID,
                                                strOutMsg);

      update rodata_outstock_d d
         set d.status = '13', d.OUTSTOCK_CELL_ID = v_nOldCellID
       where d.status = '11'
         and d.warehouse_no = strWarehose_No
         and d.enterprise_no = strEnterPriseNo
         and d.outstock_no = strOutStockNo
         and d.row_id = curOutstockInfor.ROW_ID;
    end loop;

    --更新退货下架单头
    select count(1)
      into v_iCount
      from rodata_outstock_d d
     where d.status = '10'
       and d.enterprise_no = strEnterPriseNo
       and d.warehouse_no = strWarehose_No
       and d.owner_no = strOwnerNo
       and d.outstock_no = strOutStockNo;
    if v_iCount > 0 then
      return;
    end if;

    --更新下架单头档
    pkobj_rodata.P_RO_UpdateOutStockHeader(strEnterPriseNo,
                                           strWarehose_No,
                                           strOutStockNo,
                                           strOwnerNo,
                                           strUserID,
                                           strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;


    if v_strRsv1='0' then
        P_OutStockToDivide(strEnterPriseNo,
                           strWarehose_No,
                           strOwnerNo,
                           strOutStockNo,
                           strUserID,
                           strOutMsg);

        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
    else

        --退货下架单转历史
        pkobj_rodata.P_RO_UpdateOutStockHistory(strEnterPriseNo,
                                                strWarehose_No,
                                                strOutStockNo,
                                                strOwnerNo,
                                                strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
    end if;


    strOutMsg := 'Y|[]';
  end P_SpecialSaveOutstock;
  /*********************************************************************************************
  功能说明： 按拣货明细表的数据写退货箱明细，
             1、需整张下架单拣货完成后才写，
             2、因为很多项目的退货是没有标签的，故若没有标签号就将下架单号作为LABEL_NO
             3、此操作不涉及库存的改变；
             4、头档的RECEDE_NO 在项目为一对一退货时可记录退货单号，在多张退货单一起退货时记录N
             5、箱明细产生后，将退货下架单装历史
  创建日期：2015.7.23
  ********************************************************************************************/
  procedure P_CreateRecedeBox(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                              strWarehose_No  in rodata_outstock_m.warehouse_no%type,
                              strOwnerNo      in rodata_outstock_m.owner_no%type,
                              strOutStockNo   in rodata_outstock_d.outstock_no%type,
                              strUserID       in rodata_outstock_d.assign_name%type,
                              strOutMsg       out varchar2) is
    v_iCount      integer;
    v_strLabelNo  rodata_outstock_d.label_no%type := 'N';
    v_strSourceNo Rodata_Outstock_d.Source_No%TYPE;
    v_nRealQty    rodata_outstock_d.real_qty%type;
  begin
    strOutMsg := 'N|[P_CreateRecedeBox]';
    --首先获取拣货单的状态是不是整单回单
    select count(*)
      into v_iCount
      from rodata_outstock_m t
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWarehose_No
       and t.outstock_no = strOutStockNo
       and t.status = '13';
    if v_iCount = 0 then
      return;
    end if;

    select max(source_no), sum(real_qty)
      into v_strSourceNo, v_nRealQty
      from rodata_outstock_d
     where enterprise_no = strEnterPriseNo
       and warehouse_no = strWarehose_No
       and outstock_no = strOutStockNo;

    if v_nRealQty > 0 then

      --查询下架明细
      for GetOutStock in (select distinct label_no, outstock_cell_no
                            from rodata_outstock_d
                           where enterprise_no = strEnterPriseNo
                             and warehouse_no = strWarehose_No
                             and outstock_no = strOutStockNo
                             and real_qty > 0
                           order by label_no) loop

        if GetOutStock.label_no = 'N' then
          v_strLabelNo := strOutStockNo;
        else
          v_strLabelNo := GetOutStock.label_no;
        end if;

        /*
        if GetOutStock.label_no<>v_strLabelNo then*/
        --写退货标签头档
        PKOBJ_RODATA.P_InsertRodataBoxM(strEnterPriseNo,
                                        strWarehose_No,
                                        strOwnerNo,
                                        v_strLabelNo,
                                        v_strSourceNo,
                                        GetOutStock.outstock_cell_no,
                                        strUserID,
                                        '0',
                                        strOutMsg);

        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
        --写退货标签明细
        pkobj_rodata.P_InsertRodataBoxItem(strEnterPriseNo,
                                           strWarehose_No,
                                           strOwnerNo,
                                           strOutstockNo,
                                           GetOutStock.label_no,
                                           v_strSourceNo,
                                           strUserID,
                                           '1',
                                           strOutMsg);

        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
        /*               end if;*/
      end loop;
    end if;

    --退货下架单转历史
    pkobj_rodata.P_RO_UpdateOutStockHistory(strEnterPriseNo,
                                            strWarehose_No,
                                            strOutStockNo,
                                            strOwnerNo,
                                            strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    strOutMsg := 'Y|[]';
  end P_CreateRecedeBox;
  /**********************************************************************--退货回单************
   功能说明：用于拣货回单直接产生退货清单的情况，用于退回回单以后直接产生退货清单的流程，目前共速达、铁越在用、
            1、按商品明细进行下架回单；
            2、整单回单；
            3、产生预制退货单；
            4、退货确认
  *********************************************************************************************/
  procedure P_RO_OutstockReturn(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                                strWarehose_No  in rodata_outstock_m.warehouse_no%type,
                                strOwnerNo      in rodata_outstock_m.owner_no%type,
                                strOutStockNo   in rodata_outstock_d.outstock_no%type,
                                strLabelNo      in rodata_outstock_d.label_no%type,
                                strArticleNo    in rodata_outstock_d.article_no%type,
                                strBarcode      in stock_article_info.barcode%type,
                                nPackingQTY     in rodata_outstock_d.packing_qty%type,
                                strQuality      in idata_check_d.quality%type, --品质
                                dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                                dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                                strLotNo        in stock_article_info.lot_no%type, --批次号
                                strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                                strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                                strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                                strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                                strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                                strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                                strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                                strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                                strScellNo      in rodata_outstock_d.s_cell_no%type,
                                nArticleQTY     in rodata_outstock_d.article_qty%type,
                                nRealQTY        in rodata_outstock_d.real_qty%type,
                                strRealCellNo   in rodata_outstock_d.outstock_cell_no%type,
                                strOutUserID    in rodata_outstock_d.outstock_name%type,
                                strUserID       in rodata_outstock_d.assign_name%type,
                                strDockNo       in bdef_defdock.dock_no%type,
                                strOutMsg       out varchar2) is
    v_iCount       integer := 0;
    v_strDeliverNo rodata_deliver_d.deliver_no%type;
		v_strRecedeType wms_rodataorder.recede_type%TYPE;--退厂类型
		v_strAuto_comfirm_flag wms_rodataorder.auto_comfirm_flag%TYPE;--标记是否自动确认
  begin
    strOutMsg := 'N|[P_RO_OutstockReturn]';

   --先取退厂类型
	 BEGIN
		 SELECT m.recede_type INTO v_strRecedeType
		 FROM rodata_outstock_m m WHERE
		 m.enterprise_no = strEnterPriseNo
		 AND m.warehouse_no = strWarehose_No
		 AND m.owner_no = strOwnerNo
		 AND m.outstock_no = strOutStockNo;
		 exception
      when no_data_found THEN
				strOutMsg := 'N|[找不到对应的退货类型]';
				return;
	 END;

    P_SaveOutstock(strEnterPriseNo,
                   strWarehose_No,
                   strOwnerNo,
                   strOutStockNo,
                   strLabelNo,
                   strArticleNo,
                   strBarcode,
                   nPackingQTY,
                   strQuality,
                   dtProduceDate,
                   dtExpireDate,
                   strLotNo,
                   strRSV_BATCH1,
                   strRSV_BATCH2,
                   strRSV_BATCH3,
                   strRSV_BATCH4,
                   strRSV_BATCH5,
                   strRSV_BATCH6,
                   strRSV_BATCH7,
                   strRSV_BATCH8,
                   strScellNo,
                   nArticleQTY,
                   nRealQTY,
                   strRealCellNo,
                   strOutUserID,
                   strUserID,
                   '1',
                   strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    ---回单先不自动确认。。依据配置来处理 sunl 2016年7月22日

    --根据货主仓别级别对应的单据类型获取是否需要自动确认的标识
    begin
      select Auto_comfirm_flag
        into v_strAuto_comfirm_flag
        from wms_warehouse_rodataorder
       where enterprise_no = strEnterPriseNo
         and warehouse_no = strWarehose_No
         and owner_no = strOwnerNo
         and recede_type = v_strRecedeType;
    exception
      when no_data_found then
        --获取货主级别对应的标识
        begin
          select Auto_comfirm_flag
            into v_strAuto_comfirm_flag
            from wms_owner_rodataorder
           where enterprise_no = strEnterPriseNo
             and owner_no = strOwnerNo
             and recede_type = v_strRecedeType;
        exception
          when no_data_found then
            --获取系统级别对应的标识
            begin
              select Auto_comfirm_flag
                into v_strAuto_comfirm_flag
                from wms_rodataorder
               where enterprise_no = strEnterPriseNo
                 and recede_type = v_strRecedeType;
            exception
              when no_data_found then
                strOutMsg := 'N|[找不到对应的单据配置]';
                return;
            end;
        end;
    end;

		if(v_strAuto_comfirm_flag = '1') THEN
			for GetRecede in (select distinct recede_no
													from rodata_box_d
												 where enterprise_no = strEnterPriseNo
													 and warehouse_no = strWarehose_No
													 and outstock_no = strOutStockNo) loop
				v_iCount := v_iCount + 1;
				--退货确认
				P_RO_Confirm(strEnterPriseNo,
										 strWarehose_No,
										 strOwnerNo,
										 GetRecede.recede_no,
										 strUserID,
										 strDockNo,
										 v_strDeliverNo,
										 strOutMsg);
				if substr(strOutMsg, 1, 1) <> 'Y' then
					return;
				end if;

			end loop;

			--更新退货单头档
			if v_iCount > 0 then
				--
				pkobj_rodata.P_RO_UpdateRecedeHeader(strEnterPriseNo,
																						 strWarehose_No,
																						 v_strDeliverNo,
																						 strOwnerNo,
																						 strUserID,
																						 '13',
																						 strOutMsg);
				if substr(strOutMsg, 1, 1) <> 'Y' then
					return;
				end if;
			end if;

    END IF;
		strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_RO_OutstockReturn;

  /*********************************************************************************************
  创建人：luozhiling
  创建时间：2014.11.8
  功能说明：扫描完成后，对退货单做整单回单，扣减库存处理。
  ************************************************************************************************/
  procedure P_PO_ScanSaveComfire(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                                 strWarehose_No  in rodata_outstock_m.warehouse_no%type,
                                 strOwnerNo      in rodata_outstock_m.owner_no%type,
                                 strOutStockNo   in rodata_outstock_d.outstock_no%type,
                                 strScanUserId   in rodata_outstock_d.outstock_name%type,
                                 strUserID       in rodata_outstock_d.assign_name%type,
                                 strDockNo       in bdef_defdock.dock_no%type,
                                 strOutMsg       out varchar2) is
    v_iCount     integer;
    v_strOwnerNo rodata_outstock_m.owner_no%type;
  begin
    strOutMsg := 'N|[P_PO_ScanSaveComfire]';

    --更新库存\退货单明细\下架单明细
    PKOBJ_STOCK.p_WM_Receipt_WriteContent(strEnterPriseNo,
                                          strWarehose_No,
                                          strOutStockNo,
                                          '1',
                                          strUserID,
                                          strOutMsg);

    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    --更新退货下架单头
    select count(1)
      into v_iCount
      from rodata_outstock_d d
     where d.status = '10'
       and d.enterprise_no = strEnterPriseNo
       and d.warehouse_no = strWarehose_No
       and d.outstock_no = strOutStockNo;
    if v_iCount > 0 then
      return;
    end if;

    --根据下架单查找货主
    select owner_no
      into v_strOwnerNo
      from rodata_outstock_m d
     where d.enterprise_no = strEnterPriseNo
       and d.warehouse_no = strWarehose_No
       and d.outstock_no = strOutStockNo;

    --更新下架单头档
    pkobj_rodata.P_RO_UpdateOutStockHeader(strEnterPriseNo,
                                           strWarehose_No,
                                           strOutStockNo,
                                           v_strOwnerNo,
                                           strUserID,
                                           strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    --根据下架单号更新退货单主档
    pkobj_rodata.P_RO_UpdateRecedeHeader(strEnterPriseNo,
                                         strWarehose_No,
                                         strOutStockNo,
                                         v_strOwnerNo,
                                         strUserID,
                                         '14',
                                         strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    --写箱明细
    P_CreateRecedeBox(strEnterPriseNo,
                      strWarehose_No,
                      v_strOwnerNo,
                      strOutStockNo,
                      strUserID,
                      strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_PO_ScanSaveComfire;

  /*********************************************************************************************
  创建人：luozhiling
  创建时间：2015.11.2
  功能说明：按SKU退货下架回单(支持多生产日期等属性）,不扣减库存
  ************************************************************************************************/
  procedure P_MulRsvSaveOutstock(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                                 strWarehose_No  in rodata_outstock_m.warehouse_no%type,
                                 strOwnerNo      in rodata_outstock_m.owner_no%type,
                                 strOutStockNo   in rodata_outstock_d.outstock_no%type,
                                 strsLabelNo     in rodata_outstock_d.s_label_no%type,
                                 strArticleNo    in rodata_outstock_d.article_no%type,
                                 nPackingQTY     in rodata_outstock_d.packing_qty%type,
                                 strQuality      in idata_check_d.quality%type, --品质
                                 dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                                 dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                                 strLotNo        in stock_article_info.lot_no%type, --批次号
                                 strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                                 strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                                 strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                                 strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                                 strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                                 strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                                 strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                                 strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                                 strScellNo      in rodata_outstock_d.s_cell_no%type,
                                 nArticleQTY     in rodata_outstock_d.article_qty%type,
                                 nRealQTY        in rodata_outstock_d.real_qty%type,
                                 strRealCellNo   in rodata_outstock_d.outstock_cell_no%type,
                                 strOutUserID    in rodata_outstock_d.outstock_name%type,
                                 strUserID       in rodata_outstock_d.assign_name%type,
                                 strDockNo       in bdef_defdock.dock_no%type,
                                 strOutMsg       out varchar2) is
    v_TotalRealQTY  rodata_outstock_d.article_qty%type := nRealQTY;
    v_RealQTY       rodata_outstock_d.article_qty%type := 0;
    v_iCount        integer := 0;
    v_strTaskType   rodata_outstock_m.Task_Type%type;
    v_strRecedeType rodata_outstock_m.recede_type%type;
    v_strClassType  rodata_outstock_m.class_type%type;
  begin
    --更新表单拣货下架明细
    strOutMsg := 'N|[P_MulRsvSaveOutstock]';

    select rom.task_type, rom.recede_type, rom.class_type
      into v_strTaskType, v_strRecedeType, v_strClassType
      from rodata_outstock_m rom
     where rom.enterprise_no = strEnterPriseNo
       and rom.warehouse_no = strWarehose_No
       and rom.outstock_no = strOutStockNo;

    if v_strTaskType = '1' and v_strClassType = '0' then
      --清场的退货拣货走特殊流程,整单回单后转分播单，不经过扫描
      P_SpecialSaveOutstock(strEnterPriseNo,
                            strWarehose_No,
                            strOwnerNo,
                            strOutStockNo,
                            strsLabelNo,
                            strArticleNo,
                            nPackingQTY,
                            strQuality,
                            dtProduceDate,
                            dtExpireDate,
                            strLotNo,
                            strRSV_BATCH1,
                            strRSV_BATCH2,
                            strRSV_BATCH3,
                            strRSV_BATCH4,
                            strRSV_BATCH5,
                            strRSV_BATCH6,
                            strRSV_BATCH7,
                            strRSV_BATCH8,
                            strScellNo,
                            nArticleQTY,
                            nRealQTY,
                            strOutUserID,
                            strUserID,
                            '1',
                            strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
    else
      for curOutstockInfor in (select ood.*
                                 from rodata_outstock_m  oom,
                                      rodata_outstock_d  ood,
                                      stock_article_info sai
                                where oom.enterprise_no = ood.enterprise_no
                                  and oom.enterprise_no = sai.enterprise_no
                                  and oom.warehouse_no = ood.warehouse_no
                                  and oom.outstock_no = ood.outstock_no
                                  and ood.article_no = sai.article_no
                                  and ood.article_id = sai.article_id
                                  and oom.enterprise_no = strEnterPriseNo
                                  and oom.warehouse_no = strWarehose_No
                                  and oom.outstock_no = strOutStockNo
                                  and ood.s_label_no = strsLabelNo
                                  and oom.task_type = '1'
                                  and ood.article_no = strArticleNo
                                  and ood.s_cell_no = strScellNo
                                  and ood.packing_qty = nPackingQTY
                                  and sai.produce_date = dtProduceDate
                                  and sai.expire_date = dtExpireDate
                                  and sai.lot_no = strLotNo
                                  and sai.quality = strQuality
                                  and sai.rsv_batch1 = strRSV_BATCH1
                                  and sai.rsv_batch2 = strRSV_BATCH2
                                  and sai.rsv_batch3 = strRSV_BATCH3
                                  and sai.rsv_batch4 = strRSV_BATCH4
                                  and sai.rsv_batch5 = strRSV_BATCH5
                                  and sai.rsv_batch6 = strRSV_BATCH6
                                  and sai.rsv_batch7 = strRSV_BATCH7
                                  and sai.rsv_batch8 = strRSV_BATCH8
                                  and ood.status = '10'
                                  for update) loop

        v_iCount := v_iCount + 1;
        --有拆指示
        if v_TotalRealQTY >= curOutstockInfor.Article_Qty then
          v_RealQTY := curOutstockInfor.Article_Qty;
        else
          v_RealQTY := v_TotalRealQTY;
        end if;

        --更新下架明细；
        pkobj_rodata.P_RO_UpdateOutstockQty(strEnterPriseNo,
                                            curOutstockInfor.warehouse_no,
                                            strOutStockNo,
                                            v_RealQTY,
                                            strRealCellNo,
                                            strOwnerNo,
                                            curOutstockInfor.Row_Id,
                                            strOutUserID,
                                            strOutMsg);

        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;

        v_TotalRealQTY := v_TotalRealQTY - v_RealQTY;

        --将下架指示转历史
        pkobj_rodata.P_RO_InsertOutStockDirectHTY(strEnterPriseNo,
                                                  strWarehose_No,
                                                  strOwnerNo,
                                                  curOutstockInfor.Divide_Id,
                                                  strUserID,
                                                  strOutMsg);

      end loop;

      if v_iCount = 0 then
        strOutMsg := 'N|[]'; --找不到对应的下架数据
        return;
      end if;

      ---更新下架单头档
      UPDATE rodata_outstock_m OOM
         SET OOM.UPDT_DATE = SYSDATE,
             OOM.UPDT_NAME = strUserId,
             OOM.STATUS    = '11'
       where oom.enterprise_no = strEnterPriseNo
         and oom.warehouse_no = strWarehose_No
         and oom.outstock_no = strOutStockNo
         and oom.owner_no = strOwnerNo
         and oom.status = '10'
         and not exists (select 'x'
                from rodata_outstock_d
               where warehouse_no = strWarehose_No
                 and owner_no = strOwnerNo
                 and outstock_no = strOutStockNo
                 and status = '10');

    end if;
    strOutMsg := 'Y|[成功]';

  end P_MulRsvSaveOutstock;

  /*********************************************************************************************
  创建人：luozhiling
  创建时间：2014.11.8
  功能说明：退货下架扫描
  ************************************************************************************************/
  procedure P_PO_ScanOutstock(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                              strWarehose_No  in rodata_outstock_m.warehouse_no%type,
                              strOwnerNo      in rodata_outstock_m.owner_no%type,
                              strOutStockNo   in rodata_outstock_d.outstock_no%type,
                              strSourceNo     in rodata_outstock_d.source_no%type,
                              strArticleNo    in rodata_outstock_d.article_no%type,
                              strLabelNo      in rodata_outstock_d.label_no%type, -- 目的标签号
                              nPackingQTY     in rodata_outstock_d.packing_qty%type,
                              nRealQTY        in rodata_outstock_d.real_qty%type,
                              strScanUserId   in rodata_outstock_d.scan_name%type,
                              strDockNo       in bdef_defdock.dock_no%type,
                              strOutMsg       out varchar2) is
    v_nRemainQty rodata_outstock_d.article_qty%type := nRealQTY;
    v_nCurrQty   rodata_outstock_d.article_qty%type := 0;
    v_iCount     integer := 0;
  begin
    strOutMsg := 'N|[P_PO_ScanOutstock]';

    --校验此标签号是否可用

    select count(*)
      into v_iCount
      from rodata_outstock_d ood
     where ood.enterprise_no = strEnterPriseNo
       and ood.warehouse_no = strWarehose_No
       and (ood.label_no = strLabelNo or ood.s_label_no = strLabelNo)
       and ood.outstock_no <> strOutStockNo;

    if v_iCount > 0 then
      strOutMsg := 'N|[此标签已被占用，不可用]';
      return;
    end if;

    if v_iCount = 0 then
      --检查是否是已封箱标签
      select count(*)
        into v_iCount
        from rodata_box_d ood
       where ood.enterprise_no = strEnterPriseNo
         and ood.warehouse_no = strWarehose_No
         and ood.label_no = strLabelNo;
      if v_iCount > 0 then
        strOutMsg := 'N|[此标签已被占用，不可用]';
        return;
      end if;
    end if;

    for curOutstockInfor in (select *
                               from rodata_outstock_d d
                              where d.enterprise_no = strEnterPriseNo
                                and d.warehouse_no = strWarehose_No
                                and d.owner_no = strOwnerNo
                                and d.outstock_no = strOutStockNo
                                and d.source_no = strSourceNo
                                and d.article_no = strArticleNo
                                and d.packing_qty = nPackingQTY
                                and d.label_no = 'N'
                                and d.status = '11'
                                and d.outstock_qty - d.real_qty > 0
                                for update) loop

      v_iCount := v_iCount + 1;

      if v_nRemainQty >
         curOutstockInfor.outstock_qty - curOutstockInfor.real_qty then
        v_nCurrQty := curOutstockInfor.outstock_qty -
                      curOutstockInfor.real_qty;
      else
        v_nCurrQty := v_nRemainQty;
      end if;

      v_nRemainQty := v_nRemainQty - v_nCurrQty;

      --更新箱明细
      update rodata_outstock_d t
         set t.article_qty  = t.article_qty + v_nCurrQty,
             t.outstock_qty = t.outstock_qty + v_nCurrQty,
             t.real_qty     = t.real_qty + v_nCurrQty,
             t.scan_name    = strScanUserId,
             t.scan_date    = sysdate
       where t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strWarehose_No
         and t.owner_no = strOwnerNo
         and t.outstock_no = strOutStockNo
         and t.article_no = strArticleNo
         AND T.divide_id = curOutstockInfor.divide_id
         and t.source_no = curOutstockInfor.source_no
         and t.s_cell_no = curOutstockInfor.s_cell_no
         and t.s_cell_id = curOutstockInfor.s_cell_id
         and t.outstock_cell_no = curOutstockInfor.outstock_cell_no
         and t.label_no = strLabelNo
         and t.status = '11';

      if sql%notfound then
        --若更新不到数据，需要拆下架明细

        --新增下架明细
        Pkobj_rodata.P_RO_InsertOutStockItem(strEnterPriseNo,
                                             strWarehose_No,
                                             strOwnerNo,
                                             strOutStockNo,
                                             curOutstockInfor.article_no,
                                             curOutstockInfor.s_cell_no,
                                             curOutstockInfor.s_cell_id,
                                             v_nCurrQty,
                                             v_nCurrQty,
                                             curOutstockInfor.outstock_cell_no,
                                             curOutstockInfor.s_label_no,
                                             strLabelNo,
                                             curOutstockInfor.divide_id,
                                             strScanUserId,
                                             strOutMsg);

        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
      end if;

      --扣减原下架明细
      update rodata_outstock_d t
         set t.outstock_qty = t.outstock_qty - v_nCurrQty,
             t.article_qty  = t.article_qty - v_nCurrQty
       where t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strWarehose_No
         and t.owner_no = strOwnerNo
         and t.outstock_no = strOutStockNo
         and t.article_no = strArticleNo
         AND T.divide_id = curOutstockInfor.divide_id
         and t.source_no = curOutstockInfor.source_no
         and t.s_cell_no = curOutstockInfor.s_cell_no
         and t.s_cell_id = curOutstockInfor.s_cell_id
         and t.outstock_cell_no = curOutstockInfor.outstock_cell_no
         and t.source_no = strSourceNo
         and t.label_no = curOutstockInfor.label_no
         and t.row_id = curOutstockInfor.row_id
         and t.status = '11'
         and t.outstock_qty - t.real_qty > 0;

      if sql%notfound then
        strOutMsg := 'N|[E25203]';
        return;
      end if;

      --删除数量为0的数据
      delete from rodata_outstock_d
       where enterprise_no = strEnterPriseNo
         and warehouse_no = strWarehose_No
         and owner_no = strOwnerNo
         and outstock_no = strOutStockNo
         and article_no = strArticleNo
         AND divide_id = curOutstockInfor.divide_id
         and source_no = curOutstockInfor.source_no
         and s_cell_no = curOutstockInfor.s_cell_no
         and s_cell_id = curOutstockInfor.s_cell_id
         and status = '11'
         and article_qty = 0
         and real_qty = 0
         and outstock_qty = 0;

    end loop;

    if v_nRemainQty > 0 then
      strOutMsg := 'N|[扫描超量]'; --扫描超量
      return;
    end if;
    strOutMsg := 'Y|[成功]';
  end P_PO_ScanOutstock;

  /*********************************************************************************************
  创建人：luozhiling
  创建时间：2014.11.8
  功能说明：退货下架扫描封箱
  ************************************************************************************************/

  procedure P_RO_ScanCloseBox(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                              strWarehose_No  in rodata_outstock_m.warehouse_no%type,
                              strOwnerNo      in rodata_outstock_m.owner_no%type,
                              strLabelNo      in rodata_outstock_d.label_no%type,
                              strUserId       in rodata_outstock_d.scan_name%type,
                              strDockNo       in bdef_defdock.dock_no%type,
                              strOutMsg       out varchar2) is

    v_PrintTaskNo job_printtask_m.task_no%type;
  begin
    strOutMsg := 'N|[P_RO_ScanCloseBox]';

    --写打印任务头档

    PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterPriseNo,
                                        strWarehose_No,
                                        strLabelNo,
                                        '0',
                                        CONST_REPORTID.RPT_WM_BOXNO,
                                        strDockNo,
                                        '0',
                                        strUserId,
                                        v_PrintTaskNo,
                                        strOutMsg);

    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterPriseNo,
                                        strWarehose_No,
                                        strLabelNo,
                                        '0',
                                        CONST_REPORTID.RPT_WM_BOXITEM,
                                        strDockNo,
                                        '0',
                                        strUserId,
                                        v_PrintTaskNo,
                                        strOutMsg);

    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    /* --修改下架明细的状态为12，封箱后标签状态为12
    update rodata_outstock_d d set d.status='12'
      where d.enterprise_no=strEnterPriseNo
      and d.warehouse_no= strWarehose_No
      and d.label_no=strLabelNo and d.status='11';*/

    strOutMsg := 'Y|[成功]';
  end P_RO_ScanCloseBox;

  /*********************************************************************************************
  创建人：luozhiling
  创建时间：2015.3.24
  功能说明：写预制退货单, 目前只能支持一个物流箱对应一张退货单
  ************************************************************************************************/
  procedure P_InsertDeliver_List(strEnterPriseNo IN rodata_outstock_m.enterprise_no%type,
                                 strWarehose_No  in rodata_outstock_m.warehouse_no%type,
                                 strOwnerNo      in rodata_outstock_m.owner_no%type,
                                 strRecedeNo     in rodata_outstock_d.source_no%type,
                                 strUserID       in rodata_outstock_d.assign_name%type,
                                 strDock_No      in bdef_defdock.dock_no%type,
                                 strDeliverNo    out rodata_deliver_m.deliver_no%type,
                                 strOutMsg       out varchar2) is
    v_iCount       integer;
    v_strDeliverNo rodata_deliver_m.deliver_no%type;
  begin
    --写预制退货单
    strOutMsg      := 'N|[P_InsertDeliver_List]';
    v_iCount       := 0;
    v_strDeliverNo := 'N';
    for curOutstockInfor in (select *
                               from rodata_box_d d
                              where d.enterprise_no = strEnterPriseNo
                                and d.warehouse_no = strWarehose_No
                                and d.owner_no = strOwnerNo
                                and d.recede_no = strRecedeNo
                                and d.status = '0'
                                and d.article_qty > 0
                              order by d.outstock_no
                                for update) loop
      if v_iCount = 0 then
        --取下架单号
        PKLG_WMS_BASE.p_getsheetno(strEnterPriseNo,
                                   strWarehose_No,
                                   CONST_DOCUMENTTYPE.ODATARL,
                                   v_strDeliverNo,
                                   strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;

        --定退货清单头档
        pkobj_rodata.P_RO_WriteWmDeliverHead(strEnterPriseNo,
                                             strWarehose_No,
                                             strOwnerNo,
                                             v_strDeliverNo,
                                             strUserID,
                                             '10',
                                             strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
      end if;

      if v_strDeliverNo = 'N' then
        select deliver_no
          into v_strDeliverNo
          from rodata_deliver_d t
         where t.enterprise_no = strEnterPriseNo
           and t.warehouse_no = strWarehose_No
           and t.recede_no = strRecedeNo
           and rownum = 1;

      end if;

      strDeliverNo := v_strDeliverNo;
      pkobj_rodata.P_RO_WriteWmDeliverItem(strEnterPriseNo,
                                           strWarehose_No,
                                           strOwnerNo,
                                           v_strDeliverNo,
                                           curOutstockInfor.recede_no,
                                           curOutstockInfor.Po_Id,
                                           curOutstockInfor.Article_No,
                                           curOutstockInfor.Article_Id,
                                           curOutstockInfor.Packing_Qty,
                                           curOutstockInfor.article_qty,
                                           curOutstockInfor.article_qty,
                                           'N',
                                           curOutstockInfor.label_no,
                                           curOutstockInfor.sub_label_no,
                                           strUserID,
                                           strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      v_iCount := v_iCount + 1;

    end loop;

    if v_iCount = 0 then
      strOutMsg := 'N|[]'; --找不到对应的退货标签
      return;
    end if;

    strOutMsg := 'Y|[成功]';
  end P_InsertDeliver_List;

  /*********************************************************************************************
  创建人：luozhiling
  创建时间：2015.3.24
  功能说明：退货确认回单
  ************************************************************************************************/
  procedure P_DeliverConfirm(strEnterPriseNo IN rodata_outstock_m.enterprise_no%type,
                             strWarehose_No  in rodata_outstock_m.warehouse_no%type,
                             strOwnerNo      in rodata_outstock_m.owner_no%type,
                             strDeliverNo    in rodata_outstock_d.source_no%type, --预制退货单号
                             strUserID       in rodata_outstock_d.assign_name%type,
                             strDock_No      in bdef_defdock.dock_no%type,
                             strOutMsg       out varchar2) is
    v_iCount      integer;
    v_PrintTaskNo job_printtask_m.task_no%type;
    v_recedeNo    rodata_box_m.recede_no%type; --退货单号
  begin
    strOutMsg := 'N|[P_DeliverConfirm]';
    -- 根据退货单处理库存

    PKOBJ_STOCK.proc_RO_deliver_DelContent(strEnterPriseNo,
                                           strWarehose_No,
                                           strDeliverNo,
                                           '1',
                                           strUserID,
                                           strOutMsg);

    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    --写退货清单打印任务
    PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterPriseNo,
                                        strWarehose_No,
                                        strDeliverNo,
                                        '0',
                                        const_reportid.RPT_WM_DELIVER,
                                        strDock_No,
                                        '0',
                                        strUserId,
                                        v_PrintTaskNo,
                                        strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    --更新退货配送单头档

    update rodata_deliver_m t
       set t.status = '13'
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWarehose_No
       and t.deliver_no = strDeliverNo;

    --检查此配送单对应的退货单是否都已完成

    select count(*)
      into v_iCount
      from rodata_outstock_direct ood
     where ood.status not in ('13', '16')
       and ood.enterprise_no = strEnterPriseNo
       and ood.warehouse_no = strWarehose_No
       and ood.source_no in
           (select t.recede_no
              from rodata_deliver_d t
             where t.enterprise_no = strEnterPriseNo
               and t.warehouse_no = strWarehose_No
               and t.deliver_no = strDeliverNo);
    if v_iCount > 0 then
      strOutMsg := 'N|[P_DeliverConfirm]';
    end if;

    select count(*)
      into v_iCount
      from rodata_outstock_d ood
     where ood.status not in ('13', '16')
       and ood.enterprise_no = strEnterPriseNo
       and ood.warehouse_no = strWarehose_No
       and ood.source_no in
           (select t.recede_no
              from rodata_deliver_d t
             where t.enterprise_no = strEnterPriseNo
               and t.warehouse_no = strWarehose_No
               and t.deliver_no = strDeliverNo);
    if v_iCount > 0 then
      strOutMsg := 'N|[P_DeliverConfirm]';
    end if;

    select count(*)
      into v_iCount
      from rodata_deliver_d ood, rodata_deliver_m t
     where t.enterprise_no = ood.enterprise_no
       and t.warehouse_no = ood.warehouse_no
       and t.deliver_no = ood.deliver_no
       and t.status <> '13'
       and t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWarehose_No
       and t.deliver_no = strDeliverNo;
    if v_iCount > 0 then
      strOutMsg := 'N|[P_DeliverConfirm]';
    end if;

    --更新退货单头档
    update rodata_recede_m t
       set t.status = '13'
     where t.status not in ('13', '16')
       and t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWarehose_No
       and t.recede_no in
           (select a.recede_no
              from rodata_deliver_d a
             where a.enterprise_no = strEnterPriseNo
               and a.warehouse_no = strWarehose_No
               and a.deliver_no = strDeliverNo);

    --更新退货箱标签，并转历史
    select distinct de.recede_no
      into v_recedeNo
      from rodata_deliver_d de
     where de.enterprise_no = strEnterPriseNo
       and de.warehouse_no = strWarehose_No
       and de.deliver_no = strDeliverNo;

    update rodata_box_m m
       set m.status = '1'
     where m.status = '0'
       and m.enterprise_no = strEnterPriseNo
       and m.warehouse_no = strWarehose_No
       and m.label_no in (select de.label_no
                            from rodata_box_m de
                           where de.enterprise_no = strEnterPriseNo
                             and de.warehouse_no = strWarehose_No
                             and de.recede_no = v_recedeNo);

    update rodata_box_d d
       set d.status = '1'
     where d.status = '0'
       and d.enterprise_no = strEnterPriseNo
       and d.warehouse_no = strWarehose_No
       and d.label_no in (select distinct de.label_no
                            from rodata_box_d de
                           where de.enterprise_no = strEnterPriseNo
                             and de.warehouse_no = strWarehose_No
                             and de.recede_no = v_recedeNo);

    pkobj_rodata.P_RO_InsertBoxMHTY(strEnterPriseNo,
                                    strWarehose_No,
                                    strOwnerNo,
                                    v_recedeNo,
                                    strUserID,
                                    strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    pkobj_rodata.P_RO_InsertBoxDHTY(strEnterPriseNo,
                                    strWarehose_No,
                                    v_recedeNo,
                                    strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

		--回单不转历史：作业单据做结转，不转历史 sunl 20160721
 /*   --退厂单据转历史 huangb 20160516
    pkobj_rodata.P_RO_InsertHTY(strEnterPriseNo,
                                strWarehose_No, --仓别
                                strOwnerNo,
                                strDeliverNo, --预制退货单号
                                strUserID,
                                strOutMsg);*/
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    strOutMsg := 'Y|[成功]';
  end P_DeliverConfirm;
  /********************************************************************************************************
  功能说明：按商品做退货标签整理
            处理步骤：1、处理箱明细数据；
                      2、写标签整理日志；
                      3、扣减原标签库存；、
                      4、新增目的标签库存
        2015.8.12

  ***********************************************************************************************************/
  procedure P_ArticleMoveLabel(strEnterPriseNo in rodata_box_m.enterprise_no%type,
                               strWarehose_No  in rodata_box_m.warehouse_no%type,
                               strOwnerNo      in rodata_box_m.owner_no%type,
                               strsLabelNo     in rodata_box_m.label_no%type, --原标签
                               strdLabelNo     in rodata_box_m.label_no%type, --目的标签
                               strArticleNo    in rodata_box_d.article_no%type, --商品编码
                               nPackingQty     in rodata_box_d.packing_qty%type,
                               dtProduceDate   in stock_article_info.produce_date%type,
                               dtExpireDate    in stock_article_info.expire_date%type,
                               strQuality      in stock_article_info.quality%type,
                               strLotNo        in stock_article_info.lot_no%type,
                               nMoveQty        in stock_content.qty%type,
                               strUserId       in rodata_outstock_d.scan_name%type,
                               strOutMsg       out varchar2) is
    nCurrQty      rodata_box_d.article_qty%type;
    nRemainQty    rodata_box_d.article_qty%type := nMoveQty;
    v_iCount      integer;
    v_strStatus   rodata_box_m.status%type;
    v_strRecedeNo rodata_box_m.recede_no%type;
    v_nRowId      rodata_box_d.row_id%type;
    v_strCellId   stock_content.cell_id%type;
    v_strCellNo   rodata_box_m.owner_cell_no%type;
  begin
    strOutMsg := 'N|[P_ArticleMoveLabel]';

    --获取标签信息
    begin
      select t.recede_no, t.owner_cell_no
        into v_strRecedeNo, v_strCellNo
        from rodata_box_m t
       where t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strWarehose_No
         and t.label_no = strsLabelNo;
    exception
      when no_data_found then
        strOutMsg := 'N|[找不到来源标签]';
        return;
    end;

    --判断目的标签是否存在
    begin
      select t.status
        into v_strStatus
        from rodata_box_m t
       where t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strWarehose_No
         and t.label_no = strdLabelNo;
    exception
      when no_data_found then
        v_strStatus := 'N';
    end;

    if v_strStatus = '1' then
      strOutMsg := 'N|[]'; --该箱标签不可用
      return;
    end if;

    if v_strStatus = 'N' then
      --新标签，需要写标签头档
      Pkobj_Rodata.P_InsertRodataBoxM(strEnterPriseNo,
                                      strWarehose_No,
                                      strOwnerNo,
                                      strdLabelNo,
                                      v_strRecedeNo,
                                      v_strCellNo,
                                      strUserId,
                                      '0',
                                      strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
    end if;

    nRemainQty := nMoveQty;

    for GetBoxItem in (select sai.produce_date,
                              sai.expire_date,
                              sai.quality,
                              sai.lot_no,
                              rbd.*
                         from rodata_box_d rbd, stock_article_info sai
                        where rbd.enterprise_no = sai.enterprise_no
                          and rbd.article_no = sai.article_no
                          and rbd.article_id = sai.article_id
                          and rbd.enterprise_no = strEnterPriseNo
                          and rbd.warehouse_no = strWarehose_No
                          and rbd.article_no = strArticleNo
                          and rbd.packing_qty = nPackingQty
                          AND sai.produce_date = dtProduceDate
                          and sai.expire_date = dtExpireDate
                          and sai.quality = strQuality
                          and sai.lot_no = strLotNo
                          and rbd.label_no = strsLabelNo
                        order by rbd.article_no, rbd.article_id) loop

      --处理箱明细数据
      v_iCount := v_iCount + 1;

      if nRemainQty < GetBoxItem.article_qty then
        nCurrQty := nRemainQty;
      else
        nCurrQty := GetBoxItem.article_qty;
      end if;

      nRemainQty := nRemainQty - nCurrQty;

      --获取目的储位Row_ID,
      begin
        select row_id
          into v_nRowId
          from rodata_box_d t
         where t.enterprise_no = strEnterPriseNo
           and t.warehouse_no = strWarehose_No
           and t.label_no = strdLabelNo
           and t.recede_no = v_strRecedeNo
           and t.outstock_no = GetBoxItem.outstock_no
           and t.po_id = GetBoxItem.po_id
           and t.article_no = GetBoxItem.article_no
           and t.article_id = GetBoxItem.article_id
           and t.packing_qty = GetBoxItem.packing_qty;
      exception
        when no_data_found then
          --取最大的ROW_id
          select nvl(max(row_id), 0) + 1
            into v_nRowId
            from rodata_box_d t
           where t.enterprise_no = strEnterPriseNo
             and t.warehouse_no = strWarehose_No
             and t.label_no = strdLabelNo
             and t.recede_no = v_strRecedeNo;
      end;

      --新增目的箱明细数据
      PKOBj_rodata.P_updateInsertBoxItem(strEnterPriseNo,
                                         strWarehose_No,
                                         strOwnerNo,
                                         GetBoxItem.outstock_no,
                                         strdLabelNo,
                                         v_strRecedeNo,
                                         v_nRowId,
                                         GetBoxItem.article_no,
                                         GetBoxItem.article_id,
                                         GetBoxItem.packing_qty,
                                         GetBoxItem.po_id,
                                         nCurrQty,
                                         strUserId,
                                         '0',
                                         strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --增加目的箱明细库存
      PKOBJ_STOCK.p_InstContent_qtyByCellNo(GetBoxItem.Enterprise_No, --
                                            GetBoxItem.Warehouse_No, --仓别
                                            GetBoxItem.Owner_No, --货主
                                            'N', --部门
                                            GetBoxItem.Article_No, --商品编码
                                            GetBoxItem.Article_Id, --商品ID
                                            v_strCellNo, --目的储位
                                            v_strCellNo, --源储位
                                            GetBoxItem.Packing_Qty, --包装数量
                                            nCurrQty, --转移数量
                                            strdLabelNo, --目的标签
                                            strdLabelNo, --目的标签
                                            '3', --存储类型
                                            v_strRecedeNo, --存储类型的值
                                            strUserId, --操作人
                                            v_strRecedeNo, --整理单号
                                            '2', --操作工具
                                            1, --是否可手工移库 0:不允许手工移库；1：可手工移库
                                            v_strCellId, --返回的储位ID
                                            strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --扣减来源箱明细数据
      PKOBj_rodata.P_updateInsertBoxItem(strEnterPriseNo,
                                         strWarehose_No,
                                         strOwnerNo,
                                         GetBoxItem.outstock_no,
                                         strsLabelNo,
                                         v_strRecedeNo,
                                         GetBoxItem.row_id,
                                         GetBoxItem.article_no,
                                         GetBoxItem.article_id,
                                         GetBoxItem.packing_qty,
                                         GetBoxItem.po_id,
                                         -nCurrQty,
                                         strUserId,
                                         '0',
                                         strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --扣减来源箱明细对应库存
      PKOBJ_STOCK.p_UpdtContent_qtyByCellNo(strEnterPriseNo,
                                            strWarehose_No,
                                            strOwnerNo,
                                            GetBoxItem.article_no,
                                            GetBoxItem.article_id,
                                            v_strCellNo,
                                            v_strCellNo,
                                            GetBoxItem.Packing_Qty,
                                            nCurrQty,
                                            strsLabelNo,
                                            '3',
                                            v_strRecedeNo,
                                            strUserId,
                                            v_strRecedeNo,
                                            '0',
                                            strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --写标签转移日志
      pkobj_rodata.P_InsertLabelMoveLog(strEnterPriseNo,
                                        strWarehose_No,
                                        strOwnerNo,
                                        v_strRecedeNo,
                                        strsLabelNo,
                                        strdLabelNo,
                                        GetBoxItem.article_no,
                                        GetBoxItem.packing_qty,
                                        nCurrQty,
                                        GetBoxItem.produce_date,
                                        GetBoxItem.expire_date,
                                        GetBoxItem.quality,
                                        GetBoxItem.lot_no,
                                        v_strCellNo,
                                        v_strCellNo,
                                        strUserId,
                                        '3',
                                        strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --删除来源标签头数据
      pkobj_rodata.P_DeleteBoxHead(strEnterPriseNo,
                                   strWarehose_No,
                                   strOwnerNo,
                                   strsLabelNo,
                                   strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      if nRemainQty = 0 then
        exit;
      end if;
    end loop;
  end P_ArticleMoveLabel;
  /********************************************************************************************************
  功能说明：整箱转移退货标签
            处理步骤：1、处理箱明细数据；
                      2、写标签整理日志；
                      3、扣减原标签库存；、
                      4、新增目的标签库存
        2015.8.12
   ***********************************************************************************************************/
  procedure P_MoveLabel(strEnterPriseNo in rodata_box_m.enterprise_no%type,
                        strWarehose_No  in rodata_box_m.warehouse_no%type,
                        strOwnerNo      in rodata_box_m.owner_no%type,
                        strsLabelNo     in rodata_box_m.label_no%type, --原标签
                        strdLabelNo     in rodata_box_m.label_no%type, --目的标签
                        strUserId       in rodata_box_m.rgst_name%type,
                        strOutMsg       out varchar2) is
    v_iCount integer := 0;
  begin
    strOutMsg := 'N|[P_MoveLabel]';
    for GetBoxItem in (select sai.lot_no,
                              sai.produce_date,
                              sai.expire_date,
                              sai.quality,
                              t.recede_no,
                              t.article_no,
                              t.packing_qty,
                              sum(t.article_qty) article_qty
                         from rodata_box_d t, stock_article_info sai
                        where t.enterprise_no = sai.enterprise_no
                          and t.article_no = sai.article_no
                          and t.article_id = sai.article_id
                          and t.enterprise_no = strEnterPriseNo
                          and t.warehouse_no = strWarehose_No
                          and t.label_no = strsLabelNo
                        group by sai.lot_no,
                                 sai.produce_date,
                                 sai.expire_date,
                                 sai.quality,
                                 sai.lot_no,
                                 t.recede_no,
                                 t.article_no,
                                 t.packing_qty) loop

      v_iCount := v_iCount + 1;
      P_ArticleMoveLabel(strEnterPriseNo,
                         strWarehose_No,
                         strOwnerNo,
                         strsLabelNo,
                         strdLabelNo,
                         GetBoxItem.article_no,
                         GetBoxItem.packing_qty,
                         GetBoxItem.produce_date,
                         GetBoxItem.expire_date,
                         GetBoxItem.quality,
                         GetBoxItem.lot_no,
                         GetBoxItem.article_qty,
                         strUserId,
                         strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

    end loop;

    if v_iCount = 0 then
      strOutMsg := 'N|[]'; --找不到对应的标签
      return;
    end if;
    strOutMsg := 'Y|[]';
  end P_MoveLabel;
  /*************************************************************************************************************
  功能说明：退货标签库存回库
  处理步骤
          1、从退货标签中获取标签信息，
          2、将标签明细的数据循环转移到目的储位上；
          3、打散标签库存；
          4、将退货单库存释放为普通库存stock_value的值置回为N
  2015.10.23
  ************************************************************************************************************/
  procedure P_LabelGetCell(strEnterPriseNo in rodata_box_m.enterprise_no%type,
                           strWarehose_No  in rodata_box_m.warehouse_no%type,
                           strLabelNo      in rodata_box_m.label_no%type, --原标签
                           strUserId       in rodata_box_m.rgst_name%type,
                           strOutMsg       out varchar2) is
    v_strRecedeNo   rodata_recede_m.recede_no%type;
    v_strOwnerNo    bdef_defowner.owner_no%type;
    v_strDestCellNo cdef_defcell.cell_no%type;
    nOutCellID      stock_content.cell_id%type;
  begin
    strOutMsg := 'N|[P_LabelGetCell]';
    --
    --校验此标签表是否是退货标签；
    begin
      select t.owner_no, t.recede_no
        into v_strOwnerNo, v_strRecedeNo
        from rodata_box_m t
       where t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strWarehose_No
         and t.label_no = strLabelNo;
    exception
      when no_data_found then
        strOutMsg := 'N|[找不到对应的退货标签]';
        return;
    end;

    --校验储位是否正确
    begin
      select cd.cell_no
        into v_strDestCellNo
        from cdef_defcell    cd,
             cdef_defware    cw,
             cdef_defarea    ca,
             rodata_recede_m rrm
       where cd.enterprise_no = cw.enterprise_no
         and cd.warehouse_no = cw.warehouse_no
         and cw.enterprise_no = ca.enterprise_no
         and cw.warehouse_no = ca.warehouse_no
         and ca.ware_no = cd.ware_no
         and ca.area_no = cd.area_no
         and ca.area_usetype = '3'
         and ca.AREA_ATTRIBUTE = '3'
         and ca.ATTRIBUTE_TYPE = '6'
         and cw.org_no = rrm.org_no
         and cd.enterprise_no = rrm.enterprise_no
         and cd.warehouse_no = rrm.warehouse_no
         and rrm.recede_no = v_strRecedeNo
         and rownum = 1;
    exception
      when no_data_found then
        strOutMsg := 'N|[找不到退货的异常处理储位]';
        return;
    end;

    --根据标签明细循环处理库存
    for GetLabel in (select rbm.owner_cell_no, rbd.*
                       from rodata_box_d rbd, rodata_box_m rbm
                      where rbm.enterprise_no = rbd.enterprise_no
                        and rbm.warehouse_no = rbd.warehouse_no
                        and rbm.label_no = rbd.label_no
                        and rbd.enterprise_no = strEnterPriseNo
                        and rbd.warehouse_no = strWarehose_No
                        and rbd.label_no = strLabelNo) loop

      --增加目的储位库存
      Pkobj_stock.p_InstContent_qtyByCellNo(strEnterPriseNo,
                                            strWarehose_NO,
                                            GetLabel.owner_no,
                                            'N',
                                            GetLabel.article_no,
                                            GetLabel.article_id,
                                            v_strDestCellNo,
                                            GetLabel.owner_cell_no,
                                            GetLabel.packing_qty,
                                            GetLabel.article_qty,
                                            'N',
                                            'N',
                                            '1',
                                            'N',
                                            strUserId,
                                            v_strRecedeNo,
                                            '1',
                                            '1',
                                            nOutCellID,
                                            strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --减少来源储位库存
      Pkobj_stock.p_UpdtContent_qtyByCellNo(strEnterPriseNo,
                                            strWarehose_NO,
                                            GetLabel.owner_no,
                                            GetLabel.article_no,
                                            GetLabel.article_id,
                                            GetLabel.owner_cell_no,
                                            v_strDestCellNo,
                                            GetLabel.packing_qty,
                                            GetLabel.article_qty,
                                            strlabelNo,
                                            '3',
                                            GetLabel.recede_no,
                                            strUserId,
                                            v_strRecedeNo,
                                            '1',
                                            strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --扣减标签明细

      --更新来源箱明细状态
      update rodata_box_d t
         set t.status = '9'
       where t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strWarehose_No
         and t.label_no = strLabelNo
         and t.row_id = GetLabel.row_id
         and t.recede_no = GetLabel.recede_no;
    end loop;

    --更新标签头档状态
    update rodata_box_m t
       set t.status = '9'
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWarehose_No
       and t.label_no = strLabelNo;
    --箱标签转历史
    pkobj_rodata.P_ForLabelInsertBoxMHTY(strEnterPriseNo,
                                         strWarehose_No,
                                         v_strOwnerNo,
                                         strLabelNo,
                                         strUserID,
                                         strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    pkobj_rodata.P_ForLabelInsertBoxDHTY(strEnterPriseNo,
                                         strWarehose_No,
                                         strLabelNo,
                                         strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    strOutMsg := 'Y|[成功]';
  end P_LabelGetCell;
  /*********************************************************************************************************************
    功能说明：退货确认，用于一张退货单对应一张退货清单的情况
             处理步骤：1、根据退货单获取下架单并写预制退货单；
                       2、退货确认回单
    修改人：luozhiling
    修改时间：2015.03.24
  **********************************************************************************************************************/
  --退货确认
  procedure P_RO_Confirm(strEnterPriseNo IN rodata_outstock_m.enterprise_no%type,
                         strWarehose_No  in rodata_outstock_m.warehouse_no%type,
                         strOwnerNo      in rodata_outstock_m.owner_no%type,
                         strRecedeNo     in rodata_outstock_d.source_no%type,
                         strUserID       in rodata_outstock_d.assign_name%type,
                         strDock_No      in bdef_defdock.dock_no%type,
                         strDeliverNo    out rodata_deliver_d.deliver_no%type,
                         strOutMsg       out varchar2) is
    v_strDeliverNo rodata_deliver_m.deliver_no%type := 'N';
  begin
    strOutMsg := 'N|[P_RO_Confirm]';

    --写预制退货单

    P_InsertDeliver_List(strEnterPriseNo,
                         strWarehose_No,
                         strOwnerNo,
                         strRecedeNo,
                         strUserID,
                         strDock_No,
                         v_strDeliverNo,
                         strOutMsg);

    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    strDeliverNo := v_strDeliverNo;

    P_DeliverConfirm(strEnterPriseNo,
                     strWarehose_No,
                     strOwnerNo,
                     v_strDeliverNo,
                     strUserID,
                     strDock_No,
                     strOutMsg);

    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_RO_Confirm;
  /****************************************************************************************************888
  功能说明：1、将退货下架单的数据转到返配上架单，并写相应的库存，天天惠清场特殊流程
            注意：要求回单是的目的储位的CELL_ID不变
  *********************************************************************************************************/
  procedure P_OutStockToDivide(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                               strWarehose_No  in rodata_outstock_m.warehouse_no%type,
                               strOwnerNo      in rodata_outstock_m.owner_no%type,
                               strOutStockNo   in rodata_outstock_d.outstock_no%type,
                               strUserID       in rodata_outstock_d.assign_name%type,
                               strOutMsg       out varchar2) is
    v_nLocateCellID stock_content.cell_id%type;
    v_nRowID        ridata_locate_direct.row_id%type;
    v_strLocateNo   rodata_outstock_d.locate_no%type;
    strInstockNo    ridata_instock_m.instock_no%type;
  begin
    strOutMsg := 'N|[]';
    for GetOutStockItem in (select rrm.supplier_no,
                                   rrm.recede_type,
                                   rom.operate_type,
                                   rod.*
                              from rodata_outstock_d rod,
                                   rodata_outstock_m rom,
                                   rodata_recede_m   rrm
                             where rod.enterprise_no = rom.enterprise_no
                               and rod.warehouse_no = rom.warehouse_no
                               and rod.outstock_no = rom.outstock_no
                               and rrm.enterprise_no = rod.enterprise_no
                               and rrm.warehouse_no = rod.warehouse_no
                               and rrm.recede_no = rod.source_no
                               and rom.enterprise_no = strEnterPriseNo
                               and rom.warehouse_no = strWarehose_No
                               and rom.outstock_no = strOutStockNo
                               and rod.real_qty > 0) loop

      v_strLocateNo := GetOutStockItem.locate_no;
      --写库存(此处的来源储位是下架单的目的储位

      PKOBJ_STOCK.p_UpdtContent_Reservation(strEnterPriseNo,
                                            strWarehose_No, --仓库编码
                                            GetOutStockItem.outstock_cell_no, --来源储位
                                            GetOutStockItem.outstock_cell_id, --来源储位ID
                                            GetOutStockItem.dps_cell_no, --目的储位
                                            strOutStockNo,
                                            strOutStockNo,
                                            GetOutStockItem.real_qty, --商品数量
                                            '0', --预上类型
                                            strUserID, --操作人员
                                            v_nLocateCellID, --储位id
                                            strOutMsg);
      if substr(strOutMsg, 1, 1) = 'N' then
        return;
      end if;

      v_nRowID := SEQ_RIDATA_LOCATE_DIRECT.NEXTVAL;

      insert into ridata_instock_direct
        (enterprise_no,
         row_id,
         source_no,
         locate_no,
         auto_locate_flag,
         operate_type,
         cell_no,
         cell_id,
         warehouse_no,
         owner_no,
         article_no,
         article_id,
         packing_qty,
         dest_cell_no,
         dest_cell_id,
         instock_qty,
         status,
         label_no,
         sub_label_no,
         business_type,
         rgst_name,
         rgst_date,
         updt_name,
         updt_date,
         supplier_no,
         batch_no,
         operate_date,
         quality_flag,
         wave_no,
         untread_type,
         class_type)
      values
        (strEnterpriseNo,
         v_nRowID,
         strOutStockNo,
         strOutStockNo,
         '0',
         GetOutStockItem.operate_type,
         GetOutStockItem.outstock_cell_no,
         GetOutStockItem.outstock_cell_id,
         strWarehose_No,
         strOwnerNo,
         GetOutStockItem.article_no,
         GetOutStockItem.article_id,
         GetOutStockItem.packing_qty,
         GetOutStockItem.dps_cell_no,
         v_nLocateCellID,
         GetOutStockItem.real_qty,
         '10',
         strOutstockNo,
         strOutStockNo,
         '7',
         strUserID,
         sysdate,
         strUserID,
         sysdate,
         GetOutStockItem.supplier_no,
         GetOutStockItem.batch_no,
         trunc(sysdate),
         '2',
         v_strLocateNo,
         GetOutStockItem.recede_type,
         '1');

      --需要扣减退货单明细的定位数量
      update rodata_recede_d t
         set t.locate_qty = t.locate_qty - GetOutStockItem.real_qty
       where t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strWarehose_No
         and t.recede_no = GetOutStockItem.source_no
         and t.po_id = GetOutStockItem.po_id
         and t.article_no = GetOutStockItem.article_no
         and t.locate_qty - GetOutStockItem.real_qty >= 0;

    end loop;

    --返配上架发单
    pkobj_ridata.P_insertInstock(strEnterPriseNo,
                                 strWarehose_No,
                                 strUserID,
                                 strOutStockNo,
                                 'N',
                                 '0',
                                 strInstockNo,
                                 strOutMsg);
    if substr(strOutMsg, 1, 1) = 'N' then
      return;
    end if;

    --退货下架单转历史
    pkobj_rodata.P_RO_UpdateOutStockHistory(strEnterPriseNo,
                                            strWarehose_No,
                                            strOutStockNo,
                                            strOwnerNo,
                                            strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    strOutMsg := 'Y|[]';

  end P_OutStockToDivide;

  /*********************************************************************************************************************
    功能说明：快速退货扫描保存
             处理步骤：1、根据退货单获取下架单并写预制退货单；
                       2、退货确认回单
    修改人：lizhiping
    修改时间：2016.01.13
  **********************************************************************************************************************/
  procedure p_save_scan_recede(strEnterPriseNo IN rodata_recede_d.enterprise_no%type,
                               strWarehose_No  in rodata_recede_d.warehouse_no%type,
                               strOwnerNo      in rodata_recede_d.owner_no%type,
                               strRecedeNo     in rodata_recede_d.recede_no%type,
                               strArticleNo    in rodata_recede_d.article_no%type,
                               nScanQty        in rodata_recede_d.budget_qty%type,
                               strUserID       in rodata_recede_d_scanlog.rgst_name%type,
                               strOutMsg       out varchar2) is


    v_nRefQty    rodata_recede_d.budget_qty%type;
    v_nBudgetQty rodata_recede_d.budget_qty%type;
    v_nScanBudgetQty rodata_recede_d.budget_qty%type;
    v_nCurrUserScanBudgetQty rodata_recede_d.budget_qty%type;
    v_nSumQty    stock_content.qty%type;

    v_strOverFlag wms_rodataorder.over_qty_flag%type;
  begin
    strOutMsg := 'Y|';
    --获取退货单是否允许超量信息
    select nvl(wwr.over_qty_flag, nvl(wor.over_qty_flag, wr.over_qty_flag))
      into v_strOverFlag
      from wms_rodataorder wr
      left join wms_owner_rodataorder wor
        on wor.enterprise_no = wr.enterprise_no
       and wor.recede_type = wr.recede_type
       and wor.owner_no = strOwnerNo
      left join wms_warehouse_rodataorder wwr
        on wwr.enterprise_no = wr.enterprise_no
       and wwr.recede_type = wr.recede_type
       and wwr.warehouse_no = strWarehose_No
       and wwr.owner_no = strOwnerNo
     where wr.enterprise_no = strEnterPriseNo
       and wr.recede_type in
           (select rrm.recede_type
              from rodata_recede_m rrm
             where rrm.enterprise_no = strEnterPriseNo
               and rrm.warehouse_no = strWarehose_No
               and rrm.recede_no = strRecedeNo);

    --锁定商品
    update bdef_defarticle bda
       set bda.status = bda.status
     where bda.enterprise_no = strEnterPriseNo
       and bda.article_no = strArticleNo;

    --判断是否存在于退货单中的商品，以及是否超出订单中的数量

    select nvl(sum(rrd.recede_qty), -1), nvl(sum(rrd.budget_qty), -1)
      into v_nRefQty, v_nBudgetQty
      from rodata_recede_d rrd
     where rrd.enterprise_no = strEnterPriseNo
       and rrd.warehouse_no = strWarehose_No
       and rrd.recede_no = strRecedeNo
       and rrd.owner_no = strOwnerNo
       and rrd.article_no = strArticleNo;
    if v_nRefQty < 0 then
      strOutMsg := 'N|当前退货类型不支持超品';
      return;
    end if;


    select nvl(sum(budget_qty),0) into v_nScanBudgetQty
    from rodata_recede_d_scanlog rrds
     where rrds.enterprise_no = strEnterPriseNo
       and rrds.warehouse_no = strWarehose_No
       and rrds.recede_no = strRecedeNo
       and rrds.article_no = strArticleNo;


    select nvl(sum(budget_qty),0) into v_nCurrUserScanBudgetQty
    from rodata_recede_d_scanlog rrds
     where rrds.enterprise_no = strEnterPriseNo
       and rrds.warehouse_no = strWarehose_No
       and rrds.recede_no = strRecedeNo
       and rrds.article_no = strArticleNo
       and rrds.rgst_name = strUserID;

    if nScanQty < 0 then

      if v_nCurrUserScanBudgetQty <= 0 then
        strOutMsg := 'N|当前商品已无量可扣';
        return;
      end if;

    else
      if v_strOverFlag = '0' and (nScanQty + v_nBudgetQty + v_nScanBudgetQty) > v_nRefQty then
        strOutMsg := 'N|当前退货类型不支持超量';
        return;
      end if;
    end if;

    --判断是否超过库存总量
    if nScanQty > 0 then
      select nvl(sum(sc.qty + sc.instock_qty - sc.outstock_qty +
                     sc.unusual_qty),
                 0)
        into v_nSumQty
        from stock_content sc
       where sc.enterprise_no = strEnterPriseNo
         and sc.warehouse_no = strWarehose_No
         and sc.article_no = strArticleNo
         and exists
       (select 'x'
                from cdef_defcell cdc, cdef_defware cw, rodata_recede_m rrm
               where cw.enterprise_no = cdc.enterprise_no
                 and cw.warehouse_no = cdc.warehouse_no
                 and cw.ware_no = cdc.ware_no
                 and cw.org_no = rrm.org_no
                 and cdc.enterprise_no = sc.enterprise_no
                 and cdc.warehouse_no = sc.warehouse_no
                 and cdc.cell_no = sc.cell_no
                 and cdc.cell_status in ('0') --正常货位
                 and rrm.enterprise_no = strEnterPriseNo
                 and rrm.warehouse_no = strWarehose_No
                 and rrm.recede_no = strRecedeNo);

      if (nScanQty + v_nBudgetQty + v_nScanBudgetQty) > v_nSumQty then
        strOutMsg := 'N|系统库存账不足';
        return;
      end if;
    end if;


    --增加扫描日志
    update rodata_recede_d_scanlog rrds
       set rrds.budget_qty = nvl(rrds.budget_qty,0) + nScanQty,
           rrds.updt_name  = strUserID,
           rrds.updt_date  = sysdate
     where rrds.enterprise_no = strEnterPriseNo
       and rrds.warehouse_no = strWarehose_No
       and rrds.recede_no = strRecedeNo
       and rrds.article_no = strArticleNo
       and rrds.rgst_name = strUserID;
    if sql%notfound then
      insert into rodata_recede_d_scanlog
        (enterprise_no,
         warehouse_no,
         owner_no,
         recede_no,
         article_no,
         budget_qty,
         rgst_name,
         rgst_date)
      values
        (strEnterPriseNo,
         strWarehose_No,
         strOwnerNo,
         strRecedeNo,
         strArticleNo,
         nScanQty,
         strUserID,
         sysdate);
    end if;

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_save_scan_recede;


  /*********************************************************************************************************************
    功能说明：快速退货换箱
    修改人：lizhiping
    修改时间：2016.01.15
  **********************************************************************************************************************/
  procedure p_cut_scan_recede(strEnterPriseNo IN rodata_recede_d.enterprise_no%type,
                               strWarehose_No  in rodata_recede_d.warehouse_no%type,
                               strOwnerNo      in rodata_recede_d.owner_no%type,
                               strRecedeNo     in rodata_recede_d.recede_no%type,
                               strUserID       in rodata_recede_d_scanlog.rgst_name%type,
                               strOutMsg       out varchar2) is

    v_nTotalQty rodata_recede_d.budget_qty%type;
    v_nAllogQty rodata_recede_d.budget_qty%type;

    v_strOverFlag wms_rodataorder.over_qty_flag%type;
  begin

    strOutMsg := 'Y|';
    --获取退货单是否允许超量信息
    select nvl(wwr.over_qty_flag, nvl(wor.over_qty_flag, wr.over_qty_flag))
      into v_strOverFlag
      from wms_rodataorder wr
      left join wms_owner_rodataorder wor
        on wor.enterprise_no = wr.enterprise_no
       and wor.recede_type = wr.recede_type
       and wor.owner_no = strOwnerNo
      left join wms_warehouse_rodataorder wwr
        on wwr.enterprise_no = wr.enterprise_no
       and wwr.recede_type = wr.recede_type
       and wwr.warehouse_no = strWarehose_No
       and wwr.owner_no = strOwnerNo
     where wr.enterprise_no = strEnterPriseNo
       and wr.recede_type in
           (select rrm.recede_type
              from rodata_recede_m rrm
             where rrm.enterprise_no = strEnterPriseNo
               and rrm.warehouse_no = strWarehose_No
               and rrm.recede_no = strRecedeNo);

    for v_cs_scan in (select rrds.article_no,sum(rrds.budget_qty) as budget_qty
       from  rodata_recede_d_scanlog rrds
     where rrds.enterprise_no = strEnterPriseNo
       and rrds.warehouse_no = strWarehose_No
       and rrds.recede_no = strRecedeNo
       and rrds.rgst_name = strUserID
       group by rrds.article_no) loop
      --循环修改明细数量
      v_nTotalQty := v_cs_scan.budget_qty;

      for v_csRecede_d in (select rrd.PO_ID,
                                  rrd.recede_qty,
                                  nvl(rrd.budget_qty,0) as budget_qty
                             from rodata_recede_d rrd
                            where rrd.enterprise_no = strEnterPriseNo
                              and rrd.warehouse_no = strWarehose_No
                              and rrd.recede_no = strRecedeNo
                              and rrd.owner_no = strOwnerNo
                              and rrd.article_no = v_cs_scan.article_no) loop


        --允许超量，直接把量记录到第一条
        if v_strOverFlag = '1' then
          v_nAllogQty := v_nTotalQty;
        else
          v_nAllogQty := v_csRecede_d.Recede_Qty -
                         v_csRecede_d.Budget_Qty;
          if v_nAllogQty > v_nTotalQty then
            v_nAllogQty := v_nTotalQty;
          end if;
        end if;
        v_nTotalQty := v_nTotalQty - v_nAllogQty;

        update rodata_recede_d rrd
           set rrd.budget_qty = nvl(rrd.budget_qty,0) + v_nAllogQty
         where rrd.enterprise_no = strEnterPriseNo
           and rrd.warehouse_no = strWarehose_No
           and rrd.owner_no = strOwnerNo
           and rrd.recede_no = strRecedeNo
           and rrd.po_id = v_csRecede_d.Po_Id;

        if v_nTotalQty <= 0 then
          exit;
        end if;
      end loop;
    end loop;


    insert into rodata_recede_d_scanloghty(enterprise_no, warehouse_no, owner_no,
      recede_no, article_no, budget_qty,
      rgst_name, rgst_date, updt_name, updt_date)
    select enterprise_no, warehouse_no, owner_no,
      recede_no, article_no, budget_qty,
      rgst_name, rgst_date, updt_name, updt_date
    from  rodata_recede_d_scanlog rrds
     where rrds.enterprise_no = strEnterPriseNo
       and rrds.warehouse_no = strWarehose_No
       and rrds.recede_no = strRecedeNo
       and rrds.rgst_name = strUserID;


     delete from  rodata_recede_d_scanlog rrds
     where rrds.enterprise_no = strEnterPriseNo
       and rrds.warehouse_no = strWarehose_No
       and rrds.recede_no = strRecedeNo
       and rrds.rgst_name = strUserID;

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_cut_scan_recede;

  /*********************************************************************************************
  功能说明：校验指定目的储位是否合法

  *********************************************************************************************/
  procedure P_CheckLocateCell(strEnterPriseNo in rodata_recede_m.enterprise_no%type,
                                strWareHouseNo  in rodata_recede_m.WAREHOUSE_NO%type, --仓库编码
                                strOwnerNo      in rodata_recede_m.owner_no%type, --委托业主编码
                                strRecedeNo     in rodata_recede_m.recede_no%type, --进货汇总单号
                                strDestCellNo   in cdef_defcell.cell_no%type,
                                strResult       out varchar2)is
       v_strOrgNo               rodata_recede_m.org_no%type;
       v_strDestCellOrgNo       rodata_recede_m.org_no%type;
  begin

       if strDestCellNo<>'N' or strDestCellNo is not null then --校验货位;
         -- 货位必须存在且同机构
        --获取退货单的机构
        begin
            select nvl(rrm.org_no,'N') into v_strOrgNo from rodata_recede_m rrm
            where rrm.enterprise_no=strEnterPriseNo
            and rrm.warehouse_no=strWareHouseNo and rrm.recede_no=strRecedeNo;
        exception when no_data_found then
             strResult:='N|[找不到对应的退货单]';
             return;
        end;

        --获取目的储位对应的机构
        begin
            select cw.org_no into v_strDestCellOrgNo from cdef_defcell cd,cdef_defware cw,cdef_defarea ca
            where cd.enterprise_no=cw.enterprise_no and cd.warehouse_no=cw.warehouse_no
            and cd.enterprise_no=ca.enterprise_no and cd.warehouse_no=ca.warehouse_no
            and cd.ware_no=ca.ware_no and cd.area_no=ca.area_no and ca.AREA_ATTRIBUTE='0'
            and cd.cell_status='0'
            and cd.ware_no=cw.ware_no and cd.cell_no=strDestCellNo;
        exception when no_data_found then
             strResult:='N|[目的储位不存在或不是作业区]';
             return;
        end;

        if v_strOrgNo<>v_strDestCellOrgNo then
             strResult:='N|[目的储位的机构与退货单不是同一机构]';
             return;
        end if;
      end if;
      strResult:='Y|[]';
   end P_CheckLocateCell;

end pklg_rodata;

/

