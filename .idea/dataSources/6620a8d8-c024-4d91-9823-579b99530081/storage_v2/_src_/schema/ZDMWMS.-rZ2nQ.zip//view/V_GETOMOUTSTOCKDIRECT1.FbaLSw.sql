create view V_GETOMOUTSTOCKDIRECT1 as
SELECT ood.enterprise_no,OOD.WAREHOUSE_NO,
       OOD.OWNER_NO,
       OOD.OUTSTOCK_TYPE,
       OOD.OPERATE_TYPE,
       OOD.OPERATE_DATE,
       OOD.PICK_TYPE,
       OOD.BATCH_NO,
       OOD.DIRECT_SERIAL,
       OOD.WAVE_NO,
       OOD.EXP_TYPE,
       OOD.EXP_NO,
       OOD.CUST_NO,
       OOD.SUB_CUST_NO,
       OOD.ARTICLE_NO,
       OOD.ARTICLE_ID,
       OOD.PACKING_QTY,
       OOD.S_CELL_NO,
       OOD.S_CONTAINER_NO,
       --OOD.PICK_CONTAINER_NO,
       OOD.S_CELL_ID,
       OOD.D_CELL_NO,
       OOD.D_CELL_ID,
       --OOD.CUST_CONTAINER_NO,
       OOD.LOCATE_QTY,
       OOD.STATUS,
       OOD.DELIVER_AREA,
       OOD.LINE_NO,
       OOD.PRIORITY,
       OOD.A_SORTER_CHUTE_NO,
       OOD.CHECK_CHUTE_NO,
       OOD.DELIVER_OBJ,
       OOD.SUPP_COUNT,
       OOD.DEVICE_NO,
       OOD.DPS_CELL_NO,
       OOD.RGST_NAME,
       OOD.RGST_DATE,
       OOD.UPDT_NAME,
       OOD.UPDT_DATE,
       OOD.TEMP_STATUS,
       OOD.EXP_DATE,
       OOD.STOCK_TYPE,
       OOD.LABEL_NO,
       OOD.SOURCE_TYPE,
       CDA.AREA_TYPE,
       CDA.ADVANCER_PICK_FLAG,
      -- NVL(WOS.SPLITTING_FLAG, '1') SPLITTING_FLAG,
       (sum(OOD.Locate_Qty) over(partition by ood.WAREHOUSE_NO, ood.WAVE_NO)) SUMQTY,

       (CASE OOD.OPERATE_TYPE || OOD.PICK_TYPE
         WHEN 'B0' THEN
          '0'
         ELSE
          '1'
       END) B_DIVIDE,
       (CASE OOD.OPERATE_TYPE || OOD.PICK_TYPE
         WHEN 'C0' THEN
          '0'
          ELSE
          '1'
       END) C_DIVIDE,
       BDA.ARTICLE_NAME,
       (sum(bda.unit_volumn + (ood.locate_qty - 1) * bda.CUMULATIVE_VOLUMN)
        over(partition by ood.WAREHOUSE_NO,
             ood.WAVE_NO,
             ood.OUTSTOCK_TYPE,
             ood.BATCH_NO,
             ood.OPERATE_TYPE,
             ood.S_CONTAINER_NO,
             ood.s_cell_no,
             ood.article_no)) SUM_ARTICLE_VOL,
       (sum(ood.locate_qty * bda.unit_weight)
        over(partition by ood.WAREHOUSE_NO,
             ood.WAVE_NO,
             ood.OUTSTOCK_TYPE,
             ood.BATCH_NO,
             ood.OPERATE_TYPE,
             ood.S_CONTAINER_NO,
             ood.s_cell_no,
             ood.article_no)) SUM_ARTICLE_WEIGHT,
       (sum(ood.locate_qty) over(partition by ood.WAREHOUSE_NO,
                                 ood.WAVE_NO,
                                 ood.OUTSTOCK_TYPE,
                                 ood.BATCH_NO,
                                 ood.OPERATE_TYPE,
                                 ood.S_CONTAINER_NO,
                                 ood.s_cell_no,
                                 ood.article_no)) SUM_LOCATE_QTY,
       NVL(ROUND(sum(ood.locate_qty / cca.packing_qty)
                 over(partition by ood.WAREHOUSE_NO,
                      ood.WAVE_NO,
                      ood.OUTSTOCK_TYPE,
                      ood.BATCH_NO,
                      ood.OPERATE_TYPE,
                      ood.S_CONTAINER_NO,
                      ood.s_cell_no,
                      ood.article_no),
                 4),
           0.01) SUM_ARTICLE_PACK,
       nvl(ROUND((ood.locate_qty / cca.packing_qty), 0.01), 4) unit_packrate,
       (CASE
         WHEN EXISTS (SELECT 'X'
                 FROM Odata_OUTSTOCK_DIRECT TMP
                WHERE TMP.ARTICLE_NO = OOD.ARTICLE_NO
                  AND TMP.WAREHOUSE_NO = OOD.WAREHOUSE_NO
                  and tmp.enterprise_no =ood.enterprise_no
                  AND TMP.OWNER_NO = OOD.OWNER_NO
                  AND OOD.OUTSTOCK_TYPE = '0'
                  AND OOD.OPERATE_TYPE in ('C', 'D')
                  AND TMP.D_CELL_NO = OOD.S_CELL_NO
                  AND TMP.STATUS > '10'
                  and tmp.status < '13') THEN
          0
         ELSE
          1
       END) SUPP_FLAG,
       bap.spec,
       cai.BARCODE,
       CAI.LOT_NO,
       CAI.EXPIRE_DATE,
       CAI.PRODUCE_DATE,
       CAI.IMPORT_BATCH_NO,
       CAI.QUALITY,
       BAP.PACKING_WEIGHT,
       BAP.QPALETTE,
       BAP.SORTER_FLAG,
       CDC.WARE_NO,
       BAP.PACKING_UNIT,
       (CDC.WARE_NO || CDC.AREA_NO) AREA_NO,
       (CDC.WARE_NO || CDC.AREA_NO || CDC.STOCK_NO) STOCK_NO,
       (CDC.WARE_NO || CDC.AREA_NO || CDC.STOCK_Y) AS AREA_LAYER,
       (CDC.WARE_NO || CDC.AREA_NO || CDC.STOCK_NO || CDC.STOCK_Y) STOCK_LAYER,
        nvl(otad.allot_rule, wtr.allot_rule) allot_rule,
        nvl(otad.box_flag, wtr.box_flag) box_flag,
        nvl(otad.para_value, wtr.para_value) para_value,
        nvl(otad.task_type, wtr.task_type) task_type,
        nvl(otad.print_type,wtr.print_type) print_type,
        nvl(otad.task_get_type,wtr.task_get_type) task_get_type --Modify BY QZH AT 2016-5-24 增加索单方式字段
  FROM ODATA_OUTSTOCK_DIRECT OOD
 INNER JOIN STOCK_ARTICLE_INFO CAI
    ON CAI.ARTICLE_NO = OOD.ARTICLE_NO  AND CAI.ARTICLE_ID = OOD.ARTICLE_ID and cai.enterprise_no =ood.enterprise_no
  inner join BDEF_defarticle bda
    on ood.article_no = bda.article_no  and bda.enterprise_no =ood.enterprise_no
 left JOIN BDEF_ARTICLE_PACKING BAP
    ON OOD.ARTICLE_NO = BAP.ARTICLE_NO  AND OOD.PACKING_QTY = BAP.PACKING_QTY and bap.enterprise_no =ood.enterprise_no
 INNER JOIN CDEF_DEFCELL CDC
    ON OOD.S_CELL_NO = CDC.CELL_NO AND OOD.WAREHOUSE_NO = CDC.WAREHOUSE_NO and ood.enterprise_no =cdc.enterprise_no
 INNER JOIN CDEF_DEFAREA CDA
    ON CDC.WAREHOUSE_NO = CDA.WAREHOUSE_NO and cdc.enterprise_no =cda.enterprise_no AND CDC.WARE_NO = CDA.WARE_NO
   AND CDC.AREA_NO = CDA.AREA_NO
  left join CSET_cell_article cca
    on ood.WAREHOUSE_NO = cca.WAREHOUSE_NO  and cca.enterprise_no =ood.enterprise_no  and ood.article_no = cca.ARTICLE_NO
   and ood.owner_no = cca.owner_no  and cca.pick_type = 'B'
  LEFT JOIN (select c.enterprise_no,c.outstock_type,c.operate_type,
                    nvl(d.pick_order, c.pick_order) pick_order
               from WMS_CRTPAPER_ORDER c  left join oset_CRTPAPER_ORDER d
                 on c.outstock_type = d.outstock_type and c.enterprise_no = d.enterprise_no
                and c.operate_type = d.operate_type) od
    ON OOD.OUTSTOCK_TYPE = od.OUTSTOCK_TYPE AND OOD.OPERATE_TYPE = od.OPERATE_TYPE and od.enterprise_no =ood.enterprise_no
   inner join WMS_TASKALLOT_RULE wtr  on wtr.operate_type=ood.operate_type and wtr.outstock_type=ood.outstock_type
   left join oset_task_allot_d otad  on otad.warehouse_no=ood.warehouse_no and otad.enterprise_no =ood.enterprise_no
   and otad.outstock_type=ood.outstock_type and otad.operate_type=ood.operate_type and otad.task_id=cda.task_id
 WHERE OOD.STATUS = '10' and ood.outstock_type in('1','4')
 ORDER BY ood.enterprise_no,OOD.warehouse_no,
          OOD.PRIORITY DESC,
          OOD.WAVE_NO,
          OOD.BATCH_NO,
          SUPP_FLAG,
          OD.PICK_ORDER,
          OOD.OUTSTOCK_TYPE,
          OOD.OPERATE_TYPE,
          OOD.PICK_TYPE     DESC,
          --B??????
           (CASE B_DIVIDE
            WHEN '0' THEN
             CASE OOD.OPERATE_TYPE
               WHEN 'B' THEN
                OOD.CUST_NO || OOD.DELIVER_OBJ
               ELSE
                '0'
             END
            ELSE
             '0'
          END),
          --C??????
         (CASE C_DIVIDE
            WHEN '0' THEN
             OOD.CUST_NO || OOD.DELIVER_OBJ
            ELSE
             '0'
          END),
          (CASE ALLOT_RULE
            WHEN '1' THEN
             CDC.WARE_NO
            WHEN '2' THEN
             (CDC.WARE_NO || CDC.AREA_NO)
            WHEN '3' THEN
             (CDC.WARE_NO || CDC.AREA_NO || CDC.STOCK_NO)
            WHEN '4' THEN
             (CDC.WARE_NO || CDC.AREA_NO || CDC.STOCK_Y)
            WHEN '5' THEN
             (CDC.WARE_NO || CDC.AREA_NO || CDC.STOCK_NO || CDC.STOCK_Y)
          END),
          (CASE BOX_FLAG
            WHEN '1' THEN
             OOD.S_CONTAINER_NO
            WHEN '6' THEN
             OOD.S_CONTAINER_NO
          END),
          BAP.SORTER_FLAG,
          OOD.S_CELL_NO,
          OOD.S_CONTAINER_NO,
          OOD.ARTICLE_NO


/

