create view V_SEARCH_9103_2 as
select oem.enterprise_no,oem.WAREHOUSE_NO,oem.wave_no,oem.exp_no,oed.article_no,bda.article_name,bda.barcode,cu.cust_name,oem.exp_date locate_date,
oem.erpoperate_date,bag.group_name,oem.cust_no,oem.sourceexp_no,oed.packing_qty,
oed.article_qty plan_qty,oed.locate_qty located_qty,oed.article_qty-oed.locate_qty diversity_plan_qty,oem.batch_no
from  odata_exp_m oem,odata_exp_d oed ,bdef_defarticle bda ,bdef_defcust cu,bdef_article_group bag
where oem.enterprise_no=oed.enterprise_no and oem.warehouse_no=oed.warehouse_no
and oem.owner_no=oed.owner_no and oem.exp_no=oed.exp_no
and oed.enterprise_no=bda.enterprise_no and oed.owner_no=bda.owner_no
and oed.article_no=bda.article_no
and oem.enterprise_no=cu.enterprise_no and oem.owner_no=cu.owner_no
and oem.cust_no=cu.cust_no
and bda.enterprise_no=bag.enterprise_no and bda.owner_no=bag.owner_no
and bda.group_no=bag.group_no
and oem.status>='11'
order by oem.enterprise_no,oem.WAREHOUSE_NO,oem.wave_no,oem.exp_no,oed.article_no

/

