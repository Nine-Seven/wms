create package body PKLG_IDATA is

  /************************************************************************************************
       功能：集单
       日期：2015-07-03
       chensr
  *************************************************************************************************/
  procedure p_single_set(v_EnterpriseNo      in idata_import_m.enterprise_no%type,
                         v_WarehouseNo       in idata_import_m.warehouse_no%type,
                         v_Import_No         in idata_import_m.import_no%type,
                         v_OldSImportNo      in idata_import_mm.s_import_no%type, --原汇总单号,没有则传N
                         v_RgstName          in idata_import_mm.rgst_name%type,
                         v_strNewS_Import_No OUT Idata_Import_Mm.S_IMPORT_NO%type, --返回的汇总单号
                         v_OutMsg            out varchar2) is

    strImportType         idata_import_m.import_type%type;
    v_strClassType        idata_import_m.class_type%type;
    strOwnerNo            idata_import_m.owner_no%type;
    strPaperType          bdef_paperno.papertype%type;
    strSupplierNo         idata_import_m.supplier_no%type;
    v_strAutoCollectOrder wms_defbase.sdefine%type; ---0:不自动集单；1：自动集单
    v_strPoNo             idata_import_m.po_no%type;

  begin
    v_OutMsg := 'N|[p_Idata_Order_Time]';

    /* if v_EnterpriseNo is null
    then v_OutMsg:='N|jinlai';
    return ;
    end if;*/

    --获取出货类型、货主、供应商
    SELECT iim.import_type， iim.owner_no,
           iim.supplier_no,
           iim.po_no,
           iim.class_type
      into strImportType,
           strOwnerNo,
           strSupplierNo,
           v_strPoNo,
           v_strClassType
      FROM idata_import_m iim
     where iim.import_no = v_Import_No
       and iim.status = '10'
       and iim.enterprise_no = v_EnterpriseNo
       and iim.warehouse_no = v_WarehouseNo;

    if v_strClassType = '0' then
      --存储
      strPaperType := 'SS';
    else
      strPaperType := 'SD'; --直通
    end if;

    if v_OldSImportNo = 'N' then

      --读取是否自动集单的参数，若自动集单，则写汇总单头档的S_IMPORT_NO=PO_NO,

      PKLG_WMS_Public.P_GetIdataOrder(v_EnterpriseNo,
                                      v_WarehouseNo,
                                      strOwnerNo,
                                      strImportType,
                                      'AUTOCOLLECTORDER',
                                      v_strAutoCollectOrder,
                                      v_OutMsg);
      if (substr(v_OutMsg, 1, 1) = 'N') then
        return;
      end if;

      if v_strAutoCollectOrder = '1' then
        v_strNewS_Import_No := v_strPoNo;
      else

        --当单号为N时取值
        PKLG_WMS_BASE.p_getsheetno(v_EnterpriseNo,
                                   v_WarehouseNo,
                                   strPaperType,
                                   v_strNewS_Import_No,
                                   v_OutMsg);
        if substr(v_OutMsg, 1, 1) <> 'Y' then
          return;
        end if;
      end if;

      --写进货汇总头档
      PKOBJ_IDATA.p_Idata_Import_Mm(v_EnterpriseNo,
                                    v_WarehouseNo,
                                    v_strNewS_Import_No,
                                    strImportType,
                                    v_strClassType,
                                    strOwnerNo,
                                    'N',
                                    strImportType,
                                    strSupplierNo,
                                    '1',
                                    'N',
                                    v_RgstName,
                                    v_OutMsg);

      if substr(v_OutMsg, 1, 1) <> 'Y' then
        return;
      end if;
    else
      v_strNewS_Import_No := v_OldSImportNo;
    end if;

    --写进货汇总单和进货单对应关系
    PKOBJ_IDATA.p_Idata_Import_Sm(v_EnterpriseNo,
                                  v_WarehouseNo,
                                  v_strNewS_Import_No,
                                  v_Import_No,
                                  v_RgstName,
                                  v_OutMsg);
    if substr(v_OutMsg, 1, 1) <> 'Y' then
      return;
    end if;
    --写进货汇总单明细
    PKOBJ_IDATA.p_Idata_Import_Sd(v_EnterpriseNo,
                                  v_WarehouseNo,
                                  v_strNewS_Import_No,
                                  v_Import_No,
                                  v_OutMsg);
    if substr(v_OutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    --更加进货单头档状态
    update Idata_Import_m iim
       set iim.status = 11, iim.updt_date = sysdate
     where iim.warehouse_No = v_WarehouseNo
       and iim.enterprise_no = v_EnterpriseNo
       and iim.import_no = v_Import_No
       and iim.status = 10;
    if sql%rowcount <= 0 then
      v_OutMsg := 'N|[E20701]'; --更新进货单状态失败，单号:' || v_Import_No;
      return;
    end if;

  exception
    when others then
      v_OutMsg := 'N|' || SQLERRM ||
                  substr(dbms_utility.format_error_backtrace, 1, 256);
      v_OutMsg := 'Y';
  end p_single_set;
  /************************************************************************************************
       修改人：chensr
       日期：2015-01-27
       功能：进货预约

  *************************************************************************************************/
  procedure p_Idata_Order_Time(v_EnterpriseNo      in idata_import_m.enterprise_no%type,
                               v_WarehouseNo       in idata_import_m.warehouse_no%type,
                               v_Import_No         in idata_import_m.import_no%type,
                               v_Request_Date      in idata_order_status.request_date%type,
                               v_Start_Time        in idata_order_status.start_time%type,
                               v_End_Time          in idata_order_status.end_time%type,
                               v_FirstFlag         in odata_locate_m.SOURCE_TYPE%type, --是否第一张单；0：否；1：是 ;2:根据原单号产生汇总单号
                               v_OldSImportNo      in idata_import_mm.s_import_no%type, --原汇总单号
                               v_RgstName          in idata_import_mm.rgst_name%type,
                               v_strWorkSpaceNo    in idata_check_m.dock_no%type,
                               v_strDockNo         in idata_order_status.dock_no%type,
                               v_printFlag         in varchar2,
                               v_strNewS_Import_No OUT Idata_Import_Mm.S_IMPORT_NO%type, --返回的汇总单号
                               v_OutMsg            out varchar2) is

    strImportType             idata_import_m.import_type%type;
    strOwnerNo                idata_import_m.owner_no%type;
    strPaperType              bdef_paperno.papertype%type;
    strSupplierNo             idata_import_m.supplier_no%type;
    strPrtTask                job_printtask_m.task_no%type;
    strReportId               pntdef_report.report_id%type;
    v_strPoNo                 idata_import_m.po_no%type;
    v_strIC_ReturnType        wms_defbase.sdefine%type; --是否一单一验参数
    v_nIC_ReturnType          wms_defbase.ndefine%type;
    v_strIC_ConfirmBuildSheet wms_defbase.sdefine%type; ---0：剩余部分手工重新预约，1：不自动预约，原汇总单有效,2：自动预约产生新汇总单
    v_nIC_ConfirmBuildSheet   wms_defbase.ndefine%type;
    v_strClassType            idata_import_m.class_type%type;

  begin
    v_OutMsg := 'N|[p_Idata_Order_Time]';

    --获取出货类型、货主、供应商
    SELECT iim.import_type， iim.owner_no,
           iim.supplier_no,
           iim.po_no,
           iim.class_type
      into strImportType,
           strOwnerNo,
           strSupplierNo,
           v_strPoNo,
           v_strClassType
      FROM idata_import_m iim
     where iim.import_no = v_Import_No
       and iim.status = 10
       and iim.enterprise_no = v_EnterpriseNo
       and iim.warehouse_no = v_WarehouseNo;

    if strImportType = 'IS' then
      strPaperType := 'SS';
    else
      strPaperType := 'SD';
    end if;

    --取一单多验，未完验的单验收确认时预约系统参数
    PKLG_WMS_BASE.p_GetBasePara(v_EnterpriseNo,
                                v_WarehouseNo,
                                strOwnerNo,
                                'IC_ConfirmBuildSheet',
                                'I',
                                'IC',
                                v_strIC_ConfirmBuildSheet,
                                v_nIC_ConfirmBuildSheet,
                                v_OutMsg);
    if (substr(v_OutMsg, 1, 1) = 'N') then
      return;
    end if;

    --取一单一验，一单多验和一品多验的系统参数
    PKLG_WMS_BASE.p_GetBasePara(v_EnterpriseNo,
                                v_WarehouseNo,
                                strOwnerNo,
                                'IC_ReturnType',
                                'I',
                                'IC',
                                v_strIC_ReturnType,
                                v_nIC_ReturnType,
                                v_OutMsg);
    if (substr(v_OutMsg, 1, 1) = 'N') then
      return;
    end if;

    --if是一单多验，并且剩余量需手工预约，则需新取汇总单号;else按以前的判断逻辑hkl
    if v_strIC_ConfirmBuildSheet = '0' and v_strIC_ReturnType = '2' then
      PKLG_WMS_BASE.p_getsheetno(v_EnterpriseNo,
                                 v_WarehouseNo,
                                 strPaperType,
                                 v_strNewS_Import_No,
                                 v_OutMsg);
      if substr(v_OutMsg, 1, 1) <> 'Y' then
        return;
      end if;

    else
      if v_FirstFlag = '1' then
        --第一次需要取号
        PKLG_WMS_BASE.p_getsheetno(v_EnterpriseNo,
                                   v_WarehouseNo,
                                   strPaperType,
                                   v_strNewS_Import_No,
                                   v_OutMsg);
        if substr(v_OutMsg, 1, 1) <> 'Y' then
          return;
        end if;
      end if;
      if v_FirstFlag = '0' then
        v_strNewS_Import_No := v_OldSImportNo;
      end if;
      if v_FirstFlag = '2' then
        v_strNewS_Import_No := v_strPoNo;
      end if;

    end if;

    --写进货汇总头档
    PKOBJ_IDATA.p_Idata_Import_Mm(v_EnterpriseNo,
                                  v_WarehouseNo,
                                  v_strNewS_Import_No,
                                  strImportType,
                                  v_strClassType,
                                  strOwnerNo,
                                  'N',
                                  strImportType,
                                  strSupplierNo,
                                  '1',
                                  'N',
                                  v_RgstName,
                                  v_OutMsg);
    --写进货汇总单和进货单对应关系
    PKOBJ_IDATA.p_Idata_Import_Sm(v_EnterpriseNo,
                                  v_WarehouseNo,
                                  v_strNewS_Import_No,
                                  v_Import_No,
                                  v_RgstName,
                                  v_OutMsg);

    --写进货汇总单明细
    PKOBJ_IDATA.p_Idata_Import_Sd(v_EnterpriseNo,
                                  v_WarehouseNo,
                                  v_strNewS_Import_No,
                                  v_Import_No,
                                  v_OutMsg);

    --写预约状况记录表
    PKOBJ_IDATA.p_Idata_Order_Status(v_EnterpriseNo,
                                     v_WarehouseNo,
                                     strOwnerNo,--add by huangcx 20160816
                                     v_strNewS_Import_No,
                                     v_Request_Date,
                                     v_strDockNo,
                                     v_Start_Time,
                                     v_End_Time,
                                     v_RgstName,
                                     v_OutMsg);
    --写预约单号记录档
    PKOBJ_IDATA.p_Idata_Order_Sheet(v_EnterpriseNo,
                                    v_WarehouseNo,
                                    strOwnerNo,--add by huangcx 20160816
                                    v_strNewS_Import_No,
                                    v_Import_No,
                                    v_RgstName,
                                    v_OutMsg);

    --如果是最后一张单据 则写打印任务
    if v_FirstFlag = '1' OR v_FirstFlag = '2' then
      --写报表打印任务
      if v_printFlag = '2' then
        strReportId := CONST_REPORTID.L_IS_READY_CHECK;
        PKOBJ_PRINTTASK.p_insert_taskmaster(v_EnterpriseNo,
                                            v_WarehouseNo,
                                            v_strNewS_Import_No,
                                            0,
                                            strReportId,
                                            v_strWorkSpaceNo,
                                            0,
                                            v_RgstName,
                                            strPrtTask,
                                            v_OutMsg);

        if substr(v_OutMsg, 1, 1) <> 'Y' then
          return;
        end if;
      end if;
      --写标签打印任务
      if v_printFlag = '3' then
        strReportId := CONST_REPORTID.B_IS_READY_CHECK;
        PKOBJ_PRINTTASK.p_insert_taskmaster(v_EnterpriseNo,
                                            v_WarehouseNo,
                                            v_strNewS_Import_No,
                                            0,
                                            strReportId,
                                            v_strWorkSpaceNo,
                                            0,
                                            v_RgstName,
                                            strPrtTask,
                                            v_OutMsg);

        if substr(v_OutMsg, 1, 1) <> 'Y' then
          return;
        end if;
      end if;

    end if;

    --更加进货单头档状态
    update Idata_Import_m iim
       set iim.status = 11, iim.updt_date = sysdate
     where iim.warehouse_No = v_WarehouseNo
       and iim.enterprise_no = v_EnterpriseNo
       and iim.import_no = v_Import_No
       and iim.status = 10;
    if sql%rowcount <= 0 then
      v_OutMsg := 'N|[E20701]'; --更新进货单状态失败，单号:' || v_Import_No;
      return;
    end if;

  exception
    when others then
      v_OutMsg := 'N|' || SQLERRM ||
                  substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_Idata_Order_Time;
  /**********************************************************************************
  lich
  2014-04-23
  功能说明：普通保存验收数据
  **********************************************************************************/
  procedure P_SaveCheckDataIS(strEnterpriseNo   in idata_check_m.enterprise_no%type,
                              strWareHouseNo    in idata_check_m.warehouse_no%type,
                              strOwnerNo        in idata_check_m.owner_no%type,
                              strsImportNo      in idata_check_m.s_import_no%type, --进货汇总单号
                              strArticleNo      in idata_check_d.article_no%type,
                              strBarcode        in idata_check_d.barcode%type,
                              nPackingQty       in idata_check_d.packing_qty%type,
                              nCheckQty         in idata_check_d.check_qty%type,
                              strPrinterGroupNo in idata_check_m.printer_group_no%type, --工作站
                              strDockNo         in idata_check_m.dock_no%type, --码头
                              strWorkerNo       in idata_check_m.rgst_name%type, --操作人
                              strCheckTools     in idata_check_m.check_tools%type, --验收工具
                              nIsAdd            in integer, --是否累加 0:覆盖 1:累加
                              strQuality        in idata_check_d.quality%type, --品质
                              dtProduceDate     in idata_check_d.produce_date%type,
                              dtExpireDate      in idata_check_d.expire_date%type,
                              strLotNo          in idata_check_d.lot_no%type, --批次号
                              strRSV_BATCH1     in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                              strRSV_BATCH2     in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                              strRSV_BATCH3     in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                              strRSV_BATCH4     in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                              strRSV_BATCH5     in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                              strRSV_BATCH6     in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                              strRSV_BATCH7     in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                              strRSV_BATCH8     in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                              strTemperature    in idata_check_pal_tmp.temperature%type, --温度
                              strLabelNo        in stock_label_m.label_no%type, --实体标签号
                              strSupLabelNo     in idata_check_pal_tmp.sub_label_no%type, --子标签号
                              strFixPalFlag     in idata_check_pal.Fixpal_Flag%type, --1：固定板号；2：流水板号;
                              strBusinessType   in idata_check_pal.Fixpal_Flag%type, --业务类型：0-普通验收；1-直通验收；2-大批量验收；3-客户别；5-越库；6-B/C品
                              strsCheckNo       out idata_check_m.s_check_no%type,
                              strResult         out varchar2) is
    v_iCount        integer;
    v_strsCheckNo   idata_check_m.s_check_no%type;
    v_strImportType idata_check_m.import_type%type;
    v_stockType     idata_import_m.stock_type%type;
    v_stockValue    idata_import_m.stock_value%type;
    v_strSupplierNo idata_import_m.supplier_no%type;
    v_nExpiryDays   bdef_defarticle.expiry_days%type;
    v_nLotType      bdef_defarticle.lot_type%type;
    v_strClassType  idata_import_m.class_type%type;

  begin
    strResult := 'N|[P_SaveCheckDataIS]';
    --检查进货汇总单是否已验收确认；
    begin
      select count(*)
        into v_iCount
        from idata_import_mm
       where warehouse_no = strWareHouseNo
         and enterprise_no = strEnterpriseNo
         and owner_no = strOwnerNo
         and s_import_no = strsImportNo
         and status not in ('16', '13');
    exception
      when no_data_found then
        strResult := 'N|[E20901]'; --查询不到对应的进货汇总单
        return;
    end;

    --锁定进货汇总单头；
    update idata_import_mm
       set status = '12'
     where warehouse_no = strWareHouseNo
       and enterprise_no = strEnterpriseNo
       and owner_no = strOwnerNo
       and s_import_no = strsImportNo;

    if sql%notfound then
      strResult := 'N|[E20902]'; --更新进货汇总单失败
      return;
    end if;

    --取汇总验收单号；
    begin
      select distinct s_check_no
        into v_strsCheckNo
        from idata_check_m
       where warehouse_no = strWareHouseNo
         and enterprise_no = strEnterpriseNo
         and owner_no = strOwnerNo
         and s_import_no = strsImportNo
         and status <> '13';
    exception
      when no_data_found then
        --若取不到汇总验收单号，则写验收头档；
        PKOBJ_IDATA.p_Insert_Idata_Check_M(strEnterpriseNo,
                                           strWareHouseNo,
                                           strOwnerNo,
                                           strSImportNo,
                                           strDockNo,
                                           strWorkerNo,
                                           strPrinterGroupNo,
                                           strCheckTools,
                                           v_strsCheckNo,
                                           strResult);
        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;
    end;

    strsCheckNo := v_strsCheckNo;

    --获取单据等信息
    begin
      select supplier_no, stock_type, stock_value, import_type, class_type
        into v_strSupplierNO,
             v_stockType,
             v_StockValue,
             v_strImportType,
             v_strClassType
        from idata_import_mm
       where warehouse_no = strWareHouseNo
         and enterprise_no = strEnterpriseNo
         and owner_no = strOwnerNo
         and s_import_no = strsImportNo;
    exception
      when no_data_found then
        strResult := 'N|[E20903]'; --取进货汇总单信息失败
        return;
    end;

    --写临时板表；
    PKOBJ_IDATA.p_Insert_Idata_Check_Pal_Tmp(strEnterpriseNo,
                                             strWareHouseNo,
                                             strOwnerNo,
                                             strSImportNo,
                                             v_strsCheckNo,
                                             v_strClassType,
                                             strArticleNo,
                                             strQuality,
                                             dtProduceDate,
                                             dtExpireDate,
                                             strLotNo,
                                             strRSV_BATCH1,
                                             strRSV_BATCH2,
                                             strRSV_BATCH3,
                                             strRSV_BATCH4,
                                             strRSV_BATCH5,
                                             strRSV_BATCH6,
                                             strRSV_BATCH7,
                                             strRSV_BATCH8,
                                             strTemperature,
                                             strBarcode,
                                             nPackingQty,
                                             nCheckQty,
                                             strLabelNo,
                                             strSupLabelNo,
                                             strBusinessType,
                                             strFixPalFlag,
                                             strPrinterGroupNo,
                                             strDockNo,
                                             v_stockType,
                                             v_stockValue,
                                             strWorkerNo,
                                             v_strImportType,
                                             v_strSupplierNo,
                                             strCheckTools,
                                             nIsAdd,
                                             'N',
                                             '',
                                             '',
                                             strResult);

    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    begin
      select bda.expiry_days, bda.lot_type
        into v_nExpiryDays, v_nLotType
        from bdef_defarticle bda
       where bda.article_no = strArticleNo
         and bda.enterprise_no = strEnterpriseNo;
    exception
      when no_data_found then
        strResult := 'N|[E20921]'; --读取商品信息失败
        return;
    end;
    --如果商品管批号信息，则写商品批号管理信息
    --if v_nExpiryDays =0 then
    if v_nLotType = 1 or v_nLotType = 3 then
      PKOBJ_STOCK.p_Insert_Article_lot_manage(strEnterpriseNo,
                                              strWareHouseNo,
                                              strArticleNo,
                                              strLotNo,
                                              dtProduceDate,
                                              dtExpireDate,
                                              dtExpireDate - dtProduceDate,
                                              strWorkerNo,
                                              0,
                                              strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
    end if;

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_SaveCheckDataIS;

  /***********************************************************************************************
  lich
  2014.04.23
  功能：封板验收主程序
  ***********************************************************************************************/
  procedure P_Close_Pal_Main(strEnterprise  in idata_check_pal_tmp.enterprise_no%type, --企业
                             strWareHouseNo in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                             strOwnerNo     in idata_check_pal_tmp.owner_no%type, --委托业主编码
                             strsImportNo   in idata_check_m.s_import_no%type, --进货汇总单号
                             strsCheckNo    in idata_check_pal_tmp.s_check_no%type, --验收汇总单号
                             strLabelNo     in idata_check_pal_tmp.label_no%type, --板号
                             strWorkerNo    in idata_check_pal_tmp.rgst_name%type, --操作人
                             strFixPalFlag  in idata_check_pal.Fixpal_Flag%type, --1：固定板号；2：流水板号;3：固定流水混合验收
                             strResult      out varchar2) is
    v_strSCheckNo idata_check_m.s_check_no%type;
  begin
    strResult := 'N|[P_Close_Pal_Main]';

    select distinct icm.s_check_no
      into v_strSCheckNo
      from idata_check_m icm
     where icm.s_import_no = strsImportNo
       and icm.enterprise_no = strEnterprise
       and icm.warehouse_no = strWareHouseNo
       and icm.status <> '13';

    if strFixPalFlag = '1' or strFixPalFlag = '3' then
      --固定板人工封板 混合板验收走固定板流程
      P_CheckSplitPal_Fixed(strEnterprise,
                            strWareHouseNo,
                            strOwnerNo,
                            strsImportNo,
                            v_strSCheckNo,
                            strLabelNo,
                            strWorkerNo,
                            strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;
    end if;
    if strFixPalFlag = '2' then
      --流水板自动柝板
      P_CheckSplitPal_Qlide(strEnterprise,
                            strWareHouseNo,
                            strOwnerNo,
                            strsImportNo,
                            v_strSCheckNo,
                            strLabelNo,
                            strWorkerNo,
                            strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;
    end if;

    strResult := 'Y';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_Close_Pal_Main;
  /*************************************************************************************************
     作者:lich
     日期:  2013-10-30
     功能: 固定板人工封板
  *************************************************************************************************/
  procedure P_CheckSplitPal_Fixed(strEnterpriseNo in idata_check_pal_tmp.enterprise_no%type,
                                  strWareHouseNo  in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                  strOwnerNo      in idata_check_pal_tmp.owner_no%type, --委托业主编码
                                  strSimportNo    in idata_check_m.s_import_no%type, --进货汇总单号
                                  strSCheckNo     in idata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                  strLabelNo      in idata_check_pal_tmp.label_no%type, --板号
                                  strWorkerNo     in idata_check_pal_tmp.rgst_name%type, --操作人
                                  strResult       out varchar2) is
    cursor v_GetCheckPalTmp is
      select *
        from idata_check_pal_tmp
       where WAREHOUSE_NO = strWareHouseNo
         and enterprise_no = strEnterpriseNo
         and owner_no = strOwnerNo
         and s_import_no = strsImportNo
         and s_check_no = strsCheckNo
         and label_no = strLabelNo
         and status = '10'
       order by label_no, article_no, row_id;

    strContainNo    varchar2(24); --内部容器号
    strLabelNoTmp   varchar2(24); --板号
    strSessionID    varchar2(10);
    intCount        integer; --记录拆板数
    v_strLabelNo    idata_check_pal.label_no%type;
    v_strSubLabelNo idata_check_pal.sub_label_no%type;
    v_nRemainQty    idata_check_pal.check_qty%type;
  begin
    strResult := 'N|[P_CheckSplitPal_Fixed]';
    intCount  := 0;
    --取板信息
    for GetCheckPalTmp in v_GetCheckPalTmp loop
      --取P标签 只取一个标签
      if (intCount = 0) then
        --取P标签 只取一个标签
        pklg_wms_base.p_get_ContainerNoBase(strEnterpriseNo,
                                            strWareHouseNo,
                                            'P',
                                            strWorkerNo,
                                            'D',
                                            1,
                                            '2',
                                            '31',
                                            strLabelNoTmp,
                                            strContainNo,
                                            strSessionID,
                                            strResult);
        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;
      end if;

      if strLabelNo = 'N' then
        v_strLabelNo := strLabelNoTmp;
      else
        v_strLabelNo := strLabelNo;
      end if;

      if GetCheckPalTmp.Sub_Label_No = 'N' then
        v_strSubLabelNo := strLabelNoTmp;
      else
        v_strSubLabelNo := GetCheckPalTmp.Sub_Label_No;
      end if;

      --配量
      p_idata_MixAmount(strEnterpriseNo,
                        strWareHouseNo,
                        strOwnerNo,
                        strSimportNo,
                        strSCheckNo,
                        strLabelNo,
                        v_strLabelNo,
                        v_strSubLabelNo,
                        strContainNo,
                        GetCheckPalTmp.check_qty,
                        GetCheckPalTmp.row_id,
                        strWorkerNo,
                        v_nRemainQty,
                        strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      if v_nRemainQty > 0 then
        --表示超量验收
        --做超量处理
        P_OverQtyMixAmount(strEnterpriseNo,
                           strWareHouseNo,
                           strOwnerNo,
                           strSimportNo,
                           strSCheckNo,
                           strLabelNo,
                           v_strLabelNo,
                           v_strSubLabelNo,
                           strContainNo,
                           v_nRemainQty,
                           GetCheckPalTmp.row_id,
                           strWorkerNo,
                           strResult);
        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;
      end if;
      intCount := intCount + 1;

      delete from idata_check_pal_tmp
       where WAREHOUSE_NO = strWareHouseNo
         and enterprise_no = strEnterpriseNo
         and owner_no = strOwnerNo
         and s_import_no = strSimportNo
         and s_check_no = strSCheckNo
         and label_no = strLabelNo
         and row_id = GetCheckPalTmp.row_id;
    end loop;

    if (intcount = 0) then
      strResult := 'N|[E20904]'; --该板上没有商品，不能封板
      return;
    end if;

    --将此此板对应的扫描日志数据转历史
    insert into bdef_scan_loghty
      (enterprise_no,
       warehouse_no,
       scan_barcode,
       source_no,
       article_no,
       cell_no,
       label_no,
       qty,
       rgst_name,
       rgst_date,
       check_type,
       operate_date,
       merge_box_no,
       dept_no)
      select enterprise_no,
             warehouse_no,
             t.scan_barcode,
             t.source_no,
             t.article_no,
             t.cell_no,
             t.label_no,
             t.qty,
             t.rgst_name,
             t.rgst_date,
             t.check_type,
             t.operate_date,
             t.merge_box_no,
             t.dept_no
        from bdef_scan_log t
       where t.label_no = strLabelNo
         AND t.warehouse_no = strWareHouseNo
         AND t.enterprise_no = strEnterpriseNo
         AND T.source_no = strSimportNo;

    --删除扫描日志表数据
    delete from bdef_scan_log
     where label_no = strLabelNo
       AND enterprise_no = strEnterpriseNo
       AND warehouse_no = strWareHouseNo
       AND source_no = strSimportNo;

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_CheckSplitPal_Fixed;

  /*************************************************************************************************
     作者:lich
     日期:  2013-10-30
     功能: 拆板(流水板)
  *************************************************************************************************/
  procedure P_CheckSplitPal_Qlide(strEnterpriseNo in idata_check_pal_tmp.enterprise_no%type,
                                  strWareHouseNo  in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                  strOwnerNo      in idata_check_pal_tmp.owner_no%type, --委托业主编码
                                  strSimportNo    in idata_check_m.s_import_no%type, --进货汇总单号
                                  strSCheckNo     in idata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                  strLabelNo      in idata_check_pal_tmp.label_no%type, --板号
                                  strWorkerNo     in idata_check_pal_tmp.rgst_name%type, --操作人
                                  strResult       out varchar2) is
    cursor v_GetCheckPalTmp is
      select *
        from idata_check_pal_tmp
       where WAREHOUSE_NO = strWareHouseNo
         and enterprise_no = strEnterpriseNo
         and owner_no = strOwnerNo
         and s_import_no = strsImportNo
         and s_check_no = strsCheckNo
         and label_no = strLabelNo
         and status = '10'
       order by label_no, article_no, row_id;

    intTmp        idata_check_pal_tmp.check_qty%type; --中间量
    strContainNo  idata_check_pal.container_no%type; --内部容器号
    strLabelNoTmp idata_check_pal.label_no%type; --板号
    --strSupLabelNoTmp       idata_check_pal.sub_label_no%type; --子板号
    decQPalete             bdef_article_packing.qpalette%type; --标准堆叠
    v_decQPalete           bdef_article_packing.qpalette%type; --标准堆叠 用来取号运算 huangb 20160730
    v_Count                number := 0; --huangb 20160730
    strSessionID           varchar2(10);
    decCheckQty            idata_check_pal_tmp.check_qty%type; --按标准堆叠拆板时记录临时板验收量
    intCount               integer;
    v_strContainerType     stock_label_m.container_type%TYPE;
    v_strContainerMaterial wms_defcontainer.container_material%type;
    v_nRemainQty           idata_check_d.check_qty%type;
    v_IsExcessFlag         varchar2(10); --是否超量 0-否;1-是 huangb 20160730
  begin
    strResult := 'N|[P_CheckSplitPal_Qlide]';
    intCount  := 0;
    --取板信息
    for GetCheckPalTmp in v_GetCheckPalTmp loop
      intCount := intCount + 1;
      ----自动拆板3-取标准堆叠
      begin
        SELECT NVL(bwp.qpalette, bap.qpalette) qpalette
          into decQPalete
          FROM bdef_article_packing bap
          left join bdef_warehouse_packing bwp
            on bwp.warehouse_no = strWareHouseNo
           and bwp.enterprise_no = bap.enterprise_no
           and bwp.article_no = bap.article_no
           and bwp.packing_qty = bap.packing_qty
         where bap.article_no = GetCheckPalTmp.article_no
           and bap.packing_qty = GetCheckPalTmp.packing_qty
           and bap.enterprise_no = strEnterpriseNo;

      exception
        when no_data_found then
          /*strResult := 'N|[' || GetCheckPalTmp.article_no ||
          '没有取到标准堆叠量]'; */ --商品未设置标准堆叠!
          -- decQPalete := 999 * 999;
          decQPalete := 300;
          --  return;
      end;
      if (decQPalete is null or decQPalete = 0) then
        strResult := 'N|[' || GetCheckPalTmp.article_no || '标准堆叠量为0]'; --商品未设置标准堆叠!
        return;
      end if;

      --需要拆出零散数量
      decCheckQty    := GetCheckPalTmp.check_qty;
      v_decQPalete   := decQPalete;
      v_Count        := 0;
      v_IsExcessFlag := '0';
      while decCheckQty > 0 loop
        v_Count := v_Count + 1;
        if (decQPalete > decCheckQty) then
          if decCheckQty < GetCheckPalTmp.packing_qty then
            intTmp                 := decCheckQty;
            v_strContainerType     := 'B';
            v_strContainerMaterial := '11';
          else
            if mod(decCheckQty, GetCheckPalTmp.packing_qty) > 0 then
              intTmp                 := mod(decCheckQty,
                                            GetCheckPalTmp.packing_qty);
              v_strContainerType     := 'B';
              v_strContainerMaterial := '11';
            else
              intTmp                 := decCheckQty;
              v_strContainerType     := 'P';
              v_strContainerMaterial := '31';
            end if;
          end if;
        else
          intTmp                 := decQPalete;
          v_strContainerType     := 'P';
          v_strContainerMaterial := '31';
        end if;

        decCheckQty := decCheckQty - intTmp;

        if v_Count = 1 or v_decQPalete <= 0 then
          v_decQPalete := decQPalete;
          --取标签
          pklg_wms_base.p_get_ContainerNoBase(strEnterpriseNo,
                                              strWareHouseNo,
                                              v_strContainerType,
                                              strWorkerNo,
                                              'D',
                                              1,
                                              2, --标签用途
                                              v_strContainerMaterial, --容器材质(板)
                                              strLabelNoTmp,
                                              strContainNo,
                                              strSessionID,
                                              strResult);

          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;
        end if;
        if v_strContainerType = 'B' then
          v_decQPalete := 0;
        else
          v_decQPalete := v_decQPalete - intTmp;
        end if;

        if strLabelNo <> 'N' then
          strLabelNoTmp := strLabelNo;
        end if;

        if v_IsExcessFlag = '0' then
          --正常配量
          p_idata_MixAmount(strEnterpriseNo,
                            strWareHouseNo,
                            strOwnerNo,
                            strSimportNo,
                            strSCheckNo,
                            strLabelNo,
                            strLabelNoTmp,
                            strLabelNoTmp,
                            strContainNo,
                            intTmp,
                            GetCheckPalTmp.row_id,
                            strWorkerNo,
                            v_nRemainQty,
                            strResult);
          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;
          --超量配量 haungb 20160730
        else
          P_OverQtyMixAmount(strEnterpriseNo,
                             strWareHouseNo,
                             strOwnerNo,
                             strSimportNo,
                             strSCheckNo,
                             strLabelNo,
                             strLabelNoTmp,
                             strLabelNoTmp,
                             strContainNo,
                             intTmp,
                             GetCheckPalTmp.row_id,
                             strWorkerNo,
                             strResult);
          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;
        end if;

        --如果为超量 则 进入超量验收中 huangb 20160730
        if v_nRemainQty > 0 then
          v_IsExcessFlag := '1';
          decCheckQty    := decCheckQty + v_nRemainQty;
          v_decQPalete   := v_decQPalete + v_nRemainQty;
          v_nRemainQty   := 0;
        end if;

      end loop;

      delete from idata_check_pal_tmp
       where WAREHOUSE_NO = strWareHouseNo
         and enterprise_no = strEnterpriseNo
         and owner_no = strOwnerNo
         and s_import_no = strSimportNo
         and s_check_no = strSCheckNo
         and label_no = strLabelNo
         and row_id = GetCheckPalTmp.row_id;

    end loop;
    if intCount = 0 then
      strResult := 'N|[E20904]'; --该板上没有商品，不能封板
      return;
    end if;

    --将此此板对应的扫描日志数据转历史
    insert into bdef_scan_loghty
      (enterprise_no,
       warehouse_no,
       scan_barcode,
       source_no,
       article_no,
       cell_no,
       label_no,
       qty,
       rgst_name,
       rgst_date,
       check_type,
       operate_date,
       merge_box_no,
       dept_no)
      select enterprise_no,
             warehouse_no,
             t.scan_barcode,
             t.source_no,
             t.article_no,
             t.cell_no,
             t.label_no,
             t.qty,
             t.rgst_name,
             t.rgst_date,
             t.check_type,
             t.operate_date,
             t.merge_box_no,
             t.dept_no
        from bdef_scan_log t
       where t.label_no = strLabelNo
         AND t.warehouse_no = strWareHouseNo
         AND t.enterprise_no = strEnterpriseNo
         AND T.source_no = strSimportNo
         and t.rgst_name = strWorkerNo;

    --删除扫描日志表数据
    delete from bdef_scan_log
     where label_no = strLabelNo
       AND enterprise_no = strEnterpriseNo
       AND warehouse_no = strWareHouseNo
       AND source_no = strSimportNo
       and rgst_name = strWorkerNo;

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_CheckSplitPal_Qlide;

  /************************************************************************************************
   功能说明：超量验收配量
  ************************************************************************************************/
  procedure P_OverQtyMixAmount(strEnterpriseNo  in idata_check_pal_tmp.enterprise_no%type,
                               strWareHouseNo   in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                               strOwnerNo       in idata_check_pal_tmp.owner_no%type, --委托业主
                               strSimportNo     in idata_check_m.s_import_no%type, --进货汇总单号
                               strSCheckNo      in idata_check_pal_tmp.s_check_no%type, --验收汇总单号
                               strLabelNo       in idata_check_pal_tmp.label_no%type, --扫描的原板号，若没有默认N
                               strNewLabelNo    in idata_check_pal_tmp.label_no%type, --新取板号，流水板验收时用
                               strNewSubLabelNo in idata_check_pal_tmp.sub_label_no%type, --新子容器板号，流水板验收时用
                               strContainerNo   in idata_check_pal.container_no%type,
                               nCheckQty        in idata_check_pal_tmp.check_qty%type,
                               nRowId           in idata_check_pal_tmp.row_id%type,
                               strWorkerNo      idata_check_pal_tmp.rgst_name%type, --操作人
                               strResult        out varchar2) is
    v_strArticleNo idata_check_d.article_no%type;
    v_nPackingQty  idata_check_d.packing_qty%type;
    v_strImportNo  idata_check_m.import_no%type;
  begin
    strResult := 'N|[P_OverQtyMixAmount]';

    begin
      select d.article_no, d.packing_qty, m.import_no
        into v_strArticleNo, v_nPackingQty, v_strImportNo
        from idata_import_d d, idata_import_sm m, idata_check_pal_tmp tmp
       where m.WAREHOUSE_NO = d.WAREHOUSE_NO
         and m.enterprise_no = d.enterprise_no
         and m.owner_no = d.owner_no
         and m.import_no = d.import_no
         and tmp.enterprise_no = m.enterprise_no
         and tmp.WAREHOUSE_NO = m.WAREHOUSE_NO
         and tmp.owner_no = m.owner_no
         and tmp.s_import_no = m.s_import_no
         and tmp.s_check_no = strSCheckNo
         and tmp.label_no = strLabelNo
         and d.article_no = tmp.article_no
         and d.packing_qty = tmp.packing_qty
         and m.enterprise_no = strEnterpriseNo
         and m.WAREHOUSE_NO = strWareHouseNo
         and m.owner_no = strOwnerNo
         and m.s_import_no = strSimportNo
         and tmp.row_id = nRowId
         and m.status <> '13'
         and m.status <> '16'
         and d.status <> '13'
         and d.status <> '16'
         and rownum = 1;
    exception
      when no_data_found then
        strResult := 'N|[找不到对应的进货单数据]';
        return;
    end;

    PKOBJ_IDATA.p_insert_idata_check_D(strEnterpriseNo,
                                       strWareHouseNo,
                                       strOwnerNo,
                                       strsImportNo,
                                       strsCheckNo,
                                       v_strImportNo,
                                       strWorkerNo,
                                       nCheckQty,
                                       nRowId,
                                       strLabelNo,
                                       strResult);

    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    --更新进货单及进货汇总单
    PKOBJ_IDATA.p_Update_Idata_Import_D(strEnterpriseNo,
                                        strWareHouseNo,
                                        strOwnerNo,
                                        strSImportNo,
                                        v_strImportNo,
                                        v_strArticleNo,
                                        v_nPackingQty,
                                        nCheckQty,
                                        strWorkerNo,
                                        strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    --写进货对象
    PKOBJ_IDATA.p_Insert_Idata_Check_Pal(strEnterpriseNo,
                                         strWareHouseNo,
                                         strOwnerNo,
                                         strSimportNo,
                                         strSCheckNo,
                                         v_strImportNo,
                                         strWorkerNo,
                                         nCheckQty,
                                         strLabelNo,
                                         strNewLabelNo,
                                         strNewSubLabelNo,
                                         strContainerNo,
                                         nRowId,
                                         strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_OverQtyMixAmount;

  /************************************************************************************************
  lich
  2014-04-23
  说明：根据临时板明细写验收数据

  ***********************************************************************************************/
  procedure p_idata_MixAmount(strEnterpriseNo  in idata_check_pal_tmp.enterprise_no%type,
                              strWareHouseNo   in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                              strOwnerNo       in idata_check_pal_tmp.owner_no%type, --委托业主
                              strSimportNo     in idata_check_m.s_import_no%type, --进货汇总单号
                              strSCheckNo      in idata_check_pal_tmp.s_check_no%type, --验收汇总单号
                              strLabelNo       in idata_check_pal_tmp.label_no%type, --扫描的原板号，若没有默认N
                              strNewLabelNo    in idata_check_pal_tmp.label_no%type, --新取板号，流水板验收时用
                              strNewSubLabelNo in idata_check_pal_tmp.sub_label_no%type, --新子容器板号，流水板验收时用
                              strContainerNo   in idata_check_pal.container_no%type,
                              nCheckQty        in idata_check_pal_tmp.check_qty%type,
                              nRowId           in idata_check_pal_tmp.row_id%type,
                              strWorkerNo      in idata_check_pal_tmp.rgst_name%type, --操作人
                              nRemainQty       out idata_check_d.check_qty%type, --剩余验收量
                              strResult        out varchar2) is

    --取未验量
    cursor cur_UnCheckInfo is
      select d.article_no,
             d.packing_qty,
             d.po_qty,
             d.import_qty,
             m.import_no,
             tmp.row_id
        from idata_import_d d, idata_import_sm m, idata_check_pal_tmp tmp
       where m.WAREHOUSE_NO = d.WAREHOUSE_NO
         and m.enterprise_no = d.enterprise_no
         and m.owner_no = d.owner_no
         and m.import_no = d.import_no
         and tmp.enterprise_no = m.enterprise_no
         and tmp.WAREHOUSE_NO = m.WAREHOUSE_NO
         and tmp.owner_no = m.owner_no
         and tmp.s_import_no = m.s_import_no
         and tmp.s_check_no = strSCheckNo
         and tmp.label_no = strLabelNo
         and d.article_no = tmp.article_no
         and d.packing_qty = tmp.packing_qty
         and m.enterprise_no = strEnterpriseNo
         and m.WAREHOUSE_NO = strWareHouseNo
         and m.owner_no = strOwnerNo
         and m.s_import_no = strSimportNo
         and tmp.row_id = nRowId
         and (d.po_qty - d.import_qty > 0 or d.po_qty = 0) --Add BY QZH AT 2016-7-12
         and m.status <> '13'
         and m.status <> '16'
         and d.status <> '13'
         and d.status <> '16';

    nUnCheckQty  idata_check_d.check_qty%type; --未验量
    nTmpQty      idata_check_d.check_qty%type; --中间量
    nSumCheckQty idata_check_d.check_qty%type; --板验收量
    v_iCount     integer;
  begin
    strResult := 'N|[p_idata_MixAmount]';
    v_iCount  := 0;
    --取板信息
    nTmpQty := 0;

    nSumCheckQty := nCheckQty;

    for cur_UnCheck in cur_UnCheckInfo loop

      v_iCount := v_iCount + 1;

      --超品ADD BY QZH AT 2016-7-12
      if cur_UnCheck.po_qty = 0 then
        nUnCheckQty := nSumCheckQty;
      else
        --正常配量
        nUnCheckQty := cur_UnCheck.po_qty - cur_UnCheck.import_qty;
      end if;

      if (nUnCheckQty > 0) then
        --有未验量时扣减数量
        if (nSumCheckQty < nUnCheckQty) then
          nTmpQty := nSumCheckQty;
        else
          nTmpQty := nUnCheckQty;
        end if;

        PKOBJ_IDATA.p_insert_idata_check_D(strEnterpriseNo,
                                           strWareHouseNo,
                                           strOwnerNo,
                                           strsImportNo,
                                           strsCheckNo,
                                           cur_UnCheck.import_no,
                                           strWorkerNo,
                                           nTmpQty,
                                           nRowId,
                                           strLabelNo,
                                           strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        --更新进货单及进货汇总单
        PKOBJ_IDATA.p_Update_Idata_Import_D(strEnterpriseNo,
                                            strWareHouseNo,
                                            strOwnerNo,
                                            strSImportNo,
                                            cur_UnCheck.import_no,
                                            cur_UnCheck.Article_No,
                                            cur_UnCheck.Packing_Qty,
                                            nTmpQty,
                                            strWorkerNo,
                                            strResult);
        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        --写进货对象
        PKOBJ_IDATA.p_Insert_Idata_Check_Pal(strEnterpriseNo,
                                             strWareHouseNo,
                                             strOwnerNo,
                                             strSimportNo,
                                             strSCheckNo,
                                             cur_UnCheck.import_no,
                                             strWorkerNo,
                                             nTmpQty,
                                             strLabelNo,
                                             strNewLabelNo,
                                             strNewSubLabelNo,
                                             strContainerNo,
                                             nRowId,
                                             strResult);
        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;
        nSumCheckQty := nSumCheckQty - nTmpQty; --验收量扣减完,跳出循环
      end if;

      if (nSumCheckQty <= 0) then
        exit;
      end if;
    end loop;
    nRemainQty := nSumCheckQty;
    /*    if v_iCount = 0 then
          strResult := 'N|[E20932]';--读进货明细失败
          return;
        end if;
    */
    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_idata_MixAmount;

  /***********************************************************************************************
  修改人:lich
  日期:2014-04-24
  功能：根据验收汇总单写标签数据、定位指示和库存
  ************************************************************************************************/
  procedure p_idata_sCheckLocateInstock(strEnterpriseNo    in stock_label_m.enterprise_no%type, --企业
                                        strWareHouseNo     in stock_label_m.warehouse_no%type, --仓别
                                        strScheckNo        in idata_check_pal.s_check_no%type, --汇总验收单号
                                        strUser_ID         in stock_label_m.Rgst_Name%type, --操作人员
                                        strCheckTool       in idata_check_pal_tmp.check_tools%type, --验收工具
                                        strspecify_cell_no in idata_locate_direct.specify_cell_no%type, --指定储位
                                        strLabelNo         in idata_check_pal.label_no%type, --如果表单作业刚传值N，RF作业刚板号
                                        strLocateNo        OUT idata_locate_direct.locate_no%type,
                                        strOutMsg          out varchar2) is

    cursor v_GetCheckPal is
      select imm.serial_no, icp.*, icm.Supplier_No
        from idata_check_pal icp,
             idata_check_m   icm,
             idata_check_d   icd,
             idata_import_m  iim,
             idata_import_mm imm
       where icm.enterprise_no = icp.enterprise_no
         and icm.enterprise_no = icd.enterprise_no
         and icm.warehouse_no = icp.warehouse_no
         and icm.warehouse_no = icd.warehouse_no
         and icm.owner_no = icp.owner_no
         and icm.owner_no = icd.owner_no
         and icm.check_no = icd.check_no
         and icm.check_no = icp.check_no
         and icm.enterprise_no = strEnterpriseNo
         and icm.warehouse_no = strWareHouseNo
         and icm.s_check_no = strScheckNo
         and icp.label_no =
             decode(strLabelNo, 'N', icp.label_no, strLabelNo)
         and icd.row_id = icp.check_row_id
         and icp.status = '10'
         and iim.import_no = icm.import_no
         and iim.enterprise_no = icm.enterprise_no
         and iim.warehouse_no = icm.warehouse_no
         and iim.owner_no = icm.owner_no
         and imm.s_import_no = icm.s_import_no
         and imm.enterprise_no = icm.enterprise_no
         and imm.warehouse_no = icm.warehouse_no
         and imm.owner_no = icm.owner_no
         and icp.article_no = icd.article_no --add by luozhiling 20160813
      /*        and icp.business_type='0'*/
       order by icp.label_no, /*icp.scan_label_no*/ icp.sub_label_no;

    strContainerType     stock_label_m.container_type%type; --标签类型
    strContainerNo       stock_label_m.container_no%type; --容器号
    strREPORT_ID         stock_label_m.report_id%type; --报表ID
    strCellNo            stock_content.cell_no%type; --暂存区储位
    strSESSION_ID        varchar2(500); --不返回标签号时，返回sessionID号
    v_nPalRowID          stock_label_d.row_id%type;
    v_nBoxRowID          stock_label_d.row_id%type;
    v_strLabelNo         stock_label_m.label_no%type; --记录label_no
    v_strSubLabelNo      idata_check_pal.sub_label_no%type; --记录sub_label_no
    v_strSubLabelNoTmp   idata_check_pal.sub_label_no%type; --记录sub_label_no
    v_Container_Material WMS_DEFCONTAINER.Container_Material%type; --容器材质
    v_strLocateNo        idata_locate_direct.locate_no%type; --进货定位单号
    v_iCount             integer;
    v_nArticleId         stock_content.article_id%type; --商品属性ID
    v_nCellID            stock_content.cell_id%type;
    v_strLocateType      idata_locate_direct.locate_type%type;
    v_LocateFlag         idata_locate_direct.container_locate_flag%type; --0按箱定位；1：按商品定位
    v_strAutoLoateFlag   idata_locate_direct.auto_locate_flag%type; --0：人工定位；1:自动定位
    v_strMixFlag         cdef_defarea.mix_flag%type;
    v_strImportType      idata_import_m.import_type%type;
  begin

    strOutMsg       := 'N|[p_idata_sCheckLocateInstock]';
    v_nPalRowID     := 0;
    v_nBoxRowID     := 0;
    v_strLabelNo    := 'N';
    v_strSubLabelNo := 'N';
    strContainerNo  := 'N';
    v_iCount        := 0;
    --获取暂存区储位
    begin
      select CDC.CELL_NO
        into strCellNo
        FROM CDEF_DEFAREA CDA, CDEF_DEFCELL CDC
       WHERE CDA.ENTERPRISE_NO = CDC.ENTERPRISE_NO
         AND CDA.warehouse_no = CDC.warehouse_no
         AND CDA.WARE_NO = CDC.WARE_NO
         AND CDA.AREA_NO = CDC.AREA_NO
         AND CDA.AREA_ATTRIBUTE = '1'
         AND (CDA.ATTRIBUTE_TYPE = '1' OR CDA.ATTRIBUTE_TYPE = '0')
         and cda.warehouse_no = strWareHouseNo
         and cda.enterprise_no = strEnterpriseNo
         and rownum < 2
       order by cdc.cell_no;
    exception
      when no_data_found then
        strOutMsg := 'N|[E20905]'; --获取进货暂存区失败;
        return;
    end;

    --取定位指示号；
    begin
      PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                 strWareHouseNo,
                                 CONST_DOCUMENTTYPE.IDATAIL,
                                 v_strLocateNo,
                                 strOutMsg);
      if (strOutMsg is null or substr(strOutMsg, 1, 1) = 'N') then
        strOutMsg := 'N|[E20906]'; --取进货定位单号失败
        return;
      end if;
    end;

    strLocateNo := v_strLocateNo;

    --循环板明细添加标签信息
    for GetCheckPal in v_GetCheckPal loop
      v_iCount        := v_iCount + 1;
      v_strImportType := GetCheckPal.import_type;

      -----------------开始****写板标签头-------------------------------
      --判断容器类型
      if substr(GetCheckPal.Label_No, 0, 1) = 'B' then
        strContainerType := 'B';
        strREPORT_ID     := CONST_REPORTID.IM_ID_DIVIDE_B;
      else
        strContainerType := 'P';
        strREPORT_ID     := CONST_REPORTID.B_I_INSTOCKP;
      end if;

      if GetCheckPal.label_no <> GetCheckPal.sub_label_no then
        --板标签
        if GetCheckPal.label_no <> v_strLabelNo then
          v_nPalRowID          := 1;
          v_strLabelNo         := GetCheckPal.label_no;
          strContainerNo       := GetCheckPal.container_no;
          v_Container_Material := '31';
        else
          v_nPalRowID := v_nPalRowID + 1;
        end if;
        --箱标签
        if GetCheckPal.sub_label_no <> v_strSubLabelNo then
          v_nBoxRowID          := 1;
          v_strSubLabelNo      := GetCheckPal.sub_label_no;
          v_Container_Material := '21';
        else
          v_nBoxRowID := v_nBoxRowID + 1;
        end if;
      else
        --板标签
        if GetCheckPal.label_no <> v_strLabelNo then
          v_nPalRowID          := 1;
          v_strLabelNo         := GetCheckPal.label_no;
          strContainerNo       := GetCheckPal.container_no;
          v_Container_Material := '31';
        else
          v_nPalRowID := v_nPalRowID + 1;
        end if;
        v_nBoxRowID := 0;
      end if;
      if v_nPalRowID = 1 then
        --写板标签头
        PKOBJ_IDATA.p_Insert_Stock_Label_M(strEnterpriseNo,
                                           strWareHouseNo,
                                           'N',
                                           strScheckNo,
                                           v_strLabelNo,
                                           strContainerNo,
                                           strContainerType,
                                           'N',
                                           strCellNo,
                                           GetCheckPal.CUST_NO,
                                           'N',
                                           'N',
                                           'N',
                                           'N',
                                           '0',
                                           'N',
                                           GetCheckPal.Dock_No,
                                           'N',
                                           strUser_ID,
                                           strREPORT_ID,
                                           'N',
                                           1,
                                           GetCheckPal.Stock_Type,
                                           '0',
                                           GetCheckPal.container_no,
                                           0,
                                           0,
                                           GetCheckPal.wave_no,
                                           strOutMsg);
        if substr(strOutMsg, 1, 1) = 'N' then
          return;
        end if;
      end if;

      if v_nBoxRowID = 1 then
        --箱标签时，通过label_no取内部容器号，相同板号只取一次
        pklg_wms_base.p_get_ContainerNoBase(strEnterpriseNo,
                                            strWareHouseNo,
                                            'C',
                                            strUser_ID,
                                            'D',
                                            1, --产生容器号数量
                                            2, --标签用途
                                            v_Container_Material, --容器材质
                                            v_strSubLabelNoTmp,
                                            strContainerNo,
                                            strSESSION_ID,
                                            strOutMsg);
        if (substr(strOutMsg, 1, 1) = 'N') then
          return;
        end if;

        if v_strSubLabelNo <> 'N' then
          v_strSubLabelNoTmp := v_strSubLabelNo;
        end if;

        --写箱标签头
        PKOBJ_IDATA.p_Insert_Stock_Label_M(strEnterpriseNo,
                                           strWareHouseNo,
                                           'N',
                                           strScheckNo,
                                           v_strSubLabelNoTmp,
                                           strContainerNo,
                                           strContainerType,
                                           'N',
                                           strCellNo,
                                           GetCheckPal.CUST_NO,
                                           'N',
                                           'N',
                                           'N',
                                           'N',
                                           '0',
                                           'N',
                                           GetCheckPal.Dock_No,
                                           'N',
                                           strUser_ID,
                                           strREPORT_ID,
                                           'N',
                                           1,
                                           GetCheckPal.Stock_Type,
                                           '0',
                                           GetCheckPal.container_no,
                                           0,
                                           0,
                                           GetCheckPal.wave_no,
                                           strOutMsg);

        if substr(strOutMsg, 1, 1) = 'N' then
          return;
        end if;
      end if;
      ------------------结束****写板标签头------------------------------------
      -----------------开始****增加目的储位库存-------------------------------
      --获取商品属性ID
      PKLG_WMS_BASE.p_getArticleID(GetCheckPal.Enterprise_No,
                                   GetCheckPal.article_no,
                                   GetCheckPal.barcode,
                                   GetCheckPal.lot_no,
                                   GetCheckPal.Produce_Date,
                                   GetCheckPal.expire_date,
                                   --GetCheckPal.item_type,
                                   GetCheckPal.quality,
                                   GetCheckPal.Rsv_Batch1,
                                   GetCheckPal.Rsv_Batch2,
                                   GetCheckPal.Rsv_Batch3,
                                   GetCheckPal.Rsv_Batch4,
                                   GetCheckPal.Rsv_Batch5,
                                   GetCheckPal.Rsv_Batch6,
                                   GetCheckPal.Rsv_Batch7,
                                   GetCheckPal.Rsv_Batch8,
                                   --GetCheckPal.batch_serial_no,
                                   --'N',
                                   GetCheckPal.check_no,
                                   '0',
                                   strUser_ID,
                                   GetCheckPal.Price,
                                   v_nArticleId,
                                   strOutMsg);

      if (substr(strOutMsg, 1, 1) <> 'Y') then
        return;
      end if;

      --增加目的储位库存
      PKobj_stock.p_InstContent_qtyByCellNo(strEnterpriseNo,
                                            strWareHouseNo,
                                            GetCheckPal.owner_no,
                                            GetCheckPal.dept_no,
                                            GetCheckPal.article_no,
                                            v_nArticleId,
                                            strCellNo,
                                            strCellNo,
                                            GetCheckPal.packing_qty,
                                            GetCheckPal.check_qty,
                                            GetCheckPal.Label_No,
                                            GetCheckPal.Sub_Label_No,
                                            GetCheckPal.stock_type,
                                            GetCheckPal.stock_value,
                                            strUser_ID,
                                            strScheckNo,
                                            strCheckTool,
                                            '0',
                                            v_nCellID,
                                            strOutMsg);

      if (substr(strOutMsg, 1, 1) <> 'Y') then
        return;
      end if;
      -----------------结束****增加目的储位库存-------------------------------
      -----------------开始****写定位指示表-----------------------------------
      if GetCheckPal.BUSINESS_TYPE = '0' or GetCheckPal.BUSINESS_TYPE = '1' then
        v_strLocateType := '1';
        v_LocateFlag    := '1';
      end if;
      --commit;

      --
      begin
        select a.mix_flag
          into v_strMixFlag
          from (select cd.ware_no || cd.area_no, cd.mix_flag
                  from cset_cell_article  cca,
                       cset_area_backup_d cab,
                       cdef_defarea       cd
                 where cca.enterprise_no = cab.enterprise_no
                   and cca.warehouse_no = cab.warehouse_no
                   and cca.line_id = cab.line_id
                   and cab.enterprise_no = cd.enterprise_no
                   and cab.warehouse_no = cd.warehouse_no
                   and cab.ware_no || cab.area_no = cd.ware_no || cd.area_no
                   and cd.area_pick = '0'
                   and cca.article_no = GetCheckPal.article_no
                   and cd.enterprise_no = strEnterpriseNo
                   and cd.warehouse_no = strWareHouseNo
                 order by cab.a_level) a
         where rownum = 1;
      exception
        when no_data_found then
          v_strMixFlag := '2';
      end;

      if v_strMixFlag = '0' then
        v_strAutoLoateFlag := '1';
      else
        v_strAutoLoateFlag := '0';
      end if;

      PKOBJ_IDATA.p_Insert_Idata_Locate_Direct(strEnterpriseNo,
                                               strWareHouseNo,
                                               GetCheckPal.owner_no,
                                               v_strLocateType,
                                               v_LocateFlag,
                                               v_strAutoLoateFlag,
                                               strScheckNo,
                                               strCellNo,
                                               strUser_ID,
                                               strLocateNo,
                                               strspecify_cell_no,
                                               GetCheckPal.article_no,
                                               v_nArticleId,
                                               GetCheckPal.packing_qty,
                                               GetCheckPal.Dock_No,
                                               GetCheckPal.Printer_Group_No,
                                               GetCheckPal.Rgst_Name,
                                               GetCheckPal.stock_type,
                                               GetCheckPal.stock_value,
                                               GetCheckPal.Sub_Label_No,
                                               GetCheckPal.Label_No,
                                               GetCheckPal.Business_Type,
                                               GetCheckPal.Fixpal_Flag,
                                               GetCheckPal.serial_no,
                                               GetCheckPal.Quality,
                                               GetCheckPal.Import_Type,
                                               strOutMsg);

      if (substr(strOutMsg, 1, 1) <> 'Y') then
        return;
      end if;

      -----------------结束****写定位指示表-----------------------------------
      --更新板明细状态
      update idata_check_pal icp
         set icp.status    = '13',
             icp.updt_name = strUser_ID,
             icp.updt_date = sysdate
       where icp.enterprise_no = strEnterpriseNo
         and icp.warehouse_no = strWareHouseNo
         and icp.owner_no = GetCheckPal.owner_no
         and icp.s_check_no = GetCheckPal.s_check_no
         and icp.check_no = GetCheckPal.check_no
         and icp.check_row_id = GetCheckPal.check_row_id
         and icp.container_no = GetCheckPal.container_no
         and icp.label_no = GetCheckPal.label_no
         and icp.sub_label_no = GetCheckPal.Sub_Label_No
         and icp.status = '10';

      if sql%notfound then
        strOutMsg := 'N|[E20907]'; --更新板明细失败;
        return;
      end if;
    end loop;

    if v_iCount = 0 then
      strOutMsg := 'N|[E20908]'; --没有获取到板明细信息;
      return;
    end if;

    if substr(strOutMsg, 1, 1) = 'N' then
      return;
    end if;

    --判断商品是否可以
    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_idata_sCheckLocateInstock;

  /*************************************************************************************************
       修改人：luozhiling
       日期：2013-10-20
       功能：验收确认,可支持一单一验，一单多验和一品多验
       一单一验：1、验收单确认
                 2、进货汇总单做确认，进货汇总单转历史
                 3、对进货单进行结案。
       一单多验：
                1、验收单确认
                2、根据参数配置判断：a.进货汇总单可继续用，不更新进货汇总单数据，只将进货单已验收的品项置为13的状态
                b.进货汇总单置为13状态，并转历史，置进货单已验收的品项为13状态。
       一品多验：
                 1、验收单确认
                 2、根据参数配置判断：a.进货汇总单可继续用，不更新进货汇总单数据，只将进货单已验收完成的品项置为13的状态
                b.进货汇总单置为13状态，并转历史，置进货单已验收完成的品项为13状态。

        更新物流码为已入库，并记录相应的进货汇总单号
  *************************************************************************************************/
  procedure P_Comfire_Idata_Check(strEnterprise_No in idata_check_pal_tmp.enterprise_no%type, --企业
                                  strWAREHOUSE_NO  in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码)
                                  strS_import_no   in idata_check_m.s_import_no%type, --进货汇总单号
                                  strS_Check_no    in idata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                  strWorkerNo      in idata_check_pal_tmp.rgst_name%type, --操作人
                                  strUnloadWorker  in idata_check_m.unload_worker%type, --卸货人
                                  strDockNo        in pntset_printer_workstation.workstation_no%type, --工作站号
                                  strResult        Out varchar2) is
    --v_strPrtTask              job_printtask_m.task_no%type;
    v_strIC_ReturnType        wms_defbase.sdefine%type; --是否一单一验参数
    v_nIC_ReturnType          wms_defbase.ndefine%type;
    v_strIC_ConfirmBuildSheet wms_defbase.sdefine%type; ---0：剩余部分手工重新预约，1：不自动预约，原汇总单有效,2：自动预约产生新汇总单
    v_nIC_ConfirmBuildSheet   wms_defbase.ndefine%type;
    v_strOwnerNo              idata_import_mm.owner_no%type;
    v_Import_Type             idata_import_m.import_type%type;
    v_OutFlag                 wms_idatatype.diff_confirm_flag%type;
    v_strCount                NUMBER;
  begin
    strResult := 'N|[P_Comfire_Idata_Check]';

    --获取货主信息
    select distinct owner_no, import_type
      into v_strOwnerNo, v_Import_Type
      from idata_import_sm
     where enterprise_no = strEnterprise_No
       and warehouse_no = strWAREHOUSE_NO
       and s_import_no = strS_import_no;

    --验收有差异时是否允许验收确认
    PKLG_WMS_PUBLIC.P_GetIdataOrder(strEnterprise_No,
                                    strWAREHOUSE_NO,
                                    v_strOwnerNo,
                                    v_Import_Type,
                                    'DIFF_CONFIRM_FLAG',
                                    v_OutFlag,
                                    strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    --有差异时不允许验收确认
    if v_OutFlag = '0' then
      select count(1)
        into v_strCount
        from idata_import_d iid
       where iid.warehouse_no = strWAREHOUSE_NO
         and iid.enterprise_no = strEnterprise_No
         and iid.po_qty <> iid.import_qty
         and exists (select 'x'
                from idata_import_sm mm
               where mm.enterprise_no = strEnterprise_No
                 and mm.warehouse_no = strWAREHOUSE_NO
                 and mm.s_import_no = strS_import_no
                 and mm.warehouse_no = iid.warehouse_no
                 and mm.enterprise_no = iid.enterprise_no
                 and mm.import_no = iid.import_no
                 and mm.owner_no = iid.owner_no);

      if v_strCount > 0 then
        strResult := 'N|[' || strS_import_no || ']有差异不允许验收确认！';
        return;
      end if;
    end if;

    --取一单多验，未完验的单验收确认时预约参数
    PKLG_WMS_BASE.p_GetBasePara(strEnterprise_No,
                                strWAREHOUSE_NO,
                                v_strOwnerNo,
                                'IC_ConfirmBuildSheet',
                                'I',
                                'IC',
                                v_strIC_ConfirmBuildSheet,
                                v_nIC_ConfirmBuildSheet,
                                strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    --取一单一验，一单多验和一品多验的系统参数
    PKLG_WMS_BASE.p_GetBasePara(strEnterprise_No,
                                strWAREHOUSE_NO,
                                v_strOwnerNo,
                                'IC_ReturnType',
                                'I',
                                'IC',
                                v_strIC_ReturnType,
                                v_nIC_ReturnType,
                                strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    if v_strIC_ReturnType = '1' then
      v_strIC_ConfirmBuildSheet := '0';
    end if;

    --更新验收单状态
    PKOBJ_IDATA.P_Close_Idata_Check(strEnterprise_No,
                                    strWAREHOUSE_NO,
                                    strS_import_no,
                                    strS_Check_nO,
                                    strWorkerNo,
                                    strUnloadWorker,
                                    v_strIC_ConfirmBuildSheet,
                                    strDockNo,
                                    strResult);

    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    --根据验收明细写库存三级帐
    for GetCheckItem in (select icm.import_type, icd.*
                           from idata_check_m icm, idata_check_d icd
                          where icm.enterprise_no = icd.enterprise_no
                            and icm.warehouse_no = icd.warehouse_no
                            and icm.check_no = icd.check_no
                            and icm.enterprise_no = strEnterprise_No
                            and icm.warehouse_no = strWAREHOUSE_NO
                            and icm.s_check_no = strS_Check_no
                            and icm.s_import_no = strS_import_no) loop

      --写商品批次库存帐
      pkobj_stock.P_insertImportBatchStock(strEnterprise_No,
                                           strWAREHOUSE_NO,
                                           v_strOwnerNo,
                                           GetCheckItem.dept_no,
                                           GetCheckItem.article_no,
                                           GetCheckItem.quality,
                                           GetCheckItem.check_no,
                                           GetCheckItem.produce_date,
                                           GetCheckItem.expire_date,
                                           GetCheckItem.lot_no,
                                           GetCheckItem.rsv_batch1,
                                           GetCheckItem.rsv_batch2,
                                           GetCheckItem.rsv_batch3,
                                           GetCheckItem.rsv_batch4,
                                           GetCheckItem.rsv_batch5,
                                           GetCheckItem.rsv_batch6,
                                           GetCheckItem.rsv_batch7,
                                           GetCheckItem.rsv_batch8,
                                           GetCheckItem.barcode,
                                           GetCheckItem.packing_qty,
                                           GetCheckItem.check_qty,
                                           GetCheckItem.stock_type,
                                           GetCheckItem.stock_value,
                                           strWorkerNo,
                                           strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
      --写库存三级帐
      pkobj_stock.P_InsertArticleStockList(strEnterprise_No,
                                           strWAREHOUSE_NO,
                                           v_strOwnerNo,
                                           GetCheckItem.dept_no,
                                           GetCheckItem.article_no,
                                           GetCheckItem.quality,
                                           GetCheckItem.produce_date,
                                           GetCheckItem.expire_date,
                                           GetCheckItem.lot_no,
                                           GetCheckItem.rsv_batch1,
                                           GetCheckItem.rsv_batch2,
                                           GetCheckItem.rsv_batch3,
                                           GetCheckItem.rsv_batch4,
                                           GetCheckItem.rsv_batch5,
                                           GetCheckItem.rsv_batch6,
                                           GetCheckItem.rsv_batch7,
                                           GetCheckItem.rsv_batch8,
                                           GetCheckItem.barcode,
                                           GetCheckItem.packing_qty,
                                           GetCheckItem.check_qty,
                                           GetCheckItem.stock_type,
                                           GetCheckItem.stock_value,
                                           1,
                                           GetCheckItem.import_type,
                                           GetCheckItem.check_no,
                                           strWorkerNo,
                                           GetCheckItem.check_no,
                                           strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

    end loop;

    --如果配置为自动产生汇总单或者该进货单已经验完则转历史
    select count(*)
      into v_strCount
      from idata_import_d d, idata_import_sm sm
     where d.enterprise_no = sm.enterprise_no
       and d.warehouse_no = sm.enterprise_no
       and d.import_no = sm.import_no
       and d.enterprise_no = strEnterprise_No
       and d.warehouse_no = strWAREHOUSE_NO
       and sm.s_import_no = strS_import_no
       and d.po_qty <> d.import_qty;

    if v_strIC_ConfirmBuildSheet <> '1' or v_strCount = 0 then

      --将进货汇总单数据转历史
      PKOBJ_IDATA.P_Idata_sImportToHty(strEnterprise_No,
                                       strWAREHOUSE_NO,
                                       v_strOwnerNo,
                                       strS_import_no,
                                       strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
    end if;

    --将进货单状态改为结案；
    PKOBJ_IDATA.P_Close_Idata_Import(strEnterprise_No,
                                     strWAREHOUSE_NO,
                                     strS_import_no,
                                     strWorkerNo,
                                     v_strIC_ReturnType,
                                     strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_Comfire_Idata_Check;
  /*************************************************************************************************
       创建人：hekl
       日期：2015-09-17
       功能：验收确认,可支持一单一验，一单多验和一品多验,天天惠
             1、验收确认
             2、将进货单明细总量小于10的单据结案（包括汇总单）
  *************************************************************************************************/
  procedure P_Comfire_Idata_Check_tth(strEnterprise_No in idata_check_pal_tmp.enterprise_no%type, --企业
                                      strWAREHOUSE_NO  in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码)
                                      strS_import_no   in idata_check_m.s_import_no%type, --进货汇总单号
                                      strS_Check_no    in idata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                      strPoNo          in idata_import_m.po_no%type, --采购单号
                                      strWorkerNo      in idata_check_pal_tmp.rgst_name%type, --操作人
                                      strUnloadWorker  in idata_check_m.unload_worker%type, --卸货人
                                      strDockNo        in pntset_printer_workstation.workstation_no%type, --工作站号
                                      strResult        Out varchar2) is
    v_strCount    NUMBER;
    v_strImportNo IDATA_IMPORT_D.IMPORT_NO%TYPE;
    v_strOwnerNo  idata_import_mm.owner_no%type;
  begin
    strResult := 'N|[P_Comfire_Idata_Check_tth]';

    --获取货主信息
    select distinct owner_no
      into v_strOwnerNo
      from idata_import_sm
     where enterprise_no = strEnterprise_No
       and warehouse_no = strWAREHOUSE_NO
       and s_import_no = strS_import_no;

    --验收确认；
    P_Comfire_Idata_Check(strEnterprise_No,
                          strWAREHOUSE_NO,
                          strS_import_no,
                          strS_Check_no,
                          strWorkerNo,
                          strUnloadWorker,
                          strDockNo,
                          strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    --将进货单明细总量小于10的单据结案（包括汇总单）
    select count(*)
      into v_strCount
      from idata_import_m m
     where m.enterprise_no = strEnterprise_No
       and m.warehouse_no = strWAREHOUSE_NO
       and m.po_no = strPoNo
       and m.status not in ('13', '16');

    if v_strCount > 0 then

      begin
        select count(*)
          into v_strCount
          from idata_import_d d, idata_import_sm sm
         where d.enterprise_no = sm.enterprise_no
           and d.warehouse_no = sm.warehouse_no
           and d.import_no = sm.import_no
           and d.enterprise_no = strEnterprise_No
           and d.warehouse_no = strWAREHOUSE_NO
           and sm.s_import_no = strS_import_no having
         sum(d.po_qty - d.import_qty) < 10;
      exception
        when no_data_found then
          v_strCount := 0;
      end;

      if v_strCount > 0 then
        select sm.import_no
          into v_strImportNo
          from idata_import_sm sm
         where sm.enterprise_no = strEnterprise_No
           and sm.warehouse_no = strWAREHOUSE_NO
           and sm.s_import_no = strS_import_no;

        --更新进货单状态
        update idata_import_m
           set status = '13'
         where import_no = v_strImportNo
           and enterprise_no = strEnterprise_No
           and warehouse_no = strWAREHOUSE_NO
           and status not in ('13', '16');

        update idata_import_D
           set status = '13'
         where import_no = v_strImportNo
           and enterprise_no = strEnterprise_No
           and warehouse_no = strWAREHOUSE_NO
           and status not in ('13', '16');

        update idata_import_allot
           set status = '13'
         where import_no = v_strImportNo
           and enterprise_no = strEnterprise_No
           and warehouse_no = strWAREHOUSE_NO
           and status not in ('13', '16');

        --更新进货汇总状态
        update idata_import_sd
           set status = '13'
         where s_import_no = strS_import_no
           and enterprise_no = strEnterprise_No
           and warehouse_no = strWAREHOUSE_NO
           and status not in ('13', '16');

        update idata_import_sm
           set status = '13', updt_name = strWorkerNo, updt_date = sysdate
         where enterprise_no = strEnterprise_No
           and warehouse_no = strWAREHOUSE_NO
           and s_import_no = strS_import_no
           and status not in ('13', '16');

        update idata_import_mm iim
           set status = '13', updt_name = strWorkerNo, updt_date = sysdate
         where enterprise_no = strEnterprise_No
           and warehouse_no = strWAREHOUSE_NO
           and s_import_no = strS_import_no
           and status not in ('13', '16');
        --将进货汇总单数据转历史
        PKOBJ_IDATA.P_Idata_sImportToHty(strEnterprise_No,
                                         strWAREHOUSE_NO,
                                         v_strOwnerNo,
                                         strS_import_no,
                                         strResult);
        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

      end if;
    end if;

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_Comfire_Idata_Check_tth;

  /*************************************************************************************************
       修改人：lich
       日期：2013-05-06
       功能：上架回单

  *************************************************************************************************/
  procedure p_Save_Idata_InStock(strEnterpriseNo in idata_instock_m.enterprise_no%type,
                                 strWareHouseNo  in idata_instock_m.warehouse_no%type,
                                 strInstockNo    in idata_instock_m.instock_no%type,
                                 strDestCellNo   in idata_instock_d.dest_cell_no%type,
                                 strRealCellNo   in idata_instock_d.real_cell_no%type,
                                 strLabelNo      in idata_instock_d.label_no%type,
                                 strArticleNo    in idata_instock_d.article_no%type,
                                 dtProduceDate   in idata_check_d.produce_date%type,
                                 dtExpireDate    in idata_check_d.expire_date%type,
                                 strQuality      in idata_check_d.quality%type, --品质
                                 strLotNo        in idata_check_d.lot_no%type, --批次号
                                 strRSV_BATCH1   in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                                 strRSV_BATCH2   in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                                 strRSV_BATCH3   in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                                 strRSV_BATCH4   in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                                 strRSV_BATCH5   in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                                 strRSV_BATCH6   in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                                 strRSV_BATCH7   in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                                 strRSV_BATCH8   in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                                 nPackingQty     in idata_instock_d.packing_qty%type,
                                 nArticleQty     in idata_instock_d.article_qty%type,
                                 nRealQty        in idata_instock_d.real_qty%type,
                                 strUserId       in idata_instock_m.rgst_name%type, --上架人
                                 strPaperUserId  in idata_instock_m.rgst_name%type, --回单人
                                 strTools        in stock_content_move.terminal_flag%type,
                                 nIsAddFlag      in integer, --是否新增记录 1是0否
                                 strResult       out varchar2) is
    cursor v_GetInstockItem is
      select iid.instock_id,
             iid.owner_no,
             iid.cell_no,
             iid.cell_id,
             iid.article_no,
             iid.article_id,
             iid.dest_cell_id,
             iid.dest_cell_no,
             iid.article_qty,
             iid.real_qty,
             iid.real_cell_no,
             iid.packing_qty,
             iid.sub_label_no,
             iiD.stock_type,
             iid.stock_value,
             iid.business_type,
             iid.label_no
        from idata_instock_d    iid,
             idata_instock_m    iim,
             stock_article_info sai
       where iid.enterprise_no = iim.enterprise_no
         and iid.enterprise_no = sai.enterprise_no
         and iim.warehouse_no = iid.warehouse_no
         and iim.instock_no = iid.instock_no
         and iid.article_no = sai.article_no
         and iid.article_id = sai.article_id
         and iid.enterprise_no = strEnterpriseNo
         and iid.warehouse_no = strWareHouseNo
         and iid.instock_no = strInstockNo
         and iid.label_no = strLabelNo
         and iid.article_no = strArticleNo
         and iid.dest_cell_no = strDestCellNo
         and iid.packing_qty = nPackingQty
         and sai.produce_date = dtProduceDate
         and sai.expire_date = dtExpireDate
         and sai.lot_no = strLotNo
         and sai.rsv_batch1 = strRSV_BATCH1
         and sai.rsv_batch2 = strRSV_BATCH2
         and sai.rsv_batch3 = strRSV_BATCH3
         and sai.rsv_batch4 = strRSV_BATCH4
         and sai.rsv_batch5 = strRSV_BATCH5
         and sai.rsv_batch6 = strRSV_BATCH6
         and sai.rsv_batch7 = strRSV_BATCH7
         and sai.rsv_batch8 = strRSV_BATCH8
         and iid.status = '10'
      --and iid.article_qty-iid.real_qty>0
       order by iid.dest_cell_no,
                iid.article_no,
                case
                  when iid.article_qty = nRealQty then
                   1
                  else
                   2
                end,
                iid.article_qty - iid.real_qty;
    --iid.instock_id;

    v_strDeptNo         stock_content.dept_no%type;
    nRemainQty          stock_content.qty%type; --剩余数量
    nTempQty            stock_content.qty%type; --当次回单数量
    v_icount            integer;
    strOtype            cdef_defarea.o_type%type;
    v_nCellID           stock_content.cell_id%type;
    v_strLabelNo        stock_label_m.label_no%type;
    v_nOutCellId        stock_content.cell_id%type;
    v_strOwnerNo        bdef_defowner.owner_no%type;
    v_strLoateType      idata_instock_m.locate_type%type;
    v_strInstockDiffQty wms_defbase.sdefine%type;
    v_nInstockDiffQty   wms_defbase.ndefine%type;
    v_updateStatusFlag  wms_defbase.sdefine%type := '0'; --0:不拆笔，不差异回单；1：有差异回单不拆笔，2：有差异回单拆笔
    v_nArticleQty       idata_instock_d.article_qty%type;
    v_strCellNo         cdef_defcell.cell_no%type;
    v_Import_Type       idata_import_m.import_type%type;
    v_Owner_No          idata_import_m.owner_no%type;
    v_OutFlag           wms_idatatype.unconfirm_instock_flag%type;
    v_Source_No         idata_instock_d.source_no%type;
  begin
    strResult := 'N|[p_Save_Idata_InStock]';

    select DISTINCT iim.locate_type,
                    iim.owner_no,
                    iim.import_type,
                    iim.owner_no,
                    iid.source_no
      into v_strLoateType,
           v_strOwnerNo,
           v_Import_Type,
           v_Owner_No,
           v_Source_No
      from idata_instock_m iim, IDATA_INSTOCK_D IID
     where iim.enterprise_no = strEnterpriseNo
       and iim.warehouse_no = strWareHouseNo
       and iim.instock_no = strInstockNo
       AND iim.enterprise_no = iid.enterprise_no
       and iim.warehouse_no = iid.warehouse_no
       and iim.instock_no = iid.instock_no
       and iim.owner_no = iid.owner_no;

    --上架时判断验收确认状态
    PKLG_WMS_PUBLIC.P_GetIdataOrder(strEnterpriseNo,
                                    strWareHouseNo,
                                    v_Owner_No,
                                    v_Import_Type,
                                    'UNCONFIRM_INSTOCK_FLAG',
                                    v_OutFlag,
                                    strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    if v_OutFlag = '0' then
      --未确认不允许上架

      select count(1)
        into v_icount
        from idata_check_m icm
       where icm.warehouse_no = strWareHouseNo
         and icm.enterprise_no = strEnterpriseNo
         and icm.s_check_no = v_Source_No
         and icm.status < '13';

      if v_icount > 0 then
        strResult := 'N|[' || v_Source_No || ']未验收确认不允许上架！';
        return;
      end if;
    end if;

    if v_strLoateType = '1' then
      --读取
      PKLG_WMS_BASE.p_GetBasePara(strEnterPriseNo,
                                  strWareHouseNo,
                                  v_strOwnerNo,
                                  'Instock_diffQty',
                                  'I',
                                  'INSTOCK',
                                  v_strInstockDiffQty,
                                  v_nInstockDiffQty,
                                  strResult);
      if substr(strResult, 1, 1) = 'N' then
        strResult := 'N|[E30025]';
        return;
      end if;
    end if;

    if v_strLoateType = '3' then
      --读取
      PKLG_WMS_BASE.p_GetBasePara(strEnterPriseNo,
                                  strWareHouseNo,
                                  v_strOwnerNo,
                                  'Instock_diffQty',
                                  'RI',
                                  'RI_INSTOCK',
                                  v_strInstockDiffQty,
                                  v_nInstockDiffQty,
                                  strResult);
      if substr(strResult, 1, 1) = 'N' then
        strResult := 'N|[E30025]';
        return;
      end if;
    end if;

    --读取系统参数判断是否可缺量回单

    if v_strInstockDiffQty = '0' then
      --0:不拆笔，不差异回单；1：有差异回单不拆笔，2：可拆笔
      if nArticleQty <> nRealQty then
        strResult := 'N|[不允许上架差异回单]';
        return;
      end if;
    end if;
    if v_strInstockDiffQty = '1' then
      if nArticleQty <> nRealQty then
        v_updateStatusFlag := '1';
      end if;
    end if;

    if strDestCellNo <> strRealCellNo then
      --当预计上架储位<>实际上架储位时做校验
      --校验目的储位
      Pkobj_stock.CheckRealInstockCell(strEnterpriseNo,
                                       strWareHouseNo,
                                       v_strOwnerNo,
                                       strArticleNo,
                                       dtProduceDate,
                                       dtExpireDate,
                                       strQuality,
                                       strLotNo,
                                       strRSV_BATCH1,
                                       strRSV_BATCH2,
                                       strRSV_BATCH3,
                                       strRSV_BATCH4,
                                       strRSV_BATCH5,
                                       strRSV_BATCH6,
                                       strRSV_BATCH7,
                                       strRSV_BATCH8,
                                       strRealCellNo,
                                       strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
    end if;

    nRemainQty := nRealQty;
    v_icount   := 0;

    for GetInstockItem in v_GetInstockItem loop
      v_icount := v_icount + 1;

      --获取部门编码
      begin
        select sc.dept_no
          into v_strDeptNo
          from stock_content sc
         where sc.enterprise_no = strEnterpriseNo
           and sc.warehouse_no = strWareHouseNo
           and sc.owner_no = GetInstockItem.owner_no
           and sc.cell_no = GetInstockItem.cell_no
           and sc.cell_id = GetInstockItem.cell_id;
      exception
        when no_data_found then
          strResult := 'N|[E21303]'; --获取库存信息失败
          return;
      end;

      if nRemainQty >= GetInstockItem.article_qty then
        nTempQty := GetInstockItem.article_qty;
      else
        nTempQty := nRealQty;
      end if;

      nRemainQty := nRemainQty - nTempQty;

      if v_updateStatusFlag = '0' then
        v_nArticleQty := nTempQty;
      end if;
      if v_updateStatusFlag = '1' then
        v_nArticleQty := GetInstockItem.article_qty;
      end if;

      --更新上架明细
      PKOBJ_IDATA.P_Update_Idata_Instock(strEnterpriseNo,
                                         strWareHouseNo,
                                         GetInstockItem.owner_no,
                                         strInstockNo,
                                         GetInstockItem.instock_id,
                                         strRealCellNo,
                                         nTempQty,
                                         strUserId,
                                         strPaperUserId,
                                         '13',
                                         v_updateStatusFlag,
                                         strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --更新来源储位库存
      PKOBJ_STOCK.p_UpdtContent_qtyByCellID(strEnterpriseNo,
                                            strWareHouseNo,
                                            GetInstockItem.cell_id,
                                            GetInstockItem.cell_no,
                                            GetInstockItem.dest_cell_no,
                                            nTempQty,
                                            v_nArticleQty,
                                            strUserId,
                                            strInstockNo,
                                            strTools,
                                            strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --更新目的储位库存
      pkobj_stock.p_UpdtInstContent_Qty(strEnterpriseNo,
                                        strWareHouseNo,
                                        GetInstockItem.dest_cell_id,
                                        GetInstockItem.dest_cell_no,
                                        GetInstockItem.cell_no,
                                        nTempQty,
                                        v_nArticleQty,
                                        strUserId,
                                        strInstockNo,
                                        strTools,
                                        v_nCellID,
                                        strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      if strDestCellNo <> strRealCellNo then
        --修改储位时，需将预计上架储位的库存移库到实际上架储位
        --更新来源储位库存
        pkobj_stock.p_UpdtContent_qtyByCellNo(strEnterpriseNo,
                                              strWareHouseNo,
                                              GetInstockItem.owner_no,
                                              GetInstockItem.article_no,
                                              GetInstockItem.article_id,
                                              strDestCellNo,
                                              strRealCellNo,
                                              GetInstockItem.packing_qty,
                                              nTempQty,
                                              GetInstockItem.Sub_Label_No,
                                              GetInstockItem.stock_type,
                                              GetInstockItem.stock_value,
                                              strUserId,
                                              strInstockNo,
                                              strTools,
                                              strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        --更新目的储位库存
        pkobj_stock.p_InstContent_qtyByCellNo(strEnterpriseNo,
                                              strWareHouseNo,
                                              GetInstockItem.owner_no,
                                              v_strDeptNo,
                                              GetInstockItem.article_no,
                                              GetInstockItem.article_id,
                                              strRealCellNo,
                                              strDestCellNo,
                                              GetInstockItem.packing_qty,
                                              nTempQty,
                                              GetInstockItem.Label_No,
                                              GetInstockItem.Sub_Label_No,
                                              GetInstockItem.stock_type,
                                              GetInstockItem.stock_value,
                                              strUserId,
                                              strInstockNo,
                                              strTools,
                                              '1',
                                              v_nCellID,
                                              strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;
      end if;

      --修改可移库标识
      pkobj_stock.p_UpdtContent_Mvflag(strEnterpriseNo,
                                       strWareHouseNo,
                                       strRealCellNo,
                                       v_nCellID,
                                       '1',
                                       strUserId,
                                       strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --检查上架区域是否是保留容器的区域
      begin
        select cd.o_type
          into strOtype
          from cdef_defarea cd, cdef_defcell t
         where cd.enterprise_no = t.enterprise_no
           and cd.warehouse_no = t.warehouse_no
           and cd.ware_no = t.ware_no
           and cd.area_no = t.area_no
           and cd.enterprise_no = strEnterpriseNo
           and cd.warehouse_no = strWareHouseNo
           and t.cell_no = strRealCellNo;
      exception
        when no_data_found then
          strResult := 'N|[E21304]'; --获取上架储区的信息失败
          return;
      end;

      --判断是否保留容器号
      if (strOtype <> 'P' or (GetInstockItem.business_type <> '3' and
         GetInstockItem.business_type <> '6')) and v_nCellID is not null then
        --3客户别，6B品\P保留标签
        pkobj_stock.p_UpdtContent_ContainerNo(strEnterpriseNo,
                                              strWareHouseNo,
                                              'N',
                                              'N',
                                              strRealCellNo,
                                              v_nCellID,
                                              strUserId,
                                              v_nOutCellId,
                                              strResult);
        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;
      end if;

      if v_nArticleQty <> nTempQty and v_strInstockDiffQty <> '2' then
        --差异上架并不拆笔
        --将库存移到虚拟储位

        begin
          select a.cell_no
            into v_strCellNo
            from cdef_defcell a, cdef_defarea b
           where a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and a.ware_no = b.ware_no
             and a.area_no = b.area_no
             and a.enterprise_no = strEnterpriseNo
             and a.warehouse_no = strWareHouseNo
             and b.area_usetype = 1
             and b.area_attribute = 3
             and b.attribute_type in (0, 1)
             and rownum < 2;
        exception
          when no_data_found then
            strResult := 'N|[E21306]'; --没有读取到差异数量计账储位
            return;
        end;

        pkobj_stock.p_UpdtContent_qtyByCellNo(strEnterpriseNo,
                                              strWareHouseNo,
                                              GetInstockItem.owner_no,
                                              GetInstockItem.article_no,
                                              GetInstockItem.article_id,
                                              GetInstockItem.cell_no,
                                              v_strCellNo,
                                              GetInstockItem.packing_qty,
                                              v_nArticleqty - nTempQty,
                                              GetInstockItem.Sub_Label_No,
                                              GetInstockItem.stock_type,
                                              GetInstockItem.stock_value,
                                              strUserId,
                                              strInstockNo,
                                              strTools,
                                              strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        --更新虚拟目的储位库存
        pkobj_stock.p_InstContent_qtyByCellNo(strEnterpriseNo,
                                              strWareHouseNo,
                                              GetInstockItem.owner_no,
                                              v_strDeptNo,
                                              GetInstockItem.article_no,
                                              GetInstockItem.article_id,
                                              v_strCellNo,
                                              GetInstockItem.Cell_No,
                                              GetInstockItem.packing_qty,
                                              v_nArticleqty - nTempQty,
                                              GetInstockItem.Label_No,
                                              GetInstockItem.Sub_Label_No,
                                              GetInstockItem.stock_type,
                                              GetInstockItem.stock_value,
                                              strUserId,
                                              strInstockNo,
                                              strTools,
                                              '1',
                                              v_nCellID,
                                              strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        --修改可移库标识
        pkobj_stock.p_UpdtContent_Mvflag(strEnterpriseNo,
                                         strWareHouseNo,
                                         v_strCellNo,
                                         v_nCellID,
                                         '1',
                                         strUserId,
                                         strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        pkobj_stock.p_UpdtContent_ContainerNo(strEnterpriseNo,
                                              strWareHouseNo,
                                              'N',
                                              'N',
                                              v_strCellNo,
                                              v_nCellID,
                                              strUserId,
                                              v_nOutCellId,
                                              strResult);
        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;
      end if;

      begin
        select label_no
          into v_strLabelNo
          from idata_instock_d
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and instock_no = strInstockNo
           and sub_Label_No = GetInstockItem.Sub_Label_No
           and status in ('10', '12')
           and rownum < 2;
      exception
        when no_data_found then
          --子标签追踪
          pkobj_label.p_Updt_InStock_Label(strEnterpriseNo,
                                           strWareHouseNo,
                                           strInstockNo,
                                           GetInstockItem.Sub_Label_No,
                                           strUserId,
                                           strResult);
          if substr(strResult, 1, 1) = 'N' then
            return;
          end if;
      end;

      --标签追踪
      begin
        select label_no
          into v_strLabelNo
          from idata_instock_d
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and instock_no = strInstockNo
           and label_no = GetInstockItem.label_no
           and status in ('10', '12')
           and rownum < 2;
      exception
        when no_data_found then
          --标签追踪
          pkobj_label.p_Updt_InStock_Label(strEnterpriseNo,
                                           strWareHouseNo,
                                           strInstockNo,
                                           GetInstockItem.label_no,
                                           strUserId,
                                           strResult);
          if substr(strResult, 1, 1) = 'N' then
            return;
          end if;
      end;

      PKOBJ_STOCK.P_InsertOwnerCell(strEnterpriseNo,
                                    strWareHouseNo,
                                    GetInstockItem.owner_no,
                                    strRealCellNo,
                                    strArticleNo,
                                    strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;

      if nRemainQty = 0 then
        exit;
      end if;

    end loop;

    if v_icount = 0 then
      strResult := 'N|[E21305]'; --没有读取到上架明细;
      return;
    end if;

    strResult := 'Y';

  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_Save_Idata_InStock;

  /**************************************************************************************************
  创建人：luozhiling
  创建日期:2014.12.24
  功能说明：整单上架回单
  ***************************************************************************************************/
  procedure P_saveInstockAll(strEnterpriseNo in idata_instock_m.enterprise_no%type,
                             strWarehouseNo  in idata_instock_m.warehouse_no%type,
                             strInstockNo    in idata_instock_m.instock_no%type,
                             strUserId       in idata_instock_m.rgst_name%type, --上架人
                             strPaperUserId  in idata_instock_m.rgst_name%type, --回单人
                             strTools        in stock_content_move.terminal_flag%type,
                             strResult       out varchar2) is
  begin
    strResult := 'N|[P_saveInstockAll]';
    for p in (select sai.produce_date,
                     sai.expire_date,
                     sai.lot_no,
                     sai.quality,
                     sai.rsv_batch1,
                     sai.rsv_batch2,
                     sai.rsv_batch3,
                     sai.rsv_batch4,
                     sai.rsv_batch5,
                     sai.rsv_batch6,
                     sai.rsv_batch7,
                     sai.rsv_batch8,
                     iid.dest_cell_no,
                     iid.label_no,
                     iid.article_no,
                     iid.packing_qty,
                     iid.article_qty
                from idata_instock_d iid, stock_article_info sai
               where iid.warehouse_no = strWarehouseNo
                 and iid.enterprise_no = strEnterpriseNo
                 and iid.instock_no = strInstockNo
                 and iid.status = '10'
                 and iid.article_no = sai.article_no
                 and iid.article_id = sai.article_id) loop
      --上架回单
      pklg_idata.p_Save_Idata_InStock(strEnterpriseNo,
                                      strWareHouseNo,
                                      strInstockNo,
                                      p.dest_cell_no,
                                      p.dest_cell_no,
                                      p.label_no,
                                      p.article_no,
                                      p.produce_date,
                                      p.expire_date,
                                      p.quality,
                                      p.lot_no,
                                      p.rsv_batch1,
                                      p.rsv_batch2,
                                      p.rsv_batch3,
                                      p.rsv_batch4,
                                      p.rsv_batch5,
                                      p.rsv_batch6,
                                      p.rsv_batch7,
                                      p.rsv_batch8,
                                      p.packing_qty,
                                      p.article_qty,
                                      p.article_qty,
                                      strUserId,
                                      strPaperUserId,
                                      '1',
                                      '0',
                                      strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
    end loop;
    --整单做确认
    p_RfComfire_Idata_InStock(strEnterpriseNo,
                              strWareHouseNo,
                              strInstockNo,
                              strUserId,
                              strPaperUserId,
                              strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      strResult := 'Y|[成功]';
  end P_saveInstockAll;
  /*************************************************************************************************
       修改人：lich
       日期：2013-05-06
       功能：上架回单确认

  *************************************************************************************************/
  procedure p_Comfire_Idata_InStock(strEnterpriseNo in idata_instock_m.enterprise_no%type,
                                    strWareHouseNo  in idata_instock_m.warehouse_no%type,
                                    strInstockNo    in idata_instock_m.instock_no%type,
                                    strUserId       in idata_instock_m.rgst_name%type, --上架人
                                    strPaperUserId  in idata_instock_m.rgst_name%type, --回单人
                                    strTools        in stock_content_move.terminal_flag%type,
                                    strResult       out varchar2) is
    cursor v_GetInstockItem is
      select *
        from (select b.owner_no,
                     b.article_no,
                     b.article_id,
                     b.packing_qty,
                     b.cell_no,
                     b.cell_id,
                     b.dest_cell_no,
                     b.dest_cell_id,
                     b.label_no,
                     b.sub_label_no,
                     b.stock_type,
                     b.stock_value,
                     b.source_no,
                     a.import_type,
                     sum(b.article_qty) article_qty,
                     sum(b.real_qty) real_qty
                from idata_instock_m a, idata_instock_d b
               where a.enterprise_no = b.enterprise_no
                 and a.warehouse_no = b.warehouse_no
                 and a.instock_no = b.instock_no
                 and b.status = '10'
                 and a.enterprise_no = strEnterpriseNo
                 and a.warehouse_no = strWareHouseNo
                 and b.instock_no = strInstockNo
               group by b.owner_no,
                        b.article_no,
                        b.article_id,
                        b.packing_qty,
                        b.cell_no,
                        b.cell_id,
                        b.dest_cell_no,
                        b.dest_cell_id,
                        b.label_no,
                        b.sub_label_no,
                        b.stock_type,
                        b.stock_value,
                        a.import_type,
                        b.source_no
               order by b.dest_cell_no, b.article_no)
       where article_qty - real_qty > 0;

    v_strDeptNo   stock_content.dept_no%type;
    nTempQty      stock_content.qty%type; --差异数量
    v_icount      integer;
    v_Count       integer;
    v_strCellNo   stock_content.cell_no%type; --差异数量记账储位
    v_nCellID     stock_content.cell_id%type;
    v_strLabelNo  stock_label_m.label_no%type;
    v_strLocateNo idata_instock_m.locate_no%type;
    v_OutFlag     wms_idatatype.unconfirm_instock_flag%type;
  begin
    strResult := 'N|[p_Comfire_Idata_InStock]';

    --获取定位波次号
    select locate_no
      into v_strLocateNo
      from idata_instock_m
     where enterprise_no = strEnterpriseNo
       and warehouse_no = strWareHouseNo
       and instock_no = strInstockNo;

    v_icount := 0;

    for GetInstockItem in v_GetInstockItem loop
      v_icount := v_icount + 1;

      if v_icount = 1 then
        --上架时判断验收确认状态
        PKLG_WMS_PUBLIC.P_GetIdataOrder(strEnterpriseNo,
                                        strWareHouseNo,
                                        GetInstockItem.Owner_No,
                                        GetInstockItem.IMPORT_TYPE,
                                        'UNCONFIRM_INSTOCK_FLAG',
                                        v_OutFlag,
                                        strResult);
        if substr(strResult, 1, 1) = 'N' then
          return;
        end if;

        if v_OutFlag = '0' then
          --未确认不允许上架

          select count(1)
            into v_Count
            from idata_check_m icm
           where icm.warehouse_no = strWareHouseNo
             and icm.enterprise_no = strEnterpriseNo
             and icm.s_check_no = GetInstockItem.Source_No
             and icm.status < '13';

          if v_Count > 0 then
            strResult := 'N|[' || GetInstockItem.Source_No ||
                         ']未验收确认不允许上架！';
            return;
          end if;
        end if;

      end if;
      --获取部门编码
      begin
        select sc.dept_no
          into v_strDeptNo
          from stock_content sc
         where sc.enterprise_no = strEnterpriseNo
           and sc.warehouse_no = strWareHouseNo
           and sc.owner_no = GetInstockItem.owner_no
           and sc.cell_no = GetInstockItem.cell_no
           and sc.cell_id = GetInstockItem.cell_id;
      exception
        when no_data_found then
          strResult := 'N|[E21303]'; --获取库存信息失败
          return;
      end;

      begin
        select a.cell_no
          into v_strCellNo
          from cdef_defcell a, cdef_defarea b
         where a.enterprise_no = b.enterprise_no
           and a.warehouse_no = b.warehouse_no
           and a.ware_no = b.ware_no
           and a.area_no = b.area_no
           and a.enterprise_no = strEnterpriseNo
           and a.warehouse_no = strWareHouseNo
           and b.area_usetype = 1
           and b.area_attribute = 3
           and b.attribute_type in (0, 1)
           and rownum < 2;
      exception
        when no_data_found then
          strResult := 'N|[E21306]'; --没有读取到差异数量计账储位
          return;
      end;

      nTempQty := GetInstockItem.article_qty - GetInstockItem.Real_Qty;

      --更新来源储位库存
      PKOBJ_STOCK.p_UpdtContent_qtyByCellID(strEnterpriseNo,
                                            strWareHouseNo,
                                            GetInstockItem.cell_id,
                                            GetInstockItem.cell_no,
                                            GetInstockItem.dest_cell_no,
                                            nTempQty,
                                            GetInstockItem.article_qty,
                                            strUserId,
                                            strInstockNo,
                                            strTools,
                                            strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --更新目的储位库存
      pkobj_stock.p_InstContent_qtyByCellID(strEnterpriseNo,
                                            strWareHouseNo,
                                            GetInstockItem.dest_cell_id,
                                            GetInstockItem.dest_cell_no,
                                            GetInstockItem.cell_no,
                                            nTempQty,
                                            GetInstockItem.article_qty,
                                            strUserId,
                                            strInstockNo,
                                            strTools,
                                            strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --修改储位时，需将预计上架储位的库存移库到实际上架储位
      --更新来源储位库存
      pkobj_stock.p_UpdtContent_qtyByCellNo(strEnterpriseNo,
                                            strWareHouseNo,
                                            GetInstockItem.owner_no,
                                            GetInstockItem.article_no,
                                            GetInstockItem.article_id,
                                            GetInstockItem.Dest_Cell_No,
                                            v_strCellNo,
                                            GetInstockItem.packing_qty,
                                            nTempQty,
                                            GetInstockItem.Sub_Label_No,
                                            GetInstockItem.stock_type,
                                            GetInstockItem.stock_value,
                                            strUserId,
                                            strInstockNo,
                                            strTools,
                                            strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --更新虚拟目的储位库存
      pkobj_stock.p_InstContent_qtyByCellNo(strEnterpriseNo,
                                            strWareHouseNo,
                                            GetInstockItem.owner_no,
                                            v_strDeptNo,
                                            GetInstockItem.article_no,
                                            GetInstockItem.article_id,
                                            v_strCellNo,
                                            GetInstockItem.Dest_Cell_No,
                                            GetInstockItem.packing_qty,
                                            nTempQty,
                                            GetInstockItem.Label_No,
                                            GetInstockItem.Sub_Label_No,
                                            GetInstockItem.stock_type,
                                            GetInstockItem.stock_value,
                                            strUserId,
                                            strInstockNo,
                                            strTools,
                                            '1',
                                            v_nCellID,
                                            strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      ---------更新上架单头档和明细------------
      update idata_instock_d iid
         set iid.status       = 13,
             iid.real_cell_no = v_strCellNo,
             iid.real_qty     = iid.article_qty,
             iid.updt_name    = strUserId,
             iid.updt_date    = sysdate
       where iid.enterprise_no = strEnterpriseNo
         and iid.warehouse_no = strWareHouseNo
         and iid.owner_no = GetInstockItem.owner_no
         and iid.instock_no = strInstockno
         and iid.status = 10
         and iid.article_no = GetInstockItem.Article_No
         and iid.article_id = GetInstockItem.Article_Id
         and iid.packing_qty = GetInstockItem.Packing_Qty
         and iid.cell_no = GetInstockItem.Cell_No
         and iid.cell_id = GetInstockItem.Cell_Id
         and iid.dest_cell_no = GetInstockItem.Dest_Cell_No
         and iid.label_no = GetInstockItem.Label_No
         and iid.sub_label_no = GetInstockItem.Sub_Label_No
         and iid.stock_type = GetInstockItem.Stock_Type
         and iid.stock_value = GetInstockItem.Stock_Value;

      if sql%rowcount <= 0 then
        strResult := 'N|[E430101]'; --更新上架明细失败
        return;
      end if;

      begin
        select label_no
          into v_strLabelNo
          from idata_instock_d
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and instock_no = strInstockNo
           and sub_Label_No = GetInstockItem.Sub_Label_No
           and status in ('10', '12')
           and rownum < 2;
      exception
        when no_data_found then
          --子标签追踪
          pkobj_label.p_Updt_InStock_Label(strEnterpriseNo,
                                           strWareHouseNo,
                                           strInstockNo,
                                           GetInstockItem.Sub_Label_No,
                                           strUserId,
                                           strResult);
          if substr(strResult, 1, 1) = 'N' then
            return;
          end if;
      end;

      --标签追踪
      begin
        select label_no
          into v_strLabelNo
          from idata_instock_d
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and instock_no = strInstockNo
           and label_no = GetInstockItem.label_no
           and status in ('10', '12')
           and rownum < 2;
      exception
        when no_data_found then
          --标签追踪
          pkobj_label.p_Updt_InStock_Label(strEnterpriseNo,
                                           strWareHouseNo,
                                           strInstockNo,
                                           GetInstockItem.label_no,
                                           strUserId,
                                           strResult);
          if substr(strResult, 1, 1) = 'N' then
            return;
          end if;
      end;
    end loop;

    update idata_instock_m iim
       set iim.status         = '13',
           iim.updt_name      = strPaperUserId,
           iim.updt_date      = sysdate,
           iim.instock_worker = strUserId,
           iim.instock_date   = sysdate
     where iim.enterprise_no = strEnterpriseNo
       and iim.wareHouse_no = strWareHouseNo
       and iim.instock_no = strInstockNo;

    if sql%rowcount <= 0 then
      strResult := 'N|[E430102]'; --更新上架单头档失败
      return;
    end if;

    --上架回单已完成，需要转历史
    PKOBJ_IDATA.P_Idate_InstockToHty(strEnterpriseNo,
                                     strWareHouseNo,
                                     v_strLocateNo,
                                     strInstockNo,
                                     strResult);

    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    strResult := 'Y';

  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_Comfire_Idata_InStock;
  /*************************************************************************************************
       修改人：lich
       日期：2013-06-23
       功能：Rf上架回单确认

  *************************************************************************************************/
  procedure p_RfComfire_Idata_InStock(strEnterpriseNo in idata_instock_m.enterprise_no%type,
                                      strWareHouseNo  in idata_instock_m.warehouse_no%type,
                                      strInstockNo    in idata_instock_m.instock_no%type,
                                      strUserId       in idata_instock_m.rgst_name%type, --上架人
                                      strPaperUserId  in idata_instock_m.rgst_name%type, --回单人
                                      strResult       out varchar2) is

    v_icount      integer;
    v_strLocateNo idata_instock_m.locate_no%type;

  begin
    strResult := 'N|[p_RfComfire_Idata_InStock]';

    select locate_no
      into v_strLocateNo
      from idata_instock_m
     where enterprise_no = strEnterpriseNo
       and warehouse_no = strWareHouseNo
       and instock_no = strInstockNo;

    v_icount := 0;

    select count(*)
      into v_icount
      from idata_instock_d iid
     where iid.enterprise_no = strEnterpriseNo
       and iid.warehouse_no = strWareHouseNo
       and iid.instock_no = strInstockNo
       and iid.status = 10;

    if v_icount = 0 then
      update idata_instock_m iim
         set iim.status         = '13',
             iim.updt_name      = strPaperUserId,
             iim.updt_date      = sysdate,
             iim.instock_worker = strUserId,
             iim.instock_date   = sysdate
       where iim.enterprise_no = strEnterpriseNo
         and iim.wareHouse_no = strWareHouseNo
         and iim.instock_no = strInstockNo;

      if sql%rowcount <= 0 then
        strResult := 'N|[E430102]'; --更新上架单头档失败
        return;
      end if;

      --上架回单已完成，需要转历史
      PKOBJ_IDATA.P_Idate_InstockToHty(strEnterpriseNo,
                                       strWareHouseNo,
                                       v_strLocateNo,
                                       strInstockNo,
                                       strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
    end if;

    strResult := 'Y';

  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_RfComfire_Idata_InStock;

  /**********************************************************************************************************
     lich
     2014.06.05
     功能：校验能否验收
  ***********************************************************************************************************/
  procedure P_CheckExists(strEnterpriseNo in idata_check_m.enterprise_no%type, --企业
                          strWareHouseNo  in idata_check_m.warehouse_no%type, --仓库编码
                          strOwnerNo      in idata_import_mm.Owner_No%type, --进货汇总单号
                          strSimportNo    in idata_import_mm.s_import_no%type, --进货汇总单号
                          strArticleNo    in idata_check_d.article_no%type, --商品编码
                          strPackingQty   in idata_check_d.packing_qty%type, --商品条码
                          dtProduceDate   in idata_check_d.produce_date%type, --生产日期
                          dtExpireDate    in idata_check_d.expire_date%type, --到期日期
                          nCheckQty       in idata_check_d.check_qty%type, --验收数量
                          strOverFlag     in varchar2, --超品标识，0-正常；1-超品
                          strPromptType   out varchar2, --提示类型1：报警 2冻结 3超量
                          strPromptFlag   out varchar2, --处理方式1：提示类型（0:成功 ;1：拦截，不允许验入；2：提醒，但可强制验入；3：授权 ）
                          strResult       OUT varchar2) is

    --v_iCount          integer;
    v_nDatediff       integer;
    v_nExpiryDays     bdef_defarticle.expiry_days%type;
    v_nFreezeRate     bdef_defarticle.freezerate%type;
    v_nAlarmRate      bdef_defarticle.alarmrate%type;
    v_nCheckQtyRate   bdef_defarticle.check_qty_rate%type;
    v_nFreezeRateDay  bdef_defarticle.expiry_days%type; --Modify BY QZH AT 2016-6-23
    v_nAlarmRateDay   bdef_defarticle.expiry_days%type; --Modify BY QZH AT 2016-6-23
    v_nLotType        bdef_defarticle.lot_type%type;
    v_nFreezeRateType wms_defbase.ndefine%type;
    v_nAlarmRateType  wms_defbase.ndefine%type;

    v_sFreezeRateType wms_defbase.sdefine%type;
    v_sAlarmRateType  wms_defbase.sdefine%type;

    --超品参数
    --v_sCheckOverFlag wms_defbase.sdefine%type := '0';
    --v_nCheckOverFlag wms_defbase.ndefine%type;
    v_Import_Type  idata_import_m.import_type%type;
    v_Owner_No     bdef_defowner.owner_no%type;
    v_nPoQty       idata_import_sd.po_qty%type;
    v_nmaxQty      idata_import_sd.po_qty%type;
    v_ncheckQty    idata_import_sd.po_qty%type;
    v_nTmpCheckQty idata_check_pal_tmp.check_qty%type;
    v_overQtyFlag  wms_idatatype.modify_flag%type; --add by huangcx 20160718
  begin
    strResult := 'N|[P_CheckExists]';

    --计算输入的生产日期与今天日期的相隔天数
    select ceil(sysdate - dtProduceDate) into v_nDatediff from dual;

    begin
      select bda.freezerate,
             bda.expiry_days * (100 - bda.freezerate) * 0.01,
             bda.alarmrate,
             bda.expiry_days * (100 - bda.alarmrate) * 0.01,
             bda.check_excess,
             bda.lot_type,
             bda.expiry_days
        into v_nFreezeRate,
             v_nFreezeRateDay,
             v_nAlarmRate,
             v_nAlarmRateDay,
             v_nCheckQtyRate,
             v_nLotType,
             v_nExpiryDays
        from bdef_defarticle bda
       where bda.enterprise_no = strEnterpriseNo
         and bda.article_no = strArticleNo;
    exception
      when no_data_found then
        strResult := 'N|[E20933]'; --商品不存在
        return;
    end;

    IF (v_nExpiryDays > -1) THEN
      --1.只管批次 2.只管生产日期 3.批次+生产日期 4=都不管
      if v_nLotType = '2' or v_nLotType = '3' then
        --取冻结系统参数
        PKLG_WMS_BASE.p_GetBasePara(strEnterpriseNo,
                                    strWareHouseNo,
                                    strOwnerNo,
                                    'IC_FreezeRate',
                                    'I',
                                    'IC',
                                    v_sFreezeRateType,
                                    v_nFreezeRateType,
                                    strResult);
        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        if v_nFreezeRate != 0 and v_nDatediff > v_nFreezeRateDay then
          strResult     := 'Y|[E20934]'; --商品处于冻结状态
          strPromptType := '2';
          strPromptFlag := v_sFreezeRateType;
          return;
        end if;

        --取报警系统参数
        PKLG_WMS_BASE.p_GetBasePara(strEnterpriseNo,
                                    strWareHouseNo,
                                    strOwnerNo,
                                    'IC_AlarmRate',
                                    'I',
                                    'IC',
                                    v_sAlarmRateType,
                                    v_nAlarmRateType,
                                    strResult);
        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        if v_nAlarmRate != 0 and v_nDatediff > v_nAlarmRateDay then
          strResult     := 'Y|[E20935]'; --商品处于报警状态
          strPromptType := '1';
          strPromptFlag := v_sAlarmRateType;
          return;
        end if;
      end if;
    END IF;

    begin
      --获取货主信息
      select distinct owner_no, import_type
        into v_Owner_No, v_Import_Type
        from idata_import_sm
       where enterprise_no = strEnterpriseNo
         and warehouse_no = strWareHouseNo
         and s_import_no = strSimportNo;
    exception
      when no_data_found then
        strResult := 'N|[' || strSimportNo || '[不存在！]';
        return;
      when others then
        strResult := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
        return;
    end;

    --是否允许超量
    PKLG_WMS_PUBLIC.P_GetIdataOrder(strEnterpriseNo,
                                    strWareHouseNo,
                                    v_Owner_No,
                                    v_Import_Type,
                                    'OVER_QTY_FLAG',
                                    v_overQtyFlag,
                                    strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    --update by huangcx 20160718
    if strOverFlag = '0' then
      --非超品验收
      begin
        select iisd.po_qty * (1 + bda.check_excess / 100) checkExcess,
               iisd.po_qty
          into v_nmaxQty, v_nPoQty
          from idata_import_sd iisd, bdef_defarticle bda
         where iisd.article_no = bda.article_no
           and iisd.enterprise_no = bda.enterprise_no
           and iisd.enterprise_no = strEnterpriseNo
           and iisd.warehouse_no = strWareHouseNo
           and iisd.s_import_no = strSimportNo
           and iisd.article_no = strArticleNo
           and iisd.packing_qty = strPackingQty;
      exception
        when no_data_found then
          --允许超品
          if v_overQtyFlag = '2' then
            strPromptType := '3';
            strPromptFlag := '2';
            strResult     := 'Y';
          else
            strResult := 'N|[E20933]'; --商品不存在
          end if;
          return;
      end;

      select nvl(sum(icd.check_qty), 0) check_qty
        into v_nCheckQty
        from idata_check_d icd, idata_check_m icm
       where icd.check_no = icm.check_no
         and icd.enterprise_no = icm.enterprise_no
         and icd.warehouse_no = icm.warehouse_no
         and icd.owner_no = icm.owner_no
         and icm.enterprise_no = strEnterpriseNo
         and icm.warehouse_no = strWareHouseNo
         and icm.s_import_no = strSimportNo
         and icd.article_no = strArticleNo
         and icd.packing_qty = strPackingQty;

      select nvl(sum(t.check_qty), 0)
        into v_nTmpCheckQty
        from idata_check_pal_tmp t
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.s_import_no = strSimportNo
         and t.article_no = strArticleNo
         and t.packing_qty = strPackingQty;

      --不允许超量
      if v_overQtyFlag = '0' then
        if v_nmaxQty - v_ncheckQty - v_nTmpCheckQty - nCheckQty < 0 then
          strResult := 'N|[该单据类型不允许超量]';
          return;
        end if;
      else
        if v_overQtyFlag = '1' then
          --允许超量
          if v_nCheckQtyRate = 0 then
            if v_nmaxQty - v_ncheckQty - v_nTmpCheckQty - nCheckQty < 0 then
              strResult     := 'N|[E20936]'; --不能超量验收
              strPromptType := '3';
              strPromptFlag := '1';
              return;
            end if;
          end if;

          if v_nCheckQtyRate > 0 then
            --如果超量，不能超出超量比率
            if v_nmaxQty - v_ncheckQty - v_nTmpCheckQty - nCheckQty < 0 then
              strResult     := 'N|验收数量已超出商品超量比率！'; --不能超量验收
              strPromptType := '3';
              strPromptFlag := '1';
              return;
            end if;
            --返回界面提问是否允许超量
            if v_nPoQty - v_ncheckQty - v_nTmpCheckQty - nCheckQty < 0 then
              strPromptType := '3';
              strPromptFlag := '2';
              strResult     := 'Y';
              return;
            end if;
          end if;
        end if;
      end if;
      --end update
    else
      if v_overQtyFlag <> '2' then
        strResult := 'N|[该单据[' || v_Import_Type || ']类型不允许超品项验收]';
        return;
      end if;
    end if;
    strPromptFlag := '0';
    strResult     := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_CheckExists;
  /**********************************************************************************************************
     zhouhuan
     2014.4.22
     功能：上架发单
  ***********************************************************************************************************/
  procedure P_InsertInstock(strEnterpriseNo in idata_instock_direct.enterprise_no%type,
                            strWareHouseNo  in idata_instock_direct.warehouse_no%type, --仓别
                            strWorkerNo     in idata_instock_direct.rgst_name%type, --操作人
                            strLocateNo     in idata_instock_direct.locate_no%type, --定位单号
                            strDockNo       in pntset_printer_workstation.workstation_no%type, --工作站号
                            strPrintType    in job_printtask_m.task_type%type, --0:不打印；1:打印报表；2：打印标签
                            strInstockNo    out idata_instock_d.instock_no%type, --上架单号
                            strResult       out varchar2) is
    v_strPrtTask job_printtask_m.task_no%type;
  begin

    strResult := 'N|[E00025]P_InsertInstock';

    --取验收单号
    begin

      --锁定上架指示表
      update idata_instock_direct iid
         set iid.status = iid.status
       where iid.enterprise_no = strEnterpriseNo
         and iid.warehouse_no = strWareHouseNo
         and iid.locate_no = strLocateNo;

      strInstockNo := '';
      PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                 strWareHouseNo,
                                 CONST_DOCUMENTTYPE.IDATAIP,
                                 strInstockNo,
                                 strResult);
      if (strInstockNo is null or substr(strResult, 1, 1) = 'N') then
        strResult := 'N|[E21319]'; --取上架单号错误!
        return;
      end if;
    end;

    if strPrintType = 1 then
      --写报表打印任务
      PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterpriseNo,
                                          strWareHouseNo,
                                          strInstockNo,
                                          0,
                                          CONST_REPORTID.L_INSTOCK,
                                          strDockNo,
                                          0,
                                          strWorkerNo,
                                          v_strPrtTask,
                                          strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;
    end if;

    if strPrintType = 2 then
      --写标签打印任务--共速达不用，暂时预留
      PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterpriseNo,
                                          strWareHouseNo,
                                          strInstockNo,
                                          0,
                                          CONST_REPORTID.B_I_INSTOCKP,
                                          strDockNo,
                                          0,
                                          strWorkerNo,
                                          v_strPrtTask,
                                          strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;
    end if;

    --写上架单头档
    PKOBJ_IDATA.p_InsertInstockM(strEnterpriseNo,
                                 strWareHouseNo,
                                 strWorkerNo,
                                 strLocateNo,
                                 strInstockNo,
                                 strResult);
    if substr(strResult, 1, 1) <> 'Y' then
      return;
    end if;

    --写上架单明细档
    PKOBJ_IDATA.p_InsertInstockD(strEnterpriseNo,
                                 strWareHouseNo,
                                 strWorkerNo,
                                 strLocateNo,
                                 strInstockNo,
                                 strResult);
    if substr(strResult, 1, 1) <> 'Y' then
      return;
    end if;

    --更新上架指示状态
    update idata_instock_direct iid
       set iid.status = '13'
     where iid.enterprise_no = strEnterpriseNo
       and iid.warehouse_no = strWareHouseNo
       and iid.locate_no = strLocateNo
       and iid.status = '10';

    if sql%rowcount <= 0 then
      strResult := 'N|[E21320]'; --更新上架指示失败
      return;
    end if;

    --标签追踪
    for p in (select label_no /*, container_no*/
                from idata_instock_direct
               where enterprise_no = strEnterpriseNo
                 and warehouse_no = strWareHouseNo
                 and locate_no = strLocateNo
                 and status = '13') loop
      --更新标签头档状态
      update stock_label_m slm
         set slm.status    = CLabelStatus.GETTask_TOCELL,
             slm.updt_name = strWorkerNo,
             slm.updt_date = sysdate
       where slm.status = CLabelStatus.LOCATE_TOCELL
         and slm.label_no = p.label_no
         and slm.enterprise_no = strEnterpriseNo
         and slm.warehouse_no = strWareHouseNo
         and not exists (select 'x'
                from idata_instock_direct
               where enterprise_no = strEnterpriseNo
                 and warehouse_no = strWareHouseNo
                 and locate_no = strLocateNo
                 and status = '10'
                 and label_no = p.label_no
              /*and container_no = p.container_no*/
              );
      if sql%rowcount > 0 then
        --标签跟踪
        pkobj_label.proc_InsertLabel_Log(strEnterpriseNo,
                                         strWareHouseNo,
                                         p.label_no,
                                         strWorkerNo,
                                         0,
                                         CLabelStatus.GETTask_TOCELL,
                                         strResult);
        if substr(strResult, 1, 1) = 'N' then
          return;
        end if;
      end if;
    end loop;
    strResult := 'Y|';

    /*     --上架指示转历史
    PKOBJ_IDATA.p_InstockDirectToHty(strWareHouseNo,strLocateNo,strResult);

    --定位指示转历史
    PKOBJ_IDATA.p_LocateDirectToHty(strWareHouseNo,strLocateNo,strResult);*/

  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_InsertInstock;

  /*****************************************************************************************************
  创建人：luozhiling
  创建时间：2014.10.25.
  功能说明：对上架标签做标签销毁：
  1、未确认标签：修改验收数量，对上架的业务单据做取消，扣减库存
  2、已确认标签：对上架单做回单，并将库存移至销毁区。
  *****************************************************************************************************/
  procedure P_instock_Label_Cancel(strEnterpriseNo in stock_label_m.enterprise_no%type,
                                   strWareHouseNo  in stock_label_m.warehouse_no%type,
                                   strLabelNo      in stock_label_m.label_no%type,
                                   strWorkerNo     in stock_label_m.rgst_name%type,
                                   strResult       out varchar2) is
    Cursor v_GetCheckInf is
      select icm.check_no, icm.status check_status, iid.*
        from idata_instock_d iid, stock_article_info sai, idata_check_m icm
       where iid.warehouse_no = icm.warehouse_no
         and iid.article_no = sai.article_no
         and iid.article_id = sai.article_id
         and sai.import_batch_no = icm.check_no
         and iid.warehouse_no = strWareHouseNo
         and iid.label_no = strLabelNo
       order by icm.check_no, icm.status;
    v_nCellID         stock_content.cell_id%type;
    v_strCancelCell   cdef_defcell.cell_no%type;
    v_strConatainerNo stock_label_m.container_no%type;
    strPaperNo        idata_check_m.check_no%type;
    v_strLocateNo     idata_instock_m.locate_no%type;
    v_strInstockNo    idata_instock_m.instock_no%type;
    v_strChekNo       idata_check_m.check_no%type;
  begin
    strResult := 'N|[P_instock_Label_Cancel]';
    --读取标签销毁储区
    begin
      select cell_no
        into v_strCancelCell
        from cdef_defarea cd, cdef_defcell t
       where cd.warehouse_no = t.warehouse_no
         and cd.area_no = t.area_no
         and cd.ware_no = t.ware_no
         and cd.area_usetype = '1'
         and cd.area_attribute = '3' -- and cd.attribute_type='0'
         and rownum = 1;
    exception
      when no_data_found then
        strResult := 'N|[E21306]'; --没有读取到差异数量计账储位
        return;
    end;

    --获取标签内部容器号
    begin
      select container_no
        into v_strConatainerNo
        from stock_label_m
       where warehouse_no = strWareHouseNo
         and label_no = strLabelNo;
    exception
      when no_data_found then
        strResult := 'N|[E22513]';
        return;
    end;

    --锁定上架标签
    update idata_instock_d
       set status = status
     where warehouse_no = strWareHouseNo
       and label_no = strLabelNo;

    --先做上架回单
    for instock_Cancel in (select iid.*
                             from idata_instock_d    iid,
                                  stock_article_info sai
                            where iid.article_no = sai.article_no
                              and iid.article_id = sai.article_id
                              and warehouse_no = strWareHouseNo
                              and label_no = strLabelNo
                              and iid.status = '10') loop

      pkobj_idata.P_Update_Idata_Instock(strEnterpriseNo,
                                         strWareHouseNo,
                                         instock_cancel.owner_no,
                                         instock_cancel.instock_no,
                                         instock_cancel.instock_id,
                                         instock_cancel.dest_cell_no,
                                         0, --instock_cancel.article_qty,
                                         strWorkerNo,
                                         strWorkerNo,
                                         '13',
                                         '0',
                                         strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --更新来源储位库存
      PKOBJ_STOCK.p_UpdtContent_qtyByCellID(strEnterpriseNo,
                                            strWareHouseNo,
                                            instock_Cancel.cell_id,
                                            instock_Cancel.cell_no,
                                            instock_Cancel.dest_cell_no,
                                            0,
                                            instock_Cancel.article_qty,
                                            strWorkerNo,
                                            instock_Cancel.instock_no,
                                            '1',
                                            strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --更新目的储位库存
      pkobj_stock.p_UpdtInstContent_Qty(strEnterpriseNo,
                                        strWareHouseNo,
                                        instock_Cancel.dest_cell_id,
                                        instock_Cancel.dest_cell_no,
                                        instock_Cancel.cell_no,
                                        0,
                                        instock_Cancel.article_qty,
                                        strWorkerNo,
                                        instock_Cancel.instock_no,
                                        '1',
                                        v_nCellID,
                                        strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --修改可移库标识
      pkobj_stock.p_UpdtContent_Mvflag(strEnterpriseNo,
                                       strWareHouseNo,
                                       instock_Cancel.cell_no,
                                       instock_Cancel.cell_id,
                                       '1',
                                       strWorkerNo,
                                       strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
    end loop;

    --检查商品对应的验收单是否做确认

    --取标签销毁单号
    begin
      PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                 strWareHouseNo,
                                 CONST_DOCUMENTTYPE.LABELXH,
                                 strPaperNo,
                                 strResult);
      if (strPaperNo is null or substr(strResult, 1, 1) = 'N') then
        strResult := 'N|[E20909]'; --取汇总验收单号错误!
        return;
      end if;
    end;

    for GetCheckInf in v_GetCheckInf loop
      v_strChekNo := GetCheckInf.Check_No;
      if GetCheckInf.check_status < '13' then
        --未验收确认，直接删除库存，并将取消验收数据
        pkobj_stock.p_UpdtContent_qtyByCellNo(strEnterpriseNo,
                                              strWareHouseNo,
                                              GetCheckInf.owner_no,
                                              GetCheckInf.article_no,
                                              GetCheckInf.article_id,
                                              GetCheckInf.cell_no,
                                              GetCheckInf.cell_no,
                                              GetCheckInf.packing_qty,
                                              GetCheckInf.article_qty,
                                              strLabelNo,
                                              GetCheckInf.stock_type,
                                              GetCheckInf.stock_value,
                                              strWorkerNo,
                                              strPaperNo,
                                              '1',
                                              strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        pkobj_idata.P_Label_Cancel_IScheck(strWarehouseNo,
                                           GetCheckInf.owner_no,
                                           GetCheckInf.source_no,
                                           strLabelNo,
                                           'N',
                                           'N',
                                           GetCheckInf.article_no,
                                           GetCheckInf.article_id,
                                           GetCheckInf.packing_qty,
                                           GetCheckInf.article_qty,
                                           strWorkerNo,
                                           strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;
      else

        --将目的储位库存转移到销毁区:扣减来源储位库存
        pkobj_stock.p_UpdtContent_qtyByCellNo(strEnterpriseNo,
                                              strWareHouseNo,
                                              GetCheckInf.owner_no,
                                              GetCheckInf.article_no,
                                              GetCheckInf.article_id,
                                              GetCheckInf.cell_no,
                                              v_strCancelCell,
                                              GetCheckInf.packing_qty,
                                              GetCheckInf.article_qty,
                                              strlabelNo,
                                              GetCheckInf.stock_type,
                                              GetCheckInf.stock_value,
                                              strWorkerNo,
                                              strPaperNo,
                                              '1',
                                              strResult);
        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        --增加目的储位库存
        pkobj_stock.p_InstContent_fcqtyByCellNo(strEnterpriseNo,
                                                strWareHouseNo,
                                                GetCheckInf.owner_no,
                                                'N',
                                                GetCheckInf.article_no,
                                                GetCheckInf.article_id,
                                                v_strCancelCell,
                                                GetCheckInf.cell_no,
                                                GetCheckInf.packing_qty,
                                                GetCheckInf.article_qty,
                                                strlabelNo,
                                                GetCheckInf.sub_label_no,
                                                GetCheckInf.stock_type,
                                                GetCheckInf.stock_value,
                                                strWorkerNo,
                                                strPaperNo,
                                                '1',
                                                '1',
                                                v_nCellID,
                                                strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        pkobj_stock.p_UpdtContent_ContainerNo(strEnterpriseNo,
                                              strWareHouseNo,
                                              'N',
                                              'N',
                                              v_strCancelCell,
                                              v_nCellID,
                                              strWorkerNo,
                                              v_nCellID,
                                              strResult);
        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

      end if;
    end loop;

    --获取定位波次号
    select distinct locate_no, iim.instock_no
      into v_strLocateNo, v_strInstockNo
      from idata_instock_m iim, idata_instock_d iid
     where iim.enterprise_no = iid.enterprise_no
       and iim.warehouse_no = iid.warehouse_no
       and iim.instock_no = iid.instock_no
       and iim.enterprise_no = strEnterpriseNo
       and iim.warehouse_no = strWareHouseNo
       and iid.label_no = strLabelNo
       and rownum = 1;

    --更新板明细状态
    update idata_check_pal t
       set t.status    = '16',
           t.updt_name = strWorkerNo,
           t.updt_date = sysdate
     where t.warehouse_no = strWareHouseNo
       and t.enterprise_no = strEnterpriseNo
       and t.label_no = strLabelNo
       and t.container_no = v_strConatainerNo
       and t.check_no = v_strChekNo;

    --更新上架单状态
    update idata_instock_d t
       set t.status = '16'
     where t.warehouse_no = strWareHouseNo
       and t.enterprise_no = strEnterpriseNo
       and t.label_no = strLabelNo;

    --更新上架指示状态
    update idata_instock_direct iid
       set iid.status = '16'
     where iid.warehouse_no = strWareHouseNo
       and iid.enterprise_no = strEnterpriseNo
       and iid.label_no = strLabelNo;

    update idata_locate_direct iid
       set iid.status = '16'
     where iid.warehouse_no = strWareHouseNo
       and iid.enterprise_no = strEnterpriseNo
       and iid.label_no = strLabelNo;

    update idata_instock_m t
       set t.status = '16'
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWareHouseNo
       and t.instock_no = v_strInstockNo
       and not exists (select 'x'
              from idata_instock_d
             where enterprise_no = strEnterpriseNo
               and warehouse_no = strWareHouseNo
               and instock_no = v_strInstockNo
               and label_no = strLabelNo
               and status < '13');

    if sql%rowcount > 0 then

      PKOBJ_IDATA.P_Label_InstockToHty(strWareHouseNo,
                                       strLabelNo,
                                       v_strLocateNo,
                                       strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
    end if;
    --更新标签状态
    pkobj_label.p_updt_label_status(strEnterpriseNo,
                                    strWareHouseNo,
                                    v_strConatainerNo,
                                    strWorkerNo,
                                    CLabelStatus.instock_cancel,
                                    strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    --标签转历史
    pkobj_label.proc_RemoveLabel(strEnterpriseNo,
                                 strWareHouseNo,
                                 v_strConatainerNo,
                                 strResult);

    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    strResult := 'Y|成功!';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_instock_Label_Cancel;
  /*****************************************************************************************************
  创建人：luozhiling
  创建时间：2014.10.25.
  功能说明：对未分播回单的标签进行分播单处理
            1、将对应的分播明细数据置未16
           注意：需考虑存储的分播标签和直通的分播标签
  *****************************************************************************************************/

  procedure P_DivideLabelCancel(strEnterpriseNo in stock_label_m.enterprise_no%type,
                                strWareHouseNo  in stock_label_m.warehouse_no%type,
                                strContainerNo  in stock_label_m.label_no%type, --内部容器号
                                strWorkerNo     in stock_label_m.rgst_name%type,
                                strResult       out varchar2) is
    --strPaperNo    idata_check_m.check_no%type;
    v_iCount      integer;
    v_strDivideNo odata_divide_m.divide_no%type;
    v_strOwnerNo  odata_divide_m.owner_no%type;
  begin
    strResult := 'Y|[]';

    --获取分播单；
    begin
      select distinct owner_no, divide_no
        into v_strOwnerNo, v_strDivideNo
        from odata_divide_d
       where enterprise_no = strEnterpriseNo
         and warehouse_no = strWareHouseNo
         and s_container_no = strContainerNo
         and status < '13'
         and rownum = 1;
    exception
      when no_data_found then
        return;
    end;

    --更新分播单状态
    update odata_divide_d t
       set t.status      = '16',
           t.divide_name = strWorkerNo,
           t.divide_date = sysdate
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWareHouseNo
       and t.s_container_no = strContainerNo
       and t.status < '13';

    if sql%notfound then
      return;
    end if;

    --检查是否有未分播回单的明细，若有，不处理；
    select count(*)
      into v_iCount
      from odata_divide_d
     where enterprise_no = strEnterpriseNo
       and warehouse_no = strWareHouseNo
       and divide_no = v_strDivideNo
       and status < '13';

    if v_iCount = 0 then
      --若无未回单的数据
      --检查是否有已回单的明细，若有，头档状态更新为13，若无，头档状态更新为16
      select count(*)
        into v_iCount
        from odata_divide_d
       where enterprise_no = strEnterpriseNo
         and warehouse_no = strWareHouseNo
         and divide_no = v_strDivideNo
         and status = '13';
      if v_iCount = 0 then
        update odata_divide_m t
           set t.status    = '16',
               t.updt_name = strWorkerNo,
               t.updt_date = sysdate
         where t.enterprise_no = strEnterpriseNo
           and t.warehouse_no = strWareHouseNo
           and t.divide_no = v_strDivideNo;
      else
        update odata_divide_m t
           set t.status    = '13',
               t.updt_name = strWorkerNo,
               t.updt_date = sysdate
         where t.enterprise_no = strEnterpriseNo
           and t.warehouse_no = strWareHouseNo
           and t.divide_no = v_strDivideNo;
      end if;
    end if;

    --分播单转历史
    pkobj_odata_divide.p_Update_Odata_Divide_Hty(strEnterPriseNo,
                                                 strWarehouseNo,
                                                 v_strOwnerNo,
                                                 v_strDivideNo,
                                                 strResult);

    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_DivideLabelCancel;

  /*****************************************************************************************************
  创建人：luozhiling
  创建时间：2014.10.25.
  功能说明：对客户标签做标签销毁：，
            1、根据标签明细判断是否是直通或存储；
            2、如果是存储标签直接将库存转移到销毁区，并且做标签销毁，如果是直通的客户标签，需要判断验收单的状态，
            并且根据验收单状态来判断是否做销毁或验收还原。
  *****************************************************************************************************/

  procedure P_Cust_Label_Cancel(strEnterpriseNo in stock_label_m.enterprise_no%type,
                                strWareHouseNo  in stock_label_m.warehouse_no%type,
                                strLabelNo      in stock_label_m.label_no%type,
                                strWorkerNo     in stock_label_m.rgst_name%type,
                                strResult       out varchar2) is
    strPaperNo       idata_check_m.check_no%type;
    v_strCancelCell  cdef_defcell.cell_no%type;
    v_nCellID        stock_content.cell_id%type;
    v_nOutCellId     stock_content.cell_id%type;
    v_strLabelNo     stock_label_m.label_no%type;
    v_strContainerNo stock_label_m.container_no%type;
    v_strUseType     stock_label_m.use_type%type; --1：客户标签；2：分播标签
    --v_iCount              integer;
    v_strOwnerContainerNo stock_label_m.owner_container_no%type; --所属容器
  begin
    strResult := 'N|[P_Cust_Label_Cancel]';
    --读取标签销毁储区
    begin
      select cell_no
        into v_strCancelCell
        from cdef_defarea cd, cdef_defcell t
       where cd.enterprise_no = t.enterprise_no
         and cd.enterprise_no = strEnterpriseNo
         and cd.warehouse_no = t.warehouse_no
         and cd.area_no = t.area_no
         and cd.ware_no = t.ware_no
         and cd.area_usetype = '1'
         and cd.area_attribute = '3' --and cd.attribute_type='0'
         and rownum = 1;
    exception
      when no_data_found then
        strResult := 'N|[E21306]'; --没有读取到差异数量计账储位
        return;
    end;

    --取标签销毁单号
    begin
      PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                 strWareHouseNo,
                                 CONST_DOCUMENTTYPE.LABELXH,
                                 strPaperNo,
                                 strResult);
      if (strPaperNo is null or substr(strResult, 1, 1) = 'N') then
        strResult := 'N|[E20909]'; --取汇总验收单号错误!
        return;
      end if;
    end;

    --获取标签内部容器号
    begin
      select container_no, use_type, owner_container_no
        into v_strContainerNo, v_strUseType, v_strOwnerContainerNo
        from stock_label_m slm
       where slm.enterprise_no = strEnterpriseNo
         and slm.warehouse_no = strWareHouseNo
         and slm.label_no = strLabelNo;
    exception
      when no_data_found then
        strResult := 'N|[E21707]';
        return;
    end;

    if v_strUseType = '2' then
      P_DivideLabelCancel(strEnterpriseNo,
                          strWareHouseNo,
                          v_strContainerNo,
                          strWorkerNo,
                          strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
    end if;

    for GetCheckInf in (select slm.hm_manual_flag,
                               slm.owner_cell_no,
                               icm.s_check_no,
                               icm.check_no,
                               icm.status check_status,
                               sld.*
                          from stock_label_m      slm,
                               stock_label_d      sld,
                               stock_article_info sai,
                               idata_check_m      icm
                         where slm.warehouse_no = sld.warehouse_no
                           and slm.container_no = sld.container_no
                           and sld.article_no = sai.article_no
                           and sld.article_id = sai.article_id
                           and sai.import_batch_no = icm.check_no
                           and slm.warehouse_no = strWareHouseNo
                           and slm.label_no = strLabelNo
                           and icm.status < '13'
                           and sld.exp_type = 'ID'
                         order by icm.s_check_no, icm.check_no, icm.status) loop

      --还原验收数据
      pkobj_idata.P_Label_Cancel_IDcheck(strEnterPriseNo,
                                         strWarehouseNo,
                                         GetCheckInf.owner_no,
                                         GetCheckInf.s_check_no,
                                         strLabelNo,
                                         GetCheckInf.cust_no,
                                         GetCheckInf.article_no,
                                         GetCheckInf.article_id,
                                         GetCheckInf.packing_qty,
                                         GetCheckInf.qty,
                                         strWorkerNo,
                                         strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --标签销毁处理分播数据

      --将库存移至标签销毁区；
      if GetCheckInf.HM_MANUAL_FLAG = '0' then
        v_strLabelNo := strLabelNo;
      else
        v_strLabelNo := 'N';
      end if;

      --删除对应的库存

      pkobj_stock.p_UpdtContent_qtyByCellNo(strEnterpriseNo,
                                            strWareHouseNo,
                                            GetCheckInf.owner_no,
                                            GetCheckInf.article_no,
                                            GetCheckInf.article_id,
                                            GetCheckInf.owner_cell_no,
                                            GetCheckInf.owner_cell_no,
                                            GetCheckInf.packing_qty,
                                            GetCheckInf.qty,
                                            v_strLabelNo,
                                            '1',
                                            'N',
                                            strWorkerNo,
                                            strPaperNo,
                                            '1',
                                            strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --扣减标签明细数据
      pkobj_label.P_UpdtLabelItme(strEnterpriseNo,
                                  strWareHouseNo,
                                  GetCheckInf.container_no,
                                  strWorkerNo,
                                  GetCheckInf.divide_id,
                                  GetCheckInf.article_no,
                                  GetCheckInf.article_id,
                                  GetCheckInf.qty,
                                  GetCheckInf.row_id,
                                  strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
    end loop;

    if v_strContainerNo = v_strOwnerContainerNo then
      --没有并板关系的标签

      for GetLableItem in (select slm.owner_cell_no,
                                  slm.HM_MANUAL_FLAG,
                                  sld.*
                             from stock_label_m slm, stock_label_d sld
                            where slm.warehouse_no = sld.warehouse_no
                              and slm.container_no = sld.container_no
                              and slm.warehouse_no = strWareHouseNo
                              and slm.label_no = strLabelNo /*
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            and sld.exp_type<>'ID'*/
                           ) loop

        --将库存移至标签销毁区；
        if GetLableItem.HM_MANUAL_FLAG = '0' then
          v_strLabelNo := strLabelNo;
        else
          v_strLabelNo := 'N';
        end if;

        --将目的储位库存转移到销毁区:扣减来源储位库存
        pkobj_stock.p_UpdtContent_qtyByCellNo(strEnterpriseNo,
                                              strWareHouseNo,
                                              GetLableItem.owner_no,
                                              GetLableItem.article_no,
                                              GetLableItem.article_id,
                                              GetLableItem.owner_cell_no,
                                              v_strCancelCell,
                                              GetLableItem.packing_qty,
                                              GetLableItem.qty,
                                              v_strLabelNo,
                                              '1',
                                              'N',
                                              strWorkerNo,
                                              strPaperNo,
                                              '1',
                                              strResult);
        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        --增加目的储位库存
        pkobj_stock.p_InstContent_qtyByCellNo(strEnterpriseNo,
                                              strWareHouseNo,
                                              GetLableItem.owner_no,
                                              'N',
                                              GetLableItem.article_no,
                                              GetLableItem.article_id,
                                              v_strCancelCell,
                                              GetLableItem.owner_cell_no,
                                              GetLableItem.packing_qty,
                                              GetLableItem.qty,
                                              v_strLabelNo,
                                              v_strLabelNo,
                                              '1',
                                              'N',
                                              strWorkerNo,
                                              strPaperNo,
                                              '1',
                                              '1',
                                              v_nCellID,
                                              strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        pkobj_stock.p_UpdtContent_ContainerNo(strEnterpriseNo,
                                              strWareHouseNo,
                                              'N',
                                              'N',
                                              v_strCancelCell,
                                              v_nCellID,
                                              strWorkerNo,
                                              v_nOutCellId,
                                              strResult);
        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;
      end loop;
    else
      --有并板关系的标签
      --
      P_LoadPal_Cancel(strEnterpriseNo,
                       strWareHouseNo,
                       strLabelNo,
                       strWorkerNo,
                       v_strCancelCell,
                       strPaperNo,
                       strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
    end if;

    --更新标签状态
    pkobj_label.p_updt_label_status(strEnterpriseNo,
                                    strWareHouseNo,
                                    v_strContainerNo,
                                    strWorkerNo,
                                    CLabelStatus.DIVIDED_CANCEL,
                                    strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    --标签转历史
    pkobj_label.proc_RemoveLabel(strEnterpriseNo,
                                 strWareHouseNo,
                                 v_strContainerNo,
                                 strResult);

    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;
    strResult := 'Y|[成功]';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_Cust_Label_Cancel;
  /*****************************************************************************************************
  创建人：luozhiling
  创建时间：2014.10.25.
  功能说明：对已经被并板或者并板的标签做销毁：，
            1、如果是存储标签直接将库存转移到销毁区，并且做标签销毁，
  *****************************************************************************************************/

  procedure P_LoadPal_Cancel(strEnterpriseNo in stock_label_m.enterprise_no%type,
                             strWareHouseNo  in stock_label_m.warehouse_no%type,
                             strLabelNo      in stock_label_m.label_no%type,
                             strWorkerNo     in stock_label_m.rgst_name%type,
                             strDestCellNo   in stock_label_m.owner_cell_no%type, --目的储位
                             strPaperNo      in stock_label_m.source_no%type, --销毁单号
                             strResult       out varchar2) is
    v_nCellID    stock_content.cell_id%type;
    v_nOutCellId stock_content.cell_id%type;
    --v_strLabelNo          stock_label_m.label_no%type;
    --v_strContainerNo      stock_label_m.container_no%type;
    --v_strUseType          stock_label_m.use_type%type; --1：客户标签；2：分播标签
    --v_iCount              integer;
    --v_strOwnerContainerNo stock_label_m.owner_container_no%type; --所属容器
  begin
    strResult := 'N|[P_LoadPal_Cancel]';

    for GetLableItem in (select a.owner_cell_no, sld.*
                           from (select t.owner_cell_no,
                                        t.enterprise_no,
                                        t.warehouse_no,
                                        t.label_no,
                                        m.label_no owner_label_no,
                                        m.container_no
                                   from stock_label_m t, stock_label_m m
                                  where t.label_no = strLabelNo
                                    and t.enterprise_no = m.enterprise_no
                                    and t.warehouse_no = m.warehouse_no
                                    and t.container_no = m.owner_container_no) a,
                                stock_label_d sld
                          where a.enterprise_no = sld.enterprise_no
                            and a.warehouse_no = sld.warehouse_no
                            and a.container_no = sld.container_no
                            and a.enterprise_no = strEnterpriseNo
                            and a.warehouse_no = strWareHouseNo) loop

      --将目的储位库存转移到销毁区:扣减来源储位库存
      pkobj_stock.p_UpdtContent_qtyByCellNo(strEnterpriseNo,
                                            strWareHouseNo,
                                            GetLableItem.owner_no,
                                            GetLableItem.article_no,
                                            GetLableItem.article_id,
                                            GetLableItem.owner_cell_no,
                                            strDestCellNo,
                                            GetLableItem.packing_qty,
                                            GetLableItem.qty,
                                            strLabelNo,
                                            '1',
                                            'N',
                                            strWorkerNo,
                                            strPaperNo,
                                            '1',
                                            strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --增加目的储位库存
      pkobj_stock.p_InstContent_qtyByCellNo(strEnterpriseNo,
                                            strWareHouseNo,
                                            GetLableItem.owner_no,
                                            'N',
                                            GetLableItem.article_no,
                                            GetLableItem.article_id,
                                            strDestCellNo,
                                            GetLableItem.owner_cell_no,
                                            GetLableItem.packing_qty,
                                            GetLableItem.qty,
                                            strLabelNo,
                                            strLabelNo,
                                            '1',
                                            'N',
                                            strWorkerNo,
                                            strPaperNo,
                                            '1',
                                            '1',
                                            v_nCellID,
                                            strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      pkobj_stock.p_UpdtContent_ContainerNo(strEnterpriseNo,
                                            strWareHouseNo,
                                            'N',
                                            'N',
                                            strDestCellNo,
                                            v_nCellID,
                                            strWorkerNo,
                                            v_nOutCellId,
                                            strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
    end loop;

    strResult := 'Y|[成功]';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_LoadPal_Cancel;
  /***********************************************************************************************************
   创建人：luozhiling
   创建时间：2014.10.27
   功能说明：标签销毁时校验标签是否可做销毁
  **********************************************************************************************************/
  procedure PROC_Check_LABEL_CANCEL(strEnterpriseNo in stock_label_m.enterprise_no%type,
                                    strWareHouseNo  in stock_label_m.warehouse_no%type,
                                    strLabelNo      in stock_label_m.label_no%type,
                                    strResult       out varchar2) is
    v_strStatus  stock_label_m.status%type;
    v_strUseType stock_label_m.use_type%type;
    v_iCount     integer;
    checkCount   integer;
  begin
    strResult := 'N|[PROC_Check_LABEL_CANCEL]';
    --校验标签是否能做销毁
    begin
      select slm.status, slm.use_type
        into v_strStatus, v_strUseType
        from stock_label_m slm
       where slm.enterprise_no = strEnterpriseNo
         and slm.warehouse_no = strWarehouseNo
         and slm.label_no = strLabelNo;
    exception
      when no_data_found then
        strResult := 'N|[E22909]';
        return;
    end;

    if v_strStatus = CLabelStatus.PICK_HAND_OUT or
       v_strStatus = CLabelStatus.HasRelevanceBox then
      strResult := 'N|[E35002]';
      return;
    end if;

    if v_strStatus = CLabelStatus.PICK_END AND v_strUseType = '1' then
      --检查此标签对应的分播单是否已回单
      strResult := 'N|[待复核的标签，系统暂未实现做销毁]'; --
      return;
    end if;

    if v_strStatus = CLabelStatus.NEW_LABEL_NO then
      strResult := 'N|[E35005]';
      return;
    end if;

    if v_strStatus = CLabelStatus.LOADED_IN_PAL then
      strResult := 'N|[E35006]';
      return;
    end if;

    if v_strStatus = CLabelStatus.LOADED_IN_CAR then
      strResult := 'N|[E35007]';
      return;
    end if;

    if v_strUseType = '3' then
      strResult := 'N|[E35004]';
      return;
    end if;

    --检查一个标签是否包含多个验收单且未确认
    select count(distinct icm.s_check_no)
      into checkCount
      from stock_label_m      slm,
           stock_label_d      sld,
           stock_article_info sai,
           idata_check_m      icm
     where slm.enterprise_no = sld.enterprise_no
       and slm.enterprise_no = sai.enterprise_no
       and slm.enterprise_no = icm.enterprise_no
       and slm.enterprise_no = strEnterpriseNo
       and slm.warehouse_no = sld.warehouse_no
       and slm.owner_container_no = sld.container_no
       and sld.article_no = sai.article_no
       and sld.article_id = sai.article_id
       and sai.import_batch_no = icm.check_no
       and slm.warehouse_no = strWareHouseNo
       and slm.label_no = strLabelNo
       and icm.status < '13'
       and sld.exp_type = 'ID';

    --if v_iCount > 1 then  yanjunfeng 2018-03-29
    if checkCount >1 then 
      strResult := 'N|[多张未确认的直通单库存混在一起，不允许直接销毁]';
      return;
    end if;

    --若有多个验收批次则，不允许销毁
    select count(distinct sai.import_batch_no)
      into v_iCount
      from stock_label_m slm, stock_label_d sld, stock_article_info sai
     where slm.enterprise_no = sld.enterprise_no
       and slm.enterprise_no = sai.enterprise_no
       and slm.warehouse_no = sld.warehouse_no
       and slm.owner_container_no = sld.container_no
       and sld.article_no = sai.article_no
       and sld.article_id = sai.article_id
       and slm.enterprise_no = strEnterpriseNo
       and slm.warehouse_no = strWareHouseNo
       and slm.label_no = strLabelNo;
   -- if v_iCount > 1 and checkCount <= 1 then  yanjunfeng 2018-03-29
   if v_iCount > 1 and checkCount > 1 then   
      strResult := 'N|[此标签含多个批次并有验收单未审核，不能直接销毁]';
      return;
    end if;
    --计算是否混标签
    select count(*)
      into v_iCount
      from stock_label_m slm, stock_label_m m
     where slm.enterprise_no = m.enterprise_no
       and slm.warehouse_no = m.warehouse_no
       and slm.container_no = m.owner_container_no
       and slm.enterprise_no = strEnterpriseNo
       and slm.warehouse_no = strWareHouseNo
       and slm.label_no = strLabelNo;
   -- if v_iCount > 1 and checkCount <= 1 then  yanjunfeng 2018-03-29
   if v_iCount > 1 and checkCount > 1 then   
      strResult := 'N|[此标签含多个标签并有验收单未审核，不能直接销毁]';
      return;
    end if;

    strResult := 'Y|[成功]';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end PROC_Check_LABEL_CANCEL;

  /*****************************************************************************************************
   创建人：luozhiling
   创建时间:2016.3.21
   功能说明：对标签上的单SKU部分做销毁的校验
             1、只能是客户标签才允许做销毁
  ******************************************************************************************************/
  procedure Proc_CheckSku_Label_cancel(strEnterpriseNo     in stock_label_m.enterprise_no%type,
                                       strWareHouseNo      in stock_label_m.warehouse_no%type,
                                       strLabelNo          in stock_label_m.label_no%type,
                                       strLabelProduceFlag out wms_defbase.ndefine%type,
                                       strResult           out varchar2) is
    v_strStatus           stock_label_m.status%type;
    v_strUseType          stock_label_m.use_type%type;
    v_strOwnerNo          stock_label_d.owner_no%type;
    v_strLabelProduceFlag wms_defbase.sdefine%type; ---0:不管生产日期；1:管生产日期
    v_nLabelProduceFlag   wms_defbase.ndefine%type;
  begin
    strResult := 'N|[Proc_CheckSku_Label_cancel]';
    --校验标签是否能做销毁
    begin
      select slm.status, slm.use_type
        into v_strStatus, v_strUseType
        from stock_label_m slm
       where slm.enterprise_no = strEnterpriseNo
         and slm.warehouse_no = strWarehouseNo
         and slm.label_no = strLabelNo;
    exception
      when no_data_found then
        strResult := 'N|[E22909]';
        return;
    end;

    if v_strUseType = '0' then
      strResult := 'N|[收货标签不允许单SKU销毁]';
      return;
    end if;

    if v_strUseType = '2' then
      strResult := 'N|[分播标签不允许单SKU销毁]';
      return;
    end if;

    if v_strUseType = '3' then
      strResult := 'N|[移库标签不允许单SKU销毁]';
      return;
    end if;

    if v_strStatus = CLabelStatus.PICK_HAND_OUT or
       v_strStatus = CLabelStatus.HasRelevanceBox then
      strResult := 'N|[E35002]';
      return;
    end if;

    if v_strStatus = CLabelStatus.PICK_END AND v_strUseType = '1' then
      --检查此标签对应的分播单是否已回单
      strResult := 'N|[待复核的标签，系统暂未实现做销毁]'; --
      return;
    end if;

    if v_strStatus = CLabelStatus.NEW_LABEL_NO then
      strResult := 'N|[E35005]';
      return;
    end if;

    if v_strStatus = CLabelStatus.LOADED_IN_PAL then
      strResult := 'N|[E35006]';
      return;
    end if;

    if v_strStatus = CLabelStatus.LOADED_IN_CAR then
      strResult := 'N|[E35007]';
      return;
    end if;

    --add by huangcx 20160623
    --校验直通标签是否已做验收确认
    begin
      select distinct slm.status
        into v_strStatus
        from idata_check_m icm, stock_label_m slm, stock_label_d sld
       where icm.enterprise_no = slm.enterprise_no
         and icm.s_check_no = slm.source_no
         and slm.enterprise_no = sld.enterprise_no
         and slm.warehouse_no = sld.warehouse_no
         and slm.source_no = sld.source_no
         and slm.container_no = sld.container_no
         and sld.exp_type = 'ID'
         and icm.status = '13'
         and slm.enterprise_no = strEnterpriseNo
         and slm.warehouse_no = strWarehouseNo
         and slm.label_no = strLabelNo;
    exception
      when no_data_found then
        strResult := 'N|[未验收确认直通标签不允许单SKU销毁]';
        return;
    end;
    --end add

    --获取货主编号
    begin
      select sld.owner_no
        into v_strOwnerNo
        from stock_label_d sld, stock_label_m slm
       where slm.enterprise_no = sld.enterprise_no
         and slm.warehouse_no = sld.warehouse_no
         and slm.label_no = strLabelNo
         and rownum = 1;
    exception
      when no_data_found then
        strResult := 'N|[找不到对应的标签明细]';
        return;
    end;

    --读取是否管理生产日期的参数，若管理生产日期，则按传入的日期做销毁，若不管理生产日期，系统自动配量 ,
    PKLG_WMS_BASE.p_GetBasePara(strEnterpriseNo,
                                strWareHouseNo,
                                v_strOwnerNo,
                                'LabelProduceFlag',
                                'O',
                                'LAB_CANCEL',
                                v_strLabelProduceFlag,
                                v_nLabelProduceFlag,
                                strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;
    strLabelProduceFlag := v_strLabelProduceFlag;
    strResult           := 'Y|[成功]';

    strResult := 'Y|[]';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end Proc_CheckSku_Label_cancel;

  /**********************************************************************************************************
      创建人：luozhiling
      创建时间：2014.10.27
      功能说明：标签销毁，包含存储和直通标签的销毁
  **********************************************************************************************************/
  procedure PROC_LABEL_CANCEL(strEnterpriseNo in stock_label_m.enterprise_no%type,
                              strWareHouseNo  in stock_label_m.warehouse_no%type,
                              strLabelNo      in stock_label_m.label_no%type,
                              strWorkerNo     in stock_label_m.rgst_name%type,
                              strResult       out varchar2) is
    v_strStatus       stock_label_m.status%type;
    v_strUseType      stock_label_m.use_type%type;
    v_strSourceNo     stock_label_m.source_no%type;
    v_strConatainerNo stock_label_m.container_no%type;

  begin
    strResult := 'N|[PROC_LABEL_CANCEL]';

    --校验标签是否能做销毁
    PROC_Check_LABEL_CANCEL(strEnterpriseNo,
                            strWareHouseNo,
                            strLabelNo,
                            strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    begin
      select slm.status, slm.use_type, slm.source_no, slm.container_no
        into v_strStatus, v_strUseType, v_strSourceNo, v_strConatainerNo
        from stock_label_m slm
       where slm.warehouse_no = strWarehouseNo
         and slm.enterprise_no = strEnterpriseNo
         and slm.label_no = strLabelNo;
    exception
      when no_data_found then
        strResult := 'N|[E22909]';
        return;
    end;

    if v_strUseType = '0' then
      --进货标签
      P_instock_Label_Cancel(strEnterpriseNo,
                             strWareHouseNo,
                             strLabelNo,
                             strWorkerNo,
                             strResult);

      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;
    end if;

    if v_strUseType = '1' or v_strUseType = '2' then
      --客户标签
      P_Cust_Label_Cancel(strEnterpriseNo,
                          strWareHouseNo,
                          strLabelNo,
                          strWorkerNo,
                          strResult);

      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;
    end if;

    --直通标签
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end PROC_LABEL_CANCEL;
  /**********************************************************************************************************
      创建人：luozhiling
      创建时间：2016.3.21
      功能说明：对标签上的某个SKU进行销毁，只能处理客户标签，需支持直通和存储的标签,考虑生产日期等属性
  **********************************************************************************************************/
  procedure P_Sku_lab_cancel(strEnterpriseNo     in stock_label_m.enterprise_no%type,
                             strWareHouseNo      in stock_label_m.warehouse_no%type,
                             strLabelNo          in stock_label_m.label_no%type,
                             strArticleNo        in stock_label_d.article_no%type,
                             nPackingQty         in stock_content.packing_qty%type,
                             dtProduceDate       in stock_article_info.produce_date%type,
                             dtExpireDate        in stock_article_info.expire_date%type,
                             nCancelQty          in stock_label_d.qty%type,
                             strWorkerNo         in stock_label_m.rgst_name%type,
                             strLabelProduceFlag in wms_defbase.sdefine%type, ---0:不管生产日期；1:管生产日期
                             strResult           out varchar2) is
    v_strConatainerNo stock_label_m.container_no%type;
    strPaperNo        idata_check_m.check_no%type;
    v_strCancelCell   cdef_defcell.cell_no%type;
    v_nCellID         stock_content.cell_id%type;
    v_nOutCellId      stock_content.cell_id%type;
    v_strLabelNo      stock_label_m.label_no%type;
    v_nRemainQty      stock_label_d.qty%type := nCancelQty;
    v_nCurrQty        stock_label_d.qty%type;
    v_nQty            stock_label_d.qty%type;
    v_strOwnerNo      bdef_defowner.owner_no%type;
  begin
    strResult := 'N|[P_Sku_lab_cancel]';

    --读取标签销毁储区
    begin
      select cell_no
        into v_strCancelCell
        from cdef_defarea cd, cdef_defcell t
       where cd.enterprise_no = t.enterprise_no
         and cd.enterprise_no = strEnterpriseNo
         and cd.warehouse_no = t.warehouse_no
         and cd.area_no = t.area_no
         and cd.ware_no = t.ware_no
         and cd.area_usetype = '1'
         and cd.area_attribute = '3'
         and cd.warehouse_no = strWareHouseNo --and cd.attribute_type='0'
         and rownum = 1;
    exception
      when no_data_found then
        strResult := 'N|[E21306]'; --没有读取到差异数量计账储位
        return;
    end;

    --获取货主编码
    begin
      select owner_no
        into v_strOwnerNo
        from bdef_defarticle
       where article_no = strArticleNo;
    exception
      when no_data_found then
        strResult := 'N|[找不到对应的储位]';
        return;
    end;

    --取标签销毁单号
    begin
      PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                 strWareHouseNo,
                                 CONST_DOCUMENTTYPE.LABELXH,
                                 strPaperNo,
                                 strResult);
      if (strPaperNo is null or substr(strResult, 1, 1) = 'N') then
        strResult := 'N|[E20909]'; --取汇总验收单号错误!
        return;
      end if;
    end;

    --获取标签内部容器号
    begin
      select container_no
        into v_strConatainerNo
        from stock_label_m slm
       where slm.warehouse_no = strWareHouseNo
         and slm.label_no = strLabelNo;
    exception
      when no_data_found then
        strResult := 'N|[E21707]';
        return;
    end;

    --对直通数据的处理

    for GetCheckInf in (select slm.hm_manual_flag,
                               slm.owner_cell_no,
                               icm.s_check_no,
                               icm.check_no,
                               icm.status check_status,
                               sld.*
                          from stock_label_m      slm,
                               stock_label_d      sld,
                               stock_article_info sai,
                               idata_check_m      icm
                         where slm.warehouse_no = sld.warehouse_no
                           and slm.container_no = sld.container_no
                           and sld.article_no = sai.article_no
                           and sld.article_id = sai.article_id
                           and sai.import_batch_no = icm.check_no
                           and slm.warehouse_no = strWareHouseNo
                           and slm.label_no = strLabelNo
                           and icm.status < '13'
                           and sld.article_no = strArticleNo
                           and (strLabelProduceFlag = '0' or
                               (strLabelProduceFlag = '1' and
                               sld.packing_qty = nPackingQty))
                           and (strLabelProduceFlag = '0' or
                               (strLabelProduceFlag = '1' and
                               sai.produce_date = dtProduceDate))
                           and (strLabelProduceFlag = '0' or
                               (strLabelProduceFlag = '1' and
                               sai.expire_date = dtExpireDate))
                           and sld.exp_type = 'ID'
                         order by icm.s_check_no, icm.check_no, icm.status) loop

      if v_nRemainQty <= GetCheckInf.qty then
        v_nCurrQty := v_nRemainQty;
      else
        v_nCurrQty := GetCheckInf.qty;
      end if;

      v_nRemainQty := v_nRemainQty - v_nCurrQty;

      --还原验收数据
      pkobj_idata.P_Label_Cancel_IDcheck(strEnterPriseNo,
                                         strWarehouseNo,
                                         GetCheckInf.owner_no,
                                         GetCheckInf.s_check_no,
                                         strLabelNo,
                                         GetCheckInf.cust_no,
                                         GetCheckInf.article_no,
                                         GetCheckInf.article_id,
                                         GetCheckInf.packing_qty,
                                         v_nCurrQty,
                                         strWorkerNo,
                                         strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --标签销毁处理分播数据

      --将库存移至标签销毁区；
      if GetCheckInf.HM_MANUAL_FLAG = '0' then
        v_strLabelNo := strLabelNo;
      else
        v_strLabelNo := 'N';
      end if;

      --删除对应的库存

      pkobj_stock.p_UpdtContent_qtyByCellNo(strEnterpriseNo,
                                            strWareHouseNo,
                                            GetCheckInf.owner_no,
                                            GetCheckInf.article_no,
                                            GetCheckInf.article_id,
                                            GetCheckInf.owner_cell_no,
                                            GetCheckInf.owner_cell_no,
                                            GetCheckInf.packing_qty,
                                            v_nCurrQty,
                                            v_strLabelNo,
                                            '1',
                                            'N',
                                            strWorkerNo,
                                            strPaperNo,
                                            '1',
                                            strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --扣减标签明细数据
      pkobj_label.P_UpdtLabelItme(strEnterpriseNo,
                                  strWareHouseNo,
                                  GetCheckInf.container_no,
                                  strWorkerNo,
                                  GetCheckInf.divide_id,
                                  GetCheckInf.article_no,
                                  GetCheckInf.article_id,
                                  v_nCurrQty,
                                  GetCheckInf.row_id,
                                  strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      if v_nRemainQty = 0 then
        exit;
      end if;
    end loop;

    for GetLableItem in (select slm.owner_cell_no, slm.HM_MANUAL_FLAG, sld.*
                           from stock_label_m      slm,
                                stock_label_d      sld,
                                stock_article_info sai
                          where slm.enterprise_no = sld.enterprise_no
                            and slm.warehouse_no = sld.warehouse_no
                            and slm.container_no = sld.container_no
                            and sld.article_no = sai.article_no
                            and sld.article_id = sai.article_id
                            and slm.warehouse_no = strWareHouseNo
                            and slm.enterprise_no = strEnterpriseNo
                            and slm.label_no = strLabelNo
                            and (strLabelProduceFlag = '0' or
                                (strLabelProduceFlag = '1' and
                                sld.packing_qty = nPackingQty))
                            and (strLabelProduceFlag = '0' or
                                (strLabelProduceFlag = '1' and
                                sai.produce_date = dtProduceDate))
                            and (strLabelProduceFlag = '0' or
                                (strLabelProduceFlag = '1' and
                                sai.expire_date = dtExpireDate))) loop

      --将库存移至标签销毁区；
      if GetLableItem.HM_MANUAL_FLAG = '0' then
        v_strLabelNo := strLabelNo;
      else
        v_strLabelNo := 'N';
      end if;

      if v_nRemainQty <= GetLableItem.qty then
        v_nCurrQty := v_nRemainQty;
      else
        v_nCurrQty := GetLableItem.qty;
      end if;

      v_nRemainQty := v_nRemainQty - v_nCurrQty;

      --将目的储位库存转移到销毁区:扣减来源储位库存
      pkobj_stock.p_UpdtContent_qtyByCellNo(strEnterpriseNo,
                                            strWareHouseNo,
                                            GetLableItem.owner_no,
                                            GetLableItem.article_no,
                                            GetLableItem.article_id,
                                            GetLableItem.owner_cell_no,
                                            v_strCancelCell,
                                            GetLableItem.packing_qty,
                                            v_nCurrQty,
                                            v_strLabelNo,
                                            '1',
                                            'N',
                                            strWorkerNo,
                                            strPaperNo,
                                            '1',
                                            strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --增加目的储位库存
      pkobj_stock.p_InstContent_qtyByCellNo(strEnterpriseNo,
                                            strWareHouseNo,
                                            GetLableItem.owner_no,
                                            'N',
                                            GetLableItem.article_no,
                                            GetLableItem.article_id,
                                            v_strCancelCell,
                                            GetLableItem.owner_cell_no,
                                            GetLableItem.packing_qty,
                                            v_nCurrQty,
                                            v_strLabelNo,
                                            v_strLabelNo,
                                            '1',
                                            'N',
                                            strWorkerNo,
                                            strPaperNo,
                                            '1',
                                            '1',
                                            v_nCellID,
                                            strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      pkobj_stock.p_UpdtContent_ContainerNo(strEnterpriseNo,
                                            strWareHouseNo,
                                            'N',
                                            'N',
                                            v_strCancelCell,
                                            v_nCellID,
                                            strWorkerNo,
                                            v_nOutCellId,
                                            strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --扣减标签明细数据
      pkobj_label.P_UpdtLabelItme(strEnterpriseNo,
                                  strWareHouseNo,
                                  GetLableItem.container_no,
                                  strWorkerNo,
                                  GetLableItem.divide_id,
                                  GetLableItem.article_no,
                                  GetLableItem.article_id,
                                  v_nCurrQty, --update by huangcx 20160623 原先传GetLableItem.qty
                                  GetLableItem.row_id,
                                  strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      if v_nRemainQty = 0 then
        exit;
      end if;
    end loop;

    if v_nRemainQty > 0 then
      strResult := 'N|[没有足够的库存]';
      return;
    end if;

    --检查此标签是否还有数据
    select nvl(sum(sld.qty), 0)
      into v_nQty
      from stock_label_d sld
     where sld.enterprise_no = strEnterpriseNo
       and sld.warehouse_no = strWareHouseNo
       and sld.container_no = v_strConatainerNo;

    if v_nQty = 0 then

      --更新标签状态
      pkobj_label.p_updt_label_status(strEnterpriseNo,
                                      strWareHouseNo,
                                      v_strConatainerNo,
                                      strWorkerNo,
                                      CLabelStatus.DIVIDED_CANCEL,
                                      strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --标签转历史
      pkobj_label.proc_RemoveLabel(strEnterpriseNo,
                                   strWareHouseNo,
                                   v_strConatainerNo,
                                   strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
    end if;
    strResult := 'Y|[成功]';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_Sku_lab_cancel;
  /*************************************************************************************************
   创建人：luozhiling
   修改人：hekl
   创建时间：2014.12.14
   功能说明：对采购单进行取消、关单
  **************************************************************************************************/
  procedure P_import_cancel(strEnterpriseNo in stock_label_m.enterprise_no%type,
                            strWareHouseNo  in idata_import_m.warehouse_no%type,
                            strOwnerNo      in idata_import_m.owner_no%type,
                            strImportNo     in idata_import_m.import_no%type,
                            strUserID       in idata_import_m.updt_name%type,
                            strResult       out varchar2) is
    --v_strsImportNo idata_import_m.import_no%type;
    --importQty      idata_import_sd.import_qty%type;
    --checkQty       idata_check_pal_tmp.check_qty%type;
    v_strStatus idata_check_m.status%type;
  begin
    strResult := 'N|[P_import_cancel]';
    --v_strsImportNo := 'N';

    begin
      select distinct m.status
        into v_strStatus
        from idata_check_m m
       where m.s_import_no in
             (select sm.s_import_no
                from idata_import_sm sm
               where sm.import_no = strImportNo)
         and m.enterprise_no = strEnterpriseNo
         and m.warehouse_no = strWareHouseNo;

    exception
      when no_data_found then
        v_strStatus := 10; --没有数据，走取消流程
    end;

    --判断是否验收确认
    if v_strStatus = 13 then
      --状态为13，已做验收确认，一品多验，走关单流程
      pkobj_idata.P_import_close(strEnterpriseNo,
                                 strWareHouseNo,
                                 strOwnerNo,
                                 strImportNo,
                                 strUserID,
                                 strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;

    else
      --未做验收确认，一单一验，走取消订单流程
      pkobj_idata.P_import_cancel(strEnterpriseNo,
                                  strWareHouseNo,
                                  strOwnerNo,
                                  strImportNo,
                                  strUserID,
                                  strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;
    end if;

    strResult := 'Y|成功';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_import_cancel;
  /*************************************************************************************************
  创建人：luozhiling
  创建时间：2014.12.24
  功能说明：1、指定储位验收、上架
  ***************************************************************************************************/
  procedure P_checkDirectCell(strEnterpriseNo in idata_check_pal_tmp.enterprise_no%type,
                              strWareHouseNo  in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                              strOwnerNo      in idata_check_pal_tmp.owner_no%type, --委托业主编码
                              strsImportNo    in idata_check_m.s_import_no%type, --进货汇总单号
                              strsCheckNo     in idata_check_pal_tmp.s_check_no%type, --验收汇总单号
                              strCellNo       in idata_locate_direct.cell_no%type, --板号
                              strDockNo       in idata_check_m.dock_no%type,
                              strWorkerNo     in idata_check_pal_tmp.rgst_name%type, --操作人
                              strResult       out varchar2) is
    v_strLocateNo  idata_locate_direct.locate_no%type;
    v_strTaskNo    job_printtask_m.task_no%type;
    v_strInstockNo idata_instock_m.instock_no%type;
  begin
    strResult := 'N|[P_checkDirectCell]';

    P_CheckSplitPal_Fixed(strEnterpriseNo,
                          strWareHouseNo,
                          strOwnerNo,
                          strsImportNo,
                          strsCheckNo,
                          'N',
                          strWorkerNo,
                          strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    p_idata_sCheckLocateInstocK(strEnterpriseNo,
                                strWareHouseNo,
                                strScheckNo,
                                strWorkerNo,
                                '1',
                                strCellNo,
                                'N',
                                V_strLocateNo,
                                strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    pklg_ilocate.p_locate_main(strEnterpriseNo,
                               strWareHouseNo,
                               strOwnerNo,
                               v_strLocateNo,
                               '0',
                               strWorkerNo,
                               v_strTaskNo,
                               strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    P_InsertInstock(strEnterpriseNo,
                    strWareHouseNo,
                    strWorkerNo,
                    v_strLocateNo,
                    strDockNo,
                    '0',
                    v_strInstockNo,
                    strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    P_saveInstockAll(strEnterpriseNo,
                     strWareHouseNo,
                     v_strInstockNo,
                     strWorkerNo,
                     strWorkerNo,
                     '1',
                     strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    strResult := 'Y|[成功]';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_checkDirectCell;

  /*****************************************************************************************************************
  lich
  20150209
  功能说明：验收作业，标签号校验
  ***************************************************************************************************************/
  procedure P_CheckLabelNo(strEnterpriseNo in idata_check_m.enterprise_no%type,
                           strWarehouseNo  in idata_check_m.warehouse_no%type,
                           strLabelNo      in stock_label_m.label_no%type,
                           strSImportNo    in idata_check_m.s_import_no%type,
                           strOutMsg       out varchar2) is
    v_Count integer := 0;
  begin
    strOutMsg := 'N|[P_CheckLabelNo]';
    --检查临时板表
    select count(*)
      into v_Count
      from idata_check_pal_tmp icpt
     where icpt.warehouse_no = strWarehouseNo
       and icpt.enterprise_no = strEnterpriseNo
       and icpt.label_no = strLabelNo
       and icpt.s_import_no <> strSImportNo
       and rownum < 2;
    if v_Count > 0 then
      strOutMsg := 'N|[E20939]'; --该板号已被使用！
      return;
    end if;

    --检查标签表
    select count(*)
      into v_Count
      from stock_label_m
     where label_no = strLabelNo
       and status <> '0'
       and warehouse_no = strWarehouseNo
       and enterprise_no = strEnterpriseNo
       and source_no not in
           (select icm.s_check_no
              from idata_check_m icm
             where warehouse_no = strWarehouseNo
               and enterprise_no = strEnterpriseNo
               and icm.s_import_no = strSImportNo);
    if v_Count > 0 then
      strOutMsg := 'N|[E20939]'; --该板号已被使用！
      return;
    end if;

    --检查库存表
    select count(*)
      into v_Count
      from stock_content sc, stock_article_info sai
     where sc.article_no = sai.article_no
       and sc.article_id = sai.article_id
       and sc.label_no = strLabelNo
       and qty + instock_qty > 0
       and sc.warehouse_no = strWarehouseNo
       and sc.enterprise_no = strEnterpriseNo
       and sai.import_batch_no not in
           (select icp.check_no
              from idata_check_pal icp, idata_check_m icm
             where icp.check_no = icm.check_no
               and icp.warehouse_no = icm.warehouse_no
               and icp.enterprise_no = icm.enterprise_no
               and icp.status = '10'
               and icm.s_import_no = strSImportNo
               and icm.warehouse_no = strWarehouseNo
               and icm.enterprise_no = strEnterpriseNo);
    if v_Count > 0 then
      strOutMsg := 'N|[E20940]'; --该板号已有商品！
      return;
    end if;

    strOutMsg := 'Y|成功！';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_CheckLabelNo;
  /***********************************************************************************************
  lich
  2015.02.09
  功能：RF封板验收
  ***********************************************************************************************/
  procedure P_RF_Close_Pal(strEnterpriseNo in idata_check_pal_tmp.enterprise_no%type, --企业
                           strWareHouseNo  in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                           strOwnerNo      in idata_check_pal_tmp.owner_no%type, --委托业主编码
                           strsImportNo    in idata_check_m.s_import_no%type, --进货汇总单号
                           strsCheckNo     in idata_check_pal_tmp.s_check_no%type, --验收汇总单号
                           strLabelNo      in idata_check_pal_tmp.label_no%type, --板号
                           strWorkerNo     in idata_check_pal_tmp.rgst_name%type, --操作人
                           strPrintType    in job_printtask_m.task_type%type, ----0:不打印；1:打印报表；2：打印标签
                           strFixPalFlag   in idata_check_pal.Fixpal_Flag%type, --1：固定板号；2：流水板号;3：固定流水混合验收
                           strDockNo       in pntset_printer_workstation.workstation_no%type, --工作站号
                           strResult       out varchar2) is
    v_strSCheckNo    idata_check_m.s_check_no%type;
    v_strLocateNo    idata_locate_direct.locate_no%type;
    v_strPrintTaskNo job_printtask_m.task_no%type;
    v_strInstockNo   idata_instock_m.instock_no%type;

    v_CellManagerType bdef_defowner.cell_manager_type%type;
    v_strPrintType    job_printtask_m.task_type%type;
    v_strPlanCellNo   cdef_defcell.cell_no%type;
  begin
    strResult := 'N|[P_RF_Close_Pal]';
    --检验板号 ,流水板验收不作板号校验
    if strFixPalFlag <> '2' then
      P_CheckLabelNo(strEnterpriseNo,
                     strWarehouseNo,
                     strLabelNo,
                     strsImportNo,
                     strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;
    end if;

    begin
      select icpt.s_check_no
        into v_strSCheckNo
        from idata_check_pal_tmp icpt
       where icpt.warehouse_no = strWareHouseNo
         and icpt.enterprise_no = strEnterpriseNo
         and icpt.s_import_no = strsImportNo
         and rownum < 2;
    exception
      when no_data_found then
        strResult := 'N|[该板上没有商品，不能封板！]'; --
        return;
    end;

    --调用封板过程
    P_Close_Pal_Main(strEnterpriseNo,
                     strWareHouseNo,
                     strOwnerNo,
                     strsImportNo,
                     v_strSCheckNo,
                     strLabelNo,
                     strWorkerNo,
                     strFixPalFlag,
                     strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    --货主为大储位管理，验收后直接上架回单
    --首先读取该货主在此仓别下的配置
    begin
      select nvl(CELL_MANAGER_TYPE, 0), nvl(type_value, 'N')
        into v_CellManagerType, v_strPlanCellNo
        from bset_owner_cell_manage t
       where t.enterprise_no = strEnterpriseNo
         and t.owner_no = strOwnerNo
         and t.warehouse_no = strWareHouseNo;
    exception
      when no_data_found then
        begin
          select nvl(CELL_MANAGER_TYPE, 0), nvl(type_value, 'N')
            into v_CellManagerType, v_strPlanCellNo
            from bdef_defowner t
           where t.enterprise_no = strEnterpriseNo
             and t.owner_no = strOwnerNo;
        exception
          when no_data_found then
            strResult := 'N|[货主资料不存在，请核实！]';
            return;
        end;
    end;

    --大储位管理或者固定板验收，不打印上架标签
    if v_CellManagerType = '1' or strFixPalFlag = '1' then
      v_strPrintType := '0';
    else
      v_strPrintType := strPrintType;
    end if;

    --调用根据验收汇总单写标签数据、定位指示和库存
    p_idata_sCheckLocateInstock(strEnterpriseNo,
                                strWareHouseNo,
                                v_strSCheckNo,
                                strWorkerNo,
                                '2',
                                v_strPlanCellNo,
                                strLabelNo,
                                v_strLocateNo,
                                strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;
    --调用进货定位程序入口
    PKLG_ILOCATE.p_locate_main(strEnterPriseNo,
                               strWareHouseNo,
                               strOwnerNo,
                               v_strLocateNo,
                               '0',
                               strWorkerNo,
                               v_strPrintTaskNo,
                               strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    --调用发单程序
    P_InsertInstock(strEnterpriseNo,
                    strWareHouseNo,
                    strWorkerNo,
                    v_strLocateNo,
                    strDockNo,
                    v_strPrintType, --'0',
                    v_strInstockNo,
                    strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;
    if v_CellManagerType = '1' then
      --上架回单
      P_saveInstockAll(strEnterpriseNo,
                       strWarehouseNo,
                       v_strInstockNo,
                       strWorkerNo,
                       strWorkerNo,
                       '0', --strTools 无用
                       strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;
    end if;

    ---小嘴这里需要打印商品信息
    ---这里需要按当前的单据做处理。。记住补印。。待完善

    ---必须是打标签才执行，必须是固定板或者混合板
    IF (strPrintType = '2' AND (strFixPalFlag = '1' OR strFixPalFlag = '3')) THEN

      --这里 单独处理小嘴打印问题。
      P_IDCHECK_PRINT_ARTICLEINFO(strEnterpriseNo,
                                  strWareHouseNo,
                                  v_strInstockNo,
                                  strDockNo,
                                  strWorkerNo,
                                  strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;

    END IF;
    strResult := 'Y';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_RF_Close_Pal;

  /**********************************************************************************
  lich
  2015-02-09
  功能说明：RF保存验收数据
  **********************************************************************************/
  procedure P_RF_SaveCheckDataIS(strEnterpriseNo   in idata_check_m.enterprise_no%type,
                                 strWareHouseNo    in idata_check_m.warehouse_no%type,
                                 strOwnerNo        in idata_check_m.owner_no%type,
                                 strsImportNo      in idata_check_m.s_import_no%type, --进货汇总单号
                                 strArticleNo      in idata_check_d.article_no%type,
                                 strBarcode        in idata_check_d.barcode%type,
                                 nPackingQty       in idata_check_d.packing_qty%type,
                                 nCheckQty         in idata_check_d.check_qty%type,
                                 strPrinterGroupNo in idata_check_m.printer_group_no%type, --工作站
                                 strDockNo         in idata_check_m.dock_no%type, --码头
                                 strWorkerNo       in idata_check_m.rgst_name%type, --操作人
                                 strCheckTools     in idata_check_m.check_tools%type, --验收工具
                                 nIsAdd            in integer, --是否累加 0:覆盖 1:累加
                                 strQuality        in idata_check_d.quality%type, --品质
                                 dtProduceDate     in idata_check_d.produce_date%type,
                                 dtExpireDate      in idata_check_d.expire_date%type,
                                 strLotNo          in idata_check_d.lot_no%type, --批次号
                                 strRSV_BATCH1     in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                                 strRSV_BATCH2     in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                                 strRSV_BATCH3     in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                                 strRSV_BATCH4     in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                                 strRSV_BATCH5     in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                                 strRSV_BATCH6     in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                                 strRSV_BATCH7     in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                                 strRSV_BATCH8     in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                                 nTemperature      in idata_check_pal_tmp.temperature%type, --温度
                                 strLabelNo        in stock_label_m.label_no%type, --实体标签号
                                 strSupLabelNo     in idata_check_pal_tmp.sub_label_no%type, --子标签号
                                 strPrintType      in job_printtask_m.task_type%type, ----0:不打印；1:打印报表；2：打印标签
                                 strFixPalFlag     in idata_check_pal.Fixpal_Flag%type, --1：固定板号；2：流水板号;
                                 strBusinessType   in idata_check_pal.Fixpal_Flag%type, --业务类型：0-普通验收；1-直通验收；2-大批量验收；3-客户别；5-越库；6-B/C品
                                 strCheckType      in varchar2,
                                 strsCheckNo       out idata_check_m.s_check_no%type,
                                 strResult         out varchar2) is
    --v_iCount        integer;
    --v_strsCheckNo   idata_check_m.s_check_no%type;
    --v_strImportType idata_check_m.import_type%type;
    --v_stockType     idata_import_m.stock_type%type;
    --v_stockValue    idata_import_m.stock_value%type;
    --v_strSupplierNo idata_import_m.supplier_no%type;
    --v_nExpiryDays   bdef_defarticle.expiry_days%type;
    --v_nLotType      bdef_defarticle.lot_type%type;

    v_strLabelNoTmp    idata_check_pal_tmp.label_no%type;
    v_strSubLabelNoTmp idata_check_pal_tmp.sub_label_no%type;
    v_strContainNo     idata_check_pal.container_no%type;
    v_strSessionID     varchar2(10);
  begin
    strResult := 'N|[P_RF_SaveCheckDataIS]';

    --update by sunl 20160429
    --校验生产日期不能大于今天。
    if (dtProduceDate > sysdate) then
      strResult := 'N|[商品生产日期不能大于今天！]';
      return;
    end if;

    --混合板验收，系统自动取号
    if strFixPalFlag = '3' then
      --取标签
      pklg_wms_base.p_get_ContainerNoBase(strEnterpriseNo,
                                          strWareHouseNo,
                                          'P',
                                          strWorkerNo,
                                          'D',
                                          1,
                                          2, --标签用途
                                          '31', --容器材质(板)
                                          v_strLabelNoTmp,
                                          v_strContainNo,
                                          v_strSessionID,
                                          strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;
      v_strSubLabelNoTmp := v_strLabelNoTmp;
    else
      v_strLabelNoTmp    := strLabelNo;
      v_strSubLabelNoTmp := strSupLabelNo;
    end if;

    P_SaveCheckDataIS(strEnterpriseNo,
                      strWareHouseNo,
                      strOwnerNo,
                      strsImportNo,
                      strArticleNo,
                      strBarcode,
                      nPackingQty,
                      nCheckQty,
                      strPrinterGroupNo,
                      strDockNo,
                      strWorkerNo,
                      strCheckTools,
                      nIsAdd,
                      strQuality,
                      dtProduceDate,
                      dtExpireDate,
                      strLotNo,
                      strRSV_BATCH1,
                      strRSV_BATCH2,
                      strRSV_BATCH3,
                      strRSV_BATCH4,
                      strRSV_BATCH5,
                      strRSV_BATCH6,
                      strRSV_BATCH7,
                      strRSV_BATCH8,
                      nTemperature, --温度
                      v_strLabelNoTmp,
                      v_strSubLabelNoTmp,
                      strFixPalFlag,
                      strBusinessType,
                      strsCheckNo,
                      strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;
    --F2:扫商品扫板、F3:整单验收，则调用封板
    if strCheckType = 'F2' or strCheckType = 'F3' then
      P_RF_Close_Pal(strEnterpriseNo,
                     strWareHouseNo,
                     strOwnerNo,
                     strsImportNo,
                     strsCheckNo,
                     v_strLabelNoTmp,
                     strWorkerNo,
                     strPrintType,
                     strFixPalFlag,
                     strDockNo,
                     strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;
    end if;
    strResult := 'Y';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_RF_SaveCheckDataIS;
  /**************************************************************************************************
  功能说明：
          1、适用于天天惠的直通扫描验收数据保存。
          2、预配数量；
          3、写临时表；
   创建人：weiyufei
   创建时间：2015.6.30
  ***************************************************************************************************/
  procedure P_SCAN_IDCHECK_TTH(strEnterpriseNo   in idata_check_m.enterprise_no%type,
                               strWareHouseNo    in idata_check_m.warehouse_no%type,
                               strOwnerNo        in idata_check_m.owner_no%type,
                               strsImportNo      in idata_check_m.s_import_no%type, --进货汇总单号
                               strArticleNo      in idata_check_d.article_no%type,
                               strBarcode        in idata_check_d.barcode%type,
                               nPackingQty       in idata_check_d.packing_qty%type,
                               nCheckQty         in idata_check_d.check_qty%type,
                               strPrinterGroupNo in idata_check_m.printer_group_no%type, --工作站
                               strDockNo         in idata_check_m.dock_no%type, --码头
                               strWorkerNo       in idata_check_m.rgst_name%type, --操作人
                               strCheckTools     in idata_check_m.check_tools%type, --验收工具
                               nIsAdd            in integer, --是否累加 0:覆盖 1:累加
                               strQuality        in idata_check_d.quality%type, --品质
                               dtProduceDate     in idata_check_d.produce_date%type,
                               dtExpireDate      in idata_check_d.expire_date%type,
                               strLotNo          in idata_check_d.lot_no%type, --批次号
                               strRSV_BATCH1     in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                               strRSV_BATCH2     in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                               strRSV_BATCH3     in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                               strRSV_BATCH4     in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                               strRSV_BATCH5     in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                               strRSV_BATCH6     in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                               strRSV_BATCH7     in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                               strRSV_BATCH8     in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                               strLabelNo        in stock_label_m.label_no%type, --实体标签号
                               strSubLabelNo     in idata_check_pal_tmp.sub_label_no%type, --子标签号
                               strFixPalFlag     in idata_check_pal.Fixpal_Flag%type, --1：固定板号；2：流水板号;
                               strBusinessType   in idata_check_pal.Business_Type%type, --业务类型：0-普通验收；1-直通验收；2-大批量验收；3-客户别；5-越库；6-B/C品
                               strsCheckNo       out idata_check_m.s_check_no%type,
                               strResult         out varchar2) is
    v_strsCheckNo idata_check_m.s_check_no%type;

    v_stockType    idata_import_mm.stock_type%type;
    v_stockValue   idata_import_mm.stock_value%type;
    v_strClassType idata_import_mm.class_type%type;

    nSumPoQty      idata_import_sd.po_qty%type; --总剩余验收数量
    nAcrossQty     idata_import_sd.check_across_qty%type; --直通剩余数量
    nCurrRemainQty idata_import_sd.po_qty%type; --当前剩余验收数量

  begin
    --读取未验量,检查是否超量
    strResult := 'N|[P_SCAN_IDCHECK_TTH]';

    begin
      select stock_type, a.stock_value, a.class_type
        into v_stockType, v_stockValue, v_strClassType
        from idata_import_mm a
       where warehouse_no = strWareHouseNo
         and enterprise_no = strEnterpriseNo
         and owner_no = strOwnerNo
         and s_import_no = strsImportNo;
    exception
      when no_data_found then
        strResult := 'N|[E20903]'; --取进货汇总单信息失败
        return;
    end;

    --锁定进货汇总单头档
    update idata_import_mm mm
       set mm.status = mm.status
     where mm.warehouse_no = strWareHouseNo
       and mm.enterprise_no = strEnterpriseNo
       and mm.s_import_no = strsImportNo
       and mm.owner_no = strOwnerNo;

    --获取商品的未验收数量
    select sum(t.po_qty - t.import_qty) sumQty
      into nSumPoQty
      from idata_import_sd t
     where t.warehouse_no = strWareHouseNo
       and t.enterprise_no = strEnterpriseNo
       and t.owner_no = strOwnerNo
       and t.s_import_no = strsImportNo
       and t.article_no = strArticleNo
       and t.packing_qty = nPackingQty;

    --获取商品的直通出货数量
    select nvl(sum(t.po_qty - t.allot_qty), 0)
      into nAcrossQty
      from idata_import_allot t, idata_import_sm iis
     where t.enterprise_no = iis.enterprise_no
       and t.warehouse_no = iis.warehouse_no
       and t.owner_no = iis.owner_no
       and t.import_no = iis.import_no
       and t.warehouse_no = strWareHouseNo
       and t.owner_no = strOwnerNo
       and t.article_no = strArticleNo
       and t.packing_qty = nPackingQty
       and t.enterprise_no = strEnterpriseNo
       and iis.s_import_no = strsImportNo
       AND t.status not in ('13', '16');

    if nSumPoQty < nCheckQty then
      --暂不支持超量
      strResult := 'N|[E00022]';
      return;
    end if;

    if nCheckQty > nAcrossQty then
      nCurrRemainQty := nCheckQty - nAcrossQty;
    end if;
    --验收数量大于直通数量时，剩余部分转存储
    if nCurrRemainQty > 0 and nIsAdd = 1 then
      strResult := 'N|[已满足直通数量，请先封箱]';
      return;
    end if;
    if nAcrossQty > 0 then
      --取汇总验收单号；
      begin
        select distinct s_check_no
          into v_strsCheckNo
          from idata_check_m
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and owner_no = strOwnerNo
           and s_import_no = strsImportNo
           and status <> '13';
      exception
        when no_data_found then

          --若取不到汇总验收单号，则写验收头档；
          PKOBJ_IDATA.p_Insert_Idata_Check_M(strEnterpriseNo,
                                             strWareHouseNo,
                                             strOwnerNo,
                                             strSImportNo,
                                             strDockNo,
                                             strWorkerNo,
                                             strPrinterGroupNo,
                                             strCheckTools,
                                             v_strsCheckNo,
                                             strResult);
          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;
      end;
      --累加扫描数量
      --写临时板表；
      PKOBJ_IDATA.p_Insert_Idata_Check_Pal_Tmp(strEnterpriseNo,
                                               strWareHouseNo,
                                               strOwnerNo,
                                               strSImportNo,
                                               v_strsCheckNo,
                                               v_strClassType,
                                               strArticleNo,
                                               strQuality,
                                               dtProduceDate,
                                               dtExpireDate,
                                               strLotNo,
                                               strRSV_BATCH1,
                                               strRSV_BATCH2,
                                               strRSV_BATCH3,
                                               strRSV_BATCH4,
                                               strRSV_BATCH5,
                                               strRSV_BATCH6,
                                               strRSV_BATCH7,
                                               strRSV_BATCH8,
                                               '', --温度
                                               strBarcode,
                                               nPackingQty,
                                               nCheckQty,
                                               strLabelNo,
                                               strSubLabelNo,
                                               strBusinessType,
                                               strFixPalFlag,
                                               strPrinterGroupNo,
                                               strDockNo,
                                               v_stockType,
                                               v_stockValue,
                                               strWorkerNo,
                                               'ID',
                                               'N',
                                               strCheckTools,
                                               nIsAdd,
                                               'N',
                                               '',
                                               '',
                                               strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
    end if;
    strsCheckNo := v_strsCheckNo;
    strResult   := 'Y|成功!';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_SCAN_IDCHECK_TTH;

  /**********************************************************************************************************
     hekl
     2015.07.13
     功能：进货单据失效
     1、分整单失效、部分商品失效
  ***********************************************************************************************************/
  procedure p_idata_expired(strEnterPriseNo in fcdata_plan_m.enterprise_no%type,
                            strWareHouseNo  in fcdata_plan_m.warehouse_no%type, --仓库编码
                            strResult       OUT varchar2) is
    v_count       integer;
    v_sImportNo   idata_import_sm.s_import_no%type; --汇总进货单号
    v_sCheckNo    idata_import_sm.s_import_no%type; --汇总验收单号
    v_dock_no     idata_check_m.dock_no%type; --码头号
    v_status      idata_import_d.status%type; --状态
    v_simport_qty idata_check_pal_tmp.check_qty%type; --单据的验收数量
    v_spo_qty     idata_check_pal_tmp.check_qty%type; --单据的进货数量
  begin
    strResult := 'N|[p_idata_expired]';

    --循环过期单据
    for import_m in (select m.enterprise_no,
                            m.warehouse_no,
                            m.import_no,
                            m.request_date,
                            m.end_date
                       from idata_import_m m
                      where m.enterprise_no = strEnterPriseNo
                        and m.warehouse_no = strWareHouseNo
                        and m.status not in ('13', '16')
                        and m.order_end_date < trunc(sysdate)) loop

      --如果没有数据则还没有做预约，直接做整单失效
      begin
        select sm.s_import_no
          into v_sImportNo
          from idata_import_sm sm
         where sm.enterprise_no = strEnterPriseNo
           and sm.warehouse_no = strWareHouseNo
           and sm.import_no = import_m.import_no;
      exception
        when no_data_found then
          update idata_import_m mm
             set mm.status = '99'
           where mm.enterprise_no = strEnterPriseNo
             and mm.warehouse_no = strWareHouseNo
             and mm.import_no = import_m.import_no;
          update idata_import_d dd
             set dd.status = '99'
           where dd.enterprise_no = strEnterPriseNo
             and dd.warehouse_no = strWareHouseNo
             and dd.import_no = import_m.import_no;
          goto top;
      end;

      --判断该单据临时表是否数据,有数据直接跳出，循环下一张单
      select count(*)
        into v_count
        from idata_check_pal_tmp p
       where p.enterprise_no = strEnterPriseNo
         and p.warehouse_no = strWareHouseNo
         and p.s_import_no = v_sImportNo;

      if v_count = 0 then

        --判断该单据的import_qty
        select sum(d.import_qty), sum(d.po_qty)
          into v_simport_qty, v_spo_qty
          from idata_import_d d
         where d.enterprise_no = strEnterPriseNo
           and d.warehouse_no = strWareHouseNo
           and d.import_no = import_m.import_no;

        if v_simport_qty = 0 then
          --整单失效
          update idata_import_m mm
             set mm.status = '99'
           where mm.enterprise_no = strEnterPriseNo
             and mm.warehouse_no = strWareHouseNo
             and mm.import_no = import_m.import_no;
          update idata_import_d dd
             set dd.status = '99'
           where dd.enterprise_no = strEnterPriseNo
             and dd.warehouse_no = strWareHouseNo
             and dd.import_no = import_m.import_no;
        else
          if v_simport_qty = v_spo_qty then
            --整单验收完成，判断是否验收确认，如果没有验收确认，则自动验收确认
            select m.status, m.s_check_no, m.dock_no
              into v_status, v_sCheckNo, v_dock_no
              from idata_check_m m
             where m.enterprise_no = strEnterPriseNo
               and m.warehouse_no = strWareHouseNo
               and m.import_no = import_m.import_no;

            if v_status <> '13' then
              --自动验收确认
              PKLG_IDATA.P_Comfire_Idata_Check(strEnterPriseNo,
                                               strWareHouseNo,
                                               v_sImportNo,
                                               v_sCheckNo,
                                               'admin',
                                               'admin',
                                               v_dock_no,
                                               strResult);
              if substr(strResult, 1, 1) = 'N' then
                exit;
              end if;
            end if;

          else
            --部分验收
            for import_d in (select *
                               from idata_import_d d
                              where d.enterprise_no = strEnterPriseNo
                                and d.warehouse_no = strWareHouseNo
                                and d.import_no = import_m.import_no
                                and d.import_qty <> d.po_qty) loop
              --该商品未验收
              if import_d.import_qty = 0 then
                update idata_import_d dd
                   set dd.status = '98'
                 where dd.enterprise_no = strEnterPriseNo
                   and dd.warehouse_no = strWareHouseNo
                   and dd.import_no = import_m.import_no;
              elsif import_d.import_qty > 0 then
                --商品验收一部分
                update idata_import_d dd
                   set dd.status = '97'
                 where dd.enterprise_no = strEnterPriseNo
                   and dd.warehouse_no = strWareHouseNo
                   and dd.import_no = import_m.import_no;
              end if;

            end loop;

          end if;
        end if;

      else
        exit;
      end if;
      <<top>>
      null;
    end loop;

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_idata_expired;

  /**********************************************************************************************************
     hekl
     2015.08.01
     功能：进货单据失效,用于天天惠一单多验自动结案，不需回传ERP状态
     1、只做整单失效，对已做验收未做封箱的数据不做处理
  ***********************************************************************************************************/
  procedure p_idata_expired_tth(strEnterPriseNo in fcdata_plan_m.enterprise_no%type,
                                strWareHouseNo  in fcdata_plan_m.warehouse_no%type, --仓库编码
                                strResult       OUT varchar2) is
    v_count     integer;
    v_sImportNo idata_import_sm.s_import_no%type; --汇总进货单号
    --v_sCheckNo    idata_import_sm.s_import_no%type; --汇总验收单号
    --v_dock_no     idata_check_m.dock_no%type; --码头号
    --v_status      idata_import_d.status%type; --状态
    --v_simport_qty idata_check_pal_tmp.check_qty%type; --单据的验收数量
    --v_spo_qty     idata_check_pal_tmp.check_qty%type; --单据的进货数量
    v_strOwnerNo idata_import_sm.owner_no%type;
  begin
    strResult := 'N|[p_idata_expired]';

    --循环过期单据
    for import_m in (select m.enterprise_no,
                            m.warehouse_no,
                            m.import_no,
                            m.request_date,
                            m.end_date
                       from idata_import_m m
                      where m.enterprise_no = strEnterPriseNo
                        and m.warehouse_no = strWareHouseNo
                        and m.status not in ('13', '16')
                        and m.order_end_date < trunc(sysdate)) loop
      --如果找不到数据则该单还未做预约，直接失效
      begin
        select sm.s_import_no, sm.owner_no
          into v_sImportNo, v_strOwnerNo
          from idata_import_sm sm
         where sm.enterprise_no = strEnterPriseNo
           and sm.warehouse_no = strWareHouseNo
           and sm.import_no = import_m.import_no;
      exception
        when no_data_found then
          --整单失效
          update idata_import_m mm
             set mm.status = '13'
           where mm.enterprise_no = strEnterPriseNo
             and mm.warehouse_no = strWareHouseNo
             and mm.import_no = import_m.import_no;
          update idata_import_d dd
             set dd.status = '13'
           where dd.enterprise_no = strEnterPriseNo
             and dd.warehouse_no = strWareHouseNo
             and dd.import_no = import_m.import_no;
          update idata_import_allot ot
             set ot.status = '13'
           where ot.enterprise_no = strEnterPriseNo
             and ot.warehouse_no = strWareHouseNo
             and ot.import_no = import_m.import_no;
          goto top;
      end;

      --判断该单据临时表是否数据,有数据直接跳出，循环下一张单
      select count(*)
        into v_count
        from idata_check_pal_tmp p
       where p.enterprise_no = strEnterPriseNo
         and p.warehouse_no = strWareHouseNo
         and p.s_import_no = v_sImportNo;

      if v_count = 0 then
        --整单失效
        update idata_import_m mm
           set mm.status = '13'
         where mm.enterprise_no = strEnterPriseNo
           and mm.warehouse_no = strWareHouseNo
           and mm.import_no = import_m.import_no;
        update idata_import_d dd
           set dd.status = '13'
         where dd.enterprise_no = strEnterPriseNo
           and dd.warehouse_no = strWareHouseNo
           and dd.import_no = import_m.import_no;
        update idata_import_allot ot
           set ot.status = '13'
         where ot.enterprise_no = strEnterPriseNo
           and ot.warehouse_no = strWareHouseNo
           and ot.import_no = import_m.import_no;

        --将汇总单转历史

        PKOBJ_IDATA.P_Idata_sImportToHty(strEnterpriseNo,
                                         strWareHouseNo,
                                         v_strOwnerNo,
                                         v_sImportNo,
                                         strResult);
        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

      else
        exit;
      end if;

      <<top>>
      null;

    end loop;

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_idata_expired_tth;
  /**********************************************************************************************************
     hcx
     2015.08.17
     功能：移动台车验收-客户与电子标签储位校验
  ***********************************************************************************************************/
  procedure P_CheckDpsCellNo(strEnterpriseNo in idata_import_allot.enterprise_no%type,
                             strWarehouseNo  in idata_import_allot.warehouse_no%type,
                             strImportNo     in idata_import_allot.import_no%type,
                             strArticleNo    in idata_import_allot.article_no%type,
                             strResult       out varchar2) is
    v_strDeviceGroupNo bset_article_group_divide.device_group_no%type;
    v_Count            integer := 0;
  begin
    strResult := 'N|[P_CheckDpsCellNo]';
    begin
      select bagd.device_group_no
        into v_strDeviceGroupNo
        from bdef_defarticle bd, bset_article_group_divide bagd
       where bd.group_no = bagd.group_no
         and bd.enterprise_no = bagd.enterprise_no
         and bd.enterprise_no = strEnterpriseNo
         and bd.article_no = strArticleNo
         and bagd.warehouse_no = strWarehouseNo;
    exception
      when no_data_found then
        begin
          select ddg.device_group_no
            into v_strDeviceGroupNo
            from device_divide_group ddg
           where ddg.use_type = '1'
             and ddg.default_flag = '1'
             and ddg.warehouse_no = strWarehouseNo
             and ddg.enterprise_no = strEnterpriseNo;
        exception
          when no_data_found then
            strResult := 'N|[该商品所属类别未设置分播区]';
            return;
        end;
    end;
    begin
      select count(*)
        into v_Count
        from (select iia.cust_no
                from idata_import_allot iia
               where iia.cust_no not in
                     (select ccd.cust_no
                        from cset_cust_dpscell ccd,
                             cdef_defcell_dps  cdd,
                             device_divide_m   ddm
                       where ccd.enterprise_no = cdd.enterprise_no
                         and cdd.warehouse_no = cdd.warehouse_no
                         and ccd.dps_cell_no = cdd.cell_no
                         and cdd.enterprise_no = ddm.enterprise_no
                         and cdd.warehouse_no = ddm.warehouse_no
                         and cdd.device_no = ddm.device_no
                         and ddm.device_group_no = v_strDeviceGroupNo
                         and ccd.enterprise_no = strEnterpriseNo
                         and ccd.warehouse_no = strWarehouseNo)
                 and iia.enterprise_no = strEnterpriseNo
                 and iia.warehouse_no = strWarehouseNo
                 and iia.import_no = strImportNo
                 and iia.article_no = strArticleNo);

      if v_Count > 0 then
        strResult := 'N|[该商品有客户未设置电子标签储位]';
        return;
      end if;

    end;

    strResult := 'Y';

  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_CheckDpsCellNo;

  /**********************************************************************************************************
     sl
     2016.03.14
     功能：直通验收封板后 打印商品信息（小嘴）
  ***********************************************************************************************************/
  procedure P_IDCHECK_PRINT_ARTICLEINFO(strEnterpriseNo in idata_check_m.enterprise_no%type,
                                        strWareHouseNo  in idata_check_m.warehouse_no%type,
                                        strInstockNo    IN idata_instock_d.instock_no%type, --上架单
                                        strDockNo       in idata_check_m.dock_no%type, --码头
                                        strWorkerNo     in idata_check_m.rgst_name%type, --操作人
                                        strResult       out varchar2) IS
    v_PrintTaskNo  job_printtask_m.task_no%type;
    v_nowPrintFlag bdef_defarticle.print_flag%type; --当前的打印类型
  begin
    --strResult := 'N|[P_IDCHECK_PRINT_ARTICLEINFO]';
    v_nowPrintFlag := 'N'; --默认值N

    --这里只查询出当前有配置打印任务的商品信息，没有则跳过
    for p in (SELECT distinct a.print_flag, t.report_id, c.article_no
                FROM idata_instock_d          c,
                     bdef_defarticle          a,
                     pnt_article_group_report t,
                     stock_article_info       i
               WHERE c.owner_no = a.owner_no
                 AND c.enterprise_no = a.enterprise_no
                 AND c.article_no = a.article_no
                 AND c.enterprise_no = t.enterprise_no
                 AND a.print_flag = t.print_flag
                 AND c.enterprise_no = i.enterprise_no
                 AND c.article_no = i.article_no
                 AND c.article_id = i.article_id
                 AND c.instock_no = strInstockNo
                 AND c.warehouse_no = strWareHouseNo
                 AND c.enterprise_no = strEnterpriseNo
               ORDER BY a.print_flag ASC) LOOP
      --这里判断是否写打印任务头档
      IF (p.print_flag <> v_nowPrintFlag) THEN
        --如果打印类型不一致则新取打印任务号
        PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                   strWareHouseNo,
                                   CONST_DOCUMENTTYPE.PRINTPT,
                                   v_PrintTaskNo,
                                   strResult);
        if substr(strResult, 1, 1) <> 'Y' then
          return;
        end if;
        v_nowPrintFlag := p.print_flag;

        --写任务头档
        PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterpriseNo,
                                            strWareHouseNo,
                                            strInstockNo, --原单号写汇总验收单头档
                                            '0',
                                            p.report_id,
                                            strDockNo,
                                            '0',
                                            strWorkerNo,
                                            v_PrintTaskNo,
                                            strResult);
        if substr(strResult, 1, 1) <> 'Y' then
          return;
        end if;
      END IF;
      IF (v_PrintTaskNo IS NULL) THEN
        --如果没有配置需要打印的商品信息，则这里直接跳过
        return;
      END IF;
      --写任务明细
      PKOBJ_PRINTTASK.p_insert_taskdetail(strEnterpriseNo,
                                          strWareHouseNo,
                                          v_PrintTaskNo,
                                          p.article_no,
                                          1,
                                          1,
                                          strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;
    end loop;

    strResult := 'Y|成功!';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  END P_IDCHECK_PRINT_ARTICLEINFO;

  /*=====================================================================================
  huangb insert to 20160721
  验收差异确认
  ======================================================================================*/
  PROCEDURE p_Check_DiffConfirm(strEnterpriseNo in idata_import_m.enterprise_no%type, --企业号
                                strWarehouseNo  in idata_import_m.warehouse_no%type, --仓别
                                strOwnerNo      in idata_import_m.owner_no%type, --委托业主
                                strImportNo     in idata_import_m.import_no%type, --进货单号
                                strNewPoNo      in idata_import_m.rsv_varod3%type, --海关重新下传的进货原单号
                                strUserId       in stock_label_m.rgst_name%type, --操作人员
                                strOutMsg       out varchar2) is

    v_PoNo       idata_import_m.po_no%type; --进货原单号
    v_RrsvVarod2 idata_import_m.rsv_varod2%type; --字符预留字段 记录海关改单后的新单号 默认同po_no
    v_SendFlag   idata_import_m.send_flag%type; --导出状态 10-未导出;13-已导出
    v_DiffCount  number := 0; --当前进货单对应的汇总单下还未做差异差异确认的单据

  begin
    strOutMsg := 'N|[p_Check_DiffConfirm]';

    --判断进货单号是否存在
    begin
      select iim.po_no, nvl(iim.rsv_varod2, 'N'), iim.send_flag
        into v_PoNo, v_RrsvVarod2, v_SendFlag
        from idata_import_m iim
       where iim.enterprise_no = strEnterpriseNo
         and iim.warehouse_no = strWarehouseNo
         and iim.owner_no = strOwnerNo
         and iim.import_no = strImportNo;
    exception
      when no_data_found then
        strOutMsg := 'N|进货单[' || strImportNo || ']不存在';
        return;
    end;

    if v_SendFlag <> '13' then
      strOutMsg := 'N|采购单[' || v_PoNo || ']未导出,不允许差异确认';
      return;
    end if;

    if v_RrsvVarod2 <> v_PoNo then
      strOutMsg := 'N|采购单[' || v_PoNo || ']已经差异确认,差异确认单[' || v_RrsvVarod2 || ']';
      return;
    end if;

    --修改进货单据头档的rsv_varod2 为海关重新下传的进货原单号
    update idata_import_m iim
       set iim.rsv_varod2 = strNewPoNo,
           iim.updt_name  = strUserId,
           iim.updt_date  = sysdate
     where iim.enterprise_no = strEnterpriseNo
       and iim.warehouse_no = strWarehouseNo
       and iim.owner_no = strOwnerNo
       and iim.import_no = strImportNo;
    if sql%notfound then
      strOutMsg := 'N|修改采购单据[' || v_PoNo || ']头档信息失败(0行)';
    end if;

    --修改进货单据明细的计划量
    update idata_import_d iid
       set iid.po_qty = iid.import_qty
     where iid.enterprise_no = strEnterpriseNo
       and iid.warehouse_no = strWarehouseNo
       and iid.owner_no = strOwnerNo
       and iid.import_no = strImportNo;
    if sql%notfound then
      strOutMsg := 'N|修改采购单据[' || v_PoNo || ']明细信息失败(0行)';
    end if;

    /*如果当前单据对应的汇总单下所有进货单全部没有差异
    则 修改汇总单据的计划量*/
    select count(1)
      into v_DiffCount
      from idata_import_sm iis, idata_import_d iid
     where iid.enterprise_no = iis.enterprise_no
       and iid.warehouse_no = iis.warehouse_no
       and iid.owner_no = iis.owner_no
       and iid.import_no = iis.import_no
       and iis.enterprise_no = strEnterpriseNo
       and iis.warehouse_no = strWarehouseNo
       and iis.owner_no = strOwnerNo
       and iis.import_no <> strImportNo
       and iid.po_qty <> iid.import_qty
       and exists (select 'X'
              from idata_import_sm t
             where t.enterprise_no = iis.enterprise_no
               and t.warehouse_no = iis.warehouse_no
               and t.owner_no = iis.owner_no
               and t.s_import_no = iis.s_import_no
               and t.import_no = strImportNo);

    if v_DiffCount = 0 then
      update idata_import_sd iisd
         set iisd.po_qty = iisd.import_qty
       where iisd.enterprise_no = strEnterpriseNo
         and iisd.warehouse_no = strWarehouseNo
         and iisd.owner_no = strOwnerNo
         and exists (select 'X'
                from idata_import_sm t
               where t.enterprise_no = iisd.enterprise_no
                 and t.warehouse_no = iisd.warehouse_no
                 and t.owner_no = iisd.owner_no
                 and t.s_import_no = iisd.s_import_no
                 and t.import_no = strImportNo);
      if sql%notfound then
        strOutMsg := 'N|修改采购单据[' || v_PoNo || ']对应的汇总单明细信息失败(0行)';
      end if;
    end if;
    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_Check_DiffConfirm;

end PKLG_IDATA;

/

