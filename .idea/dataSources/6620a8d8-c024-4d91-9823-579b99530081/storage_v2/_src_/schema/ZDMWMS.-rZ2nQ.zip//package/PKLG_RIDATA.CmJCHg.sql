create package        PKLG_RIDATA is
/************************************************************************************************
   功能：集单
   日期：2015-07-03
   chensr
  *************************************************************************************************/
   procedure p_single_set(strEnterpriseNo in ridata_untread_m.enterprise_no%type,
                            strWareHouseNo  in ridata_untread_m.warehouse_no%type,
                            strUntreadNo    in ridata_untread_m.untread_no%type,
                            strsUntreadNo   in ridata_untread_mm.s_untread_no%type, --原汇总单号
                            strOutUntreadNo out ridata_untread_mm.s_untread_no%type, --返回的汇总单号
                            strResult       out varchar2);


  /**********************************************************************************
  hekl
  2015-04-07
  功能说明：返配手建单保存汇总单信息
  **********************************************************************************/
  procedure p_SaveUntread_m(strEnterpriseNo in ridata_untread_m.enterprise_no%type,
                            strWareHouseNo  in ridata_untread_m.warehouse_no%type,
                            strUntreadNo    in ridata_untread_m.untread_no%type,
                            strsUntreadNo   in ridata_untread_mm.s_untread_no%type, --原汇总单号
                            strOutUntreadNo out ridata_untread_mm.s_untread_no%type, --返回的汇总单号
                            strResult       out varchar2);
    /**********************************************************************************************************
   功能：校验能否超量验收
***********************************************************************************************************/
  procedure P_CheckExists(strEnterpriseNo           in    ridata_check_m.enterprise_no%type,--企业
                          strWareHouseNo            in    ridata_check_m.warehouse_no%type,--仓库编码
                          strOwnerNo                in    ridata_untread_m.Owner_No%type,--
                          strUntreadType            in    ridata_untread_m.untread_type%type,
                          strClassType              in    ridata_untread_mm.class_type%type,
                          strQualityFlag            in    ridata_untread_mm.quality%type,
                          strsUntreadNo             in    ridata_untread_mm.s_untread_no%type,--返配汇总单号
                          strArticleNo              in    ridata_check_d.article_no%type,--商品编码
                          nPackingQty               in    ridata_check_d.packing_qty%type,--
                          nCheckQty                 in    ridata_check_d.check_qty%type,--验收数量
                          strResult                 OUT   varchar2);
  /**********************************************************************************
  luozhiling
  2015-7-14
   功能说明：天天惠校验单号此商品是否可扫描验收
  **********************************************************************************/
  function f_CheckDevice(strEnterPriseNo in ridata_check_m.enterprise_no%type,
                         strWareHouseNo  in ridata_check_m.warehouse_no%type,
                         strsUntreadNo   in ridata_untread_sm.s_untread_no%type,
                         strStyle        in bdef_defarticle.rsv_attr2%type, --款号,若取到空，传N
                         strSupplierNo   in ridata_check_pal_tmp.supplier_no%type,
                         strDeviceNo     in ridata_check_pal_tmp.device_no%type,
                         strLabelId      in ridata_check_pal_tmp.label_id%type)
    return boolean;


 procedure P_RF_SaveCheck(strEnterPriseNo   in ridata_check_m.enterprise_no%type,
                          strWareHouseNo    in ridata_check_m.warehouse_no%type,
                          strOwnerNo        in ridata_check_m.owner_no%type,
                          strsUntreadNo     in ridata_untread_sm.s_untread_no%type,
                          strUntreadType    in ridata_untread_sm.untread_type%type,
                          strArticleNo      in ridata_check_d.article_no%type,
                          strBarcode        in ridata_check_d.barcode%type,
                          nPackingQty       in ridata_check_d.packing_qty%type,
                          nCheckQty         in ridata_check_d.check_qty%type,
                          strPrinterGroupNo in ridata_check_m.printer_group_no%type,
                          strDockNo         in ridata_check_m.dock_no%type,
                          strWorkerNo       in ridata_check_m.rgst_name%type, --验收人
                          strCheckTools     in ridata_check_m.check_tools%type,
                          nIsAdd            in integer, --是否累加 0:覆盖 1:累加
                          strQuality        in ridata_check_d.quality%type, --品质
                          dtProduceDate     in ridata_check_d.produce_date%type,
                          dtExpireDate      in Ridata_check_d.expire_date%type,
                          strLotNo          in ridata_check_d.lot_no%type, --批次号
                          strRSV_BATCH1     in ridata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                          strRSV_BATCH2     in ridata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                          strRSV_BATCH3     in ridata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                          strRSV_BATCH4     in ridata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                          strRSV_BATCH5     in ridata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                          strRSV_BATCH6     in ridata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                          strRSV_BATCH7     in ridata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                          strRSV_BATCH8     in ridata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                          strLabelNo        in stock_label_m.label_no%type,
                          strSubLabelNo     in stock_label_m.label_no%type,
                          strSupplierNo     in ridata_untread_d.supplier_no%type,
                          strFixPalFlag     in ridata_check_pal.Fixpal_Flag%type, --1：固定板号；2：流水板号;
                          strBusinessType   in ridata_check_pal.Business_Type%type, --业务类型：0-普通验收；1-直通验收；2-大批量验收；3-客户别；5-越库；6-B/C品
                          strDeviceNo       in ridata_check_pal_tmp.device_no%type, --分播墙号，若无，系统默认N
                          strCellNo         in ridata_check_pal_tmp.cell_no%type,
                          strQualityFlag    in ridata_check_pal_tmp.quality_flag%type, --品质类型0滞销品，1过季品，A质量问题，B次品
                          strBatchNo        in ridata_check_pal_tmp.batch_no%type,
                          strClassType      in ridata_untread_m.class_type%type,
                          strsCheckNo       out ridata_check_m.s_check_no%type,
                          strOutLabelNo     out ridata_check_pal_tmp.label_no%type,
                          strResult         out varchar2);

 /**********************************************************************************
  hekangli
  2015-03-09
  功能说明：返配验收数据保存
  **********************************************************************************/
 procedure P_SaveCheck(strEnterPriseNo   in ridata_check_m.enterprise_no%type,
                         strWareHouseNo    in ridata_check_m.warehouse_no%type,
                         strOwnerNo        in ridata_check_m.owner_no%type,
                         strsUntreadNo     in ridata_untread_sm.s_untread_no%type,
                         strArticleNo      in ridata_check_d.article_no%type,
                         strBarcode        in ridata_check_d.barcode%type,
                         nPackingQty       in ridata_check_d.packing_qty%type,
                         nCheckQty         in ridata_check_d.check_qty%type,
                         strPrinterGroupNo in ridata_check_m.printer_group_no%type,
                         strDockNo         in ridata_check_m.dock_no%type,
                         strWorkerNo       in ridata_check_m.rgst_name%type, --验收人
                         strCheckTools     in ridata_check_m.check_tools%type,
                         nIsAdd            in integer, --是否累加 0:覆盖 1:累加
                         strQuality        in ridata_check_d.quality%type, --品质
                         dtProduceDate     in ridata_check_d.produce_date%type,
                         dtExpireDate      in Ridata_check_d.expire_date%type,
                         strLotNo          in ridata_check_d.lot_no%type, --批次号
                         strRSV_BATCH1     in ridata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                         strRSV_BATCH2     in ridata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                         strRSV_BATCH3     in ridata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                         strRSV_BATCH4     in ridata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                         strRSV_BATCH5     in ridata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                         strRSV_BATCH6     in ridata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                         strRSV_BATCH7     in ridata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                         strRSV_BATCH8     in ridata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                         strLabeId         in ridata_check_pal_tmp.label_id%type, --
                         strLabelNo        in stock_label_m.label_no%type,
                         strSubLabelNo     in stock_label_m.label_no%type,
                         strSupplierNo     in ridata_untread_d.supplier_no%type,
                         strFixPalFlag     in ridata_check_pal.Fixpal_Flag%type, --1：固定板号；2：流水板号;3:天天惠模式
                         strBusinessType   in ridata_check_pal.Fixpal_Flag%type, --业务类型：0-普通验收；1-直通验收；2-大批量验收；3-客户别；5-越库；6-B/C品
                         strDeviceNo       in ridata_check_pal_tmp.device_no%type, --分播墙号，若无，系统默认N
                         strCellNo         in ridata_check_pal_tmp.cell_no%type,
                         strQualityFlag    in ridata_check_pal_tmp.quality_flag%type, --品质类型0滞销品，1过季品，A质量问题，B次品
                         strBatchNo        in ridata_check_pal_tmp.batch_no%type,
                         strClassType      in ridata_untread_m.class_type%type,
                         strsCheckNo       out ridata_check_m.s_check_no%type,
                         strResult         out varchar2);

  /*********************************************************************************************************************
   luozhiling
   2015.7.15
   功能说明：1、校验商品对应的供应商是否有设置资源，有继续，若无，系统拦截
             2、返配验收保存
  *********************************************************************************************************************/
  procedure P_SaveCheckTTH(strEnterPriseNo   in ridata_check_m.enterprise_no%type,
                           strWareHouseNo    in ridata_check_m.warehouse_no%type,
                           strOwnerNo        in ridata_check_m.owner_no%type,
                           strUntreadType    in  ridata_untread_m.untread_type%type,
                           strsUntreadNo     in ridata_untread_sm.s_untread_no%type,
                           strArticleNo      in ridata_check_d.article_no%type,
                           strBarcode        in ridata_check_d.barcode%type,
                           nPackingQty       in ridata_check_d.packing_qty%type,
                           nCheckQty         in ridata_check_d.check_qty%type,
                           strPrinterGroupNo in ridata_check_m.printer_group_no%type,
                           strDockNo         in ridata_check_m.dock_no%type,
                           strWorkerNo       in ridata_check_m.rgst_name%type, --验收人
                           strCheckTools     in ridata_check_m.check_tools%type,
                           nIsAdd            in integer, --是否累加 0:覆盖 1:累加
                           strQuality        in ridata_check_d.quality%type, --品质
                           dtProduceDate     in ridata_check_d.produce_date%type,
                           dtExpireDate      in Ridata_check_d.expire_date%type,
                           strLotNo          in ridata_check_d.lot_no%type, --批次号
                           strRSV_BATCH1     in ridata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                           strRSV_BATCH2     in ridata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                           strRSV_BATCH3     in ridata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                           strRSV_BATCH4     in ridata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                           strRSV_BATCH5     in ridata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                           strRSV_BATCH6     in ridata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                           strRSV_BATCH7     in ridata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                           strRSV_BATCH8     in ridata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                           strLabelNo        in stock_label_m.label_no%type,
                           strSubLabelNo     in stock_label_m.label_no%type,
                           strSupplierNo     in ridata_untread_d.supplier_no%type,
                           strFixPalFlag     in ridata_check_pal.Fixpal_Flag%type, --1：固定板号；2：流水板号;3:天天惠模式
                           strBusinessType   in ridata_check_pal.Fixpal_Flag%type, --业务类型：0-普通验收；1-直通验收；2-大批量验收；3-客户别；5-越库；6-B/C品
                           strDeviceNo       in ridata_check_pal_tmp.device_no%type, --分播墙号，若无，系统默认N
                           strLabelId        in ridata_check_pal_tmp.label_id%type, --扫描墙号
                           strStyle          in ridata_box.style%type, --款号，若无，记为N
                           strCellNo         in cdef_defcell.cell_no%type, --指定储位，若无指定储位，传N
                           strClassType      in ridata_untread_mm.class_type%type, --0:存储,1:清场
                           strQualityFlag    in ridata_check_pal_tmp.quality_flag%type, --品质类型0滞销品，1过季品，A质量问题，B次品
                           strsCheckNo       out ridata_check_m.s_check_no%type,
                           strResult         out varchar2);
  /**************************************************************************************************
    luozhiling
    2013.12.19
    功能说明：返配验收、定位、上架发单
  **************************************************************************************************/
  procedure P_SaveClosePal_main(strEnterPriseNo in ridata_check_pal_tmp.enterprise_no%type,
                              strWareHouseNo  in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                              strOwnerNo      in ridata_check_pal_tmp.owner_no%type, --委托业主编码
                              strsUntreadNo   in ridata_untread_sm.s_untread_no%type, --进货汇总单号
                              strUntreadType  in ridata_untread_m.untread_type%type,
                              strClassType    in ridata_untread_m.class_type%type,
                              strQualityFlag  in ridata_untread_m.quality%type,
                              strsCheckNo     in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                              strLabelNo      in ridata_check_pal_tmp.label_no%type, --板号
                              strWorkerNo     in ridata_check_pal_tmp.rgst_name%type, --操作人
                              strDockNo       iN ridata_check_m.dock_no%type,
                              strPrintFlag    in job_printtask_m.back_flag%type,--打印标识，0：不打印，1：打印表单，2：打印标签
                              strResult       out varchar2) ;

/******************************************************************************************************
 功能说明：天天惠封箱
           1、根据类型判断封箱
           A、质量问题、清场商品、滞销品按标签做封箱，
           B、过季品按标签做封箱，但需要指定储位，并系统自动上架回单
*******************************************************************************************************/
 procedure P_TTHClosePal_Main(strEnterPriseNo      in ridata_check_pal_tmp.enterprise_no%type,
                                 strWareHouseNo       in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                 strOwnerNo           in ridata_check_pal_tmp.owner_no%type, --委托业主编码
                                 strUntreadType       in ridata_untread_m.untread_type%type,
                                 strClassType         in ridata_untread_m.class_type%type,
                                 strQualityFlag       in ridata_untread_m.quality%type,
                                 strsUntreadNo        in ridata_untread_sm.s_untread_no%type, --进货汇总单号
                                 strsCheckNo          in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                 strLabelNo           in ridata_check_pal_tmp.label_no%type, --板号
                                 strWorkerNo          in ridata_check_pal_tmp.rgst_name%type, --操作人
                                 strDockNo            iN ridata_check_m.dock_no%type,
                                 strDestCellNo        in cdef_defcell.cell_no%type,--指定储位，若无，传N
                                 strPrintFlag         in job_printtask_m.back_flag%type,--打印标识，0：不打印，1：打印表单，2：打印标签
                                 strResult            out varchar2);

  /**************************************************************************************************
   luozhiling
   2015.7.15
   功能说明：1、对扫描墙进行封箱
  **************************************************************************************************/
  procedure P_DeviceCloseBox_Main(strEnterPriseNo in ridata_check_pal_tmp.enterprise_no%type,
                                  strWareHouseNo  in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                  strOwnerNo      in ridata_check_pal_tmp.owner_no%type, --委托业主编码
                                  strDeviceNo     in ridata_box.device_no%type, --扫描墙号
                                  strWaveNo       in ridata_box.wave_no%type, --波次号
                                  strWorkerNo     in ridata_check_pal_tmp.rgst_name%type, --操作人
                                  strDockNo       iN ridata_check_m.dock_no%type,
                                  strQualityFlag  in ridata_box.quality%type, --0,正常，1过季，A，质量问题，B次品
                                  strDestCellNo   in cdef_defcell.cell_no%type, --指定储位，若无，传N
                                  strResult       out varchar2);
/**************************************************************************************************
  luozhiling
  2014.6.20
  功能说明：1、固定板号封板，定位并上架
            2、适用于一箱对应多张返配汇总单的情况
            3、目前天天惠在用，用于对某箱号做封箱并上架上架定位、发单
**************************************************************************************************/
 procedure P_ClosePalDivide_main(strEnterPriseNo      in ridata_check_pal_tmp.enterprise_no%type,
                                 strWareHouseNo       in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                 strOwnerNo           in ridata_check_pal_tmp.owner_no%type, --委托业主编码
                                 strsUntreadNo        in ridata_untread_sm.s_untread_no%type, --进货汇总单号
                                 strUntreadType       in ridata_untread_m.untread_type%type,
                                 strClassType         in ridata_untread_m.class_type%type,
                                 strQualityFlag       in ridata_untread_m.quality%type,
                                 strsCheckNo          in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                 strLabelNo           in ridata_check_pal_tmp.label_no%type, --板号
                                 strWorkerNo          in ridata_check_pal_tmp.rgst_name%type, --操作人
                                 strDockNo            iN ridata_check_m.dock_no%type,
                                 strDestCellNo        in cdef_defcell.cell_no%type,--指定储位，若无，传N
                                 strPrintFlag         in job_printtask_m.back_flag%type,--打印标识，0：不打印，1：打印表单，2：打印标签
                                 strResult            out varchar2);

  /**************************************************************************************************
    luozhiling
    2014.6.20
    功能说明：返配验收，按品质分板，定位并上架
  **************************************************************************************************/
  procedure P_ClosePalQuality_main(strEnterPriseNo in ridata_check_pal_tmp.enterprise_no%type,
                                   strWareHouseNo  in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                   strOwnerNo      in ridata_check_pal_tmp.owner_no%type, --委托业主编码
                                   strsUntreadNo   in ridata_untread_sm.s_untread_no%type, --进货汇总单号
                                   strsCheckNo     in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                   strLabelNo      in ridata_check_pal_tmp.label_no%type, --板号
                                   strWorkerNo     in ridata_check_pal_tmp.rgst_name%type, --操作人
                                   strDestCellNo   in cdef_defcell.cell_no%type,
                                   strDockNo       iN ridata_check_m.dock_no%type,
                                   strResult       out varchar2);

  /*************************************************************************************************
  创建人：luozhiling
  创建时间：2015.7.20
  功能说明：次品仓指定储位验收、上架
            1、按单做验收保存；
            2、一张单对应一张标签；
            3、按单写定位指示、上架定位
            4、上架发单；
            5、自动上架回单；
            6、对返配单对应的验收单做验收确认
  ***************************************************************************************************/
  procedure P_BadGoodSaveCheck_Instock(strEnterpriseNo in ridata_check_pal_tmp.enterprise_no%type,
                                       strWareHouseNo  in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                       strOwnerNo      in ridata_check_pal_tmp.owner_no%type, --委托业主编码
                                       strsUntreadNo   in ridata_check_m.s_untread_no%type, --进货汇总单号
                                       strsCheckNo     in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                       strCellNo       in ridata_locate_direct.cell_no%type, --板号
                                       strDockNo       in ridata_check_m.dock_no%type,
                                       strWorkerNo     in ridata_check_pal_tmp.rgst_name%type, --操作人
                                       strResult       out varchar2);

 /****************************************************************************************************
 功能说明：1、返配发单；
           2、根据返配单据类型判断是否需要自动回单
  luozhiling
 ****************************************************************************************************/
 procedure SendInstockTaskAndComfire(strEnterPriseNo       in ridata_check_m.enterprise_no%type,
                                    strWareHouseNo        in ridata_instock_direct.warehouse_no%type, --仓别
                                    strOwnerNo            in ridata_instock_direct.owner_no%type,
                                    strUntreadType        in ridata_untread_m.untread_type%type,
                                    strClassType          in ridata_untread_m.class_type%type,
                                    strQualityFlag        in ridata_untread_m.quality%type,
                                    strWorkerNo           in ridata_instock_direct.rgst_name%type, --操作人
                                    strLocateNo           in ridata_instock_direct.locate_no%type,
                                    strDockNo             in ridata_check_m.dock_no%type,
                                    strPrintFlag          in job_printtask_m.reprint_flag%type,--打印标识，0：不打印，1：打印标签，打印表单
                                    strInstockNo          out ridata_instock_d.instock_no%type, --上架单号
                                    strResult             out varchar2);

  /**************************************************************************************************
  创建人：luozhiling
  创建日期:2015.7.20
  功能说明：整单上架回单
  ***************************************************************************************************/
  procedure P_saveInstockAll(strEnterpriseNo in Ridata_instock_m.enterprise_no%type,
                             strWarehouseNo  in Ridata_instock_m.warehouse_no%type,
                             strInstockNo    in Ridata_instock_m.instock_no%type,
                             strUserId       in Ridata_instock_m.rgst_name%type, --上架人
                             strPaperUserId  in Ridata_instock_m.rgst_name%type, --回单人
                             strTools        in stock_content_move.terminal_flag%type,
                             strResult       out varchar2);
/*****************************************************************************************************
 功能说明：返配上架取消：
           1、将整单做上架回单，
           2、将差异部分库存转移到质量问题差异区
  创建人：luozhiling
  日期：2015-12-27
*****************************************************************************************************/
 procedure P_InstockCancel(strEnterpriseNo in Ridata_instock_m.enterprise_no%type,
                             strWarehouseNo  in Ridata_instock_m.warehouse_no%type,
                             strInstockNo    in Ridata_instock_m.instock_no%type,
                             strUserId       in Ridata_instock_m.rgst_name%type, --上架人
                             strPaperUserId  in Ridata_instock_m.rgst_name%type, --回单人
                             strTools        in stock_content_move.terminal_flag%type,
                             strResult       out varchar2);
  /************************************************************************************************
  luozhiling
  2013-10-10
  说明：根据临时板明细写验收数据,不超品、超量

  ***********************************************************************************************/
  procedure p_MixAmount(strEnterPriseNo in ridata_check_pal_tmp.enterprise_no%type,
                        strWareHouseNo  in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                        strOwnerNo      in ridata_check_pal_tmp.owner_no%type, --委托业主
                        strsUntreadNo   in ridata_check_pal_tmp.s_untread_no%type, --返配汇总单号
                        strUntreadType        in ridata_untread_m.untread_type%type,
                        strClassType          in ridata_untread_m.class_type%type,
                        strQualityFlag        in ridata_untread_m.quality%type,
                        strSCheckNo     in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                        strLabelNo      in ridata_check_pal_tmp.label_no%type, --扫描的原板号，若没有默认N
                        strNewLabelNo   in ridata_check_pal_tmp.label_no%type, --新取板号，流水板验收时用
                        strContainerNo  in ridata_check_pal_tmp.label_no%type,
                        nCheckQty       in ridata_check_pal_tmp.check_qty%type,
                        nRowId          in ridata_check_pal_tmp.row_id%type,
                        strWorkerNo     in ridata_check_pal_tmp.rgst_name%type, --操作人
                        strResult       out varchar2);
  /***********************************************************************************************8

     作者:luozhiling
     日期:  2013-11-12
     功能: 返配验收时，将临时板明细的数据转移到验收数据里，按品质产生板号
  *************************************************************************************************/
  procedure P_CheckSplitPal(strEnterPriseNo in ridata_check_pal_tmp.enterprise_no%type,
                            strWareHouseNo  in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                            strOwnerNo      in ridata_check_pal_tmp.owner_no%type, --委托业主编码
                            strsUntreadNo   in ridata_untread_sm.s_untread_no%type, --进货汇总单号
                            strsCheckNo     in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                            strLabelNo      in ridata_check_pal_tmp.label_no%type, --板号
                            strWorkerNo     in ridata_check_pal_tmp.rgst_name%type, --操作人
                            strResult       out varchar2);
  /***********************************************************************************************8
     作者:luozhiling
     日期:  2014-6-20
     功能: 返配验收封箱时，检查是否需要释放资源
  *************************************************************************************************/
  procedure P_ReleaseDevice(strEnterPriseNo in ridata_check_pal_tmp.enterprise_no%type,
                            strWareHouseNo  in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                            strLabelNo      in ridata_check_pal_tmp.label_no%type, --板号
                            strLabelId      in ridata_check_pal_tmp.label_id%type, --扫描墙储位（箱序号）
                            strDeviceNo     in ridata_check_pal_tmp.device_no%type, --扫描墙号
                            strUserID       in ridata_check_m.updt_name%type,
                            strResult       out varchar2);
  /***********************************************************************************************8
     作者:luozhiling
     日期:  2014-6-20
     功能: 返配验收时，将临时板明细的数据转移到验收数据里，一板对应多汇总单,
     此过程适用于固定板号收货，同一容器内不区分品质
  *************************************************************************************************/
  procedure P_CheckFixPal(strEnterPriseNo in ridata_check_pal_tmp.enterprise_no%type,
                          strWareHouseNo  in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                          strOwnerNo      in ridata_check_pal_tmp.owner_no%type, --委托业主编码
                          strsUntreadNo   in ridata_untread_sm.s_untread_no%type, --进货汇总单号
                          strsCheckNo     in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                          strLabelNo      in ridata_check_pal_tmp.label_no%type, --板号
                          strWorkerNo     in ridata_check_pal_tmp.rgst_name%type, --操作人
                          strResult       out varchar2);
  /***********************************************************************************************
  修改人:luozhiling
  日期:2013-11-4
  功能：根据验收汇总单写标签数据、定位指示和库存
  ************************************************************************************************/
  procedure p_sCheckLocate(strEnterPriseNo    in stock_label_m.enterprise_no%type,
                           strWareHouseNo     in stock_label_m.warehouse_no%type, --仓别
                           strScheckNo        in ridata_check_m.s_check_no%type, --汇总验收单号
                           strUser_ID         in stock_label_m.Rgst_Name%type, --操作人员
                           strCheckTool       in ridata_check_pal_tmp.check_tools%type, --验收工具
                           strspecify_cell_no in ridata_locate_direct.specify_cell_no%type, --指定储位
                           strLocateNo        OUT ridata_locate_direct.locate_no%type,
                           strOutMsg          out varchar2);
  /*************************************************************************************************
       修改人：luozhiling
       日期：2013-10-20
       功能：上架回单

  *************************************************************************************************/
  procedure P_SaveInstock(strEnterPriseNo  in ridata_instock_m.enterprise_no%type,
                          strWareHouseNo   in Ridata_instock_m.warehouse_no%type,
                          strInstockNo     in Ridata_instock_m.instock_no%type,
                          strDestCellNo    in Ridata_instock_d.dest_cell_no%type,
                          strInstockCellNo in Ridata_instock_d.real_cell_no%type,
                          strLabelNo       in Ridata_instock_d.label_no%type,
                          strArticleNo     in Ridata_instock_d.article_no%type,
                          dtProduceDate    in stock_article_info.produce_date%type,
                          nPackingQty      in Ridata_instock_d.packing_qty%type,
                          nRealQty         in Ridata_instock_d.real_qty%type,
                          strUserId        in Ridata_instock_m.rgst_name%type, --上架人
                          strPaperUserId   in Ridata_instock_m.rgst_name%type, --回单人
                          strTools         in stock_content_move.terminal_flag%type,
                          strResult        out varchar2);
  /*************************************************************************************************
       修改人：luozhiling
       日期：2013-10-20
       功能：电子标签更新上架明细

  *************************************************************************************************/
  procedure P_UpdateDPSInstockitem(strEnterPriseNo in ridata_instock_m.enterprise_no%type,
                                   strWareHouseNo  in Ridata_instock_m.warehouse_no%type,
                                   strInstockNo    in Ridata_instock_m.instock_no%type,
                                   strLabelNo      in Ridata_instock_d.label_no%type,
                                   strArticleNo    in Ridata_instock_d.article_no%type,
                                   strBarcode      in stock_article_info.barcode%type,
                                   nPackingQty     in Ridata_instock_d.packing_qty%type,
                                   nRealQty        in Ridata_instock_d.real_qty%type,
                                   strUserId       in Ridata_instock_m.rgst_name%type, --上架人
                                   strPaperUserId  in Ridata_instock_m.rgst_name%type, --回单人
                                   strTools        in stock_content_move.terminal_flag%type,
                                   strResult       out varchar2);

  /*************************************************************************************************
       修改人：luozhiling
       日期：2014-6-20
       功能：电子标签上架回单
  *************************************************************************************************/

  procedure P_DpsComfireInstock(strEnterPriseNo   in ridata_instock_m.enterprise_no%type,
                                strWareHouseNo    in Ridata_instock_m.warehouse_no%type,
                                strInstockCellNo  in Ridata_instock_d.label_no%type,
                                strUserId         in Ridata_instock_m.rgst_name%type, --上架人
                                strPaperUserId    in Ridata_instock_m.rgst_name%type, --回单人
                                strTools          in stock_content_move.terminal_flag%type,
                                strPrinterGroupNo in ridata_check_m.printer_group_no%type,
                                strResult         out varchar2);
 /*************************************************************************************************
     修改人：luozhiling
     日期：2013-10-20
     功能：验收确认,一单一验，可直接对返配单做结案,按汇总单做确认，需考虑一张汇总单对应多张验收单的情况

*************************************************************************************************/
  procedure P_comfireCheck(strEnterPriseNo       in     ridata_untread_m.enterprise_no%type,
                           strWAREHOUSE_NO       in     ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码)
                           strS_untread_no       in     ridata_untread_sm.s_untread_no%type, --进货汇总单号
                           strUntreadType        in     ridata_untread_m.untread_type%type,
                           strClassType          in     ridata_untread_m.class_type%type,
                           strQualityFlag        in     ridata_untread_m.quality%type,
                           strOwnerNo            in     ridata_untread_m.owner_no%type,
                           strS_Check_no         in     ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                           strWorkerNo           in     ridata_check_pal_tmp.rgst_name%type, --操作人
                           strDockNo             in     ridata_check_m.dock_no%type,
                           strComfirFlag         in     ridata_check_m.check_tools%type,--强制做验收确认，做验收确认操作是传1，验收保存带确认时传0
                           strResult             Out    varchar2);
  /***********************************************************************************************
  修改人:luozhiling
  日期:2014-6-20
  功能：根据板明细写标签数据、库存，采用分播墙的方式，写分播数据
  ************************************************************************************************/
  procedure p_LabelLocate(strEnterPriseNo in stock_label_m.enterprise_no%type,
                          strWareHouseNo  in stock_label_m.warehouse_no%type, --仓别
                          strLabelNo      in ridata_check_m.s_check_no%type, --汇总验收单号
                          strUser_ID      in stock_label_m.Rgst_Name%type, --操作人员
                          strCheckTool    in ridata_check_pal_tmp.check_tools%type, --验收工具
                          strPrintFlag    in ridata_check_m.check_tools%type, --是否打印：0：不打印，1：打印
                          strDestCellNo   in ridata_check_pal.cell_no%type, --指定上架储位
                          strLocateNo     OUT ridata_locate_direct.locate_no%type,
                          strOutMsg       out varchar2);

  /***********************************************************************************************
  修改人:luozhiling
  日期:2014-6-21
  功能：获取返配验收箱标签号
  ************************************************************************************************/
  procedure P_GetLabelNo(strEnterPriseNo in ridata_untread_m.enterprise_no%type,
                         strWarehouseNo  in ridata_untread_m.warehouse_no%type,
                         strSupplierNo   in ridata_untread_d.supplier_no%type,
                         strWorkerNo     in ridata_check_pal_tmp.rgst_name%type,
                         strDockNo       in ridata_check_pal_tmp.dock_no%type,
                         dtOperateDate   in cset_cell_supplier.operate_date%type,
                         strLabelId      out ridata_check_pal_tmp.label_no%type,
                         strLaebelNo     out stock_label_m.label_no%type,
                         strResult       out varchar2);

  /*=====================================================================================
   insert to 20140621
  返配供应商分配储位
  ======================================================================================*/
  PROCEDURE p_RI_SupperAllotCell(strEnterPriseNo in ridata_untread_sm.enterprise_no%type,
                                 strwarehouse_no in ridata_untread_sm.warehouse_no%type, --仓别
                                 strowner_no     in ridata_untread_sm.owner_no%type,
                                 strSUntreadNo   in ridata_untread_sm.s_untread_no%type, --返配汇总单号
                                 strDockNo       in ridata_check_m.dock_no%type, --扫描台
                                 strDeviceNo     in device_divide_m.device_no%type, --扫描墙号
                                 strUser_Id      in ridata_untread_sm.rgst_name%type, --操作人员
                                 strQuality      in ridata_untread_d.quality%type, --界面传入的品质类型,不传默认为‘N';如果不为'N',那么根据传入值进行判断。
                                 strBoxCount     out integer, --需要的物流箱数目
                                 strFinishBox    out varchar2,
                                 strOutMsg       out varchar2);

  --*********************************************************************************
  --获取扫描墙格子号信息
  --*********************************************************************************
  PROCEDURE p_GET_SCAN_LABEL_ID(strEnterPriseNo in ridata_untread_sm.enterprise_no%type,
                                strwarehouse_no in ridata_untread_sm.warehouse_no%type, --仓别
                                strowner_no     in ridata_untread_sm.owner_no%type,
                                strSUntreadNo   in ridata_untread_sm.s_untread_no%type, --返配汇总单号
                                strDeviceNo     in device_divide_m.device_no%type, --扫描墙号
                                strArticleNo    in ridata_untread_d.article_no%type,
                                strWave_no      in ridata_untread_mm.wave_no%type,
                                --strStyle        in bdef_defarticle.rsv_strategy2%type,
                                strlabel_id out ridata_box.label_id%type, --需要的物流箱数目
                                strOutMsg   out varchar2);
  /*************************************************************************************************
       修改人：hekl
       日期：2015-07-23
       功能：对次品和过季品做品质转换（天天惠）
  *************************************************************************************************/
  procedure P_QUALITY_CHANGETTH(strEnterPriseNo in ridata_untread_m.enterprise_no%type,
                                strWAREHOUSE_NO in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码)
                                strS_untread_no in ridata_untread_sm.s_untread_no%type, --进货汇总单号
                                strS_Check_no   in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                strWorkerNo     in ridata_check_pal_tmp.rgst_name%type, --操作人
                                strDockNo       in ridata_check_m.dock_no%type,
                                strResult       Out varchar2);
  /*************************************************************************************************
       修改人：hekl
       日期：2015-07-23
       功能：1、对次品和过季品做品质转换（天天惠）
             2、验收确认,一单一验，可直接对返配单做结案
  *************************************************************************************************/
  procedure P_comfireCheckTTH(strEnterPriseNo       in     ridata_untread_m.enterprise_no%type,
                           strWAREHOUSE_NO       in     ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码)
                           strS_untread_no       in     ridata_untread_sm.s_untread_no%type, --进货汇总单号
                           strUntreadType        in     ridata_untread_m.untread_type%type,
                           strClassType          in     ridata_untread_m.class_type%type,
                           strQualityFlag        in     ridata_untread_m.quality%type,
                           strOwnerNo            in     ridata_untread_m.owner_no%type,
                           strS_Check_no         in     ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                           strWorkerNo           in     ridata_check_pal_tmp.rgst_name%type, --操作人
                           strDockNo             in     ridata_check_m.dock_no%type,
                           strComfirFlag         in     ridata_check_m.check_tools%type,--强制做验收确认，做验收确认操作是传1，验收保存带确认时传0
                           strResult             Out    varchar2);

  procedure P_CheckDpsDeviceNo(strEnterPriseNo in ridata_untread_m.enterprise_no%type,
                               strWAREHOUSE_NO in ridata_untread_m.WAREHOUSE_NO%type, --仓库编码)
                               strDpsArea      in cdef_defcell_dps.dps_area%type, --电子标签小区
                               strStockNo      in cdef_defcell_dps.stock_no%type,
                               strUseType      in cdef_defcell_dps.use_type%type,
                               strCtrlNo       in cdef_defcell_dps.ctrl_no%type, --控制箱号
                               strLabelNo      in ridata_instock_d.label_no%type, --分播标签号
                               strResult       Out varchar2);

  procedure Proc_RIData_Locate_Tmp(strEnterpriseNo in ridata_untread_m.enterprise_no%type,
                                   strWarehouseNo  in ridata_untread_m.warehouse_no%type,
                                   strOwnerNo      in ridata_untread_m.owner_no%type,
                                   strSUntreadNo   in ridata_untread_mm.s_untread_no%type,
                                   strOutMsg       out varchar2);

   /********************************************************************************************
   功能说明：特殊的返配验收封箱、上架定位、发单和自动回单
             此流程是特殊流程，不根据系统配置来处理

   ********************************************************************************************/
   procedure P_SpecialCloseBoxAndInstock(strEnterPriseNo in ridata_check_pal_tmp.enterprise_no%type,
                                strWareHouseNo  in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                strOwnerNo      in ridata_check_pal_tmp.owner_no%type, --委托业主编码
                                strsUntreadNo   in ridata_check_m.s_untread_no%type, --进货汇总单号
                                strsCheckNo     in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                strLabelNo      in ridata_check_pal_tmp.label_no%type, --板号
                                strWorkerNo     in ridata_check_pal_tmp.rgst_name%type, --操作人
                                strDestCellNo   in cdef_defcell.cell_no%type,
                                strDockNo       iN ridata_check_m.dock_no%type,
                                strPrintFlag    in job_printtask_m.back_flag%type,--打印标识，0：不打印，1：打印表单，2：打印标签
                                strResult       out varchar2);
/*************************************************************************************************
     修改人：luozhiling
     日期：2013-10-20
     功能：上架回单

*************************************************************************************************/
  procedure P_SpecialSaveInstock(strEnterPriseNo          in      ridata_instock_m.enterprise_no%type,
                          strWareHouseNo           in      Ridata_instock_m.warehouse_no%type,
                          strInstockNo             in      Ridata_instock_m.instock_no%type,
                          strDestCellNo            in      Ridata_instock_d.dest_cell_no%type,
                          strInstockCellNo         in      Ridata_instock_d.real_cell_no%type,
                          strLabelNo               in      Ridata_instock_d.label_no%type,
                          strArticleNo             in      Ridata_instock_d.article_no%type,
                          dtProduceDate            in      stock_article_info.produce_date%type,
                          nPackingQty              in      Ridata_instock_d.packing_qty%type,
                          nRealQty                 in      Ridata_instock_d.real_qty%type,
                          strUserId                in      Ridata_instock_m.rgst_name%type,--上架人
                          strPaperUserId           in      Ridata_instock_m.rgst_name%type,--回单人
                          strTools                 in      stock_content_move.terminal_flag%type,
                          strResult                out     varchar2);
  /*********************************************************************************************
  功能说明：校验封箱储位是否合法

  *********************************************************************************************/
  procedure P_CheckCloseBoxCell(strEnterPriseNo in ridata_check_pal_tmp.enterprise_no%type,
                                strWareHouseNo  in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                strOwnerNo      in ridata_check_pal_tmp.owner_no%type, --委托业主编码
                                strsUntreadNo   in ridata_check_m.s_untread_no%type, --进货汇总单号
                                strsCheckNo     in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                strDestCellNo   in cdef_defcell.cell_no%type,
                                strResult       out varchar2);
   /**************************************************************************************************
  创建人：luozhiling
  创建日期:2015.7.20
  功能说明：整单指定储位上架回单
  ***************************************************************************************************/
  procedure P_LocateCellsaveInstockAll(   strEnterpriseNo   in Ridata_instock_m.enterprise_no%type,
                                strWarehouseNo    in Ridata_instock_m.warehouse_no%type,
                                strInstockNo      in Ridata_instock_m.instock_no%type,
                                strUserId         in Ridata_instock_m.rgst_name%type, --上架人
                                strPaperUserId    in Ridata_instock_m.rgst_name%type, --回单人
                                strInstockCellNo  in cdef_defcell.cell_no%type,
                                strTools          in stock_content_move.terminal_flag%type,
                                strResult         out varchar2);
  /***********************************************************************************************
  修改人:hcx
  日期:2016-3-1
  功能：审空单
  ************************************************************************************************/
  procedure P_ComfireEmptyList(
                               strEnterpriseNo  in    ridata_untread_m.enterprise_no%type,
                               strWareHouseNo   in    ridata_untread_m.warehouse_no%type,
                               strOwnerNo       in    ridata_untread_m.owner_no%type,
                               strSUntreadNo    in    ridata_untread_mm.s_untread_no%type,
                               strUntreadNo     in    ridata_untread_m.untread_no%type,
                               strUserId        in    ridata_untread_m.rgst_name%type,
                               strResult        out   varchar2);
end PKLG_RIDATA;


/

