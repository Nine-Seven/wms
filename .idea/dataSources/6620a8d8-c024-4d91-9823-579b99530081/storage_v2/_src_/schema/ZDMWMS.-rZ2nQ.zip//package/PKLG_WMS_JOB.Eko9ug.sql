create package        PKLG_WMS_JOB is
  -- Created : 2016/6/21 10:38:38

--后台管理调用存储过程程序
procedure p_wmsJobConfig(strOutMsg          out varchar2);


end PKLG_WMS_JOB;


/

