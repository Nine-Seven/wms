create PACKAGE BODY PKLG_ODISPATCH IS

  /*****************************************************************************************
     功能：取指定出货单对应的区域（多区域返回空）
    MODIFY BY JUN 2016-06-20
  *****************************************************************************************/
  FUNCTION F_GETAREABYEXPNO(STRENTERPRISE   IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                            STRWAREHOUSE_NO IN ODATA_LOCATE_M.WAREHOUSE_NO%TYPE, --仓别
                            STROWNERNO      IN ODATA_LOCATE_M.OWNER_NO%TYPE, --货主
                            STREXPNO        IN ODATA_LOCATE_D.EXP_NO%TYPE --出货单号
                            ) RETURN VARCHAR2 IS
    V_AREA   VARCHAR(15);
		V_AREAS  VARCHAR2(500);--记录区域值
    V_ROWNUM NUMBER(4);
  BEGIN
    V_ROWNUM := 0;
		V_AREAS := '';

    FOR Q IN (SELECT *
                FROM ODATA_EXP_D D
               WHERE D.WAREHOUSE_NO = STRWAREHOUSE_NO
                 AND D.ENTERPRISE_NO = STRENTERPRISE
                 AND D.OWNER_NO = STROWNERNO
                 AND D.EXP_NO = STREXPNO) LOOP
      SELECT CA.AREA_NO
        INTO V_AREA
        FROM (SELECT DISTINCT D.ENTERPRISE_NO,
                     D.WAREHOUSE_NO,
                     D.OWNER_NO,
                     NVL(NVL(AA.CELL_NO, BB.CELL_NO), CC.CELL_NO) CELL_NO
                FROM ODATA_EXP_D D,
                     (SELECT A.ENTERPRISE_NO,
                             A.WAREHOUSE_NO,
                             A.OWNER_NO,
                             A.ARTICLE_NO,
                             A.CELL_NO
                        FROM CSET_CELL_ARTICLE A
                       WHERE A.WAREHOUSE_NO = STRWAREHOUSE_NO
                         AND A.ENTERPRISE_NO = STRENTERPRISE
                         AND A.OWNER_NO = STROWNERNO
                         AND A.ARTICLE_NO = Q.ARTICLE_NO
                         AND ROWNUM = 1) AA,
                     (SELECT S.ENTERPRISE_NO,
                             S.WAREHOUSE_NO,
                             S.OWNER_NO,
                             S.ARTICLE_NO,
                             S.CELL_NO
                        FROM STOCK_CONTENT S, CDEF_DEFCELL C, CDEF_DEFAREA CA
                       WHERE S.ENTERPRISE_NO = C.ENTERPRISE_NO
                         AND S.WAREHOUSE_NO = C.WAREHOUSE_NO
                         AND S.CELL_NO = C.CELL_NO
                         AND C.WAREHOUSE_NO = CA.WAREHOUSE_NO
                         AND C.ENTERPRISE_NO = CA.ENTERPRISE_NO
                         AND C.AREA_NO = CA.AREA_NO
                         AND C.WARE_NO = CA.WARE_NO
                         AND CA.AREA_ATTRIBUTE = '0'
                         AND CA.ATTRIBUTE_TYPE = '0'
                         AND CA.AREA_PICK = '1'
                         AND S.WAREHOUSE_NO = STRWAREHOUSE_NO
                         AND S.ENTERPRISE_NO = STRENTERPRISE
                         AND S.OWNER_NO = STROWNERNO
                         AND S.ARTICLE_NO = Q.ARTICLE_NO
                         AND ROWNUM = 1) BB,
                     STOCK_ART_CELL CC
               WHERE D.ARTICLE_NO = AA.ARTICLE_NO(+)
                 AND D.ENTERPRISE_NO = AA.ENTERPRISE_NO(+)
                 AND D.WAREHOUSE_NO = AA.WAREHOUSE_NO(+)
                 AND D.OWNER_NO = AA.OWNER_NO(+)
                 AND D.ARTICLE_NO = BB.ARTICLE_NO(+)
                 AND D.ENTERPRISE_NO = BB.ENTERPRISE_NO(+)
                 AND D.WAREHOUSE_NO = BB.WAREHOUSE_NO(+)
                 AND D.OWNER_NO = BB.OWNER_NO(+)
                 AND D.ARTICLE_NO = CC.ARTICLE_NO(+)
                 AND D.ENTERPRISE_NO = CC.ENTERPRISE_NO(+)
                 AND D.WAREHOUSE_NO = CC.WAREHOUSE_NO(+)
                 AND D.ITEM_TYPE = '0'
                 AND D.WAREHOUSE_NO = STRWAREHOUSE_NO
                 AND D.EXP_NO = STREXPNO
                 AND D.ARTICLE_NO = Q.ARTICLE_NO
                 AND D.OWNER_NO = STROWNERNO
                 AND D.ENTERPRISE_NO = STRENTERPRISE) T
        LEFT JOIN CDEF_DEFCELL CC
          ON T.ENTERPRISE_NO = CC.ENTERPRISE_NO
         AND T.WAREHOUSE_NO = CC.WAREHOUSE_NO
         AND T.CELL_NO = CC.CELL_NO
        LEFT JOIN CDEF_DEFAREA CA
          ON CC.WAREHOUSE_NO = CA.WAREHOUSE_NO
         AND CC.ENTERPRISE_NO = CA.ENTERPRISE_NO
         AND CC.WARE_NO = CA.WARE_NO
         AND CC.AREA_NO = CA.AREA_NO
         AND CA.AREA_PICK = '1'
         AND CA.AREA_ATTRIBUTE = '0'
         AND CA.ATTRIBUTE_TYPE = '0';
      IF(V_AREAS IS NULL) THEN
			   V_AREAS := ',' || V_AREA;
         V_ROWNUM := V_ROWNUM + 1;
			ELSE
				IF (instr(V_AREAS,',' || V_AREA) > 0) THEN
					--这里表示当前的区域之前已存在！
					NULL;
				ELSE
				   V_AREAS := V_AREAS || ',' ||  V_AREA;
					 V_ROWNUM := V_ROWNUM + 1;
				END IF;
			END IF;

    END LOOP;
    IF (V_ROWNUM > 1) THEN
      V_AREA := ''; --如果有多个区域，则直接返回空值
    END IF;
    RETURN V_AREA;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN '';
  END;

  /*****************************************************************************************
     功能：取指定出货单对应的储位（多区域返回最小的储位）
    MODIFY BY JUN 2016-08-01
  *****************************************************************************************/
  FUNCTION F_GETCELLNOBYEXPNO(STRENTERPRISE   IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                              STRWAREHOUSE_NO IN ODATA_LOCATE_M.WAREHOUSE_NO%TYPE, --仓别
                              STROWNERNO      IN ODATA_LOCATE_M.OWNER_NO%TYPE, --货主
                              STREXPNO        IN ODATA_LOCATE_D.EXP_NO%TYPE --出货单号
                              ) RETURN VARCHAR2 IS
    V_CELLNO VARCHAR(25); --记录储位值，只保留最小的
  BEGIN
    V_CELLNO := '';

    SELECT MIN(T.CELL_NO)
      INTO V_CELLNO
      FROM (SELECT DISTINCT D.ENTERPRISE_NO,
                            D.WAREHOUSE_NO,
                            D.OWNER_NO,
                            NVL(NVL(AA.CELL_NO, BB.CELL_NO), CC.CELL_NO) CELL_NO
              FROM ODATA_EXP_D D,
                   (SELECT A.ENTERPRISE_NO,
                           A.WAREHOUSE_NO,
                           A.OWNER_NO,
                           A.ARTICLE_NO,
                           A.CELL_NO
                      FROM CSET_CELL_ARTICLE A, ODATA_EXP_D OD
                     WHERE A.WAREHOUSE_NO = STRWAREHOUSE_NO
                       AND A.ENTERPRISE_NO = STRENTERPRISE
                       AND A.OWNER_NO = STROWNERNO
                       AND A.ENTERPRISE_NO = OD.ENTERPRISE_NO
                       AND A.WAREHOUSE_NO = OD.WAREHOUSE_NO
                       AND A.OWNER_NO = OD.OWNER_NO
                       AND A.ARTICLE_NO = OD.ARTICLE_NO
                       AND OD.EXP_NO = STREXPNO
                       AND ROWNUM = 1) AA,
                   (SELECT S.ENTERPRISE_NO,
                           S.WAREHOUSE_NO,
                           S.OWNER_NO,
                           S.ARTICLE_NO,
                           S.CELL_NO
                      FROM STOCK_CONTENT S,
                           CDEF_DEFCELL  C,
                           CDEF_DEFAREA  CA,
                           ODATA_EXP_D   OD
                     WHERE S.ENTERPRISE_NO = C.ENTERPRISE_NO
                       AND S.WAREHOUSE_NO = C.WAREHOUSE_NO
                       AND S.CELL_NO = C.CELL_NO
                       AND C.WAREHOUSE_NO = CA.WAREHOUSE_NO
                       AND C.ENTERPRISE_NO = CA.ENTERPRISE_NO
                       AND C.AREA_NO = CA.AREA_NO
                       AND C.WARE_NO = CA.WARE_NO
                       AND CA.AREA_ATTRIBUTE = '0'
                       AND CA.ATTRIBUTE_TYPE = '0'
                       AND CA.AREA_PICK = '1'
                       AND S.WAREHOUSE_NO = STRWAREHOUSE_NO
                       AND S.ENTERPRISE_NO = STRENTERPRISE
                       AND S.OWNER_NO = STROWNERNO
                       AND S.ENTERPRISE_NO = OD.ENTERPRISE_NO
                       AND S.WAREHOUSE_NO = OD.WAREHOUSE_NO
                       AND S.OWNER_NO = OD.OWNER_NO
                       AND S.ARTICLE_NO = OD.ARTICLE_NO
                       AND OD.EXP_NO = STREXPNO
                       AND ROWNUM = 1) BB,
                   STOCK_ART_CELL CC
             WHERE D.ARTICLE_NO = AA.ARTICLE_NO(+)
               AND D.ENTERPRISE_NO = AA.ENTERPRISE_NO(+)
               AND D.WAREHOUSE_NO = AA.WAREHOUSE_NO(+)
               AND D.OWNER_NO = AA.OWNER_NO(+)
               AND D.ARTICLE_NO = BB.ARTICLE_NO(+)
               AND D.ENTERPRISE_NO = BB.ENTERPRISE_NO(+)
               AND D.WAREHOUSE_NO = BB.WAREHOUSE_NO(+)
               AND D.OWNER_NO = BB.OWNER_NO(+)
               AND D.ARTICLE_NO = CC.ARTICLE_NO(+)
               AND D.ENTERPRISE_NO = CC.ENTERPRISE_NO(+)
               AND D.WAREHOUSE_NO = CC.WAREHOUSE_NO(+)
               AND D.ITEM_TYPE = '0'
               AND D.WAREHOUSE_NO = STRWAREHOUSE_NO
               AND D.EXP_NO = STREXPNO
               AND D.ARTICLE_NO = D.ARTICLE_NO
               AND D.OWNER_NO = STROWNERNO
               AND D.ENTERPRISE_NO = STRENTERPRISE) T;

    RETURN V_CELLNO;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN '';
  END;

 /*****************************************************************************************
     功能：取订单所包含的所有储区信息(仓区+储区)
    MODIFY BY SUN 2016-08-15
  *****************************************************************************************/
  FUNCTION F_getAllAreaByExpNO(STRENTERPRISE   IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                              STRWAREHOUSE_NO IN ODATA_LOCATE_M.WAREHOUSE_NO%TYPE, --仓别
                              STROWNERNO      IN ODATA_LOCATE_M.OWNER_NO%TYPE, --货主
                              STREXPNO        IN ODATA_LOCATE_D.EXP_NO%TYPE --出货单号
                              ) RETURN VARCHAR2 IS
    V_AREAs VARCHAR2(1000); --记录仓区+储区
  BEGIN
    V_AREAs := ',';

    FOR Q IN (SELECT *
                FROM ODATA_EXP_D D
               WHERE D.WAREHOUSE_NO = STRWAREHOUSE_NO
                 AND D.ENTERPRISE_NO = STRENTERPRISE
                 AND D.OWNER_NO = STROWNERNO
                 AND D.EXP_NO = STREXPNO) LOOP
			FOR P IN (
      SELECT '[' || CA.WARE_NO || ']' || CA.AREA_NO V_AREA
        FROM (SELECT DISTINCT D.ENTERPRISE_NO,
                     D.WAREHOUSE_NO,
                     D.OWNER_NO,
                     NVL(NVL(AA.CELL_NO, BB.CELL_NO), CC.CELL_NO) CELL_NO
                FROM ODATA_EXP_D D,
                     (SELECT A.ENTERPRISE_NO,
                             A.WAREHOUSE_NO,
                             A.OWNER_NO,
                             A.ARTICLE_NO,
                             A.CELL_NO
                        FROM CSET_CELL_ARTICLE A
                       WHERE A.WAREHOUSE_NO = STRWAREHOUSE_NO
                         AND A.ENTERPRISE_NO = STRENTERPRISE
                         AND A.OWNER_NO = STROWNERNO
                         AND A.ARTICLE_NO = Q.ARTICLE_NO
                         AND ROWNUM = 1) AA,
                     (SELECT S.ENTERPRISE_NO,
                             S.WAREHOUSE_NO,
                             S.OWNER_NO,
                             S.ARTICLE_NO,
                             S.CELL_NO
                        FROM STOCK_CONTENT S, CDEF_DEFCELL C, CDEF_DEFAREA CA
                       WHERE S.ENTERPRISE_NO = C.ENTERPRISE_NO
                         AND S.WAREHOUSE_NO = C.WAREHOUSE_NO
                         AND S.CELL_NO = C.CELL_NO
                         AND C.WAREHOUSE_NO = CA.WAREHOUSE_NO
                         AND C.ENTERPRISE_NO = CA.ENTERPRISE_NO
                         AND C.AREA_NO = CA.AREA_NO
                         AND C.WARE_NO = CA.WARE_NO
                         AND CA.AREA_ATTRIBUTE = '0'
                         AND CA.ATTRIBUTE_TYPE = '0'
                         AND CA.AREA_PICK = '1'
                         AND S.WAREHOUSE_NO = STRWAREHOUSE_NO
                         AND S.ENTERPRISE_NO = STRENTERPRISE
                         AND S.OWNER_NO = STROWNERNO
                         AND S.ARTICLE_NO = Q.ARTICLE_NO
                         AND ROWNUM = 1) BB,
                     STOCK_ART_CELL CC
               WHERE D.ARTICLE_NO = AA.ARTICLE_NO(+)
                 AND D.ENTERPRISE_NO = AA.ENTERPRISE_NO(+)
                 AND D.WAREHOUSE_NO = AA.WAREHOUSE_NO(+)
                 AND D.OWNER_NO = AA.OWNER_NO(+)
                 AND D.ARTICLE_NO = BB.ARTICLE_NO(+)
                 AND D.ENTERPRISE_NO = BB.ENTERPRISE_NO(+)
                 AND D.WAREHOUSE_NO = BB.WAREHOUSE_NO(+)
                 AND D.OWNER_NO = BB.OWNER_NO(+)
                 AND D.ARTICLE_NO = CC.ARTICLE_NO(+)
                 AND D.ENTERPRISE_NO = CC.ENTERPRISE_NO(+)
                 AND D.WAREHOUSE_NO = CC.WAREHOUSE_NO(+)
                 AND D.ITEM_TYPE = '0'
                 AND D.WAREHOUSE_NO = STRWAREHOUSE_NO
                 AND D.EXP_NO = STREXPNO
                 AND D.ARTICLE_NO = Q.ARTICLE_NO
                 AND D.OWNER_NO = STROWNERNO
                 AND D.ENTERPRISE_NO = STRENTERPRISE) T
        LEFT JOIN CDEF_DEFCELL CC
          ON T.ENTERPRISE_NO = CC.ENTERPRISE_NO
         AND T.WAREHOUSE_NO = CC.WAREHOUSE_NO
         AND T.CELL_NO = CC.CELL_NO
        LEFT JOIN CDEF_DEFAREA CA
          ON CC.WAREHOUSE_NO = CA.WAREHOUSE_NO
         AND CC.ENTERPRISE_NO = CA.ENTERPRISE_NO
         AND CC.WARE_NO = CA.WARE_NO
         AND CC.AREA_NO = CA.AREA_NO
         AND CA.AREA_PICK = '1'
         AND CA.AREA_ATTRIBUTE = '0'
         AND CA.ATTRIBUTE_TYPE = '0') LOOP

				IF(V_AREAS = ',') THEN
					V_AREAS := V_AREAs || P.V_AREA || ',';
				ELSE
					IF (instr(V_AREAS,',' || P.V_AREA || ',') > 0) THEN
						--这里表示当前的区域之前已存在！
						NULL;
					ELSE
						V_AREAS :=V_AREAs || P.V_AREA || ',';
					END IF;
				END IF;

			END LOOP;

    END LOOP;
    if(V_AREAS = ',') THEN
		  V_AREAS := '';--如果没有区域。则返回空
		END IF;

    RETURN V_AREAs;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN '';
  END;

 /*****************************************************************************************
     功能：统计当前的单据是否包含异性品
    MODIFY BY SUN 2016-08-15
  *****************************************************************************************/
  FUNCTION F_setRuleFlagByExpNO(STRENTERPRISE   IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                              STRWAREHOUSE_NO IN ODATA_LOCATE_M.WAREHOUSE_NO%TYPE, --仓别
                              STROWNERNO      IN ODATA_LOCATE_M.OWNER_NO%TYPE, --货主
                              STREXPNO        IN ODATA_LOCATE_D.EXP_NO%TYPE --出货单号
                              ) RETURN VARCHAR2 IS
    V_RuleFlag VARCHAR2(1); --记录当前是否包含异性品  0:异性品，1：正常品
    V_ROWNUM NUMBER(4);
  BEGIN
    V_RuleFlag := '1';
		V_ROWNUM := 0;

		BEGIN
			--查当前出货单的异性品个数
			SELECT COUNT(a.article_no) INTO V_ROWNUM FROM odata_exp_d d,bdef_defarticle a
			WHERE d.exp_no = STREXPNO AND d.owner_no = STROWNERNO
			AND d.enterprise_no = STRENTERPRISE AND d.warehouse_no = STRWAREHOUSE_NO
			and d.article_no = a.article_no and d.enterprise_no = a.enterprise_no
			AND a.rule_flag = '0' ;
		EXCEPTION
      WHEN OTHERS THEN
				V_ROWNUM := 0;
		END;
		if(V_ROWNUM > 0) THEN
		  V_RuleFlag := '0';
		END IF;

    RETURN V_RuleFlag;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN '1';--默认1，正常品
  END;



  /*****************************************************************************************
     功能：对出货单进行集单(界面调用)
    MODIFY BY JUN 2014-05-20
  *****************************************************************************************/
  PROCEDURE P_INS_O_LOCATE_TASK(STRENTERPRISENO IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                                STRWAREHOUSENO  IN ODATA_LOCATE_M.WAREHOUSE_NO%TYPE, --仓别
                                STROWNERNO      IN ODATA_LOCATE_M.OWNER_NO%TYPE, --货主
                                STREXPTYPE      IN ODATA_LOCATE_M.EXP_TYPE%TYPE, --出货单类型
                                STRLOCATENAME   IN ODATA_LOCATE_M.LOCATE_NAME%TYPE, --集单人员
                                --DTLOCATEDATE     IN ODATA_LOCATE_M.LOCATE_DATE%TYPE,--集单时间
                                STRDIVIDEFLAG           IN ODATA_LOCATE_BATCH.C_DIVIDE_FLAG%TYPE, --1：允许分播；0：不允许分播
                                STRSENDBUF_COMPUTE_FLAG IN ODATA_LOCATE_BATCH.SENDBUF_COMPUTE_FLAG%TYPE, --是否试算月台资源，1:试算；0:不试算
                                STRSPECIFYCELL          IN ODATA_LOCATE_BATCH.SPECIFY_CELL%TYPE, --指定储位定位，默认N，表示不指定储位
                                NTASKBATCH              IN ODATA_LOCATE_BATCH.BATCH_NO%TYPE, --分布式定位，任务批次号
                                STRSOURCETYPE           IN ODATA_LOCATE_M.SOURCE_TYPE%TYPE, --分布式定位，任务批次号
                                STRDIVIDE_COMPUTE_FLAG  IN DEVICE_DIVIDE_M.DIVIDE_COMPUTE_FLAG%TYPE, --分播设备
                                STRCHECK_COMPUTE_FLAG   IN ODATA_LOCATE_BATCH.CHECK_COMPUTE_FLAG%TYPE, --复合台
                                STRORGNO                IN ODATA_EXP_M.ORG_NO%TYPE,
                                STRBATCH_RULE_ID        IN WMS_OUTWAVEPLAN_D.BATCH_RULE_ID%TYPE, --规则ID
                                STRAUTO                 NUMBER, --标记是否自动 1自动，2手动
                                STRIP                   IN VARCHAR2, --本地IP
                                --NRULE_ID          IN ODATA_LOCATE_M.RULE_ID%TYPE,
                                NTASK_ALLOTRULEID IN ODATA_LOCATE_BATCH.TASK_RULE_ID%TYPE,

                                STRWAVENO OUT ODATA_LOCATE_M.WAVE_NO%TYPE, --波次号
                                STRRESULT OUT VARCHAR2) IS

    V_BATCH_STRATEGY_ID  WMS_OUTWAVEPLAN_D.BATCH_STRATEGY_ID%TYPE; --策略ID
    V_BATCH_RULE_ID      WMS_OUTWAVEPLAN_D.BATCH_RULE_ID%TYPE; --规则ID
    V_BATCH_COMPUTE      WMS_OUTWAVEPLAN_D.BATCH_COMPUTE%TYPE; --批次切分方式
    V_BATCH_COMPUTE_TYPE WMS_OUTWAVEPLAN_D.BATCH_COMPUTE%TYPE; --批次切分模式

  BEGIN
    STRRESULT := 'N|P_INS_O_LOCATE_TASK';

    --根据当前的单据类型，取策略配置
    BEGIN
      SELECT D.BATCH_STRATEGY_ID,
             D.BATCH_RULE_ID,
             D.BATCH_COMPUTE,
             D.BATCH_COMPUTE_TYPE
        INTO V_BATCH_STRATEGY_ID,
             V_BATCH_RULE_ID,
             V_BATCH_COMPUTE,
             V_BATCH_COMPUTE_TYPE
        FROM WMS_OUTORDER O, WMS_OUTWAVEPLAN_M M, WMS_OUTWAVEPLAN_D D
       WHERE O.ENTERPRISE_NO = M.ENTERPRISE_NO
         AND O.MANUALBATCH_STRATEGY_ID = M.BATCH_STRATEGY_ID
         AND O.ENTERPRISE_NO = D.ENTERPRISE_NO
         AND (CASE
               WHEN (STRAUTO = 1) THEN
                O.AUTOBATCH_STRATEGY_ID
               ELSE
                O.MANUALBATCH_STRATEGY_ID
             END) = D.BATCH_STRATEGY_ID
         AND O.ENTERPRISE_NO = STRENTERPRISENO
         AND D.BATCH_RULE_ID = STRBATCH_RULE_ID
         AND O.EXP_TYPE = STREXPTYPE;

    EXCEPTION
      WHEN OTHERS THEN
        STRRESULT := 'N|获取当前试算流程失败！';
        RETURN;
    END;

    --调统一入口
    P_AUTO_LOCATE_MAIN(STRENTERPRISENO,
                       STRWAREHOUSENO,
                       STROWNERNO,
                       STREXPTYPE,
                       STRLOCATENAME,
                       STRDIVIDEFLAG,
                       STRSENDBUF_COMPUTE_FLAG,
                       STRSPECIFYCELL,
                       STRSOURCETYPE,
                       STRDIVIDE_COMPUTE_FLAG,
                       STRCHECK_COMPUTE_FLAG,
                       STRORGNO,
                       V_BATCH_STRATEGY_ID, --可以指定执行某个策略、规则，可以传0
                       V_BATCH_RULE_ID, --可以指定执行某个策略、规则，可以传0
                       NTASKBATCH,
                       '3',
                       STRIP,
                       '1',
                       STRWAVENO,
                       STRRESULT);
    IF SUBSTR(STRRESULT, 1, 1) = 'N' THEN
      RETURN;
    END IF;
    STRRESULT := 'Y|P_INS_O_LOCATE_TASK';

  EXCEPTION
    WHEN OTHERS THEN
      STRRESULT := 'N|' || SQLERRM ||
                   SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);

  END P_INS_O_LOCATE_TASK;

  /*****************************************************************************************
     功能：写执行日志
  *****************************************************************************************/
  PROCEDURE P_WRITELOG(STRSTRATEGY_ID   IN WMS_OUTWAVEPLAN_D.BATCH_STRATEGY_ID%TYPE, --策略ID
                       STRBATCH_RULE_ID IN WMS_OUTWAVEPLAN_D.BATCH_RULE_ID%TYPE, --策略序号
                       STRECECTYPE      IN TMP_LOCATEBATCH_LOG.EXECTYPE%TYPE, --类型
                       STREXECREMARK    IN TMP_LOCATEBATCH_LOG.EXECREMARK%TYPE, --说明
                       STRMESSAGE       IN TMP_LOCATEBATCH_LOG.MESSAGE%TYPE, --信息描述
                       STRWAVEID        IN TMP_LOCATEBATCH_LOG.WAVEID%TYPE, --波次流水（时间戳）
                       STRPROCNAME      IN TMP_LOCATEBATCH_LOG.PROCNAME%TYPE --执行过程名
                       ) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    INSERT INTO TMP_LOCATEBATCH_LOG
      (SEQID,
       WAVEID,
       PROCNAME,
       STRATEGY_ID,
       BATCH_RULE_ID,
       EXECREMARK,
       EXECTYPE,
       EXECDATE,
       MESSAGE)
    VALUES
      (SEQ_TEMP_LOCATE.NEXTVAL,
       STRWAVEID,
       STRPROCNAME,
       STRSTRATEGY_ID,
       STRBATCH_RULE_ID,
       STREXECREMARK,
       STRECECTYPE,
       SYSDATE,
       STRMESSAGE);
    COMMIT;
  END P_WRITELOG;

  /*****************************************************************************************
      功能：自动集单：底层自动集单调用！
      参数为企业，仓别，货主
      注：底层自动集单不调定位！可以指定执行某个策略、规则，不指定可以传0
  *****************************************************************************************/
  PROCEDURE P_AUTO_LOCATE(STRENTERPRISENO  IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                          STRWAREHOUSENO   IN ODATA_LOCATE_M.WAREHOUSE_NO%TYPE, --仓别
                          STROWNERNO       IN ODATA_LOCATE_M.OWNER_NO%TYPE, --货主
                          STRATEGY_ID      IN ODATA_LOCATE_BATCH.BATCH_STRATEGY_ID%TYPE, --指定策略 不指定传0
                          STRBATCH_RULE_ID IN ODATA_LOCATE_BATCH.BATCH_RULE_ID%TYPE, --指定规则 不指定传0
                          STRRESULT        OUT VARCHAR2) IS
    STRWAVENO ODATA_LOCATE_M.WAVE_NO%TYPE; --波次号 参数
  BEGIN
    STRRESULT := 'N|P_AUTO_LOCATE';
    P_AUTO_LOCATE_MAIN(STRENTERPRISENO,
                       STRWAREHOUSENO,
                       STROWNERNO,
                       'ALL',
                       'AUTO',
                       '',
                       '',
                       'N', --默认值N
                       '1', --默认值1
                       '',
                       '',
                       'ALL',
                       STRATEGY_ID,
                       STRBATCH_RULE_ID,
                       0,
                       '1',
                       '255.255.255.255',
                       '0',
                       STRWAVENO,
                       STRRESULT);
    IF SUBSTR(STRRESULT, 1, 1) <> 'N' THEN
      COMMIT;
    ELSE
      RETURN;
    END IF;
    STRRESULT := 'Y|P_AUTO_LOCATE';
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      STRRESULT := 'N|' || SQLERRM ||
                   SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
  END P_AUTO_LOCATE;

/*****************************************************************************************
    功能：自动集单：指定出货单号集单
    ADD BY SUNL 2016年7月27日
    注：不带自动定位！
*****************************************************************************************/
PROCEDURE P_AUTO_LOCATEBYEXPNO(STRENTERPRISENO IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                               STRWAREHOUSENO  IN ODATA_LOCATE_M.WAREHOUSE_NO%TYPE, --仓别
                               STROWNERNO      IN ODATA_LOCATE_M.OWNER_NO%TYPE, --货主
                               STRLOCATENAME   IN ODATA_LOCATE_M.LOCATE_NAME%TYPE, --定位人
                               STREXP_TYPE     IN ODATA_EXP_M.EXP_TYPE%TYPE, --指定出货单类型
                               STREXP_NO       IN ODATA_EXP_M.EXP_NO%TYPE, --指定出货单号
                               STRWAVENO       OUT ODATA_LOCATE_M.WAVE_NO%TYPE, --波次号
                               STRRESULT       OUT VARCHAR2) IS
  V_NEWBATCH_NO    ODATA_LOCATE_BATCH.BATCH_NO%TYPE; --作业批次号
  V_WAVEID         TMP_LOCATEBATCH_LOG.WAVEID%TYPE; --波次流水（时间戳）
  V_SKU_COUNT_MODE WMS_OUTWAVEPLAN_D.SKU_COUNT_MODE%TYPE;
  V_STRORGNO       ODATA_EXP_M.ORG_NO%TYPE;
  V_STRIP          ODATA_TMP_LOCATE_SELECT.TMP_ID%TYPE;

  P_BATCH_STRATEGY_ID  ODATA_LOCATE_BATCH.BATCH_STRATEGY_ID%TYPE;
  P_BATCH_RULE_ID      ODATA_LOCATE_BATCH.BATCH_RULE_ID%TYPE;
  P_LOCATE_STRATEGY_ID WMS_OUTORDER.LOCATE_STRATEGY_ID%TYPE;
  P_BATCH_COMPUTE      WMS_OUTWAVEPLAN_D.BATCH_COMPUTE%TYPE;
  P_INDUSTRY_FLAG      ODATA_LOCATE_BATCH.INDUSTRY_FLAG%TYPE;

BEGIN
  V_WAVEID         := TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS');
  V_SKU_COUNT_MODE := 0;
  V_NEWBATCH_NO    := 0;
  V_STRORGNO       := '';
  V_STRIP          := '256.256.256.256'; --这里给一个不存在的IP单独处理

  STRWAVENO := '';
  STRRESULT := 'N|P_AUTO_LOCATEBYEXPNO';

  --1. 校验当前的出货单是1品还是多品（非传统模式需要校验是否多品，用于取规则）
  BEGIN
    --SKU_COUNT_MODE 默认值是2
    SELECT M.SKU_COUNT_MODE, M.ORG_NO
      INTO V_SKU_COUNT_MODE, V_STRORGNO
      FROM ODATA_EXP_M M
     WHERE M.ENTERPRISE_NO = STRENTERPRISENO
       AND M.OWNER_NO = STROWNERNO
       AND M.WAREHOUSE_NO = STRWAREHOUSENO
       AND M.EXP_NO = STREXP_NO
       AND M.EXP_TYPE = STREXP_TYPE;
  EXCEPTION
    WHEN OTHERS THEN
      V_SKU_COUNT_MODE := 0;
  END;
  IF (V_SKU_COUNT_MODE = 0) THEN
    STRRESULT := 'N|获取订单类型失败！';
    RETURN;
  END IF;
  --2. 根据当前的出货单类型获取指定的规则信息
  BEGIN
    SELECT T.BATCH_STRATEGY_ID,
           T.BATCH_RULE_ID,
           T.LOCATE_STRATEGY_ID,
           T.BATCH_COMPUTE,
           T.INDUSTRY_FLAG
      INTO P_BATCH_STRATEGY_ID,
           P_BATCH_RULE_ID,
           P_LOCATE_STRATEGY_ID,
           P_BATCH_COMPUTE,
           P_INDUSTRY_FLAG
      FROM V_GETMANUALLOCATEBATCHINFO T
     WHERE T.STATUS = '1'
       AND T.EXP_TYPE = STREXP_TYPE
       AND T.ENTERPRISE_NO = STRENTERPRISENO
       AND T.SKU_COUNT_MODE = (case when t.INDUSTRY_FLAG = '2'  then V_SKU_COUNT_MODE else '2' end);
  EXCEPTION
    WHEN OTHERS THEN
      STRRESULT := 'N|获取波次规则失败！';
      RETURN;
  END;
  --3. 将当前指定的单据写入到集单临时表
  BEGIN
    DELETE TMP_ODATA_EXP_M M
     WHERE M.ENTERPRISE_NO = STRENTERPRISENO
       AND M.STRIP = V_STRIP;
    INSERT INTO TMP_ODATA_EXP_M
      (ENTERPRISE_NO,
       WAREHOUSE_NO,
       OWNER_NO,
       EXP_NO,
       DELIVER_ADDRESS,
       DELIVER_TYPE,
       ORDER_SOURCE,
       SHIPPER_NO,
       SINGLE_LOCATE_FLAG,
       AREA,
       STATUS,
       STRIP,
       ORG_NO,
       OVERTIME,ORDERTYPE)
      SELECT M.ENTERPRISE_NO,
             M.WAREHOUSE_NO,
             M.OWNER_NO,
             M.EXP_NO,
             M.DELIVER_ADDRESS,
             M.DELIVER_TYPE,
             M.ORDER_SOURCE,
             M.SHIPPER_NO,
             '0',
             PKLG_ODISPATCH.F_GETAREABYEXPNO(M.ENTERPRISE_NO,
                                             M.WAREHOUSE_NO,
                                             M.OWNER_NO,
                                             M.EXP_NO),
             '1', --这里状态直接默认1 处理中
             V_STRIP,
             M.ORG_NO,
             CASE
               WHEN SYSDATE > M.RGST_DATE + 2 / (24 * 60) THEN
                '1'
               ELSE
                '0'
             END,0
        FROM ODATA_EXP_M M
       WHERE M.STATUS = '10'
         AND M.EXP_NO = STREXP_NO
         AND M.ENTERPRISE_NO = STRENTERPRISENO
         AND M.EXP_TYPE = STREXP_TYPE
         AND M.WAREHOUSE_NO = STRWAREHOUSENO
         AND M.OWNER_NO = STROWNERNO;
  END;
  --4. 集单
  P_LOCATE_CONTROL(STRENTERPRISENO,
                   STRWAREHOUSENO,
                   STROWNERNO,
                   STREXP_TYPE,
                   STRLOCATENAME,
                   P_BATCH_STRATEGY_ID,
                   P_BATCH_RULE_ID,
                   '',
                   '',
                   'N',
                   0,
                   '1',
                   '',
                   '',
                   V_STRORGNO,
                   P_BATCH_COMPUTE,
                   '0',
                   P_INDUSTRY_FLAG,
                   V_STRIP,
                   P_LOCATE_STRATEGY_ID,
                   V_WAVEID,
                   STRWAVENO,
                   V_NEWBATCH_NO,
                   STRRESULT);
  IF SUBSTR(STRRESULT, 1, 1) = 'N' THEN
    RETURN;
  END IF;
  IF (STRWAVENO IS NULL) THEN
    STRRESULT := 'N|集单异常，未获取到波次！';
    RETURN;
  END IF;
 /* --5. 定位
  BEGIN
    PKLG_OLOCATE.P_LOCATE_MAIN(STRENTERPRISENO,
                               STRWAREHOUSENO,
                               STRWAVENO,
                               STRLOCATENAME,
                               STRRESULT);
    IF SUBSTR(STRRESULT, 1, 1) <> 'Y' THEN
      P_WRITELOG(P_BATCH_STRATEGY_ID,
                 P_BATCH_RULE_ID,
                 'N',
                 '自动定位失败！波次号：' || STRWAVENO,
                 STRRESULT,
                 V_WAVEID,
                 'P_AUTO_LOCATEBYEXPNO');
      RETURN;
    ELSE
      P_WRITELOG(P_BATCH_STRATEGY_ID,
                 P_BATCH_RULE_ID,
                 'E',
                 '自动定位成功！波次号：' || STRWAVENO,
                 STRRESULT,
                 V_WAVEID,
                 'P_AUTO_LOCATEBYEXPNO');
    END IF;
  END;*/
  STRRESULT := 'Y|P_AUTO_LOCATEBYEXPNO';
EXCEPTION
  WHEN OTHERS THEN
    STRRESULT := 'N|' || SQLERRM ||
                 SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
END P_AUTO_LOCATEBYEXPNO;

  /*****************************************************************************************
      功能：自动集单：界面自动集单调用！
      注：界面自动集单要调定位！可以指定执行某个策略、规则，不指定可以传0
  *****************************************************************************************/
  PROCEDURE P_FRONTAUTO_LOCATE(STRENTERPRISENO         IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                               STRWAREHOUSENO          IN ODATA_LOCATE_M.WAREHOUSE_NO%TYPE, --仓别
                               STROWNERNO              IN ODATA_LOCATE_M.OWNER_NO%TYPE, --货主
                               STREXPTYPE              IN ODATA_LOCATE_M.EXP_TYPE%TYPE, --出货单类型
                               STRLOCATENAME           IN ODATA_LOCATE_M.LOCATE_NAME%TYPE, --集单人员
                               STRDIVIDEFLAG           IN ODATA_LOCATE_BATCH.C_DIVIDE_FLAG%TYPE, --1：允许分播；0：不允许分播
                               STRSENDBUF_COMPUTE_FLAG IN ODATA_LOCATE_BATCH.SENDBUF_COMPUTE_FLAG%TYPE, --是否试算月台资源，1:试算；0:不试算
                               STRSPECIFYCELL          IN ODATA_LOCATE_BATCH.SPECIFY_CELL%TYPE, --指定储位定位，默认N，表示不指定储位
                               STRSOURCETYPE           IN ODATA_LOCATE_M.SOURCE_TYPE%TYPE, --分布式定位，任务批次号
                               STRDIVIDE_COMPUTE_FLAG  IN DEVICE_DIVIDE_M.DIVIDE_COMPUTE_FLAG%TYPE, --分播设备
                               STRCHECK_COMPUTE_FLAG   IN ODATA_LOCATE_BATCH.CHECK_COMPUTE_FLAG%TYPE, --复合台
                               STRORGNO                IN ODATA_EXP_M.ORG_NO%TYPE,
                               NTASKBATCH              IN ODATA_LOCATE_BATCH.BATCH_NO%TYPE, --分布式定位，任务批次号
                               STRATEGY_ID             IN ODATA_LOCATE_BATCH.BATCH_STRATEGY_ID%TYPE, --指定策略 不指定传0
                               STRBATCH_RULE_ID        IN ODATA_LOCATE_BATCH.BATCH_RULE_ID%TYPE, --指定规则 不指定传0
                               STRIP                   IN VARCHAR2, --本地IP
                               STRRESULT               OUT VARCHAR2) IS
    STRWAVENO ODATA_LOCATE_M.WAVE_NO%TYPE; --波次号 参数
  BEGIN
    STRRESULT := 'N|P_FRONTAUTO_LOCATE';
    P_AUTO_LOCATE_MAIN(STRENTERPRISENO,
                       STRWAREHOUSENO,
                       STROWNERNO,
                       STREXPTYPE,
                       STRLOCATENAME,
                       STRDIVIDEFLAG,
                       STRSENDBUF_COMPUTE_FLAG,
                       STRSPECIFYCELL,
                       STRSOURCETYPE,
                       STRDIVIDE_COMPUTE_FLAG,
                       STRCHECK_COMPUTE_FLAG,
                       STRORGNO,
                       STRATEGY_ID, --可以指定执行某个策略、规则，可以传0
                       STRBATCH_RULE_ID, --可以指定执行某个策略、规则，可以传0
                       NTASKBATCH,
                       '2',
                       STRIP,
                       '1',
                       STRWAVENO,
                       STRRESULT);
    IF SUBSTR(STRRESULT, 1, 1)  = 'N' THEN
      RETURN;
    END IF;
    STRRESULT := 'Y|P_FRONTAUTO_LOCATE';
  EXCEPTION
    WHEN OTHERS THEN
      STRRESULT := 'N|' || SQLERRM ||
                   SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
  END P_FRONTAUTO_LOCATE;

  /*****************************************************************************************
     功能：自动集单入口(自动集单、自动定位)
     ADD BY SUNL 20160627
  *****************************************************************************************/
  PROCEDURE P_AUTO_LOCATE_MAIN(STRENTERPRISENO         IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                               STRWAREHOUSENO          IN ODATA_LOCATE_M.WAREHOUSE_NO%TYPE, --仓别
                               STROWNERNO              IN ODATA_LOCATE_M.OWNER_NO%TYPE, --货主
                               STREXPTYPE              IN ODATA_LOCATE_M.EXP_TYPE%TYPE, --出货单类型
                               STRLOCATENAME           IN ODATA_LOCATE_M.LOCATE_NAME%TYPE, --集单人员
                               STRDIVIDEFLAG           IN ODATA_LOCATE_BATCH.C_DIVIDE_FLAG%TYPE, --1：允许分播；0：不允许分播
                               STRSENDBUF_COMPUTE_FLAG IN ODATA_LOCATE_BATCH.SENDBUF_COMPUTE_FLAG%TYPE, --是否试算月台资源，1:试算；0:不试算
                               STRSPECIFYCELL          IN ODATA_LOCATE_BATCH.SPECIFY_CELL%TYPE, --指定储位定位，默认N，表示不指定储位
                               STRSOURCETYPE           IN ODATA_LOCATE_M.SOURCE_TYPE%TYPE, --分布式定位，任务批次号
                               STRDIVIDE_COMPUTE_FLAG  IN DEVICE_DIVIDE_M.DIVIDE_COMPUTE_FLAG%TYPE, --分播设备
                               STRCHECK_COMPUTE_FLAG   IN ODATA_LOCATE_BATCH.CHECK_COMPUTE_FLAG%TYPE, --复合台
                               STRORGNO                IN ODATA_EXP_M.ORG_NO%TYPE,
                               STRATEGY_ID             IN ODATA_LOCATE_BATCH.BATCH_STRATEGY_ID%TYPE, --指定策略 不指定传0
                               STRBATCH_RULE_ID        IN ODATA_LOCATE_BATCH.BATCH_RULE_ID%TYPE, --指定规则 不指定传0
                               NTASKBATCH              IN ODATA_LOCATE_BATCH.BATCH_NO%TYPE, --分布式定位，任务批次号
                               STROPERATIONTYPE        IN VARCHAR2, --操作类型 1：底层自动，2：前台自动，--3:前台手动
                               STRIP                   IN VARCHAR2, --本地IP
                               STRAUTOLOCATE           IN VARCHAR2, --是否自动定位 0：否，1：是
                               STRWAVENO               OUT ODATA_LOCATE_M.WAVE_NO%TYPE, --波次号
                               STRRESULT               OUT VARCHAR2) IS
    NUM_RECORDCOUNT NUMBER; --当前记录数
    DATE_D_LASTTIME DATE; --记录明细间隔时间
    NUM_BATCHNO     NUMBER(4); --当前批次记录号
    NUM_BASETYPE    NUMBER; --类型基数（归类用）
    NUM_NOWTYPE     NUMBER; --当前类型
    V_STRORGNO      ODATA_EXP_M.ORG_NO%TYPE; --机构号，当界面传ALL时使用。
    STRWAVEID       TMP_LOCATEBATCH_LOG.WAVEID%TYPE; --波次流水（时间戳）
    V_END           VARCHAR2(1); --标记是否是最后一个规则

    STR_TMP_ARTICLENOS   VARCHAR2(500); --聚类时，存储筛选出的商品编码集合
    STR_TMP_ARTICLECOUNT NUMBER; --聚类时，需要排除的商品编码个数
    STR_TMP_ISSUCCESS    NUMBER; --聚类时，记录是否聚类成功

    STR_TMP_FAILARTICLES VARCHAR2(500); --聚类时，存储执行聚类失败的商品编码集合

	  V_K_AREA             tmp_odata_exp_m.area%TYPE;--记录当前区域
		V_K_RN               NUMBER;--记录当前区域所含订单数
		V_MixOwnerExp        wms_defbase.sdefine%TYPE;
		V_STRATEGY_ID        ODATA_LOCATE_BATCH.BATCH_STRATEGY_ID%TYPE;--指定策略
		V_OWNER_NO           ODATA_LOCATE_M.OWNER_NO%TYPE;
  BEGIN
    STRRESULT          := 'N|P_AUTO_LOCATE_MAIN';
    NUM_RECORDCOUNT    := 0;
    NUM_BASETYPE       := 100; --基数默认100
    NUM_NOWTYPE        := 0; --初始值为0
    STR_TMP_ARTICLENOS := '';
		V_MixOwnerExp :='0';--默认0
		V_STRATEGY_ID := STRATEGY_ID;


		BEGIN
			--如果没有指定策略或规则，才进行校验
			IF (V_STRATEGY_ID = 0 AND STRBATCH_RULE_ID = '0') THEN
				-- 获取配置
				begin
					SELECT b.sdefine INTO V_MixOwnerExp FROM  wms_defbase b
					WHERE b.colname = 'MixOwnerExp' AND b.group_no = 'O'
					AND b.sub_group_no ='O_LOCATE' AND b.use_memo = '1'
					AND b.enterprise_no = STRENTERPRISENO;
				EXCEPTION
					WHEN OTHERS THEN
						STRRESULT := 'N|请检查wms_defbase配置MixOwnerExp！';
						RETURN;
				END;

				BEGIN
					--如果配置允许混货主，且传入货主为ALL，且不是底层自动
					IF(STROWNERNO = 'ALL' AND V_MixOwnerExp= '1' AND STROPERATIONTYPE <> '1') THEN
					 --先检查订单池内的货主个数
					 SELECT COUNT(0) INTO NUM_RECORDCOUNT FROM (SELECT m.owner_no FROM odata_exp_m m WHERE m.status = '10' AND m.enterprise_no = STRENTERPRISENO
					 GROUP BY m.owner_no);

					 IF(NUM_RECORDCOUNT = 0) THEN
						--没有单据
						STRRESULT := 'N|没有订单可以调度！';
						RETURN;
					 END IF;

					 IF(NUM_RECORDCOUNT = 1) THEN
						 --只有1个货主，则尝试取该货主的配置策略
						 BEGIN
                 SELECT K.BATCH_STRATEGY_ID INTO V_STRATEGY_ID FROM (
                SELECT DISTINCT a.BATCH_STRATEGY_ID FROM (
                 select * FROM V_GETAUTOLOCATEBATCHINFO WHERE 1= (CASE WHEN STROPERATIONTYPE = '2' THEN 1 ELSE 0 END)
                 UNION ALL
                  select * FROM V_GETMANUALLOCATEBATCHINFO WHERE 1= (CASE WHEN STROPERATIONTYPE = '3' THEN 1 ELSE 0 END)
                  ) A,odata_exp_m M WHERE m.status = '10' AND m.enterprise_no = STRENTERPRISENO
                  AND a.owner_no(+) = m.owner_no) K;--Modify BY QZH AT 20160911
               EXCEPTION
                WHEN OTHERS THEN
                  STRRESULT := 'N|未查询到有效的策略信息！';
                  RETURN;
               END;
					 ELSE
						 --如果有多个货主，则直接取系统级配置，这里不处理
						 NULL;
					 END IF;
					END IF;
				END;
	    END IF;
	  END;


	--循环当前所有货主 按货主切波次！！！
	FOR L IN (
		SELECT m.owner_no 
    FROM odata_exp_m m 
    WHERE m.status = '10' 
    AND m.enterprise_no = STRENTERPRISENO
    AND M.WAREHOUSE_NO = STRWAREHOUSENO
		GROUP BY m.owner_no
		) LOOP
    IF(V_MixOwnerExp = '1' and NUM_RECORDCOUNT>1 ) THEN --Modify BY QZH AT 20160911
		V_OWNER_NO := 'ALL';
		ELSE
			V_OWNER_NO := l.owner_no;--每次一个货主，按货主切波次！
		END IF;
    --循环所有策略，可以指定策略
    FOR U IN (SELECT M.BATCH_STRATEGY_ID
                FROM WMS_OUTWAVEPLAN_M M
               WHERE M.ENTERPRISE_NO = STRENTERPRISENO
                 AND M.BATCH_STRATEGY_ID = (CASE
                       WHEN STRATEGY_ID = 0 THEN
                        M.BATCH_STRATEGY_ID
                       ELSE
                        V_STRATEGY_ID
                     END)
               GROUP BY M.BATCH_STRATEGY_ID) LOOP
      --重置批次、波次号
      NUM_BATCHNO := 0; --批次号
      STRWAVENO   := ''; --波次号
      V_END       := '0';
      --获取时间戳，用于记录日志 按波次开始时计算！
      STRWAVEID := TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS');

      --循环视图 自动集所有的批次(可以指定规则)
      FOR P IN (SELECT DISTINCT A.*
                  FROM (SELECT C.*
                          FROM V_GETAUTOLOCATEBATCHINFO C
                         WHERE C.STATUS = '1' --只查询有效的规则
                           AND C.ENTERPRISE_NO = STRENTERPRISENO
                           AND C.BATCH_STRATEGY_ID = U.BATCH_STRATEGY_ID
                           AND 1 = (CASE
                                 WHEN STROPERATIONTYPE = '3' THEN
                                  0
                                 ELSE
                                  1
                               END)
                           AND C.EXP_TYPE = (CASE
                                 WHEN STREXPTYPE = 'ALL' THEN
                                  C.EXP_TYPE
                                 ELSE
                                  STREXPTYPE
                               END)
                           AND C.BATCH_RULE_ID = (CASE
                                 WHEN STRBATCH_RULE_ID = 0 THEN
                                  C.BATCH_RULE_ID
                                 ELSE
                                  STRBATCH_RULE_ID
                               END) AND c.EXP_TYPE IS NOT NULL
                        UNION ALL
                        SELECT C.*
                          FROM V_GETMANUALLOCATEBATCHINFO C
                         WHERE C.STATUS = '1' --只查询有效的规则
                           AND C.ENTERPRISE_NO = STRENTERPRISENO
                           AND C.BATCH_STRATEGY_ID = U.BATCH_STRATEGY_ID
                           AND 1 = (CASE
                                 WHEN STROPERATIONTYPE = '3' THEN
                                  1
                                 ELSE
                                  0
                               END)
                           AND C.EXP_TYPE = (CASE
                                 WHEN STREXPTYPE = 'ALL' THEN
                                  C.EXP_TYPE
                                 ELSE
                                  STREXPTYPE
                               END)
                           AND C.BATCH_RULE_ID = (CASE
                                 WHEN STRBATCH_RULE_ID = 0 THEN
                                  C.BATCH_RULE_ID
                                 ELSE
                                  STRBATCH_RULE_ID
                               END) AND c.EXP_TYPE IS NOT NULL) A
                 ORDER BY A.BATCH_STRATEGY_ID ASC, A.SEQ_ORDER ASC) LOOP


          P_WRITELOG(P.Batch_Strategy_Id,
                     P.BATCH_RULE_ID,
                     'E',
                     '参数输出',
                     'V_OWNER_NO = '||V_OWNER_NO  ,
                     STRWAVEID,
                     'P_AUTO_LOCATE_MAIN');

        --0. 校验当前的规则是否是最后一个规则，界面调用，需要强行组波次
        BEGIN
          IF (STROPERATIONTYPE <> '1') THEN
            FOR Y IN (SELECT MAX(D.BATCH_RULE_ID) RULE_ID, D.SKU_COUNT_MODE
                        FROM WMS_OUTWAVEPLAN_D D
                       WHERE D.BATCH_STRATEGY_ID = U.BATCH_STRATEGY_ID
                         AND D.ENTERPRISE_NO = STRENTERPRISENO
                       GROUP BY D.SKU_COUNT_MODE) LOOP
              IF (Y.RULE_ID = P.BATCH_RULE_ID) THEN
                V_END := '1'; --如果当前是最后一个规则
                EXIT;
              ELSE
                V_END := '0';
              END IF;
            END LOOP;
          ELSE
            V_END := '0';
          END IF;
        END;

        --1. 校验当前的规则是否达到了执行时间(自动调用需要)
        BEGIN
          IF (STROPERATIONTYPE = '1') THEN
            BEGIN
              BEGIN
                SELECT J.LAST_RUN_TIME
                  INTO DATE_D_LASTTIME
                  FROM WMS_JOB_CONFIG J
                 WHERE J.DRIVE_TABLE = 'WMS_OUTWAVEPLAN_D'
                   AND J.PROC_NAME = 'INTERVAL_TIMES' || P.BATCH_RULE_ID
                   AND J.WAREHOUSE_NO = STRWAREHOUSENO
                   AND J.OWNER_NO = V_OWNER_NO
                   AND J.ENTERPRISE_NO = P.ENTERPRISE_NO;

              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  DATE_D_LASTTIME := SYSDATE - 1; --如果未找到上次执行时间配置，默认直接执行
              END;
              IF ((DATE_D_LASTTIME + P.INTERVAL_TIMES / (24 * 60)) >
                 SYSDATE) THEN
                STRRESULT := 'N|未到执行时间！';
                P_WRITELOG(P.BATCH_STRATEGY_ID,
                           P.BATCH_RULE_ID,
                           'E',
                           '校验明细间隔时间',
                           STRRESULT,
                           STRWAVEID,
                           'P_AUTO_LOCATE_MAIN');
                GOTO NEXT_V_WAVE_END; --跳出当前的规则，进行下一个规则
              END IF;
              P_WRITELOG(P.BATCH_STRATEGY_ID,
                         P.BATCH_RULE_ID,
                         'Y',
                         '校验明细间隔时间',
                         '上次执行时间:' ||
                         TO_CHAR(DATE_D_LASTTIME, 'YYYY-MM-DD HH24:MI:SS'),
                         STRWAVEID,
                         'P_AUTO_LOCATE_MAIN');
            END;
          END IF;
        END;

        --2. 获取有效的订单，写到临时表
        BEGIN
          P_WRITETMP_ODATA_EXP(STRENTERPRISENO,
                               STRWAREHOUSENO,
                               V_OWNER_NO,
                               STRORGNO,
															 STREXPTYPE,
                               STRIP,
                               P.BATCH_STRATEGY_ID,
                               P.BATCH_RULE_ID,
                               STRWAVEID,
															 p.industry_flag,
                               STROPERATIONTYPE, --界面调用写2
                               STRRESULT);
          IF SUBSTR(STRRESULT, 1, 1) <> 'Y' THEN
            P_WRITELOG(P.BATCH_STRATEGY_ID,
                       P.BATCH_RULE_ID,
                       'N',
                       '写订单池数据失败',
                       STRRESULT,
                       STRWAVEID,
                       'P_AUTO_LOCATE_MAIN');

            GOTO NEXT_V_WAVE;
          END IF;

          --重置作业状态
          UPDATE TMP_ODATA_EXP_M M
             SET M.STATUS = '1'
           WHERE M.ENTERPRISE_NO = STRENTERPRISENO
             AND M.STRIP = STRIP
             AND M.STATUS = '0';

          --查看数据量
          BEGIN
            P_LOCATECHECK_GETDATASIZE(STRENTERPRISENO,
                                      STRIP,
                                      P.BATCH_STRATEGY_ID,
                                      P.BATCH_RULE_ID,
                                      STRWAVEID,
                                      0,
                                      NUM_RECORDCOUNT,
                                      STRRESULT);

            IF SUBSTR(STRRESULT, 1, 1) <> 'Y' THEN
              P_WRITELOG(P.BATCH_STRATEGY_ID,
                         P.BATCH_RULE_ID,
                         'E',
                         '获取待处理任务数量(获取单据后)',
                         STRRESULT,
                         STRWAVEID,
                         'P_AUTO_LOCATE_MAIN');

              GOTO NEXT_V_WAVE;
            END IF;
            IF (NUM_RECORDCOUNT = 0) THEN
              --如果没有记录，则直接进行下一轮规则
              GOTO NEXT_V_WAVE;
            END IF;
          END;

        END;

        --2.1 单据清理
				BEGIN
					--如果策略指定区域出货，则这里需要排除掉所有不含指定区域的单据
					if(p.area_limmit = '1') THEN
					  --如果有限制区域
					  IF(p.area_limmit_value IS NOT NULL) THEN
						   P_LOCATECHECK_LimmitAREA(STRENTERPRISENO,STRIP,p.batch_strategy_id,p.batch_rule_id
							 ,STRWAVEID,p.area_limmit_value,STRRESULT);
						END IF;
					END IF;
				END;

			  --这里判断是否是传统模式
        IF(p.industry_flag = '1') THEN
          P_WRITELOG(U.BATCH_STRATEGY_ID,
                     '0',
                     'N',
                     '传统模式',
                     '这里是传统模式',
                     STRWAVEID,
                     'P_AUTO_LOCATE_MAIN');
				 --这里需要重新取当前分类对应的机构号
            IF (STRORGNO = 'ALL') THEN
              V_STRORGNO := '';
              --如果界面传的ALL。则每个分类重新取机构！
              SELECT M.ORG_NO
                INTO V_STRORGNO
                FROM TMP_ODATA_EXP_M M
               WHERE M.ENTERPRISE_NO = STRENTERPRISENO
                 AND M.STRIP = STRIP
                 AND M.STATUS = '1'
                 AND ROWNUM = 1;
            ELSE
              V_STRORGNO := STRORGNO;
            END IF;

				  --如果是传统模式。则直接全部集单
					 P_LOCATE_CONTROL(STRENTERPRISENO,
                                     STRWAREHOUSENO,
                                     V_OWNER_NO,
                                     P.EXP_TYPE,
                                     STRLOCATENAME,
                                     P.BATCH_STRATEGY_ID,
                                     P.BATCH_RULE_ID,
                                     STRDIVIDEFLAG,
                                     STRSENDBUF_COMPUTE_FLAG,
                                     STRSPECIFYCELL,
                                     NTASKBATCH,
                                     STRSOURCETYPE,
                                     STRDIVIDE_COMPUTE_FLAG,
                                     STRCHECK_COMPUTE_FLAG,
                                     V_STRORGNO,
                                     P.BATCH_COMPUTE,
                                     '0',
                                     P.INDUSTRY_FLAG,
                                     STRIP,
                                     P.LOCATE_STRATEGY_ID,
                                     STRWAVEID,
                                     STRWAVENO,
                                     NUM_BATCHNO,
                                     STRRESULT);
								GOTO NEXT_V_WAVE;
				END IF;

        --3. 归类
        BEGIN
          --初始状态下，所有的单据全部归在1类

          --如果单据对应的承运商限制了独立拣货，则单独出一个分类，未限制的为同一类
          BEGIN
            NUM_NOWTYPE := 0;
            FOR K1 IN (SELECT M.SHIPPER_NO
                         FROM TMP_ODATA_EXP_M M
                        WHERE M.ENTERPRISE_NO = P.ENTERPRISE_NO
                          AND M.STATUS = '1'
                          AND M.SINGLE_LOCATE_FLAG = '1'
                          AND M.STRIP = STRIP
                        GROUP BY M.SHIPPER_NO) LOOP
              --先取出需要独立拣货的所有单据所包含的承运商
              NUM_NOWTYPE := NUM_NOWTYPE + 1;
              UPDATE TMP_ODATA_EXP_M M
                 SET M.ORDERTYPE = M.ORDERTYPE * NUM_BASETYPE + NUM_NOWTYPE
               WHERE M.ENTERPRISE_NO = P.ENTERPRISE_NO
                 AND M.STATUS = '1'
                 AND M.SHIPPER_NO = K1.SHIPPER_NO
                 AND M.STRIP = STRIP;

              STRRESULT := 'E|更新' || SQL%ROWCOUNT || '条记录，承运商：' ||
                           K1.SHIPPER_NO;
              P_WRITELOG(P.BATCH_STRATEGY_ID,
                         P.BATCH_RULE_ID,
                         'E',
                         '归类(独立拣货)',
                         STRRESULT,
                         STRWAVEID,
                         'P_AUTO_LOCATE_MAIN');
            END LOOP;

            NUM_NOWTYPE := NUM_NOWTYPE + 1;
            UPDATE TMP_ODATA_EXP_M M
               SET M.ORDERTYPE = M.ORDERTYPE * NUM_BASETYPE + NUM_NOWTYPE
             WHERE M.ENTERPRISE_NO = P.ENTERPRISE_NO
               AND M.STATUS = '1'
               AND M.SINGLE_LOCATE_FLAG = '0'
               AND M.STRIP = STRIP;

            STRRESULT := 'E|更新' || SQL%ROWCOUNT || '条记录';
            P_WRITELOG(P.BATCH_STRATEGY_ID,
                       P.BATCH_RULE_ID,
                       'E',
                       '归类(非独立拣货)',
                       STRRESULT,
                       STRWAVEID,
                       'P_AUTO_LOCATE_MAIN');
          END;

          --按机构归类
          BEGIN
            NUM_NOWTYPE := 0;
            FOR K2 IN (SELECT M.ORG_NO
                         FROM TMP_ODATA_EXP_M M
                        WHERE M.ENTERPRISE_NO = P.ENTERPRISE_NO
                          AND M.STATUS = '1'
                          AND M.STRIP = STRIP
                        GROUP BY M.ORG_NO) LOOP
              --查出当前所有的机构号，按机构号第一次归类
              NUM_NOWTYPE := NUM_NOWTYPE + 1;
              UPDATE TMP_ODATA_EXP_M M
                 SET M.ORDERTYPE = M.ORDERTYPE * NUM_BASETYPE + NUM_NOWTYPE
               WHERE M.ENTERPRISE_NO = P.ENTERPRISE_NO
                 AND M.STATUS = '1'
                 AND M.ORG_NO = K2.ORG_NO
                 AND M.STRIP = STRIP;

              STRRESULT := 'E|更新' || SQL%ROWCOUNT || '条记录，机构号：' ||
                           K2.ORG_NO;
              P_WRITELOG(P.BATCH_STRATEGY_ID,
                         P.BATCH_RULE_ID,
                         'E',
                         '归类(机构号)',
                         STRRESULT,
                         STRWAVEID,
                         'P_AUTO_LOCATE_MAIN');
            END LOOP;
          END;

           --限制区域的，按区域归类
            BEGIN
              --限制区域，不允许跨区
              IF (P.Area_Allow = '0') THEN
              /*  --先踢无区域和已跨区的单据
                P_LOCATECHECK_AREA(STRENTERPRISENO,
                                   STRIP,
                                   P.BATCH_STRATEGY_ID,
                                   P.BATCH_RULE_ID,
                                   STRWAVEID,
                                   STRRESULT);

                IF SUBSTR(STRRESULT, 1, 1) <> 'Y' THEN
                  P_WRITELOG(P.BATCH_STRATEGY_ID,
                             P.BATCH_RULE_ID,
                             'E',
                             '限制区域-踢除无区域单据',
                             STRRESULT,
                             STRWAVEID,
                             'P_AUTO_LOCATE_MAIN');

                  GOTO NEXT_V_WAVE;
                END IF;
*/
                --归类
                NUM_NOWTYPE := 0;
                FOR K3 IN (SELECT M.AREA
                             FROM TMP_ODATA_EXP_M M
                            WHERE M.ENTERPRISE_NO = P.ENTERPRISE_NO
                              AND M.STATUS = '1'
                              AND M.STRIP = STRIP
                              AND M.AREA IS NOT NULL
                            GROUP BY M.AREA) LOOP
                  --查出当前所有的机构号，按机构号第一次归类
                  NUM_NOWTYPE := NUM_NOWTYPE + 1;
                  UPDATE TMP_ODATA_EXP_M M
                     SET M.ORDERTYPE = M.ORDERTYPE * NUM_BASETYPE +
                                       NUM_NOWTYPE
                   WHERE M.ENTERPRISE_NO = P.ENTERPRISE_NO
                     AND M.STATUS = '1'
                     AND M.AREA = K3.AREA
                     AND M.STRIP = STRIP;

                  STRRESULT := 'E|更新' || SQL%ROWCOUNT || '条记录，区域：' || K3.AREA;
                  P_WRITELOG(P.BATCH_STRATEGY_ID,
                             P.BATCH_RULE_ID,
                             'E',
                             '归类(区域)',
                             STRRESULT,
                             STRWAVEID,
                             'P_AUTO_LOCATE_MAIN');
                END LOOP;
              END IF;
            END;

					--按货主归类
				/*	BEGIN
            NUM_NOWTYPE := 0;
            FOR K4 IN (SELECT M.OWNER_NO
                         FROM TMP_ODATA_EXP_M M
                        WHERE M.ENTERPRISE_NO = P.ENTERPRISE_NO
                          AND M.STATUS = '1'
                          AND M.STRIP = STRIP
                        GROUP BY M.OWNER_NO) LOOP
              --查出当前所有的机构号，按机构号第一次归类
              NUM_NOWTYPE := NUM_NOWTYPE + 1;
              UPDATE TMP_ODATA_EXP_M M
                 SET M.ORDERTYPE = M.ORDERTYPE * NUM_BASETYPE + NUM_NOWTYPE
               WHERE M.ENTERPRISE_NO = P.ENTERPRISE_NO
                 AND M.STATUS = '1'
                 AND M.OWNER_NO = K4.OWNER_NO
                 AND M.STRIP = STRIP;

              STRRESULT := 'E|更新' || SQL%ROWCOUNT || '条记录，货主：' ||
                           K4.OWNER_NO;
              P_WRITELOG(P.BATCH_STRATEGY_ID,
                         P.BATCH_RULE_ID,
                         'E',
                         '归类(货主)',
                         STRRESULT,
                         STRWAVEID,
                         'P_AUTO_LOCATE_MAIN');
            END LOOP;
          END;*/

						--按仓别归类
					/*BEGIN
            NUM_NOWTYPE := 0;
            FOR K5 IN (SELECT M.WAREHOUSE_NO
                         FROM TMP_ODATA_EXP_M M
                        WHERE M.ENTERPRISE_NO = P.ENTERPRISE_NO
                          AND M.STATUS = '1'
                          AND M.STRIP = STRIP
                        GROUP BY M.WAREHOUSE_NO) LOOP
              --查出当前所有的机构号，按机构号第一次归类
              NUM_NOWTYPE := NUM_NOWTYPE + 1;
              UPDATE TMP_ODATA_EXP_M M
                 SET M.ORDERTYPE = M.ORDERTYPE * NUM_BASETYPE + NUM_NOWTYPE
               WHERE M.ENTERPRISE_NO = P.ENTERPRISE_NO
                 AND M.STATUS = '1'
                 AND M.WAREHOUSE_NO = K5.WAREHOUSE_NO
                 AND M.STRIP = STRIP;

              STRRESULT := 'E|更新' || SQL%ROWCOUNT || '条记录，仓别：' ||
                           K5.WAREHOUSE_NO;
              P_WRITELOG(P.BATCH_STRATEGY_ID,
                         P.BATCH_RULE_ID,
                         'E',
                         '归类(仓别)',
                         STRRESULT,
                         STRWAVEID,
                         'P_AUTO_LOCATE_MAIN');
            END LOOP;
          END;
        */


				  --按是否异性品归类
					BEGIN
						--如果不是配置的不限制
						IF(p.rule_flag <> '2') THEN
              NUM_NOWTYPE := 0;
							FOR K6 IN (SELECT M.RULE_FLAG
													 FROM TMP_ODATA_EXP_M M
													WHERE M.ENTERPRISE_NO = P.ENTERPRISE_NO
														AND M.STATUS = '1'
														AND M.STRIP = STRIP
													GROUP BY M.RULE_FLAG) LOOP
								--查出当前所有的异性品限制，按异性品限制归类
								NUM_NOWTYPE := NUM_NOWTYPE + 1;
								UPDATE TMP_ODATA_EXP_M M
									 SET M.ORDERTYPE = M.ORDERTYPE * NUM_BASETYPE + NUM_NOWTYPE
								 WHERE M.ENTERPRISE_NO = P.ENTERPRISE_NO
									 AND M.STATUS = '1'
									 AND M.RULE_FLAG = K6.RULE_FLAG
									 AND M.STRIP = STRIP;

								STRRESULT := 'E|更新' || SQL%ROWCOUNT || '条记录，异性品限制：' ||
													 K6.RULE_FLAG;
								P_WRITELOG(P.BATCH_STRATEGY_ID,
													 P.BATCH_RULE_ID,
													 'E',
													 '归类(异性品限制)',
													 STRRESULT,
													 STRWAVEID,
													 'P_AUTO_LOCATE_MAIN');
							END LOOP;
						END IF;
					END;

				END;

			--4. 根据当前的SKU限制，排除其它单据
        BEGIN
          P_LOCATECHECK_SKUCOUNT(STRENTERPRISENO,
                                 P.SKU_COUNT_MODE,
                                 P.SKUCOUNT,
                                 P.SKU_LIMMIT,
                                 STRIP,
                                 P.BATCH_STRATEGY_ID,
                                 P.BATCH_RULE_ID,
                                 STRWAVEID,
                                 STRRESULT);
          IF SUBSTR(STRRESULT, 1, 1) <> 'Y' THEN
            P_WRITELOG(P.BATCH_STRATEGY_ID,
                       P.BATCH_RULE_ID,
                       'E',
                       '排除非指定SKU数量的单据失败',
                       STRRESULT,
                       STRWAVEID,
                       'P_AUTO_LOCATE_MAIN');

            GOTO NEXT_V_WAVE;
          END IF;
        END;

        --归类完成，按照限制条件踢单
        BEGIN
          --这里循环所有的分类 按分类筛单，生成批次
          FOR Q1 IN (SELECT M.ORDERTYPE
                       FROM TMP_ODATA_EXP_M M
                      WHERE M.ENTERPRISE_NO = STRENTERPRISENO
                        AND M.STRIP = STRIP
                        AND M.STATUS = '1'
                      GROUP BY M.ORDERTYPE) LOOP
            P_WRITELOG(P.BATCH_STRATEGY_ID,
                       P.BATCH_RULE_ID,
                       'E',
                       '循环分类',
                       '当前分类：' || Q1.ORDERTYPE,
                       STRWAVEID,
                       'P_AUTO_LOCATE_MAIN');

            --这里需要重新取当前分类对应的机构号
            IF (STRORGNO = 'ALL') THEN
              V_STRORGNO := '';
              --如果界面传的ALL。则每个分类重新取机构！
              SELECT M.ORG_NO
                INTO V_STRORGNO
                FROM TMP_ODATA_EXP_M M
               WHERE M.ENTERPRISE_NO = STRENTERPRISENO
                 AND M.STRIP = STRIP
                 AND M.STATUS = '1'
                 AND M.ORDERTYPE = Q1.ORDERTYPE
                 AND ROWNUM = 1;
            ELSE
              V_STRORGNO := STRORGNO;
            END IF;

            IF (P.SKU_COUNT_MODE = '1') THEN
              --一单一品，有提总的先跑一轮提总
              IF (P.C_LIMMIT = '1') THEN
                --提总
                FOR Q2 IN (SELECT D.ENTERPRISE_NO,
                                  D.WAREHOUSE_NO,
                                  D.OWNER_NO,
                                  D.ARTICLE_NO,
                                  SUM(D.ARTICLE_QTY) QTY,
                                  A.PACKING_QTY,
                                  MOD(SUM(D.ARTICLE_QTY), A.PACKING_QTY) LS
                             FROM TMP_ODATA_EXP_M      M1,
                                  ODATA_EXP_D          D,
                                  BDEF_ARTICLE_PACKING A
                            WHERE M1.ENTERPRISE_NO = D.ENTERPRISE_NO
                              AND M1.WAREHOUSE_NO = D.WAREHOUSE_NO
                              AND M1.OWNER_NO = D.OWNER_NO
                              AND M1.EXP_NO = D.EXP_NO
                              AND D.ENTERPRISE_NO = A.ENTERPRISE_NO
                              AND D.ARTICLE_NO = A.ARTICLE_NO
                              AND D.ITEM_TYPE = '0'
                              AND M1.ENTERPRISE_NO = STRENTERPRISENO
                              AND M1.STRIP = STRIP
                              AND M1.ORDERTYPE = Q1.ORDERTYPE
                              AND M1.STATUS = '1'
                            GROUP BY D.ENTERPRISE_NO,
                                     D.WAREHOUSE_NO,
                                     D.OWNER_NO,
                                     D.ARTICLE_NO,
                                     A.PACKING_QTY) LOOP
                  --一单一品，直接排除LS数量/最小操作包装的订单即可
                  UPDATE TMP_ODATA_EXP_M MM
                     SET MM.STATUS = '9'
                   WHERE EXISTS
                   (SELECT 1
                            FROM (SELECT *
                                    FROM (SELECT M1.*,aa.qmin_operate_packing
                                            FROM ODATA_EXP_M     M,
                                                 TMP_ODATA_EXP_M M1,
                                                 ODATA_EXP_D     D,
																								 bdef_defarticle aa
                                           WHERE M.WAREHOUSE_NO =
                                                 M1.WAREHOUSE_NO
                                             AND M.ENTERPRISE_NO =
                                                 M1.ENTERPRISE_NO
                                             AND M.OWNER_NO = M1.OWNER_NO
                                             AND M.EXP_NO = M1.EXP_NO
                                             AND M.ENTERPRISE_NO =
                                                 D.ENTERPRISE_NO
                                             AND M.WAREHOUSE_NO =
                                                 D.WAREHOUSE_NO
                                             AND M.OWNER_NO = D.OWNER_NO
                                             AND M.EXP_NO = D.EXP_NO
																						 AND d.article_no = aa.article_no
																						 AND d.enterprise_no = aa.enterprise_no
                                             AND D.ARTICLE_NO = Q2.ARTICLE_NO
                                             AND M1.STRIP = STRIP
                                             AND M1.ORDERTYPE = Q1.ORDERTYPE
                                                --AND M1.OVERTIME = '0'
                                             AND M1.STATUS = '1'
                                           ORDER BY M.RGST_DATE DESC)
                                   WHERE ROWNUM <= (Q2.LS / qmin_operate_packing)) L --删除指定零散量的单据
                           WHERE MM.ENTERPRISE_NO = L.ENTERPRISE_NO
                             AND MM.WAREHOUSE_NO = L.WAREHOUSE_NO
                             AND MM.OWNER_NO = L.OWNER_NO
                             AND MM.EXP_NO = L.EXP_NO
                          --AND MM.OVERTIME = '0'
                          )
                     AND MM.STATUS = '1'
                     AND MM.ORDERTYPE = Q1.ORDERTYPE
                     AND MM.STRIP = STRIP;
                  STRRESULT := 'E|排除了' || SQL%ROWCOUNT || '条记录  商品：' ||
                               Q2.ARTICLE_NO || ' 包装：' || Q2.PACKING_QTY;
                  P_WRITELOG(P.BATCH_STRATEGY_ID,
                             P.BATCH_RULE_ID,
                             'E',
                             '箱限制（一单一品）',
                             STRRESULT,
                             STRWAVEID,
                             'P_AUTO_LOCATE_MAIN');
                END LOOP;

              END IF;

							--标记混拣开始
							<<NEXT_V_MIX>>
							NULL;
              --上下限校验
              BEGIN
                NUM_RECORDCOUNT := 0;
                --查看数据量
                BEGIN
                  P_LOCATECHECK_GETDATASIZE(STRENTERPRISENO,
                                            STRIP,
                                            P.BATCH_STRATEGY_ID,
                                            P.BATCH_RULE_ID,
                                            STRWAVEID,
                                            Q1.ORDERTYPE,
                                            NUM_RECORDCOUNT,
                                            STRRESULT);

                  IF SUBSTR(STRRESULT, 1, 1) <> 'Y' THEN
                    P_WRITELOG(P.BATCH_STRATEGY_ID,
                               P.BATCH_RULE_ID,
                               'E',
                               '获取待处理任务数量(上下限校验)',
                               STRRESULT,
                               STRWAVEID,
                               'P_AUTO_LOCATE_MAIN');
                    GOTO NEXT_V_ORDERTYPE; --获取订单量失败，直接退出当前分类循环
                  END IF;
                  P_WRITELOG(P.BATCH_STRATEGY_ID,
                             P.BATCH_RULE_ID,
                             'E',
                             '获取待处理任务数量(上下限校验)',
                             '当前订单量',
                             STRWAVEID,
                             'P_AUTO_LOCATE_MAIN');
                  IF (NUM_RECORDCOUNT = 0) THEN
                    STRRESULT := 'N|当前分类' || Q1.ORDERTYPE || '没有有效单据！';
                    GOTO NEXT_V_ORDERTYPE; --获取订单量失败，直接退出当前分类循环
                  END IF;
                END;

                --如果限制了下限，则校验下限
                BEGIN
                  IF (P.MIN_ORDER > 0) THEN
                    IF (NUM_RECORDCOUNT < P.MIN_ORDER) THEN
                      --当前记录数小于下限设置
                      P_WRITELOG(P.BATCH_STRATEGY_ID,
                                 P.BATCH_RULE_ID,
                                 'E',
                                 '获取待处理任务数量(下限校验)',
                                 '当前记录数' || NUM_RECORDCOUNT || '未达到下限' ||
                                 P.MIN_ORDER,
                                 STRWAVEID,
                                 'P_AUTO_LOCATE_MAIN');
                      GOTO NEXT_V_ORDERTYPE;
                    END IF;
                  END IF;
                END;

							  --不校验上限
                  P_LOCATE_CONTROL(STRENTERPRISENO,
                                   STRWAREHOUSENO,
                                   V_OWNER_NO,
                                   P.EXP_TYPE,
                                   STRLOCATENAME,
                                   P.BATCH_STRATEGY_ID,
                                   P.BATCH_RULE_ID,
                                   STRDIVIDEFLAG,
                                   STRSENDBUF_COMPUTE_FLAG,
                                   STRSPECIFYCELL,
                                   NTASKBATCH,
                                   STRSOURCETYPE,
                                   STRDIVIDE_COMPUTE_FLAG,
                                   STRCHECK_COMPUTE_FLAG,
                                   V_STRORGNO,
                                   P.BATCH_COMPUTE,
                                   Q1.ORDERTYPE,
                                   P.INDUSTRY_FLAG,
                                   STRIP,
                                   P.LOCATE_STRATEGY_ID,
                                   STRWAVEID,
                                   STRWAVENO,
                                   NUM_BATCHNO,
                                   STRRESULT);

               -- END IF;
              END;

							IF (V_END = '1') THEN
                --如果强制执行，则将剩余单据强行进入批次
                UPDATE TMP_ODATA_EXP_M M
                   SET M.STATUS = '1'
                 WHERE M.STATUS = '9'
                   AND M.STRIP = STRIP
                   AND M.ENTERPRISE_NO = STRENTERPRISENO
                   AND M.ORDERTYPE = Q1.ORDERTYPE;
                STRRESULT := 'E|更新' || SQL%ROWCOUNT || '条记录， 重新校验上下限生成批次！当前分类：' || Q1.ORDERTYPE;
								P_WRITELOG(P.BATCH_STRATEGY_ID,
													 P.BATCH_RULE_ID,
													 'E',
													 '一单一品强制执行！',
													 STRRESULT,
													 STRWAVEID,
													 'P_AUTO_LOCATE_MAIN');
								--校验是否还有剩余的记录，有则强制生成批次
 							  IF (SQL%ROWCOUNT > 0) THEN
                   GOTO NEXT_V_MIX;
								END  IF;
              END IF;
            ELSE
              --一单多品
              IF (P.REPEAT_TIMES > 0) THEN
                --聚类是在循环内部校验及创建批次
                BEGIN
                  --1. 先查出当前分类下大于等于设定的重复度的所有商品及其重复度，写入临时表 TMP_LOCATE_CLUSTERING1
                  BEGIN
                    DELETE TMP_LOCATE_CLUSTERING1 T WHERE T.STRIP = STRIP;

                    INSERT INTO TMP_LOCATE_CLUSTERING1
                      (STRIP, ARTICLE_NO, DUPLICATIONCOUNT, ALEVEL)
                      SELECT *
                        FROM (SELECT M.STRIP,
                                     D.ARTICLE_NO,
                                     COUNT(D.ARTICLE_NO) DUPLICATIONCOUNT,
                                     1
                                FROM TMP_ODATA_EXP_M M, ODATA_EXP_D D
                               WHERE M.ENTERPRISE_NO = D.ENTERPRISE_NO
                                 AND M.WAREHOUSE_NO = D.WAREHOUSE_NO
                                 AND M.OWNER_NO = D.OWNER_NO
                                 AND M.EXP_NO = D.EXP_NO
                                 AND M.STRIP = STRIP
                                 AND M.ENTERPRISE_NO = P.ENTERPRISE_NO
                                 AND M.ORDERTYPE = Q1.ORDERTYPE
                                 AND M.STATUS = '1'
                               GROUP BY M.STRIP, D.ARTICLE_NO) A
                       WHERE A.DUPLICATIONCOUNT >= P.REPEAT_TIMES;
                    STRRESULT := 'E|当前新增了' || SQL%ROWCOUNT || '条记录 ';
                    P_WRITELOG(P.BATCH_STRATEGY_ID,
                               P.BATCH_RULE_ID,
                               'E',
                               '一单多品写TMP_LOCATE_CLUSTERING1',
                               STRRESULT,
                               STRWAVEID,
                               'P_AUTO_LOCATE_MAIN');
                  END;
                  --2. 将当前分类下的所有订单，写入临时表TMP_LOCATE_CLUSTERING2
                  BEGIN
                    DELETE TMP_LOCATE_CLUSTERING2 T WHERE T.STRIP = STRIP;

                    INSERT INTO TMP_LOCATE_CLUSTERING2
                      (STRIP, EXP_NO, ARTICLE_NO, ELEVEL)
                      SELECT DISTINCT M.STRIP, M.EXP_NO, D.ARTICLE_NO, 1
                        FROM TMP_ODATA_EXP_M M, ODATA_EXP_D D
                       WHERE M.ENTERPRISE_NO = D.ENTERPRISE_NO
                         AND M.WAREHOUSE_NO = D.WAREHOUSE_NO
                         AND M.OWNER_NO = D.OWNER_NO
                         AND M.EXP_NO = D.EXP_NO
                         AND M.STRIP = STRIP
                         AND M.ENTERPRISE_NO = P.ENTERPRISE_NO
                         AND M.ORDERTYPE = Q1.ORDERTYPE;
                    STRRESULT := 'E|当前新增了' || SQL%ROWCOUNT || '条记录 ';
                    P_WRITELOG(P.BATCH_STRATEGY_ID,
                               P.BATCH_RULE_ID,
                               'E',
                               '一单多品写TMP_LOCATE_CLUSTERING2',
                               STRRESULT,
                               STRWAVEID,
                               'P_AUTO_LOCATE_MAIN');

                  END;
                  --调聚类过程
                  BEGIN

				            DELETE TMP_LOCATE_CLUSTERING3 t WHERE t.strip = STRIP;
                    STR_TMP_ARTICLENOS   := '';
                    STR_TMP_ARTICLECOUNT := 0;
                    STR_TMP_ISSUCCESS    := 0; --默认不成功
                    P_LOCATECHECK_CLUSTERING(P.BATCH_STRATEGY_ID,
                                             P.BATCH_RULE_ID,
                                             STRWAVEID,
                                             P.SKU_LIMMIT,
                                             P.SKUCOUNT,
                                             P.REPEAT_TIMES,
                                             Q1.ORDERTYPE,
                                             STRIP,
                                             1,
                                             1,
                                             STR_TMP_FAILARTICLES,
                                             STR_TMP_ARTICLENOS,
                                             STR_TMP_ARTICLECOUNT,
                                             STR_TMP_ISSUCCESS,
                                             STRENTERPRISENO,
                                             STRWAREHOUSENO,
                                             V_OWNER_NO,
                                             P.EXP_TYPE,
                                             STRLOCATENAME,
                                             STRDIVIDEFLAG,
                                             STRSENDBUF_COMPUTE_FLAG,
                                             STRSPECIFYCELL,
                                             NTASKBATCH,
                                             STRSOURCETYPE,
                                             STRDIVIDE_COMPUTE_FLAG,
                                             STRCHECK_COMPUTE_FLAG,
                                             V_STRORGNO,
                                             P.BATCH_COMPUTE,
                                             P.INDUSTRY_FLAG,
                                             P.LOCATE_STRATEGY_ID,
                                             STRWAVENO,
                                             NUM_BATCHNO,
                                             STRRESULT);

                  END;

                  IF (V_END = '1') THEN
                    --如果是强制生成批次时，则将剩余未处理的单据强行生成批次
                    UPDATE TMP_ODATA_EXP_M M
											 SET M.STATUS = '1'
										 WHERE M.STATUS IN('8','9')
											 AND M.STRIP = STRIP
											 AND M.ENTERPRISE_NO = STRENTERPRISENO
                       AND M.ORDERTYPE = Q1.ORDERTYPE;
                    STRRESULT := 'E|当前重置了' || SQL%ROWCOUNT || '条记录 ';
                    P_WRITELOG(P.BATCH_STRATEGY_ID,
                               P.BATCH_RULE_ID,
                               'E',
                               '强制一单多品，进行混拣',
                               STRRESULT,
                               STRWAVEID,
                               'P_AUTO_LOCATE_MAIN');
                  END IF;
                END;
              END IF;
							--如果没有限制重复度，表示混拣，或者是强制执行的。也进行一次混拣
              IF(P.REPEAT_TIMES = 0 OR V_END = '1') THEN
                --混拣 暂时不考虑箱拣，不考虑只设置重复度或SKU限制的
                --上下限校验
                BEGIN
                  NUM_RECORDCOUNT := 0;
                  --查看数据量
                  BEGIN
                    P_LOCATECHECK_GETDATASIZE(STRENTERPRISENO,
                                              STRIP,
                                              P.BATCH_STRATEGY_ID,
                                              P.BATCH_RULE_ID,
                                              STRWAVEID,
                                              Q1.ORDERTYPE,
                                              NUM_RECORDCOUNT,
                                              STRRESULT);

                    IF SUBSTR(STRRESULT, 1, 1) <> 'Y' THEN
                      P_WRITELOG(P.BATCH_STRATEGY_ID,
                                 P.BATCH_RULE_ID,
                                 'E',
                                 '获取待处理任务数量(上下限校验)',
                                 STRRESULT,
                                 STRWAVEID,
                                 'P_AUTO_LOCATE_MAIN');
                      GOTO NEXT_V_ORDERTYPE; --获取订单量失败，直接退出当前分类循环
                    END IF;
                    P_WRITELOG(P.BATCH_STRATEGY_ID,
                               P.BATCH_RULE_ID,
                               'E',
                               '获取待处理任务数量(上下限校验)',
                               '当前订单量 ：' || NUM_RECORDCOUNT,
                               STRWAVEID,
                               'P_AUTO_LOCATE_MAIN');
                    IF (NUM_RECORDCOUNT = 0) THEN
                      STRRESULT := 'N|当前分类' || Q1.ORDERTYPE || '没有有效单据！';
                      GOTO NEXT_V_ORDERTYPE; --获取订单量失败，直接退出当前分类循环
                    END IF;
                  END;

                  --如果限制了下限，则校验下限
                  BEGIN
                    IF (P.MIN_ORDER > 0) THEN
                      IF (NUM_RECORDCOUNT < P.MIN_ORDER) THEN
                        --当前记录数小于下限设置
                        P_WRITELOG(P.BATCH_STRATEGY_ID,
                                   P.BATCH_RULE_ID,
                                   'E',
                                   '获取待处理任务数量(下限校验)',
                                   '当前记录数' || NUM_RECORDCOUNT || '未达到下限' ||
                                   P.MIN_ORDER,
                                   STRWAVEID,
                                   'P_AUTO_LOCATE_MAIN');
                        GOTO NEXT_V_ORDERTYPE;
                      END IF;
                    END IF;
                  END;

                  --上限
                  IF (P.TASK_ORDER > 0) THEN
                    --1、先检查是否达到上限
                    IF (NUM_RECORDCOUNT < P.TASK_ORDER) THEN
                      --这里可以正常组一个批次
                      P_LOCATE_CONTROL(STRENTERPRISENO,
                                       STRWAREHOUSENO,
                                       V_OWNER_NO,
                                       P.EXP_TYPE,
                                       STRLOCATENAME,
                                       P.BATCH_STRATEGY_ID,
                                       P.BATCH_RULE_ID,
                                       STRDIVIDEFLAG,
                                       STRSENDBUF_COMPUTE_FLAG,
                                       STRSPECIFYCELL,
                                       NTASKBATCH,
                                       STRSOURCETYPE,
                                       STRDIVIDE_COMPUTE_FLAG,
                                       STRCHECK_COMPUTE_FLAG,
                                       V_STRORGNO,
                                       P.BATCH_COMPUTE,
                                       Q1.ORDERTYPE,
                                       P.INDUSTRY_FLAG,
                                       STRIP,
                                       P.LOCATE_STRATEGY_ID,
                                       STRWAVEID,
                                       STRWAVENO,
                                       NUM_BATCHNO,
                                       STRRESULT);
                    ELSE
                      --将当前分类的有效单据写成一个临时状态
                      UPDATE TMP_ODATA_EXP_M M
                         SET M.STATUS = '3'
                       WHERE M.STATUS = '1'
                         AND M.STRIP = STRIP
                         AND M.ENTERPRISE_NO = STRENTERPRISENO
                         AND M.ORDERTYPE = Q1.ORDERTYPE;
                      STRRESULT := 'E|排除了' || SQL%ROWCOUNT || '条记录 ';
                      P_WRITELOG(P.BATCH_STRATEGY_ID,
                                 P.BATCH_RULE_ID,
                                 'E',
                                 '变更临时操作状态',
                                 STRRESULT,
                                 STRWAVEID,
                                 'P_AUTO_LOCATE_MAIN');
                      --这里做一个循环，只是按数量筛单用
                      LOOP
                        --1.先统计当前待处理单据的数量
                        BEGIN
                          NUM_RECORDCOUNT := 0;
                          SELECT COUNT(0)
                            INTO NUM_RECORDCOUNT
                            FROM TMP_ODATA_EXP_M M
                           WHERE M.STRIP = STRIP
                             AND M.ENTERPRISE_NO = STRENTERPRISENO
                             AND M.ORDERTYPE = Q1.ORDERTYPE
                             AND M.STATUS = '3';
                          STRRESULT := '当前待处理的单据数量： ' || NUM_RECORDCOUNT;
                          P_WRITELOG(P.BATCH_STRATEGY_ID,
                                     P.BATCH_RULE_ID,
                                     'E',
                                     '当前待处理的单据量',
                                     STRRESULT,
                                     STRWAVEID,
                                     'P_AUTO_LOCATE_MAIN');
                          IF (NUM_RECORDCOUNT = 0) THEN
                            EXIT;
                          END IF;
                        END;

											---这里需要取出当前单据所含品项所在的储位！根据储位排序
											---如果当前的单据没有跨区，只取当前所含品项所在的最小储位
											---已跨区的单据放在最后处理
											---同一区域下，如果单据量能组成批次，则放在一个批次

											BEGIN
												--1. 先检查当前分类下，含单据数量最大的区域，是否能组成批次
												V_K_AREA :='';
												V_K_RN := 0;
												--每次取最大的一个区域
												BEGIN
												SELECT L.area,L.rn INTO V_K_AREA,V_K_RN FROM
												(SELECT * FROM (SELECT m2.area,COUNT(0) rn
												       FROM TMP_ODATA_EXP_M M2
															 WHERE M2.STATUS = '3'
																 AND M2.STRIP = STRIP
																 AND M2.ENTERPRISE_NO = STRENTERPRISENO
																 AND M2.ORDERTYPE = Q1.ORDERTYPE
																 AND m2.area IS NOT NULL -- 不取跨区的单据
																 GROUP BY m2.area
																 )K WHERE rn >= P.TASK_ORDER ORDER BY k.area ASC) L WHERE ROWNUM = 1;

												EXCEPTION
													WHEN OTHERS THEN
														V_K_AREA :='';
												    V_K_RN := 0;
												END;
												IF(V_K_RN > P.TASK_ORDER) THEN
												 --如果当前的单据量大于上限值，则处理当前区域的所有单据
												 BEGIN
													 --这里重算分类
													 NUM_NOWTYPE := 1;
												  UPDATE TMP_ODATA_EXP_M M
                           SET M.STATUS = '1'--,M.ORDERTYPE = M.ORDERTYPE * NUM_BASETYPE + NUM_NOWTYPE
                         WHERE M.STATUS = '3'
                           AND M.STRIP = STRIP
                           AND M.ENTERPRISE_NO = STRENTERPRISENO
                           AND M.ORDERTYPE = Q1.ORDERTYPE
                           AND EXISTS
                         (SELECT 1
                                  FROM (SELECT * FROM (SELECT *
                                          FROM TMP_ODATA_EXP_M M2
                                         WHERE M2.STATUS = '3'
                                           AND M2.STRIP = STRIP
                                           AND M2.ENTERPRISE_NO = STRENTERPRISENO
                                           AND M2.ORDERTYPE = Q1.ORDERTYPE
																					 AND m2.area = V_K_AREA --查指定区域的数据
                                          -- AND ROWNUM <= P.TASK_ORDER
																				 ORDER BY M2.CELL_NO ASC --按储位升序
																				) WHERE ROWNUM <= P.TASK_ORDER
																				) M1
                                 WHERE M.ENTERPRISE_NO = M1.ENTERPRISE_NO
                                   AND M.WAREHOUSE_NO = M1.WAREHOUSE_NO
                                   AND M.OWNER_NO = M1.OWNER_NO
                                   AND M.EXP_NO = M1.EXP_NO);
                        STRRESULT := 'E|当前处理了' || SQL%ROWCOUNT || '条记录 V_K_RN='||V_K_RN;
                        P_WRITELOG(P.BATCH_STRATEGY_ID,
                                   P.BATCH_RULE_ID,
                                   'E',
                                   '处理当前单据操作状态1',
                                   STRRESULT,
                                   STRWAVEID,
                                   'P_AUTO_LOCATE_MAIN');
                        --END IF;
                        --组批次
                        P_LOCATE_CONTROL(STRENTERPRISENO,
                                         STRWAREHOUSENO,
                                         V_OWNER_NO,
                                         P.EXP_TYPE,
                                         STRLOCATENAME,
                                         P.BATCH_STRATEGY_ID,
                                         P.BATCH_RULE_ID,
                                         STRDIVIDEFLAG,
                                         STRSENDBUF_COMPUTE_FLAG,
                                         STRSPECIFYCELL,
                                         NTASKBATCH,
                                         STRSOURCETYPE,
                                         STRDIVIDE_COMPUTE_FLAG,
                                         STRCHECK_COMPUTE_FLAG,
                                         V_STRORGNO,
                                         P.BATCH_COMPUTE,
                                         Q1.ORDERTYPE,--Q1.ORDERTYPE * NUM_BASETYPE + NUM_NOWTYPE,--
                                         P.INDUSTRY_FLAG,
                                         STRIP,
                                         P.LOCATE_STRATEGY_ID,
                                         STRWAVEID,
                                         STRWAVENO,
                                         NUM_BATCHNO,
                                         STRRESULT);
													END;

												ELSE
													--这里需要重算
													V_K_AREA :='';
													V_K_RN := 0;
													--每次取最大的一个区域
													BEGIN
													SELECT L.area,L.rn INTO V_K_AREA,V_K_RN FROM
													(SELECT * FROM (SELECT m2.area,COUNT(0) rn
																 FROM TMP_ODATA_EXP_M M2
																 WHERE M2.STATUS = '3'
																	 AND M2.STRIP = STRIP
																	 AND M2.ENTERPRISE_NO = STRENTERPRISENO
																	 AND M2.ORDERTYPE = Q1.ORDERTYPE
																	 AND m2.area IS NOT NULL -- 不取跨区的单据
																	 GROUP BY m2.area
																	 )K /*WHERE rn >= P.TASK_ORDER*/ ORDER BY k.area ASC) L WHERE ROWNUM = 1;

													EXCEPTION
														WHEN OTHERS THEN
															V_K_AREA :='';
															V_K_RN := 0;
													END;

												  if(V_K_RN > 0) THEN

													--这里按货位排序。不考虑区域
													begin
														UPDATE TMP_ODATA_EXP_M M
															 SET M.STATUS = '1'
														 WHERE M.STATUS = '3'
															 AND M.STRIP = STRIP
															 AND M.ENTERPRISE_NO = STRENTERPRISENO
															 AND M.ORDERTYPE = Q1.ORDERTYPE
															 AND EXISTS
														 (SELECT 1
																			FROM (SELECT *
																							FROM TMP_ODATA_EXP_M M2
																						 WHERE M2.STATUS = '3'
																							 AND M2.STRIP = STRIP
																							 AND M2.ENTERPRISE_NO = STRENTERPRISENO
																							 AND M2.ORDERTYPE = Q1.ORDERTYPE
																							 AND ROWNUM <= P.TASK_ORDER
																							 AND m2.area IS NOT NULL
																						 ORDER BY M2.CELL_NO ASC
																						) M1
																		 WHERE M.ENTERPRISE_NO = M1.ENTERPRISE_NO
																			 AND M.WAREHOUSE_NO = M1.WAREHOUSE_NO
																			 AND M.OWNER_NO = M1.OWNER_NO
																			 AND M.EXP_NO = M1.EXP_NO);
														STRRESULT := 'E|当前处理了' || SQL%ROWCOUNT || '条记录  V_K_RN='||V_K_RN;
														P_WRITELOG(P.BATCH_STRATEGY_ID,
																			 P.BATCH_RULE_ID,
																			 'E',
																			 '处理当前单据操作状态2',
																			 STRRESULT,
																			 STRWAVEID,
																			 'P_AUTO_LOCATE_MAIN');
														--END IF;
														--组批次
														P_LOCATE_CONTROL(STRENTERPRISENO,
																						 STRWAREHOUSENO,
																						 V_OWNER_NO,
																						 P.EXP_TYPE,
																						 STRLOCATENAME,
																						 P.BATCH_STRATEGY_ID,
																						 P.BATCH_RULE_ID,
																						 STRDIVIDEFLAG,
																						 STRSENDBUF_COMPUTE_FLAG,
																						 STRSPECIFYCELL,
																						 NTASKBATCH,
																						 STRSOURCETYPE,
																						 STRDIVIDE_COMPUTE_FLAG,
																						 STRCHECK_COMPUTE_FLAG,
																						 V_STRORGNO,
																						 P.BATCH_COMPUTE,
																						 Q1.ORDERTYPE,
																						 P.INDUSTRY_FLAG,
																						 STRIP,
																						 P.LOCATE_STRATEGY_ID,
																						 STRWAVEID,
																						 STRWAVENO,
																						 NUM_BATCHNO,
																						 STRRESULT);
														END;

													ELSE

													--这里按货位排序。不考虑区域
													begin
														UPDATE TMP_ODATA_EXP_M M
															 SET M.STATUS = '1'
														 WHERE M.STATUS = '3'
															 AND M.STRIP = STRIP
															 AND M.ENTERPRISE_NO = STRENTERPRISENO
															 AND M.ORDERTYPE = Q1.ORDERTYPE
															 AND EXISTS
														 (SELECT 1
																			FROM (SELECT *
																							FROM TMP_ODATA_EXP_M M2
																						 WHERE M2.STATUS = '3'
																							 AND M2.STRIP = STRIP
																							 AND M2.ENTERPRISE_NO = STRENTERPRISENO
																							 AND M2.ORDERTYPE = Q1.ORDERTYPE
																							 AND ROWNUM <= P.TASK_ORDER
																						 ORDER BY M2.CELL_NO ASC
																						) M1
																		 WHERE M.ENTERPRISE_NO = M1.ENTERPRISE_NO
																			 AND M.WAREHOUSE_NO = M1.WAREHOUSE_NO
																			 AND M.OWNER_NO = M1.OWNER_NO
																			 AND M.EXP_NO = M1.EXP_NO);
														STRRESULT := 'E|当前处理了' || SQL%ROWCOUNT || '条记录  V_K_RN='||V_K_RN;
														P_WRITELOG(P.BATCH_STRATEGY_ID,
																			 P.BATCH_RULE_ID,
																			 'E',
																			 '处理当前单据操作状态3',
																			 STRRESULT,
																			 STRWAVEID,
																			 'P_AUTO_LOCATE_MAIN');
														--END IF;
														--组批次
														P_LOCATE_CONTROL(STRENTERPRISENO,
																						 STRWAREHOUSENO,
																						 V_OWNER_NO,
																						 P.EXP_TYPE,
																						 STRLOCATENAME,
																						 P.BATCH_STRATEGY_ID,
																						 P.BATCH_RULE_ID,
																						 STRDIVIDEFLAG,
																						 STRSENDBUF_COMPUTE_FLAG,
																						 STRSPECIFYCELL,
																						 NTASKBATCH,
																						 STRSOURCETYPE,
																						 STRDIVIDE_COMPUTE_FLAG,
																						 STRCHECK_COMPUTE_FLAG,
																						 V_STRORGNO,
																						 P.BATCH_COMPUTE,
																						 Q1.ORDERTYPE,
																						 P.INDUSTRY_FLAG,
																						 STRIP,
																						 P.LOCATE_STRATEGY_ID,
																						 STRWAVEID,
																						 STRWAVENO,
																						 NUM_BATCHNO,
																						 STRRESULT);
														END;

													END IF;

												END IF;

											END;

											END LOOP;

                    END IF;
                  ELSE
                    --不校验上限
                    P_LOCATE_CONTROL(STRENTERPRISENO,
                                     STRWAREHOUSENO,
                                     V_OWNER_NO,
                                     P.EXP_TYPE,
                                     STRLOCATENAME,
                                     P.BATCH_STRATEGY_ID,
                                     P.BATCH_RULE_ID,
                                     STRDIVIDEFLAG,
                                     STRSENDBUF_COMPUTE_FLAG,
                                     STRSPECIFYCELL,
                                     NTASKBATCH,
                                     STRSOURCETYPE,
                                     STRDIVIDE_COMPUTE_FLAG,
                                     STRCHECK_COMPUTE_FLAG,
                                     V_STRORGNO,
                                     P.BATCH_COMPUTE,
                                     Q1.ORDERTYPE,
                                     P.INDUSTRY_FLAG,
                                     STRIP,
                                     P.LOCATE_STRATEGY_ID,
                                     STRWAVEID,
                                     STRWAVENO,
                                     NUM_BATCHNO,
                                     STRRESULT);

                  END IF;
                END;

              END IF;
            END IF;
            --跳出当前的分类
            <<NEXT_V_ORDERTYPE>>
            NULL;
          END LOOP;
        END;

        --跳出当前的规则，进行下一个规则 这里要记录当前执行时间
        <<NEXT_V_WAVE>>
        NULL;

        --记录当前规则的执行时间
        BEGIN
          --只有底层自动需要校验执行时间
          IF (STROPERATIONTYPE = '1') THEN
            NUM_RECORDCOUNT := 0;
            SELECT COUNT(0)
              INTO NUM_RECORDCOUNT
              FROM WMS_JOB_CONFIG J
             WHERE J.DRIVE_TABLE = 'WMS_OUTWAVEPLAN_D'
               AND J.PROC_NAME = 'INTERVAL_TIMES' || P.BATCH_RULE_ID
               AND J.ENTERPRISE_NO = STRENTERPRISENO
               AND J.WAREHOUSE_NO = STRWAREHOUSENO
               AND J.OWNER_NO = V_OWNER_NO;

            IF (NUM_RECORDCOUNT = 0) THEN
              INSERT INTO WMS_JOB_CONFIG
                (ENTERPRISE_NO,
                 WAREHOUSE_NO,
                 PROC_NAME,
                 PROC_NAME_DESC,
                 START_TIME_LIMIT,
                 END_TIME_LIMIT,
                 LAST_RUN_TIME,
                 DRIVE_TABLE,
                 RUN_COUNT_TYPE,
                 RUN_TIME_INTERVAL,
                 OWNER_NO)
              VALUES
                (P.ENTERPRISE_NO,
                 STRWAREHOUSENO,
                 'INTERVAL_TIMES' || P.BATCH_RULE_ID,
                 '波次试算规则明细' || P.BATCH_RULE_ID,
                 '00:00:00',
                 '23:59:59',
                 SYSDATE,
                 'WMS_OUTWAVEPLAN_D',
                 1,
                 P.INTERVAL_TIMES,
                 V_OWNER_NO);
            ELSE
              --存在则更新
              UPDATE WMS_JOB_CONFIG J
                 SET J.LAST_RUN_TIME = SYSDATE
               WHERE J.DRIVE_TABLE = 'WMS_OUTWAVEPLAN_D'
                 AND J.PROC_NAME = 'INTERVAL_TIMES' || P.BATCH_RULE_ID
                 AND J.WAREHOUSE_NO = STRWAREHOUSENO
                 AND J.ENTERPRISE_NO = P.ENTERPRISE_NO
                 AND J.OWNER_NO = V_OWNER_NO;
            END IF;

            IF SQL%ROWCOUNT <= 0 THEN
              STRRESULT := 'N|写WMS_JOB_CONFIG表记录失败！';
              P_WRITELOG(P.BATCH_STRATEGY_ID,
                         P.BATCH_RULE_ID,
                         'N',
                         '写上次规则执行时间失败',
                         STRRESULT,
                         STRWAVEID,
                         'P_AUTO_LOCATE_MAIN');
            ELSE
              STRRESULT := 'E|更新' || SQL%ROWCOUNT ||
                           '行记录！PROC_NAME = INTERVAL_TIMES' ||
                           P.BATCH_RULE_ID;
              P_WRITELOG(P.BATCH_STRATEGY_ID,
                         P.BATCH_RULE_ID,
                         'N',
                         '写上次规则执行时间成功',
                         STRRESULT,
                         STRWAVEID,
                         'P_AUTO_LOCATE_MAIN');
            END IF;

          END IF;
        END;

        --跳出当前的规则，进行下一个规则 这里直接结束当前规则
        <<NEXT_V_WAVE_END>>
        NULL;
      END LOOP; --循环批次

/*      IF (STRWAVENO IS NULL )THEN
				STRRESULT := 'N|集单失败！';
			END IF;*/

      --在这里调定位
      IF (STRWAVENO IS NOT NULL AND STRAUTOLOCATE = '1') THEN

        --自动定位上一个波次
        PKLG_OLOCATE.P_LOCATE_MAIN(STRENTERPRISENO,
                                   STRWAREHOUSENO,
                                   STRWAVENO,
                                   STRLOCATENAME,
                                   STRRESULT);
        IF SUBSTR(STRRESULT, 1, 1) <> 'Y' THEN
          P_WRITELOG(U.BATCH_STRATEGY_ID,
                     '0',
                     'N',
                     '自动定位失败！波次号：' || STRWAVENO,
                     STRRESULT,
                     STRWAVEID,
                     'P_AUTO_LOCATE_MAIN');
          ROLLBACK;
          RETURN;
        ELSE
          P_WRITELOG(U.BATCH_STRATEGY_ID,
                     '0',
                     'E',
                     '自动定位成功！波次号：' || STRWAVENO,
                     STRRESULT,
                     STRWAVEID,
                     'P_AUTO_LOCATE_MAIN');
          COMMIT;
        END IF;

      END IF;

    END LOOP; --循环波次

		IF (V_MixOwnerExp = '1') THEN
			EXIT; -- 如果是混货主的。则前面传到底层处理的货主是ALL，则这里只需要循环一次
		END IF;
	END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      IF (STRAUTOLOCATE = '1') THEN
        ROLLBACK;
      END IF;
      STRRESULT := 'N|' || SQLERRM ||
                   SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
  END P_AUTO_LOCATE_MAIN;

   /*****************************************************************************************
     功能：写执行临时表
  *****************************************************************************************/
  PROCEDURE P_WRITETMP_ODATA_EXP(STRENTERPRISENO  IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                                 STRWAREHOUSENO   IN ODATA_LOCATE_M.WAREHOUSE_NO%TYPE, --仓别(不限制可以传ALL)
                                 STROWNERNO       IN ODATA_LOCATE_M.OWNER_NO%TYPE, --货主(不限制可以传ALL)
                                 STRORG_NO        IN ODATA_EXP_M.ORG_NO%TYPE, --机构(前台集单可能传)
                               STREXPTYPE              IN ODATA_LOCATE_M.EXP_TYPE%TYPE, --出货单类型
                                 STRIP            IN TMP_ODATA_EXP_M.STRIP%TYPE, --IP
                                 STRATEGY_ID      IN WMS_OUTWAVEPLAN_D.BATCH_STRATEGY_ID%TYPE, --策略ID
                                 STRBATCH_RULE_ID IN WMS_OUTWAVEPLAN_D.BATCH_RULE_ID%TYPE, --规则ID
                                 STRWAVEID        IN TMP_LOCATEBATCH_LOG.WAVEID%TYPE, --波次流水（时间戳）
                             STRINDUSTRY_FLAG      IN ODATA_LOCATE_M.INDUSTRY_FLAG%TYPE, --行业标识
                                 STRTYPE          IN VARCHAR2, --操作类型 1：底层自动，2：前台自动，--3:前台手动
                                 STRRESULT        OUT VARCHAR2) IS
    --PRAGMA AUTONOMOUS_TRANSACTION;
    V_SQL VARCHAR2(6000); --查询SQL
  BEGIN
    STRRESULT := 'N|P_WRITETMP_ODATA_EXP！';

    --写记录时，先清一次记录
    DELETE TMP_ODATA_EXP_M M WHERE M.STRIP = STRIP;

    V_SQL := '';
    FOR P IN (SELECT DISTINCT A.*
                FROM (SELECT C.*
                        FROM V_GETAUTOLOCATEBATCHINFO C
                       WHERE C.STATUS = '1' --只查询有效的规则
                         AND C.ENTERPRISE_NO = STRENTERPRISENO
                         AND 1 = (CASE
                               WHEN STRTYPE = '3' THEN
                                0
                               ELSE
                                1
                             END)
												 AND C.EXP_TYPE = (CASE
															 WHEN STREXPTYPE = 'ALL' THEN
																C.EXP_TYPE
															 ELSE
																STREXPTYPE
														 END)
                         AND C.BATCH_STRATEGY_ID = STRATEGY_ID
                         AND C.BATCH_RULE_ID = STRBATCH_RULE_ID
                      UNION ALL
                      SELECT C.*
                        FROM V_GETMANUALLOCATEBATCHINFO C
                       WHERE C.STATUS = '1' --只查询有效的规则
                         AND C.ENTERPRISE_NO = STRENTERPRISENO
                         AND 1 = (CASE
                               WHEN STRTYPE = '3' THEN
                                1
                               ELSE
                                0
                             END)
												 AND C.EXP_TYPE = (CASE
															 WHEN STREXPTYPE = 'ALL' THEN
																C.EXP_TYPE
															 ELSE
																STREXPTYPE
														 END)
                         AND C.BATCH_STRATEGY_ID = STRATEGY_ID
                         AND C.BATCH_RULE_ID = STRBATCH_RULE_ID) A) LOOP
      --拼接SQL
      IF (STRTYPE = '1') THEN
        V_SQL := 'INSERT INTO TMP_ODATA_EXP_M
              (ENTERPRISE_NO,
               WAREHOUSE_NO,
               OWNER_NO,
               EXP_NO,
               DELIVER_ADDRESS,
               DELIVER_TYPE,
               ORDER_SOURCE,
               SHIPPER_NO,
               SINGLE_LOCATE_FLAG,
               AREA,CELL_NO,WARENO_AREANOS,RULE_FLAG,
               STATUS,
               STRIP,
               ORG_NO,
               OVERTIME)
              SELECT M.ENTERPRISE_NO,
                     M.WAREHOUSE_NO,
                     M.OWNER_NO,
                     M.EXP_NO,
                     M.DELIVER_ADDRESS,
                     M.DELIVER_TYPE,
                     M.ORDER_SOURCE,
                     M.SHIPPER_NO,
                     ''0'',
                     PKLG_ODISPATCH.F_GETAREABYEXPNO(M.ENTERPRISE_NO,
                                      M.WAREHOUSE_NO,
                                      M.OWNER_NO,
                                      M.EXP_NO),
                     PKLG_ODISPATCH.F_GETCELLNOBYEXPNO(M.ENTERPRISE_NO,
                                      M.WAREHOUSE_NO,
                                      M.OWNER_NO,
                                      M.EXP_NO),
                     PKLG_ODISPATCH.F_getAllAreaByExpNO(M.ENTERPRISE_NO,
                                      M.WAREHOUSE_NO,
                                      M.OWNER_NO,
                                      M.EXP_NO),
                     PKLG_ODISPATCH.F_setRuleFlagByExpNO(M.ENTERPRISE_NO,
                                      M.WAREHOUSE_NO,
                                      M.OWNER_NO,
                                      M.EXP_NO),
                     ''0'',
                     ''' || STRIP || ''',
                     M.ORG_NO,
                     CASE
                       WHEN SYSDATE > M.RGST_DATE + ' ||
                 P.WAIT_TIMES || ' / (24 * 60) THEN
                        ''1''
                       ELSE
                        ''0''
                     END
                FROM ODATA_EXP_M M
               WHERE M.STATUS = ''10''';
      ELSE
        V_SQL := 'INSERT INTO TMP_ODATA_EXP_M
              (ENTERPRISE_NO,
               WAREHOUSE_NO,
               OWNER_NO,
               EXP_NO,
               DELIVER_ADDRESS,
               DELIVER_TYPE,
               ORDER_SOURCE,
               SHIPPER_NO,
               SINGLE_LOCATE_FLAG,
               AREA,CELL_NO,WARENO_AREANOS,RULE_FLAG,
               STATUS,
               STRIP,
               ORG_NO,
               OVERTIME)
              SELECT M.ENTERPRISE_NO,
                     M.WAREHOUSE_NO,
                     M.OWNER_NO,
                     M.EXP_NO,
                     M.DELIVER_ADDRESS,
                     M.DELIVER_TYPE,
                     M.ORDER_SOURCE,
                     M.SHIPPER_NO,
                     ''0'',
                     PKLG_ODISPATCH.F_GETAREABYEXPNO(M.ENTERPRISE_NO,
                                      M.WAREHOUSE_NO,
                                      M.OWNER_NO,
                                      M.EXP_NO),
                     PKLG_ODISPATCH.F_GETCELLNOBYEXPNO(M.ENTERPRISE_NO,
                                      M.WAREHOUSE_NO,
                                      M.OWNER_NO,
                                      M.EXP_NO),
                     PKLG_ODISPATCH.F_getAllAreaByExpNO(M.ENTERPRISE_NO,
                                      M.WAREHOUSE_NO,
                                      M.OWNER_NO,
                                      M.EXP_NO),
                     PKLG_ODISPATCH.F_setRuleFlagByExpNO(M.ENTERPRISE_NO,
                                      M.WAREHOUSE_NO,
                                      M.OWNER_NO,
                                      M.EXP_NO),
                     ''0'',
                    ''' || STRIP || ''',
                     M.ORG_NO,
                     CASE
                       WHEN SYSDATE > M.RGST_DATE + ' ||
                 P.WAIT_TIMES || ' / (24 * 60) THEN
                        ''1''
                       ELSE
                        ''0''
                     END
                FROM ODATA_EXP_M M, ODATA_TMP_LOCATE_SELECT T
               WHERE M.STATUS = ''10''
                 AND M.ENTERPRISE_NO = T.ENTERPRISE_NO
                 AND M.WAREHOUSE_NO = T.WAREHOUSE_NO
                 AND M.OWNER_NO = T.OWNER_NO
                 AND M.EXP_NO = T.EXP_NO
                 AND T.STATUS = ''1''
                 AND T.TMP_ID = ''' || STRIP || '''';
      END IF;
      --单据类型
      V_SQL := V_SQL || ' AND M.EXP_TYPE = ''' || P.EXP_TYPE || '''';
      --企业
      V_SQL := V_SQL || ' AND M.ENTERPRISE_NO = ''' || P.ENTERPRISE_NO || '''';

      --货主、仓别
      IF (STRTYPE = '1') THEN
        --如果规则指定了货主
        IF (P.OWNER_NO <> 'N') THEN
          V_SQL := V_SQL || ' AND M.OWNER_NO = ''' || P.OWNER_NO || '''';
        END IF;
        --如果规则指定了仓别
        IF (P.WAREHOUSE_NO <> 'N') THEN
          V_SQL := V_SQL || ' AND M.WAREHOUSE_NO = ''' || P.WAREHOUSE_NO || '''';
        END IF;
      ELSE
        --界面传
				if(STROWNERNO <> 'ALL') THEN
          V_SQL := V_SQL || ' AND M.OWNER_NO = ''' || STROWNERNO || '''';
				END IF;
				if(STRWAREHOUSENO <> 'ALL') THEN
          V_SQL := V_SQL || ' AND M.WAREHOUSE_NO = ''' || STRWAREHOUSENO || '''';
				END IF;
      END IF;

      --校验机构
      IF (STRORG_NO <> 'ALL') THEN
        V_SQL := V_SQL || ' AND M.ORG_NO = ''' || STRORG_NO || '''';
      END IF;

      --校验配送站点
      IF (P.DELIVER_ADDRESS <> 'ALL') THEN
        V_SQL := V_SQL || ' AND M.DELIVER_ADDRESS = ''' ||
                 P.DELIVER_ADDRESS || '''';
      END IF;

      --校验配送方式
      IF (P.DELIVER_TYPE <> 'ALL') THEN
        V_SQL := V_SQL || ' AND M.DELIVER_TYPE = ''' || P.DELIVER_TYPE || '''';
      END IF;

      --校验平台
      IF (P.ORDER_SOURCE <> 'ALL') THEN
        V_SQL := V_SQL || ' AND M.ORDER_SOURCE = ''' || P.ORDER_SOURCE || '''';
      END IF;

      --校验承运商
      IF (P.SHIPPER_NO <> 'ALL') THEN
        V_SQL := V_SQL || ' AND M.SHIPPER_NO = ''' || P.SHIPPER_NO || '''';
      END IF;

		  --校验快递单号(只有电商行业的才需要校验快递单号)
			if(STRINDUSTRY_FLAG = '2') THEN
			   --如果是电商的单据。则必须有快递单号才能够集单
			   V_SQL := V_SQL || ' AND M.SHIPPER_DELIVER_NO IS NOT NULL AND M.SHIPPER_DELIVER_NO <> ''N''';
			END IF;
      EXIT;
    END LOOP;
    P_WRITELOG(STRATEGY_ID,
               STRBATCH_RULE_ID,
               'E',
               '抓数据SQL',
               V_SQL,
               STRWAVEID,
               'P_AUTO_LOCATE_MAIN');
    EXECUTE IMMEDIATE V_SQL;
    STRRESULT := 'E|新增了' || SQL%ROWCOUNT || '行记录！';
    P_WRITELOG(STRATEGY_ID,
               STRBATCH_RULE_ID,
               'E',
               '写订单池记录',
               STRRESULT,
               STRWAVEID,
               'P_AUTO_LOCATE_MAIN');

    --2. 刷独立拣货标识
    UPDATE TMP_ODATA_EXP_M M
       SET M.SINGLE_LOCATE_FLAG = '1'
     WHERE EXISTS (SELECT 1
              FROM BDEF_DEFSHIPPER S
             WHERE M.ENTERPRISE_NO = S.ENTERPRISE_NO
               AND M.SHIPPER_NO = S.SHIPPER_NO
               AND S.SINGLE_LOCATE_FLAG = '1')
       AND M.STRIP = STRIP
       AND M.STATUS = '0';

    STRRESULT := 'E|更新' || SQL%ROWCOUNT || '行记录！';
    P_WRITELOG(STRATEGY_ID,
               STRBATCH_RULE_ID,
               'E',
               '刷独立拣货标识',
               STRRESULT,
               STRWAVEID,
               'P_AUTO_LOCATE_MAIN');

    STRRESULT := 'Y|记录新增完成！';
    --COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      --ROLLBACK;
      STRRESULT := 'N|' || SQLERRM ||
                   SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
  END P_WRITETMP_ODATA_EXP;

  /*****************************************************************************************
     功能：限制SKU数
     ADD BY SUNL 20160620
  *****************************************************************************************/
  PROCEDURE P_LOCATECHECK_SKUCOUNT(STRENTERPRISENO   IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                                   STRSKU_COUNT_MODE IN WMS_OUTWAVEPLAN_D.SKU_COUNT_MODE%TYPE, --订单类型
                                   STRSKUCOUNT       IN WMS_OUTWAVEPLAN_D.SKUCOUNT%TYPE, --SKU上限
                                   STRSKU_LIMMIT     IN WMS_OUTWAVEPLAN_D.SKU_LIMMIT%TYPE, --品项数限制
                                   STRIP             IN TMP_ODATA_EXP_M.STRIP%TYPE,
                                   STRATEGY_ID       IN WMS_OUTWAVEPLAN_D.BATCH_STRATEGY_ID%TYPE, --策略ID
                                   STRBATCH_RULE_ID  IN WMS_OUTWAVEPLAN_D.BATCH_RULE_ID%TYPE, --规则ID
                                   STRWAVEID         IN TMP_LOCATEBATCH_LOG.WAVEID%TYPE, --波次流水（时间戳）
                                   STRRESULT         OUT VARCHAR2) IS
  BEGIN

  
    IF (STRSKU_COUNT_MODE > '0') THEN
      --这里表示一单一品
    
      UPDATE TMP_ODATA_EXP_M M
         SET M.STATUS = '9'
       WHERE EXISTS (SELECT 1
                FROM ODATA_EXP_M E
               WHERE M.ENTERPRISE_NO = E.ENTERPRISE_NO
                 AND M.WAREHOUSE_NO = E.WAREHOUSE_NO
                 AND M.OWNER_NO = E.OWNER_NO
                 AND M.EXP_NO = E.EXP_NO
                 AND M.ENTERPRISE_NO = STRENTERPRISENO
                 AND E.Sku_Count_Mode <> STRSKU_COUNT_MODE)
         AND M.STRIP = STRIP
         AND M.ENTERPRISE_NO = STRENTERPRISENO
         AND M.STATUS = '1';
      STRRESULT := 'E|更新' || SQL%ROWCOUNT || '条记录';
      P_WRITELOG(STRATEGY_ID,
                 STRBATCH_RULE_ID,
                 'E',
                 '删除非一单一品记录',
                 STRRESULT,
                 STRWAVEID,
                 'P_LOCATECHECK_SKUCOUNT');
    end if;
  
    --订单重复品项限制
    IF STRSKU_LIMMIT > 0 THEN
    
      UPDATE TMP_ODATA_EXP_M M
         SET M.STATUS = '9'
       WHERE EXISTS (SELECT 1
                FROM ODATA_EXP_M E
               WHERE M.ENTERPRISE_NO = E.ENTERPRISE_NO
                 AND M.WAREHOUSE_NO = E.WAREHOUSE_NO
                 AND M.OWNER_NO = E.OWNER_NO
                 AND M.EXP_NO = E.EXP_NO
                 AND M.ENTERPRISE_NO = STRENTERPRISENO
                 AND E.SKUCOUNT < STRSKU_LIMMIT)
         AND M.STRIP = STRIP
         AND M.ENTERPRISE_NO = STRENTERPRISENO
         AND M.STATUS = '1';
      STRRESULT := 'E|更新' || SQL%ROWCOUNT || '条记录';
      P_WRITELOG(STRATEGY_ID,
                 STRBATCH_RULE_ID,
                 'E',
                 '删除非一单两品记录',
                 STRRESULT,
                 STRWAVEID,
                 'P_LOCATECHECK_SKUCOUNT');
    end if;
  
    --重复上限
    if STRSKUCOUNT > 0 then
    
      UPDATE TMP_ODATA_EXP_M M
         SET M.STATUS = '9'
       WHERE EXISTS (SELECT 1
                FROM ODATA_EXP_M E
               WHERE M.ENTERPRISE_NO = E.ENTERPRISE_NO
                 AND M.WAREHOUSE_NO = E.WAREHOUSE_NO
                 AND M.OWNER_NO = E.OWNER_NO
                 AND M.EXP_NO = E.EXP_NO
                 AND M.ENTERPRISE_NO = STRENTERPRISENO
                 AND E.SKUCOUNT > STRSKUCOUNT)
         AND M.STRIP = STRIP
         AND M.ENTERPRISE_NO = STRENTERPRISENO
         AND M.STATUS = '1';
    
      STRRESULT := 'E|更新' || SQL%ROWCOUNT || '条记录';
      P_WRITELOG(STRATEGY_ID,
                 STRBATCH_RULE_ID,
                 'E',
                 '删除非一单两品记录',
                 STRRESULT,
                 STRWAVEID,
                 'P_LOCATECHECK_SKUCOUNT');
    
    END IF;
   STRRESULT := 'Y|';

  EXCEPTION
    WHEN OTHERS THEN
      STRRESULT := 'N|' || SQLERRM ||
                   SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
  END P_LOCATECHECK_SKUCOUNT;

  /*****************************************************************************************
     功能：限制区域
     ADD BY SUNL 20160620
  *****************************************************************************************/
  PROCEDURE P_LOCATECHECK_AREA(STRENTERPRISENO  IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                               STRIP            IN TMP_ODATA_EXP_M.STRIP%TYPE,
                               STRATEGY_ID      IN WMS_OUTWAVEPLAN_D.BATCH_STRATEGY_ID%TYPE, --策略ID
                               STRBATCH_RULE_ID IN WMS_OUTWAVEPLAN_D.BATCH_RULE_ID%TYPE, --规则ID
                               STRWAVEID        IN TMP_LOCATEBATCH_LOG.WAVEID%TYPE, --波次流水（时间戳）
                               STRRESULT        OUT VARCHAR2) IS
  BEGIN
    --限制区域时，需要把已跨区的，和没有区域的单据排除

    UPDATE TMP_ODATA_EXP_M M
       SET M.STATUS = '9'
     WHERE M.ENTERPRISE_NO = STRENTERPRISENO
       AND M.STRIP = STRIP
       AND M.STATUS = '1'
       AND M.AREA IS NULL;
    STRRESULT := 'E|更新了' || SQL%ROWCOUNT || '条记录';
    P_WRITELOG(STRATEGY_ID,
               STRBATCH_RULE_ID,
               'E',
               '区域限制',
               STRRESULT,
               STRWAVEID,
               'P_LOCATECHECK_AREA');

    STRRESULT := 'Y|';

  EXCEPTION
    WHEN OTHERS THEN
      STRRESULT := 'N|' || SQLERRM ||
                   SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
  END P_LOCATECHECK_AREA;

  /*****************************************************************************************
     功能：限定区域
     ADD BY SUNL 20160815
  *****************************************************************************************/
  PROCEDURE P_LOCATECHECK_LimmitAREA(STRENTERPRISENO  IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                               STRIP            IN TMP_ODATA_EXP_M.STRIP%TYPE,
                               STRATEGY_ID      IN WMS_OUTWAVEPLAN_D.BATCH_STRATEGY_ID%TYPE, --策略ID
                               STRBATCH_RULE_ID IN WMS_OUTWAVEPLAN_D.BATCH_RULE_ID%TYPE, --规则ID
                               STRWAVEID        IN TMP_LOCATEBATCH_LOG.WAVEID%TYPE, --波次流水（时间戳）
															 StrArea_Limmit_Value  IN WMS_OUTWAVEPLAN_D.Area_Limmit_Value%TYPE, --限定区域出货
                               STRRESULT        OUT VARCHAR2) IS
  BEGIN
    --限定区域时，需要把不包含指定区域的单据排除

    UPDATE TMP_ODATA_EXP_M M
       SET M.STATUS = '9'
     WHERE M.ENTERPRISE_NO = STRENTERPRISENO
       AND M.STRIP = STRIP
       AND M.STATUS = '1'
       AND instr(M.WARENO_AREANOS,StrArea_Limmit_Value) = 0;
    STRRESULT := 'E|更新了' || SQL%ROWCOUNT || '条记录';
    P_WRITELOG(STRATEGY_ID,
               STRBATCH_RULE_ID,
               'E',
               '指定区域出货',
               STRRESULT,
               STRWAVEID,
               'P_LOCATECHECK_LimmitAREA');

    STRRESULT := 'Y|';

  EXCEPTION
    WHEN OTHERS THEN
      STRRESULT := 'N|' || SQLERRM ||
                   SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
  END P_LOCATECHECK_LimmitAREA;



  /*****************************************************************************************
     功能：获取数据量
     ADD BY SUNL 20160620
  *****************************************************************************************/
  PROCEDURE P_LOCATECHECK_GETDATASIZE(STRENTERPRISENO  IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                                      STRIP            IN TMP_ODATA_EXP_M.STRIP%TYPE,
                                      STRATEGY_ID      IN WMS_OUTWAVEPLAN_D.BATCH_STRATEGY_ID%TYPE, --策略ID
                                      STRBATCH_RULE_ID IN WMS_OUTWAVEPLAN_D.BATCH_RULE_ID%TYPE, --规则ID
                                      STRWAVEID        IN TMP_LOCATEBATCH_LOG.WAVEID%TYPE, --波次流水（时间戳）
                                      STRORDERTYPE     IN TMP_ODATA_EXP_M.ORDERTYPE%TYPE, --分类 可以传0
                                      STRDATASIZE      OUT NUMBER, --数据量
                                      STRRESULT        OUT VARCHAR2) IS

  BEGIN
    --限制区域时，需要把已跨区的，和没有区域的单据排除

    STRDATASIZE := 0;
    SELECT COUNT(0)
      INTO STRDATASIZE
      FROM TMP_ODATA_EXP_M M
     WHERE M.STRIP = STRIP
       AND M.ENTERPRISE_NO = STRENTERPRISENO
       AND M.ORDERTYPE = (CASE
             WHEN STRORDERTYPE = 0 THEN
              M.ORDERTYPE
             ELSE
              STRORDERTYPE
           END)
       AND M.STATUS = '1';
    STRRESULT := 'E|当前有' || STRDATASIZE || '条记录';
    P_WRITELOG(STRATEGY_ID,
               STRBATCH_RULE_ID,
               'E',
               '查看数据量',
               STRRESULT,
               STRWAVEID,
               'P_LOCATECHECK_GETDATASIZE');

    STRRESULT := 'Y|';

  EXCEPTION
    WHEN OTHERS THEN
      STRRESULT := 'N|' || SQLERRM ||
                   SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
  END P_LOCATECHECK_GETDATASIZE;

  /*****************************************************************************************
     功能：对出货单进行集单（自动集单）
     自动集单写批次，调LOCATE过程
     ADD BY SUNL 20160620
  *****************************************************************************************/
  PROCEDURE P_LOCATE_CONTROL(STRENTERPRISENO         IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                             STRWAREHOUSENO          IN ODATA_LOCATE_M.WAREHOUSE_NO%TYPE, --仓别
                             STROWNERNO              IN ODATA_LOCATE_M.OWNER_NO%TYPE, --货主
                             STREXPTYPE              IN ODATA_LOCATE_M.EXP_TYPE%TYPE, --出货单类型
                             STRLOCATENAME           IN ODATA_LOCATE_M.LOCATE_NAME%TYPE, --集单人员
                             STRATEGY_ID             IN ODATA_LOCATE_BATCH.BATCH_STRATEGY_ID%TYPE, --策略ID
                             STRBATCH_RULE_ID        IN WMS_OUTWAVEPLAN_D.BATCH_RULE_ID%TYPE, --规则ID
                             STRDIVIDEFLAG           IN ODATA_LOCATE_BATCH.C_DIVIDE_FLAG%TYPE, --1：允许分播；0：不允许分播
                             STRSENDBUF_COMPUTE_FLAG IN ODATA_LOCATE_BATCH.SENDBUF_COMPUTE_FLAG%TYPE, --是否试算月台资源，1:试算；0:不试算
                             STRSPECIFYCELL          IN ODATA_LOCATE_BATCH.SPECIFY_CELL%TYPE, --指定储位定位，默认N，表示不指定储位
                             NTASKBATCH              IN ODATA_LOCATE_BATCH.BATCH_NO%TYPE, --分布式定位，任务批次号
                             STRSOURCETYPE           IN ODATA_LOCATE_M.SOURCE_TYPE%TYPE, --分布式定位，任务批次号
                             STRDIVIDE_COMPUTE_FLAG  IN DEVICE_DIVIDE_M.DIVIDE_COMPUTE_FLAG%TYPE, --分播设备
                             STRCHECK_COMPUTE_FLAG   IN ODATA_LOCATE_BATCH.CHECK_COMPUTE_FLAG%TYPE, --复合台
                             STRORGNO                IN ODATA_EXP_M.ORG_NO%TYPE,
                             --NTASK_ALLOTRULEID       IN ODATA_LOCATE_BATCH.TASK_RULE_ID%TYPE,
                             STRBATCH_COMPUTE      IN WMS_OUTWAVEPLAN_D.BATCH_COMPUTE%TYPE, --批次切分模式
                             STRORDERTYPE          IN TMP_ODATA_EXP_M.ORDERTYPE%TYPE, --分类 可以传0
                             STRINDUSTRY_FLAG      IN ODATA_LOCATE_M.INDUSTRY_FLAG%TYPE, --行业标识
                             STRIP                 IN VARCHAR2, --本地IP
                             STRLOCATE_STRATEGY_ID IN WMS_OUTLOCATE_STRATEGY_D.LOCATE_STRATEGY_ID%TYPE, --定位策略ID
                             STRWAVEID             IN TMP_LOCATEBATCH_LOG.WAVEID%TYPE, --波次流水（时间戳）
                             STRWAVENO             IN OUT ODATA_LOCATE_M.WAVE_NO%TYPE, --波次号
                             STRNEWBATCH_NO        IN OUT ODATA_LOCATE_BATCH.BATCH_NO%TYPE, --作业批次号
                             STRRESULT             OUT VARCHAR2) IS
    NUM_RECORDCOUNT      NUMBER(8); --当前记录数
    V_STRDELIVEROBJLEVEL ODATA_LOCATE_BATCH.DELIVER_OBJ_LEVEL%TYPE;

  BEGIN

    STRRESULT := 'N|P_LOCATE_CONTROL';

          P_WRITELOG(STRATEGY_ID,
                     STRBATCH_RULE_ID,
                     'E',
                     '参数输出',
                     'STROWNERNO = '||STROWNERNO || '   STRORDERTYPE=' || STRORDERTYPE,
                     STRWAVEID,
                     'P_LOCATE_CONTROL');
    BEGIN
      --1. 校验临时表是否有待处理的数据
      BEGIN
        NUM_RECORDCOUNT := 0;
        SELECT COUNT(0)
          INTO NUM_RECORDCOUNT
          FROM TMP_ODATA_EXP_M M
         WHERE M.STATUS = '1'
           AND M.ORDERTYPE =( CASE WHEN STRINDUSTRY_FLAG = '1' THEN m.ordertype ELSE STRORDERTYPE END)
           AND M.STRIP = STRIP;
        IF NUM_RECORDCOUNT = 0 THEN
          STRRESULT := 'E|临时表TMP_ODATA_EXP_M没有记录，批次创建失败！ 分类为：' ||
                       STRORDERTYPE;
          P_WRITELOG(STRATEGY_ID,
                     STRBATCH_RULE_ID,
                     'E',
                     '校验是否存在待处理数据',
                     STRRESULT,
                     STRWAVEID,
                     'P_LOCATE_CONTROL');
          RETURN;
        END IF;

      END;

      --2. 结束校验，写集单信息
      BEGIN
        --如果波次号是空的，则新取一个波次号！
        IF (STRWAVENO IS NULL) THEN
          PKLG_WMS_BASE.P_GETSHEETNO(STRENTERPRISENO,
                                     STRWAREHOUSENO,
                                     CONST_DOCUMENTTYPE.ODATALO,
                                     STRWAVENO,
                                     STRRESULT);
          IF SUBSTR(STRRESULT, 1, 1) <> 'Y' THEN
            P_WRITELOG(STRATEGY_ID,
                       STRBATCH_RULE_ID,
                       'E',
                       '取波次号',
                       STRRESULT,
                       STRWAVEID,
                       'P_LOCATE_CONTROL');

            RETURN;
          ELSE
            P_WRITELOG(STRATEGY_ID,
                       STRBATCH_RULE_ID,
                       'E',
                       '取波次号',
                       '波次号：' || STRWAVENO,
                       STRWAVEID,
                       'P_LOCATE_CONTROL');
          END IF;
        END IF;
      END;
    END;

    SELECT DISTINCT D.DELIVER_OBJ_LEVEL
      INTO V_STRDELIVEROBJLEVEL
      FROM WMS_OUTLOCATE_STRATEGY_D D
     WHERE D.ENTERPRISE_NO = STRENTERPRISENO
       AND D.LOCATE_STRATEGY_ID = STRLOCATE_STRATEGY_ID;

    --批次号累加
    STRNEWBATCH_NO := STRNEWBATCH_NO + 1;

    --新增出货定位指示头档
    PKOBJ_ODISPATCH.P_INS_O_LOCATE_M(STRENTERPRISENO,
                                     STRWAREHOUSENO,
                                     STROWNERNO,
                                     STRORGNO,
                                     STRWAVENO,
                                     STREXPTYPE,
                                     STRLOCATENAME,
                                     STRSOURCETYPE,
                                     STRINDUSTRY_FLAG,
                                     STRRESULT);
    IF SUBSTR(STRRESULT, 1, 1) <> 'Y' THEN
      P_WRITELOG(STRATEGY_ID,
                 STRBATCH_RULE_ID,
                 'E',
                 '新增出货定位指示头档失败',
                 STRRESULT || '波次号：' || STRWAVENO || ' 批次号：' ||
                 STRNEWBATCH_NO,
                 STRWAVEID,
                 'P_LOCATE_CONTROL');
      RETURN;
    ELSE
      P_WRITELOG(STRATEGY_ID,
                 STRBATCH_RULE_ID,
                 'E',
                 '新增出货定位指示头档成功',
                 '波次号：' || STRWAVENO || ' 批次号：' || STRNEWBATCH_NO,
                 STRWAVEID,
                 'P_LOCATE_CONTROL');
    END IF;

    --插入指示明细
    INSERT INTO ODATA_LOCATE_D
      (WAREHOUSE_NO,
       OWNER_NO,
       WAVE_NO,
       ROW_ID,
       CUST_NO,
       SUB_CUST_NO,
       EXP_NO,
       ARTICLE_NO,
       PLAN_QTY,
       LOCATED_QTY,
       STATUS,
       LINE_NO,
       BATCH_NO,
       B_OUT_FLAG,
       PRIORITY,
       ADD_EXP_NO,
       PRODUCE_CONDITION,
       PRODUCE_VALUE1,
       PRODUCE_VALUE2,
       EXPIRE_CONDITION,
       EXPIRE_VALUE1,
       EXPIRE_VALUE2,
       QUALITY_CONDITION,
       QUALITY_VALUE1,
       QUALITY_VALUE2,
       LOTNO_CONDITION,
       LOTNO_VALUE1,
       LOTNO_VALUE2,
       RSVBATCH1_CONDITION,
       RSVBATCH1_VALUE1,
       RSVBATCH1_VALUE2,
       RSVBATCH2_CONDITION,
       RSVBATCH2_VALUE1,
       RSVBATCH2_VALUE2,
       RSVBATCH3_CONDITION,
       RSVBATCH3_VALUE1,
       RSVBATCH3_VALUE2,
       RSVBATCH4_CONDITION,
       RSVBATCH4_VALUE1,
       RSVBATCH4_VALUE2,
       RSVBATCH5_CONDITION,
       RSVBATCH5_VALUE1,
       RSVBATCH5_VALUE2,
       RSVBATCH6_CONDITION,
       RSVBATCH6_VALUE1,
       RSVBATCH6_VALUE2,
       RSVBATCH7_CONDITION,
       RSVBATCH7_VALUE1,
       RSVBATCH7_VALUE2,
       RSVBATCH8_CONDITION,
       RSVBATCH8_VALUE1,
       RSVBATCH8_VALUE2,
       SPECIFY_FIELD,
       SPECIFY_CONDITION,
       SPECIFY_VALUE1,
       SPECIFY_VALUE2,
       EXP_DATE,
       PLAN_EXPORT_QTY,
       EXPORT_QTY,
       IMPORT_NO,
       STOCK_TYPE,
       TRANS_GROUP_NO,
       ENTERPRISE_NO,
       DELIVER_OBJ)
      SELECT STRWAREHOUSENO,
             OED.OWNER_NO,
             STRWAVENO,
             ROWNUM,
             OEM.CUST_NO,
             OEM.SUB_CUST_NO,
             OEM.EXP_NO,
             OED.ARTICLE_NO,
             OED.ARTICLE_QTY,
             OED.LOCATE_QTY,
             10,
             OEM.LINE_NO, --OTLS.LINE_NO,
             STRNEWBATCH_NO, --OTLS.BATCH_NO,
             DECODE(BD.SHIPPING_METHOD, 0, 0, 1), --1,
             OEM.PRIORITY, --100,
             OEM.ADD_EXP_NO, --'N',
             OED.PRODUCE_CONDITION,
             OED.PRODUCE_VALUE1,
             OED.PRODUCE_VALUE2,
             OED.EXPIRE_CONDITION,
             OED.EXPIRE_VALUE1,
             OED.EXPIRE_VALUE2,
             OED.QUALITY_CONDITION,
             OED.QUALITY_VALUE1,
             OED.QUALITY_VALUE2,
             OED.LOTNO_CONDITION,
             OED.LOTNO_VALUE1,
             OED.LOTNO_VALUE2,
             OED.RSVBATCH1_CONDITION,
             OED.RSVBATCH1_VALUE1,
             OED.RSVBATCH1_VALUE2,
             OED.RSVBATCH2_CONDITION,
             OED.RSVBATCH2_VALUE1,
             OED.RSVBATCH2_VALUE2,
             OED.RSVBATCH3_CONDITION,
             OED.RSVBATCH3_VALUE1,
             OED.RSVBATCH3_VALUE2,
             OED.RSVBATCH4_CONDITION,
             OED.RSVBATCH4_VALUE1,
             OED.RSVBATCH4_VALUE2,
             OED.RSVBATCH5_CONDITION,
             OED.RSVBATCH5_VALUE1,
             OED.RSVBATCH5_VALUE2,
             OED.RSVBATCH6_CONDITION,
             OED.RSVBATCH6_VALUE1,
             OED.RSVBATCH6_VALUE2,
             OED.RSVBATCH7_CONDITION,
             OED.RSVBATCH7_VALUE1,
             OED.RSVBATCH7_VALUE2,
             OED.RSVBATCH8_CONDITION,
             OED.RSVBATCH8_VALUE1,
             OED.RSVBATCH8_VALUE2,
             OED.SPECIFY_FIELD,
             OED.SPECIFY_CONDITION,
             OED.SPECIFY_VALUE1,
             OED.SPECIFY_VALUE2,
             TRUNC(SYSDATE),
             0,
             0,
             OEM.IMPORT_NO,
             OEM.STOCK_TYPE, --'1',
             0,
             STRENTERPRISENO,
             DECODE(V_STRDELIVEROBJLEVEL,
                    '0',
                    OEM.CUST_NO,
                    '1',
                    OEM.SOURCEEXP_NO,
                    OEM.CUST_NO)
        FROM ODATA_EXP_M     OEM,
             ODATA_EXP_D     OED,
             TMP_ODATA_EXP_M T,
             BDEF_DEFCUST    BD
       WHERE OEM.ENTERPRISE_NO = OED.ENTERPRISE_NO
         AND OEM.WAREHOUSE_NO = OED.WAREHOUSE_NO
         AND OEM.OWNER_NO = OED.OWNER_NO
         AND OEM.EXP_NO = OED.EXP_NO
         AND OEM.EXP_TYPE = STREXPTYPE
         AND OEM.WAREHOUSE_NO = STRWAREHOUSENO
         AND OEM.ENTERPRISE_NO = STRENTERPRISENO

            --ADD BY QZH AT 2016-7-14
         AND BD.ENTERPRISE_NO = OEM.ENTERPRISE_NO
         AND BD.CUST_NO = OEM.CUST_NO
            --ADD END

         AND OEM.STATUS = '10'
         AND OEM.EXP_NO = T.EXP_NO
         AND OEM.WAREHOUSE_NO = T.WAREHOUSE_NO
         AND OEM.ENTERPRISE_NO = T.ENTERPRISE_NO
         AND OEM.OWNER_NO = T.OWNER_NO
         AND T.STRIP = STRIP
       AND T.ORDERTYPE = (CASE WHEN STRORDERTYPE = '0' THEN t.ORDERTYPE ELSE STRORDERTYPE END)
         AND T.STATUS = '1'
       GROUP BY STRWAREHOUSENO,
             OED.OWNER_NO,
             STRWAVENO,
             ROWNUM,
             OEM.CUST_NO,
             OEM.SUB_CUST_NO,
             OEM.EXP_NO,
             OED.ARTICLE_NO,
             OED.ARTICLE_QTY,
             OED.LOCATE_QTY,
             OEM.LINE_NO, --OTLS.LINE_NO,
             STRNEWBATCH_NO, --OTLS.BATCH_NO,
             DECODE(BD.SHIPPING_METHOD, 0, 0, 1), --1,
             OEM.PRIORITY, --100,
             OEM.ADD_EXP_NO, --'N',
             OED.PRODUCE_CONDITION,
             OED.PRODUCE_VALUE1,
             OED.PRODUCE_VALUE2,
             OED.EXPIRE_CONDITION,
             OED.EXPIRE_VALUE1,
             OED.EXPIRE_VALUE2,
             OED.QUALITY_CONDITION,
             OED.QUALITY_VALUE1,
             OED.QUALITY_VALUE2,
             OED.LOTNO_CONDITION,
             OED.LOTNO_VALUE1,
             OED.LOTNO_VALUE2,
             OED.RSVBATCH1_CONDITION,
             OED.RSVBATCH1_VALUE1,
             OED.RSVBATCH1_VALUE2,
             OED.RSVBATCH2_CONDITION,
             OED.RSVBATCH2_VALUE1,
             OED.RSVBATCH2_VALUE2,
             OED.RSVBATCH3_CONDITION,
             OED.RSVBATCH3_VALUE1,
             OED.RSVBATCH3_VALUE2,
             OED.RSVBATCH4_CONDITION,
             OED.RSVBATCH4_VALUE1,
             OED.RSVBATCH4_VALUE2,
             OED.RSVBATCH5_CONDITION,
             OED.RSVBATCH5_VALUE1,
             OED.RSVBATCH5_VALUE2,
             OED.RSVBATCH6_CONDITION,
             OED.RSVBATCH6_VALUE1,
             OED.RSVBATCH6_VALUE2,
             OED.RSVBATCH7_CONDITION,
             OED.RSVBATCH7_VALUE1,
             OED.RSVBATCH7_VALUE2,
             OED.RSVBATCH8_CONDITION,
             OED.RSVBATCH8_VALUE1,
             OED.RSVBATCH8_VALUE2,
             OED.SPECIFY_FIELD,
             OED.SPECIFY_CONDITION,
             OED.SPECIFY_VALUE1,
             OED.SPECIFY_VALUE2,
             TRUNC(SYSDATE),
             OEM.IMPORT_NO,
             OEM.STOCK_TYPE, --'1',
             STRENTERPRISENO,
             DECODE(V_STRDELIVEROBJLEVEL,
                    '0',
                    OEM.CUST_NO,
                    '1',
                    OEM.SOURCEEXP_NO,
                    OEM.CUST_NO);

    IF SQL%ROWCOUNT <= 0 THEN
      STRRESULT := 'N|[E21703]';
      P_WRITELOG(STRATEGY_ID,
                 STRBATCH_RULE_ID,
                 'E',
                 '新增出货定位指示明细失败',
                 STRRESULT || ' 波次号：' || STRWAVENO || ' 批次号：' ||
                 STRNEWBATCH_NO,
                 STRWAVEID,
                 'P_LOCATE_CONTROL');
      RETURN;
    ELSE
      P_WRITELOG(STRATEGY_ID,
                 STRBATCH_RULE_ID,
                 'E',
                 '新增出货定位指示明细成功',
                 ' 波次号：' || STRWAVENO || ' 批次号：' || STRNEWBATCH_NO || '行数' ||SQL%ROWCOUNT,
                 STRWAVEID,
                 'P_LOCATE_CONTROL');
    END IF;

    --新增明细后，把客户，线路，批次，波次号，更新对应的出货通知单
    --MM 2015-05-30 优化慢
    FOR OLOD IN (SELECT DISTINCT OD.OWNER_NO,
                                 OD.EXP_NO,
                                 OD.CUST_NO,
                                 OD.SUB_CUST_NO,
                                 OD.LINE_NO,
                                 OD.BATCH_NO,
                                 OD.WAVE_NO
                   FROM ODATA_LOCATE_D OD
                  WHERE OD.ENTERPRISE_NO = STRENTERPRISENO
                    AND OD.WAREHOUSE_NO = STRWAREHOUSENO
                    AND OD.OWNER_NO = (CASE WHEN STROWNERNO = 'ALL' THEN od.owner_no ELSE STROWNERNO END)
										AND od.batch_no = STRNEWBATCH_NO
                    AND OD.WAVE_NO = STRWAVENO) LOOP
      UPDATE ODATA_EXP_M OEM
         SET OEM.CUST_NO     = NVL(OLOD.CUST_NO, OEM.CUST_NO),
             OEM.SUB_CUST_NO = NVL(OLOD.SUB_CUST_NO, OEM.SUB_CUST_NO),
             OEM.LINE_NO     = NVL(OLOD.LINE_NO, OEM.LINE_NO),
             OEM.BATCH_NO    = NVL(OLOD.BATCH_NO, OEM.BATCH_NO),
             OEM.WAVE_NO     = NVL(OLOD.WAVE_NO, OEM.WAVE_NO),
             OEM.UPDT_NAME   = STRLOCATENAME,
             OEM.UPDT_DATE   = SYSDATE,
             OEM.EXP_DATE    = SYSDATE,  OEM.STATUS = '11'
       WHERE OEM.OWNER_NO = OLOD.OWNER_NO
         AND OEM.WAREHOUSE_NO = STRWAREHOUSENO
         AND OEM.ENTERPRISE_NO = STRENTERPRISENO
         AND OEM.EXP_NO = OLOD.EXP_NO
         AND OEM.STATUS = '10';
    IF SQL%ROWCOUNT <= 0 THEN
      STRRESULT := 'N|[E21703]';
      P_WRITELOG(STRATEGY_ID,
                 STRBATCH_RULE_ID,
                 'E',
                 '集单成功更新出货通知单的状态失败',
                 ' 波次号：' || STRWAVENO || ' 批次号：' || STRNEWBATCH_NO || ' 单号：' || OLOD.EXP_NO,
                 STRWAVEID,
                 'P_LOCATE_CONTROL');
      RETURN;
    ELSE
      P_WRITELOG(STRATEGY_ID,
                 STRBATCH_RULE_ID,
                 'E',
                 '集单成功更新出货通知单的状态成功',
                 ' 波次号：' || STRWAVENO || ' 批次号：' || STRNEWBATCH_NO || ' 单号：' || OLOD.EXP_NO|| '行数' ||SQL%ROWCOUNT,
                 STRWAVEID,
                 'P_LOCATE_CONTROL');
    END IF;
    END LOOP;


    --刷自动集单临时表状态。
    UPDATE TMP_ODATA_EXP_M T
       SET T.STATUS = '2'
     WHERE T.ENTERPRISE_NO = STRENTERPRISENO
       AND T.WAREHOUSE_NO = STRWAREHOUSENO
       AND T.OWNER_NO = (CASE WHEN STROWNERNO = 'ALL' THEN t.OWNER_NO ELSE STROWNERNO END)
       AND T.STRIP = STRIP
       AND T.ORDERTYPE = (CASE WHEN STRORDERTYPE = '0' THEN t.ORDERTYPE ELSE STRORDERTYPE END)
       AND T.STATUS = '1';

    IF SQL%ROWCOUNT <= 0 THEN
      P_WRITELOG(STRATEGY_ID,
                 STRBATCH_RULE_ID,
                 'E',
                 '刷自动集单临时表状态失败',
                 ' 波次号：' || STRWAVENO || ' 批次号：' || STRNEWBATCH_NO,
                 STRWAVEID,
                 'P_LOCATE_CONTROL');
      RETURN;
    ELSE
      P_WRITELOG(STRATEGY_ID,
                 STRBATCH_RULE_ID,
                 'E',
                 '刷自动集单临时表状态成功',
                 ' 波次号：' || STRWAVENO || ' 批次号：' || STRNEWBATCH_NO|| '行数' ||SQL%ROWCOUNT,
                 STRWAVEID,
                 'P_LOCATE_CONTROL');
    END IF;

    --写批次配置表信息
    IF (STRDIVIDEFLAG IS NULL AND STRSENDBUF_COMPUTE_FLAG IS NULL AND
       STRSPECIFYCELL IS NULL AND NTASKBATCH IS NULL AND
       STRDIVIDE_COMPUTE_FLAG IS NULL AND STRCHECK_COMPUTE_FLAG IS NULL
       --AND NTASK_ALLOTRULEID IS NULL
       ) THEN
      --都为空，则是后台自动集单
      INSERT INTO ODATA_LOCATE_BATCH
        (WAREHOUSE_NO,
         ENTERPRISE_NO,
         OWNER_NO,
         WAVE_NO,
         EXP_TYPE,
         BATCH_NO,
         BATCH_STRATEGY_ID,
         BATCH_RULE_ID,
         EXP_DATE,
         TASK_BATCH,
         SPECIFY_CELL,
         PRINT_VALUE1,
         PRINT_VALUE2,
         PRINT_ENVOICE,
         PRINT_WAYBILL,
         PRINT_PACKLIST,
         CUST_LOGIBOX_RULE_ID,
         DIVIDE_LOGIBOX_RULE_ID,
         TASK_RULE_ID,
         /*   DIVIDE_COMPUTE_FLAG,
         DIVIDE_COMPUTE_LEVEL,
         DIVIDE_COMPUTE_VALUE,*/
         CHECK_COMPUTE_FLAG,
         CHECK_COMPUTE_LEVEL,
         CHECK_COMPUTE_VALUE,
         SENDBUF_COMPUTE_FLAG,
         SENDBUF_COMPUTE_LEVEL,
         SENDBUF_COMPUTE_VALUE,
         DELIVER_OBJ_LEVEL,
         P_FLAG,
         M_FLAG,
         W_FLAG,
         S_FLAG,
         D_FLAG,
         B_DIVIDE_FLAG,
         C_DIVIDE_FLAG,
         COMMIT_TYPE,
         SHORTQTY_TYPE,
         WORKFLOW_STRATEGY_ID,
         LAST_PICK_FLAG,
         PICK_STRATEGY_ID,
         INDUSTRY_FLAG,
         --BATCH_RSV1, BATCH_RSV2, BATCH_RSV3,LOCATE_RSV1, LOCATE_RSV2, LOCATE_RSV3,
         RGST_NAME,
         RGST_DATE /*, UPDT_NAME, UPDT_DATE*/
				 ,DIVIDE_STRATEGY_ID ,B_CHECK_STRATEGY_ID,C_CHECK_STRATEGY_ID,COMFIRE_STRATEGY_ID
				 ,LOAD_STRATEGY_ID,RSV1_STRATEGY_ID,RSV2_STRATEGY_ID,RSV3_STRATEGY_ID,RSV4_STRATEGY_ID
				 ,RSV5_STRATEGY_ID,RSV6_STRATEGY_ID,RSV7_STRATEGY_ID,RSV8_STRATEGY_ID
				 ,RSV9_STRATEGY_ID,RSV10_STRATEGY_ID)
        SELECT STRWAREHOUSENO,
               I.ENTERPRISE_NO,
               STROWNERNO,
               STRWAVENO,
               I.EXP_TYPE,
               --STRNEWBATCH_NO,
               STRNEWBATCH_NO,
               I.BATCH_STRATEGY_ID,
               I.BATCH_RULE_ID,
               TRUNC(SYSDATE),
               0,
               'N',
               CASE
                 WHEN I.W_PRINT_VALUE1 IS NOT NULL THEN
                  I.W_PRINT_VALUE1
                 ELSE
                  I.PRINT_VALUE1
               END PRINT_VALUE1,
               CASE
                 WHEN I.W_PRINT_VALUE2 IS NOT NULL THEN
                  I.W_PRINT_VALUE2
                 ELSE
                  I.PRINT_VALUE2
               END PRINT_VALUE2,
               CASE
                 WHEN I.W_PRINT_ENVOICE IS NOT NULL THEN
                  I.W_PRINT_ENVOICE
                 ELSE
                  I.PRINT_ENVOICE
               END PRINT_ENVOICE,
               CASE
                 WHEN I.W_PRINT_WAYBILL IS NOT NULL THEN
                  I.W_PRINT_WAYBILL
                 ELSE
                  I.PRINT_WAYBILL
               END PRINT_WAYBILL,
               CASE
                 WHEN I.W_PRINT_PACKLIST IS NOT NULL THEN
                  I.W_PRINT_PACKLIST
                 ELSE
                  I.PRINT_PACKLIST
               END PRINT_PACKLIST,
               I.CUST_LOGIBOX_RULE_ID,
               I.DIVIDE_LOGIBOX_RULE_ID,
               I.TASK_RULE_ID,
               /*   C2.DIVIDE_COMPUTE_FLAG,
               C2.DIVIDE_COMPUTE_LEVEL,
               C2.DIVIDE_COMPUTE_VALUE,*/
               C2.CHECK_COMPUTE_FLAG,
               C2.CHECK_COMPUTE_LEVEL,
               C2.CHECK_COMPUTE_VALUE,
               C2.SENDBUF_COMPUTE_FLAG,
               C2.SENDBUF_COMPUTE_LEVEL,
               C2.SENDBUF_COMPUTE_VALUE,
               T2.DELIVER_OBJ_LEVEL,
               T2.P_FLAG,
               T2.M_FLAG,
               T2.W_FLAG,
               T2.S_FLAG,
               T2.D_FLAG,
               I.B_DIVIDE_FLAG,
               I.C_DIVIDE_FLAG,
               T2.COMMIT_TYPE,
               T2.SHORTQTY_TYPE,
               I.WORKFLOW_STRATEGY_ID,
               NVL(I.LAST_PICK_FLAG,'N'),
               I.PICK_STRATEGY_ID,
               I.INDUSTRY_FLAG,
               'AUTO',
               SYSDATE
				 ,I.DIVIDE_STRATEGY_ID ,I.B_CHECK_STRATEGY_ID,I.C_CHECK_STRATEGY_ID,I.COMFIRE_STRATEGY_ID
				 ,I.LOAD_STRATEGY_ID,I.RSV1_STRATEGY_ID,I.RSV2_STRATEGY_ID,I.RSV3_STRATEGY_ID,I.RSV4_STRATEGY_ID
				 ,I.RSV5_STRATEGY_ID,I.RSV6_STRATEGY_ID,I.RSV7_STRATEGY_ID,I.RSV8_STRATEGY_ID
				 ,I.RSV9_STRATEGY_ID,I.RSV10_STRATEGY_ID
          FROM (SELECT DISTINCT A.*
                  FROM (SELECT *
                          FROM V_GETAUTOLOCATEBATCHINFO V
                         WHERE V.BATCH_STRATEGY_ID = STRATEGY_ID
                           AND V.BATCH_RULE_ID = STRBATCH_RULE_ID
                           AND V.EXP_TYPE = STREXPTYPE
                           AND V.ENTERPRISE_NO = STRENTERPRISENO
                        UNION ALL
                        SELECT *
                          FROM V_GETMANUALLOCATEBATCHINFO V
                         WHERE V.BATCH_STRATEGY_ID = STRATEGY_ID
                           AND V.BATCH_RULE_ID = STRBATCH_RULE_ID
                           AND V.EXP_TYPE = STREXPTYPE
                           AND V.ENTERPRISE_NO = STRENTERPRISENO) A) I,
               WMS_OUTLOCATE_STRATEGY_M T1,
               WMS_OUTLOCATE_STRATEGY_D T2,
               WMS_COMPUTE_STRATEGY_M C1,
               WMS_COMPUTE_STRATEGY_D C2
         WHERE I.ENTERPRISE_NO = T1.ENTERPRISE_NO
           AND I.LOCATE_STRATEGY_ID = T1.LOCATE_STRATEGY_ID
           AND T1.ENTERPRISE_NO = T2.ENTERPRISE_NO
           AND T1.LOCATE_STRATEGY_ID = T2.LOCATE_STRATEGY_ID
           AND I.ENTERPRISE_NO = C1.ENTERPRISE_NO
           AND I.COMPUTE_STRATEGY_ID = C1.COMPUTE_STRATEGY_ID
           AND C1.ENTERPRISE_NO = C2.ENTERPRISE_NO
           AND C1.COMPUTE_STRATEGY_ID = C2.COMPUTE_STRATEGY_ID
           AND I.ENTERPRISE_NO = STRENTERPRISENO
           AND I.BATCH_STRATEGY_ID = STRATEGY_ID
           AND I.BATCH_RULE_ID = STRBATCH_RULE_ID
           AND I.EXP_TYPE = STREXPTYPE;

    ELSE
      --这里是前台自动集单
      --写批次记录表
      INSERT INTO ODATA_LOCATE_BATCH
        (WAREHOUSE_NO,
         ENTERPRISE_NO,
         OWNER_NO,
         WAVE_NO,
         EXP_TYPE,
         BATCH_NO,
         BATCH_STRATEGY_ID,
         BATCH_RULE_ID,
         EXP_DATE,
         TASK_BATCH,
         SPECIFY_CELL,
         PRINT_VALUE1,
         PRINT_VALUE2,
         PRINT_ENVOICE,
         PRINT_WAYBILL,
         PRINT_PACKLIST,
         CUST_LOGIBOX_RULE_ID,
         DIVIDE_LOGIBOX_RULE_ID,
         TASK_RULE_ID,
         /*    DIVIDE_COMPUTE_FLAG,
         DIVIDE_COMPUTE_LEVEL,
         DIVIDE_COMPUTE_VALUE,*/
         CHECK_COMPUTE_FLAG,
         CHECK_COMPUTE_LEVEL,
         CHECK_COMPUTE_VALUE,
         SENDBUF_COMPUTE_FLAG,
         SENDBUF_COMPUTE_LEVEL,
         SENDBUF_COMPUTE_VALUE,
         DELIVER_OBJ_LEVEL,
         P_FLAG,
         M_FLAG,
         W_FLAG,
         S_FLAG,
         D_FLAG,
         B_DIVIDE_FLAG,
         C_DIVIDE_FLAG,
         COMMIT_TYPE,
         SHORTQTY_TYPE,
         WORKFLOW_STRATEGY_ID,
         LAST_PICK_FLAG,
         PICK_STRATEGY_ID,
         INDUSTRY_FLAG,
         --BATCH_RSV1, BATCH_RSV2, BATCH_RSV3,LOCATE_RSV1, LOCATE_RSV2, LOCATE_RSV3,
         RGST_NAME,
         RGST_DATE /*, UPDT_NAME, UPDT_DATE*/
				 ,DIVIDE_STRATEGY_ID ,B_CHECK_STRATEGY_ID,C_CHECK_STRATEGY_ID,COMFIRE_STRATEGY_ID
				 ,LOAD_STRATEGY_ID,RSV1_STRATEGY_ID,RSV2_STRATEGY_ID,RSV3_STRATEGY_ID,RSV4_STRATEGY_ID
				 ,RSV5_STRATEGY_ID,RSV6_STRATEGY_ID,RSV7_STRATEGY_ID,RSV8_STRATEGY_ID
				 ,RSV9_STRATEGY_ID,RSV10_STRATEGY_ID)
        SELECT STRWAREHOUSENO,
               I.ENTERPRISE_NO,
               STROWNERNO,
               STRWAVENO,
               I.EXP_TYPE,
               STRNEWBATCH_NO,
               I.BATCH_STRATEGY_ID,
               I.BATCH_RULE_ID,
               TRUNC(SYSDATE),
               NTASKBATCH,
               STRSPECIFYCELL,
               CASE
                 WHEN I.W_PRINT_VALUE1 IS NOT NULL THEN
                  I.W_PRINT_VALUE1
                 ELSE
                  I.PRINT_VALUE1
               END PRINT_VALUE1,
               CASE
                 WHEN I.W_PRINT_VALUE2 IS NOT NULL THEN
                  I.W_PRINT_VALUE2
                 ELSE
                  I.PRINT_VALUE2
               END PRINT_VALUE2,
               CASE
                 WHEN I.W_PRINT_ENVOICE IS NOT NULL THEN
                  I.W_PRINT_ENVOICE
                 ELSE
                  I.PRINT_ENVOICE
               END PRINT_ENVOICE,
               CASE
                 WHEN I.W_PRINT_WAYBILL IS NOT NULL THEN
                  I.W_PRINT_WAYBILL
                 ELSE
                  I.PRINT_WAYBILL
               END PRINT_WAYBILL,
               CASE
                 WHEN I.W_PRINT_PACKLIST IS NOT NULL THEN
                  I.W_PRINT_PACKLIST
                 ELSE
                  I.PRINT_PACKLIST
               END PRINT_PACKLIST,
               I.CUST_LOGIBOX_RULE_ID,
               I.DIVIDE_LOGIBOX_RULE_ID,
               I.TASK_RULE_ID,
               /*   CASE
                 WHEN C2.DIVIDE_COMPUTE_FLAG = '1' THEN
                  STRDIVIDE_COMPUTE_FLAG
                 ELSE
                  '0'
               END,
               C2.DIVIDE_COMPUTE_LEVEL,
               C2.DIVIDE_COMPUTE_VALUE,*/
               CASE
                 WHEN C2.CHECK_COMPUTE_FLAG = '1' THEN
                  STRCHECK_COMPUTE_FLAG
                 ELSE
                  '0'
               END,
               C2.CHECK_COMPUTE_LEVEL,
               C2.CHECK_COMPUTE_VALUE,
               CASE
                 WHEN C2.SENDBUF_COMPUTE_FLAG = '1' THEN
                  STRSENDBUF_COMPUTE_FLAG
                 ELSE
                  '0'
               END,
               C2.SENDBUF_COMPUTE_LEVEL,
               C2.SENDBUF_COMPUTE_VALUE,
               T2.DELIVER_OBJ_LEVEL,
               T2.P_FLAG,
               T2.M_FLAG,
               T2.W_FLAG,
               T2.S_FLAG,
               T2.D_FLAG,
							 --摘果优先
							 CASE
                 WHEN I.b_Divide_Flag = '0' THEN
                  '0'
                 ELSE
                  CASE
										 WHEN STRDIVIDEFLAG = '0' THEN
											'0'
										 ELSE
											I.b_Divide_Flag
									 END
               END B_DIVIDE_FLAG,
							  CASE
                 WHEN I.C_Divide_Flag = '0' THEN
                  '0'
                 ELSE
                  CASE
										 WHEN STRDIVIDEFLAG = '0' THEN
											'0'
										 ELSE
											I.C_Divide_Flag
									 END
               END C_DIVIDE_FLAG,
               T2.COMMIT_TYPE,
               T2.SHORTQTY_TYPE,
               I.WORKFLOW_STRATEGY_ID,
               NVL(I.LAST_PICK_FLAG,'N'),
               I.PICK_STRATEGY_ID,
               I.INDUSTRY_FLAG,
               STRLOCATENAME,
               SYSDATE
				 ,I.DIVIDE_STRATEGY_ID ,I.B_CHECK_STRATEGY_ID,I.C_CHECK_STRATEGY_ID,I.COMFIRE_STRATEGY_ID
				 ,I.LOAD_STRATEGY_ID,I.RSV1_STRATEGY_ID,I.RSV2_STRATEGY_ID,I.RSV3_STRATEGY_ID,I.RSV4_STRATEGY_ID
				 ,I.RSV5_STRATEGY_ID,I.RSV6_STRATEGY_ID,I.RSV7_STRATEGY_ID,I.RSV8_STRATEGY_ID
				 ,I.RSV9_STRATEGY_ID,I.RSV10_STRATEGY_ID
          FROM (SELECT DISTINCT A.*
                  FROM (SELECT *
                          FROM V_GETAUTOLOCATEBATCHINFO V
                         WHERE V.BATCH_STRATEGY_ID = STRATEGY_ID
                           AND V.BATCH_RULE_ID = STRBATCH_RULE_ID
                           AND V.EXP_TYPE = STREXPTYPE
                           AND V.ENTERPRISE_NO = STRENTERPRISENO
                        UNION ALL
                        SELECT *
                          FROM V_GETMANUALLOCATEBATCHINFO V
                         WHERE V.BATCH_STRATEGY_ID = STRATEGY_ID
                           AND V.BATCH_RULE_ID = STRBATCH_RULE_ID
                           AND V.EXP_TYPE = STREXPTYPE
                           AND V.ENTERPRISE_NO = STRENTERPRISENO) A) I,
               WMS_OUTLOCATE_STRATEGY_M T1,
               WMS_OUTLOCATE_STRATEGY_D T2,
               WMS_COMPUTE_STRATEGY_M C1,
               WMS_COMPUTE_STRATEGY_D C2
         WHERE I.ENTERPRISE_NO = T1.ENTERPRISE_NO
           AND I.LOCATE_STRATEGY_ID = T1.LOCATE_STRATEGY_ID
           AND T1.ENTERPRISE_NO = T2.ENTERPRISE_NO
           AND T1.LOCATE_STRATEGY_ID = T2.LOCATE_STRATEGY_ID
           AND I.ENTERPRISE_NO = C1.ENTERPRISE_NO
           AND I.COMPUTE_STRATEGY_ID = C1.COMPUTE_STRATEGY_ID
           AND C1.ENTERPRISE_NO = C2.ENTERPRISE_NO
           AND C1.COMPUTE_STRATEGY_ID = C2.COMPUTE_STRATEGY_ID
           AND I.ENTERPRISE_NO = STRENTERPRISENO
           AND I.BATCH_STRATEGY_ID = STRATEGY_ID
           AND I.BATCH_RULE_ID = STRBATCH_RULE_ID
           AND I.EXP_TYPE = STREXPTYPE;

		NULL;
    END IF;

    IF SQL%ROWCOUNT <= 0 THEN
      P_WRITELOG(STRATEGY_ID,
                 STRBATCH_RULE_ID,
                 'E',
                 '写批次配置表信息失败',
                 ' 波次号：' || STRWAVENO || ' 批次号：' || STRNEWBATCH_NO,
                 STRWAVEID,
                 'P_LOCATE_CONTROL');
      RETURN;
    ELSE
      P_WRITELOG(STRATEGY_ID,
                 STRBATCH_RULE_ID,
                 'E',
                 '写批次配置表信息成功',
                 ' 波次号：' || STRWAVENO || ' 批次号：' || STRNEWBATCH_NO || '行数' ||SQL%ROWCOUNT,
                 STRWAVEID,
                 'P_LOCATE_CONTROL');
    END IF;

    --如果不采用波次切分，则重算批次信息
    IF (STRBATCH_COMPUTE <> '4') THEN
      P_SET_BATCH(STRENTERPRISENO => STRENTERPRISENO,
                  STRWAREHOUSENO  => STRWAREHOUSENO,
                  STRWAVENO       => STRWAVENO,
                  STRBATCHNO      => STRNEWBATCH_NO,
                  STRRESULT       => STRRESULT);
      IF SUBSTR(STRRESULT, 1, 1) <> 'Y' THEN
        P_WRITELOG(STRATEGY_ID,
                   STRBATCH_RULE_ID,
                   'E',
                   '重算批次信息失败',
                   STRRESULT || '波次号：' || STRWAVENO || ' 批次号：' ||
                   STRNEWBATCH_NO,
                   STRWAVEID,
                   'P_LOCATE_CONTROL');
        RETURN;
      ELSE
        P_WRITELOG(STRATEGY_ID,
                   STRBATCH_RULE_ID,
                   'E',
                   '重算批次信息成功',
                   '波次号：' || STRWAVENO || ' 批次号：' || STRNEWBATCH_NO,
                   STRWAVEID,
                   'P_LOCATE_CONTROL');

      END IF;

      --重新获取最新的批次号
      SELECT MAX(to_number(B.BATCH_NO))
        INTO STRNEWBATCH_NO
        FROM ODATA_LOCATE_BATCH B
       WHERE B.WAVE_NO = STRWAVENO
         AND B.WAREHOUSE_NO = STRWAREHOUSENO
         AND B.ENTERPRISE_NO = STRENTERPRISENO
         AND B.OWNER_NO = STROWNERNO;
      P_WRITELOG(STRATEGY_ID,
                 STRBATCH_RULE_ID,
                 'E',
                 '重新获取最新的批次号',
                 '波次号：' || STRWAVENO || ' 批次号：' || STRNEWBATCH_NO,
                 STRWAVEID,
                 'P_LOCATE_CONTROL');
   END IF;

    STRRESULT := 'Y|';
  EXCEPTION
    WHEN OTHERS THEN
      STRRESULT := 'N|' || SQLERRM ||
                   SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);

  END P_LOCATE_CONTROL;

  /*****************************************************************************************
     功能：批次设置
     LIZHIPING 2015-12-21
  *****************************************************************************************/
  PROCEDURE P_SET_BATCH(STRENTERPRISENO IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE,
                        STRWAREHOUSENO  IN ODATA_LOCATE_M.WAREHOUSE_NO%TYPE,
                        STRWAVENO       IN ODATA_LOCATE_M.WAVE_NO%TYPE,
                        STRBATCHNO      IN NUMBER,
                        STRRESULT       OUT VARCHAR2) IS

    V_STRBATCHCOMPUTE     WMS_OUTWAVEPLAN_D.BATCH_COMPUTE%TYPE;
    V_STRBATCHCOMPUTETYPE WMS_OUTWAVEPLAN_D.BATCH_COMPUTE%TYPE;
    V_STRDELIVEROBJLEVEL  ODATA_LOCATE_BATCH.DELIVER_OBJ_LEVEL%TYPE;
    V_STRCDIVIDEFLAG      ODATA_LOCATE_BATCH.C_DIVIDE_FLAG%TYPE;
    V_STRBDIVIDEFLAG      ODATA_LOCATE_BATCH.B_DIVIDE_FLAG%TYPE;
    V_STREXPTYPE          ODATA_LOCATE_M.EXP_TYPE%TYPE;

    V_NCUSTQTY       DEVICE_DIVIDE_M.CUST_QTY%TYPE;
    V_NDELIVEROBJQTY DEVICE_DIVIDE_M.CUST_QTY%TYPE;

    V_NBATCHNO   NUMBER;
    V_NLINECOUNT NUMBER;

    I                NUMBER;
    J                NUMBER;
    V_NNEXTSTEP      NUMBER;
    V_NCURRPOS       NUMBER;
    V_NALLOTQTY      NUMBER;
    V_BLORDERDESC    BOOLEAN;
    V_BLBATCHALLFLAG BOOLEAN;
    V_BLBACKFLAG     BOOLEAN;

    TYPE TYPE_ARRAY_LINE IS TABLE OF TYPE_STU_LINE INDEX BY BINARY_INTEGER;

    V_ARRLINENO TYPE_ARRAY_LINE;

  BEGIN
    STRRESULT := 'Y|';
    BEGIN
      SELECT OD.BATCH_COMPUTE,
             OD.BATCH_COMPUTE_TYPE,
             LB.DELIVER_OBJ_LEVEL,
             LB.EXP_TYPE,
             LB.C_DIVIDE_FLAG,
             LB.B_DIVIDE_FLAG
        INTO V_STRBATCHCOMPUTE,
             V_STRBATCHCOMPUTETYPE,
             V_STRDELIVEROBJLEVEL,
             V_STREXPTYPE,
             V_STRCDIVIDEFLAG,
             V_STRBDIVIDEFLAG
        FROM ODATA_LOCATE_BATCH LB, WMS_OUTWAVEPLAN_D OD
       WHERE LB.ENTERPRISE_NO = STRENTERPRISENO
         AND LB.WAREHOUSE_NO = STRWAREHOUSENO
         AND LB.WAVE_NO = STRWAVENO
         AND LB.BATCH_NO = STRBATCHNO
         AND LB.ENTERPRISE_NO = OD.ENTERPRISE_NO
         AND LB.BATCH_STRATEGY_ID = OD.BATCH_STRATEGY_ID
         AND LB.BATCH_RULE_ID = OD.BATCH_RULE_ID;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        STRRESULT := 'N|[未查询到批次策略信息]';
        RETURN;
    END;

    /*--设置配送对象
      --'0---按客户,1----按单据,2----按实体客户'
      UPDATE ODATA_LOCATE_D OD
         SET OD.DELIVER_OBJ = CASE
                                WHEN V_STRDELIVEROBJLEVEL = '0' THEN
                                 OD.CUST_NO
                                ELSE
                                 CASE
                                   WHEN V_STRDELIVEROBJLEVEL = '1' THEN
                                    (SELECT OEM.SOURCEEXP_NO
                                       FROM ODATA_EXP_M OEM
                                      WHERE OEM.ENTERPRISE_NO = OD.ENTERPRISE_NO
                                        AND OEM.WAREHOUSE_NO = OD.WAREHOUSE_NO
                                        AND OEM.EXP_NO = OD.EXP_NO)
                                   ELSE --按实体客户,暂不支持
                                    OD.CUST_NO
                                 END
                              END
       WHERE OD.ENTERPRISE_NO = STRENTERPRISENO
         AND OD.WAREHOUSE_NO = STRWAREHOUSENO
         AND OD.WAVE_NO = STRWAVENO
         AND OD.BATCH_NO = STRBATCHNO;
    */
    --采用波次规则切分批次或者不切批次，则不需再做批次试算
    IF V_STRBATCHCOMPUTE IN ('0', '4') THEN
      RETURN;
    END IF;

    --允许分播并且按分播设备切批次
    IF V_STRBATCHCOMPUTE = '2' AND
       (V_STRCDIVIDEFLAG = '1' AND V_STRBDIVIDEFLAG = '1') THEN

      BEGIN
        SELECT MIN(CUST_QTY)
          INTO V_NCUSTQTY
          FROM (SELECT DDM.DEVICE_NO,
                       DDM.GRADE,
                       SUM(DDM.CUST_QTY) AS CUST_QTY
                  FROM DEVICE_DIVIDE_M               DDM,
                       WMS_WAREHOUSE_OUTORDER_DEVICE WWOD
                 WHERE DDM.ENTERPRISE_NO = WWOD.ENTERPRISE_NO
                   AND DDM.WAREHOUSE_NO = WWOD.WAREHOUSE_NO
                   AND DDM.DEVICE_GROUP_NO = WWOD.DEVICE_GROUP_NO
                   AND WWOD.ENTERPRISE_NO = STRENTERPRISENO
                   AND WWOD.WAREHOUSE_NO = STRWAREHOUSENO
                   AND WWOD.EXP_TYPE = V_STREXPTYPE
                 GROUP BY DDM.DEVICE_NO, DDM.GRADE);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          RETURN;
      END;

      --如果均分
      IF V_STRBATCHCOMPUTETYPE = '0' THEN

        --总配送对象数
        SELECT COUNT(DISTINCT OD.DELIVER_OBJ)
          INTO V_NDELIVEROBJQTY
          FROM ODATA_LOCATE_D OD
         WHERE OD.ENTERPRISE_NO = STRENTERPRISENO
           AND OD.WAREHOUSE_NO = STRWAREHOUSENO
           AND OD.WAVE_NO = STRWAVENO
           AND OD.BATCH_NO = STRBATCHNO;

        --单批次配送对象数
        V_NDELIVEROBJQTY := FLOOR(V_NDELIVEROBJQTY /
                                  CEIL(V_NDELIVEROBJQTY / V_NCUSTQTY));

        IF V_NDELIVEROBJQTY < V_NCUSTQTY THEN
          V_NCUSTQTY := V_NDELIVEROBJQTY;
        END IF;
      END IF;

      --当前批次号为传入批次
      V_NBATCHNO := STRBATCHNO;
      FOR V_CSLINE IN (SELECT OD.LINE_NO,
                              COUNT(DISTINCT OD.DELIVER_OBJ) AS DELIVEROBJCOUNT
                         FROM ODATA_LOCATE_D OD
                        WHERE OD.ENTERPRISE_NO = STRENTERPRISENO
                          AND OD.WAREHOUSE_NO = STRWAREHOUSENO
                          AND OD.WAVE_NO = STRWAVENO
                          AND OD.BATCH_NO = STRBATCHNO
                        GROUP BY OD.LINE_NO
                        ORDER BY DELIVEROBJCOUNT) LOOP
        V_ARRLINENO(V_NBATCHNO).STRLINENO := V_CSLINE.LINE_NO;
        V_ARRLINENO(V_NBATCHNO).NCOUNT := V_CSLINE.DELIVEROBJCOUNT;

        V_NBATCHNO := V_NBATCHNO + 1;

      END LOOP;

      V_NLINECOUNT := V_NBATCHNO - 1;
      V_NBATCHNO   := STRBATCHNO;
      I            := 1;
      J            := V_NLINECOUNT;

      V_NDELIVEROBJQTY := 0;
      V_BLORDERDESC    := TRUE;
      V_BLBACKFLAG     := TRUE;

      V_NNEXTSTEP := 1;
      LOOP
        V_BLBATCHALLFLAG := FALSE;
        IF V_BLORDERDESC = TRUE THEN
          --如果整个批次超过分播设备最大可播数量
          IF V_ARRLINENO(J).NCOUNT + V_NDELIVEROBJQTY > V_NCUSTQTY THEN
            --首次逆向前进时
            IF V_BLBACKFLAG = TRUE THEN

              V_NALLOTQTY := V_NCUSTQTY - V_NDELIVEROBJQTY;
              V_ARRLINENO(J).NCOUNT := V_ARRLINENO(J).NCOUNT - V_NALLOTQTY;
              V_NCURRPOS := J;

              V_NDELIVEROBJQTY := V_NCUSTQTY;
            ELSE
              --虽然超了，但当前条确实刚好能一个批次
              IF V_ARRLINENO(J).NCOUNT = V_NCUSTQTY THEN

                UPDATE ODATA_LOCATE_D OD
                   SET OD.BATCH_NO = TO_CHAR(V_NBATCHNO + V_NNEXTSTEP)
                 WHERE OD.ENTERPRISE_NO = STRENTERPRISENO
                   AND OD.WAREHOUSE_NO = STRWAREHOUSENO
                   AND OD.WAVE_NO = STRWAVENO
                   AND OD.BATCH_NO = STRBATCHNO
                   AND OD.LINE_NO = V_ARRLINENO(J).STRLINENO;

                V_NNEXTSTEP := V_NNEXTSTEP + 1;
                J           := J - 1;

                GOTO NEXT_LINE_BREAKPOINT;
              ELSE
                V_BLORDERDESC := FALSE;
                GOTO NEXT_LINE_BREAKPOINT;
              END IF;
            END IF;
          ELSE
            --如果当前线路没有超过批次值
            V_NDELIVEROBJQTY := V_NDELIVEROBJQTY + V_ARRLINENO(J).NCOUNT;
            V_ARRLINENO(J).NCOUNT := 0;
            V_NCURRPOS := J;

            V_BLBATCHALLFLAG := TRUE;

            J            := J - 1;
            V_BLBACKFLAG := FALSE;

          END IF;
        ELSE
          --如果从前往后不能拼，则从后面找大的拆分
          IF V_ARRLINENO(I).NCOUNT + V_NDELIVEROBJQTY > V_NCUSTQTY THEN
            V_BLORDERDESC := TRUE;
            V_BLBACKFLAG  := TRUE;
            GOTO NEXT_LINE_BREAKPOINT;
          ELSE
            V_NDELIVEROBJQTY := V_NDELIVEROBJQTY + V_ARRLINENO(I).NCOUNT;
            V_ARRLINENO(I).NCOUNT := 0;
            V_NCURRPOS := I;
            V_BLBATCHALLFLAG := TRUE;
            I := I + 1;
          END IF;
        END IF;

        IF V_BLBATCHALLFLAG = TRUE THEN
          UPDATE ODATA_LOCATE_D OD
             SET OD.BATCH_NO = TO_CHAR(V_NBATCHNO)
           WHERE OD.ENTERPRISE_NO = STRENTERPRISENO
             AND OD.WAREHOUSE_NO = STRWAREHOUSENO
             AND OD.WAVE_NO = STRWAVENO
             AND OD.BATCH_NO = STRBATCHNO
             AND OD.LINE_NO = V_ARRLINENO(V_NCURRPOS).STRLINENO;
        ELSE
          UPDATE ODATA_LOCATE_D OD
             SET OD.BATCH_NO = TO_CHAR(V_NBATCHNO)
           WHERE OD.ENTERPRISE_NO = STRENTERPRISENO
             AND OD.WAREHOUSE_NO = STRWAREHOUSENO
             AND OD.WAVE_NO = STRWAVENO
             AND OD.BATCH_NO = STRBATCHNO
             AND OD.LINE_NO = V_ARRLINENO(V_NCURRPOS).STRLINENO
             AND EXISTS
           (SELECT 'X'
                    FROM (SELECT OD.DELIVER_OBJ,
                                 DENSE_RANK() OVER(ORDER BY OD.DELIVER_OBJ) SORT_ORDER
                            FROM ODATA_LOCATE_D OD
                           WHERE OD.ENTERPRISE_NO = STRENTERPRISENO
                             AND OD.WAREHOUSE_NO = STRWAREHOUSENO
                             AND OD.WAVE_NO = STRWAVENO
                             AND OD.BATCH_NO = STRBATCHNO
                             AND OD.LINE_NO = V_ARRLINENO(V_NCURRPOS)
                                .STRLINENO) C
                   WHERE C.DELIVER_OBJ = OD.DELIVER_OBJ
                     AND C.SORT_ORDER <= V_NALLOTQTY);
        END IF;

        IF V_NDELIVEROBJQTY >= V_NCUSTQTY THEN
          V_NDELIVEROBJQTY := 0;
          V_NBATCHNO       := V_NBATCHNO + V_NNEXTSTEP;
          V_NNEXTSTEP      := 1;
        END IF;

        <<NEXT_LINE_BREAKPOINT>>
        IF I > J THEN
          EXIT;
        END IF;
      END LOOP;

    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      STRRESULT := 'N|' || SQLERRM ||
                   SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);

  END P_SET_BATCH;

  /*****************************************************************************************
     功能：根据(策略ID)、规则ID 获取所有有效的单据，写入临时表 前台用
     ADD BY SUNL 20160622
  *****************************************************************************************/
  PROCEDURE P_WRITEORDERBYRULEID(STRENTERPRISE IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                                 --STRBATCH_STRATEGY_ID IN WMS_OUTWAVEPLAN_D.BATCH_STRATEGY_ID%TYPE,--策略ID
                                 STRBATCH_RULE_ID IN WMS_OUTWAVEPLAN_D.BATCH_RULE_ID%TYPE, --规则ID
                                 STREXP_TYPE      IN ODATA_LOCATE_BATCH.EXP_TYPE%TYPE, --出货单类型
                                 STRIP            IN ODATA_TMP_LOCATE_SELECT.TMP_ID%TYPE, --IP
                                 STRRESULT        OUT VARCHAR2) IS
  BEGIN
    STRRESULT := 'N|P_WRITEORDERBYRULEID';
    FOR Q IN (SELECT C.*
                FROM V_GETMANUALLOCATEBATCHINFO C
               WHERE C.STATUS = '1' --只查询有效的规则
                 AND C.BATCH_RULE_ID = STRBATCH_RULE_ID
                 AND C.EXP_TYPE = STREXP_TYPE
                 AND C.ENTERPRISE_NO = STRENTERPRISE) LOOP
      --1.先根据等待时间写临时表
      BEGIN
        --先清临时表
        DELETE TMP_ODATA_EXP_M M WHERE M.STRIP = STRIP;
        --写定位临时表数据
        INSERT INTO TMP_ODATA_EXP_M
          (ENTERPRISE_NO,
           WAREHOUSE_NO,
           OWNER_NO,
           EXP_NO,
           DELIVER_ADDRESS,
           DELIVER_TYPE,
           ORDER_SOURCE,
           SHIPPER_NO,
           SINGLE_LOCATE_FLAG,
           AREA,CELL_NO,WARENO_AREANOS,RULE_FLAG,
           STATUS,
           STRIP,
           ORG_NO,
           OVERTIME)
          SELECT M.ENTERPRISE_NO,
                 M.WAREHOUSE_NO,
                 M.OWNER_NO,
                 M.EXP_NO,
                 M.DELIVER_ADDRESS,
                 M.DELIVER_TYPE,
                 M.ORDER_SOURCE,
                 M.SHIPPER_NO,
                 '0',
                 PKLG_ODISPATCH.F_GETAREABYEXPNO(M.ENTERPRISE_NO,
                                  M.WAREHOUSE_NO,
                                  M.OWNER_NO,
                                  M.EXP_NO),
								 PKLG_ODISPATCH.F_GETCELLNOBYEXPNO(M.ENTERPRISE_NO,
																	M.WAREHOUSE_NO,
																	M.OWNER_NO,
																	M.EXP_NO),
								 PKLG_ODISPATCH.F_getAllAreaByExpNO(M.ENTERPRISE_NO,
																	M.WAREHOUSE_NO,
																	M.OWNER_NO,
																	M.EXP_NO),
								 PKLG_ODISPATCH.F_setRuleFlagByExpNO(M.ENTERPRISE_NO,
																	M.WAREHOUSE_NO,
																	M.OWNER_NO,
																	M.EXP_NO),
                 '5',
                 STRIP,
                 M.ORG_NO,
                 CASE
                   WHEN SYSDATE > M.RGST_DATE + Q.WAIT_TIMES / (24 * 60) THEN
                    '1'
                   ELSE
                    '0'
                 END
            FROM ODATA_EXP_M M
           WHERE M.STATUS = '10'
             AND M.EXP_TYPE = Q.EXP_TYPE
             AND M.ENTERPRISE_NO = STRENTERPRISE
             AND M.WAREHOUSE_NO = (CASE
                   WHEN Q.WAREHOUSE_NO = 'N' THEN
                    M.WAREHOUSE_NO
                   ELSE
                    Q.WAREHOUSE_NO
                 END)
             AND M.OWNER_NO = (CASE
                   WHEN Q.OWNER_NO = 'N' THEN
                    M.OWNER_NO
                   ELSE
                    Q.OWNER_NO
                 END);

      END;

      --校验配送站点
      BEGIN
        IF (Q.DELIVER_ADDRESS <> 'ALL') THEN
          DELETE TMP_ODATA_EXP_M T
           WHERE EXISTS (SELECT 1
                    FROM ODATA_EXP_M M
                   WHERE T.ENTERPRISE_NO = M.ENTERPRISE_NO
                     AND T.WAREHOUSE_NO = M.WAREHOUSE_NO
                     AND T.OWNER_NO = M.OWNER_NO
                     AND T.EXP_NO = M.EXP_NO
                     AND M.DELIVER_ADDRESS <> Q.DELIVER_ADDRESS)
             AND T.STRIP = STRIP
             AND T.STATUS = '5';
        END IF;
      END;

      --校验配送方式
      BEGIN
        IF (Q.DELIVER_TYPE <> 'ALL') THEN
          DELETE TMP_ODATA_EXP_M T
           WHERE EXISTS (SELECT 1
                    FROM ODATA_EXP_M M
                   WHERE T.ENTERPRISE_NO = M.ENTERPRISE_NO
                     AND T.WAREHOUSE_NO = M.WAREHOUSE_NO
                     AND T.OWNER_NO = M.OWNER_NO
                     AND T.EXP_NO = M.EXP_NO
                     AND M.DELIVER_TYPE <> Q.DELIVER_TYPE)
             AND T.STRIP = STRIP
             AND T.STATUS = '5';
        END IF;
      END;

      --校验平台
      BEGIN
        IF (Q.ORDER_SOURCE <> 'ALL') THEN
          DELETE TMP_ODATA_EXP_M T
           WHERE EXISTS (SELECT 1
                    FROM ODATA_EXP_M M
                   WHERE T.ENTERPRISE_NO = M.ENTERPRISE_NO
                     AND T.WAREHOUSE_NO = M.WAREHOUSE_NO
                     AND T.OWNER_NO = M.OWNER_NO
                     AND T.EXP_NO = M.EXP_NO
                     AND M.ORDER_SOURCE <> Q.ORDER_SOURCE)
             AND T.STRIP = STRIP
             AND T.STATUS = '5';
        END IF;
      END;

      --校验承运商
      BEGIN
        IF (Q.SHIPPER_NO <> 'ALL') THEN
          DELETE TMP_ODATA_EXP_M T
           WHERE EXISTS (SELECT 1
                    FROM ODATA_EXP_M M
                   WHERE T.ENTERPRISE_NO = M.ENTERPRISE_NO
                     AND T.WAREHOUSE_NO = M.WAREHOUSE_NO
                     AND T.OWNER_NO = M.OWNER_NO
                     AND T.EXP_NO = M.EXP_NO
                     AND M.SHIPPER_NO <> Q.SHIPPER_NO)
             AND T.STRIP = STRIP
             AND T.STATUS = '5';
        END IF;
      END;

      --校验SKU数
      BEGIN
         --SKU 品项数,0不限制品项
          IF (Q.SKU_COUNT_MODE > 0) THEN
          
            DELETE TMP_ODATA_EXP_M T
             WHERE EXISTS (SELECT 1
                      FROM ODATA_EXP_M M
                     WHERE T.ENTERPRISE_NO = M.ENTERPRISE_NO
                       AND T.WAREHOUSE_NO = M.WAREHOUSE_NO
                       AND T.OWNER_NO = M.OWNER_NO
                       AND T.EXP_NO = M.EXP_NO
                       AND M.SKU_COUNT_MODE <> Q.SKU_COUNT_MODE)
               AND T.STRIP = STRIP
               AND T.STATUS = '5';
          end if;
        /*IF (Q.SKU_COUNT_MODE = 1) THEN
          --一单1品，保留SKU等于1的记录
          DELETE TMP_ODATA_EXP_M T
           WHERE EXISTS (SELECT 1
                    FROM ODATA_EXP_M M
                   WHERE T.ENTERPRISE_NO = M.ENTERPRISE_NO
                     AND T.WAREHOUSE_NO = M.WAREHOUSE_NO
                     AND T.OWNER_NO = M.OWNER_NO
                     AND T.EXP_NO = M.EXP_NO
                     AND M.SKUCOUNT <> 1)
             AND T.STRIP = STRIP
             AND T.STATUS = '5';

          \* FOR Q1 IN (SELECT D.ENTERPRISE_NO,
                            D.WAREHOUSE_NO,
                            D.OWNER_NO,
                            D.ARTICLE_NO,
                            SUM(D.ARTICLE_QTY) QTY,
                            A.PACKING_QTY,
                            MOD(SUM(D.ARTICLE_QTY), A.PACKING_QTY) LS
                       FROM TMP_ODATA_EXP_M      M1,
                            ODATA_EXP_D          D,
                            BDEF_ARTICLE_PACKING A
                      WHERE M1.ENTERPRISE_NO = D.ENTERPRISE_NO
                        AND M1.WAREHOUSE_NO = D.WAREHOUSE_NO
                        AND M1.OWNER_NO = D.OWNER_NO
                        AND M1.EXP_NO = D.EXP_NO
                        AND M1.ENTERPRISE_NO = STRENTERPRISE
                        AND D.ITEM_TYPE = '0'
                        AND M1.STRIP = STRIP
                        AND D.ENTERPRISE_NO = A.ENTERPRISE_NO
                        AND D.ARTICLE_NO = A.ARTICLE_NO
                        AND M1.STATUS = '0'
                      GROUP BY D.ENTERPRISE_NO,
                               D.WAREHOUSE_NO,
                               D.OWNER_NO,
                               D.ARTICLE_NO,
                               A.PACKING_QTY) LOOP
            --一单一品，直接排除LS数量的订单即可
            UPDATE TMP_ODATA_EXP_M MM
               SET MM.STATUS = '9'
             WHERE EXISTS
             (SELECT 1
                      FROM (SELECT *
                              FROM (SELECT M1.*
                                      FROM ODATA_EXP_M M, TMP_ODATA_EXP_M M1
                                     WHERE M.WAREHOUSE_NO = M1.WAREHOUSE_NO
                                       AND M.ENTERPRISE_NO = M1.ENTERPRISE_NO
                                       AND M.OWNER_NO = M1.OWNER_NO
                                       AND M.EXP_NO = M1.EXP_NO
                                       AND M1.STRIP = STRIP
                                       AND M1.STATUS = '0'
                                     ORDER BY M.RGST_DATE DESC)
                             WHERE ROWNUM <= Q1.LS) L --删除指定零散量的单据
                     WHERE MM.ENTERPRISE_NO = L.ENTERPRISE_NO
                       AND MM.WAREHOUSE_NO = L.WAREHOUSE_NO
                       AND MM.OWNER_NO = L.OWNER_NO
                       AND MM.EXP_NO = L.EXP_NO)
               AND MM.STRIP = STRIP
               AND MM.STATUS = '0';

          END LOOP;
          DELETE TMP_ODATA_EXP_M MM
           WHERE MM.ENTERPRISE_NO = STRENTERPRISE
             AND MM.STRIP = STRIP
             AND MM.STATUS = '9';*\
        ELSE
          IF (Q.SKU_LIMMIT = 1) THEN
            --一单2品，保留SKU等于2的记录
            DELETE TMP_ODATA_EXP_M T
             WHERE EXISTS (SELECT 1
                      FROM ODATA_EXP_M M
                     WHERE T.ENTERPRISE_NO = M.ENTERPRISE_NO
                       AND T.WAREHOUSE_NO = M.WAREHOUSE_NO
                       AND T.OWNER_NO = M.OWNER_NO
                       AND T.EXP_NO = M.EXP_NO
                       AND M.SKUCOUNT <> 2)
               AND T.STRIP = STRIP
               AND T.STATUS = '5';
          ELSE
            --一单多品，保留SKU大于等于2的记录
            DELETE TMP_ODATA_EXP_M T
             WHERE EXISTS (SELECT 1
                      FROM ODATA_EXP_M M
                     WHERE T.ENTERPRISE_NO = M.ENTERPRISE_NO
                       AND T.WAREHOUSE_NO = M.WAREHOUSE_NO
                       AND T.OWNER_NO = M.OWNER_NO
                       AND T.EXP_NO = M.EXP_NO
                       AND M.SKUCOUNT = 1)
               AND T.STRIP = STRIP
               AND T.STATUS = '5';
          END IF;
        END IF;*/
      END;

      --不允许跨区
      if Q.AREA_ALLOW='0' then
          DELETE TMP_ODATA_EXP_M T
           WHERE T.AREA IS NULL
             AND T.STRIP = STRIP
             AND T.STATUS = '5';
      end if;

       --（不）规则商品
      if Q.RULE_FLAG IN ('0','1') then
          DELETE TMP_ODATA_EXP_M T
           WHERE T.RULE_FLAG<>Q.RULE_FLAG
             AND T.STRIP = STRIP
             AND T.STATUS = '5';
      end if;

      --界面调单据时，不校验上下限

      EXIT;
    END LOOP;

    STRRESULT := 'Y|P_WRITEORDERBYRULEID';
  EXCEPTION
    WHEN OTHERS THEN
      STRRESULT := 'N|' || SQLERRM ||
                   SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
  END P_WRITEORDERBYRULEID;

  /*****************************************************************************************
     功能：根据是否赠品刷指定单据的SKU数
     ADD BY SUNL 20160620
  *****************************************************************************************/
  PROCEDURE P_LOCATECHECK_UPDATESKU(STRENTERPRISE   IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE,
                                    STRWAREHOUSE_NO IN ODATA_LOCATE_M.WAREHOUSE_NO%TYPE,
                                    STROWNER_NO     IN ODATA_LOCATE_M.OWNER_NO%TYPE,
                                    STREXP_NO       IN ODATA_EXP_M.EXP_NO%TYPE,
                                    STRRESULT       OUT VARCHAR2) IS
  BEGIN
    --SKU数指的不是品项数，而是最小操作包装的总量！！！
    UPDATE ODATA_EXP_M M
       SET M.SKUCOUNT =
           (SELECT SUM(D.ARTICLE_QTY / A.QMIN_OPERATE_PACKING) SKUCOUNT
              FROM ODATA_EXP_D D, BDEF_DEFARTICLE A
             WHERE D.EXP_NO = M.EXP_NO
               AND D.WAREHOUSE_NO = M.WAREHOUSE_NO
               AND D.ENTERPRISE_NO = M.ENTERPRISE_NO
               AND D.OWNER_NO = M.OWNER_NO
               AND D.ARTICLE_NO = A.ARTICLE_NO
               AND D.OWNER_NO = A.OWNER_NO
               AND D.ENTERPRISE_NO = A.ENTERPRISE_NO
               AND D.ITEM_TYPE = '0'
               AND D.EXP_NO = (CASE
                     WHEN STREXP_NO = 'ALL' THEN
                      D.EXP_NO
                     ELSE
                      STREXP_NO
                   END)
               AND D.ENTERPRISE_NO = STRENTERPRISE
               AND D.WAREHOUSE_NO = (CASE
                     WHEN STRWAREHOUSE_NO = 'ALL' THEN
                      D.WAREHOUSE_NO
                     ELSE
                      STRWAREHOUSE_NO
                   END)
               AND D.OWNER_NO = (CASE
                     WHEN STROWNER_NO = 'ALL' THEN
                      D.OWNER_NO
                     ELSE
                      STROWNER_NO
                   END))
     WHERE M.ENTERPRISE_NO = STRENTERPRISE
       AND M.WAREHOUSE_NO = (CASE
             WHEN STRWAREHOUSE_NO = 'ALL' THEN
              M.WAREHOUSE_NO
             ELSE
              STRWAREHOUSE_NO
           END)
       AND M.OWNER_NO = (CASE
             WHEN STROWNER_NO = 'ALL' THEN
              M.OWNER_NO
             ELSE
              STROWNER_NO
           END)
       AND M.STATUS in('-1','10') --by lai 2017-11-10
       AND M.EXP_NO = (CASE
             WHEN STREXP_NO = 'ALL' THEN
              M.EXP_NO
             ELSE
              STREXP_NO
           END)
       AND M.SKUCOUNT = 0;

		UPDATE odata_exp_m m SET m.SKU_COUNT_MODE =
		(CASE WHEN m.skucount = 1 THEN '1' ELSE '2' END)
		WHERE M.ENTERPRISE_NO = STRENTERPRISE
       AND M.WAREHOUSE_NO = (CASE
             WHEN STRWAREHOUSE_NO = 'ALL' THEN
              M.WAREHOUSE_NO
             ELSE
              STRWAREHOUSE_NO
           END)
       AND M.OWNER_NO = (CASE
             WHEN STROWNER_NO = 'ALL' THEN
              M.OWNER_NO
             ELSE
              STROWNER_NO
           END)
       AND M.STATUS in('-1', '10') --by lai 2017-11-10
       AND M.EXP_NO = (CASE
             WHEN STREXP_NO = 'ALL' THEN
              M.EXP_NO
             ELSE
              STREXP_NO
           END);

    STRRESULT := 'Y|';
  EXCEPTION
    WHEN OTHERS THEN
      STRRESULT := 'N|' || SQLERRM ||
                   SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
  END P_LOCATECHECK_UPDATESKU;

  /*****************************************************************************************
     功能： 聚类算法！
     ADD BY SUNL 20160712
  *****************************************************************************************/
  PROCEDURE P_LOCATECHECK_CLUSTERING(
                                     --记录日志用
                                     STRBATCH_STRATEGY_ID IN ODATA_LOCATE_BATCH.BATCH_STRATEGY_ID%TYPE, --指定策略 不指定传0
                                     STRBATCH_RULE_ID     IN ODATA_LOCATE_BATCH.BATCH_RULE_ID%TYPE, --指定规则 不指定传0
                                     STRWAVEID            IN TMP_LOCATEBATCH_LOG.WAVEID%TYPE, --波次流水（时间戳）
                                     --聚类算法用
                                     STRSKU_LIMMIT     IN WMS_OUTWAVEPLAN_D.SKU_LIMMIT%TYPE, --每订单允许无重复品项数
                                     STRSKUCOUNT       IN WMS_OUTWAVEPLAN_D.SKUCOUNT%TYPE, --品项上限
                                     STRREPEAT_TIMES   IN WMS_OUTWAVEPLAN_D.REPEAT_TIMES%TYPE, --重复度限制
                                     STRORDERTYPE      IN TMP_ODATA_EXP_M.ORDERTYPE%TYPE, --分类
                                     STR_IP            IN VARCHAR2, --本地IP
                                     STRALEVEL         IN TMP_LOCATE_CLUSTERING1.ALEVEL%TYPE, -- 商品级别 P1
                                     STRELEVEL         IN TMP_LOCATE_CLUSTERING2.ELEVEL%TYPE, -- 订单级别 P2
                                     STR_FAILARTICLES  IN OUT VARCHAR2, --当前有效的商品编码 C1
                                     STR_ARTICLES      IN OUT VARCHAR2, --当前有效的商品编码 P3
                                     STR_ARTICLESCOUNT IN OUT NUMBER, --记录当前有效商品个数 P4
                                     STR_ISSUCCESS     OUT NUMBER, --记录当前是否执行成功 (0,失败；1，成功) P5

                                     --生成批次用
                                     STRENTERPRISENO         IN ODATA_LOCATE_M.ENTERPRISE_NO%TYPE, --企业
                                     STRWAREHOUSENO          IN ODATA_LOCATE_M.WAREHOUSE_NO%TYPE, --仓别
                                     STROWNERNO              IN ODATA_LOCATE_M.OWNER_NO%TYPE, --货主
                                     STREXPTYPE              IN ODATA_LOCATE_M.EXP_TYPE%TYPE, --出货单类型
                                     STRLOCATENAME           IN ODATA_LOCATE_M.LOCATE_NAME%TYPE, --集单人员
                                     STRDIVIDEFLAG           IN ODATA_LOCATE_BATCH.C_DIVIDE_FLAG%TYPE, --1：允许分播；0：不允许分播
                                     STRSENDBUF_COMPUTE_FLAG IN ODATA_LOCATE_BATCH.SENDBUF_COMPUTE_FLAG%TYPE, --是否试算月台资源，1:试算；0:不试算
                                     STRSPECIFYCELL          IN ODATA_LOCATE_BATCH.SPECIFY_CELL%TYPE, --指定储位定位，默认N，表示不指定储位
                                     NTASKBATCH              IN ODATA_LOCATE_BATCH.BATCH_NO%TYPE, --分布式定位，任务批次号
                                     STRSOURCETYPE           IN ODATA_LOCATE_M.SOURCE_TYPE%TYPE, --分布式定位，任务批次号
                                     STRDIVIDE_COMPUTE_FLAG  IN DEVICE_DIVIDE_M.DIVIDE_COMPUTE_FLAG%TYPE, --分播设备
                                     STRCHECK_COMPUTE_FLAG   IN ODATA_LOCATE_BATCH.CHECK_COMPUTE_FLAG%TYPE, --复合台
                                     STRORGNO                IN ODATA_EXP_M.ORG_NO%TYPE,
                                     STRBATCH_COMPUTE        IN WMS_OUTWAVEPLAN_D.BATCH_COMPUTE%TYPE, --批次切分模式
                                     STRINDUSTRY_FLAG        IN ODATA_LOCATE_M.INDUSTRY_FLAG%TYPE, --行业标识
                                     STRLOCATE_STRATEGY_ID   IN WMS_OUTLOCATE_STRATEGY_D.LOCATE_STRATEGY_ID%TYPE, --定位策略ID
                                     STRWAVENO               IN OUT ODATA_LOCATE_M.WAVE_NO%TYPE, --波次号
                                     NUM_BATCHNO             IN OUT ODATA_LOCATE_BATCH.BATCH_NO%TYPE, --作业批次号

                                     STRRESULT OUT VARCHAR2) IS
    NUM_RECORDCOUNT NUMBER; --当前记录数
    V_ALEVEL     NUMBER; --商品级别
    V_ELEVEL     NUMBER; --订单级别
    V_BASE_LEVEL NUMBER; --级别基数

    V_MAXREPEATARTICLE ODATA_LOCATE_D.ARTICLE_NO%TYPE; --最大重复度品项 C2
    V_DUPLICATIONCOUNT TMP_LOCATE_CLUSTERING1.DUPLICATIONCOUNT%TYPE; --最大重复度
  BEGIN
    V_BASE_LEVEL := 100;
    --3.1. 删除当前级别对应的订单（T1表）
    --     1、所有品项不在T1表的订单
    --     2、不在T1表中的品项数大于每订单允许无重复的订单
    BEGIN
      --1
      DELETE TMP_LOCATE_CLUSTERING2 T
       WHERE T.EXP_NO NOT IN
             (SELECT DISTINCT T2.EXP_NO
                FROM TMP_LOCATE_CLUSTERING2 T2, TMP_LOCATE_CLUSTERING1 T1
               WHERE T1.STRIP = T2.STRIP
                 AND T1.ARTICLE_NO = T2.ARTICLE_NO
                 AND T1.STRIP = STR_IP
                 AND T1.ALEVEL = STRALEVEL
                 AND T2.ELEVEL = STRELEVEL)
         AND T.STRIP = STR_IP
         AND T.ELEVEL = STRELEVEL;

      STRRESULT := 'E|更新' || SQL%ROWCOUNT || '条记录：E级别：' || STRELEVEL;
      P_WRITELOG(STRBATCH_STRATEGY_ID,
                 STRBATCH_RULE_ID,
                 'E',
                 '3.1.1 删除所有品项不在T1表的订单',
                 STRRESULT,
                 STRWAVEID,
                 'P_LOCATECHECK_CLUSTERING');

      --2
      DELETE TMP_LOCATE_CLUSTERING2 C
       WHERE EXISTS (SELECT *
                FROM (SELECT COUNT(DISTINCT T.ARTICLE_NO) GS, T.EXP_NO
                        FROM TMP_LOCATE_CLUSTERING2 T
                       WHERE T.STRIP = STR_IP
                         AND T.ARTICLE_NO NOT IN
                             (SELECT T1.ARTICLE_NO
                                FROM TMP_LOCATE_CLUSTERING1 T1
                               WHERE T1.STRIP = STR_IP
                                 AND T1.ALEVEL = STRALEVEL)
                       GROUP BY T.EXP_NO) M
               WHERE C.EXP_NO = M.EXP_NO
                 AND M.GS > STRSKU_LIMMIT)
         AND C.STRIP = STR_IP
         AND C.ELEVEL = STRELEVEL;
      STRRESULT := 'E|更新' || SQL%ROWCOUNT || '条记录：E级别：' || STRELEVEL;
      P_WRITELOG(STRBATCH_STRATEGY_ID,
                 STRBATCH_RULE_ID,
                 'E',
                 '3.1.2 不在T1表中的品项数大于每订单允许无重复的订单  ',
                 STRRESULT,
                 STRWAVEID,
                 'P_LOCATECHECK_CLUSTERING');
    END;
    --3.2 如果P4>=（SKU限制数-允许无重复品项数）
    --3.2.1 组批次
    --3.2.2 P5置为成功
    --3.2.3 退出过程
    BEGIN
      IF (STR_ARTICLESCOUNT >= (STRSKUCOUNT - STRSKU_LIMMIT)) THEN
        --3.2.1
        BEGIN
          --这一步需要先处理TMP_ODATA_EXP_M表的数据，才能集批次。
          --目前有效的订单存在于T2表中，级别为当前的P2


          --将当前分类下，不存在T2表上个级别下的所有出货单据状态置为8
          UPDATE TMP_ODATA_EXP_M M
             SET M.STATUS = '8'
           WHERE M.STRIP = STR_IP
             AND M.ENTERPRISE_NO = STRENTERPRISENO
             AND NOT EXISTS (SELECT 1
                    FROM TMP_LOCATE_CLUSTERING2 T
                   WHERE M.EXP_NO = T.EXP_NO
                     AND M.STRIP = T.STRIP
                     AND M.STRIP = STR_IP
                     AND T.ELEVEL = floor(STRELEVEL / V_BASE_LEVEL))
             AND M.ORDERTYPE = STRORDERTYPE
             AND M.STATUS = '1';
          STRRESULT := 'E|更新' || SQL%ROWCOUNT || '条记录：E级别：' ||  floor(STRELEVEL / V_BASE_LEVEL);
          P_WRITELOG(STRBATCH_STRATEGY_ID,
                     STRBATCH_RULE_ID,
                     'E',
                     '3.1.1 将当前分类下，不存在T2表当前级别下的所有出货单据状态置为8  ',
                     STRRESULT,
                     STRWAVEID,
                     'P_LOCATECHECK_CLUSTERING');

          P_LOCATE_CONTROL(STRENTERPRISENO,
                           STRWAREHOUSENO,
                           STROWNERNO,
                           STREXPTYPE,
                           STRLOCATENAME,
                           STRBATCH_STRATEGY_ID,
                           STRBATCH_RULE_ID,
                           STRDIVIDEFLAG,
                           STRSENDBUF_COMPUTE_FLAG,
                           STRSPECIFYCELL,
                           NTASKBATCH,
                           STRSOURCETYPE,
                           STRDIVIDE_COMPUTE_FLAG,
                           STRCHECK_COMPUTE_FLAG,
                           STRORGNO,
                           STRBATCH_COMPUTE,
                           STRORDERTYPE,
                           STRINDUSTRY_FLAG,
                           STR_IP,
                           STRLOCATE_STRATEGY_ID,
                           STRWAVEID,
                           STRWAVENO,
                           NUM_BATCHNO,
                           STRRESULT);

				--将当前分类下，状态为8的单据还原
				UPDATE TMP_ODATA_EXP_M M
					 SET M.STATUS = '1'
				 WHERE M.STRIP = STR_IP
					 AND M.ENTERPRISE_NO = STRENTERPRISENO
					 AND M.ORDERTYPE = STRORDERTYPE
					 AND M.STATUS = '8';
				P_WRITELOG(STRBATCH_STRATEGY_ID,
									 STRBATCH_RULE_ID,
									 'E',
									 '3.1.1 将当前分类下，状态为8的单据还原  ',
									 'E|更新' || SQL%ROWCOUNT || '条记录：E级别：' || STRELEVEL,
									 STRWAVEID,
									 'P_LOCATECHECK_CLUSTERING');
				IF SUBSTR(STRRESULT, 1, 1) <> 'Y' THEN
          P_WRITELOG(STRBATCH_STRATEGY_ID,
                     STRBATCH_RULE_ID,
                     'E',
                     '3.1.1 集批次失败！  ',
                     STRRESULT,
                     STRWAVEID,
                     'P_LOCATECHECK_CLUSTERING');
					STR_ISSUCCESS := 0;--失败则回退
					RETURN;
				END IF;
        END;
        --3.2.2
        STR_ISSUCCESS := 1;
				DELETE TMP_LOCATE_CLUSTERING3 t WHERE t.strip = STR_IP AND t.ctype = '2';
		/*
				STR_FAILARTICLES:='';
			  STR_ARTICLES :='';
			  STR_ARTICLESCOUNT:=0;
                                     */
        --3.2.3
        RETURN;
      END IF;
    END;
    --3.11 设置级别
    V_ALEVEL := STRALEVEL * V_BASE_LEVEL + 1;
    V_ELEVEL := STRELEVEL * V_BASE_LEVEL + 1;
    --3.12 循环
    LOOP
      --3.12.1 获取最高重复度品项（C2）（不含已处理未成功的品项C1）,取不到退出循环
      BEGIN

			  --test
				BEGIN
					FOR QQ IN (SELECT * FROM TMP_LOCATE_CLUSTERING3 WHERE strip = STR_IP ORDER BY CTYPE ASC) LOOP
						P_WRITELOG(STRBATCH_STRATEGY_ID,
                   STRBATCH_RULE_ID,
                   'E',
                   '3.12.1 测试数据 ',
                  qq.ctype || '--' || qq.article_no,
                   STRWAVEID,
                   'P_LOCATECHECK_CLUSTERING');
					END LOOP;
				END;


				V_DUPLICATIONCOUNT :=0;
        V_MAXREPEATARTICLE := ''; --初始置为空
        FOR K1 IN (SELECT *
                     FROM TMP_LOCATE_CLUSTERING1 T
                    WHERE T.STRIP = STR_IP
                      AND T.ALEVEL = STRALEVEL
											AND NOT EXISTS(SELECT 1 FROM TMP_LOCATE_CLUSTERING3 c
											WHERE c.strip = t.strip AND c.article_no = t.article_no)
                   /*   AND T.ARTICLE_NO NOT IN ((CASE WHEN STR_FAILARTICLES IS NULL THEN 'N' ELSE STR_FAILARTICLES END))
                      AND T.ARTICLE_NO NOT IN ((CASE WHEN STR_ARTICLES IS NULL THEN 'N' ELSE STR_ARTICLES END))*/
                    ORDER BY T.DUPLICATIONCOUNT DESC, T.ARTICLE_NO ASC) LOOP
          V_MAXREPEATARTICLE := K1.ARTICLE_NO;
					V_DUPLICATIONCOUNT := k1.duplicationcount;
          EXIT;
        END LOOP;

        STRRESULT := 'E|获取最高重复度品项C2：' || V_MAXREPEATARTICLE || '。重复度：'||V_DUPLICATIONCOUNT||'  A级别：' ||
                     STRALEVEL;
        P_WRITELOG(STRBATCH_STRATEGY_ID,
                   STRBATCH_RULE_ID,
                   'E',
                   '3.12.1 获取最高重复度品项（C2） ',
                   STRRESULT,
                   STRWAVEID,
                   'P_LOCATECHECK_CLUSTERING');

        IF (V_MAXREPEATARTICLE IS NULL) THEN
					--找不到可用品项，回退
          RETURN;
				ELSIF(V_DUPLICATIONCOUNT < STRREPEAT_TIMES) THEN
				  --重复度不足则回退
				  RETURN;
				ELSE
					--将当前正在处理的商品信息写入临时表T3
					INSERT INTO TMP_LOCATE_CLUSTERING3(ARTICLE_NO,CTYPE,STRIP)
					VALUES (V_MAXREPEATARTICLE,'2',STR_IP);
					NUM_RECORDCOUNT:=0;
					SELECT COUNT(DISTINCT c.article_no) INTO NUM_RECORDCOUNT FROM TMP_LOCATE_CLUSTERING3 c
					WHERE c.strip = STR_IP AND c.ctype = '2';

          STR_ARTICLESCOUNT  := NUM_RECORDCOUNT;
        END IF;

      END;
      --3.12.2 把含C2品项的订单写入T2表（使用新级别）（不含C2品项）
      BEGIN
        INSERT INTO TMP_LOCATE_CLUSTERING2
          (STRIP, EXP_NO, ARTICLE_NO, ELEVEL)
          SELECT STR_IP, E.EXP_NO, E.ARTICLE_NO, V_ELEVEL
            FROM ODATA_EXP_D E
           WHERE EXISTS (SELECT 1
                    FROM (SELECT D.ENTERPRISE_NO,
                                 D.WAREHOUSE_NO,
                                 D.OWNER_NO,
                                 D.EXP_NO
                            FROM TMP_ODATA_EXP_M M, ODATA_EXP_D D
                           WHERE M.ENTERPRISE_NO = D.ENTERPRISE_NO
                             AND M.WAREHOUSE_NO = D.WAREHOUSE_NO
                             AND M.OWNER_NO = D.OWNER_NO
                             AND M.EXP_NO = D.EXP_NO
                             AND D.ARTICLE_NO = V_MAXREPEATARTICLE
                             AND M.STRIP = STR_IP
                             AND M.ENTERPRISE_NO = STRENTERPRISENO
                             AND M.ORDERTYPE = STRORDERTYPE) T
                   WHERE E.ENTERPRISE_NO = T.ENTERPRISE_NO
                     AND E.WAREHOUSE_NO = T.WAREHOUSE_NO
                     AND E.OWNER_NO = T.OWNER_NO
                     AND E.EXP_NO = T.EXP_NO)
						 --必须只算当前级别的订单
						 AND EXISTS(SELECT 1 FROM TMP_LOCATE_CLUSTERING2 c
						 WHERE c.strip = str_ip AND c.elevel = STRELEVEL)

							AND NOT EXISTS(SELECT 1 FROM TMP_LOCATE_CLUSTERING3 a
							WHERE a.strip = str_ip AND a.article_no = e.article_no AND a.ctype = '1')
						/*	AND E.ARTICLE_NO NOT IN ((CASE WHEN STR_FAILARTICLES IS NULL THEN 'N' ELSE STR_FAILARTICLES END))
							AND E.ARTICLE_NO NOT IN ((CASE WHEN STR_ARTICLES IS NULL THEN 'N' ELSE STR_ARTICLES END))*/
							;
        STRRESULT := 'E|新增' || SQL%ROWCOUNT || '条记录：E级别：' || V_ELEVEL;
        P_WRITELOG(STRBATCH_STRATEGY_ID,
                   STRBATCH_RULE_ID,
                   'E',
                   '3.12.2 把含C2品项的订单写入T2表（使用新级别）（不含C2品项） ',
                   STRRESULT,
                   STRWAVEID,
                   'P_LOCATECHECK_CLUSTERING');
      END;
      --3.12.3 计算T2表的重复度（新级别），写入T1表
      BEGIN
        INSERT INTO TMP_LOCATE_CLUSTERING1
          (STRIP, ARTICLE_NO, DUPLICATIONCOUNT, ALEVEL)
					SELECT * FROM (
          SELECT STR_IP, T.ARTICLE_NO, COUNT(T.ARTICLE_NO) CFD, V_ALEVEL
            FROM TMP_LOCATE_CLUSTERING2 T
           WHERE T.STRIP = STR_IP
             AND T.ELEVEL = V_ELEVEL
           GROUP BY T.ARTICLE_NO
           ORDER BY COUNT(T.ARTICLE_NO) DESC, T.ARTICLE_NO ASC) MK
					 WHERE mk.cfd >= STRREPEAT_TIMES;
        STRRESULT := 'E|新增' || SQL%ROWCOUNT || '条记录：A级别：' || V_ALEVEL;
        P_WRITELOG(STRBATCH_STRATEGY_ID,
                   STRBATCH_RULE_ID,
                   'E',
                   '3.12.3 计算T2表的重复度（新级别），写入T1表',
                   STRRESULT,
                   STRWAVEID,
                   'P_LOCATECHECK_CLUSTERING');
      END;
      --3.12.4 递归，调当前存储过程
      BEGIN

        P_LOCATECHECK_CLUSTERING(STRBATCH_STRATEGY_ID,
                                 STRBATCH_RULE_ID,
                                 STRWAVEID,
                                 STRSKU_LIMMIT,
                                 STRSKUCOUNT,
                                 STRREPEAT_TIMES,
                                 STRORDERTYPE,
                                 STR_IP,
                                 V_ALEVEL,
                                 V_ELEVEL,
                                 STR_FAILARTICLES,
                                 STR_ARTICLES,
                                 STR_ARTICLESCOUNT,
                                 STR_ISSUCCESS,
                                 STRENTERPRISENO,
                                 STRWAREHOUSENO,
                                 STROWNERNO,
                                 STREXPTYPE,
                                 STRLOCATENAME,
                                 STRDIVIDEFLAG,
                                 STRSENDBUF_COMPUTE_FLAG,
                                 STRSPECIFYCELL,
                                 NTASKBATCH,
                                 STRSOURCETYPE,
                                 STRDIVIDE_COMPUTE_FLAG,
                                 STRCHECK_COMPUTE_FLAG,
                                 STRORGNO,
                                 STRBATCH_COMPUTE,
                                 STRINDUSTRY_FLAG,
                                 STRLOCATE_STRATEGY_ID,
                                 STRWAVENO,
                                 NUM_BATCHNO,
                                 STRRESULT);
      END;
      --3.12.5 校验P5；成功：1.更新T2表（删除已生成批次的订单）（P2）
      --                    2.更新T1表的重复度（如果当前P1无数据，退回）
      --             不成功：1. C1 = C1+C2
      BEGIN
        IF (STR_ISSUCCESS = 1) THEN
          DELETE TMP_LOCATE_CLUSTERING2 T
           WHERE EXISTS (SELECT 1
                    FROM TMP_ODATA_EXP_M M
                   WHERE T.STRIP = M.STRIP
                     AND T.EXP_NO = M.EXP_NO
                     AND M.STATUS = '2'
                     AND M.ORDERTYPE = STRORDERTYPE
                     AND M.STRIP = STR_IP)
             AND T.STRIP = STR_IP
             AND T.ELEVEL = V_ELEVEL;
          STRRESULT := 'E|删除' || SQL%ROWCOUNT || '条记录：E级别：' || V_ELEVEL;
          P_WRITELOG(STRBATCH_STRATEGY_ID,
                     STRBATCH_RULE_ID,
                     'E',
                     '3.12.5 更新T2表（删除已生成批次的订单）',
                     STRRESULT,
                     STRWAVEID,
                     'P_LOCATECHECK_CLUSTERING');
          --先删除
          DELETE TMP_LOCATE_CLUSTERING1 T
           WHERE T.STRIP = STR_IP
             AND T.ALEVEL = V_ALEVEL;
          --再新增
          INSERT INTO TMP_LOCATE_CLUSTERING1
            (STRIP, ARTICLE_NO, DUPLICATIONCOUNT, ALEVEL)
            SELECT STR_IP, T.ARTICLE_NO, COUNT(T.ARTICLE_NO), V_ALEVEL
              FROM TMP_LOCATE_CLUSTERING2 T
             WHERE T.STRIP = STR_IP
               AND T.ELEVEL = V_ELEVEL
             GROUP BY T.ARTICLE_NO
             ORDER BY COUNT(T.ARTICLE_NO) DESC, T.ARTICLE_NO ASC;
          STRRESULT := 'E|新增' || SQL%ROWCOUNT || '条记录：A级别：' || V_ALEVEL;
          P_WRITELOG(STRBATCH_STRATEGY_ID,
                     STRBATCH_RULE_ID,
                     'E',
                     '3.12.5 更新T1表的重复度',
                     STRRESULT,
                     STRWAVEID,
                     'P_LOCATECHECK_CLUSTERING');

        ELSE

						--将当前正在处理的商品信息写入临时表T3
					INSERT INTO TMP_LOCATE_CLUSTERING3(ARTICLE_NO,CTYPE,STRIP)
					VALUES (V_MAXREPEATARTICLE,'1',STR_IP);

          STRRESULT := 'E| 不成功：C1：' || V_MAXREPEATARTICLE;
          P_WRITELOG(STRBATCH_STRATEGY_ID,
                     STRBATCH_RULE_ID,
                     'E',
                     '3.12.5 校验P5',
                     STRRESULT,
                     STRWAVEID,
                     'P_LOCATECHECK_CLUSTERING');
        END IF;
      END;
      --3.12.6 删除当前IP1和IP2的订单
      BEGIN
        DELETE TMP_LOCATE_CLUSTERING1 T
         WHERE T.STRIP = STR_IP
           AND T.ALEVEL = V_ALEVEL;
        STRRESULT := 'E|删除' || SQL%ROWCOUNT || '条记录：A级别：' || V_ALEVEL;
        P_WRITELOG(STRBATCH_STRATEGY_ID,
                   STRBATCH_RULE_ID,
                   'E',
                   '3.12.6 删除当前IP1的订单',
                   STRRESULT,
                   STRWAVEID,
                   'P_LOCATECHECK_CLUSTERING');
        DELETE TMP_LOCATE_CLUSTERING2 T
         WHERE T.STRIP = STR_IP
           AND T.ELEVEL = V_ELEVEL;
        STRRESULT := 'E|新增' || SQL%ROWCOUNT || '条记录：E级别：' || V_ELEVEL;
        P_WRITELOG(STRBATCH_STRATEGY_ID,
                   STRBATCH_RULE_ID,
                   'E',
                   '3.12.6 删除当前IP2的订单',
                   STRRESULT,
                   STRWAVEID,
                   'P_LOCATECHECK_CLUSTERING');
      END;

    END LOOP;

    STRRESULT := 'Y|P_LOCATECHECK_CLUSTERING';
  EXCEPTION
    WHEN OTHERS THEN
      STRRESULT := 'N|' || SQLERRM ||
                   SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
  END P_LOCATECHECK_CLUSTERING;



END PKLG_ODISPATCH;

/

