create package        PKLG_FCDATA_CHECK is

/**********************************************************************************************************
   zhouhuan
   2014.4.21
   功能：  功能：盘点发单--》切单-->写盘点单头档
***********************************************************************************************************/
      procedure P_FcdataCheck_GetTask(strWareHouseNo            in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_plan_m.owner_no%type,
                                  strUserId               in    fcdata_plan_m.rgst_name%type,--作业人
                                  strPaperUserId          in    fcdata_plan_m.rgst_name%type,--单据人
                                  strRequstNo             in   fcdata_plan_m.plan_no%type,--需求单号
                                  strCutFlag              in   fcdata_check_m.fcdata_type%type,--储位顺序
                                  strMoveType             in   fcdata_check_m.fcdata_type%type,--储位上商品顺序
                                  strResult               OUT    varchar2);

/**********************************************************************************************************
   zhouhuan
   2014.4.22
   功能：盘点发单
***********************************************************************************************************/
 procedure P_FcdataCheck_SendTask(strWareHouseNo            in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_plan_m.owner_no%type,
                                  strUserId               in    fcdata_plan_m.rgst_name%type,--作业人
                                  strCheckNo              in   fcdata_plan_m.plan_no%type,--盘点单号
                                  strCheckType            in   fcdata_check_m.check_type%type,--1:初盘；2：复盘
                                  strDockNo               in   pntset_printer_dock.dock_no%type,
                                  strFcdataType            in   fcdata_check_m.fcdata_type%type,--1:盘点；2：循环盘；3：动销盘
                                  strPrintType            in   fcdata_check_d.check_type%type,--1:打印报表；2：打印标签
                                  strResult               OUT    varchar2);

/**********************************************************************************************************
   zhouhuan
   2014.4.22
   功能：复盘/三盘发单
***********************************************************************************************************/
  procedure P_FcdataCheck_SendTaskAgain(strWareHouseNo            in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_plan_m.owner_no%type,
                                  strUserId               in    fcdata_plan_m.rgst_name%type,--作业人
                                  strCheckNo              in   fcdata_plan_m.plan_no%type,--盘点单号
                                  strCheckType            in   fcdata_check_m.check_type%type,--1:初盘；2：复盘
                                  strDockNo               in   pntset_printer_dock.dock_no%type,
                                  strFcdataType           in   fcdata_check_m.fcdata_type%type,--1:盘点；2：循环盘；3：动销盘
                                  strPrintType            in   fcdata_check_d.check_type%type,--1:打印报表；2：打印标签
                                  strCellNo               in   fcdata_check_d.cell_no%type,--储位
                                  strResult               OUT    varchar2);
end PKLG_FCDATA_CHECK;


/

