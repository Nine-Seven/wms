create package body pklg_odata is

  /* \*****************************************************************************************************************
  QUZHIHUI
  20131110
  功能说明：按区域+客户发单
  Modify BY QZH AT 2016-5-24 支持RF索单
  下架表结构去掉Pick_Container_No,cust_container_no huangb 20160620
  ***************************************************************************************************************\
  procedure p_pick_by_cust(strEnterpriseNo     in odata_outstock_m.enterprise_no%type,
                           v_warehouse_No      in odata_locate_m.warehouse_no%type,
                           v_Owner_No          in odata_outstock_d.owner_no%type,
                           v_Exp_Type          in odata_outstock_direct.exp_type%type,
                           v_WAVE_No           in odata_outstock_d.wave_no%type,
                           v_Area_No           in cdef_defcell.cell_no%type,
                           v_Cust_No           in bdef_defcust.cust_no%type,
                           v_Dock_No           in bdef_defdock.dock_no%type,
                           v_PickWorker        in odata_outstock_d.assign_name%type, --拣货人员
                           v_Operate_Type      in varchar2,
                           v_deliverObj        in odata_outstock_d.deliver_obj%type, --配送对象，如果不按配送对象切单，传N
                           v_strUserID         in odata_outstock_m.rgst_name%type, --系统操作人员
                           v_strPrintPaperType in odata_outstock_m.task_type%type, --是否打印表单标识，0：不打印，1，打印
                           strOutMsg           out varchar2) is

    --v_PickDeviceType odata_outstock_d.pick_device%type:='1';--PC终端
    v_AreaNo            cdef_defcell.area_no%type := v_Area_No;
    v_OperateType       varchar2(3) := v_Operate_Type;
    blCutTask           boolean;
    v_PrintPaperType    odata_outstock_m.task_type%type := v_strPrintPaperType;
    v_TaskGetType       WMS_TASKALLOT_RULE.Task_Get_Type%type;
    strCondition        varchar2(32767) := 'N';
    strOldCondition     varchar2(32767) := 'N';
    strCount_Condition  varchar2(32767) := 'N';
    strCurr_ArticleNo   varchar2(32767) := 'N';
    strCurr_CellNo      varchar2(32767) := 'N';
    strCurr_ContainerNo varchar2(32767) := 'N';
    nMaxBoxes           number := 0;
    nBoxes              number := 0;
    nSum_Boxes          number := 0;
    v_PrintStatus       odata_outstock_m.print_status%type;
    nMaxItems           number := 0;
    nItems              number := 0;
    nSum_Items          number := 0;

    nMax_Vol    number := 1000;
    nCurr_Stack number := 0;
    nSum_Stack  number := 0;

    nMax_Weight  number := 0;
    nCurr_Weight number := 0;
    nSum_Weight  number := 0;

    nQty          number := 0;
    nSum_QTY      number := 0;
    v_OutstockNo  odata_outstock_d.outstock_no%type;
    v_Print_Type  odata_outstock_m.task_type%type;
    v_strPickType odata_outstock_m.pick_type%type := '0';
  begin
    strOutMsg    := 'N|[p_pick_by_cust]';
    strCondition := '';

    if upper(v_area_no) = 'ALL' then
      v_AreaNo := '%';
    end if;

    if upper(v_Operate_Type) = 'ALL' then
      v_OperateType := '%';
    end if;

    for curOutstockDirect in (select *
                                from V_GETOMOUTSTOCKDIRECT0 v
                               where v.WAREHOUSE_NO = v_warehouse_No
                                 and v.EXP_TYPE = v_Exp_Type
                                 and v.WAVE_NO = v_wave_No
                                 and v.AREA_NO like v_AreaNo
                                 and v.CUST_NO = v_Cust_No
                                 and v.OPERATE_TYPE like v_OperateType
                                 and v.enterprise_no = strEnterpriseNo
                                 and v.outstock_type = '0'
                                 and ((v_deliverObj <> 'N' and
                                     v.deliver_obj = v_deliverObj) or
                                     v_deliverObj = 'N')) loop
      strOldCondition := strCondition;
      blCutTask       := false;
      v_Print_Type    := curOutstockDirect.print_type;
      v_TaskGetType   := curOutstockDirect.Task_Get_Type;
      strCondition    := curOutstockDirect.Operate_Type;

      --Modify BY QZH AT 2016-5-24 打印任务含报表，则表单打印任务不写
      if v_Print_Type in (CONST_REPORTID.Print_Report,
                          CONST_REPORTID.Print_MD_Report,
                          CONST_REPORTID.Print_M_Report,
                          CONST_REPORTID.Print_D_Report) then
        v_PrintPaperType := '0';
      end if;

      --Modify BY QZH AT 2016-5-24 PC前台发单
      if curOutstockDirect.Task_Get_Type = '0' then
        v_PrintStatus := '1';
      else
        v_PrintStatus := '0';
      end if;

      if (curOutstockDirect.Stock_Type <> CONST_DEFINE.cOutTaskType_cCust and
         curOutstockDirect.Operate_Type <> 'B') then
        strCondition := strCondition || curOutstockDirect.Sorter_Flag;
        \* else
        strCondition := null;*\
      end if;

      case curOutstockDirect.Allot_Rule
        when CONST_DEFINE.cAllotRule_Ware then
          strCondition := strCondition || curOutstockDirect.Ware_No;
        when CONST_DEFINE.cAllotRule_Area then
          strCondition := strCondition || curOutstockDirect.Area_No;
        when CONST_DEFINE.cAllotRule_Stock then
          strCondition := strCondition || curOutstockDirect.Stock_No;
        when CONST_DEFINE.cAllotRule_Area_Layer then
          strCondition := strCondition || curOutstockDirect.Area_Layer;
        when CONST_DEFINE.cAllotRule_Stock_Layer then
          strCondition := strCondition || curOutstockDirect.Stock_Layer;
        when CONST_DEFINE.cAllotRule_DPS_Area then
          strCondition := strCondition || curOutstockDirect.Dps_Area;
      end case;

      if (curOutstockDirect.Operate_Type = 'B' and
         curOutstockDirect.b_Divide = '0') then
        strCondition := strCondition || curOutstockDirect.Cust_No;
        strCondition := strCondition || curOutstockDirect.Deliver_Obj;
      end if;

      if (curOutstockDirect.Operate_Type = 'C' and
         curOutstockDirect.c_Divide = '0') then
        strCondition := strCondition || curOutstockDirect.Cust_No;
        strCondition := strCondition || curOutstockDirect.Deliver_Obj;
      end if;

      if curOutstockDirect.Operate_Type = 'P' \*and
                                                                                                                             curOutstockDirect.Source_Type = CONST_DEFINE.CSource_Type_MASS)*\
       then
        strCondition := strCondition || curOutstockDirect.Cust_No;
        strCondition := strCondition || curOutstockDirect.Deliver_Obj;
        --v_Print_Type:=const_reportid.Print_M;
      end if;

      if (curOutstockDirect.Operate_Type = 'M') then
        strCondition := strCondition || curOutstockDirect.s_Container_No;
      else
        case curOutstockDirect.Box_Flag
          when CONST_DEFINE.cBoxFlag_No_Cute then
            null;
          when CONST_DEFINE.cBoxFlag_Cute_By_Cases then
            --按拣货物流箱
            if curOutstockDirect.Operate_Type = 'B' then
              nMaxBoxes := curOutstockDirect.Para_Value;
              --if strCount_Condition <> curOutstockDirect.Pick_Container_No then
              if strCount_Condition <> curOutstockDirect.s_Container_No then
                nBoxes     := 1;
                nSum_Boxes := nSum_Boxes + nBoxes;
                --strCount_Condition := curOutstockDirect.Pick_Container_No;
                strCount_Condition := curOutstockDirect.s_Container_No;
              end if;
            end if;
          when CONST_DEFINE.cBoxFlag_Cute_By_PalNo then
            --按来源板号
            if (curOutstockDirect.Operate_Type = 'P' or
               curOutstockDirect.Operate_Type = 'M' or
               curOutstockDirect.Operate_Type = 'S' or
               curOutstockDirect.Operate_Type = 'W') then

              nMaxBoxes := curOutstockDirect.Para_Value;
              if strCount_Condition <> curOutstockDirect.s_Container_No then
                nBoxes             := 1;
                nSum_Boxes         := nSum_Boxes + nBoxes;
                strCount_Condition := curOutstockDirect.s_Container_No;
              end if;
            end if;
          when CONST_DEFINE.cBoxFlag_Cute_By_PAL_Cases then
            --按板堆叠+标准箱
            if (curOutstockDirect.Operate_Type = 'C' or
               curOutstockDirect.Operate_Type = 'D') then
              nMaxBoxes := curOutstockDirect.Para_Value;
              nMax_Vol  := 1000;
              if (strCurr_ArticleNo <> curOutstockDirect.ARTICLE_NO or
                 strCurr_CellNo <> curOutstockDirect.s_Cell_No or
                 strCurr_ContainerNo <> curOutstockDirect.S_CONTAINER_NO) then
                nCurr_Stack := Round(curOutstockDirect.SUM_LOCATE_QTY * 1000 /
                                     curOutstockDirect.QPALETTE,
                                     5);
                nSum_Stack  := nSum_Stack + nCurr_Stack;
                nBoxes      := floor(curOutstockDirect.SUM_LOCATE_QTY /
                                     curOutstockDirect.PACKING_QTY);
                nSum_Boxes  := nSum_Boxes + nBoxes;
              end if;
            end if;
          when CONST_DEFINE.cBoxFlag_Cute_By_PAL_Items then
            --按板堆叠+品项数
            if (curOutstockDirect.Operate_Type = 'C' or
               curOutstockDirect.Operate_Type = 'D') then
              nMax_Vol  := 1000;
              nMaxItems := curOutstockDirect.Para_Value;
              if (strCurr_ArticleNo <> curOutstockDirect.ARTICLE_NO or
                 strCurr_CellNo <> curOutstockDirect.s_Cell_No or
                 strCurr_ContainerNo <> curOutstockDirect.S_CONTAINER_NO) then
                strCurr_ArticleNo := curOutstockDirect.ARTICLE_NO;
                \*                  strCurr_CellNo    := curOutstockDirect.s_Cell_No;*\
                nItems      := 1;
                nSum_Items  := nSum_Items + nItems;
                nCurr_Stack := Round(curOutstockDirect.SUM_LOCATE_QTY * 1000 /
                                     curOutstockDirect.QPALETTE,
                                     5);
                nSum_Stack  := nSum_Stack + nCurr_Stack;
              end if;
            end if;
          when CONST_DEFINE.cBoxFlag_Cute_By_PAL_Weight then
            --按板堆叠+重量
            if (curOutstockDirect.Operate_Type = 'C' or
               curOutstockDirect.Operate_Type = 'D') then
              nMax_Vol    := 1000;
              nMax_Weight := curOutstockDirect.Para_Value;
              if (strCurr_ArticleNo <> curOutstockDirect.ARTICLE_NO or
                 strCurr_CellNo <> curOutstockDirect.s_Cell_No or
                 strCurr_ContainerNo <> curOutstockDirect.S_CONTAINER_NO) then
                strCurr_ArticleNo := curOutstockDirect.ARTICLE_NO;

                nCurr_Weight := curOutstockDirect.Sum_Article_Weight;
                nSum_Weight  := nSum_Weight + nCurr_Weight;
                nCurr_Stack  := Round(curOutstockDirect.SUM_LOCATE_QTY * 1000 /
                                      curOutstockDirect.QPALETTE,
                                      5);
                nSum_Stack   := nSum_Stack + nCurr_Stack;
              end if;
            end if;
          when CONST_DEFINE.cBoxFlag_Cute_By_Pals_Stack then
            --按板堆叠
            if (curOutstockDirect.Operate_Type = 'C' or
               curOutstockDirect.Operate_Type = 'D' or
               curOutstockDirect.Operate_Type = 'B') then
              nMax_Vol := 1000;
              if (strCurr_ArticleNo <> curOutstockDirect.ARTICLE_NO or
                 strCurr_CellNo <> curOutstockDirect.s_Cell_No or
                 strCurr_ContainerNo <> curOutstockDirect.S_CONTAINER_NO) then
                nCurr_Stack := Round(curOutstockDirect.SUM_LOCATE_QTY * 1000 /
                                     curOutstockDirect.QPALETTE,
                                     5);
                nSum_Stack  := nSum_Stack + nCurr_Stack;
              end if;
              nQty     := curOutstockDirect.LOCATE_QTY;
              nSum_QTY := nSum_QTY + nQty;
            end if;

          else
            null;
        end case;
      end if;

      if strOldCondition <> strCondition or strOldCondition is null then
        blCutTask := true;
      end if;

      if (blCutTask = false) then
        --B型作业且箱数大于系统可成单的箱数
        if (nSum_Boxes > nMaxBoxes and nMaxBoxes > 0 and
           curOutstockDirect.OPERATE_TYPE = 'B') then
          blCutTask := true;
        end if;
      end if;

      if (blCutTask = false) then
        --非B型作业且箱数大于系统可成单的箱数并且不同储位
        if ((nSum_Boxes > nMaxBoxes and nMaxBoxes > 0) and
           (curOutstockDirect.OPERATE_TYPE <> 'B') and
           (strCurr_CellNo <> curOutstockDirect.S_CELL_NO)) then
          blCutTask := true;
        end if;
      end if;

      if (blCutTask = false) then
        --累加品项数大于系统设置成单品项数且不同储位
        if ((nSum_Items > nMaxItems and nMaxItems > 0) and
           strCurr_CellNo <> curOutstockDirect.S_CELL_NO) then
          blCutTask := true;
        end if;
      end if;

      if (blCutTask = false) then
        --累加堆叠比例大于1且不同储位
        if ((floor(nSum_Stack) > nMax_Vol and nMax_Vol > 0) and
           strCurr_CellNo <> curOutstockDirect.S_CELL_NO) then
          blCutTask := true;
        end if;
      end if;

      if (blCutTask = false) then
        \*累加堆叠比例大于1且区域类型为地面堆叠、
        当前成单累加数量大于板堆叠比例且为当前累加数量能被商品包装整除*\
        if ((floor(nSum_Stack) > nMax_Vol and nMax_Vol > 0) and
           curOutstockDirect.AREA_TYPE = '3' and
           (floor(nSum_QTY) mod floor(curOutstockDirect.PACKING_QTY)) = 0 and
           floor(nSum_QTY) >= floor(curOutstockDirect.QPALETTE)) then
          blCutTask := true;
        end if;
      end if;

      if (blCutTask = false) then
        --当前累加重量大于系统设置最大重量且不同储位
        if ((floor(nSum_Weight) > nMax_Weight and nMax_Weight > 0) and
           strCurr_CellNo <> curOutstockDirect.S_CELL_NO and
           strCurr_ContainerNo <> curOutstockDirect.S_CONTAINER_NO) then
          blCutTask := true;
        end if;
      end if;

      --写下架单头
      if (blCutTask) then
        if v_OutstockNo is not null then

          --更新下架指示
          pkobj_odata.P_O_UpdatedOmOutStockDirect(strEnterPriseNo,
                                                  v_warehouse_No,
                                                  v_OutstockNo,
                                                  v_strUserID,
                                                  strOutMsg);

          if instr(strOutMsg, 'N', 1, 1) = 1 then
            return;
          end if;

          --写标签信息
          P_WriteLabelInfo(strEnterPriseNo,
                           v_warehouse_No,
                           v_Exp_Type,
                           v_Owner_No,
                           v_OutstockNo,
                           strOutMsg);
          if instr(strOutMsg, 'N', 1, 1) = 1 then
            return;
          end if;

          --Modify BY QZH AT 2016-5-24 PC前台发单
          if curOutstockDirect.Task_Get_Type = '0' then
            --写打印任务
            P_WritePrintJob(strEnterPriseNo,
                            v_warehouse_No,
                            v_OutstockNo,
                            v_Print_Type,
                            v_PickWorker,
                            strOutMsg);
            if instr(strOutMsg, 'N', 1, 1) = 1 then
              return;
            end if;
          end if;

          if v_PrintPaperType = '1' then
            --写表单打印任务
            --写打印任务
            P_WritePrintJob_Paper(strEnterPriseNo,
                                  v_warehouse_No,
                                  v_OutstockNo,
                                  v_Dock_No,
                                  v_PickWorker,
                                  strOutMsg);
            if instr(strOutMsg, 'N', 1, 1) = 1 then
              return;
            end if;
          end if;

          --出货单据状态跟踪 huangb 20160629
          P_Send_ExpTrace(strEnterPriseNo,
                          v_warehouse_No,
                          v_OutstockNo,
                          v_PickWorker,
                          strOutMsg);
          if instr(strOutMsg, 'N', 1, 1) = 1 then
            return;
          end if;

        end if;

        --记录当前指示的堆叠和重量、品项数、箱数
        if curOutstockDirect.Box_Flag = Const_Define.cBoxFlag_Cute_By_Cases then
          nSum_Boxes := nBoxes;
        else
          nSum_Boxes := 1;
        end if;

        nSum_Items := nItems;

        if curOutstockDirect.OPERATE_TYPE in ('C', 'D') then
          nSum_Weight := nCurr_Weight;
          nSum_Stack  := nCurr_Stack;
        end if;
        nSum_Qty := nQty;
        --end if;

        --取下架单号
        PKLG_WMS_BASE.p_getsheetno(strEnterPriseNo,
                                   curOutstockDirect.Warehouse_No,
                                   CONST_DOCUMENTTYPE.ODATAHO,
                                   v_OutstockNo,
                                   strOutMsg);
        if instr(strOutMsg, 'N', 1, 1) = 1 then
          return;
        end if;

        --写下架单头
        pkobj_odata.P_O_WriteOutStockHead(strEnterPriseNo,
                                          curOutstockDirect.Warehouse_No,
                                          v_Owner_No,
                                          v_WAVE_No,
                                          v_OutstockNo,
                                          curOutstockDirect.Pick_Type,
                                          curOutstockDirect.Batch_No,
                                          curOutstockDirect.Operate_Type,
                                          '10',
                                          v_strUserID,
                                          curOutstockDirect.TASK_TYPE,
                                          curOutstockDirect.Priority,
                                          curOutstockDirect.Exp_Date,
                                          curOutstockDirect.Outstock_Type,
                                          v_Dock_No,
                                          curOutstockDirect.Source_Type,
                                          curOutstockDirect.print_type,
                                          v_PrintStatus,
                                          curOutstockDirect.Task_Get_Type,
                                          'N',
                                          strOutMsg);
        if instr(strOutMsg, 'N', 1, 1) = 1 then
          return;
        end if;
      end if;

      --写下架明细
      PKOBJ_ODATA.P_O_WriteOutStockItem(strEnterPriseNo,
                                        curOutstockDirect.Warehouse_No,
                                        v_OutstockNo,
                                        v_PickWorker,
                                        curOutstockDirect.Direct_Serial,
                                        curOutstockDirect.Operate_Date,
                                        v_strPickType,
                                        strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        return;
      end if;
      strCurr_ContainerNo := curOutstockDirect.S_CONTAINER_NO;
      strCurr_ArticleNo   := curOutstockDirect.ARTICLE_NO;
      strCurr_CellNo      := curOutstockDirect.S_CELL_NO;
    end loop;

    --更新下架指示
    pkobj_odata.P_O_UpdatedOmOutStockDirect(strEnterPriseNo,
                                            v_warehouse_No,
                                            v_OutstockNo,
                                            v_strUserID,
                                            strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      return;
    end if;

    --写标签信息
    P_WriteLabelInfo(strEnterPriseNo,
                     v_warehouse_No,
                     v_Exp_Type,
                     v_Owner_No,
                     v_OutstockNo,
                     strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      return;
    end if;

    --Modify BY QZH AT 2016-5-24 PC前台发单
    if v_TaskGetType = '0' then
      --写打印任务
      P_WritePrintJob(strEnterPriseNo,
                      v_warehouse_No,
                      v_OutstockNo,
                      v_Print_Type,
                      v_PickWorker,
                      strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        return;
      end if;
    end if;
    if v_PrintPaperType = '1' then
      --写表单打印任务
      --写打印任务
      P_WritePrintJob_Paper(strEnterPriseNo,
                            v_warehouse_No,
                            v_OutstockNo,
                            v_dock_no,
                            v_PickWorker,
                            strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        return;
      end if;
    end if;
    --end if;

    --出货单据状态跟踪 huangb 20160629
    P_Send_ExpTrace(strEnterPriseNo,
                    v_warehouse_No,
                    v_OutstockNo,
                    v_PickWorker,
                    strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      return;
    end if;

    --波次跟踪，若整波次发单完成，则更新菠次追踪状态为11
    update odata_wave_trace owt
       set owt.status = '11', owt.updt_date = sysdate
     where owt.warehouse_no = v_warehouse_No
       and owt.wave_no = v_WAVE_No
       and owt.enterprise_no = strEnterPriseNo
       and owt.status = '10'
       and owt.wave_no not in
           (select wave_no
              from odata_outstock_direct
             where warehouse_no = v_warehouse_No
               and enterprise_no = strEnterPriseNo
               and wave_no = v_WAVE_No
               and status in ('10', '11', '12'));

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_pick_by_cust;

  \*****************************************************************************************************************
  2016.3.9
  功能说明：按配送对象发单，不分区域和作业类型
  ***************************************************************************************************************\
  procedure p_pick_by_deliver_obj(strEnterpriseNo     in odata_outstock_m.enterprise_no%type,
                                  v_warehouse_No      in odata_locate_m.warehouse_no%type,
                                  v_Owner_No          in odata_outstock_d.owner_no%type,
                                  v_Exp_Type          in odata_outstock_direct.exp_type%type,
                                  v_WAVE_No           in odata_outstock_d.wave_no%type,
                                  v_DeliverOBJ        in odata_outstock_d.deliver_obj%type,
                                  v_Dock_No           in bdef_defdock.dock_no%type,
                                  v_PickWorker        in odata_outstock_d.assign_name%type, --拣货人员
                                  v_strUserID         in odata_outstock_m.rgst_name%type, --系统操作人员
                                  v_strPrintPaperType in odata_outstock_m.task_type%type, --是否打印表单标识，0：不打印，1，打印
                                  strOutMsg           out varchar2) is
  begin
    strOutMsg := 'N|[p_pick_by_deliver_obj]';

    for OutstockInf in (select distinct v.CUST_NO, v.area_no, v.OPERATE_TYPE
                          from V_GETOMOUTSTOCKDIRECT0 v
                         where v.WAREHOUSE_NO = v_warehouse_No
                           and v.EXP_TYPE = v_Exp_Type
                           and v.WAVE_NO = v_wave_No
                           and v.enterprise_no = strEnterpriseNo
                           and v.outstock_type = '0'
                           and v.DELIVER_OBJ = v_deliverObj
                         order by v.CUST_NO, v.area_no, v.OPERATE_TYPE) loop
      --根据配送对象循环发单

      p_pick_by_cust(strEnterpriseNo,
                     v_warehouse_No,
                     v_Owner_No,
                     v_Exp_Type,
                     v_WAVE_No,
                     OutstockInf.area_no,
                     OutstockInf.cust_no,
                     v_Dock_No,
                     v_PickWorker,
                     OutstockInf.operate_type,
                     v_deliverObj,
                     v_strUserID,
                     v_strPrintPaperType,
                     strOutMsg);

      if instr(strOutMsg, 'N', 1, 1) = 1 then
        return;
      end if;
    end loop;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_pick_by_deliver_obj;

  \* 功能说明：自动成单发单
  Modify BY QZH AT 2016-5-24 支持RF索单
  下架表结构去掉Pick_Container_No,cust_container_no huangb 20160620
  *\
  procedure p_pick_by_Area(strEnterpriseNo     in odata_outstock_m.enterprise_no%type,
                           v_warehouse_No      in odata_locate_m.warehouse_no%type,
                           v_Owner_No          in odata_outstock_d.owner_no%type,
                           v_Exp_Type          in odata_outstock_direct.exp_type%type,
                           v_Source_Type       in odata_outstock_direct.source_type%type,
                           v_WAVE_No           in odata_outstock_d.wave_no%type,
                           v_Area_No           in cdef_defcell.cell_no%type,
                           v_Dock_No           in bdef_defdock.dock_no%type,
                           v_Operate_Type      in varchar2,
                           v_strUserID         in odata_outstock_m.rgst_name%type, --系统操作人员
                           v_strPrintPaperType in odata_outstock_m.task_type%type, --是否打印表单标识，0：不打印，1，打印
                           strOutMsg           out varchar2) is

    blCutTask           boolean;
    strCondition        varchar2(32767) := 'N';
    strOldCondition     varchar2(32767) := 'N';
    strCount_Condition  varchar2(32767) := 'N';
    strCurr_ArticleNo   varchar2(32767) := 'N';
    strCurr_CellNo      varchar2(32767) := 'N';
    strCurr_ContainerNo varchar2(32767) := 'N';
    nMaxBoxes           number := 0;
    nBoxes              number := 0;
    nSum_Boxes          number := 0;
    v_PrintPaperType    odata_outstock_m.task_type%type := v_strPrintPaperType; --是否打印表单标识，0：不打印，1，打印
    v_PrintStatus       odata_outstock_m.print_status%type;
    v_TaskGetType       WMS_TASKALLOT_RULE.Task_Get_Type%type;
    v_AreaNo            cdef_defcell.area_no%type := v_Area_No;
    v_OperateType       varchar2(3) := v_Operate_Type;
    nMaxItems           number := 0;
    nItems              number := 0;
    nSum_Items          number := 0;

    nMax_Vol    number := 1000;
    nCurr_Stack number := 0;
    nSum_Stack  number := 0;

    nMax_Weight  number := 0;
    nCurr_Weight number := 0;
    nSum_Weight  number := 0;

    nQty         number := 0;
    nSum_QTY     number := 0;
    v_OutstockNo odata_outstock_d.outstock_no%type;
    v_Print_Type odata_outstock_m.task_type%type;

  begin
    strOutMsg := 'N|[p_pick_by_Area]';

    strCondition       := '';
    strCount_Condition := '-1';

    if upper(v_area_no) = 'ALL' then
      v_AreaNo := '%';
    end if;

    if upper(v_Operate_Type) = 'ALL' then
      v_OperateType := '%';
    end if;

    for curOutstockDirect in (select *
                                from V_GETOMOUTSTOCKDIRECT0 v
                               where v.WAREHOUSE_NO = v_warehouse_No
                                 and v.OWNER_NO = v_Owner_No
                                 and v.EXP_TYPE = v_Exp_Type
                                 and v.WAVE_NO = v_wave_No
                                 and v.AREA_NO like v_AreaNo
                                 and v.Source_Type = v_Source_Type
                                 and v.OPERATE_TYPE like v_OperateType
                                 and v.enterprise_no = strEnterPriseNo
                                 and v.outstock_type = '0') loop
      strOldCondition := strCondition;
      blCutTask       := false;
      v_Print_Type    := curOutstockDirect.print_type;
      v_TaskGetType   := curOutstockDirect.Task_Get_Type;
      strCondition    := curOutstockDirect.Operate_Type;

      --Modify BY QZH AT 2016-5-24 打印任务含报表，则表单打印任务不写
      if v_Print_Type in (CONST_REPORTID.Print_Report,
                          CONST_REPORTID.Print_MD_Report,
                          CONST_REPORTID.Print_M_Report,
                          CONST_REPORTID.Print_D_Report) then
        v_PrintPaperType := '0';
      end if;

      --Modify BY QZH AT 2016-5-24 PC前台发单
      if curOutstockDirect.Task_Get_Type = '0' then
        v_PrintStatus := '1';
      else
        v_PrintStatus := '0';
      end if;

      if (curOutstockDirect.Stock_Type <> CONST_DEFINE.cOutTaskType_cCust and
         curOutstockDirect.Operate_Type <> 'B') then
        strCondition := strCondition || curOutstockDirect.Sorter_Flag;
      end if;

      case curOutstockDirect.Allot_Rule
        when CONST_DEFINE.cAllotRule_Ware then
          strCondition := strCondition || curOutstockDirect.Ware_No;
        when CONST_DEFINE.cAllotRule_Area then
          strCondition := strCondition || curOutstockDirect.Area_No;
        when CONST_DEFINE.cAllotRule_Stock then
          strCondition := strCondition || curOutstockDirect.Stock_No;
        when CONST_DEFINE.cAllotRule_Area_Layer then
          strCondition := strCondition || curOutstockDirect.Area_Layer;
        when CONST_DEFINE.cAllotRule_Stock_Layer then
          strCondition := strCondition || curOutstockDirect.Stock_Layer;
        when CONST_DEFINE.cAllotRule_DPS_Area then
          strCondition := strCondition || curOutstockDirect.Dps_Area;
      end case;

      if (curOutstockDirect.Operate_Type = 'B' and
         curOutstockDirect.b_Divide = '0') then
        strCondition := strCondition || curOutstockDirect.Cust_No;
        strCondition := strCondition || curOutstockDirect.Deliver_Obj;
      end if;

      if (curOutstockDirect.Operate_Type = 'C' and
         curOutstockDirect.c_Divide = '0') then
        strCondition := strCondition || curOutstockDirect.Cust_No;
        strCondition := strCondition || curOutstockDirect.Deliver_Obj;
      end if;

      if curOutstockDirect.Operate_Type = 'P' \* and
                                                                                                                             curOutstockDirect.Source_Type = CONST_DEFINE.CSource_Type_MASS)*\
       then
        strCondition := strCondition || curOutstockDirect.Cust_No;
        strCondition := strCondition || curOutstockDirect.Deliver_Obj;
        --v_Print_Type:=const_reportid.Print_M;
      end if;

      if (curOutstockDirect.Operate_Type = 'M') then
        strCondition := strCondition || curOutstockDirect.s_Container_No;
      else
        case curOutstockDirect.Box_Flag
          when CONST_DEFINE.cBoxFlag_No_Cute then
            null;
          when CONST_DEFINE.cBoxFlag_Cute_By_Cases then
            --按拣货物流箱
            if curOutstockDirect.Operate_Type = 'B' then
              nMaxBoxes := curOutstockDirect.Para_Value;
              if curOutstockDirect.pick_type = '0' then
                --if strCount_Condition <> curOutstockDirect.cust_container_no then
                if strCount_Condition <> curOutstockDirect.s_Container_No then
                  nBoxes     := 1;
                  nSum_Boxes := nSum_Boxes + nBoxes;
                  --strCount_Condition := curOutstockDirect.cust_container_no;
                  strCount_Condition := curOutstockDirect.s_Container_No;
                end if;
              else
                --if strCount_Condition <> curOutstockDirect.Pick_Container_No then
                if strCount_Condition <> curOutstockDirect.s_Container_No then
                  nBoxes     := 1;
                  nSum_Boxes := nSum_Boxes + nBoxes;
                  --strCount_Condition := curOutstockDirect.pick_container_no;
                  strCount_Condition := curOutstockDirect.s_Container_No;
                end if;
              end if;
            end if;
          when CONST_DEFINE.cBoxFlag_Cute_By_PalNo then
            --按来源板号
            if (curOutstockDirect.Operate_Type = 'P' or
               curOutstockDirect.Operate_Type = 'M' or
               curOutstockDirect.Operate_Type = 'S' or
               curOutstockDirect.Operate_Type = 'W') then

              nMaxBoxes := curOutstockDirect.Para_Value;
              if strCount_Condition <> curOutstockDirect.s_Container_No then
                nBoxes             := 1;
                nSum_Boxes         := nSum_Boxes + nBoxes;
                strCount_Condition := curOutstockDirect.s_Container_No;
              end if;
            end if;
          when CONST_DEFINE.cBoxFlag_Cute_By_PAL_Cases then
            --按板堆叠+标准箱
            if (curOutstockDirect.Operate_Type = 'C' or
               curOutstockDirect.Operate_Type = 'D') then
              nMaxBoxes := curOutstockDirect.Para_Value;
              nMax_Vol  := 1000;
              if (strCurr_ArticleNo <> curOutstockDirect.ARTICLE_NO or
                 strCurr_CellNo <> curOutstockDirect.s_Cell_No or
                 strCurr_ContainerNo <> curOutstockDirect.S_CONTAINER_NO) then
                nCurr_Stack := Round(curOutstockDirect.SUM_LOCATE_QTY * 1000 /
                                     curOutstockDirect.QPALETTE,
                                     5);
                nSum_Stack  := nSum_Stack + nCurr_Stack;
                nBoxes      := floor(curOutstockDirect.SUM_LOCATE_QTY /
                                     curOutstockDirect.PACKING_QTY);
                nSum_Boxes  := nSum_Boxes + nBoxes;
              end if;
            end if;
          when CONST_DEFINE.cBoxFlag_Cute_By_PAL_Items then
            --按板堆叠+品项数
            if (curOutstockDirect.Operate_Type = 'C' or
               curOutstockDirect.Operate_Type = 'D') then
              nMax_Vol  := 1000;
              nMaxItems := curOutstockDirect.Para_Value;
              if (strCurr_ArticleNo <> curOutstockDirect.ARTICLE_NO or
                 strCurr_CellNo <> curOutstockDirect.s_Cell_No or
                 strCurr_ContainerNo <> curOutstockDirect.S_CONTAINER_NO) then
                strCurr_ArticleNo := curOutstockDirect.ARTICLE_NO;
                \*                  strCurr_CellNo    := curOutstockDirect.s_Cell_No;*\
                nItems      := 1;
                nSum_Items  := nSum_Items + nItems;
                nCurr_Stack := Round(curOutstockDirect.SUM_LOCATE_QTY * 1000 /
                                     curOutstockDirect.QPALETTE,
                                     5);
                nSum_Stack  := nSum_Stack + nCurr_Stack;
              end if;
            end if;
          when CONST_DEFINE.cBoxFlag_Cute_By_PAL_Weight then
            --按板堆叠+重量
            if (curOutstockDirect.Operate_Type = 'C' or
               curOutstockDirect.Operate_Type = 'D') then
              nMax_Vol    := 1000;
              nMax_Weight := curOutstockDirect.Para_Value;
              if (strCurr_ArticleNo <> curOutstockDirect.ARTICLE_NO or
                 strCurr_CellNo <> curOutstockDirect.s_Cell_No or
                 strCurr_ContainerNo <> curOutstockDirect.S_CONTAINER_NO) then
                strCurr_ArticleNo := curOutstockDirect.ARTICLE_NO;

                nCurr_Weight := curOutstockDirect.Sum_Article_Weight;
                nSum_Weight  := nSum_Weight + nCurr_Weight;
                nCurr_Stack  := Round(curOutstockDirect.SUM_LOCATE_QTY * 1000 /
                                      curOutstockDirect.QPALETTE,
                                      5);
                nSum_Stack   := nSum_Stack + nCurr_Stack;
              end if;
            end if;
          when CONST_DEFINE.cBoxFlag_Cute_By_Pals_Stack then
            --按板堆叠
            if (curOutstockDirect.Operate_Type = 'C' or
               curOutstockDirect.Operate_Type = 'D' or
               curOutstockDirect.Operate_Type = 'B') then
              nMax_Vol := 1000;
              if (strCurr_ArticleNo <> curOutstockDirect.ARTICLE_NO or
                 strCurr_CellNo <> curOutstockDirect.s_Cell_No or
                 strCurr_ContainerNo <> curOutstockDirect.S_CONTAINER_NO) then
                nCurr_Stack := Round(curOutstockDirect.SUM_LOCATE_QTY * 1000 /
                                     curOutstockDirect.QPALETTE,
                                     5);
                nSum_Stack  := nSum_Stack + nCurr_Stack;
              end if;
              nQty     := curOutstockDirect.LOCATE_QTY;
              nSum_QTY := nSum_QTY + nQty;
            end if;
          else
            null;
        end case;

      end if;

      if strOldCondition <> strCondition or strOldCondition is null then
        blCutTask := true;
      end if;

      if (blCutTask = false) then
        --B型作业且箱数大于系统可成单的箱数
        if (nSum_Boxes > nMaxBoxes and nMaxBoxes > 0 and
           curOutstockDirect.OPERATE_TYPE = 'B') then
          blCutTask := true;
        end if;
      end if;

      if (blCutTask = false) then
        --非B型作业且箱数大于系统可成单的箱数并且不同储位
        if ((nSum_Boxes > nMaxBoxes and nMaxBoxes > 0) and
           (curOutstockDirect.OPERATE_TYPE <> 'B') and
           (strCurr_CellNo <> curOutstockDirect.S_CELL_NO)) then
          blCutTask := true;
        end if;
      end if;

      if (blCutTask = false) then
        --累加品项数大于系统设置成单品项数且不同储位
        if ((nSum_Items > nMaxItems and nMaxItems > 0) and
           strCurr_CellNo <> curOutstockDirect.S_CELL_NO) then
          blCutTask := true;
        end if;
      end if;

      if (blCutTask = false) then
        --累加堆叠比例大于1且不同储位
        if ((floor(nSum_Stack) > nMax_Vol and nMax_Vol > 0) and
           strCurr_CellNo <> curOutstockDirect.S_CELL_NO) then
          blCutTask := true;
        end if;
      end if;

      if (blCutTask = false) then
        \*累加堆叠比例大于1且区域类型为地面堆叠、
        当前成单累加数量大于板堆叠比例且为当前累加数量能被商品包装整除*\
        if ((floor(nSum_Stack) > nMax_Vol and nMax_Vol > 0) and
           curOutstockDirect.AREA_TYPE = '3' and
           (floor(nSum_QTY) mod floor(curOutstockDirect.PACKING_QTY)) = 0 and
           floor(nSum_QTY) >= floor(curOutstockDirect.QPALETTE)) then
          blCutTask := true;
        end if;
      end if;

      if (blCutTask = false) then
        --当前累加重量大于系统设置最大重量且不同储位
        if ((floor(nSum_Weight) > nMax_Weight and nMax_Weight > 0) and
           strCurr_CellNo <> curOutstockDirect.S_CELL_NO and
           strCurr_ContainerNo <> curOutstockDirect.S_CONTAINER_NO) then
          blCutTask := true;
        end if;
      end if;

      --写下架单头
      if (blCutTask) then
        if v_OutstockNo is not null then

          --更新下架指示
          pkobj_odata.P_O_UpdatedOmOutStockDirect(strEnterPriseNo,
                                                  v_warehouse_No,
                                                  v_OutstockNo,
                                                  v_strUserID,
                                                  strOutMsg);
          if instr(strOutMsg, 'N', 1, 1) = 1 then
            return;
          end if;

          --写标签信息
          P_WriteLabelInfo(strEnterPriseNo,
                           v_warehouse_No,
                           v_Exp_Type,
                           v_Owner_No,
                           v_OutstockNo,
                           strOutMsg);
          if instr(strOutMsg, 'N', 1, 1) = 1 then
            return;
          end if;

          --Modify BY QZH AT 2016-5-24 PC前台发单
          if curOutstockDirect.Task_Get_Type = '0' then

            --写打印任务
            P_WritePrintJob(strEnterPriseNo,
                            v_warehouse_No,
                            v_OutstockNo,
                            v_Print_Type,
                            v_strUserID,
                            strOutMsg);
            if instr(strOutMsg, 'N', 1, 1) = 1 then
              return;
            end if;
          end if;

          if v_PrintPaperType = '1' then
            --写表单打印任务
            --写打印任务
            P_WritePrintJob_Paper(strEnterPriseNo,
                                  v_warehouse_No,
                                  v_OutstockNo,
                                  v_Dock_No,
                                  v_strUserID,
                                  strOutMsg);
            if instr(strOutMsg, 'N', 1, 1) = 1 then
              return;
            end if;
          end if;
          --end if;

          --出货单据状态跟踪 huangb 20160629
          P_Send_ExpTrace(strEnterPriseNo,
                          v_warehouse_No,
                          v_OutstockNo,
                          v_strUserID,
                          strOutMsg);
          if instr(strOutMsg, 'N', 1, 1) = 1 then
            return;
          end if;

          --记录当前指示的堆叠和重量、品项数、箱数
          if curOutstockDirect.Box_Flag =
             Const_Define.cBoxFlag_Cute_By_Cases then
            nSum_Boxes := nBoxes;
          else
            nSum_Boxes := 1;
          end if;

          nSum_Items := nItems;

          if curOutstockDirect.OPERATE_TYPE in ('C', 'D') then
            nSum_Weight := nCurr_Weight;
            nSum_Stack  := nCurr_Stack;
          end if;
          nSum_Qty := nQty;
        end if;

        --取下架单号
        PKLG_WMS_BASE.p_getsheetno(strEnterPriseNo,
                                   curOutstockDirect.Warehouse_No,
                                   CONST_DOCUMENTTYPE.ODATAHO,
                                   v_OutstockNo,
                                   strOutMsg);
        if instr(strOutMsg, 'N', 1, 1) = 1 then
          return;
        end if;

        --写下架单头
        pkobj_odata.P_O_WriteOutStockHead(strEnterPriseNo,
                                          curOutstockDirect.Warehouse_No,
                                          v_Owner_No,
                                          v_WAVE_No,
                                          v_OutstockNo,
                                          curOutstockDirect.Pick_Type,
                                          curOutstockDirect.Batch_No,
                                          curOutstockDirect.Operate_Type,
                                          '10',
                                          v_strUserID,
                                          curOutstockDirect.TASK_TYPE,
                                          curOutstockDirect.Priority,
                                          curOutstockDirect.Exp_Date,
                                          curOutstockDirect.Outstock_Type,
                                          v_Dock_No,
                                          curOutstockDirect.Source_Type,
                                          curOutstockDirect.print_type,
                                          v_PrintStatus,
                                          curOutstockDirect.Task_Get_Type,
                                          'N',
                                          strOutMsg);
        if instr(strOutMsg, 'N', 1, 1) = 1 then
          return;
        end if;
      end if;

      --写下架明细
      PKOBJ_ODATA.P_O_WriteOutStockItem(strEnterPriseNo,
                                        curOutstockDirect.Warehouse_No,
                                        v_OutstockNo,
                                        v_strUserID,
                                        curOutstockDirect.Direct_Serial,
                                        curOutstockDirect.Operate_Date,
                                        curOutstockDirect.pick_type,
                                        strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        return;
      end if;

      \*if curOutstockDirect.outstock_type = '0' and
         curOutstockDirect.operate_type = 'B' then
        if curOutstockDirect.Pick_Type = '1' then
          strCurr_ContainerNo := curOutstockDirect.pick_CONTAINER_NO;
          strCount_Condition  := curOutstockDirect.pick_CONTAINER_NO;
        else
          strCurr_ContainerNo := curOutstockDirect.cust_CONTAINER_NO;
          strCount_Condition  := curOutstockDirect.cust_CONTAINER_NO;
        end if;
      else
        strCurr_ContainerNo := curOutstockDirect.S_CONTAINER_NO;
        strCount_Condition  := curOutstockDirect.S_CONTAINER_NO;
      end if;*\
      strCurr_ContainerNo := curOutstockDirect.S_CONTAINER_NO;
      strCount_Condition  := curOutstockDirect.S_CONTAINER_NO;

      strCurr_ArticleNo := curOutstockDirect.ARTICLE_NO;
      strCurr_CellNo    := curOutstockDirect.S_CELL_NO;
    end loop;

    --更新下架指示
    pkobj_odata.P_O_UpdatedOmOutStockDirect(strEnterPriseNo,
                                            v_warehouse_No,
                                            v_OutstockNo,
                                            v_strUserID,
                                            strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      return;
    end if;

    --写标签信息
    P_WriteLabelInfo(strEnterPriseNo,
                     v_warehouse_No,
                     v_Exp_Type,
                     v_Owner_No,
                     v_OutstockNo,
                     strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      return;
    end if;

    --Modify BY QZH AT 2016-5-24 PC前台发单
    if v_TaskGetType = '0' then
      --写打印任务
      P_WritePrintJob(strEnterPriseNo,
                      v_warehouse_No,
                      v_OutstockNo,
                      v_Print_Type,
                      v_strUserID,
                      strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        return;
      end if;
    end if;

    if v_PrintPaperType = '1' then
      --写表单打印任务
      --写打印任务
      P_WritePrintJob_Paper(strEnterPriseNo,
                            v_warehouse_No,
                            v_OutstockNo,
                            v_Dock_No,
                            v_strUserID,
                            strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        return;
      end if;
    end if;
    --end if;

    --出货单据状态跟踪 huangb 20160629
    P_Send_ExpTrace(strEnterPriseNo,
                    v_warehouse_No,
                    v_OutstockNo,
                    v_strUserID,
                    strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      return;
    end if;

    --波次跟踪，若整波次发单完成，则更新菠次追踪状态为11
    update odata_wave_trace owt
       set owt.status = '11', owt.updt_date = sysdate
     where owt.warehouse_no = v_warehouse_No
       and owt.wave_no = v_WAVE_No
       and owt.enterprise_no = strEnterPriseNo
       and owt.status = '10'
       and owt.wave_no not in
           (select wave_no
              from odata_outstock_direct
             where warehouse_no = v_warehouse_No
               and enterprise_no = strEnterPriseNo
               and wave_no = v_WAVE_No
               and status in ('10', '11', '12'));

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_pick_by_Area;

  */ /*****************************************************************************************************************
  功能说明：发单
  Modify BY QZH AT 2016-5-24 支持RF索单
  更改获取规则参数方式 huangb 20160618
  下架表结构去掉Pick_Container_No,cust_container_no 以及增加按批次切单方式 huangb 20160620
  新增出货单据状态跟踪 huangb 20160629
  ***************************************************************************************************************/
  procedure p_pick_by_ec(strEnterpriseNo     in odata_outstock_m.enterprise_no%type,
                         v_warehouse_No      in odata_locate_m.warehouse_no%type,
                         v_Owner_No          in odata_outstock_d.owner_no%type,
                         v_Exp_Type          in odata_outstock_direct.exp_type%type,
                         v_WAVE_No           in odata_outstock_d.wave_no%type,
                         v_Batch_No          in odata_outstock_d.batch_no%type, --批次 huangb 20160618
                         v_Area_No           in cdef_defcell.cell_no%type,
                         v_Cust_No           in bdef_defcust.cust_no%type, --客户，电商传N
                         v_DeliverOBJ        in odata_outstock_d.deliver_obj%type, --配送对象，无法确定传N
                         v_Dock_No           in bdef_defdock.dock_no%type,
                         v_PickWorker        in odata_outstock_d.assign_name%type, --拣货人员
                         v_Operate_Type      in varchar2,
                         v_strUserID         in odata_outstock_m.rgst_name%type, --系统操作人员
                         v_strPrintPaperType in odata_outstock_m.task_type%type, --是否打印拣货单标识，0：不打印，1，打印
                         strPrintWayBill     in odata_outstock_m.task_type%type, --是否打印快递面单，0：不打印，1：打印
                         strPrintPackList    in odata_outstock_m.task_type%type, --是否打印装箱清单，0：不打印，1：打印
                         strPrintInVoice     in odata_outstock_m.task_type%type, --是否打印发票，0：不打印，1：打印
                         strOutMsg           out varchar2) is

    --v_PickDeviceType odata_outstock_d.pick_device%type:='1';--PC终端
    -- v_AreaNo         cdef_defcell.area_no%type := v_Area_No;
    v_OperateType    varchar2(3) := v_Operate_Type;
    blCutTask        boolean;
    v_PrintPaperType odata_outstock_m.task_type%type := v_strPrintPaperType;
    v_OwnerNo        odata_locate_batch.owner_no%type; --委托业主 huangb 20160803

    --v_strWaveRule     varchar2(3) := '1'; --波次切单规则
    v_strBatchRule      varchar2(3) := '1'; --批次切单规则 huangb 20160618
    v_TaskGetType       WMS_TASKALLOT_RULE.Task_Get_Type%type;
    v_TaskType          WMS_TASKALLOT_RULE.Task_Type%type; --拣货打单方式 huangb 20160620
    strCondition        varchar2(32767) := 'N';
    strOldCondition     varchar2(32767) := 'N';
    strCount_Condition  varchar2(32767) := 'N';
    strCurr_ArticleNo   varchar2(32767) := 'N';
    strCurr_CellNo      varchar2(32767) := 'N';
    strCurr_ContainerNo varchar2(32767) := 'N';
    strCurr_ExpNo       odata_exp_m.exp_no%type := 'N';
    v_Curr_DeliverObj   odata_outstock_direct.deliver_obj%type := 'N';
    v_lstExp_No         varchar2(32767) := 'N';
    nMaxBoxes           number := 0;
    nBoxes              number := 0;
    nSum_Boxes          number := 0;
    v_PrintStatus       odata_outstock_m.print_status%type;
    nMaxItems           number := 0;
    nItems              number := 0;
    nSum_Items          number := 0;

    nMaxOrders    number := 0;
    v_nOrderCount number := 0;
    --v_nDeliverObjCount number := 0;
    nMax_Vol    number := 1000;
    nCurr_Stack number := 0;
    nSum_Stack  number := 0;

    nMax_Weight  number := 0;
    nCurr_Weight number := 0;
    nSum_Weight  number := 0;

    nQty          number := 0;
    nSum_QTY      number := 0;
    v_OutstockNo  odata_outstock_d.outstock_no%type;
    v_Print_Type  odata_outstock_m.task_type%type;
    v_strPickType odata_outstock_m.pick_type%type := '0';

    v_Print_WayBill  odata_locate_batch.print_waybill%type;
    v_Print_Invoice  odata_locate_batch.print_envoice%type;
    v_Print_PackList odata_locate_batch.print_packlist%type;
    v_OneDeliverOnePick wms_taskallot_rule_m.onedeliveronepick%type;--要求一次拣货
  begin
    strOutMsg := 'N|[p_pick_by_ec]';

    --获取委托业主 huangb 20160803
    begin
      select olb.owner_no into v_OwnerNo
        from odata_locate_batch olb
       where olb.enterprise_no = strEnterpriseNo
         and olb.warehouse_no = v_warehouse_No
         and olb.wave_no = v_WAVE_No
         and olb.batch_no = v_Batch_No;
    exception
      when no_data_found then
        strOutMsg := 'N|批次规则odata_locate_batch没有数据!';
        return;
    end;

    begin
      select m.rule_type,
             t.print_waybill,
             t.print_packlist,
             t.print_envoice,
             nvl(m.para_value, 1),
             nvl(m.task_type, '0'),
             nvl(m.print_type, '2'),
             nvl(m.task_get_type, '0'),
             nvl(m.Onedeliveronepick,'0')
        into v_strBatchRule,
             v_Print_WayBill,
             v_Print_PackList,
             v_Print_Invoice,
             nMaxOrders,
             v_TaskType,
             v_Print_Type,
             v_TaskGetType,
             v_OneDeliverOnePick
        from odata_locate_batch t, wms_taskallot_rule_m m
       where t.enterprise_no = m.enterprise_no
         and t.task_rule_id = m.task_ruleid
         and t.enterprise_no = strEnterpriseNo
         and t.owner_no = v_OwnerNo
         and t.warehouse_no = v_warehouse_No
         and t.wave_no = v_WAVE_No
         and t.batch_no = v_Batch_No;
    exception
      when no_data_found then
        strOutMsg := 'N|切单规则wms_taskallot_rule_m未定义!';
        return;
    end;

    nMaxItems := nMaxOrders;

    for curOutstockDirect in (select t.*
                                from (select v.*, rownum as rowno
                                        from V_GETOMOUTSTOCKDIRECT0 v
                                       where v.WAREHOUSE_NO = v_warehouse_No
                                         and v.EXP_TYPE = v_Exp_Type
                                         and v.WAVE_NO = v_wave_No
                                         and v.BATCH_NO = v_Batch_No
                                         and (v.CUST_NO = v_Cust_No or
                                             upper(v_Cust_No) = 'N')
                                         and (v.DELIVER_OBJ = v_DeliverOBJ or
                                             upper(v_DeliverOBJ) = 'N')
                                         and (v.AREA_NO = v_Area_No or
                                             upper(v_Area_No) = 'ALL')
                                         and (v.OPERATE_TYPE = v_Operate_Type or
                                             upper(v_Operate_Type) = 'ALL')
                                         and v.enterprise_no =
                                             strEnterpriseNo
                                         and v.outstock_type = '0'
                                         and (v_OneDeliverOnePick='0'
                                         or (v_OneDeliverOnePick='1'
                                         and not exists(select 'x' from
                                         odata_outstock_direct ood
                                         where ood.enterprise_no=v.ENTERPRISE_NO
                                         and ood.warehouse_no=v.WAREHOUSE_NO
                                         and ood.wave_no=v.WAVE_NO
                                         and ood.batch_no=v.BATCH_NO
                                         and ood.operate_type=v.OPERATE_TYPE
                                         and ood.deliver_obj=v.DELIVER_OBJ
                                         and ood.status in ('11','12')))))
                                         t
                               order by t.OPERATE_TYPE,
                                        CASE v_strBatchRule
                                          WHEN '3' THEN
                                           t.DELIVER_OBJ
                                          WHEN '4' THEN
                                           t.DELIVER_OBJ || t.rowno
                                          WHEN '5' THEN
                                           t.article_no
                                          WHEN '6' THEN
                                           t.article_no || t.rowno
                                          else
                                           null
                                        end,
                                        t.rowno) loop
      strOldCondition := strCondition;
      blCutTask       := false;
      --如果是按订单数,配送对象,商品代码,批次切单 则 不根据操作类型切单 huangb 20160622
      --strCondition    := curOutstockDirect.Operate_Type;

      --只要是有按区域属性切单的规则 则 相关规则都根据区域规则来 huangb 20160620
      if v_strBatchRule in ('1', '4', '6') then
        v_TaskType    := curOutstockDirect.Task_Type;
        v_Print_Type  := curOutstockDirect.print_type;
        v_TaskGetType := curOutstockDirect.Task_Get_Type;
      end if;

      v_OperateType := curOutstockDirect.Operate_Type;
      --如果是按订单数,配送对象,商品代码,批次切单 则 下架单头档的作业类型为混合作业类型
      if v_strBatchRule in ('2', '3', '5', '7') then
        v_OperateType := COPERATE_TYPE.TYPE_MIX;
      end if;
      --如果是按批次切分 则当前批次不切分 huangb 20160620
      if v_strBatchRule = '7' then
        strCondition := curOutstockDirect.Batch_No;
      else
        --huangb 20160622
        strCondition := v_OperateType;
      end if;

      --Modify BY QZH AT 2016-5-24 打印任务含报表，则表单打印任务不写
      if v_Print_Type in (CONST_REPORTID.Print_Report,
                          CONST_REPORTID.Print_MD_Report,
                          CONST_REPORTID.Print_M_Report,
                          CONST_REPORTID.Print_D_Report) then
        v_PrintPaperType := '0';
      end if;

      --Modify BY QZH AT 2016-5-24 PC前台发单
      if v_TaskGetType = '0' then
        v_PrintStatus := '1';
      else
        v_PrintStatus := '0';
      end if;

      if v_strBatchRule in ('2', '3', '4', '5', '6') then

        case v_strBatchRule
        --按订单数
          when '2' then
            if instr(v_lstExp_No, '''' || curOutstockDirect.Exp_No || '''') <= 0 then
              v_lstExp_No   := v_lstExp_No || ',' || '''' ||
                               curOutstockDirect.Exp_No || '''';
              v_nOrderCount := v_nOrderCount + 1;
            end if;
            --按配送对象
          when '3' then
            if v_Curr_DeliverObj <> curOutstockDirect.DELIVER_OBJ then
              --v_nDeliverObjCount := v_nDeliverObjCount + 1;
              blCutTask := true;
            end if;
            --按配送对象+区域规则
          when '4' then
            if v_Curr_DeliverObj <> curOutstockDirect.DELIVER_OBJ then
              --v_nDeliverObjCount := v_nDeliverObjCount + 1;
              blCutTask := true;
            end if;
            --按商品
          when '5' then
            if strCurr_ArticleNo <> curOutstockDirect.Article_No then
              --nItems := 1;
              blCutTask := true;
            end if;
            --按商品 +区域
          when '6' then
            if strCurr_ArticleNo <> curOutstockDirect.Article_No then
              --nItems := nItems + 1;
              blCutTask := true;
            end if;
        end case;

        if (blCutTask = false and v_strBatchRule = '2') then
          if v_nOrderCount > nMaxOrders then
            blCutTask := true;
          end if;
        end if;
        --按配送对象切单 huangb 20160618 注释于20160630
        /*if (blCutTask = false) then
          if v_nDeliverObjCount > nMaxOrders then
            blCutTask := true;
          end if;
        end if;
        if (blCutTask = false) then
          if nItems > nMaxItems then
            blCutTask := true;
          end if;
        end if;*/
      end if;

      if v_strBatchRule in ('1', '4', '6') and blCutTask = false then

        if (curOutstockDirect.Stock_Type <> CONST_DEFINE.cOutTaskType_cCust and
           curOutstockDirect.Operate_Type <> 'B') then
          strCondition := strCondition || curOutstockDirect.Sorter_Flag;
        end if;

        case curOutstockDirect.Allot_Rule
          when CONST_DEFINE.cAllotRule_Ware then
            strCondition := strCondition || curOutstockDirect.Ware_No;
          when CONST_DEFINE.cAllotRule_Area then
            strCondition := strCondition || curOutstockDirect.Area_No;
          when CONST_DEFINE.cAllotRule_Stock then
            strCondition := strCondition || curOutstockDirect.Stock_No;
          when CONST_DEFINE.cAllotRule_Area_Layer then
            strCondition := strCondition || curOutstockDirect.Area_Layer;
          when CONST_DEFINE.cAllotRule_Stock_Layer then
            strCondition := strCondition || curOutstockDirect.Stock_Layer;
          when CONST_DEFINE.cAllotRule_DPS_Area then
            strCondition := strCondition || curOutstockDirect.Dps_Area;
        end case;

        --Modify BY QZH AT 2016-7-21  分播不再参考配送对象，按配送对象分单上面已有限制
        if (curOutstockDirect.Operate_Type = 'C' and
           curOutstockDirect.c_Divide = '0') then
          strCondition := strCondition || curOutstockDirect.Cust_No;
          --Modify BY QZH AT 2016-7-21
          --strCondition := strCondition || curOutstockDirect.Deliver_Obj;
        end if;

        if curOutstockDirect.Operate_Type = 'P' then
          strCondition := strCondition || curOutstockDirect.Cust_No;
          --Modify BY QZH AT 2016-7-21
          --strCondition := strCondition || curOutstockDirect.Deliver_Obj;
          --v_Print_Type:=const_reportid.Print_M;
        end if;

        if (curOutstockDirect.Operate_Type = 'B' and
           curOutstockDirect.b_Divide = '0') then
          strCondition := strCondition || curOutstockDirect.Cust_No;
          --Modify BY QZH AT 2016-7-21
          --strCondition := strCondition || curOutstockDirect.Deliver_Obj;
        end if;

        if (curOutstockDirect.Operate_Type = 'M') then
          strCondition := strCondition || curOutstockDirect.s_Container_No;
        else
          case curOutstockDirect.Box_Flag
            when CONST_DEFINE.cBoxFlag_No_Cute then
              null;
            when CONST_DEFINE.cBoxFlag_Cute_By_Cases then
              --按拣货物流箱
              if curOutstockDirect.Operate_Type = 'B' then
                nMaxBoxes := curOutstockDirect.Para_Value;
                --if strCount_Condition <> curOutstockDirect.Pick_Container_No then
                if strCount_Condition <> curOutstockDirect.s_Container_No then
                  nBoxes     := 1;
                  nSum_Boxes := nSum_Boxes + nBoxes;
                  --strCount_Condition := curOutstockDirect.Pick_Container_No;
                  strCount_Condition := curOutstockDirect.s_Container_No;
                end if;
              end if;
            when CONST_DEFINE.cBoxFlag_Cute_By_PalNo then
              --按来源板号
              if (curOutstockDirect.Operate_Type = 'P' or
                 curOutstockDirect.Operate_Type = 'M' or
                 curOutstockDirect.Operate_Type = 'S' or
                 curOutstockDirect.Operate_Type = 'W') then

                nMaxBoxes := curOutstockDirect.Para_Value;
                if strCount_Condition <> curOutstockDirect.s_Container_No then
                  nBoxes             := 1;
                  nSum_Boxes         := nSum_Boxes + nBoxes;
                  strCount_Condition := curOutstockDirect.s_Container_No;
                end if;
              end if;
            when CONST_DEFINE.cBoxFlag_Cute_By_PAL_Cases then
              --按板堆叠+标准箱
              if (curOutstockDirect.Operate_Type = 'C' or
                 curOutstockDirect.Operate_Type = 'D') then
                nMaxBoxes := curOutstockDirect.Para_Value;
                nMax_Vol  := 1000;
                if (strCurr_ArticleNo <> curOutstockDirect.ARTICLE_NO or
                   strCurr_CellNo <> curOutstockDirect.s_Cell_No or
                   strCurr_ContainerNo <> curOutstockDirect.S_CONTAINER_NO) then
                  nCurr_Stack := Round(curOutstockDirect.SUM_LOCATE_QTY * 1000 /
                                       curOutstockDirect.QPALETTE,
                                       5);
                  nSum_Stack  := nSum_Stack + nCurr_Stack;
                  nBoxes      := floor(curOutstockDirect.SUM_LOCATE_QTY /
                                       curOutstockDirect.PACKING_QTY);
                  nSum_Boxes  := nSum_Boxes + nBoxes;
                end if;
              end if;
            when CONST_DEFINE.cBoxFlag_Cute_By_PAL_Items then
              --按板堆叠+品项数
              if (curOutstockDirect.Operate_Type = 'C' or
                 curOutstockDirect.Operate_Type = 'D') then
                nMax_Vol  := 1000;
                nMaxItems := curOutstockDirect.Para_Value;
                if (strCurr_ArticleNo <> curOutstockDirect.ARTICLE_NO or
                   strCurr_CellNo <> curOutstockDirect.s_Cell_No or
                   strCurr_ContainerNo <> curOutstockDirect.S_CONTAINER_NO) then
                  strCurr_ArticleNo := curOutstockDirect.ARTICLE_NO;
                  /*                  strCurr_CellNo    := curOutstockDirect.s_Cell_No;*/
                  nItems      := 1;
                  nSum_Items  := nSum_Items + nItems;
                  nCurr_Stack := Round(curOutstockDirect.SUM_LOCATE_QTY * 1000 /
                                       curOutstockDirect.QPALETTE,
                                       5);
                  nSum_Stack  := nSum_Stack + nCurr_Stack;
                end if;
              end if;
            when CONST_DEFINE.cBoxFlag_Cute_By_PAL_Weight then
              --按板堆叠+重量
              if (curOutstockDirect.Operate_Type = 'C' or
                 curOutstockDirect.Operate_Type = 'D') then
                nMax_Vol    := 1000;
                nMax_Weight := curOutstockDirect.Para_Value;
                if (strCurr_ArticleNo <> curOutstockDirect.ARTICLE_NO or
                   strCurr_CellNo <> curOutstockDirect.s_Cell_No or
                   strCurr_ContainerNo <> curOutstockDirect.S_CONTAINER_NO) then
                  strCurr_ArticleNo := curOutstockDirect.ARTICLE_NO;

                  nCurr_Weight := curOutstockDirect.Sum_Article_Weight;
                  nSum_Weight  := nSum_Weight + nCurr_Weight;
                  nCurr_Stack  := Round(curOutstockDirect.SUM_LOCATE_QTY * 1000 /
                                        curOutstockDirect.QPALETTE,
                                        5);
                  nSum_Stack   := nSum_Stack + nCurr_Stack;
                end if;
              end if;
            when CONST_DEFINE.cBoxFlag_Cute_By_Pals_Stack then
              --按板堆叠
              if (curOutstockDirect.Operate_Type = 'C' or
                 curOutstockDirect.Operate_Type = 'D' or
                 curOutstockDirect.Operate_Type = 'B') then
                nMax_Vol := 1000;
                if (strCurr_ArticleNo <> curOutstockDirect.ARTICLE_NO or
                   strCurr_CellNo <> curOutstockDirect.s_Cell_No or
                   strCurr_ContainerNo <> curOutstockDirect.S_CONTAINER_NO) then
                  nCurr_Stack := Round(curOutstockDirect.SUM_LOCATE_QTY * 1000 /
                                       curOutstockDirect.QPALETTE,
                                       5);
                  nSum_Stack  := nSum_Stack + nCurr_Stack;
                end if;
                nQty     := curOutstockDirect.LOCATE_QTY;
                nSum_QTY := nSum_QTY + nQty;
              end if;

            else
              null;
          end case;
        end if;

        if (blCutTask = false) then
          --B型作业且箱数大于系统可成单的箱数
          if (nSum_Boxes > nMaxBoxes and nMaxBoxes > 0 and
             curOutstockDirect.OPERATE_TYPE = 'B') then
            blCutTask := true;
          end if;
        end if;

        if (blCutTask = false) then
          --非B型作业且箱数大于系统可成单的箱数并且不同储位
          if ((nSum_Boxes > nMaxBoxes and nMaxBoxes > 0) and
             (curOutstockDirect.OPERATE_TYPE <> 'B') and
             (strCurr_CellNo <> curOutstockDirect.S_CELL_NO)) then
            blCutTask := true;
          end if;
        end if;

        if (blCutTask = false) then
          --累加品项数大于系统设置成单品项数且不同储位
          if ((nSum_Items > nMaxItems and nMaxItems > 0) and
             strCurr_CellNo <> curOutstockDirect.S_CELL_NO) then
            blCutTask := true;
          end if;
        end if;

        if (blCutTask = false) then
          --累加堆叠比例大于1且不同储位
          if ((floor(nSum_Stack) > nMax_Vol and nMax_Vol > 0) and
             strCurr_CellNo <> curOutstockDirect.S_CELL_NO) then
            blCutTask := true;
          end if;
        end if;

        if (blCutTask = false) then
          /*累加堆叠比例大于1且区域类型为地面堆叠、
          当前成单累加数量大于板堆叠比例且为当前累加数量能被商品包装整除*/
          if ((floor(nSum_Stack) > nMax_Vol and nMax_Vol > 0) and
             curOutstockDirect.AREA_TYPE = '3' and
             (floor(nSum_QTY) mod floor(curOutstockDirect.PACKING_QTY)) = 0 and
             floor(nSum_QTY) >= floor(curOutstockDirect.QPALETTE)) then
            blCutTask := true;
          end if;
        end if;

        if (blCutTask = false) then
          --当前累加重量大于系统设置最大重量且不同储位
          if ((floor(nSum_Weight) > nMax_Weight and nMax_Weight > 0) and
             strCurr_CellNo <> curOutstockDirect.S_CELL_NO and
             strCurr_ContainerNo <> curOutstockDirect.S_CONTAINER_NO) then
            blCutTask := true;
          end if;
        end if;
      end if;

      if strOldCondition <> strCondition or strOldCondition = 'N' then
        blCutTask := true;
      end if;

      --写下架单头
      if (blCutTask) then
        if v_OutstockNo is not null then

          --更新下架指示
          pkobj_odata.P_O_UpdatedOmOutStockDirect(strEnterPriseNo,
                                                  v_warehouse_No,
                                                  v_OutstockNo,
                                                  v_strUserID,
                                                  strOutMsg);

          if instr(strOutMsg, 'N', 1, 1) = 1 then
            return;
          end if;

          --写标签信息
          P_WriteLabelInfo(strEnterPriseNo,
                           v_warehouse_No,
                           v_Exp_Type,
                           v_OwnerNo,
                           v_OutstockNo,
                           strOutMsg);
          if instr(strOutMsg, 'N', 1, 1) = 1 then
            return;
          end if;

          --Modify BY QZH AT 2016-5-24 PC前台发单
          --if curOutstockDirect.Task_Get_Type = '0' then
          if v_TaskGetType = '0' then
            --写打印任务
            P_WritePrintJob(strEnterPriseNo,
                            v_warehouse_No,
                            v_OutstockNo,
                            v_Print_Type,
                            v_PickWorker,
                            strOutMsg);
            if instr(strOutMsg, 'N', 1, 1) = 1 then
              return;
            end if;
          end if;

          if v_PrintPaperType = '1' then
            --写表单打印任务
            --写打印任务
            P_WritePrintJob_Paper(strEnterPriseNo,
                                  v_warehouse_No,
                                  v_OutstockNo,
                                  v_Dock_No,
                                  v_PickWorker,
                                  strOutMsg);
            if instr(strOutMsg, 'N', 1, 1) = 1 then
              return;
            end if;
          end if;

          --打装箱清单
          if strPrintPackList = '1' or v_Print_PackList = '1' then
            P_WritePrintJob_BoxList(strEnterPriseNo,
                                    v_warehouse_No,
                                    v_OutstockNo,
                                    v_Dock_No,
                                    v_PickWorker,
                                    strOutMsg);
            if instr(strOutMsg, 'N', 1, 1) = 1 then
              return;
            end if;
          end if;

          --打面单
          if strPrintWayBill = '1' or v_Print_WayBill = '1' then
            P_WritePrintJob_WayBill(strEnterPriseNo,
                                    v_warehouse_No,
                                    v_OutstockNo,
                                    v_Dock_No,
                                    v_PickWorker,
                                    strOutMsg);
            if instr(strOutMsg, 'N', 1, 1) = 1 then
              return;
            end if;
          end if;

          --打发票
          if strPrintInVoice = '1' or v_Print_Invoice = '1' then
            P_WritePrintJob_Invoice(strEnterPriseNo,
                                    v_warehouse_No,
                                    v_OutstockNo,
                                    v_Dock_No,
                                    v_PickWorker,
                                    strOutMsg);
            if instr(strOutMsg, 'N', 1, 1) = 1 then
              return;
            end if;
          end if;

          --出货单据状态跟踪 huangb 20160629
          P_Send_ExpTrace(strEnterPriseNo,
                          v_warehouse_No,
                          v_OutstockNo,
                          v_PickWorker,
                          strOutMsg);
          if instr(strOutMsg, 'N', 1, 1) = 1 then
            return;
          end if;

          --记录当前指示的堆叠和重量、品项数、箱数
          if curOutstockDirect.Box_Flag =
             Const_Define.cBoxFlag_Cute_By_Cases then
            nSum_Boxes := nBoxes;
          else
            nSum_Boxes := 1;
          end if;

          nSum_Items := nItems;

          if curOutstockDirect.OPERATE_TYPE in ('C', 'D') then
            nSum_Weight := nCurr_Weight;
            nSum_Stack  := nCurr_Stack;
          end if;
          nSum_Qty := nQty;

          --订单号
          strCurr_ExpNo := curOutstockDirect.Exp_No;
          --v_Curr_DeliverObj  := curOutstockDirect.DELIVER_OBJ; --huangb 20160618
          v_lstExp_No   := '''' || strCurr_ExpNo || '''';
          v_nOrderCount := 1;
          --v_nDeliverObjCount := 1; --huangb 20160618
          nItems := 1;
        end if;

        --取下架单号
        PKLG_WMS_BASE.p_getsheetno(strEnterPriseNo,
                                   curOutstockDirect.Warehouse_No,
                                   CONST_DOCUMENTTYPE.ODATAHO,
                                   v_OutstockNo,
                                   strOutMsg);
        if instr(strOutMsg, 'N', 1, 1) = 1 then
          return;
        end if;

        --写下架单头
        pkobj_odata.P_O_WriteOutStockHead(strEnterPriseNo,
                                          curOutstockDirect.Warehouse_No,
                                          v_OwnerNo,
                                          v_WAVE_No,
                                          v_OutstockNo,
                                          curOutstockDirect.Pick_Type,
                                          curOutstockDirect.Batch_No,
                                          --curOutstockDirect.Operate_Type,
                                          v_OperateType,
                                          '10',
                                          v_strUserID,
                                          --curOutstockDirect.TASK_TYPE,
                                          v_TaskType,
                                          curOutstockDirect.Priority,
                                          curOutstockDirect.Exp_Date,
                                          curOutstockDirect.Outstock_Type,
                                          v_Dock_No,
                                          curOutstockDirect.Source_Type,
                                          --curOutstockDirect.print_type,
                                          v_Print_Type,
                                          v_PrintStatus,
                                          --curOutstockDirect.Task_Get_Type,
                                          v_TaskGetType,
                                          'N',
                                          strOutMsg);
        if instr(strOutMsg, 'N', 1, 1) = 1 then
          return;
        end if;
      end if;

      --写下架明细
      PKOBJ_ODATA.P_O_WriteOutStockItem(strEnterPriseNo,
                                        curOutstockDirect.Warehouse_No,
                                        v_OutstockNo,
                                        v_PickWorker,
                                        curOutstockDirect.Direct_Serial,
                                        curOutstockDirect.Operate_Date,
                                        v_strPickType,
                                        strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        return;
      end if;
      strCurr_ContainerNo := curOutstockDirect.S_CONTAINER_NO;
      strCurr_ArticleNo   := curOutstockDirect.ARTICLE_NO;
      strCurr_CellNo      := curOutstockDirect.S_CELL_NO;
      strCurr_ExpNo       := curOutstockDirect.Exp_No;
      v_Curr_DeliverObj   := curOutstockDirect.DELIVER_OBJ; --huangb 20160630
    end loop;

    --更新下架指示
    pkobj_odata.P_O_UpdatedOmOutStockDirect(strEnterPriseNo,
                                            v_warehouse_No,
                                            v_OutstockNo,
                                            v_strUserID,
                                            strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      return;
    end if;

    --写标签信息
    P_WriteLabelInfo(strEnterPriseNo,
                     v_warehouse_No,
                     v_Exp_Type,
                     v_OwnerNo,
                     v_OutstockNo,
                     strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      return;
    end if;

    --Modify BY QZH AT 2016-5-24 PC前台发单
    if v_TaskGetType = '0' then
      --写打印任务
      P_WritePrintJob(strEnterPriseNo,
                      v_warehouse_No,
                      v_OutstockNo,
                      v_Print_Type,
                      v_PickWorker,
                      strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        return;
      end if;
    end if;

    if v_PrintPaperType = '1' then
      --写表单打印任务
      --写打印任务
      P_WritePrintJob_Paper(strEnterPriseNo,
                            v_warehouse_No,
                            v_OutstockNo,
                            v_dock_no,
                            v_PickWorker,
                            strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        return;
      end if;
    end if;

    --打装箱清单
    if strPrintPackList = '1' or v_Print_PackList = '1' then
      P_WritePrintJob_BoxList(strEnterPriseNo,
                              v_warehouse_No,
                              v_OutstockNo,
                              v_Dock_No,
                              v_PickWorker,
                              strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        return;
      end if;
    end if;

    --打面单
    if strPrintWayBill = '1' or v_Print_WayBill = '1' then
      P_WritePrintJob_WayBill(strEnterPriseNo,
                              v_warehouse_No,
                              v_OutstockNo,
                              v_Dock_No,
                              v_PickWorker,
                              strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        return;
      end if;
    end if;

    --打发票
    if strPrintInVoice = '1' or v_Print_Invoice = '1' then
      P_WritePrintJob_Invoice(strEnterPriseNo,
                              v_warehouse_No,
                              v_OutstockNo,
                              v_Dock_No,
                              v_PickWorker,
                              strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        return;
      end if;
    end if;

    --出货单据状态跟踪 huangb 20160629
    P_Send_ExpTrace(strEnterPriseNo,
                    v_warehouse_No,
                    v_OutstockNo,
                    v_PickWorker,
                    strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      return;
    end if;

    --波次跟踪，若整波次发单完成，则更新菠次追踪状态为11
    update odata_wave_trace owt
       set owt.status = '11', owt.updt_date = sysdate
     where owt.warehouse_no = v_warehouse_No
       and owt.wave_no = v_WAVE_No
       and owt.enterprise_no = strEnterPriseNo
       and owt.status = '10'
       and owt.wave_no not in
           (select wave_no
              from odata_outstock_direct
             where warehouse_no = v_warehouse_No
               and enterprise_no = strEnterPriseNo
               and wave_no = v_WAVE_No
               and status in ('10', '11', '12'));

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_pick_by_ec;

  /* 功能说明：出货量补货发单
  Modify BY QZH AT 2016-5-24 支持RF索单
  下架表结构去掉Pick_Container_No,cust_container_no huangb 20160620
  */
  procedure p_Hm_by_Area(strEnterpriseNo     in odata_outstock_m.enterprise_no%type,
                         v_warehouse_No      in odata_locate_m.warehouse_no%type,
                         v_Owner_No          in odata_outstock_d.owner_no%type,
                         v_Exp_Type          in odata_outstock_direct.exp_type%type,
                         v_WAVE_No           in odata_outstock_d.wave_no%type,
                         v_Batch_No          in odata_outstock_d.batch_no%type, --批次 huangb 20160618
                         v_Area_No           in cdef_defcell.cell_no%type,
                         v_Dock_No           in bdef_defdock.dock_no%type,
                         v_Operate_Type      in odata_outstock_m.operate_type%type,
                         v_strUserID         in odata_outstock_m.rgst_name%type, --系统操作人员
                         v_strPrintPaperType in odata_outstock_m.task_type%type, --是否打印表单标识，0：不打印，1，打印
                         strOutMsg           out varchar2) is

    v_PrintPaperType    odata_outstock_m.task_type%type := v_strPrintPaperType; --是否打印表单标识，0：不打印，1，打印
    v_PrintStatus       odata_outstock_m.print_status%type;
    blCutTask           boolean;
    v_TaskGetType       WMS_TASKALLOT_RULE.Task_Get_Type%type;
    v_AreaNo            cdef_defcell.area_no%type := v_Area_No;
    v_OperateType       varchar2(3) := v_Operate_Type;
    strCondition        varchar2(32767) := 'N';
    strOldCondition     varchar2(32767) := 'N';
    strCount_Condition  varchar2(32767) := 'N';
    strCurr_ArticleNo   varchar2(32767) := 'N';
    strCurr_CellNo      varchar2(32767) := 'N';
    strCurr_ContainerNo varchar2(32767) := 'N';
    nMaxBoxes           number := 0;
    nBoxes              number := 0;
    nSum_Boxes          number := 0;

    nMaxItems  number := 0;
    nItems     number := 0;
    nSum_Items number := 0;

    nMax_Vol    number := 1000;
    nCurr_Stack number := 0;
    nSum_Stack  number := 0;

    nMax_Weight  number := 0;
    nCurr_Weight number := 0;
    nSum_Weight  number := 0;

    nQty         number := 0;
    nSum_QTY     number := 0;
    v_OutstockNo odata_outstock_d.outstock_no%type;
    v_Print_Type odata_outstock_m.task_type%type;
    v_OwnerNo    odata_locate_batch.owner_no%type; --委托业主 huangb 20160803

  begin
    strOutMsg    := 'N|[p_Hm_by_Area]';
    strCondition := '';

    --获取委托业主 huangb 20160803
    begin
      select olb.owner_no into v_OwnerNo
        from odata_locate_batch olb
       where olb.enterprise_no = strEnterpriseNo
         and olb.warehouse_no = v_warehouse_No
         and olb.wave_no = v_WAVE_No
         and olb.batch_no = v_Batch_No;
    exception
      when no_data_found then
        strOutMsg := 'N|批次规则odata_locate_batch没有数据!';
        return;
    end;

    if upper(v_area_no) = 'ALL' then
      v_AreaNo := '%';
    end if;

    if upper(v_Operate_Type) = 'ALL' then
      v_OperateType := '%';
    end if;

    for curOutstockDirect in (select *
                                from V_GETOMOUTSTOCKDIRECT1 v
                               where v.WAREHOUSE_NO = v_warehouse_No
                                 and v.enterprise_no = strEnterPriseNo
                                 --有混合业主情况,不带委托业主 huangb 20160803
                                 --and v.OWNER_NO = v_Owner_No
                                 and v.EXP_TYPE = v_Exp_Type
                                 and v.WAVE_NO = v_wave_No
                                 and v.batch_no = v_Batch_No
                                 and v.AREA_NO like v_AreaNo
                                    --and v.Source_Type = v_Source_Type
                                 and v.OPERATE_TYPE like v_OperateType
                                 and v.outstock_type = '1') loop
      strOldCondition := strCondition;
      blCutTask       := false;
      v_Print_Type    := curOutstockDirect.print_type;
      v_TaskGetType   := curOutstockDirect.Task_Get_Type;

      --Modify BY QZH AT 2016-5-24 打印任务含报表，则表单打印任务不写
      if v_Print_Type in (CONST_REPORTID.Print_Report,
                          CONST_REPORTID.Print_MD_Report,
                          CONST_REPORTID.Print_M_Report,
                          CONST_REPORTID.Print_D_Report) then
        v_PrintPaperType := '0';
      end if;

      --Modify BY QZH AT 2016-5-24 PC前台发单
      if curOutstockDirect.Task_Get_Type = '0' then
        v_PrintStatus := '1';
      else
        v_PrintStatus := '0';
      end if;

      if (curOutstockDirect.Stock_Type <> CONST_DEFINE.cOutTaskType_cCust and
         curOutstockDirect.Operate_Type <> 'B') then
        strCondition := curOutstockDirect.Sorter_Flag;
      else
        strCondition := null;
      end if;

      case curOutstockDirect.Allot_Rule
        when CONST_DEFINE.cAllotRule_Ware then
          strCondition := strCondition || curOutstockDirect.Ware_No;
        when CONST_DEFINE.cAllotRule_Area then
          strCondition := strCondition || curOutstockDirect.Area_No;
        when CONST_DEFINE.cAllotRule_Stock then
          strCondition := strCondition || curOutstockDirect.Stock_No;
        when CONST_DEFINE.cAllotRule_Area_Layer then
          strCondition := strCondition || curOutstockDirect.Area_Layer;
        when CONST_DEFINE.cAllotRule_Stock_Layer then
          strCondition := strCondition || curOutstockDirect.Stock_Layer;
      end case;

      if (curOutstockDirect.Operate_Type = 'B' and
         curOutstockDirect.b_Divide = '0') then
        strCondition := strCondition || curOutstockDirect.Cust_No;
        strCondition := strCondition || curOutstockDirect.Deliver_Obj;
      end if;

      if (curOutstockDirect.Operate_Type = 'C' and
         curOutstockDirect.c_Divide = '0') then
        strCondition := strCondition || curOutstockDirect.Cust_No;
        strCondition := strCondition || curOutstockDirect.Deliver_Obj;
      end if;

      if (curOutstockDirect.Operate_Type = 'P' and
         curOutstockDirect.Source_Type = CONST_DEFINE.CSource_Type_MASS) then
        strCondition := strCondition || curOutstockDirect.Cust_No;
        strCondition := strCondition || curOutstockDirect.Deliver_Obj;
      end if;

      if (curOutstockDirect.Operate_Type = 'M') then
        strCondition := strCondition || curOutstockDirect.s_Container_No;
      else
        case curOutstockDirect.Box_Flag
          when CONST_DEFINE.cBoxFlag_No_Cute then
            null;
          when CONST_DEFINE.cBoxFlag_Cute_By_Cases then
            --按拣货物流箱
            if curOutstockDirect.Operate_Type = 'B' then
              nMaxBoxes := curOutstockDirect.Para_Value;
              --if strCount_Condition <> curOutstockDirect.Pick_Container_No then
              if strCount_Condition <> curOutstockDirect.s_Container_No then
                nBoxes     := 1;
                nSum_Boxes := nSum_Boxes + nBoxes;
                --strCount_Condition := curOutstockDirect.Pick_Container_No;
                strCount_Condition := curOutstockDirect.s_Container_No;
              end if;
            end if;
          when CONST_DEFINE.cBoxFlag_Cute_By_PalNo then
            --按来源板号
            if (curOutstockDirect.Operate_Type = 'P' or
               curOutstockDirect.Operate_Type = 'M' or
               curOutstockDirect.Operate_Type = 'S' or
               curOutstockDirect.Operate_Type = 'W') then

              nMaxBoxes := curOutstockDirect.Para_Value;
              if strCount_Condition <> curOutstockDirect.s_Container_No then
                nBoxes             := 1;
                nSum_Boxes         := nSum_Boxes + nBoxes;
                strCount_Condition := curOutstockDirect.s_Container_No;
              end if;
            end if;
          when CONST_DEFINE.cBoxFlag_Cute_By_PAL_Cases then
            --按板堆叠+标准箱
            if (curOutstockDirect.Operate_Type = 'C' or
               curOutstockDirect.Operate_Type = 'D') then
              nMaxBoxes := curOutstockDirect.Para_Value;
              nMax_Vol  := 1000;
              if (strCurr_ArticleNo <> curOutstockDirect.ARTICLE_NO or
                 strCurr_CellNo <> curOutstockDirect.s_Cell_No or
                 strCurr_ContainerNo <> curOutstockDirect.S_CONTAINER_NO) then
                nCurr_Stack := Round(curOutstockDirect.SUM_LOCATE_QTY * 1000 /
                                     curOutstockDirect.QPALETTE,
                                     5);
                nSum_Stack  := nSum_Stack + nCurr_Stack;
                nBoxes      := floor(curOutstockDirect.SUM_LOCATE_QTY /
                                     curOutstockDirect.PACKING_QTY);
                nSum_Boxes  := nSum_Boxes + nBoxes;
              end if;
            end if;
          when CONST_DEFINE.cBoxFlag_Cute_By_PAL_Items then
            --按板堆叠+品项数
            if (curOutstockDirect.Operate_Type = 'C' or
               curOutstockDirect.Operate_Type = 'D') then
              nMax_Vol  := 1000;
              nMaxItems := curOutstockDirect.Para_Value;
              if (strCurr_ArticleNo <> curOutstockDirect.ARTICLE_NO or
                 strCurr_CellNo <> curOutstockDirect.s_Cell_No or
                 strCurr_ContainerNo <> curOutstockDirect.S_CONTAINER_NO) then
                /*                  strCurr_ArticleNo := curOutstockDirect.ARTICLE_NO;
                strCurr_CellNo    := curOutstockDirect.s_Cell_No;*/
                nItems      := 1;
                nSum_Items  := nSum_Items + nItems;
                nCurr_Stack := Round(curOutstockDirect.SUM_LOCATE_QTY * 1000 /
                                     curOutstockDirect.QPALETTE,
                                     5);
                nSum_Stack  := nSum_Stack + nCurr_Stack;
              end if;
            end if;
          when CONST_DEFINE.cBoxFlag_Cute_By_PAL_Weight then
            --按板堆叠+重量
            if (curOutstockDirect.Operate_Type = 'C' or
               curOutstockDirect.Operate_Type = 'D') then
              nMax_Vol    := 1000;
              nMax_Weight := curOutstockDirect.Para_Value;
              if (strCurr_ArticleNo <> curOutstockDirect.ARTICLE_NO or
                 strCurr_CellNo <> curOutstockDirect.s_Cell_No or
                 strCurr_ContainerNo <> curOutstockDirect.S_CONTAINER_NO) then
                /*                  strCurr_ArticleNo := curOutstockDirect.ARTICLE_NO;*/

                nCurr_Weight := curOutstockDirect.Sum_Article_Weight;
                nSum_Weight  := nSum_Weight + nCurr_Weight;
                nCurr_Stack  := Round(curOutstockDirect.SUM_LOCATE_QTY * 1000 /
                                      curOutstockDirect.QPALETTE,
                                      5);
                nSum_Stack   := nSum_Stack + nCurr_Stack;
              end if;
            end if;
          when CONST_DEFINE.cBoxFlag_Cute_By_Pals_Stack then
            --按板堆叠
            if (curOutstockDirect.Operate_Type = 'C' or
               curOutstockDirect.Operate_Type = 'D' or
               curOutstockDirect.Operate_Type = 'B') then
              nMax_Vol := 1000;
              if (strCurr_ArticleNo <> curOutstockDirect.ARTICLE_NO or
                 strCurr_CellNo <> curOutstockDirect.s_Cell_No or
                 strCurr_ContainerNo <> curOutstockDirect.S_CONTAINER_NO) then
                nCurr_Stack := Round(curOutstockDirect.SUM_LOCATE_QTY * 1000 /
                                     curOutstockDirect.QPALETTE,
                                     5);
                nSum_Stack  := nSum_Stack + nCurr_Stack;
              end if;
              nQty     := curOutstockDirect.LOCATE_QTY;
              nSum_QTY := nSum_QTY + nQty;
            end if;
          else
            null;
        end case;
      end if;

      if strOldCondition <> strCondition or strOldCondition is null then
        blCutTask := true;
      end if;

      if (blCutTask = false) then
        --B型作业且箱数大于系统可成单的箱数
        if (nSum_Boxes > nMaxBoxes and nMaxBoxes > 0 and
           curOutstockDirect.OPERATE_TYPE = 'B') then
          blCutTask := true;
        end if;
      end if;

      if (blCutTask = false) then
        --非B型作业且箱数大于系统可成单的箱数并且不同储位
        if ((nSum_Boxes > nMaxBoxes and nMaxBoxes > 0) and
           (curOutstockDirect.OPERATE_TYPE <> 'B') and
           (strCurr_CellNo <> curOutstockDirect.S_CELL_NO)) then
          blCutTask := true;
        end if;
      end if;

      if (blCutTask = false) then
        --累加品项数大于系统设置成单品项数且不同储位
        if ((nSum_Items > nMaxItems and nMaxItems > 0) and
           strCurr_CellNo <> curOutstockDirect.S_CELL_NO) then
          blCutTask := true;
        end if;
      end if;

      if (blCutTask = false) then
        --累加堆叠比例大于1且不同储位
        if ((floor(nSum_Stack) > nMax_Vol and nMax_Vol > 0) and
           strCurr_CellNo <> curOutstockDirect.S_CELL_NO) then
          blCutTask := true;
        end if;
      end if;

      if (blCutTask = false) then
        /*累加堆叠比例大于1且区域类型为地面堆叠、
        当前成单累加数量大于板堆叠比例且为当前累加数量能被商品包装整除*/
        if ((floor(nSum_Stack) > nMax_Vol and nMax_Vol > 0) and
           curOutstockDirect.AREA_TYPE = '3' and
           (floor(nSum_QTY) mod floor(curOutstockDirect.PACKING_QTY)) = 0 and
           floor(nSum_QTY) >= floor(curOutstockDirect.QPALETTE)) then
          blCutTask := true;
        end if;
      end if;

      if (blCutTask = false) then
        --当前累加重量大于系统设置最大重量且不同储位
        if ((floor(nSum_Weight) > nMax_Weight and nMax_Weight > 0) and
           strCurr_CellNo <> curOutstockDirect.S_CELL_NO and
           strCurr_ContainerNo <> curOutstockDirect.S_CONTAINER_NO) then
          blCutTask := true;
        end if;
      end if;

      --写下架单头
      if (blCutTask) then
        if v_OutstockNo is not null then

          --更新下架指示
          pkobj_odata.P_O_UpdatedOmOutStockDirect(strEnterPriseNo,
                                                  v_warehouse_No,
                                                  v_OutstockNo,
                                                  v_strUserID,
                                                  strOutMsg);
          if instr(strOutMsg, 'N', 1, 1) = 1 then
            return;
          end if;

          --写标签信息
          P_WriteLabelInfo(strEnterPriseNo,
                           v_warehouse_No,
                           v_Exp_Type,
                           v_OwnerNo,
                           v_OutstockNo,
                           strOutMsg);
          if instr(strOutMsg, 'N', 1, 1) = 1 then
            return;
          end if;

          --Modify BY QZH AT 2016-5-24 PC前台发单
          if curOutstockDirect.Task_Get_Type = '0' then
            --写打印任务
            P_WritePrintJob(strEnterPriseNo,
                            v_warehouse_No,
                            v_OutstockNo,
                            v_Print_Type,
                            v_strUserID,
                            strOutMsg);
            if instr(strOutMsg, 'N', 1, 1) = 1 then
              return;
            end if;
          end if;

          if v_PrintPaperType = '1' then
            --写表单打印任务
            --写打印任务
            P_WritePrintJob_Paper(strEnterPriseNo,
                                  v_warehouse_No,
                                  v_OutstockNo,
                                  v_Dock_No,
                                  v_strUserID,
                                  strOutMsg);
            if instr(strOutMsg, 'N', 1, 1) = 1 then
              return;
            end if;
          end if;
          --end if;
          --记录当前指示的堆叠和重量、品项数、箱数
          if curOutstockDirect.Box_Flag =
             Const_Define.cBoxFlag_Cute_By_Cases then
            nSum_Boxes := nBoxes;
          else
            nSum_Boxes := 1;
          end if;

          nSum_Items := nItems;

          if curOutstockDirect.OPERATE_TYPE in ('C', 'D') then
            nSum_Weight := nCurr_Weight;
            nSum_Stack  := nCurr_Stack;
          end if;
          nSum_Qty := nQty;
        end if;

        --取下架单号
        PKLG_WMS_BASE.p_getsheetno(strEnterPriseNo,
                                   curOutstockDirect.Warehouse_No,
                                   CONST_DOCUMENTTYPE.MDATAHS,
                                   v_OutstockNo,
                                   strOutMsg);
        if instr(strOutMsg, 'N', 1, 1) = 1 then
          return;
        end if;

        --写下架单头
        pkobj_odata.P_O_WriteOutStockHead(strEnterPriseNo,
                                          curOutstockDirect.Warehouse_No,
                                          v_OwnerNo,
                                          v_WAVE_No,
                                          v_OutstockNo,
                                          curOutstockDirect.Pick_Type,
                                          curOutstockDirect.Batch_No,
                                          curOutstockDirect.Operate_Type,
                                          '10',
                                          v_strUserID,
                                          curOutstockDirect.TASK_TYPE,
                                          curOutstockDirect.Priority,
                                          curOutstockDirect.Exp_Date,
                                          curOutstockDirect.Outstock_Type,
                                          v_Dock_No,
                                          curOutstockDirect.Source_Type,
                                          curOutstockDirect.print_type,
                                          v_PrintStatus,
                                          curOutstockDirect.Task_Get_Type,
                                          'N',
                                          strOutMsg);
        if instr(strOutMsg, 'N', 1, 1) = 1 then
          return;
        end if;
      end if;

      --写下架明细
      PKOBJ_ODATA.P_O_WriteOutStockItem(strEnterPriseNo,
                                        curOutstockDirect.Warehouse_No,
                                        v_OutstockNo,
                                        v_strUserID,
                                        curOutstockDirect.Direct_Serial,
                                        curOutstockDirect.Operate_Date,
                                        curOutstockDirect.pick_type,
                                        strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        return;
      end if;
      strCurr_ContainerNo := curOutstockDirect.S_CONTAINER_NO;
      strCurr_ArticleNo   := curOutstockDirect.ARTICLE_NO;
      strCurr_CellNo      := curOutstockDirect.S_CELL_NO;
    end loop;

    --更新下架指示
    pkobj_odata.P_O_UpdatedOmOutStockDirect(strEnterPriseNo,
                                            v_warehouse_No,
                                            v_OutstockNo,
                                            v_strUserID,
                                            strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      return;
    end if;

    --写标签信息
    P_WriteLabelInfo(strEnterPriseNo,
                     v_warehouse_No,
                     v_Exp_Type,
                     v_OwnerNo,
                     v_OutstockNo,
                     strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      return;
    end if;

    --Modify BY QZH AT 2016-5-24 PC前台发单
    if v_TaskGetType = '0' then
      --写打印任务
      P_WritePrintJob(strEnterPriseNo,
                      v_warehouse_No,
                      v_OutstockNo,
                      v_Print_Type,
                      v_strUserID,
                      strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        return;
      end if;
    end if;

    if v_PrintPaperType = '1' then
      --写表单打印任务
      --写打印任务
      P_WritePrintJob_Paper(strEnterPriseNo,
                            v_warehouse_No,
                            v_OutstockNo,
                            v_Dock_No,
                            v_strUserID,
                            strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        return;
      end if;
    end if;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_Hm_by_Area;

  --写标签信息
  /*******************************************************************************************
   quzhhui
   2013.12.12
   --写标签信息
  *******************************************************************************************/
  procedure P_WriteLabelInfo(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                             strWarehouse_No in odata_outstock_m.warehouse_no%type,
                             v_strExpType    in odata_exp_m.exp_type%type,
                             strOwnerNo      in odata_outstock_m.owner_no%type,
                             strOutStockNo   in odata_outstock_m.outstock_no%type,
                             strOutMsg       out varchar2) is
    v_strUserID       odata_outstock_m.rgst_name%type;
    v_strOperateType  odata_outstock_m.operate_type%type;
    v_strSourceType   odata_outstock_m.source_type%type;
    v_strPickType     odata_outstock_m.pick_type%type;
    v_strTaskType     odata_outstock_m.task_type%type;
    v_strPrintType    odata_outstock_m.print_type%type;
    v_strOutstockType odata_outstock_m.outstock_type%type;
  begin
    begin
      select oom.operate_type,
             oom.source_type,
             oom.pick_type,
             oom.task_type,
             oom.print_type,
             oom.outstock_type,
             oom.rgst_name
        into v_strOperateType,
             v_strSourceType,
             v_strPickType,
             v_strTaskType,
             v_strPrintType,
             v_strOutstockType,
             v_strUserID
        from odata_outstock_m oom
       where oom.enterprise_no = strEnterPriseNo
         and oom.warehouse_no = strwarehouse_no
         and oom.outstock_no = strOutStockNo;

    exception
      when others then
        strOutMsg := 'N|[E22116]';
        return;
    end;
    case v_strTaskType
      when CONST_REPORTID.PrintSerialLabel then
        --0流水标签
        --流水标签
        if v_strOutstockType = Const_DEFINE.COutStockType_OmOutstock then
          --出货
          PKLG_Tasklabel.P_O_WriteLabelSerial(strEnterpriseNo,
                                              strWarehouse_No,
                                              strOwnerNo,
                                              v_strExpType,
                                              strOutStockNo,
                                              v_strOperateType,
                                              v_strSourceType,
                                              v_strPickType,
                                              v_strTaskType,
                                              v_strPrintType,
                                              v_strOutstockType,
                                              v_strUserID,
                                              strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        end if;
        if v_strOutstockType = Const_DEFINE.COutStockType_Replenishment then
          --出货量补货

          PKLG_Tasklabel.P_H_WriteLabelSerial(strEnterpriseNo,
                                              strWarehouse_No,
                                              strOwnerNo,
                                              strOutStockNo,
                                              v_strOperateType,
                                              v_strSourceType,
                                              v_strPickType,
                                              v_strTaskType,
                                              v_strPrintType,
                                              v_strOutstockType,
                                              v_strUserID,
                                              strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        end if;
      when CONST_REPORTID.PrintTaskLabel then
        --任务标签
        if v_strOutstockType = Const_DEFINE.COutStockType_OmOutstock then
          --出货
          PKLG_Tasklabel.P_O_WriteLabelTask(strEnterpriseNo,
                                            strWarehouse_No,
                                            strOwnerNo,
                                            v_strExpType,
                                            strOutStockNo,
                                            v_strOperateType,
                                            v_strSourceType,
                                            v_strPickType,
                                            v_strTaskType,
                                            v_strPrintType,
                                            v_strOutstockType,
                                            v_strUserID,
                                            strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        end if;
        if v_strOutstockType = Const_DEFINE.COutStockType_Replenishment then
          --出货量补货
          PKLG_Tasklabel.P_H_WriteLabelTask(strEnterpriseNo,
                                            strWarehouse_No,
                                            strOwnerNo,
                                            strOutStockNo,
                                            v_strOperateType,
                                            v_strSourceType,
                                            v_strPickType,
                                            v_strTaskType,
                                            v_strPrintType,
                                            v_strOutstockType,
                                            v_strUserID,
                                            strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        end if;
        if v_strOutstockType = Const_DEFINE.COutStockType_SafeVolume or
           v_strOutstockType = Const_DEFINE.COutStockType_Artificially then
          --安全量补货
          PKLG_Tasklabel.P_H_WriteLabelTask(strEnterpriseNo,
                                            strWarehouse_No,
                                            strOwnerNo,
                                            strOutStockNo,
                                            v_strOperateType,
                                            v_strSourceType,
                                            v_strPickType,
                                            v_strTaskType,
                                            v_strPrintType,
                                            v_strOutstockType,
                                            v_strUserID,
                                            strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        end if;
      else
        strOutMsg := 'Y';
    end case;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_WriteLabelInfo;

  --写打印任务
  procedure P_WritePrintJob(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                            strWarehouse_No in odata_outstock_m.warehouse_no%type,
                            strOutStockNo   in odata_outstock_m.outstock_no%type,
                            strPrintJobType in odata_outstock_m.task_type%type,
                            strUserId       in Odata_Outstock_m.rgst_name%type,
                            strOutMsg       out varchar2) is
    v_DockNo odata_outstock_m.dock_no%type;
  begin

    select m.dock_no
      into v_DockNo
      from odata_outstock_m m
     where m.warehouse_no = strWarehouse_No
       and m.enterprise_no = strEnterpriseNo
       and m.outstock_no = strOutStockNo;

    P_WritePrintJob_Control(strEnterpriseNo,
                            strWarehouse_No,
                            strOutStockNo,
                            strPrintJobType,
                            strUserId,
                            v_DockNo,
                            strOutMsg);
    return;
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_WritePrintJob;

  --写打印任务
  /*打印入口2 Add by sl*/
  procedure P_WritePrintJob2(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                             strWarehouse_No in odata_outstock_m.warehouse_no%type,
                             strOutStockNo   in odata_outstock_m.outstock_no%type,
                             strPrintJobType in odata_outstock_m.task_type%type,
                             strUserId       in Odata_Outstock_m.rgst_name%type,
                             strdockno       in Odata_Outstock_m.Dock_No%type,
                             strOutMsg       out varchar2) is
    v_DockNo odata_outstock_m.dock_no%type;
  BEGIN
    --如果没传码头号，则取下架单头档的码头号，
    IF (strdockno IS NULL OR strdockno = 'N') THEN
      select m.dock_no
        into v_DockNo
        from odata_outstock_m m
       where m.warehouse_no = strWarehouse_No
         and m.enterprise_no = strEnterpriseNo
         and m.outstock_no = strOutStockNo;
    ELSE
      v_DockNo := strdockno;
    END IF;

    P_WritePrintJob_Control(strEnterpriseNo,
                            strWarehouse_No,
                            strOutStockNo,
                            strPrintJobType,
                            strUserId,
                            v_DockNo,
                            strOutMsg);
    return;
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_WritePrintJob2;

  /*打印方法统一控制层 Add by sl*/
  procedure P_WritePrintJob_Control(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                                    strWarehouse_No in odata_outstock_m.warehouse_no%type,
                                    strOutStockNo   in odata_outstock_m.outstock_no%type,
                                    strPrintJobType in odata_outstock_m.task_type%type,
                                    strUserId       in Odata_Outstock_m.rgst_name%type,
                                    strdockno       in Odata_Outstock_m.Dock_No%type,
                                    strOutMsg       out varchar2) is
  BEGIN
    case strPrintJobType
      when CONST_REPORTID.Print_MD then
        P_WritePrintJob_LabelMD(strEnterpriseNo,
                                strWarehouse_No,
                                strOutStockNo,
                                strdockno,
                                strUserId,
                                strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
      when CONST_REPORTID.Print_M then
        P_WritePrintJob_LabelM(strEnterpriseNo,
                               strWarehouse_No,
                               strOutStockNo,
                               strdockno,
                               strUserId,
                               strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
      when CONST_REPORTID.Print_D then
        P_WritePrintJob_LabelD(strEnterpriseNo,
                               strWarehouse_No,
                               strOutStockNo,
                               strdockno,
                               strUserId,
                               strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
      when CONST_REPORTID.Print_Report then
        P_WritePrintJob_Paper(strEnterpriseNo,
                              strWarehouse_No,
                              strOutStockNo,
                              strdockno,
                              strUserId,
                              strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
      when CONST_REPORTID.Print_M_Report then
        P_WritePrintJob_LabelM(strEnterpriseNo,
                               strWarehouse_No,
                               strOutStockNo,
                               strdockno,
                               strUserId,
                               strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
        P_WritePrintJob_Paper(strEnterpriseNo,
                              strWarehouse_No,
                              strOutStockNo,
                              strdockno,
                              strUserId,
                              strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
      when CONST_REPORTID.Print_D_Report then
        P_WritePrintJob_LabelD(strEnterpriseNo,
                               strWarehouse_No,
                               strOutStockNo,
                               strdockno,
                               strUserId,
                               strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
        P_WritePrintJob_Paper(strEnterpriseNo,
                              strWarehouse_No,
                              strOutStockNo,
                              strdockno,
                              strUserId,
                              strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
      when CONST_REPORTID.Print_MD_Report then
        P_WritePrintJob_LabelMD(strEnterpriseNo,
                                strWarehouse_No,
                                strOutStockNo,
                                strdockno,
                                strUserId,
                                strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
        P_WritePrintJob_Paper(strEnterpriseNo,
                              strWarehouse_No,
                              strOutStockNo,
                              strdockno,
                              strUserId,
                              strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
    end case;
    return;
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_WritePrintJob_Control;

  /*******************************************************************************8
  功能说明： 写拣货、补货表单打印任务；
           规则、1一张下架单一个打印任务
           2、根据下架单号写JOB_PRIINT_M
   根据配置写打印拣货单任务 huangb 20160621
  *******************************************************************************/
  procedure P_WritePrintJob_Paper(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                                  strWarehouse_No in odata_outstock_m.warehouse_no%type,
                                  strOutstockNo   in odata_outstock_m.outstock_no%type,
                                  strDockNo       in odata_outstock_m.dock_no%type,
                                  strUserId       in Odata_Outstock_m.rgst_name%type,
                                  strOutMsg       out varchar2) is

    v_PrintJobNo   job_printtask_m.task_no%type := 'N';
    v_Outstocktype odata_outstock_m.outstock_type%type;
    v_ReportID     job_printtask_m.report_id%type := 'N';
    v_PrintGroupNo job_printtask_m.printer_group_no%type;

    --以下参数为通过配置写打印报表的一些参数 huangb 20160621
    v_ReportPaperType pntset_module_report.paper_type%type := CONST_DOCUMENTTYPE.ODATAHO; --单据类型 例如'HO' := 'IP' := 'SS'等wms内部产生的单据类型，可为标签

  begin
    begin
      select m.outstock_type
        into v_Outstocktype
        from odata_outstock_m m
       where m.warehouse_no = strWarehouse_No
         and m.enterprise_no = strEnterpriseNo
         and m.outstock_no = strOutstockNo;
    exception
      when no_data_found then
        strOutMsg := 'N|[E22116]';
        return;
    end;

    if v_Outstocktype = const_define.COutStockType_OmOutstock then
      v_ReportPaperType := CONST_DOCUMENTTYPE.ODATAHO;
    else
      v_ReportPaperType := CONST_DOCUMENTTYPE.MDATAHS;
    end if;

    PKLG_WMS_Public.p_GetReportId(strEnterPriseNo, --企业号
                                  strWarehouse_No, --仓别号
                                  v_ReportPaperType, --单据类型 参考包CONST_REPORT_TYPE
                                  CREPORT_TYPE.TYPE_L, --报表类型 L:表单；M:标签头档；D:标签明细;WAY-面单;INV-发票;BOX-装箱清
                                  strOutstockNo, --源单号
                                  --返回参数
                                  v_ReportID, --返回报表ID
                                  strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      return;
    end if;

    /*if v_Outstocktype = const_define.COutStockType_OmOutstock then
      v_ReportID := const_reportid.L_CustPick;
    else
      v_ReportID := const_reportid.L_HMTask_C;
    end if;*/

    PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                               strWarehouse_No,
                               CONST_DOCUMENTTYPE.PRINTPT,
                               v_PrintJobNo,
                               strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    --根据码头获取打印机组
    PKLG_WMS_Public.GetPrintGroupByDockNo(strEnterpriseNo,
                                          strWarehouse_No,
                                          strDockNo,
                                          v_PrintGroupNo,
                                          strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    INSERT INTO JOB_PRINTTASK_M
      (enterprise_no,
       Warehouse_No,
       TASK_NO,
       SOURCE_NO,
       BACK_FLAG,
       TASK_TYPE,
       REPRINT_FLAG,
       REPORT_ID,
       PRINTER_GROUP_NO,
       OPERATE_DATE,
       RGST_NAME,
       RGST_DATE)
    values
      (strEnterpriseNo,
       strWarehouse_No,
       v_PrintJobNo,
       strOutstockNo,
       '0',
       'L',
       '0',
       v_ReportID,
       v_PrintGroupNo,
       trunc(sysdate),
       strUserId,
       sysdate);

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_WritePrintJob_Paper;

  /*******************************************************************************8
  功能说明： 写打印面单
           规则、1一张订单一个打印任务
           2、根据下架单号写JOB_PRIINT_M
  新增打印顺序 huangb 20160705
  *******************************************************************************/
  procedure P_WritePrintJob_WayBill(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                                    strWarehouse_No in odata_outstock_m.warehouse_no%type,
                                    strOutstockNo   in odata_outstock_m.outstock_no%type,
                                    strDockNo       in odata_outstock_m.dock_no%type,
                                    strUserId       in Odata_Outstock_m.rgst_name%type,
                                    strOutMsg       out varchar2) is
    v_Count        number := 0;
    v_PrintJobNo   job_printtask_m.task_no%type := 'N';
    v_Outstocktype odata_outstock_m.outstock_type%type;
    v_PickType     odata_outstock_m.pick_type%type;
    
  begin
    begin
      select m.outstock_type, m.pick_type
        into v_Outstocktype, v_PickType
        from odata_outstock_m m
       where m.warehouse_no = strWarehouse_No
         and m.enterprise_no = strEnterpriseNo
         and m.outstock_no = strOutstockNo;
    exception
      when no_data_found then
        strOutMsg := 'N|[E22116]';
        return;
    end;

    --不是出货
    if v_Outstocktype <> const_define.COutStockType_OmOutstock then
      strOutMsg := 'Y|';
      return;
    end if;

    for GetOutstock in (select m.exp_no,
                               m.waybill_print_status as Print_WayBillCount,
                               min(cdc.pick_order),
                               min(d.s_cell_no),
                               min(d.dps_cell_no)
                          from odata_exp_m      m,
                               odata_outstock_d d,
                               cdef_defcell     cdc
                              
                         where m.exp_type = d.exp_type
                           and m.exp_no = d.exp_no
                           and m.enterprise_no = d.enterprise_no
                           and m.warehouse_no = d.warehouse_no
                           and cdc.cell_no = d.s_cell_no
                           and cdc.warehouse_no = d.warehouse_no
                           and cdc.enterprise_no = d.enterprise_no
                           and d.outstock_no = strOutstockNo
                           and d.enterprise_no = strEnterpriseNo
                           and d.warehouse_no = strWarehouse_No                       
                         group by m.exp_no, m.waybill_print_status
                         order by case v_PickType
                                    when '0' then
                                     cast(min(cdc.pick_order) as varchar2(20))
                                    when '1' then
                                     min(d.dps_cell_no)
                                    when '2' then
                                     cast(min(cdc.pick_order) as varchar2(20))
                                  end,
                                  min(d.s_cell_no),
                                  min(d.dps_cell_no)) loop

      v_Count := v_Count + 1;
      if GetOutstock.print_waybillcount = '0' then
        v_PrintJobNo := 'N';       
        PKLG_WMS_Public.p_Insert_SpecialReportTask(strEnterPriseNo, --企业号
                                                   strWarehouse_No, --仓别号
                                                   CREPORT_TYPE.TYPE_WAY, --报表类型 WAY-面单;INV-发票;BOX-装箱清
                                                   GetOutstock.exp_no, --源单号
                                                   strDockNo, --码头或工作站号
                                                   '0', --补印标识
                                                   strUserId, --操作人员
                                                   --返回参数
                                                   v_PrintJobNo, --打印任务单号 如外部生成 则传外部生成打印任务号,否则传'N'
                                                   strOutMsg);
        if instr(strOutMsg, 'N', 1, 1) = 1 then
          return;
        end if;
      end if;
    end loop;
    if v_Count <= 0 then
      strOutMsg := 'N|打印面单下架单[' || strOutstockNo || ']没有订单信息';
      return;
    end if;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_WritePrintJob_WayBill;

  /*******************************************************************************8
  功能说明： 写打印发票
           规则、1一张订单一个打印任务
           2、根据下架单号写JOB_PRIINT_M
  *******************************************************************************/
  procedure P_WritePrintJob_Invoice(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                                    strWarehouse_No in odata_outstock_m.warehouse_no%type,
                                    strOutstockNo   in odata_outstock_m.outstock_no%type,
                                    strDockNo       in odata_outstock_m.dock_no%type,
                                    strUserId       in Odata_Outstock_m.rgst_name%type,
                                    strOutMsg       out varchar2) is
    v_Count        number := 0;
    v_PrintJobNo   job_printtask_m.task_no%type := 'N';
    v_Outstocktype odata_outstock_m.outstock_type%type;
    v_ReportID     job_printtask_m.report_id%type := 'N';
    v_PickType     odata_outstock_m.pick_type%type;
  begin
    begin
      select m.outstock_type, m.pick_type
        into v_Outstocktype, v_PickType
        from odata_outstock_m m
       where m.warehouse_no = strWarehouse_No
         and m.enterprise_no = strEnterpriseNo
         and m.outstock_no = strOutstockNo;
    exception
      when no_data_found then
        strOutMsg := 'N|[E22116]';
        return;
    end;

    --不是出货
    if v_Outstocktype <> const_define.COutStockType_OmOutstock then
      strOutMsg := 'Y|';
      return;
    end if;

    for t in (select m.exp_no,
                     m.print_bill_flag Print_InVoice_Flag,
                     m.ENVOICE_PRINT_STATUS Print_InVoiceCount,
                     min(cdc.pick_order),
                     min(d.s_cell_no),
                     min(d.dps_cell_no)
                from odata_exp_m m, odata_outstock_d d, cdef_defcell cdc
               where m.exp_type = d.exp_type
                 and m.exp_no = d.exp_no
                 and d.outstock_no = strOutstockNo
                 and m.enterprise_no = d.enterprise_no
                 and m.warehouse_no = d.warehouse_no
                 and cdc.cell_no = d.s_cell_no
                 and cdc.warehouse_no = d.warehouse_no
                 and cdc.enterprise_no = d.enterprise_no
                 and d.enterprise_no = strEnterpriseNo
                 and d.warehouse_no = strWarehouse_No
               group by m.exp_no, m.print_bill_flag, m.ENVOICE_PRINT_STATUS
               order by case v_PickType
                          when '0' then
                           cast(min(cdc.pick_order) as varchar2(20))
                          when '1' then
                           min(d.dps_cell_no)
                          when '2' then
                           cast(min(cdc.pick_order) as varchar2(20))
                        end,
                        min(d.s_cell_no),
                        min(d.dps_cell_no)) loop

      v_Count := v_Count + 1;
      --未打过，且需要打印发票
      if t.print_invoicecount = '0' and t.print_invoice_flag = '1' then
        v_PrintJobNo := 'N';
        v_ReportID   := 'N';

        PKLG_WMS_Public.p_Insert_SpecialReportTask(strEnterPriseNo, --企业号
                                                   strWarehouse_No, --仓别号
                                                   CREPORT_TYPE.TYPE_INV, --报表类型 WAY-面单;INV-发票;BOX-装箱清
                                                   t.exp_no, --源单号
                                                   strDockNo, --码头或工作站号
                                                   '0', --补印标识
                                                   strUserId, --操作人员
                                                   --返回参数
                                                   v_PrintJobNo, --打印任务单号 如外部生成 则传外部生成打印任务号,否则传'N'
                                                   strOutMsg);
        if instr(strOutMsg, 'N', 1, 1) = 1 then
          return;
        end if;
      end if;
    end loop;

    if v_Count <= 0 then
      strOutMsg := 'N|打印面单下架单[' || strOutstockNo || ']没有订单信息';
      return;
    end if;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_WritePrintJob_Invoice;

  /*******************************************************************************8
  功能说明： 写打印装箱清单
           规则、1一张订单一个打印任务
           2、根据下架单号写JOB_PRIINT_M
  *******************************************************************************/
  procedure P_WritePrintJob_BoxList(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                                    strWarehouse_No in odata_outstock_m.warehouse_no%type,
                                    strOutstockNo   in odata_outstock_m.outstock_no%type,
                                    strDockNo       in odata_outstock_m.dock_no%type,
                                    strUserId       in Odata_Outstock_m.rgst_name%type,
                                    strOutMsg       out varchar2) is
    v_Count        number := 0;
    v_PrintJobNo   job_printtask_m.task_no%type := 'N';
    v_Outstocktype odata_outstock_m.outstock_type%type;
    v_ReportID     job_printtask_m.report_id%type := 'N';
    v_PickType     odata_outstock_m.pick_type%type;
  begin
    begin
      select m.outstock_type, m.pick_type
        into v_Outstocktype, v_PickType
        from odata_outstock_m m
       where m.warehouse_no = strWarehouse_No
         and m.enterprise_no = strEnterpriseNo
         and m.outstock_no = strOutstockNo;
    exception
      when no_data_found then
        strOutMsg := 'N|[E22116]';
        return;
    end;

    --不是出货
    if v_Outstocktype <> const_define.COutStockType_OmOutstock then
      strOutMsg := 'Y|';
      return;
    end if;

    for t in (select m.exp_no,
                     m.PACKLIST_PRINT_STATUS Print_PackListCount,
                     min(cdc.pick_order),
                     min(d.s_cell_no),
                     min(d.dps_cell_no)
                from odata_exp_m m, odata_outstock_d d, cdef_defcell cdc
               where m.exp_type = d.exp_type
                 and m.exp_no = d.exp_no
                 and d.outstock_no = strOutstockNo
                 and m.enterprise_no = d.enterprise_no
                 and m.warehouse_no = d.warehouse_no
                 and cdc.cell_no = d.s_cell_no
                 and cdc.warehouse_no = d.warehouse_no
                 and cdc.enterprise_no = d.enterprise_no
                 and d.enterprise_no = strEnterpriseNo
                 and d.warehouse_no = strWarehouse_No
               group by m.exp_no, m.PACKLIST_PRINT_STATUS
               order by case v_PickType
                          when '0' then
                           cast(min(cdc.pick_order) as varchar2(20))
                          when '1' then
                           min(d.dps_cell_no)
                          when '2' then
                           cast(min(cdc.pick_order) as varchar2(20))
                        end,
                        min(d.s_cell_no),
                        min(d.dps_cell_no)) loop
      v_Count := v_Count + 1;
      --未打印过箱清单
      if t.print_packlistcount = '0' then
        v_PrintJobNo := 'N';
        v_ReportID   := 'N';

        PKLG_WMS_Public.p_Insert_SpecialReportTask(strEnterPriseNo, --企业号
                                                   strWarehouse_No, --仓别号
                                                   CREPORT_TYPE.TYPE_BOX, --报表类型 WAY-面单;INV-发票;BOX-装箱清
                                                   t.exp_no, --源单号
                                                   strDockNo, --码头或工作站号
                                                   '0', --补印标识
                                                   strUserId, --操作人员
                                                   --返回参数
                                                   v_PrintJobNo, --打印任务单号 如外部生成 则传外部生成打印任务号,否则传'N'
                                                   strOutMsg);
        if instr(strOutMsg, 'N', 1, 1) = 1 then
          return;
        end if;
      end if;
    end loop;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_WritePrintJob_BoxList;

  /*************************************************************************************************8
   功能说明：只打印拣货标签头的打印任务；
            规则：1、一拣货单一打印任务；
                  2、根据拣货单写对应的JOB_PRINT_M
   根据配置写打印标签头档任务 huangb 20160621
  ****************************************************************************************************/
  procedure P_WritePrintJOb_LabelM(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                                   strWarehouse_No in odata_outstock_m.warehouse_no%type,
                                   strOutstockNo   in odata_outstock_m.outstock_no%type,
                                   strDockNo       in odata_outstock_m.dock_no%type,
                                   strUserId       in Odata_Outstock_m.rgst_name%type,
                                   strOutMsg       out varchar2) is
    iCount         integer := 0;
    v_PrintJobNo   job_printtask_m.task_no%type := 'N';
    v_ReportID     job_printtask_m.report_id%type := 'N';
    v_PrintGroupNo job_printtask_m.printer_group_no%type;
    v_strExpType   odata_outstock_d.exp_type%type;
    v_strOwnerNo   odata_outstock_d.owner_no%type; --
    --v_strDeliverObjLevel odata_locate_batch.deliver_obj_level%type; --0:按客户；1：按单据
    v_Outstock_Type odata_outstock_m.outstock_type%type; --huangb 20160621
    v_Pick_Type     odata_outstock_m.pick_type%type; --huangb 20160621

    --以下参数为通过配置写打印报表的一些参数 huangb 20160621
    v_ReportPaperType pntset_module_report.paper_type%type := CONST_DOCUMENTTYPE.ODATAHO; --单据类型 例如'HO' := 'IP' := 'SS'等wms内部产生的单据类型，可为标签

  begin
    strOutMsg := 'N|[P_WritePrintJOb_LabelM]';

    -----------------------------
    begin
      select ood.exp_type, ood.owner_no, oom.outstock_type, oom.pick_type
        into v_strExpType, v_strOwnerNo, v_Outstock_Type, v_Pick_Type
        from odata_outstock_m oom, odata_outstock_d ood
       where oom.enterprise_no = ood.enterprise_no
         and oom.warehouse_no = ood.warehouse_no
         and oom.outstock_no = ood.outstock_no
         and oom.warehouse_no = strwarehouse_no
         and oom.enterprise_no = strEnterPriseNo
         and oom.outstock_no = strOutStockNo
         and rownum = 1;
    exception
      when no_data_found then
        return;
    end;

    /*PKLG_OLOCATE.GetDeliverObjLevel(strEnterpriseNo,
                                    strWareHouse_No,
                                    v_strOwnerNo,
                                    v_strExpType,
                                    v_strDeliverObjLevel,
                                    strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      strOutMsg := 'N|[E22105]';
      return;
    end if;*/
    for curLabelInfo in (select distinct B.ENTERPRISE_NO,
                                         oom.operate_type,
                                         B.WAREHOUSE_NO,
                                         B.REPORT_ID,
                                         B.SOURCE_NO,
                                         B.CONTAINER_TYPE,
                                         B.USE_TYPE
                           FROM STOCK_LABEL_M B, odata_outstock_m oom
                          WHERE B.WAREHOUSE_NO = strWarehouse_No
                            and b.enterprise_no = strEnterpriseNo
                            and b.enterprise_no = oom.enterprise_no
                            and b.warehouse_no = oom.warehouse_no
                            AND B.SOURCE_NO = strOutstockNo

                               --默认状态-拣货发单
                            AND (B.STATUS = CLabelStatus.PICK_HAND_OUT OR
                                B.STATUS = CLabelStatus.MOVE_HAND_OUT)
                            and b.source_no = oom.outstock_no

                          ORDER BY b.enterprise_no,
                                   B.Warehouse_No,
                                   B.SOURCE_NO,
                                   B.USE_TYPE,
                                   B.CONTAINER_TYPE,
                                   REPORT_ID) loop
      iCount := iCount + 1;

      if v_Outstock_Type = const_define.COutStockType_OmOutstock then
        v_ReportPaperType := CONST_DOCUMENTTYPE.ODATAHO;
      else
        v_ReportPaperType := CONST_DOCUMENTTYPE.MDATAHS;
      end if;

      PKLG_WMS_Public.p_GetReportId(strEnterPriseNo, --企业号
                                    strWarehouse_No, --仓别号
                                    v_ReportPaperType, --单据类型 参考包CONST_REPORT_TYPE
                                    CREPORT_TYPE.TYPE_M, --报表类型 L:表单；M:标签头档；D:标签明细;WAY-面单;INV-发票;BOX-装箱清
                                    strOutstockNo, --源单号
                                    --返回参数
                                    v_ReportID, --返回报表ID
                                    strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        return;
      end if;

      PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                 strWarehouse_No,
                                 CONST_DOCUMENTTYPE.PRINTPT,
                                 v_PrintJobNo,
                                 strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      /*if curLabelInfo.Use_Type = CLabelUseType.MOVE_STOCK_LABEL then
        case curLabelInfo.Container_Type
          when 'B' then
            v_ReportID := CONST_REPORTID.HmPickLabel_B_Head;
          when 'C' then
            v_ReportID := CONST_REPORTID.B_HMTask_C;
          else
            v_ReportID := CONST_REPORTID.B_HMTask_C;
        end case;
      else
        if curLabelInfo.Use_Type = CLabelUseType.CUSTOMER_LABEL then
          if v_strDeliverObjLevel = '1' then
            --按单
            if curLabelInfo.operate_type = 'P' then
              v_ReportID := CONST_REPORTID.B_ExpPickTaskLabel_PM;
            end if;
            if curLabelInfo.operate_type = 'C' then
              v_ReportID := CONST_REPORTID.B_CustPickTaskLabel_CM;
            end if;
            if curLabelInfo.operate_type = 'B' then
              v_ReportID := CONST_REPORTID.B_CustPickTaskLabel_BM;
            end if;
          else
            --按客户
            if curLabelInfo.operate_type = 'P' then
              v_ReportID := CONST_REPORTID.B_CustPickTaskLabel_PM;
            end if;
            if curLabelInfo.operate_type = 'C' then
              v_ReportID := CONST_REPORTID.B_CustPickTaskLabel_CM;
            end if;
            if curLabelInfo.operate_type = 'B' then
              v_ReportID := CONST_REPORTID.B_CustPickTaskLabel_BM;
            end if;
          end if;
        else
          case curLabelInfo.Container_Type
            when 'B' then
              v_ReportID := CONST_REPORTID.B_DividePickTaskLabel_BM;
            when 'C' then
              v_ReportID := CONST_REPORTID.B_DividePickTaskLabel_C;
            else
              v_ReportID := CONST_REPORTID.B_DividePickTaskLabel_MM;
          end case;
        end if;
      end if;*/
      --根据码头获取打印机组
      PKLG_WMS_Public.GetPrintGroupByDockNo(strEnterpriseNo,
                                            strWarehouse_No,
                                            strDockNo,
                                            v_PrintGroupNo,
                                            strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
      INSERT INTO JOB_PRINTTASK_M
        (enterprise_no,
         Warehouse_No,
         TASK_NO,
         SOURCE_NO,
         BACK_FLAG,
         TASK_TYPE,
         REPRINT_FLAG,
         REPORT_ID,
         PRINTER_GROUP_NO,
         OPERATE_DATE,
         RGST_NAME,
         RGST_DATE)
      values
        (strEnterpriseNo,
         strWarehouse_No,
         v_PrintJobNo,
         strOutstockNo,
         '0',
         'B',
         '0',
         v_ReportID,
         v_PrintGroupNo,
         trunc(sysdate),
         strUserId,
         sysdate);
    end loop;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_WritePrintJOb_LabelM;

  /***************************************************************************************8
   功能说明：写打印标签明细的打印任务；
             规则：1、一拣货任务会产生一个打印任务号；
                   2、将拣货单号和报表ID写入对应的JOB_PRINT_M表
                   3、将拣货单下的内部标签号写入对应个JOB_PRINT_D表
   根据配置写打印标签明细任务 huangb 20160621
  ****************************************************************************************/
  procedure P_WritePrintJob_LabelD(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                                   strWarehouse_No in odata_outstock_m.warehouse_no%type,
                                   strOutstockNo   in odata_outstock_m.outstock_no%type,
                                   strDockNo       in odata_outstock_m.dock_no%type,
                                   strUserId       in Odata_Outstock_m.rgst_name%type,
                                   strOutMsg       out varchar2) is
    iCount         integer := 0;
    v_PrintJobNo   job_printtask_m.task_no%type := 'N';
    v_ReportID     job_printtask_m.report_id%type := 'N';
    v_PrintGroupNo job_printtask_m.printer_group_no%type;
    v_strExpType   odata_outstock_d.exp_type%type;
    v_strOwnerNo   odata_outstock_d.owner_no%type; --
    --v_strDeliverObjLevel odata_locate_batch.deliver_obj_level%type; --0:按客户；1：按单据
    v_Outstock_Type odata_outstock_m.outstock_type%type; --huangb 20160621
    v_Pick_Type     odata_outstock_m.pick_type%type; --huangb 20160621

    --以下参数为通过配置写打印报表的一些参数 huangb 20160621
    v_ReportPaperType pntset_module_report.paper_type%type := CONST_DOCUMENTTYPE.ODATAHO; --单据类型 例如'HO' := 'IP' := 'SS'等wms内部产生的单据类型，可为标签

  begin
    strOutMsg := 'N|[P_WritePrintJob_LabelD]';

    begin
      select ood.exp_type, ood.owner_no, oom.outstock_type, oom.pick_type
        into v_strExpType, v_strOwnerNo, v_Outstock_Type, v_Pick_Type
        from odata_outstock_m oom, odata_outstock_d ood
       where oom.enterprise_no = ood.enterprise_no
         and oom.warehouse_no = ood.warehouse_no
         and oom.outstock_no = ood.outstock_no
         and oom.warehouse_no = strwarehouse_no
         and oom.enterprise_no = strEnterPriseNo
         and oom.outstock_no = strOutStockNo
         and rownum = 1;
    exception
      when no_data_found then
        return;
    end;

    /*PKLG_OLOCATE.GetDeliverObjLevel(strEnterpriseNo,
                                    strWareHouse_No,
                                    v_strOwnerNo,
                                    v_strExpType,
                                    v_strDeliverObjLevel,
                                    strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      strOutMsg := 'N|[E22105]';
      return;
    end if;*/
    for curLabelInfo in (select distinct B.ENTERPRISE_NO,
                                         oom.operate_type,
                                         B.WAREHOUSE_NO,
                                         B.REPORT_ID,
                                         B.SOURCE_NO,
                                         B.CONTAINER_TYPE,
                                         B.USE_TYPE,
                                         b.container_no,
                                         oom.task_type
                           FROM STOCK_LABEL_M B, odata_outstock_m oom
                          WHERE B.WAREHOUSE_NO = strWarehouse_No
                            and b.enterprise_no = strEnterpriseNo
                            and b.enterprise_no = oom.enterprise_no
                            and b.warehouse_no = oom.warehouse_no
                            AND B.SOURCE_NO = strOutstockNo
                               --默认状态-拣货发单
                            AND (B.STATUS = CLabelStatus.PICK_HAND_OUT OR
                                B.STATUS = CLabelStatus.MOVE_HAND_OUT)
                            and b.source_no = oom.outstock_no

                          ORDER BY b.enterprise_no,
                                   B.Warehouse_No,
                                   B.SOURCE_NO,
                                   B.USE_TYPE,
                                   REPORT_ID) loop
      iCount := iCount + 1;
      if iCount = 1 then
        PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                   strWarehouse_No,
                                   CONST_DOCUMENTTYPE.PRINTPT,
                                   v_PrintJobNo,
                                   strOutMsg);
        if strOutMsg <> 'Y' then
          return;
        end if;
      end if;

      if v_Outstock_Type = const_define.COutStockType_OmOutstock then
        v_ReportPaperType := CONST_DOCUMENTTYPE.ODATAHO;
      else
        v_ReportPaperType := CONST_DOCUMENTTYPE.MDATAHS;
      end if;

      PKLG_WMS_Public.p_GetReportId(strEnterPriseNo, --企业号
                                    strWarehouse_No, --仓别号
                                    v_ReportPaperType, --单据类型 参考包CONST_REPORT_TYPE
                                    CREPORT_TYPE.TYPE_D, --报表类型 L:表单；M:标签头档；D:标签明细;WAY-面单;INV-发票;BOX-装箱清
                                    strOutstockNo, --源单号
                                    --返回参数
                                    v_ReportID, --返回报表ID
                                    strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        return;
      end if;

      /*if curLabelInfo.Use_Type = CLabelUseType.MOVE_STOCK_LABEL then
        --移库任务
        if curLabelInfo.operate_type = 'B' then
          v_ReportID := CONST_REPORTID.B_HMTask_BD;
        end if;
        if curLabelInfo.operate_type = 'C' then
          v_ReportID := CONST_REPORTID.B_HMTask_CD;
        end if;
      else
        if curLabelInfo.Use_Type = CLabelUseType.CUSTOMER_LABEL then
          --拣货客户标签任务
          if v_strDeliverObjLevel = '1' then
            --按单
            if curLabelInfo.operate_type = 'P' then
              v_ReportID := CONST_REPORTID.B_ExpPickTaskLabel_PM;
            end if;
            if curLabelInfo.operate_type = 'C' then
              if curLabelInfo.task_type = '2' then
                v_ReportID := CONST_REPORTID.B_ExpPickTaskLabel_C;
              else
                v_ReportID := CONST_REPORTID.B_EXPPickSerialLabel_C;
              end if;
            end if;
            if curLabelInfo.operate_type = 'B' then
              v_ReportID := CONST_REPORTID.B_ExpPickTaskLabel_B;
            end if;
          else
            --按客户
            if curLabelInfo.operate_type = 'P' then
              v_ReportID := CONST_REPORTID.B_CustPickTaskLabel_PM;
            end if;
            if curLabelInfo.operate_type = 'C' then

              if curLabelInfo.task_type = '2' then
                v_ReportID := CONST_REPORTID.B_CustPickTaskLabel_C;
              else
                v_ReportID := CONST_REPORTID.B_CustPickSerialLabel_C;
              end if;
            end if;
            if curLabelInfo.operate_type = 'B' then
              v_ReportID := CONST_REPORTID.B_CustPickTaskLabel_B;
            end if;
          end if;
        else

          --拣货分播标签任务
          if curLabelInfo.operate_type = 'B' then
            v_ReportID := CONST_REPORTID.B_DividePickTaskLabel_B;
          end if;
          if curLabelInfo.operate_type = 'C' then
            v_ReportID := CONST_REPORTID.B_DividePickTaskLabel_C;
          else
            v_ReportID := curLabelInfo.Report_Id;
          end if;
        end if;
      end if;*/

      --根据码头获取打印机组
      PKLG_WMS_Public.GetPrintGroupByDockNo(strEnterpriseNo,
                                            strWarehouse_No,
                                            strDockNo,
                                            v_PrintGroupNo,
                                            strOutMsg);
      if strOutMsg <> 'Y' then
        return;
      end if;

      if iCount = 1 then
        INSERT INTO JOB_PRINTTASK_M
          (enterprise_no,
           Warehouse_No,
           TASK_NO,
           SOURCE_NO,
           BACK_FLAG,
           TASK_TYPE,
           REPRINT_FLAG,
           REPORT_ID,
           PRINTER_GROUP_NO,
           OPERATE_DATE,
           RGST_NAME,
           RGST_DATE)
        values
          (strEnterpriseNo,
           strWarehouse_No,
           v_PrintJobNo,
           strOutstockNo,
           '0',
           'B',
           '0',
           v_ReportID,
           v_PrintGroupNo,
           trunc(sysdate),
           strUserId,
           sysdate);
      end if;

      --写打印任务明细
      insert into job_printtask_d
        (enterprise_no,
         warehouse_no,
         task_no,
         container_no,
         print_sn,
         print_qty)
      values
        (strEnterpriseNo,
         strWarehouse_No,
         v_PrintJobNo,
         curLabelInfo.container_no,
         iCount,
         1);
    end loop;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_WritePrintJob_LabelD;

  /***************************************************************************************8
   功能说明：打印任务单头和标签明细的打印任务；
             规则：1、会产生拣货单号和标签号的两个打印任务；
                  2、 产生拣货单号的打印任务同P_WritePrintJob_LabelM；
                  3、产生拣货标签明细的打印任务同P_WritePrintJob_LabelD

  ****************************************************************************************/
  procedure P_WritePrintJob_LabelMD(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                                    strWarehouse_No in odata_outstock_m.warehouse_no%type,
                                    strOutstockNo   in odata_outstock_m.outstock_no%type,
                                    strDockNo       in odata_outstock_m.dock_no%type,
                                    strUserId       in Odata_Outstock_m.rgst_name%type,
                                    strOutMsg       out varchar2) is

  begin
    strOutMsg := 'N|[P_WritePrintJob_LabelMD]';

    --写下架单头的打印任务
    P_WritePrintJOb_LabelM(strEnterpriseNo,
                           strWarehouse_No,
                           strOutstockNo,
                           strDockNo,
                           strUserId,
                           strOutMsg);
    if strOutMsg <> 'Y' then
      return;
    end if;

    --写下架标签的打印任务

    P_WritePrintJOb_LabelD(strEnterpriseNo,
                           strWarehouse_No,
                           strOutstockNo,
                           strDockNo,
                           strUserId,
                           strOutMsg);
    if strOutMsg <> 'Y' then
      return;
    end if;
  end P_WritePrintJob_LabelMD;
  --外部号转内部号
  procedure TransFixNoToSerialNo(strEnterpriseNo     in odata_outstock_m.enterprise_no%type,
                                 strWAREHOUSE_NO     in stock_label_m.warehouse_no%type,
                                 strLabel_No         in stock_label_m.label_no%type,
                                 strUserID           in stock_label_m.rgst_name%type,
                                 strUseType          in stock_label_m.use_type%type,
                                 strDeliverOBJ       in stock_label_m.deliver_obj%type,
                                 strContainer_Type   out stock_label_m.container_type%type,
                                 strContainer_No     out stock_label_m.container_no%type,
                                 strContainerNewFlag out integer,
                                 strOutMsg           out varchar2) is
    v_strContainerNo stock_label_m.container_no%type := 'N';
    v_strLabelNo     stock_label_m.label_no%type := 'N';
    v_SessionID      varchar2(100) := 'N';
  begin
    strOutMsg           := 'N|[TransFixNoToSerialNo]';
    strContainerNewFlag := 0;
    CheckContainerStatus(strEnterpriseNo,
                         strWAREHOUSE_NO,
                         strLabel_No,
                         strUserID,
                         strUseType,
                         strDeliverOBJ,
                         strContainer_Type,
                         strContainer_No,
                         strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    if substr(strOutMsg, 1, 1) = 'Y' and strContainer_Type <> 'N' then
      return;
    end if;

    if strContainer_Type = 'N' or strContainer_Type is null then
      PKLG_WMS_BASE.p_get_ContainerNoBase(strEnterpriseNo,
                                          strWAREHOUSE_NO,
                                          CLabelType.LABEL_TYPE_P,
                                          strUserID,
                                          'D',
                                          1,
                                          strUseType,
                                          null,
                                          v_strLabelNo,
                                          v_strContainerNo,
                                          v_SessionID,
                                          strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
      strContainer_No     := v_strContainerNo;
      strContainer_Type   := CLabelType.LABEL_TYPE_P;
      strContainerNewFlag := 1;
    end if;
    strOutMsg := 'Y|成功!';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end TransFixNoToSerialNo;

  --检查标签状态
  procedure CheckContainerStatus(strEnterpriseNo   in odata_outstock_m.enterprise_no%type,
                                 strWAREHOUSE_NO   in stock_label_m.warehouse_no%type,
                                 strLabel_No       in stock_label_m.label_no%type,
                                 strUserID         in stock_label_m.rgst_name%type,
                                 strUseType        in stock_label_m.use_type%type,
                                 strDeliverOBJ     in stock_label_m.deliver_obj%type,
                                 strContainer_Type out stock_label_m.container_type%type,
                                 strContainer_No   out stock_label_m.container_no%type,
                                 strOutMsg         out varchar2) is
    --v_Count                  integer:=0;
    v_ContainerNo   stock_label_m.container_no%type;
    v_ContainerType stock_label_m.container_type%type;
    v_UserType      stock_label_m.use_type%type;
    v_DeliverObj    stock_label_m.deliver_obj%type;
    v_Status        stock_label_m.status%type;
  begin

    begin
      select clm.container_no,
             clm.container_type,
             clm.use_type,
             clm.deliver_obj,
             clm.status
        into v_ContainerNo,
             v_ContainerType,
             v_UserType,
             v_DeliverObj,
             v_Status
        from stock_label_m clm
       where clm.label_no = strLabel_No
         and clm.warehouse_no = strWAREHOUSE_NO
         and clm.enterprise_no = strEnterpriseNo
         and clm.status not between
             CDestroyLabelStatusRange.DESTROY_BEGIN_STATUS and
             CDestroyLabelStatusRange.DESTROY_END_STATUS;
    exception
      when no_data_found then
        v_ContainerNo   := 'N';
        v_ContainerType := 'N';
    end;

    if v_ContainerNo = 'N' and v_ContainerType = 'N' then
      strOutMsg := 'Y|成功!';
      return;
    end if;

    if strUseType <> v_UserType then
      strOutMsg := 'N|[E22514]';
      return;
    end if;

    if v_UserType = CLabelUseType.CUSTOMER_LABEL then
      if v_DeliverObj <> strDeliverOBJ and v_DeliverObj <> 'N' then
        strOutMsg := 'N|[E22515]';
        return;
      end if;
      if v_Status <> CLabelStatus.PICK_END and
         v_Status <> CLabelStatus.NEW_LABEL_NO and
         v_Status <> CLabelStatus.RECEIVING then
        strOutMsg := 'N|[E22516]';
        return;
      end if;

      --配送对象不一样为新取板号，则更新配送对象
      if v_DeliverObj <> strDeliverOBJ or
         v_Status = CLabelStatus.NEW_LABEL_NO then
        UPDATE STOCK_LABEL_M
           SET DELIVER_OBJ = strDeliverOBJ,
               UPDT_DATE   = SYSDATE,
               UPDT_NAME   = strUserID,
               STATUS      = CLabelStatus.PICK_END
         WHERE LABEL_NO = strLabel_No
           and enterprise_no = strEnterpriseNo
           AND WAREHOUSE_NO = strWAREHOUSE_NO;

        if sql%rowcount <= 0 then
          strOutMsg := 'N|[E22116]';
          return;
        end if;
      end if;
    end if;

    strContainer_Type := v_ContainerType;
    strContainer_No   := v_ContainerNo;
    strOutMsg         := 'Y|成功！';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end CheckContainerStatus;
  /****************************************************************************************************
     quzhihui
     2013.11.25
     功能说明：更新下架单头档
  ******************************************************************************************************/
  procedure p_UpdtOutstockHeader(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                                 strWAREHOUSE_NO in odata_outstock_m.warehouse_no%type,
                                 strOutstockNo   in odata_outstock_m.outstock_no%type,
                                 strUserID       in odata_outstock_m.rgst_name%type,
                                 strOutMsg       out varchar2) is
    v_iCount integer := 0;
  begin
    strOutMsg := 'N|[p_UpdtOutstockHeader]';
    select count(1)
      into v_iCount
      from odata_outstock_d d
     where d.warehouse_no = strWAREHOUSE_NO
       and d.enterprise_no = strEnterpriseNo
       and d.outstock_no = strOutstockNo
       and d.status = '10';

    if v_iCount > 0 then
      strOutMsg := 'Y|成功';
      return;
    end if;

    update odata_outstock_m m
       set m.status = '13', m.updt_name = strUserID, m.updt_date = sysdate
     where m.warehouse_no = strWAREHOUSE_NO
       and m.enterprise_no = strEnterpriseNo
       and m.outstock_no = strOutstockNo;

    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E22302]';
      return;
    end if;
    strOutMsg := 'Y|成功';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_UpdtOutstockHeader;

  /****************************************************************************************************
   chensr
   2015.12.19
   添加临时表
  ******************************************************************************************************/
  procedure insert_tmp_locate_select(strTmpId            in odata_tmp_locate_select.tmp_id%type,
                                     strCurrEnterpriseNo in odata_tmp_locate_select.enterprise_no%type,
                                     strWareHouseNo      in odata_tmp_locate_select.warehouse_no%type,
                                     strOwnerNo          in odata_tmp_locate_select.owner_no%type,
                                     strCustNo           in varchar2,
                                     strLineNo           in odata_tmp_locate_select.line_no%type,
                                     strBatchNo          in odata_tmp_locate_select.batch_no%type,
                                     strExpNo            in odata_tmp_locate_select.exp_no%type,
                                     strVolume           in odata_tmp_locate_select.volume%type,
                                     strWeigth           in odata_tmp_locate_select.weight%type,
                                     strQbox             in odata_tmp_locate_select.qbox%type,
                                     flag                in varchar2,
                                     strResult           out varchar2) is

  begin
    strResult := 'Y';

    if flag = '1' then
      pkobj_odispatch.P_Insert_TmpLocateForExpNo(strTmpId,
                                                 strCurrEnterpriseNo,
                                                 strWareHouseNo,
                                                 strOwnerNo,
                                                 strLineNo,
                                                 strBatchNo,
                                                 strExpNo,
                                                 strVolume,
                                                 strWeigth,
                                                 strQbox,
                                                 strResult);
    end if;
    if flag = '0' then
      pkobj_odispatch.P_Insert_TmpLocateForCust(strTmpId,
                                                strCurrEnterpriseNo,
                                                strWareHouseNo,
                                                strOwnerNo,
                                                strLineNo,
                                                strBatchNo,
                                                strCustNo,
                                                strVolume,
                                                strWeigth,
                                                strQbox,
                                                strResult);
    end if;

  end insert_tmp_locate_select;

  /****************************************************************************************************
   chensr
   2015.12.19
   删除临时表
  ******************************************************************************************************/
  procedure delete_tmp_locate_select(strTmpId            in odata_tmp_locate_select.tmp_id%type,
                                     strCurrEnterpriseNo in odata_tmp_locate_select.enterprise_no%type,
                                     strWareHouseNo      in odata_tmp_locate_select.warehouse_no%type,
                                     strOwnerNo          in odata_tmp_locate_select.owner_no%type,
                                     strCustNo           in varchar2,
                                     strLineNo           in odata_tmp_locate_select.line_no%type,
                                     strBatchNo          in odata_tmp_locate_select.batch_no%type,
                                     strExpNo            in odata_tmp_locate_select.exp_no%type,
                                     flag                in varchar2,
                                     strResult           out varchar2) is

  begin
    strResult := 'Y';

    if flag = '1' then
      pkobj_odispatch.P_Delete_TmpLocateForExpNo(strTmpId,
                                                 strCurrEnterpriseNo,
                                                 strWareHouseNo,
                                                 strOwnerNo,
                                                 strLineNo,
                                                 strBatchNo,
                                                 strExpNo,
                                                 strResult);
    end if;
    if flag = '0' then
      pkobj_odispatch.P_Delete_TmpLocateForCust(strTmpId,
                                                strCurrEnterpriseNo,
                                                strWareHouseNo,
                                                strOwnerNo,
                                                strLineNo,
                                                strBatchNo,
                                                strCustNo,
                                                strResult);
    end if;

  end delete_tmp_locate_select;

  /*******************************************************************************************
   发单完成出货单据跟踪状态修改
   huangb 20160629
  *******************************************************************************************/
  procedure P_Send_ExpTrace(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                            strWarehouseNo  in odata_outstock_m.warehouse_no%type,
                            strOutStockNo   in odata_outstock_m.outstock_no%type,
                            strUserID       in odata_outstock_m.rgst_name%type, --操作人员
                            strOutMsg       out varchar2) is
  begin
    strOutMsg := 'N|P_Send_ExpTrace';

    --跟新出货单表跟踪状态为发单
    update odata_exp_m s
       set s.exp_status = COdataExpStatus.ExpTracAllSend,
           s.updt_name  = strUserID,
           s.updt_date  = sysdate
     where s.enterprise_no = strEnterPriseNo
       and s.warehouse_no = strWareHouseNo
       and s.exp_status < COdataExpStatus.ExpTracAllSend
       and exists (select 'X'
              from odata_outstock_d ood
             where s.enterprise_no = ood.enterprise_no
               and s.warehouse_no = ood.warehouse_no
               and s.exp_no = ood.exp_no
               and ood.enterprise_no = strEnterPriseNo
               and ood.warehouse_no = strWareHouseNo
               and ood.outstock_no = strOutStockNo);

    --跟新出货单据跟踪状态表为发单
    update odata_exp_status s
       set s.curr_status    = COdataExpStatus.ExpTracAllSend,
           s.send_task_date = sysdate,
           s.send_task_name = strUserID
     where s.enterprise_no = strEnterPriseNo
       and s.warehouse_no = strWareHouseNo
       and s.curr_status < COdataExpStatus.ExpTracAllSend
       and exists (select 'X'
              from odata_outstock_d ood
             where s.enterprise_no = ood.enterprise_no
               and s.warehouse_no = ood.warehouse_no
               and s.exp_no = ood.exp_no
               and ood.enterprise_no = strEnterPriseNo
               and ood.warehouse_no = strWareHouseNo
               and ood.outstock_no = strOutStockNo);

    --新增出货跟踪状态日志表
    insert into ODATA_EXP_STATUS_LOG
      (enterprise_no,
       Warehouse_No,
       Owner_No,
       Exp_Type,
       Exp_No,
       exp_Status,
       Rgst_Name,
       Rgst_Date)
      select distinct strEnterpriseNo,
                      strWareHouseNo,
                      ood.owner_no,
                      ood.exp_type,
                      ood.exp_no,
                      COdataExpStatus.ExpTracAllSend,
                      strUserID,
                      sysdate
        from odata_outstock_d ood
       where ood.enterprise_no = strEnterPriseNo
         and ood.warehouse_no = strWareHouseNo
         and ood.outstock_no = strOutStockNo
         and not exists
       (select 'X'
                from ODATA_EXP_STATUS_LOG osl
               where ood.enterprise_no = osl.enterprise_no
                 and ood.warehouse_no = osl.warehouse_no
                 and ood.Owner_No = osl.Owner_No
                 and ood.Exp_Type = osl.Exp_Type
                 and ood.Exp_No = osl.Exp_No
                 and osl.exp_Status = COdataExpStatus.ExpTracAllSend);

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_Send_ExpTrace;


end pklg_odata;

/

