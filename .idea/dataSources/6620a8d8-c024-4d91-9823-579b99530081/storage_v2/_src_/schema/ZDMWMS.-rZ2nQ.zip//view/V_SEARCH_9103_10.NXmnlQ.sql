create view V_SEARCH_9103_10 as
select aom.order_no,aom.source_no,aom.sdate,aom.owner_alias,aom.cust_alias,aod.barcode_no,aod.article_name,
aod.order_qty,aod.in_qty,aod.sign_qty,aod.lost_qty, aod.in_qty-aod.sign_qty-aod.lost_qty diffqty
from acdata_order_m aom,acdata_order_d aod
where aom.order_no= aod.order_no


/

