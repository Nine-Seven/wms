create view V_SEARCH_9103_026 as
SELECT A.ENTERPRISE_NO,
       A.WAREHOUSE_NO,
       A.OWNER_NO,
       A.RGST_DATE,
       A.SOURCEEXP_NO,
       (case A.exp_type
         when 'B2C' then
          'B2C出库'
         when 'B2C1' then
          '预包出库'
         when ' OJ' then
          '客户自提出库'
         when 'OCJ' then
          '国检送检出库'
         when 'OBC' then
          '包材出库'
         when 'OYP' then
          '样品担保出库'
         when 'OHQ' then
          '账册结转出区'
         when 'OS' then
          '紧急单出库'
         when 'B2C' then
          '一般贸易出库'
         else
          'N'
       end) as exp_type,
       A.EXP_NO,
       A.WAVE_NO,
       A.SHIPPER_DELIVER_NO,
       A.SHIPPER_NO,
       B.RGST_NAME, --建单人
       bd.worker_name,
       A.UPDT_NAME,
       BDW.WORKER_NAME as UPDT_NAME1,
/*       B.LOCATE_NAME, --定位人
       B.SEND_TASK_NAME, --发单人
       B.OUTSTOCK_NAME, --拣货人
       B.DIVIDE_NAME, --分播人
       B.B_CHECK_NAME, --复核人
       B.LOADCAR_NAME, --装车人
       B.CLOSE_NAME, --封车人*/
       （ CASE B.CURR_STATUS WHEN '00' THEN '建单' when '05' THEN '已定位'
       when '10' THEN '已定位' when '20' THEN '已发单' when '25' THEN '未拣货'
       when '30' THEN '已回单' when '35' THEN '未分播' when '40' THEN '已分播'
       when '45' THEN '未复核' when '50' THEN '已复核' when '55' THEN '未装车'
       when '60' THEN '已装车' when '65' THEN '未封车' when '70' THEN '已封车'
       when '90' THEN '取消' when '99' THEN '病单' else 'N' END）CURR_STATUS
  FROM ODATA_EXP_M A
   JOIN odata_exp_status B
    ON A.ENTERPRISE_NO = B.ENTERPRISE_NO
   AND A.EXP_NO = B.EXP_NO
   AND A.WAREHOUSE_NO = B.WAREHOUSE_NO
   AND B.CURR_STATUS<'70'
 left join bdef_defworker bdw
    on bdw.enterprise_no = B.Enterprise_No
   and bdw.worker_no = A.UPDT_NAME
    left join bdef_defworker bd
    on bd.enterprise_no = B.Enterprise_No
   and bd.worker_no = A.Rgst_Name

--AND A.EXP_TYPE = B.EXP_TYPE


/

