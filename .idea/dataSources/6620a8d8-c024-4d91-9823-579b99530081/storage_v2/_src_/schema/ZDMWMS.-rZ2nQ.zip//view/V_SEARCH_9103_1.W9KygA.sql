create view V_SEARCH_9103_1 as
select distinct d."ENTERPRISE_NO",d."WAREHOUSE_NO",d."DIVIDE_NO",d."OPERATE_DATE",d."DIVIDE_TYPE",d."BATCH_NO",d."STATUS",d."EXP_DATE",d."RGST_NAME",d."RGST_DATE",d."UPDT_NAME",d."UPDT_DATE",d."OWNER_NO",d."STATUS_DESC",d."SOURCE_NO",d."LABEL_NO"
  from (select odm.*, def.text status_desc, odd.source_no, lm.label_no
          from Odata_DIVIDE_M odm
         inner join wms_deffieldval def
            on def.colname = upper('STATUS')
           and def.table_name = upper('OM_DIVIDE_M')
           and def.value = odm.status
         inner join Odata_DIVIDE_D odd
            on odd.enterprise_no = odm.enterprise_no
           and odd.WAREHOUSE_NO = odm.WAREHOUSE_NO
           and odd.divide_no = odm.divide_no
         inner join stock_label_m lm
            on lm.enterprise_no = odd.enterprise_no
           and lm.WAREHOUSE_NO = odd.WAREHOUSE_NO
           and lm.container_no = odd.s_container_no
           and lm.owner_container_no = odd.s_container_no
           and lm.source_no = odd.source_no) d

/

