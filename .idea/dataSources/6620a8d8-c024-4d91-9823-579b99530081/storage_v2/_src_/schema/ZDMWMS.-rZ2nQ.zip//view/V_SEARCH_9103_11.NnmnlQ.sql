create view V_SEARCH_9103_11 as
select sc.warehouse_no,dc.warehouse_name,sc.order_no,sc.source_no,sc.article_name,sc.barcode_no,sc.in_qty,sc.in_wt,sc.in_vl,sc.qty,sc.wt,sc.vl
from acdata_stockcontent sc,bdef_defloc dc
where sc.warehouse_no = dc.warehouse_no


/

