create package        PKLG_IDATA_ID is
  -- Author  : wyf
  -- Created : 2015-07-15
  -- Purpose :

  -- Public type declarations
  /************************************************************************************************
       修改人：wyf
       日期：2015-07-15
       功能：扫描验收保存
  *************************************************************************************************/
  procedure P_SCAN_IDCHECK(strEnterpriseNo   in idata_check_m.enterprise_no%type,
                           strWareHouseNo    in idata_check_m.warehouse_no%type,
                           strOwnerNo        in idata_check_m.owner_no%type,
                           strsImportNo      in idata_check_m.s_import_no%type, --进货汇总单号
                           strArticleNo      in idata_check_d.article_no%type,
                           strBarcode        in idata_check_d.barcode%type,
                           nPackingQty       in idata_check_d.packing_qty%type,
                           nCheckQty         in idata_check_d.check_qty%type,
                           strPrinterGroupNo in idata_check_m.printer_group_no%type, --工作站
                           strDockNo         in idata_check_m.dock_no%type, --码头
                           strWorkerNo       in idata_check_m.rgst_name%type, --操作人
                           strCheckTools     in idata_check_m.check_tools%type, --验收工具
                           nIsAdd            in integer, --是否累加 0:覆盖 1:累加
                           strQuality        in idata_check_d.quality%type, --品质
                           dtProduceDate     in idata_check_d.produce_date%type,
                           dtExpireDate      in idata_check_d.expire_date%type,
                           strLotNo          in idata_check_d.lot_no%type, --批次号
                           strRSV_BATCH1     in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                           strRSV_BATCH2     in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                           strRSV_BATCH3     in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                           strRSV_BATCH4     in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                           strRSV_BATCH5     in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                           strRSV_BATCH6     in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                           strRSV_BATCH7     in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                           strRSV_BATCH8     in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                           strLabelNo        in stock_label_m.label_no%type, --实体标签号
                           strInDeviceNo     in idata_check_pal_tmp.sub_label_no%type, --子标签号 传入保存设备号
                           strFixPalFlag     in idata_check_pal_tmp.Fixpal_Flag%type, --1：固定板号；2：流水板号;
                           strBusinessType   in idata_check_pal_tmp.Business_Type%type, --业务类型：0-普通验收；1-直通验收；2-大批量验收；3-客户别；5-越库；6-B/C品
                           strOutDeviceNo    out idata_check_pal_tmp.sub_label_no%type, --子标签号 传出保存设备号
                           strResult         out varchar2);

  /************************************************************************************************
       修改人：wyf
       日期：2015-07-15
       功能：扫描验收保存找设备线路
  *************************************************************************************************/
  procedure P_SCAN_IDALLOT_GETDEVICE(strEnterpriseNo   in idata_check_m.enterprise_no%type,
                                     strWareHouseNo    in idata_check_m.warehouse_no%type,
                                     strOwnerNo        in idata_check_m.owner_no%type,
                                     strsImportNo      in idata_check_m.s_import_no%type, --进货汇总单号
                                     strArticleNo      in idata_check_d.article_no%type,
                                     nPackingQty       in idata_check_d.packing_qty%type,
                                     nCheckQty         in idata_check_d.check_qty%type,
                                     strPrinterGroupNo in idata_check_m.printer_group_no%type, --工作站
                                     strDockNo         in idata_check_m.dock_no%type, --码头
                                     --strWorkerNo       in idata_check_m.rgst_name%type, --操作人
                                     --strCheckTools     in idata_check_m.check_tools%type, --验收工具
                                     --strQuality        in idata_check_d.quality%type, --品质
                                     --dtProduceDate     in idata_check_d.produce_date%type,
                                     --dtExpireDate      in idata_check_d.expire_date%type,
                                     --strLotNo          in idata_check_d.lot_no%type, --批次号strLabelNo        in stock_label_m.label_no%type, --实体标签号
                                     strDeviceGroupNo in device_divide_group.device_group_no%type,
                                     strDeviceNo      in idata_check_pal_tmp.sub_label_no%type, --子标签号 保存设备号
                                     strOutDeviceNo   out idata_check_pal_tmp.sub_label_no%type,
                                     strResult        out varchar2);
  /************************************************************************************************
       修改人：wyf
       日期：2015-07-15
       功能：扫描验收保存找客户
  *************************************************************************************************/
  procedure P_SCAN_IDALLOT_GETCUST(strEnterpriseNo   in idata_check_m.enterprise_no%type,
                                   strWareHouseNo    in idata_check_m.warehouse_no%type,
                                   strOwnerNo        in idata_check_m.owner_no%type,
                                   strSImportNo      in idata_check_m.s_import_no%type, --进货汇总单号
                                   strArticleNo      in idata_check_d.article_no%type,
                                   nPackingQty       in idata_check_d.packing_qty%type,
                                   nCheckQty         in idata_check_d.check_qty%type,
                                   strPrinterGroupNo in idata_check_m.printer_group_no%type, --工作站
                                   strDockNo         in idata_check_m.dock_no%type, --码头
                                   strWorkerNo       in idata_check_m.rgst_name%type, --操作人
                                   --strCheckTools     in idata_check_m.check_tools%type, --验收工具
                                   --strQuality        in idata_check_d.quality%type, --品质
                                   --dtProduceDate     in idata_check_d.produce_date%type,
                                   --dtExpireDate      in idata_check_d.expire_date%type,
                                   --strLotNo          in idata_check_d.lot_no%type, --批次号strLabelNo        in stock_label_m.label_no%type, --实体标签号
                                   strDeviceNo in idata_check_pal_tmp.sub_label_no%type, --子标签号 保存设备号
                                   --strFixPalFlag     in idata_check_pal_tmp.Fixpal_Flag%type, --1：固定板号；2：流水板号;
                                   --strBusinessType   in idata_check_pal_tmp.Business_Type%type, --业务类型：0-普通验收；1-直通验收；2-大批量验收；3-客户别；5-越库；6-B/C品
                                   strCustNo out idata_check_pal_tmp.cust_no%type,
                                   nNeedQty  out idata_check_pal_tmp.check_qty%type, --分配客户数量
                                   nQty      out idata_check_pal_tmp.check_qty%type, --剩余数量
                                   strResult out varchar2);
  /************************************************************************************************
       修改人：wyf
       日期：2015-07-15
       功能：RF封箱
  *************************************************************************************************/
  procedure P_RF_IDCLOSEBOX(strEnterpriseNo   in idata_check_m.enterprise_no%type,
                            strWareHouseNo    in idata_check_m.warehouse_no%type,
                            strOwnerNo        in idata_check_m.owner_no%type,
                            strsImportNo      in idata_check_m.s_import_no%type, --进货汇总单号
                            strArticleNo      in idata_check_d.article_no%type,
                            strBarcode        in idata_check_d.barcode%type,
                            nPackingQty       in idata_check_d.packing_qty%type,
                            nCheckQty         in idata_check_d.check_qty%type, --RF封箱传0
                            strPrinterGroupNo in idata_check_m.printer_group_no%type, --工作站
                            strDockNo         in idata_check_m.dock_no%type, --码头
                            strWorkerNo       in idata_check_m.rgst_name%type, --操作人
                            strCheckTools     in idata_check_m.check_tools%type, --验收工具
                            strQuality        in idata_check_d.quality%type, --品质
                            dtProduceDate     in idata_check_d.produce_date%type,
                            dtExpireDate      in idata_check_d.expire_date%type,
                            strLotNo          in idata_check_d.lot_no%type, --批次号
                            strRSV_BATCH1     in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                            strRSV_BATCH2     in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                            strRSV_BATCH3     in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                            strRSV_BATCH4     in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                            strRSV_BATCH5     in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                            strRSV_BATCH6     in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                            strRSV_BATCH7     in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                            strRSV_BATCH8     in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                            strLabelNo        in stock_label_m.label_no%type, --实体标签号
                            strDeviceNo       in idata_check_pal_tmp.sub_label_no%type, --子标签号 设备线路号
                            strPrintFlag      in bdef_defarticle.print_flag%type,
                            --strFixPalFlag     in idata_check_pal.Fixpal_Flag%type, --1：固定板号；2：流水板号;
                            --strBusinessType   in idata_check_pal.Fixpal_Flag%type, --业务类型：0-普通验收；1-直通验收；2-大批量验收；3-客户别；5-越库；6-B/C品
                            strsCheckNo out idata_check_m.s_check_no%type,
                            strResult   out varchar2);
  /************************************************************************************************
       修改人：wyf
       日期：2015-07-15
       功能：前台验收保存
  *************************************************************************************************/
  procedure P_PC_SAVE_IDCHECK(strEnterpriseNo   in idata_check_m.enterprise_no%type,
                              strWareHouseNo    in idata_check_m.warehouse_no%type,
                              strOwnerNo        in idata_check_m.owner_no%type,
                              strsImportNo      in idata_check_m.s_import_no%type, --进货汇总单号
                              strArticleNo      in idata_check_d.article_no%type,
                              strBarcode        in idata_check_d.barcode%type,
                              nPackingQty       in idata_check_d.packing_qty%type,
                              nCheckQty         in idata_check_d.check_qty%type,
                              strPrinterGroupNo in idata_check_m.printer_group_no%type, --工作站
                              strDockNo         in idata_check_m.dock_no%type, --码头
                              strWorkerNo       in idata_check_m.rgst_name%type, --操作人
                              strCheckTools     in idata_check_m.check_tools%type, --验收工具
                              --nIsAdd            in integer, --是否累加 0:覆盖 1:累加
                              strQuality    in idata_check_d.quality%type, --品质
                              dtProduceDate in idata_check_d.produce_date%type,
                              dtExpireDate  in idata_check_d.expire_date%type,
                              strLotNo      in idata_check_d.lot_no%type, --批次号
                              strRSV_BATCH1 in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                              strRSV_BATCH2 in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                              strRSV_BATCH3 in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                              strRSV_BATCH4 in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                              strRSV_BATCH5 in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                              strRSV_BATCH6 in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                              strRSV_BATCH7 in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                              strRSV_BATCH8 in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                              strLabelNo    in stock_label_m.label_no%type, --实体标签号
                              strSubLabelNo in idata_check_pal_tmp.sub_label_no%type, --子标签号
                              strPrintFlag  in bdef_defarticle.print_flag%type,
                              --strFixPalFlag     in idata_check_pal.Fixpal_Flag%type, --1：固定板号；2：流水板号;
                              --strBusinessType   in idata_check_pal.Fixpal_Flag%type, --业务类型：0-普通验收；1-直通验收；2-大批量验收；3-客户别；5-越库；6-B/C品
                              strResult out varchar2);
  /************************************************************************************************
       修改人：wyf
       日期：2015-07-15
       功能：封箱
  *************************************************************************************************/
  procedure P_SAVE_IDCLOSEBOX(strEnterpriseNo   in idata_check_m.enterprise_no%type,
                              strWareHouseNo    in idata_check_m.warehouse_no%type,
                              strOwnerNo        in idata_check_m.owner_no%type,
                              strsImportNo      in idata_check_m.s_import_no%type, --进货汇总单号
                              strArticleNo      in idata_check_d.article_no%type,
                              strBarcode        in idata_check_d.barcode%type,
                              nPackingQty       in idata_check_d.packing_qty%type,
                              nCheckQty         in idata_check_d.check_qty%type, --RF封箱传0
                              strPrinterGroupNo in idata_check_m.printer_group_no%type, --工作站
                              strDockNo         in idata_check_m.dock_no%type, --码头
                              strWorkerNo       in idata_check_m.rgst_name%type, --操作人
                              strCheckTools     in idata_check_m.check_tools%type, --验收工具
                              strQuality        in idata_check_d.quality%type, --品质
                              dtProduceDate     in idata_check_d.produce_date%type,
                              dtExpireDate      in idata_check_d.expire_date%type,
                              strLotNo          in idata_check_d.lot_no%type, --批次号
                              strRSV_BATCH1     in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                              strRSV_BATCH2     in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                              strRSV_BATCH3     in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                              strRSV_BATCH4     in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                              strRSV_BATCH5     in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                              strRSV_BATCH6     in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                              strRSV_BATCH7     in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                              strRSV_BATCH8     in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                              strLabelNo        in stock_label_m.label_no%type, --实体标签号
                              strDeviceNo       in idata_check_pal_tmp.sub_label_no%type, --子标签号
                              strDeviceGroupNo  in device_divide_group.device_group_no%type, --设备组
                              strPrintFlag      in bdef_defarticle.print_flag%type,
                              --strFixPalFlag     in idata_check_pal.Fixpal_Flag%type, --1：固定板号；2：流水板号;
                              --strBusinessType   in idata_check_pal.Fixpal_Flag%type, --业务类型：0-普通验收；1-直通验收；2-大批量验收；3-客户别；5-越库；6-B/C品
                              strsCheckNo out idata_check_m.s_check_no%type,
                              strResult   out varchar2);
  /************************************************************************************************
       修改人：wyf
       日期：2015-07-15
       功能：直通验收封箱配量
  *************************************************************************************************/
  procedure P_SAVE_ID_ALLOT(strEnterpriseNo   in idata_check_m.enterprise_no%type,
                            strWareHouseNo    in idata_check_m.warehouse_no%type,
                            strOwnerNo        in idata_check_m.owner_no%type,
                            strsImportNo      in idata_check_m.s_import_no%type, --进货汇总单号
                            strArticleNo      in idata_check_d.article_no%type,
                            nPackingQty       in idata_check_d.packing_qty%type,
                            nCheckQty         in idata_check_d.check_qty%type,
                            strCheckTools     in idata_check_m.check_tools%type, --验收工具
                            strPrinterGroupNo in idata_check_m.printer_group_no%type, --工作站
                            strDockNo         in idata_check_m.dock_no%type, --码头
                            strLabelNo        in idata_check_pal_tmp.label_no%type,
                            strDeviceNo       in idata_check_pal_tmp.sub_label_no%type, --子标签号
                            strResult         out varchar2);
  /************************************************************************************************
       修改人：wyf
       日期：2015-07-15
       功能：直通封箱写标签，分播指示，更新进货表
  *************************************************************************************************/
  procedure P_SAVE_ID_LOCATE(strEnterpriseNo in idata_check_m.enterprise_no%type,
                             strWareHouseNo  in idata_check_m.warehouse_no%type,
                             strOwnerNo      in idata_check_m.owner_no%type,
                             strsImportNo    in idata_check_m.s_import_no%type, --进货汇总单号
                             strArticleNo    in idata_check_d.article_no%type,
                             strBarcode      in idata_check_d.barcode%type,
                             nPackingQty     in idata_check_d.packing_qty%type,
                             strWorkerNo     in idata_check_m.rgst_name%type, --操作人
                             strQuality      in idata_check_d.quality%type, --品质
                             dtProduceDate   in idata_check_d.produce_date%type,
                             dtExpireDate    in idata_check_d.expire_date%type,
                             strLotNo        in idata_check_d.lot_no%type, --批次号
                             strRSV_BATCH1   in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                             strRSV_BATCH2   in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                             strRSV_BATCH3   in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                             strRSV_BATCH4   in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                             strRSV_BATCH5   in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                             strRSV_BATCH6   in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                             strRSV_BATCH7   in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                             strRSV_BATCH8   in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                             strLabelNo      in stock_label_m.label_no%type, --实体标签号
                             strDeviceNo     in idata_check_pal_tmp.sub_label_no%type,
                             strsCheckNo     in idata_check_m.s_check_no%type,
                             strCellNo       in stock_content.cell_no%type,
                             strStockType    in idata_import_mm.stock_type%type,
                             strDockNo       in idata_check_pal.dock_no%type,
                             strWaveNo       in idata_import_mm.wave_no%type,
                             strContainerNo  out stock_label_m.label_no%type, --内部容器号
                             strResult       out varchar2);
  /************************************************************************************************
       修改人：wyf
       日期：2015-07-15
       功能：直通转存储
  *************************************************************************************************/
  procedure P_SAVE_ID2IS(strEnterpriseNo   in idata_check_m.enterprise_no%type,
                         strWareHouseNo    in idata_check_m.warehouse_no%type,
                         strOwnerNo        in idata_check_m.owner_no%type,
                         strsImportNo      in idata_check_m.s_import_no%type, --进货汇总单号
                         strArticleNo      in idata_check_d.article_no%type,
                         strBarcode        in idata_check_d.barcode%type,
                         nPackingQty       in idata_check_d.packing_qty%type,
                         nCheckQty         in idata_check_d.check_qty%type, --当前剩余验收数量
                         strPrinterGroupNo in idata_check_m.printer_group_no%type, --工作站
                         strDockNo         in idata_check_m.dock_no%type, --码头
                         strWorkerNo       in idata_check_m.rgst_name%type, --操作人
                         strCheckTools     in idata_check_m.check_tools%type, --验收工具
                         strQuality        in idata_check_d.quality%type, --品质
                         dtProduceDate     in idata_check_d.produce_date%type,
                         dtExpireDate      in idata_check_d.expire_date%type,
                         strLotNo          in idata_check_d.lot_no%type, --批次号
                         strRSV_BATCH1     in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                         strRSV_BATCH2     in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                         strRSV_BATCH3     in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                         strRSV_BATCH4     in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                         strRSV_BATCH5     in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                         strRSV_BATCH6     in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                         strRSV_BATCH7     in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                         strRSV_BATCH8     in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                         strLabelNo        in stock_label_m.label_no%type, --实体标签号
                         strSubLabelNo     in idata_check_pal_tmp.sub_label_no%type, --子标签号
                         strFixPalFlag     in idata_check_pal.Fixpal_Flag%type, --1：固定板号；2：流水板号;
                         strBusinessType   in idata_check_pal.business_type%type, --业务类型：0-普通验收；1-直通验收；2-大批量验收；3-客户别；5-越库；6-B/C品
                         strsCheckNo       out idata_check_m.s_check_no%type,
                         strResult         out varchar2);
  /************************************************************************************************
       修改人：wyf
       日期：2015-07-15
       功能：扫描扣减数量
  *************************************************************************************************/
  procedure P_SCAN_DEDUCTION(strEnterpriseNo   in idata_check_m.enterprise_no%type,
                             strWareHouseNo    in idata_check_m.warehouse_no%type,
                             strOwnerNo        in idata_check_m.owner_no%type,
                             strsImportNo      in idata_check_m.s_import_no%type, --进货汇总单号
                             strArticleNo      in idata_check_d.article_no%type,
                             strBarcode        in idata_check_d.barcode%type,
                             nPackingQty       in idata_check_d.packing_qty%type,
                             nCheckQty         in idata_check_d.check_qty%type,
                             strPrinterGroupNo in idata_check_m.printer_group_no%type, --工作站
                             strDockNo         in idata_check_m.dock_no%type, --码头
                             strWorkerNo       in idata_check_m.rgst_name%type, --操作人
                             strCheckTools     in idata_check_m.check_tools%type, --验收工具
                             strQuality        in idata_check_d.quality%type, --品质
                             dtProduceDate     in idata_check_d.produce_date%type,
                             dtExpireDate      in idata_check_d.expire_date%type,
                             strLotNo          in idata_check_d.lot_no%type, --批次号
                             strRSV_BATCH1     in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                             strRSV_BATCH2     in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                             strRSV_BATCH3     in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                             strRSV_BATCH4     in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                             strRSV_BATCH5     in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                             strRSV_BATCH6     in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                             strRSV_BATCH7     in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                             strRSV_BATCH8     in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                             strLabelNo        in stock_label_m.label_no%type, --实体标签号
                             strDeviceNo       in idata_check_pal_tmp.sub_label_no%type, --子标签号 保存设备号
                             strResult         out varchar2);
  /************************************************************************************************
       修改人：wyf
       日期：2015-07-15
       功能：打印吊牌和条码
  *************************************************************************************************/
  procedure P_IDCHECK_PRINT(strEnterpriseNo in idata_check_m.enterprise_no%type,
                            strWareHouseNo  in idata_check_m.warehouse_no%type,
                            strArticleNo    in idata_check_d.article_no%type,
                            strBarcode      in idata_check_d.barcode%type,
                            nCheckQty       in idata_check_d.check_qty%type,
                            --strPrinterGroupNo in idata_check_m.printer_group_no%type, --工作站
                            strDockNo    in idata_check_m.dock_no%type, --码头
                            strWorkerNo  in idata_check_m.rgst_name%type, --操作人
                            strPrintFlag in bdef_defarticle.print_flag%type,
                            strResult    out varchar2);
  /************************************************************************************************
       修改人：wyf
       日期：2015-11-30
       功能：1、直通验收；
             2、分播发单；
             3、剩余商品转存储验收；
             4、存储定位；
             5、上架发单
             （不支持电子标签储位分播）
  *************************************************************************************************/
  procedure P_SAVE_IDCHECK(strEnterpriseNo   in idata_check_m.enterprise_no%type,
                           strWareHouseNo    in idata_check_m.warehouse_no%type,
                           strOwnerNo        in idata_check_m.owner_no%type,
                           strsImportNo      in idata_check_m.s_import_no%type, --进货汇总单号
                           strArticleNo      in idata_check_d.article_no%type,
                           strBarcode        in idata_check_d.barcode%type,
                           nPackingQty       in idata_check_d.packing_qty%type,
                           nCheckQty         in idata_check_d.check_qty%type,
                           strPrinterGroupNo in idata_check_m.printer_group_no%type, --工作站
                           strDockNo         in idata_check_m.dock_no%type, --码头
                           strWorkerNo       in idata_check_m.rgst_name%type, --操作人
                           strCheckTools     in idata_check_m.check_tools%type, --验收工具
                           nIsAdd            in integer, --是否累加 0:覆盖 1:累加
                           strQuality        in idata_check_d.quality%type, --品质
                           dtProduceDate     in idata_check_d.produce_date%type,
                           dtExpireDate      in idata_check_d.expire_date%type,
                           strLotNo          in idata_check_d.lot_no%type, --批次号
                           strRSV_BATCH1     in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                           strRSV_BATCH2     in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                           strRSV_BATCH3     in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                           strRSV_BATCH4     in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                           strRSV_BATCH5     in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                           strRSV_BATCH6     in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                           strRSV_BATCH7     in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                           strRSV_BATCH8     in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                           strLabelNo        in stock_label_m.label_no%type, --实体标签号
                           strSubLabelNo     in idata_check_pal_tmp.sub_label_no%type, --子标签号
                           strArtPrintFlag      in bdef_defarticle.print_flag%type, --打印商品条码标识
                           strFixPalFlag     in idata_check_pal.Fixpal_Flag%type, --1：固定板号；2：流水板号;
                           strBusinessType   in idata_check_pal.Fixpal_Flag%type, --业务类型：0-普通验收；1-直通验收；2-大批量验收；3-客户别；5-越库；6-B/C品
                           strPrintFlag      in varchar2,--单据打印标识 0 不打印，1：打印表单，2：打印标签
                           strResult         out varchar2);
  /************************************************************************************************
       修改人：wyf
       日期：2015-11-30
       功能：直通封板(无电子标签分配)
  *************************************************************************************************/
  procedure P_SAVE_IDCLOSEPAL(strEnterpriseNo   in idata_check_m.enterprise_no%type,
                              strWareHouseNo    in idata_check_m.warehouse_no%type,
                              strOwnerNo        in idata_check_m.owner_no%type,
                              strsImportNo      in idata_check_m.s_import_no%type, --进货汇总单号
                              strArticleNo      in idata_check_d.article_no%type,
                              strBarcode        in idata_check_d.barcode%type,
                              nPackingQty       in idata_check_d.packing_qty%type,
                              nCheckQty         in idata_check_d.check_qty%type, --RF封箱传0
                              strPrinterGroupNo in idata_check_m.printer_group_no%type, --工作站
                              strDockNo         in idata_check_m.dock_no%type, --码头
                              strWorkerNo       in idata_check_m.rgst_name%type, --操作人
                              strCheckTools     in idata_check_m.check_tools%type, --验收工具
                              strQuality        in idata_check_d.quality%type, --品质
                              dtProduceDate     in idata_check_d.produce_date%type,
                              dtExpireDate      in idata_check_d.expire_date%type,
                              strLotNo          in idata_check_d.lot_no%type, --批次号
                              strRSV_BATCH1     in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                              strRSV_BATCH2     in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                              strRSV_BATCH3     in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                              strRSV_BATCH4     in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                              strRSV_BATCH5     in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                              strRSV_BATCH6     in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                              strRSV_BATCH7     in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                              strRSV_BATCH8     in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                              strLabelNo        in stock_label_m.label_no%type, --实体标签号
                              strSubLabelNo     in idata_check_pal_tmp.sub_label_no%type, --子标签号
                              strFixPalFlag     in idata_check_pal.Fixpal_Flag%type, --1：固定板号；2：流水板号;
                              strBusinessType   in idata_check_pal.Fixpal_Flag%type, --业务类型：0-普通验收；1-直通验收；2-大批量验收；3-客户别；5-越库；6-B/C品
                              strArtPrintFlag   in bdef_defarticle.print_flag%type,
                              strWaveNo         in idata_import_mm.wave_no%type,
                              strImportType     in idata_import_mm.import_type%type,
                              strPrintFlag      in varchar2,--单据打印标识 0 不打印，1：打印表单，2：打印标签
                              strSCheckNo       out idata_check_m.s_check_no%type,
                              strResult         out varchar2);
  /************************************************************************************************
       修改人：wyf
       日期：2015-11-30
       功能：直通封箱写标签，分播指示，更新进货表(无电子标签分配)
  *************************************************************************************************/
  procedure P_SAVE_IDWIRTEDIRECT(strEnterpriseNo in idata_check_m.enterprise_no%type,
                                 strWareHouseNo  in idata_check_m.warehouse_no%type,
                                 strOwnerNo      in idata_check_m.owner_no%type,
                                 strsImportNo    in idata_check_m.s_import_no%type, --进货汇总单号
                                 strArticleNo    in idata_check_d.article_no%type,
                                 strBarcode      in idata_check_d.barcode%type,
                                 nPackingQty     in idata_check_d.packing_qty%type,
                                 strWorkerNo     in idata_check_m.rgst_name%type, --操作人
                                 strQuality      in idata_check_d.quality%type, --品质
                                 dtProduceDate   in idata_check_d.produce_date%type,
                                 dtExpireDate    in idata_check_d.expire_date%type,
                                 strLotNo        in idata_check_d.lot_no%type, --批次号
                                 strRSV_BATCH1   in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                                 strRSV_BATCH2   in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                                 strRSV_BATCH3   in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                                 strRSV_BATCH4   in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                                 strRSV_BATCH5   in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                                 strRSV_BATCH6   in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                                 strRSV_BATCH7   in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                                 strRSV_BATCH8   in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                                 strLabelNo      in stock_label_m.label_no%type, --实体标签号
                                 strSubLabelNo   in idata_check_pal_tmp.sub_label_no%type,
                                 strsCheckNo     in idata_check_m.s_check_no%type,
                                 strCellNo       in stock_content.cell_no%type,
                                 strStockType    in idata_import_mm.stock_type%type,
                                 strDockNo       in idata_check_pal.dock_no%type,
                                 strFixPalFlag   in idata_check_pal.Fixpal_Flag%type, --1：固定板号；2：流水板号;
                                 strWaveNo       in idata_import_mm.wave_no%type,
                                 strImportType   in idata_import_mm.import_type%type,
                                 strBatchNo      in odata_divide_allot.batch_no%type,
                                 strContainerNo  out stock_label_m.label_no%type, --内部容器号z
                                 strResult       out varchar2);

  /************************************************************************************************
       日期：2015-12-5
       功能：根据单据配置判断是否走门店整板，目前只适用于配送对象按客户的业务模式
  *************************************************************************************************/
  procedure P_Chang_DivideSingCust(strEnterPriseNo   in ODATA_DIVIDE_D.Enterprise_No%type, --企业号
                                   strWareHouseNo    in ODATA_DIVIDE_D.warehouse_no%type, --仓别
                                   strOWNER_NO       in ODATA_DIVIDE_D.OWNER_NO%type, --委托业主
                                   strDockNo         in bdef_defdock.dock_no%type, --码头
                                   strSource_No      in odata_divide_direct.source_no%type, --来源单号
                                   strS_CONTAINER_NO in odata_divide_direct.S_CONTAINER_NO%type, --来源容器
                                   strUserID         in bdef_defworker.worker_no%type, --系统操作人员
                                   strPrint_Flag     in varchar, --是否打印
                                   strOutMsg         out varchar2);

 /*=====================================================================================
   insert to 20151212
  进货直通分配格子号
  ======================================================================================*/
    PROCEDURE p_I_CustAllot_LABEL_RG(strEnterPriseNo in idata_import_sm.enterprise_no%type,
                                 strwarehouse_no in idata_import_sm.warehouse_no%type, --仓别
                                 strowner_no     in idata_import_sm.owner_no%type,
                                 strSImportNo   in idata_import_sm.s_import_no%type, --进货汇总单号
                                 strClassType    in wms_warehouse_outorder.exp_type%type,
                                 strUser_Id      in idata_import_sm.rgst_name%type, --操作人员
                                 strDockNo       in idata_check_m.dock_no%type,---打印码头
                                 strOutMsg       out varchar2) ;
end PKLG_IDATA_ID;


/

