create package body PKLG_ODATA_MOVE_JUN is

  /*****************************************************************************************
   功能：容器整理，按商品整理
  Modify By JUN AT 2014-06-03
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure p_container_arrange(strEnterpriseNo in stock_label_m.enterprise_no%type, --仓别
                                strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                                strSLabelNo     in stock_label_m.label_no%type, --来源标签
                                strDLabelNo     in stock_label_m.label_no%type, --目的标签
                                strDeliverOBJ   in stock_label_d.deliver_obj%type, --配送对象
                                strArticleNo    in stock_label_d.article_no%type, --商品编码
                                nPackingQty     in stock_label_d.packing_qty%type, --商品包装
                                nMoveQty        in stock_label_d.qty%type, --移动数量 0：表示整箱移
                                strQuality      in stock_article_info.quality%type, --品质
                                dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                                dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                                strLotNo        in stock_article_info.lot_no%type, --批号
                                strRsvBatch1    in stock_article_info.rsv_batch1%type, --预留批属性1
                                strRsvBatch2    in stock_article_info.rsv_batch2%type, --预留批属性2
                                strRsvBatch3    in stock_article_info.rsv_batch3%type, --预留批属性3
                                strRsvBatch4    in stock_article_info.rsv_batch4%type, --预留批属性4
                                strRsvBatch5    in stock_article_info.rsv_batch5%type, --预留批属性5
                                strRsvBatch6    in stock_article_info.rsv_batch6%type, --预留批属性6
                                strRsvBatch7    in stock_article_info.rsv_batch7%type, --预留批属性7
                                strRsvBatch8    in stock_article_info.rsv_batch8%type, --预留批属性8
                                strUserId       in stock_label_m.rgst_name%type, --操作人员
                                strTerminalFlag in varchar2, --操作设备
                                strResult       out varchar2) is
    --返回 执行结果
    v_strsContainerNo stock_label_m.container_no%type; --来源内部容器号
    v_strdContainerNo stock_label_m.container_no%type; --目的内部容器号

    v_nCount         number(10); --记录数，以做判断;
    v_dStatus        stock_label_m.status%type; --目的容器状态
    v_sStatus        stock_label_m.status%type; --源容器状态
    v_sDeliverObj    stock_label_m.deliver_obj%type; --源容器配送对象
    v_sUseType       stock_label_m.use_type%type; --源容器标签
    v_sLineNo        stock_label_m.line_no%type; --源容器线路
    v_dContainerType stock_label_m.container_type%type; --目的容器类型
    v_strArrangeNo   stock_label_move_log.arrange_no%type; --整理单号
    v_strContainerNo stock_label_m.container_no%type; --容器号
    v_strLabelNo     stock_label_m.label_no%type; --板号
    v_strStockValue  stock_content.stock_value%type;
    v_strCellId      stock_content.cell_id%type;
    v_nAllQty        stock_label_d.qty%type; --总量
    v_nContainerQty  stock_label_d.qty%type; --中间量
    v_nTmpQty        stock_label_d.qty%type; --中间量
    v_strWaveNo      stock_label_d.wave_no%type;
    v_Owner_No       bdef_defowner.owner_no%type;
    v_Exp_Type       odata_exp_m.exp_type%type;

    v_strTrunckCellNo   stock_label_m.trunck_cell_no%type;
    v_strAsorterChuteNo stock_label_m.a_sorter_chute_no%type;
    v_strDeliverObj     stock_label_m.deliver_obj%type;
    v_strDeliverArea    stock_label_m.deliver_area%type;
    v_strCustNo         stock_label_m.cust_no%type;
    v_strOwnerCellNo    stock_label_m.owner_cell_no%type;
    v_strSourceNo       stock_label_m.source_no%type;
    v_strCheckChuteNo   stock_label_m.check_chute_no%type;
    v_strFlowFlag       wms_deflabel_status.flow_flag%type;
    v_strAutoFlag       wms_deflabel_status.must_run%type;

    v_strArrangeGetSeqByLocate varchar2(20);
    v_nArrangeGetSeqByLocate   varchar2(20);
    v_outMsg                   varchar2(255);
  begin
    strResult := 'N|[p_container_arrange]';

    p_contrast_containerNo(strEnterpriseNo,
                           strWarehouseNo,
                           strSLabelNo,
                           strDLabelNo,
                           strResult);

    if substr(v_OutMsg, 1, 1) <> 'Y' then
      strResult := v_OutMsg;
      return;
    end if;
    --取来源容器号
    select slm.deliver_obj,
           slm.status,
           slm.use_type,
           slm.line_no,
           slm.trunck_cell_no,
           slm.a_sorter_chute_no,
           slm.deliver_obj,
           slm.deliver_area,
           Slm.cust_no,
           slm.owner_cell_no,
           slm.source_no,
           slm.check_chute_no,
           slm.container_no
      into v_sDeliverObj,
           v_sStatus,
           v_sUseType,
           v_sLineNo,
           v_strTrunckCellNo,
           v_strAsorterChuteNo,
           v_strDeliverObj,
           v_strDeliverArea,
           v_strCustNo,
           v_strOwnerCellNo,
           v_strSourceNo,
           v_strCheckChuteNo,
           v_strsContainerNo
      from stock_label_m slm
     where slm.enterprise_no = strEnterpriseNo
       and slm.warehouse_no = strWarehouseNo
       and slm.label_no = strSLabelNo;

    --获取目的容器号
    begin
      select slm.container_no, slm.status
        into v_strdContainerNo, v_dStatus
        from stock_label_m slm
       where slm.enterprise_no = strEnterpriseNo
         and slm.warehouse_no = strWarehouseNo
         and slm.label_no = strDLabelNo;
    exception
      when no_data_found then
        strResult := 'N|标签号不存在-' || strDLabelNo;
        return;
    end;

    --获取整理单号
    PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                               strWarehouseNo,
                               CONST_DOCUMENTTYPE.ODATACT,
                               v_strArrangeNo,
                               v_OutMsg);
    if substr(v_OutMsg, 1, 1) <> 'Y' then
      strResult := v_OutMsg;
      return;
    end if;

    --根据单号把记录写进stock_label_move_log表
    if nMoveQty <> 0 then
      --不等于0 等于零散移
      v_nCount        := 0;
      v_nAllQty       := nMoveQty;
      v_nContainerQty := 0;
      v_nTmpQty       := 0;
      for i_Label_Detail in (select sld.*
                               from stock_label_d      sld,
                                    stock_article_info sai
                              where sld.enterprise_no = sai.enterprise_no
                                and sld.article_no = sai.article_no
                                and sld.article_id = sai.article_id
                                and sld.enterprise_no = strEnterpriseNo
                                and sld.article_no = strArticleNo
                                and sld.packing_qty = nPackingQty
                                and sld.container_no = v_strsContainerNo
                                and sld.deliver_obj =
                                --容器整理不需要传配送对象 huangb 20160812
                                (case when strDeliverOBJ = 'N' then v_sDeliverObj else strDeliverOBJ end)
                                and sai.quality = strQuality
                                and sai.produce_date = dtProduceDate
                                and sai.expire_date = dtExpireDate
                                and sai.lot_no = strLotNo
                                and sai.rsv_batch1 = strRsvBatch1
                                and sai.rsv_batch2 = strRsvBatch2
                                and sai.rsv_batch3 = strRsvBatch3
                                and sai.rsv_batch4 = strRsvBatch4
                                and sai.rsv_batch5 = strRsvBatch5
                                and sai.rsv_batch6 = strRsvBatch6
                                and sai.rsv_batch7 = strRsvBatch7
                                and sai.rsv_batch8 = strRsvBatch8
                              order by sld.article_id) loop

        v_nContainerQty := i_Label_Detail.Qty;
        v_nCount        := v_nCount + 1;

        if v_nAllQty > v_nContainerQty then
          v_nTmpQty := v_nContainerQty;
        else
          v_nTmpQty := v_nAllQty;
        end if;
        insert into stock_label_move_log
          (warehouse_no,
           arrange_no,
           row_id,
           s_container_no,
           d_container_no,
           batch_no,
           owner_no,
           source_no,
           article_no,
           article_id,
           packing_qty,
           move_qty,
           exp_no,
           wave_no,
           cust_no,
           sub_cust_no,
           line_no,
           divide_id,
           exp_type,
           rgst_name,
           rgst_date,
           enterprise_no)
          select strWarehouseNo,
                 v_strArrangeNo,
                 sld.row_id,
                 v_strsContainerNo,
                 v_strDcontainerNo,
                 sld.batch_no,
                 sld.owner_no,
                 sld.source_no,
                 sld.article_no,
                 sld.article_id,
                 sld.packing_qty,
                 v_nTmpQty,
                 sld.exp_no,
                 sld.wave_no,
                 sld.cust_no,
                 sld.sub_cust_no,
                 sld.line_no,
                 sld.divide_id,
                 sld.exp_type,
                 strUserId,
                 sysdate,
                 sld.enterprise_no
            from stock_label_d sld
           where sld.warehouse_no = strWarehouseNo
             and sld.enterprise_no = strEnterpriseNo
             and sld.container_no = v_strsContainerNo
             and sld.article_no = i_Label_Detail.Article_No
             and sld.article_id = i_Label_Detail.Article_Id
             and sld.divide_id = i_Label_Detail.Divide_Id
             and sld.row_id = i_Label_Detail.Row_Id;

        if sql%rowcount <= 0 then
          strResult := 'N|[E23211]'; --插入明细失败
          return;
        end if;
        v_nAllQty := v_nAllQty - v_nTmpQty;

        if v_nAllQty <= 0 then
          exit;
        end if;
      end loop;

      if v_nCount = 0 then
        strResult := 'N|[E23212]'; --找不到容器明细
        return;
      end if;
    else
      --等于0  等于整板移
      insert into stock_label_move_log
        (warehouse_no,
         arrange_no,
         row_id,
         s_container_no,
         d_container_no,
         batch_no,
         owner_no,
         source_no,
         article_no,
         article_id,
         packing_qty,
         move_qty,
         exp_no,
         wave_no,
         cust_no,
         sub_cust_no,
         line_no,
         divide_id,
         exp_type,
         rgst_name,
         rgst_date,
         enterprise_no)
        select strWarehouseNo,
               v_strArrangeNo,
               sld.row_id,
               v_strsContainerNo,
               v_strDcontainerNo,
               sld.batch_no,
               sld.owner_no,
               sld.source_no,
               sld.article_no,
               sld.article_id,
               sld.packing_qty,
               sld.qty,
               sld.exp_no,
               sld.wave_no,
               sld.cust_no,
               sld.sub_cust_no,
               sld.line_no,
               sld.divide_id,
               sld.exp_type,
               strUserId,
               sysdate,
               sld.enterprise_no
          from stock_label_d sld
         where sld.warehouse_no = strWarehouseNo
           and sld.enterprise_no = strEnterpriseNo
           and sld.container_no = v_strsContainerNo;

      if sql%rowcount <= 0 then
        strResult := 'N|[E23211]'; --插入明细失败
        return;
      end if;
    end if;

    --循环整理单明细
    for i_MoveLabel_Info in (select slml.*,
                                    slm.owner_cell_no  as s_owner_cell_no,
                                    dlm.owner_cell_no  as d_owner_cell_no,
                                    slm.container_type,
                                    slm.label_no       as s_label_no,
                                    dlm.label_no       as d_label_no,
                                    dlm.stock_type,
                                    slm.hm_manual_flag
                               from stock_label_move_log slml,
                                    stock_label_m        slm,
                                    stock_label_m        dlm
                              where slml.warehouse_no = slm.warehouse_no
                                and slml.enterprise_no = slm.enterprise_no
                                and slml.s_container_no = slm.container_no
                                and slml.warehouse_no = dlm.warehouse_no
                                and slml.enterprise_no = dlm.enterprise_no
                                and slml.d_container_no = dlm.container_no
                                and slm.enterprise_no = strEnterpriseNo
                                and slml.arrange_no = v_strArrangeNo) loop
      v_nCount := 1;
      -------------------是否储位库存，------------------------------
      if i_MoveLabel_Info.hm_manual_flag = '1' then
        v_strContainerNo := 'N'; --储位库存
        v_strLabelNo     := 'N'; --储位库存
      else
        v_strContainerNo := i_MoveLabel_Info.s_Container_No; --标签库存
        v_strLabelNo     := i_MoveLabel_Info.s_Label_No; --标签库存
      end if;
      if (i_MoveLabel_Info.Stock_Type = 2) then
        --客户别数据 库存表需要写n_Stock_Value值
        v_strStockValue := i_MoveLabel_Info.Cust_No;
      else
        v_strStockValue := 'N';
      end if;

      v_Owner_No := i_MoveLabel_Info.Owner_No;
      v_Exp_Type := i_MoveLabel_Info.Exp_Type;

      --增加目的库存 没有预上数量
      PKOBJ_STOCK.p_InstContent_qtyByCellNo(i_MoveLabel_Info.Enterprise_No, --
                                            i_MoveLabel_Info.Warehouse_No, --仓别
                                            i_MoveLabel_Info.Owner_No, --货主
                                            'N', --部门
                                            i_MoveLabel_Info.Article_No, --商品编码
                                            i_MoveLabel_Info.Article_Id, --商品ID
                                            i_MoveLabel_Info.d_Owner_Cell_No, --目的储位
                                            i_MoveLabel_Info.s_Owner_Cell_No, --源储位
                                            i_MoveLabel_Info.Packing_Qty, --包装数量
                                            i_MoveLabel_Info.Move_Qty, --转移数量
                                            i_MoveLabel_Info.d_Label_No, --目的标签
                                            i_MoveLabel_Info.d_Label_No, --目的标签
                                            i_MoveLabel_Info.Stock_Type, --存储类型
                                            v_strStockValue, --存储类型的值
                                            strUserId, --操作人
                                            v_strArrangeNo, --整理单号
                                            strTerminalFlag, --操作工具
                                            0, --是否可手工移库 0:不允许手工移库；1：可手工移库
                                            v_strCellId, --返回的储位ID
                                            v_outMsg --返回的结果
                                            );
      if (substr(v_OutMsg, 1, 1) <> 'Y') then
        strResult := v_OutMsg;
        return;
      end if;

      --扣减源库存 循环扣减, 不处理预约上下架量，直接扣减库存
      PKOBJ_STOCK.p_UpdtContent_qtyByCellNo(i_MoveLabel_Info.Enterprise_No, --
                                            i_MoveLabel_Info.Warehouse_No, --仓别
                                            i_MoveLabel_Info.Owner_No, --货主
                                            i_MoveLabel_Info.Article_No, --商品编码
                                            i_MoveLabel_Info.Article_Id, --商品ID
                                            i_MoveLabel_Info.s_Owner_Cell_No, --源储位
                                            i_MoveLabel_Info.d_Owner_Cell_No, --目的储位
                                            i_MoveLabel_Info.Packing_Qty, --包装数量
                                            i_MoveLabel_Info.Move_Qty, --转移数量
                                            i_MoveLabel_Info.s_Label_No, --源标签
                                            i_MoveLabel_Info.Stock_Type, --存储类型
                                            v_strStockValue, --存储类型的值
                                            strUserId, --操作人
                                            v_strArrangeNo, --整理单号
                                            strTerminalFlag, --操作工具
                                            v_outMsg); --返回结果
      if (substr(v_OutMsg, 1, 1) <> 'Y') then
        strResult := v_OutMsg;
        return;
      end if;

    end loop;

    if v_dStatus = CLabelStatus.NEW_LABEL_NO then
      --判断当前工作流是否执行状态

      PKOBJ_HB.p_getlabelnoFlow(strEnterPriseNo,
                                strWarehouseNo,
                                v_Owner_No,
                                v_Exp_Type,
                                v_strScontainerNo,
                                v_strFlowFlag,
                                v_outMsg);
      if (substr(v_outMsg, 1, 1) <> 'Y') then
        return;
      end if;

      if v_strFlowFlag = '1' then
        v_dStatus := v_sStatus;
      else
        PKOBJ_HB.p_GetLabelStatusFromWorkflow(strEnterPriseNo,
                                              strWarehouseNo,
                                              v_Owner_No,
                                              v_Exp_Type,
                                              v_strScontainerNo,
                                              v_dStatus,
                                              v_strAutoFlag,
                                              v_outMsg);
        if (substr(v_outMsg, 1, 1) <> 'Y') then
          return;
        end if;
      end if;

      update stock_label_m slm
         set slm.trunck_cell_no    = v_strTrunckCellNo,
             slm.a_sorter_chute_no = v_strAsorterChuteNo,
             slm.deliver_obj       = v_strDeliverObj,
             slm.deliver_area      = v_strDeliverArea,
             slm.cust_no           = v_strCustNo,
             slm.owner_cell_no     = v_strOwnerCellNo,
             slm.line_no           = v_sLineNo,
             slm.rgst_name         = strUserId,
             slm.source_no         = v_strSourceNo,
             slm.status            = v_dStatus,
             slm.check_chute_no    = v_strCheckChuteNo
       where slm.warehouse_no = strWarehouseNo
         and slm.enterprise_no = strEnterpriseNo
         and slm.container_no = v_strDcontainerNo;
      update stock_label_d sld
         set sld.status = v_dStatus
       where sld.warehouse_no = strWarehouseNo
         and sld.enterprise_no = strEnterpriseNo
         and sld.container_no = v_strDcontainerNo;

    end if;
    --标签转移
    PKOBJ_LABEL.proc_OM_ArrangeMoveLabelInfo(strEnterpriseNo,
                                             strWarehouseNo, --仓别
                                             v_strArrangeNo, --整理单号
                                             strUserId, --操作人
                                             v_outMsg); --返回结果
    if (substr(v_OutMsg, 1, 1) <> 'Y') then
      strResult := v_OutMsg;
      return;
    end if;

    --销毁空标签头 容器整理使用
    PKOBJ_LABEL.proc_OM_Destory_NullLabel(strEnterpriseNo,
                                          strWarehouseNo, --仓别
                                          v_strScontainerNo, --容器号
                                          strUserId, --操作人
                                          v_outMsg --返回结果
                                          );
    if (substr(v_OutMsg, 1, 1) <> 'Y') then
      strResult := v_OutMsg;
      return;
    end if;

    --转历史
    begin
      insert into stock_label_move_loghty
        (warehouse_no,
         arrange_no,
         row_id,
         s_container_no,
         d_container_no,
         batch_no,
         owner_no,
         source_no,
         article_no,
         article_id,
         packing_qty,
         move_qty,
         exp_no,
         wave_no,
         cust_no,
         sub_cust_no,
         line_no,
         divide_id,
         exp_type,
         rgst_name,
         rgst_date,
         enterprise_no)
        select *
          from stock_label_move_log slml
         where slml.warehouse_no = strWarehouseNo
           and slml.enterprise_no = strEnterpriseNo
           and slml.arrange_no = v_strArrangeNo;

      if sql%rowcount <= 0 then
        strResult := 'N|[E23213]'; --插入历史表失败
        return;
      end if;
    end;

    delete stock_label_move_log slml
     where slml.warehouse_no = strWarehouseNo
       and slml.enterprise_no = strEnterpriseNo
       and slml.arrange_no = v_strArrangeNo;

    --获取系统参数
    --内复核、出货整理标签产生配送对象的序列号的级别系统参数(0：按客户产生，1：按波次下的客户产生)
    PKLG_WMS_BASE.p_GetBasePara(strEnterpriseNo,
                                strWareHouseNo,
                                'N',
                                'Arrange_GetSeqByLocate',
                                'O',
                                'O_ARRANGE',
                                v_strArrangeGetSeqByLocate,
                                v_nArrangeGetSeqByLocate,
                                v_outMsg);
    if substr(v_outMsg, 1, 1) = 'N' then
      strResult := 'N|[E23214]'; --找不到系统参数
      return;
    end if;

    if v_dContainerType = 'B' then
      --0：按客户产生
      if v_strArrangeGetSeqByLocate = '0' then
        begin
          update stock_label_m slm
             set slm.seq_value =
                 (select max(slm.seq_value) + 1
                    from stock_label_m slm
                   where slm.warehouse_no = strWarehouseNo
                     and slm.enterprise_no = strEnterpriseNo
                     and slm.container_no = v_strDcontainerNo
                     and slm.deliver_obj = v_sDeliverObj)
           where slm.warehouse_no = strWarehouseNo
             and slm.enterprise_no = strEnterpriseNo
             and slm.container_no = v_strDcontainerNo
             and slm.seq_value = 0;

          /*           if sql%rowcount <= 0 then
            strResult := 'N|[E23215]';--更新seq_value失败
            return;
          end if;*/
        end;

        --按波次下的客户产生
      elsif v_strArrangeGetSeqByLocate = '1' then
        begin
          select sld.wave_no
            into v_strWaveNo
            from stock_label_d sld
           where sld.container_no = v_strDcontainerNo
             and sld.warehouse_no = strWarehouseNo
             and sld.enterprise_no = strEnterpriseNo
             and rownum = 1;
        end;

        begin
          update stock_label_m slm
             set slm.seq_value =
                 (select max(slm.seq_value) + 1
                    from stock_label_m slm, stock_label_d sld
                   where slm.container_no = sld.container_no
                     and slm.warehouse_no = strWarehouseNo
                     and slm.enterprise_no = strEnterpriseNo
                     and slm.container_no = v_strDcontainerNo
                     and sld.wave_no = v_strWaveNo
                     and slm.deliver_obj = v_sDeliverObj)
           where slm.warehouse_no = strWarehouseNo
             and slm.enterprise_no = strEnterpriseNo
             and slm.container_no = v_strDcontainerNo
             and slm.seq_value = 0;

          /*            if sql%rowcount <= 0 then
            strResult := 'N|[E23215]';--更新seq_value失败
            return;
          end if;*/
        end;
      end if;
    end if;

    strResult := 'Y|[E23206]'; --标签转移成功

  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_container_arrange;

  /*****************************************************************************************
    功能：校验源容器号是否合法
   Modify By JUN AT 2014-06-03
  用于容器整理中对原容器的校验
   *****************************************************************************************/
  procedure p_check_strScontainerNo(strEnterpriseNo in stock_label_m.enterprise_no%type,
                                    strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                                    strLabelNo      in stock_label_m.label_no%type, --源容器号
                                    strResult       out varchar2) is
    v_nDetailCount      number; --判断是否有明细
    v_sDeliverObj       stock_label_m.deliver_obj%type; --源容器配送对象
    v_sStatus           stock_label_m.status%type; --源容器状态
    v_sUseType          stock_label_m.use_type%type; --源容器标签
    v_sLineNo           stock_label_m.line_no%type; --源容器线路
    v_sContainerNo      stock_label_m.container_no%type;
    v_sOwnerContainerNo stock_label_m.owner_container_no%type;
    v_sOwnerCellNo      stock_label_m.owner_cell_no%type;
    v_areaUseType       cdef_defarea.area_usetype%type;
    v_areaAttribute     cdef_defarea.area_attribute%type;
    v_attributeType     cdef_defarea.attribute_type%type;

  begin
    strResult := 'N|[p_check_strScontainerNo]';

    --获取来源容器的配送对象和状态
    begin
      select slm.deliver_obj,
             slm.status,
             slm.use_type,
             slm.line_no,
             slm.deliver_obj,
             slm.container_no,
             slm.owner_container_no,
             slm.owner_cell_no
        into v_sDeliverObj,
             v_sStatus,
             v_sUseType,
             v_sLineNo,
             v_sDeliverObj,
             v_sContainerNo,
             v_sOwnerContainerNo,
             v_sOwnerCellNo
        from stock_label_m slm
       where slm.warehouse_no = strWarehouseNo
         and slm.enterprise_no = strEnterpriseNo
         and slm.label_no = strLabelNo;
    exception
      when no_data_found then
        strResult := 'N|[E23207]'; --无此容器号
        return;
    end;

    --查询原容器是否有明细
    begin
      select count(1)
        into v_nDetailCount
        from stock_label_d sld
       where sld.enterprise_no = strEnterpriseNo
         and sld.warehouse_no = sld.warehouse_no
         and sld.container_no = v_sContainerNo;
    exception
      when no_data_found then
        strResult := 'N|[E23210]'; --源容器号无明细
        return;
    end;

    --判断是不是处于出货暂存区或发货暂存区
    begin
      select a.area_usetype, a.area_attribute, a.attribute_type
        into v_areaUseType, v_areaAttribute, v_attributeType
        from cdef_defcell c, cdef_defarea a
       where c.warehouse_no = a.warehouse_no
         and c.enterprise_no = a.enterprise_no
         and c.ware_no = a.ware_no
         and c.area_no = a.area_no
         and c.warehouse_no = strWarehouseNo
         and c.enterprise_no = strEnterpriseNo
         and c.cell_no = v_sOwnerCellNo;

    exception
      when no_data_found then
        strResult := 'N|[E23216]'; --标签最后并入储位不对
        return;
    end;

    --判断标签状态在可允许的范围
    if v_sStatus not in (
                         /*      CLabelStatus.PICK_END,*/CLabelStatus.PICK_MOVING,
                         CLabelStatus.RECEIVING,
                         CLabelStatus.DIVIDE_FROM_PAL,
                         CLabelStatus.SORTING_PASS,
                         CLabelStatus.CONFIRM,
                         CLabelStatus.INNER_CHECKING,
                         CLabelStatus.INNER_CHECKED,
                         CLabelStatus.WAIT_OUTER_CHECK,
                         CLabelStatus.OUTER_CHECKED,
                         CLabelStatus.WAIT_TURN_AREA,
                         CLabelStatus.WAIT_LOAD_CAR) then
      strResult := 'N|' || '[' || v_sStatus || '不在可允许范围]'; --标签状态不在可允许的范围
      --strResult:=v_sStatus||'不在可允许的范围';
      return;
    end if;

    if v_sUseType <> 1 then
      strResult := 'N|[E23208]'; --标签状态必须要为客户标签
      return;
    end if;

    if v_sContainerNo <> v_sOwnerContainerNo then
      strResult := 'N|[E23218]'; --不能使用并板标签
      return;
    end if;

    if v_areaAttribute <> '1' or v_areaUseType <> '1' then
      strResult := 'N|[E23219]'; --标签必须处于发货暂存区或发货暂存区
      return;
    end if;

    if v_attributeType not in ('2', '3', '4', '5') then
      strResult := 'N|[E23219]'; --标签必须处于发货暂存区或发货暂存区
      return;
    end if;
    strResult := 'Y|[成功]'; --成功
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_check_strScontainerNo;

  /*****************************************************************************************
   功能：校验源容器号是否可移目的容器号
  Modify By JUN AT 2014-06-03
  取目的标签的波次号改成从标签头档获取 huangb 20160602
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure p_contrast_containerNo(strEnterpriseNo in stock_label_m.enterprise_no%type, --仓别
                                   strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                                   strSLabelNo     in stock_label_m.label_no%type, --源容器号
                                   strDLabelNo     in stock_label_m.label_no%type, --目的容器号
                                   strResult       out varchar2) is
    v_sDeliverObj      stock_label_m.deliver_obj%type; --源容器配送对象
    v_dDeliverObj      stock_label_m.deliver_obj%type; --目的容器配送对象
    v_sStatus          stock_label_m.status%type; --源容器状态
    v_dStatus          stock_label_m.status%type; --目的容器状态
    v_sUseType         stock_label_m.use_type%type; --源容器标签
    v_dUseType         stock_label_m.use_type%type; --目的容器标签
    v_sLineNo          stock_label_m.line_no%type; --源容器线路
    v_dLineNo          stock_label_m.line_no%type; --目的容器线路
    v_dContainerType   stock_label_m.container_type%type; --目的容器类型
    v_sBatchNo         stock_label_m.batch_no%type; --源容器批次
    v_dBatchNo         stock_label_m.batch_no%type; --目的容器批次
    v_sWaveNo          stock_label_d.wave_no%type; --源容器的波此
    v_dWaveNo          stock_label_d.wave_no%type := 'N'; --目的容器的波此
    v_strSourceNo      stock_label_m.source_no%type;
    v_deliverArea      stock_label_m.deliver_area%type;
    v_ownerCellNo      stock_label_m.owner_cell_no%type;
    v_trunckCellNo     stock_label_m.trunck_cell_no%type;
    v_AsorterChuteNo   stock_label_m.a_sorter_chute_no%type;
    v_checkChuteNo     stock_label_m.check_chute_no%type;
    v_rgstName         stock_label_m.rgst_name%type;
    v_reportId         stock_label_m.report_id%type;
    v_ownerContainerNo stock_label_m.owner_container_no%type;
    v_sContainerNo     stock_label_m.container_no%type;
    v_dContainerNo     stock_label_m.container_no%type;

    v_strDeliverObj        stock_label_m.deliver_obj%type;
    v_strCustNo            stock_label_m.cust_no%type;
    v_strOwnerCellNo       stock_label_m.owner_cell_no%type;
    v_nDetailCount         number;
    v_strArrangeCheckBatch varchar2(20);
    v_nArrangeCheckBatch   number(10);
    v_strArrangeCheckWave  varchar2(20);
    v_nArrangeCheckWave    number(10);
    v_strArrangeFixPal     varchar2(20);
    v_nArrangeFixPal       number(10);
    v_strOutMsg            varchar2(256);

    v_strLabelNoTmp   stock_label_m.label_no%type;
    v_strDcontainerNo stock_label_m.container_no%type;
    v_strSessionId    varchar2(256);
    v_strsFlowValue   wms_deflabel_status.flow_value%type;--来源标签工作流范围
    v_strDFlowValue   wms_deflabel_status.flow_value%type;--来源标签工作流范围

  begin

    --源标签号和目的标签号不允许相同
    if strSLabelNo = strDLabelNo then
      strResult := 'N|[E23222]';
      return;
    end if;

    --获取来源容器的配送对象和状态
    begin
      select slm.deliver_obj,
             slm.status,
             slm.use_type,
             slm.line_no,
             slm.deliver_obj,
             slm.cust_no,
             slm.owner_cell_no,
             slm.batch_no,
             slm.source_no,
             slm.deliver_area,
             slm.owner_cell_no,
             slm.trunck_cell_no,
             slm.a_sorter_chute_no,
             slm.check_chute_no,
             slm.rgst_name,
             slm.report_id,
             slm.owner_container_no,
             slm.container_no
        into v_sDeliverObj,
             v_sStatus,
             v_sUseType,
             v_sLineNo,
             v_strDeliverObj,
             v_strCustNo,
             v_strOwnerCellNo,
             v_sBatchNo,
             v_strSourceNo,
             v_deliverArea,
             v_ownerCellNo,
             v_trunckCellNo,
             v_AsorterChuteNo,
             v_checkChuteNo,
             v_rgstName,
             v_reportId,
             v_ownerContainerNo,
             v_sContainerNo
        from stock_label_m slm
       where slm.warehouse_no = strWarehouseNo
         and slm.enterprise_no = strEnterpriseNo
         and slm.label_no = strSLabelNo;
    exception
      when no_data_found then
        strResult := 'N|[E23207]'; --无此容器号
        return;
    end;

    --查询原容器是否有明细
    begin
      select count(1)
        into v_nDetailCount
        from stock_label_d sld
       where sld.enterprise_no = strEnterpriseNo
         and sld.warehouse_no = strWarehouseNo
         and sld.container_no = v_sContainerNo;
    exception
      when no_data_found then
        strResult := 'N|[E23210]'; --源容器号无明细
        return;
    end;

    --获取源容器号的波此号
    begin
      select distinct sld.wave_no
        into v_sWaveNo
        from stock_label_d sld
       where sld.warehouse_no = strWarehouseNo
         and sld.enterprise_no = strEnterpriseNo
         and sld.container_no = v_sContainerNo
         and rownum = 1;
    exception
      when no_data_found then
        strResult := 'N|[E23207]'; --无此容器号
        return;
    end;

    --获取目的容器的配送对象和状态和容器标签和目的容器类型
    begin
      select slm.deliver_obj,
             slm.status,
             slm.use_type,
             slm.container_type,
             slm.line_no,
             slm.batch_no,
             slm.container_no,
             slm.wave_no
        into v_dDeliverObj,
             v_dStatus,
             v_dUseType,
             v_dContainerType,
             v_dLineNo,
             v_dBatchNo,
             v_dContainerNo,
             v_dWaveNo
        from stock_label_m slm
       where slm.warehouse_no = strWarehouseNo
         and slm.enterprise_no = strEnterpriseNo
         and slm.label_no = strDLabelNo;

     --读取来源标签工作流范围
     begin
          select flow_value into v_strsFlowValue from wms_deflabel_status t
          where t.status_type=v_sStatus;
     exception when no_data_found then
          strResult:='N|[读取不到来源标签的工作流范围]';
          return;
     end;

          --读取目的标签工作流范围
     begin
          select flow_value into v_strdFlowValue from wms_deflabel_status t
          where t.status_type=v_dStatus;
     exception when no_data_found then
          strResult:='N|[读取不到目的标签的工作流范围]';
          return;
     end;

     if v_dStatus<>CLabelStatus.NEW_LABEL_NO and v_strdFlowValue<>v_strsFlowValue then
          strResult:='N|[来源标签的工作流范围和目的标签不一致，不能整理]';
          return;
     end if;

      --判断标签状态在可允许的范围
      if v_dStatus not in (
                           /*      CLabelStatus.PICK_END,*/CLabelStatus.PICK_MOVING,
                           CLabelStatus.RECEIVING,
                           CLabelStatus.DIVIDE_FROM_PAL,
                           CLabelStatus.SORTING_PASS,
                           CLabelStatus.CONFIRM,
                           CLabelStatus.INNER_CHECKING,
                           CLabelStatus.INNER_CHECKED,
                           CLabelStatus.WAIT_OUTER_CHECK,
                           CLabelStatus.OUTER_CHECKED,
                           CLabelStatus.WAIT_TURN_AREA,
                           CLabelStatus.NEW_LABEL_NO,
                           CLabelStatus.WAIT_LOAD_CAR) then
        strResult := 'N|' || '[' || v_dStatus || '不在可允许范围]'; --标签状态不在可允许的范围
        --strResult:=v_sStatus||'不在可允许的范围';
        return;
      end if;

      --容器整理时,同一客户不同批次的商品是否可整理到一个容器内。0：不允许；1：允许
      PKLG_WMS_BASE.p_GetBasePara(strEnterpriseNo,
                                  strWareHouseNo,
                                  'N',
                                  'Arrange_CheckBatch',
                                  'O',
                                  'O_ARRANGE',
                                  v_strArrangeCheckBatch,
                                  v_nArrangeCheckBatch,
                                  v_strOutMsg);
      if substr(v_strOutMsg, 1, 1) = 'N' then
        strResult := 'N|[E23214]';
        return;
      end if;

      --获取系统参数
      --容器整理时,不同波次的商品是否可整理到一个容器内。0：不允许；1：允许
      PKLG_WMS_BASE.p_GetBasePara(strEnterpriseNo,
                                  strWareHouseNo,
                                  'N',
                                  'Arrange_CheckWave',
                                  'O',
                                  'O_ARRANGE',
                                  v_strArrangeCheckWave,
                                  v_nArrangeCheckWave,
                                  v_strOutMsg);
      if substr(v_strOutMsg, 1, 1) = 'N' then
        strResult := 'N|[E23214]';
        return;
      end if;

      --获取目的容器号的波此号
      /*if v_dStatus<>CLabelStatus.NEW_LABEL_NO then
          begin
            select distinct sld.wave_no
              into v_dWaveNo
              from stock_label_d sld
             where sld.warehouse_no = strWarehouseNo
               and sld.enterprise_no = strEnterpriseNo
               and sld.container_no = v_dContainerNo
               and rownum = 1;

            exception
              when no_data_found then
                strResult:='N|[E23207]';--无此容器号
                return;
          end;

          if v_strArrangeCheckWave = '0' then
            if v_sWaveNo <> v_dWaveNo then
              strResult:='N|[E23220]';--不同波次的商品不允许整理到一个容器内
            return;
            end if;
          end if;
      end if;*/
      if v_strArrangeCheckWave = '0' then
        if v_sWaveNo <> v_dWaveNo then
          strResult := 'N|[E23220]'; --不同波次的商品不允许整理到一个容器内
          return;
        end if;
      end if;

      --判断来源容器号的配送对象和目的容器号的配送对象是否不一至
      if v_sDeliverObj <> v_dDeliverObj then
        strResult := 'N|[E23201]'; --配送对象不一至
        return;
      else
        if v_strArrangeCheckBatch = '0' then
          if v_sBatchNo <> v_dBatchNo then
            strResult := 'N|[E23221]'; --同一客户不同批次的商品不允许整理到一个容器内
            return;
          end if;
        end if;
      end if;
      if v_sUseType <> 1 or v_dUseType <> 1 then
        strResult := 'N|[E23208]'; --标签状态必须要为客户标签
        return;
      end if;
      if v_sLineNo <> v_dLineNo then
        strResult := 'N|[E23209]'; --源容器线路要与目的容器线路相等
        return;
      end if;

      if v_dContainerType = 'C' then
        strResult := 'N|[E23204]'; --目的容器的容器类型不能等于C
        return;
      end if;
      if v_DStatus = CLabelStatus.PICK_END then
        strResult := 'N|[拣货完成状态可不进行整理]'; --源容器号的状态与目的容器号的状态都不能为6D
        return;
      end if;
      if v_sStatus = CLabelStatus.OUTER_CHECKING or
         v_dStatus = CLabelStatus.OUTER_CHECKING then
        --'6D'
        strResult := 'N|[E23205]'; --源容器号的状态与目的容器号的状态都不能为6D
        return;
      end if;
      if v_sStatus = CLabelStatus.WAIT_TURN_AREA or
         v_dStatus = CLabelStatus.WAIT_TURN_AREA then
        --'90'
        strResult := 'N|[E23223]'; --标签状态不能为已转区
        return;
      end if;
      if v_sStatus = ClabelStatus.LOADED_IN_CAR or
         v_dStatus = ClabelStatus.LOADED_IN_CAR then
        --'A1'
        strResult := 'N|[E23224]'; --标签状态不能为已装车
        return;
      end if;

    exception
      when no_data_found then
        --判断是否可新取号

        --目的容器若在系统不存在，是否需要新产生标签号。0--不产生标签号；1---产品标签
        PKLG_WMS_BASE.p_GetBasePara(strEnterpriseNo,
                                    strWareHouseNo,
                                    'N',
                                    'Arrange_FixPal',
                                    'O',
                                    'O_ARRANGE',
                                    v_strArrangeFixPal,
                                    v_nArrangeFixPal,
                                    v_strOutMsg);
        if substr(v_strOutMsg, 1, 1) = 'N' then
          strResult := 'N|[E23214]';
          return;
        end if;

        if v_strArrangeFixPal = 1 then
          pklg_wms_base.p_get_ContainerNoBase(strEnterpriseNo,
                                              strWarehouseNo,
                                              'P',
                                              '',
                                              'D',
                                              1,
                                              '2',
                                              '31',
                                              v_strLabelNoTmp,
                                              v_strDcontainerNo,
                                              v_strSessionId,
                                              v_strOutMsg);
          if (substr(v_strOutMsg, 1, 1) = 'N') then
            return;
          end if;

          pkobj_label.proc_Insert_LabelMaster(strEnterpriseNo,
                                              strWarehouseNo,
                                              v_sBatchNo,
                                              v_strSourceNo,
                                              strDLabelNo,
                                              v_strDcontainerNo,
                                              'P',
                                              v_deliverArea,
                                              v_ownerCellNo,
                                              v_strCustNo,
                                              v_trunckCellNo,
                                              v_AsorterChuteNo,
                                              v_checkChuteNo,
                                              v_sDeliverObj,
                                              v_sUseType,
                                              v_sLineNo,
                                              'N',
                                              'N',
                                              v_rgstName,
                                              v_reportId,
                                              'N',
                                              'N',
                                              '1',
                                              '0',
                                              v_strDcontainerNo,
                                              ClabelStatus.NEW_LABEL_NO,
                                              '0',
                                              v_sWaveNo,
                                              v_strOutMsg);
          if (substr(v_strOutMsg, 1, 1) = 'N') then
            return;
          end if;

          strResult := 'Y|[成功]';
          return;
        else
          strResult := 'N|[E23207]';
          return;-- huangb 20160813
        end if;

    end;

    strResult := 'Y|[成功]'; --成功
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_contrast_containerNo;

  /*****************************************************************************************
   功能：容器并板前校验
  Modify By JUN AT 2014-06-03
  pragma autonomous_transaction;
  目前用于共速达的拣货回单的容器校验，可支持边拣边整理的情况
  *****************************************************************************************/
  procedure p_check_merge(strEnterpriseNo in stock_label_m.enterprise_no%type, --仓别
                          strWarehouseNo  in stock_label_m.warehouse_no%type,
                          strSLabelNo     in stock_label_m.label_no%type,
                          strDLabelNo     in stock_label_m.label_no%type,
                          strResult       out varchar2) is
    v_sDeliverObj      stock_label_m.deliver_obj%type; --源容器配送对象
    v_dDeliverObj      stock_label_m.deliver_obj%type; --目的容器配送对象
    v_sStatus          stock_label_m.status%type; --源容器状态
    v_dStatus          stock_label_m.status%type; --目的容器状态
    v_sUseType         stock_label_m.use_type%type; --源容器标签
    v_dUseType         stock_label_m.use_type%type; --目的容器标签
    v_sLineNo          stock_label_m.line_no%type; --源容器线路
    v_dLineNo          stock_label_m.line_no%type; --目的容器线路
    v_dContainerType   stock_label_m.container_type%type; --目的容器类型
    v_sBatchNo         stock_label_m.batch_no%type; --源容器批次
    v_dBatchNo         stock_label_m.batch_no%type; --目的容器批次
    v_sWaveNo          stock_label_d.wave_no%type; --源容器的波此
    v_dWaveNo          stock_label_d.wave_no%type; --目的容器的波此
    v_strSourceNo      stock_label_m.source_no%type;
    v_deliverArea      stock_label_m.deliver_area%type;
    v_ownerCellNo      stock_label_m.owner_cell_no%type;
    v_trunckCellNo     stock_label_m.trunck_cell_no%type;
    v_AsorterChuteNo   stock_label_m.a_sorter_chute_no%type;
    v_checkChuteNo     stock_label_m.check_chute_no%type;
    v_rgstName         stock_label_m.rgst_name%type;
    v_reportId         stock_label_m.report_id%type;
    v_ownerContainerNo stock_label_m.owner_container_no%type;
    v_sContainerNo     stock_label_m.container_no%type;
    v_dContainerNo     stock_label_m.container_no%type;

    v_strDeliverObj  stock_label_m.deliver_obj%type;
    v_strCustNo      stock_label_m.cust_no%type;
    v_strOwnerCellNo stock_label_m.owner_cell_no%type;
    v_nDetailCount   number;

    v_strArrangeCheckBatch varchar2(20);
    v_nArrangeCheckBatch   number(10);
    v_strArrangeCheckWave  varchar2(20);
    v_nArrangeCheckWave    number(10);
    v_strArrangeFixPal     varchar2(20);
    v_nArrangeFixPal       number(10);
    v_strOutMsg            varchar2(256);

    v_strLabelNoTmp   stock_label_m.label_no%type;
    v_strDcontainerNo stock_label_m.container_no%type;
    v_strSessionId    varchar2(256);
    v_statusType      wms_deflabel_status.status_type%type;
    v_strAutoFlag     varchar2(10);
    v_strOwner_No     bdef_defowner.owner_no%type;
    v_ExpType         odata_exp_m.exp_type%type;
    v_strsFlowValue   wms_deflabel_status.flow_value%type;--来源标签工作流范围
    v_strDFlowValue   wms_deflabel_status.flow_value%type;--来源标签工作流范围
  begin

    --源标签号和目的标签号不允许相同
    if strSLabelNo = strDLabelNo then
      strResult := 'N|[E23222]';
      return;
    end if;

    --获取来源容器的配送对象和状态
    begin
      select slm.deliver_obj,
             slm.status,
             slm.use_type,
             slm.line_no,
             slm.deliver_obj,
             slm.cust_no,
             slm.owner_cell_no,
             slm.batch_no,
             slm.source_no,
             slm.deliver_area,
             slm.owner_cell_no,
             slm.trunck_cell_no,
             slm.a_sorter_chute_no,
             slm.check_chute_no,
             slm.rgst_name,
             slm.report_id,
             slm.owner_container_no,
             slm.container_no
        into v_sDeliverObj,
             v_sStatus,
             v_sUseType,
             v_sLineNo,
             v_strDeliverObj,
             v_strCustNo,
             v_strOwnerCellNo,
             v_sBatchNo,
             v_strSourceNo,
             v_deliverArea,
             v_ownerCellNo,
             v_trunckCellNo,
             v_AsorterChuteNo,
             v_checkChuteNo,
             v_rgstName,
             v_reportId,
             v_ownerContainerNo,
             v_sContainerNo
        from stock_label_m slm
       where slm.warehouse_no = strWarehouseNo
         and slm.enterprise_no = strEnterpriseNo
         and slm.label_no = strSLabelNo;
    exception
      when no_data_found then
        strResult := 'N|[E23207]'; --无此容器号
        return;
    end;

    --查询原容器是否有明细
    begin
      select count(1)
        into v_nDetailCount
        from stock_label_d sld
       where sld.enterprise_no = strEnterpriseNo
         and sld.warehouse_no = strWarehouseNo
         and sld.container_no = v_sContainerNo;
    exception
      when no_data_found then
        strResult := 'N|[E23210]'; --源容器号无明细
        return;
    end;

    --获取源容器号的波此号
    begin
      select distinct sld.wave_no, sld.owner_no, sld.exp_type
        into v_sWaveNo, v_strOwner_No, v_ExpType
        from stock_label_d sld
       where sld.warehouse_no = strWarehouseNo
         and sld.enterprise_no = strEnterpriseNo
         and sld.container_no = v_sContainerNo
         and rownum = 1;
    exception
      when no_data_found then
        strResult := 'N|[E23207]'; --无此容器号
        return;
    end;

    --获取目的标签信息

    --获取目的容器的配送对象和状态和容器标签和目的容器类型
    begin
      select slm.deliver_obj,
             slm.status,
             slm.use_type,
             slm.container_type,
             slm.line_no,
             slm.batch_no,
             slm.container_no
        into v_dDeliverObj,
             v_dStatus,
             v_dUseType,
             v_dContainerType,
             v_dLineNo,
             v_dBatchNo,
             v_dContainerNo
        from stock_label_m slm
       where slm.warehouse_no = strWarehouseNo
         and slm.enterprise_no = strEnterpriseNo
         and slm.label_no = strDLabelNo;

       --读取来源标签工作流范围
       begin
            select flow_value into v_strsFlowValue from wms_deflabel_status t
            where t.status_type=v_sStatus;
       exception when no_data_found then
            strResult:='N|[读取不到来源标签的工作流范围]';
            return;
       end;

            --读取目的标签工作流范围
       begin
            select flow_value into v_strdFlowValue from wms_deflabel_status t
            where t.status_type=v_dStatus;
       exception when no_data_found then
            strResult:='N|[读取不到目的标签的工作流范围]';
            return;
       end;

       if v_dStatus<>CLabelStatus.NEW_LABEL_NO and v_strdFlowValue<>v_strsFlowValue then
            strResult:='N|[来源标签的工作流范围和目的标签不一致，不能整理]';
            return;
       end if;
    exception
      when no_data_found then


        --判断标签状态在可允许的范围
        if v_dStatus not in (
                             /*      CLabelStatus.PICK_END,*/CLabelStatus.PICK_MOVING,
                             CLabelStatus.RECEIVING,
                             CLabelStatus.DIVIDE_FROM_PAL,
                             CLabelStatus.SORTING_PASS,
                             CLabelStatus.CONFIRM,
                             CLabelStatus.INNER_CHECKING,
                             CLabelStatus.INNER_CHECKED,
                             CLabelStatus.WAIT_OUTER_CHECK,
                             CLabelStatus.OUTER_CHECKED,
                             CLabelStatus.WAIT_TURN_AREA,
                             CLabelStatus.WAIT_LOAD_CAR) then
          strResult := 'N|' || '[' || v_dStatus || '不在可允许范围]'; --标签状态不在可允许的范围
          --strResult:=v_sStatus||'不在可允许的范围';
          return;
        end if;

        --目的容器若在系统不存在，是否需要新产生标签号。0--不产生标签号；1---产品标签
        PKLG_WMS_BASE.p_GetBasePara(strEnterpriseNo,
                                    strWareHouseNo,
                                    'N',
                                    'Arrange_FixPal',
                                    'O',
                                    'O_ARRANGE',
                                    v_strArrangeFixPal,
                                    v_nArrangeFixPal,
                                    v_strOutMsg);
        if substr(v_strOutMsg, 1, 1) = 'N' then
          strResult := 'N|[E23214]';
          return;
        end if;

        if v_strArrangeFixPal = 1 then
          --需要新取号
          pklg_wms_base.p_get_ContainerNoBase(strEnterpriseNo,
                                              strWarehouseNo,
                                              'P',
                                              v_rgstName,
                                              'D',
                                              1,
                                              '2',
                                              '31',
                                              v_strLabelNoTmp,
                                              v_strDcontainerNo,
                                              v_strSessionId,
                                              v_strOutMsg);
          if (substr(v_strOutMsg, 1, 1) = 'N') then
            return;
          end if;

          pkobj_label.proc_Insert_LabelMaster(strEnterpriseNo,
                                              strWarehouseNo,
                                              v_sBatchNo,
                                              v_strSourceNo,
                                              strDLabelNo,
                                              v_strDcontainerNo,
                                              'P',
                                              v_deliverArea,
                                              v_ownerCellNo,
                                              v_strCustNo,
                                              v_trunckCellNo,
                                              v_AsorterChuteNo,
                                              v_checkChuteNo,
                                              v_sDeliverObj,
                                              v_sUseType,
                                              v_sLineNo,
                                              'N',
                                              'N',
                                              v_rgstName,
                                              v_reportId,
                                              'N',
                                              'N',
                                              '1',
                                              '0',
                                              v_strDcontainerNo,
                                              ClabelStatus.NEW_LABEL_NO, --CLABELSTATUS.RECEIVING,改于20140627 因工作流未完成 暂时写死
                                              '0',
                                              v_sWaveNo,
                                              v_strOutMsg);
          if (substr(v_strOutMsg, 1, 1) = 'N') then
            return;
          end if;
          strResult := 'Y|[成功]';
          return;
        end if;
    end;

    --容器整理时,同一客户不同批次的商品是否可整理到一个容器内。0：不允许；1：允许
    PKLG_WMS_BASE.p_GetBasePara(strEnterpriseNo,
                                strWareHouseNo,
                                'N',
                                'Arrange_CheckBatch',
                                'O',
                                'O_ARRANGE',
                                v_strArrangeCheckBatch,
                                v_nArrangeCheckBatch,
                                v_strOutMsg);
    if substr(v_strOutMsg, 1, 1) = 'N' then
      strResult := 'N|[E23214]';
      return;
    end if;

    --获取系统参数
    --容器整理时,不同波次的商品是否可整理到一个容器内。0：不允许；1：允许
    PKLG_WMS_BASE.p_GetBasePara(strEnterpriseNo,
                                strWareHouseNo,
                                'N',
                                'Arrange_CheckWave',
                                'O',
                                'O_ARRANGE',
                                v_strArrangeCheckWave,
                                v_nArrangeCheckWave,
                                v_strOutMsg);
    if substr(v_strOutMsg, 1, 1) = 'N' then
      strResult := 'N|[E23214]';
      return;
    end if;

    if v_dStatus <> ClabelStatus.NEW_LABEL_NO then
      --获取目的容器号的波此号
      begin
        select distinct sld.wave_no
          into v_dWaveNo
          from stock_label_d sld
         where sld.warehouse_no = strWarehouseNo
           and sld.enterprise_no = strEnterpriseNo
           and sld.container_no = v_dContainerNo
           and rownum = 1;
      exception
        when no_data_found then
          strResult := 'N|[E23207]'; --无此容器号
          return;
      end;

      if v_strArrangeCheckWave = '0' then
        if v_sWaveNo <> v_dWaveNo then
          strResult := 'N|[E23220]'; --不同波次的商品不允许整理到一个容器内
          return;
        end if;
      end if;

      --判断来源容器号的配送对象和目的容器号的配送对象是否不一至
      if v_sDeliverObj <> v_dDeliverObj then
        strResult := 'N|[E23201]'; --配送对象不一至
        return;
      end if;
      if v_sUseType <> 1 or v_dUseType <> 1 then
        strResult := 'N|[E23208]'; --标签状态必须要为客户标签
        return;
      end if;
      if v_sLineNo <> v_dLineNo then
        strResult := 'N|[E23209]'; --源容器线路要与目的容器线路相等
        return;
      end if;
      if v_dContainerType = 'C' then
        strResult := 'N|[E23204]'; --目的容器的容器类型不能等于C
        return;
      end if;

      if v_sStatus = CLabelStatus.OUTER_CHECKING or
         v_dStatus = CLabelStatus.OUTER_CHECKING then
        --'6D'
        strResult := 'N|[E23205]'; --源容器号的状态与目的容器号的状态都不能为6D
        return;
      end if;
    end if;

    if v_dStatus not in (Clabelstatus.PICK_HAND_OUT, --50
                         Clabelstatus.PICK_END, --52
                         Clabelstatus.RECEIVING, --61
                         Clabelstatus.WAIT_LOAD_CAR,
                         ClabelStatus.NEW_LABEL_NO) then
      --A0
      strResult := v_dStatus || '[E23225]';
      return;
    end if;

    PKOBJ_HB.p_GetLabelStatusFromWorkflow(strEnterPriseNo,
                                          strWarehouseNo,
                                          v_strOwner_No,
                                          v_ExpType,
                                          v_sContainerNo,
                                          v_statusType,
                                          v_strAutoFlag,
                                          v_strOutMsg);
    if substr(v_strOutMsg, 1, 1) = 'N' then
      strResult := 'N|[找不到工作流配置]';
      return;
    end if;

    if v_dStatus <> Clabelstatus.NEW_LABEL_NO and
       ((v_dStatus < '60' and v_dStatus <> v_statusType) or
       (v_dStatus >= '60' and v_dStatus <> v_sStatus)) then
      --如果目的标签状态不等于工作流状态
      strResult := 'N|[E23227]';
      return;
    end if;

    strResult := 'Y|[成功]'; --成功
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_check_merge;
  /*****************************************************************************************
   功能：容器并板，整板转移
  Modify By JUN AT 2014-06-03
  pragma autonomous_transaction;
  用于共速达的边拣货边整理
  *****************************************************************************************/
  procedure p_merge_container(strEnterpriseNo in stock_label_m.enterprise_no%type,
                              strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                              strScontainerNo in stock_label_m.container_no%type, --源容器号
                              strDcontainerNo in stock_label_m.container_no%type, --目的容器号
                              strArticleNo    in stock_label_d.article_no%type, --商品编码
                              nPackingQty     in stock_label_d.packing_qty%type, --商品包装
                              nMoveQty        in stock_label_d.qty%type, --移动数量
                              strQuality      in stock_article_info.quality%type, --品质
                              dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                              dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                              strLotNo        in stock_article_info.lot_no%type, --批号
                              strRsvBatch1    in stock_article_info.rsv_batch1%type, --预留批属性1
                              strRsvBatch2    in stock_article_info.rsv_batch2%type, --预留批属性2
                              strRsvBatch3    in stock_article_info.rsv_batch3%type, --预留批属性3
                              strRsvBatch4    in stock_article_info.rsv_batch4%type, --预留批属性4
                              strRsvBatch5    in stock_article_info.rsv_batch5%type, --预留批属性5
                              strRsvBatch6    in stock_article_info.rsv_batch6%type, --预留批属性6
                              strRsvBatch7    in stock_article_info.rsv_batch7%type, --预留批属性7
                              strRsvBatch8    in stock_article_info.rsv_batch8%type, --预留批属性8
                              strUserId       in stock_label_m.rgst_name%type, --操作人员
                              strTerminalFlag in varchar2, --操作设备
                              strResult       out varchar2) is
    v_nCount         number(10); --记录数，以做判断;
    v_sDeliverObj    stock_label_m.deliver_obj%type; --源容器配送对象
    v_dDeliverObj    stock_label_m.deliver_obj%type; --目的容器配送对象
    v_sStatus        stock_label_m.status%type; --源容器状态
    v_dStatus        stock_label_m.status%type; --目的容器状态
    v_sUseType       stock_label_m.use_type%type; --源容器标签
    v_dUseType       stock_label_m.use_type%type; --目的容器标签
    v_sLineNo        stock_label_m.line_no%type; --源容器线路
    v_dLineNo        stock_label_m.line_no%type; --目的容器线路
    v_dContainerType stock_label_m.container_type%type; --目的容器类型
    v_strArrangeNo   stock_label_move_log.arrange_no%type; --整理单号
    v_strContainerNo stock_label_m.container_no%type; --容器号
    v_strLabelNo     stock_label_m.label_no%type; --板号
    v_strStockValue  stock_content.stock_value%type;
    v_strCellId      stock_content.cell_id%type;
    v_nAllQty        stock_label_d.qty%type; --总量
    v_nContainerQty  stock_label_d.qty%type; --中间量
    v_nTmpQty        stock_label_d.qty%type; --中间量
    v_strWaveNo      stock_label_d.wave_no%type;

    v_strOwner_No bdef_defowner.owner_no%type;
    v_ExpType     odata_exp_m.exp_type%type;
    v_statusType  wms_deflabel_status.status_type%type;

    v_strTrunckCellNo   stock_label_m.trunck_cell_no%type;
    v_strAsorterChuteNo stock_label_m.a_sorter_chute_no%type;
    v_strDeliverObj     stock_label_m.deliver_obj%type;
    v_strDeliverArea    stock_label_m.deliver_area%type;
    v_strCustNo         stock_label_m.cust_no%type;
    v_strOwnerCellNo    stock_label_m.owner_cell_no%type;
    v_strUserId         stock_label_m.rgst_name%type;
    v_strSourceNo       stock_label_m.source_no%type;

    v_strArrangeGetSeqByLocate varchar2(20);
    v_nArrangeGetSeqByLocate   varchar2(20);
    v_outMsg                   varchar2(255);
    v_strAutoFlag              varchar2(10);
  begin
    strResult := 'N|[p_merge_container]';

    --获取出货暂存区储位
    begin
      select cd.cell_no
        into v_strOwnerCellNo
        from cdef_defcell cd, cdef_defarea t
       where cd.warehouse_no = t.warehouse_no
         and cd.enterprise_no = t.enterprise_no
         and cd.ware_no = t.ware_no
         and cd.area_no = t.area_no
         and cd.warehouse_no = strWarehouseNo
         and cd.enterprise_no = strEnterpriseNo
         and t.area_usetype = '1'
         and t.AREA_ATTRIBUTE = '1'
         and t.ATTRIBUTE_TYPE = '2'
         and rownum = 1;
    exception
      when no_data_found then
        strResult := 'N|[E23228]'; --无此容器号
        return;
    end;

    --获取来源容器的配送对象和状态
    begin
      select distinct slm.deliver_obj,
                      slm.status,
                      slm.use_type,
                      slm.line_no,
                      slm.trunck_cell_no,
                      slm.a_sorter_chute_no,
                      slm.deliver_obj,
                      slm.deliver_area,
                      slm.cust_no,
                      slm.rgst_name,
                      slm.source_no,
                      d.owner_no,
                      d.exp_type
        into v_sDeliverObj,
             v_sStatus,
             v_sUseType,
             v_sLineNo,
             v_strTrunckCellNo,
             v_strAsorterChuteNo,
             v_strDeliverObj,
             v_strDeliverArea,
             v_strCustNo,
             v_strUserId,
             v_strSourceNo,
             v_strOwner_No,
             v_ExpType
        from stock_label_m slm, stock_label_d d
       where slm.warehouse_no = strWarehouseNo
         and slm.enterprise_no = strEnterpriseNo
         and slm.container_no = strScontainerNo
         and slm.enterprise_no = d.enterprise_no
         and slm.warehouse_no = d.warehouse_no
         and slm.container_no = d.container_no;
    exception
      when no_data_found then
        strResult := 'N|[E23207]'; --无此容器号
        return;
    end;

    if v_sStatus < '60' then

      PKOBJ_HB.p_GetLabelStatusFromWorkflow(strEnterPriseNo,
                                            strWarehouseNo,
                                            v_strOwner_No,
                                            v_ExpType,
                                            strScontainerNo,
                                            v_statusType,
                                            v_strAutoFlag,
                                            strResult);
      if substr(strResult, 1, 1) = 'N' then
        strResult := 'N|[找不到工作流配置]';
        return;
      end if;
    else
      v_statusType := v_sStatus;
    end if;

    --获取目的容器的配送对象和状态和容器标签和目的容器类型
    begin
      select slm.deliver_obj,
             slm.status,
             slm.use_type,
             slm.container_type,
             slm.line_no
        into v_dDeliverObj,
             v_dStatus,
             v_dUseType,
             v_dContainerType,
             v_dLineNo
        from stock_label_m slm
       where slm.warehouse_no = strWarehouseNo
         and slm.enterprise_no = strEnterpriseNo
         and slm.container_no = strDcontainerNo;
    exception
      when no_data_found then
        strResult := 'N|[E23207]'; --无此容器号
        return;
    end;

    if v_dStatus <> Clabelstatus.NEW_LABEL_NO and
       ((v_dStatus < '60' and v_dStatus <> v_statusType) or
       (v_dStatus >= '60' and v_dStatus <> v_sStatus)) then
      --如果目的标签状态不等于工作流状态
      strResult := 'N|[E23227]';
      return;
    end if;

    --获取整理单号
    PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                               strWarehouseNo,
                               CONST_DOCUMENTTYPE.ODATACT,
                               v_strArrangeNo,
                               v_OutMsg);
    if substr(v_OutMsg, 1, 1) <> 'Y' then
      strResult := v_OutMsg;
      return;
    end if;

    --根据单号把记录写进stock_label_move_log表
    if nMoveQty <> 0 then
      --不等于0 等于零散移
      v_nCount        := 0;
      v_nAllQty       := nMoveQty;
      v_nContainerQty := 0;
      v_nTmpQty       := 0;
      for i_Label_Detail in (select sld.*
                               from stock_label_d      sld,
                                    stock_article_info sai
                              where sld.article_no = sai.article_no
                                and sld.enterprise_no = strEnterpriseNo
                                and sld.enterprise_no = sai.enterprise_no
                                and sld.article_no = strArticleNo
                                and sld.packing_qty = nPackingQty
                                and sld.article_id = sai.article_id
                                and sld.container_no = strScontainerNo
                                and sai.quality = strQuality
                                and sai.produce_date = dtProduceDate
                                and sai.expire_date = dtExpireDate
                                and sai.lot_no = strLotNo
                                and sai.rsv_batch1 = strRsvBatch1
                                and sai.rsv_batch2 = strRsvBatch2
                                and sai.rsv_batch3 = strRsvBatch3
                                and sai.rsv_batch4 = strRsvBatch4
                                and sai.rsv_batch5 = strRsvBatch5
                                and sai.rsv_batch6 = strRsvBatch6
                                and sai.rsv_batch7 = strRsvBatch7
                                and sai.rsv_batch8 = strRsvBatch8
                                and sld.status >= CLabelStatus.PICK_END) loop

        v_nContainerQty := i_Label_Detail.Qty;
        v_nCount        := v_nCount + 1;

        if v_nAllQty > v_nContainerQty then
          v_nTmpQty := v_nContainerQty;
        else
          v_nTmpQty := v_nAllQty;
        end if;
        insert into stock_label_move_log
          (warehouse_no,
           arrange_no,
           row_id,
           s_container_no,
           d_container_no,
           batch_no,
           owner_no,
           source_no,
           article_no,
           article_id,
           packing_qty,
           move_qty,
           exp_no,
           wave_no,
           cust_no,
           sub_cust_no,
           line_no,
           divide_id,
           exp_type,
           rgst_name,
           rgst_date,
           enterprise_no)
          select strWarehouseNo,
                 v_strArrangeNo,
                 sld.row_id,
                 strScontainerNo,
                 strDcontainerNo,
                 sld.batch_no,
                 sld.owner_no,
                 sld.source_no,
                 sld.article_no,
                 sld.article_id,
                 sld.packing_qty,
                 v_nTmpQty,
                 sld.exp_no,
                 sld.wave_no,
                 sld.cust_no,
                 sld.sub_cust_no,
                 sld.line_no,
                 sld.divide_id,
                 sld.exp_type,
                 strUserId,
                 sysdate,
                 strEnterpriseNo
            from stock_label_d sld
           where sld.warehouse_no = strWarehouseNo
             and sld.enterprise_no = strEnterpriseNo
             and sld.container_no = strScontainerNo
             and sld.article_no = i_Label_Detail.Article_No
             and sld.article_id = i_Label_Detail.Article_Id
             and sld.divide_id = i_Label_Detail.Divide_Id
             and sld.row_id = i_Label_Detail.Row_Id;

        if sql%rowcount <= 0 then
          strResult := 'N|[E23211]'; --插入明细失败
          return;
        end if;
        v_nAllQty := v_nAllQty - v_nTmpQty;

        if v_nAllQty <= 0 then
          exit;
        end if;
      end loop;

      if v_nCount = 0 then
        strResult := 'N|[E23212]'; --找不到容器明细
        return;
      end if;
    else
      --等于0  等于整板移
      insert into stock_label_move_log
        (warehouse_no,
         arrange_no,
         row_id,
         s_container_no,
         d_container_no,
         batch_no,
         owner_no,
         source_no,
         article_no,
         article_id,
         packing_qty,
         move_qty,
         exp_no,
         wave_no,
         cust_no,
         sub_cust_no,
         line_no,
         divide_id,
         exp_type,
         rgst_name,
         rgst_date,
         enterprise_no)
        select strWarehouseNo,
               v_strArrangeNo,
               sld.row_id,
               strScontainerNo,
               strDcontainerNo,
               sld.batch_no,
               sld.owner_no,
               sld.source_no,
               sld.article_no,
               sld.article_id,
               sld.packing_qty,
               sld.qty,
               sld.exp_no,
               sld.wave_no,
               sld.cust_no,
               sld.sub_cust_no,
               sld.line_no,
               sld.divide_id,
               sld.exp_type,
               strUserId,
               sysdate,
               strEnterpriseNo
          from stock_label_d sld
         where sld.warehouse_no = strWarehouseNo
           and sld.enterprise_no = strEnterpriseNo
           and sld.container_no = strScontainerNo;
      if sql%rowcount <= 0 then
        strResult := 'N|[E23211]'; --插入明细失败
        return;
      end if;
    end if;

    --循环整理单明细
    for i_MoveLabel_Info in (select slml.*,
                                    slm.container_type,
                                    slm.label_no       as s_label_no,
                                    dlm.label_no       as d_label_no,
                                    dlm.stock_type,
                                    slm.hm_manual_flag
                               from stock_label_move_log slml,
                                    stock_label_m        slm,
                                    stock_label_m        dlm
                              where slml.warehouse_no = slm.warehouse_no
                                and slml.enterprise_no = slm.enterprise_no
                                and slml.s_container_no = slm.container_no
                                and slml.warehouse_no = dlm.warehouse_no
                                and slml.d_container_no = dlm.container_no
                                and slml.arrange_no = v_strArrangeNo
                                and slml.enterprise_no = strEnterpriseNo) loop
      v_nCount := 1;
      -------------------是否储位库存，------------------------------
      if i_MoveLabel_Info.hm_manual_flag = '1' then
        v_strContainerNo := 'N'; --储位库存
        v_strLabelNo     := 'N'; --储位库存
      else
        v_strContainerNo := i_MoveLabel_Info.s_Container_No; --标签库存
        v_strLabelNo     := i_MoveLabel_Info.s_Label_No; --标签库存
      end if;
      if (i_MoveLabel_Info.Stock_Type = 2) then
        --客户别数据 库存表需要写n_Stock_Value值
        v_strStockValue := i_MoveLabel_Info.Cust_No;
      else
        v_strStockValue := 'N';
      end if;

      --增加目的库存 没有预上数量
      PKOBJ_STOCK.p_InstContent_qtyByCellNo(i_MoveLabel_Info.Enterprise_No,
                                            i_MoveLabel_Info.Warehouse_No, --仓别
                                            i_MoveLabel_Info.Owner_No, --货主
                                            'N', --部门
                                            i_MoveLabel_Info.Article_No, --商品编码
                                            i_MoveLabel_Info.Article_Id, --商品ID
                                            v_strOwnerCellNo, --目的储位
                                            v_strOwnerCellNo, --源储位
                                            i_MoveLabel_Info.Packing_Qty, --包装数量
                                            i_MoveLabel_Info.Move_Qty, --转移数量
                                            i_MoveLabel_Info.d_Label_No, --目的标签
                                            i_MoveLabel_Info.d_Label_No, --目的标签
                                            i_MoveLabel_Info.Stock_Type, --存储类型
                                            v_strStockValue, --存储类型的值
                                            strUserId, --操作人
                                            v_strArrangeNo, --整理单号
                                            strTerminalFlag, --操作工具
                                            0, --是否可手工移库 0:不允许手工移库；1：可手工移库
                                            v_strCellId, --返回的储位ID
                                            v_outMsg --返回的结果
                                            );
      if (substr(v_OutMsg, 1, 1) <> 'Y') then
        strResult := v_OutMsg;
        return;
      end if;

      --扣减源库存 循环扣减, 不处理预约上下架量，直接扣减库存
      PKOBJ_STOCK.p_UpdtContent_qtyByCellNo(i_MoveLabel_Info.Enterprise_No,
                                            i_MoveLabel_Info.Warehouse_No, --仓别
                                            i_MoveLabel_Info.Owner_No, --货主
                                            i_MoveLabel_Info.Article_No, --商品编码
                                            i_MoveLabel_Info.Article_Id, --商品ID
                                            v_strOwnerCellNo, --源储位
                                            v_strOwnerCellNo, --目的储位
                                            i_MoveLabel_Info.Packing_Qty, --包装数量
                                            i_MoveLabel_Info.Move_Qty, --转移数量
                                            i_MoveLabel_Info.s_Label_No, --源标签
                                            i_MoveLabel_Info.Stock_Type, --存储类型
                                            v_strStockValue, --存储类型的值
                                            strUserId, --操作人
                                            v_strArrangeNo, --整理单号
                                            strTerminalFlag, --操作工具
                                            v_outMsg); --返回结果
      if (substr(v_OutMsg, 1, 1) <> 'Y') then
        strResult := v_OutMsg;
        return;
      end if;

    end loop;
    --标签转移
    PKOBJ_LABEL.proc_OM_ArrangeMoveLabelInfo(strEnterpriseNo,
                                             strWarehouseNo, --仓别
                                             v_strArrangeNo, --整理单号
                                             strUserId, --操作人
                                             v_outMsg); --返回结果
    if (substr(v_OutMsg, 1, 1) <> 'Y') then
      strResult := v_OutMsg;
      return;
    end if;

    if v_dStatus = CLabelStatus.NEW_LABEL_NO then
      update stock_label_m slm
         set slm.trunck_cell_no    = v_strTrunckCellNo,
             slm.a_sorter_chute_no = v_strAsorterChuteNo,
             slm.deliver_obj       = v_strDeliverObj,
             slm.deliver_area      = v_strDeliverArea,
             slm.cust_no           = v_strCustNo,
             slm.owner_cell_no     = v_strOwnerCellNo,
             slm.line_no           = v_sLineNo,
             slm.rgst_name         = v_strUserId,
             slm.source_no         = v_strSourceNo,
             slm.status            = v_statusType
       where slm.warehouse_no = strWarehouseNo
         and slm.enterprise_no = strEnterpriseNo
         and slm.container_no = strDcontainerNo;

      update stock_label_d sld
         set sld.status = v_statusType
       where sld.warehouse_no = strWarehouseNo
         and sld.enterprise_no = strEnterpriseNo
         and sld.container_no = strDcontainerNo;
    end if;

    --销毁空标签头 容器整理使用
    PKOBJ_LABEL.proc_OM_Destory_NullLabel(strEnterpriseNo,
                                          strWarehouseNo, --仓别
                                          strScontainerNo, --容器号
                                          strUserId, --操作人
                                          v_outMsg --返回结果
                                          );
    if (substr(v_OutMsg, 1, 1) <> 'Y') then
      strResult := v_OutMsg;
      return;
    end if;

    --转历史
    begin
      insert into stock_label_move_loghty
        (warehouse_no,
         arrange_no,
         row_id,
         s_container_no,
         d_container_no,
         batch_no,
         owner_no,
         source_no,
         article_no,
         article_id,
         packing_qty,
         move_qty,
         exp_no,
         wave_no,
         cust_no,
         sub_cust_no,
         line_no,
         divide_id,
         exp_type,
         rgst_name,
         rgst_date,
         enterprise_no)
        select *
          from stock_label_move_log slml
         where slml.warehouse_no = strWarehouseNo
           and slml.enterprise_no = strEnterpriseNo
           and slml.arrange_no = v_strArrangeNo;

      if sql%rowcount <= 0 then
        strResult := 'N|[E23213]'; --插入历史表失败
        return;
      end if;
    end;

    delete stock_label_move_log slml
     where slml.warehouse_no = strWarehouseNo
       and slml.arrange_no = v_strArrangeNo;

    --获取系统参数
    --内复核、出货整理标签产生配送对象的序列号的级别系统参数(0：按客户产生，1：按波次下的客户产生)
    PKLG_WMS_BASE.p_GetBasePara(strEnterpriseNo,
                                strWareHouseNo,
                                'N',
                                'Arrange_GetSeqByLocate',
                                'O',
                                'O_ARRANGE',
                                v_strArrangeGetSeqByLocate,
                                v_nArrangeGetSeqByLocate,
                                v_outMsg);
    if substr(v_outMsg, 1, 1) = 'N' then
      strResult := 'N|[E23214]'; --找不到系统参数
      return;
    end if;

    if v_dContainerType = 'B' then
      --0：按客户产生
      if v_strArrangeGetSeqByLocate = '0' then
        begin
          update stock_label_m slm
             set slm.seq_value =
                 (select max(slm.seq_value) + 1
                    from stock_label_m slm
                   where slm.warehouse_no = strWarehouseNo
                     and slm.enterprise_no = strEnterpriseNo
                     and slm.container_no = strDcontainerNo
                     and slm.deliver_obj = v_dDeliverObj)
           where slm.warehouse_no = strWarehouseNo
             and slm.enterprise_no = strEnterpriseNo
             and slm.container_no = strDcontainerNo
             AND slm.seq_value = 0;

          if sql%rowcount <= 0 then
            strResult := 'N|[E23215]'; --更新seq_value失败
            return;
          end if;
        end;

        --按波次下的客户产生
      elsif v_strArrangeGetSeqByLocate = '1' then
        begin
          select sld.wave_no
            into v_strWaveNo
            from stock_label_d sld
           where sld.container_no = strDcontainerNo
             and sld.warehouse_no = strWarehouseNo
             and sld.enterprise_no = strEnterpriseNo
             and rownum = 1;
        end;

        begin
          update stock_label_m slm
             set slm.seq_value =
                 (select max(slm.seq_value) + 1
                    from stock_label_m slm, stock_label_d sld
                   where slm.container_no = sld.container_no
                     and slm.warehouse_no = strWarehouseNo
                     and slm.enterprise_no = strEnterpriseNo
                     and slm.container_no = strDcontainerNo
                     and sld.wave_no = v_strWaveNo
                     and slm.deliver_obj = v_dDeliverObj)
           where slm.warehouse_no = strWarehouseNo
             and slm.enterprise_no = strEnterpriseNo
             and slm.container_no = strDcontainerNo
             and slm.seq_value = 0;

          if sql%rowcount <= 0 then
            strResult := 'N|[E23215]'; --更新seq_value失败
            return;
          end if;
        end;
      end if;
    end if;

    strResult := 'Y|[成功]'; --标签转移成功

  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_merge_container;

  /*****************************************************************************************
   功能：出货整理新取标签号码
  Modify By lich AT 2014-11-07
  *****************************************************************************************/

  procedure p_getnew_containerNo(strEnterpriseNo  in stock_label_m.enterprise_no%type,
                                 strWarehouseNo   in stock_label_m.warehouse_no%type, --仓别
                                 strSLabelNo      in stock_label_m.label_no%type, --源容器号
                                 strContainerType in stock_label_m.container_type%type, ----P：栈板；B物流箱
                                 strUserId        in bdef_defworker.worker_no%type,
                                 strDLabelNo      out stock_label_m.label_no%type, --目的容器号
                                 strResult        out varchar2) is
    v_strDcontainerNo      stock_label_m.container_no%type;
    v_strSessionId         varchar2(256);
    v_iCount               integer;
    v_strContainerMaterial wms_defcontainer.container_material%type;
  begin
    v_icount := 0;
    if strContainerType = 'P' then
      v_strContainerMaterial := '31';
    end if;
    if strContainerType = 'B' then
      v_strContainerMaterial := '11';
    end if;

    for P in (select *
                from stock_label_m m
               where m.warehouse_no = strWareHouseNo
                 and m.enterprise_no = strEnterpriseNo
                 and m.label_no = strSLabelNo
                 and rownum < 2) loop
      v_icount := v_icount + 1;
      --取标签号
      pklg_wms_base.p_get_ContainerNoBase(strEnterpriseNo,
                                          strWarehouseNo,
                                          strContainerType,
                                          strUserId,
                                          'D',
                                          1,
                                          '2',
                                          v_strContainerMaterial,
                                          strDLabelNo,
                                          v_strDcontainerNo,
                                          v_strSessionId,
                                          strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
      --写标签头档
      pkobj_label.proc_Insert_LabelMaster(strEnterpriseNo,
                                          strWarehouseNo,
                                          p.batch_no,
                                          p.source_no,
                                          strDLabelNo,
                                          v_strDcontainerNo,
                                          strContainerType,
                                          p.deliver_area,
                                          p.owner_cell_no,
                                          p.cust_no,
                                          p.trunck_cell_no,
                                          p.a_sorter_chute_no,
                                          p.check_chute_no,
                                          p.deliver_obj,
                                          p.use_type,
                                          p.line_no,
                                          'N',
                                          'N',
                                          strUserId,
                                          p.report_id,
                                          'N',
                                          'N',
                                          '1',
                                          '0',
                                          v_strDcontainerNo,
                                          ClabelStatus.NEW_LABEL_NO,
                                          '0',
                                          P.WAVE_NO,
                                          strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
    end loop;

    if v_iCount = 0 then
      strResult := 'N|[E23207]'; --无此容器号
      return;
    end if;

    strResult := 'Y|[成功]'; --成功
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_getnew_containerNo;

  /*****************************************************************************************
   功能：用于电商复核打包的取标签号（电商特殊功能，一复核单对应多个配送对象，按复核标签明细的信息产生标签号

  20160605
  *****************************************************************************************/

  procedure P_DeliverObjLableNo(strEnterpriseNo  in stock_label_m.enterprise_no%type,
                                strWarehouseNo   in stock_label_m.warehouse_no%type, --仓别
                                strCheckNo       in stock_label_m.label_no%type, --源容器号
                                strDeliverObj    in stock_label_m.deliver_obj%type,
                                strContainerType in stock_label_m.container_type%type, ----P：栈板；B物流箱
                                strUserId        in bdef_defworker.worker_no%type,
                                strResult        out varchar2) is
    v_strDcontainerNo      stock_label_m.container_no%type;
    v_strSessionId         varchar2(256);
    v_iCount               integer := 0;
    v_strContainerMaterial wms_defcontainer.container_material%type;
    v_strReportId          job_printtask_m.report_id%type;
    v_strLabelNo           stock_label_m.label_no%type;
  begin
    select count(1)
      into v_iCount
      from stock_label_m slm
     where slm.source_no = strCheckNo
       and slm.deliver_obj = strDeliverObj
       and slm.enterprise_no = strEnterpriseNo
       and slm.warehouse_no = strWarehouseNo;

    if v_iCount > 0 then
      strResult := 'Y|';
      return;
    end if;

    v_iCount := 0;

    for GetCheckLabel in (select slm.trunck_cell_no,
                                 slm.a_sorter_chute_no,
                                 slm.check_chute_no,
                                 slm.owner_cell_no,
                                 sld.*
                            from odata_check_label_d ood,
                                 stock_label_d       sld,
                                 stock_label_m       slm
                           where ood.enterprise_no = sld.enterprise_no
                             and ood.warehouse_no = sld.warehouse_no
                             and sld.enterprise_no = slm.enterprise_no
                             and sld.warehouse_no = slm.warehouse_no
                             and sld.container_no = slm.container_no
                             and ood.container_no = sld.container_no
                             and ood.enterprise_no = strEnterPriseNo
                             and ood.warehouse_no = strWareHouseNo
                             and ood.check_no = strCheckNo
                             and sld.article_no = ood.article_no
                             and ood.deliver_obj = strDeliverObj
                             and sld.divide_id = ood.divide_id
                             and sld.article_id = ood.article_id
                             and sld.packing_qty = ood.packing_qty
                             and sld.exp_no = ood.exp_no
                             and rownum = 1) loop

      v_iCount := v_iCount + 1;

      pklg_wms_base.p_get_ContainerNoBase(strEnterPriseNo,
                                          strWareHouseNo,
                                          strContainerType,
                                          strUserId,
                                          'D',
                                          1,
                                          '2',
                                          v_strContainerMaterial,
                                          v_strLabelNo,
                                          v_strDcontainerNo,
                                          v_strSessionId,
                                          strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      v_strReportId := CONST_REPORTID.B_CLOSEExpBOX;

      pkobj_label.proc_Insert_LabelMaster(strEnterPriseNo,
                                          strWareHouseNo,
                                          GetCheckLabel.batch_no,
                                          strCheckNo,
                                          strDeliverObj,
                                          v_strDcontainerNo,
                                          strContainerType,
                                          'N',
                                          GetCheckLabel.owner_cell_no,
                                          GetCheckLabel.CUST_NO,
                                          GetCheckLabel.TRUNCK_CELL_NO,
                                          GetCheckLabel.a_sorter_chute_no,
                                          GetCheckLabel.CHECK_CHUTE_NO,
                                          strDeliverObj,
                                          CLabelUseType.CUSTOMER_LABEL,
                                          GetCheckLabel.line_no,
                                          'N',
                                          'N',
                                          strUserId,
                                          v_strReportId,
                                          'N',
                                          'N',
                                          '1',
                                          '0',
                                          v_strDcontainerNo,
                                          CLABELSTATUS.NEW_LABEL_NO,
                                          '0',
                                          GetCheckLabel.wave_no,
                                          strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

    end loop;

    if v_iCOUNT = 0 THEN
      --找不到对应的分播数据
      strResult := 'N|[找不到对应的复核数据]';
      return;
    end if;

    strResult := 'Y|[成功]'; --成功
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_DeliverObjLableNo;
  /*****************************************************************************************
   功能：装并板新取号，用固定板号或者流水板号
  *****************************************************************************************/
  procedure p_getNewMergeLabel(strEnterpriseNo  in stock_label_m.enterprise_no%type,
                               strWarehouseNo   in stock_label_m.warehouse_no%type, --仓别
                               strSLabelNo      in stock_label_m.label_no%type, --源容器号
                               strdLableNo      in stock_label_m.label_no%type, --目的标签号，传N流水板号，否则固定板号
                               strContainerType in stock_label_m.container_type%type, ----P：栈板；B物流箱
                               strUserId        in bdef_defworker.worker_no%type,
                               strDLabelNo      out stock_label_m.label_no%type, --目的容器号
                               strResult        out varchar2) is
    v_strDcontainerNo      stock_label_m.container_no%type;
    v_strSessionId         varchar2(256);
    v_iCount               integer;
    v_strContainerMaterial wms_defcontainer.container_material%type;
  begin
    v_icount := 0;
    if strContainerType = 'P' then
      v_strContainerMaterial := '31';
    end if;
    if strContainerType = 'B' then
      v_strContainerMaterial := '11';
    end if;

    for P in (select *
                from stock_label_m m
               where m.warehouse_no = strWareHouseNo
                 and m.enterprise_no = strEnterpriseNo
                 and m.label_no = strSLabelNo
                 and rownum < 2) loop
      v_icount := v_icount + 1;
      --取标签号
      pklg_wms_base.p_get_ContainerNoBase(strEnterpriseNo,
                                          strWarehouseNo,
                                          strContainerType,
                                          strUserId,
                                          'D',
                                          1,
                                          '2',
                                          v_strContainerMaterial,
                                          strDLabelNo,
                                          v_strDcontainerNo,
                                          v_strSessionId,
                                          strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      if strdLableNo <> 'N' then
        strDLabelNo := strdLableNo;
      end if;
      --写标签头档
      pkobj_label.proc_Insert_LabelMaster(strEnterpriseNo,
                                          strWarehouseNo,
                                          p.batch_no,
                                          p.source_no,
                                          strDLabelNo,
                                          v_strDcontainerNo,
                                          strContainerType,
                                          p.deliver_area,
                                          p.owner_cell_no,
                                          p.cust_no,
                                          p.trunck_cell_no,
                                          p.a_sorter_chute_no,
                                          p.check_chute_no,
                                          p.deliver_obj,
                                          p.use_type,
                                          p.line_no,
                                          'N',
                                          'N',
                                          strUserId,
                                          p.report_id,
                                          'N',
                                          'N',
                                          '1',
                                          '0',
                                          v_strDcontainerNo,
                                          ClabelStatus.NEW_LABEL_NO,
                                          '0',
                                          p.wave_no,
                                          strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
    end loop;

    if v_iCount = 0 then
      strResult := 'N|[E23207]'; --无此容器号
      return;
    end if;

    strResult := 'Y|[成功]'; --成功
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_getNewMergeLabel;

  /*****************************************************************************************
  2015.12.4
  功能说明：1、根据l来源标签的信息进行取号
            2、打印
  ******************************************************************************************/
  procedure GetDeliverObjLabelAndPrint(strEnterPriseNo  in stock_label_m.Enterprise_No%type, --企业号
                                       strWareHouseNo   in stock_label_m.warehouse_no%type, --仓别
                                       strsLabelNo      in stock_label_m.label_no%type, --来源标签号
                                       strDockNo        in bdef_defdock.dock_no%type, --工作站
                                       strContainerType in stock_label_m.container_type%type, --P：栈板；
                                       strUserId        in stock_label_m.rgst_name%type,
                                       strDLabelNo      out stock_label_m.label_no%type, --目的标签号
                                       strOutMsg        out varchar2) is
    --返回值
    v_strPrtTask    job_printtask_m.task_no%type;
    v_strReportId   job_printtask_m.report_id%type;
    v_strCustNo     stock_label_m.cust_no%type;
    v_strDeliverObj stock_label_m.deliver_obj%type;
  begin
    strOutMsg := 'N|[GetDeliverObjLabelAndPrint]';

    p_getnew_containerNo(strEnterPriseNo,
                         strWareHouseNo,
                         strSLabelNo,
                         strContainerType,
                         strUserId,
                         strDLabelNo,
                         strOutMsg);

    if (substr(strOutMsg, 1, 1) = 'N') then
      return;
    end if;

    select slm.cust_no, slm.deliver_obj
      into v_strCustNo, v_strDeliverObj
      from stock_label_m slm
     where slm.enterprise_no = strEnterPriseNo
       and slm.warehouse_no = strWareHouseNo
       and slm.label_no = strsLabelNo;

    if v_strCustNo <> v_strDeliverObj then
      --按单
      v_strReportId := CONST_REPORTID.B_CLOSEExpBOX;
    else
      v_strReportId := CONST_REPORTID.B_CLOSECustBOX;
    end if;

    --写打印任务头档
    PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterpriseNo,
                                        strWareHouseNo,
                                        strDLabelNo,
                                        0,
                                        v_strReportId,
                                        strDockNo,
                                        0,
                                        strUserId,
                                        v_strPrtTask,
                                        strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    strOutMsg := 'Y|[成功]';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end GetDeliverObjLabelAndPrint;

  /*****************************************************************************************
   功能：出货整理扫描条码保存商品
  Modify By lich AT 2014-11-07
  *****************************************************************************************/
  procedure p_Arrange_Save_Article(strEnterpriseNo in stock_label_m.enterprise_no%type,
                                   strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                                   strSLabelNo     in stock_label_m.label_no%type, --源容器号
                                   strDLabelNo     in stock_label_m.label_no%type, --目的容器号
                                   strDeliverOBJ   in stock_label_m.deliver_obj%type, --配送对象
                                   strArticleNo    in stock_label_d.article_no%type, --商品编码
                                   nPacking_QTY    in odata_check_d.packing_qty%type, --包装数量
                                   strQuality      in stock_article_info.quality%type, --品质
                                   dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                                   dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                                   strLotNo        in stock_article_info.lot_no%type, --批次号
                                   strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                                   strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                                   strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                                   strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                                   strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                                   strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                                   strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                                   strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                                   strBarcode      in stock_article_info.barcode%type,
                                   iQty            in stock_label_d.qty%type, --数量
                                   strUserId       in stock_label_m.rgst_name%type, --操作人
                                   strResult       out varchar2) is
    v_iCount integer;
    --v_iQty   integer;
  begin
    v_icount := 0;

    for P in (select d.container_no,
                     d.article_no,
                     d.packing_qty,
                     sum(d.qty),
                     sai.quality,
                     sai.produce_date,
                     sai.expire_date,
                     sai.lot_no,
                     sai.rsv_batch1,
                     sai.rsv_batch2,
                     sai.rsv_batch3,
                     sai.rsv_batch4,
                     sai.rsv_batch5,
                     sai.rsv_batch6,
                     sai.rsv_batch7,
                     sai.rsv_batch8
                from stock_label_m      m,
                     stock_label_d      d,
                     stock_article_info sai
               where m.warehouse_no = d.warehouse_no
                 and m.enterprise_no = d.enterprise_no
                 and d.enterprise_no = sai.enterprise_no
                 and m.container_no = d.container_no
                 and d.article_no = sai.article_no
                 and d.article_id = sai.article_id
                 and d.packing_qty = nPacking_QTY
                 and m.warehouse_no = strWareHouseNo
                 and m.enterprise_no = strEnterpriseNo
                 and m.label_no = strSLabelNo
                 and d.deliver_obj = strDeliverOBJ
                 and d.article_no = strArticleNo
                 and sai.produce_date = dtProduceDate
                 and sai.expire_date = dtExpireDate
                 and sai.lot_no = strLotNo
                 and sai.quality = strQuality
                 and sai.rsv_batch1 = strRSV_BATCH1
                 and sai.rsv_batch2 = strRSV_BATCH2
                 and sai.rsv_batch3 = strRSV_BATCH3
                 and sai.rsv_batch4 = strRSV_BATCH4
                 and sai.rsv_batch5 = strRSV_BATCH5
                 and sai.rsv_batch6 = strRSV_BATCH6
                 and sai.rsv_batch7 = strRSV_BATCH7
                 and sai.rsv_batch8 = strRSV_BATCH8
               group by d.container_no,
                        d.article_no,
                        d.packing_qty,
                        sai.quality,
                        sai.produce_date,
                        sai.expire_date,
                        sai.lot_no,
                        sai.rsv_batch1,
                        sai.rsv_batch2,
                        sai.rsv_batch3,
                        sai.rsv_batch4,
                        sai.rsv_batch5,
                        sai.rsv_batch6,
                        sai.rsv_batch7,
                        sai.rsv_batch8) loop
      v_icount := v_icount + 1;

      --容器整理
      p_container_arrange(strEnterpriseNo,
                          strWareHouseNo,
                          strSLabelNo,
                          strdLabelNo,
                          strDeliverOBJ,
                          strArticleNo,
                          P.PACKING_QTY,
                          iQty,
                          P.QUALITY,
                          P.PRODUCE_DATE,
                          P.EXPIRE_DATE,
                          p.LOT_NO,
                          P.RSV_BATCH1,
                          P.RSV_BATCH2,
                          P.RSV_BATCH3,
                          P.RSV_BATCH4,
                          P.RSV_BATCH5,
                          P.RSV_BATCH6,
                          P.RSV_BATCH7,
                          P.RSV_BATCH8,
                          strUserId,
                          '1',
                          strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

    end loop;

    if v_iCount = 0 then
      strResult := 'N|[E23207]'; --无此容器号
      return;
    end if;

    strResult := 'Y|[成功]'; --成功
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_Arrange_Save_Article;

  /******************************************************************************************
  出货整理打包》源标签号检验(天天惠专用)
  Modify By lich AT 2014-11-10
  *****************************************************************************************/
  procedure p_check_SLabelNo(strEnterpriseNo in stock_label_m.enterprise_no%type,
                             strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                             strLabelNo      in stock_label_m.label_no%type, --源容器号
                             strResult       out varchar2) is
    v_sStatus           stock_label_m.status%type; --源容器状态
    v_sStatusName       wms_deflabel_status.status_name%type;
    v_sDeliverObj       stock_label_m.deliver_obj%type; --源容器配送对象
    v_sUseType          stock_label_m.use_type%type; --源容器标签
    v_sLineNo           stock_label_m.line_no%type; --源容器线路
    v_sContainerNo      stock_label_m.container_no%type;
    v_sOwnerContainerNo stock_label_m.owner_container_no%type;
    v_sOwnerCellNo      stock_label_m.owner_cell_no%type;
    v_areaUseType       cdef_defarea.area_usetype%type;
    v_areaAttribute     cdef_defarea.area_attribute%type;
    v_attributeType     cdef_defarea.attribute_type%type;
    v_iCount            integer;
  begin
    strResult := 'N|[p_check_SLabelNo]';

    --获取来源容器的配送对象和状态
    begin
      select slm.status,
             b.status_name,
             slm.deliver_obj,
             slm.use_type,
             slm.line_no,
             slm.deliver_obj,
             slm.container_no,
             slm.owner_container_no,
             slm.owner_cell_no
        into v_sStatus,
             v_sStatusName,
             v_sDeliverObj,
             v_sUseType,
             v_sLineNo,
             v_sDeliverObj,
             v_sContainerNo,
             v_sOwnerContainerNo,
             v_sOwnerCellNo
        from stock_label_m slm， wms_deflabel_status b
       where slm.status = b.status_type
         and slm.warehouse_no = strWarehouseNo
         and slm.enterprise_no = strEnterpriseNo
         and slm.label_no = strLabelNo;
    exception
      when no_data_found then
        strResult := 'N|[E23207]'; --无此容器号
        return;
    end;

    --判断标签状态在可允许的范围
    if v_sStatus != CLabelStatus.PICK_END then
      strResult := 'N|[' || strLabelNo || '状态为' || v_sStatusName ||
                   ',不允许做整理]';
      return;
    end if;

    --查询原容器是否有明细
    begin
      select count(1)
        into v_iCount
        from stock_label_d sld
       where sld.enterprise_no = strEnterpriseNo
         and sld.warehouse_no = sld.warehouse_no
         and sld.container_no = v_sContainerNo;
    exception
      when no_data_found then
        strResult := 'N|[E23210]'; --源容器号无明细
        return;
    end;

    --判断是不是处于出货暂存区或发货暂存区
    begin
      select a.area_usetype, a.area_attribute, a.attribute_type
        into v_areaUseType, v_areaAttribute, v_attributeType
        from cdef_defcell c, cdef_defarea a
       where c.warehouse_no = a.warehouse_no
         and c.enterprise_no = a.enterprise_no
         and c.ware_no = a.ware_no
         and c.area_no = a.area_no
         and c.warehouse_no = strWarehouseNo
         and c.enterprise_no = strEnterpriseNo
         and c.cell_no = v_sOwnerCellNo;

    exception
      when no_data_found then
        strResult := 'N|[E23216]'; --标签最后并入储位不对
        return;
    end;

    --判断标签状态在可允许的范围
    if v_sStatus not in (CLabelStatus.PICK_END,
                         CLabelStatus.PICK_MOVING,
                         CLabelStatus.RECEIVING,
                         CLabelStatus.DIVIDE_FROM_PAL,
                         CLabelStatus.SORTING_PASS,
                         CLabelStatus.CONFIRM,
                         CLabelStatus.INNER_CHECKING,
                         CLabelStatus.INNER_CHECKED,
                         CLabelStatus.WAIT_OUTER_CHECK,
                         CLabelStatus.OUTER_CHECKED,
                         CLabelStatus.WAIT_TURN_AREA,
                         CLabelStatus.WAIT_LOAD_CAR) then
      strResult := 'N|' || '[' || v_sStatus || '不在可允许范围]'; --标签状态不在可允许的范围
      --strResult:=v_sStatus||'不在可允许的范围';
      return;
    end if;

    if v_sUseType <> '1' then
      strResult := 'N|[E23208]'; --标签状态必须要为客户标签
      return;
    end if;

    if v_sContainerNo <> v_sOwnerContainerNo then
      strResult := 'N|[E23218]'; --不能使用并板标签
      return;
    end if;

    if v_areaAttribute <> '1' or v_areaUseType <> '1' then
      strResult := 'N|[E23219]'; --标签必须处于发货暂存区或发货暂存区
      return;
    end if;

    if v_attributeType not in ('2', '3', '4', '5') then
      strResult := 'N|[E23219]'; --标签必须处于发货暂存区或发货暂存区
      return;
    end if;

    strResult := 'Y|[成功]'; --成功
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_check_SLabelNo;

  /***********************************************************************************************
   功能说明 ：
            根据任务号或者箱号写复核单，目前用于电商的复核

  ***********************************************************************************************/

  procedure p_creat_odata_check(strEnterpriseNo in odata_check_m.enterprise_no%type,
                                strWareHouseNo  in odata_check_m.warehouse_no%type,
                                strCheckChuteNo in odata_check_m.check_chute_no%type, --复核台滑道号
                                strTaksNo       in stock_label_m.source_no%type, --任务号，没有则传N
                                strBoxNo        in stock_label_m.label_no%type, --箱号/ 快递单号
                                strCheckType    in varchar2, --复核类型：1:按任务复核或按箱号,2:快递单号复核
                                strUserId       in odata_check_m.rgst_name%type,
                                strCheckNo      out odata_check_m.check_no%type,
                                strResult       out varchar2) is
    v_strCheckNo odata_check_m.check_no%type;
    --v_strCheckStatus odata_check_m.status%type;
    v_Article_QTY    odata_exp_d.article_qty%type;
    v_Source_No      stock_label_m.source_no%type;
    v_Label_No       stock_label_m.label_no%type;
    v_Container_No   stock_label_m.container_no%type;
    v_Container_Type stock_label_d.container_type%type;
    v_Status         stock_label_m.status%type;
    --v_Wave_No        stock_label_m.wave_no%type;
    v_Exp_No odata_exp_m.exp_no%type := 'N';
    v_iCount integer := 0;
  begin
    strResult := 'N|[p_creat_odata_check]';

    --按任务复核
    if strCheckType = '1' then

      for GetExpInfo in (select sum(oed.article_qty) article_qty,
                                oed.exp_no,
                                oed.article_no,
                                oem.enterprise_no,
                                oem.warehouse_no,
                                oem.owner_no
                           from odata_exp_m oem, odata_exp_d oed
                          where oem.enterprise_no = oed.enterprise_no
                            and oem.warehouse_no = oed.warehouse_no
                            and oem.exp_no = oed.exp_no
                            and oed.item_type = '1' --免拣品
                            and exists
                          (select 'x'
                                   from stock_label_m slm, stock_label_d sld
                                  where slm.enterprise_no = strEnterpriseNo
                                    and slm.warehouse_no = strWareHouseNo
                                    and slm.source_no = strTaksNo
                                    and slm.use_type =
                                        CLabelUseType.CUSTOMER_LABEL
                                    and slm.status between
                                        CLabelStatus.PICK_END and
                                        CLabelStatus.WAIT_LOAD_CAR
                                    and slm.container_no = sld.container_no
                                    and slm.enterprise_no = sld.enterprise_no
                                    and slm.warehouse_no = sld.warehouse_no
                                    and sld.exp_no = oem.exp_no
                                    and sld.exp_type = oem.exp_type
                                    and sld.enterprise_no = oem.enterprise_no
                                    and sld.warehouse_no = oem.warehouse_no)
                          group by oed.exp_no,
                                   oed.article_no,
                                   oem.enterprise_no,
                                   oem.warehouse_no,
                                   oem.owner_no) loop

        select slm.source_no,
               slm.label_no,
               slm.container_no,
               slm.container_type,
               slm.status --,
        --slm.wave_no,
        --slm.batch_no
          into v_Source_No,
               v_Label_No,
               v_Container_No,
               v_Container_Type,
               v_Status --,
        --v_wave_No,
        --v_batch_No
          from stock_label_m slm, stock_label_d sld
         where slm.enterprise_no = strEnterpriseNo
           and slm.warehouse_no = strWareHouseNo
           and slm.source_no = strTaksNo
           and slm.use_type = CLabelUseType.CUSTOMER_LABEL
           and slm.status between CLabelStatus.PICK_END and
               CLabelStatus.WAIT_LOAD_CAR
           and slm.container_no = sld.container_no
           and slm.enterprise_no = sld.enterprise_no
           and slm.warehouse_no = sld.warehouse_no
           and sld.exp_no = GetExpInfo.Exp_No
           and sld.enterprise_no = GetExpInfo.Enterprise_No
           and sld.warehouse_no = GetExpInfo.Warehouse_No
           and sld.owner_no = GetExpInfo.Owner_No
           and rownum = 1;

        --免拣品定位，并写标签明细
        pklg_olocate.P_Locate_SpecialArea(strEnterpriseNo,
                                          strWareHouseNo,
                                          strUserId,
                                          GetExpInfo.Article_No,
                                          GetExpInfo.Article_Qty,
                                          '1',
                                          'N',
                                          v_Source_No,
                                          GetExpInfo.Exp_No,
                                          v_Label_No,
                                          v_Container_No,
                                          v_Container_Type,
                                          v_Status,
                                          '1',
                                          v_Article_QTY,
                                          strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        if v_Article_QTY <> GetExpInfo.Article_Qty then
          strResult := 'N|赠品不允许缺量定位！';
          return;
        end if;
      end loop;

      for GetLabelNo in (select distinct slm.batch_no,
                                         slm.cust_no,
                                         slm.line_no,
                                         slm.curr_area,
                                         sld.deliver_obj,
                                         sld.owner_no,
                                         slm.label_no,
                                         slm.container_no,
                                         sld.exp_no
                           from stock_label_m slm, stock_label_d sld
                          where slm.enterprise_no = strEnterpriseNo
                            and slm.warehouse_no = strWareHouseNo
                            and (slm.source_no = strTaksNo or
                                slm.label_no = strTaksNo)
                            and slm.use_type = CLabelUseType.CUSTOMER_LABEL
                            and slm.status between CLabelStatus.PICK_END and
                                CLabelStatus.WAIT_LOAD_CAR
                            and slm.container_no = sld.container_no
                            and slm.enterprise_no = sld.enterprise_no
                            and slm.warehouse_no = sld.warehouse_no
                            and not exists
                          (select 'x'
                                   from odata_check_label_d t
                                  where t.enterprise_no = slm.enterprise_no
                                    and t.warehouse_no = slm.warehouse_no
                                    and t.lable_no = slm.label_no
                                    and t.container_no = slm.container_no)
                          order by sld.exp_no, slm.container_no) loop

        if v_iCount = 0 then
          --取复核单头档单号
          PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                     strWareHouseNo,
                                     CONST_DOCUMENTTYPE.ODATAOC,
                                     v_strCheckNo,
                                     strResult);
          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;
          --新增复核单头档
          PKOBJ_ODATA_CHECK.p_insert_Odata_check_m(strEnterpriseNo,
                                                   strWarehouseNo,
                                                   v_strCheckNo,
                                                   GetLabelNo.owner_no,
                                                   GetLabelNo.batch_no,
                                                   GetLabelNo.cust_no,
                                                   '10',
                                                   strCheckChuteNo,
                                                   'N',
                                                   GetLabelNo.line_no,
                                                   GetLabelNo.curr_area,
                                                   strUserId,
                                                   strResult);
          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;

          --新增复核单明细
          insert into odata_check_d
            (enterprise_no,
             warehouse_no,
             owner_no,
             check_no,
             exp_no,
             exp_type,
             exp_date,
             article_no,
             packing_qty,
             plan_qty,
             article_qty,
             real_qty,
             status,
             rgst_name,
             rgst_date,
             deliver_obj)
            select a.enterprise_no,
                   a.warehouse_no,
                   a.owner_no,
                   v_strCheckNo,
                   a.exp_no,
                   a.exp_type,
                   a.exp_date,
                   a.article_no,
                   a.packing_qty,
                   oed.article_qty,
                   a.article_qty,
                   0,
                   '10',
                   strUserId,
                   sysdate,
                   a.deliver_obj
              from (select a.enterprise_no,
                           a.warehouse_no,
                           a.owner_no,
                           a.exp_no,
                           a.exp_type,
                           a.exp_date,
                           a.article_no,
                           a.packing_qty,
                           sum(a.qty) article_qty,
                           a.deliver_obj
                      from stock_label_d a, stock_label_m t
                     where a.enterprise_no = t.enterprise_no
                       and a.warehouse_no = t.warehouse_no
                       and a.container_no = t.container_no
                       and a.enterprise_no = strEnterpriseNo
                       and a.warehouse_no = strWareHouseNo
                       and (t.source_no = strTaksNo or
                           t.label_no = strTaksNo)
                       and not exists
                     (select 'x'
                              from odata_check_label_d d
                             where t.enterprise_no = d.enterprise_no
                               and t.warehouse_no = d.warehouse_no
                               and t.label_no = d.lable_no
                               and t.container_no = d.container_no)
                     group by a.enterprise_no,
                              a.warehouse_no,
                              a.owner_no,
                              a.exp_no,
                              a.article_no,
                              a.packing_qty,
                              a.exp_type,
                              a.exp_date,
                              a.deliver_obj) a,
                   odata_exp_d oed
             where a.exp_no = oed.exp_no
               and a.article_no = oed.article_no
               and a.warehouse_no = oed.warehouse_no
               and a.enterprise_no = oed.enterprise_no;

        end if;

        -- 复核标签单明细
        PKOBJ_ODATA_CHECK.p_insert_checkLabelD_by_label(strEnterpriseNo,
                                                        strWarehouseNo,
                                                        v_strCheckNo,
                                                        GetLabelNo.container_no,
                                                        strUserId,
                                                        strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        --更新来源标签的复核台
        update stock_label_m t
           set t.check_chute_no = strCheckChuteNo
         where t.enterprise_no = strEnterpriseNo
           and t.warehouse_no = strWareHouseNo
           and t.label_no = GetLabelNo.label_no;

        if v_Exp_No <> GetLabelNo.Exp_No then
          --单据状态跟踪，开始复核
          PKOBJ_ODISPATCH.P_Insert_Odata_Exp_Trace(strEnterPriseNo,
                                                   strWarehouseNo,
                                                   GetLabelNo.Exp_No,
                                                   COdataExpStatus.ExpTracPartCheck,
                                                   strUserId,
                                                   strResult);
          if substr(strResult, 1, 1) <> 'Y' then
            return;
          end if;
        end if;

        v_Exp_No := GetLabelNo.Exp_No;

        v_iCount := v_iCount + 1;

      end loop;
    end if;
    /*
      if v_iCount <= 0 then
        --按箱号

        for GetExpInfo in (select sum(oed.article_qty) article_qty,
                                  oed.exp_no,
                                  oed.article_no,
                                  oem.enterprise_no,
                                  oem.warehouse_no,
                                  oem.owner_no
                             from odata_exp_m oem, odata_exp_d oed
                            where oem.enterprise_no = oed.enterprise_no
                              and oem.warehouse_no = oed.warehouse_no
                              and oem.exp_no = oed.exp_no
                              and oed.item_type = '1' --免拣品
                              and exists
                            (select 'x'
                                     from stock_label_m slm, stock_label_d sld
                                    where slm.enterprise_no = strEnterpriseNo
                                      and slm.warehouse_no = strWareHouseNo
                                      and slm.label_no = strTaksNo
                                      and slm.use_type =
                                          CLabelUseType.CUSTOMER_LABEL
                                      and slm.status between
                                          CLabelStatus.PICK_END and
                                          CLabelStatus.WAIT_LOAD_CAR
                                      and slm.container_no = sld.container_no
                                      and slm.enterprise_no = sld.enterprise_no
                                      and slm.warehouse_no = sld.warehouse_no
                                      and sld.exp_no = oem.exp_no
                                      and sld.exp_type = oem.exp_type
                                      and sld.enterprise_no = oem.enterprise_no
                                      and sld.warehouse_no = oem.warehouse_no)
                            group by oed.exp_no,
                                     oed.article_no,
                                     oem.enterprise_no,
                                     oem.warehouse_no,
                                     oem.owner_no) loop

          select slm.source_no,
                 slm.label_no,
                 slm.container_no,
                 slm.container_type,
                 slm.status --,
          --slm.wave_no,
          --slm.batch_no
            into v_Source_No,
                 v_Label_No,
                 v_Container_No,
                 v_Container_Type,
                 v_Status --,
          --v_wave_No,
          --v_batch_No
            from stock_label_m slm, stock_label_d sld
           where slm.enterprise_no = strEnterpriseNo
             and slm.warehouse_no = strWareHouseNo
             and slm.label_no = strTaksNo
             and slm.use_type = CLabelUseType.CUSTOMER_LABEL
             and slm.status between CLabelStatus.PICK_END and
                 CLabelStatus.WAIT_LOAD_CAR
             and slm.container_no = sld.container_no
             and slm.enterprise_no = sld.enterprise_no
             and slm.warehouse_no = sld.warehouse_no
             and sld.exp_no = GetExpInfo.Exp_No
             and sld.enterprise_no = GetExpInfo.Enterprise_No
             and sld.warehouse_no = GetExpInfo.Warehouse_No
             and sld.owner_no = GetExpInfo.Owner_No
             and rownum = 1;

          --免拣品定位，并写标签明细
          pklg_olocate.P_Locate_SpecialArea(strEnterpriseNo,
                                            strWareHouseNo,
                                            strUserId,
                                            GetExpInfo.Article_No,
                                            GetExpInfo.Article_Qty,
                                            '1',
                                            'N',
                                            v_Source_No,
                                            GetExpInfo.Exp_No,
                                            v_Label_No,
                                            v_Container_No,
                                            v_Container_Type,
                                            v_Status,
                                            '1',
                                            v_Article_QTY,
                                            strResult);

          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;

          if v_Article_QTY <> GetExpInfo.Article_Qty then
            strResult := 'N|赠品不允许缺量定位！';
            return;
          end if;
        end loop;

        for GetLabelNo in (select distinct slm.batch_no,
                                           slm.cust_no,
                                           slm.line_no,
                                           slm.curr_area,
                                           sld.deliver_obj,
                                           sld.owner_no,
                                           slm.label_no,
                                           slm.container_no,
                                           sld.exp_no
                             from stock_label_m slm, stock_label_d sld
                            where slm.enterprise_no = strEnterpriseNo
                              and slm.warehouse_no = strWareHouseNo
                              and slm.label_no = strTaksNo
                              and slm.use_type = CLabelUseType.CUSTOMER_LABEL
                              and slm.status between CLabelStatus.PICK_END and
                                  CLabelStatus.WAIT_LOAD_CAR
                              and slm.container_no = sld.container_no
                              and slm.enterprise_no = sld.enterprise_no
                              and slm.warehouse_no = sld.warehouse_no
                            order by sld.exp_no) loop

          if v_iCount = 0 then
            --新增复核单头档
            PKOBJ_ODATA_CHECK.p_insert_Odata_check_m(strEnterpriseNo,
                                                     strWarehouseNo,
                                                     v_strCheckNo,
                                                     GetLabelNo.owner_no,
                                                     GetLabelNo.batch_no,
                                                     GetLabelNo.cust_no,
                                                     '10',
                                                     strCheckChuteNo,
                                                     'N',
                                                     GetLabelNo.line_no,
                                                     GetLabelNo.curr_area,
                                                     strUserId,
                                                     strResult);
            if (substr(strResult, 1, 1) = 'N') then
              return;
            end if;

            --新增复核单明细
            insert into odata_check_d
              (enterprise_no,
               warehouse_no,
               owner_no,
               check_no,
               exp_no,
               exp_type,
               exp_date,
               article_no,
               packing_qty,
               plan_qty,
               article_qty,
               real_qty,
               status,
               rgst_name,
               rgst_date,
               deliver_obj)
              select a.enterprise_no,
                     a.warehouse_no,
                     a.owner_no,
                     v_strCheckNo,
                     a.exp_no,
                     a.exp_type,
                     a.exp_date,
                     a.article_no,
                     a.packing_qty,
                     oed.article_qty,
                     a.article_qty,
                     0,
                     '10',
                     strUserId,
                     sysdate,
                     a.deliver_obj
                from (select a.enterprise_no,
                             a.warehouse_no,
                             a.owner_no,
                             a.exp_no,
                             a.exp_type,
                             a.exp_date,
                             a.article_no,
                             a.packing_qty,
                             sum(a.qty) article_qty,
                             a.deliver_obj
                        from stock_label_d a, stock_label_m t
                       where a.enterprise_no = t.enterprise_no
                         and a.warehouse_no = t.warehouse_no
                         and a.container_no = t.container_no
                         and a.enterprise_no = strEnterpriseNo
                         and a.warehouse_no = strWareHouseNo
                         and t.label_no = strTaksNo
                       group by a.enterprise_no,
                                a.warehouse_no,
                                a.owner_no,
                                a.exp_no,
                                a.article_no,
                                a.packing_qty,
                                a.exp_type,
                                a.exp_date,
                                a.deliver_obj) a,
                     odata_exp_d oed
               where --不支持同一商品两条出货单明细
               a.exp_no = oed.exp_no
               and a.article_no = oed.article_no
               and a.warehouse_no = oed.warehouse_no
               and a.enterprise_no = oed.enterprise_no;

          end if;
          -- 复核标签单明细
          PKOBJ_ODATA_CHECK.p_insert_checkLabelD_by_label(strEnterpriseNo,
                                                          strWarehouseNo,
                                                          v_strCheckNo,
                                                          GetLabelNo.container_no,
                                                          strUserId,
                                                          strResult);

          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;

          --更新来源标签的复核台
          update stock_label_m t
             set t.check_chute_no = strCheckChuteNo
           where t.enterprise_no = strEnterpriseNo
             and t.warehouse_no = strWareHouseNo
             and t.label_no = GetLabelNo.label_no;

          if v_Exp_No <> GetLabelNo.Exp_No then
            --单据状态跟踪，开始复核
            PKOBJ_ODISPATCH.P_Insert_Odata_Exp_Trace(strEnterPriseNo,
                                                     strWarehouseNo,
                                                     GetLabelNo.Exp_No,
                                                     COdataExpStatus.ExpTracPartCheck,
                                                     strUserId,
                                                     strResult);
            if substr(strResult, 1, 1) <> 'Y' then
              return;
            end if;
          end if;

          v_Exp_No := GetLabelNo.Exp_No;
          v_iCount := v_iCount + 1;
        end loop;
      end if;
    */
    --按快递单号
    if strCheckType = '2' then
      for GetExpInfo in (select sum(oed.article_qty) article_qty,
                                oed.exp_no,
                                oed.article_no,
                                oem.enterprise_no,
                                oem.warehouse_no,
                                oem.owner_no
                           from odata_exp_m oem, odata_exp_d oed
                          where oem.enterprise_no = oed.enterprise_no
                            and oem.warehouse_no = oed.warehouse_no
                            and oem.exp_no = oed.exp_no
                            and oem.shipper_deliver_no = strTaksNo
                            and oed.item_type = '1' --免拣品
                            and exists
                          (select 'x'
                                   from stock_label_m slm, stock_label_d sld
                                  where slm.enterprise_no = strEnterpriseNo
                                    and slm.warehouse_no = strWareHouseNo
                                    and slm.use_type =
                                        CLabelUseType.CUSTOMER_LABEL
                                    and slm.status between
                                        CLabelStatus.PICK_END and
                                        CLabelStatus.WAIT_LOAD_CAR
                                    and slm.container_no = sld.container_no
                                    and slm.enterprise_no = sld.enterprise_no
                                    and slm.warehouse_no = sld.warehouse_no
                                    and sld.exp_no = oem.exp_no
                                    and sld.exp_type = oem.exp_type
                                    and sld.enterprise_no = oem.enterprise_no
                                    and sld.warehouse_no = oem.warehouse_no)
                          group by oed.exp_no,
                                   oed.article_no,
                                   oem.enterprise_no,
                                   oem.warehouse_no,
                                   oem.owner_no) loop

        select slm.source_no,
               slm.label_no,
               slm.container_no,
               slm.container_type,
               slm.status --,
        --slm.wave_no,
        --slm.batch_no
          into v_Source_No,
               v_Label_No,
               v_Container_No,
               v_Container_Type,
               v_Status --,
        --v_wave_No,
        --v_batch_No
          from stock_label_m slm, stock_label_d sld
         where slm.enterprise_no = strEnterpriseNo
           and slm.warehouse_no = strWareHouseNo
           and exists (select 'x'
                  from odata_exp_m oem
                 where oem.shipper_deliver_no = strTaksNo
                   and oem.enterprise_no = strEnterpriseNo
                   and oem.warehouse_no = strWareHouseNo
                   and oem.exp_no = sld.exp_no
                   and oem.exp_type = sld.exp_type
                   and oem.status <> '16')
           and slm.use_type = CLabelUseType.CUSTOMER_LABEL
           and slm.status between CLabelStatus.PICK_END and
               CLabelStatus.WAIT_LOAD_CAR
           and slm.container_no = sld.container_no
           and slm.enterprise_no = sld.enterprise_no
           and slm.warehouse_no = sld.warehouse_no
           and sld.exp_no = GetExpInfo.Exp_No
           and sld.enterprise_no = GetExpInfo.Enterprise_No
           and sld.warehouse_no = GetExpInfo.Warehouse_No
           and sld.owner_no = GetExpInfo.Owner_No
           and rownum = 1;

        --免拣品定位，并写标签明细
        pklg_olocate.P_Locate_SpecialArea(strEnterpriseNo,
                                          strWareHouseNo,
                                          strUserId,
                                          GetExpInfo.Article_No,
                                          GetExpInfo.Article_Qty,
                                          '1',
                                          'N',
                                          v_Source_No,
                                          GetExpInfo.Exp_No,
                                          v_Label_No,
                                          v_Container_No,
                                          v_Container_Type,
                                          v_Status,
                                          '1',
                                          v_Article_QTY,
                                          strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        if v_Article_QTY <> GetExpInfo.Article_Qty then
          strResult := 'N|赠品不允许缺量定位！';
          return;
        end if;
      end loop;

      for GetLabelNo in (select distinct slm.batch_no,
                                         slm.cust_no,
                                         slm.line_no,
                                         slm.curr_area,
                                         sld.deliver_obj,
                                         sld.owner_no,
                                         slm.label_no,
                                         sld.container_no,
                                         sld.exp_no
                           from stock_label_m slm, stock_label_d sld
                          where slm.enterprise_no = strEnterpriseNo
                            and slm.warehouse_no = strWareHouseNo
                            and exists
                          (select 'x'
                                   from odata_exp_m oem
                                  where oem.shipper_deliver_no = strTaksNo
                                    and oem.enterprise_no = strEnterpriseNo
                                    and oem.warehouse_no = strWareHouseNo
                                    and oem.exp_no = sld.exp_no
                                    and oem.exp_type = sld.exp_type
                                    and oem.status <> '16')
                            and slm.use_type = CLabelUseType.CUSTOMER_LABEL
                            and slm.status between CLabelStatus.PICK_END and
                                CLabelStatus.WAIT_LOAD_CAR
                            and slm.container_no = sld.container_no
                            and slm.enterprise_no = sld.enterprise_no
                            and slm.warehouse_no = sld.warehouse_no
                          order by sld.exp_no, sld.container_no) loop

        if v_iCount = 0 then
          --取复核单头档单号
          PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                     strWareHouseNo,
                                     CONST_DOCUMENTTYPE.ODATAOC,
                                     v_strCheckNo,
                                     strResult);
          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;

          --新增复核单头档
          PKOBJ_ODATA_CHECK.p_insert_Odata_check_m(strEnterpriseNo,
                                                   strWarehouseNo,
                                                   v_strCheckNo,
                                                   GetLabelNo.owner_no,
                                                   GetLabelNo.batch_no,
                                                   GetLabelNo.cust_no,
                                                   '10',
                                                   strCheckChuteNo,
                                                   'N',
                                                   GetLabelNo.line_no,
                                                   GetLabelNo.curr_area,
                                                   strUserId,
                                                   strResult);
          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;

          --新增复核单明细
          insert into odata_check_d
            (enterprise_no,
             warehouse_no,
             owner_no,
             check_no,
             exp_no,
             exp_type,
             exp_date,
             article_no,
             packing_qty,
             plan_qty,
             article_qty,
             real_qty,
             status,
             rgst_name,
             rgst_date,
             deliver_obj)
            select a.enterprise_no,
                   a.warehouse_no,
                   a.owner_no,
                   v_strCheckNo,
                   a.exp_no,
                   a.exp_type,
                   a.exp_date,
                   a.article_no,
                   a.packing_qty,
                   oed.article_qty,
                   a.article_qty,
                   0,
                   '10',
                   strUserId,
                   sysdate,
                   a.deliver_obj
              from (select a.enterprise_no,
                           a.warehouse_no,
                           a.owner_no,
                           a.exp_no,
                           a.exp_type,
                           a.exp_date,
                           a.article_no,
                           a.packing_qty,
                           sum(a.qty) article_qty,
                           a.deliver_obj
                      from stock_label_d a, stock_label_m t
                     where a.enterprise_no = t.enterprise_no
                       and a.warehouse_no = t.warehouse_no
                       and a.container_no = t.container_no
                       and a.enterprise_no = strEnterpriseNo
                       and a.warehouse_no = strWareHouseNo
                       and exists
                     (select 'x'
                              from odata_exp_m oem
                             where oem.shipper_deliver_no = strTaksNo
                               and oem.enterprise_no = strEnterpriseNo
                               and oem.warehouse_no = strWareHouseNo
                               and oem.exp_no = a.exp_no
                               and oem.exp_type = a.exp_type
                               and oem.status <> '16')
                     group by a.enterprise_no,
                              a.warehouse_no,
                              a.owner_no,
                              a.exp_no,
                              a.article_no,
                              a.packing_qty,
                              a.exp_type,
                              a.exp_date,
                              a.deliver_obj) a,
                   odata_exp_d oed
             where --不支持同一商品两条出货单明细
             a.exp_no = oed.exp_no
             and a.article_no(+) = oed.article_no
             and a.warehouse_no = oed.warehouse_no;

        end if;

        -- 复核标签单明细
        PKOBJ_ODATA_CHECK.p_insert_checkLabelD_by_label(strEnterpriseNo,
                                                        strWarehouseNo,
                                                        v_strCheckNo,
                                                        GetLabelNo.container_no,
                                                        strUserId,
                                                        strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        --更新来源标签的复核台
        update stock_label_m t
           set t.check_chute_no = strCheckChuteNo
         where t.enterprise_no = strEnterpriseNo
           and t.warehouse_no = strWareHouseNo
           and t.label_no = GetLabelNo.label_no;

        if v_Exp_No <> GetLabelNo.Exp_No then
          --单据状态跟踪，开始复核
          PKOBJ_ODISPATCH.P_Insert_Odata_Exp_Trace(strEnterPriseNo,
                                                   strWarehouseNo,
                                                   GetLabelNo.Exp_No,
                                                   COdataExpStatus.ExpTracPartCheck,
                                                   strUserId,
                                                   strResult);
          if substr(strResult, 1, 1) <> 'Y' then
            return;
          end if;
        end if;

        v_Exp_No := GetLabelNo.Exp_No;

        v_iCount := v_iCount + 1;
      end loop;

    end if;

    if v_iCount <= 0 then
      strResult := 'N|[扫描的单号无效]'; --成功
      return;
    end if;

    strCheckNo := v_strCheckNo;

    strResult := 'Y|[成功]'; --成功
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_creat_odata_check;
  /***********************************************************************************************
   --根据箱号写复核单数据
  ***********************************************************************************************/

  procedure p_creat_odata_check_by_label(strEnterpriseNo in odata_check_m.enterprise_no%type,
                                         strWareHouseNo  in odata_check_m.warehouse_no%type,
                                         strlabelNo      in stock_label_m.label_no%type, --箱号
                                         strCheckChuteNo in odata_check_m.check_chute_no%type, --复核台滑道号
                                         strUserId       in odata_check_m.rgst_name%type,
                                         strResult       out varchar2) is

    v_strCheckNo     odata_check_m.check_no%type;
    v_strBatchNo     odata_check_m.batch_no%type;
    v_strCustNo      odata_check_m.cust_no%type;
    v_strLineNo      odata_check_m.line_no%type;
    v_strCurrArea    odata_check_m.curr_area%type;
    v_deliverObj     stock_label_m.deliver_obj%type;
    v_ownerNo        stock_label_d.owner_no%type;
    v_containerNo    stock_label_d.container_no%type;
    v_strCheckStatus odata_check_m.status%type;
  begin
    --获取标签信息
    begin
      select slm.batch_no,
             slm.cust_no,
             slm.line_no,
             slm.curr_area,
             slm.deliver_obj,
             sld.owner_no,
             slm.container_no
        into v_strBatchNo,
             v_strCustNo,
             v_strLineNo,
             v_strCurrArea,
             v_deliverObj,
             v_ownerNo,
             v_containerNo
        from stock_label_m slm, stock_label_d sld
       where slm.enterprise_no = strEnterpriseNo
         and slm.warehouse_no = strWareHouseNo
         and slm.label_no = strlabelNo
         and slm.use_type = CLabelUseType.CUSTOMER_LABEL
         and slm.status between CLabelStatus.PICK_END and
             CLabelStatus.WAIT_LOAD_CAR
         and slm.container_no = sld.container_no
         and slm.enterprise_no = sld.enterprise_no
         and slm.warehouse_no = sld.warehouse_no
         and rownum = 1;
    exception
      when no_data_found then
        strResult := 'N|[p_creat_odata_check]';
        return;
    end;

    --判断此标签是否有对应的复核单
    begin
      select a.status, a.check_no
        into v_strCheckStatus, v_strCheckNo
        from odata_check_label_d t, odata_check_m a
       where t.enterprise_no = a.enterprise_no
         and t.warehouse_no = a.warehouse_no
         and t.check_no = a.check_no
         and t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.lable_no = strlabelNo
         and rownum = 1;
    exception
      when no_data_found then
        v_strCheckStatus := '';
    end;

    if v_strCheckStatus = '12' then
      strResult := 'N|[该标签已经做复核回单]';
      return;
    end if;

    --取复核单头档单号
    PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                               strWareHouseNo,
                               CONST_DOCUMENTTYPE.ODATAOC,
                               v_strCheckNo,
                               strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    --新增复核单头档
    PKOBJ_ODATA_CHECK.p_insert_Odata_check_m(strEnterpriseNo,
                                             strWarehouseNo,
                                             v_strCheckNo,
                                             v_ownerNo,
                                             v_strBatchNo,
                                             v_strCustNo,
                                             '10',
                                             strCheckChuteNo,
                                             v_deliverObj,
                                             v_strLineNo,
                                             v_strCurrArea,
                                             strUserId,
                                             strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    --新增复核单明细
    PKOBJ_ODATA_CHECK.p_insert_Odata_checkD_by_label(strEnterpriseNo,
                                                     strWareHouseNo,
                                                     v_strCheckNo,
                                                     v_containerNo,
                                                     strUserId,
                                                     strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    -- 复核标签单明细
    PKOBJ_ODATA_CHECK.p_insert_checkLabelD_by_label(strEnterpriseNo,
                                                    strWarehouseNo,
                                                    v_strCheckNo,
                                                    v_containerNo,
                                                    strUserId,
                                                    strResult);

    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    --更新来源标签的复核台
    update stock_label_m t
       set t.check_chute_no = strCheckChuteNo
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWareHouseNo
       and t.label_no = strlabelNo;

    strResult := 'Y|[成功]'; --成功
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_creat_odata_check_by_label;

  /************************************************************************************************
  功能说明：：
           1、校验单号；
           2、创建复核单
  ************************************************************************************************/
  procedure P_CheckAndCreate(strEnterpriseNo in odata_check_m.enterprise_no%type,
                             strWareHouseNo  in odata_check_m.warehouse_no%type,
                             strCheckChuteNo in odata_check_m.check_chute_no%type, --复核台滑道号
                             strTaksNo       in stock_label_m.source_no%type, --任务号，没有则传N
                             strBoxNo        in stock_label_m.label_no%type, --箱号/ 快递单号
                             strCheckType    in varchar2, --复核类型：1:按任务复核\按箱号；2：快递单号复核
                             strUserId       in odata_check_m.rgst_name%type,
                             strAutoOutstock in varchar2, --是否可自动下架回单:Y-可以,N-不可以
                             strCheckNo      out odata_check_m.check_no%type,
                             strResult       out varchar2) is
    v_strCheckNo  odata_check_m.check_no%type;

  begin
    strResult := 'N|[P_CheckAndCreate]';

    --自动拣货回单
    if strAutoOutstock = 'Y' then
      if strCheckType = '1' then

        --任务单号
        for curOutstockInfo in (select slm.label_no as stock_label_no,
                                       oom.task_type,
                                       --ood.*,
                                       ood.article_no,
                                       ood.outstock_no,
                                       ood.packing_qty,
                                       ood.s_cell_no,
                                       sum(ood.article_qty) article_qty,
                                       sum(ood.real_qty) real_qty,
                                       sai.quality,
                                       sai.produce_date,
                                       sai.expire_date,
                                       sai.lot_no,
                                       sai.rsv_batch1,
                                       sai.rsv_batch2,
                                       sai.rsv_batch3,
                                       sai.rsv_batch4,
                                       sai.rsv_batch5,
                                       sai.rsv_batch6,
                                       sai.rsv_batch7,
                                       sai.rsv_batch8
                                  from stock_label_m      slm,
                                       odata_outstock_d   ood,
                                       odata_outstock_m   oom,
                                       stock_article_info sai
                                 where oom.outstock_no = ood.outstock_no
                                   and oom.enterprise_no = ood.enterprise_no
                                   and oom.warehouse_no = ood.warehouse_no
                                   and oom.enterprise_no = strEnterpriseNo
                                   and oom.warehouse_no = strWareHouseNo
                                   and slm.source_no = oom.outstock_no
                                   and slm.enterprise_no = oom.enterprise_no
                                   and slm.warehouse_no = oom.warehouse_no
                                   and slm.status =
                                       CLABELSTATUS.PICK_HAND_OUT
                                   and (slm.source_no = strTaksNo or
                                       slm.label_no = strTaksNo)
                                   and sai.article_no = ood.article_no
                                   and sai.article_id = ood.article_id
                                   and sai.enterprise_no = ood.enterprise_no
                                   and ood.status < '13'
                                 group by slm.label_no,
                                          oom.task_type,
                                          --ood.*,
                                          ood.article_no,
                                          ood.outstock_no,
                                          ood.packing_qty,
                                          ood.s_cell_no,

                                          sai.quality,
                                          sai.produce_date,
                                          sai.expire_date,
                                          sai.lot_no,
                                          sai.rsv_batch1,
                                          sai.rsv_batch2,
                                          sai.rsv_batch3,
                                          sai.rsv_batch4,
                                          sai.rsv_batch5,
                                          sai.rsv_batch6,
                                          sai.rsv_batch7,
                                          sai.rsv_batch8) loop

          --流水标签
          if curOutstockInfo.Task_Type = '0' then
            PKLG_ODATA_LICH.P_SerialLabel_Save(strEnterpriseNo,
                                               strWareHouseNo,
                                               curOutstockInfo.Outstock_No,
                                               curOutstockInfo.stock_label_no,
                                               curOutstockInfo.Article_No,
                                               curOutstockInfo.Packing_Qty,
                                               curOutstockInfo.s_Cell_No,
                                               curOutstockInfo.Article_Qty -
                                               curOutstockInfo.Real_Qty,
                                               curOutstockInfo.Quality,
                                               curOutstockInfo.Produce_Date,
                                               curOutstockInfo.Expire_Date,
                                               curOutstockInfo.Lot_No,
                                               curOutstockInfo.Rsv_Batch1,
                                               curOutstockInfo.Rsv_Batch2,
                                               curOutstockInfo.Rsv_Batch3,
                                               curOutstockInfo.Rsv_Batch4,
                                               curOutstockInfo.Rsv_Batch5,
                                               curOutstockInfo.Rsv_Batch6,
                                               curOutstockInfo.Rsv_Batch7,
                                               curOutstockInfo.Rsv_Batch8,
                                               strUserId,
                                               strUserId,
                                               strUserId,
                                               strResult);

            if (substr(strResult, 1, 1) = 'N') then
              return;
            end if;
          end if;

          --任务标签
          if curOutstockInfo.Task_Type = '2' then
            PKLG_ODATA_LICH.P_TaskLabelSave_Odata_Outstock(strEnterpriseNo,
                                                           strWareHouseNo,
                                                           curOutstockInfo.Outstock_No,
                                                           curOutstockInfo.stock_label_no,
                                                           curOutstockInfo.stock_label_no,
                                                           curOutstockInfo.Article_No,
                                                           curOutstockInfo.Packing_Qty,
                                                           curOutstockInfo.s_Cell_No,
                                                           curOutstockInfo.Article_Qty-
                                                           curOutstockInfo.Real_Qty,
                                                            curOutstockInfo.Article_Qty-
                                                           curOutstockInfo.Real_Qty,
                                                           curOutstockInfo.Quality,
                                                           curOutstockInfo.Produce_Date,
                                                           curOutstockInfo.Expire_Date,
                                                           curOutstockInfo.Lot_No,
                                                           curOutstockInfo.Rsv_Batch1,
                                                           curOutstockInfo.Rsv_Batch2,
                                                           curOutstockInfo.Rsv_Batch3,
                                                           curOutstockInfo.Rsv_Batch4,
                                                           curOutstockInfo.Rsv_Batch5,
                                                           curOutstockInfo.Rsv_Batch6,
                                                           curOutstockInfo.Rsv_Batch7,
                                                           curOutstockInfo.Rsv_Batch8,
                                                           strCheckChuteNo,
                                                           strUserId,
                                                           strUserId,
                                                           strUserId,
                                                           strResult);
            if (substr(strResult, 1, 1) = 'N') then
              return;
            end if;
          end if;
        end loop;
        /*
          --箱号
          for curOutstockInfo in (select slm.label_no stock_label_no,
                                         oom.task_type,
                                         --ood.*,
                                         ood.article_no,
                                         ood.outstock_no,
                                         ood.packing_qty,
                                         ood.s_cell_no,
                                         sum(ood.article_qty) article_qty,
                                         sum(ood.real_qty) real_qty,
                                         sai.quality,
                                         sai.produce_date,
                                         sai.expire_date,
                                         sai.lot_no,
                                         sai.rsv_batch1,
                                         sai.rsv_batch2,
                                         sai.rsv_batch3,
                                         sai.rsv_batch4,
                                         sai.rsv_batch5,
                                         sai.rsv_batch6,
                                         sai.rsv_batch7,
                                         sai.rsv_batch8
                                    from stock_label_m      slm,
                                         odata_outstock_d   ood,
                                         odata_outstock_m   oom,
                                         stock_article_info sai
                                   where oom.outstock_no = ood.outstock_no
                                     and oom.enterprise_no = ood.enterprise_no
                                     and oom.warehouse_no = ood.warehouse_no
                                     and slm.label_no = strTaksNo
                                     and oom.enterprise_no = strEnterpriseNo
                                     and oom.warehouse_no = strWareHouseNo
                                     and slm.source_no = oom.outstock_no
                                     and slm.enterprise_no = oom.enterprise_no
                                     and slm.warehouse_no = oom.warehouse_no
                                     and slm.status =
                                         CLABELSTATUS.PICK_HAND_OUT
                                     and sai.article_no = ood.article_no
                                     and sai.article_id = ood.article_id
                                     and sai.enterprise_no = ood.enterprise_no
                                     and ood.status < '13'
                                   group by slm.label_no,
                                            oom.task_type,
                                            --ood.*,
                                            ood.article_no,
                                            ood.outstock_no,
                                            ood.packing_qty,
                                            ood.s_cell_no,
                                            sai.quality,
                                            sai.produce_date,
                                            sai.expire_date,
                                            sai.lot_no,
                                            sai.rsv_batch1,
                                            sai.rsv_batch2,
                                            sai.rsv_batch3,
                                            sai.rsv_batch4,
                                            sai.rsv_batch5,
                                            sai.rsv_batch6,
                                            sai.rsv_batch7,
                                            sai.rsv_batch8) loop

            --流水标签
            if curOutstockInfo.Task_Type = '0' then
              PKLG_ODATA_LICH.P_SerialLabel_Save(strEnterpriseNo,
                                                 strWareHouseNo,
                                                 curOutstockInfo.Outstock_No,
                                                 curOutstockInfo.stock_label_no,
                                                 curOutstockInfo.Article_No,
                                                 curOutstockInfo.Packing_Qty,
                                                 curOutstockInfo.s_Cell_No,
                                                 curOutstockInfo.Article_Qty -
                                                 curOutstockInfo.Real_Qty,
                                                 curOutstockInfo.Quality,
                                                 curOutstockInfo.Produce_Date,
                                                 curOutstockInfo.Expire_Date,
                                                 curOutstockInfo.Lot_No,
                                                 curOutstockInfo.Rsv_Batch1,
                                                 curOutstockInfo.Rsv_Batch2,
                                                 curOutstockInfo.Rsv_Batch3,
                                                 curOutstockInfo.Rsv_Batch4,
                                                 curOutstockInfo.Rsv_Batch5,
                                                 curOutstockInfo.Rsv_Batch6,
                                                 curOutstockInfo.Rsv_Batch7,
                                                 curOutstockInfo.Rsv_Batch8,
                                                 strUserId,
                                                 strUserId,
                                                 strUserId,
                                                 strResult);

              if (substr(strResult, 1, 1) = 'N') then
                return;
              end if;
            end if;
            --任务标签
            if curOutstockInfo.Task_Type = '2' then
              PKLG_ODATA_LICH.P_TaskLabelSave_Odata_Outstock(strEnterpriseNo,
                                                             strWareHouseNo,
                                                             curOutstockInfo.Outstock_No,
                                                             curOutstockInfo.stock_label_no,
                                                             curOutstockInfo.stock_label_no,
                                                             curOutstockInfo.Article_No,
                                                             curOutstockInfo.Packing_Qty,
                                                             curOutstockInfo.s_Cell_No,
                                                             curOutstockInfo.Article_Qty,
                                                             curOutstockInfo.Real_Qty,
                                                             curOutstockInfo.Quality,
                                                             curOutstockInfo.Produce_Date,
                                                             curOutstockInfo.Expire_Date,
                                                             curOutstockInfo.Lot_No,
                                                             curOutstockInfo.Rsv_Batch1,
                                                             curOutstockInfo.Rsv_Batch2,
                                                             curOutstockInfo.Rsv_Batch3,
                                                             curOutstockInfo.Rsv_Batch4,
                                                             curOutstockInfo.Rsv_Batch5,
                                                             curOutstockInfo.Rsv_Batch6,
                                                             curOutstockInfo.Rsv_Batch7,
                                                             curOutstockInfo.Rsv_Batch8,
                                                             strCheckChuteNo,
                                                             strUserId,
                                                             strUserId,
                                                             strUserId,
                                                             strResult);
              if (substr(strResult, 1, 1) = 'N') then
                return;
              end if;
            end if;
          end loop;
        */
      end if;
      --面单号
      if strCheckType = '2' then
        for curOutstockInfo in (select slm.label_no stock_label_no,
                                       oom.task_type,
                                       --ood.*,
                                       ood.article_no,
                                       ood.outstock_no,
                                       ood.packing_qty,
                                       ood.s_cell_no,
                                       sum(ood.article_qty) article_qty,
                                       sum(ood.real_qty) real_qty,
                                       sai.quality,
                                       sai.produce_date,
                                       sai.expire_date,
                                       sai.lot_no,
                                       sai.rsv_batch1,
                                       sai.rsv_batch2,
                                       sai.rsv_batch3,
                                       sai.rsv_batch4,
                                       sai.rsv_batch5,
                                       sai.rsv_batch6,
                                       sai.rsv_batch7,
                                       sai.rsv_batch8
                                  from stock_label_m      slm,
                                       odata_outstock_d   ood,
                                       odata_outstock_m   oom,
                                       stock_article_info sai,
                                       odata_exp_m        oem
                                 where oem.shipper_deliver_no = strTaksNo
                                   and oem.enterprise_no = ood.enterprise_no
                                   and oem.warehouse_no = oom.warehouse_no

                                   and oom.enterprise_no = ood.enterprise_no
                                   and oem.exp_no = ood.exp_no
                                   and oem.exp_type = ood.exp_type
                                   and oem.warehouse_no = ood.warehouse_no
                                   and oom.outstock_no = ood.outstock_no
                                   and slm.source_no = oom.outstock_no
                                   and slm.enterprise_no = oom.enterprise_no
                                   and slm.warehouse_no = oom.warehouse_no
                                   and slm.status =
                                       CLABELSTATUS.PICK_HAND_OUT
                                   and sai.article_no = ood.article_no
                                   and sai.article_id = ood.article_id
                                   and ood.status < '13'
                                 group by slm.label_no,
                                          oom.task_type,
                                          --ood.*,
                                          ood.article_no,
                                          ood.outstock_no,
                                          ood.packing_qty,
                                          ood.s_cell_no,
                                          sai.quality,
                                          sai.produce_date,
                                          sai.expire_date,
                                          sai.lot_no,
                                          sai.rsv_batch1,
                                          sai.rsv_batch2,
                                          sai.rsv_batch3,
                                          sai.rsv_batch4,
                                          sai.rsv_batch5,
                                          sai.rsv_batch6,
                                          sai.rsv_batch7,
                                          sai.rsv_batch8) loop

          --流水标签
          if curOutstockInfo.Task_Type = '0' then
            PKLG_ODATA_LICH.P_SerialLabel_Save(strEnterpriseNo,
                                               strWareHouseNo,
                                               curOutstockInfo.Outstock_No,
                                               curOutstockInfo.stock_label_no,
                                               curOutstockInfo.Article_No,
                                               curOutstockInfo.Packing_Qty,
                                               curOutstockInfo.s_Cell_No,
                                               curOutstockInfo.Article_Qty -
                                               curOutstockInfo.Real_Qty,
                                               curOutstockInfo.Quality,
                                               curOutstockInfo.Produce_Date,
                                               curOutstockInfo.Expire_Date,
                                               curOutstockInfo.Lot_No,
                                               curOutstockInfo.Rsv_Batch1,
                                               curOutstockInfo.Rsv_Batch2,
                                               curOutstockInfo.Rsv_Batch3,
                                               curOutstockInfo.Rsv_Batch4,
                                               curOutstockInfo.Rsv_Batch5,
                                               curOutstockInfo.Rsv_Batch6,
                                               curOutstockInfo.Rsv_Batch7,
                                               curOutstockInfo.Rsv_Batch8,
                                               strUserId,
                                               strUserId,
                                               strUserId,
                                               strResult);

            if (substr(strResult, 1, 1) = 'N') then
              return;
            end if;
          end if;
          --任务标签
          if curOutstockInfo.Task_Type = '2' then
            PKLG_ODATA_LICH.P_TaskLabelSave_Odata_Outstock(strEnterpriseNo,
                                                           strWareHouseNo,
                                                           curOutstockInfo.Outstock_No,
                                                           curOutstockInfo.stock_label_no,
                                                           curOutstockInfo.stock_label_no,
                                                           curOutstockInfo.Article_No,
                                                           curOutstockInfo.Packing_Qty,
                                                           curOutstockInfo.s_Cell_No,
                                                           curOutstockInfo.Article_Qty-
                                                           curOutstockInfo.Real_Qty,
                                                            curOutstockInfo.Article_Qty-
                                                           curOutstockInfo.Real_Qty,
                                                           curOutstockInfo.Quality,
                                                           curOutstockInfo.Produce_Date,
                                                           curOutstockInfo.Expire_Date,
                                                           curOutstockInfo.Lot_No,
                                                           curOutstockInfo.Rsv_Batch1,
                                                           curOutstockInfo.Rsv_Batch2,
                                                           curOutstockInfo.Rsv_Batch3,
                                                           curOutstockInfo.Rsv_Batch4,
                                                           curOutstockInfo.Rsv_Batch5,
                                                           curOutstockInfo.Rsv_Batch6,
                                                           curOutstockInfo.Rsv_Batch7,
                                                           curOutstockInfo.Rsv_Batch8,
                                                           strCheckChuteNo,
                                                           strUserId,
                                                           strUserId,
                                                           strUserId,
                                                           strResult);
            if (substr(strResult, 1, 1) = 'N') then
              return;
            end if;
          end if;
        end loop;
      end if;
    end if;


    P_TaskAndBoxCheck(strEnterpriseNo,
                      strWareHouseNo,
                      strCheckChuteNo,
                      strTaksNo,
                      strTaksNo,
                      strCheckType,
                      v_strCheckNo,
                      strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    if v_strCheckNo = 'N' or v_strCheckNo is null then

      --创建复核单
      p_creat_odata_check(strEnterpriseNo,
                          strWareHouseNo,
                          strCheckChuteNo,
                          strTaksNo,
                          strTaksNo,
                          strCheckType,
                          strUserId,
                          v_strCheckNo,
                          strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
    end if;

    strCheckNo := v_strCheckNo;

    strResult := 'Y';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_CheckAndCreate;

  /************************************************************************************************
  功能说明：复核单校验：
           1、支持按任务号校验；
           2、支持按箱号校验
  ************************************************************************************************/
  procedure P_TaskAndBoxCheck(strEnterpriseNo in odata_check_m.enterprise_no%type,
                              strWareHouseNo  in odata_check_m.warehouse_no%type,
                              strCheckChuteNo in odata_check_m.check_chute_no%type, --复核台滑道号
                              strTaksNo       in stock_label_m.source_no%type, --任务号，没有则传N
                              strBoxNo        in stock_label_m.label_no%type, --箱号/ 快递单号
                              strCheckType    in varchar2, --复核类型：1:按任务复核或按箱号；2：快递单号复核
                              strCheckNo      out odata_check_m.check_no%type,
                              strResult       out varchar2) is
    v_strCheckNo      odata_check_m.check_no%type;
    v_strCheckChuteNo odata_check_m.check_chute_no%type;
    v_strStatus       stock_label_m.status%type;
    v_strUseType      stock_label_m.use_type%type;
    v_Count           integer := 0;
    v_Check_Level     WMS_CHECK_STRATEGY.Check_Level%type; --复核级别

  begin
    strResult := 'N|[P_TaskAndBoxCheck]';

    --按面单进行复核
    if strCheckType = '2' then
      begin
        select t.check_no, ocm.check_chute_no
          into v_strCheckNo, v_strCheckChuteNo
          from odata_check_label_d t, stock_label_m slm, odata_check_m ocm
         where t.enterprise_no = ocm.enterprise_no
           and t.warehouse_no = ocm.warehouse_no
           and t.check_no = ocm.check_no
           and t.enterprise_no = slm.enterprise_no
           and t.warehouse_no = slm.warehouse_no
           and t.enterprise_no = strEnterpriseNo
           and t.warehouse_no = strWareHouseNo
           and t.lable_no = slm.label_no

           and exists (select 'x'
                  from odata_exp_m oem
                 where oem.shipper_deliver_no = strTaksNo
                   and oem.enterprise_no = strEnterpriseNo
                   and oem.warehouse_no = strWareHouseNo
                   and oem.exp_no = t.exp_no
                   and oem.exp_type = t.exp_type
                   and oem.status <> '16')
              --and slm.status not in ('C0', '50', 'A0', 'A1')
           and slm.status = '6A'
           and rownum = 1;
      exception
        when no_data_found then
          strCheckNo := 'N';
      end;
    end if;

    if strCheckType = '1' then
      --获取复核单号
      begin
        select t.check_no, ocm.check_chute_no
          into v_strCheckNo, v_strCheckChuteNo
          from odata_check_label_d t, stock_label_m slm, odata_check_m ocm
         where t.enterprise_no = ocm.enterprise_no
           and t.warehouse_no = ocm.warehouse_no
           and t.check_no = ocm.check_no
           and t.enterprise_no = slm.enterprise_no
           and t.warehouse_no = slm.warehouse_no
           and t.enterprise_no = strEnterpriseNo
           and t.warehouse_no = strWareHouseNo
           and t.lable_no = slm.label_no
           and slm.status = '6A'
           and (slm.source_no = strTaksNo or slm.label_no = strTaksNo)
           and rownum = 1;
      exception
        when no_data_found then
          --没有复核单号
          strCheckNo := 'N';
      end;
    end if;

    --判断标签是否存在
    select count(1)
      into v_Count
      from stock_label_m slm
     where slm.enterprise_no = strEnterpriseNo
       and slm.warehouse_no = strWareHouseNo
       and slm.status = '6A'
       and slm.use_type = '1'
       and (slm.source_no = strTaksNo or slm.label_no = strTaksNo);
    if v_Count <= 0 then
      strResult := 'N|[' || strTaksNo || '该任务不存在]';
      return;
    end if;

    if v_strCheckChuteNo <> strCheckChuteNo then
      strResult := 'N|[该单已在' || v_strCheckChuteNo || '复核台扫描过]';
      return;
    end if;

    --
    select t.check_level
      into v_Check_Level
      from WMS_CHECK_STRATEGY t
     where t.check_type = 'B'
       and exists
     (select 'x'
              from odata_locate_batch olb, stock_label_m slm
             where olb.b_check_strategy_id = t.check_strategy_id
               and olb.enterprise_no = t.enterprise_no
               and slm.enterprise_no = strEnterpriseNo
               and slm.warehouse_no = strWareHouseNo
               and (slm.source_no = strTaksNo or slm.label_no = strTaksNo)
               and slm.wave_no = olb.wave_no
               and slm.batch_no = olb.batch_no
               and slm.warehouse_no = olb.warehouse_no
               and slm.enterprise_no = olb.enterprise_no);

    --按单复核
    if v_Check_Level = '2' then
      select count(1)
        into v_Count
        from stock_label_m a, stock_label_d b
       where a.enterprise_no = b.enterprise_no
         and a.warehouse_no = b.warehouse_no
         and a.container_no = b.container_no
         and a.status < '6A'
         and exists
       (select 'x'
                from stock_label_m c, stock_label_d d
               where c.enterprise_no = strEnterpriseNo
                 and c.warehouse_no = strWareHouseNo
                 and c.enterprise_no = d.enterprise_no
                 and c.warehouse_no = d.warehouse_no
                 and c.container_no = d.container_no
                 and b.enterprise_no = d.enterprise_no
                 and b.warehouse_no = d.warehouse_no
                 and b.exp_no = d.exp_no
                 and b.exp_type = d.exp_type
                 and (c.source_no = strTaksNo or c.label_no = strTaksNo));
    end if;

    --按批次
    if v_Check_Level = '3' then
      select count(1)
        into v_Count
        from stock_label_m a, stock_label_d b
       where a.enterprise_no = b.enterprise_no
         and a.warehouse_no = b.warehouse_no
         and a.container_no = b.container_no
         and a.status < '6A'
         and exists
       (select 'x'
                from stock_label_m c, stock_label_d d
               where c.enterprise_no = strEnterpriseNo
                 and c.warehouse_no = strWareHouseNo
                 and c.enterprise_no = d.enterprise_no
                 and c.warehouse_no = d.warehouse_no
                 and c.container_no = d.container_no
                 and b.enterprise_no = d.enterprise_no
                 and b.warehouse_no = d.warehouse_no
                 and b.batch_no = d.batch_no
                 and (c.source_no = strTaksNo or c.label_no = strTaksNo));
    end if;

    if v_Count > 0 then
      strResult := 'N|[该任务' || strTaksNo || '还未完成！]';
      return;
    end if;

    strCheckNo := v_strCheckNo;

    strResult := 'Y';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_TaskAndBoxCheck;

  /***********************************************************************************************
   --扫描商品条码-整理容器
   功能说明：根据来源标签里的商品进行复核
   chensr
   2015.5.5
   调用 pkobj_odata_check.P_UpdtaOdataCheckD 增加返回错误 huangb 20160602
  ***********************************************************************************************/
  procedure P_CheckLabelArticle(strEnterpriseNo in odata_check_m.enterprise_no%type,
                                strWareHouseNo  in odata_check_m.warehouse_no%type,
                                strCheckNo      in odata_check_m.check_no%type,
                                strArticle_No   in odata_check_d.article_no%type, --商品编码
                                nPacking_QTY    in odata_check_d.packing_qty%type, --包装数量
                                strQuality      in stock_article_info.quality%type, --品质
                                dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                                dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                                strLotNo        in stock_article_info.lot_no%type, --批次号
                                strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                                strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                                strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                                strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                                strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                                strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                                strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                                strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                                strBarcode      in stock_article_info.barcode%type,
                                strSLabelNo     in odata_check_label_d.lable_no%type, --来源标签
                                strDLabelNo     in stock_label_m.label_no%type, --目的标签
                                nRealQty        in odata_check_d.real_qty%type, --回单数量
                                strUserId       in odata_check_m.rgst_name%type,
                                strResult       out varchar2) is
    v_nCurrQty   odata_check_d.real_qty%type;
    v_nRemainQty odata_check_d.real_qty%type;
  begin
    strResult := 'N|[P_CheckLabelArticle]';

    v_nRemainQty := nRealQty;

    for GetOdataCheckItem in (select ocd.*
                                from odata_check_label_d ocd,
                                     stock_article_info  sai
                               where ocd.enterprise_no = sai.enterprise_no
                                 and ocd.article_no = sai.article_no
                                 and ocd.article_id = sai.article_id
                                 and ocd.enterprise_no = strEnterpriseNo
                                 and ocd.warehouse_no = strWareHouseNo
                                 and ocd.check_no = strCheckNo
                                 and ocd.article_no = strArticle_No
                                 and ocd.packing_qty = nPacking_QTY
                                 and sai.produce_date = dtProduceDate
                                 and sai.expire_date = dtExpireDate
                                 and sai.lot_no = strLotNo
                                 and sai.quality = strQuality
                                 and sai.rsv_batch1 = strRSV_BATCH1
                                 and sai.rsv_batch2 = strRSV_BATCH2
                                 and sai.rsv_batch3 = strRSV_BATCH3
                                 and sai.rsv_batch4 = strRSV_BATCH4
                                 and sai.rsv_batch5 = strRSV_BATCH5
                                 and sai.rsv_batch6 = strRSV_BATCH6
                                 and sai.rsv_batch7 = strRSV_BATCH7
                                 and sai.rsv_batch8 = strRSV_BATCH8
                                 and ocd.LABLE_NO = strSLabelNo
                                 and ocd.article_qty - ocd.real_qty > 0
                               order by ocd.article_id) loop

      if v_nRemainQty >= GetOdataCheckItem.real_qty then
        v_nCurrQty := GetOdataCheckItem.real_qty;
      else
        v_nCurrQty := v_nRemainQty;
      end if;

      v_nRemainQty := v_nRemainQty - v_nCurrQty;

      --更新复核标签明细
      PKOBJ_ODATA_CHECK.P_UpdateOdataCheckLabelD(strEnterpriseNo,
                                                 strWareHouseNo,
                                                 strCheckNo,
                                                 GetOdataCheckItem.container_no,
                                                 strDLabelNo,
                                                 GetOdataCheckItem.row_id,
                                                 v_nCurrQty,
                                                 strUserId,
                                                 strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --更新复核单明细
      pkobj_odata_check.P_UpdtaOdataCheckD(strEnterpriseNo,
                                           strWareHouseNo,
                                           strCheckNo,
                                           GetOdataCheckItem.Exp_No,
                                           GetOdataCheckItem.article_no,
                                           GetOdataCheckItem.packing_qty,
                                           v_nCurrQty,
                                           strUserId,
                                           strResult);
      if (substr(strResult, 1, 1) <> 'Y') then
        return;
      end if;

      --整理商品
      p_Arrange_Save_Article(strEnterpriseNo,
                             strWarehouseNo,
                             strSLabelNo,
                             strDLabelNo,
                             GetOdataCheckItem.Deliver_Obj,
                             strArticle_No,
                             nPacking_QTY,
                             strQuality,
                             dtProduceDate,
                             dtExpireDate,
                             strLotNo,
                             strRSV_BATCH1,
                             strRSV_BATCH2,
                             strRSV_BATCH3,
                             strRSV_BATCH4,
                             strRSV_BATCH5,
                             strRSV_BATCH6,
                             strRSV_BATCH7,
                             strRSV_BATCH8,
                             strBarcode,
                             v_nCurrQty,
                             strUserId,
                             strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      if v_nRemainQty <= 0 then
        exit;
      end if;
    end loop;

    PKOBJ_ODATA_CHECK.P_UpdateOdataCheckM(strEnterpriseNo,
                                          strWareHouseNo,
                                          strCheckNo,
                                          strUserId,
                                          strResult);

    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

  end P_CheckLabelArticle;

  /***********************************************************************************************
   --扫描商品条码-整理容器（电商）
   功能说明：根据复核单里的商品进行复核，需循环按商品抓取标签号再进行处理
   chensr
   2015.5.5
  ***********************************************************************************************/
  procedure P_CheckArticle(strEnterpriseNo in odata_check_m.enterprise_no%type,
                           strWareHouseNo  in odata_check_m.warehouse_no%type,
                           strCheckNo      in odata_check_m.check_no%type,
                           strDeliverObj   in odata_check_m.deliver_obj%type,
                           strArticle_No   in odata_check_d.article_no%type, --商品编码
                           nPacking_QTY    in odata_check_d.packing_qty%type, --包装数量
                           strQuality      in stock_article_info.quality%type, --品质
                           dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                           dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                           strLotNo        in stock_article_info.lot_no%type, --批次号
                           strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                           strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                           strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                           strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                           strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                           strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                           strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                           strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                           strBarcode      in stock_article_info.barcode%type,
                           strsLabelNo     in stock_label_m.label_no%type,
                           strDLabelNo     in stock_label_m.label_no%type, --目的标签
                           nRealQty        in odata_check_d.real_qty%type, --回单数量
                           strUserId       in odata_check_m.rgst_name%type,
                           strResult       out varchar2) is

    v_nCurrQty odata_check_d.real_qty%type;
    --v_nSumQty    odata_check_d.real_qty%type;
    v_nRemainQty odata_check_d.real_qty%type;
    v_iCount     integer := 0;
  begin
    strResult := 'N|[P_CheckArticle]';

    v_nRemainQty := nRealQty;
    if v_nRemainQty < 0 then
      v_nRemainQty := v_nRemainQty * -1;
    end if;

    for GetOdataCheckItem in (select ocd.*
                                from odata_check_label_d ocd,
                                     stock_article_info  sai
                               where ocd.enterprise_no = sai.enterprise_no
                                 and ocd.article_no = sai.article_no
                                 and ocd.article_id = sai.article_id
                                 and ocd.enterprise_no = strEnterpriseNo
                                 and ocd.warehouse_no = strWareHouseNo
                                 and ocd.check_no = strCheckNo
                                 and ocd.lable_no = strsLabelNo
                                 and ocd.article_no = strArticle_No
                                 and ocd.packing_qty = nPacking_QTY
                                 and sai.produce_date = dtProduceDate
                                 and sai.expire_date = dtExpireDate
                                 and sai.lot_no = strLotNo
                                 and sai.quality = strQuality
                                 and sai.rsv_batch1 = strRSV_BATCH1
                                 and sai.rsv_batch2 = strRSV_BATCH2
                                 and sai.rsv_batch3 = strRSV_BATCH3
                                 and sai.rsv_batch4 = strRSV_BATCH4
                                 and sai.rsv_batch5 = strRSV_BATCH5
                                 and sai.rsv_batch6 = strRSV_BATCH6
                                 and sai.rsv_batch7 = strRSV_BATCH7
                                 and sai.rsv_batch8 = strRSV_BATCH8
                                 and ocd.deliver_obj = strDeliverObj
                                 and ocd.status in ('10', '11')
                               order by ocd.container_no, ocd.article_id) loop

      v_iCount := v_iCount + 1;

      if nRealQty > 0 then
        --
        v_nCurrQty := GetOdataCheckItem.article_qty -
                      GetOdataCheckItem.real_qty;
        if v_nCurrQty > v_nRemainQty then
          v_nCurrQty := v_nRemainQty;
        end if;

        v_nRemainQty := v_nRemainQty - v_nCurrQty;
      else

        v_nCurrQty := GetOdataCheckItem.real_qty;
        if v_nCurrQty > v_nRemainQty then
          v_nCurrQty := v_nRemainQty;
        end if;

        v_nRemainQty := v_nRemainQty - v_nCurrQty;

        v_nCurrQty := v_nCurrQty * -1;

      end if;

      --更新复核标签明细
      PKOBJ_ODATA_CHECK.P_UpdateOdataCheckLabelD(strEnterpriseNo,
                                                 strWareHouseNo,
                                                 strCheckNo,
                                                 GetOdataCheckItem.container_no,
                                                 strDLabelNo,
                                                 GetOdataCheckItem.row_id,
                                                 v_nCurrQty,
                                                 strUserId,
                                                 strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --更新复核单明细
      pkobj_odata_check.P_UpdtaOdataCheckD(strEnterpriseNo,
                                           strWareHouseNo,
                                           strCheckNo,
                                           GetOdataCheckItem.Exp_No,
                                           GetOdataCheckItem.article_no,
                                           GetOdataCheckItem.packing_qty,
                                           v_nCurrQty,
                                           strUserId,
                                           strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      if v_nRemainQty = 0 then
        exit;
      end if;

    end loop;

    if v_nRemainQty > 0 then
      strResult := 'N|[库存扣减超量]';
      return;

    end if;

    if v_iCount = 0 then
      strResult := 'N|[找不到要复核的标签明细]';
      return;
    end if;

    strResult := 'Y';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_CheckArticle;
  /**************************************************************************************************
  功能说明：复核转病单
  luozhiling
  2015.5.5
  **************************************************************************************************/
  procedure P_DiffCheckSave(strEnterpriseNo in odata_check_m.enterprise_no%type,
                            strWareHouseNo  in odata_check_m.warehouse_no%type,
                            strCheckNo      in odata_check_m.check_no%type,
                            strDeliverObj   in odata_check_m.deliver_obj%type,
                            strUserId       in odata_check_m.updt_name%type,
                            strResult       out varchar2) is

    v_Exp_No odata_exp_m.exp_no%type := 'N';
  begin
    strResult := 'N|[P_DiffCheckSave]';

    --对复核单里未回单的明细进行回单；

    update odata_check_label_d t
       set t.status     = '13',
           t.check_name = strUserId,
           t.check_date = sysdate
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWareHouseNo
       and t.check_no = strCheckNo
       and t.deliver_obj=strDeliverObj
       and t.status = '10';

    --对复核单明细进行回单
    update odata_check_d t
       set t.status     = '13',
           t.check_name = strUserId,
           t.check_date = sysdate
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWareHouseNo
       and t.check_no = strCheckNo
       and t.deliver_obj=strDeliverObj
       and t.status = '10';

    --对有差异的原标签做转病单
    for GetLabel in (select distinct owner_no, lable_no, exp_no
                       from odata_check_label_d
                      where enterprise_no = strEnterpriseNo
                        and warehouse_no = strWareHouseNo
                        and check_no = strCheckNo
                        and deliver_obj=strDeliverObj
                        and article_qty <> real_qty
                      order by exp_no, lable_no) loop

      if v_Exp_No <> GetLabel.Exp_No then
        --转病单
        PKLG_ODATA_EXPCANCEL.P_TurnOdataExpCancel(strEnterPriseNo,
                                                  strWarehouseNo,
                                                  GetLabel.Owner_No,
                                                  GetLabel.Exp_No,
                                                  '3', --复核转病单
                                                  strUserId,
                                                  strResult);
        if substr(strResult, 1, 1) <> 'Y' then
          return;
        end if;

        --单据状态跟踪，转病单
        PKOBJ_ODISPATCH.P_Insert_Odata_Exp_Trace(strEnterPriseNo,
                                                 strWarehouseNo,
                                                 GetLabel.Exp_No,
                                                 COdataExpStatus.ExpTracAllIllness,
                                                 strUserId,
                                                 strResult);
        if substr(strResult, 1, 1) <> 'Y' then
          return;
        end if;
      end if;

      --标签跟踪
      update stock_label_m slm
         set slm.status    = 'C0',
             slm.updt_name = strUserId,
             slm.updt_date = sysdate
       where slm.enterprise_no = strEnterPriseNo
         and slm.warehouse_no = strWarehouseNo
         and slm.label_no = GetLabel.lable_no;

      v_Exp_No := GetLabel.Exp_No;
    end loop;

    --更新复核单头档
    pkobj_odata_check.P_UpdateOdataCheckM(strEnterpriseNo,
                                          strWareHouseNo,
                                          strCheckNo,
                                          strUserId,
                                          strResult);

    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    --复核单转历史
    PKOBJ_ODATA_CHECK.p_insert_Odata_check_log(strEnterpriseNo,
                                               strWareHouseNo,
                                               strCheckNo,
                                               strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    strResult := 'Y|[成功]';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_DiffCheckSave;

 /***********************************************************************************************
   --扫描商品条码-整理容器（电商）--自动封箱，转病单
   功能说明：按复核单上的商品进行复核
   chensr
   2015.5.5
   功能描述：1、根据条码取订单；
             2、若此订单未产生复核标签，新取号
             3、若此订单已有复核标签，复核保存
             4、若整订单扫描完成，自动封箱

  ***********************************************************************************************/
 procedure p_scanArticle_cutBox_sickOrder(strEnterpriseNo  in odata_check_m.enterprise_no%type,
                                           strWareHouseNo   in odata_check_m.warehouse_no%type,
                                           strCheckNo       in odata_check_m.check_no%type,
                                           strTaksNo        in stock_label_m.source_no%type, --任务号或快递单号
                                           strDeliverObj    in odata_check_m.deliver_obj%type, --第一次传N，后面用返回的值
                                           strArticle_No    in odata_check_d.article_no%type, --商品编码
                                           nRealQty         in odata_check_d.real_qty%type, --回单数量
                                           strUserId        in odata_check_m.rgst_name%type,
                                           strDockNo        in ridata_check_m.dock_no%type,
                                           strPrintWayBill  in odata_outstock_m.task_type%type, --是否打印快递面单，0：不打印，1：打印
                                           strPrintPackList in odata_outstock_m.task_type%type, --是否打印装箱清单，0：不打印，1：打印
                                           strPrintInVoice  in odata_outstock_m.task_type%type, --是否打印发票，0：不打印，1：打印
                                           strCheckType     in varchar2, --复核类型：1:按任务复核或箱号；2：快递单号复核
                                           strCloseFlag     out varchar2, --封箱标识，'Y' 完成；‘N'未完成
                                           strOutDeliverObj out stock_label_m.deliver_obj%type,
                                           strOutLabelNo    out stock_label_m.label_no%type,
                                           strPackMateMsg   out bdef_defarticle.article_name%type, --提示的包材名称
                                           strOutFinishFlag out varchar2, --复核完成标识，'Y' 完成；‘N'未完成
                                           strResult        out varchar2) is
    v_iCount          integer := 0;
    v_strDeliverOBJ   odata_check_m.deliver_obj%type := 'N';
    v_Exp_No          odata_exp_m.exp_no%type;
    v_nCurrQty        odata_check_d.real_qty%type;
    v_nRemainQty      odata_check_d.real_qty%type := abs(nRealQty);
    v_QMinPack        bdef_defarticle.qmin_operate_packing%type;
    v_Task_No         varchar2(100) := 'N';
    v_D_Label_No      stock_label_m.label_no%type;
    strPromptPackmate varchar2(1) := '0';
    v_PackMateNo      bdef_defarticle.article_no%type;
    v_CheckStrage     wms_check_strategy.check_strategy_id%type;

    --发票
    v_Print_InVoice_Flag odata_exp_m.print_bill_flag%type;
    v_Print_InVoiceCount odata_exp_m.ENVOICE_PRINT_STATUS%type;

    --清单
    v_Print_PackList_Flag ODATA_LOCATE_BATCH.PRINT_PACKLIST%type;
    v_Print_PackListCount odata_exp_m.packlist_print_status%type;

    --面单
    v_Print_WayBill_Flag ODATA_LOCATE_BATCH.PRINT_WAYBILL%type;
    v_Print_WayBillCount odata_exp_m.waybill_print_status%type;
    

  begin
    strResult := 'N|[p_scanArticle_cutBox_sickOrder]';

    begin
      select bda.qmin_operate_packing
        into v_QMinPack
        from bdef_defarticle bda
       where bda.enterprise_no = strEnterpriseNo
         and bda.article_no = strArticle_No;
    exception
      when no_data_found then
        strResult := 'N|找不到商品资料-' || strArticle_No;
        return;
    end;

    if nvl(v_QMinPack, 0) <= 0 then
      v_QMinPack := 1;
    end if;

    --换算成最小单位
    v_nRemainQty := v_nRemainQty * v_QMinPack;
    
    --直接按商品配给任一单
    for GetCheckLabel in (select ocd.deliver_obj,
                                 ocd.article_no,
                                 ocd.packing_qty,
                                 ocd.row_id,
                                 ocd.container_no,
                                 ocd.d_label_no,
                                 sai.barcode,
                                 sai.quality,
                                 sai.produce_date,
                                 sai.expire_date,
                                 sai.lot_no,
                                 sai.rsv_batch1,
                                 sai.rsv_batch2,
                                 sai.rsv_batch3,
                                 sai.rsv_batch4,
                                 sai.rsv_batch5,
                                 sai.rsv_batch6,
                                 sai.rsv_batch7,
                                 sai.rsv_batch8,
                                 ocd.lable_no,
                                 ocd.exp_no,
                                 ocd.exp_type,
                                 oem.status                exp_status,
                                 oem.print_bill_flag       Print_InVoice_Flag,
                                 OLB.PRINT_PACKLIST        Print_PackList_Flag,
                                 OLB.PRINT_WAYBILL         Print_WayBill_Flag,
                                 OLB.INDUSTRY_FLAG,
                                 OLB.B_CHECK_STRATEGY_ID,
                                 OEM.SHIPPER_DELIVER_NO,
                                 oem.ENVOICE_PRINT_STATUS  Print_InVoiceCount,
                                 oem.PACKLIST_PRINT_STATUS Print_PackListCount,
                                 oem.waybill_print_status  Print_WayBillCount,
                                 ocd.article_qty,
                                 ocd.real_qty
                            from odata_check_label_d ocd,
                                 stock_article_info  sai,
                                 odata_exp_m         oem,
                                 ODATA_LOCATE_BATCH  OLB
                           where olb.enterprise_no = oem.enterprise_no
                             and olb.warehouse_no = oem.warehouse_no
                             and olb.wave_no = oem.wave_no
                             and olb.batch_no = oem.batch_no
                             and ocd.exp_no = oem.exp_no
                             and ocd.exp_type = oem.exp_type
                             and ocd.enterprise_no = sai.enterprise_no
                             and ocd.article_no = sai.article_no
                             and ocd.article_id = sai.article_id
                             --and ocd.lable_no = strTaksNo    --导致一单多品同批次复核混乱的原因
                             and ocd.enterprise_no = strEnterpriseNo
                             and ocd.warehouse_no = strWareHouseNo
                             and ocd.check_no = strCheckNo
                             and ocd.article_no = strArticle_No
                             and ocd.article_qty - ocd.real_qty >= nRealQty
                             and ocd.status < '13'
                             and (strDeliverObj = 'N' or
                                 (strDeliverObj <> 'N' and
                                 ocd.deliver_obj = strDeliverObj))
                           order by ocd.status desc,
                                    oem.status,
                                    ocd.deliver_obj,
                                    oem.print_bill_flag,
                                    OLB.PRINT_PACKLIST,
                                    OLB.PRINT_WAYBILL,
                                    oem.ENVOICE_PRINT_STATUS,
                                    oem.PACKLIST_PRINT_STATUS,
                                    oem.waybill_print_status,
                                    ocd.article_no,
                                    ocd.packing_qty,
                                    sai.barcode,
                                    sai.quality,
                                    sai.produce_date,
                                    sai.expire_date,
                                    sai.lot_no,
                                    sai.rsv_batch1,
                                    sai.rsv_batch2,
                                    sai.rsv_batch3,
                                    sai.rsv_batch4,
                                    sai.rsv_batch5,
                                    sai.rsv_batch6,
                                    sai.rsv_batch7,
                                    sai.rsv_batch8,
                                    ocd.lable_no,
                                    ocd.exp_no,
                                    ocd.exp_type) loop

      --判断单据是否取消
      if GetCheckLabel.exp_status = '16' then
        strResult := 'N|订单' || GetCheckLabel.exp_no || '已取消！';
        return;
      end if;

      if v_iCount = 0 and strDeliverObj = 'N' and
         GetCheckLabel.Industry_Flag = '1' --传统行业
       then
        --新取号
        P_DeliverObjLableNo(strEnterpriseNo,
                            strWareHouseNo,
                            strCheckNo,
                            GetCheckLabel.deliver_obj,
                            'B',
                            strUserId,
                            strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;
      end if;

      --电商行业
      if GetCheckLabel.Industry_Flag = '2' then
        v_D_Label_No := GetCheckLabel.Shipper_Deliver_No;
      else
        v_D_Label_No := GetCheckLabel.Deliver_Obj;
      end if;

      v_iCount := v_iCount + 1;

      --Add BY QZH AT 2016-6-24 一次只处理一个配送对象
      if v_strDeliverOBJ <> GetCheckLabel.deliver_obj and
         v_strDeliverOBJ <> 'N' then
        exit;
      end if;

      strOutLabelNo        := v_D_Label_No;
      v_strDeliverOBJ      := GetCheckLabel.deliver_obj;
      v_Exp_No             := GetCheckLabel.exp_No;
      v_Print_InVoice_Flag := GetCheckLabel.Print_InVoice_Flag;
      v_Print_InVoiceCount := GetCheckLabel.Print_InVoiceCount;

      v_Print_PackList_Flag := GetCheckLabel.Print_PackList_Flag;
      v_Print_PackListCount := GetCheckLabel.Print_PackListCount;

      v_Print_WayBill_Flag := GetCheckLabel.Print_WayBill_Flag;
      v_Print_WayBillCount := GetCheckLabel.Print_WayBillCount;
      v_CheckStrage        := GetCheckLabel.B_CHECK_STRATEGY_ID;

      if nRealQty > 0 then
        --正常扫描，取差异量
        v_nCurrQty := GetCheckLabel.article_qty - GetCheckLabel.real_qty;
        if v_nCurrQty > v_nRemainQty then
          v_nCurrQty := v_nRemainQty;
        end if;

        v_nRemainQty := v_nRemainQty - v_nCurrQty;
      else
        --取消扫描，取已扫描量
        v_nCurrQty := GetCheckLabel.real_qty;

        if v_nCurrQty > v_nRemainQty then
          v_nCurrQty := v_nRemainQty;
        end if;

        v_nRemainQty := v_nRemainQty - v_nCurrQty;
        v_nCurrQty   := v_nCurrQty * -1;
      end if;

      --更新复核标签明细
      PKOBJ_ODATA_CHECK.P_UpdateOdataCheckLabelD(strEnterpriseNo,
                                                 strWareHouseNo,
                                                 strCheckNo,
                                                 GetCheckLabel.container_no,
                                                 v_D_Label_No,
                                                 GetCheckLabel.Row_Id,
                                                 v_nCurrQty,
                                                 strUserId,
                                                 strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --更新复核单明细
      pkobj_odata_check.P_UpdtaOdataCheckD(strEnterpriseNo,
                                           strWareHouseNo,
                                           strCheckNo,
                                           GetCheckLabel.Exp_No,
                                           GetCheckLabel.Article_No,
                                           GetCheckLabel.Packing_Qty,
                                           v_nCurrQty,
                                           strUserId,
                                           strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      if v_nRemainQty = 0 then
        exit;
      end if;
    end loop;

    if v_iCount = 0 then
      strResult := 'N|[当前任务不存在此条码]';
      return;
    end if;

    if v_nRemainQty > 0 then
      strResult := 'N|[库存扣减超量]';
      return;
    end if;

    --判断此配送对象是否全部回单
    select count(*)
      into v_iCount
      from odata_check_d ood
     where ood.enterprise_no = strEnterpriseNo
       and ood.warehouse_no = strWareHouseNo
       and ood.check_no = strCheckNo
       and ood.deliver_obj = v_strDeliverOBJ
       and ood.status < '13';

    strOutDeliverObj := v_strDeliverOBJ;
    if v_iCount = 0 then
      --复核完成
      strCloseFlag := 'Y';
      --对此配送对象自动封箱
      P_CLOSEBOX(strEnterPriseNo,
                 strWareHouseNo,
                 strUserId,
                 v_D_Label_No,
                 --strPrinterGroupNo,
                 strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --打印发票
      if v_Print_InVoiceCount <= 0 then
        if v_Print_InVoice_Flag > '0' or strPrintInVoice = '1' then
          PKLG_WMS_Public.p_Insert_SpecialReportTask(strEnterPriseNo,
                                                     strWareHouseNo,
                                                     CREPORT_TYPE.TYPE_INV,
                                                     v_Exp_No, --v_strDeliverOBJ,
                                                     strDockNo,
                                                     '0',
                                                     strUserId,
                                                     v_Task_No,
                                                     strResult);
        end if;
      end if;

       --装箱清单
      if v_Print_PackListCount <= 0 then
        if v_Print_PackList_Flag > '0' or strPrintPackList = '1' then
          PKLG_WMS_Public.p_Insert_SpecialReportTaskExt(strEnterPriseNo,
                                                     strWareHouseNo,
                                                     CREPORT_TYPE.TYPE_BOX,
                                                     v_Exp_No, --v_strDeliverOBJ,
                                                     strDockNo,
                                                     '0',
                                                     strUserId,
                                                     '3',--复核时打印
                                                     'N',
                                                     'N',
                                                     'N',
                                                     'N',
                                                     'N',
                                                     'N',
                                                     'N',
                                                     v_Task_No,
                                                     strResult);
        end if;
      end if;

      --打印面单
      if v_Print_WayBillCount <= 0 then
        if --strCheckType = '1' and
           (v_Print_WayBill_Flag > '0' or strPrintWayBill = '1') then
          --不是按面单扫描
          
          PKLG_WMS_Public.p_Insert_SpecialReportTask(strEnterPriseNo,
                                                     strWareHouseNo,
                                                     CREPORT_TYPE.TYPE_WAY,
                                                     v_Exp_No, --v_strDeliverOBJ,
                                                     strDockNo,
                                                     '0',
                                                     strUserId,
                                                     v_Task_No,
                                                     strResult);
        end if;
      end if;

      --单据状态跟踪
      PKOBJ_ODISPATCH.P_Insert_Odata_Exp_Trace(strEnterPriseNo,
                                               strWareHouseNo,
                                               v_Exp_No,
                                               COdataExpStatus.ExpTracAllCheck,
                                               strUserID,
                                               strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;
    else
      strCloseFlag := 'N';
      --单据状态跟踪
      PKOBJ_ODISPATCH.P_Insert_Odata_Exp_Trace(strEnterPriseNo,
                                               strWareHouseNo,
                                               v_Exp_No,
                                               COdataExpStatus.ExpTracPartCheck,
                                               strUserID,
                                               strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;
    end if;

    --是否提示建议包材
     begin
        select t.pack_advance
          into strPromptPackmate
          from wms_check_strategy t
         where t.enterprise_no = strEnterpriseNo
           and t.check_type = 'B'
           and t.check_strategy_id = v_CheckStrage;

        if strPromptPackmate = '1' then
          p_getPackMate(strEnterPriseNo,
                        strWareHouseNo,
                        v_D_Label_No,
                        v_PackMateNo,
                        strPackMateMsg,
                        v_iCount, --借用
                        v_Task_No); --借用
        end if;
      end;

    strOutFinishFlag := 'N';
    --判断当前任务是否复核完成

    select count(1)
      into v_iCount
      from stock_label_m m
     where m.source_no = strTaksNo
       and m.enterprise_no = strEnterpriseNo
       and m.warehouse_no = strWareHouseNo;

    --按拣货任务号
    if v_iCount > 0 then
      select count(*)
        into v_iCount
        from odata_check_label_d ocd
       where ocd.enterprise_no = strEnterpriseNo
         and ocd.warehouse_no = strWareHouseNo
         and exists (select 'x'
                from stock_label_d d
               where d.enterprise_no = ocd.enterprise_no
                 and d.warehouse_no = ocd.warehouse_no
                 and d.source_no = strTaksNo
                 and d.exp_no = ocd.exp_no
                 and d.exp_type = ocd.exp_type)
         and ocd.status < '13';
    else
      select count(*)
        into v_iCount
        from odata_check_label_d ocd
       where ocd.enterprise_no = strEnterpriseNo
         and ocd.warehouse_no = strWareHouseNo
         and ocd.lable_no = strTaksNo
         and ocd.status < '13';
    end if;

    if v_iCount <= 0 then
      strOutFinishFlag := 'Y';
    end if;

    strResult := 'Y';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_scanArticle_cutBox_sickOrder;

  /*订单取消*/
  procedure p_OrderCancel(strEnterpriseNo in odata_check_m.enterprise_no%type,
                          strWareHouseNo  in odata_check_m.warehouse_no%type,
                          strCheckNo      in odata_check_m.check_no%type, --复核单号
                          strSource_No    in odata_exp_m.shipper_deliver_no%type, --面单号或原订单号
                          strCheckType    in varchar2, --复核类型：1:按原订单号；2：快递单号复核
                          strUserID       in odata_check_m.rgst_name%type,
                          strResult       out varchar2) is
    strExpStatus odata_exp_m.status%type;
  begin

    strResult := 'N|p_OrderCancel';

    --按面单号
    if strCheckType = '2' then
      begin
        select oem.status
          into strExpStatus
          from odata_exp_m oem
         where oem.warehouse_no = strWareHouseNo
           and oem.enterprise_no = strEnterpriseNo
           and oem.shipper_deliver_no = strSource_No;
      exception
        when no_data_found then
          strResult := 'N|面单号' || strSource_No || '不存在';
          return;
      end;

      if strExpStatus <> '16' then
        strResult := 'N|面单号' || strSource_No || '未取消';
        return;
      end if;

      update odata_check_d ocd
         set ocd.status = '16'
       where ocd.warehouse_no = strWareHouseNo
         and ocd.enterprise_no = strEnterpriseNo
         and ocd.check_no = strCheckNo
         and exists
       (select 'x'
                from odata_exp_m oem
               where oem.enterprise_no = ocd.enterprise_no
                 and oem.warehouse_no = ocd.warehouse_no
                 and oem.exp_type = ocd.exp_type
                 and oem.exp_no = ocd.exp_no
                 and oem.shipper_deliver_no = strSource_No);

      if sql%rowcount > 0 then

        insert into odata_check_dhty
          (enterprise_no,
           warehouse_no,
           owner_no,
           exp_no,
           exp_type,
           exp_date,
           check_no,
           article_no,
           packing_qty,
           plan_qty,
           article_qty,
           real_qty,
           status,
           rgst_name,
           rgst_date,
           check_name,
           check_date,
           deliver_obj)
          select enterprise_no,
                 warehouse_no,
                 owner_no,
                 exp_no,
                 exp_type,
                 exp_date,
                 check_no,
                 article_no,
                 packing_qty,
                 plan_qty,
                 article_qty,
                 real_qty,
                 status,
                 rgst_name,
                 rgst_date,
                 check_name,
                 check_date,
                 deliver_obj
            from odata_check_d ocd
           where ocd.warehouse_no = strWareHouseNo
             and ocd.enterprise_no = strEnterpriseNo
             and ocd.check_no = strCheckNo
             and ocd.status = '16'
             and exists
           (select 'x'
                    from odata_exp_m oem
                   where oem.enterprise_no = ocd.enterprise_no
                     and oem.warehouse_no = ocd.warehouse_no
                     and oem.exp_type = ocd.exp_type
                     and oem.exp_no = ocd.exp_no
                     and oem.shipper_deliver_no = strSource_No);

        delete from odata_check_d ocd
         where ocd.warehouse_no = strWareHouseNo
           and ocd.enterprise_no = strEnterpriseNo
           and ocd.check_no = strCheckNo
           and ocd.status = '16'
           and exists
         (select 'x'
                  from odata_exp_m oem
                 where oem.enterprise_no = ocd.enterprise_no
                   and oem.warehouse_no = ocd.warehouse_no
                   and oem.exp_type = ocd.exp_type
                   and oem.exp_no = ocd.exp_no
                   and oem.shipper_deliver_no = strSource_No);

      end if;

      update odata_check_label_d ocd
         set ocd.status = '16'
       where ocd.warehouse_no = strWareHouseNo
         and ocd.enterprise_no = strEnterpriseNo
         and ocd.check_no = strCheckNo
         and exists
       (select 'x'
                from odata_exp_m oem
               where oem.enterprise_no = ocd.enterprise_no
                 and oem.warehouse_no = ocd.warehouse_no
                 and oem.exp_type = ocd.exp_type
                 and oem.exp_no = ocd.exp_no
                 and oem.shipper_deliver_no = strSource_No);

      if sql%rowcount > 0 then

        insert into odata_check_label_dhty
          (enterprise_no,
           warehouse_no,
           owner_no,
           check_no,
           row_id,
           lable_no,
           divide_id,
           container_no,
           exp_no,
           exp_type,
           exp_date,
           article_no,
           packing_qty,
           article_id,
           article_qty,
           real_qty,
           status,
           check_name,
           check_date,
           d_label_no,
           deliver_obj)
          select enterprise_no,
                 warehouse_no,
                 owner_no,
                 check_no,
                 row_id,
                 lable_no,
                 divide_id,
                 container_no,
                 exp_no,
                 exp_type,
                 exp_date,
                 article_no,
                 packing_qty,
                 article_id,
                 article_qty,
                 real_qty,
                 status,
                 check_name,
                 check_date,
                 d_label_no,
                 deliver_obj
            from odata_check_label_d ocd
           where ocd.warehouse_no = strWareHouseNo
             and ocd.enterprise_no = strEnterpriseNo
             and ocd.check_no = strCheckNo
             and ocd.status = '16'
             and exists
           (select 'x'
                    from odata_exp_m oem
                   where oem.enterprise_no = ocd.enterprise_no
                     and oem.warehouse_no = ocd.warehouse_no
                     and oem.exp_type = ocd.exp_type
                     and oem.exp_no = ocd.exp_no
                     and oem.shipper_deliver_no = strSource_No);

        delete from odata_check_label_d ocd
         where ocd.warehouse_no = strWareHouseNo
           and ocd.enterprise_no = strEnterpriseNo
           and ocd.check_no = strCheckNo
           and ocd.status = '16'
           and exists
         (select 'x'
                  from odata_exp_m oem
                 where oem.enterprise_no = ocd.enterprise_no
                   and oem.warehouse_no = ocd.warehouse_no
                   and oem.exp_type = ocd.exp_type
                   and oem.exp_no = ocd.exp_no
                   and oem.shipper_deliver_no = strSource_No);

      end if;

      for curLabel in (select distinct slm.label_no
                         from stock_label_d sld, stock_label_m slm
                        where slm.enterprise_no = sld.enterprise_no
                          and slm.warehouse_no = sld.warehouse_no
                          and slm.container_no = sld.container_no
                          and exists
                        (select 'x'
                                 from odata_exp_m oem
                                where oem.shipper_deliver_no = strSource_No
                                  and oem.enterprise_no = strEnterpriseNo
                                  and oem.warehouse_no = strWareHouseNo
                                  and oem.enterprise_no = sld.enterprise_no
                                  and oem.warehouse_no = sld.warehouse_no
                                  and oem.exp_type = sld.exp_type
                                  and oem.exp_no = sld.exp_no)) loop

        PKLG_ODATA_EXPCANCEL.P_Cancel_LabeltoMove(strEnterpriseNo,
                                                  strWareHouseNo,
                                                  curLabel.label_no,
                                                  strUserID,
                                                  strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;
      end loop;
    end if;

    --按原单号
    if strCheckType = '1' then
      begin
        select oem.status
          into strExpStatus
          from odata_exp_m oem
         where oem.warehouse_no = strWareHouseNo
           and oem.enterprise_no = strEnterpriseNo
           and oem.exp_no = strSource_No;
      exception
        when no_data_found then
          strResult := 'N|订单号' || strSource_No || '不存在';
          return;
      end;

      if strExpStatus <> '16' then
        strResult := 'N|订单号' || strSource_No || '未取消';
        return;
      end if;

      update odata_check_d ocd
         set ocd.status = '16'
       where ocd.warehouse_no = strWareHouseNo
         and ocd.enterprise_no = strEnterpriseNo
         and ocd.check_no = strCheckNo
         and ocd.exp_no = strSource_No;

      if sql%rowcount > 0 then
        insert into odata_check_dhty
          (enterprise_no,
           warehouse_no,
           owner_no,
           exp_no,
           exp_type,
           exp_date,
           check_no,
           article_no,
           packing_qty,
           plan_qty,
           article_qty,
           real_qty,
           status,
           rgst_name,
           rgst_date,
           check_name,
           check_date,
           deliver_obj)
          select enterprise_no,
                 warehouse_no,
                 owner_no,
                 exp_no,
                 exp_type,
                 exp_date,
                 check_no,
                 article_no,
                 packing_qty,
                 plan_qty,
                 article_qty,
                 real_qty,
                 status,
                 rgst_name,
                 rgst_date,
                 check_name,
                 check_date,
                 deliver_obj
            from odata_check_d ocd
           where ocd.warehouse_no = strWareHouseNo
             and ocd.enterprise_no = strEnterpriseNo
             and ocd.check_no = strCheckNo
             and ocd.exp_no = strSource_No
             and ocd.status = '16';

        delete from odata_check_d ocd
         where ocd.warehouse_no = strWareHouseNo
           and ocd.enterprise_no = strEnterpriseNo
           and ocd.check_no = strCheckNo
           and ocd.exp_no = strSource_No
           and ocd.status = '16';
      end if;

      update odata_check_label_d ocd
         set ocd.status = '16'
       where ocd.warehouse_no = strWareHouseNo
         and ocd.enterprise_no = strEnterpriseNo
         and ocd.check_no = strCheckNo
         and ocd.exp_no = strSource_No;

      if sql%rowcount > 0 then

        insert into odata_check_label_dhty
          (enterprise_no,
           warehouse_no,
           owner_no,
           check_no,
           row_id,
           lable_no,
           divide_id,
           container_no,
           exp_no,
           exp_type,
           exp_date,
           article_no,
           packing_qty,
           article_id,
           article_qty,
           real_qty,
           status,
           check_name,
           check_date,
           d_label_no,
           deliver_obj)
          select enterprise_no,
                 warehouse_no,
                 owner_no,
                 check_no,
                 row_id,
                 lable_no,
                 divide_id,
                 container_no,
                 exp_no,
                 exp_type,
                 exp_date,
                 article_no,
                 packing_qty,
                 article_id,
                 article_qty,
                 real_qty,
                 status,
                 check_name,
                 check_date,
                 d_label_no,
                 deliver_obj
            from odata_check_label_d ocd
           where ocd.warehouse_no = strWareHouseNo
             and ocd.enterprise_no = strEnterpriseNo
             and ocd.check_no = strCheckNo
             and ocd.exp_no = strSource_No
             and ocd.status = '16';

        delete from odata_check_label_d ocd
         where ocd.warehouse_no = strWareHouseNo
           and ocd.enterprise_no = strEnterpriseNo
           and ocd.check_no = strCheckNo
           and ocd.exp_no = strSource_No
           and ocd.status = '16';
      end if;

      for curLabel in (select distinct slm.label_no
                         from stock_label_d sld, stock_label_m slm
                        where slm.enterprise_no = sld.enterprise_no
                          and slm.warehouse_no = sld.warehouse_no
                          and slm.container_no = sld.container_no
                          and sld.exp_no = strSource_No
                          and slm.enterprise_no = strEnterpriseNo
                          and slm.warehouse_no = strWarehouseNo) loop

        PKLG_ODATA_EXPCANCEL.P_Cancel_LabeltoMove(strEnterpriseNo,
                                                  strWareHouseNo,
                                                  curLabel.label_no,
                                                  strUserID,
                                                  strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;
      end loop;
    end if;
    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_OrderCancel;

  /***********************************************************************************************
   对转病单的标签进行解锁
   chensr
   2015.5.5
  ***********************************************************************************************/
  procedure P_UnlockLabel(strEnterpriseNo in stock_label_m.Enterprise_No%type,
                          strWarehouseNo  in stock_label_m.Warehouse_No%type,
                          strDeliverObj   in stock_label_m.source_no%type,
                          strWorkerNo     in stock_label_m.rgst_name%type,
                          strResult       out varchar2) is
  begin
    strResult := 'N|[P_UnlockLabel]';

    for GetLabelNo in (select container_no
                         from stock_label_m
                        where enterprise_no = strEnterPriseNo
                          and warehouse_no = strWareHouseNo
                          AND deliver_obj = strDeliverObj
                          and status = CLabelStatus.OM_CANCEL_Lock) loop
      --更新标签明细表状态
      PKOBJ_label.p_updt_labelDetail_status(strEnterPriseNo,
                                            strWarehouseNo,
                                            GetLabelNo.container_no,
                                            strWorkerNo,
                                            CLabelStatus.INNER_CHECKING,
                                            strResult);

      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;

      --更新标签头档表状态
      PKOBJ_label.p_updt_label_status(strEnterPriseNo,
                                      strWarehouseNo,
                                      GetLabelNo.container_no,
                                      strWorkerNo,
                                      CLabelStatus.INNER_CHECKING,
                                      strResult);

      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;
    end loop;

    strResult := 'Y|[P_UnlockLabel]';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_UnlockLabel;
  /*****************************************************************************************
   功能：出货整理扫描条码保存商品(根据箱号)
  chensr 2015-06-26
  1、扫描时只做复核回单，
  2、当整单扫描完成后，系统需自动封箱，并打印封箱标签
  调用 P_CheckArticle 增加返回错误 huangb 20160602
  *****************************************************************************************/
  procedure P_scanArticle_by_labelNo(strEnterpriseNo in odata_check_m.enterprise_no%type,
                                     strWareHouseNo  in odata_check_m.warehouse_no%type,
                                     strCheckNo      in odata_check_m.check_no%type,
                                     strArticle_No   in odata_check_d.article_no%type, --商品编码
                                     nPacking_QTY    in odata_check_d.packing_qty%type, --包装数量
                                     strQuality      in stock_article_info.quality%type, --品质
                                     dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                                     dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                                     strLotNo        in stock_article_info.lot_no%type, --批次号
                                     strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                                     strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                                     strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                                     strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                                     strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                                     strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                                     strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                                     strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                                     strBarcode      in stock_article_info.barcode%type,
                                     strsLabelNo     in stock_label_m.label_no%type, --来源标签
                                     strDLabelNo     in stock_label_m.label_no%type, --目的标签
                                     nRealQty        in odata_check_d.real_qty%type, --回单数量
                                     strUserId       in odata_check_m.rgst_name%type,
                                     strDockNo       in bdef_defdock.dock_no%type,
                                     strResult       out varchar2) is
    v_iCount         integer;
    v_strCheckStatus odata_check_m.status%type;
    v_strDeliverObj  odata_check_m.deliver_obj%type;
    v_QMinPack       bdef_defarticle.qmin_operate_packing%type;
    v_nRemainQty     odata_check_d.real_qty%type := nRealQty;
  begin
    strResult := 'N|[P_scanArticle_by_labelNo]';

    --校验复核单状态
    begin
      select status, deliver_obj
        into v_strCheckStatus, v_strDeliverObj
        from odata_check_m
       where enterprise_no = strEnterpriseNo
         and warehouse_no = strWareHouseNo
         and check_no = strCheckNo;
      if v_strCheckStatus = '12' then
        strResult := 'N[已回单的复核单不可扫描]';
        return;
      end if;
    exception
      when no_data_found then
        strResult := 'N|[找不到复核单]';
        return;
    end;

    begin
      select bda.qmin_operate_packing
        into v_QMinPack
        from bdef_defarticle bda
       where bda.enterprise_no = strEnterpriseNo
         and bda.article_no = strArticle_No;
    exception
      when no_data_found then
        strResult := 'N|找不到商品资料-' || strArticle_No;
        return;
    end;

    if nvl(v_QMinPack, 0) <= 0 then
      v_QMinPack := 1;
    end if;

    --换算成最小单位
    v_nRemainQty := v_nRemainQty * v_QMinPack;

    --校验原标签是否可复核到目的标签
    p_contrast_containerNo(strEnterpriseNo,
                           strWarehouseNo,
                           strSLabelNo,
                           strDLabelNo,
                           strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    --整理容器
    P_CheckArticle(strEnterpriseNo,
                   strWareHouseNo,
                   strCheckNo,
                   v_strDeliverObj,
                   strArticle_No,
                   nPacking_QTY,
                   strQuality,
                   dtProduceDate,
                   dtExpireDate,
                   strLotNo,
                   strRSV_BATCH1,
                   strRSV_BATCH2,
                   strRSV_BATCH3,
                   strRSV_BATCH4,
                   strRSV_BATCH5,
                   strRSV_BATCH6,
                   strRSV_BATCH7,
                   strRSV_BATCH8,
                   strBarcode,
                   strSLabelNo,
                   strDLabelNo,
                   v_nRemainQty,
                   strUserId,
                   strResult);
    if (substr(strResult, 1, 1) <> 'Y') then
      return;
    end if;

    --判断复核单是否全部回单
    select count(*)
      into v_iCount
      from odata_check_label_d ocd
     where ocd.enterprise_no = strEnterpriseNo
       and ocd.warehouse_no = strWareHouseNo
       and ocd.check_no = strCheckNo
       and ocd.article_qty > ocd.real_Qty;

    --将复核单转历史
    if v_iCount = 0 then
      --此复核单全部扫描完成
      update odata_check_m t
         set t.status = '12'
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.check_no = strCheckNo;
    end if;

  end P_scanArticle_by_labelNo;

  /*****************************************************************************************
    功能：取消扫描、
    201511.05
  *****************************************************************************************/
  procedure p_CancelScanLabel(strEnterPriseNo in stock_label_m.enterprise_no%type,
                              strWareHouseNo  in stock_label_m.warehouse_no%type, --仓别
                              strUserId       in stock_label_m.rgst_name%type, --封箱人
                              strCheckNo      in odata_check_m.check_no%type,
                              strLabelNo      in stock_label_m.label_no%type, --标签号
                              strResult       out varchar2) is
    v_iCount integer := 0;
  begin
    strResult := 'N|[p_CancelScanLabel]';
    --

    select count(*)
      into v_iCount
      from odata_check_m t
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWareHouseNo
       and t.check_no = strCheckNo
       and t.status = '12';

    if v_iCount = 1 then
      strResult := 'N|[该标签对应的复核单已回单，不可重扫]';
      return;
    end if;

    select count(*)
      into v_iCount
      from odata_check_label_d t
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWareHouseNo
       and t.Lable_No = strLabelNo
       and t.check_no <> strCheckNo;

    if v_iCount > 0 then
      strResult := 'N|[此标签已存在多张复核单的商品，不可重扫]';
      return;
    end if;

    for GetLabelItem in (select *
                           from odata_check_label_d t
                          where t.enterprise_no = strEnterPriseNo
                            and t.warehouse_no = strWareHouseNo
                            and t.d_label_no = strLabelNo
                            and t.check_no = strCheckNo
                            and status < '13') loop
      v_iCount := v_iCount + 1;

      update odata_check_label_d t
         set t.real_qty = t.real_qty - GetLabelItem.real_qty
       where t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strWareHouseNo
         and t.check_no = strCheckNo
         and t.row_id = GetLabelItem.row_id
         and t.d_label_no = strLabelNo;

      update odata_check_d t
         set t.status     = '10',
             t.real_qty   = t.real_qty - GetLabelItem.real_qty,
             t.check_name = strUserId
       where t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strWareHouseNo
         and t.check_no = strCheckNo
         and t.owner_no = GetLabelItem.owner_no
         and t.exp_no = GetLabelItem.exp_no
         and t.article_no = GetLabelItem.article_no
         and t.packing_qty = GetLabelItem.packing_qty;

    end loop;

    if v_iCount = 0 then
      strResult := 'N|找不到标签明细';
      return;
    end if;
    strResult := 'Y|[]';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_CancelScanLabel;

  /*****************************************************************************************
    功能：复核封箱打标签（天天惠）、
    20150703
    chensr
    修改说明：2015.11.4,转移标签明细和库存
  *****************************************************************************************/
  procedure P_ODATA_CHECK_CUTBOX(strEnterPriseNo   in stock_label_m.enterprise_no%type,
                                 strWareHouseNo    in stock_label_m.warehouse_no%type, --仓别
                                 strUserId         in stock_label_m.rgst_name%type, --封箱人
                                 strLabelNo        in stock_label_m.label_no%type, --标签号
                                 strPrinterGroupNo in ridata_check_m.printer_group_no%type,
                                 strResult         out varchar2) is
    v_strPrtTask ridata_instock_d.instock_no%type;
    --v_iCount     integer := 0;
    --v_UpdateFlag boolean := false;
  begin
    strResult := 'N|[P_ODATA_CHECK_CUTBOX]';

    P_ODATA_CHECK_CLOSEBOX(strEnterPriseNo,
                           strWareHouseNo,
                           strUserId,
                           strLabelNo,
                           --strPrinterGroupNo,
                           strResult);

    if substr(strResult, 1, 1) <> 'Y' then
      return;
    end if;

    --写打印任务头档
    PKOBJ_PRINTTASK.p_insert_PrintGrouptaskmaster(strEnterPriseNo,
                                                  strWareHouseNo,
                                                  strLabelNo,
                                                  0,
                                                  CONST_REPORTID.B_CLOSECustBOX,
                                                  strPrinterGroupNo,
                                                  0,
                                                  strUserId,
                                                  v_strPrtTask,
                                                  strResult);
    if substr(strResult, 1, 1) <> 'Y' then
      return;
    end if;

    --写打印任务头档
    PKOBJ_PRINTTASK.p_insert_PrintGrouptaskmaster(strEnterPriseNo,
                                                  strWareHouseNo,
                                                  strLabelNo,
                                                  0,
                                                  CONST_REPORTID.RPT_BOXITEM,
                                                  strPrinterGroupNo,
                                                  0,
                                                  strUserId,
                                                  v_strPrtTask,
                                                  strResult);
    if substr(strResult, 1, 1) <> 'Y' then
      return;
    end if;

    strResult := 'Y|[成功]';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_ODATA_CHECK_CUTBOX;

  /*****************************************************************************************
    功能：复核封箱-电商
  *****************************************************************************************/
  procedure P_CLOSEBOX(strEnterPriseNo in stock_label_m.enterprise_no%type,
                       strWareHouseNo  in stock_label_m.warehouse_no%type, --仓别
                       strUserId       in stock_label_m.rgst_name%type, --封箱人
                       strLabelNo      in stock_label_m.label_no%type, --标签号
                       strResult       out varchar2) is
    v_strContainerNo  stock_label_m.container_no%type; --容器号
    v_strLabelNo      stock_label_m.label_no%type; --板号
    v_strStockValue   stock_content.stock_value%type;
    v_strCellId       stock_content.cell_id%type;
    v_iCount          integer := 0;
    v_dStatus         stock_label_m.status%type;
    v_strOwner_No     bdef_defowner.owner_no%type;
    v_ExpType         odata_exp_m.exp_type%type;
    v_sStatus         stock_label_m.status%type;
    v_strFlowFlag     wms_outorder_flow_d.flow_flag%type;
    v_strScontainerNo stock_label_m.container_no%type;
    v_strAutoFlag     wms_deflabel_status.must_run%type;
    v_strCheck_No     odata_check_d.check_no%type;
  begin

    --更新标签明细状态
    update odata_check_label_d t
       set t.status = '13'
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWareHouseNo
       and t.d_label_no = strLabelNo;

    --循环复核单明细
    for i_MoveLabel_Info in (select slm.container_no   as s_container_no,
                                    slml.enterprise_no,
                                    slml.warehouse_no,
                                    slml.owner_no,
                                    slml.exp_type,
                                    slml.article_no,
                                    slml.check_no,
                                    slml.article_id,
                                    slml.row_id,
                                    slml.real_qty,
                                    slml.packing_qty,
                                    slm.owner_cell_no  as s_owner_cell_no,
                                    dlm.owner_cell_no  as d_owner_cell_no,
                                    slm.container_type,
                                    dlm.cust_no,
                                    slm.label_no       as s_label_no,
                                    dlm.label_no       as d_label_no,
                                    dlm.container_no   as d_container_no,
                                    dlm.status         as d_label_status,
                                    slm.status         as s_label_status,
                                    dlm.stock_type,
                                    slm.hm_manual_flag
                               from odata_check_label_d slml,
                                    stock_label_m       slm,
                                    stock_label_m       dlm
                              where slml.warehouse_no = slm.warehouse_no
                                and slml.enterprise_no = slm.enterprise_no
                                and slml.container_no = slm.container_no
                                and slml.warehouse_no = dlm.warehouse_no
                                and slml.enterprise_no = dlm.enterprise_no
                                and slml.d_label_no = dlm.label_no
                                and slm.enterprise_no = strEnterpriseNo
                                and dlm.label_no = strLabelNo) loop

      -------------------是否储位库存，------------------------------
      if i_MoveLabel_Info.Hm_Manual_Flag = '1' then
        v_strContainerNo := 'N'; --储位库存
        v_strLabelNo     := 'N'; --储位库存
      else
        v_strContainerNo := i_MoveLabel_Info.s_Container_No; --标签库存
        v_strLabelNo     := i_MoveLabel_Info.s_Label_No; --标签库存
      end if;

      if (i_MoveLabel_Info.Stock_Type = 2) then
        --客户别数据 库存表需要写n_Stock_Value值
        v_strStockValue := i_MoveLabel_Info.Cust_No;
      else
        v_strStockValue := 'N';
      end if;

      if i_MoveLabel_Info.s_Container_No <> i_MoveLabel_Info.d_Container_No then

        --增加目的库存 没有预上数量
        PKOBJ_STOCK.p_InstContent_qtyByCellNo(i_MoveLabel_Info.Enterprise_No, --
                                              i_MoveLabel_Info.Warehouse_No, --仓别
                                              i_MoveLabel_Info.Owner_No, --货主
                                              'N', --部门
                                              i_MoveLabel_Info.Article_No, --商品编码
                                              i_MoveLabel_Info.Article_Id, --商品ID
                                              i_MoveLabel_Info.d_Owner_Cell_No, --目的储位
                                              i_MoveLabel_Info.s_Owner_Cell_No, --源储位
                                              i_MoveLabel_Info.Packing_Qty, --包装数量
                                              i_MoveLabel_Info.Real_Qty, --转移数量
                                              i_MoveLabel_Info.d_Label_No, --目的标签
                                              i_MoveLabel_Info.d_Label_No, --目的标签
                                              i_MoveLabel_Info.Stock_Type, --存储类型
                                              v_strStockValue, --存储类型的值
                                              strUserId, --操作人
                                              i_MoveLabel_Info.Check_No, --复核单号
                                              '1', --操作工具
                                              0, --是否可手工移库 0:不允许手工移库；1：可手工移库
                                              v_strCellId, --返回的储位ID
                                              strResult --返回的结果
                                              );
        if (substr(strResult, 1, 1) <> 'Y') then
          return;
        end if;

        --扣减源库存 循环扣减, 不处理预约上下架量，直接扣减库存
        PKOBJ_STOCK.p_UpdtContent_qtyByCellNo(i_MoveLabel_Info.Enterprise_No, --
                                              i_MoveLabel_Info.Warehouse_No, --仓别
                                              i_MoveLabel_Info.Owner_No, --货主
                                              i_MoveLabel_Info.Article_No, --商品编码
                                              i_MoveLabel_Info.Article_Id, --商品ID
                                              i_MoveLabel_Info.s_Owner_Cell_No, --源储位
                                              i_MoveLabel_Info.d_Owner_Cell_No, --目的储位
                                              i_MoveLabel_Info.Packing_Qty, --包装数量
                                              i_MoveLabel_Info.Real_Qty, --转移数量
                                              i_MoveLabel_Info.s_Label_No, --源标签
                                              i_MoveLabel_Info.Stock_Type, --存储类型
                                              v_strStockValue, --存储类型的值
                                              strUserId, --操作人
                                              i_MoveLabel_Info.Check_No, --整理单号
                                              '1', --操作工具
                                              strResult); --返回结果
        if (substr(strResult, 1, 1) <> 'Y') then
          return;
        end if;

        --标签明细转移
        pkobj_label.proc_om_ArrangeByCheck_No(i_MoveLabel_Info.Enterprise_No,
                                              i_MoveLabel_Info.Warehouse_No,
                                              i_MoveLabel_Info.Owner_No,
                                              i_MoveLabel_Info.check_no,
                                              i_MoveLabel_Info.s_Container_No,i_MoveLabel_Info.Real_Qty,
                                              i_MoveLabel_Info.Row_Id,
                                              strUserId,
                                              strResult);

        if (substr(strResult, 1, 1) <> 'Y') then
          return;
        end if;
      end if;

      v_strScontainerNo := i_MoveLabel_Info.s_Container_No;
      v_strOwner_No     := i_MoveLabel_Info.Owner_No;
      v_ExpType         := i_MoveLabel_Info.Exp_Type;
      v_dStatus         := i_MoveLabel_Info.d_Label_Status;
      v_sStatus         := i_MoveLabel_Info.s_label_Status;
      v_strCheck_No     := i_MoveLabel_Info.Check_No;

      v_iCount := v_iCount + 1;
    end loop;

    if v_iCount <= 0 then
      strResult := 'N|找不到需要封箱的库存-'||strLabelNo;
      return;
    end if;

    --if v_dStatus = CLabelStatus.NEW_LABEL_NO then
    --判断当前工作流是否执行状态

    PKOBJ_HB.p_getlabelnoFlow(strEnterPriseNo,
                              strWarehouseNo,
                              v_strOwner_No,
                              v_ExpType,
                              v_strScontainerNo,
                              v_strFlowFlag,
                              strResult);
    if (substr(strResult, 1, 1) <> 'Y') then
      return;
    end if;

    if v_strFlowFlag = '0' then
      v_dStatus := v_sStatus;
    else
      PKOBJ_HB.p_GetLabelStatusFromWorkflow(strEnterPriseNo,
                                            strWarehouseNo,
                                            v_strOwner_No,
                                            v_ExpType,
                                            v_strScontainerNo,
                                            v_dStatus,
                                            v_strAutoFlag,
                                            strResult);
      if (substr(strResult, 1, 1) <> 'Y') then
        return;
      end if;
    end if;
    --end if;

    --更新标签状态
    update stock_label_m sld
       set sld.status = v_dStatus
     where sld.warehouse_no = strWarehouseNo
       and sld.enterprise_no = strEnterpriseNo
       and sld.label_no = strLabelNo;

    update stock_label_d sld
       set sld.status = v_dStatus
     where sld.warehouse_no = strWarehouseNo
       and sld.enterprise_no = strEnterpriseNo
       and exists (select 'x'
              from stock_label_m slm
             where slm.enterprise_no = sld.enterprise_no
               and slm.warehouse_no = sld.warehouse_no
               and slm.container_no = sld.container_no
               and slm.enterprise_no = strEnterPriseNo
               and slm.warehouse_no = strWareHouseNo
               and slm.label_no = strLabelNo);

    --销毁空标签头
    PKOBJ_LABEL.proc_OM_Destory_NullLabel(strEnterpriseNo,
                                          strWarehouseNo, --仓别
                                          v_strScontainerNo, --容器号
                                          strUserId, --操作人
                                          strResult --返回结果
                                          );
    if (substr(strResult, 1, 1) <> 'Y') then
      return;
    end if;

    select count(*)
      into v_iCount
      from odata_check_label_d t
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWareHouseNo
       and t.check_no = v_strCheck_No
       and t.status < '13';

    if v_iCount <= 0 then

      PKOBJ_ODATA_CHECK.P_UpdateOdataCheckM(strEnterpriseNo,
                                            strWareHouseNo,
                                            v_strCheck_No,
                                            strUserId,
                                            strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      PKOBJ_ODATA_CHECK.p_insert_Odata_check_log(strEnterpriseNo,
                                                 strWareHouseNo,
                                                 v_strCheck_No,
                                                 strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
    end if;

    strResult := 'Y|[成功]';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_CLOSEBOX;

  /*****************************************************************************************
    功能：复核封箱
  *****************************************************************************************/
  procedure P_ODATA_CHECK_CLOSEBOX(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                   strWareHouseNo  in stock_label_m.warehouse_no%type, --仓别
                                   strUserId       in stock_label_m.rgst_name%type, --封箱人
                                   strLabelNo      in stock_label_m.label_no%type, --标签号
                                   --strPrinterGroupNo in ridata_check_m.printer_group_no%type,
                                   strResult out varchar2) is
    --v_strPrtTask ridata_instock_d.instock_no%type;
    v_iCount     integer := 0;
    v_UpdateFlag boolean := false;
  begin
    strResult := 'N|[P_ODATA_CHECK_CLOSEBOX]';

    --剥离标签明细
    for GetLableItem in (select *
                           from odata_check_label_d t
                          where t.enterprisE_no = strEnterPriseNo
                            and t.warehouse_no = strWareHouseNo
                            and t.d_label_no = strLabelNo
                            and t.status < '13'
                            and t.real_qty > 0
                            and t.article_qty - t.real_qty > 0) loop

      PKOBJ_ODATA_CHECK.P_SaveOdataCheckLabelD(strEnterpriseNo,
                                               strWareHouseNo,
                                               GetLableItem.check_no,
                                               GetLableItem.container_no,
                                               strLabelNo,
                                               GetLableItem.row_id,
                                               GetLableItem.article_qty -
                                               GetLableItem.real_qty,
                                               strUserId,
                                               strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      update odata_check_label_d t
         set t.article_qty = GetLableItem.real_qty
       where enterprise_no = strEnterPriseNo
         and warehouse_no = strWareHouseNo
         and check_no = GetLableItem.check_no
         and row_id = GetLableItem.row_id;

    end loop;

    --根据标签转移库存和标签明细
    for GetOdataCheckItem in (select t.check_no,
                                     t.lable_no,
                                     t.container_no,
                                     t.article_no,
                                     t.packing_qty,
                                     t.deliver_obj,
                                     sai.barcode,
                                     sai.produce_date,
                                     sai.expire_date,
                                     sai.quality,
                                     sai.lot_no,
                                     sai.rsv_batch1,
                                     sai.rsv_batch2,
                                     sai.rsv_batch3,
                                     sai.rsv_batch4,
                                     sai.rsv_batch5,
                                     sai.rsv_batch6,
                                     sai.rsv_batch7,
                                     sai.rsv_batch8,
                                     sum(t.real_qty) real_qty
                                from odata_check_label_d t,
                                     stock_article_info  sai
                               where t.enterprise_no = sai.enterprise_no
                                 and t.article_no = sai.article_no
                                 and t.article_id = sai.article_id
                                 and t.enterprise_no = strEnterPriseNo
                                 and t.warehouse_no = strWareHouseNo
                                 and t.d_label_no = strLabelNo
                                 and t.real_qty > 0
                                 and t.status < '13'
                               group by t.check_no,
                                        t.lable_no,
                                        t.container_no,
                                        t.article_no,
                                        t.packing_qty,
                                        t.deliver_obj,
                                        sai.barcode,
                                        sai.produce_date,
                                        sai.expire_date,
                                        sai.quality,
                                        sai.lot_no,
                                        sai.rsv_batch1,
                                        sai.rsv_batch2,
                                        sai.rsv_batch3,
                                        sai.rsv_batch4,
                                        sai.rsv_batch5,
                                        sai.rsv_batch6,
                                        sai.rsv_batch7,
                                        sai.rsv_batch8) loop
      v_iCount := v_iCount + 1;

      p_Arrange_Save_Article(strEnterpriseNo,
                             strWarehouseNo,
                             GetOdataCheckItem.lable_no,
                             strLabelNo,
                             GetOdataCheckItem.Deliver_Obj,
                             GetOdataCheckItem.article_no,
                             GetOdataCheckItem.packing_qty,
                             GetOdataCheckItem.quality,
                             GetOdataCheckItem.produce_date,
                             GetOdataCheckItem.expire_date,
                             GetOdataCheckItem.lot_no,
                             GetOdataCheckItem.rsv_batch1,
                             GetOdataCheckItem.rsv_batch2,
                             GetOdataCheckItem.rsv_batch3,
                             GetOdataCheckItem.rsv_batch4,
                             GetOdataCheckItem.rsv_batch5,
                             GetOdataCheckItem.rsv_batch6,
                             GetOdataCheckItem.rsv_batch7,
                             GetOdataCheckItem.rsv_batch8,
                             GetOdataCheckItem.barcode,
                             GetOdataCheckItem.real_qty,
                             strUserId,
                             strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
    end loop;

    if v_iCount <= 0 then
      strResult := 'N|未找到复核的标签明细';
      return;
    end if;

    --更新复核明细
    update odata_check_label_d t
       set t.status = '13'
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWareHouseNo
       and t.d_label_no = strLabelNo
       and t.d_label_no <> 'N'
       and t.real_qty > 0;

    --循环处理复核单
    for GetCheck in (select ocm.check_no, ocm.status
                       from odata_check_m ocm
                      where ocm.enterprise_no = strEnterpriseNo
                        and ocm.warehouse_no = strWareHouseNo
                        and exists
                      (select 'x'
                               from odata_check_label_d ocd
                              where ocd.check_no = ocm.check_no
                                and enterprise_no = strEnterPriseNo
                                and warehouse_no = strWareHouseNo
                                and d_label_no = strLabelNo)) loop

      v_UpdateFlag := false;
      --首先该单判断是否全部完成
      if GetCheck.Status = '12' then
        v_UpdateFlag := True;

        update odata_check_label_d t
           set t.status = '13'
         where t.status < '13'
           and t.enterprise_no = strEnterPriseNo
           and t.warehouse_no = strWareHouseNo
           and t.check_no = GetCheck.check_no;

      else
        select count(*)
          into v_iCount
          from odata_check_label_d t
         where t.enterprise_no = strEnterPriseNo
           and t.warehouse_no = strWareHouseNo
           and t.check_no = GetCheck.check_no
           and t.status < '13';

        if v_iCount = 0 then
          v_UpdateFlag := True;
        end if;
      end if;

      if v_UpdateFlag = true then
        PKOBJ_ODATA_CHECK.P_UpdateOdataCheckM(strEnterpriseNo,
                                              strWareHouseNo,
                                              GetCheck.check_no,
                                              strUserId,
                                              strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        PKOBJ_ODATA_CHECK.p_insert_Odata_check_log(strEnterpriseNo,
                                                   strWareHouseNo,
                                                   GetCheck.check_no,
                                                   strResult);
        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;
      end if;
    end loop;

    strResult := 'Y|[成功]';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_ODATA_CHECK_CLOSEBOX;

  /*****************************************************************************************
    功能：复核封箱回单（天天惠）
    20151010
    chensr
  *****************************************************************************************/
  procedure P_PROC_Receipt(strEnterPriseNo in stock_label_m.enterprise_no%type,
                           strWareHouseNo  in stock_label_m.warehouse_no%type, --仓别
                           strCheckNo      in odata_check_m.check_no%type,
                           strResult       out varchar2) is
    v_iCount integer := 0;
  begin
    strResult := 'Y|';
    --判断是否整单都已做封箱
    select count(*)
      into v_iCount
      from odata_check_label_d t
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWareHouseNo
       and t.check_no = strCheckNo
       and t.real_qty > 0
       and t.d_label_no <> 'N'
       and t.status < '13';

    if v_iCount > 0 then
      --更新复核单头档--扫描完成
      update odata_check_m t
         set t.status = '12', t.updt_date = sysdate
       where t.status = '10'
         and t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strWareHouseNo
         and t.check_no = strCheckNo;
    else
      --全部做封箱

      --转历史
      insert into odata_check_label_dhty
        (enterprise_no,
         warehouse_no,
         owner_no,
         check_no,
         row_id,
         lable_no,
         divide_id,
         container_no,
         exp_no,
         exp_type,
         exp_date,
         article_no,
         packing_qty,
         article_id,
         article_qty,
         real_qty,
         status,
         check_name,
         check_date,
         d_label_no)
        select a.enterprise_no,
               a.warehouse_no,
               a.owner_no,
               a.check_no,
               a.row_id,
               a.lable_no,
               a.divide_id,
               a.container_no,
               a.exp_no,
               a.exp_type,
               a.exp_date,
               a.article_no,
               a.packing_qty,
               a.article_id,
               a.article_qty,
               a.real_qty,
               '13',
               a.check_name,
               a.check_date,
               a.d_label_no
          from odata_check_label_d a
         where a.enterprise_no = strEnterPriseNo
           and a.warehouse_no = strWareHouseNo
           and a.check_no = strCheckNo;

      insert into odata_check_dhty
        (enterprise_no,
         warehouse_no,
         owner_no,
         exp_no,
         exp_type,
         exp_date,
         check_no,
         article_no,
         packing_qty,
         plan_qty,
         article_qty,
         real_qty,
         status,
         rgst_name,
         rgst_date,
         check_name,
         check_date)
        select a.enterprise_no,
               a.warehouse_no,
               a.owner_no,
               a.exp_no,
               a.exp_type,
               a.exp_date,
               a.check_no,
               a.article_no,
               a.packing_qty,
               a.plan_qty,
               a.article_qty,
               a.real_qty,
               '13',
               a.rgst_name,
               a.rgst_date,
               a.check_name,
               a.check_date
          from odata_check_d a
         where a.enterprise_no = strEnterPriseNo
           and a.warehouse_no = strWareHouseNo
           and a.check_no = strCheckNo;

      insert into odata_check_mhty
        (enterprise_no,
         warehouse_no,
         owner_no,
         check_no,
         operate_date,
         batch_no,
         cust_no,
         status,
         check_chute_no,
         deliver_obj,
         line_no,
         curr_area,
         rgst_name,
         rgst_date,
         updt_name,
         updt_date,
         --huangb 20160509
         REPORT_UP_SERIAL)
        select a.enterprise_no,
               a.warehouse_no,
               a.owner_no,
               a.check_no,
               a.operate_date,
               a.batch_no,
               a.cust_no,
               '13',
               a.check_chute_no,
               a.deliver_obj,
               a.line_no,
               a.curr_area,
               a.rgst_name,
               a.rgst_date,
               a.updt_name,
               a.updt_date,
               --huangb 20160509
               REPORT_UP_SERIAL
          from odata_check_m a
         where a.enterprise_no = strEnterPriseNo
           and a.warehouse_no = strWareHouseNo
           and a.check_no = strCheckNo;

      --删除数据
      delete from odata_check_label_d a
       where a.enterprise_no = strEnterPriseNo
         and a.warehouse_no = strWareHouseNo
         and a.check_no = strCheckNo;

      delete from odata_check_d a
       where a.enterprise_no = strEnterPriseNo
         and a.warehouse_no = strWareHouseNo
         and a.check_no = strCheckNo;

      delete from odata_check_m a
       where a.enterprise_no = strEnterPriseNo
         and a.warehouse_no = strWareHouseNo
         and a.check_no = strCheckNo;
    end if;
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_PROC_Receipt;

  /*************************************************************************************************************
  功能说明：
          1、装并板
          支持板、物流箱和原装箱往板标签上并
  调用 pkcheck_odata.P_Check_Mergelabel 增加返回错误 huangb 20160602
  *************************************************************************************************************/
  procedure p_merge_Pal(strEnterpriseNo in stock_label_m.enterprise_no%type, --仓别
                        strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                        strSLabelNo     in stock_label_m.label_no%type, --原标签(被并板标签）
                        strDLabelNo     in stock_label_m.label_no%type, --目的标签
                        strUserId       in stock_label_m.updt_name%type,
                        strResult       out varchar2) is
    v_strsContainerNo stock_label_m.container_no%type; --来源内部容器号
    v_strdContainerNo stock_label_m.container_no%type; --目的内部容器号
    v_Owner_No        bdef_defowner.owner_no%type;
    v_Exp_Type        odata_exp_m.exp_type%type;
    v_dStatus         stock_label_m.status%type; --目的容器状态
    v_sStatus         stock_label_m.status%type; --源容器状态
    v_sDeliverObj     stock_label_m.deliver_obj%type; --源容器配送对象
    v_sUseType        stock_label_m.use_type%type; --源容器标签
    v_sLineNo         stock_label_m.line_no%type; --源容器线路
    v_strCellId       stock_content.cell_id%type;

    v_strTrunckCellNo   stock_label_m.trunck_cell_no%type;
    v_strAsorterChuteNo stock_label_m.a_sorter_chute_no%type;
    v_strDeliverObj     stock_label_m.deliver_obj%type;
    v_strDeliverArea    stock_label_m.deliver_area%type;
    v_strCustNo         stock_label_m.cust_no%type;
    v_strOwnerCellNo    stock_label_m.owner_cell_no%type;
    v_strSourceNo       stock_label_m.source_no%type;
    v_strCheckChuteNo   stock_label_m.check_chute_no%type;
    v_strFlowFlag       wms_deflabel_status.flow_flag%type;
    v_strAutoFlag       wms_deflabel_status.must_run%type;

    v_strLabelStock stock_label_m.hm_manual_flag%type; --0:标签库存；1：储位库存
    v_strsLabelNo   stock_label_m.label_no%type;
    v_strDCustNo    stock_label_m.cust_no%type;

  begin
    strResult := 'N|[p_merge_Pal]';

    pkcheck_odata.P_Check_Mergelabel(strEnterpriseNo,
                                     strWarehouseNo,
                                     strSLabelNo,
                                     strDLabelNo,
                                     v_dStatus,
                                     v_strDCustNo,
                                     strResult);
    if (substr(strResult, 1, 1) <> 'Y') then
      return;
    end if;
    --取来源容器号
    select slm.deliver_obj,
           slm.status,
           slm.use_type,
           slm.line_no,
           slm.trunck_cell_no,
           slm.a_sorter_chute_no,
           slm.deliver_obj,
           slm.deliver_area,
           Slm.cust_no,
           slm.owner_cell_no,
           slm.source_no,
           slm.check_chute_no,
           slm.container_no,
           slm.HM_MANUAL_FLAG
      into v_sDeliverObj,
           v_sStatus,
           v_sUseType,
           v_sLineNo,
           v_strTrunckCellNo,
           v_strAsorterChuteNo,
           v_strDeliverObj,
           v_strDeliverArea,
           v_strCustNo,
           v_strOwnerCellNo,
           v_strSourceNo,
           v_strCheckChuteNo,
           v_strsContainerNo,
           v_strLabelStock
      from stock_label_m slm
     where slm.enterprise_no = strEnterpriseNo
       and slm.warehouse_no = strWarehouseNo
       and slm.label_no = strSLabelNo;

    --获取目的容器号
    select slm.container_no, slm.cust_no
      into v_strdContainerNo, v_strDCustNo
      from stock_label_m slm
     where slm.enterprise_no = strEnterpriseNo
       and slm.warehouse_no = strWarehouseNo
       and slm.label_no = strDLabelNo;

    for i_Label_Detail in (select slm.stock_type,
                                  slm.owner_container_no,
                                  case
                                    when v_strLabelStock = '1' and
                                         slm.container_no =
                                         slm.owner_container_no then
                                     'N'
                                    else
                                     (select label_no
                                        from stock_label_m
                                       where container_no in
                                             (select slm.owner_container_no
                                                from stock_label_m slm
                                               where slm.enterprise_no =
                                                     strEnterpriseNo
                                                 and slm.warehouse_no =
                                                     strWarehouseNo
                                                 and slm.container_no =
                                                     v_strsContainerNo))
                                  end label_no,
                                  sld.*
                             from stock_label_d sld, stock_label_m slm
                            where slm.enterprise_no = sld.enterprise_no
                              and slm.warehouse_no = sld.warehouse_no
                              and slm.container_no = sld.container_no
                              and sld.enterprise_no = strEnterpriseNo
                              and sld.warehouse_no = strWarehouseNo
                              and (slm.owner_cell_no, sld.article_no,
                                   sld.article_id, sld.packing_qty, case
                                     when v_strLabelStock = '1' then
                                      'N'
                                     else
                                      strSLabelNo
                                   end) in
                                  (select sc.cell_no,
                                          sc.article_no,
                                          sc.article_id,
                                          sc.packing_qty,
                                          sc.label_no
                                     from stock_content sc
                                    where sc.enterprise_no = strEnterpriseNo
                                      and sc.warehouse_no = strWarehouseNo)
                              and slm.container_no = v_strsContainerNo) loop

      --增加目的库存 没有预上数量
      PKOBJ_STOCK.p_InstContent_qtyByCellNo(strEnterpriseNo, --
                                            strWarehouseNo, --仓别
                                            i_Label_Detail.Owner_No, --货主
                                            'N', --部门
                                            i_Label_Detail.Article_No, --商品编码
                                            i_Label_Detail.Article_Id, --商品ID
                                            v_strOwnerCellNo, --目的储位
                                            v_strOwnerCellNo, --源储位
                                            i_Label_Detail.Packing_Qty, --包装数量
                                            i_Label_Detail.qty, --转移数量
                                            strDLabelNo, --目的标签
                                            strDLabelNo, --目的标签
                                            i_Label_Detail.Stock_Type, --存储类型
                                            'N', --存储类型的值
                                            strUserId, --操作人
                                            strDLabelNo, --装并板单号，以目的标签作为单号
                                            '2', --操作工具
                                            0, --是否可手工移库 0:不允许手工移库；1：可手工移库
                                            v_strCellId, --返回的储位ID
                                            strResult);
      if (substr(strResult, 1, 1) <> 'Y') then
        return;
      end if;

      if v_strLabelStock = '1' and
         i_Label_Detail.container_no = i_Label_Detail.owner_container_no then
        v_strsLabelNo := 'N';
      else
        v_strsLabelNo := i_Label_Detail.label_no;
      end if;

      v_Owner_No := i_Label_Detail.Owner_No;
      v_Exp_Type := i_Label_Detail.Exp_Type;

      --扣减源库存 循环扣减, 不处理预约上下架量，直接扣减库存
      PKOBJ_STOCK.p_UpdtContent_qtyByCellNo(strEnterpriseNo, --
                                            strWarehouseNo, --仓别
                                            i_Label_Detail.Owner_No, --货主
                                            i_Label_Detail.Article_No, --商品编码
                                            i_Label_Detail.Article_Id, --商品ID
                                            v_strOwnerCellNo, --源储位
                                            v_strOwnerCellNo, --目的储位
                                            i_Label_Detail.Packing_Qty, --包装数量
                                            i_Label_Detail.qty, --转移数量
                                            v_strsLabelNo, --源标签
                                            i_Label_Detail.Stock_Type, --存储类型
                                            'N', --存储类型的值
                                            strUserId, --操作人
                                            strDLabelNo, --整理单号
                                            '2', --操作工具
                                            strResult); --返回结果
      if (substr(strResult, 1, 1) <> 'Y') then
        return;
      end if;
    end loop;

    --更新目的标签头档状态

    if v_dStatus = CLabelStatus.NEW_LABEL_NO then
      --判断当前工作流是否执行状态

      PKOBJ_HB.p_getlabelnoFlow(strEnterPriseNo,
                                strWarehouseNo,
                                v_Owner_No,
                                v_Exp_Type,
                                v_strScontainerNo,
                                v_strFlowFlag,
                                strResult);
      if (substr(strResult, 1, 1) <> 'Y') then
        return;
      end if;

      if v_strFlowFlag = '1' then
        v_dStatus := v_sStatus;
      else
        PKOBJ_HB.p_GetLabelStatusFromWorkflow(strEnterPriseNo,
                                              strWarehouseNo,
                                              v_Owner_No,
                                              v_Exp_Type,
                                              v_strScontainerNo,
                                              v_dStatus,
                                              v_strAutoFlag,
                                              strResult);
        if (substr(strResult, 1, 1) <> 'Y') then
          return;
        end if;
      end if;

      update stock_label_m slm
         set slm.trunck_cell_no    = v_strTrunckCellNo,
             slm.a_sorter_chute_no = v_strAsorterChuteNo,
             slm.deliver_obj       = v_strDeliverObj,
             slm.deliver_area      = v_strDeliverArea,
             slm.cust_no           = v_strCustNo,
             slm.owner_cell_no     = v_strOwnerCellNo,
             slm.line_no           = v_sLineNo,
             slm.rgst_name         = strUserId,
             slm.source_no         = v_strSourceNo,
             slm.status            = v_dStatus,
             slm.check_chute_no    = v_strCheckChuteNo
       where slm.warehouse_no = strWarehouseNo
         and slm.enterprise_no = strEnterpriseNo
         and slm.container_no = v_strDcontainerNo;
      update stock_label_d sld
         set sld.status = v_dStatus
       where sld.warehouse_no = strWarehouseNo
         and sld.enterprise_no = strEnterpriseNo
         and sld.container_no = v_strDcontainerNo;

    end if;

    --更新来源标签状态
    update stock_label_m t
       set t.status             = '62',
           t.updt_name          = strUserId,
           t.updt_date          = sysdate,
           t.owner_container_no = v_strdContainerNo
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWarehouseNo
       and t.label_no = strSLabelNo;

    --更新来源标签明细状态
    update stock_label_d sm
       set sm.status    = '62',
           sm.updt_date = sysdate,
           sm.updt_name = strUserId
     where sm.container_no = v_strsContainerNo
       and sm.warehouse_no = strWarehouseNo
       and sm.enterprise_no = strEnterPriseNo;

    strResult := 'Y|[]';
  end p_merge_Pal;

  /* 装并板 标签检查 （此方法为小嘴所用） Add by sunl
  * 用于校验当前预装板的标签（来源标签）是否属于当前被装的板（目的标签）
  * 此方法内部会调用 P_MergePal_Slabel_Check 过程，用于校验当前的标签是否有效
  * 此方法内部会调用 P_Check_Mergelabel 过程，用于校验当前源标签是否可以并到目的标签
  * 此方法内部会调用 PKLG_ODATA_MOVE_JUN.p_merge_Pal 过程，用于执行装并板操作
  */
  procedure P_MergePal_Label_CheckAndSave(strEnterpriseNo in stock_label_m.enterprise_no%type,
                                          strWarehouseNo  in stock_label_m.warehouse_no%type,
                                          strSLabelNo     in stock_label_m.label_no%type, --来源标签
                                          strDLabelNo     in stock_label_m.label_no%type, --目的标签（往上放货的容器）
                                          strUserID       IN stock_label_m.rgst_name%TYPE, --操作用户
                                          strUseType      in stock_label_m.use_type%type, --1：仅检查标签是否可用 2：检查标签是否可用，且进行装板操作
                                          strStatusText   out wms_deffieldval.text%type, --标签状态描述
                                          strCustName     out bdef_defcust.cust_name%type, --客户名称
                                          strOutMsg       out varchar2) IS
    strStatus  stock_label_m.status%type; --记录校验标签时返回的标签状态
    strCustNo  stock_label_m.cust_no%type; --记录校验标签时返回的客户编码
    HasFlag    NUMBER; --标记当前的来源标签 是否属于 当前的 目的板
    tmpStatus  stock_label_m.status%type; --记录校验标签时返回的标签状态
    tmpCustNo  stock_label_m.cust_no%type; --记录校验标签时返回的客户编码
    tmpAreaNo  stock_label_m.label_no%TYPE; --用于记录当前的暂存区
    v_SLabelNo stock_label_m.label_no%type;
    v_DLabelNo stock_label_m.label_no%type;
    v_iCount   integer;
  BEGIN
    v_SLabelNo := upper(strSLabelNo);
    v_DLabelNo := upper(strDLabelNo);

    --源标签号和目的标签号不允许相同
    if v_SLabelNo = v_DLabelNo then
      strOutMsg := 'N|[E23222]';
      return;
    end if;

    --源标签不允许多次并板到目的标签

    --来源标签不为空，则校验当前的来源标签是否有效
    IF (strSLabelNo IS NOT NULL) THEN
      pkcheck_odata.P_MergePal_Slabel_Check(strEnterpriseNo,
                                            strWarehouseNo,
                                            v_SLabelNo,
                                            '1',
                                            tmpStatus,
                                            tmpCustNo,
                                            strOutMsg);
      if (substr(strOutMsg, 1, 1) = 'N') then
        return;
      end if;
      IF (tmpStatus IS NOT NULL) THEN
        strStatus := tmpStatus;
      END IF;
      IF (tmpCustNo IS NOT NULL) THEN
        strCustNo := tmpCustNo;
      END IF;
    END IF;

    if strStatus = '62' then
      --校验是否已并入目的板
      --
      select count(*)
        into v_iCount
        from stock_label_m slm
       where slm.enterprise_no = strEnterpriseNo
         and slm.warehouse_no = strWarehouseNo
         and slm.owner_container_no in
             (select container_no
                from stock_label_m
               where enterprise_no = strEnterpriseNo
                 and warehouse_no = strWarehouseNo
                 and label_no = strDLabelNo)
         and slm.label_no = strSLabelNo;

      if v_iCount = 1 then
        strOutMsg := 'N|[已被并入此板]';
        return;
      end if;

    end if;

    --目的标签不为空，则校验当前的目的标签是否有效
    IF (strDLabelNo IS NOT NULL) THEN
      tmpAreaNo := '';
      --这里需要校验当前的板标签是否是有效的月台编码
      BEGIN
        SELECT b.buffer_name
          INTO tmpAreaNo
          FROM oset_buffer b
         WHERE b.enterprise_no = strEnterpriseNo
           AND b.warehouse_no = strWarehouseNo
           AND b.buffer_name = v_DLabelNo;
      exception
        when no_data_found then
          strOutMsg := 'N|当前的目的板号无效！';
          RETURN;
      END;
      IF (tmpAreaNo IS NULL) THEN
        strOutMsg := 'N|当前的目的板号无效！';
        RETURN;
      END IF;

      pkcheck_odata.P_MergePal_Slabel_Check(strEnterpriseNo,
                                            strWarehouseNo,
                                            v_DLabelNo,
                                            '2',
                                            tmpStatus,
                                            tmpCustNo,
                                            strOutMsg);
      if (substr(strOutMsg, 1, 1) = 'N') then
        return;
      end if;
      IF (tmpStatus IS NOT NULL) THEN
        strStatus := tmpStatus;
      END IF;
      IF (tmpCustNo IS NOT NULL) THEN
        strCustNo := tmpCustNo;
      END IF;
    END IF;

    HasFlag := 0;
    --当来源标签与目的标签均不为空时，需要校验当前的目的标签 是否属于 来源标签对应的月台
    IF (strDLabelNo IS NOT NULL AND strSLabelNo IS NOT NULL) THEN
      for p in (SELECT M.LABEL_NO, B.BUFFER_NAME
                  FROM STOCK_LABEL_M             M,
                       ODATA_SEND_AREA_CALCULATE C,
                       OSET_BUFFER               B
                 WHERE M.ENTERPRISE_NO = C.ENTERPRISE_NO
                   AND M.WAREHOUSE_NO = C.WAREHOUSE_NO
                   AND M.Deliver_Obj = C.Deliver_Obj
                   AND C.WAREHOUSE_NO = B.WAREHOUSE_NO
                   AND C.ENTERPRISE_NO = B.ENTERPRISE_NO
                   AND C.CELL_NO = B.CELL_NO
                   AND C.AREA_NO = B.AREA_NO
                   AND C.STOCK_NO = B.STOCK_NO
                   AND M.LABEL_NO = v_SLabelNo) LOOP
        IF (v_DLabelNo = p.buffer_name) THEN
          HasFlag := 1;
        END IF;
      end loop;
      IF (HasFlag = 0) THEN
        strOutMsg := 'N|当前的箱标签不属于当前的板号！';
        return;
      END IF;
    END IF;

    --检查是否需要做装并板
    IF (strUseType = '2') THEN
      /*--这里校验当前的源标签是否可以并到目的板
      pkcheck_odata.P_Check_Mergelabel(strEnterpriseNo,strWarehouseNo,strSLabelNo,strDLabelNo,strStatus,strCustNo,strOutMsg);
      if (substr(strOutMsg, 1, 1) = 'N') then
          return;
      end if;*/

      --这里进行装并板操作
      p_merge_Pal(strEnterpriseNo,
                  strWarehouseNo,
                  v_SLabelNo,
                  v_DLabelNo,
                  strUserID,
                  strOutMsg);
      if (substr(strOutMsg, 1, 1) = 'N') then
        return;
      end if;
    END IF;

    strCustName   := '';
    strStatusText := '';
    --取客户名称
    if (strCustNo IS NOT NULL) THEN
      begin
        SELECT c.cust_name
          INTO strCustName
          FROM bdef_defcust c
         WHERE c.cust_no = strCustNo;
      exception
        when no_data_found then
          strCustName := '';
          strOutMsg   := 'N|客户信息获取失败！';
          return;
      end;
    ELSE
      strCustName := '';
    END IF;

    --取标签描述
    IF (strStatus IS NOT NULL) THEN
      begin
        SELECT v.text
          INTO strStatusText
          FROM wms_deffieldval v
         WHERE v.table_name = 'STOCK_LABEL_M'
           AND v.colname = 'STATUS'
           AND v.value = strStatus;
      exception
        when no_data_found THEN
          strStatusText := '';
          strOutMsg     := 'N|状态描述获取失败！';
          return;
      end;
    ELSE
      strStatusText := '';
    END IF;

    strOutMsg := 'Y|[成功]'; --成功
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  END P_MergePal_Label_CheckAndSave;
  /*******************************************************************************************************
    整理确认校验
    功能说明：1、校验是否能做整理确认
              若拣货未完成，不能整理确认，若拣货完成，返回波次号、客户名称、月台货位、总箱数
              目前用于小嘴的装车
  ********************************************************************************************************/
  procedure P_ArrangeCheck(strEnterpriseNo in stock_label_m.enterprise_no%type,
                           strWarehouseNo  in stock_label_m.warehouse_no%type,
                           strsLabelNo     in stock_label_m.label_no%type, --来源标签
                           strUserID       IN stock_label_m.rgst_name%TYPE, --操作用户
                           strDeliverObj   out stock_label_m.deliver_obj%type,
                           strDeliverArea  out stock_label_m.deliver_area%type,
                           strWaveNo       out stock_label_m.wave_no%type,
                           strCustName     out bdef_defcust.cust_name%type, --客户名称
                           nLabelNum       out integer,
                           strOutMsg       out varchar2) IS
    v_strStatus stock_label_m.status%type;
    v_iCount    integer;
  begin
    strOutMsg := 'N|[P_ArrangeCheck]';

    --
    begin
      select bd.cust_no || bd.cust_name,
             slm.deliver_obj,
             slm.deliver_area,
             slm.wave_no,
             slm.status
        into strCustName,
             strDeliverObj,
             strDeliverArea,
             strWaveNo,
             v_strStatus
        from stock_label_m slm, bdef_defcust bd
       where slm.enterprise_no = strEnterpriseNo
         and slm.warehouse_no = strWarehouseNo
         and slm.label_no = strsLabelNo
         and slm.cust_no = bd.cust_no /*and slm.container_type='P'*/
      ;
    exception
      when no_data_found then
        --检查此单据是否可做整理确认
        --根据月台编号获取标签号
        begin
          SELECT c.deliver_obj, c.wave_no
            into strDeliverObj, strWaveNo
            FROM ODATA_SEND_AREA_CALCULATE C, OSET_BUFFER B
           where c.enterprisE_no = b.enterprise_no
             and c.warehouse_no = b.warehouse_no
             and c.cell_no = b.cell_no
             and c.area_no = b.area_no
             and c.stock_no = b.stock_no
             and b.buffer_name = strsLabelNo;
        exception
          when no_data_found then
            strOutMsg := 'N|[找不到对应的月台资源或月台资源不存在]';
            return;
        end;

        select count(*)
          into v_iCount
          from odata_outstock_direct ood
         where ood.enterprise_no = strEnterpriseNo
           and ood.warehouse_no = strWarehouseNo
           and ood.wave_no = strWaveNo
           and ood.deliver_obj = strDeliverObj
           and ood.status < '13';

        if v_iCount > 0 then
          strOutMsg := 'N|[' || strDeliverObj || '还有单未发]';
          return;
        end if;

        select count(*)
          into v_iCount
          from stock_label_m slm
         where slm.enterprise_no = strEnterpriseNo
           and slm.warehouse_no = strWarehouseNo
           and slm.wave_no = strWaveNo
           and slm.deliver_obj = strDeliverObj
           and slm.status = '50';

        if v_iCount > 0 THEN
          strOutMsg := 'N|[' || strDeliverObj || '还有' || v_iCOUNT ||
                       '标签未回]';
          return;
        end if;

        select count(*)
          into v_iCount
          from stock_label_m slm
         where slm.enterprise_no = strEnterpriseNo
           and slm.warehouse_no = strWarehouseNo
           and slm.wave_no = strWaveNo
           and slm.deliver_obj = strDeliverObj
           and slm.status >= '62';
        if v_iCount > 0 then
          strOutMsg := 'N|[已做整理确认]';
          return;
        end if;

        --获取客户和发货货位
        select bd.cust_no || bd.cust_name, slm.deliver_area
          into strCustName, strDeliverArea
          from stock_label_m slm, bdef_defcust bd
         where slm.enterprise_no = strEnterpriseNo
           and slm.warehouse_no = strWarehouseNo
           and slm.cust_no = bd.cust_no
           and slm.wave_no = strWaveNo
           and slm.deliver_obj = strDeliverObj
           and rownum = 1;

        --获取箱标签数
        select count(*)
          into v_iCount
          from stock_label_m slm
         where slm.enterprise_no = strEnterpriseNo
           and slm.warehouse_no = strWarehouseNo
           and slm.wave_no = strWaveNo
           and slm.deliver_obj = strDeliverObj
           and slm.container_type in ('C', 'B');

        --获取箱数
        select nvl(sum(sld.qty / sld.packing_qty), 0) + v_iCount
          into nLabelNum
          from stock_label_d sld
         where sld.enterprise_no = strEnterpriseNo
           and sld.warehouse_no = strWarehouseNo
           and sld.wave_no = strWaveNo
           and sld.deliver_obj = strDeliverObj
           and sld.container_type = 'P';

    end;

    SELECT count(*)
      into v_iCount
      FROM STOCK_LABEL_M M, ODATA_SEND_AREA_CALCULATE C, OSET_BUFFER B
     WHERE M.ENTERPRISE_NO = C.ENTERPRISE_NO
       AND M.WAREHOUSE_NO = C.WAREHOUSE_NO
       AND M.Deliver_Obj = C.Deliver_Obj
       AND C.WAREHOUSE_NO = B.WAREHOUSE_NO
       AND C.ENTERPRISE_NO = B.ENTERPRISE_NO
       AND C.CELL_NO = B.CELL_NO
       AND C.AREA_NO = B.AREA_NO
       AND C.STOCK_NO = B.STOCK_NO
       AND M.LABEL_NO = strsLabelNo;
    if v_iCount > 0 then
      strOutMsg := 'N|[此标签状态不正确不能整理确认]';
      return;
    end if;

    if v_strStatus <> '61' then
      strOutMsg := 'N|[此标签状态不正确不能整理确认]';
      return;
    end if;

    strOutMsg := 'Y|[成功]';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_ArrangeCheck;

  /*=====================================================================================
  huangb insert to 20160720
  标签称重
  ======================================================================================*/
  PROCEDURE p_Save_LabelWeigh(strEnterpriseNo in STOCK_LABEL_M.enterprise_no%type, --企业号
                              strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                              strDockNo       in bdef_defdock.dock_no%type, --码头
                              strLabelNo      in stock_label_m.label_No%type, --标签号
                              nWeigh          in stock_label_m.weight%type, --重量
                              strUserId       in stock_label_m.rgst_name%type, --操作人员
                              strOutMsg       out varchar2) is

    v_Count      number(10) := 0; --循环行数
    v_UseType    stock_label_m.use_type %type; --标签用途
    v_Status     stock_label_m.status%type; --标签状态
    v_StatusDesc wms_deflabel_status.status_name%type; --标签状态备注

  begin
    strOutMsg := 'N|[p_Save_LabelWeigh]';

    --判断标签是否存在
    begin
      select slm.use_type, slm.status, wds.status_name
        into v_UseType, v_Status, v_StatusDesc
        from stock_label_m slm
        left join wms_deflabel_status wds
          on wds.status_type = slm.status
       where slm.enterprise_no = strEnterpriseNo
         and slm.warehouse_no = strWarehouseNo
         and slm.label_no = strLabelNo;
    exception
      when no_data_found then
        strOutMsg := 'N|[当前标签不存在]';
        return;
    end;

    --判断标签是否为客户标签
    if (v_UseType <> '1') then
      strOutMsg := 'N|[当前标签不是客户标签]';
      return;
    end if;

    --判断标签状态是否正确
    /*if v_Status <> CLabelStatus.RECEIVING then
      strOutMsg := 'N|[当前标签状态为('|| v_StatusDesc ||'),不能称重]';
      return;
    end if;*/

    --更新标签重量
    update stock_label_m slm
       set slm.weight    = nWeigh,
           slm.updt_name = strUserId,
           slm.updt_date = sysdate
     where slm.enterprise_no = strEnterpriseNo
       and slm.warehouse_no = strWarehouseNo
       and slm.label_no = strLabelNo;
    if sql%notfound then
      strOutMsg := 'N|[更新标签重量信息失败(更新0行)]';
    end if;

    strOutMsg := 'Y|';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_Save_LabelWeigh;

  /*=====================================================================================
  功能说明：包材处理
           1、根据快递面单写库存调帐单；
           2、根据库存调帐单定位并回单；

  ======================================================================================*/
   PROCEDURE P_strPackMateDeal(strEnterpriseNo in STOCK_LABEL_M.enterprise_no%type, --企业号
                              strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                              strLabelNo      in stock_label_m.label_no%type, --快递面单，电商的快递面单等于标签
                              strArticlNo     in stock_label_d.article_no%type, --包材编码=商品编码
                              nRealQty        in stock_content.qty%type, --包材出货数量
                              strUserId       in stock_label_m.rgst_name%type, --操作人员
                              strOutMsg       out varchar2) is
    v_cell_ware_count   number(10); --判断是否在此仓别下存在此储位的计数器
    v_Count      number(10) := 0; --循环行数
    v_strOrgNo   odata_exp_m.org_no%type;
    v_strExpNo   odata_exp_m.exp_no%type;
    nCurQty      stock_content.qty%type := 0; --当前数量
    nRemainQty   stock_content.qty%type := nRealQty; --剩余数量
    --nTotalQty    stock_content.qty%type := nRealQty; --总数量
    v_strPlanNo  stock_plan_m.plan_no%type;
    v_strOwnerNo bdef_defowner.owner_no%type;
  begin
    strOutMsg := 'N|[P_strPackMateDeal]';

    select count(*)
      into v_Count
      from bdef_defarticle bd
     where bd.article_no = strArticlNo
       and bd.VIRTUAL_FLAG = '2';

    if v_Count = 0 then
      strOutMsg := 'N|[找不到商品资料或不是包材商品]';
      return;
    end if;

    --获取机构号和出货单号
    begin
      select org_no, exp_no
        into v_strOrgNo, v_strExpNo
        from odata_exp_m t
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWarehouseNo
         and t.SHIPPER_DELIVER_NO = strLabelNo;
    exception
      when no_data_found then
        strOutMsg := 'N|[找不到对应的出货单]';
        return;
    end;

    v_Count := 0;

    --根据快递面单写库存调帐单
    --读取库存
    for GetStock in (select sc.cell_no,sai.*,
                            sc.owner_no,
                            sc.packing_qty,
                            sc.stock_type,
                            sc.stock_value,
                            sc.label_no,
                            (sc.qty - sc.outstock_qty) qty
                       from stock_content sc,stock_article_info sai
                      where sc.enterprise_no=sai.enterprise_no
                      and sc.article_no=sai.article_no
                      and sc.article_id=sai.article_id
                       and sc.enterprise_no = strEnterpriseNo
                        and sc.warehouse_no = strWarehouseNo
                        and sc.article_no = strArticlNo
                        and sc.qty > sc.outstock_qty
                      order by sc.cell_no,
                               sc.owner_no,
                               sai.article_no,
                               sc.packing_qty,
                               sc.stock_type,
                               sc.stock_value,
                               sc.label_no) loop
      --判断如果储位不属于该仓别，跳过，此条库存信息为错误库存总账数据                         
      select count(1) into v_cell_ware_count 
      from cdef_defcell t 
      where t.warehouse_no = strWarehouseNo and t.cell_no = GetStock.Cell_No;                         
                               
      if v_cell_ware_count < 1 then
        insert into STOCK_CONTENT_ERR
        select * from STOCK_CONTENT sc1
        where sc1.article_no = GetStock.Article_No
        and sc1.cell_no = GetStock.Cell_No
        and sc1.warehouse_no = strWarehouseNo
        and sc1.enterprise_no = GetStock.Enterprise_No;
        continue;
      end if;

      v_strOwnerNo := GetStock.owner_no;

      v_Count := v_Count + 1;

      if nRemainQty >= GetStock.qty then
        nCurQty := GetStock.qty;
      else
        nCurQty := nRemainQty;
      end if;

      nRemainQty := nRemainQty - nCurQty;

      pklg_adj.P_saveStockPlan(strEnterpriseNo,
                               strWarehouseNo,
                               GetStock.owner_no,
                               '4', --包材管理
                               v_strExpNo,
                               strArticlNo,
                               GetStock.packing_qty,
                               GetStock.Produce_Date,
                               GetStock.Expire_Date,
                               GetStock.Quality,
                               GetStock.Lot_No,
                               GetStock.Import_Batch_No,
                               GetStock.Rsv_Batch1,
                               GetStock.Rsv_Batch2,
                               GetStock.Rsv_Batch3,
                               GetStock.Rsv_Batch4,
                               GetStock.Rsv_Batch5,
                               GetStock.Rsv_Batch6,
                               GetStock.Rsv_Batch7,
                               GetStock.Rsv_Batch8,
                               GetStock.cell_no,
                               -nCurQty,
                               GetStock.stock_type,
                               GetStock.stock_value,
                               GetStock.label_no,
                               strUserId,
                               '0',
                               v_strOrgNo,
                               'N',
                               strLabelNo,
                               v_strPlanNo,
                               strOutMsg);

      if substr(strOutMsg, 1, 1) = 'N' then
        return;
      end if;

      if nRemainQty<=0 then
         exit ;
      end if;
    end loop;

    if v_Count = 0 then
      strOutMsg := 'N|[该商品无库存]';
      return;
    end if;

    pklg_adj.P_stockLocateComfire(strEnterPriseNo,
                                  strWareHouseNo,
                                  v_strOwnerNo,
                                  v_strPlanNo,
                                  'N',
                                  strUserId,
                                  'N',
                                  '0',
                                  strOutMsg);

    if substr(strOutMsg, 1, 1) = 'N' then
      return;
    end if;
    strOutMsg := 'Y|';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end P_strPackMateDeal;

end PKLG_ODATA_MOVE_JUN;

/

