create view V_SEARCH_9114_001 as
select enterprise_no,warehouse_no,owner_no,"OUTSTOCK_NO","OPERATE_DATE","ARTICLE_NO","ARTICLE_NAME","BARCODE","ARTICLE_QTY","REAL_QTY","S_CELL_NO","D_CELL_NO","STATUS","OUTSTOCK_NAME","OUTSTOCKWORKNAME","INSTOCK_NAME","INSTOCKWORKNAME" from (
select oom.enterprise_no,oom.warehouse_no,oom.owner_no,oom.outstock_no, --移库单号
       oom.operate_date, --操作日期
     --  oom.outstock_type, --下架类型（不显示）
     --  ood.exp_no, --移库计划单号
       a.article_no, --商品编码
       a.article_name, --商品名称
       a.barcode, --商品条码
       ood.article_qty, --计划数量
       ood.real_qty, --实际数量
       ood.s_cell_no, --来源储位
       ood.d_cell_no, --目的储位
       oom.status,--操作状态
/*       oom.rgst_name, --发单人员
       bdw.worker_name, --发单人姓名
       oom.updt_name, --回单人员
       bdw1.worker_name updateWorkName, --回单人姓名*/
       ood.outstock_name, --下架人员
       bdw2.worker_name outstockWorkName, --下架人姓名
       ood.instock_name, --上架人员
       bdw3.worker_name instockWorkName --上架人姓名
  from odata_outstock_mhty  oom,
       odata_outstock_dhty  ood,
       bdef_defarticle      a,
/*       bdef_defworker       bdw,
       bdef_defworker       bdw1,*/
       bdef_defworker       bdw2,
       bdef_defworker       bdw3
 where oom.warehouse_no = ood.warehouse_no
   and oom.owner_no = ood.owner_no
   and oom.outstock_no = ood.outstock_no
   and oom.enterprise_no = ood.enterprise_no
   and ood.article_no = a.article_no
   and ood.owner_no = a.owner_no
   and ood.enterprise_no = a.enterprise_no
   and oom.outstock_type in ('1','3','4')
/*   and oom.enterprise_no = bdw.enterprise_no
   and oom.rgst_name = bdw.worker_no
   and oom.enterprise_no = bdw1.enterprise_no
   and oom.updt_name = bdw1.worker_no*/
   and oom.enterprise_no = bdw2.enterprise_no
   and ood.instock_name = bdw2.worker_no
   and oom.enterprise_no = bdw3.enterprise_no
   and ood.outstock_name = bdw3.worker_no
 union all
select oom.enterprise_no,oom.warehouse_no,oom.owner_no,oom.outstock_no, --移库单号
       oom.operate_date, --操作日期
     --  oom.outstock_type, --下架类型（不显示）
     --  ood.exp_no, --移库计划单号
       a.article_no, --商品编码
       a.article_name, --商品名称
       a.barcode, --商品条码
       ood.article_qty, --计划数量
       ood.real_qty, --实际数量
       ood.s_cell_no, --来源储位
       ood.d_cell_no, --目的储位
       oom.status,--操作状态
/*       oom.rgst_name, --发单人员
       bdw.worker_name, --发单人姓名
       oom.updt_name, --回单人员
       bdw1.worker_name updateWorkName, --回单人姓名*/
       ood.outstock_name, --下架人员
       bdw2.worker_name outstockWorkName, --下架人姓名
       ood.instock_name, --上架人员
       bdw3.worker_name instockWorkName --上架人姓名
  from odata_outstock_m   oom,
       odata_outstock_d   ood,
       bdef_defarticle      a,
/*       bdef_defworker       bdw,
       bdef_defworker       bdw1,*/
       bdef_defworker       bdw2,
       bdef_defworker       bdw3
 where oom.warehouse_no = ood.warehouse_no
   and oom.owner_no = ood.owner_no
   and oom.outstock_no = ood.outstock_no
   and oom.enterprise_no = ood.enterprise_no
   and ood.article_no = a.article_no
   and ood.owner_no = a.owner_no
   and ood.enterprise_no = a.enterprise_no
   and oom.outstock_type in ('1','3','4')
/*   and oom.enterprise_no = bdw.enterprise_no
   and oom.rgst_name = bdw.worker_no
   and oom.enterprise_no = bdw1.enterprise_no
   and oom.updt_name = bdw1.worker_no*/
   and oom.enterprise_no = bdw2.enterprise_no
   and ood.instock_name = bdw2.worker_no
   and oom.enterprise_no = bdw3.enterprise_no
   and ood.outstock_name = bdw3.worker_no
)


/

