create package        PKLG_MLOCATE is

  -- Author  : LIZHIPING
  -- Created : 2013-09-28 10:56:43
  -- Purpose :

  -- Public type declarations
  -- type <TypeName> is <Datatype>;
  TYPE cv_type IS REF CURSOR; --声明游标类型

  -- Public constant declarations
  -- <ConstantName> constant <Datatype> := <Value>;

  -- Public variable declarations
  -- <VariableName> <Datatype>;

  -- Public function and procedure declarations
  -- function <FunctionName>(<Parameter> <Datatype>) return <Datatype>;

  --商品补货定位
  procedure p_supply_article(v_nTmpStockID   in number,
                             strEnterpriseNo in odata_locate_m.enterprise_no%type,
                             strWareHouseNo  in varchar2, --仓库代码
                             strOwnerNo      in varchar2,
                             strSourceNo     in varchar2, --定位号
                             strBatchNo      in varchar2, --批次号
                             strStatus       in varchar2,
                             strOperateType  in varchar2, --作业类型
                             strOutstockType in varchar2, --出货类型
                             strSourceType   in varchar2, --来源类型
                             strCPickCellNo  in cset_cell_article.cell_no%type,
                             nCMaxQty        in cset_cell_article.max_qty_a%type,
                             nCKeepCells     in cset_cell_article.keep_cells%type,
                             strBPickCellNo  in cset_cell_article.cell_no%type,
                             nBMaxQty        in cset_cell_article.max_qty_a%type,
                             nBKeepCells     in cset_cell_article.keep_cells%type,
                             nPickLine       in cset_cell_article.line_id%type,
                             nPickCellCount  in number,
                             strStockType    in varchar2,
                             strStockValue   in varchar2,
                             strPrioity      in varchar2,
                             dtLocateDate    in date,
                             strArticleNo    in varchar2, --商品代码
                             nNeedSuppQty    in number,
                             nMinSuppQty     in number,
                             nRealSuppQty    in out number,
                             nMustMinFlag    in number,
                             strWorkNo       in varchar2, --员工代码
                             nSuppType       in varchar2,
                             strErrorMsg     out varchar2);

  --写库存及定位指示
  procedure p_write_direct(v_nTmpStockID   in number,
                           strEnterpriseNo in odata_locate_m.enterprise_no%type,
                           strWareHouseNo  in varchar2, --仓库代码
                           strOwnerNo      in varchar2,
                           strSourceNo     in varchar2, --定位号
                           strOutstockType in varchar2, --出货类型
                           strSourceType   in varchar2, --来源类型
                           strOperateType  in varchar2, --定位类型
                           strBPickCellNo  in cset_cell_article.cell_no%type,
                           strCPickCellNo  in cset_cell_article.cell_no%type,
                           nKeepCells      in cset_cell_article.keep_cells%type, --Modify BY QZH AT 2016-4-22
                           nPickLine       in cset_cell_article.line_id%type,
                           strBatchNo      in varchar2, --定位批次
                           nSuppType       in number, --补货类型
                           nCurrSuppLevel  in number, --补货级别
                           strStatus       in varchar2,
                           strPrioity      in varchar2,
                           dtLocateData    in date,
                           strArticleNo    in varchar2, --商品代码
                           nArticleID      in number, --Article_ID
                           strCellNo       in varchar2,
                           strDeptNo       in varchar2,
                           strContainerNo  in varchar2,
                           nPacking_Qty    in number,
                           nProduceFlag    in number,
                           dtProduceDate   in date,
                           strQuality      in varchar2, --商品品质
                           --strItemType     in varchar2, --商品属性
                           strLotNo in varchar2,
                           --strSupplierNo   in varchar2,
                           strStockType   in varchar2, --库存性质
                           strStockValue  in varchar2, --库存值
                           nLocateQty     in number, --定位量
                           nRealLocateQty in out number,
                           strWorkNo      in varchar2, --员工代码
                           strErrorMsg    out varchar2);

  --读取补货目的储位
  procedure p_get_supp_cell(strEnterpriseNo in odata_locate_m.enterprise_no%type,
                            strWareHouseNo  in varchar2, --仓库代码
                            strOwnerNo      in varchar2,
                            strOperateType  in varchar2, --定位类型
                            strBPickCellNo  in cset_cell_article.cell_no%type,
                            strCPickCellNo  in cset_cell_article.cell_no%type,
                            nKeepCells      in cset_cell_article.keep_cells%type, --Modify BY QZH AT 2016-4-22
                            nPickLine       in cset_cell_article.line_id%type,
                            nSuppType       in number, --补货类型
                            nCurrSuppLevel  in number, --补货级别
                            strArticleNo    in varchar2, --商品代码
                            nArticleID      in number, --Article_ID
                            nPacking_Qty    in bdef_article_packing.packing_qty%type,
                            nLocateQty      in stock_content.qty%type,
                            strDeptNo       in varchar2,
                            nProduceFlag    in number,
                            dtProduceDate   in date,
                            strQuality      in varchar2, --商品品质
                            --strItemType    in varchar2, --商品属性
                            strLotNo      in varchar2,
                            strStockType  in varchar2, --库存性质
                            strStockValue in varchar2, --库存值
                            strDestCellNo out varchar2,
                            strErrorMsg   out varchar2);

  /*-----------------------------------------------
  设置储位商品补货次数
  ------------------------------------------------*/
  procedure p_set_cell_suppcount(strEnterpriseNo in odata_locate_m.enterprise_no%type,
                                 strWareHouseNo  in varchar2, --仓库代码
                                 strCellNo       in varchar2,
                                 strArticleNo    in varchar2, --商品代码
                                 strErrorMsg     out varchar2);

  /*-----------------------------------------------
  安全量补货入口
  ------------------------------------------------*/
  procedure p_securitysupply_main(strEnterpriseNo in odata_locate_m.enterprise_no%type,
                                  strWareHouseNo  in varchar2, --仓库代码
                                  strOwnerNo      in varchar2,
                                  strPlanNo       in varchar2, --计划单号
                                  strWorkNo       in varchar2, --操作人员
                                  strErrorMsg     out varchar2);

  /*-----------------------------------------------
  安全量补货
  ------------------------------------------------*/
  procedure p_securitysupply_article(strEnterpriseNo in varchar2, --企业号
                                     strWareHouseNo  in varchar2, --仓库代码
                                     strOwnerNo      in varchar2,
                                     strPlanNo       in varchar2, --定位号
                                     strPickType     in varchar2, --下架类型 C或者B
                                     strOutstockType in varchar2, --出货类型 3:安全量补货
                                     strSourceType   in varchar2, --来源类型 1:普通
                                     strBatchNo      in varchar2, --定位批次 默认为N
                                     strArticleNo    in varchar2, --商品代码
                                     strArticleID    in varchar2,
                                     nNeedSuppQty    in number, --补货量
                                     nRealSuppQty    in out number, --定位量
                                     dtLocateDate    in date,
                                     nSuppType       in varchar2, --补货类型0：保拣线补到拣货位；1：全仓补到拣货位
                                     strLineID       in varchar2, --保拣线
                                     strWorkNo       in varchar2, --员工代码
                                     strSDeFine      in varchar2, --是否只补拣货位
                                     strPickCellNO   in varchar2, --拣货位
                                     strErrorMsg     out varchar2);

  /*-----------------------------------------------
  安全量补货写定位指示
  ------------------------------------------------*/
  procedure p_securitywrite_direct(strEnterpriseNo in varchar2,
                                   strWareHouseNo  in varchar2, --仓库代码
                                   strOwnerNo      in varchar2,
                                   strSourceNo     in varchar2, --定位号
                                   strOutstockType in varchar2, --出货类型
                                   strSourceType   in varchar2, --来源类型
                                   strOperateType  in varchar2, --定位类型
                                   strBatchNo      in varchar2, --定位批次
                                   nSuppType       in number, --补货类型
                                   nCurrSuppLevel  in number, --补货级别
                                   strStatus       in varchar2,
                                   strPrioity      in varchar2,
                                   dtLocateData    in date,
                                   strArticleNo    in varchar2, --商品代码
                                   strCellNo       in varchar2,
                                   strDestCellNo   in varchar2,
                                   strDeptNo       in varchar2,
                                   strContainerNo  in varchar2,
                                   nPacking_Qty    in number,
                                   nProduceFlag    in number,
                                   dtProduceDate   in date,
                                   strQuality      in varchar2, --商品品质
                                   --strItemType     in varchar2, --商品属性
                                   strLotNo in varchar2,
                                   --strSupplierNo   in varchar2,
                                   strStockType   in varchar2, --库存性质
                                   strStockValue  in varchar2, --库存值
                                   nLocateQty     in number, --定位量
                                   nRealLocateQty in out number,
                                   strWorkNo      in varchar2, --员工代码
                                   strErrorMsg    out varchar2);

end PKLG_MLOCATE;


/

