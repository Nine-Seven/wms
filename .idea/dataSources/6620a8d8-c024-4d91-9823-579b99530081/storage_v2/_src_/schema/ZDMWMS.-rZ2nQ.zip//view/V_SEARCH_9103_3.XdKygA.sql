create view V_SEARCH_9103_3 as
SELECT oem.enterprise_no,
       OEM.WAREHOUSE_NO,
       OEM.EXP_TYPE,
       OEM.EXP_NO,
       OEM.SOURCEEXP_NO,
       OEM.CUST_NO,
       OEM.SUB_CUST_NO,
       BDC.CUST_NAME,
       OEM.OWNER_NO,
       NVL(WDF.TEXT, OEM.STATUS) LOCATE_STATUS,
       CASE
         WHEN EXISTS (SELECT 'x'
                 FROM Odata_Outstock_Dhty OD
                WHERE OD.EXP_NO = OEM.EXP_NO
                  and od.enterprise_no = oem.enterprise_no) THEN
          '已拣货完成'
         ELSE
          CASE
            WHEN EXISTS (SELECT 'x'
                    FROM ODATA_OUTSTOCK_D OD
                   WHERE OD.EXP_NO = OEM.EXP_NO
                     and od.enterprise_no = oem.enterprise_no
                     AND OD.STATUS < '13') THEN
             '拣货中'
            ELSE
             '未发单'
          END
       END AS OUTSTOCK_STATUS,
       CASE
         WHEN NOT EXISTS
          (SELECT 'x' FROM ODATA_DIVIDE_D OD
            WHERE OD.EXP_NO = OEM.EXP_NO
              and od.enterprise_no = oem.enterprise_no) THEN
          '未分播发单'
         ELSE
          CASE
            WHEN EXISTS (SELECT 'x'
                    FROM ODATA_DIVIDE_D OD
                   WHERE OD.EXP_NO = OEM.EXP_NO
                     and od.enterprise_no = oem.enterprise_no
                     AND OD.STATUS < '13') THEN
             '分播中'
            ELSE
             '已分播完成'
          END
       END AS DIVIDE_STATUS,
       CASE
         WHEN NOT EXISTS (SELECT 'x'
                 FROM ODATA_RECHECK_D ORD
                WHERE ORD.EXP_NO = OEM.EXP_NO
                  and ord.enterprise_no = oem.enterprise_no) THEN
          '未装车拣货发单'
         ELSE
          CASE
            WHEN EXISTS (SELECT 'X'
                    FROM ODATA_RECHECK_D ORD, ODATA_RECHECK_M ORM
                   WHERE ORM.WAREHOUSE_NO = ORD.WAREHOUSE_NO
                     and orm.enterprise_no = ord.enterprise_no
                     AND ORM.RECHECK_NO = ORD.RECHECK_NO
                     AND ord.exp_no = oem.exp_no
                     AND ORM.STATUS = '10') THEN
             '财务审核完成'
            WHEN EXISTS (SELECT 'X'
                    FROM ODATA_RECHECK_D ORD, ODATA_RECHECK_M ORM
                   WHERE ORM.WAREHOUSE_NO = ORD.WAREHOUSE_NO
                     and orm.enterprise_no = ord.enterprise_no
                     AND ORM.RECHECK_NO = ORD.RECHECK_NO
                     AND ord.exp_no = oem.exp_no
                     AND ORM.STATUS = '11') THEN
             '等待财务审核'
            WHEN EXISTS (SELECT 'X'
                    FROM ODATA_RECHECK_D ORD, ODATA_RECHECK_M ORM
                   WHERE ORM.WAREHOUSE_NO = ORD.WAREHOUSE_NO
                     and orm.enterprise_no = ord.enterprise_no
                     AND ORM.RECHECK_NO = ORD.RECHECK_NO
                     AND ord.exp_no = oem.exp_no
                     AND ORM.STATUS = '13') THEN
             '装车拣货完成'
            WHEN EXISTS (SELECT 'X'
                    FROM ODATA_RECHECK_D ORD, ODATA_RECHECK_M ORM
                   WHERE ORM.WAREHOUSE_NO = ORD.WAREHOUSE_NO
                     and orm.enterprise_no = ord.enterprise_no
                     AND ORM.RECHECK_NO = ORD.RECHECK_NO
                     AND ord.exp_no = oem.exp_no
                     AND ORM.STATUS = '16') THEN
             '财务取消'
          END
       END AS RECHECK_STATUS,
       CASE
         WHEN NOT EXISTS (SELECT 'x'
                 FROM ODATA_LOADPROPOSE_D OL
                WHERE OL.EXP_NO = OEM.EXP_NO
                  and ol.enterprise_no = oem.enterprise_no) THEN
          '未装车'
         ELSE
          '已装车'
       END LOADPROPOSE_STATUS,
       CASE
         WHEN NOT EXISTS (SELECT 'x'
                 FROM ODATA_DELIVER_D ODD
                WHERE ODD.EXP_NO = OEM.EXP_NO
                  and odd.enterprise_no = oem.enterprise_no) THEN
          '未出车'
         ELSE
          '已配送'
       END DELIVER_STATUS,
       ocv.car_plan_no,
       oem.import_no,
       oem.erpoperate_date
  FROM ODATA_EXP_M OEM
 INNER JOIN bdef_DEFCUST BDC
    ON OEM.CUST_NO = BDC.CUST_NO
    and oem.enterprise_no = bdc.enterprise_no
  LEFT JOIN WMS_DEFFIELDVAL WDF
    ON WDF.TABLE_NAME = 'ODATA_EXP_M'
   AND WDF.COLNAME = 'STATUS'
   AND WDF.VALUE = OEM.STATUS
  left join ODATA_carplan_volume ocv
    on oem.WAREHOUSE_NO = ocv.WAREHOUSE_NO
   and oem.enterprise_no = ocv.enterprise_no
   and oem.exp_no = ocv.exp_no
 GROUP BY oem.enterprise_no,
          OEM.WAREHOUSE_NO,
          OEM.OWNER_NO,
          OEM.EXP_TYPE,
          OEM.EXP_NO,
          OEM.SOURCEEXP_NO,
          OEM.CUST_NO,
          OEM.SUB_CUST_NO,
          wdf.text,
          oem.status,
          BDC.CUST_NAME,
          ocv.car_plan_no,
          oem.import_no,
          oem.erpoperate_date

/

