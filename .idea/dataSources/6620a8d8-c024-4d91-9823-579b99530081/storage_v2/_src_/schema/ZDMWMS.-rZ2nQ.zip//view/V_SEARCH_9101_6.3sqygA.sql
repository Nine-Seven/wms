create view V_SEARCH_9101_6 as
select m.enterprise_no,m.owner_no,m.family_no,m.family_name,d.article_no,e.owner_article_no,e.article_name,e.rsv_attr1,e.rsv_attr3,e.rsv_attr4 from bdef_article_family_m m,bdef_article_family_d d,bdef_defarticle e
where m.family_no=d.family_no and m.enterprise_no=d.enterprise_no and m.owner_no=d.owner_no
and d.enterprise_no=e.enterprise_no and d.owner_no=e.owner_no and d.article_no=e.article_no


/

