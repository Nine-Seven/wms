create view V_SEARCH_9104_3 as
select "BARCODE","ARTICLE_NAME","SUPPLIER_NO","ENTERPRISE_NO","WAREHOUSE_NO","OWNER_NO","SOURCE_NO","S_LABEL_NO","LABEL_NO","ROW_ID","ARTICLE_NO","PACKING_QTY","QTY","PRODUCE_DATE","EXPIRE_DATE","QUALITY","LOT_NO","S_CELL_NO","D_CELL_NO","PRINTER_GROUP_NO","DOCK_NO","STATUS","RGST_NAME","RGST_DATE","UPDT_NAME","UPDT_DATE","ARRANGE_TYPE","STATUS_DESC"
  from (select bda.barcode,bda.ARTICLE_NAME,
               bda.supplier_no,
               a.*,
               decode(a.status, '10', '初始', '已封箱') as status_desc
          from stock_label_arrange_log a
          join v_bdef_defarticle bda
            on a.enterprise_no = bda.enterprise_no
           and a.article_no = bda.article_no
         where a.arrange_type = '2')

/

