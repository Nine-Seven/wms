create package        PKOBJ_ODATA is
  --出货对象

  /*****************************************************************************************
     功能：写出货下架单头档
     Modify BY QZH AT 2016-5-24 RF索单的打印状态为0
  *****************************************************************************************/
  procedure P_O_WriteOutStockHead(strEnterPriseNo in odata_outstock_m.enterprise_no%type,
                                  v_warehouse_no  in odata_outstock_m.warehouse_no%type, --仓别
                                  strOwnerNo      in odata_outstock_m.owner_no%type, --货主
                                  strWaveNo       in odata_outstock_m.wave_no%type,
                                  strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                  strPickType     in odata_outstock_m.pick_type%type, --拣货方式
                                  strBatchNo      in odata_outstock_m.batch_no%type, --批次
                                  strOperateType  in odata_outstock_m.operate_type%type, --作业类型
                                  strStatus       in odata_outstock_m.status%type, --作业状态
                                  strUserID       in odata_outstock_m.rgst_name%type, --员工ID
                                  strTaskType     in odata_outstock_m.task_type%type, --发单方式
                                  strPriorty      in odata_outstock_m.priority%type, --优先级
                                  strExp_Date     in odata_outstock_m.operate_date%type, --操作日期
                                  strOutStockType in odata_outstock_m.outstock_type%type, --出货类型
                                  strDockNo       in odata_outstock_m.dock_no%type, --码头编码
                                  strSourceType   in odata_outstock_m.source_type%type, --作业类型
                                  strPrintType    in odata_outstock_m.print_type%type,
                                  strPrintStatus  in odata_outstock_m.print_status%type,
                                  strTaskGetType  in odata_outstock_m.task_get_type%type,
                                  strMemo         in odata_outstock_m.memo%type,
                                  strOutMsg       out varchar2); --返回值

  /*****************************************************************************************
     功能：写出货下架单明细
  *****************************************************************************************/
  procedure P_O_WriteOutStockItem(strEnterPriseNo in odata_outstock_m.enterprise_no%type,
                                  v_warehouse_no  in odata_outstock_d.warehouse_no%type, --仓别
                                  strOutStockNo   in odata_outstock_d.outstock_no%type, --下架单号
                                  strAssignName   in odata_outstock_d.assign_name%type, --计划作业人员
                                  strDirectSerial in odata_outstock_d.divide_id%type, --指示序列
                                  strOperateDate  in odata_outstock_m.operate_date%type, --操作日期
                                  strPickType     in odata_outstock_m.pick_type%type, --0：摘果；1：播种
                                  strOutMsg       out varchar2); --返回值

  /*****************************************************************************************
     功能：修改出货下架指示
  *****************************************************************************************/
  procedure P_O_UpdatedOmOutStockDirect(strEnterPriseNo in odata_outstock_m.enterprise_no%type,
                                        v_warehouse_no  in odata_outstock_m.warehouse_no%type, --仓别
                                        strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                        strUserID       in odata_outstock_m.rgst_name%type, --员工ID
                                        strOutMsg       out varchar2); --返回值

  /*****************************************************************************************
     功能：修改出货下架明细信息

  *****************************************************************************************/
  procedure P_O_UpdatedOmOutStockItem(strEnterPriseNo in odata_outstock_d.enterprise_no%type,
                                      v_warehouse_no  in odata_outstock_d.warehouse_no%type, --仓别
                                      strOutStockNo   in odata_outstock_d.outstock_no%type, --下架单号
                                      strRealQty      in odata_outstock_d.real_qty%type,
                                      strScontainerNo in odata_outstock_d.s_container_no%type,
                                      strOwnerNo      in odata_outstock_d.owner_no%type,
                                      strDivideId     in odata_outstock_d.divide_id%type,
                                      strOutstockName in odata_outstock_d.outstock_name%type, --出货员工ID
                                      strInstockName  in odata_outstock_d.instock_name%type, --出货员工ID
                                      strStatus       in odata_outstock_d.status%type, --状态
                                      strOutMsg       out varchar2); --返回值

  /*****************************************************************************************
     功能：修改出货下架单头信息

  *****************************************************************************************/
  procedure P_O_UpdateOmOutStockHeader(strEnterPriseNo in odata_outstock_m.enterprise_no%type,
                                       v_warehouse_no  in odata_outstock_m.warehouse_no%type, --仓别
                                       strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                       strUserId       in odata_outstock_m.rgst_name%type, --员工ID
                                       strOutMsg       out varchar2); --返回值

  /*****************************************************************************************
     功能：下架回单 数据转历史处理

  *****************************************************************************************/
  procedure P_O_UpdateOmOutStockHistory(strEnterPriseNo in odata_outstock_m.enterprise_no%type, --仓别
                                        v_warehouse_no  in odata_outstock_m.warehouse_no%type, --仓别
                                        strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                        strUserId       in odata_outstock_m.rgst_name%type, --员工ID
                                        strFlagZero     in varchar2, --拣货零回标示
                                        strOutMsg       out varchar2); --返回值

  /*****************************************************************************************
     功能：修改出货下架明细信息    --按下架单号、按储位、按商品回单

  *****************************************************************************************/
  procedure P_O_UpdtStockByStockArticle(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                        v_warehouse_no  in stock_label_m.warehouse_no%type,
                                        strOutStockNo   in stock_label_m.source_no%type,
                                        strArticleNo    in stock_label_d.article_no%type,
                                        strScellNo      in odata_outstock_d.s_cell_no%type,
                                        strFlagZero     in varchar2,
                                        strUserID       in stock_label_m.updt_name%type,
                                        strOutMsg       out varchar2); --返回值

  /*****************************************************************************************
     功能：修改出货下架明细信息    --按下架单号整单回单

  *****************************************************************************************/
  procedure P_O_UpdatedStockDByStockNo(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                       v_warehouse_no  in stock_label_m.warehouse_no%type,
                                       strOutStockNo   in stock_label_m.source_no%type,
                                       strFlagZero     in varchar2,
                                       strUserID       in stock_label_m.updt_name%type,
                                       strOutMsg       out varchar2); --返回值

  /*****************************************************************************************
     功能：下架单号更新下架单头档派单人员 ( RF 派单+换人 功能 )

  *****************************************************************************************/
  procedure P_O_UpdatedOutNameByStockNo(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                        v_warehouse_no  in stock_label_m.warehouse_no%type, --仓别
                                        strOutStockNo   in stock_label_m.source_no%type, --下架单号
                                        strHandOutName  in stock_label_m.updt_name%type, --派单人
                                        strType         in varchar2, --操作类型  （1：派单， 2 ：换人, 3：回收）
                                        strUserID       in stock_label_m.updt_name%type, --操作人
                                        strOutMsg       out varchar2); --返回值

  /*****************************************************************************************
     功能：下架回单  触发未触发的 出货或补货

  *****************************************************************************************/
  procedure P_O_CheckStatusCanOutstock(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                       v_warehouse_no  in stock_label_m.warehouse_no%type, --仓别
                                       strOwnerNo      in odata_outstock_d.owner_no%type, --委托业主编码
                                       strOutMsg       out varchar2); --返回值

  /*****************************************************************************************
     功能：修改出货下架单头信息( 立库移库  修改状态为中间状态 A1)

  *****************************************************************************************/
  procedure P_O_UpdateHmOutStockHeader(strEnterPriseNo in odata_outstock_m.enterprise_no%type,
                                       v_warehouse_no  in odata_outstock_m.warehouse_no%type, --仓别
                                       strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                       strUserId       in odata_outstock_m.rgst_name%type, --员工ID
                                       strOutMsg       out varchar2); --返回值

  /***********************************************************************************************************
   创建人：luozhiling
   时间：2013.11.11
   功能：表单回单时将来源标签库存转移到目的标签
  ************************************************************************************************************/
  procedure P_Odata_Outstock_label(strEnterPriseNo    in odata_outstock_m.enterprise_no%type,
                                   strWareHouseNo     in odata_outstock_d.warehouse_no%type, --仓库编码
                                   strOutstockNo      in odata_outstock_d.outstock_no%type, --分播单号
                                   strsContainerNo    in odata_outstock_d.s_container_no%type, --来源容器号
                                   strDestContainerNo in odata_outstock_d.d_container_no%type, --目的容器号
                                   nDivideId          in odata_outstock_d.divide_id%type, --
                                   strArticleNo       in odata_outstock_d.article_no%type,
                                   nArticleId         in odata_outstock_d.article_id%type,
                                   nPackingQty        in odata_outstock_d.packing_qty%type,
                                   strExpNo           in odata_outstock_d.exp_no%type,
                                   nRealQty           in odata_outstock_d.real_qty%type,
                                   strCustNo          in odata_outstock_d.Cust_No%type, --客户编码
                                   strUserId          in odata_outstock_m.rgst_name%type,
                                   strResult          OUT varchar2);

  --检查下架单时间限制
  procedure P_O_check_TimeLimit(strEnterPriseNo in cdef_defware.enterprise_no%type,
                                strWareHouseNo  in cdef_defware.warehouse_no%type,
                                strOutstock_No  in odata_outstock_m.outstock_no%type,
                                strOwner_No     in odata_outstock_m.owner_no%type,
                                strResult       OUT varchar2);

end PKOBJ_ODATA;


/

