create package pkobj_Create_base is

  /**********************************************************************************************************
    csr
    2015.10.09
    功能：导入货主资料
  ***********************************************************************************************************/
  procedure p_insertOwner(strEnterpriseNo in tmp_formexcel_owner.enterprise_no%type,
                          strUserId       in bdef_defworker.worker_no%type,
                          strRowid        out tmp_formexcel_owner.row_id%type,
                          strOutMsg       out varchar2);

  /**********************************************************************************************************
     luozhiling
     2015.04.20
     功能：导入商品类别资料
  ***********************************************************************************************************/
  procedure P_insertArticleGroup(strEnterpriseNo in bdef_article_group.enterprise_no%type,
                                 dtOperateDate   in Tmp_FormExcel_ARTICLE_GROUP.Operate_Date%type,
                                 strUserId       in bdef_defworker.worker_no%type,
                                 strOutMsg       out varchar2);

  /**********************************************************************************************************
     luozhiling
     2015.04.20
     功能：导入商品资料（导入规则：货主商品编码是否为空，为空新增，不为空修改，修改不到新增）
  ***********************************************************************************************************/
  procedure p_insertdefarticle(strEnterpriseNo in bdef_article_group.enterprise_no%type,
                               dtOperateDate   in Tmp_FormExcel_ARTICLE_GROUP.Operate_Date%type,
                               strFlag         in varchar2,--1， 表示普通格式，2：商品名称=货主编码+商品名称
                               strUserId       in bdef_defworker.worker_no%type,
                               strOutMsg       out varchar2);
  /**********************************************************************************************************
    hekl
    2015.04.24
    功能：导入客户资料
  ***********************************************************************************************************/
  procedure p_insertdefcust(strEnterpriseNo in tmp_formexcel_cust.enterprise_no%type,
                            strUserId       in bdef_defworker.worker_no%type,
                            strRowid        out tmp_formexcel_cust.row_id%type,
                            strOutMsg       out varchar2);

  /**********************************************************************************************************
    hekl
    2015.04.24
    功能：导入供应商资料
  ***********************************************************************************************************/
  procedure p_insertdefsupplier(strEnterpriseNo in bdef_defsupplier.enterprise_no%type,
                                strUserId       in bdef_defworker.worker_no%type,
                                strRowid        out tmp_fromexcel_supplier.row_id%type,
                                strOutMsg       out varchar2);

  /**********************************************************************************************************

    2015.04.24
    功能：导入商品储位对照关系
  ***********************************************************************************************************/
  procedure p_insertCsetCellArticle(strEnterpriseNo in bdef_article_group.enterprise_no%type,
                                    strWareHouseNo  in cset_cell_article.warehouse_no%type,
                                    strUserId       in bdef_defworker.worker_no%type,
                                    strOutMsg       out varchar2);

  /*************************************************************************************************
   创建人：chensr
   创建时间：2014.12.19
   功能说明：excel导入（存储进货手建单）
  **************************************************************************************************/
  procedure P_idata_import(strEnterpriseNo in idata_import_tmp.enterprise_no%type,
                           strWareHouseNo  in idata_import_tmp.warehouse_no%type,
                           strUserId       in bdef_defworker.worker_no%type,
                           strResult       out varchar2);

  /*************************************************************************************************
   创建人：hekl
   创建时间：2015.11.30
   功能说明：excel导入（直通进货手建单）
  **************************************************************************************************/
  procedure P_idata_import_id(strEnterpriseNo in idata_import_tmp.enterprise_no%type,
                              strWareHouseNo  in idata_import_tmp.warehouse_no%type,
                              strUserId       in bdef_defworker.worker_no%type,
                              strResult       out varchar2);
  /*************************************************************************************************
   创建人：chensr
   创建时间：2014.12.19
   功能说明：excel导入（出货手建单）
  **************************************************************************************************/
  procedure p_odata_exp(strCurrEnterpriseNo in odata_exp_tmp.enterprise_no%type,
                        strWareHouseNo      in odata_exp_tmp.warehouse_no%type,
                        strUserId           in bdef_defworker.worker_no%type,
                        strResult           out varchar2);
  /*************************************************************************************************
   创建人：hkl
   创建时间：2015.09.15
   功能说明：excel报损手建单导入
  **************************************************************************************************/
  procedure P_sodata_waste(strEnterpriseNo in idata_import_tmp.enterprise_no%type,
                           strWareHouseNo  in idata_import_tmp.warehouse_no%type,
                           strUserId       in bdef_defworker.worker_no%type,
                           strResult       out varchar2);

  /*************************************************************************************************
    创建人：hekl
    创建时间：2015.07.09
    功能说明：移库人工移库手建单的导入
  **************************************************************************************************/
  procedure P_mdata_planUpLoad(strEnterpriseNo in mdata_plan_m.enterprise_no%type,
                               strWareHouseNo  in mdata_plan_m.warehouse_no%type,
                               strWorkerNo     in mdata_plan_m.rgst_name%type,
                               strResult       out varchar2);
  /*************************************************************************************************
    创建人：hcx
    创建时间：2015.11.30
    功能说明：返配手建单导入
  **************************************************************************************************/
  procedure P_ridata_untread(strEnterpriseNo in ridata_untread_tmp.enterprise_no%type,
                             strWareHouseNo  in ridata_untread_tmp.warehouse_no%type,
                             strWorkSpaceNo  in ridata_check_m.dock_no%type,
                             strUserId       in bdef_defworker.worker_no%type,
                             strResult       out varchar2);
  /*************************************************************************************************
    创建人：hcx
    创建时间：2015.12.01
    功能说明：退厂手建单导入
  **************************************************************************************************/
  procedure P_rodata_recede(strEnterpriseNo in ridata_untread_tmp.enterprise_no%type,
                            strWareHouseNo  in ridata_untread_tmp.warehouse_no%type,
                            strUserId       in bdef_defworker.worker_no%type,
                            strResult       out varchar2);
  /**********************************************************************************************************
   chensr
    2015.08.11
    功能：储位导入
  ***********************************************************************************************************/
  procedure p_insertDefcell(strEnterpriseNo in tmp_formexcel_defcell.enterprise_no%type,
                            strWarehouseNo  in tmp_formexcel_defcell.warehouse_no%type,
                            strUserId       in bdef_defworker.worker_no%type,
                            strRowid        out tmp_formexcel_defcell.row_id%type,
                            strOutMsg       out varchar2);
  /**********************************************************************************************************
   huangcx
  2015.10.27
  功能：计费项目导入
  ***********************************************************************************************************/

  procedure P_bill_formulaset(strEnterpriseNo in bill_formulaset_tmp.enterprise_no%type,
                              strWareHouseNo  in bill_formulaset_tmp.warehouse_no%type,
                              strUserId       in bill_formulaset.rgst_name%type,
                              strResult       out varchar2);

  /**********************************************************************************************************
   hkl
  2016.01.29
  功能：判断该货主的进货单是否能自动生成包装
  ***********************************************************************************************************/

  procedure P_idata_import_article(strEnterpriseNo in idata_import_m.enterprise_no%type,
                                   strWareHouseNo  in idata_import_m.warehouse_no%type,
                                   strOwnerNo      in idata_import_m.owner_no%type,
                                   strArticleNo    in idata_import_d.article_no%type,
                                   strPackingQty   in idata_import_d.packing_qty%type,
                                   strUserId       in bill_formulaset.rgst_name%type,
                                   strResult       out varchar2);
  /**********************************************************************************************************
   hcx
  2016.07.05
  功能：商品与商品群组关系导入
  ***********************************************************************************************************/
  procedure P_bdef_article_family(
                           strEnterpriseNo  in    idata_import_tmp.enterprise_no%type,
                           strUserId        in    bdef_defworker.worker_no%type,
                           strResult        out   varchar2);

/**********************************************************************************************************
   czh
   2016.7.26
  功能：集货作业导入
  ***********************************************************************************************************/
  procedure P_odata_package(strEnterpriseNo in odata_package_tmp.enterprise_no%type,
                             strWareHouseNo  in odata_package_tmp.warehouse_no%type,
                             strUserId       in bdef_defworker.worker_no%type,
                             strResult       out varchar2);
  /**********************************************************************************************************
     校验商品资料临时表的资料是否正确，
     20160815
  ***********************************************************************************************************/
  procedure p_Checkarticle(strEnterpriseNo in bdef_article_group.enterprise_no%type,
                           dtOperateDate   in Tmp_FormExcel_ARTICLE_GROUP.Operate_Date%type,
                           strUserId       in bdef_defworker.worker_no%type,
                           strOutMsg       out varchar2);

   /****************************************************************************************************
     2016.12.22
     将Excel数据导入出货订单
     JCL
  ******************************************************************************************************/
  PROCEDURE P_CREATE_STOCK(strEnterpriseNo in stock_plan_m.enterprise_no%type,
                                              strWareHouseNo  in stock_plan_m.warehouse_no%type,
                                              strUserId       in bdef_defworker.worker_no%type,
                                              strOutMsg       out varchar2);
end pkobj_Create_base;


/

