create view V_SEARCH_9110_1 as
select ccl.enterprise_no,ccl.warehouse_no,ccl.owner_no,o.owner_alias,cf.project_name,ccl.build_date,ccl.qty
  from cost_cost_list ccl,bdef_defowner o,cost_formulaset cf
WHERE ccl.enterprise_no = o.enterprise_no AND ccl.owner_no = o.owner_no
AND ccl.enterprise_no = cf.enterprise_no AND ccl.warehouse_no = cf.warehouse_no
AND ccl.owner_no = cf.owner_no AND ccl.billing_project = cf.billing_project
AND ccl.billing_type = cf.billing_type
ORDER BY ccl.owner_no,ccl.build_date,cf.project_name


/

