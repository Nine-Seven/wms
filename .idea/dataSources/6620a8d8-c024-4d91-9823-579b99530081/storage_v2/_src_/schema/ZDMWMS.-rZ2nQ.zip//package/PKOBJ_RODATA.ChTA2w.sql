create package        pkobj_rodata is
  --退货对象

  /*       功能：写退货下架单头档
  *****************************************************************************************/
  procedure P_RO_WriteOutStockHead(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                                   strWarehouseNo in rodata_outstock_m.warehouse_no%type, --仓别
                                   strOwnerNo     in rodata_outstock_m.owner_no%type,
                                   strOutStockNo  in rodata_outstock_m.outstock_no%type, --下架单号
                                   strOperateType in rodata_outstock_m.operate_type%type, --作业类型
                                   strRecedeType  in rodata_outstock_m.recede_type%type,--退货类型
                                   strClassType   in rodata_outstock_m.class_type%type,--0:正常；1：质量问题；2：总仓
                                   strUserID      in rodata_outstock_m.rgst_name%type, --员工ID
                                   strTaskType    in rodata_outstock_m.task_type%type,
                                   strOutMsg      out varchar2);
  --     功能：写退货下架单明细
  procedure P_RO_WriteOutStockItem(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                                   strWarehouseNo in rodata_outstock_direct.warehouse_no%type, --仓别
                                   strOwnerNo     in rodata_outstock_direct.owner_no%type,
                                   strOutStockNo  in rodata_outstock_d.outstock_no%type, --下架单号
                                   strAssignName  in rodata_outstock_d.assign_name%type, --计划作业人员
                                   dOperateDate   in rodata_outstock_direct.operate_date%type,
                                   nDirectSerial  in rodata_outstock_direct.direct_serial%type, --指示序列
                                   strOutMsg      out varchar2);

  --新增拆分的退货下架明细
  procedure P_RO_InsertOutStockItem(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                                    strWarehouseNo in rodata_outstock_direct.warehouse_no%type, --仓别
                                    strOwnerNo     in rodata_outstock_direct.owner_no%type,
                                    strOutStockNo  in rodata_outstock_d.outstock_no%type, --下架单号
                                    strArticleNO   IN rodata_outstock_d.article_no%type,
                                    strScellNo     in rodata_outstock_d.s_cell_no%type,
                                    strsCellId     in rodata_outstock_d.s_cell_id%type,
                                    nArticleQTY    in rodata_outstock_d.article_qty%type, --预计拆分数量
                                    nRealQTY       in rodata_outstock_d.article_qty%type, --实际拆分数量
                                    strRealCellNo  in rodata_outstock_d.d_cell_no%type,
                                    strsLablNo     in rodata_outstock_d.s_label_no%type,--来源标签
                                    strLabelNo     in rodata_outstock_d.label_no%type,--目的标签
                                    nDivideId      in rodata_outstock_d.divide_id%type, --指示序列
                                    strScanName    in rodata_outstock_d.scan_name%type,--扫描人
                                    strOutMsg      out varchar2) ;
  --更新退货下架指示
  procedure P_RO_UpdatedOutStockDirect(strEnterPriseNo in rodata_outstock_d.enterprise_no%type,
                                       strWarehouseNo in rodata_outstock_d.warehouse_no%type, --仓别
                                       strOwnerNo     in rodata_outstock_d.owner_no%type,
                                       strOutStockNo  in rodata_outstock_d.outstock_no%type, --下架单号
                                       strUserID      in rodata_outstock_d.assign_name%type, --员工ID
                                       strOutMsg      out varchar2);
  --将下架指示转历史
  procedure P_RO_InsertOutStockDirectHTY(strEnterPriseNo in rodata_outstock_d.enterprise_no%type,
                                       strWarehouseNo in rodata_outstock_d.warehouse_no%type, --仓别
                                       strOwnerNo     in rodata_outstock_d.owner_no%type,
                                       DivideId  in rodata_outstock_d.divide_id%type, --下架序列号
                                       strUserID      in rodata_outstock_d.assign_name%type, --员工ID
                                       strOutMsg      out varchar2);

  --更新退货单头档
  procedure P_RO_UpdateRecedeHeader(strEnterPriseNo in rodata_recede_m.enterprise_no%type,
                                    strWarehouseNo in rodata_recede_m.warehouse_no%type, --仓别
                                    strDeliverNo   in rodata_deliver_m.deliver_no%type, --下架单号
                                    strOwnerNo     in rodata_recede_m.owner_no%type,
                                    strUserId      in rodata_recede_m.rgst_name%type, --员工ID
                                    strStatus      in rodata_recede_m.status%type,
                                    strOutMsg      out varchar2);

  /*****************************************************************************************
     功能：修改退货下架单头信息
  *****************************************************************************************/
  procedure P_RO_UpdateOutStockHeader(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                                      strWarehouseNo in rodata_outstock_m.warehouse_no%type, --仓别
                                      strOutStockNo  in rodata_outstock_m.outstock_no%type, --下架单号
                                      strOwnerNo     in rodata_outstock_m.owner_no%type,
                                      strUserId      in rodata_outstock_m.rgst_name%type, --员工ID
                                      strOutMsg      out varchar2);

  /*****************************************************************************************
     功能：修改退货下架明细信息

  *****************************************************************************************/
  procedure P_RO_UpdatedOutStockItem(strEnterPriseNo in rodata_outstock_d.enterprise_no%type,
                                     strWarehouseNo  in rodata_outstock_d.warehouse_no%type, --仓别
                                     strOutStockNo   in rodata_outstock_d.outstock_no%type, --下架单号
                                     nArticleQTY     in rodata_outstock_d.article_qty%type,
                                     nRealQty        in rodata_outstock_d.real_qty%type,
                                     strRealCellNo   in rodata_outstock_d.outstock_cell_no%type,
                                     strOwnerNo      in rodata_outstock_d.owner_no%type,
                                     nRowID          in rodata_outstock_d.Row_Id%type,
                                     strLabelNo      in rodata_outstock_d.label_no%type,
                                     strOutstockName in rodata_outstock_d.outstock_name%type, --出货员工ID
                                     strStatus       in rodata_outstock_d.status%type, --状态
                                     strOutMsg       out varchar2);


  /***************************************************************************************************88
  创建人：quzhihui
  功能说明：更新下架明细，只更新实际退货数量

  ***********************************************************************************************/
  procedure P_UpdatedRealQty(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                             strWarehouseNo  in rodata_outstock_d.warehouse_no%type, --仓别
                             strOutStockNo   in rodata_outstock_d.outstock_no%type, --下架单号
                             nArticleQTY     in rodata_outstock_d.article_qty%type,
                             nRealQty        in rodata_outstock_d.real_qty%type,
                             strRealCellNo   in rodata_outstock_d.outstock_cell_no%type,
                             strOwnerNo      in rodata_outstock_d.owner_no%type,
                             nRowId          in rodata_outstock_d.row_id%type,
                             strLabelNo      in rodata_outstock_d.label_no%type,
                             strOutstockName in rodata_outstock_d.outstock_name%type, --出货员工ID
                             strStatus       in rodata_outstock_d.status%type, --状态
                             strOutMsg       out varchar2);

  /*************************************************************************************8
  功能说明：根据写退货箱头档
  2015.7.23

  **************************************************************************************/
  procedure P_InsertRodataBoxM(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                                    strWarehouseNo in rodata_outstock_m.warehouse_no%type, --仓别
                                    strOwnerNo     in rodata_outstock_m.owner_no%type,
                                    strLabelNo     in rodata_box_m.label_no%type,
                                    strRecedeNo    in rodata_box_m.recede_no%type,
                                    strOwnerCellNo in rodata_box_m.owner_cell_no%type,
                                    strUserID      in rodata_deliver_m.rgst_name%type,
                                    strStatus      in rodata_deliver_m.status%type,
                                    strOutMsg      out varchar2);

  /*************************************************************************************8
  功能说明：根据写退货箱明细
  2015.7.23

  **************************************************************************************/
  procedure P_InsertRodataBoxItem(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                                    strWarehouseNo in rodata_outstock_m.warehouse_no%type, --仓别
                                    strOwnerNo     in rodata_outstock_m.owner_no%type,
                                    strOutstockNo  in rodata_outstock_d.outstock_no%type,
                                    strLabelNo     in rodata_box_m.label_no%type,
                                    strRecedeNo    in rodata_box_m.recede_no%type,
                                    strUserID      in rodata_deliver_m.rgst_name%type,
                                    strStatus      in rodata_deliver_m.status%type,
                                    strOutMsg      out varchar2);
  /*********************************************************************************************
  功能说明：1、新增或更新退货箱明细
         2015.8.13

  **********************************************************************************************/
  procedure P_updateInsertBoxItem(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                                    strWarehouseNo in rodata_outstock_m.warehouse_no%type, --仓别
                                    strOwnerNo     in rodata_outstock_m.owner_no%type,
                                    strOutstockNo  in rodata_outstock_d.outstock_no%type,
                                    strLabelNo     in rodata_box_m.label_no%type,
                                    strRecedeNo    in rodata_box_m.recede_no%type,
                                    nRowID         in rodata_box_d.row_id%type,
                                    strArticleNo   in rodata_box_d.article_no%type,
                                    nArticleId     in rodata_box_d.article_id%type,
                                    nPackingQty    in rodata_box_d.packing_qty%type,
                                    nPoId          in rodata_box_d.po_id%type,
                                    nRealQty       in rodata_box_d.article_qty%type,
                                    strUserID      in rodata_deliver_m.rgst_name%type,
                                    strStatus      in rodata_deliver_m.status%type,
                                    strOutMsg      out varchar2);
  /*********************************************************************************************
  功能说明：1、新增或更新退货箱明细
         2015.8.13

  **********************************************************************************************/
  procedure P_DeleteBoxHead(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                            strWarehouseNo in rodata_outstock_m.warehouse_no%type, --仓别
                            strOwnerNo     in rodata_outstock_m.owner_no%type,
                            strLabelNo     in rodata_box_m.label_no%type,
                            strOutMsg      out varchar2);

  /*********************************************************************************************
  功能说明：1、写标签整理日志
         2015.8.13

  **********************************************************************************************/
  procedure P_InsertLabelMoveLog(strEnterPriseNo in rodata_box_m.enterprise_no%type,
                            strWarehouseNo in rodata_box_m.warehouse_no%type, --仓别
                            strOwnerNo     in rodata_box_m.owner_no%type,
                            strRecedeNo    in rodata_box_m.recede_no%type,
                            strsLabelNo    in rodata_box_m.label_no%type,--来源标签
                            strdLabelNo    in rodata_box_m.label_no%type,--目的标签
                            strArticleNo   in rodata_box_d.article_no%type,
                            nPackingQty    in rodata_box_d.packing_qty%type,
                            nQty           in rodata_box_d.article_qty%type,
                            dtProduceDate  in stock_article_info.produce_date%type,
                            dtExpireDate   in stock_article_info.expire_date%type,
                            strQuality     in stock_article_info.quality%type,
                            strLotNo       in stock_article_info.lot_no%type,
                            strsCellNo     in stock_content.cell_no%type,
                            strdCellNo     in stock_content.cell_no%type,
                            strUserId      in bdef_defworker.worker_no%type,
                            strArrangeType in stock_label_arrange_log.arrange_type%type,--0：上架整理，1：过季转应季整理，2：应季转过季打包（库存录标签），3：退厂打包';
                            strOutMsg      out varchar2);

  /*数据转历史处理*/
  procedure P_RO_UpdateOutStockHistory(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                                       strWarehouseNo in rodata_outstock_m.warehouse_no%type, --仓别
                                       strOutStockNo  in rodata_outstock_m.outstock_no%type, --下架单号
                                       strOwnerNo     in rodata_outstock_m.owner_no%type,
                                       strOutMsg      out varchar2); --返回值
  --写退货清单头档
  procedure P_RO_WriteWmDeliverHead(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                                    strWarehouseNo in rodata_outstock_m.warehouse_no%type, --仓别
                                    strOwnerNo     in rodata_outstock_m.owner_no%type,
                                    strDeliverNo   in rodata_deliver_m.deliver_no%type,
                                    strUserID      in rodata_deliver_m.rgst_name%type,
                                    strStatus      in rodata_deliver_m.status%type,
                                    strOutMsg      out varchar2);

  --写退货清单明细
  procedure P_RO_WriteWmDeliverItem(strEnterPriseNo in rodata_deliver_d.enterprise_no%type,
                                    strWarehouseNo in rodata_deliver_d.warehouse_no%type, --仓别
                                    strOwnerNo     in rodata_deliver_d.owner_no%type,
                                    strDeliverNo   in rodata_deliver_d.deliver_no%type,
                                    strRECEDE_NO   in rodata_deliver_d.recede_no%type,
                                    nPO_ID         in rodata_deliver_d.po_id%type,
                                    strARTICLE_NO  in rodata_deliver_d.article_no%type,
                                    nARTICLE_ID    in rodata_deliver_d.article_id%type,
                                    nPACKING_QTY   in rodata_deliver_d.packing_qty%type,
                                    nARTICLE_QTY   in rodata_deliver_d.article_qty%type,
                                    nRealQTY       in rodata_deliver_d.real_qty%type,
                                    strCELL_NO     in rodata_deliver_d.cell_no%type,
                                    strLabelNo     in rodata_deliver_d.label_no%type,
                                    strSubLabelNo  in rodata_deliver_d.sub_label_no%type,
                                    strRECEDE_NAME in rodata_deliver_d.recede_name%type,
                                    strOutMsg      out varchar2);

  --更新退货下架明细
  /*******************************************************************************************************
  创建人：luozhiling
  创建时间：2014.11.19
  功能说明：更新退货下架明细的outstock_qty为拣货下架数量，并且更新下架单状态，用于下架完成后再扫描打包的流程
  ********************************************************************************************************/
  procedure P_RO_UpdateOutstockQty(strEnterPriseNo in rodata_outstock_d.enterprise_no%type,
                                   strWarehouseNo  in rodata_outstock_d.warehouse_no%type, --仓别
                                   strOutStockNo   in rodata_outstock_d.outstock_no%type, --下架单号
                                   nRealQty        in rodata_outstock_d.real_qty%type,
                                   strRealCellNo   in rodata_outstock_d.outstock_cell_no%type,
                                   strOwnerNo      in rodata_outstock_d.owner_no%type,
                                   nRowId          in rodata_outstock_d.row_id%type,
                                   strOutstockName in rodata_outstock_d.outstock_name%type, --出货员工ID
                                   strOutMsg       out varchar2);

   /*******************************************************************************************************
  创建人：hekl
  创建时间：2015.08.11
  功能说明：将退货标签头档转历史
  ********************************************************************************************************/
   procedure P_RO_InsertBoxMHTY(strEnterPriseNo in rodata_outstock_d.enterprise_no%type,
                               strWarehouseNo  in rodata_outstock_d.warehouse_no%type, --仓别
                               strOwnerNo      in rodata_outstock_m.owner_no%type,
                               strRecedeNo    in rodata_outstock_d.source_no%type,--退货单号
                               strUserID      in rodata_box_d.label_no%type,
                               strOutMsg       out varchar2);
   /*******************************************************************************************************
  创建人：hekl
  创建时间：2015.08.11
  功能说明：将退货标签明细转历史
  ********************************************************************************************************/
   procedure P_RO_InsertBoxDHTY(strEnterPriseNo in rodata_outstock_d.enterprise_no%type,
                                   strWarehouseNo  in rodata_outstock_d.warehouse_no%type, --仓别
                                   strRecedeNo    in rodata_outstock_d.source_no%type,--退货单号
                                   strOutMsg       out varchar2);
  /*******************************************************************************************************
  创建人：hekl
  创建时间：2015.08.11
  功能说明：将退货标签头档转历史，按标签转历史
  ********************************************************************************************************/
  procedure P_ForLabelInsertBoxMHTY(strEnterPriseNo in rodata_outstock_d.enterprise_no%type,
                               strWarehouseNo  in rodata_outstock_d.warehouse_no%type, --仓别
                               strOwnerNo      in rodata_outstock_m.owner_no%type,
                               strLableNo    in rodata_outstock_d.label_no%type,--退货单号
                               strUserID      in rodata_box_d.label_no%type,
                               strOutMsg       out varchar2);

  /*******************************************************************************************************
  创建人：hekl
  创建时间：2015.08.11
  功能说明：将退货标签明细转历史,按标签转历史
  ********************************************************************************************************/
  procedure P_ForLabelInsertBoxDHTY(strEnterPriseNo in rodata_outstock_d.enterprise_no%type,
                                   strWarehouseNo  in rodata_outstock_d.warehouse_no%type, --仓别
                                   strLabelNo    in rodata_outstock_d.label_no%type,--标签号
                                   strOutMsg       out varchar2);

  /*******************************************************************************************************
  创建人：huangb
  创建时间：2016.05.16
  功能说明：退厂单据转历史
  ********************************************************************************************************/
  procedure P_RO_InsertHTY(strEnterPriseNo in rodata_deliver_mhty.enterprise_no%type,
                           strWarehouseNo  in rodata_deliver_mhty.warehouse_no%type, --仓别
                           strOwnerNo      in rodata_deliver_mhty.owner_no%type,
                           strDeliverNo    in rodata_deliver_mhty.deliver_no%type, --预制退货单号
                           strUserID       in rodata_deliver_mhty.rgst_name%type,
                           strOutMsg       out varchar2);
end pkobj_rodata;


/

