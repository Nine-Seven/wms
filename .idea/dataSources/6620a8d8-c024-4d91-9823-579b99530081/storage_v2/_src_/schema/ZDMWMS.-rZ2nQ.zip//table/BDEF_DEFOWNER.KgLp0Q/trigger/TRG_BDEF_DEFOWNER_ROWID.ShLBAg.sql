create trigger TRG_BDEF_DEFOWNER_ROWID
    before insert or update
    on BDEF_DEFOWNER
    for each row
declare
  i_id NUMBER;
begin
  select SEQ_BDEF_DEFOWNER_ROWID.NEXTVAL into i_id from dual;
  :NEW.ROW_ID := i_id;
end TRG_BDEF_DEFOWNER_ROWID;


/

