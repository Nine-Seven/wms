create view V_SEARCH_9109_5 as
select odm.warehouse_no,
       odm.send_name,
       bdw.worker_name,
       bag.l_group_no,
       bag.l_group_name,
       bag.m_group_no,
       bag.m_group_name,
       trunc(odd.qty / odd.packing_qty) real_box,
       odm.operate_date
  from odata_deliver_m    odm,
       odata_deliver_d    odd,
       bdef_defarticle    bda,
       bdef_article_group bag,
       bdef_defworker     bdw
 where odm.deliver_no = odd.deliver_no
   and odd.article_no = bda.article_no
   and bda.group_no = bag.group_no
   and odm.send_name = bdw.worker_no


/

