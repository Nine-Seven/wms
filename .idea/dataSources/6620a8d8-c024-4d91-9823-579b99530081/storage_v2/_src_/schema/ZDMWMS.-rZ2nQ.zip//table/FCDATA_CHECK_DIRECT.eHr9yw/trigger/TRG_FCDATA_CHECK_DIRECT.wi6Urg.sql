create trigger TRG_FCDATA_CHECK_DIRECT
    before insert
    on FCDATA_CHECK_DIRECT
    for each row
declare
i_id integer;
begin
select SEQ_FCDATA_CHECK_DIRECT.nextval into i_id from dual;
:NEW.DIRECT_SERIAL := i_id;
end;


/

