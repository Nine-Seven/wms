create package body        PKOBJ_ODATA_EXPCANCEL is
  /****************************************************************************************************
   创建人：hcx
   2015.4.27
   写病单处理指示
  ******************************************************************************************************/
  procedure P_InOdataExpCancelDirect(strEnterpriseNo in odata_exp_cancel_direct.enterprise_no%type, --企业
                                     strWareHouseNo  in odata_exp_cancel_direct.warehouse_no%type, --仓别
                                     strOwnerNo      in odata_exp_cancel_direct.owner_no%type, --货主
                                     strExpNo        in odata_exp_cancel_direct.exp_no%type, --出货单号
                                     strSourceType   in odata_exp_cancel_direct.source_type%type, --病单来源
                                     strUserId       in odata_exp_cancel_direct.rgst_name%type, --操作人员
                                     strResult       out varchar2) is
    --返回结果
    v_strExpType   odata_exp_m.exp_type%type; --出货类别
    dtExpDate      odata_exp_m.exp_date%type; --定位日期
    v_strCustNo    odata_exp_m.cust_no%type; --客户编码
    v_strSubCustNo odata_exp_m.sub_cust_no%type; --子客户编码
    v_strStatus    odata_exp_m.status%type; --状态
    v_strOwnerNo   odata_exp_m.owner_no%type;
  begin

    strResult := 'N|[P_InOdataExpCancelDirect]';

    begin
      select exp_type, exp_date, cust_no, sub_cust_no, status,owner_no
        into v_strExpType,
             dtExpDate,
             v_strCustNo,
             v_strSubCustNo,
             v_strStatus,v_strOwnerNo
        from odata_exp_m t
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.exp_no = strExpNo;
    exception
      when no_data_found then
        strResult := 'N|[]'; --出货单不存在
        return;
    end;

    if v_strStatus = COdataExpStatus.CancelDierct then
      strResult := 'Y|[成功]';
      return;
    end if;

    insert into odata_exp_cancel_direct
      (enterprise_no,
       warehouse_no,
       owner_no,
       exp_type,
       exp_no,
       exp_date,
       cust_no,
       sub_cust_no,
       operate_date,
       status,
       source_type,
       rgst_name,
       rgst_date)
    values
      (strEnterpriseNo,
       strWareHouseNo,
       strOwnerNo,
       v_strExpType,
       strExpNo,
       dtExpDate,
       v_strCustNo,
       v_strSubCustNo,
       trunc(sysdate),
       '10',
       strSourceType,
       strUserId,
       sysdate);
    if sql%rowcount <= 0 then
      strResult := 'N|[E39001]'; --写入病单处理指示失败];
      return;
    end if;
    strResult := 'Y|成功';
  end P_InOdataExpCancelDirect;

  /****************************************************************************************************
   创建人：hcx
   2015.4.27
   写病单处理单头档
  ******************************************************************************************************/
  procedure P_InsertOdataExpCancelM(strEnterpriseNo in odata_exp_cancel_m.enterprise_no%type, --企业
                                    strWareHouseNo  in odata_exp_cancel_m.warehouse_no%type, --仓别
                                    strCanCelNo     in odata_exp_cancel_m.cancel_no%type, --病单单号
                                    strOwnerNo      in odata_exp_cancel_m.owner_no%type, --货主
                                    strExpNo        in odata_exp_cancel_m.exp_no%type, --出货单号
                                    strSourceType   in odata_exp_cancel_direct.source_type%type, --病单来源
                                    strUserId       in odata_exp_cancel_m.rgst_name%type, --操作人员
                                    strResult       out varchar2) is --返回结果

  begin
    strResult := 'N|[P_InsertOdataExpCancelM]';

    insert into odata_exp_cancel_m
      (enterprise_no,
       warehouse_no,
       cancel_no,
       owner_no,
       exp_type,
       exp_no,
       exp_date,
       cust_no,
       sub_cust_no,
       operate_date,
       status,
       rgst_name,
       rgst_date,
       source_type)
      select strEnterpriseNo,
             strWareHouseNo,
             strCancelNo,
             strOwnerNo,
             t.exp_type,
             strExpNo,
             t.exp_date,
             t.cust_no,
             t.sub_cust_no,
             trunc(sysdate),
             '10',
             strUserId,
             sysdate,
             strSourceType
        from odata_exp_m t
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.exp_no = strExpNo;

    if sql%rowcount <= 0 then
      strResult := 'N|[E39002]'; --写入病单处理单头档失败];
      return;
    end if;
    strResult := 'Y|成功';
  end P_InsertOdataExpCancelM;

  /****************************************************************************************************
   创建人：hcx
   2015.4.27
   写病单处理单明细
  ******************************************************************************************************/
  procedure P_InsertOdataExpCancelD(strEnterpriseNo in odata_exp_cancel_d.enterprise_no%type, --企业
                                    strWareHouseNo  in odata_exp_cancel_d.warehouse_no%type, --仓别
                                    strOwnerNo      in odata_exp_cancel_d.cancel_no%type, --货主
                                    strCanCelNo     in odata_exp_cancel_d.cancel_no%type, --病单单号
                                    strExpNo        in odata_exp_cancel_d.exp_no%type, --出货单号
                                    strSourceType   in odata_exp_cancel_direct.source_type%type, --病单来源
                                    strUserId       in odata_exp_cancel_d.rgst_name%type, --操作人员
                                    strResult       out varchar2) is --返回结果

  begin

    strResult := 'N|[P_InsertOdataExpCancelD]';

    if strSourceType = '1' then
      --定位缺量
      insert into odata_exp_cancel_d
        (enterprise_no,
         warehouse_no,
         owner_no,
         exp_type,
         cancel_no,
         operate_date,
         exp_no,
         exp_date,
         article_no,
         packing_qty,
         article_qty,
         real_qty,
         status,
         rgst_name,
         rgst_date)
        select oem.enterprise_no,
               oem.warehouse_no,
               oem.owner_no,
               oem.exp_type,
               strCanCelNo,
               trunc(sysdate),
               oem.exp_no,
               oem.exp_date,
               oed.article_no,
               oed.packing_qty,
               sum(oed.article_qty),
               sum(oed.locate_qty),
               '10',
               strUserId,
               sysdate
          from odata_exp_m oem, odata_exp_d oed
         where oem.enterprise_no = oed.enterprise_no
           and oem.warehouse_no = oed.warehouse_no
           and oem.exp_no = oed.exp_no
           and oem.enterprise_no = strEnterpriseNo
           and oem.warehouse_no = strWareHouseNo
           and oem.exp_no = strExpNo
         group by oem.enterprise_no,
                  oem.warehouse_no,
                  oem.owner_no,
                  oem.exp_type,
                  oem.exp_no,
                  oem.exp_date,
                  oed.article_no,
                  oed.packing_qty;
    end if;

    if strSourceType = '2' then
      --拣货整单缺量

      insert into odata_exp_cancel_d
        (enterprise_no,
         warehouse_no,
         owner_no,
         exp_type,
         cancel_no,
         operate_date,
         exp_no,
         exp_date,
         article_no,
         packing_qty,
         article_qty,
         real_qty,
         status,
         rgst_name,
         rgst_date)
        select a.enterprise_no,
               a.warehouse_no,
               a.owner_no,
               a.exp_type,
               strCanCelNo,
               sysdate,
               a.exp_no,
               a.exp_date,
               a.article_no,
               a.packing_qty,
               a.plan_qty,
               nvl(b.real_qty, 0),
               '10',
               strUserId,
               sysdate
          from (select oem.exp_type,
                       oem.exp_date,
                       oem.enterprise_no,
                       oem.warehouse_no,
                       oem.owner_no,
                       oem.exp_no,
                       oed.article_no,
                       oed.packing_qty,
                       sum(oed.article_qty) plan_qty
                  from odata_exp_d oed, odata_exp_m oem
                 where oem.enterprise_no = oed.enterprise_no
                   and oem.warehouse_no = oed.warehouse_no
                   and oem.exp_no = oed.exp_no
                   and oem.enterprise_no = strEnterpriseNo
                   and oem.warehouse_no = strWareHouseNo
                 group by oem.exp_type,
                          oem.exp_date,
                          oem.enterprise_no,
                          oem.warehouse_no,
                          oem.owner_no,
                          oem.exp_no,
                          oed.article_no,
                          oed.packing_qty) a,
               (select sld.exp_no,
                       sld.article_no,
                       sld.packing_qty,
                       sum(sld.qty) real_qty
                  from stock_label_d sld
                 where sld.enterprise_no = strEnterpriseNo
                   and sld.warehouse_no = strWareHouseNo
                   and sld.status <> CLabelStatus.PICK_HAND_OUT
                 group by sld.exp_no, sld.article_no, sld.packing_qty) b
         where a.article_no = b.article_no
           and a.exp_no = b.exp_no
           and a.enterprise_no = strEnterpriseNo
           and a.warehouse_no = strWareHouseNo;
    end if;

    if strSourceType = '3' then
      --复核缺量

      insert into odata_exp_cancel_d
        (enterprise_no,
         warehouse_no,
         owner_no,
         exp_type,
         cancel_no,
         operate_date,
         exp_no,
         exp_date,
         article_no,
         packing_qty,
         article_qty,
         real_qty,
         status,
         rgst_name,
         rgst_date)
        select ocm.enterprise_no,
               ocm.warehouse_no,
               ocd.owner_no,
               ocd.exp_type,
               strCanCelNo,
               trunc(sysdate),
               ocd.exp_no,
               ocd.exp_date,
               ocd.article_no,
               ocd.packing_qty,
               sum(ocd.Plan_Qty),
               sum(ocd.real_qty),
               '10',
               strUserId,
               sysdate
          from odata_check_m ocm, odata_check_d ocd
         where ocm.enterprise_no = ocd.enterprise_no
           and ocm.warehouse_no = ocd.warehouse_no
           and ocm.check_no = ocd.check_no
           and ocm.enterprise_no = strEnterpriseNo
           and ocm.warehouse_no = strWareHouseNo
           and ocd.exp_no = strExpNo
         group by ocm.enterprise_no,
                  ocm.warehouse_no,
                  ocd.owner_no,
                  ocd.exp_type,
                  ocd.exp_no,
                  ocd.exp_date,
                  ocd.article_no,
                  ocd.packing_qty;
    end if;

    if strSourceType = '4' then
      --分播缺量

      insert into odata_exp_cancel_d
        (enterprise_no,
         warehouse_no,
         owner_no,
         exp_type,
         cancel_no,
         operate_date,
         exp_no,
         exp_date,
         article_no,
         packing_qty,
         article_qty,
         real_qty,
         status,
         rgst_name,
         rgst_date)
        select ocm.enterprise_no,
               ocm.warehouse_no,
               ocd.owner_no,
               ocd.exp_type,
               strCanCelNo,
               trunc(sysdate),
               ocd.exp_no,
               ocd.exp_date,
               ocd.article_no,
               ocd.packing_qty,
               sum(ocd.article_qty),
               sum(ocd.real_qty),
               '10',
               strUserId,
               sysdate
          from odata_divide_m ocm, odata_divide_d ocd
         where ocm.enterprise_no = ocd.enterprise_no
           and ocm.warehouse_no = ocd.warehouse_no
           and ocm.divide_no = ocd.divide_no
           and ocm.enterprise_no = strEnterpriseNo
           and ocm.warehouse_no = strWareHouseNo
           and ocd.exp_no = strExpNo
         group by ocm.enterprise_no,
                  ocm.warehouse_no,
                  ocd.owner_no,
                  ocd.exp_type,
                  ocd.exp_no,
                  ocd.exp_date,
                  ocd.article_no,
                  ocd.packing_qty;
    end if;

    if sql%rowcount <= 0 then
      strResult := 'N|[E39003]'; --写入病单处理单明细失败];
      return;
    end if;
    strResult := 'Y|成功';
  end P_InsertOdataExpCancelD;

  /****************************************************************************************************
   创建人：hcx
   2015.4.27
   写病单处理标签明细
  ******************************************************************************************************/

  procedure P_InOdataExpCancelLabelItem(strEnterpriseNo in odata_exp_cancel_label_item.enterprise_no%type, --企业
                                        strWareHouseNo  in odata_exp_cancel_label_item.warehouse_no%type, --仓别
                                        strCancelNo     in odata_exp_cancel_label_item.cancel_no%type, --病单单号
                                        strExpNo        in odata_exp_cancel_label_item.exp_no%type, --出货单号
                                        strUserId       in odata_exp_cancel_label_item.rgst_name%type, --操作人员
                                        strResult       out varchar2) is --返回结果
  begin
    strResult := 'N|[P_InOdataExpCancelLabelItem]';

    --写病单标签明细
    insert into odata_exp_cancel_label_item
      (enterprise_no,
       warehouse_no,
       owner_no,
       exp_type,
       cancel_no,
       operate_date,
       exp_no,
       exp_date,
       owner_cell_no,
       article_no,
       article_id,
       packing_qty,
       label_no,
       real_qty,
       d_label_no,
       status,
       label_status,
       source_no,
       container_no,
       d_container_no,
       divide_id,
       row_id,
       rgst_name,
       rgst_date)
      select strEnterpriseNo,
             strWareHouseNo,
             sld.owner_no,
             sld.exp_type,
             strCancelNo,
             t.operate_date,
             sld.exp_no,
             sld.exp_date,
             slm.owner_cell_no,
             sld.article_no,
             sld.article_id,
             sld.packing_qty,
             slm.label_no,
             sld.qty,
             slm.label_no,
             '10',
             slm.status,
             sld.source_no,
             sld.container_no,
             sld.container_no,
             sld.divide_id,
             sld.row_id,
             strUserId,
             sysdate
        from odata_exp_cancel_d t, stock_label_d sld, stock_label_m slm
       where t.enterprise_no = slm.enterprise_no
         and t.enterprise_no = sld.enterprise_no
         and t.warehouse_no = slm.warehouse_no
         and t.warehouse_no = sld.warehouse_no
         and t.exp_no = sld.exp_no
         and sld.container_no = slm.container_no
         and t.article_no = sld.article_no
         and t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.cancel_no = strCancelNo;

    if sql%rowcount <= 0 then
      strResult := 'N|[E39004]'; --写入病单标签明细失败];
      return;
    end if;
    --更新标签明细
    update stock_label_d sld
       set sld.status    = CLabelStatus.OM_CANCEL_Lock,
           sld.updt_name = strUserId,
           sld.updt_date = sysdate
     where sld.enterprise_no = strEnterpriseNo
       and sld.warehouse_no = strWareHouseNo
       and sld.container_no in
           (select d_container_no
              from odata_exp_cancel_label_item
             where enterprise_no = strEnterpriseNo
               and warehouse_no = strWareHouseNo
               and cancel_no = strCancelNo);

    if sql%rowcount <= 0 then
      strResult := 'N|[E22701]';
      return;
    end if;

    --写标签跟踪日志
    insert into STOCK_LABEL_LOG
      (enterprise_no,
       warehouse_no,
       LABEL_NO,
       CONTAINER_NO,
       OWNER_CELL_NO,
       CONTAINER_TYPE,
       OWNER_CONTAINER_NO,
       STATUS,
       RGST_NAME,
       RGST_DATE)
      select m.enterprise_no,
             m.warehouse_no,
             m.label_no,
             m.container_no,
             m.owner_cell_no,
             m.container_type,
             m.owner_container_no,
             CLabelStatus.OM_CANCEL_Lock,
             strUserId,
             sysdate
        from STOCK_LABEL_M m
       where m.warehouse_no = strWareHouseNo
         and m.enterprise_no = strEnterpriseNo
         and m.container_no in
             (select d_container_no
                from odata_exp_cancel_label_item
               where enterprise_no = strEnterpriseNo
                 and warehouse_no = strWareHouseNo
                 and cancel_no = strCancelNo)
         and m.STATUS <> CLabelStatus.OM_CANCEL_Lock;

    if sql%rowcount <= 0 then
      strResult := 'N|[E22306]';
      return;
    end if;

    --更新标签状态头档

    update stock_label_m slm
       set slm.status    = CLabelStatus.OM_CANCEL_Lock,
           slm.updt_name = strUserId,
           slm.updt_date = sysdate
     where slm.enterprise_no = strEnterpriseNo
       and slm.warehouse_no = strWareHouseNo
       and slm.container_no in
           (select d_container_no
              from odata_exp_cancel_label_item
             where enterprise_no = strEnterpriseNo
               and warehouse_no = strWareHouseNo
               and cancel_no = strCancelNo);

    if sql%rowcount <= 0 then
      strResult := 'N|[E22116]';
      return;
    end if;

    strResult := 'Y|成功';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_InOdataExpCancelLabelItem;

  /*****************************************************************************************************************
   hcx
  20150430
  功能说明：病单处理指示表转历史
  ***************************************************************************************************************/

  procedure p_RemoveOdataExpCancelDirect(strEnterpriseNo in odata_exp_cancel_direct.Enterprise_No%type, --企业
                                         strWarehouseNo  in odata_exp_cancel_direct.Warehouse_No%type, --仓别
                                         strExpNo        in odata_exp_cancel_direct.exp_no%type, --出货单号
                                         strSourceType   in odata_exp_cancel_direct.source_type%type, --病单来源
                                         strResult       out varchar2) is --返回结果
  begin
    strResult := 'N|[p_RemoveOdataExpCancelDirect]';
    insert into odata_exp_cancel_direct_hty
      (enterprise_no,
       warehouse_no,
       owner_no,
       exp_type,
       exp_no,
       exp_date,
       cust_no,
       sub_cust_no,
       operate_date,
       status,
       source_type,
       rgst_name,
       rgst_date,
       updt_name,
       updt_date)
      select enterprise_no,
             warehouse_no,
             owner_no,
             exp_type,
             exp_no,
             exp_date,
             cust_no,
             sub_cust_no,
             operate_date,
             status,
             source_type,
             rgst_name,
             rgst_date,
             updt_name,
             updt_date
        from odata_exp_cancel_direct
       where enterprise_no = strEnterpriseNo
         and WAREHOUSE_NO = strWarehouseNo
         and exp_no = strExpNo
         and source_type = strSourceType;
    delete from odata_exp_cancel_direct
     where enterprise_no = strEnterpriseNo
       and WAREHOUSE_NO = strWarehouseNo
       and exp_no = strExpNo
       and source_type = strSourceType
       and status = '13';
    strResult := 'Y|成功';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_RemoveOdataExpCancelDirect;

  /*****************************************************************************************************************
   hekangli
  20150430
  功能说明：病单审核，病单头档明细表转历史
  ***************************************************************************************************************/
  procedure proc_RemoveCancel(strEnterpriseNo in Odata_Exp_Cancel_m.Enterprise_No%type,
                              strWarehouseNo  in ODATA_EXP_CANCEL_M.Warehouse_No%type,
                              strCancelNo     in odata_exp_cancel_m.cancel_no%type,
                              strResult       out varchar2) is

  begin
    strResult := 'N|[P_InsertOdataExpCancelM]';

    --头档转历史
    insert into ODATA_EXP_CANCEL_M_HTY
      (enterprise_no,
       WAREHOUSE_NO,
       CANCEL_NO,
       OWNER_NO,
       EXP_TYPE,
       EXP_NO,
       EXP_DATE,
       CUST_NO,
       SUB_CUST_NO,
       OPERATE_DATE,
       STATUS,
       HANDLE_FLAG,
       SEND_FLAG,
       RGST_NAME,
       RGST_DATE,
       SOURCE_TYPE,
       --huangb 20160509
       REPORT_UP_SERIAL)
      select enterprise_no,
             WAREHOUSE_NO,
             CANCEL_NO,
             OWNER_NO,
             EXP_TYPE,
             EXP_NO,
             EXP_DATE,
             CUST_NO,
             SUB_CUST_NO,
             OPERATE_DATE,
             STATUS,
             HANDLE_FLAG,
             SEND_FLAG,
             RGST_NAME,
             RGST_DATE,
             SOURCE_TYPE,
             --huangb 20160509
             REPORT_UP_SERIAL
        from odata_exp_cancel_m
       where enterprise_no = strEnterpriseNo
         and WAREHOUSE_NO = strWarehouseNo
         and CANCEL_NO = strCancelNo;

    --明细转历史
    insert into ODATA_EXP_CANCEL_D_HTY
      (enterprise_no,
       WAREHOUSE_NO,
       OWNER_NO,
       EXP_TYPE,
       CANCEL_NO,
       OPERATE_DATE,
       EXP_NO,
       EXP_DATE,
       ARTICLE_NO,
       PACKING_QTY,
       ARTICLE_QTY,
       REAL_QTY,
       STATUS,
       HANDLE_FLAG,
       RGST_NAME,
       RGST_DATE)
      select enterprise_no,
             WAREHOUSE_NO,
             OWNER_NO,
             EXP_TYPE,
             CANCEL_NO,
             OPERATE_DATE,
             EXP_NO,
             EXP_DATE,
             ARTICLE_NO,
             PACKING_QTY,
             ARTICLE_QTY,
             REAL_QTY,
             STATUS,
             HANDLE_FLAG,
             RGST_NAME,
             RGST_DATE
        from odata_exp_cancel_d
       where enterprise_no = strEnterpriseNo
         and WAREHOUSE_NO = strWarehouseNo
         and CANCEL_NO = strCancelNo;

    --删除病单通知
    delete odata_exp_cancel_m
     where enterprise_no = strEnterpriseNo
       and WAREHOUSE_NO = strWarehouseNo
       and CANCEL_NO = strCancelNo;

    delete odata_exp_cancel_d
     where enterprise_no = strEnterpriseNo
       and WAREHOUSE_NO = strWarehouseNo
       and CANCEL_NO = strCancelNo;

    strResult := 'Y|成功';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end proc_RemoveCancel;

  /*****************************************************************************************************************
  hekangli
  20150430
  功能说明：病单审核，病单标签明细转历史
  ***************************************************************************************************************/
  procedure proc_RemoveCancelLabel(strEnterpriseNo in Odata_Exp_Cancel_m.Enterprise_No%type,
                                   strWarehouseNo  in ODATA_EXP_CANCEL_M.Warehouse_No%type,
                                   strCancelNo     in odata_exp_cancel_m.cancel_no%type,
                                   strResult       out varchar2) is

  begin
    strResult := 'proc_RemoveCancelLabel';

    insert into ODATA_EXP_CANCEL_LABEL_ITEMHTY
      (enterprise_no,
       WAREHOUSE_NO,
       OWNER_NO,
       EXP_TYPE,
       CANCEL_NO,
       OPERATE_DATE,
       EXP_NO,
       EXP_DATE,
       ARTICLE_NO,
       ARTICLE_ID,
       PACKING_QTY,
       LABEL_NO,
       REAL_QTY,
       D_LABEL_NO,
       STATUS,
       SOURCE_NO,
       CONTAINER_NO,
       DIVIDE_ID,
       ROW_ID,
       RGST_NAME,
       RGST_DATE,
       OWNER_CELL_NO,
       --huangb 20160509
       REPORT_UP_SERIAL)
      select enterprise_no,
             WAREHOUSE_NO,
             OWNER_NO,
             EXP_TYPE,
             CANCEL_NO,
             OPERATE_DATE,
             EXP_NO,
             EXP_DATE,
             ARTICLE_NO,
             ARTICLE_ID,
             PACKING_QTY,
             LABEL_NO,
             REAL_QTY,
             D_LABEL_NO,
             STATUS,
             SOURCE_NO,
             CONTAINER_NO,
             DIVIDE_ID,
             ROW_ID,
             RGST_NAME,
             RGST_DATE,
             OWNER_CELL_NO,
             --huangb 20160509
             REPORT_UP_SERIAL
        from odata_exp_cancel_label_item
       where enterprise_no = strEnterpriseNo
         and WAREHOUSE_NO = strWarehouseNo
         and CANCEL_NO = strCancelNo;

    --删除病单通知
    delete odata_exp_cancel_label_item
     where enterprise_no = strEnterpriseNo
       and WAREHOUSE_NO = strWarehouseNo
       and CANCEL_NO = strCancelNo;

    strResult := 'Y|成功';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end proc_RemoveCancelLabel;
end PKOBJ_ODATA_EXPCANCEL;

/

