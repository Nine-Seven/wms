create package PKLG_FCDATA is

/**********************************************************************************************************
   luozhiling
   2013.11.16
   功能：按盘点计划成需求,一盘点计划单成一张需求单
***********************************************************************************************************/
    procedure P_Fcdata_RequestLocate(strEnterPriseNo        in    fcdata_plan_m.enterprise_no%type,
                                  strWareHouseNo            in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_plan_m.owner_no%type,
                                  strUserId               in    fcdata_plan_m.rgst_name%type,
                                  strPlanNo               in   fcdata_plan_m.plan_no%type,--盘点计划单号
                                  strRequstNo             OUT  fcdata_request_m.request_no%type,--盘点需求单号
                                  strResult               OUT    varchar2);

/**********************************************************************************************************
   MM
   2014.4.17
   功能：按需求单写盘点定位指示
***********************************************************************************************************/
    procedure P_Fcdata_LocateDirect(strEnterPriseNo         in    fcdata_plan_m.enterprise_no%type,
                                  strWareHouseNo            in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_plan_m.owner_no%type,
                                  strUserId               in    fcdata_plan_m.rgst_name%type,
                                  strRequstNo             IN   fcdata_request_m.request_no%type,--移库计划头档
                                  dtBEGIN_DATE            in   fcdata_plan_m.BEGIN_DATE%type,
                                  dtEND_DATE              in   fcdata_plan_m.END_DATE%type,
                                  strResult               OUT    varchar2);

 /*******************************************************************************************************************
  功能说明：
  1、按需求单定位；
  2、盘点切单；

 ******************************************************************************************************************/
    procedure P_LocateDirectAndCutTask(strEnterPriseNo         in    fcdata_plan_m.enterprise_no%type,
                                  strWareHouseNo            in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_plan_m.owner_no%type,
                                  strUserId               in    fcdata_plan_m.rgst_name%type,
                                  strRequstNo             IN   fcdata_request_m.request_no%type,--移库计划头档
                                  dtBEGIN_DATE            in   fcdata_plan_m.BEGIN_DATE%type,
                                  dtEND_DATE              in   fcdata_plan_m.END_DATE%type,
                                  strCutFlag              in   fcdata_check_m.fcdata_type%type,--1:按通道；2：按通道+层
                                  strResult               OUT    varchar2);
/**********************************************************************************************************
   luozhiling
   2013.11.16
   功能：按盘点计划成需求
   ***********************************************************************************************************/
   procedure P_Fcdata_RequestDirect(strEnterPriseNo         in    fcdata_plan_m.enterprise_no%type,
                                  strWareHouseNo            in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo                in    fcdata_plan_m.owner_no%type,
                                  strUserId                 in    fcdata_plan_m.rgst_name%type,
                                  strPlanNo                 in   fcdata_plan_m.plan_no%type,--盘点计划单号
                                  strRequstNo               OUT  fcdata_request_m.request_no%type,--盘点需求单号
                                  strResult                 OUT    varchar2);
/**********************************************************************************************************
   luozhiling
   2014.1.6
   功能：盘点发单
***********************************************************************************************************/
  /*  procedure P_SendTask(strWareHouseNo            in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_plan_m.owner_no%type,
                                  strUserId               in    fcdata_plan_m.rgst_name%type,--作业人
                                  strCheckNo              in   fcdata_plan_m.plan_no%type,--盘点单号
                                  strCheckType            in   fcdata_check_m.check_type%type,--1:初盘；2：复盘
                                  strDockNo               in   bset_printer_dock.dock_no%type,
                                  strResult               OUT    varchar2);*/

/**********************************************************************************************************
   luozhiling
   2014.1.6
   功能：盘点结案
***********************************************************************************************************/
    procedure P_fcdata_closePlan(strEnterPriseNo      in    fcdata_plan_m.enterprise_no%type,
                                 strWareHouseNo       in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                 strOwnerNo              in    fcdata_plan_m.owner_no%type,
                                 strPlanNo               in    fcdata_plan_m.plan_no%type,--盘点计划单号
                                 strUserId               in    fcdata_plan_m.rgst_name%type,--作业人
                                 strResult               OUT    varchar2);

/**********************************************************************************************************
   zhouhuan
   2014.4.21
   功能：  功能：盘点发单--》切单-->写盘点单头档
***********************************************************************************************************/
    procedure P_GetTask(strEnterPriseNo         in    fcdata_plan_m.enterprise_no%type,
                        strWareHouseNo          in    fcdata_plan_m.warehouse_no%type,--仓库编码
                        strOwnerNo              in    fcdata_plan_m.owner_no%type,
                        strUserId               in    fcdata_plan_m.rgst_name%type,--作业人
                        strPaperUserId          in    fcdata_plan_m.rgst_name%type,--单据人
                        strRequstNo             in   fcdata_plan_m.plan_no%type,--需求单号
                        strCutFlag              in   fcdata_check_m.fcdata_type%type,--1:按通道；2：按通道+层
                        strMoveType             in   fcdata_check_m.fcdata_type%type,--1：U型；2：W型
                        strResult               OUT    varchar2);

/**********************************************************************************************************
   zhouhuan
   2014.4.22
   功能：初盘发单
***********************************************************************************************************/
    procedure P_SendTask(strEnterPriseNo         in    fcdata_plan_m.enterprise_no%type,
                         strWareHouseNo          in    fcdata_plan_m.warehouse_no%type,--仓库编码
                         strOwnerNo              in    fcdata_plan_m.owner_no%type,
                         strUserId               in    fcdata_plan_m.rgst_name%type,--作业人
                         strCheckNo              in    fcdata_plan_m.plan_no%type,--盘点单号
                         strCheckType            in    fcdata_check_m.check_type%type,--1:初盘
                         strDockNo               in    pntset_printer_dock.dock_no%type,
                         strFcdataType           in    fcdata_check_m.fcdata_type%type,--1:盘点；2：循环盘；3：动销盘
                         strPrintType            in    fcdata_check_d.check_type%type,--1:打印报表；2：打印标签;0:不打印
                         strResult               OUT    varchar2);

/********************************************************************************************************
 功能说明：储位检查按储位实时定位
 luozhiling
 2015.10.19
********************************************************************************************************/
 procedure P_LocateCell(strEnterPriseNo          in    fcdata_plan_m.enterprise_no%type,
                       strWareHouseNo           in    fcdata_plan_m.warehouse_no%type,--仓库编码
                       strOwnerNo               in    fcdata_plan_m.owner_no%type,--货主编号
                       strCheckNo               in    fcdata_check_m.check_no%type,--盘点单号
                       strCellNo                in    fcdata_check_d.cell_no%type,
                       strUserId                in    fcdata_check_m.rgst_name%type,--盘点人
                       strResult                OUT   varchar2);

 /*********************************************************************************************************88
  功能说明：校验盘点储位或标签

 ***********************************************************************************************************/
 procedure P_CheckCellOrLabel(strEnterPriseNo         in    fcdata_plan_m.enterprise_no%type,
                              strWareHouseNo          in    fcdata_plan_m.warehouse_no%type,--仓库编码
                              strOwnerNo              in    fcdata_plan_m.owner_no%type,
                              strCheckNo              in    fcdata_plan_m.plan_no%type,--盘点单号
                              strCellNo               in    fcdata_check_d.cell_no%type,--储位,支持标签或储位
                              strOutCellNo            out   fcdata_check_d.cell_no%type,
                              strResult               OUT   varchar2);

/**********************************************************************************************************
   zhouhuan
   2014.4.22
   功能：复盘/三盘发单
***********************************************************************************************************/
    procedure P_SendTaskAgain(strEnterPriseNo         in    fcdata_plan_m.enterprise_no%type,
                              strWareHouseNo          in    fcdata_plan_m.warehouse_no%type,--仓库编码
                              strOwnerNo              in    fcdata_plan_m.owner_no%type,
                              strUserId               in    fcdata_plan_m.rgst_name%type,--作业人
                              strCheckNo              in    fcdata_plan_m.plan_no%type,--盘点单号
                              strCheckType            in    fcdata_check_m.check_type%type,--2:复盘；3：三盘
                              strDockNo               in    pntset_printer_dock.dock_no%type,
                              strFirstFlag            in    varchar2,--0=第一张单
                              strPrintType            in    fcdata_check_d.check_type%type,--1:打印报表；2：打印标签;0: 不打印
                              strCellNo               in    fcdata_check_d.cell_no%type,--储位
                              strResult               OUT   varchar2);

end PKLG_FCDATA;


/

