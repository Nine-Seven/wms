create view V_SEARCH_9106_2 as
select ism.enterprise_no,ism.WAREHOUSE_NO,ism.owner_no,ism.instock_no,
wf.text as locate_type,bda.ARTICLE_Name,isd.ARTICLE_NO,bda.OWNER_ARTICLE_NO,bda.barcode,
isd.packing_qty,sum(isd.ARTICLE_QTY) ARTICLE_QTY,sum(isd.real_qty) real_qty,trunc(sum(isd.real_qty)/isd.packing_qty) box_qty,
sum(isd.real_qty) - trunc(sum(isd.real_qty)/isd.packing_qty)*isd.packing_qty ling_ty,
0 packing_weight,0 packing_volumn,
DEST_CELL_NO,REAL_CELL_NO,cc.area_no DEST_AREA,group_no,label_NO,SOURCE_NO,ism.status statusout,isd.updt_date instock_time,
bw.worker_name instock_worker from
idata_instock_m ism ,idata_instock_d isd ,bdef_defarticle bda ,cdef_defcell  cc ,bdef_defworker bw,wms_deffieldval wf
where wf.table_name=upper('idata_instock_m')
 and wf.colname=upper('locate_type')
 and wf.value=ism.locate_type
 and  ism.enterprise_no=isd.enterprise_no and ism.warehouse_no=isd.warehouse_no
 and ism.owner_no=isd.owner_no and ism.instock_no=isd.instock_no
 and isd.enterprise_no=bda.enterprise_no and isd.owner_no=bda.owner_no
 and isd.article_no=bda.article_no
 and isd.enterprise_no=cc.enterprise_no and isd.warehouse_no=cc.warehouse_no
 and isd.cell_no=cc.cell_no
 and ism.enterprise_no=bw.enterprise_no(+) and ism.updt_name=bw.worker_no(+)
 group by  ism.enterprise_no,ism.WAREHOUSE_NO,ism.owner_no,ism.instock_no,wf.text,bda.ARTICLE_Name,isd.ARTICLE_NO,bda.OWNER_ARTICLE_NO,bda.barcode,
isd.packing_qty,DEST_CELL_NO,REAL_CELL_NO,cc.area_no ,group_no,label_NO,SOURCE_NO,ism.status ,isd.updt_date,bw.worker_name
union all
select ism.enterprise_no,ism.WAREHOUSE_NO,ism.owner_no,ism.instock_no,wf.text as locate_type,
bda.ARTICLE_Name,isd.ARTICLE_NO,bda.OWNER_ARTICLE_NO,bda.barcode,
isd.packing_qty,sum(isd.ARTICLE_QTY) ARTICLE_QTY,sum(isd.real_qty) real_qty,trunc(sum(isd.real_qty)/isd.packing_qty) box_qty,
sum(isd.real_qty) - trunc(sum(isd.real_qty)/isd.packing_qty)*isd.packing_qty ling_ty,
0 packing_weight,0 packing_volumn,
DEST_CELL_NO,REAL_CELL_NO,cc.area_no DEST_AREA,group_no,label_NO,SOURCE_NO,ism.status statusout,isd.updt_date instock_time,
bw.worker_name instock_worker from
idata_instock_mhty ism ,idata_instock_dhty isd ,bdef_defarticle bda ,cdef_defcell  cc ,bdef_defworker bw,wms_deffieldval wf
where wf.table_name=upper('idata_instock_m')
 and wf.colname=upper('locate_type')
 and wf.value=ism.locate_type
 and ism.enterprise_no=isd.enterprise_no and ism.warehouse_no=isd.warehouse_no
 and ism.owner_no=isd.owner_no and ism.instock_no=isd.instock_no
 and isd.enterprise_no=bda.enterprise_no and isd.owner_no=bda.owner_no
 and isd.article_no=bda.article_no
 and isd.enterprise_no=cc.enterprise_no and isd.warehouse_no=cc.warehouse_no
 and isd.cell_no=cc.cell_no
 and ism.enterprise_no=bw.enterprise_no and ism.updt_name=bw.worker_no
 group by  ism.enterprise_no,ism.WAREHOUSE_NO,ism.owner_no,ism.instock_no,wf.text,bda.ARTICLE_Name,isd.ARTICLE_NO,bda.OWNER_ARTICLE_NO,bda.barcode,
isd.packing_qty,DEST_CELL_NO,REAL_CELL_NO,cc.area_no ,group_no,label_NO,SOURCE_NO,ism.status ,isd.updt_date,bw.worker_name
order by enterprise_no,WAREHOUSE_NO,owner_no,instock_no,ARTICLE_NO

/

