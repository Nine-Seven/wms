create package body PKLG_MDATA is
  /***********************************************************************************************************
   创建人：luozhiling
   时间：2013.11.16
   功能：人工移库
  ***********************************************************************************************************/
  procedure P_mdata_PlanMove(strEnterPriseNo in mdata_plan_m.enterprise_no%type,
                             strWareHouseNo  in mdata_plan_m.warehouse_no%type, --仓库编码
                             strOwnerNo      in mdata_plan_m.owner_no%type,
                             strUserId       in mdata_plan_m.rgst_name%type,
                             strSouceType    in mdata_plan_m.source_type%type, --移库类型；1:商品移库；2：标签移库
                             strOutstockType in mdata_plan_m.outstock_type%type, --下架类型：3：安全量补货；4:人工移库
                             strArticleNo    in mdata_plan_d.article_no%type, --商品编码
                             nPackingQty     in mdata_plan_d.packing_qty%type,
                             dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                             dtExPireDate    in stock_article_info.expire_date%type, --到期日
                             strQUALITY      in stock_article_info.quality%type,
                             strLotNo        in stock_article_info.lot_no%type, --批次号
                             strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                             strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                             strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                             strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                             strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                             strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                             strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                             strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                             nPlanQty        in mdata_plan_d.origin_qty%type, --计划移库量
                             strStockType    in mdata_plan_d.stock_type%type,
                             strStockVAlue   in mdata_plan_d.stock_value%type,
                             strsCellNo      in mdata_plan_d.s_cell_no%type, --来源储位
                             strLabelNo      in mdata_plan_d.s_label_no%type, --来源标签号
                             strSubLabelNo   in mdata_plan_d.s_sub_label_no%type, --来源子标签号
                             strDestCellNo   in mdata_plan_d.d_cell_no%type, --目的储位
                             strsPlanNo      in mdata_plan_d.plan_no%type, --原计划单号
                             strPlanNo       out mdata_plan_m.plan_no%type, --返回的计划单号
                             strResult       OUT varchar2) is
    v_strPlanNo mdata_plan_m.plan_no%type;
  begin

    strResult := 'N|[P_mdata_PlanHead]';

    if strsPlanNo = 'N' then
      --写移库头档
      pkobj_mdata.P_mdata_PlanHead(strEnterPriseNo,
                                   strWareHouseNo,
                                   strOwnerNo,
                                   strUserId,
                                   strSouceType,
                                   strOutstockType,
                                   v_strPlanNo,
                                   strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;
      strPlanNo := v_strPlanNo;
    else
      v_strPlanNo := strsPlanNo;
      strPlanNo   := strsPlanNo;
    end if;

    --校验目的储位
    --校验目的储位
    Pkobj_stock.CheckMoveDestCell(strEnterpriseNo,
                                  strWareHouseNo,
                                  strOwnerNo,
                                  strArticleNo,
                                  dtProduceDate,
                                  dtExPireDate,
                                  '0',
                                  'N',
                                  'N',
                                  'N',
                                  'N',
                                  'N',
                                  'N',
                                  'N',
                                  'N',
                                  'N',
                                  strDestCellNo,
                                  strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    --写移库明细
    pkobj_mdata.P_mdata_PlanItem(strEnterPriseNo,
                                 strWareHouseNo,
                                 strOwnerNo,
                                 v_strPlanNo,
                                 strArticleNo,
                                 dtProduceDate,
                                 dtExPireDate,
                                 nPackingQty,
                                 strQuality,
                                 strLotNo,
                                 strRSV_BATCH1,
                                 strRSV_BATCH2,
                                 strRSV_BATCH3,
                                 strRSV_BATCH4,
                                 strRSV_BATCH5,
                                 strRSV_BATCH6,
                                 strRSV_BATCH7,
                                 strRSV_BATCH8,
                                 nPlanQty,
                                 strStockType,
                                 strStockVAlue,
                                 strsCellNo,
                                 strLabelNo,
                                 strSubLabelNo,
                                 strDestCellNo,
                                 strResult);

    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    strResult := 'Y';

  end P_mdata_PlanMove;

  /***********************************************************************************************************
   创建人：luozhiling
   时间：2014.12.15
   功能：安全量补货
  ***********************************************************************************************************/
  procedure P_mdata_HMPlanMove(strEnterPriseNo in mdata_plan_m.enterprise_no%type, --企业号
                               strWareHouseNo  in mdata_plan_m.warehouse_no%type, --仓库编码
                               strOwnerNo      in mdata_plan_m.owner_no%type,
                               strUserId       in mdata_plan_m.rgst_name%type,
                               strSouceType    in mdata_plan_m.source_type%type, --移库类型；1:商品移库；2：标签移库
                               strOutstockType in mdata_plan_m.outstock_type%type, --下架类型：3：安全量补货；4:人工移库
                               strArticleNo    in mdata_plan_d.article_no%type, --商品编码
                               nPackingQty     in mdata_plan_d.packing_qty%type,
                               nPlanQty        in mdata_plan_d.origin_qty%type, --计划移库量
                               strStockType    in mdata_plan_d.stock_type%type,
                               strStockVAlue   in mdata_plan_d.stock_value%type,
                               strDestCellNo   in mdata_plan_d.d_cell_no%type, --目的储位
                               strsPlanNo      in mdata_plan_d.plan_no%type, --原计划单号
                               strPlanNo       out mdata_plan_m.plan_no%type, --返回的计划单号
                               strResult       OUT varchar2) is
    v_strPlanNo mdata_plan_m.plan_no%type;
  begin

    strResult := 'N|[P_mdata_PlanHead]';

    if strsPlanNo = 'N' then
      --写移库头档
      pkobj_mdata.P_mdata_PlanHead(strEnterPriseNo,
                                   strWareHouseNo,
                                   strOwnerNo,
                                   strUserId,
                                   strSouceType,
                                   strOutstockType,
                                   v_strPlanNo,
                                   strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;
      strPlanNo := v_strPlanNo;
    else
      v_strPlanNo := strsPlanNo;
      strPlanNo   := strsPlanNo;
    end if;

    --写移库明细
    pkobj_mdata.P_mdata_PlanItem(strEnterPriseNo,
                                 strWareHouseNo,
                                 strOwnerNo,
                                 v_strPlanNo,
                                 strArticleNo,
                                 to_date('19000101', 'yyyymmdd'),
                                 to_date('19000101', 'yyyymmdd'),
                                 nPackingQty,
                                 '0',
                                 'N',
                                 'N',
                                 'N',
                                 'N',
                                 'N',
                                 'N',
                                 'N',
                                 'N',
                                 'N',
                                 nPlanQty,
                                 strStockType,
                                 strStockVAlue,
                                 'N',
                                 'N',
                                 'N',
                                 strDestCellNo,
                                 strResult);

    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    strResult := 'Y';

  end P_mdata_HMPlanMove;

  /******************************************************************************************
   luozhiling
   2014.12.18
   功能说明：人工移库、安全量补货写定位指示并定位
  ******************************************************************************************/
  procedure P_mdata_Locate_Main(strEnterPriseNo in mdata_plan_m.enterprise_no%type, --企业号
                                strWareHouseNo  in mdata_plan_m.warehouse_no%type, --仓库编码
                                strOwnerNo      in mdata_plan_m.owner_no%type,
                                strPlanNo       in mdata_plan_m.plan_no%type, --移库计划头档
                                strUserId       in mdata_plan_m.rgst_name%type,
                                strResult       OUT varchar2) is
    v_strOutStockType mdata_plan_m.outstock_type%type;
  begin
    strResult := 'N|[P_mdata_Locate_Main]';
    select outstock_type
      into v_strOutStockType
      from mdata_plan_m mpm
     where mpm.warehouse_no = strWareHouseNo
       and mpm.enterprise_no = strEnterPriseNo
       and mpm.plan_no = strPlanNo;

    pkobj_mdata.P_mdata_locateDiect(strEnterPriseNo,
                                    strWareHouseNo,
                                    strOwnerNo,
                                    strPlanNo,
                                    strUserId,
                                    strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    if v_strOutStockType = '4' then
      pkobj_mdata.P_mdata_foundStock(strEnterPriseNo,
                                     strWareHouseNo,
                                     strPlanNO,
                                     strUserId,
                                     strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;
    end if;

    if v_strOutStockType = '3' then
      PKLG_MLOCATE.p_securitysupply_main(strEnterPriseNo,
                                         strWareHouseNo,
                                         strOwnerNo,
                                         strPlanNO,
                                         strUserId,
                                         strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;
    end if;

    strResult := 'Y|[成功]';
  end P_mdata_Locate_Main;

  /******************************************************************************************
    quzhihui
    2013.11.20
    功能说明：人工移库发单
  ******************************************************************************************/
  --移库人工发单
  procedure p_DoManuHM(strEnterPriseNo in odata_outstock_m.enterprise_no%type,
                       strWAREHOUSE_NO in bdef_warehouse_packing.warehouse_no%type,
                       strOwner_No     in bdef_defowner.owner_no%type,
                       strOutStockType in odata_outstock_m.outstock_type%type, --下架类型4:人工移库；3：安全量补货
                       strMoveSeqType  in varchar2, --1,按来源,2-按目的,3-单一来源+单一目的
                       strPick_Worker  in bdef_defworker.worker_no%type, --预定下架人员
                       strDock_No      in bdef_defdock.dock_no%type, --码头号
                       strUserID       in bdef_defworker.worker_no%type,
                       strReportType   in odata_outstock_m.task_type%type, --打印类型,参考CONST_REPORTID中定义
                       strOutMsg       out varchar2) is
    iCount    integer := 0;
    v_sDefine wms_defbase.sdefine%type := '1';
    --v_nDefine       wms_defbase.ndefine%type := 0;
    v_PrintStatus   odata_outstock_m.print_status%type;
    strCondition    varchar2(32767);
    strOldCondition varchar2(32767);
    blCutTask       boolean;
    v_OutstockNo    odata_outstock_d.outstock_no%type;
    v_Operate_Type  odata_outstock_m.operate_type%type;
    v_Print_Type    odata_outstock_m.task_type%type;

    --打印纸单
    v_Task_Type wms_taskallot_rule.task_type%type := CONST_REPORTID.PrintPaper;
  begin
    /*      begin
        --读取系统参数
        PKLG_WMS_BASE.p_GetBasePara(strWAREHOUSE_NO,strOwner_No,'HM_NeedOutstockAndInstock','HM','ALL',
                                    v_sDefine,v_nDefine,strOutMsg);

    end;*/
    v_Print_Type := strReportType; --参考CONST_REPORTID中定义
    blCutTask    := fALSE;
    for curOutstockdirect in (select ood.*,
                                     cds.ware_no || cds.area_no S_Area_No,
                                     cdd.ware_no || cdd.area_no D_Area_No
                                from V_GETOMOUTSTOCKDIRECT1 ood
                               inner join cdef_defcell cds
                                  on ood.warehouse_no = cds.warehouse_no
                                 and ood.enterprise_no = cds.enterprise_no
                                 and ood.s_cell_no = cds.cell_no

                               inner join cdef_defcell cdd
                                  on ood.warehouse_no = cdd.warehouse_no
                                 and ood.enterprise_no = cdd.enterprise_no
                                 and ood.d_cell_no = cdd.cell_no

                               where ood.warehouse_no = strWAREHOUSE_NO
                                 and ood.enterprise_no = strEnterPriseNo
                                 and ood.owner_no = strOwner_No
                                 and ood.status = '10'
                                 and ood.outstock_type = strOutStockType
                                 and ood.source_type =
                                     Const_DEFINE.CSource_Type_COMMON
                               order by case v_sDefine
                                          when '0' then --一步上架
                                           case strMoveSeqType
                                             when MoveSeqType.Source then
                                              ood.s_cell_no || ood.exp_type ||
                                              ood.exp_no
                                             when MoveSeqType.Objective then
                                              ood.d_cell_no || ood.exp_type ||
                                              ood.exp_no
                                             when MoveSeqType.Sourceobjective then
                                              ood.s_cell_no || ood.d_cell_no ||
                                              ood.exp_type || ood.exp_no
                                           end
                                          else --上下架分开
                                           case strMoveSeqType
                                             when MoveSeqType.Source then
                                              S_Area_No || ood.exp_type ||
                                              ood.exp_no
                                             when MoveSeqType.Objective then
                                              D_Area_No || ood.exp_type ||
                                              ood.exp_no
                                             when MoveSeqType.Sourceobjective then
                                              S_Area_No || D_Area_No ||
                                              ood.exp_type || ood.exp_no
                                           end
                                        end) loop
      strOldCondition := strCondition;
      v_Operate_Type  := curOutstockdirect.Operate_Type;

      --Modify BY QZH AT 2016-5-24 PC前台发单
      if curOutstockDirect.Task_Get_Type = '0' then
        v_PrintStatus := '1';
      else
        v_PrintStatus := '0';
      end if;

      if v_sDefine = '0' then
        --一步上架
        case strMoveSeqType
          when MoveSeqType.Source then
            strCondition := curOutstockdirect.s_cell_no ||
                            curOutstockdirect.exp_type ||
                            curOutstockdirect.exp_no;
          when MoveSeqType.Objective then
            strCondition := curOutstockdirect.d_cell_no ||
                            curOutstockdirect.exp_type ||
                            curOutstockdirect.exp_no;
          when MoveSeqType.Sourceobjective then
            strCondition := curOutstockdirect.s_cell_no ||
                            curOutstockdirect.d_cell_no ||
                            curOutstockdirect.exp_type ||
                            curOutstockdirect.exp_no;
        end case;
      else
        --上下架分开
        case strMoveSeqType
          when MoveSeqType.Source then
            strCondition := curOutstockdirect.S_Area_No ||
                            curOutstockdirect.exp_type ||
                            curOutstockdirect.exp_no;
          when MoveSeqType.Objective then
            strCondition := curOutstockdirect.D_Area_No ||
                            curOutstockdirect.exp_type ||
                            curOutstockdirect.exp_no;
          when MoveSeqType.Sourceobjective then
            strCondition := curOutstockdirect.S_Area_No ||
                            curOutstockdirect.D_Area_No ||
                            curOutstockdirect.exp_type ||
                            curOutstockdirect.exp_no;
        end case;
      end if;

      if strOldCondition <> strCondition or strOldCondition is null then
        blCutTask := true;
      else
        blCutTask := false;
      end if;

      --写下架单头
      if (blCutTask) then
        if v_OutstockNo is not null then

          --更新下架指示
          pkobj_odata.P_O_UpdatedOmOutStockDirect(strEnterPriseNo,
                                                  strWAREHOUSE_NO,
                                                  v_OutstockNo,
                                                  strUserID,
                                                  strOutMsg);
          if strOutMsg <> 'Y' then
            return;
          end if;

          --任务标签
          if v_Task_Type = CONST_REPORTID.PrintTaskLabel then
            --写标签信息

            PKLG_Tasklabel.P_H_WriteLabelTask(strEnterpriseNo,
                                              strWarehouse_No,
                                              strOwner_No,
                                              v_OutstockNo,
                                              curOutstockDirect.operate_type,
                                              curOutstockDirect.source_type,
                                              curOutstockDirect.pick_type,
                                              curOutstockDirect.task_type,
                                              curOutstockDirect.print_type,
                                              curOutstockDirect.outstock_type,
                                              strUserID,
                                              strOutMsg);
            if strOutMsg <> 'Y' then
              return;
            end if;
          end if;

          if v_Print_Type = '1' then

            --写打印任务
            pklg_odata.P_WritePrintJob_Paper(strEnterPriseNo,
                                             strWAREHOUSE_NO,
                                             v_OutstockNo,
                                             strDock_No,
                                             strUserID,
                                             strOutMsg);
            if strOutMsg <> 'Y' then
              return;
            end if;
          else
            --写打印任务
            pklg_odata.P_WritePrintJob(strEnterPriseNo,
                                       strWAREHOUSE_NO,
                                       v_OutstockNo,
                                       v_Print_Type,
                                       strUserID,
                                       strOutMsg);
            if strOutMsg <> 'Y' then
              return;
            end if;
          end if;
        end if;

        --取下架单号
        PKLG_WMS_BASE.p_getsheetno(strEnterPriseNo,
                                   curOutstockDirect.Warehouse_No,
                                   CONST_DOCUMENTTYPE.MDATAHS,
                                   v_OutstockNo,
                                   strOutMsg);
        if strOutMsg <> 'Y' then
          return;
        end if;

        --写下架单头
        pkobj_odata.P_O_WriteOutStockHead(strEnterPriseNo,
                                          curOutstockdirect.Warehouse_No,
                                          curOutstockdirect.Owner_No,
                                          curOutstockdirect.wave_no,
                                          v_OutstockNo,
                                          curOutstockDirect.Pick_Type,
                                          curOutstockDirect.Batch_No,
                                          curOutstockDirect.Operate_Type,
                                          '10',
                                          strUserID,
                                          v_Print_Type,
                                          curOutstockDirect.Priority,
                                          curOutstockDirect.Exp_Date,
                                          curOutstockDirect.Outstock_Type,
                                          strDock_No,
                                          curOutstockDirect.Source_Type,
                                          curOutstockdirect.print_type,
                                          v_PrintStatus,
                                          '0',
                                          'N',
                                          strOutMsg);
        if strOutMsg <> 'Y' then
          return;
        end if;
      end if;

      --写下架明细
      PKOBJ_ODATA.P_O_WriteOutStockItem(strEnterPriseNo,
                                        curOutstockDirect.Warehouse_No,
                                        v_OutstockNo,
                                        strPick_Worker,
                                        curOutstockDirect.Direct_Serial,
                                        curOutstockDirect.Operate_Date,
                                        curOutstockdirect.pick_type,
                                        strOutMsg);
      if strOutMsg <> 'Y' then
        return;
      end if;

      iCount := iCount + 1;
    end loop;

    --更新下架指示
    pkobj_odata.P_O_UpdatedOmOutStockDirect(strEnterPriseNo,
                                            strWarehouse_No,
                                            v_OutstockNo,
                                            strUserID,
                                            strOutMsg);
    if strOutMsg <> 'Y' then
      return;
    end if;

    --

    --任务标签
    if v_Task_Type = CONST_REPORTID.PrintTaskLabel then
      --写标签信息

      PKLG_Tasklabel.P_H_WriteLabelTask(strEnterpriseNo,
                                        strWarehouse_No,
                                        strOwner_No,
                                        v_OutstockNo,
                                        'C',
                                        '1',
                                        '0',
                                        v_Task_Type,
                                        v_Print_Type,
                                        strOutStockType,
                                        strUserID,
                                        strOutMsg);
      if strOutMsg <> 'Y' then
        return;
      end if;
    end if;

    if v_Print_Type = '1' then

      --写打印任务
      pklg_odata.P_WritePrintJob_Paper(strEnterPriseNo,
                                       strWAREHOUSE_NO,
                                       v_OutstockNo,
                                       strDock_No,
                                       strUserID,
                                       strOutMsg);
      if strOutMsg <> 'Y' then
        return;
      end if;
    else
      --写打印任务
      pklg_odata.P_WritePrintJob(strEnterPriseNo,
                                 strWAREHOUSE_NO,
                                 v_OutstockNo,
                                 v_Print_Type,
                                 strUserID,
                                 strOutMsg);
      if strOutMsg <> 'Y' then
        return;
      end if;
    end if;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_DoManuHM;
  /******************************************************************************************
    huangcx
    2015.10.27
    功能说明：移库定位、发单
  ******************************************************************************************/

  procedure P_mdata_locateAndSend(strEnterPriseNo in mdata_plan_m.enterprise_no%type, --企业号
                                  strWareHouseNo  in mdata_plan_m.warehouse_no%type, --仓库编码
                                  strOwnerNo      in mdata_plan_m.owner_no%type,
                                  strPlanNo       in mdata_plan_m.plan_no%type, --移库计划头档
                                  strOutStockType in odata_outstock_m.outstock_type%type, --下架类型4:人工移库；3：安全量补货
                                  strMoveSeqType  in varchar2, --1,按来源,2-按目的,3-单一来源+单一目的
                                  strDock_No      in bdef_defdock.dock_no%type, --码头号
                                  strReportType   in odata_outstock_m.task_type%type, --打印类型,参考CONST_REPORTID中定义
                                  strUserId       in mdata_plan_m.rgst_name%type,
                                  strResult       OUT varchar2) is
    v_strCanSendFlag wms_defbase.sdefine%type;
    v_nCanSendFlag   wms_defbase.sdefine%type;
    v_count          number;
  begin
    strResult := 'N|[P_mdata_Locate_Main]';
    --移库定位
    pklg_mdata.P_mdata_Locate_Main(strEnterPriseNo,
                                   strWareHouseNo,
                                   strOwnerNo,
                                   strPlanNo,
                                   strUserId,
                                   strResult);
    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;
    --判断是否定到位
    select count(1)
      into v_count
      from mdata_locate_direct
     where owner_no = strOwnerNo
       and enterprise_no = strEnterPriseNo
       and warehouse_no = strWareHouseNo
       and plan_no = strPlanNo;
    if v_count <> 0 then
      --获取系统参数 判断是否需要建单就移库发单
      PKLG_WMS_BASE.p_GetBasePara(strEnterpriseNo,
                                  strWareHouseNo,
                                  strOwnerNo,
                                  'Mdata_Send_flag',
                                  'M',
                                  'M_Send',
                                  v_strCanSendFlag,
                                  v_nCanSendFlag,
                                  strResult);
      if substr(strResult, 1, 1) = 'N' then
        strResult := 'N|[E30025]';
        return;
      end if;

      if v_strCanSendFlag = '1' then
        --移库发单
        pklg_mdata.p_DoManuHM(strEnterPriseNo,
                              strWareHouseNo,
                              strOwnerNo,
                              strOutStockType,
                              strMoveSeqType,
                              strUserId,
                              strDock_No,
                              strUserId,
                              strReportType,
                              strResult);
        if substr(strResult, 1, 1) = 'N' then
          return;
        end if;
      end if;
    end if;

    strResult := 'Y|[成功]';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end P_mdata_locateAndSend;
  --移库表单下架回单
  procedure p_HmOutstock_Return(strEnterPriseNo   in odata_outstock_m.enterprise_no%type,
                                strWarehose_No    in bdef_warehouse_packing.warehouse_no%type,
                                strOwner_No       in bdef_defowner.owner_no%type,
                                strOutstock_No    in odata_outstock_m.outstock_no%type,
                                strArticle_No     in bdef_defarticle.article_no%type,
                                strBarcode        in bdef_defarticle.barcode%type,
                                dtProduceDate     in stock_article_info.produce_date%type,
                                dtExpireDate      in stock_article_info.expire_date%type,
                                strQUALITY        in stock_article_info.quality%type,
                                strLotNo          in stock_article_info.lot_no%type, --批次号
                                strRSV_BATCH1     in stock_article_info.rsv_batch1%type, --预留批属性1
                                strRSV_BATCH2     in stock_article_info.rsv_batch2%type, --预留批属性2
                                strRSV_BATCH3     in stock_article_info.rsv_batch3%type, --预留批属性3
                                strRSV_BATCH4     in stock_article_info.rsv_batch4%type, --预留批属性4
                                strRSV_BATCH5     in stock_article_info.rsv_batch5%type, --预留批属性5
                                strRSV_BATCH6     in stock_article_info.rsv_batch6%type, --预留批属性6
                                strRSV_BATCH7     in stock_article_info.rsv_batch7%type, --预留批属性7
                                strRSV_BATCH8     in stock_article_info.rsv_batch8%type, --预留批属性8
                                strS_Cell_No      in cdef_defcell.cell_no%type, --源储位
                                strD_Cell_No      in cdef_defcell.cell_no%type, --目的储位
                                nArticleQty       in odata_outstock_d.article_qty%type, --计划数量
                                nRealQTY          in odata_outstock_d.article_qty%type, --实际数量
                                strUserID         in bdef_defworker.worker_no%type, --操作人员ID
                                strInstockUserID  IN bdef_defworker.worker_no%type, --上架人员
                                strOutstockUserID in bdef_defworker.worker_no%type, --下架人员
                                strOutMsg         out varchar2) is
    iCount                 integer := 0;
    v_OutstockType         odata_outstock_m.outstock_type%type;
    v_TotalQTY             odata_outstock_d.article_qty%type := nRealQTY;
    v_RealQTY              odata_outstock_d.article_qty%type;
    v_strUnableDiffQtyFlag wms_defbase.sdefine%type;
    v_nUnableDiffQtyFlag   wms_defbase.ndefine%type;
  begin

    begin
      select m.outstock_type
        into v_OutstockType
        from odata_outstock_m m
       where m.outstock_no = strOutstock_No
         and m.enterprise_no = strEnterPriseNo
         and m.warehouse_no = strWarehose_No;
    exception
      when no_data_found then
        strOutMsg := 'N|[E22104]';
        return;
    end;

    --锁单头
    update odata_outstock_m m
       set m.status = m.status
     where m.warehouse_no = strWarehose_No
       and m.enterprise_no = strEnterPriseNo
          -- and m.owner_no=strOwner_No
       and m.outstock_no = strOutstock_No
       and m.status = '10';

    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E22302]';
      return;
    end if;

    if v_OutstockType = '1' then
      --出货量补货
      if nArticleQty <> nRealQTY then
        strOutMsg := 'N|[出货量补货回单不允许修改数量]';
        return;
      end if;
    end if;

    if v_OutstockType = '3' then
      --获取系统参数 判断是出货量补货是否允许修改数量
      PKLG_WMS_BASE.p_GetBasePara(strEnterPriseNo,
                                  strWarehose_No,
                                  strOwner_No,
                                  'UnableDiffQtyToHM',
                                  'M',
                                  'M_OUTSTOCK',
                                  v_strUnableDiffQtyFlag,
                                  v_nUnableDiffQtyFlag,
                                  strOutMsg);
      if substr(strOutMsg, 1, 1) = 'N' then
        strOutMsg := 'N|[E30025]';
        return;
      end if;

      if v_strUnableDiffQtyFlag = '0' and nArticleQty <> nRealQty then
        strOutMsg := 'N|[安全量补货回单不允许修改数量]';
        return;
      end if;
    end if;

    for curOutstockInfo in (select d.*
                              from odata_outstock_d   d,
                                   stock_article_info sai
                             where d.warehouse_no = strWarehose_No
                               and d.enterprise_no = strEnterPriseNo
                               and d.outstock_no = strOutstock_No
                               and d.owner_no = strOwner_No
                               and d.article_no = strArticle_No
                               and d.s_cell_no = strS_Cell_No
                               and d.d_cell_no = strD_Cell_No
                               and d.status = '10'
                               and d.enterprise_no = sai.enterprise_no
                               and d.article_no = sai.article_no
                               and d.article_id = sai.article_id
                               and sai.produce_date = dtProduceDate
                               and sai.expire_date = dtExpireDate
                               and sai.quality = strQUALITY --add by huangcx 20160725
                               and sai.lot_no = strLotNo
                               and sai.barcode = strBarcode
                               and sai.rsv_batch1 = strRSV_BATCH1
                               and sai.rsv_batch2 = strRSV_BATCH2
                               and sai.rsv_batch3 = strRSV_BATCH3
                               and sai.rsv_batch4 = strRSV_BATCH4
                               and sai.rsv_batch5 = strRSV_BATCH5
                               and sai.rsv_batch6 = strRSV_BATCH6
                               and sai.rsv_batch7 = strRSV_BATCH7
                               and sai.rsv_batch8 = strRSV_BATCH8) loop

      if v_TotalQTY >= curOutstockInfo.Article_Qty then
        v_RealQTY := curOutstockInfo.Article_Qty;
      else
        v_RealQTY := v_TotalQTY;
      end if;

      v_TotalQTY := v_TotalQTY - v_RealQTY;

      --更新下架明细
      PKOBJ_ODATA_LICH.P_Update_Odata_OutStock_D(strEnterPriseNo,
                                                 strWarehose_No,
                                                 strOutstock_No,
                                                 v_RealQTY,
                                                 curOutstockInfo.d_Container_No,
                                                 curOutstockInfo.Owner_No,
                                                 curOutstockInfo.Divide_Id,
                                                 strOutstockUserID,
                                                 strInstockUserID,
                                                 '13',
                                                 strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --更新库存
      PKOBJ_STOCK.proc_OM_Receipt_WriteContent(strEnterPriseNo,
                                               strWarehose_No,
                                               curOutstockInfo.s_Cell_Id,
                                               curOutstockInfo.s_Cell_No,
                                               curOutstockInfo.d_Cell_Id,
                                               curOutstockInfo.d_Cell_No,
                                               v_RealQTY,
                                               curOutstockInfo.Article_Qty,
                                               strOutstock_No,
                                               '1',
                                               strInstockUserID,
                                               strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      if v_TotalQTY = 0 then
        exit;
      end if;
    end loop;

    --判断目的储位是否
    PKOBJ_STOCK.P_InsertOwnerCell(strEnterpriseNo,
                                  strWarehose_No,
                                  strOwner_No,
                                  strD_Cell_No,
                                  strArticle_No,
                                  strOutMsg);
    if substr(strOutMsg, 1, 1) = 'N' then
      return;
    end if;

    --更新下架头
    select count(1)
      into iCount
      from odata_outstock_d d
     where d.status = '10'
       and d.outstock_no = strOutstock_No
       and d.enterprise_no = strEnterPriseNo
       and d.warehouse_no = strWarehose_No;

    if iCount <= 0 then
      --更新下架单头
      PKOBJ_ODATA_LICH.P_Update_Odata_OutStock_M(strEnterPriseNo,
                                                 strWarehose_No,
                                                 strOutstock_No,
                                                 strUserID,
                                                 strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      P_ChangeQualityOrg(strEnterPriseNo,
                         strWarehose_No,
                         strOutstock_No,
                         strUserID,
                         strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --转历史
      PKOBJ_ODATA_LICH.P_Update_Odata_OutStock_Hty(strEnterPriseNo,
                                                   strWarehose_No,
                                                   strOutstock_No,
                                                   strUserID,
                                                   '0',
                                                   strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
    end if;

    --触发补货指示
    pkobj_odata.P_O_CheckStatusCanOutstock(strEnterPriseNo,
                                           strWarehose_No,
                                           strOwner_No,
                                           strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;


    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_HmOutstock_Return;

  /**********************************************************************************************8
  lich
  20140711
  功能说明：标签移库回单
  ***********************************************************************************************/
  procedure P_TaskLabel_Outstock_Move(strEnterPriseNo in odata_outstock_m.enterprise_no%type,
                                      strWarehose_No  in odata_outstock_m.warehouse_no%type, --仓别
                                      strOutstock_No  in odata_outstock_m.outstock_no%type, --下架单号
                                      strFixLabel_No  in odata_outstock_d.label_no%type, --标签号码
                                      strArticle_No   in odata_outstock_d.article_no%type, --商品编码
                                      nPacking_QTY    in odata_outstock_d.packing_qty%type, --包装数量
                                      strSCell_No     in odata_outstock_d.s_cell_no%type, --来源储位
                                      nArticleQty     in odata_outstock_d.article_qty%type, --计划数量
                                      nReal_QTY       in odata_outstock_d.article_qty%type, --下架数量
                                      strQuality      in idata_check_d.quality%type, --品质
                                      dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                                      dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                                      strLotNo        in stock_article_info.lot_no%type, --批次号
                                      strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                                      strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                                      strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                                      strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                                      strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                                      strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                                      strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                                      strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                                      strDock_No      in odata_outstock_m.dock_no%type, --工作站
                                      strUserID       in odata_outstock_m.rgst_name%type, --回单人
                                      strOutstock_ID  in odata_outstock_d.outstock_name%type, --下架人
                                      strInstock_ID   in odata_outstock_d.instock_name%type, --上架人
                                      strOutMsg       out varchar2) is

    v_strPickType          odata_outstock_m.pick_type%type := 'N';
    v_strWaveNo            odata_outstock_d.wave_no%type := 'N';
    v_refContainerNO       stock_label_m.container_no%type := 'N';
    v_TotalQTY             odata_outstock_d.real_qty%type := nReal_QTY;
    v_RealQTY              odata_outstock_d.real_qty%type := 0;
    v_Count                integer := 0;
    v_strOwnerNo           bdef_defowner.owner_no%type;
    v_strOutstockType      odata_outstock_m.outstock_type%type;
    v_strUnableDiffQtyFlag wms_defbase.sdefine%type;
    v_nUnableDiffQtyFlag   wms_defbase.ndefine%type;

    cursor v_GetOutstockItem is
      select m.outstock_type,
             m.operate_type,
             m.source_type,
             m.pick_type,
             m.task_type,
             d.*
        from odata_outstock_d d, odata_outstock_m m, stock_article_info sai
       where m.warehouse_no = d.warehouse_no
         and m.enterprise_no = d.enterprise_no
         and m.enterprise_no = sai.enterprise_no
         and m.enterprise_no = strEnterPriseNo
         and m.outstock_no = d.outstock_no
         and d.article_no = sai.article_no
         and d.article_id = sai.article_id
         and d.warehouse_no = strWarehose_No
         and d.outstock_no = strOutstock_No
         and d.article_no = strArticle_No
         and d.packing_qty = nPacking_QTY
         and d.s_cell_no = strSCell_No
         and sai.produce_date = dtProduceDate
         and sai.expire_date = dtExpireDate
         and sai.lot_no = strLotNo
         and sai.rsv_batch1 = strRSV_BATCH1
         and sai.rsv_batch2 = strRSV_BATCH2
         and sai.rsv_batch3 = strRSV_BATCH3
         and sai.rsv_batch4 = strRSV_BATCH4
         and sai.rsv_batch5 = strRSV_BATCH5
         and sai.rsv_batch6 = strRSV_BATCH6
         and sai.rsv_batch7 = strRSV_BATCH7
         and sai.rsv_batch8 = strRSV_BATCH8
         and d.status = '10'
         and m.status = '10';

  begin
    strOutMsg := 'N|[P_TaskLabel_Outstock_Move]';

    select distinct m.pick_type, d.wave_no, m.outstock_type, m.owner_no
      into v_strPickType, v_strWaveNo, v_strOutstockType, v_strOwnerNo
      from odata_outstock_m m, odata_outstock_d d
     where m.warehouse_no = d.warehouse_no
       and m.enterprise_no = d.enterprise_no
       and m.enterprise_no = strEnterPriseNo
       and m.outstock_no = d.outstock_no
       and m.warehouse_no = strWarehose_No
       and m.outstock_no = strOutstock_No
       and m.status < '13';

    if v_strOutstockType = '1' then
      --出货量补货
      if nArticleQty <> nReal_QTY then
        strOutMsg := 'N|[出货量补货回单不允许修改数量]';
        return;
      end if;
    end if;

    if v_strOutstockType = '3' then
      --获取系统参数 判断是出货量补货是否允许修改数量
      PKLG_WMS_BASE.p_GetBasePara(strEnterPriseNo,
                                  strWarehose_No,
                                  v_strOwnerNo,
                                  'UnableDiffQtyToHM',
                                  'M',
                                  'M_OUTSTOCK',
                                  v_strUnableDiffQtyFlag,
                                  v_nUnableDiffQtyFlag,
                                  strOutMsg);
      if substr(strOutMsg, 1, 1) = 'N' then
        strOutMsg := 'N|[E30025]';
        return;
      end if;

      if v_strUnableDiffQtyFlag = '0' and nArticleQty <> nReal_Qty then
        strOutMsg := 'N|[安全量补货回单不允许修改数量]';
        return;
      end if;
    end if;

    if sql%rowcount <= 0 then
      return;
    end if;

    for curOutstockInfo in v_GetOutstockItem loop
      v_Count := v_Count + 1;
      if v_TotalQTY >= curOutstockInfo.Article_Qty then
        v_RealQTY := curOutstockInfo.Article_Qty;
      else
        v_RealQTY := v_TotalQTY;
      end if;

      v_TotalQTY := v_TotalQTY - v_RealQTY;

      begin
        select slm.container_no
          into v_refContainerNO
          from stock_label_m slm
         where slm.warehouse_no = strWarehose_No
           and slm.enterprise_no = strEnterPriseNo
           and slm.label_no = strFixLabel_No;
      exception
        when no_data_found then
          strOutMsg := 'N|[E22114]'; --获取容器号信息失败
          return;
      end;

      --更新下架明细
      PKOBJ_ODATA_LICH.P_Update_Odata_OutStock_D(strEnterPriseNo,
                                                 strWarehose_No,
                                                 strOutstock_No,
                                                 v_RealQTY,
                                                 v_refContainerNO,
                                                 curOutstockInfo.Owner_No,
                                                 curOutstockInfo.Divide_Id,
                                                 strOutstock_ID,
                                                 strInstock_ID,
                                                 '13',
                                                 strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --更新库存
      PKOBJ_STOCK.proc_OM_Receipt_WriteContent(strEnterPriseNo,
                                               strWarehose_No,
                                               curOutstockInfo.s_Cell_Id,
                                               curOutstockInfo.s_Cell_No,
                                               curOutstockInfo.d_Cell_Id,
                                               curOutstockInfo.d_Cell_No,
                                               v_RealQTY,
                                               curOutstockInfo.Article_Qty,
                                               strOutstock_No,
                                               '1',
                                               strOutstock_ID,
                                               strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
      --更新标签
      PKOBJ_LABEL.P_Updt_OutStock_Label(strEnterPriseNo,
                                        strWarehose_No,
                                        curOutstockInfo.Owner_No,
                                        strOutstock_No,
                                        strFixLabel_No,
                                        v_RealQTY,
                                        curOutstockInfo.d_Cell_No,
                                        curOutstockInfo.divide_id,
                                        strOutstock_ID,
                                        strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --判断目的储位是否
      PKOBJ_STOCK.P_InsertOwnerCell(strEnterpriseNo,
                                    strWarehose_No,
                                    curOutstockInfo.owner_no,
                                    curOutstockInfo.d_cell_no,
                                    strArticle_No,
                                    strOutMsg);
      if substr(strOutMsg, 1, 1) = 'N' then
        return;
      end if;

      if v_TotalQTY = 0 then
        exit;
      end if;

    end loop;

    if v_Count = 0 then
      strOutMsg := 'N|[E22117]';
      return;
    end if;

    select count(1)
      into v_Count
      from odata_outstock_d d
     where d.status = '10'
       and d.outstock_no = strOutstock_No
       and d.enterprise_no = strEnterPriseNo
       and d.warehouse_no = strWarehose_No;

    if v_Count <= 0 then
      --更新下架单头
      PKOBJ_ODATA_LICH.P_Update_Odata_OutStock_M(strEnterPriseNo,
                                                 strWarehose_No,
                                                 strOutstock_No,
                                                 strUserID,
                                                 strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      P_ChangeQualityOrg(strEnterPriseNo,
                         strWarehose_No,
                         strOutstock_No,
                         strUserID,
                         strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --转历史
      PKOBJ_ODATA.P_O_UpdateOmOutStockHistory(strEnterPriseNo,
                                              strWarehose_No,
                                              strOutstock_No,
                                              strUserID,
                                              '0',
                                              strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
    end if;

    --触发补货指示
    pkobj_odata.P_O_CheckStatusCanOutstock(strEnterPriseNo,
                                           strWarehose_No,
                                           v_strOwnerNo,
                                           strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_TaskLabel_Outstock_Move;
  /***************************************************************************************************************
  功能说明：获取及时移库建议储位
  创建人:wyf
  创建时间：2015.07.25
  ***************************************************************************************************************/
  procedure proc_HM_MoveCell_GetDCellNo(strEnterPriseNo in stock_content.enterprise_no%type,
                                        strWarehouseNo  in stock_content.warehouse_no%type,
                                        strArticleNo    in stock_content.article_no%type,
                                        strSCellNo      in stock_content.cell_no%type,
                                        strLabelNo      in stock_content.label_no%type,
                                        nPackingQty     in stock_content.packing_qty%type,
                                        nMoveQty        in stock_content.qty%type,
                                        dtProduceDate   in varchar2, --stock_article_info.produce_date%type,
                                        dtExpireDate    in varchar2, --stock_article_info.expire_date%type,
                                        strQUALITY      in stock_article_info.quality%type,
                                        strLotNo        in stock_article_info.lot_no%type, --批次号
                                        strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                                        strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                                        strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                                        strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                                        strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                                        strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                                        strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                                        strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                                        strAreaUseType  in cdef_defarea.area_usetype%type, --指定目的区域类型0：不指定，1：普通区，3：退货区，5：异常区
                                        strDCellNo      out stock_content.cell_no%type,
                                        strOutMsg       out varchar2) is

    v_strOwnerNo   stock_content.owner_no%type;
    v_strTmpCellNo stock_content.cell_no%type;
    v_nQty         stock_content.qty%type;
    v_nMaxQty      cset_cell_article.max_qty_a%type;
    v_nQpalette    bdef_article_packing.qpalette%type;

    v_nStep           integer := 0;
    v_ntmpStep        integer := 0;
    v_strSAreaUseType cdef_defarea.area_usetype%type;
    v_strWareNo       cdef_defarea.ware_no%type;
    --找库存 动态游标
    TYPE ref_cursor_type IS REF CURSOR;
    v_getStock ref_cursor_type;

    v_strSql       varchar2(6000); --找储位SQL
    v_strCommand   varchar2(5000); --主命令
    v_strCondition varchar2(1000); --条件
    v_strOrderBy   varchar2(100); --排序
    v_strGroup     varchar2(100); --分组

    v_nCount integer;
  begin
    strOutMsg := 'N|[proc_HM_MoveCell_GetDCellNo]';
    --获取货主信息
    select owner_no
      into v_strOwnerNo
      from bdef_defarticle
     where article_no = strArticleNo
       and enterprise_no = strEnterPriseNo;

    if strAreaUseType = '0' then
      select cda.area_usetype, cda.ware_no
        into v_strSAreaUseType, v_strWareNo
        from cdef_defarea cda, cdef_defcell cdc
       where cda.enterprise_no = cdc.enterprise_no
         and cda.warehouse_no = cdc.warehouse_no
         and cda.ware_no = cdc.ware_no
         and cda.area_no = cdc.area_no
         and cda.enterprise_no = strEnterPriseNo
         and cda.warehouse_no = strWarehouseNo
         and cdc.cell_no = strSCellNo;
    else
      v_strSAreaUseType := strAreaUseType;
    end if;
    v_strCommand := 'select sc.cell_no,sum(sc.qty+sc.instock_qty-sc.outstock_qty) sum_qty from stock_content sc ' ||
                    ' inner join stock_article_info sai  on sc.Article_no = sai.Article_no and sc.Article_id = sai.Article_id  and sc.enterprise_no = sai.enterprise_no ' ||
                    ' inner join cdef_defcell cdc on cdc.enterprise_no=sc.enterprise_no and cdc.warehouse_no=sc.warehouse_no and cdc.cell_no=sc.cell_no ' ||
                    ' inner join cdef_defarea cda on cda.enterprise_no=cdc.enterprise_no and cda.warehouse_no=cdc.warehouse_no and cda.area_no=cdc.area_no and cda.ware_no=cdc.ware_no  ' ||
                    ' inner join bdef_defarticle bda on sc.enterprise_no=bda.enterprise_no and sc.article_no=bda.article_no and sc.owner_no=bda.owner_no ' ||
                    ' where cdc.cell_status = ''0'' and sc.warehouse_no = ''' ||
                    strWarehouseNo || ''' and sc.enterprise_no = ''' ||
                    strEnterPriseNo || ''' and sc.owner_no = ''' ||
                    v_strOwnerNo || ''' and sc.cell_no <> ''' || strSCellNo ||
                    ''' and cda.ware_no = ''' || v_strWareNo || '''';
    /*select sc.cell_no,sum(sc.qty) sum_qty from stock_content sc
    inner join stock_article_info sai on sc.Article_no = sai.Article_no
      and sc.Article_id = sai.Article_id  and sc.enterprise_no = sai.enterprise_no
    inner join cdef_defcell cdc  on cdc.enterprise_no = sc.enterprise_no
      and cdc.warehouse_no = sc.warehouse_no  and cdc.cell_no = sc.cell_no
    inner join cdef_defarea cda
       on cda.enterprise_no = cdc.enterprise_no  and cda.warehouse_no = cdc.warehouse_no
      and cda.area_no = cdc.area_no and cda.ware_no=cdc.ware_no
    inner join bdef_defarticle bda on sc.enterprise_no=bda.enterprise_no and sc.article_no=bda.article_no and sc.owner_no=bda.owner_no
    where sc.warehouse_no = strWarehouseNo  and sc.enterprise_no = strEnterPriseNo
      and sc.article_no = strArticleNo  and sc.cell_no <> strsCellNo
      and sai.produce_date = dtProduceDate  and sai.expire_date = dtExpireDate
      and sai.quality = strQUALITY  and sai.rsv_batch1 = strRSV_BATCH1
      and sai.rsv_batch2 = strRSV_BATCH2  and sai.rsv_batch3 = strRSV_BATCH3
      and sai.rsv_batch4 = strRSV_BATCH4  and sai.rsv_batch5 = strRSV_BATCH5
      and sai.rsv_batch6 = strRSV_BATCH6  and sai.rsv_batch7 = strRSV_BATCH7
      and sai.rsv_batch8 = strRSV_BATCH8  and sai.lot_no = strLotNo
      and sc.label_no = strLabelNo  and sc.packing_qty = nPackingQty
      and cda.area_usetype='3' and cda.area_attribute='0' and cdc.mix_flag = '1'
      and (exists (select 1 from cset_cell_article c where sc.enterprise_no=c.enterprise_no and sc.warehouse_no=c.warehouse_no and sc.owner_no=c.owner_no and sc.article_no=c.article_no)
      or exists (select 1 from cset_cell_article c where sc.enterprise_no=c.enterprise_no and sc.warehouse_no = c.warehouse_no and sc.owner_no = c.owner_no and cda.ware_no=c.ware_no and cda.area_no=c.area_no)
      or exists (select 1 from cset_cell_article c where sc.enterprise_no=c.enterprise_no and sc.warehouse_no = c.warehouse_no and sc.owner_no = c.owner_no and cda.ware_no=c.ware_no and cda.area_no=c.area_no and cdc.stock_no=c.stock_no))
      and exists (select 1 from bdef_defarticle a where a.enterprise_no=sc.enterprise_no and a.owner_no=c.enterprise_no and a.supplier_no=bda.supplier_no)
      order by sc.cell_no,sum(sc.qty)
      group by sc.cell_no ;*/
    if v_strSAreaUseType = '1' then
      --普通区
      v_strCommand := v_strCommand ||
                      ' and cda.area_usetype=''1'' and cda.area_attribute=''0''';
      v_nStep      := 0;
    elsif v_strSAreaUseType = '3' then
      --退货区
      v_strCommand := v_strCommand ||
                      ' and cda.area_usetype=''3'' and cda.area_attribute=''0''';
      v_nStep      := 1;
      v_ntmpStep   := 1;
    elsif v_strSAreaUseType = '5' then
      --异常区
      v_strCommand := v_strCommand ||
                      ' and cda.area_usetype=''1'' and cda.area_attribute=''0''';
      v_nStep      := 0;
    end if;

    <<RESTART>>
    NULL;
    if v_nStep = 0 then
      --找拣货位
      /*v_strCondition := ' and (exists (select 1 from cset_cell_article c where sc.enterprise_no=c.enterprise_no and sc.warehouse_no=c.warehouse_no and sc.owner_no=c.owner_no and sc.article_no=c.article_no) ' ||
      ' or exists (select 1 from cset_cell_article c where sc.enterprise_no=c.enterprise_no and sc.warehouse_no = c.warehouse_no and sc.owner_no = c.owner_no and cda.ware_no=c.ware_no and cda.area_no=c.area_no) ' ||
      ' or exists (select 1 from cset_cell_article c where sc.enterprise_no=c.enterprise_no and sc.warehouse_no = c.warehouse_no and sc.owner_no = c.owner_no and cda.ware_no=c.ware_no and cda.area_no=c.area_no and cdc.stock_no=c.stock_no))';*/
      v_strCondition := ' and sc.article_no = ''' || strArticleNo || '''';
      v_strCondition := v_strCondition || ' and cda.area_pick=''1''';
    elsif v_nStep = 1 then
      --找商品属性相同的储位
      v_strCondition := ' and trunc(sai.produce_date) = trunc(date''' ||
                        dtProduceDate ||
                        ''') and trunc(sai.expire_date) = trunc(date''' ||
                        dtExpireDate || ''') and sai.quality = ''' ||
                        strQUALITY || ''' and sai.rsv_batch1 = ''' ||
                        strRSV_BATCH1 || ''' and sai.rsv_batch2 = ''' ||
                        strRSV_BATCH2 || ''' and sai.rsv_batch3 = ''' ||
                        strRSV_BATCH3 || ''' and sai.rsv_batch4 = ''' ||
                        strRSV_BATCH4 || ''' and sai.rsv_batch5 = ''' ||
                        strRSV_BATCH5 || ''' and sai.rsv_batch6 = ''' ||
                        strRSV_BATCH6 || ''' and sai.rsv_batch7 = ''' ||
                        strRSV_BATCH7 || ''' and sai.rsv_batch8 = ''' ||
                        strRSV_BATCH8 || ''' and sai.lot_no = ''' ||
                        strLotNo || ''' and sc.article_no = ''' ||
                        strArticleNo || ''' and sc.label_no = ''' ||
                        strLabelNo || ''' and sc.packing_qty =  ' ||
                        nPackingQty;
      if v_strSAreaUseType = '1' then
        --普通区保管位
        v_strCondition := v_strCondition || ' and cda.area_pick=''0''';
      end if;
    elsif v_nStep = 2 then
      --找不同属性可混储位
      v_strCondition := ' and sc.article_no = ''' || strArticleNo ||
                        ''' and cdc.mix_flag=''1''';
      if v_strSAreaUseType = '1' then
        --普通区保管位
        v_strCondition := v_strCondition || ' and cda.area_pick=''0''';
      end if;
    elsif v_nStep = 3 then
      --退货区商品可进行第三步 找相同供应商可混储位
      v_strCondition := ' and sc.article_no <> ''' || strArticleNo ||
                        ''' and cdc.mix_flag=''2''' ||
                        ' and exists (select 1 from bdef_defarticle a where a.enterprise_no=sc.enterprise_no and a.owner_no=sc.owner_no and a.supplier_no=bda.supplier_no)';

    end if;

    v_strOrderBy := ' order by sc.cell_no,sum(sc.qty+sc.instock_qty-sc.outstock_qty)  ';
    v_strGroup   := ' group by sc.cell_no';

    v_strSql := null;
    v_strSql := v_strCommand || v_strCondition || v_strGroup ||
                v_strOrderBy;

    begin
      --取拣货位最大量
      select distinct c.max_qty_a
        into v_nMaxQty
        from cset_cell_article c
      /*join stock_content cc
       on c.warehouse_no = cc.warehouse_no
      and c.enterprise_no = cc.enterprise_no
      and c.owner_no = cc.owner_no
      and c.article_no = cc.article_no*/
      --预留商品群组关联拣货位
       where c.enterprise_no = strEnterPriseNo
         and c.warehouse_no = strWarehouseNo
         and c.owner_no = v_strOwnerNo
         and c.article_no = strArticleNo
         AND rownum = 1;
    exception
      when no_data_found then
        v_nMaxQty := 0;
    end;

    begin
      --获取商品堆叠
      select nvl(b.qpalette, a.qpalette) Qpalette
        into v_nQpalette
        from bdef_article_packing a
        left join bdef_warehouse_packing b
          on b.enterprise_no = a.enterprise_no
         and a.article_no = b.article_no
         and a.packing_qty = b.packing_qty
         AND b.warehouse_no = strWarehouseNo
       where a.enterprise_no = strEnterPriseNo
         and a.article_no = strArticleNo
         AND a.packing_qty = nPackingQty;
    exception
      when no_data_found then
        v_nQpalette := 999 * 999;
    end;
    open v_getStock for v_strSql;
    loop
      fetch v_getStock
        into v_strTmpCellNo, v_nQty;
      exit when v_getStock%notfound;
      --检验数量
      if v_nStep = 0 then
        --拣货位检查可入数量
        if v_nMaxQty - v_nQty > nMoveQty then
          strDCellNo := v_strTmpCellNo;
          exit;
        end if;
      elsif v_nStep = 1 then
        --非拣货位
        if v_strSAreaUseType = '1' then
          if v_nQpalette - v_nQty > nMoveQty then
            strDCellNo := v_strTmpCellNo;
            exit;
          end if;
        elsif v_strSAreaUseType = '2' then
          strDCellNo := v_strTmpCellNo;
          exit;
        end if;
      elsif v_nStep = 2 then
        if v_nQpalette - v_nQty > nMoveQty then
          strDCellNo := v_strTmpCellNo;
          exit;
        end if;
      elsif v_nStep = 3 then
        strDCellNo := v_strTmpCellNo;
        exit;
      end if;
    end loop;
    close v_getStock;

    if v_nStep = 0 and strDCellNo is null then
      --拣货区找不到储位找商品拣货位
      --拣货位个数
      select count(1)
        into v_nCount
        from cset_cell_article c
       where c.enterprise_no = strEnterPriseNo
         and c.warehouse_no = strWarehouseNo
         and c.owner_no = v_strOwnerNo
         and c.article_no = strArticleNo;
      if v_nCount = 0 then
        v_strTmpCellNo := null;
      elsif v_nCount = 1 then
        select c.cell_no
          into v_strTmpCellNo
          from cset_cell_article c
         where c.enterprise_no = strEnterPriseNo
           and c.warehouse_no = strWarehouseNo
           and c.owner_no = v_strOwnerNo
           and c.article_no = strArticleNo;
        strDCellNo := v_strTmpCellNo;
      else
        --多个拣货位取箱拣货位,取不到找零散拣货位
        begin
          select c.cell_no
            into v_strTmpCellNo
            from cset_cell_article c
           where c.enterprise_no = strEnterPriseNo
             and c.warehouse_no = strWarehouseNo
             and c.owner_no = v_strOwnerNo
             and c.article_no = strArticleNo
             and c.pick_type = 'C';
        exception
          when no_data_found then
            select c.cell_no
              into v_strTmpCellNo
              from cset_cell_article c
             where c.enterprise_no = strEnterPriseNo
               and c.warehouse_no = strWarehouseNo
               and c.owner_no = v_strOwnerNo
               and c.article_no = strArticleNo
               and c.pick_type = 'B';
        end;
        strDCellNo := v_strTmpCellNo;
      end if;
      /*      begin
        select c.cell_no
          into v_strTmpCellNo
          from cset_cell_article c
         where c.enterprise_no = strEnterPriseNo
           and c.warehouse_no = strWarehouseNo
           and c.owner_no = v_strOwnerNo
           and c.article_no = strArticleNo;
        strDCellNo := v_strTmpCellNo;
      exception
        when no_data_found then
          v_strTmpCellNo := null;
      end;*/
    end if;
    if strDCellNo is null then
      v_nStep := v_nStep + 1;
      if v_nStep < 3 or (v_strSAreaUseType <> '3' and v_nStep < 2) then
        v_ntmpStep := v_nStep;
        goto RESTART;
      else
        strDCellNo := 'N';
      end if;
    end if;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end proc_HM_MoveCell_GetDCellNo;
  /***************************************************************************************************************
  功能说明：即时移库
  创建人:luozhiling
  创建时间：2014.12.4
  ***************************************************************************************************************/
  procedure proc_SaveMoveCell(strEnterPriseNo  IN stock_content.enterprise_no%type,
                              strWarehouseNo   in stock_content.warehouse_no%type,
                              strArticleNo     in stock_content.article_no%type,
                              strsCellNo       in stock_content.cell_no%type, --来源储位或来源标签
                              strLabelNo       in stock_content.label_no%type,
                              strDCellNo       in stock_content.cell_no%type, --目的储位或目的标签
                              nPackingQty      in stock_content.packing_qty%type,
                              dtProduceDate    in stock_article_info.produce_date%type,
                              dtExpireDate     in stock_article_info.expire_date%type,
                              strQUALITY       in stock_article_info.quality%type,
                              strLotNo         in stock_article_info.lot_no%type, --批次号
                              strRSV_BATCH1    in stock_article_info.rsv_batch1%type, --预留批属性1
                              strRSV_BATCH2    in stock_article_info.rsv_batch2%type, --预留批属性2
                              strRSV_BATCH3    in stock_article_info.rsv_batch3%type, --预留批属性3
                              strRSV_BATCH4    in stock_article_info.rsv_batch4%type, --预留批属性4
                              strRSV_BATCH5    in stock_article_info.rsv_batch5%type, --预留批属性5
                              strRSV_BATCH6    in stock_article_info.rsv_batch6%type, --预留批属性6
                              strRSV_BATCH7    in stock_article_info.rsv_batch7%type, --预留批属性7
                              strRSV_BATCH8    in stock_article_info.rsv_batch8%type, --预留批属性8
                              NRealQty         in stock_content.qty%type,
                              strTERMINAL_FLAG in stock_content_move.terminal_flag%type,
                              strSourceType    in odata_outstock_m.source_type%type,
                              strUserID        in stock_content.rgst_name%type,
                              strOutMsg        out varchar2) is

    n_count         number(10); --记录数，以做判断;
    v_strOutstockNo odata_outstock_m.Outstock_No%type; --下架单号
    n_Dcell_id      stock_content.cell_id%type; --目的储位ID
    n_MoveSumQty    stock_content.Qty%type; --转移总数量
    n_MoveQty       stock_content.Qty%type; --转移数量
    v_strOwnerNo    stock_content.owner_no%type;
    v_nDIVIDEID     odata_outstock_d.divide_id%type;
    v_strsCellNo    cdef_defcell.cell_no%type;
    v_strsLabeNo    stock_label_m.label_no%type;
    v_strDCellNo    cdef_defcell.cell_no%type;
    v_strDLabeNo    stock_label_m.label_no%type;
    v_PrintStatus   odata_outstock_m.print_status%type := '0';
  begin
    strOutMsg := 'N|[proc_SaveMoveCell]';

    --获取货主信息
    select owner_no
      into v_strOwnerNo
      from bdef_defarticle
     where article_no = strArticleNo
       and enterprise_no = strEnterPriseNo;
    --判断strsCellNo是储位或标签
    begin
      select T.cell_no
        into v_strsCellNo
        from cdef_defcell t
       where t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strWarehouseNo
         and t.cell_no = strsCellNo;
      v_strsLabeNo := 'N';
    exception
      when no_data_found then

        v_strsLabeNo := strsCellNo;
        --获取来源储位
        begin
          select distinct t.cell_no
            into v_strsCellNo
            from stock_content t
           where t.enterprise_no = strEnterPriseNo
             and t.warehouse_no = strWarehouseNo
             and t.label_no = strsCellNo;
        exception
          when no_data_found then
            strOutMsg := 'N|[找不到对应的来源库存]';
            return;
        end;
    end;
    --判断目的储位或标签
    begin
      select t.cell_no
        into v_strdCellNo
        from cdef_defcell t
       where t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strWarehouseNo
         and t.cell_no = strdCellNo;
      v_strdLabeNo := 'N';

      --校验目的储位
      --校验目的储位
      Pkobj_stock.CheckMoveDestCell(strEnterpriseNo,
                                    strWareHouseNo,
                                    v_strOwnerNo,
                                    strArticleNo,
                                    dtProduceDate,
                                    dtExpireDate,
                                    strQuality,
                                    strLotNo,
                                    strRSV_BATCH1,
                                    strRSV_BATCH2,
                                    strRSV_BATCH3,
                                    strRSV_BATCH4,
                                    strRSV_BATCH5,
                                    strRSV_BATCH6,
                                    strRSV_BATCH7,
                                    strRSV_BATCH8,
                                    v_strdCellNo,
                                    strOutMsg);
      if (substr(strOutMsg, 1, 1) = 'N') then
        return;
      end if;

    exception
      when no_data_found then

        v_strdLabeNo := strdCellNo;
        --获取来源储位
        begin
          select distinct t.cell_no
            into v_strdCellNo
            from stock_content t
           where t.enterprise_no = strEnterPriseNo
             and t.warehouse_no = strWarehouseNo
             and t.label_no = strdCellNo;
        exception
          when no_data_found then
            strOutMsg := 'N|[找不到对应的目的库存]';
            return;
        end;
    end;

    n_count      := 0;
    n_MoveSumQty := NRealQty;

    ----------------------------------生成移库下架单号---------------------------------------------
    pklg_wms_base.p_getsheetno(strEnterPriseNo,
                               strWarehouseNo,
                               CONST_DOCUMENTTYPE.MDATAHS,
                               v_strOutstockNo,
                               strOutMsg);
    if (substr(strOutMsg, 1, 1) <> 'Y') then
      return;
    end if;
    ----------------------------------添加移库下架头挡---------------------------------------------

    --写下架单头
    pkobj_odata.P_O_WriteOutStockHead(strEnterPriseNo,
                                      strWarehouseNo,
                                      v_strOwnerNo,
                                      v_strOutstockNo,
                                      v_strOutstockNo,
                                      '0',
                                      'N',
                                      'C',
                                      '10',
                                      strUserID,
                                      '1',
                                      '100',
                                      trunc(sysdate),
                                      '4',
                                      'N',
                                      strSourceType,
                                      '1',
                                      v_PrintStatus,
                                      '0',
                                      'N',
                                      strOutMsg);
    if strOutMsg <> 'Y' then
      return;
    end if;
    ----------------------------------获取商品库存信息-------------------------------------------
    for i_Content_Info in (select sc.*
                             from stock_content sc
                            inner join stock_article_info sai
                               on sc.Article_no = sai.Article_no
                              and sc.Article_id = sai.Article_id
                              and sc.enterprise_no = sai.enterprise_no
                            where sc.warehouse_no = strWarehouseNo
                              and sc.enterprise_no = strEnterPriseNo
                              and sc.article_no = sai.article_no
                              and sc.article_id = sai.article_id
                              and sc.article_no = strArticleNo
                              and sc.cell_no = v_strsCellNo
                              and sai.produce_date = dtProduceDate
                              and sai.expire_date = dtExpireDate
                              and sai.quality = strQUALITY
                              and sai.rsv_batch1 = strRSV_BATCH1
                              and sai.rsv_batch2 = strRSV_BATCH2
                              and sai.rsv_batch3 = strRSV_BATCH3
                              and sai.rsv_batch4 = strRSV_BATCH4
                              and sai.rsv_batch5 = strRSV_BATCH5
                              and sai.rsv_batch6 = strRSV_BATCH6
                              and sai.rsv_batch7 = strRSV_BATCH7
                              and sai.rsv_batch8 = strRSV_BATCH8
                              and sai.lot_no = strLotNo
                              and sc.label_no = v_strsLabeNo
                              and sc.packing_qty = nPackingQty
                              and sc.qty - sc.outstock_qty > 0) loop
      n_count := n_count + 1; --判断是否进了循环
      ------------------------当总转移数量等于0时，跳出本次循环
      if (n_MoveSumQty <= 0 or i_Content_Info.Qty <= 0) then
        ------------------------跳出本次循环，
        goto CutContentEnd;
      end if;
      --------循环配量-------------------
      if (i_Content_Info.Qty - i_Content_Info.outstock_qty >= n_MoveSumQty) then
        n_MoveQty := n_MoveSumQty;
      else
        n_MoveQty := i_Content_Info.Qty - i_Content_Info.outstock_qty;
      end if;
      n_MoveSumQty := n_MoveSumQty - n_MoveQty;
      ----------------------------------写库存预下预上数量-------------------------------------------
      pkobj_stock.p_UpdtContent_Reservation(strEnterPriseNo,
                                            strWarehouseNo,
                                            v_strsCellNo,
                                            i_Content_Info.cell_id,
                                            v_strDCellNo,
                                            v_strDLabeNo,
                                            v_strDLabeNo,
                                            n_MoveQty,
                                            i_Content_Info.instock_type,
                                            strUserID,
                                            n_Dcell_id,
                                            strOutMsg);
      if (substr(strOutMsg, 1, 1) <> 'Y') then
        return;
      end if;
      ----------------------------------添加移库下架明细---------------------------------------------
      v_nDIVIDEID := SEQ_ODATA_OUTSTOCK_DIRECT.NEXTVAL;
      insert into odata_outstock_d
        (enterprise_no,
         warehouse_no,
         owner_no,
         outstock_no,
         divide_id,
         operate_date,
         exp_type,
         exp_no,
         wave_no,
         cust_no,
         sub_cust_no,
         article_no,
         article_id,
         packing_qty,
         s_cell_no,
         s_cell_id,
         s_container_no,
         d_cell_no,
         d_cell_id,
         article_qty,
         real_qty,
         status,
         deliver_obj,
         assign_name,
         exp_date,
         label_no,
         sub_label_no)
      values
        (strEnterPriseNo,
         strWarehouseNo,
         v_strOwnerNo,
         v_strOutstockNo,
         v_nDIVIDEID,
         trunc(sysdate),
         'N',
         v_strOutstockNo,
         v_strOutstockNo,
         v_strDLabeNo,
         v_strDLabeNo,
         strArticleNo,
         i_Content_Info.article_id,
         nPackingQTY,
         v_strsCellNo,
         i_Content_info.cell_id,
         'N',
         v_strDCellNo,
         n_Dcell_id,
         n_MoveQty,
         0,
         '10',
         'N',
         strUserID,
         trunc(sysdate),
         v_strsLabeNo,
         i_Content_Info.sub_label_no);
      <<CutContentEnd>>
      null;
    end loop;

    if (n_MoveSumQty > 0) then

      strOutMsg := 'N|[E01866]';
      return;
    end if;
    ----------------------------------调用下架回单-------------------------------------------------
    for i_OutStock_Info in (select ood.*
                              from odata_outstock_d ood
                             where ood.warehouse_no = strWarehouseNo
                               and ood.enterprise_no = strEnterPriseNo
                               and ood.status = '10'
                               and ood.OUTSTOCK_NO = v_strOutstockNo) loop

      --更新下架明细
      PKOBJ_ODATA_LICH.P_Update_Odata_OutStock_D(strEnterPriseNo,
                                                 strWarehouseNo,
                                                 v_strOutstockNo,
                                                 i_OutStock_Info.article_qty,
                                                 i_OutStock_Info.s_Container_No,
                                                 i_OutStock_Info.Owner_No,
                                                 i_OutStock_Info.Divide_Id,
                                                 strUserID,
                                                 strUserID,
                                                 '13',
                                                 strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --更新库存
      PKOBJ_STOCK.proc_OM_Receipt_WriteContent(strEnterPriseNo,
                                               strWarehouseNo,
                                               i_OutStock_Info.s_Cell_Id,
                                               i_OutStock_Info.s_Cell_No,
                                               i_OutStock_Info.d_Cell_Id,
                                               i_OutStock_Info.d_Cell_No,
                                               i_OutStock_Info.Article_Qty,
                                               i_OutStock_Info.Article_Qty,
                                               v_strOutstockNo,
                                               '1',
                                               strUserID,
                                               strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --判断目的储位是否
      PKOBJ_STOCK.P_InsertOwnerCell(strEnterpriseNo,
                                    strWarehouseNo,
                                    v_strOwnerNo,
                                    i_OutStock_Info.d_cell_no,
                                    strArticleNo,
                                    strOutMsg);
      if substr(strOutMsg, 1, 1) = 'N' then
        return;
      end if;

    end loop;
    --更新下架头
    select count(1)
      into n_count
      from odata_outstock_d d
     where d.status = '10'
       and d.outstock_no = v_strOutstockNo
       and d.enterprise_no = strEnterPriseNo
       and d.warehouse_no = strWarehouseNo;

    if n_count <= 0 then
      --更新下架单头
      PKOBJ_ODATA_LICH.P_Update_Odata_OutStock_M(strEnterPriseNo,
                                                 strWarehouseNo,
                                                 v_strOutstockNo,
                                                 strUserID,
                                                 strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      P_ChangeQualityOrg(strEnterPriseNo,
                         strWareHouseNo,
                         v_strOutstockNo,
                         strUserID,
                         strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --转历史
      PKOBJ_ODATA_LICH.P_Update_Odata_OutStock_Hty(strEnterPriseNo,
                                                   strWarehouseNo,
                                                   v_strOutstockNo,
                                                   strUserID,
                                                   '0',
                                                   strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
    end if;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end proc_SaveMoveCell;
  /***************************************************************************************************************
  功能说明：标签移库扫标签
  创建人:wyf
  创建时间：2015.07.25
  ***************************************************************************************************************/
  procedure proc_LabelMoveScanLabelNo(strEnterPriseNo IN stock_content.enterprise_no%type,
                                      strWarehouseNo  in stock_content.warehouse_no%type,
                                      strLabelNo      in stock_content.label_no%type,
                                      strDCellNo      out stock_content.cell_no%type,
                                      strOutMsg       out varchar2) is
    v_nCount integer;
  begin
    strOutMsg  := 'Y|';
    strDCellNo := 'N';
    --校验标签是否为可做标签移库的标签 不存在与标签表 不存在预上预下
    select count(1)
      into v_nCount
      from stock_content c, stock_article_info cai
     where c.enterprise_no = cai.enterprise_no
       and c.article_no = cai.article_no
       and c.article_id = cai.article_id
       and c.enterprise_no = strEnterPriseNo
       and c.warehouse_no = strWarehouseNo
       and c.label_no = strLabelNo
       and (c.outstock_qty <> 0 or c.instock_qty <> 0);
    if v_nCount > 0 then
      strDCellNo := 'N';
      strOutMsg  := 'N|标签存在预约量';
      return;
    end if;

    select count(1)
      into v_nCount
      from stock_content c, stock_article_info cai
     where c.enterprise_no = cai.enterprise_no
       and c.article_no = cai.article_no
       and c.article_id = cai.article_id
       and c.enterprise_no = strEnterPriseNo
       and c.warehouse_no = strWarehouseNo
       and c.label_no = strLabelNo
       and exists (select 1
              from stock_label_m a
             where a.enterprise_no = c.enterprise_no
               and a.warehouse_no = c.warehouse_no
               and a.label_no = c.label_no);

    if v_nCount > 0 then
      strDCellNo := 'N';
      strOutMsg  := 'N|不是库存标签，不能移库';
      return;
    end if;

    proc_RIGetDCellNo(strEnterPriseNo,
                      strWarehouseNo,
                      strLabelNo,
                      strDCellNo,
                      strOutMsg);
    if (substr(strOutMsg, 1, 1) <> 'Y') then
      return;
    end if;
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end proc_LabelMoveScanLabelNo;
  /***************************************************************************************************************
  功能说明：获取返配标签移库建议储位
  创建人:wyf
  创建时间：2015.07.25
  ***************************************************************************************************************/
  procedure proc_RIGetDCellNo(strEnterPriseNo IN stock_content.enterprise_no%type,
                              strWarehouseNo  in stock_content.warehouse_no%type,
                              strLabelNo      in stock_content.label_no%type,
                              strDCellNo      out stock_content.cell_no%type,
                              strOutMsg       out varchar2) is
    v_strClassType ridata_untread_m.class_type%type;
    v_strQuality   ridata_untread_m.quality%type;

    v_strSupplierNo bdef_defarticle.supplier_no%type;
    --v_strRsvAttr2   bdef_defarticle.rsv_attr2%type;
    v_strTmpCellNo stock_content.cell_no%type;

    v_strOrgNo ridata_untread_m.org_no%type; --机构
    v_nCount   number(10);
  begin
    strOutMsg := 'N|[proc_RIGetDCellNo]';
    if strLabelNo = 'N' then
      strOutMsg := 'N|[标签输入有误！]';
    end if;
    v_nCount := 0;
    --校验标签是否可用
    begin
      --校验标签属于那种类型单据 质量问题与清场的可用   获取对应的供应商
      select min(rum.class_type),
             min(rum.quality),
             min(bda.supplier_no),
             min(rum.org_no),
             count(distinct bda.supplier_no)
        into v_strClassType,
             v_strQuality,
             v_strSupplierNo,
             v_strOrgNo,
             v_nCount
        from stock_content      c,
             stock_article_info cai,
             ridata_check_m     rcm,
             ridata_untread_m   rum,
             bdef_defarticle    bda
       where c.enterprise_no = cai.enterprise_no
         and c.article_no = cai.article_no
         and c.article_id = cai.article_id
         and cai.import_batch_no = rcm.check_no
         and cai.enterprise_no = rcm.enterprise_no
         and c.warehouse_no = rcm.warehouse_no
         and c.owner_no = rcm.owner_no
         and rcm.enterprise_no = rum.enterprise_no
         and rcm.warehouse_no = rum.warehouse_no
         and rcm.owner_no = rum.owner_no
         and rcm.untread_no = rum.untread_no
         and c.enterprise_no = bda.enterprise_no
         and c.article_no = bda.article_no
         and rcm.owner_no = bda.owner_no
         and c.enterprise_no = strEnterPriseNo
         and c.warehouse_no = strWarehouseNo
         and c.label_no = strLabelNo;
    exception
      when no_data_found then
        strOutMsg  := 'Y|';
        strDCellNo := 'N';
        return;
    end;

    if v_nCount > 1 then
      strOutMsg  := 'Y|';
      strDCellNo := 'N';
      return;
    end if;
    --获取建议储位
    --清场 寻找退货区 已有供应商+款号相同的储位，无则找空储位
    if v_strClassType = '1' then
      --获取款号
      for p in (select distinct bda.rsv_attr2
                  from stock_content      c,
                       stock_article_info cai,
                       ridata_check_m     rcm,
                       ridata_untread_m   rum,
                       bdef_defarticle    bda
                 where c.enterprise_no = cai.enterprise_no
                   and c.article_no = cai.article_no
                   and c.article_id = cai.article_id
                   and cai.import_batch_no = rcm.check_no
                   and cai.enterprise_no = rcm.enterprise_no
                   and c.warehouse_no = rcm.warehouse_no
                   and c.owner_no = rcm.owner_no
                   and rcm.enterprise_no = rum.enterprise_no
                   and rcm.warehouse_no = rum.warehouse_no
                   and rcm.owner_no = rum.owner_no
                   and rcm.untread_no = rum.untread_no
                   and c.enterprise_no = bda.enterprise_no
                   and c.article_no = bda.article_no
                   and rcm.owner_no = bda.owner_no
                   and c.enterprise_no = strEnterPriseNo
                   and c.warehouse_no = strWarehouseNo
                   and c.label_no = strLabelNo) loop
        begin
          --找库存量最小的
          select a.cell_no
            into v_strTmpCellNo
            from (select *
                    from (select c.cell_no, sum(c.qty) sum_qty
                            from stock_content c,
                                 cdef_defcell  cdc,
                                 cdef_defarea  cda,
                                 cdef_defware  cdw
                           where c.warehouse_no = cdc.warehouse_no
                             and c.enterprise_no = cdc.enterprise_no
                             and c.cell_no = cdc.cell_no
                             and cdc.warehouse_no = cda.warehouse_no
                             and cdc.enterprise_no = cda.enterprise_no
                             and cdc.area_no = cda.area_no
                             and cda.ware_no = cdc.ware_no
                             and cda.enterprise_no = cdw.enterprise_no
                             and cda.warehouse_no = cdw.warehouse_no
                             and cda.ware_no = cdw.ware_no
                             and cdw.org_no = v_strOrgNo
                             and cda.area_usetype = '3'
                             and cda.area_attribute = '0'
                             and cdc.cell_status = '0'
                             and cdc.enterprise_no = strEnterPriseNo
                             and cdc.warehouse_no = strWarehouseNo
                             and exists
                           (select 1
                                    from bdef_defarticle bda
                                   where c.enterprise_no = bda.enterprise_no
                                     and c.owner_no = bda.owner_no
                                     and c.article_no = bda.article_no
                                     and bda.supplier_no = v_strSupplierNo
                                     and bda.rsv_attr2 = p.rsv_attr2)
                             and c.enterprise_no = strEnterPriseNo
                             and c.warehouse_no = strWarehouseNo
                           group by c.cell_no)
                   order by sum_qty) a
           where rownum = 1;
        exception
          when no_data_found then
            goto nextOne;
        end;
        if v_strTmpCellNo is not null then
          exit;
        end if;
        <<nextOne>>
        null;
      end loop;
    end if;
    --质量问题 寻找退货区 已有供应商相同的储位，无则找空储位
    if v_strQuality = 'A' then
      begin
        --找库存量最小的
        select a.cell_no
          into v_strTmpCellNo
          from (select *
                  from (select c.cell_no, sum(c.qty) sum_qty
                          from stock_content c,
                               cdef_defcell  cdc,
                               cdef_defarea  cda,
                               cdef_defware  cdw
                         where c.warehouse_no = cdc.warehouse_no
                           and c.enterprise_no = cdc.enterprise_no
                           and c.cell_no = cdc.cell_no
                           and cdc.warehouse_no = cda.warehouse_no
                           and cdc.enterprise_no = cda.enterprise_no
                           and cdc.area_no = cda.area_no
                           and cda.ware_no = cdc.ware_no
                           and cda.enterprise_no = cdw.enterprise_no
                           and cda.warehouse_no = cdw.warehouse_no
                           and cda.ware_no = cdw.ware_no
                           and cdw.org_no <> v_strOrgNo
                           and cda.area_usetype = '3'
                           and cda.area_attribute = '0'
                           and cdc.cell_status = '0'
                           and cdc.enterprise_no = strEnterPriseNo
                           and cdc.warehouse_no = strWarehouseNo
                           and exists
                         (select 1
                                  from bdef_defarticle bda
                                 where c.enterprise_no = bda.enterprise_no
                                   and c.owner_no = bda.owner_no
                                   and c.article_no = bda.article_no
                                   and bda.supplier_no = v_strSupplierNo)
                           and c.enterprise_no = strEnterPriseNo
                           and c.warehouse_no = strWarehouseNo
                         group by c.cell_no)
                 order by sum_qty) a
         where rownum = 1;
      exception
        when no_data_found then
          v_strTmpCellNo := null;
      end;
    end if;
    --找一个空储位
    if v_strTmpCellNo is null then
      begin
        select cell_no
          into v_strTmpCellNo
          from (select cdc.cell_no
                  from cdef_defcell cdc, cdef_defarea cda, cdef_defware cdw
                 where cdc.warehouse_no = cda.warehouse_no
                   and cdc.enterprise_no = cda.enterprise_no
                   and cdc.area_no = cda.area_no
                   and cda.ware_no = cdc.ware_no
                   and cda.enterprise_no = cdw.enterprise_no
                   and cda.warehouse_no = cdw.warehouse_no
                   and cda.ware_no = cdw.ware_no
                   and cdc.enterprise_no = strEnterPriseNo
                   and cdc.warehouse_no = strWarehouseNo
                   and ((v_strClassType = '1' and cdw.org_no = v_strOrgNo) or
                       (v_strQuality = 'A' and cdw.org_no <> v_strOrgNo))
                   and cda.area_usetype = '3'
                   and cda.area_attribute = '0'
                   and cdc.cell_status = '0'
                   and not exists
                 (select 1
                          from stock_content c
                         where c.warehouse_no = cdc.warehouse_no
                           and c.enterprise_no = cdc.enterprise_no
                           and c.cell_no = cdc.cell_no)
                 order by cdc.cell_no) a
         where rownum = 1;
      exception
        when no_data_found then
          v_strTmpCellNo := 'N';
      end;
    end if;

    strDCellNo := v_strTmpCellNo;
    strOutMsg  := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end proc_RIGetDCellNo;
  /***************************************************************************************************************
  功能说明：标签即时移库,可支持将标签从来源储位直接移库到目的储位
                         可支持将来源标签的库存直接转移到目的储位
  创建人:wyf
  创建时间：2015.07.25
  ***************************************************************************************************************/
  procedure proc_RISaveLabelMoveCell(strEnterPriseNo  IN stock_content.enterprise_no%type,
                                     strWarehouseNo   in stock_content.warehouse_no%type,
                                     strLabelNo       in stock_content.label_no%type,
                                     strDCellNo       in stock_content.cell_no%type, --可传储位和标签号
                                     strdCellUseType  in varchar2, --目的储位类型：1：表示扫描的目的储位；2：表示扫描的目的标签
                                     strTERMINAL_FLAG in stock_content_move.terminal_flag%type,
                                     strSourceType    in odata_outstock_m.source_type%type,
                                     strUserID        in stock_content.rgst_name%type,
                                     strOutMsg        out varchar2) is

    n_count         number(10); --记录数，以做判断;
    v_strOutstockNo odata_outstock_m.Outstock_No%type; --下架单号
    n_Dcell_id      stock_content.cell_id%type; --目的储位ID
    n_MoveQty       stock_content.Qty%type; --转移数量
    v_strOwnerNo    stock_content.owner_no%type;
    v_nDIVIDEID     odata_outstock_d.divide_id%type;
    v_strDCellNo    stock_content.cell_no%type;
    v_strDLabelNo   stock_label_m.label_no%type;
    v_PrintStatus   odata_outstock_m.print_status%type := '0';
  begin
    strOutMsg := 'N|[proc_RISaveLabelMoveCell]';
    n_count   := 0;

    if strdCellUseType = '2' then
      --扫描的目的标签,需要根据目的标签去找目的储位
      begin
        select count(1)
          into n_count
          from stock_content t
         where t.enterprise_no = strEnterPriseNo
           and t.warehouse_no = strWareHouseNo
           and t.label_no = strDCellNo
           and t.outstock_qty > 0;
        if n_count > 0 then
          strOutMsg := 'N|[目的标签存在预下，不允许移入]';
          return;
        end if;

        select distinct cell_no
          into v_strDCellNo
          from stock_content t
         where t.enterprise_no = strEnterPriseNo
           and t.warehouse_no = strWareHouseNo
           and t.label_no = strDCellNo;

      exception
        when no_data_found then
          strOutMsg := 'N|[找不到目的标签对应的储位]';
          return;
      end;
      v_strDLabelNo := strDCellNo;

      --若目的标签是标签，则不能不同供应商混标签

      select COUNT(*)
        into n_count
        from stock_content sc, bdef_defarticle bd
       where sc.article_no = bd.article_no
         and sc.enterprise_no = strEnterPriseNo
         and sc.warehouse_no = strWareHouseNo
         and sc.label_no = strLabelNo
         and bd.supplier_no not in
             (select bd.supplier_no
                from stock_content sc, bdef_defarticle bd
               where sc.article_no = bd.article_no
                 and sc.enterprise_no = strEnterPriseNo
                 and sc.warehouse_no = strWareHouseNo
                 and sc.label_no = strDCellNo);

      if n_count > 0 then
        strOutMsg := 'N|[找不到目的标签对应的储位]';
        return;
      end if;
    else
      v_strDCellNo  := strDCellNo;
      v_strDLabelNo := strLabelNo;
    end if;

    --获取货主信息
    select distinct owner_no
      into v_strOwnerNo
      from stock_content
     where label_no = strLabelNo
       and enterprise_no = strEnterPriseNo
       and warehouse_no = strWarehouseNo;
    ----------------------------------生成移库下架单号---------------------------------------------
    pklg_wms_base.p_getsheetno(strEnterPriseNo,
                               strWarehouseNo,
                               CONST_DOCUMENTTYPE.MDATAHS,
                               v_strOutstockNo,
                               strOutMsg);
    if (substr(strOutMsg, 1, 1) <> 'Y') then
      return;
    end if;
    ----------------------------------添加移库下架头挡---------------------------------------------

    --写下架单头
    pkobj_odata.P_O_WriteOutStockHead(strEnterPriseNo,
                                      strWarehouseNo,
                                      v_strOwnerNo,
                                      v_strOutstockNo,
                                      v_strOutstockNo,
                                      '0',
                                      'N',
                                      'C',
                                      '10',
                                      strUserID,
                                      '1',
                                      '100',
                                      trunc(sysdate),
                                      '4',
                                      'N',
                                      strSourceType,
                                      '1',
                                      v_PrintStatus,
                                      '0',
                                      'N',
                                      strOutMsg);
    if strOutMsg <> 'Y' then
      return;
    end if;
    ----------------------------------获取商品库存信息-------------------------------------------
    for i_Content_Info in (select sc.*,
                                  sai.quality,
                                  sai.produce_date,
                                  sai.expire_date,
                                  sai.lot_no,
                                  sai.rsv_batch1,
                                  sai.rsv_batch2,
                                  sai.rsv_batch3,
                                  sai.rsv_batch4,
                                  sai.rsv_batch5,
                                  sai.rsv_batch6,
                                  sai.rsv_batch7,
                                  sai.rsv_batch8
                             from stock_content sc
                            inner join stock_article_info sai
                               on sc.Article_no = sai.Article_no
                              and sc.Article_id = sai.Article_id
                              and sc.enterprise_no = sai.enterprise_no
                            where sc.warehouse_no = strWarehouseNo
                              and sc.enterprise_no = strEnterPriseNo
                              and sc.owner_no = v_strOwnerNo
                              and sc.label_no = strLabelNo
                              and sc.qty - sc.outstock_qty > 0) loop

      --校验目的储位
      Pkobj_stock.CheckMoveDestCell(strEnterpriseNo,
                                    strWareHouseNo,
                                    v_strOwnerNo,
                                    i_Content_Info.article_no,
                                    i_Content_Info.produce_date,
                                    i_Content_Info.expire_date,
                                    i_Content_Info.quality,
                                    i_Content_Info.lot_no,
                                    i_Content_Info.rsv_batch1,
                                    i_Content_Info.rsv_batch2,
                                    i_Content_Info.rsv_batch3,
                                    i_Content_Info.rsv_batch4,
                                    i_Content_Info.rsv_batch5,
                                    i_Content_Info.rsv_batch6,
                                    i_Content_Info.rsv_batch7,
                                    i_Content_Info.rsv_batch8,
                                    v_strDCellNo,
                                    strOutMsg);
      if (substr(strOutMsg, 1, 1) <> 'Y') then
        return;
      end if;

      n_count := n_count + 1; --判断是否进了循环

      --------循环配量-------------------
      n_MoveQty := i_Content_Info.Qty - i_Content_Info.outstock_qty;
      ----------------------------------写库存预下预上数量-------------------------------------------
      pkobj_stock.p_UpdtContent_Reservation(strEnterPriseNo,
                                            strWarehouseNo,
                                            i_Content_Info.Cell_No,
                                            i_Content_Info.cell_id,
                                            v_strDCellNo,
                                            v_strDLabelNo,
                                            v_strDLabelNo,
                                            n_MoveQty,
                                            i_Content_Info.instock_type,
                                            strUserID,
                                            n_Dcell_id,
                                            strOutMsg);
      if (substr(strOutMsg, 1, 1) <> 'Y') then
        return;
      end if;
      ----------------------------------添加移库下架明细---------------------------------------------
      v_nDIVIDEID := SEQ_ODATA_OUTSTOCK_DIRECT.NEXTVAL;
      insert into odata_outstock_d
        (enterprise_no,
         warehouse_no,
         owner_no,
         outstock_no,
         divide_id,
         operate_date,
         exp_type,
         exp_no,
         wave_no,
         cust_no,
         sub_cust_no,
         article_no,
         article_id,
         packing_qty,
         s_cell_no,
         s_cell_id,
         s_container_no,
         d_cell_no,
         d_cell_id,
         article_qty,
         real_qty,
         status,
         deliver_obj,
         assign_name,
         exp_date,
         label_no,
         sub_label_no)
      values
        (strEnterPriseNo,
         strWarehouseNo,
         v_strOwnerNo,
         v_strOutstockNo,
         v_nDIVIDEID,
         trunc(sysdate),
         'N',
         v_strOutstockNo,
         v_strOutstockNo,
         v_strDLabelNo, --挪用记录目的标签
         v_strDLabelNo, --挪用记录目的标签
         i_Content_Info.Article_No,
         i_Content_Info.article_id,
         i_Content_Info.Packing_Qty,
         i_Content_Info.Cell_No,
         i_Content_info.cell_id,
         'N',
         v_strDCellNo,
         n_Dcell_id,
         n_MoveQty,
         0,
         '10',
         'N',
         strUserID,
         trunc(sysdate),
         strLabelNo,
         i_Content_Info.sub_label_no);
    end loop;

    ----------------------------------调用下架回单-------------------------------------------------
    for i_OutStock_Info in (select ood.*
                              from odata_outstock_d ood
                             where ood.warehouse_no = strWarehouseNo
                               and ood.enterprise_no = strEnterPriseNo
                               and ood.status = '10'
                               and ood.OUTSTOCK_NO = v_strOutstockNo) loop

      --更新下架明细
      PKOBJ_ODATA_LICH.P_Update_Odata_OutStock_D(strEnterPriseNo,
                                                 strWarehouseNo,
                                                 v_strOutstockNo,
                                                 i_OutStock_Info.article_qty,
                                                 i_OutStock_Info.s_Container_No,
                                                 i_OutStock_Info.Owner_No,
                                                 i_OutStock_Info.Divide_Id,
                                                 strUserID,
                                                 strUserID,
                                                 '13',
                                                 strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --更新库存
      PKOBJ_STOCK.proc_OM_Receipt_WriteContent(strEnterPriseNo,
                                               strWarehouseNo,
                                               i_OutStock_Info.s_Cell_Id,
                                               i_OutStock_Info.s_Cell_No,
                                               i_OutStock_Info.d_Cell_Id,
                                               i_OutStock_Info.d_Cell_No,
                                               i_OutStock_Info.Article_Qty,
                                               i_OutStock_Info.Article_Qty,
                                               v_strOutstockNo,
                                               strTERMINAL_FLAG,
                                               strUserID,
                                               strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --判断目的储位是否
      PKOBJ_STOCK.P_InsertOwnerCell(strEnterpriseNo,
                                    strWarehouseNo,
                                    v_strOwnerNo,
                                    i_OutStock_Info.d_cell_no,
                                    i_OutStock_Info.article_no,
                                    strOutMsg);
      if substr(strOutMsg, 1, 1) = 'N' then
        return;
      end if;

    end loop;
    --更新下架头
    select count(1)
      into n_count
      from odata_outstock_d d
     where d.status = '10'
       and d.outstock_no = v_strOutstockNo
       and d.enterprise_no = strEnterPriseNo
       and d.warehouse_no = strWarehouseNo;

    if n_count <= 0 then
      --更新下架单头
      PKOBJ_ODATA_LICH.P_Update_Odata_OutStock_M(strEnterPriseNo,
                                                 strWarehouseNo,
                                                 v_strOutstockNo,
                                                 strUserID,
                                                 strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      P_ChangeQualityOrg(strEnterPriseNo,
                         strWareHouseNo,
                         v_strOutstockNo,
                         strUserID,
                         strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --转历史
      PKOBJ_ODATA_LICH.P_Update_Odata_OutStock_Hty(strEnterPriseNo,
                                                   strWarehouseNo,
                                                   v_strOutstockNo,
                                                   strUserID,
                                                   '0',
                                                   strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
    end if;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end proc_RISaveLabelMoveCell;

  /************************************************************************************************************
  功能说明：1、写移库头档
            2、写库明细
            3、移库回单
  创建人：luozhiling
  2015.5.8
  ************************************************************************************************************/
  procedure Proc_LabelBackCell(strEnterPriseNo IN stock_content.enterprise_no%type,
                               strWarehouseNo  in stock_content.warehouse_no%type,
                               strOwnerNo      in stock_content.owner_no%type,
                               strLabelNo      in stock_content.label_no%type, --来源标签
                               strUserID       in stock_content.rgst_name%type,
                               strOutMsg       out varchar2) is
    v_strOutstockNo odata_outstock_d.outstock_no%type;
    n_count         integer;
    v_nOutCellId    stock_content.cell_id%type;
  begin
    strOutMsg := 'N|[Proc_LabelBackCell]';

    ----------------------------------生成移库下架单号---------------------------------------------
    pklg_wms_base.p_getsheetno(strEnterPriseNo,
                               strWarehouseNo,
                               CONST_DOCUMENTTYPE.MDATAHS,
                               v_strOutstockNo,
                               strOutMsg);
    if (substr(strOutMsg, 1, 1) <> 'Y') then
      return;
    end if;

    --写下架单头
    pkobj_odata.P_O_WriteOutStockHead(strEnterPriseNo,
                                      strWarehouseNo,
                                      strOwnerNo,
                                      v_strOutstockNo,
                                      v_strOutstockNo,
                                      '0',
                                      'N',
                                      'C',
                                      '10',
                                      strUserID,
                                      '1',
                                      '100',
                                      trunc(sysdate),
                                      '4',
                                      'N',
                                      '1',
                                      '1',
                                      '0',
                                      '0',
                                      'N',
                                      strOutMsg);
    if strOutMsg <> 'Y' then
      return;
    end if;

    --写下架单明细
    for GetLableItem in (select slm.owner_cell_no, sld.*
                           from stock_label_m slm, stock_label_d sld
                          where slm.enterprise_no = sld.enterprise_no
                            and slm.enterprise_no = strEnterPriseNo
                            and slm.warehouse_no = sld.warehouse_no
                            and slm.container_no = sld.container_no
                            and slm.warehouse_no = strWareHouseNo
                            and slm.label_no = strLabelNo) loop

      pkobj_mdata.Proc_Insert_LabelBackCellItem(strEnterPriseNo,
                                                strWarehouseNo,
                                                v_strOutstockNo,
                                                strOwnerNo,
                                                GetLableItem.owner_cell_no,
                                                strLabelNo,
                                                strLabelNo,
                                                GetLableItem.source_no,
                                                GetLableItem.article_no,
                                                GetLableItem.divide_id,
                                                GetLableItem.article_id,
                                                GetLableItem.packing_qty,
                                                GetLableItem.qty,
                                                strUserID,
                                                strOutMsg);

      if strOutMsg <> 'Y' then
        return;
      end if;
    end loop;

    --移库回单
    ----------------------------------调用下架回单-------------------------------------------------
    for i_OutStock_Info in (select ood.*
                              from odata_outstock_d ood
                             where ood.warehouse_no = strWarehouseNo
                               and ood.enterprise_no = strEnterPriseNo
                               and ood.status = '10'
                               and ood.OUTSTOCK_NO = v_strOutstockNo) loop

      --更新下架明细
      PKOBJ_ODATA_LICH.P_Update_Odata_OutStock_D(strEnterPriseNo,
                                                 strWarehouseNo,
                                                 v_strOutstockNo,
                                                 i_OutStock_Info.Real_Qty,
                                                 i_OutStock_Info.s_Container_No,
                                                 i_OutStock_Info.Owner_No,
                                                 i_OutStock_Info.Divide_Id,
                                                 strUserID,
                                                 strUserID,
                                                 '13',
                                                 strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --更新库存
      PKOBJ_STOCK.proc_OM_Receipt_WriteContent(strEnterPriseNo,
                                               strWarehouseNo,
                                               i_OutStock_Info.s_Cell_Id,
                                               i_OutStock_Info.s_Cell_No,
                                               i_OutStock_Info.d_Cell_Id,
                                               i_OutStock_Info.d_Cell_No,
                                               i_OutStock_Info.Article_Qty,
                                               i_OutStock_Info.Article_Qty,
                                               v_strOutstockNo,
                                               '1',
                                               strUserID,
                                               strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --将目的容器库存的标签号转为N;
      pkobj_stock.p_UpdtContent_ContainerNo(strEnterpriseNo,
                                            strWareHouseNo,
                                            'N',
                                            'N',
                                            i_OutStock_Info.d_Cell_No,
                                            i_OutStock_Info.d_Cell_Id,
                                            strUserId,
                                            v_nOutCellId,
                                            strOutMsg);
      if (substr(strOutMsg, 1, 1) = 'N') then
        return;
      end if;

      --判断目的储位是否
      PKOBJ_STOCK.P_InsertOwnerCell(strEnterpriseNo,
                                    strWarehouseNo,
                                    i_OutStock_Info.owner_no,
                                    i_OutStock_Info.d_cell_no,
                                    i_OutStock_Info.article_no,
                                    strOutMsg);
      if substr(strOutMsg, 1, 1) = 'N' then
        return;
      end if;

    end loop;
    --更新下架头
    select count(1)
      into n_count
      from odata_outstock_d d
     where d.status = '10'
       and d.outstock_no = v_strOutstockNo
       and d.enterprise_no = strEnterPriseNo
       and d.warehouse_no = strWarehouseNo;

    if n_count <= 0 then
      --更新下架单头
      PKOBJ_ODATA_LICH.P_Update_Odata_OutStock_M(strEnterPriseNo,
                                                 strWarehouseNo,
                                                 v_strOutstockNo,
                                                 strUserID,
                                                 strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --转历史
      PKOBJ_ODATA_LICH.P_Update_Odata_OutStock_Hty(strEnterPriseNo,
                                                   strWarehouseNo,
                                                   v_strOutstockNo,
                                                   strUserID,
                                                   '0',
                                                   strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
    end if;

    strOutMsg := 'Y|[]';
  end Proc_LabelBackCell;

  /*****************************************************************************8888
  功能说明：根据移库单进行品质转换
  2015.8.7
  *********************************************************************************/
  procedure P_ChangeQualityOrg(strEnterPriseNo odata_outstock_m.enterprise_no%type,
                               strWareHouseNo  odata_outstock_m.warehouse_no%type,
                               strOutStockNo   odata_outstock_m.outstock_no%type,
                               strWorkerNo     odata_outstock_m.rgst_name%type,
                               strResult       out varchar2) is
    v_strChangeNo odata_outstock_m.outstock_no%type := 'N';
    v_strsOrgNo   cdef_defware.org_no%type := 'N';
    v_strdOrgNo   cdef_defware.org_no%type := 'N';
    v_iCount      integer := 0;
  begin
    strResult := 'N|[P_ChangeQualityOrg]';

    for GetOutstockInf in (select cws.org_no s_org_no,
                                  cwd.org_no d_org_no,
                                  ood.owner_no,
                                  ood.outstock_no,
                                  ood.article_no,
                                  ood.packing_qty,
                                  sai.produce_date,
                                  sai.expire_date,
                                  sai.import_batch_no,
                                  sai.lot_no,
                                  sai.rsv_batch1,
                                  sai.rsv_batch2,
                                  sai.rsv_batch3,
                                  sai.rsv_batch4,
                                  sai.rsv_batch5,
                                  sai.rsv_batch6,
                                  sai.rsv_batch7,
                                  sai.rsv_batch8,
                                  sum(ood.real_qty) real_qty
                             from cdef_defcell       cds,
                                  cdef_defware       cws,
                                  odata_outstock_d   ood,
                                  cdef_defcell       cdd,
                                  cdef_defware       cwd,
                                  stock_article_info sai
                            where cds.enterprise_no = cws.enterprise_no
                              and cds.warehouse_no = cws.warehouse_no
                              and cds.ware_no = cws.ware_no
                              and cds.enterprise_no = ood.enterprise_no
                              and cds.warehouse_no = ood.warehouse_no
                              and cds.cell_no = ood.s_cell_no
                              and cdd.enterprise_no = cwd.enterprise_no
                              and cdd.warehouse_no = cwd.warehouse_no
                              and cdd.ware_no = cwd.ware_no
                              and cdd.enterprise_no = ood.enterprise_no
                              and cdd.warehouse_no = ood.warehouse_no
                              and cdd.cell_no = ood.d_cell_no
                              and cws.org_no <> cwd.org_no
                              and ood.enterprise_no = sai.enterprise_no
                              and ood.article_no = sai.article_no
                              and ood.article_id = sai.article_id
                              and ood.enterprise_no = strEnterPriseNo
                              and ood.warehouse_no = strWareHouseNo
                              and ood.outstock_no = strOutStockNo
                            group by cws.org_no,
                                     cwd.org_no,
                                     ood.owner_no,
                                     ood.outstock_no,
                                     ood.article_no,
                                     ood.packing_qty,
                                     sai.produce_date,
                                     sai.expire_date,
                                     sai.import_batch_no,
                                     sai.lot_no,
                                     sai.rsv_batch1,
                                     sai.rsv_batch2,
                                     sai.rsv_batch3,
                                     sai.rsv_batch4,
                                     sai.rsv_batch5,
                                     sai.rsv_batch6,
                                     sai.rsv_batch7,
                                     sai.rsv_batch8
                            order by cws.org_no, cwd.org_no) loop
      v_iCount := v_iCount + 1;
      if GetOutstockInf.s_org_no <> v_strsOrgNo or
         GetOutstockInf.d_org_no <> v_strdOrgNo then
        --写品质转换单
        pkobj_adj.P_Insert_QUALITY_CHANGE_m(strEnterpriseNo,
                                            strWareHouseNo,
                                            GetOutstockInf.owner_no,
                                            '0',
                                            strWorkerNo,
                                            strOutStockNo,
                                            v_strChangeNo,
                                            strResult);

        if substr(strResult, 1, 1) = 'N' then
          return;
        end if;
      end if;

      --写品质转换单明细
      pkobj_adj.P_Insert_QUALITY_CHANGE_d(strEnterpriseNo,
                                          strWareHouseNo,
                                          GetOutstockInf.owner_no,
                                          '0',
                                          v_strChangeNo,
                                          GetOutstockInf.article_no,
                                          GetOutstockInf.packing_qty,
                                          GetOutstockInf.produce_date,
                                          GetOutstockInf.expire_date,
                                          GetOutstockInf.import_batch_no,
                                          GetOutstockInf.lot_no,
                                          GetOutstockInf.rsv_batch1,
                                          GetOutstockInf.rsv_batch2,
                                          GetOutstockInf.rsv_batch3,
                                          GetOutstockInf.rsv_batch4,
                                          GetOutstockInf.rsv_batch5,
                                          GetOutstockInf.rsv_batch6,
                                          GetOutstockInf.rsv_batch7,
                                          GetOutstockInf.rsv_batch8,
                                          GetOutstockInf.s_org_no,
                                          GetOutstockInf.d_org_no,
                                          GetOutstockInf.real_qty,
                                          0,
                                          'N',
                                          '1',
                                          'N',
                                          strResult);

      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;
      v_strsOrgNo := GetOutstockInf.s_org_no;
      v_strdOrgNo := GetOutstockInf.d_org_no;

    end loop;

    --品质转换回单
    if v_iCount > 0 then
      v_strChangeNo := 'N';
      for GetChangeInf in (select oqd.*
                             from org_quality_change_m oqm,
                                  org_quality_change_d oqd
                            where oqm.enterprise_no = oqd.enterprise_no
                              and oqm.warehouse_no = oqd.warehouse_no
                              and oqm.change_no = oqd.change_no
                              and oqm.po_no = strOutStockNo
                              and oqm.enterprise_no = strEnterPriseNo
                              and oqm.warehouse_no = strWareHouseNo
                            order by oqd.change_no) loop

        --更新品质转换明细
        /*****************20160606 wyf 添加ROW_ID条件**********************/
        pkobj_adj.P_Update_QUALITY_CHANGE_d(strEnterpriseNo,
                                            strWareHouseNo,
                                            GetChangeInf.owner_no,
                                            GetChangeInf.change_no,
                                            GetChangeInf.article_no,
                                            GetChangeInf.change_qty,
                                            GetChangeInf.Row_Id,
                                            strResult);
        if substr(strResult, 1, 1) = 'N' then
          return;
        end if;

        if v_strChangeNo <> GetChangeInf.change_no then
          pkobj_adj.P_Update_QUALITY_CHANGE_m(strEnterpriseNo,
                                              strWareHouseNo,
                                              GetChangeInf.owner_no,
                                              GetChangeInf.change_no,
                                              strWorkerNo,
                                              strResult);
          if substr(strResult, 1, 1) = 'N' then
            return;
          end if;
        end if;

        v_strChangeNo := GetChangeInf.change_no;

      end loop;
    end if;
    strResult := 'Y|[]';
  end P_ChangeQualityOrg;

  /*************************************************************************************************
    创建人：wyf
    创建时间：2015.08.01
    功能说明：过季转应季整理扫描标签获取信息找目的储位
  **************************************************************************************************/
  PROCEDURE P_HM_SEASON_OUT2IN_GETDCELLNO(strEnterPriseNo   in stock_content.enterprise_no%type,
                                          strWarehouseNo    in stock_content.warehouse_no%type,
                                          strLabelNo        in stock_content.warehouse_no%type,
                                          strPrinterGroupNo in STOCK_LABEL_ARRANGE_LOG.printer_group_no%type,
                                          strDockNo         in STOCK_LABEL_ARRANGE_LOG.dock_no%type,
                                          strUserID         in STOCK_LABEL_ARRANGE_LOG.rgst_name%type,
                                          strResult         out varchar2) IS
    v_strTmpCellNo    cset_cell_article.cell_no%type;
    v_strEspecialCell stock_content.cell_no%type;
    v_nCount          integer;
    v_nRowID          integer := 0;
  BEGIN
    strResult := 'N|[P_HM_SEASON_OUT2IN_GETDCELLNO]';

    select count(1)
      into v_nCount
      from STOCK_LABEL_ARRANGE_LOG t
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWarehouseNo
       and t.s_label_no = strLabelNo
       and t.arrange_type = '1'
       and t.source_no <> 'N';
    if v_nCount > 0 then
      strResult := 'Y';
      return;
    else
      delete from STOCK_LABEL_ARRANGE_LOG t
       where t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strWarehouseNo
         and t.s_label_no = strLabelNo
         and t.arrange_type = '1'
         and t.source_no = 'N';
    end if;
    --获取异常储位
    begin
      select cell_no
        into v_strEspecialCell
        from (select CDC.CELL_NO
                from cdef_defcell cdc, cdef_defarea cdd
               where cdc.enterprise_no = cdd.enterprise_no
                 and cdc.enterprise_no = strEnterPriseNo
                 and cdc.warehouse_no = cdd.warehouse_no
                 and cdc.ware_no = cdd.ware_no
                 and cdc.area_no = cdd.area_no
                 AND CDC.CELL_STATUS = '0'
                 AND CDC.CHECK_STATUS = 0
                 and cdd.AREA_ATTRIBUTE = '0'
                 and cdd.AREA_USETYPE = '5'
                 and cdd.warehouse_no = strWareHouseNo
               order by CDC.CELL_NO)
       where rownum <= 1;
    exception
      when no_data_found then
        strResult := 'N|[E21706]'; --获取异常区储位失败
        return;
    end;

    --先找拣货区该商品已有库存的储位
    for p in (select c.enterprise_no,
                     c.warehouse_no,
                     c.owner_no,
                     sum(c.qty),
                     c.packing_qty,
                     v.BARCODE,
                     v.ARTICLE_NO,
                     c.cell_no s_cell_no,
                     --cai.*,
                     cai.produce_date,
                     cai.expire_date,
                     cai.lot_no,
                     cai.quality,
                     cca.cell_no      pick_cell_no,
                     cca.stock_no     pick_stock_no,
                     cca.area_no      pick_area_no,
                     cca.ware_no      pick_ware_no
                from stock_content c
                join stock_article_info cai
                  on c.article_no = cai.article_no
                 and c.article_id = cai.article_id
                 and c.enterprise_no = cai.enterprise_no
                join cdef_defcell cdc
                  on c.warehouse_no = cdc.warehouse_no
                 and cdc.enterprise_no = c.enterprise_no
                 and cdc.cell_no = c.cell_no
                join cdef_defarea cda
                  on cda.warehouse_no = cdc.warehouse_no
                 and cda.enterprise_no = cdc.enterprise_no
                 and cda.area_no = cdc.area_no
                 and cda.ware_no = cdc.ware_no
                join v_bdef_defarticle v
                  on c.article_no = v.ARTICLE_NO
                 and c.enterprise_no = v.ENTERPRISE_NO
                 and c.owner_no = v.OWNER_NO
                left join cset_cell_article cca
                  on c.article_no = cca.article_no
                 and c.enterprise_no = cca.enterprise_no
                 and c.warehouse_no = cca.warehouse_no
                 and c.owner_no = cca.owner_no
               where cda.area_usetype = '1'
                 and cda.area_quality = '1'
                 and cda.area_attribute = '0'
                 and cda.attribute_type = '0'
                 and c.label_no = strLabelNo
                 and c.enterprise_no = strEnterPriseNo
                 and c.warehouse_no = strWarehouseNo
               group by c.enterprise_no,
                        c.warehouse_no,
                        c.owner_no,
                        c.packing_qty,
                        v.BARCODE,
                        v.ARTICLE_NO,
                        c.cell_no,
                        --cai.*,
                        cai.produce_date,
                        cai.expire_date,
                        cai.lot_no,
                        cai.quality,
                        cca.cell_no,
                        cca.stock_no,
                        cca.area_no,
                        cca.ware_no) loop
      v_nRowID := v_nRowID + 1;

      if p.pick_cell_no is not null then
        v_strTmpCellNo := p.pick_cell_no;
        --没有设置到储位，找通道下未设置商品拣货位的空储位，
        --找不到则找可混储位，再无则找储区下空储位
        --预留通过商品群组找储位
      else
        begin
          select cell_no
            into v_strTmpCellNo
            from (select sc.cell_no,
                         sum(sc.qty + sc.instock_qty - sc.outstock_qty)
                    from cdef_defarea cda
                    join cdef_defcell cdc
                      on cda.enterprise_no = cdc.enterprise_no
                     and cda.warehouse_no = cdc.warehouse_no
                     and cda.ware_no = cdc.ware_no
                     and cda.area_no = cdc.area_no
                    join stock_content sc
                      on cdc.enterprise_no = sc.enterprise_no
                     and cdc.warehouse_no = sc.warehouse_no
                     and cdc.cell_no = sc.cell_no
                   where cda.enterprise_no = strEnterPriseNo
                     and cda.warehouse_no = strWarehouseNo
                     and sc.owner_no = p.owner_no
                     and sc.article_no = p.article_no
                     and cda.area_usetype = '1'
                     and cda.area_attribute = '0'
                     and cda.area_pick = '1'
                   group by sc.cell_no
                   order by sum(sc.qty + sc.instock_qty - sc.outstock_qty))
           where rownum = 1;
        exception
          when no_data_found then
            v_strTmpCellNo := null;
        end;
        if v_strTmpCellNo is null then
          if p.pick_stock_no is not null then
            --设置到通道，先找不可混的无库存未设置商品拣货位的储位
            begin
              select cell_no
                into v_strTmpCellNo
                from (select cdc.cell_no
                        from cdef_defcell cdc
                       where cdc.enterprise_no = strEnterPriseNo
                         and cdc.warehouse_no = strWarehouseNo
                         and cdc.ware_no = p.pick_ware_no
                         and cdc.area_no = p.pick_area_no
                         and cdc.stock_no = p.pick_stock_no
                            --and cdc.mix_flag = 0
                         and cdc.cell_status <> '1'
                         and cdc.check_status = '0'
                         and not exists
                       (select 1
                                from stock_content c
                               where c.enterprise_no = cdc.enterprise_no
                                 and c.warehouse_no = cdc.warehouse_no
                                 and c.owner_no = p.owner_no
                                 and c.cell_no = cdc.cell_no)
                         and not exists
                       (select 1
                                from cset_cell_article c
                               where c.enterprise_no = cdc.enterprise_no
                                 and c.warehouse_no = cdc.warehouse_no
                                 and c.owner_no = p.owner_no
                                 and c.cell_no = cdc.cell_no)
                       order by cdc.pick_order)
               where rownum = 1;
            exception
              when no_data_found then
                v_strTmpCellNo := null;
            end;
          else
            if p.pick_area_no is not null then
              --设置到储区，先找不可混的无库存未设置商品拣货位的储位
              begin
                select cell_no
                  into v_strTmpCellNo
                  from (select cdc.cell_no
                          from cdef_defcell cdc
                         where cdc.enterprise_no = strEnterPriseNo
                           and cdc.warehouse_no = strWarehouseNo
                           and cdc.ware_no = p.pick_ware_no
                           and cdc.area_no = p.pick_area_no
                              --and cdc.mix_flag = 0
                           and cdc.cell_status <> '1'
                           and cdc.check_status = '0'
                           and not exists
                         (select 1
                                  from stock_content c
                                 where c.enterprise_no = cdc.enterprise_no
                                   and c.warehouse_no = cdc.warehouse_no
                                   and c.owner_no = p.owner_no
                                   and c.cell_no = cdc.cell_no)
                           and not exists
                         (select 1
                                  from cset_cell_article c
                                 where c.enterprise_no = cdc.enterprise_no
                                   and c.warehouse_no = cdc.warehouse_no
                                   and c.owner_no = p.owner_no
                                   and c.cell_no = cdc.cell_no)
                         order by cdc.area_no, cdc.pick_order)
                 where rownum = 1;
              exception
                when no_data_found then
                  v_strTmpCellNo := null;
              end;
            end if;
          end if;
        end if;
      end if;
      --找不到储位给异常储位
      if v_strTmpCellNo is null then
        v_strTmpCellNo := v_strEspecialCell;
      end if;

      insert into stock_label_arrange_log
        (enterprise_no,
         warehouse_no,
         owner_no,
         source_no,
         s_label_no,
         label_no,
         row_id,
         article_no,
         packing_qty,
         qty,
         produce_date,
         expire_date,
         quality,
         lot_no,
         s_cell_no,
         d_cell_no,
         printer_group_no,
         dock_no,
         status,
         ARRANGE_TYPE,
         rgst_name,
         rgst_date)
      values
        (strEnterPriseNo,
         strWarehouseNo,
         p.owner_no,
         'N',
         strLabelNo,
         'N',
         v_nRowID,
         p.article_no,
         p.packing_qty,
         0,
         p.produce_date,
         p.expire_date,
         p.quality,
         p.lot_no,
         p.s_cell_no,
         v_strTmpCellNo,
         strPrinterGroupNo,
         strDockNo,
         '10',
         '1',
         strUserID,
         sysdate);

    end loop;
    if v_nRowID = 0 then
      strResult := 'N|[标签不存在！]';
    end if;
    --strCellNo := v_strTmpCellNo;
    strResult := 'Y';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_HM_SEASON_OUT2IN_GETDCELLNO;
  /*************************************************************************************************
    创建人：wyf
    创建时间：2015.08.01
    功能说明：过季转应季整理
  **************************************************************************************************/
  PROCEDURE P_HM_SEASON_OUT2IN_ARRANGE(strEnterPriseNo   in odata_outstock_d.enterprise_no%type,
                                       strWarehouseNo    in odata_outstock_d.warehouse_no%type,
                                       strOwnerNo        in odata_outstock_d.owner_no%type,
                                       strSCellNo        in odata_outstock_d.S_Cell_No%type,
                                       strLabelNo        in odata_outstock_d.label_no%type, --来源标签
                                       strArticleNo      in odata_outstock_d.article_no%type,
                                       nPackingQty       in stock_content.packing_qty%type,
                                       dtProduceDate     in varchar2,
                                       dtExpireDate      in varchar2,
                                       strQUALITY        in stock_article_info.quality%type,
                                       strLotNo          in stock_article_info.lot_no%type, --批次号
                                       nPlanQty          in odata_outstock_d.article_qty%type,
                                       nQty              in odata_outstock_d.real_qty%type,
                                       strDCellNo        in odata_outstock_d.d_Cell_No%type,
                                       strPrinterGroupNo in STOCK_LABEL_ARRANGE_LOG.printer_group_no%type,
                                       strDockNo         in STOCK_LABEL_ARRANGE_LOG.dock_no%type,
                                       strUserID         in STOCK_LABEL_ARRANGE_LOG.rgst_name%type,
                                       strResult         out varchar2) IS
    v_nCount        integer;
    v_strOutStockNo odata_outstock_m.outstock_no%type;

    n_count      number(10); --记录数，以做判断;
    n_Dcell_id   stock_content.cell_id%type; --目的储位ID
    v_nDIVIDEID  odata_outstock_d.divide_id%type;

  BEGIN
    strResult := 'N|[P_HM_SEASON_OUT2IN_ARRANGE]';
    --校验标签
    begin
      select count(1)
        into v_nCount
        from STOCK_LABEL_ARRANGE_LOG c
       where c.enterprise_no = strEnterPriseNo
         and c.warehouse_no = strWarehouseNo
         and c.owner_no = strOwnerNo
         and c.s_cell_no = strSCellNo
         and c.s_label_no = strLabelNo
         and c.article_no = strArticleNo
         and c.d_cell_no = strDCellNo
         and c.packing_qty = nPackingQty
         and to_char(c.produce_date, 'yyyy-mm-dd') = dtProduceDate
         and to_char(c.expire_date, 'yyyy-mm-dd') = dtExpireDate
         and c.quality = strQUALITY
         and c.lot_no = strLotNo
         and c.arrange_type = '1';

      if v_nCount = 0 then
        strResult := 'N|[找不到需要整理的过季品数据！]';
        return;
      end if;
    end;
    if nPlanQty - nQty < 0 then
      strResult := 'N|[整理数量超出计划数量！]';
      return;
    end if;
    --判断是否要新增移库下架单
    begin
      select distinct c.outstock_no
        into v_strOutStockNo
        from odata_outstock_d c
       where c.enterprise_no = strEnterPriseNo
         and c.warehouse_no = strWarehouseNo
         and c.owner_no = strOwnerNo
         and c.label_no = strLabelNo;
    exception
      when no_data_found then
        --新增移库下架单和标签信息，写库存预上预下
        --取下架单号
        PKLG_WMS_BASE.p_getsheetno(strEnterPriseNo,
                                   strWarehouseNo,
                                   CONST_DOCUMENTTYPE.MDATAHS,
                                   v_strOutstockNo,
                                   strResult);
        if strResult <> 'Y' then
          return;
        end if;
        --写下架单头
        pkobj_odata.P_O_WriteOutStockHead(strEnterPriseNo,
                                          strWarehouseNo,
                                          strOwnerNo,
                                          v_strOutstockNo,
                                          v_strOutstockNo,
                                          '0',
                                          'N',
                                          'B',
                                          '10',
                                          strUserID,
                                          '2',
                                          100,
                                          trunc(sysdate),
                                          '4',
                                          strDockNo,
                                          '2',
                                          '1',
                                          '0',
                                          '0',
                                          'N',
                                          strResult);
        if strResult <> 'Y' then
          return;
        end if;
        --更新日志表 绑定下架单号
        update STOCK_LABEL_ARRANGE_LOG l
           set l.source_no = v_strOutStockNo
         where l.warehouse_no = strWarehouseNo
           and l.enterprise_no = strEnterPriseNo
           and l.owner_no = strOwnerNo
           and l.s_label_no = strLabelNo
           and l.arrange_type = '1'
           and l.source_no = 'N';

        for i_Content_Info in (select sc.*, l.D_CELL_NO
                                 from stock_content sc
                                inner join stock_article_info sai
                                   on sc.Article_no = sai.Article_no
                                  and sc.Article_id = sai.Article_id
                                  and sc.enterprise_no = sai.enterprise_no
                                inner join STOCK_LABEL_ARRANGE_LOG l
                                   on sc.enterprise_no = l.enterprise_no
                                  and sc.warehouse_no = l.warehouse_no
                                  and sc.owner_no = l.owner_no
                                  and sc.cell_no = l.s_cell_no
                                  and sc.label_no = l.s_label_no
                                  and sc.Article_no = l.Article_no
                                  and sc.packing_qty = l.packing_qty
                                  and sai.produce_date = l.produce_date
                                  and sai.expire_date = l.expire_date
                                  and sai.quality = l.quality
                                  and sai.lot_no = l.lot_no
                                where sc.warehouse_no = strWarehouseNo
                                  and sc.enterprise_no = strEnterPriseNo
                                  and sc.owner_no = strOwnerNo
                                  and sc.label_no = strLabelNo
                                  and l.arrange_type = '1'
                                  and sc.qty - sc.outstock_qty > 0) loop
          n_count := n_count + 1; --判断是否进了循环
          ----------------------------------写库存预下预上数量-------------------------------------------
          pkobj_stock.p_UpdtContent_Reservation(strEnterPriseNo,
                                                strWarehouseNo,
                                                i_Content_Info.Cell_No,
                                                i_Content_Info.cell_id,
                                                i_Content_Info.d_Cell_No,
                                                'N',
                                                i_Content_Info.sub_label_no,
                                                i_Content_Info.Qty,
                                                i_Content_Info.instock_type,
                                                strUserID,
                                                n_Dcell_id,
                                                strResult);
          if (substr(strResult, 1, 1) <> 'Y') then
            return;
          end if;
          ----------------------------------添加移库下架明细---------------------------------------------
          v_nDIVIDEID := SEQ_ODATA_OUTSTOCK_DIRECT.NEXTVAL;
          insert into odata_outstock_d
            (enterprise_no,
             warehouse_no,
             owner_no,
             outstock_no,
             divide_id,
             operate_date,
             exp_type,
             exp_no,
             wave_no,
             cust_no,
             sub_cust_no,
             article_no,
             article_id,
             packing_qty,
             s_cell_no,
             s_cell_id,
             s_container_no,
             d_cell_no,
             d_cell_id,
             article_qty,
             real_qty,
             status,
             deliver_obj,
             assign_name,
             exp_date,
             label_no,
             sub_label_no)
          values
            (strEnterPriseNo,
             strWarehouseNo,
             strOwnerNo,
             v_strOutstockNo,
             v_nDIVIDEID,
             trunc(sysdate),
             'N',
             v_strOutstockNo,
             v_strOutstockNo,
             'N',
             'N',
             i_Content_Info.Article_No,
             i_Content_Info.article_id,
             i_Content_Info.Packing_Qty,
             i_Content_info.Cell_No,
             i_Content_info.cell_id,
             'N',
             i_Content_Info.d_Cell_No,
             n_Dcell_id,
             i_Content_Info.Qty,
             i_Content_Info.Qty,
             '10',
             'N',
             strUserID,
             trunc(sysdate),
             strLabelNo,
             i_Content_Info.sub_label_no);
        end loop;

        --写标签信息
        pklg_odata.P_WriteLabelInfo(strEnterPriseNo,
                                    strWarehouseNo,
                                    'N',
                                    strOwnerNo,
                                    v_strOutstockNo,
                                    strResult);
        if strResult <> 'Y' then
          return;
        end if;
        /*        --写标签信息
        pkOBJ_label_odata.P_H_WriteLabelTask(strEnterPriseNo,
                                             strWarehouseNo,
                                             v_strOutStockNo,
                                             'B',
                                             strUserID,
                                             strResult);
        if strResult <> 'Y' then
          return;
        end if;*/
        for p in (select ood.enterprise_no,
                         ood.warehouse_no,
                         ood.outstock_no as stockNo,
                         cai.article_no,
                         cai.barcode,
                         ood.packing_qty,
                         cai.produce_date,
                         cai.expire_date,
                         cai.quality,
                         cai.LOT_NO,
                         cai.RSV_BATCH1,
                         cai.RSV_BATCH2,
                         cai.RSV_BATCH3,
                         cai.RSV_BATCH4,
                         cai.RSV_BATCH5,
                         cai.RSV_BATCH6,
                         cai.RSV_BATCH7,
                         cai.RSV_BATCH8,
                         ood.s_cell_no as OutStockCellNo,
                         ood.d_cell_no as inStockCellNo,
                         sum(ood.article_qty) as OutStockQty,
                         sum(ood.article_qty) as InStockQty
                    from odata_outstock_d ood
                    join stock_article_info cai
                      on ood.article_no = cai.article_no
                     and ood.article_id = cai.article_id
                     and ood.enterprise_no = cai.enterprise_no
                   where ood.enterprise_no = strEnterPriseNo
                     and ood.warehouse_no = strWarehouseNo
                     and ood.owner_no = strOwnerNo
                     and ood.outstock_no = v_strOutstockNo
                   group by ood.enterprise_no,
                            ood.warehouse_no,
                            ood.outstock_no,
                            cai.produce_date,
                            cai.expire_date,
                            cai.quality,
                            cai.LOT_NO,
                            cai.RSV_BATCH1,
                            cai.RSV_BATCH2,
                            cai.RSV_BATCH3,
                            cai.RSV_BATCH4,
                            cai.RSV_BATCH5,
                            cai.RSV_BATCH6,
                            cai.RSV_BATCH7,
                            cai.RSV_BATCH8,
                            ood.s_cell_no,
                            ood.d_cell_no,
                            cai.article_no,
                            cai.barcode,
                            ood.packing_qty) loop
          --移库下架
          PKOBJ_MDATA.P_mdata_RfOut(strEnterPriseNo,
                                    strWarehouseNo,
                                    v_strOutstockNo,
                                    p.article_no,
                                    p.packing_qty,
                                    p.quality,
                                    p.produce_date,
                                    p.expire_date,
                                    p.lot_no,
                                    p.rsv_batch1,
                                    p.rsv_batch2,
                                    p.rsv_batch3,
                                    p.rsv_batch4,
                                    p.rsv_batch5,
                                    p.rsv_batch6,
                                    p.rsv_batch7,
                                    p.rsv_batch8,
                                    p.outstockqty,
                                    p.outstockcellno,
                                    p.instockcellno,
                                    strLabelNo,
                                    strUserID,
                                    strResult);
          if strResult <> 'Y' then
            return;
          end if;
        end loop;
    end;

    --新增整理记录
    update STOCK_LABEL_ARRANGE_LOG c
       set c.qty = nQty, c.updt_name = strUserID, c.updt_date = sysdate
     where c.enterprise_no = strEnterPriseNo
       and c.warehouse_no = strWarehouseNo
       and c.owner_no = strOwnerNo
       and c.s_cell_no = strSCellNo
       and c.s_label_no = strLabelNo
       and c.article_no = strArticleNo
       and c.d_cell_no = strDCellNo
       and c.packing_qty = nPackingQty
       and to_char(c.produce_date, 'yyyy-mm-dd') = dtProduceDate
       and to_char(c.expire_date, 'yyyy-mm-dd') = dtExpireDate
       and c.quality = strQUALITY
       and c.lot_no = strLotNo
       and c.arrange_type = '1';
    strResult := 'Y';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_HM_SEASON_OUT2IN_ARRANGE;
  /*************************************************************************************************
    创建人：wyf
    创建时间：2015.08.01
    功能说明：获取库存记标签--应季转过季扫描
    获取库存，记库存预上预下
  **************************************************************************************************/
  PROCEDURE P_HM_STOCKSETLABEL_SCAN(strEnterPriseNo   in stock_content.enterprise_no%type,
                                    strWarehouseNo    in stock_content.warehouse_no%type,
                                    strOwnerNo        in stock_content.owner_no%type,
                                    strSCellNo        in stock_content.cell_no%type,
                                    strInSourceNo     in STOCK_LABEL_ARRANGE_LOG.SOURCE_NO%type,
                                    strInLabelNo      in stock_content.label_no%type,
                                    strSLabelNo       in stock_content.label_no%type,
                                    strArticleNo      in stock_content.article_no%type,
                                    nPackingQty       in stock_content.packing_qty%type,
                                    dtProduceDate     in varchar2,
                                    dtExpireDate      in varchar2,
                                    strQUALITY        in stock_article_info.quality%type,
                                    strLotNo          in stock_article_info.lot_no%type, --批次号
                                    nQty              in stock_content.qty%type,
                                    strPrinterGroupNo in STOCK_LABEL_ARRANGE_LOG.PRINTER_GROUP_NO%type,
                                    strDockNo         in STOCK_LABEL_ARRANGE_LOG.DOCK_NO%type,
                                    strUserID         in stock_content.rgst_name%type,
                                    strOutLabelNo     out stock_content.label_no%type, --来源标签
                                    strOutSourceNo    out STOCK_LABEL_ARRANGE_LOG.SOURCE_NO%type,
                                    strResult         out varchar2) IS
    v_nCellID        stock_content.cell_id%type;
    v_strTmpLabelNo  stock_content.label_no%type;
    v_strTmpSourceNo STOCK_LABEL_ARRANGE_LOG.SOURCE_NO%type;
    v_PrintTaskNo    job_printtask_m.task_no%type;
    v_strContainerNo stock_label_m.container_no%type;
    v_strSessionID   varchar2(100); --会话ID

    v_nRowID     integer;
    n_count      number(10); --记录数，以做判断;
    n_MoveSumQty stock_content.Qty%type; --转移总数量
    n_MoveQty    stock_content.Qty%type; --转移数量
    --v_nDIVIDEID  odata_outstock_d.divide_id%type;
  BEGIN
    strResult    := 'N|[P_HM_STOCKSETLABEL_SCAN]';
    n_MoveSumQty := nQty;
    if strInSourceNo = 'N' or strInSourceNo is null then
      PKLG_WMS_BASE.p_getsheetno(strEnterPriseNo,
                                 strWarehouseNo,
                                 CONST_DOCUMENTTYPE.MDATAHS,
                                 v_strTmpSourceNo,
                                 strResult);
      if strResult <> 'Y' then
        return;
      end if;
    else
      v_strTmpSourceNo := strInSourceNo;
    end if;
    --取标签号
    if strInLabelNo = 'N' or strInLabelNo is null then
      PKLG_WMS_BASE.p_get_ContainerNoBase(strEnterPriseNo,
                                          strWarehouseNo,
                                          'B',
                                          strUserID,
                                          'Y',
                                          1,
                                          '1',
                                          NULL,
                                          v_strTmpLabelNo,
                                          v_strContainerNo,
                                          v_strSessionID,
                                          strResult);
      if instr(strResult, 'N', 1, 1) = 1 then
        return;
      end if;
      --写标签打印任务
      PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                 strWareHouseNo,
                                 CONST_DOCUMENTTYPE.PRINTPT,
                                 v_PrintTaskNo,
                                 strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;

      PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterpriseNo,
                                          strWareHouseNo,
                                          v_strTmpSourceNo,
                                          '0',
                                          CONST_REPORTID.HmStockSetLabel,
                                          strDockNo,
                                          '0',
                                          strUserID,
                                          v_PrintTaskNo,
                                          strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;

      PKOBJ_PRINTTASK.p_insert_taskdetail(strEnterpriseNo,
                                          strWareHouseNo,
                                          v_PrintTaskNo,
                                          v_strTmpLabelNo,
                                          1,
                                          1,
                                          strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;
    else
      v_strTmpLabelNo := strInLabelNo;
    end if;
    --获取库存
    for i_Content_Info in (select sc.*
                             from stock_content sc
                            inner join stock_article_info sai
                               on sc.Article_no = sai.Article_no
                              and sc.Article_id = sai.Article_id
                              and sc.enterprise_no = sai.enterprise_no
                            where sc.warehouse_no = strWarehouseNo
                              and sc.enterprise_no = strEnterPriseNo
                              and sc.owner_no = strOwnerNo
                              and sc.cell_no = strSCellNo
                              and sc.Article_no = strArticleNo
                              and to_char(sai.produce_date, 'yyyy-mm-dd') =
                                  dtProduceDate
                              and to_char(sai.expire_date, 'yyyy-mm-dd') =
                                  dtExpireDate
                              and sai.quality = strQUALITY
                              and sai.lot_no = strLotNo
                              and sc.packing_qty = nPackingQty
                              and sc.label_no = strSLabelNo
                              and sc.qty - sc.outstock_qty > 0) loop
      n_count := n_count + 1; --判断是否进了循环
      ------------------------当总转移数量等于0时，跳出本次循环
      if (n_MoveSumQty <= 0 or i_Content_Info.Qty <= 0) then
        ------------------------跳出本次循环，
        goto CutContentEnd;
      end if;
      --------循环配量-------------------
      if (i_Content_Info.Qty - i_Content_Info.outstock_qty >= n_MoveSumQty) then
        n_MoveQty := n_MoveSumQty;
      else
        n_MoveQty := i_Content_Info.Qty - i_Content_Info.outstock_qty;
      end if;
      n_MoveSumQty := n_MoveSumQty - n_MoveQty;

      --写库存预上预下
      PKOBJ_STOCK.p_UpdtContent_Reservation(strEnterPriseNo,
                                            strWarehouseNo,
                                            strSCellNo,
                                            i_Content_Info.Cell_Id,
                                            strSCellNo,
                                            v_strTmpLabelNo,
                                            v_strTmpLabelNo,
                                            n_MoveQty,
                                            '0',
                                            strUserID,
                                            v_nCellID,
                                            strResult);
      if (substr(strResult, 1, 1) <> 'Y') then
        return;
      end if;
      --更新绩效表
      update stock_label_arrange_log c
         set c.qty       = c.qty + n_MoveQty,
             c.updt_name = strUserID,
             c.updt_date = sysdate
       where c.enterprise_no = strEnterPriseNo
         and c.warehouse_no = strWarehouseNo
         and c.owner_no = strOwnerNo
         and c.s_cell_no = strSCellNo
         and c.source_no = v_strTmpSourceNo
         and c.label_no = v_strTmpLabelNo
         and c.article_no = strArticleNo
         and c.d_cell_no = strSCellNo
         and c.packing_qty = nPackingQty
         and to_char(c.produce_date, 'yyyy-mm-dd') = dtProduceDate
         and to_char(c.expire_date, 'yyyy-mm-dd') = dtExpireDate
         and c.quality = strQUALITY
         and c.lot_no = strLotNo
         and c.arrange_type = '2';
      if sql%rowcount <= 0 then
        --更新不到，则新增
        select nvl(max(c.row_id), 0) + 1
          into v_nRowID
          from stock_label_arrange_log c
         where c.enterprise_no = strEnterPriseNo
           and c.warehouse_no = strWarehouseNo
           and c.owner_no = strOwnerNo
           and c.s_cell_no = strSCellNo
           and c.label_no = v_strTmpLabelNo
              --and c.article_no = strArticleNo
           and c.d_cell_no = strSCellNo
              --and c.packing_qty = nPackingQty
              --and to_char(c.produce_date,'yyyy-mm-dd') = dtProduceDate
              --and to_char(c.expire_date,'yyyy-mm-dd') = dtExpireDate
              --and c.quality = strQUALITY
              --and c.lot_no = strLotNo
           and c.arrange_type = '2';
        insert into stock_label_arrange_log
          (enterprise_no,
           warehouse_no,
           owner_no,
           source_no,
           s_label_no,
           label_no,
           row_id,
           article_no,
           packing_qty,
           qty,
           produce_date,
           expire_date,
           quality,
           lot_no,
           s_cell_no,
           d_cell_no,
           printer_group_no,
           dock_no,
           status,
           ARRANGE_TYPE,
           rgst_name,
           rgst_date)
        values
          (strEnterPriseNo,
           strWarehouseNo,
           strOwnerNo,
           v_strTmpSourceNo,
           i_Content_Info.Label_No,
           v_strTmpLabelNo,
           v_nRowID,
           strArticleNo,
           nPackingQty,
           n_MoveQty,
           to_date(dtProduceDate, 'yyyy-mm-dd'),
           to_date(dtExpireDate, 'yyyy-mm-dd'),
           strQUALITY,
           strLotNo,
           i_Content_Info.cell_no,
           i_Content_Info.cell_no,
           strPrinterGroupNo,
           strDockNo,
           '10',
           '2',
           strUserID,
           sysdate);
      end if;
      <<CutContentEnd>>
      null;
    end loop;
    if n_MoveSumQty > 0 then
      strResult := 'N|[录入数量超出库存可用量！]';
      return;
    end if;
    strOutLabelNo  := v_strTmpLabelNo;
    strOutSourceNo := v_strTmpSourceNo;

    strResult := 'Y';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_HM_STOCKSETLABEL_SCAN;
  /*************************************************************************************************
    创建人：wyf
    创建时间：2015.08.01
    功能说明：库存记标签--应季转过季封箱
  **************************************************************************************************/
  PROCEDURE P_HM_STOCKSETLABEL_CLOSEBOX(strEnterPriseNo  in stock_content.enterprise_no%type,
                                        strWarehouseNo   in stock_content.warehouse_no%type,
                                        strOwnerNo       in stock_content.owner_no%type,
                                        strSourceNo      in STOCK_LABEL_ARRANGE_LOG.Source_No%type,
                                        strLabelNo       in STOCK_LABEL_ARRANGE_LOG.label_no%type, --标签
                                        strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                                        strUserID        in stock_content.rgst_name%type,
                                        strResult        out varchar2) IS
    v_nCount integer;
  BEGIN
    strResult := 'N|[P_HM_STOCKSETLABEL_CLOSEBOX]';
    v_nCount  := 0;
    --获取库存
    --通过标签关联，根据相同库存属性的商品的目的储位的预上数量扣减来源储位的数量
    for p in (select l.*,
                     c.cell_id      s_cell_id,
                     cd.cell_id     d_cell_id,
                     cd.instock_qty move_qty
                from STOCK_LABEL_ARRANGE_LOG l
                join stock_article_info cai
                  on cai.enterprise_no = l.enterprise_no
                 and cai.article_no = l.article_no
                 and cai.produce_date = l.produce_date
                 and cai.expire_date = l.expire_date
                 and cai.quality = l.quality
                 and cai.lot_no = l.lot_no
              --目的储位库存
                join stock_content cd
                  on l.enterprise_no = cd.enterprise_no
                 and l.warehouse_no = cd.warehouse_no
                 and l.owner_no = cd.owner_no
                 and l.d_cell_no = cd.cell_no
                 and l.article_no = cd.article_no
                 and l.packing_qty = cd.packing_qty
                 and l.label_no = cd.label_no
                 and cai.article_no = cd.article_no
                 and cai.article_id = cd.article_id
              --来源储位库存
                join stock_content c
                  on l.enterprise_no = c.enterprise_no
                 and l.warehouse_no = c.warehouse_no
                 and l.owner_no = c.owner_no
                 and l.s_cell_no = c.cell_no
                 and l.article_no = c.article_no
                 and l.packing_qty = c.packing_qty
                 and l.s_label_no = c.label_no
                 and c.article_no = cd.article_no
                 and c.article_id = cd.article_id

               where l.enterprise_no = strEnterPriseNo
                 and l.warehouse_no = strWarehouseNo
                 and l.owner_no = strOwnerNo
                 and l.Source_No = strSourceNo
                 and l.label_no = strLabelNo
                 and l.ARRANGE_TYPE = '2'
                 and l.status = '10'
                 and c.outstock_qty > 0
                 and cd.instock_qty > 0) loop
      v_nCount := v_nCount + 1;

      --更新库存
      PKOBJ_STOCK.proc_OM_Receipt_WriteContent(strEnterPriseNo,
                                               strWarehouseNo,
                                               p.s_Cell_Id,
                                               p.s_Cell_No,
                                               p.d_Cell_Id,
                                               p.d_Cell_No,
                                               p.move_qty,
                                               p.move_qty,
                                               strSourceNo,
                                               strTERMINAL_FLAG,
                                               strUserID,
                                               strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;

    end loop;

    --校验单据是否存在
    if v_nCount <= 0 then
      strResult := 'N|[找不到需要封箱的数据，或者已封箱！]';
      return;
    end if;

    update STOCK_LABEL_ARRANGE_LOG c
       set c.status = '13', c.updt_name = strUserID, c.updt_date = sysdate
     where c.enterprise_no = strEnterPriseNo
       and c.warehouse_no = strWarehouseNo
       and c.owner_no = strOwnerNo
       and c.source_no = strSourceNo
       and c.label_no = strLabelNo
       and c.arrange_type = '2'
       and c.status = '10';

    strResult := 'Y';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_HM_STOCKSETLABEL_CLOSEBOX;
end PKLG_MDATA;

/

