create package        PKLG_BUFFER_CALCULATE is
  -- Author  : weiyufei
  -- Created : 2016-02-25
  -- Purpose : 出货暂存区资源试算
  /**************************************************************************************************/
  /*
   功能说明：定位前勾单校验暂存区资源是否够用
   创建人：wyf
   创建时间：2016.2.29
   strDelFlag = '1' and strRetryFlag = '1'时，相当于取消勾选【是否试算】可不传客户与出货单
   strDelFlag = '1' and strRetryFlag = '0'时，相当于取消勾选订单或者客户，根据是否【按客户调度】传出货单号或者客户
   strDelFlag = '0' and strRetryFlag = '1'时，相当于重算月台资源，可不传客户与出货单
   strDelFlag = '0' and strRetryFlag = '0'时，正常勾选客户或者订单，根据是否【按客户调度】传出货单号或者客户

   出货暂存区资源按出货类型策略试算 huangb 20160622
  */
  /**************************************************************************************************/
  procedure P_DeliverArea_Cal_Tmp(strEnterpriseNo in varchar2, --企业
                                  strWareHouseNo  in varchar2, --仓库代码
                                  strOwnerNo      in varchar2,
                                  strExpType      in odata_exp_m.exp_type%type,
                                  strTmpID        in odata_tmp_locate_select.tmp_id%type,
                                  strExpNo        in odata_tmp_locate_select.exp_no%type, --按单调度传 重整时不传
                                  strCustNo       in odata_exp_m.cust_no%type, --按客户时传 重整时不传
                                  strSendBufFlag  in ODATA_LOCATE_BATCH.SENDBUF_COMPUTE_FLAG%TYPE, --是否资源试算
                                  /*strSendBufLv    in ODATA_LOCATE_BATCH.SENDBUF_COMPUTE_LEVEL%TYPE, --
                                  strSendBufVal   in ODATA_LOCATE_BATCH.SENDBUF_COMPUTE_VALUE%TYPE, --
                                  strDeliverObjLv in ODATA_LOCATE_BATCH.DELIVER_OBJ_LEVEL%TYPE,*/
                                  strDelFlag      in varchar2, --是否删除 0：不删除，1：删除
                                  strRetryFlag    in varchar2, --是否暂存区资源重整 0：不重整，1：重整
                                  strResult       out varchar2);
  /**************************************************************************************************/
  /*
   功能说明：发货暂存区资源试算。
   创建人：wyf
   创建时间：2016.2.25
  */
  /**************************************************************************************************/
  procedure P_DeliverArea_Cal(strEnterpriseNo in varchar2, --企业
                              strWareHouseNo  in varchar2, --仓库代码
                              strWaveNo       in odata_locate_batch.wave_no%type, --波次号
                              strBatchNo      in odata_locate_batch.batch_no%type, --作业批次号
                              strResult       out varchar2);
  /**************************************************************************************************/
  /*
   功能说明：按配送对象计算暂存区资源。试算写临时表
   创建人：wyf
   创建时间：2016.2.25
  */
  /**************************************************************************************************/
  procedure P_Locate_SendArea(strEnterpriseNo in varchar2, --企业
                              strWareHouseNo  in varchar2, --仓库代码
                              strSendBufLv    in ODATA_LOCATE_BATCH.SENDBUF_COMPUTE_LEVEL%TYPE,
                              SendBufCompute  in ODATA_LOCATE_BATCH.SENDBUF_COMPUTE_VALUE%type,
                              strTmpID        in ODATA_SEND_AREA_CALCULATE.TMP_ID%TYPE,
                              strLineNo       in ODATA_SEND_AREA_CALCULATE.LINE_NO%TYPE,
                              strDeliverObj   in ODATA_LOCATE_D.DELIVER_OBJ%TYPE,
                              nUseWeight      in ODATA_SEND_AREA_CALCULATE.USE_WEIGHT%TYPE,
                              nUseVolume      in ODATA_SEND_AREA_CALCULATE.USE_VOLUMN%TYPE,
                              nUseBoxNum      in ODATA_SEND_AREA_CALCULATE.USE_BOXNUM%TYPE,
                              strResult       out varchar2);
  /**************************************************************************************************/
  /*
   功能说明：新增空暂存区资源临时表
   创建人：wyf
   创建时间：2016.3.2
  */
  /**************************************************************************************************/
  procedure P_Ins_temp_EmptyBuf(nContinueNum in odata_temp_EmptyBuf.Empty_Num%type,
                                nRowID       in odata_temp_EmptyBuf.Row_Id%type);
  /**************************************************************************************************/
  /*
   功能说明：新增暂存区资源试算临时表
   创建人：wyf
   创建时间：2016.2.29
  */
  /**************************************************************************************************/
  procedure P_Ins_DeliverArea_Cal_Tmp(strEnterpriseNo in varchar2, --企业
                                      strWareHouseNo  in varchar2, --仓库代码
                                      strTmpID        in odata_tmp_locate_select.tmp_id%type,
                                      strWareNo       in cdef_defcell.ware_no%type,
                                      strAreaNo       in cdef_defcell.area_no%type,
                                      strStockNo      in cdef_defcell.stock_no%type,
                                      strCellNo       in cdef_defcell.cell_no%type,
                                      nMaxQty         in odata_temp_send_area_calculate.max_qty%type,
                                      nMaxWeight      in odata_temp_send_area_calculate.max_weight%type,
                                      nMaxVolume      in odata_temp_send_area_calculate.max_volume%type,
                                      nMaxCase        in odata_temp_send_area_calculate.max_case%type,
                                      strCellStatus   in odata_temp_send_area_calculate.cell_status%type,
                                      strLineNo       in odata_temp_send_area_calculate.line_no%type,
                                      nUseVolumn      in odata_temp_send_area_calculate.use_volumn%type,
                                      nUseWeight      in odata_temp_send_area_calculate.use_weight%type,
                                      nUseBoxNum      in odata_temp_send_area_calculate.use_boxnum%type,
                                      strDeliverObj   in odata_temp_send_area_calculate.deliver_obj%type,
                                      strResult       out varchar2);
  /**************************************************************************************************/
  /*
   功能说明：删除暂存区资源试算临时表
   创建人：wyf
   创建时间：2016.2.29
  */
  /**************************************************************************************************/
  procedure P_Del_DeliverArea_Cal_Tmp(strEnterpriseNo in varchar2, --企业
                                      strWareHouseNo  in varchar2, --仓库代码
                                      strTmpID        in odata_tmp_locate_select.tmp_id%type,
                                      strDeliverObj   in odata_locate_d.deliver_obj%type,
                                      strResult       out varchar2);
  /**************************************************************************************************/
  /*
   功能说明：修出货下架指示DELIVER_AREA
   创建人：wyf
   创建时间：2016.2.29
  */
  /**************************************************************************************************/
  procedure P_SetOutStoctk_SendArea(strEnterpriseNo in varchar2, --企业
                                    strWareHouseNo  in varchar2, --仓库代码
                                    strOwnerNo      in odata_outstock_direct.owner_no%type,
                                    strWaveNo       in odata_outstock_direct.wave_no%type,
                                    strTmpID        in odata_tmp_locate_select.tmp_id%type,
                                    strResult       out varchar2);
  /**************************************************************************************************/
  /*
   功能说明：新增暂存区资源试算表
   创建人：wyf
   创建时间：2016.2.29
  */
  /**************************************************************************************************/
  procedure P_Ins_DeliverArea_Cal(strEnterpriseNo in varchar2, --企业
                                  strWareHouseNo  in varchar2, --仓库代码
                                  strTmpID        in odata_tmp_locate_select.tmp_id%type,
                                  strWaveNo       in odata_outstock_direct.wave_no%type,
                                  strResult       out varchar2);
  /**************************************************************************************************/
  /*
   功能说明：释放暂存区资源
   创建人：wyf
   创建时间：2016.2.29
  */
  /**************************************************************************************************/
  procedure P_Clear_DeliverArea_Cal(strEnterpriseNo in varchar2, --企业
                                    strWareHouseNo  in varchar2, --仓库代码
                                    strOwnerNo      in odata_outstock_direct.owner_no%type,
                                    strWaveNo       in odata_locate_batch.wave_no%type,
                                    --strBatchNo      in odata_locate_batch.batch_no%type,
                                    strDeliverObj   in odata_locate_d.deliver_obj%type,
                                    strExpType      odata_locate_batch.exp_type%type,
                                    --strLabelNo in stock_label_m.label_no%type,
                                    --strDeliverArea  in odata_outstock_direct.deliver_area%type,
                                    strResult out varchar2);
end PKLG_BUFFER_CALCULATE;


/

