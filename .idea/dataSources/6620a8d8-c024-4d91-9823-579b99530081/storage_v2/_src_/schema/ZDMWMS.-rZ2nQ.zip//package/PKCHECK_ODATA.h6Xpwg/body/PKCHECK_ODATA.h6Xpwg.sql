create package body        pkcheck_odata is
  /*****************************************************************************************************************
  lich
  20150120
  功能说明：拣货回单，标签号校验
  支持扫描下架单号 huangb 20160722
  ***************************************************************************************************************/
  procedure P_CheckLabelNo(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                           strWarehouseNo  in stock_label_m.warehouse_no%type,
                           strLabelNo      in stock_label_m.label_no%type, --标签或下架单号 huangb 20160722
                           strUserID       in odata_outstock_m.rgst_name%type,
                           strOutLabelNo   out stock_label_m.label_no%type, --返回标签号 huangb 20160722
                           strOutDivideNo  out odata_divide_m.divide_no%type, --分播单号
                           strOutMsg       out varchar2) is

    v_LabelOrOutstockNo varchar2(1) := '0'; --是标签还是下架单号 0-标签;1-下架单号
    v_OutstockNo        odata_outstock_m.outstock_no%type; --下架单号
    v_PickType          odata_outstock_m.pick_type%type; --0-摘果;1-播种;2-边拣边分
    v_LabelNo           stock_label_m.label_no%type; --标签号
    v_ContainerNo       stock_label_m.container_no%type; --系统内部容器号
    v_Status            stock_label_m.status%type; --单据或标签状态
    v_StatusDesc        varchar2(20);
    v_UseType           stock_label_m.use_type%type; --标签用途
    v_DivideNo          odata_divide_m.divide_no%type; --分播单号

  begin
    strOutMsg := 'N|[P_CheckLabelNo]';
    --判断是下架单号 还是标签号
    begin
      select '0', oom.outstock_no, oom.pick_type, slm.label_no, slm.container_no
             , slm.status, slm.use_type, wdf.text
        into v_LabelOrOutstockNo, v_OutstockNo, v_PickType, v_LabelNo, v_ContainerNo
             , v_Status, v_UseType, v_StatusDesc
        from stock_label_m slm, odata_outstock_m oom, wms_deffieldval wdf
       where oom.enterprise_no = slm.enterprise_no
         and oom.warehouse_no = slm.warehouse_no
         and oom.outstock_no = slm.source_no
         and wdf.table_name(+) = upper('STOCK_LABEL_M')
         and wdf.colname(+) = upper('STATUS')
         and wdf.value(+) = slm.status
         and slm.enterprise_no = strEnterpriseNo
         and slm.warehouse_no = strWarehouseNo
         and slm.label_no = strLabelNo;
    exception
      when no_data_found then
        begin
          select '1', t.outstock_no, t.pick_type, t.label_no, t.container_no, t.status
            into v_LabelOrOutstockNo, v_OutstockNo, v_PickType, v_LabelNo, v_ContainerNo, v_Status
            from (select oom.status, oom.outstock_no, slm.label_no, slm.container_no, oom.pick_type,
                         cdc.ware_no,cdc.area_no,cdc.stock_no,cdc.pick_order
                    from odata_outstock_m oom, odata_outstock_d ood, cdef_defcell cdc, stock_label_m slm
                   where cdc.enterprise_no = ood.enterprise_no
                     and cdc.warehouse_no = ood.warehouse_no
                     and cdc.cell_no = ood.s_cell_no
                     and slm.enterprise_no = oom.enterprise_no
                     and slm.warehouse_no = oom.warehouse_no
                     and slm.source_no = oom.outstock_no
                     and slm.status in ('40','50')
                     and oom.enterprise_no = strEnterpriseNo
                     and oom.warehouse_no = strWarehouseNo
                     and oom.outstock_no = strLabelNo
                   order by cdc.ware_no,cdc.area_no,cdc.stock_no,cdc.pick_order,slm.label_no) t
          where rownum = 1;
        exception
          when no_data_found then
            strOutMsg := 'N|下架单或标签['|| strLabelNo ||']不存在';
            return;
        end;
    end;

    --如果是标签号
    if v_LabelOrOutstockNo = '0' then

      if v_UseType not in ('1', '2') then
        strOutMsg := 'N|[E22514]'; --该标签号不是拣货标签！
        return;
      end if;

      if v_Status <> clabelstatus.PICK_HAND_OUT then
        strOutMsg := 'N|标签状态为[' || v_StatusDesc || '],不能发单';
        return;
      end if;

    end if;

    --如果是下架单号
    if v_LabelOrOutstockNo = '1' then

      if v_Status <> '10' then
        strOutMsg := 'N|该下架单不是初始状态,不能回单';
        return;
      end if;

    end if;

    ---分拣边分
    if v_PickType = Cpicktype.PickingDivide then
      --写分播指示
      begin
        --判断是否有分播单
        select odd.divide_no
          into v_DivideNo
          from odata_divide_d odd
         where odd.enterprise_no = strEnterPriseNo
           and odd.warehouse_no = strWarehouseNo
           and odd.s_container_no= v_ContainerNo
           and odd.source_no = v_OutstockNo
           and rownum <= 1;
      exception
        when no_data_found then
          PKOBJ_ODATA_DIVIDE.P_Insert_Divide_Direct(strEnterPriseNo,
                                                    strWarehouseNo,
                                                    v_OutstockNo,
                                                    v_ContainerNo,
                                                    strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;

          --写分播单
          PKLG_ODATA_DIVIDE.P_WriteOutStock_Divide(strEnterPriseNo,
                                                   strWarehouseNo,
                                                   v_OutstockNo,
                                                   strUserID,
                                                   strUserID,
                                                   v_DivideNo,
                                                   strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
      end;
    end if;

    strOutDivideNo := v_DivideNo;
    strOutLabelNo  := v_LabelNo;
    strOutMsg      := 'Y|成功！';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_CheckLabelNo;


  /*****************************************************************************************************************
  lich
  20150126
  功能说明：分播回单，RF扫描标签号校验
  ***************************************************************************************************************/
  procedure P_DivideCheckSLabelNo(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                                  strWarehouseNo  in stock_label_m.warehouse_no%type,
                                  strLabelNo      in stock_label_m.label_no%type,
                                  strOutMsg       out varchar2) is
    v_Count integer := 0;
  begin
    strOutMsg := 'N|[P_DivideCheckSLabelNo]';
    for p in (select *
                from stock_label_m slm
               where slm.enterprise_no = strEnterpriseNo
                 and slm.warehouse_no = strWarehouseNo
                 and slm.label_no = strLabelNo) loop
      v_Count := v_Count + 1;
      if p.use_type not in ('2') then
        strOutMsg := 'N|[E22514]'; --该标签号不是分播标签！
        return;
      end if;

      if p.status <> clabelstatus.PICK_END then
        strOutMsg := 'N|[E22516]'; --该标签号状态不对！
        return;
      end if;
    end loop;

    if v_Count = 0 then
      strOutMsg := 'N|[E22114]'; --该标签号不存在！
      return;
    end if;
    strOutMsg := 'Y|成功！';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_DivideCheckSLabelNo;
  /*****************************************************************************************************************
  lich
  20150126
  功能说明：分播回单，目的标签号校验
  ***************************************************************************************************************/
  procedure P_DivideCheckDLabelNo(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                                  strWarehouseNo  in stock_label_m.warehouse_no%type,
                                  strOwnerNo      in bdef_defowner.owner_no%type,
                                  strSContainerNo in stock_label_m.container_no%type, --来源标签内部容器号
                                  strDLabelNo     in stock_label_m.label_no%type,
                                  strDelvierObj   in stock_label_m.deliver_obj%type, --当前分播数据对应配送对象
                                  strCustNo       in odata_divide_d.cust_no%type,
                                  strArticleNo    in odata_divide_d.article_no%type,
                                  strOutMsg       out varchar2) is
    v_Count             integer := 0;
    v_Count1            integer := 0;
    v_Divide_FixPalS    WMS_DEFBASE.Sdefine%type; --参数的字符性值
    v_Divide_FixPalN    WMS_DEFBASE.Ndefine%type; --参数的整数值
    v_Divide_CheckWaveS WMS_DEFBASE.Sdefine%type; --参数的字符性值
    v_Divide_CheckWaveN WMS_DEFBASE.Ndefine%type; --参数的整数值
    v_Status_Type       wms_deflabel_status.status_type%type;
    v_Line_No           odata_divide_d.line_no%type;
    v_Deliver_Obj       odata_divide_d.deliver_obj%type;
    strAutoFlag         wms_deflabel_status.must_run%type := '0';
    v_exp_type          odata_divide_d.exp_type%type;
  begin
    strOutMsg := 'N|[P_DivideCheckDLabelNo]';
    --取系统参数
    PKLG_WMS_BASE.p_GetBasePara(strEnterpriseNo,
                                strWareHouseNo,
                                strOwnerNo,
                                'Divide_CheckWave',
                                'O',
                                'O_DIVIDE',
                                v_Divide_CheckWaveS,
                                v_Divide_CheckWaveN,
                                strOutMsg);
    if (substr(strOutMsg, 1, 1) = 'N') then
      return;
    end if;

    --读取源标签信息
    begin
      select odd.line_no,odd.exp_type
        into v_Line_No,v_exp_type
        from odata_divide_d odd
       where odd.article_no = strArticleNo
         and odd.cust_no = strCustNo
         and odd.deliver_obj = strDelvierObj
         and odd.s_container_no = strSContainerNo
         and odd.warehouse_no = strWarehouseNo
         and odd.enterprise_no = strEnterpriseNo
         and rownum = 1;
    exception
      when no_data_found then
        strOutMsg := 'N|[找不到对应的分播信息]';
        return;
    end;

    for p in (select *
                from stock_label_m slm
               where slm.enterprise_no = strEnterpriseNo
                 and slm.warehouse_no = strWarehouseNo
                 and slm.label_no = strDLabelNo) loop
      v_Count := v_Count + 1;
      --判断目的标签的客户与当前标签是否是同一客户
      if p.cust_no <> strCustNo then
        strOutMsg := 'N|[E22502]'; --该标签不是此客户标签！
        return;
      end if;

      if p.deliver_obj <> strDelvierObj THEN
        strOutMsg := 'N|[配送对象不一致]'; --该标签不是此客户标签！
        return;
      end if;

      if p.use_type <> '1' then
        strOutMsg := 'N|[目的标签必须为客户标签]'; --该标签不是此客户标签！
        return;
      end if;

      PKOBJ_HB.p_GetLabelStatusFromWorkflow(strEnterPriseNo,
                                            strWarehouseNo,
                                            strOwnerNo,
                                            v_exp_type,
                                            strSContainerNo,
                                            v_Status_Type,
                                            strAutoFlag,
                                            strOutMsg);
      if (substr(strOutMsg, 1, 1) = 'N') then
        return;
      end if;

      --若存在，必须是当前待分播的客户标签；标签状态可为60（新取号，不做配送对象、线路、波次一致性的校验）
      if p.status <> v_Status_Type AND
         p.status <> clabelstatus.NEW_LABEL_NO then
        strOutMsg := 'N|[该标签状态不在下一个工作流范围内]'; --该标签状态不在下一个工作流范围内！
        return;
      end if;
      --目的标签的配送对象和当前分播数据的配送对象、线路必须一致；
      if p.status = clabelstatus.NEW_LABEL_NO and p.line_no <> v_Line_No and
         p.deliver_obj <> v_Deliver_Obj then
        strOutMsg := 'N|[该标签状态不在下一个工作流范围内]'; --该标签状态不在下一个工作流范围内！
        return;
      end if;

      --读取系统参数Divide_CheckWave，若参数为0，目的标签的波次需跟当前标签一致，若参数为1，可不一致。
      if (v_Divide_CheckWaveS = '0' AND
         p.status <> CLabelStatus.NEW_LABEL_NO) THEN
        SELECT count(*)
          INTO v_Count1
          from stock_label_m slm, stock_label_d sld
         where slm.warehouse_no = sld.warehouse_no
           and slm.enterprise_no = sld.enterprise_no
           and slm.container_no = sld.container_no
           and slm.container_type = sld.container_type
           and slm.warehouse_no = strWarehouseNo
           and slm.enterprise_no = strEnterpriseNo
           and slm.container_no = strSContainerNo
           and sld.wave_no not in
               (select b.wave_no
                  from stock_label_d b
                 where b.container_no = p.container_no
                   and b.warehouse_no = p.warehouse_no
                   and b.enterprise_no = p.enterprise_no);
        if v_Count1 > 0 then
          strOutMsg := 'N|[源标签号与目的标签号波次不一样]'; --源标签号与目的标签号波次不一样！
          return;
        end if;
      END IF;
    end loop;

    --标签不存在，检查库存里是否有此标签，若有，拦截；
    if v_Count = 0 then
      select count(* ） into v_Count1 from stock_content a where a.label_no = strDLabelNo and a.warehouse_no = strWarehouseNo and a.enterprise_no = strEnterpriseNo;
      if v_Count1 > 0 then
        strOutMsg := 'N|[该标签已被占用！]'; --该标签已被占用！
        return;
      else
        --若库存不存在此标签，根据系统参数Divide_FixPal，若参数设置为0，系统给予拦截
        --取系统参数
        PKLG_WMS_BASE.p_GetBasePara(strEnterpriseNo,
                                    strWareHouseNo,
                                    strOwnerNo,
                                    'Divide_FixPal',
                                    'O',
                                    'O_DIVIDE',
                                    v_Divide_FixPalS,
                                    v_Divide_FixPalN,
                                    strOutMsg);
        if (substr(strOutMsg, 1, 1) = 'N') then
          return;
        end if;

        if v_Divide_FixPalS = '0' then
          strOutMsg := 'N|[此标签不存在！]'; --此标签不存在！
          return;
        end if;
      end if;
    end if;
    strOutMsg := 'Y|成功！';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_DivideCheckDLabelNo;

  /**************************************************************************************************88
  功能说明：装并板的来源标签的校验
  1、只有客户标签才能并板；
  2、已装并板状态的标签不能并板；
  4、A1状态的标签不能并板
  5、已存在并板标签的标签不能并板
  ***********************************************************************************************/
  procedure P_MergePal_Slabel_Check(strEnterpriseNo in stock_label_m.enterprise_no%type,
                                    strWarehouseNo  in stock_label_m.warehouse_no%type,
                                    strLabelNo      in stock_label_m.label_no%type, --来源标签
                                    strLabelType    in stock_label_m.use_type%type, --1：源标签，2：目的标签（往上放货的容器）
                                    strStatus       out stock_label_m.status%type,
                                    strCustNo       out stock_label_m.cust_no%type,
                                    strOutMsg       out varchar2) is
    v_strUseType          stock_label_m.use_type%type;
    v_strOwnerContainerNo stock_label_m.owner_container_no%type;
    v_strContainerNo      stock_label_m.container_no%type;
    v_iCount              integer;
  begin
    strOutMsg := 'N|[P_MergePal_Slabel_Check]';

    begin
      select slm.status,
             slm.use_type,
             slm.cust_no,
             slm.owner_container_no,
             slm.container_no
        into strStatus,
             v_strUseType,
             strCustNo,
             v_strOwnerContainerNo,
             v_strContainerNo
        from stock_label_m slm
       where slm.enterprise_no = strEnterpriseNo
         and slm.warehouse_no = strWarehouseNo
         and slm.label_no = strLabelNo;
    exception
      when no_data_found then
        if strLabelType = '1' then
          strOutMsg := 'N|[此标签不存在]';
          return;
        else
          strOutMsg := 'Y|[成功]'; --新标签在系统里不存在，不做拦截
          return;
        end if;
    end;

    select count(*)
      into v_iCount
      from stock_label_d sld
     where sld.enterprise_no = strEnterpriseNo
       and sld.warehouse_no = strWarehouseNo
       and sld.container_no = v_strContainerNo;

    if v_strOwnerContainerNo <> v_strContainerNo and v_iCount = 0 then
      strOutMsg := 'N|[被并板的标签，不允许并板]';
      return;
    end if;

    if v_strUseType <> '1' then
      strOutMsg := 'N|[不是客户标签，不允许并板]';
      return;
    end if;

    if strStatus = CLabelStatus.PICK_HAND_OUT then
      strOutMsg := 'N|[拣货发单状态的标签，不允许并板]';
      return;
    end if;

    if strStatus = CLabelStatus.HasRelevanceBox then
      strOutMsg := 'N|[拣货中状态的标签，不允许并板]';
      return;
    end if;
    /*       if strStatus=CLabelStatus.LOADED_IN_PAL and  strLabelType='2' then
       strOutMsg:='N|[已装并板的标签，不允许并板]';
       return;
    end if;*/

    if strStatus = CLabelStatus.NEW_LABEL_NO and strLabelType = '1' then
      strOutMsg := 'N|[新取号的标签，不允许并板]';
      return;
    end if;

    if strStatus = CLabelStatus.LOADED_IN_CAR then
      strOutMsg := 'N|[已装车的标签，不允许并板]';
      return;
    end if;

    if strStatus = CLabelStatus.WAIT_TURN_AREA then
      strOutMsg := 'N|[已转问题区的标签，不允许并板]';
      return;
    end if;

    strOutMsg := 'Y|[]';

  end P_MergePal_Slabel_Check;

  /*****************************************************************************************
   功能：校验源标签是否可并板到目的标签
  *****************************************************************************************/
  procedure P_Check_Mergelabel(strEnterpriseNo in stock_label_m.enterprise_no%type, --仓别
                               strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                               strSLabelNo     in stock_label_m.label_no%type, --原标签
                               strDLabelNo     in stock_label_m.label_no%type, --目的标签
                               strStatus       out stock_label_m.status%type, --目的标签状态
                               strCustNo       out stock_label_m.cust_no%type, --目的标签对应的客户
                               strResult       out varchar2) is
    v_sDeliverObj      stock_label_m.deliver_obj%type; --源容器配送对象
    v_dDeliverObj      stock_label_m.deliver_obj%type; --目的容器配送对象
    v_sStatus          stock_label_m.status%type; --源容器状态
    v_sUseType         stock_label_m.use_type%type; --源容器标签
    v_dUseType         stock_label_m.use_type%type; --目的容器标签
    v_sLineNo          stock_label_m.line_no%type; --源容器线路
    v_dLineNo          stock_label_m.line_no%type; --目的容器线路
    v_dContainerType   stock_label_m.container_type%type; --目的容器类型
    v_sBatchNo         stock_label_m.batch_no%type; --源容器批次
    v_dBatchNo         stock_label_m.batch_no%type; --目的容器批次
    v_sWaveNo          stock_label_d.wave_no%type; --源容器的波此
    v_dWaveNo          stock_label_d.wave_no%type; --目的容器的波此
    v_strSourceNo      stock_label_m.source_no%type;
    v_deliverArea      stock_label_m.deliver_area%type;
    v_ownerCellNo      stock_label_m.owner_cell_no%type;
    v_trunckCellNo     stock_label_m.trunck_cell_no%type;
    v_AsorterChuteNo   stock_label_m.a_sorter_chute_no%type;
    v_checkChuteNo     stock_label_m.check_chute_no%type;
    v_rgstName         stock_label_m.rgst_name%type;
    v_reportId         stock_label_m.report_id%type;
    v_ownerContainerNo stock_label_m.owner_container_no%type;
    v_sContainerNo     stock_label_m.container_no%type;
    v_dContainerNo     stock_label_m.container_no%type;

    v_strDeliverObj        stock_label_m.deliver_obj%type;
    v_strCustNo            stock_label_m.cust_no%type;
    v_strOwnerCellNo       stock_label_m.owner_cell_no%type;
    v_nDetailCount         number;
    v_strArrangeCheckBatch varchar2(20);
    v_nArrangeCheckBatch   number(10);
    v_strArrangeCheckWave  varchar2(20);
    v_nArrangeCheckWave    number(10);
    v_strArrangeFixPal     varchar2(20);
    v_nArrangeFixPal       number(10);
    v_strOutMsg            varchar2(256);

    v_strLabelNoTmp   stock_label_m.label_no%type;
    v_strDcontainerNo stock_label_m.container_no%type;
    v_strSessionId    varchar2(256);

  begin

    --源标签号和目的标签号不允许相同
    if strSLabelNo = strDLabelNo then
      strResult := 'N|[E23222]';
      return;
    end if;

    --获取来源容器的配送对象和状态
    begin
      select slm.deliver_obj,
             slm.status,
             slm.use_type,
             slm.line_no,
             slm.deliver_obj,
             slm.cust_no,
             slm.owner_cell_no,
             slm.batch_no,
             slm.source_no,
             slm.deliver_area,
             slm.owner_cell_no,
             slm.trunck_cell_no,
             slm.a_sorter_chute_no,
             slm.check_chute_no,
             slm.rgst_name,
             slm.report_id,
             slm.owner_container_no,
             slm.container_no
        into v_sDeliverObj,
             v_sStatus,
             v_sUseType,
             v_sLineNo,
             v_strDeliverObj,
             v_strCustNo,
             v_strOwnerCellNo,
             v_sBatchNo,
             v_strSourceNo,
             v_deliverArea,
             v_ownerCellNo,
             v_trunckCellNo,
             v_AsorterChuteNo,
             v_checkChuteNo,
             v_rgstName,
             v_reportId,
             v_ownerContainerNo,
             v_sContainerNo
        from stock_label_m slm
       where slm.warehouse_no = strWarehouseNo
         and slm.enterprise_no = strEnterpriseNo
         and slm.label_no = strSLabelNo;
    exception
      when no_data_found then
        strResult := 'N|[E23207]'; --无此容器号
        return;
    end;

    --查询原容器是否有明细
    begin
      select count(1)
        into v_nDetailCount
        from stock_label_d sld
       where sld.enterprise_no = strEnterpriseNo
         and sld.warehouse_no = strWarehouseNo
         and sld.container_no = v_sContainerNo;
    exception
      when no_data_found then
        strResult := 'N|[E23210]'; --源容器号无明细
        return;
    end;

    --获取源容器号的波此号
    begin
      select distinct sld.wave_no
        into v_sWaveNo
        from stock_label_d sld
       where sld.warehouse_no = strWarehouseNo
         and sld.enterprise_no = strEnterpriseNo
         and sld.container_no = v_sContainerNo
         and rownum = 1;
    exception
      when no_data_found then
        strResult := 'N|[E23207]'; --无此容器号
        return;
    end;

    --获取目的容器的配送对象和状态和容器标签和目的容器类型
    begin
      select slm.deliver_obj,
             slm.status,
             slm.use_type,
             slm.container_type,
             slm.line_no,
             slm.batch_no,
             slm.container_no,
             slm.cust_no
        into v_dDeliverObj,
             strStatus,
             v_dUseType,
             v_dContainerType,
             v_dLineNo,
             v_dBatchNo,
             v_dContainerNo,
             strCustNo
        from stock_label_m slm
       where slm.warehouse_no = strWarehouseNo
         and slm.enterprise_no = strEnterpriseNo
         and slm.label_no = strDLabelNo;

      --容器整理时,同一客户不同批次的商品是否可整理到一个容器内。0：不允许；1：允许
      PKLG_WMS_BASE.p_GetBasePara(strEnterpriseNo,
                                  strWareHouseNo,
                                  'N',
                                  'Arrange_CheckBatch',
                                  'O',
                                  'O_ARRANGE',
                                  v_strArrangeCheckBatch,
                                  v_nArrangeCheckBatch,
                                  v_strOutMsg);
      if substr(v_strOutMsg, 1, 1) = 'N' then
        strResult := 'N|[E23214]';
        return;
      end if;

      --获取系统参数
      --容器整理时,不同波次的商品是否可整理到一个容器内。0：不允许；1：允许
      PKLG_WMS_BASE.p_GetBasePara(strEnterpriseNo,
                                  strWareHouseNo,
                                  'N',
                                  'Arrange_CheckWave',
                                  'O',
                                  'O_ARRANGE',
                                  v_strArrangeCheckWave,
                                  v_nArrangeCheckWave,
                                  v_strOutMsg);
      if substr(v_strOutMsg, 1, 1) = 'N' then
        strResult := 'N|[E23214]';
        return;
      end if;

      --获取目的容器号的波此号
      if strStatus <> CLabelStatus.NEW_LABEL_NO then
        begin
          select distinct sld.wave_no
            into v_dWaveNo
            from stock_label_d sld
           where sld.warehouse_no = strWarehouseNo
             and sld.enterprise_no = strEnterpriseNo
             and sld.container_no = v_dContainerNo
             and rownum = 1;

        exception
          when no_data_found then
            strResult := 'N|[E23207]'; --无此容器号
            return;
        end;

        if v_strArrangeCheckWave = '0' then
          if v_sWaveNo <> v_dWaveNo then
            strResult := 'N|[E23220]'; --不同波次的商品不允许整理到一个容器内
            return;
          end if;
        end if;
      end if;

      --判断来源容器号的配送对象和目的容器号的配送对象是否不一至
      if v_sDeliverObj <> v_dDeliverObj then
        strResult := 'N|[E23201]'; --配送对象不一至
        return;
      else
        if v_strArrangeCheckBatch = '0' then
          if v_sBatchNo <> v_dBatchNo then
            strResult := 'N|[E23221]'; --同一客户不同批次的商品不允许整理到一个容器内
            return;
          end if;
        end if;
      end if;
      if v_sUseType <> 1 or v_dUseType <> 1 then
        strResult := 'N|[E23208]'; --标签状态必须要为客户标签
        return;
      end if;
      if v_sLineNo <> v_dLineNo then
        strResult := 'N|[E23209]'; --源容器线路要与目的容器线路相等
        return;
      end if;

      if v_dContainerType = 'C' and v_dContainerType = 'B' then
        strResult := 'N|[E23204]'; --目的容器的容器类型不能等于C
        return;
      end if;

      if v_sStatus = CLabelStatus.OUTER_CHECKING or
         strStatus = CLabelStatus.OUTER_CHECKING then
        --'6D'
        strResult := 'N|[E23205]'; --源容器号的状态与目的容器号的状态都不能为6D
        return;
      end if;
      if v_sStatus = CLabelStatus.WAIT_TURN_AREA or
         strStatus = CLabelStatus.WAIT_TURN_AREA then
        --'90'
        strResult := 'N|[E23223]'; --标签状态不能为已转区
        return;
      end if;
      if v_sStatus = ClabelStatus.LOADED_IN_CAR or
         strStatus = ClabelStatus.LOADED_IN_CAR then
        --'A1'
        strResult := 'N|[E23224]'; --标签状态不能为已装车
        return;
      end if;

    exception
      when no_data_found then
        --判断是否可新取号

        --目的容器若在系统不存在，是否需要新产生标签号。0--不产生标签号；1---产品标签
        PKLG_WMS_BASE.p_GetBasePara(strEnterpriseNo,
                                    strWareHouseNo,
                                    'N',
                                    'Arrange_FixPal',
                                    'O',
                                    'O_ARRANGE',
                                    v_strArrangeFixPal,
                                    v_nArrangeFixPal,
                                    v_strOutMsg);
        if substr(v_strOutMsg, 1, 1) = 'N' then
          strResult := 'N|[E23214]';
          return;
        end if;

        if v_strArrangeFixPal = 1 then
          pklg_wms_base.p_get_ContainerNoBase(strEnterpriseNo,
                                              strWarehouseNo,
                                              'P',
                                              '',
                                              'D',
                                              1,
                                              '2',
                                              '31',
                                              v_strLabelNoTmp,
                                              v_strDcontainerNo,
                                              v_strSessionId,
                                              v_strOutMsg);
          if (substr(v_strOutMsg, 1, 1) = 'N') then
            return;
          end if;

          pkobj_label.proc_Insert_LabelMaster(strEnterpriseNo,
                                              strWarehouseNo,
                                              v_sBatchNo,
                                              v_strSourceNo,
                                              strDLabelNo,
                                              v_strDcontainerNo,
                                              'P',
                                              v_deliverArea,
                                              v_ownerCellNo,
                                              v_strCustNo,
                                              v_trunckCellNo,
                                              v_AsorterChuteNo,
                                              v_checkChuteNo,
                                              v_sDeliverObj,
                                              v_sUseType,
                                              v_sLineNo,
                                              'N',
                                              'N',
                                              v_rgstName,
                                              v_reportId,
                                              'N',
                                              'N',
                                              '1',
                                              '0',
                                              v_strDcontainerNo,
                                              ClabelStatus.NEW_LABEL_NO,
                                              '0',
                                              v_sWaveNo,
                                              v_strOutMsg);
          if (substr(v_strOutMsg, 1, 1) = 'N') then
            return;
          end if;

          strStatus := ClabelStatus.NEW_LABEL_NO;

          strResult := 'Y|[成功]';
          return;
        else
          strResult := 'N|[E23207]';
        end if;

    end;
    strResult := 'Y|[成功]'; --成功
  end P_Check_MergelabeL;

end pkcheck_odata;

/

