create package        PKLG_ODATA_COLLECTGOODS IS

    /*****************************************************************************************
     功能：集货作业（入库，出库）扫描PONO
     ADD BY SUNL 20160715
  *****************************************************************************************/
  PROCEDURE P_COLLECTGOODS_SCANPONO(STRENTERPRISENO IN ODATA_PACKAGE_M.ENTERPRISE_NO%TYPE, --企业
                                    STRWAREHOUSENO  IN ODATA_PACKAGE_M.WAREHOUSE_NO%TYPE, --仓别
                                    STRPONO         IN ODATA_PACKAGE_M.PO_NO%TYPE, --提单号
                                    STRTYPE         IN VARCHAR2, --类型: 1，入库；2：出库
                                    STROWNERNO      OUT ODATA_PACKAGE_M.OWNER_NO%TYPE, --货主(RF上获取不到！)
                                    STRRESULT       OUT VARCHAR2);


  /*****************************************************************************************
     功能：集货作业（入库，出库）扫描 SOURCEEXPNO
     ADD BY SUNL 20160715
  *****************************************************************************************/
  PROCEDURE P_COLLECTGOODS_SCANSOURCEEXPNO(STRENTERPRISENO IN ODATA_PACKAGE_M.ENTERPRISE_NO%TYPE, --企业
                                           STRWAREHOUSENO  IN ODATA_PACKAGE_M.WAREHOUSE_NO%TYPE, --仓别
                                           STROWNERNO      IN ODATA_PACKAGE_M.OWNER_NO%TYPE, --货主
                                           STRPONO         IN ODATA_PACKAGE_M.PO_NO%TYPE, --提单号
                                           STRSOURCEEXPNO  IN ODATA_PACKAGE_D.SOURCEEXP_NO%TYPE, --订单号
                                           STRUpdt_Name    IN ODATA_PACKAGE_D.Updt_Name%TYPE, --操作人
                                           STRTYPE         IN VARCHAR2, --类型: 1，入库；2：出库
                                           STRRESULT       OUT VARCHAR2) ;

  /*****************************************************************************************
     功能：集货作业（入库，出库）整单确认 CONFIRMPONO
     ADD BY CZH 20160829
  *****************************************************************************************/
  PROCEDURE P_COLLECTGOODS_CONFIRMPONO(STRENTERPRISENO IN ODATA_PACKAGE_M.ENTERPRISE_NO%TYPE, --企业
                                           STRWAREHOUSENO  IN ODATA_PACKAGE_M.WAREHOUSE_NO%TYPE, --仓别
                                           STROWNERNO      IN ODATA_PACKAGE_M.OWNER_NO%TYPE, --货主
                                           STRPONO         IN ODATA_PACKAGE_M.PO_NO%TYPE, --提单号
                                           STRUpdt_Name    IN ODATA_PACKAGE_D.Updt_Name%TYPE, --操作人
                                           STRTYPE         IN VARCHAR2, --类型: 1，入库；2：出库
                                           STRRESULT       OUT VARCHAR2);
end PKLG_ODATA_COLLECTGOODS;


/

