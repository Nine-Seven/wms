create view V_SEARCH_9109_003 as
select i."ENTERPRISE_NO",i."WAREHOUSE_NO",i."WORKER_NO",i."WORKER_NAME",i."OPERATE_DATE",i."SUMQTY",i."STARTTIME",i."ENDTIME",floor((endtime - starttime) * 24 * 60) -
       case when to_char(starttime,'hh24:mi:ss') >= '13:00:00'  then 0 else
       case when to_char(endtime,'hh24:mi:ss') <= '12:30:00' then 0 else 90 end end
       as work_duration,
       floor(((sum(sumqty) over (partition by worker_no,operate_date))/(floor((endtime - starttime) * 24 * 60) + 1 -
       case when to_char(starttime,'hh24:mi:ss') >= '13:00:00'  then 0 else
       case when to_char(endtime,'hh24:mi:ss') <= '12:30:00' then 0 else 90 end end))*60) qty_per_hour from
(select t.enterprise_no,
               t.warehouse_no,
               t.worker_no,
       t.worker_name,
       t.operate_date,
       t.sumqty,
       min(starttime) over (partition by t.worker_no,t.operate_date) as starttime,
       max(endtime) over (partition by t.worker_no,t.operate_date) as endtime
  from (select icd.enterprise_no,
               icd.warehouse_no,
               b.worker_no,
               b.worker_name,
               trunc(icd.updt_date) as operate_date,
               min(icd.updt_date) starttime,
               max(icd.updt_date) endtime,
               sum(icd.check_qty) as sumqty
          from idata_check_pal icd, bdef_defworker b,bdef_defarticle bda
         WHERE bda.enterprise_no=icd.enterprise_no
         and bda.article_no=icd.article_no
         and b.enterprise_no=icd.enterprise_no
         and b.worker_no = icd.updt_name
         and icd.status<>'16'
         group by icd.enterprise_no,icd.warehouse_no,b.worker_no, b.worker_name, trunc(icd.updt_date)
         having sum(icd.check_qty)>0) t) i
 order by worker_no,operate_date

/

