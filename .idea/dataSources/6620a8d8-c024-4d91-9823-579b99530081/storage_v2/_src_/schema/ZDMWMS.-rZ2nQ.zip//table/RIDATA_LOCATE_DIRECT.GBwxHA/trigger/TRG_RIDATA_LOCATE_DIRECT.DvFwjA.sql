create trigger TRG_RIDATA_LOCATE_DIRECT
    before insert
    on RIDATA_LOCATE_DIRECT
    for each row
declare
i_id integer;
begin
select SEQ_IDATA_LOCATE_DIRECT.nextval into i_id from dual;
:NEW.ROW_ID := i_id;
end;


/

