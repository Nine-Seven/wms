create package body        PKLG_ROLOCATE is

  /******************************************************************************************************************
   创建人：lizhiping
   创建时间：2016.1.8
   功能：退货区分播资源试算
  ****************************************************************************************************************/
  PROCEDURE p_allot_dpscell(strEnterPriseNo in rodata_recede_m.enterprise_no%type,
                               strWareHouseNo  in rodata_recede_m.warehouse_no%type,
                               strWaveNo       in rodata_recede_m.wave_no%type, --返回的波次号
                               strClassType    in rodata_recede_m.class_type%type, --0：清场
                               strUserId       in rodata_recede_m.rgst_name%type,
                               strResult       out varchar2) is

     v_strLocateNo   rodata_outstock_direct.locate_no%type;
     v_nBatchNo      rodata_outstock_direct.batch_no%type;

     v_strWaveType  Bset_wave_manage.Wave_Type%type;
     v_strDeviceNo         device_divide_m.device_no%type;
     v_strDpsCellNo     cdef_defcell.cell_no%type;
   begin
     strResult := 'Y|';

     select decode(strClassType,'0','3') into
     v_strWaveType from dual;
     --锁定波次表,防止分配资源时，其它功能对该表做结案
    update Bset_wave_manage bwm set bwm.status=bwm.status
         where bwm.wave_type=v_strWaveType and bwm.status='0'
          and bwm.enterprise_no=strEnterPriseNo and  bwm.warehouse_no=strWareHouseNo ;

    --取有效的最大波次号
    select  nvl(max(wave_no),'0') into v_strLocateNo from Bset_wave_manage bwm where bwm.wave_type=v_strWaveType and bwm.status='0'
    and bwm.enterprise_no=strEnterPriseNo and  bwm.warehouse_no=strWareHouseNo ;

    --取最大波次对应的最大批次号
    select nvl(max(curr_batch),0) into v_nBatchNo from Bset_wave_manage bwm where bwm.wave_type=v_strWaveType and bwm.status='0'
           and bwm.enterprise_no=strEnterPriseNo and  bwm.warehouse_no=strWareHouseNo
           and wave_no =v_strLocateNo   ;

     --设备波次值：'1：直通验收波次;2：出货定位波次；3：清场（返配）电子标签分播波次；4：质量（返配）波次；5：滞销（返配）波次；6：过季（返配）波次。';

     for v_csGetDirect in (select distinct rod.owner_no,rod.supplier_no,decode(strClassType,'0',bda.rsv_attr2,'N') as style
        from rodata_outstock_direct rod,bdef_defarticle bda
       where bda.enterprise_no = rod.enterprise_no
         and bda.article_no = rod.article_no
         and rod.enterprise_no = strEnterPriseNo
         and rod.warehouse_no = strWareHouseNo
         and rod.wave_no = strWaveNo) loop

         pkobj_ridata.p_allot_supp_dpscell(strEnterPriseNo,strWareHouseNo,v_strLocateNo,v_nBatchNo,v_strDeviceNo,
         v_strDpsCellNo,v_strWaveType,
                               v_csGetDirect.owner_no,v_csGetDirect.supplier_no,v_csGetDirect.style,strUserId,strResult);
          if substr(strResult,1,1) = 'N' then
                strResult := 'N|[E24222]';
                return;
          end if;

         update rodata_outstock_direct t set t.device_no=v_strDeviceNo,t.locate_no=v_strLocateNo,
         t.dps_cell_no=v_strDpsCellNo,t.batch_no=v_nBatchNo
         where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWarehouseNo
         and t.wave_no=strWaveNo and t.supplier_no=v_csGetDirect.supplier_no
         and t.article_no in(select bd.article_no from bdef_defarticle bd
         where bd.enterprise_no=strEnterPriseNo and bd.supplier_no=v_csGetDirect.supplier_no
         and bd.rsv_attr2=v_csGetDirect.style)
         and t.status='10' and t.label_pick_flag='1';
    end loop;

   exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
   end p_allot_dpscell;
  /******************************************************************************************************************
   创建人：luozhiling
   创建时间：2013.11.21特殊版，天天惠特有流程
   功能：1、退货定位
         2、退货发单
  ****************************************************************************************************************/
  PROCEDURE P_Special_LOCATEAndTask(strEnterPriseNo in rodata_recede_m.enterprise_no%type,
                               strWareHouseNo  in rodata_recede_m.warehouse_no%type,
                               strOwnerNo      in rodata_recede_m.owner_no%type,
                               strRecedeNo     in rodata_recede_m.recede_no%type,
                               strSupplierNo   in rodata_recede_m.supplier_no%type, --若供应商为空，程序内取供应商
                               strClassType    in rodata_recede_m.class_type%type, --0：清场
                               strUserId       in rodata_recede_m.rgst_name%type,
                               strDockNo       in bdef_defdock.dock_no%type,
                               strDestCellNo   in cdef_defcell.cell_no%type,--指定目的储位定位，目前用于第一次快速清场的流程
                               strWaveNo       out rodata_recede_m.wave_no%type, --返回的波次号
                               strResult       out varchar2) is
    strOldWaveNo    rodata_recede_m.wave_no%type;
    v_iCount        integer;
    v_strSupplierNo rodata_recede_m.supplier_no%type;
    v_strRecedeType rodata_recede_m.recede_type%type;
    v_strSendPrintFlag wms_warehouse_rodataorder.sendprint_type%type; --打印标识，0：不打印，1：打表单，2，打标签，3,表单标签同时打印
   begin
    strResult := 'N|[P_Special_LOCATEAndTask]';
    ---
    select supplier_no,recede_type
      into v_strSupplierNo,v_strRecedeType
      from rodata_recede_m
     where enterprise_no = strEnterPriseNo
       and warehouse_no = strWareHouseNo
       and recede_no = strRecedeNo;

    update rodata_recede_m t set t.rsv_varod1='0'
    where t.enterprisE_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo
    and t.recede_no=strRecedeNo;

    --
    P_OverQtyDeal(strEnterPriseNo,strWareHouseNo,strOwnerNo,strRecedeNo,v_strRecedeType,strResult);

    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;


    if strClassType='0' then --清场流程的定位
        P_SPECIAL_LOCATE_Main(strEnterPriseNo,strWareHouseNo,strOwnerNo,
                        strRecedeNo,'1',strUserId,'N',strDestCellNo,strWaveNo,strResult);

        if substr(strResult, 1, 1) = 'N' then
          return;
        end if;
    else       --正常流程的定位
        P_RODATA_LOCATE_Main(strEnterPriseNo,strWareHouseNo,strOwnerNo,
                        strRecedeNo,'1',strUserId,'N',strWaveNo,strResult);

        if substr(strResult, 1, 1) = 'N' then
          return;
        end if;
    end if;

    --质量问题商品特殊处理

    if strClassType='2' THEN--强制表单拣货
       update rodata_outstock_direct t set t.LABEL_PICK_FLAG='1'
       where t.enterprise_no=strEnterPriseNo
         and t.warehouse_no = strWareHouseNo
         and t.wave_no = strWaveNo and t.class_type='2'
         and t.source_no=strRecedeNo and t.label_pick_flag='2';
    end if;

    --读取退货的打印配置
    --根据货主仓别级别对应的单据类型获取是否需要混单验收的标识
    begin
      select sendPrint_type
        into v_strSendPrintFlag
        from wms_warehouse_rodataorder
       where enterprise_no = strEnterPriseNo
         and warehouse_no = strWareHouseNo
         and owner_no = strOwnerNo
         and recede_type = v_strRecedeType;
    exception
      when no_data_found then
        --获取货主级别对应的标识
        begin
          select sendPrint_type
            into v_strSendPrintFlag
            from wms_owner_rodataorder
           where enterprise_no = strEnterPriseNo
             and owner_no = strOwnerNo
             and recede_type = v_strRecedeType;
        exception
          when no_data_found then
            --获取系统级别对应的标识
            begin
              select sendPrint_type
                into v_strSendPrintFlag
                from wms_rodataorder
               where enterprise_no = strEnterPriseNo
                 and recede_type = v_strRecedeType;
            exception
              when no_data_found then
                strResult := 'N|[找不到对应的单据配置]';
                return;
            end;
        end;
    end;

    if strClassType = '0' then
      select count(*)
        into v_iCount
        from rodata_outstock_direct ood
       where ood.enterprise_no = strEnterPriseNo
         and ood.warehouse_no = strWareHouseNo
         and ood.wave_no = strWaveNo
         and ood.label_pick_flag = '2'
         and ood.status = '10';

      if v_iCount > 0 then
        --清场商品，对于标签库存需系统自动发单回单
        --拣货发单
        --读取退货下架指示
        for GetOutstockDirect in(select distinct ood.recede_type,ood.supplier_no,ood.source_no,ood.locate_no,
            ood.device_no,ood.batch_no from rodata_outstock_direct ood
            where ood.enterprise_no=strEnterPriseNo and ood.warehouse_no=strWareHouseNo
            and ood.wave_no=strWaveNo and ood.label_pick_flag='2' and ood.status='10'
            and ood.supplier_no=v_strSupplierNo and ood.source_no=strRecedeNo)loop

            pklg_rodata.P_CleanOutStock(strEnterPriseNo,
                                            strWareHouseNo,
                                            strOwnerNo,
                                            strWaveNo,
                                            v_strRecedeType,
                                            v_strSupplierNo,
                                            strClassType,
                                            strRecedeNo,
                                            strUserId,'1','2',GetOutstockDirect.device_no,GetOutstockDirect.locate_no,
                                            GetOutstockDirect.batch_no,strDockNo,v_strSendPrintFlag,
                                            strResult);

            if substr(strResult, 1, 1) = 'N' then
              return;
            end if;
        end loop;

      end if;
    end if;

    select count(*)
      into v_iCount
      from rodata_outstock_direct ood
     where ood.enterprise_no = strEnterPriseNo
       and ood.warehouse_no = strWareHouseNo
       and ood.wave_no = strWaveNo
       and ood.status = '10';

    if v_iCount > 0 then
       pklg_rodata.P_GetTaskRooutstock(strEnterPriseNo,
                                        strWareHouseNo,
                                        strOwnerNo,
                                        strWaveNo,v_strRecedeType,
                                        v_strSupplierNo,
                                        strClassType,
                                        strRecedeNo,
                                        strDockNo,
                                        strUserId,
                                        strUserId,'C',v_strSendPrintFlag,
                                        strResult);

        if substr(strResult, 1, 1) = 'N' then
          return;
        end if;
    end if;
  end P_Special_LOCATEAndTask;
  /******************************************************************************************************************
   创建人：luozhiling
   创建时间：2013.11.21标准版，目前适用于共速达、罗牛山、大连铁越
   功能：1、退货定位
         2、退货发单
  ****************************************************************************************************************/
  PROCEDURE P_RODATA_LOCATEAndTask(strEnterPriseNo in rodata_recede_m.enterprise_no%type,
                               strWareHouseNo  in rodata_recede_m.warehouse_no%type,
                               strOwnerNo      in rodata_recede_m.owner_no%type,
                               strRecedeNo     in rodata_recede_m.recede_no%type,
                               strSupplierNo   in rodata_recede_m.supplier_no%type, --若供应商为空，程序内取供应商
                               strClassType    in rodata_recede_m.class_type%type, --0：清场
                               strUserId       in rodata_recede_m.rgst_name%type,
                               strDockNo       in bdef_defdock.dock_no%type,
                               strWaveNo       out rodata_recede_m.wave_no%type, --返回的波次号
                               strResult       out varchar2) is
    strOldWaveNo    rodata_recede_m.wave_no%type;
    v_iCount        integer;
    v_strSupplierNo rodata_recede_m.supplier_no%type;
    v_strRecedeType rodata_recede_m.recede_type%type;
    v_strSendPrintFlag wms_warehouse_rodataorder.sendprint_type%type; --打印标识，0：不打印，1：打表单，2，打标签，3,表单标签同时打印
  begin
    strResult := 'N|[P_RODATA_LOCATEAndTask]';

    P_RODATA_LOCATE_Main(strEnterPriseNo,strWareHouseNo,strOwnerNo,
                    strRecedeNo,'1',strUserId,'N',strWaveNo,strResult);

    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    select supplier_no,recede_type
      into v_strSupplierNo,v_strRecedeType
      from rodata_recede_m
     where enterprise_no = strEnterPriseNo
       and warehouse_no = strWareHouseNo
       and recede_no = strRecedeNo;

    --读取退货的打印配置
    --根据货主仓别级别对应的单据类型获取是否需要混单验收的标识
    begin
      select sendPrint_type
        into v_strSendPrintFlag
        from wms_warehouse_rodataorder
       where enterprise_no = strEnterPriseNo
         and warehouse_no = strWareHouseNo
         and owner_no = strOwnerNo
         and recede_type = v_strRecedeType;
    exception
      when no_data_found then
        --获取货主级别对应的标识
        begin
          select sendPrint_type
            into v_strSendPrintFlag
            from wms_owner_rodataorder
           where enterprise_no = strEnterPriseNo
             and owner_no = strOwnerNo
             and recede_type = v_strRecedeType;
        exception
          when no_data_found then
            --获取系统级别对应的标识
            begin
              select sendPrint_type
                into v_strSendPrintFlag
                from wms_rodataorder
               where enterprise_no = strEnterPriseNo
                 and recede_type = v_strRecedeType;
            exception
              when no_data_found then
                strResult := 'N|[找不到对应的单据配置]';
                return;
            end;
        end;
    end;

    select count(*)
      into v_iCount
      from rodata_outstock_direct ood
     where ood.enterprise_no = strEnterPriseNo
       and ood.warehouse_no = strWareHouseNo
       and ood.wave_no = strWaveNo
       and ood.status = '10';



    if v_iCount > 0 then
       pklg_rodata.P_GetTaskRooutstock(strEnterPriseNo,
                                        strWareHouseNo,
                                        strOwnerNo,
                                        strWaveNo,v_strRecedeType,
                                        v_strSupplierNo,
                                        strClassType,
                                        strRecedeNo,
                                        strDockNo,
                                        strUserId,
                                        strUserId,'C',v_strSendPrintFlag,
                                        strResult);

        if substr(strResult, 1, 1) = 'N' then
          return;
        end if;
    end if;
  end P_RODATA_LOCATEAndTask;

  /*************************************************************************************
  功能说明：退厂定位主程序,适用于普通的退货定位
  *************************************************************************************/
  PROCEDURE P_RODATA_LOCATE_Main(strEnterPriseNo in rodata_recede_m.enterprise_no%type,
                            strWareHouseNo  in rodata_recede_m.warehouse_no%type,
                            strOwnerNo      in rodata_recede_m.owner_no%type,
                            strRecedeNo     in rodata_recede_m.recede_no%type,
                            strFirstFlag    in rodata_recede_m.stock_type%type, --1：第一单；0：不是第一单
                            strUserId       in rodata_recede_m.rgst_name%type,
                            strOldWaveNo    in rodata_recede_m.wave_no%type, --原波次号
                            strWaveNo       out rodata_recede_m.wave_no%type, --返回的波次号
                            strResult       out varchar2) is

    v_strShortQtyType WMS_RODATAORDER.SHORTQTY_TYPE%TYPE;
    v_nStrategyID     WMS_RODATAORDER.STRATEGY_ID%TYPE;
    v_strDestCellNo stock_content.cell_no%type;
    v_nSumLocateQty             rodata_recede_d.locate_qty%type;

    v_iCount   integer;

    v_nLocateTimes              wms_rodataorder.locate_times%type;
    v_nPreLocateTimes           wms_rodataorder.locate_times%type;
    --huangb 20160511 退厂定位规格类型(0-不管规格；1-优先退厂明细规格；2-按退厂规格)
    v_nORDER_RSV03              wms_rodataorder.order_rsv03%type;
  BEGIN
    strResult := 'N|[P_RODATA_LOCATE_Main]';
    --锁退货单头
    update rodata_recede_m
       set status = status
     where enterprise_no = strEnterPriseNo
       and warehouse_no = strWareHouseNo
       and recede_no = strRecedeNo
       and status = '10';
    if sql%notfound then
      strResult := 'N|[E25004]';
      return;
    end if;

    --获取当前定位定位次数
    select t.locate_times
      into v_nPreLocateTimes
      from rodata_recede_m t
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWareHouseNo
       and t.recede_no = strRecedeNo;

    if strFirstFlag = '1' then
      --获取波次号
      PKLG_WMS_BASE.p_getsheetno(strEnterPriseNo,
                                 strWareHouseNo,
                                 CONST_DOCUMENTTYPE.ODATAWO,
                                 strWaveNo,
                                 strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;
    else
      strWaveNo := strOldWaveNo;
    end if;
    /*获取退货区暂存区*/
    begin
      select cell_no
        into v_strDestCellNo
        from cdef_defarea cd, cdef_defcell t
       where cd.enterprise_no = t.enterprise_no
         and cd.enterprise_no = strEnterPriseNo
         and cd.ware_no = t.ware_no
         and cd.area_no = t.area_no
         and t.warehouse_no = cd.warehouse_no
         and t.warehouse_no = strWareHouseNo
         and cd.area_usetype = '3'
         and cd.area_attribute = '1'
         and cd.attribute_type = '6'
            /*         and cd.area_type = '3'*/
         and rownum = 1;
    exception
      when no_data_found then
        strResult := 'N|[E25003]';
        return;
    end;

    --huangb 20160511
    /*select wo.shortqty_type, wo.strategy_id, wo.locate_times,wo.ORDER_RSV03
      into v_strShortQtyType, v_nStrategyID, v_nLocateTimes,v_nORDER_RSV03
      from rodata_recede_m rrm
     inner join WMS_RODATAORDER wo on wo.enterprise_no = rrm.enterprise_no
                                  and wo.recede_type = rrm.recede_type
     where rrm.warehouse_no = strWareHouseNo
       and rrm.enterprise_no = strEnterpriseNo
       and rrm.recede_no = strRecedeNo;*/
    begin
      select wwr.shortqty_type, wwr.strategy_id, wwr.locate_times,wwr.ORDER_RSV03
        into v_strShortQtyType, v_nStrategyID, v_nLocateTimes,v_nORDER_RSV03
        from rodata_recede_m rrm,wms_warehouse_rodataorder wwr
       where wwr.enterprise_no = rrm.enterprise_no
         and wwr.warehouse_no = rrm.warehouse_no
         and wwr.owner_no = rrm.owner_no
         and wwr.recede_type = rrm.recede_type
         and rrm.enterprise_no = strEnterpriseNo
         and rrm.warehouse_no = strWareHouseNo
         and rrm.owner_no = strOwnerNo
         and rrm.recede_no = strRecedeNo;
    exception
      when no_data_found then
        --获取货主级别对应的标识
        begin
          select wor.shortqty_type, wor.strategy_id, wor.locate_times,wor.ORDER_RSV03
            into v_strShortQtyType, v_nStrategyID, v_nLocateTimes,v_nORDER_RSV03
            from rodata_recede_m rrm,wms_owner_rodataorder wor
           where wor.enterprise_no = rrm.enterprise_no
             and wor.owner_no = rrm.owner_no
             and wor.recede_type = rrm.recede_type
             and rrm.enterprise_no = strEnterPriseNo
             and rrm.warehouse_no = strWareHouseNo
             and rrm.owner_no = strOwnerNo
             and rrm.recede_no = strRecedeNo;
        exception
          when no_data_found then
            --获取系统级别对应的标识
            begin
              select wr.shortqty_type, wr.strategy_id, wr.locate_times,wr.ORDER_RSV03
                into v_strShortQtyType, v_nStrategyID, v_nLocateTimes,v_nORDER_RSV03
                from rodata_recede_m rrm,wms_rodataorder wr
               where wr.enterprise_no = rrm.enterprise_no
                 and wr.recede_type = rrm.recede_type
                 and rrm.enterprise_no = strEnterPriseNo
                 and rrm.warehouse_no = strWareHouseNo
                 and rrm.owner_no = strOwnerNo
                 and rrm.recede_no = strRecedeNo;
            exception
              when no_data_found then
                strResult := 'N|[找不到对应的单据配置]';
                return;
            end;
        end;
    end;


    --退货定位
    P_RODATA_LOCATE(strEnterPriseNo,strWareHouseNo,strRecedeNo,strWaveNo,
        v_nStrategyID,v_strDestCellNo,strUserId,v_nORDER_RSV03,strResult);
    if substr(strResult, 1, 1) <> 'Y' then
      return;
    end if;


    --更新标签库存有剩余下架指示标签拣货标识为表单
    --若一个标签被多个退货单定位到而且未做拣货回单，且库存中库存数量=预下数量时，也更新为表单
    for p in (SELECT DISTINCT D.LABEL_NO
                FROM RODATA_OUTSTOCK_DIRECT D
               WHERE D.ENTERPRISE_NO = strEnterPriseNo
                 AND D.WAREHOUSE_NO = strWareHouseNo
                 AND D.SOURCE_NO = strRecedeNo
                 AND (EXISTS
                      (SELECT 'X'
                         FROM STOCK_CONTENT C
                        WHERE D.ENTERPRISE_NO = C.ENTERPRISE_NO
                          AND D.WAREHOUSE_NO = C.WAREHOUSE_NO
                          AND D.LABEL_NO = C.LABEL_NO
                          AND C.QTY - C.OUTSTOCK_QTY > 0) OR EXISTS
                      (SELECT 'X'
                         FROM RODATA_OUTSTOCK_DIRECT C
                        WHERE D.ENTERPRISE_NO = C.ENTERPRISE_NO
                          AND D.WAREHOUSE_NO = C.WAREHOUSE_NO
                          AND D.LABEL_NO = C.LABEL_NO
                          AND D.SOURCE_NO <> C.SOURCE_NO))) loop
      begin
        update rodata_outstock_direct t
           set t.label_pick_flag = '1'
         where t.enterprise_no = strEnterPriseNo
           and t.warehouse_no = strWareHouseNo
           and t.source_no = strRecedeNo
           and t.label_no = p.label_no
           and t.label_pick_flag = '2';
      end;
    end loop;

    --退货定位时缺量的处理方式：
    --1、有多少定多少，无后续处理；
    --2、若缺量则踢单；
    --3、有多少定多少，缺量部分可再次定位
    if v_strShortQtyType = '1' then
      v_iCount := 0;
    elsif v_strShortQtyType = '2' then
      v_iCount := 0;
    elsif v_strShortQtyType = '3' then
      v_iCount := 0;
      if v_nPreLocateTimes+1 < v_nLocateTimes then
        --更新出货通知单明细状态
        update rodata_recede_d
           set status = '10'
         where enterprise_no = strEnterPriseNo
           and warehouse_no = strWareHouseNo
           and recede_no = strRecedeNo
           and recede_qty > locate_qty;

        if sql%rowcount > 0 then
          update rodata_recede_m
             set status       = '10',
                 updt_name    = strUserId,
                 updt_datE    = sysdate,
                 wave_no      = strWaveNo,
                 locate_times = locate_times + 1
           where enterprise_no = strEnterPriseNo
             and warehouse_no = strWareHouseNo
             and recede_no = strRecedeNo
             and status = '10';
          if sql%notfound then
            strResult := 'N|[E25006]';
            return;
          end if;
          v_iCount := 1;
        end if;
      end if;

    end if;

    if v_iCount = 0 then
      update rodata_recede_m
         set status       = '14',
             updt_name    = strUserId,
             updt_datE    = sysdate,
             wave_no      = strWaveNo,
             locate_times = locate_times + 1
       where enterprise_no = strEnterPriseNo
         and warehouse_no = strWareHouseNo
         and recede_no = strRecedeNo
         and status = '10';
      if sql%notfound then
        strResult := 'N|[E25006]';
        return;
      end if;

      update rodata_recede_d
         set status = '14'
       where enterprise_no = strEnterPriseNo
         and warehouse_no = strWareHouseNo
         and recede_no = strRecedeNo;

      ----检查此单是否全部缺量
      select sum(locate_qty)
        into v_nSumLocateQty
        from rodata_recede_d
       where enterprise_no = strEnterPriseNo
         and warehouse_no = strWareHouseNo
         and recede_no = strRecedeNo;

      if v_nSumLocateQty = 0 then
        update rodata_recede_m
           set status = '13'
         where enterprise_no = strEnterPriseNo
           and warehouse_no = strWareHouseNo
           and recede_no = strRecedeNo;

        update rodata_recede_d
           set status = '13'
         where enterprise_no = strEnterPriseNo
           and warehouse_no = strWareHouseNo
           and recede_no = strRecedeNo;
      end if;

    end if;

    strResult := 'Y';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  END P_RODATA_LOCATE_Main;
 /*************************************************************************************
  功能说明：退厂定位主程序,适用于天天惠的特殊清场定位，
             第一次只能定位总仓的库存
             第二次定位清场区的库存
  *************************************************************************************/
  PROCEDURE P_SPECIAL_LOCATE_Main(strEnterPriseNo in rodata_recede_m.enterprise_no%type,
                            strWareHouseNo  in rodata_recede_m.warehouse_no%type,
                            strOwnerNo      in rodata_recede_m.owner_no%type,
                            strRecedeNo     in rodata_recede_m.recede_no%type,
                            strFirstFlag    in rodata_recede_m.stock_type%type, --1：第一单；0：不是第一单
                            strUserId       in rodata_recede_m.rgst_name%type,
                            strOldWaveNo    in rodata_recede_m.wave_no%type, --原波次号
                            strDestCellNo   in cdef_defcell.cell_no%type,--指定目的储位定位，目前用于第一次快速清场的流程
                            strWaveNo       out rodata_recede_m.wave_no%type, --返回的波次号
                            strResult       out varchar2) is

    v_strShortQtyType WMS_RODATAORDER.SHORTQTY_TYPE%TYPE;
    v_nStrategyID     WMS_RODATAORDER.STRATEGY_ID%TYPE;
    v_strDestCellNo stock_content.cell_no%type;
    v_nSumLocateQty             rodata_recede_d.locate_qty%type;

    v_iCount   integer;

    v_nLocateTimes              wms_rodataorder.locate_times%type;
    v_nPreLocateTimes           wms_rodataorder.locate_times%type;
    --huangb 20160511 退厂定位规格类型(0-不管规格；1-优先退厂明细规格；2-按退厂规格)
    v_nORDER_RSV03              wms_rodataorder.order_rsv03%type;
    v_strClassType              rodata_recede_m.class_type%type;

    v_blRelocateFlag           boolean := false;
    v_nUnLabelDirectCount      number(10);
  BEGIN
    strResult := 'N|[P_SPECIAL_LOCATE_Main]';
    --锁退货单头
    update rodata_recede_m
       set status = status
     where enterprise_no = strEnterPriseNo
       and warehouse_no = strWareHouseNo
       and recede_no = strRecedeNo
       and status = '10';
    if sql%notfound then
      strResult := 'N|[E25004]';
      return;
    end if;

    --获取当前定位定位次数
    select t.locate_times
      into v_nPreLocateTimes
      from rodata_recede_m t
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWareHouseNo
       and t.recede_no = strRecedeNo;

    if v_nPreLocateTimes=1 THEN
       update rodata_recede_d t set t.locate_qty=0 where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo
       and t.recede_no=strRecedeNo;
    end if;

    if strFirstFlag = '1' then
      --获取波次号
      PKLG_WMS_BASE.p_getsheetno(strEnterPriseNo,
                                 strWareHouseNo,
                                 CONST_DOCUMENTTYPE.ODATAWO,
                                 strWaveNo,
                                 strResult);
      if strResult <> 'Y' then
        return;
      end if;
    else
      strWaveNo := strOldWaveNo;
    end if;

    if (strDestCellNo IS NOT NULL AND strDestCellNo<>'N')
       and v_nPreLocateTimes=0 then --第一次定位且快速清场，需要回写此标识，采用退货预留字段
       v_strDestCellNo:=strDestCellNo;
       update rodata_recede_m t set t.RSV_VAROD1='1'
       where t.enterprise_no=strEnterPriseNo
       and t.warehouse_no=strWareHouseNo and t.recede_no=strRecedeNo;
    else
        /*获取退货区暂存区*/
        begin
          select cell_no
            into v_strDestCellNo
            from cdef_defarea cd, cdef_defcell t
           where cd.enterprise_no = t.enterprise_no
             and cd.enterprise_no = strEnterPriseNo
             and cd.ware_no = t.ware_no
             and cd.area_no = t.area_no
             and t.warehouse_no = cd.warehouse_no
             and t.warehouse_no = strWareHouseNo
             and cd.area_usetype = '3'
             and cd.area_attribute = '1'
             and cd.attribute_type = '6'
                /*         and cd.area_type = '3'*/
             and rownum = 1;
        exception
          when no_data_found then
            strResult := 'N|[E25003]';
            return;
        end;
    end if;

    --huangb 20160511
    /*select wo.shortqty_type, wo.locate_times,rrm.class_type
      into v_strShortQtyType, v_nLocateTimes,v_strClassType
      from rodata_recede_m rrm
     inner join WMS_RODATAORDER wo on wo.enterprise_no = rrm.enterprise_no
                                  and wo.recede_type = rrm.recede_type
     where rrm.warehouse_no = strWareHouseNo
       and rrm.enterprise_no = strEnterpriseNo
       and rrm.recede_no = strRecedeNo;*/

    begin
      select wwr.shortqty_type, wwr.locate_times, rrm.class_type,wwr.ORDER_RSV03
        into v_strShortQtyType, v_nLocateTimes, v_strClassType,v_nORDER_RSV03
        from rodata_recede_m rrm,wms_warehouse_rodataorder wwr
       where wwr.enterprise_no = rrm.enterprise_no
         and wwr.warehouse_no = rrm.warehouse_no
         and wwr.owner_no = rrm.owner_no
         and wwr.recede_type = rrm.recede_type
         and rrm.enterprise_no = strEnterpriseNo
         and rrm.warehouse_no = strWareHouseNo
         and rrm.owner_no = strOwnerNo
         and rrm.recede_no = strRecedeNo;
    exception
      when no_data_found then
        --获取货主级别对应的标识
        begin
          select wor.shortqty_type, wor.locate_times, rrm.class_type,wor.ORDER_RSV03
            into v_strShortQtyType, v_nLocateTimes, v_strClassType,v_nORDER_RSV03
            from rodata_recede_m rrm,wms_owner_rodataorder wor
           where wor.enterprise_no = rrm.enterprise_no
             and wor.owner_no = rrm.owner_no
             and wor.recede_type = rrm.recede_type
             and rrm.enterprise_no = strEnterPriseNo
             and rrm.warehouse_no = strWareHouseNo
             and rrm.owner_no = strOwnerNo
             and rrm.recede_no = strRecedeNo;
        exception
          when no_data_found then
            --获取系统级别对应的标识
            begin
              select wr.shortqty_type, wr.locate_times, rrm.class_type,wr.ORDER_RSV03
                into v_strShortQtyType, v_nLocateTimes, v_strClassType,v_nORDER_RSV03
                from rodata_recede_m rrm,wms_rodataorder wr
               where wr.enterprise_no = rrm.enterprise_no
                 and wr.recede_type = rrm.recede_type
                 and rrm.enterprise_no = strEnterPriseNo
                 and rrm.warehouse_no = strWareHouseNo
                 and rrm.owner_no = strOwnerNo
                 and rrm.recede_no = strRecedeNo;
            exception
              when no_data_found then
                strResult := 'N|[找不到对应的单据配置]';
                return;
            end;
        end;
    end;

    if v_nPreLocateTimes='0' then--定位总仓库存
       v_nStrategyID:='3' ;--暂时按总仓定位的策略写死
    else
       v_nStrategyID:='1';
    end if;
    --退货定位
    P_RODATA_LOCATE(strEnterPriseNo,strWareHouseNo,strRecedeNo,strWaveNo,
        v_nStrategyID,v_strDestCellNo,strUserId,v_nORDER_RSV03,strResult);

    if substr(strResult, 1, 1) <> 'Y' then
      return;
    end if;
    --更新标签库存有剩余下架指示标签拣货标识为表单
    --若一个标签被多个退货单定位到而且未做拣货回单，且库存中库存数量=预下数量时，也更新为表单
    for p in (SELECT DISTINCT D.LABEL_NO
                FROM RODATA_OUTSTOCK_DIRECT D
               WHERE D.ENTERPRISE_NO = strEnterPriseNo
                 AND D.WAREHOUSE_NO = strWareHouseNo
                 AND D.SOURCE_NO = strRecedeNo
                 AND (EXISTS
                      (SELECT 'X'
                         FROM STOCK_CONTENT C
                        WHERE D.ENTERPRISE_NO = C.ENTERPRISE_NO
                          AND D.WAREHOUSE_NO = C.WAREHOUSE_NO
                          AND D.LABEL_NO = C.LABEL_NO
                          AND C.QTY - C.OUTSTOCK_QTY > 0) OR EXISTS
                      (SELECT 'X'
                         FROM RODATA_OUTSTOCK_DIRECT C
                        WHERE D.ENTERPRISE_NO = C.ENTERPRISE_NO
                          AND D.WAREHOUSE_NO = C.WAREHOUSE_NO
                          AND D.LABEL_NO = C.LABEL_NO
                          AND D.SOURCE_NO <> C.SOURCE_NO))) loop
      begin
        update rodata_outstock_direct t
           set t.label_pick_flag = '1'
         where t.enterprise_no = strEnterPriseNo
           and t.warehouse_no = strWareHouseNo
           and t.source_no = strRecedeNo
           and t.label_no = p.label_no
           and t.label_pick_flag = '2';
      end;
    end loop;


    select count(1) into v_nUnLabelDirectCount
        from rodata_outstock_direct rod
        where rod.enterprise_no = strEnterPriseNo
          and rod.warehouse_no = strWareHouseNo
          and rod.source_no = strRecedeNo
          and rod.label_pick_flag = '1';
    --退货定位时缺量的处理方式：
    --1、有多少定多少，无后续处理；
    --2、若缺量则踢单；
    --3、有多少定多少，缺量部分可再次定位
    if v_strShortQtyType = '1' then
      v_iCount := 0;
    elsif v_strShortQtyType = '2' then
      v_iCount := 0;
    elsif v_strShortQtyType = '3' then
      v_iCount := 0;

      if v_nPreLocateTimes + 1 < v_nLocateTimes then
        v_blRelocateFlag := true;
      else

        if  v_nUnLabelDirectCount > 0 then
           v_blRelocateFlag := true;
        end if;

      end if;

      if v_blRelocateFlag = true then
        --更新出货通知单明细状态
        update rodata_recede_d
           set status = '10'
         where enterprise_no = strEnterPriseNo
           and warehouse_no = strWareHouseNo
           and recede_no = strRecedeNo;

        if sql%rowcount > 0 then
          update rodata_recede_m
             set status       = '10',
                 updt_name    = strUserId,
                 updt_datE    = sysdate,
                 wave_no      = strWaveNo,
                 locate_times = locate_times + 1
           where enterprise_no = strEnterPriseNo
             and warehouse_no = strWareHouseNo
             and recede_no = strRecedeNo
             and status = '10';
          if sql%notfound then
            strResult := 'N|[E25006]';
            return;
          end if;
          v_iCount := 1;
        end if;
      end if;

    end if;

    if v_iCount = 0 then
      update rodata_recede_m
         set status       = '14',
             updt_name    = strUserId,
             updt_datE    = sysdate,
             wave_no      = strWaveNo,
             locate_times = locate_times + 1
       where enterprise_no = strEnterPriseNo
         and warehouse_no = strWareHouseNo
         and recede_no = strRecedeNo
         and status = '10';
      if sql%notfound then
        strResult := 'N|[E25006]';
        return;
      end if;

      update rodata_recede_d
         set status = '14'
       where enterprise_no = strEnterPriseNo
         and warehouse_no = strWareHouseNo
         and recede_no = strRecedeNo;

      ----检查此单是否全部缺量
      select sum(locate_qty)
        into v_nSumLocateQty
        from rodata_recede_d
       where enterprise_no = strEnterPriseNo
         and warehouse_no = strWareHouseNo
         and recede_no = strRecedeNo;

      if v_nSumLocateQty = 0 then
        update rodata_recede_m
           set status = '13'
         where enterprise_no = strEnterPriseNo
           and warehouse_no = strWareHouseNo
           and recede_no = strRecedeNo;

        update rodata_recede_d
           set status = '13'
         where enterprise_no = strEnterPriseNo
           and warehouse_no = strWareHouseNo
           and recede_no = strRecedeNo;
      end if;

    end if;
          --特殊处理（只有清场流程的
    if v_nUnLabelDirectCount > 0  then

          --分播资源试算
          p_allot_dpscell(strEnterPriseNo,strWareHouseNo,strWaveNo,v_strClassType,strUserId,strResult);

          if substr(strResult, 1, 1) = 'N' then
            return;
          end if;
    end if;
    strResult := 'Y';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  END P_SPECIAL_LOCATE_Main;

  /********************************************************************************
   功能说明：根据退货类型配置的策略对退货单进行定位
   huangb 20150511 增加order_rsv03-退厂定位规格类型(0-不管规格；1-优先退厂明细规格；2-按退厂规格) 参数
   huangb 20160514 支持库存拆零
   huangb 20160527 去掉支持库存拆零
  ********************************************************************************/
  PROCEDURE P_RODATA_LOCATE(strEnterPriseNo in rodata_recede_m.enterprise_no%type,
                            strWareHouseNo  in rodata_recede_m.warehouse_no%type,
                            strRecedeNo     in rodata_recede_m.recede_no%type,
                            strWaveNo       in rodata_recede_m.wave_no%type, --返回的波次号
                            strStrategyId   in wms_rodataorder.strategy_id%type,
                            strDestCellNo   in cdef_defcell.cell_no%type,
                            strUserId       in bdef_defworker.worker_no%type,
                            strORDER_RSV03  in wms_rodataorder.order_rsv03%type, --退厂定位规格类型(0-不管规格；1-优先退厂明细规格；2-按退厂规格)
                            strResult       out varchar2) is

    v_nCurQty       rodata_recede_d.recede_qty%type; --当前定位数量
    v_nTotalQty     rodata_recede_d.recede_qty%type; --总定位量
    v_nRemainQty    rodata_recede_d.recede_qty%type; --剩余定位量

    v_iCount   integer;
    v_nCount   integer;
    v_strSql   VARCHAR2(5000);
    v_strUpSql VARCHAR2(5000);
    --退厂明细
    cursor v_GetLocateItem is
      select rrm.recede_type,
             rrm.Class_Type,
             rrm.supplier_no,
             rrm.stock_type,
             rrm.stock_value,
             rrm.org_no,
             rrm.DEPT_NO,
             rrd.*
        from rodata_recede_m rrm, rodata_recede_d rrd
       where rrm.enterprise_no = rrd.enterprise_no
         and rrm.enterprise_no = strEnterPriseNo
         and rrm.warehouse_no = rrd.warehouse_no
         and rrm.owner_no = rrd.owner_no
         and rrm.recede_no = rrd.recede_no
         and rrm.warehouse_no = strWareHouseNo
         and rrm.recede_no = strRecedeNo
         and rrm.status = '10'
         and rrd.recede_qty - rrd.locate_qty > 0
       order by rrd.article_no, rrd.po_id;

    v_strCondition              varchar2(500);
    v_strOrderCondition         varchar2(500);--排序条件
    v_strAreaUseTypeCondition   varchar2(100);
    v_strAreaAttributeCondition varchar2(100);
    v_strLabelNoCondition       varchar2(100);
    v_strPackingQtyCondition    varchar2(200);--库存包装条件

  BEGIN
    strResult := 'N|[PROC_TTHRecedeSearchCell]';
    --DBMS_OUTPUT.ENABLE(1000000);  测试用
    for p in v_GetLocateItem loop
      v_iCount     := v_iCount + 1;
      v_nTotalQty  := p.recede_qty - p.locate_qty;
      v_nRemainQty := p.recede_qty - p.locate_qty;
      v_nCurQty    := 0;
      v_nCount     := 0;
      --获取策略
      for rule in (select r.*, td.LIMMIT_RSV01
                     from wms_defstrategy t
                     join wms_defstrategy_d td on t.strategy_type =
                                                  td.strategy_type
                                              and t.strategy_id =
                                                  td.strategy_id
                     join wms_defrule r on r.strategy_type =
                                           td.strategy_type
                                       and r.rule_id = td.rule_id
                                       and (r.use_type <> '0' or
                                           r.use_type is null)
                    where t.strategy_id = strStrategyId
                      and t.strategy_type = 'RO'
                    order by td.rule_order) loop
        v_nCount := v_nCount + 1;
        --选择储区类型
        begin
          /*1 定位退货区储位
          2 定位次品区储位        0
          3 定位商品拣货位        0
          4 定位异常区
          5 定位良品区储位拣货区  0
          6 定位良品区储位保管区  0
          7 定位良品区（含异常区）
          8 定位过季品区          0
          9 定位良品区（不含异常区）  0*/
          if rule.rule_id = 1 then
            v_strAreaUseTypeCondition   := ' and t.area_usetype in (''3'')';
            v_strAreaAttributeCondition := ' and t.area_attribute in (''0'')';
          elsif rule.rule_id = 2 then
            goto NextOne;
          elsif rule.rule_id = 3 then
            goto NextOne;
          elsif rule.rule_id = 4 then
            v_strAreaUseTypeCondition   := ' and t.area_usetype in (''5'')';
            v_strAreaAttributeCondition := ' and t.area_attribute in (''0'')';
          elsif rule.rule_id = 5 then
            goto NextOne;
          elsif rule.rule_id = 6 then
            goto NextOne;
          elsif rule.rule_id = 7 then
            v_strAreaUseTypeCondition   := ' and t.area_usetype in (''1'',''5'')';
            v_strAreaAttributeCondition := ' and t.area_attribute in (''0'')';
          elsif rule.rule_id = 8 then
            goto NextOne;
          elsif rule.rule_id = 9 then
            goto NextOne;
          end if;
        end;
        --定位标签库存条件
        begin
          /*是否定位标签库存:
          0：普通库存，
          1：标签库存，
          2：优先标签库存*/
          if rule.limmit_rsv01 = '0' then
            v_strLabelNoCondition := ' and sc.label_no =''N'' ';
          elsif rule.limmit_rsv01 = '1' then
            v_strLabelNoCondition := ' and sc.label_no <>''N'' ';
          elsif rule.limmit_rsv01 = '2' then
            v_strLabelNoCondition := '';
          end if;
        end;

        if v_strAreaUseTypeCondition is null or
           v_strAreaAttributeCondition is null then
          strResult := 'N|[未加载到可用的退货策略，请维护！]';
          return;
        end if;

        --定位包装条件 退厂定位规格类型(0-不管规格；1-优先退厂明细规格；2-按退厂规格)
        if strORDER_RSV03 = '2' then
          v_strPackingQtyCondition   := ' and sc.packing_qty = ' || p.packing_qty;
        else
          v_strPackingQtyCondition    := '';
        end if;

        v_strUpSql := ' update stock_content sc set sc.status=status ' ||
                      ' where sc.enterprise_no = ''' || strEnterPriseNo ||
                      ''' and sc.warehouse_no = ''' || strWarehouseNo ||
                      ''' and sc.article_no = ''' || p.Article_No ||
                      ''' and sc.stock_type = ''' || p.stock_type ||
                      ''' and sc.stock_value = ''' || p.stock_value ||
                      ''' and sc.cell_no in ( ' ||
                      ' select cell_no from cdef_defware cw,cdef_defarea t,cdef_defcell cd  ' ||
                      ' where cw.ENTERPRISE_NO = cd.enterprise_no and cw.WAREHOUSE_NO = cd.warehouse_no and cw.WARE_NO = cd.ware_no ' ||
                      ' and t.ENTERPRISE_NO = cd.enterprise_no and t.WAREHOUSE_NO = cd.WAREHOUSE_NO and t.WARE_NO = cd.WARE_NO and t.AREA_NO = cd.AREA_NO ' ||
                      ' and cd.ENTERPRISE_NO = sc.ENTERPRISE_NO and cd.WAREHOUSE_NO = sc.WAREHOUSE_NO and cd.CELL_NO = sc.CELL_NO ' ||
                      ' and cd.cell_status<>''1'' ';
        v_strUpSql := v_strUpSql || v_strAreaUseTypeCondition ||
                      v_strAreaAttributeCondition || ')' ||
                      v_strPackingQtyCondition ;
        execute immediate v_strUpSql;

        --新增排序条件 huangb 20160511
        v_strOrderCondition := ' order by ';

        if rule.limmit_rsv01 = '2' then
           v_strOrderCondition := v_strOrderCondition || ' (case sc.label_no when ''N'' then 1 else 0 end),';
           if strORDER_RSV03 = '1'  then
             v_strOrderCondition := v_strOrderCondition || ' (case when sc.packing_qty = ' || p.packing_qty || ' then 0 else 1 end),';
            end if;
        else
           if strORDER_RSV03 = '1'  then
             v_strOrderCondition := v_strOrderCondition || ' (case when sc.packing_qty = ' || p.packing_qty || ' then 0 else 1 end),';
            end if;
        end if;
        v_strOrderCondition := v_strOrderCondition || ' sc.cell_no, sai.produce_date';
        --此处请注意 v_strOrderCondition的结尾不能有空格，此处是截取最后一个逗号的作用
        --v_strOrderCondition := substr(v_strOrderCondition,0,length(v_strOrderCondition) - 1);

        --获取退厂库存
        begin
          v_strSql := 'select sc.owner_no, sc.article_no, sc.article_id, sc.Qty,' ||
                      ' sc.OutStock_Qty, sc.packing_qty, sc.cell_no,  sc.cell_id, sc.stock_type,' ||
                      ' sc.stock_value, sc.label_no, sc.sub_label_no,bda.QMIN_OPERATE_PACKING ' ||
                      ' /*sc.*,sai.lot_no,sai.produce_date,sai.expire_date,sai.quality*/ ' ||
                      ' from stock_content sc,stock_article_info sai,cdef_defcell cd,cdef_defarea t,cdef_defware w,bdef_defarticle bda ' ||
                      ' where sc.enterprise_no = sai.enterprise_no and sc.enterprise_no = cd.enterprise_no ' ||
                      ' and sc.enterprise_no = t.enterprise_no and sc.warehouse_no = cd.warehouse_no ' ||
                      ' and sc.warehouse_no = t.warehouse_no and sc.article_no = sai.article_no ' ||
                      ' and sc.article_id = sai.article_id and sc.cell_no = cd.cell_no ' ||
                      ' and cd.ware_no = t.ware_no and cd.area_no = t.area_no ' ||
                      ' and t.enterprise_no = w.enterprise_no and t.warehouse_no = w.warehouse_no and t.ware_no = w.ware_no ' ||
                      ' and bda.ENTERPRISE_NO = sc.ENTERPRISE_NO and bda.owner_no = sc.owner_no and bda.article_no = sc.article_no ' ||
                      --条件
                      ' and cd.cell_status = ''0'' and cd.check_status=''0'' and sc.qty - sc.outstock_qty > 0 ' ||
                      ' and sc.enterprise_no = ''' || strEnterPriseNo || '''' ||
                      ' and sc.warehouse_no = ''' || strWareHouseNo || '''' ||
                      ' and sc.article_no = ''' || p.article_no || '''';
          --org_no
          v_strCondition := ' and (''' || p.org_no || ''' = ''N'' or (''' ||
                            p.org_no || ''' <> ''N'' and w.org_no = ''' ||
                            p.org_no || ''')) ';
          --lot_no
          v_strCondition := v_strCondition || ' and (''' || p.lot_no ||
                            ''' = ''N'' or (''' || p.lot_no ||
                            ''' <> ''N'' and sai.lot_no = ''' || p.lot_no ||
                            ''')) ';
          --quality
          if p.quality is not null then
            v_strCondition := v_strCondition || ' and sai.quality = ''' ||
                              p.quality || '''';
          end if;
          --produce_date
          if p.produce_date is not null then
            v_strCondition := v_strCondition || ' and sai.produce_date = ''' ||
                              p.produce_date || '''';
          end if;
          --expire_date
          if p.expire_date is not null then
            v_strCondition := v_strCondition || ' and sai.expire_date = ''' ||
                              p.expire_date || '''';
          end if;

          v_strSql := v_strSql ||
                      v_strCondition ||
                      v_strPackingQtyCondition ||
                      v_strAreaUseTypeCondition ||
                      v_strAreaAttributeCondition ||
                      v_strLabelNoCondition ||
                      --注意 排序必须放在最后 huangb 20160511
                      v_strOrderCondition;
         --DBMS_OUTPUT.put_line(v_strSql);测试用

        end;
        --写退厂下架指示和库存
        P_RODATA_WRITE_DIRECT(strEnterPriseNo,
                              strWareHouseNo,
                              strRecedeNo,
                              strWaveNo,
                              p.supplier_no,
                              strUserId,
                              p.class_type,
                              p.recede_type,
                              p.DEPT_NO,
                              p.po_id,
                              v_nRemainQty,
                              strDestCellNo,
                              v_strSql,
                              strResult);
        if substr(strResult, 1, 1) = 'N' then
          return;
        end if;

        <<NextOne>>
        null;
        if v_nRemainQty = 0 then
          exit;
        end if;
      end loop;
      if v_nCount = 0 then
        strResult := 'N|[未获取到退厂策略，请联系维护人员添加！]';
        return;
      end if;
      /*
        if v_nTotalQty >= v_nRemainQty and v_nRemainQty > 0 then

        end if;
      */
    end loop;

    if v_iCount = 0 then
      strResult := 'N|[E25005]';
      return;
    end if;

    --更新标签库存有剩余下架指示标签拣货标识为表单
    --若一个标签被多个退货单定位到而且未做拣货回单，且库存中库存数量=预下数量时，也更新为表单
    for p in (SELECT DISTINCT D.LABEL_NO
                FROM RODATA_OUTSTOCK_DIRECT D
               WHERE D.ENTERPRISE_NO = strEnterPriseNo
                 AND D.WAREHOUSE_NO = strWareHouseNo
                 AND D.SOURCE_NO = strRecedeNo
                 AND (EXISTS
                      (SELECT 'X'
                         FROM STOCK_CONTENT C
                        WHERE D.ENTERPRISE_NO = C.ENTERPRISE_NO
                          AND D.WAREHOUSE_NO = C.WAREHOUSE_NO
                          AND D.LABEL_NO = C.LABEL_NO
                          AND C.QTY - C.OUTSTOCK_QTY > 0) OR EXISTS
                      (SELECT 'X'
                         FROM RODATA_OUTSTOCK_DIRECT C
                        WHERE D.ENTERPRISE_NO = C.ENTERPRISE_NO
                          AND D.WAREHOUSE_NO = C.WAREHOUSE_NO
                          AND D.LABEL_NO = C.LABEL_NO
                          AND D.SOURCE_NO <> C.SOURCE_NO))) loop
      begin
        update rodata_outstock_direct t
           set t.label_pick_flag = '1'
         where t.enterprise_no = strEnterPriseNo
           and t.warehouse_no = strWareHouseNo
           and t.source_no = strRecedeNo
           and t.label_no = p.label_no
           and t.label_pick_flag = '2';
      end;
    end loop;

    strResult := 'Y';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  END P_RODATA_LOCATE;

  /*写库存，退厂下架指示
  huangb 20160514 支持库存拆零
  huangb 20160527 去掉支持库存拆零
  */
  PROCEDURE P_RODATA_WRITE_DIRECT(strEnterPriseNo in rodata_recede_m.enterprise_no%type,
                                  strWareHouseNo  in rodata_recede_m.warehouse_no%type,
                                  strRecedeNo     in rodata_recede_m.recede_no%type,
                                  strWaveNo       in rodata_recede_m.wave_no%type, --返回的波次号
                                  strSupplierNo   in rodata_recede_m.supplier_no%type,
                                  strUserId       in rodata_recede_m.rgst_name%type,
                                  strClassType    in rodata_recede_m.class_type%type,
                                  strRecedeType   in rodata_recede_m.recede_type%type,
                                  strDeptNo       in rodata_recede_m.DEPT_NO%type, --部门编号 huangb 20160514
                                  nPoID           in rodata_recede_d.po_id%type,
                                  nQty            in out rodata_recede_d.recede_qty%type,
                                  strDestCellNo   in stock_content.cell_no%type,
                                  strSql          in varchar2,
                                  strResult       out varchar2) IS
    v_nCount     number;
    v_nCurQty    rodata_recede_d.recede_qty%type; --当前定位数量
    v_nRemainQty rodata_recede_d.recede_qty%type; --剩余定位量

    v_destCellID       stock_content.cell_id%type;
    v_strLabelPickFlag rodata_outstock_direct.label_pick_flag%type;
    --退厂库存 动态游标
    TYPE ref_cursor_type IS REF CURSOR;
    v_getRecedeStock ref_cursor_type;

    v_owner_no     stock_content.owner_no%type;
    v_article_no   stock_content.article_no%type;
    v_article_id   stock_content.article_id%type;
    v_nQty         stock_content.qty%type;
    v_nOutStockQty stock_content.outstock_qty%type;
    v_packing_qty  stock_content.packing_qty%type;
    v_cell_no      stock_content.cell_no%type;
    v_cell_id      stock_content.cell_id%type;
    v_stock_type   stock_content.stock_type%type;
    v_stock_value  stock_content.stock_value%type;
    v_label_no     stock_content.label_no%type;
    v_sub_label_no stock_content.sub_label_no%type;
    v_qmin_operate_packing bdef_defarticle.qmin_operate_packing%type; --商品最小操作包装 huangb20160514

  BEGIN
    strResult := 'N|[P_RODATA_WRITE_LOCATE_DIRECT]';

    v_nCount := 0;
    v_nRemainQty := nQty;
    open v_getRecedeStock for strSql;
    loop
      fetch v_getRecedeStock
        into v_owner_no, v_article_no, v_article_id, v_nQty, v_nOutStockQty, v_packing_qty, v_cell_no
        , v_cell_id, v_stock_type, v_stock_value, v_label_no, v_sub_label_no, v_qmin_operate_packing;
      exit when v_getRecedeStock%notfound;

      v_nCount := v_nCount + 1;
      if v_nRemainQty >= v_nQty - v_nOutStockQty then
        v_nCurQty := v_nQty - v_nOutStockQty;
      else
        v_nCurQty := v_nRemainQty;
      end if;
      v_nRemainQty := v_nRemainQty - v_nCurQty;

      --写库存
      pkobj_stock.p_UpdtContent_Reservation(strEnterPriseNo,
                                            strWareHouseNo,
                                            v_cell_no,
                                            v_cell_id,
                                            strDestCellNo,
                                            v_label_no,
                                            v_sub_label_no,
                                            v_nCurQty,
                                            '0',
                                            strUserId,
                                            v_destCellID,
                                            strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;
      if v_label_no is null or v_label_no = 'N' then
        v_strLabelPickFlag := '1';
      else
        v_strLabelPickFlag := '2';
      end if;
      -- 写下架指示
      insert into rodata_outstock_direct
        (enterprise_no,
         warehouse_no,
         owner_no,
         operate_type,
         operate_date,
         supplier_no,
         SOURCE_NO,
         article_no,
         article_id,
         packing_qty,
         s_cell_no,
         s_cell_id,
         s_container_no,
         d_cell_no,
         d_cell_id,
         locate_qty,
         class_TYPE,
         po_id,
         status,
         stock_type,
         stock_value,
         rgst_name,
         rgst_date,
         wave_no,
         Label_No,
         sub_label_no,
         LABEL_PICK_FLAG,recede_type)
      values
        (strEnterPriseNo,
         strWareHouseNo,
         v_owner_no,
         'C',
         trunc(sysdate),
         strSupplierNo,
         strRecedeNo,
         v_article_no,
         v_article_id,
         v_packing_qty,
         v_cell_no,
         v_cell_id,
         'N',
         strDestCellNo,
         v_destCellID,
         v_nCurQty,
         strClassType,
         nPoID,
         '10',
         v_stock_type,
         v_stock_value,
         strUserId,
         sysdate,
         strWaveNo,
         v_label_no,
         v_sub_label_no,
         v_strLabelPickFlag,strRecedeType);

      --更新退货明细
      update rodata_recede_d t
         set t.locate_qty = t.locate_qty + v_nCurQty, t.status = '14'
       where t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strWareHouseNo
         and t.recede_no = strRecedeNo
         and t.article_no = v_article_no
         and t.po_id = nPoID;

      if v_nRemainQty = 0 then
        exit;
      end if;
    end loop;
    close v_getRecedeStock;
    nQty      := v_nRemainQty;
    strResult := 'Y';

  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256) || '[' ||
                   strSql;
  END P_RODATA_WRITE_DIRECT;

  /********************************************************************************
  功能说明：超量定位，以WMS的库存作为可用库存
  ********************************************************************************/
  PROCEDURE P_OverQtyDeal(strEnterPriseNo in rodata_recede_m.enterprise_no%type,
                          strWareHouseNo  in rodata_recede_m.warehouse_no%type,
                          strOwnerNo      in rodata_recede_m.owner_no%type,
                          strRecedeNo     in rodata_recede_m.recede_no%type,
                          strRecedeType   in rodata_recede_m.recede_type%type,
                          strResult       out varchar2) IS
      v_strOverQtyFlag      wms_rodataorder.over_qty_flag%type;
      v_nSumQty           rodata_recede_d.recede_qty%type;
  begin
       strResult:='N|[P_OverQtyDeal]';

        --获取退货类型配置
        --根据货主仓别级别对应的单据类型获取是否需要混单验收的标识
      begin
          select over_qty_flag into v_strOverQtyFlag
                 from wms_warehouse_rodataorder where enterprise_no=strEnterPriseNo
                 and warehouse_no=strWareHouseNo and owner_no=strOwnerNo and recede_type=strRecedeType;
      exception when no_data_found then
          --获取货主级别对应的标识
          begin
              select over_qty_flag
                     into v_strOverQtyFlag
                  from wms_owner_rodataorder where enterprise_no=strEnterPriseNo
                     and owner_no=strOwnerNo and recede_type=strRecedeType;
          exception when no_data_found then
              --获取系统级别对应的标识
              begin
                  select over_qty_flag
                     into v_strOverQtyFlag
                     from wms_rodataorder where enterprise_no=strEnterPriseNo
                         and recede_type=strRecedeType;
              exception when no_data_found then
                  strResult:='N|[找不到对应的单据配置]';
                  return;
              end;
           end;
      end;

      if v_strOverQtyFlag='1' then --允许超量

         update rodata_recede_d rrd set rrd.recede_qty = rrd.locate_qty +
         (select nvl(sum(t.qty+t.instock_qty),rrd.ref_recede_qty) from stock_content t
             where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo
             and t.article_no=rrd.article_no)
             where rrd.enterprise_no=strEnterPriseNo and rrd.warehouse_no=strWareHouseNo
             and rrd.recede_no=strRecedeNo;
      end if;
       strResult:='Y|[]';
  end P_OverQtyDeal;

  /********************************************************************************************************
   功能说明：清场流程第二次,整单审核，处理流程：
   1、退货定位，若定位数量和扫描数量有差异，系统给予拦截，不进行后续操作
   3、若定位量和扫描数量相等，退货发单，不打印
   4、退货回单
   5、退货确认，打印退货清单
  *********************************************************************************************************/
  PROCEDURE P_reviewRecedeNo(strEnterPriseNo in rodata_recede_m.enterprise_no%type,
                               strWareHouseNo  in rodata_recede_m.warehouse_no%type,
                               strOwnerNo      in rodata_recede_m.owner_no%type,
                               strRecedeNo     in rodata_recede_m.recede_no%type,
                               strSupplierNo   in rodata_recede_m.supplier_no%type, --若供应商为空，程序内取供应商
                               strClassType    in rodata_recede_m.class_type%type, --0：清场
                               strUserId       in rodata_recede_m.rgst_name%type,
                               strDockNo       in bdef_defdock.dock_no%type,
                               strWaveNo       out rodata_recede_m.wave_no%type, --返回的波次号
                               strResult       out varchar2)is
       v_nLocateQty            rodata_recede_d.locate_qty%type;--定位数量
       v_nBudgetQty            rodata_recede_d.budget_qty%type;--扫描数量
       v_strDeliverNo          rodata_deliver_m.deliver_no%type;
       v_strSupplierNo         rodata_recede_m.supplier_no%type;
       v_strRecedeType         rodata_recede_m.recede_type%type;
       v_iCount                integer;
  begin
       strResult:='N|[P_reviewRecedeNo]';

        update rodata_recede_m t set t.rsv_varod1='0'
        where t.enterprisE_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo
        and t.recede_no=strRecedeNo;

        --判断定位是否有差异
        select nvl(sum(t.budget_qty),0) into v_nBudgetQty
        from rodata_recede_d t where t.enterprise_no=strEnterPriseNo
        and t.warehouse_no=strWareHouseNo and t.recede_no=strRecedeNo;

        if v_nBudgetQty =0 then
           strResult:='N|[未做扫描，不能直接审核]';
           return;
        end if;

        update rodata_recede_d t set t.recede_qty=t.budget_qty,T.locate_qty=0
        where t.enterprise_no=strEnterPriseNo
        and t.warehouse_no=strWareHouseNo and t.recede_no=strRecedeNo
        and t.status='10';

        if sql%notfound then
           strResult:='N|[更新不到退货明细]';
           return;
        end if;

        select supplier_no,recede_type
          into v_strSupplierNo,v_strRecedeType
          from rodata_recede_m
         where enterprise_no = strEnterPriseNo
           and warehouse_no = strWareHouseNo
           and recede_no = strRecedeNo;

        P_RODATA_LOCATE_Main(strEnterPriseNo,strWareHouseNo,strOwnerNo,
                        strRecedeNo,'1',strUserId,'N',strWaveNo,strResult);

        if substr(strResult, 1, 1) = 'N' then
          return;
        end if;

        --判断定位是否有差异
        select nvl(sum(t.locate_qty),0) into v_nLocateQty
        from rodata_recede_d t where t.enterprise_no=strEnterPriseNo
        and t.warehouse_no=strWareHouseNo and t.recede_no=strRecedeNo;

        if v_nLocateQty<>v_nBudgetQty and v_nBudgetQty>0  then
           strResult:='N|[扫描数量和定位量有差异]';
           return;
        end if;

       --退货发单
       pklg_rodata.P_GetTaskRooutstock(strEnterPriseNo,
                                        strWareHouseNo,
                                        strOwnerNo,
                                        strWaveNo,v_strRecedeType,
                                        v_strSupplierNo,
                                        strClassType,
                                        strRecedeNo,
                                        strDockNo,
                                        strUserId,
                                        strUserId,'C','0',
                                        strResult);

        if substr(strResult, 1, 1) = 'N' then
          return;
        end if;

        --拣货回单
        for GetOutStock in (select rod.enterprise_no,rod.warehouse_no,rod.outstock_no,rod.article_no,
               rod.s_label_no,rod.packing_qty,sai.barcode,sai.quality,sai.produce_date,sai.expire_date,
               sai.lot_no,sai.rsv_batch1,sai.rsv_batch2,sai.rsv_batch3,sai.rsv_batch4,sai.rsv_batch5,
               sai.rsv_batch6,sai.rsv_batch7,sai.rsv_batch8,rod.s_cell_no,rod.d_cell_no,
               sum(rod.article_qty) article_qty
            from rodata_outstock_m  rom,rodata_outstock_d  rod,stock_article_info sai
               where rom.enterprise_no = rod.enterprise_no
                 and rom.warehouse_no = rod.warehouse_no
                 and rom.outstock_no = rod.outstock_no
                 and rom.enterprise_no = strEnterPriseNo
                 and rom.warehouse_no = strWareHouseNo
                 and rod.wave_no = strWaveNo
                 and rod.source_no = strRecedeNo
                 and rod.status = '10'
                 and rom.class_type = strClassType
                 and rod.article_no = sai.article_no
                 and rod.article_id = sai.article_id
             group by rod.enterprise_no,rod.warehouse_no,rod.outstock_no,rod.article_no,
               rod.s_label_no,rod.packing_qty,sai.barcode,sai.quality,sai.produce_date,sai.expire_date,
               sai.lot_no,sai.rsv_batch1,sai.rsv_batch2,sai.rsv_batch3,sai.rsv_batch4,sai.rsv_batch5,
                sai.rsv_batch6,sai.rsv_batch7,sai.rsv_batch8,rod.s_cell_no,rod.d_cell_no) loop
          --

          pklg_rodata.P_SaveOutstock(strEnterPriseNo,strWareHouseNo,strOwnerNo,GetOutStock.outstock_no,
                  GetOutStock.s_label_no,GetOutStock.article_no,GetOutStock.barcode,GetOutStock.packing_qty,GetOutStock.quality,
                  GetOutStock.produce_date,GetOutStock.expire_date,GetOutStock.lot_no,GetOutStock.rsv_batch1,
                  GetOutStock.rsv_batch2,GetOutStock.rsv_batch3,GetOutStock.rsv_batch4,
                 GetOutStock.rsv_batch5,GetOutStock.rsv_batch6,GetOutStock.rsv_batch7,GetOutStock.rsv_batch8,
                 GetOutStock.s_cell_no,GetOutStock.article_qty,GetOutStock.article_qty,
                 GetOutStock.d_cell_no,strUserID,strUserID,'1',strResult);

          if substr(strResult, 1, 1) <> 'Y' then
            return;
          end if;
        end loop;

      pklg_rodata.P_RO_Confirm(strEnterPriseNo,
                   strWareHouseNo,
                   strOwnerNo,
                   strRecedeNo,
                   strUserID,
                   strDockNo,
                   v_strDeliverNo,
                   strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;


      --
    pkobj_rodata.P_RO_UpdateRecedeHeader(strEnterPriseNo,
                                         strWareHouseNo,
                                         v_strDeliverNo,
                                         strOwnerNo,
                                         strUserID,
                                         '13',
                                         strResult);
    if substr(strResult, 1, 1) <> 'Y' then
      return;
    end if;



    strResult:='Y|[]';
  end P_reviewRecedeNo;

end PKLG_ROLOCATE;

/

