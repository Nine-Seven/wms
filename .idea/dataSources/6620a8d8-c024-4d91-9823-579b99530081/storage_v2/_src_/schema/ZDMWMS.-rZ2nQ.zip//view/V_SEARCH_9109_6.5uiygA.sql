create view V_SEARCH_9109_6 as
select icm.warehouse_no,
       icm.check_worker,
       bdw.worker_name,
       bag.l_group_no,
       bag.l_group_name,
       bag.m_group_no,
       bag.m_group_name,
       icd.check_qty,
       trunc(icd.check_qty / icd.packing_qty) check_box,
       icm.check_start_date,
       icm.check_end_date
  from idata_check_m      icm,
       idata_check_d      icd,
       bdef_defarticle    bda,
       bdef_article_group bag,
       bdef_defworker     bdw
 where icm.check_no = icd.check_no
   and icd.article_no = bda.article_no
   and bda.group_no = bag.group_no
   and icm.unload_worker = bdw.worker_no


/

