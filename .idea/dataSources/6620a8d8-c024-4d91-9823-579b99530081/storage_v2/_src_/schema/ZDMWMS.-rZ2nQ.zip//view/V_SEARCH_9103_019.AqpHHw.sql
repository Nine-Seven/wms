create view V_SEARCH_9103_019 as
select device_group_no,
device_group_name,
device_no,
device_name,
label_no,
operate_date,
cust_no,
cust_name,
article_no,
barcode,
article_name,
enterprise_no,warehouse_no,owner_no,
rsv_attr2,
dps_cell_no,
outstock_date,
article_qty
from
(select ddg.device_group_no,ddg.device_group_name,ddm.device_no,ddm.device_name,
dc.cust_no,dc.cust_name,bda.article_name,odd.enterprise_no,odd.warehouse_no,odd.owner_no,
odd.outstock_date,odd.article_qty,trunc(odd.operate_date) as operate_date,bda.article_no,
bda.barcode,odd.dps_cell_no,slm.label_no,bda.rsv_attr2
from odata_divide_d odd,stock_label_m slm,device_divide_group ddg,
device_divide_m ddm,bdef_defcust dc,
bdef_defarticle bda,odata_divide_m odm
where slm.enterprise_no=odd.enterprise_no
  and slm.warehouse_no=odd.warehouse_no
  and slm.container_no=odd.s_container_no
  and odd.enterprise_no=odm.enterprise_no
  and odd.warehouse_no=odm.warehouse_no
  and odd.owner_no=odm.owner_no
  and odd.divide_no=odm.divide_no
  and odm.enterprise_no=ddm.enterprise_no
  and odm.warehouse_no=ddm.warehouse_no
  and odm.device_no=ddm.device_no
  and ddg.enterprise_no=ddm.enterprise_no
  and ddg.warehouse_no=ddm.warehouse_no
  and ddg.device_group_no=ddm.device_group_no
  and dc.enterprise_no=odd.enterprise_no
  and dc.cust_no=odd.cust_no
  and bda.enterprise_no=odd.enterprise_no
  and bda.article_no=odd.article_no)

/

