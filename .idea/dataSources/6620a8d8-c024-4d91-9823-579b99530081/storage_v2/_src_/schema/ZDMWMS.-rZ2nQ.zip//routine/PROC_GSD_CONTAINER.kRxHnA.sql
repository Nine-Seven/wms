create PROCEDURE        PROC_GSD_CONTAINER(strOutMsg out   varchar2) IS
    n_count      number(10);
    n_RowID      number(15);
    n_article_id number(10);
    v_strWarehouse_no   stock_content.warehouse_no%type;
    v_strOwnerNo stock_content.owner_no%type;
    v_strCheckNo fcdata_check_m.check_no%type;
    strCellNo    cdef_defcell.cell_no%type;
    strArticleNo bdef_defarticle.article_no%type;
    strArticleID stock_article_info.article_id%type;
    strCellID    stock_content.cell_id%type;
 --   v_Produce_data    stock_article_info.produce_date%type;
    strResult         varchar2(500);

  BEGIN

    n_count      := 0;
    n_RowID      := 0;
    n_article_id := 0;
    v_strWarehouse_no   := '001';
    v_strOwnerNo := 'N';
    strCellNo    := 'N';
    strArticleNo := 'N';
    strArticleID := -1;
    strCellID    := -1;

    for t in (select a.cell_no,a.owner_article_no,a.packing_qty,b.EXPIRY_DAYS,a.produce_date,a.article_qty,a.owner_no,b.article_no,b.BARCODE from
                TEMPCHECK1608 a,v_bdef_defarticle b
              where a.owner_no=b.owner_no
              and a.owner_article_no=b.owner_article_no
              order by a.owner_no,a.cell_no
      ) loop

      n_count := 0;
      n_RowID := n_RowID +1;

      if t.owner_no<>v_strOwnerNo then

         pklg_wms_base.p_getsheetno('8888',v_strWarehouse_no,
                                    'CH',v_strCheckNo,
                                    strOutMsg);

          --盘点头档
          insert into fcdata_check_m
            (enterprise_no,warehouse_no,owner_no,plan_no,request_no, check_no, check_date,  request_date,
             assign_no,  real_no, status,serial_no,fcdata_type,check_type,
             rgst_name,rgst_date)
          values
            ('8888',v_strWarehouse_no,t.owner_no,'CP0011608269999',v_strCheckNo,v_strCheckNo,trunc(sysdate),trunc(sysdate),
             'admin','admin','13','0',1,1,'admin',sysdate);

      end if;

      v_strOwnerNo:=t.owner_no;

/*      if IS_DATE(t.pici)=1 then
        v_Produce_data := to_date(t.pici,'yyyy-mm-dd');
      else
        if is_date(substr(t.pici,0,8))=1 then
          v_Produce_data := to_date(substr(t.pici,0,8),'yyyy-mm-dd');
        else
          v_Produce_data :=trunc(sysdate );
        end if;
      end if;*/

      insert into fcdata_check_d(enterprise_no,warehouse_no,owner_no,check_no,row_id,
        cell_no,article_no,order_id,sub_order_id,barcode,packing_qty,
        produce_date,expire_date,quality,lot_no,article_qty,
        check_qty,real_qty,
        status,
        check_type,
        check_worker,
        check_date,
        different_flag)
      values('8888',v_strWarehouse_no,v_strOwnerNo,v_strCheckNo,n_RowID,
      t.cell_no,t.article_no,n_RowID,n_RowID,t.barcode,t.packing_qty,
        case
         when t.expiry_days > 0 then
          t.produce_date
         else
          trunc(to_date('19000101','yyyymmdd'))
        end,
        case
         when t.expiry_days > 0 then
          t.produce_date + t.expiry_days
         else
          trunc(to_date('19000101','yyyymmdd'))
        end,
        '0',
        'N',0,t.article_qty,t.article_qty,
        '13',
        '1',
        'admin',
        sysdate,
        '1');
    end loop;

    for  a in(select owner_no,CHECK_NO from fcdata_check_m where enterprise_no='8888' and warehouse_no='001'
      and plan_no='CP0011608269999')loop

        --根据盘点单写库存
        Pkobj_Stock.P_fcdata_insetStock('8888',v_strWarehouse_no,a.owner_no,A.CHECK_NO,'admin',n_count,strResult);
              if substr(strResult,1,1)='N' then
                 strResult:='N|[E30018]';
                 return;
              end if;



    end loop;

        --盘点有差异的写进出帐表
        Pkobj_Stock.P_stock_Insertaccount('8888',v_strWarehouse_no,v_strOwnerNo,'CP0011608269999','admin',strResult);
        if substr(strResult,1,1)='N' then
           return;
        end if;

   --写库存日结表
   insert into stock_content_rj(enterprise_no,warehouse_no,owner_no,dept_no,article_no,jc_date,
         qc_qty,qty,out_qty,in_qty,rgst_name,rgst_date,packing_qty,import_batch_no)
       select '8888',t.warehouse_no,t.owner_no,'N',t.article_no,trunc(sysdate),
              0,sum(t.real_qty),0,0,'admin',sysdate,t.packing_qty,t.CHECK_NO from fcdata_check_d t,fcdata_check_m fcm
              where t.warehouse_no=v_strWarehouse_no and t.enterprise_no=fcm.enterprise_no
              and t.check_no=fcm.check_no and fcm.plan_no='CP0011608269999'
       group by t.enterprise_no,t.check_no, t.warehouse_no,t.owner_no,t.article_no,t.packing_qty,t.CHECK_NO;


    exception
          when others then
            strOutMsg := 'N|' || SQLERRM || n_RowID ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  END PROC_GSD_CONTAINER;


/

