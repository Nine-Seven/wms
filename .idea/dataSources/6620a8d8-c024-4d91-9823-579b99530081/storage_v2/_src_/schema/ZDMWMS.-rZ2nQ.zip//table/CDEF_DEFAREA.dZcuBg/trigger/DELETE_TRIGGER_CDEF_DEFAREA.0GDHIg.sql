create trigger DELETE_TRIGGER_CDEF_DEFAREA
    before delete
    on CDEF_DEFAREA
    for each row
declare
-- local variables here
  n_count        number(10); --记录数，以做判断;

--  strOutMsg      varchar(500) ;
begin
    n_count:=0;

   --删掉通道，储位数据
   --***********************beggin删掉通道，储位数据的处理************************
   --判断当前修改的储区对应的储位是否有库存，如果存在库存，那么不让修改。
    select count(1) into n_count from  cdef_defcell cc,stock_content sc
      where cc.enterprise_no=sc.enterprise_no
      and cc.warehouse_no=sc.warehouse_no

      and cc.cell_no=sc.cell_no
      and cc.enterprise_no=:old.enterprise_no
      and cc.warehouse_no=:old.warehouse_no
      and cc.ware_no=:old.ware_no
      and cc.area_no=:old.area_no
      and cc.stock_no>'1' ;
    if n_count>0 then
      RAISE_APPLICATION_ERROR(-20004,'N|修改储区对应的储位有库存，不允删掉！');
    end if ;

    --删掉巷道的信息
  --  delete from  cdef_defstock where Warehouse_No =:old.warehouse_no and ware_no =:old.ware_no and area_no=:old.area_no  ;
    --删掉储位的信息
    delete from cdef_defcell
     where enterprise_no=:old.enterprise_no
     and Warehouse_No =:old.warehouse_no
     and ware_no =:old.ware_no
     and area_no=:old.area_no ;

   -- commit ;
   --***********************end增加通道数据的处理************************

end delete_trigger_CDEF_DEFAREA;


/

