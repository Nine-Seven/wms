create view V_SEARCH_9101_3 as
SELECT c.owner_no,c.supplier_no,
      c.supplier_name,c.supplier_alias,
      c.supplier_address1,c.supplier_phone1,
      c.supplier_fax1,c.status,c.create_flag,
      c.supplier_note_code,c.enterprise_no,c.SUPPLIER1,
     f_get_fieldtext('N','CREATE_FLAG',c.create_flag) as creatFlagText,
     f_get_fieldtext('N','DEF_STATUS',c.status) as statusText
  FROM bdef_defsupplier c,BDEF_DEFOWNER o
  where c.OWNER_NO = o.OWNER_NO
  and c.enterprise_no =c.enterprise_no


/

