create package        COPERATE_TYPE is
/*出货作业类型 huangb 20160621*/

--P型作业
TYPE_P CONSTANT ODATA_OUTSTOCK_M.Operate_Type%type := 'P';
--W型作业
TYPE_W CONSTANT ODATA_OUTSTOCK_M.Operate_Type%type := 'W';
--M型作业
TYPE_M CONSTANT ODATA_OUTSTOCK_M.Operate_Type%type := 'M';
--B型作业
TYPE_B CONSTANT ODATA_OUTSTOCK_M.Operate_Type%type := 'B';
--C型作业
TYPE_C CONSTANT ODATA_OUTSTOCK_M.Operate_Type%type := 'C';
--D型作业
TYPE_D CONSTANT ODATA_OUTSTOCK_M.Operate_Type%type := 'D';
--混合作业
TYPE_MIX CONSTANT ODATA_OUTSTOCK_M.Operate_Type%type := 'MIX';

end COPERATE_TYPE;


/

