create view V_SEARCH_9103_009 as
select "ENTERPRISE_NO",
       "WAREHOUSE_NO",
       "OWNER_NO",
       "CUST_NO",
       "CUST_NAME",
       "WAVE_NO",
       "SOURCEEXP_NO",
       "OWNER_ARTICLE_NO",
       "BATCH_NO",
       "LABEL_NO",
       "STATUS",
       "STATUS_DESC",
       "EXP_NO",
       "ARTICLE_NO",
       "ARTICLE_NAME",
       "BARCODE",
       "PACKING_QTY",
       "QTY",
       "LOADPROPOSE_NO",
       "RGST_DATE"
  from (select olm.enterprise_no,
               olm.warehouse_no,
               bda.OWNER_NO,
               old.cust_no,
               bdc.cust_name,
               sld.wave_no,
               sld.batch_no,
               slm.label_no,
               old.status,
               wdv.text status_desc,
               oem.sourceexp_no,
               bda.OWNER_ARTICLE_NO,
               sld.exp_no,
               bda.ARTICLE_NO,
               bda.ARTICLE_NAME,
               bda.BARCODE,
               sld.packing_qty,
               sld.qty,
               olm.loadpropose_no,
               olm.rgst_date
          from odata_loadpropose_m olm
          join odata_loadpropose_d old
            on olm.enterprise_no = old.enterprise_no
           and olm.warehouse_no = old.warehouse_no
           and olm.loadpropose_no = old.loadpropose_no
          join (select warehouse_no,
                      enterprise_no,
                      owner_no,
                      article_no,
                      container_no,
                      article_id,
                      exp_no,
                      cust_no,
                      updt_date,
                      packing_qty,
                      batch_no,
                      wave_no,
                      source_no,
                      qty
                 from stock_label_d
               union
               select warehouse_no,
                      enterprise_no,
                      owner_no,
                      article_no,
                      container_no,
                      article_id,
                      exp_no,
                      cust_no,
                      updt_date,
                      packing_qty,
                      batch_no,
                      wave_no,
                      source_no,
                      qty
                 from stock_label_dhty) sld
            on old.enterprise_no = sld.enterprise_no
           and old.warehouse_no = sld.warehouse_no
           and old.container_no = sld.container_no
           and old.cust_no = sld.cust_no
          join (select warehouse_no,
                       enterprise_no,
                       container_no,
                       label_no
                 from stock_label_m
               union
               select warehouse_no,
                       enterprise_no,
                       container_no,
                       label_no
                 from stock_label_mhty) slm
            on slm.enterprise_no = sld.enterprise_no
           and slm.warehouse_no = sld.warehouse_no
           and slm.container_no = sld.container_no
         INNER JOIN odata_exp_m oem
            ON oem.warehouse_no = sld.warehouse_no
           AND oem.enterprise_no = sld.enterprise_no
           AND oem.exp_no = sld.exp_no
          join bdef_defcust bdc
            on sld.enterprise_no = bdc.enterprise_no
           and sld.owner_no = bdc.owner_no
           and sld.cust_no = bdc.cust_no
          join v_bdef_defarticle bda
            on bdc.owner_no = bda.owner_no
           and old.enterprise_no = bda.enterprise_no
           and sld.article_no = bda.article_no
          left join wms_deffieldval wdv
            on old.status = wdv.value
           and wdv.table_name = 'N'
           and wdv.colname = 'STATUS') c

/

