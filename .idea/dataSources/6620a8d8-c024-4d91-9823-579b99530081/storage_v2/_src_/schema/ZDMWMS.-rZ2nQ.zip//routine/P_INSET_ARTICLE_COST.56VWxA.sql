create procedure P_INSET_ARTICLE_COST is
   strResult    varchar2(255);
begin
     --循环写库存三级帐
    for GetArticleStock in (select t.owner_no,
                                  t.enterprise_no,
                                  t.warehouse_no,
                                  t.article_no,
                                  sai.barcode,
                                  t.packing_qty,
                                  sai.produce_date,
                                  sai.expire_date,
                                  sai.quality,
                                  sai.lot_no,
                                  sai.import_batch_no,
                                  sai.rsv_batch1,
                                  sai.rsv_batch2,
                                  sai.rsv_batch3,
                                  sai.rsv_batch4,
                                  sai.rsv_batch5,
                                  sai.rsv_batch6,
                                  sai.rsv_batch7,
                                  sai.rsv_batch8,
                                  sum(qty) qty
                             from stock_content t, stock_article_info sai
                            where t.enterprise_no = t.enterprise_no
                              and t.article_no = sai.article_no
                              and t.article_id = sai.article_id
                            group by t.owner_no,
                                     t.enterprise_no,
                                     t.warehouse_no,
                                     t.article_no,
                                     sai.barcode,
                                     t.packing_qty,
                                     sai.produce_date,
                                     sai.expire_date,
                                     sai.quality,
                                     sai.lot_no,
                                     sai.import_batch_no,
                                     sai.rsv_batch1,
                                     sai.rsv_batch2,
                                     sai.rsv_batch3,
                                     sai.rsv_batch4,
                                     sai.rsv_batch5,
                                     sai.rsv_batch6,
                                     sai.rsv_batch7,
                                     sai.rsv_batch8) loop

      PKOBJ_STOCK.P_insertImportBatchStock('8888',
                                           '001',
                                           GetArticleStock.owner_no,
                                           'N',
                                           GetArticleStock.article_no,
                                           GetArticleStock.quality,
                                           GetArticleStock.import_batch_no,
                                           GetArticleStock.produce_date,
                                           GetArticleStock.expire_date,
                                           GetArticleStock.lot_no,
                                           GetArticleStock.rsv_batch1,
                                           GetArticleStock.rsv_batch2,
                                           GetArticleStock.rsv_batch3,
                                           GetArticleStock.rsv_batch4,
                                           GetArticleStock.rsv_batch5,
                                           GetArticleStock.rsv_batch6,
                                           GetArticleStock.rsv_batch7,
                                           GetArticleStock.rsv_batch8,
                                           GetArticleStock.barcode,
                                           GetArticleStock.packing_qty,
                                           GetArticleStock.qty,
                                           '1',
                                           'N',
                                           'admin',
                                           strResult);

      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;

      pkobj_stock.P_InsertArticleStockList('8888',
                                           '001',
                                           GetArticleStock.owner_no,
                                           'N',
                                           GetArticleStock.article_no,
                                           GetArticleStock.quality,
                                           GetArticleStock.produce_date,
                                           GetArticleStock.expire_date,
                                           GetArticleStock.lot_no,
                                           GetArticleStock.rsv_batch1,
                                           GetArticleStock.rsv_batch2,
                                           GetArticleStock.rsv_batch3,
                                           GetArticleStock.rsv_batch4,
                                           GetArticleStock.rsv_batch5,
                                           GetArticleStock.rsv_batch6,
                                           GetArticleStock.rsv_batch7,
                                           GetArticleStock.rsv_batch8,
                                           GetArticleStock.barcode,
                                           GetArticleStock.packing_qty,
                                           GetArticleStock.qty,
                                           '1',
                                           'N',
                                           1,
                                           'I',
                                           GetArticleStock.import_batch_no,
                                           'admin',
                                           GetArticleStock.import_batch_no,
                                           strResult);

      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;

    end loop;  
  --
end P_INSET_ARTICLE_COST;

/

