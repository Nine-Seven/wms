create view V_SEARCH_9103_024 as
select distinct odm.enterprise_no,
                trunc(odm.rgst_date) as deliver_date,
                odm.rgst_date as operate_date,
                odm.warehouse_no,
                odm.owner_no,
                bdo.owner_name,
                oem.shipper_no,
                bds.shipper_name,
                odd.label_no,
                slm.weight,
                oem.sourceexp_no,
                oem.rsv_varod4 as batch_no,
                oem.ORDER_SOURCE as ec_no,
                oem.shipper_deliver_no,
                odm.loadpropose_no
  from odata_deliver_m odm
 inner join odata_deliver_d odd
    on odd.enterprise_no = odm.enterprise_no
   and odd.warehouse_no = odm.warehouse_no
   and odd.owner_no = odm.owner_no
   and odd.deliver_no = odm.deliver_no
 inner join stock_label_mhty slm
    on slm.enterprise_no = odd.enterprise_no
   and slm.warehouse_no = odd.warehouse_no
   and slm.label_no = odd.label_no
   and slm.container_no = odd.container_no
   and slm.wave_no = odd.wave_no
 inner join bdef_defowner bdo
    on bdo.enterprise_no = odm.enterprise_no
   and bdo.owner_no = odm.owner_no
 inner join odata_exp_m oem
    on oem.enterprise_no = odd.enterprise_no
   and oem.warehouse_no = odd.warehouse_no
   and oem.owner_no = odd.owner_no
   and oem.exp_no = odd.exp_no
 inner join bdef_defshipper bds
    on bds.enterprise_no = oem.enterprise_no
   and bds.shipper_no = oem.shipper_no
 order by /*odm.loadpropose_no,
          odm.owner_no,
          oem.shipper_no,
          oem.rsv_varod4,
          oem.sourceexp_no*/  odm.rgst_date desc

/

