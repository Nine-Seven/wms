create package body        PKOBJ_COST is
  /***********************************************************************************************
  wyf
  20151208
  功能说明：根据取值策略生成消费清单
  根据计费项目策略产生的清单（固定费用只在结算日期产生）
  ***********************************************************************************************/
  procedure P_EXPENSES_LIST(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                            strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                            strOwnerNo         cost_formulaset.owner_no%type, --货主
                            strBilling_project cost_formulaset.billing_project%type, --计费项目 支持传空值
                            strBillingType     cost_formulaset.billing_type%type, --计费项目类型 支持传空值
                            dtDate             cost_expenses_list.build_date%type, --生成日期
                            strFlag            cost_expenses_list.flag%type, --是否重算，0:代表正常日结生成，1：代表重算
                            strWorkerNo        cost_expenses_list.rgst_name%type,
                            strOutMsg          out varchar2) --返回值
   IS
    v_nRow   integer := 0;
    v_dtDate cost_expenses_list.build_date%type;
  BEGIN
    strOutMsg := 'N|[P_EXPENSES_LIST]';
    --锁计费项目表
    update cost_formulaset a
       set a.status = a.status
     where a.status = '0'
       and trunc(nvl(a.END_DATE, sysdate)) >= trunc(sysdate)
       and trunc(nvl(a.begin_date, sysdate)) <= trunc(sysdate)
       and a.enterprise_no = strEnterpriseNo
       and a.warehouse_no = strWarehouseNo
       and a.owner_no = strOwnerNo
       and (a.billing_project = strBilling_project or
           strBilling_project is null)
       and (a.billing_type = strBillingType or strBillingType is null);

    /* v_dtDate := dtDate;
    if strFlag = 1 then
      --重算日期取传入日期
      v_dtDate := dtDate;
    else
      --系统自动计算取传入日期的前一天
      v_dtDate := dtDate - 1;
    end if;*/
    v_dtDate := dtDate - 1;

    for p in (select a.*
                from cost_formulaset a
               where a.status = '0'
                 and trunc(nvl(a.END_DATE, sysdate)) >= trunc(sysdate)
                 and trunc(nvl(a.begin_date, sysdate)) <= trunc(sysdate)
                 and a.enterprise_no = strEnterpriseNo
                 and a.warehouse_no = strWarehouseNo
                 and a.owner_no = strOwnerNo
                 and (a.billing_project = strBilling_project or
                     strBilling_project is null)
                 and (a.billing_type = strBillingType or
                     strBillingType is null)) loop
      v_nRow := v_nRow + 1;
      if p.Billing_Flag = '1' then
        --计算固定费用清单
        P_GCLD_FIXED(strEnterpriseNo, --企业
                     strWarehouseNo, --仓别
                     strOwnerNo, --货主
                     p.billing_project, --计费项目
                     p.billing_type, --计费项目类型
                     v_dtDate, --开始日期
                     strFlag, --0:代表正常日结生成，1：代表重算
                     strWorkerNo,
                     strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
      else
        --计算动态费用清单
        P_GCLD_DYNAMIC_NEW(strEnterpriseNo, --企业
                           strWarehouseNo, --仓别
                           strOwnerNo, --货主
                           p.billing_project, --计费项目
                           p.billing_type, --计费项目类型
                           v_dtDate, --开始日期
                           strFlag, --0:代表正常日结生成，1：代表重算
                           strWorkerNo,
                           strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
      end if;
    end loop;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_EXPENSES_LIST;

  /***********************************************************************************************
  wyf
  20151208
  功能说明：根据取值策略生成固定费用类型的消费清单
  ***********************************************************************************************/
  procedure P_GCLD_FIXED(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                         strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                         strOwnerNo         cost_formulaset.owner_no%type, --货主
                         strBilling_project cost_formulaset.billing_project%type, --计费项目
                         strBillingType     cost_formulaset.billing_type%type, --计费项目类型
                         dtDate             cost_expenses_list.build_date%type, --产生日期
                         strFlag            cost_expenses_list.flag%type, --0:代表正常日结生成，1：代表重算
                         strWorkerNo        cost_expenses_list.rgst_name%type,
                         strOutMsg          out varchar2) --返回值
   IS
    v_nRow     integer := 0;
    v_nCount   integer := 0;
    v_nDay     integer := 1;
    v_nLastDay integer := 0;
    v_dtDate   cost_expenses_list.build_date%type;
  BEGIN
    strOutMsg := 'N|[P_GCLD_FIXED]';
    for p in (select *
                from cost_formulaset a
               where a.enterprise_no = strEnterpriseNo
                 and a.warehouse_no = strWarehouseNo
                 and a.owner_no = strOwnerNo
                 and a.billing_project = strBilling_project
                 and a.billing_type = strBillingType) loop
      v_nRow := v_nRow + 1;
      --计费周期策略
      if p.billing_cycle = '1' then
        --按天
        v_dtDate := dtDate - 1;
      elsif p.billing_cycle = '2' then
        --按周 获取传入日期是周几
        select to_char(dtDate, 'd') into v_nDay from dual;
        if p.balance_day is null then
          --未维护结算日 则默认周天为结算日
          if v_nDay = '1' then
            v_dtDate := dtDate;
          else
            goto nextOne;
          end if;
        else
          --有维护结算日，则比较传入日期是否为结算日
          if v_nDay + 1 = p.balance_day then
            v_dtDate := dtDate - 1;
          else
            goto nextOne;
          end if;
        end if;
      elsif p.billing_cycle = '3' then
        --按月 获取传入日期是几号
        select to_char(dtDate, 'dd') into v_nDay from dual;
        --获取传入日期所在月份的最后一天
        select to_char(last_day(dtDate), 'dd') into v_nLastDay from dual;
        if p.balance_day is null then
          --未维护结算日，则默认每月的最后一天为结算日
          if v_nDay = v_nLastDay then
            v_dtDate := dtDate;
          else
            goto nextOne;
          end if;
        else
          --有维护结算日，则比较传入日期是否为结算日
          --若结算日大于传入日期所在月的最后一天，则判断传入日期是否为所在月份的最后一天
          if v_nDay + 1 = p.balance_day or
             (p.balance_day > v_nLastDay and v_nDay + 1 = v_nLastDay) then
            v_dtDate := dtDate - 1;
          else
            goto nextOne;
          end if;
        end if;
      else
        goto nextOne;
      end if;

      select count(1)
        into v_nCount
        from cost_expenses_list t
       where t.enterprise_no = p.enterprise_no
         and t.warehouse_no = p.warehouse_no
         and t.owner_no = p.owner_no
         and t.billing_project = p.billing_project
         and t.billing_type = p.billing_type
         and trunc(t.build_date) = trunc(dtDate)
         and t.serial_no = 'N'
         and t.status = '10';
      if v_nCount > 0 then
        if strFlag = '1' then
          --重算
          --删除已存在的清单
          delete from cost_expenses_list t
           where t.enterprise_no = p.enterprise_no
             and t.warehouse_no = p.warehouse_no
             and t.owner_no = p.owner_no
             and t.billing_project = p.billing_project
             and t.billing_type = p.billing_type
             and t.build_date = dtDate
             and t.serial_no = 'N'
             and t.status = '10';
        end if;
      end if;

      --消费清单表
      P_INSERT_EXPENSES_LIST_NEW(p.enterprise_no,
                                 p.warehouse_no,
                                 p.owner_no,
                                 p.billing_project,
                                 p.billing_type,
                                 null,
                                 'N',
                                 trunc(dtDate),
                                 'N',
                                 p.fixed_value,
                                 strFlag,
                                 strWorkerNo,
                                 strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
      <<nextOne>>
      null;
    END LOOP;
    if v_nRow = 0 then
      strOutMsg := 'N|[设费项目设置错误，请核实!]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_GCLD_FIXED;
  /***********************************************************************************************
  wyf
  20160524
  功能说明：根据取值策略生成动态费用类型的消费清单
  ***********************************************************************************************/
  procedure P_GCLD_DYNAMIC_NEW(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                               strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                               strOwnerNo         cost_formulaset.owner_no%type, --货主
                               strBilling_project cost_formulaset.billing_project%type, --计费项目
                               strBillingType     cost_formulaset.billing_type%type, --计费项目类型
                               dtDate             cost_expenses_list.build_date%type, --生成日期
                               strFlag            cost_expenses_list.flag%type, --是否重算，0:代表正常日结生成，1：代表重算
                               strWorkerNo        cost_expenses_list.rgst_name%type,
                               strOutMsg          out varchar2) IS
    intCount integer := 0;
    v_nCount integer := 0;
  BEGIN
    strOutMsg := 'N|[P_GCLD_DYNAMIC_NEW]';
    for p in (select a.*
                from cost_formulaset a
               where a.enterprise_no = strEnterpriseNo
                 and a.warehouse_no = strWarehouseNo
                 and a.owner_no = strOwnerNo
                 and a.billing_project = strBilling_project
                 and a.billing_type = strBillingType) loop
      intCount := intCount + 1;
      select count(1)
        into v_nCount
        from cost_expenses_list t
       where t.enterprise_no = p.enterprise_no
         and t.warehouse_no = p.warehouse_no
         and t.owner_no = p.owner_no
         and t.billing_project = p.billing_project
         and t.billing_type = p.billing_type
         and trunc(t.build_date) = trunc(dtDate)
         and t.serial_no = 'N'
         and t.status = '10';
      if v_nCount > 0 then
        if strFlag = '1' then
          --重算
          --删除已存在的清单
          delete from cost_expenses_list t
           where t.enterprise_no = p.enterprise_no
             and t.warehouse_no = p.warehouse_no
             and t.owner_no = p.owner_no
             and t.billing_project = p.billing_project
             and t.billing_type = p.billing_type
             and t.build_date = dtDate
             and t.serial_no = 'N'
             and t.status = '10';
        end if;
      end if;
      --使用新的表进行新增消费清单
      P_GC_COMM_LIST(strEnterpriseNo,
                     strWarehouseNo,
                     strOwnerNo,
                     strBilling_project,
                     strBillingType,
                     p.standard_flag,
                     p.billing_unit,
                     p.value_flag,
                     dtDate,
                     strFlag,
                     strWorkerNo,
                     strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
      <<nextOne>>
      null;
    end loop;
    if intCount = 0 then
      strOutMsg := 'N|[设费项目设置错误，请核实!]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_GCLD_DYNAMIC_NEW;
  /***********************************************************************************************
  wyf
  20160524
  功能说明：获取消费数据
  ***********************************************************************************************/
  procedure P_GC_COMM_LIST(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                           strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                           strOwnerNo         cost_formulaset.owner_no%type, --货主
                           strBilling_project cost_formulaset.billing_project%type, --计费项目
                           strBillingType     cost_formulaset.billing_type%type, --计费项目类型
                           strStandardFlag    cost_formulaset.standard_flag%type, --是否标准策略
                           strBillingUnit     cost_formulaset.billing_unit%type, --计费单位
                           strValueFlag       cost_formulaset.value_flag%type, --取值方式
                           --strCostFlag        cost_formulaset.cost_flag%type, --费用标识：0-应收；1-应付
                           dtDate      cost_expenses_list.build_date%type, --生成日期
                           strFlag     cost_expenses_list.flag%type, --是否重算，0:代表正常日结生成，1：代表重算
                           strWorkerNo cost_expenses_list.rgst_name%type,
                           strOutMsg   out varchar2) IS
    v_strSql cost_billing_rule.standard_sql%type;

    v_strSourceNo cost_expenses_list.source_no%type;
    v_strFamilyNo cost_expenses_list.family_no%type;
    v_nVuale      cost_expenses_list.qty%type;

    TYPE ref_cursor_type IS REF CURSOR;
    v_GetExpenseList ref_cursor_type;
  BEGIN
    strOutMsg := 'N|[P_GC_COMM_LIST]';
    v_strSql  := null;
    --获取取值方式SQL 须获取use_type为1的，为1是可用状态
    for p in (select (case
                       when strStandardFlag = '1' then
                        a.standard_sql
                       else
                        a.nonstandard_sql
                     end) strSql
                from cost_billing_rule a
               where a.billing_type = strBillingType
                 and a.billing_unit = strBillingUnit
                 and a.rule_id = strValueFlag
                 and a.enterprise_no = strEnterpriseNo
                 and a.use_type = '1'
               order by a.sql_order) loop
      v_strSql := v_strSql || p.strsql;
    end loop;
    if v_strSql is null then
      strOutMsg := 'N|计费项目[' || strBilling_project || ']取值方式SQL未填写!';
      strOutMsg := 'Y|';
      return;
    end if;
    --根据条件拼SQL   sql查出来的数据与条件需要使用统一的规则
    --规则1，需要enterprise_no,owner_no,warehouse_no,billing_project,billing_type,FAMILY_NO
    --规则2，需要数据产生数据的时间（注意产生日期的时间，例如验收是以验收确认的时间为准）
    --规则3，其他条件，非公用的条件在billing_sql中写好
    --规则4，计费视图定义v_cost_+'计费项目类型'+'计费单位'+_+'rule_id'--使用视图实现没有SQL直观
    --规则5，企业【%S0】，仓别【%S1】，货主【%S2】，日期【%S4】，预留【%S3】
    --规则6，非标准策略的计费项目关联商品群组信息  需要 计费类型【%S5】，计费项目【%S6】
    v_strSql := replace(v_strSql, '%S0', strEnterpriseNo);
    v_strSql := replace(v_strSql, '%S1', strWarehouseNo);
    v_strSql := replace(v_strSql, '%S2', strOwnerNo);
    v_strSql := replace(v_strSql, '%S4', to_char(dtDate, 'yyyy-mm-dd'));
    v_strSql := replace(v_strSql, '%S6', strBilling_project);
    if strStandardFlag = '0' then
      --是否为标准策咯：0：否；1：是
      v_strSql := replace(v_strSql, '%S5', strBillingType);
    end if;
    --获取消费清单数据
    open v_GetExpenseList for v_strSql;
    loop
      fetch v_GetExpenseList
        into v_strSourceNo, v_strFamilyNo, v_nVuale;
      exit when v_GetExpenseList%notfound;
      --新增消费清单P_INSERT_EXPENSES_LIST_NEW
      --参数：1，需要支持应收应付
      --      2，消费清单所有的费用类型字段都必须包含
      P_INSERT_EXPENSES_LIST_NEW(strEnterpriseNo,
                                 strWarehouseNo,
                                 strOwnerNo,
                                 strBilling_project,
                                 strBillingType,
                                 strBillingUnit,
                                 v_strFamilyNo,
                                 dtDate,
                                 v_strSourceNo,
                                 v_nVuale,
                                 strFlag,
                                 strWorkerNo,
                                 strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
    end loop;
    close v_GetExpenseList;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_GC_COMM_LIST;
  /***********************************************************************************************
  wyf
  20160525
  功能说明：新增消费清单
  ***********************************************************************************************/
  procedure P_INSERT_EXPENSES_LIST_NEW(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                                       strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                                       strOwnerNo         cost_formulaset.owner_no%type, --货主
                                       strBilling_project cost_formulaset.billing_project%type, --计费项目 支持传空值
                                       strBillingType     cost_formulaset.billing_type%type, --计费项目类型 支持传空值
                                       strBillingUnit     cost_formulaset.billing_unit%type,
                                       strFamilyNo        cost_formula_articlefamily.family_no%type,
                                       dtDate             cost_formulaset.rgst_date%type, --开始日期
                                       strSourceNo        cost_expenses_list.source_no%type, --来源单号
                                       nQty               cost_expenses_list.qty%type, --计费量
                                       strFlag            cost_expenses_list.flag%type, --是否重算，0:代表正常日结生成，1：代表重算
                                       strWorkerNo        cost_expenses_list.rgst_name%type,
                                       strOutMsg          out varchar2) IS
    v_NCount     integer := 0;
    v_nArea      cost_expenses_list.area%type := 0; --面积
    v_nTray      cost_expenses_list.tray%type := 0; --托盘
    v_nQty       cost_expenses_list.qty%type := 0; --数量
    v_nVolume    cost_expenses_list.volume%type := 0; --体积
    v_nWeight    cost_expenses_list.weight%type := 0; --重量
    v_nPrice     cost_expenses_list.reserved1%type := 0; --货值 --对应预留1
    v_nCell      cost_expenses_list.reserved2%type := 0; --货位 --对应预留2
    v_nReserved3 cost_expenses_list.reserved2%type := 0; --预留3
    v_nReserved4 cost_expenses_list.reserved2%type := 0; --预留4
    v_nReserved5 cost_expenses_list.reserved2%type := 0; --预留5
    v_nReserved6 cost_expenses_list.reserved2%type := 0; --预留6
  BEGIN
    strOutMsg := 'N|[P_INSERT_EXPENSES_LIST_NEW]';
    if strBillingUnit = '3' then
      --托盘数
      v_nTray := nQty;
    elsif strBillingUnit = '4' then
      --件数
      v_nQty := nQty;
    elsif strBillingUnit = '5' then
      --体积
      v_nVolume := nQty;
    elsif strBillingUnit = '6' then
      --重量
      v_nWeight := nQty / 1000;
    elsif strBillingUnit in ('7', '8') then
      --货值
      v_nPrice := nQty;
    elsif strBillingUnit = '9' then
      --货位
      v_nCell := nQty;
    else
      v_nQty := nQty;
    end if;
    select count(1)
      into v_nCount
      from COST_EXPENSES_LIST t
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWarehouseNo
       and t.owner_no = strOwnerNo
       and t.billing_project = strBilling_project
       and t.billing_type = strBillingType
       and t.family_no = strFamilyNo
       and t.source_no = strSourceNo
       and trunc(t.build_date) = trunc(dtDate);
    if v_nCount = 0 then
      if v_nTray = 0 and v_nQty = 0 and v_nVolume = 0 and v_nWeight = 0 and
         v_nPrice = 0 and v_nCell = 0 then
        null;
      else
        INSERT INTO COST_EXPENSES_LIST
          (ENTERPRISE_NO,
           WAREHOUSE_NO,
           OWNER_NO,
           BILLING_PROJECT,
           BILLING_TYPE,
           FAMILY_NO,
           BUILD_DATE,
           SOURCE_NO,
           SERIAL_NO,
           AREA,
           TRAY,
           QTY,
           VOLUME,
           WEIGHT,
           RESERVED1,
           RESERVED2,
           RESERVED3,
           RESERVED4,
           RESERVED5,
           RESERVED6,
           STATUS,
           FLAG,
           RGST_NAME,
           RGST_DATE)
        values
          (strEnterpriseNo,
           strWarehouseNo,
           strOwnerNo,
           strBilling_project,
           strBillingType,
           strFamilyNo,
           dtDate,
           strSourceNo,
           'N', --seq_bill_expenses_list.nextval,
           v_narea,
           v_nTray,
           v_nQty,
           v_nVolume,
           v_nWeight,
           v_nPrice,
           v_nCell,
           v_nreserved3,
           v_nreserved4,
           v_nreserved5,
           v_nreserved6,
           '10',
           strFlag,
           strWorkerNo,
           sysdate);
      end if;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_INSERT_EXPENSES_LIST_NEW;

  /***********************************************************************************************
  wyf
  20151208
  功能说明：根据消费清单生成费用明细表
  ***********************************************************************************************/
  procedure P_COST_DETAILS(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                           strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                           strOwnerNo         cost_formulaset.owner_no%type, --货主
                           strBilling_project cost_formulaset.billing_project%type, --计费项目 支持传空值
                           strBillingType     cost_formulaset.billing_type%type, --计费项目类型 支持传空值
                           dtDate             cost_formulaset.rgst_date%type, --开始日期
                           strFlag            cost_expenses_list.flag%type, --是否重算，0:代表正常日结生成，1：代表重算
                           strWorkerNo        cost_expenses_list.rgst_name%type,
                           strOutMsg          out varchar2) --返回值
   IS
    --v_nRow   integer := 0;
    v_dtDate cost_expenses_list.build_date%type;

    --v_nDay     integer := 1;
    --v_nLastDay integer := 0;
    v_dtStart cost_cost_list.begin_date%type; --起始日期
    v_dtEnd   cost_cost_list.end_date%type; --结束日期

    v_nQty       cost_cost_list.qty%type; --费用明细数量
    v_nAmount    cost_cost_list.amount%type; --费用金额
    v_nFavAmount cost_cost_list.favourable_amount%type; --优惠金额

    /*v_nMidValue     NUMBER; --中间值
    v_nMidFavQty    NUMBER; --中间值
    v_nMidFavAmount NUMBER; --优惠后金额
    v_strMidPro     VARCHAR2(3000);
    v_strMidFlag    VARCHAR2(3000);
    v_nMidDisAmount NUMBER;*/

    v_count       number;
    v_strSerialNo cost_expenses_list.serial_no%type;
    v_strNextFlag varchar2(1); --是否跳过  0：否 ，1：是
  BEGIN
    strOutMsg := 'N|[P_COST_DETAILS]';
    v_count   := 0;
    --锁计费项目表
    update cost_formulaset a
       set a.status = a.status
     where a.status = '0'
       and trunc(nvl(a.END_DATE, sysdate)) >= trunc(sysdate)
       and a.enterprise_no = strEnterpriseNo
       and a.warehouse_no = strWarehouseNo
       and a.owner_no = strOwnerNo
       and (a.billing_project = strBilling_project or
           strBilling_project is null)
       and (a.billing_type = strBillingType or strBillingType is null);

    /*if strFlag = 1 then
      --重算日期取传入日期
      v_dtDate := dtDate;
    else
      --系统自动计算取传入日期的前一天
      v_dtDate := dtDate - 1;
    end if;*/
    v_dtDate := dtDate - 1;
    for p in (select a.*
                from cost_formulaset a
               where a.status = '0'
                 and trunc(nvl(a.END_DATE, sysdate)) >= trunc(sysdate)
                 and a.enterprise_no = strEnterpriseNo
                 and a.warehouse_no = strWarehouseNo
                 and a.owner_no = strOwnerNo
                 and (a.billing_project = strBilling_project or
                     strBilling_project is null)
                 and (a.billing_type = strBillingType or
                     strBillingType is null)) loop
      --根据周期计算起始时间
      P_GETCYCLE_BEGINTOEND(p.billing_cycle,
                            p.balance_day,
                            v_dtDate,
                            v_dtStart,
                            v_dtEnd,
                            v_strNextFlag,
                            strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
      if v_strNextFlag = '1' then
        goto nextOne;
      end if;
      --重算处理
      --获取已存在的费用明细的SERIAL_NO，把相应的清单的SERIAL_NO置为N，并删除费用明细
      begin
        for S in (select distinct t.serial_no
                    from cost_cost_list t
                   where t.enterprise_no = p.enterprise_no
                     and t.warehouse_no = p.warehouse_no
                     and t.owner_no = p.owner_no
                     and t.billing_project = p.billing_project
                     and t.billing_type = p.billing_type
                     and t.build_date = trunc(v_dtDate)
                     and t.status = '10') loop
          if strFlag = '1' then
            --更新费用清单的serial_no为N
            update cost_expenses_list t
               set t.serial_no = 'N', t.status = '10'
             where t.serial_no = S.serial_no;
            --删除费用明细
            delete from cost_cost_list t where t.serial_no = S.serial_no;
          end if;
        end loop;
      end;
      --获取清单的数量
      select case p.billing_unit
             --托盘
               when '3' then
                nvl(sum(TRAY), 0)
               when '4' then
                nvl(sum(QTY), 0)
               when '5' then
                nvl(sum(VOLUME), 0)
               when '6' then
                nvl(sum(WEIGHT), 0)
               when '7' then
               --货值（商品价）
                nvl(sum(RESERVED1), 0)
               when '8' then
               --货值（进货价）
                nvl(sum(RESERVED1), 0)
               when '9' then
               --货位
                nvl(sum(RESERVED2), 0)
               else
                nvl(sum(QTY), 0)
             end
        into v_nQty
        from cost_expenses_list t
       where t.enterprise_no = p.enterprise_no
         and t.warehouse_no = p.warehouse_no
         and t.owner_no = p.owner_no
         and t.billing_type = p.billing_type
         and t.billing_project = p.billing_project
         and t.build_date between v_dtStart and v_dtEnd
         and t.status = '10'
         and t.serial_no = 'N';
      if p.BILLING_FLAG = '1' then
        --固定费用
        v_nAmount    := p.FIXED_VALUE;
        v_nFavAmount := 0;
      else
        --动态费用
        v_nAmount    := v_nQty * p.unit_price;
        v_nFavAmount := 0;
        /*根据策略计算优惠金额*/
        P_PROJECT_DISCOUNT(strEnterpriseNo,
                           strWarehouseNo,
                           strOwnerNo,
                           p.billing_project,
                           p.billing_type,
                           v_nQty,
                           v_nAmount,
                           v_nFavAmount,
                           strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;

        /*v_nMidFavQty    := '0';
        v_nMidFavAmount := v_nAmount;
        v_strMidPro     := ' ';
        v_strMidFlag    := ' ';
        --费用金额
        v_nMidValue := v_nAmount;
        --获取优惠策略
        for rule in (select *
                       from COST_FORMULA_DISCOUNT a
                      where a.enterprise_no = p.enterprise_no
                        and a.warehouse_no = p.warehouse_no
                        and a.owner_no = p.owner_no
                        and a.billing_type = p.billing_type
                        and a.billing_project = p.billing_project
                      order by a.LADDER desc) loop
          v_nRow := v_nRow + 1;
          --根据优惠策略计算优惠金额
          if rule.discount_flag = '1' then
            --消费值只对超出“值1”部分计费
            if v_nAmount > rule.value1 then
              if nvl(instr(v_strMidFlag, '#' || rule.DISCOUNT_FLAG || '#'),
                     0) = 0 then
                v_nMidFavAmount := v_nAmount - rule.value1;
                v_strMidFlag    := v_strMidFlag || '#' ||
                                   rule.DISCOUNT_FLAG || '#';
              end if;
            else
              v_nMidFavAmount := 0;
            end if;
          elsif rule.discount_flag = '2' then
            --费用不足“值1”，按“值1”算
            if v_nAmount < rule.value1 then
              if nvl(instr(v_strMidFlag, '#' || rule.DISCOUNT_FLAG || '#'),
                     0) = 0 then
                v_nMidFavAmount := rule.value1;
                v_strMidFlag    := v_strMidFlag || '#' ||
                                   rule.DISCOUNT_FLAG || '#';
              end if;
            end if;
          elsif rule.discount_flag = '3' then
            --费用超出“值1”，按“值2”算
            if v_nAmount > rule.value1 then
              if nvl(instr(v_strMidFlag, '#' || rule.DISCOUNT_FLAG || '#'),
                     0) = 0 then
                v_nMidFavAmount := rule.value2;
                v_strMidFlag    := v_strMidFlag || '#' ||
                                   rule.DISCOUNT_FLAG || '#';
              end if;
            end if;
          elsif rule.discount_flag = '4' then
            --费用超出“值1”，按“值2”打折
            if v_nAmount > rule.value1 then
              if nvl(instr(v_strMidFlag, '#' || rule.DISCOUNT_FLAG || '#'),
                     0) = 0 then
                v_nMidFavAmount := v_nAmount * rule.value1;
                v_strMidFlag    := v_strMidFlag || '#' ||
                                   rule.DISCOUNT_FLAG || '#';
              end if;
            end if;
          elsif rule.discount_flag = '5' then
            --费用超出“值1”的部分，按“值2”打折
            if v_nAmount > rule.value1 then
              v_nMidDisAmount := v_nMidDisAmount +
                                 (v_nMidValue - rule.VALUE1) * rule.VALUE2;
              v_nMidFavAmount := v_nAmount - v_nMidDisAmount;
            end if;
          end if;
          v_nMidValue := rule.VALUE1;
        end loop;
        --计算优惠金额
        select decode(sign(v_nAmount - v_nMidFavAmount),
                      -1,
                      0,
                      v_nAmount - v_nMidFavAmount)
          into v_nFavAmount
          from dual;*/
      end if;
      v_strSerialNo := SEQ_BILL_COST_LIST.NEXTVAL;
      if v_nQty = 0 then
        goto nextOne;
      else
        insert into cost_cost_list
          (enterprise_no,
           warehouse_no,
           owner_no,
           billing_project,
           billing_type,
           build_date,
           serial_no,
           begin_date,
           end_date,
           qty,
           amount,
           favourable_amount,
           status,
           flag,
           account_no,
           check_no,
           RGST_NAME,
           RGST_DATE,
           COST_FLAG)
        values
          (strEnterpriseNo,
           strWarehouseNo,
           strOwnerNo,
           p.billing_project,
           p.billing_type,
           v_dtDate,
           v_strSerialNo, --SEQ_BILL_COST_LIST.NEXTVAL,
           v_dtStart,
           v_dtEnd,
           v_nQty,
           v_nAmount,
           v_nFavAmount,
           '10',
           strFlag,
           'N',
           'N',
           strWorkerNo,
           sysdate,
           p.cost_flag);
        update cost_expenses_list t
           set t.serial_no = v_strSerialNo,
               t.status    = '13',
               t.updt_name = strWorkerNo,
               t.updt_date = sysdate
         where t.enterprise_no = p.enterprise_no
           and t.warehouse_no = p.warehouse_no
           and t.owner_no = p.owner_no
           and t.billing_type = p.billing_type
           and t.billing_project = p.billing_project
           and t.build_date between v_dtStart and v_dtEnd
           and t.status = '10'
           and t.serial_no = 'N';
      end if;

      <<nextOne>>
      null;
    end loop;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_COST_DETAILS;
  /***********************************************************************************************
  hcx
  20160125
  功能说明：手工生成费用明细
  ***********************************************************************************************/
  procedure P_COST_DETAILS_BYHAND(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                                  strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                                  strOwnerNo         cost_formulaset.owner_no%type, --货主
                                  dtDate             cost_cost_list.build_date%type,
                                  dtStart            cost_cost_list.begin_date%type,
                                  dtEnd              cost_cost_list.end_date%type,
                                  strBilling_project cost_formulaset.billing_project%type, --计费项目编码
                                  strBillingType     cost_formulaset.billing_type%type, --计费项目类型
                                  strFlag            cost_expenses_list.flag%type, --是否重算 0:首次生成费用 , 1:重算
                                  strDiscountFlag    varchar2, --是否使用优惠策略--0:不使用，1:使用
                                  strWorkerNo        cost_financial.rgst_name%type,
                                  strOutMsg          out varchar2) --返回值
   IS

    v_nQty       cost_cost_list.qty%type; --费用明细数量
    v_nAmount    cost_cost_list.amount%type; --费用金额
    v_nFavAmount cost_cost_list.favourable_amount%type; --优惠金额

    v_strSerialNo cost_expenses_list.serial_no%type;
  BEGIN
    strOutMsg := 'N|[P_COST_DETAILS_BYHAND]';
    --锁计费项目表
    update cost_formulaset a
       set a.status = a.status
     where a.status = '0'
       and trunc(nvl(a.END_DATE, sysdate)) >= trunc(sysdate)
       and a.enterprise_no = strEnterpriseNo
       and a.warehouse_no = strWarehouseNo
       and a.owner_no = strOwnerNo
       and (a.billing_project = strBilling_project or
           strBilling_project is null)
       and (a.billing_type = strBillingType or strBillingType is null);

    for p in (select a.*
                from cost_formulaset a
               where a.status = '0'
                 and nvl(a.END_DATE, sysdate) >= sysdate
                 and a.enterprise_no = strEnterpriseNo
                 and a.warehouse_no = strWarehouseNo
                 and a.owner_no = strOwnerNo
                 and (a.billing_project = strBilling_project or
                     strBilling_project is null)
                 and (a.billing_type = strBillingType or
                     strBillingType is null)) loop

      --获取清单的数量
      select case p.billing_unit
             --托盘
               when '3' then
                nvl(sum(TRAY), 0)
               when '4' then
                nvl(sum(QTY), 0)
               when '5' then
                nvl(sum(VOLUME), 0)
               when '6' then
                nvl(sum(WEIGHT), 0)
               when '7' then
               --货值（商品价）
                nvl(sum(RESERVED1), 0)
               when '8' then
               --货值（进货价）
                nvl(sum(RESERVED1), 0)
               when '9' then
               --货位
                nvl(sum(RESERVED2), 0)
               else
                nvl(sum(QTY), 0)
             end
        into v_nQty
        from cost_expenses_list t
       where t.enterprise_no = p.enterprise_no
         and t.warehouse_no = p.warehouse_no
         and t.owner_no = p.owner_no
         and t.billing_type = p.billing_type
         and t.billing_project = p.billing_project
         and t.build_date between dtStart and dtEnd
         and t.status = '11'
         and t.serial_no = 'N';
      if p.BILLING_FLAG = '1' then
        --固定费用
        v_nAmount    := p.FIXED_VALUE;
        v_nFavAmount := 0;
      else
        --动态费用
        v_nAmount    := v_nQty * p.unit_price;
        v_nFavAmount := 0;
        if strDiscountFlag = '1' then
          /*根据策略计算优惠金额*/
          P_PROJECT_DISCOUNT(strEnterpriseNo,
                             strWarehouseNo,
                             strOwnerNo,
                             p.billing_project,
                             p.billing_type,
                             v_nQty,
                             v_nAmount,
                             v_nFavAmount,
                             strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        end if;
      end if;
      v_strSerialNo := SEQ_BILL_COST_LIST.NEXTVAL;
      insert into cost_cost_list
        (enterprise_no,
         warehouse_no,
         owner_no,
         billing_project,
         billing_type,
         build_date,
         serial_no,
         begin_date,
         end_date,
         qty,
         amount,
         favourable_amount,
         status,
         flag,
         account_no,
         check_no,
         RGST_NAME,
         RGST_DATE,
         COST_FLAG,
         create_flag)
      values
        (strEnterpriseNo,
         strWarehouseNo,
         strOwnerNo,
         p.billing_project,
         p.billing_type,
         dtDate,
         v_strSerialNo, --SEQ_BILL_COST_LIST.NEXTVAL,
         dtStart,
         dtEnd,
         v_nQty,
         v_nAmount,
         v_nFavAmount,
         '10',
         strFlag,
         'N',
         'N',
         strWorkerNo,
         sysdate,
         p.cost_flag,
         '1');
      update cost_expenses_list t
         set t.serial_no = v_strSerialNo,
             t.status    = '13',
             t.updt_name = strWorkerNo,
             t.updt_date = sysdate
       where t.enterprise_no = p.enterprise_no
         and t.warehouse_no = p.warehouse_no
         and t.owner_no = p.owner_no
         and t.billing_type = p.billing_type
         and t.billing_project = p.billing_project
         and t.build_date between dtStart and dtEnd
         and t.status = '11'
         and t.serial_no = 'N';
      <<nextOne>>
      null;
    end loop;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end P_COST_DETAILS_BYHAND;
  /***********************************************************************************************
  wyf
  20151210
  功能说明：通过计费项目优惠策略计算优惠后金额
  ***********************************************************************************************/
  procedure P_PROJECT_DISCOUNT(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                               strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                               strOwnerNo         cost_formulaset.owner_no%type, --货主
                               strBilling_project cost_formulaset.billing_project%type, --计费项目
                               strBillingType     cost_formulaset.billing_type%type, --计费项目类型
                               nQty               cost_cost_list.qty%type,
                               nAmount            cost_cost_list.amount%type,
                               nFavAmount         out cost_cost_list.favourable_amount%type, --优惠金额
                               strOutMsg          out varchar2) IS
    v_nRow    integer := 0;
    v_nQty    cost_cost_list.qty%type; --费用明细数量
    v_nAmount cost_cost_list.amount%type; --费用金额
    --v_nFavAmount    cost_cost_list.favourable_amount%type; --优惠金额
    v_nMidValue NUMBER; --中间值
    --v_nMidFavQty    NUMBER; --中间值
    v_nMidFavAmount NUMBER; --优惠后金额
    --v_strMidPro     VARCHAR2(3000);
    v_strMidFlag    VARCHAR2(3000);
    v_nMidDisAmount NUMBER;
  BEGIN
    strOutMsg := 'N|[P_PROJECT_DISCOUNT]';
    v_nQty    := nQty;
    v_nAmount := nAmount;

    --v_nMidFavQty    := '0';
    v_nMidFavAmount := v_nAmount;
    --v_strMidPro     := ' ';
    v_strMidFlag := ' ';
    --费用金额
    v_nMidValue := v_nAmount;
    --获取优惠策略
    for rule in (select *
                   from COST_FORMULA_DISCOUNT a
                  where a.enterprise_no = strEnterpriseNo
                    and a.warehouse_no = strWarehouseNo
                    and a.owner_no = strOwnerNo
                    and a.billing_type = strBillingType
                    and a.billing_project = strBilling_project
                  order by a.LADDER desc) loop
      v_nRow := v_nRow + 1;
      --根据优惠策略计算优惠金额
      if rule.discount_flag = '1' then
        --消费值只对超出“值1”部分计费
        if v_nAmount > rule.value1 then
          if nvl(instr(v_strMidFlag, '#' || rule.DISCOUNT_FLAG || '#'), 0) = 0 then
            v_nMidFavAmount := v_nAmount - rule.value1;
            v_strMidFlag    := v_strMidFlag || '#' || rule.DISCOUNT_FLAG || '#';
          end if;
        else
          v_nMidFavAmount := 0;
        end if;
      elsif rule.discount_flag = '2' then
        --费用不足“值1”，按“值1”算
        if v_nAmount < rule.value1 then
          if nvl(instr(v_strMidFlag, '#' || rule.DISCOUNT_FLAG || '#'), 0) = 0 then
            v_nMidFavAmount := rule.value1;
            v_strMidFlag    := v_strMidFlag || '#' || rule.DISCOUNT_FLAG || '#';
          end if;
        end if;
      elsif rule.discount_flag = '3' then
        --费用超出“值1”，按“值2”算
        if v_nAmount > rule.value1 then
          if nvl(instr(v_strMidFlag, '#' || rule.DISCOUNT_FLAG || '#'), 0) = 0 then
            v_nMidFavAmount := rule.value2;
            v_strMidFlag    := v_strMidFlag || '#' || rule.DISCOUNT_FLAG || '#';
          end if;
        end if;
      elsif rule.discount_flag = '4' then
        --费用超出“值1”，按“值2”打折
        if v_nAmount > rule.value1 then
          if nvl(instr(v_strMidFlag, '#' || rule.DISCOUNT_FLAG || '#'), 0) = 0 then
            v_nMidFavAmount := v_nAmount * rule.value1;
            v_strMidFlag    := v_strMidFlag || '#' || rule.DISCOUNT_FLAG || '#';
          end if;
        end if;
      elsif rule.discount_flag = '5' then
        --费用超出“值1”的部分，按“值2”打折
        if v_nAmount > rule.value1 then
          v_nMidDisAmount := v_nMidDisAmount +
                             (v_nMidValue - rule.VALUE1) * rule.VALUE2;
          v_nMidFavAmount := v_nAmount - v_nMidDisAmount;
        end if;
      end if;
      v_nMidValue := rule.VALUE1;
    end loop;
    --计算优惠金额
    select /*decode(sign(v_nAmount - v_nMidFavAmount),
                                                                                                                                              -1,
                                                                                                                                              0,
                                                                                                                                              v_nAmount - v_nMidFavAmount)*/
     v_nAmount - v_nMidFavAmount
      into nFavAmount
      from dual;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_PROJECT_DISCOUNT;
  /***********************************************************************************************
  wyf
  20151214
  功能说明：费用明细回退
  ***********************************************************************************************/
  procedure P_REBACK_COST_DETAILS(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                                  strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                                  strOwnerNo         cost_formulaset.owner_no%type, --货主
                                  strBilling_project cost_formulaset.billing_project%type, --计费项目 支持传空值
                                  strBillingType     cost_formulaset.billing_type%type, --计费项目类型 支持传空值
                                  dtDate             cost_formulaset.rgst_date%type, --开始日期
                                  strSerialNo        cost_cost_list.serial_no%type, --流水号
                                  strOutMsg          out varchar2) IS
  BEGIN
    strOutMsg := 'N|[P_REBACK_COST_DETAILS]';
    for p in (select a.*
                from cost_formulaset a
               where a.enterprise_no = strEnterpriseNo
                 and a.warehouse_no = strWarehouseNo
                 and a.owner_no = strOwnerNo
                 and (a.billing_project = strBilling_project or
                     strBilling_project is null)
                 and (a.billing_type = strBillingType or
                     strBillingType is null)) loop
      --将费用明细重算，删除费用明细，更新消费清单的status=13 serial_no=N
      for S in (select distinct t.serial_no, status
                  from cost_cost_list t
                 where t.enterprise_no = p.enterprise_no
                   and t.warehouse_no = p.warehouse_no
                   and t.owner_no = p.owner_no
                   and t.billing_project = p.billing_project
                   and t.billing_type = p.billing_type
                   and t.build_date = trunc(dtDate)
                   and t.serial_no = strSerialNo
                   and t.status = '10') loop
        --只有还会生成对账单的费用明细允许回退
        --if p.status = '10' then
        --更新费用清单的serial_no为N
        update cost_expenses_list t
           set t.serial_no = 'N', t.status = '10'
         where t.serial_no = S.serial_no;
        --删除费用明细
        delete from cost_cost_list t where t.serial_no = S.serial_no;
        --end if;
      end loop;
    end loop;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_REBACK_COST_DETAILS;
  /***********************************************************************************************
  lich
  20140729
  功能说明：根据消费清单自动生成账单
  ***********************************************************************************************/
  procedure P_FINANCIAL_DETAILS_BYAUTO(strEnterpriseNo cost_formulaset.enterprise_no%type, --企业
                                       strWarehouseNo  cost_formulaset.warehouse_no%type, --仓别
                                       strOwnerNo      cost_formulaset.owner_no%type, --货主
                                       --strMonth         varchar, --月份
                                       dtDate            cost_cost_list.build_date%type,
                                       strAccountGroupNo cost_account_d.account_group_no%type, --科目组编码（允许为空，但重算时必须传）
                                       --strAccountNo      cost_financial.account_no%type, --科目编码（允许为空，但重算时必须传）
                                       strCheckNo  cost_financial.check_no%type, --对账单号（允许为空，但重算时必须传）
                                       strFlag     cost_expenses_list.flag%type, --是否重算 0:自动 , 1:重算
                                       strWorkerNo cost_financial.rgst_name%type,
                                       strOutMsg   out varchar2) --返回值
   IS
    v_dtDate  cost_financial.build_date%type;
    v_dtStart cost_financial.build_date%type;
    v_dtEnd   cost_financial.build_date%type;

    v_strCheckNo cost_financial.check_no%type;
    v_nCount     integer;

    v_strNextFlag varchar2(1); --是否跳过  0：否 ，1：是
  BEGIN
    strOutMsg := 'N|[P_FINANCIAL_DETAILS_BYAUTO]';

    --获取费用明细
    if strFlag = '1' then
      --重算
      v_dtDate     := dtDate - 1;
      v_strCheckNo := strCheckNo;

      select count(1)
        into v_nCount
        from cost_financial a
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWarehouseNo
         and a.owner_no = strOwnerNo
         and a.check_no = v_strCheckNo
         and a.status > '10';
      if v_nCount > 0 then
        strOutMsg := 'N|[已开始缴费的对账单无法重算！]';
        return;
      end if;
      --获取账单起始日期，结束日期，记账日期
      select distinct a.begin_date, a.end_date, a.build_date
        into v_dtStart, v_dtEnd, v_dtDate
        from cost_financial a
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWarehouseNo
         and a.owner_no = strOwnerNo
         and a.check_no = v_strCheckNo;
      --删除账单
      delete from cost_financial a
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWarehouseNo
         and a.owner_no = strOwnerNo
         and a.check_no = v_strCheckNo;
      --更新费用明细状态
      update cost_cost_list a
         set a.status = '10', a.check_no = 'N'
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWarehouseNo
         and a.owner_no = strOwnerNo
         and a.check_no = v_strCheckNo;
      --更新其他费用状态
      update cost_other_list a
         set a.status = '10', a.check_no = 'N'
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWarehouseNo
         and a.owner_no = strOwnerNo
         and a.check_no = v_strCheckNo;
      for acc in (select *
                    from cost_account_d t
                   where t.enterprise_no = strEnterpriseNo
                     and t.warehouse_no = strWarehouseNo
                     and t.owner_no = strOwnerNo
                     and t.account_group_no = strAccountGroupNo
                   order by t.ACCOUNT_ID) loop
        --新增账单
        P_INSERT_FINANCIAL(strEnterpriseNo,
                           strWarehouseNo,
                           strOwnerNo,
                           v_dtDate,
                           v_dtStart,
                           v_dtEnd,
                           acc.account_no,
                           v_strCheckNo,
                           strFlag,
                           strWorkerNo,
                           strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
      end loop;
    else
      --自动
      v_dtDate     := dtDate - 1;
      v_strCheckNo := 'N';
      --获取科目头档
      for p in (select *
                  from cost_account_m t
                 where t.enterprise_no = strEnterpriseNo
                   and t.warehouse_no = strWarehouseNo
                   and t.owner_no = strOwnerNo
                   and t.status = '0') loop
        --根据周期计算起始时间
        P_GETCYCLE_BEGINTOEND(p.ACCOUNT_CYCLE,
                              p.balance_day,
                              v_dtDate,
                              v_dtStart,
                              v_dtEnd,
                              v_strNextFlag,
                              strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
        if v_strNextFlag = '1' then
          goto nextOne;
        end if;
        for acc in (select *
                      from cost_account_d t
                     where t.enterprise_no = p.enterprise_no
                       and t.warehouse_no = p.warehouse_no
                       and t.owner_no = p.owner_no
                       and t.account_group_no = p.account_group_no
                     order by t.ACCOUNT_ID) loop
          --新增账单
          P_INSERT_FINANCIAL(strEnterpriseNo,
                             strWarehouseNo,
                             strOwnerNo,
                             v_dtDate,
                             v_dtStart,
                             v_dtEnd,
                             acc.account_no,
                             v_strCheckNo,
                             strFlag,
                             strWorkerNo,
                             strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        end loop;
        /*--获取科目明细
        for acc in (select *
                      from cost_account_d t
                     where t.enterprise_no = p.enterprise_no
                       and t.warehouse_no = p.warehouse_no
                       and t.owner_no = p.owner_no
                       and t.account_group_no = p.account_group_no
                     order by t.ACCOUNT_ID) loop
          --计算消费明细费用
          select sum(a.amount - a.favourable_amount)
            into v_nAmount
            from cost_cost_list a, cost_account_formula b
           where b.enterprise_no = acc.enterprise_no
             and b.warehouse_no = acc.warehouse_no
             and b.owner_no = acc.owner_no
             and b.account_no = acc.account_no
             and a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and a.owner_no = b.owner_no
             and a.billing_project = b.billing_project
             and a.billing_type = b.billing_type
             and a.build_date between v_dtStart and v_dtEnd
             and a.check_no = 'N'
             and a.status = '10';
          v_nDiscountAmount := v_nAmount;
          --根据策略计算出优惠后金额
          P_ACCOUNT_DISCOUNT(strEnterpriseNo,
                             strWarehouseNo,
                             strOwnerNo,
                             acc.account_no,
                             v_dtStart,
                             v_dtEnd,
                             v_nAmount,
                             v_nDiscountAmount,
                             strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
          --获取记账单号
          if v_strCheckNo is null or v_strCheckNo = 'N' then
            PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                       strWarehouseNo,
                                       CONST_DOCUMENTTYPE.COST,
                                       v_strCheckNo,
                                       strOutMsg);
            if (v_strCheckNo is null or substr(strOutMsg, 1, 1) = 'N') then
              strOutMsg := 'N|取对账单号错误!';
              return;
            end if;
          end if;
          --新增账单
          insert into cost_financial
            (enterprise_no,
             warehouse_no,
             owner_no,
             account_no,
             check_no,
             amount,
             discount_amount,
             real_amount,
             begin_date,
             end_date,
             flag,
             build_date,
             status,
             rgst_name,
             rgst_date,
             create_flag,
             cost_flag)
          values
            (strEnterpriseNo,
             strWarehouseNo,
             strOwnerNo,
             acc.account_no,
             v_strCheckNo,
             v_nAmount,
             decode(sign(v_nAmount - v_nDiscountAmount),
                    -1,
                    0,
                    v_nAmount - v_nDiscountAmount),
             0,
             v_dtStart,
             v_dtEnd,
             strFlag,
             v_dtDate,
             '10',
             strWorkerNo,
             sysdate,
             '0',
             '0');
          --更新费用明细对账单号和状态
          update cost_cost_list t
             set t.status     = '13',
                 t.check_no   = v_strCheckNo,
                 t.account_no = acc.account_no,
                 t.updt_name  = strWorkerNo,
                 t.updt_date  = sysdate
           where t.enterprise_no = strEnterpriseNo
             and t.warehouse_no = strWarehouseNo
             and t.owner_no = strOwnerNo
             and exists (select 1
                    from cost_account_formula b
                   where t.enterprise_no = b.enterprise_no
                     and t.warehouse_no = b.warehouse_no
                     and t.owner_no = b.owner_no
                     and t.billing_project = b.billing_project
                     and t.billing_type = b.billing_type
                     and b.account_no = acc.account_no)
             and t.build_date between v_dtStart and v_dtEnd
             and t.check_no = 'N'
             and t.status = '10';
        end loop;*/

        <<nextOne>>
        null;
        --计算其他费用
        --系统自动生成账单须更新时间区间内未记账的其他费用状态为11，再生成账单
        update cost_other_list t
           set t.status = '11'
         where t.enterprise_no = strEnterpriseNo
           and t.warehouse_no = strWarehouseNo
           and t.owner_no = strOwnerNo
           and t.cost_date between v_dtStart and v_dtEnd
           and t.status = '10';
        P_OTHERCOST_DETAILS(strEnterpriseNo,
                            strWarehouseNo,
                            strOwnerNo,
                            v_dtDate,
                            v_dtStart,
                            v_dtEnd,
                            v_strCheckNo,
                            strFlag,
                            '0',
                            strWorkerNo,
                            strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
        --置对账单号为空
        v_strCheckNo := 'N';
      end loop;

    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_FINANCIAL_DETAILS_BYAUTO;

  /***********************************************************************************************
  wyf
  20151210
  功能说明：手工出对账单
  ***********************************************************************************************/
  procedure P_FINANCIAL_DETAILS_BYHAND(strEnterpriseNo cost_formulaset.enterprise_no%type, --企业
                                       strWarehouseNo  cost_formulaset.warehouse_no%type, --仓别
                                       strOwnerNo      cost_formulaset.owner_no%type, --货主
                                       dtDate          cost_cost_list.build_date%type,
                                       dtStart         cost_cost_list.begin_date%type,
                                       dtEnd           cost_cost_list.end_date%type,
                                       strAccountNo    cost_financial.account_no%type, --科目编码（允许为空，但重算时必须传）
                                       strCheckNo      cost_financial.check_no%type, --对账单号（允许为空，但重算时必须传）
                                       strFlag         cost_expenses_list.flag%type, --是否重算 0:首次出账 , 1:重算
                                       strDiscountFlag varchar2, --是否使用优惠策略--0:不使用，1:使用
                                       strWorkerNo     cost_financial.rgst_name%type,
                                       strOutMsg       out varchar2) --返回值
   IS
    v_nAmount         cost_cost_list.amount%type; --按消费清单算出的金额
    v_nDiscountAmount cost_cost_list.amount%type; --优惠后的金额

    v_nCount     integer;
    v_strCheckNo cost_financial.check_no%type;
  BEGIN
    strOutMsg := 'N|[P_FINANCIAL_DETAILS_BYHAND]';
    v_nCount  := 0;
    if strFlag = '0' then
      v_strCheckNo := 'N';
      --获取已选费用明细
      for p in (select b.account_no,
                       t.billing_project,
                       t.billing_type,
                       nvl(sum(t.qty), 0) qty,
                       nvl(sum(t.amount), 0) amount,
                       nvl(sum(t.favourable_amount), 0) favourable_amount
                  from cost_cost_list t, cost_account_formula b
                 where t.enterprise_no = strEnterpriseNo
                   and t.warehouse_no = strWarehouseNo
                   and t.owner_no = strOwnerNo
                   and t.status = '11'
                   and t.enterprise_no = b.enterprise_no
                   and t.warehouse_no = b.warehouse_no
                   and t.owner_no = b.owner_no
                   and t.billing_type = b.billing_type
                   and t.billing_project = b.billing_project
                 group by b.account_no, t.billing_project, t.billing_type) loop
        for acc in (select *
                      from cost_account_d a
                     where a.enterprise_no = strEnterpriseNo
                       and a.warehouse_no = strWarehouseNo
                       and a.owner_no = strOwnerNo
                       and a.account_no = p.account_no) loop
          --计算消费明细费用
          select nvl(sum(a.amount - a.favourable_amount), 0)
            into v_nAmount
            from cost_cost_list a, cost_account_formula b
           where b.enterprise_no = acc.enterprise_no
             and b.warehouse_no = acc.warehouse_no
             and b.owner_no = acc.owner_no
             and b.account_no = acc.account_no
             and a.enterprise_no = b.enterprise_no
             and a.warehouse_no = b.warehouse_no
             and a.owner_no = b.owner_no
             and a.billing_project = b.billing_project
             and a.billing_type = b.billing_type
             and a.status = '11';
          if v_nAmount = 0 then
            null;
          else
            if strDiscountFlag = '1' then
              --根据策略计算出优惠后金额
              P_ACCOUNT_DISCOUNT(strEnterpriseNo,
                                 strWarehouseNo,
                                 strOwnerNo,
                                 acc.account_no,
                                 dtStart,
                                 dtEnd,
                                 v_nAmount,
                                 v_nDiscountAmount,
                                 strOutMsg);
              if substr(strOutMsg, 1, 1) <> 'Y' then
                return;
              end if;
            end if;
            --获取记账单号
            if v_strCheckNo is null or v_strCheckNo = 'N' then
              PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                         strWarehouseNo,
                                         CONST_DOCUMENTTYPE.COST,
                                         v_strCheckNo,
                                         strOutMsg);
              if (v_strCheckNo is null or substr(strOutMsg, 1, 1) = 'N') then
                strOutMsg := 'N|取对账单号错误!';
                return;
              end if;
            end if;
            --新增账单
            insert into cost_financial
              (enterprise_no,
               warehouse_no,
               owner_no,
               account_no,
               check_no,
               amount,
               discount_amount,
               real_amount,
               begin_date,
               end_date,
               flag,
               build_date,
               status,
               rgst_name,
               rgst_date,
               create_flag,
               cost_flag)
            values
              (strEnterpriseNo,
               strWarehouseNo,
               strOwnerNo,
               acc.account_no,
               v_strCheckNo,
               v_nAmount,
               decode(sign(v_nAmount - v_nDiscountAmount),
                      -1,
                      0,
                      v_nAmount - v_nDiscountAmount),
               0,
               dtStart,
               dtEnd,
               strFlag,
               dtDate,
               '10',
               strWorkerNo,
               sysdate,
               '1',
               '0');
            --更新费用明细的对账单号和状态
            update cost_cost_list t
               set t.status     = '13',
                   t.check_no   = v_strCheckNo,
                   t.account_no = acc.account_no,
                   t.updt_name  = strWorkerNo,
                   t.updt_date  = sysdate
             where t.enterprise_no = strEnterpriseNo
               and t.warehouse_no = strWarehouseNo
               and t.owner_no = strOwnerNo
               and exists
             (select 1
                      from cost_account_formula b
                     where t.enterprise_no = b.enterprise_no
                       and t.warehouse_no = b.warehouse_no
                       and t.owner_no = b.owner_no
                       and t.billing_project = b.billing_project
                       and t.billing_type = b.billing_type
                       and b.account_no = acc.account_no)
               and t.status = '11';
          end if;
        end loop;

      end loop;
      --计算其他费用
      --手工生成账单在界面勾选确认后须更新其他费用的状态为11
      P_OTHERCOST_DETAILS(strEnterpriseNo,
                          strWarehouseNo,
                          strOwnerNo,
                          dtDate,
                          dtStart,
                          dtEnd,
                          v_strCheckNo,
                          strFlag,
                          '1',
                          strWorkerNo,
                          strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
    else
      --重算则直接删除，返回手工记账界面重新选择
      v_strCheckNo := strCheckNo;
      select count(1)
        into v_nCount
        from cost_financial a
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWarehouseNo
         and a.owner_no = strOwnerNo
         and a.check_no = v_strCheckNo
         and a.status > '10';
      if v_nCount > 0 then
        strOutMsg := 'N|[已开始缴费的对账单无法重算！]';
        return;
      end if;

      delete from cost_financial a
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWarehouseNo
         and a.owner_no = strOwnerNo
         and a.check_no = v_strCheckNo;
      --更新费用明细状态
      update cost_cost_list a
         set a.status = '10', a.check_no = 'N'
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWarehouseNo
         and a.owner_no = strOwnerNo
         and a.check_no = v_strCheckNo;
      --更新其他费用状态
      update cost_other_list a
         set a.status = '10', a.check_no = 'N'
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWarehouseNo
         and a.owner_no = strOwnerNo
         and a.check_no = v_strCheckNo;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_FINANCIAL_DETAILS_BYHAND;

  /***********************************************************************************************
  weiyf
  20151211
  功能说明：根据消费清单自动生成账单
  ***********************************************************************************************/
  procedure P_INSERT_FINANCIAL(strEnterpriseNo cost_formulaset.enterprise_no%type, --企业
                               strWarehouseNo  cost_formulaset.warehouse_no%type, --仓别
                               strOwnerNo      cost_formulaset.owner_no%type, --货主
                               dtDate          cost_cost_list.build_date%type,
                               dtStart         cost_cost_list.begin_date%type,
                               dtEnd           cost_cost_list.end_date%type,
                               strAccountNo    cost_account_d.account_no%type, --科目组编码
                               strCheckNo      in out cost_financial.check_no%type, --对账单号（允许为空，但重算时必须传）
                               strFlag         cost_expenses_list.flag%type, --是否重算 0:自动 , 1:重算
                               strWorkerNo     cost_financial.rgst_name%type,
                               strOutMsg       out varchar2) IS

    v_nAmount         cost_cost_list.amount%type; --按消费清单算出的金额
    v_nDiscountAmount cost_cost_list.amount%type; --优惠后的金额
    v_strCheckNo      cost_financial.check_no%type;
    v_strCostFlag     cost_formulaset.cost_flag%type; --应收应付标识 0：应收，1：应付
  BEGIN
    strOutMsg    := 'N|[P_INSERT_FINANCIAL]';
    v_strCheckNo := strCheckNo;
    --获取科目明细
    for acc in (select *
                  from cost_account_d t
                 where t.enterprise_no = strEnterpriseNo
                   and t.warehouse_no = strWarehouseNo
                   and t.owner_no = strOwnerNo
                   and t.account_no = strAccountNo
                 order by t.ACCOUNT_ID) loop
      --计算消费明细费用
      for p in (select nvl(sum(a.amount - a.favourable_amount), 0) amount,
                       a.cost_flag
                --into v_nAmount, v_strCostFlag
                  from cost_cost_list a, cost_account_formula b
                 where b.enterprise_no = acc.enterprise_no
                   and b.warehouse_no = acc.warehouse_no
                   and b.owner_no = acc.owner_no
                   and b.account_no = acc.account_no
                   and a.enterprise_no = b.enterprise_no
                   and a.warehouse_no = b.warehouse_no
                   and a.owner_no = b.owner_no
                   and a.billing_project = b.billing_project
                   and a.billing_type = b.billing_type
                   and a.build_date between dtStart and dtEnd
                   and a.check_no = 'N'
                   and a.status = '10'
                 group by a.cost_flag) loop
        v_nAmount         := p.amount;
        v_nDiscountAmount := v_nAmount;
        v_strCostFlag     := p.cost_flag;
        if v_nAmount = 0 then
          null;
        else
          --根据策略计算出优惠后金额
          P_ACCOUNT_DISCOUNT(strEnterpriseNo,
                             strWarehouseNo,
                             strOwnerNo,
                             acc.account_no,
                             dtStart,
                             dtEnd,
                             v_nAmount,
                             v_nDiscountAmount,
                             strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
          --获取记账单号
          if v_strCheckNo is null or v_strCheckNo = 'N' then
            PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                       strWarehouseNo,
                                       CONST_DOCUMENTTYPE.COST,
                                       v_strCheckNo,
                                       strOutMsg);
            if (v_strCheckNo is null or substr(strOutMsg, 1, 1) = 'N') then
              strOutMsg := 'N|取对账单号错误!';
              return;
            end if;
          end if;
          --新增账单
          insert into cost_financial
            (enterprise_no,
             warehouse_no,
             owner_no,
             account_no,
             check_no,
             amount,
             discount_amount,
             real_amount,
             begin_date,
             end_date,
             flag,
             build_date,
             status,
             rgst_name,
             rgst_date,
             create_flag,
             cost_flag,
             account_group_no)
          values
            (strEnterpriseNo,
             strWarehouseNo,
             strOwnerNo,
             acc.account_no,
             v_strCheckNo,
             v_nAmount,
             decode(sign(v_nAmount - v_nDiscountAmount),
                    -1,
                    0,
                    v_nAmount - v_nDiscountAmount),
             0,
             dtStart,
             dtEnd,
             strFlag,
             dtDate,
             '10',
             strWorkerNo,
             sysdate,
             '0',
             v_strCostFlag,
             acc.account_group_no);
          --更新费用明细对账单号和状态
          update cost_cost_list t
             set t.status     = '13',
                 t.check_no   = v_strCheckNo,
                 t.account_no = acc.account_no,
                 t.updt_name  = strWorkerNo,
                 t.updt_date  = sysdate
           where t.enterprise_no = strEnterpriseNo
             and t.warehouse_no = strWarehouseNo
             and t.owner_no = strOwnerNo
             and exists (select 1
                    from cost_account_formula b
                   where t.enterprise_no = b.enterprise_no
                     and t.warehouse_no = b.warehouse_no
                     and t.owner_no = b.owner_no
                     and t.billing_project = b.billing_project
                     and t.billing_type = b.billing_type
                     and b.account_no = acc.account_no)
             and t.build_date between dtStart and dtEnd
             and t.check_no = 'N'
             and t.status = '10';
        end if;
      end loop;

    end loop;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_INSERT_FINANCIAL;

  /***********************************************************************************************
  wyf
  20151210
  功能说明：其他费用出对账单
  ***********************************************************************************************/
  procedure P_OTHERCOST_DETAILS(strEnterpriseNo cost_formulaset.enterprise_no%type, --企业
                                strWarehouseNo  cost_formulaset.warehouse_no%type, --仓别
                                strOwnerNo      cost_formulaset.owner_no%type, --货主
                                dtDate          cost_cost_list.build_date%type,
                                dtStart         cost_cost_list.begin_date%type,
                                dtEnd           cost_cost_list.end_date%type,
                                strCheckNo      in out cost_financial.check_no%type, --对账单号
                                strFlag         cost_expenses_list.flag%type, --是否重算 0:首次出账 , 1:重算
                                strCreateFlag   cost_financial.create_flag%type, --0:自动出账，1:人工出账
                                strWorkerNo     cost_financial.rgst_name%type,
                                strOutMsg       out varchar2) IS
    v_strCheckNo cost_financial.check_no%type;
  BEGIN
    strOutMsg    := 'N|[P_OTHERCOST_DETAILS]';
    v_strCheckNo := strCheckNo;
    for p in (select nvl(sum(a.cost_value), 0) Amount, a.cost_flag
                from cost_other_list a
               where a.enterprise_no = strEnterpriseNo
                 and a.warehouse_no = strWarehouseNo
                 and a.owner_no = strOwnerNo
                 and a.status = '11'
               group by a.cost_flag) loop
      --获取记账单号
      if v_strCheckNo is null or v_strCheckNo = 'N' then
        PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                   strWarehouseNo,
                                   CONST_DOCUMENTTYPE.COST,
                                   v_strCheckNo,
                                   strOutMsg);
        if (v_strCheckNo is null or substr(strOutMsg, 1, 1) = 'N') then
          strOutMsg := 'N|取对账单号错误!';
          return;
        end if;
      end if;
      --新增账单
      insert into cost_financial
        (enterprise_no,
         warehouse_no,
         owner_no,
         account_no,
         check_no,
         amount,
         discount_amount,
         real_amount,
         begin_date,
         end_date,
         flag,
         build_date,
         status,
         rgst_name,
         rgst_date,
         create_flag,
         cost_flag,
         account_group_no)
      values
        (strEnterpriseNo,
         strWarehouseNo,
         strOwnerNo,
         'N',
         v_strCheckNo,
         p.amount,
         0,
         0,
         dtStart,
         dtEnd,
         strFlag,
         dtDate,
         '10',
         strWorkerNo,
         sysdate,
         strCreateFlag,
         p.cost_flag,
         'N');
      update cost_other_list t
         set t.status    = '13',
             t.check_no  = v_strCheckNo,
             t.updt_name = strWorkerNo,
             t.updt_date = sysdate
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWarehouseNo
         and t.status = '11'
         and t.cost_flag = p.cost_flag;
    end loop;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_OTHERCOST_DETAILS;

  /***********************************************************************************************
  wyf
  20151210
  功能说明：计算周期起始时间
  ***********************************************************************************************/
  procedure P_GETCYCLE_BEGINTOEND(strCycle    cost_formulaset.billing_cycle%type,
                                  strLastDay  cost_formulaset.balance_day%type,
                                  dtDate      cost_cost_list.build_date%type,
                                  dtStart     out cost_cost_list.begin_date%type, --起始日期
                                  dtEnd       out cost_cost_list.end_date%type, --结束日期
                                  strNextFlag out varchar2, --是否跳过  0：否 ，1：是
                                  strOutMsg   out varchar2) IS
    v_dtDate   cost_cost_list.build_date%type;
    v_nDay     integer := 1;
    v_nLastDay integer := 0;
    v_dtStart  cost_cost_list.begin_date%type; --起始日期
    v_dtEnd    cost_cost_list.end_date%type; --结束日期
  BEGIN
    strOutMsg   := 'N|[P_GETCYCLE_BEGINTOEND]';
    v_dtDate    := dtDate;
    strNextFlag := '0';
    if strCycle = '1' then
      --按天
      v_dtDate  := v_dtDate;
      v_dtStart := v_dtDate;
      v_dtEnd   := v_dtDate;
    elsif strCycle = '2' then
      --按周 获取传入日期是周几
      select to_char(v_dtDate, 'd') into v_nDay from dual;
      if strLastDay is null then
        --未维护结算日 则默认周天为结算日
        if v_nDay = '1' then
          v_dtDate  := v_dtDate;
          v_dtStart := v_dtDate - 6;
          v_dtEnd   := v_dtDate;
        else
          strNextFlag := 1;
        end if;
      else
        --有维护结算日，则比较传入日期是否为结算日
        if v_nDay + 1 = strLastDay then
          v_dtDate  := v_dtDate;
          v_dtStart := v_dtDate - 6;
          v_dtEnd   := v_dtDate;
        else
          strNextFlag := 1;
        end if;
      end if;
    elsif strCycle = '3' then
      --按月 获取传入日期是几号
      select to_char(v_dtDate, 'dd') into v_nDay from dual;
      --获取传入日期所在月份的最后一天
      select to_char(last_day(v_dtDate), 'dd') into v_nLastDay from dual;
      if strLastDay is null then
        --未维护结算日，则默认每月的最后一天为结算日
        if v_nDay = v_nLastDay then
          v_dtDate := v_dtDate;
          --起始日期为本月1号
          select trunc(add_months(v_dtDate, -1)) + 1
            into v_dtStart
            from dual;
          v_dtEnd := v_dtDate;
        else
          strNextFlag := 1;
        end if;
      else
        --有维护结算日，则比较传入日期是否为结算日
        --若结算日大于传入日期所在月的最后一天，则判断传入日期是否为所在月份的最后一天
        if v_nDay + 1 = strLastDay or
           (strLastDay > v_nLastDay and v_nDay + 1 = v_nLastDay) then
          v_dtDate := v_dtDate;
          --上个月的结算日为起始日期
          select trunc(add_months(v_dtDate, -1)) + 1
            into v_dtStart
            from dual;
          v_dtEnd := v_dtDate;
        else
          strNextFlag := 1;
        end if;
      end if;
    else
      strNextFlag := 1;
    end if;
    if strNextFlag = '0' then
      dtEnd   := v_dtEnd;
      dtStart := v_dtStart;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_GETCYCLE_BEGINTOEND;
  /***********************************************************************************************
  wyf
  20151210
  功能说明：通过科目优惠策略计算优惠后金额
  ***********************************************************************************************/
  procedure P_ACCOUNT_DISCOUNT(strEnterpriseNo cost_formulaset.enterprise_no%type, --企业
                               strWarehouseNo  cost_formulaset.warehouse_no%type, --仓别
                               strOwnerNo      cost_formulaset.owner_no%type, --货主
                               strAccountNo    cost_financial.account_no%type, --科目编码
                               dtStart         cost_financial.build_date%type,
                               dtEnd           cost_financial.build_date%type,
                               nAmount         cost_cost_list.amount%type,
                               nDiscountAmount out cost_cost_list.amount%type,
                               strOutMsg       out varchar2) IS

    v_nAmount            cost_cost_list.amount%type; --按消费清单算出的金额
    v_nDiscountAmount    cost_cost_list.amount%type; --优惠后的金额
    v_nDiscountProAmount cost_cost_list.amount%type; --优惠计费项目的金额
    nRowID               NUMBER; --行号
    nMidValue            NUMBER; --中间值
    nMidDisAmount        NUMBER; --优惠金额
    strMidPro            VARCHAR2(3000);
    strMidFlag           VARCHAR2(3000);
  BEGIN
    strOutMsg         := 'N|[P_ACCOUNT_DISCOUNT]';
    v_nAmount         := nAmount;
    v_nDiscountAmount := v_nAmount;
    nMidDisAmount     := 0;
    nMidValue         := v_nAmount;
    strMidPro         := ' ';
    strMidFlag        := ' ';
    --获取优惠策略
    for L in (select *
                from cost_account_discount t
               where t.enterprise_no = strEnterpriseNo
                 and t.warehouse_no = strWarehouseNo
                 and t.owner_no = strOwnerNo
                 and t.account_no = strAccountNo
               order by t.ACCOUNT_LADDER desc) loop
      nRowID := nRowID + 1;
      if L.DISCOUNT_FLAG = '1' then
        --1  超出“值1”按“值2”打折
        if v_nAmount > L.VALUE1 then
          if nvl(instr(strMidFlag, '#' || L.DISCOUNT_FLAG || '#'), 0) = 0 then
            v_nDiscountAmount := v_nDiscountAmount * L.VALUE2;
            strMidFlag        := strMidFlag || '#' || L.DISCOUNT_FLAG || '#';
          end if;
        end if;
      elsif L.DISCOUNT_FLAG = '2' then
        --2  超出“值1”送“值2”
        if v_nAmount > L.VALUE1 then
          if nvl(instr(strMidFlag, '#' || L.DISCOUNT_FLAG || '#'), 0) = 0 then
            v_nDiscountAmount := v_nDiscountAmount - L.VALUE2;
            strMidFlag        := strMidFlag || '#' || L.DISCOUNT_FLAG || '#';
          end if;
        end if;
      elsif L.DISCOUNT_FLAG = '3' then
        --3  超出“值1”送“优惠计费项目”
        if v_nAmount > L.VALUE1 then
          if nvl(instr(strMidPro, '#' || L.BILLING_PROJECT || '#'), 0) = 0 then
            select nvl(sum(a.amount), 0)
              into v_nDiscountProAmount
              from cost_cost_list a, cost_account_formula b
             where a.enterprise_no = b.enterprise_no
               and a.warehouse_no = b.warehouse_no
               and a.owner_no = b.owner_no
               and a.billing_project = b.billing_project
               and a.billing_type = b.billing_type
               and b.enterprise_no = strEnterpriseNo
               and b.warehouse_no = strWarehouseNo
               and b.owner_no = strOwnerNo
               and b.account_no = strAccountNo
               and b.billing_project = L.BILLING_PROJECT
               and a.build_date between dtStart and dtEnd
               and a.check_no = 'N'
               and a.status = '10';

            v_nDiscountAmount := v_nDiscountAmount - v_nDiscountProAmount;

            strMidPro := strMidPro || '#' || L.BILLING_PROJECT || '#';
          end if;
        end if;
      elsif L.DISCOUNT_FLAG = '4' then
        --4  超出“值1”，“优惠计费项目”按“值2”打折
        if v_nAmount > L.VALUE1 then
          if instr(strMidPro, '#' || L.BILLING_PROJECT || '#') = 0 then
            select nvl(sum(a.amount), 0)
              into v_nDiscountProAmount
              from cost_cost_list a, cost_account_formula b
             where a.enterprise_no = b.enterprise_no
               and a.warehouse_no = b.warehouse_no
               and a.owner_no = b.owner_no
               and a.billing_project = b.billing_project
               and a.billing_type = b.billing_type
               and b.enterprise_no = strEnterpriseNo
               and b.warehouse_no = strWarehouseNo
               and b.owner_no = strOwnerNo
               and b.account_no = strAccountNo
               and b.billing_project = L.BILLING_PROJECT
               and a.build_date between dtStart and dtEnd
               and a.check_no = 'N'
               and a.status = '10';

            v_nDiscountAmount := v_nDiscountAmount -
                                 v_nDiscountProAmount * (1 - L.VALUE2);

            strMidPro := strMidPro || '#' || L.BILLING_PROJECT || '#';
          end if;
        end if;
      elsif L.DISCOUNT_FLAG = '5' then
        --5  超出“值1”的部分，按“值2”打折
        if v_nAmount > L.VALUE1 then
          nMidDisAmount     := nMidDisAmount +
                               (nMidValue - L.VALUE1) * L.VALUE2;
          v_nDiscountAmount := v_nAmount - nMidDisAmount;
        end if;
      end if;
      nMidValue := L.VALUE1;
    end loop;
    nDiscountAmount := v_nDiscountAmount;
    strOutMsg       := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_ACCOUNT_DISCOUNT;
  /***********************************************************************************************
  wyf
  20151214
  功能说明：账单回退
  ***********************************************************************************************/
  procedure P_REBACK_FINANCIAL(strEnterpriseNo cost_formulaset.enterprise_no%type, --企业
                               strWarehouseNo  cost_formulaset.warehouse_no%type, --仓别
                               strOwnerNo      cost_formulaset.owner_no%type, --货主
                               strCheckNo      cost_financial.check_no%type, --对账单号
                               strOutMsg       out varchar2) IS
  BEGIN
    strOutMsg := 'N|[P_REBACK_FINANCIAL]';
    for p in (select t.check_no, max(t.status) status
                from cost_financial t
               where t.enterprise_no = strEnterpriseNo
                 and t.warehouse_no = strWarehouseNo
                 and t.owner_no = strOwnerNo
                 and t.check_no = strCheckNo
               group by t.check_no) loop
      --只有还未缴费的对账单可做回退
      if p.status = '10' then
        --更新费用明细表 status=10 check_no=N account_no=N
        update cost_cost_list a
           set a.check_no = 'N', a.status = '10', a.account_no = 'N'
         where a.enterprise_no = strEnterpriseNo
           and a.warehouse_no = strWarehouseNo
           and a.owner_no = strOwnerNo
           and a.check_no = p.check_no;
        --更新其他费用明细表 status=10 check_no=N
        update cost_other_list a
           set a.check_no = 'N', a.status = '10'
         where a.enterprise_no = strEnterpriseNo
           and a.warehouse_no = strWarehouseNo
           and a.owner_no = strOwnerNo
           and a.check_no = p.check_no;
        --删除对账单
        delete from cost_financial a
         where a.enterprise_no = strEnterpriseNo
           and a.warehouse_no = strWarehouseNo
           and a.owner_no = strOwnerNo
           and a.check_no = p.check_no;
      else
        strOutMsg := 'N|[已缴费的对账单不允许回退！]';
        return;
      end if;
    end loop;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_REBACK_FINANCIAL;
  /***********************************************************************************************
  wyf
  20150727
  功能说明：生成计费
  ***********************************************************************************************/
  procedure P_GENERATE_BILL is
    v_strOutMsg varchar2(255);
    --dtCurMonthFirstDay bill_formulaset.rgst_date%type; --当前月第一天
    --dtCurDay           bill_formulaset.rgst_date%type; --当天
  BEGIN
    v_strOutMsg := 'N|[P_GENERATE_BILL]';

    for p in (select distinct c.enterprise_no, c.warehouse_no, c.owner_no
                from cost_formulaset c
               order by c.enterprise_no, c.warehouse_no, c.owner_no) loop
      --生成消费清单
      P_EXPENSES_LIST(p.enterprise_no,
                      p.warehouse_no,
                      p.owner_no,
                      null,
                      null,
                      trunc(sysdate),
                      '0',
                      'admin_sys',
                      v_strOutMsg);
      --生成费用明细
      P_COST_DETAILS(p.enterprise_no,
                     p.warehouse_no,
                     p.owner_no,
                     null,
                     null,
                     trunc(sysdate),
                     '0',
                     'admin_sys',
                     v_strOutMsg);
      --生成账单
      P_FINANCIAL_DETAILS_BYAUTO(p.enterprise_no,
                                 p.warehouse_no,
                                 p.owner_no,
                                 trunc(sysdate),
                                 null,
                                 null,
                                 '0',
                                 'admin_sys',
                                 v_strOutMsg);
    end loop;
    v_strOutMsg := 'Y';
  exception
    when others then
      v_strOutMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  END P_GENERATE_BILL;
  /***********************************************************************************************
  wyf
  20160104
  功能说明：重算消费清单（可重算所有货主-内部使用）
  ***********************************************************************************************/
  procedure P_RETRY_COST(strOwnerNo         cost_formulaset.owner_no%type,
                         strBilling_project cost_formulaset.billing_project%type, --计费项目 支持传空值
                         strBillingType     cost_formulaset.billing_type%type, --计费项目类型 支持传空值
                         dtStart            in date, --开始时间
                         dtEnd              in date, --结束时间
                         strOutMsg          out varchar2) is
    ndays number;
  begin
    strOutMsg := 'N|[P_RETRY_COST]';
    ndays     := trunc(dtEnd) - trunc(dtStart);
    for p in (select distinct c.enterprise_no,
                              c.warehouse_no,
                              c.owner_no,
                              c.billing_project,
                              c.billing_type
                from cost_formulaset c
               where (c.owner_no = strOwnerNo or strOwnerNo is null)
                 and (c.billing_project = strBilling_project or
                     strBilling_project is null)
                 and (c.billing_type = strBillingType or
                     strBillingType is null)
               order by c.enterprise_no, c.warehouse_no, c.owner_no) loop
      for d in 0 .. ndays loop
        /* --生成消费清单
        P_EXPENSES_LIST(p.enterprise_no,
                                   p.warehouse_no,
                                   p.owner_no,
                                   p.billing_project,
                                   p.billing_type,
                                   trunc(dtStart + d),
                                   '1',
                                   'admin_sys',
                                   strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;*/
        /* --生成费用明细
        P_COST_DETAILS(p.enterprise_no,
                                  p.warehouse_no,
                                  p.owner_no,
                                  p.billing_project,
                                  p.billing_type,
                                  trunc(dtStart + d),
                                  '1',
                                  'admin_sys',
                                  strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
        strOutMsg := null;*/
        --生成账单
        P_FINANCIAL_DETAILS_BYAUTO(p.enterprise_no,
                                   p.warehouse_no,
                                   p.owner_no,
                                   trunc(dtStart + d),
                                   null,
                                   null,
                                   '0',
                                   'admin_sys',
                                   strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;

      end loop;
    end loop;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_RETRY_COST;
end PKOBJ_COST;

/

