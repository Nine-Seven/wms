create view V_SEARCH_9108_2 as
select d.enterprise_no,
       m.serial_no,
       to_char(d.recheck_date,'yyyy-mm-dd') check_date,
       d.recheck_worker check_worker,
       d.warehouse_no,
       d.owner_no,
       d.check_no,
       d.cell_no,
       d.article_no,
       bda.article_name,
       d.barcode,
       bap.spec,
       d.quality,
       d.lot_no,
       to_char(d.produce_date, 'yyyy-mm-dd') produce_date,
       to_char(d.expire_date, 'yyyy-mm-dd') expire_date,
       floor(sum(d.article_qty) / d.packing_qty) article_box_qty,
       bap.packing_unit BOX_UNIT,
       mod(sum(d.article_qty), d.packing_qty) article_retail_QTY,
       bda.unit retail_unit,
       trunc(sum(d.recheck_qty) / d.packing_qty) check_box_qty,
       mod(sum(d.recheck_qty), d.packing_qty) check_retail_QTY,
       trunc(sum(d.article_qty - d.recheck_qty) / d.packing_qty) diff_box_qty,
       mod(sum(d.article_qty - d.recheck_qty), d.packing_qty) diff_retail_QTY
  from fcdata_check_d d
 inner join fcdata_check_m m
    on d.warehouse_no = m.warehouse_no
    and d.enterprise_no = m.enterprise_no
   and d.owner_no = m.owner_no
   and d.check_no = m.check_no
 inner join bdef_defarticle bda
    on bda.article_no = d.article_no
    and bda.enterprise_no = d.enterprise_no
 inner join bdef_article_packing bap
    on bap.article_no = d.article_no
   and bap.packing_qty = d.packing_qty
   and bap.enterprise_no = d.enterprise_no
 where d.check_type >= '2'
   and d.article_qty <> d.recheck_qty
 group by to_char(d.recheck_date,'yyyy-mm-dd'),
          d.recheck_worker,
          d.warehouse_no,
          d.enterprise_no,
          d.owner_no,
          d.check_no,
          d.cell_no,
          d.article_no,
          d.barcode,
          bap.spec,
          d.lot_no,
          d.packing_qty,
          d.quality,
          d.produce_date,
          d.expire_date,
          bap.packing_unit,
          bda.unit,
          m.serial_no,
          bda.article_name

/

