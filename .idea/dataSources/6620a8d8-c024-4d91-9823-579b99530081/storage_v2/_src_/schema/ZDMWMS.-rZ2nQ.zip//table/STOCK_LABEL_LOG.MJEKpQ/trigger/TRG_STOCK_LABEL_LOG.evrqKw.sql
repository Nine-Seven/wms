create trigger TRG_STOCK_LABEL_LOG
    before insert
    on STOCK_LABEL_LOG
    for each row
declare
i_id integer;
begin
select SEQ_STOCK_LABEL_LOG.nextval into i_id from dual;
:NEW.ROW_ID := i_id;
end;


/

