create package        PKOBJ_PRINTTASK is

  -- Author  : lizhiping
  -- Created : 2013-12-12
  -- Purpose :  打印任务
  ---------------------------------------------------------【公共begin】---------------------------------------------

  /*****************************************************************************************
     功能：写打印任务头档
    Modify By lizhiping AT 2013-12-12
  *****************************************************************************************/
  procedure p_insert_taskmaster(strEnterpriseNo in job_printtask_m.enterprise_no%type, --企业
                                strWarehouseNo  in job_printtask_m.WAREHOUSE_NO%type, --仓别
                                strSourceNo     in job_printtask_m.source_no%type, --源单号
                                strBackFlag     in job_printtask_m.back_flag%type, --后台打印标识，默认为0
                                strReportID     in job_printtask_m.report_id%type, --报表编号
                                strDockNo       varchar2, --码头或工作站号
                                strReprintFlag  in job_printtask_m.reprint_flag%type, --补印标识
                                strUserNo       in job_printtask_m.Rgst_Name%type, --操作人员
                                strTaskNo       out job_printtask_m.task_no%type,
                                strErrorMsg     out varchar2); --返回 执行结果

  /*****************************************************************************************
     功能：写打印任务明细
    Modify By lizhiping AT 2013-12-12
  *****************************************************************************************/
  procedure p_insert_taskdetail(strEnterPriseNo in job_printtask_m.enterprise_no%type,
                                strWarehouseNo  in job_printtask_m.WAREHOUSE_NO%type, --仓别
                                strTaskNo       in job_printtask_m.task_no%type,
                                strContainerNo  in job_printtask_d.container_no%type,
                                nSerialNo       in job_printtask_d.print_sn%type,
                                NPrintQty       in job_printtask_d.print_qty%type,
                                strErrorMsg     out varchar2); --返回 执行结果
  /*****************************************************************************************
     功能：根据打印机组写打印任务头档
    Modify By lizhiping AT 2013-12-12
  *****************************************************************************************/
  procedure p_insert_PrintGrouptaskmaster(strEnterPriseNo in job_printtask_m.enterprise_no%type,
                                          strWarehouseNo  in job_printtask_m.WAREHOUSE_NO%type, --仓别
                                          strSourceNo     in job_printtask_m.source_no%type, --源单号
                                          strBackFlag     in job_printtask_m.back_flag%type, --后台打印标识，默认为0
                                          strReportID     in job_printtask_m.report_id%type, --报表编号
                                          strPrintGroupNo in job_printtask_m.printer_group_no%type,
                                          strReprintFlag  in job_printtask_m.reprint_flag%type, --补印标识
                                          strUserNo       in job_printtask_m.Rgst_Name%type, --操作人员
                                          strTaskNo       out job_printtask_m.task_no%type,
                                          strErrorMsg     out varchar2);
  ---------------------------------------------------------【公共end】---------------------------------------------
   /*****************************************************************************************
     功能：补印中心写打印任务
     chensr AT 2015-8-21
  *****************************************************************************************/
  procedure p_insert_printCenter(strEnterpriseNo in job_printtask_m.enterprise_no%type, --企业
                                strWarehouseNo  in job_printtask_m.WAREHOUSE_NO%type, --仓别
                                strSourceNo     in job_printtask_m.source_no%type, --源单号
                                strBackFlag     in job_printtask_m.back_flag%type, --后台打印标识，默认为0
                                strReportID     in job_printtask_m.report_id%type, --报表编号
                                strLabelLNoList in varchar2,                       --报表标签列表
                                strDockNo       in varchar2, --码头或工作站号
                                strHtyFlag      in job_printtask_m.hty_flag%type, --是否打印历史数据
                                strPrintNum     in varchar2,
                                strUserNo       in job_printtask_m.Rgst_Name%type, --操作人员
                                strTaskNo       out job_printtask_m.task_no%type,
                                strErrorMsg     out varchar2);

   /*****************************************************************************************
     功能：打印任务转历史 JOB用，JOB在每天凌晨2点执行一次
     sl AT 20160121
  *****************************************************************************************/
  PROCEDURE P_PRINTJOB_BACKUP;

  /*=====================================================================================
  hb insert to 20160625
  打印-新增打印任务头档和明细
  ======================================================================================*/
  PROCEDURE p_Insert_TaskInfo( --新增打印任务条件
                               strEnterpriseNo    in pntset_module_report.enterprise_no%type,--企业
                               strWarehouseNo     in job_printtask_m.warehouse_no%type,--仓别号
                               strSourceNo        in job_printtask_m.source_no%type, --源单号
                               strReportId        in job_printtask_m.report_id%type, --打印的报表ID 如外部传入 则传具体的report_id且查询条件可全部为'N',否则本参数传'N'
                               strBackFlag        in job_printtask_m.back_flag%type, --后台打印标识，默认为0
                               strDockNo          in varchar2, --码头或工作站号
                               strReprintFlag     in job_printtask_m.reprint_flag%type, --补印标识
                               strUserNo          in job_printtask_m.Rgst_Name%type, --操作人员
                               strAddDetailFlag   in varchar2, --是否新增打印任务明细 0-不新增;1-新增
                               strContainerNo     in job_printtask_d.container_no%type, --需要打印的系统内部容器号不新增打印任务明细传'N'
                               nSerialNo          in job_printtask_d.print_sn%type, --不新增打印任务明细传 0
                               NPrintQty          in job_printtask_d.print_qty%type, --不新增打印任务明细传 1
                               --返回参数
                               strTaskNo          out job_printtask_m.task_no%type, --打印任务单号 如外部生成 则传外部生成打印任务号,否则传'N'
                               strOutMsg          out varchar2);

   /*****************************************************************************************
      功能：补印中心写打印任务
     add by czh 2016/10/17 写明细的时候加了包装数量和预留字段
  *****************************************************************************************/
  procedure p_insert_printCenter_forRepair(strEnterpriseNo in job_printtask_m.enterprise_no%type, --企业
                                strWarehouseNo  in job_printtask_m.WAREHOUSE_NO%type, --仓别
                                strSourceNo     in job_printtask_m.source_no%type, --源单号
                                strBackFlag     in job_printtask_m.back_flag%type, --后台打印标识，默认为0
                                strReportID     in job_printtask_m.report_id%type, --报表编号
                                strLabelLNoList in varchar2,                       --报表标签列表
                                strDockNo       in varchar2, --码头或工作站号
                                strHtyFlag      in job_printtask_m.hty_flag%type, --是否打印历史数据
                                strPrintNum     in varchar2,                     --打印份数
                                strUserNo       in job_printtask_m.Rgst_Name%type, --操作人员
                                numPackingQty   in job_printtask_d.packing_qty%type, --包装数量
                                strRsvVarod1    in job_printtask_d.RSV_VAROD1%type, --预留字段1
                                strRsvVarod2    in job_printtask_d.RSV_VAROD2%type, --预留字段2
                                strRsvVarod3    in job_printtask_d.RSV_VAROD3%type, --预留字段3
                                strRsvVarod4    in job_printtask_d.RSV_VAROD4%type, --预留字段4
                                strRsvVarod5    in job_printtask_d.RSV_VAROD5%type, --预留字段5
                                strTaskNo       out job_printtask_d.task_no%type,
                                strErrorMsg     out varchar2);
end PKOBJ_PRINTTASK;


/

