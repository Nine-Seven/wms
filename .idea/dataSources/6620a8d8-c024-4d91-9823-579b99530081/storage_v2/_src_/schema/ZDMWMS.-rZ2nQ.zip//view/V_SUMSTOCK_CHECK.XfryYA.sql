create view V_SUMSTOCK_CHECK as
select sum(beginQty)as "期初",sum(iqty)"入库",sum(oqty) "出库",sum(adjOver) "调盈",sum(adjShort) "调亏",sum(beginQty)+sum(iqty)+sum(oqty)+sum(adjOver)+sum(adjShort)  "期末",
sum(realqty) "实际库存",sum(beginQty)+sum(iqty)+sum(oqty)+sum(adjOver)+sum(adjShort)-sum(realqty) "差异库存"  from (
--期初
select sum(real_qty)beginQty,0 as iqty,0 as oqty,0 as adjOver,0 as adjShort,0 as realqty from fcdata_check_d d,bdef_defarticle a,fcdata_check_m m
 where a.enterprise_no = d.enterprise_no
and a.article_no = d.article_no and a.virtual_flag  = '0'
and d.enterprise_no = m.enterprise_no and d.warehouse_no = m.warehouse_no and d.check_no = m.check_no
and not exists(select 'x' from fcdata_plan_m pm
where  m.enterprise_no = pm.enterprise_no and m.warehouse_no = pm.warehouse_no and m.plan_no = pm.plan_no)
union all
--入库
select 0 as beginQty,nvl(sum(check_qty),0) iqty, 0 as oqty,0 as adjOver,0 as adjShort,0 as realqty from idata_check_d d,bdef_defarticle a where a.enterprise_no = d.enterprise_no
and a.article_no = d.article_no and a.virtual_flag  = '0'
union all
--出库
select 0 as beginQty,0 as iqty,-sum(qty) oqty,0 as adjOver,0 as adjShort,0 as realqty from odata_deliver_d d,bdef_defarticle a where a.enterprise_no = d.enterprise_no
and a.article_no = d.article_no and a.virtual_flag  = '0'
union all
--调盈
select 0 as beginQty,0 as iqty,0 oqty,sum(real_qty) as adjOver,0 as adjShort,0 as realqty from stock_confirm_d d,bdef_defarticle a where a.enterprise_no = d.enterprise_no
and a.article_no = d.article_no and a.virtual_flag  = '0' and real_qty > 0
union all
--调亏
select 0 as beginQty,0 as iqty,0 oqty,0  as adjOver,sum(real_qty) as adjShort,0 as realqty from stock_confirm_d d,bdef_defarticle a where a.enterprise_no = d.enterprise_no
and a.article_no = d.article_no and a.virtual_flag  = '0' and real_qty < 0
union all
--库存
select 0 as beginQty,0 as iqty,0 as oqty,0 as adjOver,0 as adjShort,sum(qty) as realqty from stock_content d,bdef_defarticle a where a.enterprise_no = d.enterprise_no
and a.article_no = d.article_no and a.virtual_flag  = '0' )


/

