create view V_SEARCH_9101_11 as
select ca.area_name,
         cd.warehouse_no,
         cd.enterprise_no,
         cd.cell_no,
         a.article_no,
         a.owner_article_no,
         a.barcode,
         a.article_name
  from cdef_defcell cd,cdef_defarea ca,
      (select cca.enterprise_no,
              cca.warehouse_no,
              cca.cell_no,
              v.article_no,
              v.owner_article_no,
              v.article_name ,
              v.barcode
       from cset_cell_article cca,
            v_article_pack_volumn_weight v
       where cca.article_no=v.article_no
         and cca.enterprise_no=v.enterprise_no)a
  where cd.warehouse_no=ca.warehouse_no
    and cd.enterprise_no = ca.enterprise_no
    and cd.ware_no||cd.area_no=ca.ware_no||ca.area_no
    and (cd.enterprise_no,cd.warehouse_no,cd.cell_no) not in (select sc.enterprise_no,sc.warehouse_no,sc.cell_no from stock_content sc)
    and ca.area_attribute='0'
    and cd.cell_status<>'1'
    and cd.warehouse_no=a.warehouse_no(+)
    and cd.enterprise_no = a.enterprise_no(+)
    and cd.cell_no=a.cell_no(+)
order by cd.enterprise_no,
         cd.warehouse_no,
         cd.cell_no


/

