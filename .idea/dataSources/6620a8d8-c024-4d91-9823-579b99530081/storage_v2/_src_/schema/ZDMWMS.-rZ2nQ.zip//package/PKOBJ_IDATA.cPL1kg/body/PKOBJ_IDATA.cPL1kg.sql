create package body        pkobj_idata is

  /******************************************************************************************************************
   作者:lich
   日期:  2014-03-24
   功能: 生成进货汇总头档
  *******************************************************************************************************************/
  procedure p_Idata_Import_Mm(v_enterprise_no in idata_import_mm.enterprise_no%type,
                              v_warehouse_no  in idata_import_mm.warehouse_no%type,
                              v_s_import_no   in idata_import_mm.s_import_no%type,
                              v_import_type   in idata_import_mm.import_type%type,
                              v_strClassType  in idata_import_mm.class_type%type,
                              v_owner_no      in idata_import_mm.owner_no%type,
                              v_dept_no       in idata_import_mm.dept_no%type,
                              v_po_type       in idata_import_mm.po_type%type,
                              v_supplier_no   in idata_import_mm.supplier_no%type,
                              v_stock_type    in idata_import_mm.stock_type%type,
                              v_stock_value   in idata_import_mm.stock_value%type,
                              v_rgst_name     in idata_import_mm.rgst_name%type,
                              v_OutMsg        out varchar2) is

  begin
    v_OutMsg := 'N|[p_Idata_Import_Mm]';

    update Idata_Import_Mm m
       set m.status = m.status
     where m.warehouse_no = v_warehouse_no
       and m.s_import_no = v_s_import_no
       and m.enterprise_no = v_enterprise_no
       and m.owner_no = v_owner_no;--add by huangcx 20160816

    if sql%rowcount <= 0 then
      insert into idata_import_mm
        (enterprise_no,
         warehouse_no,
         import_type,
         s_import_no,
         owner_no,
         dept_no,
         po_type,
         supplier_no,
         status,
         serial_no,
         stock_type,
         stock_value,
         rgst_name,
         rgst_date,class_type)
      values
        (v_enterprise_no,
         v_warehouse_no,
         v_import_type,
         v_s_import_no,
         v_owner_no,
         v_dept_no,
         v_po_type,
         v_supplier_no,
         10,
         SEQ_IDATA_IMPORT_MM.nextval,
         v_stock_type,
         v_stock_value,
         v_rgst_name,
         sysdate,v_strClassType);

    end if;
    v_OutMsg := 'Y|成功!';
  exception
    when others then
      v_OutMsg := 'N|' || SQLERRM ||
                  substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_Idata_Import_Mm;

  /******************************************************************************************************************
   作者:lich
   日期:  2014-03-24
   功能: 生成进货汇总单和进货单对应关系
  *******************************************************************************************************************/
  procedure p_Idata_Import_Sm(v_enterprise_no in idata_import_sm.enterprise_no%type,
                              v_warehouse_No  in idata_import_sm.warehouse_no%type,
                              v_s_import_no   in idata_import_sm.s_import_no%type,
                              v_Import_No     in idata_import_sm.import_no%type,
                              v_rgst_name     in idata_import_mm.rgst_name%type,
                              v_OutMsg        out varchar2) is

  begin
    v_OutMsg := 'N|[p_Idata_Import_Sm]';

    update Idata_Import_Mm m
       set m.status = m.status
     where m.warehouse_no = v_warehouse_No
       and m.s_import_no = v_s_import_no
       and m.enterprise_no = v_enterprise_no;

    insert into idata_import_sm
      (enterprise_no,
       warehouse_no,
       owner_no,
       import_type,
       s_import_no,
       import_no,
       po_no,
       po_type,
       status,
       rgst_name,
       rgst_date)
      select a.enterprise_no,
             a.warehouse_no,
             a.owner_no,
             a.import_type,
             v_s_import_no,
             a.import_no,
             a.po_no,
             a.po_type,
             10,
             v_rgst_name,
             sysdate
        from idata_import_m a
       where a.import_no = v_Import_No
         and a.enterprise_no = v_enterprise_no
         and a.warehouse_no = v_warehouse_No;

    if sql%rowcount <= 0 then
      v_OutMsg := 'N|新增0行,单号:' || v_Import_No;
      return;
    end if;
    v_OutMsg := 'Y|成功!';
  exception
    when others then
      v_OutMsg := 'N|' || SQLERRM ||
                  substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_Idata_Import_Sm;

  /******************************************************************************************************************
   作者:lich
   日期:  2014-03-24
   功能: 进货汇总单明细
  *******************************************************************************************************************/
  procedure p_Idata_Import_Sd(v_enterprise_no in idata_import_sm.enterprise_no%type,
                              v_warehouse_No  in idata_import_sm.warehouse_no%type,
                              v_s_import_no   in idata_import_sm.s_import_no%type,
                              v_Import_No     in idata_import_sm.import_no%type,
                              v_OutMsg        out varchar2) is
    nRowId idata_import_sd.row_id%type;
    cursor cur_idata_import_d is
      select iid.*
        from idata_import_d iid
       where iid.status = '10'
         and iid.import_no = v_Import_No
         and iid.enterprise_no = v_enterprise_no
         and iid.warehouse_no = v_warehouse_No;

  begin
    v_OutMsg := 'N|[p_Idata_Import_Sd]';

    update Idata_Import_Mm m
       set m.status = m.status
     where m.warehouse_no = v_warehouse_No
       and m.s_import_no = v_s_import_no
       and m.enterprise_no = v_enterprise_no;

    --写标签数据
    for v_iid in cur_idata_import_d loop
      update idata_import_sd iis
         set iis.Po_Qty = iis.po_qty
         + decode(v_iid.po_qty,0,0,v_iid.po_qty - v_iid.import_qty)  --Modify BY QZH AT 2016-7-11
       where iis.s_import_no = v_s_import_no
         and iis.article_no = v_iid.article_no
         and iis.packing_qty = v_iid.packing_qty
         and iis.enterprise_no = v_enterprise_no
         and iis.warehouse_no = v_warehouse_No;
      if sql%notfound then
        select nvl(max(iis.row_id), 0) + 1
          into nRowId
          from idata_import_sd iis
         where iis.s_import_no = v_s_import_no
           and iis.warehouse_no = v_warehouse_No
           and iis.enterprise_no = v_enterprise_no;

        insert into idata_import_sd
          (enterprise_no,
           warehouse_no,
           owner_no,
           s_import_no,
           row_id,
           article_no,
           packing_qty,
           po_qty,
           import_qty,
           qc_qty,
           status,
           out_stock_flag,
           outpace_article_flag,
           item_type,
           qc_flag)
        values
          (v_iid.enterprise_no,
           v_iid.warehouse_no,
           v_iid.owner_no,
           v_s_import_no,
           nRowId,
           v_iid.article_no,
           v_iid.packing_qty,
           decode(v_iid.po_qty, 0, 0, v_iid.po_qty - v_iid.import_qty), --Modify BY QZH AT 2016-7-11
           0,
           0,
           10,
           0,
           0,
           0,
           0);
      end if;
    end loop;
    v_OutMsg := 'Y|成功!';
  exception
    when others then
      v_OutMsg := 'N|' || SQLERRM ||
                  substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_Idata_Import_Sd;

  /******************************************************************************************************************
   作者:Quzhihui
   日期:  2016-7-11
   功能: 进货单明细
  *******************************************************************************************************************/
  procedure p_Idata_Import_d(strEnterprise_no in idata_import_m.enterprise_no%type,
                             strWarehouse_No  in idata_import_m.warehouse_no%type,
                             strOwner_No      in idata_import_m.owner_no%type,
                             strImport_No     in idata_import_m.import_no%type,
                             strArticle_No    in idata_import_d.article_no%type,
                             nPacking_QTY     in idata_import_d.packing_qty%type,
                             nPO_QTY          in idata_import_d.po_qty%type,
                             nImport_QTY      in idata_import_d.import_qty%type,
                             strStatus        in idata_import_d.status%type,
                             v_OutMsg         out varchar2) is

    v_MaxPO_ID idata_import_d.po_id%type;
    v_iCount   integer;
  begin
    v_OutMsg := 'N|[p_Idata_Import_d]';

    select count(1)
      into v_iCount
      from idata_import_d d
     where d.warehouse_no = strWarehouse_No
       and d.import_no = strImport_No
       and d.enterprise_no = strEnterprise_no
       and d.article_no = strArticle_No
       and d.packing_qty = nPacking_QTY;
    if v_iCount > 0 then
      v_OutMsg := 'Y|';
      return;
    end if;

    update idata_import_d m
       set m.status = m.status
     where m.warehouse_no = strWarehouse_No
       and m.import_no = strImport_No
       and m.enterprise_no = strEnterprise_no;

    begin
      select max(m.po_id)
        into v_MaxPO_ID
        from idata_import_d m
       where m.warehouse_no = strWarehouse_No
         and m.import_no = strImport_No
         and m.enterprise_no = strEnterprise_no;

    exception
      when no_data_found then
        v_MaxPO_ID := 1;
    end;

    insert into idata_import_d
      (enterprise_no,
       warehouse_no,
       owner_no,
       import_no,
       article_no,
       packing_qty,
       po_qty,
       import_qty,
       po_id,
       status)
    values
      (strEnterprise_no,
       strWarehouse_No,
       strOwner_No,
       strImport_No,
       strArticle_No,
       nPacking_QTY,
       nPO_QTY,
       nImport_QTY,
       v_MaxPO_ID,
       strStatus);

    v_OutMsg := 'Y|成功!';
  exception
    when others then
      v_OutMsg := 'N|' || SQLERRM ||
                  substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_Idata_Import_d;

  /******************************************************************************************************************
   作者: haungb
   日期: 2016-7-12
   功能: 超品新增进货明细以及汇总明细
  *******************************************************************************************************************/
  procedure p_Inset_ImportDetailByOver(strEnterprise_no in idata_import_m.enterprise_no%type,
                                       strWarehouse_No  in idata_import_m.warehouse_no%type,
                                       strOwner_No      in idata_import_m.owner_no%type,
                                       strS_Import_No   in idata_import_mm.s_import_no%type,
                                       strArticle_No    in idata_import_d.article_no%type,
                                       nPacking_QTY     in idata_import_d.packing_qty%type,
                                       strOutMsg        out varchar2) is

    v_Import_No idata_import_m.import_no%type := 'N';
    v_MaxPO_ID  idata_import_d.po_id%type;--进货单明细ID
    v_MaxRowId  idata_import_sd.row_id%type;--进货汇总单明细ID
    v_iCount    integer;
  begin
    strOutMsg := 'N|[p_Inset_ImportDetailByOver]';
    --获取进货单号
    begin
      select t.import_no into v_Import_No
        from (select a.import_no
                from idata_import_sm a
               where a.enterprise_no = strEnterprise_no
                 and a.warehouse_no = strWarehouse_No
                 and a.owner_no = strOwner_No
                 and a.s_import_no = strS_Import_No
               order by a.import_no) t
       where rownum = 1;
    exception
      when no_data_found then
        strOutMsg := 'N|获取进货单与汇总单对应关系失败';
        return;
    end;

    select count(1)
      into v_iCount
      from idata_import_d d
     where d.warehouse_no = strWarehouse_No
       and d.import_no = v_Import_No
       and d.enterprise_no = strEnterprise_no
       and d.article_no = strArticle_No
       and d.packing_qty = nPacking_QTY;
    if v_iCount > 0 then
      strOutMsg := 'N|当前商品已经存在当前汇总单下的进货单中';
      return;
    end if;

    update idata_import_d m
       set m.status = m.status
     where m.warehouse_no = strWarehouse_No
       and m.import_no = v_Import_No
       and m.enterprise_no = strEnterprise_no;

    begin
      select nvl(max(m.po_id),0) + 1
        into v_MaxPO_ID
        from idata_import_d m
       where m.warehouse_no = strWarehouse_No
         and m.import_no = v_Import_No
         and m.enterprise_no = strEnterprise_no;
    exception
      when no_data_found then
        v_MaxPO_ID := 1;
    end;

    --新增进货单明细
    insert into idata_import_d
      (enterprise_no,
       warehouse_no,
       owner_no,
       import_no,
       article_no,
       packing_qty,
       po_qty,
       import_qty,
       po_id,
       unit_cost,
       status)
    values
      (strEnterprise_no,
       strWarehouse_No,
       strOwner_No,
       v_Import_No,
       strArticle_No,
       nPacking_QTY,
       0,
       0,
       v_MaxPO_ID,
       0,
       '10');
    if sql%rowcount <= 0 then
      strOutMsg := 'N|新增进货单明细0行,单号:' || v_Import_No;
      return;
    end if;

    begin
      select nvl(max(iis.row_id), 0) + 1
            into v_MaxRowId
            from idata_import_sd iis
           where iis.s_import_no = strS_Import_No
             and iis.warehouse_no = strWarehouse_No
             and iis.enterprise_no = strEnterprise_no;
    exception
      when no_data_found then
        v_MaxRowId := 1;
    end;

    --新增汇总单明细
    insert into idata_import_sd
          (enterprise_no,
           warehouse_no,
           owner_no,
           s_import_no,
           row_id,
           article_no,
           packing_qty,
           po_qty,
           import_qty,
           qc_qty,
           status,
           out_stock_flag,
           outpace_article_flag,
           item_type,
           qc_flag)
        values
          (strEnterprise_no,
           strWarehouse_No,
           strOwner_No,
           strS_Import_No,
           v_MaxRowId,
           strArticle_No,
           nPacking_QTY,
           0,
           0,
           0,
           10,
           0,
           0,
           0,
           0);
    if sql%rowcount <= 0 then
      strOutMsg := 'N|新增汇总单明细0行,单号:' || strS_Import_No;
      return;
    end if;

    strOutMsg := 'Y|成功!';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                  substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_Inset_ImportDetailByOver;

  /******************************************************************************************************************
   作者:lich
   日期:  2014-03-24
   功能: 预约状况记录表
  *******************************************************************************************************************/
  procedure p_Idata_Order_Status(v_enterprise_no in idata_import_mm.enterprise_no%type,
                                 v_warehouse_No  in idata_import_mm.warehouse_no%type,
                                 v_owner_no      in idata_import_mm.owner_no%type,--add by huangcx 20160816
                                 v_s_import_no   in idata_import_mm.s_import_no%type,
                                 v_Request_Date  in Idata_Order_Status.Request_Date%type,
                                 v_strDock_no    in Idata_Order_Status.Dock_No%type,
                                 v_Start_Time    in Idata_Order_Status.Start_Time%type,
                                 v_End_Time      in Idata_Order_Status.End_Time%type,
                                 v_rgst_name     in idata_import_mm.rgst_name%type,
                                 v_OutMsg        out varchar2) is

    strOwnerNo    idata_import_mm.owner_no%type;
    strSupplierNo idata_import_mm.Supplier_No%type;
    strSerialNo   idata_import_mm.serial_no%type;

  begin
    v_OutMsg := 'N|[p_Idata_Order_Status]';

    update Idata_Order_Status ios
       set ios.status = ios.status
     where ios.warehouse_no = v_warehouse_No
       and ios.s_import_no = v_s_import_no
       and ios.enterprise_no = v_enterprise_no
       and ios.warehouse_no = v_warehouse_No
       and ios.owner_no = v_owner_no;--add by huangcx 20160816

    if sql%rowcount <= 0 then
      select iimm.serial_no, iimm.owner_no, iimm.supplier_no
        into strSerialNo, strOwnerNo, strSupplierNo
        from idata_import_mm iimm
       where iimm.warehouse_no = v_warehouse_No
         and iimm.s_import_no = v_s_import_no
         and iimm.enterprise_no = v_enterprise_no
         and iimm.owner_no = v_owner_no;--add by huangcx 20160816

      insert into Idata_Order_Status
        (Enterprise_No,
         Warehouse_No,
         Request_Date,
         Start_Time,
         End_Time,
         Sheet_Type,
         Dock_No,
         Last_Batch,
         Owner_No,
         Supplier_No,
         Order_Serial,
         Cars_Count,
         s_Import_No,
         Rgst_Name,
         Rgst_Date,
         Status)
      values
        (v_enterprise_no,
         v_warehouse_No,
         v_Request_Date,
         v_Start_Time,
         v_End_Time,
         'I',
         v_strDock_no,
         'N',
         strOwnerNo,
         strSupplierNo,strSerialNo,1, v_s_import_no,
         v_rgst_name,
         sysdate,
         10);

    end if;
    v_OutMsg := 'Y|成功!';
  exception
    when others then
      v_OutMsg := 'N|' || SQLERRM ||
                  substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_Idata_Order_Status;

  /******************************************************************************************************************
   作者:lich
   日期:  2014-03-24
   功能: 生成预约单号记录档
  *******************************************************************************************************************/
  procedure p_Idata_Order_Sheet(v_enterprise_no in idata_import_sm.enterprise_no%type,
                                v_warehouse_No  in idata_import_sm.warehouse_no%type,
                                v_owner_no     in idata_import_sm.owner_no%type,--add by huangcx 20160816
                                v_s_import_no   in idata_import_sm.s_import_no%type,
                                v_Import_No     in idata_import_sm.import_no%type,
                                v_rgst_name     in idata_import_mm.rgst_name%type,
                                v_OutMsg        out varchar2) is
    strOrderSerial idata_order_sheet.order_serial%type;
    strImportType  idata_import_mm.import_type%type;

  begin
    v_OutMsg := 'N|[p_Idata_Order_Sheet]';

    select iimm.serial_no, iimm.import_type
      into strOrderSerial, strImportType
      from idata_import_mm iimm
     where iimm.warehouse_no = v_warehouse_No
       and iimm.enterprise_no = v_enterprise_no
       and iimm.s_import_no = v_s_import_no
       and iimm.owner_no = v_owner_no;--add by huangcx 20160816

    insert into idata_order_sheet
      (enterprise_no,
       warehouse_no,
       order_serial,
       import_no,
       sku_qty,
       pal_qty,
       total_volumn,
       total_weight,
       total_packing,
       cancel_serial,
       cancel_status,
       print_flag,
       po_type,
       rgst_date,
       rgst_name)
    values
      (v_enterprise_no,
       v_warehouse_No,
       strOrderSerial,
       v_Import_No,
       0,
       0,
       0,
       0,
       0,
       '',
       'N',
       'N',
       strImportType,
       sysdate, v_rgst_name);

    if sql%rowcount <= 0 then
      v_OutMsg := 'N|新增0行,单号:' || v_Import_No;
      return;
    end if;
    v_OutMsg := 'Y|成功!';
  exception
    when others then
      v_OutMsg := 'N|' || SQLERRM ||
                  substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_Idata_Order_Sheet;

  /*************************************************************************************************************
   创建人：luozhiling
   创建时间：2013.11.25
   功能：直通验收写板明细、进货汇总明细,进货明细
  *************************************************************************************************************/
  procedure p_idata_InsertIDCheckPal(strEnterpriseNo in idata_check_pal_tmp.enterprise_no%type,
                                     strWareHouseNo  in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                     strOwnerNo      in idata_check_pal_tmp.owner_no%type, --委托业主
                                     strsImportNo    in idata_check_m.s_import_no%type, --进货汇总单号
                                     strImportNo     in idata_check_m.import_no%type, --进货单号
                                     strWorkerNo     in idata_check_pal_tmp.rgst_name%type, --操作人
                                     strNewLabelNo   in idata_check_pal_tmp.label_no%type, --新板号
                                     strSubLabelNo   in idata_check_pal_tmp.sub_label_no%type, --子容器号
                                     strContainNo    in idata_check_pal.container_no%type, --内部容器号
                                     strCustNo       in idata_check_pal.cust_no%type, --客户编码 无客户传N
                                     strfixpal_flag  IN idata_check_pal.fixpal_flag%type,
                                     intCheckQty     in idata_check_pal_tmp.check_qty%type, --验收数量
                                     strDockNo       in idata_check_pal.dock_no%type,
                                     intRowId        in idata_check_d.row_id%type, --验收明细ROW_id
                                     strWaveNo       in idata_import_mm.wave_no%type,
                                     strResult       out varchar2) is

    -- strCheck_No       idata_check_m.check_no%type;
    --  v_strLable_NO     idata_check_pal.label_no%type;
    --strScanLabelNoTmp idata_check_pal.scan_label_no%type; --接收尾箱标签
    v_iCount      integer;
    v_iCount2     integer;
    v_strBatchNo  odata_divide_allot.batch_no%type;
    v_strDeviceNo odata_divide_allot.device_no%type;

  begin
    strResult := 'N|[p_idata_InsertIDCheckPal]';
    v_iCount  := 0;

    --获取资源信息
    begin
      select nvl(b.batch_no, 'N'), nvl(b.device_no, 'N')
        into v_strBatchNo, v_strDeviceNo
        from (select distinct icm.enterprise_no,
                              icm.warehouse_no,
                              icm.s_import_no,
                              icm.import_no,
                              icm.check_no,
                              iia.po_no,
                              iia.cust_no
                from idata_import_allot iia, idata_check_m icm
               where iia.enterprise_no = icm.enterprise_no
                 and iia.warehouse_no = icm.warehouse_no
                 and iia.import_no = icm.import_no
                 and iia.import_no = strImportNo
                 and icm.s_import_no = strsImportNo
                 and icm.enterprise_no = strEnterpriseNo
                 and icm.warehouse_no = strWareHouseNo) a,
             odata_divide_allot b
       where a.enterprise_no = b.enterprise_no(+)
         and a.warehouse_no = b.warehouse_no(+)
         and a.s_import_no = b.s_import_no(+)
         and a.po_no = b.exp_no(+)
         and a.cust_no = b.cust_no(+)
         and a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWareHouseNo
         and a.s_import_no = strsImportNo
         and a.cust_no = strCustNo
         and a.import_no = strImportNo;
    exception
      when no_data_found then
        v_strBatchNo  := 'N';
        v_strDeviceNo := 'N';
    end;

    for P in (select icm.printer_group_no,icm.import_type, icm.s_check_no,icm.class_type, icd.*
                from idata_check_d icd, idata_check_m icm
               where icd.enterprise_no = icm.enterprise_no
                 and icd.warehouse_no = icm.warehouse_no
                 and icd.owner_no = icm.owner_no
                 and icd.check_no = icm.check_no
                 and icm.enterprise_no = strEnterpriseNo
                 and icm.WAREHOUSE_NO = strWareHouseNo
                 and icm.owner_no = strOwnerNo
                 and icm.s_import_no = strsImportNo
                 and icm.import_no = strImportNo
                 and icm.status < '13'
                 AND icd.row_id = intRowId) loop
      v_iCount := v_iCount + 1;

      --strScanLabelNoTmp := strNewLabelNo;
      --判断是否已经封板

      select count(*)
        into v_iCount2
        from idata_check_pal t
       where enterprise_no = strEnterpriseNo
         and WAREHOUSE_NO = strWareHouseNo
         and owner_no = strOwnerNo
         and Check_No = P.check_no
         and s_check_no = p.s_check_no --Add BY QZH AT 2016-6-22
         and label_no = strNewLabelNo
         and cust_no = strCustNo
         and status = 13;
      if v_iCount2 > 0 then
        strResult := 'N|[E20930]';
        return;
      end if;

      --更新/写入板明细

      update idata_check_pal
         set check_qty = check_qty + intCheckQty
       where enterprise_no = strEnterpriseNo
         and WAREHOUSE_NO = strWareHouseNo
         and owner_no = strOwnerNo
         and Check_No = P.check_no
         and check_row_id = intRowId
         and label_no = strNewLabelNo
         and container_no = strContainNo
         and cust_no = strCustNo
         and status = '10';

      if (sql%rowcount <= 0) then

        insert into idata_check_pal
          (WAREHOUSE_NO,
           owner_no,
           s_check_no,
           check_no,
           check_row_id,
           article_no,
           packing_qty,
           check_qty,
           label_no,
           SUB_LABEL_NO,
           status,
           fixpal_flag,
           printer_group_no,
           dock_no,
           container_no,
           stock_type,
           stock_value,
           --scan_label_no,
           business_type,
           barcode,
           produce_date,
           expire_date,
           lot_no,
           QUALITY,
           cust_no,
           --item_type,
           rgst_name,
           rgst_date,
           updt_name,
           updt_date,
           enterprise_no,
           wave_no,
           batch_no,
           device_no,
           price,class_type,import_type)
        values
          (strWareHouseNo,
           strOwnerNo,
           p.s_check_no,
           p.check_no,
           intRowId,
           p.article_no,
           p.packing_qty,
           intCheckQty,
           strNewLabelNo,
           strSubLabelNo,
           '10',
           strfixpal_flag,
           p.printer_group_no,
           strDockNo,
           strContainNo,
           '1',
           'N',
           --strScanLabelNoTmp,
           '1',
           p.barcode,
           p.produce_date,
           p.expire_date,
           p.lot_no,
           p.quality,
           strCustNo,
           --p.item_type,
           strWorkerNo,
           sysdate,
           strWorkerNo,
           sysdate,
           strEnterpriseNo,
           strWaveNo,
           v_strBatchNo,
           v_strDeviceNo,
           p.price,p.class_type,p.import_type);
      end if;
    end loop;

    if v_iCount = 0 then
      strResult := 'N|[E20937]';
      return;
    end if;
    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_idata_InsertIDCheckPal;

  /*******************************************************************************************************************
    创建人:luozhiling
    创建时间：2013.11.25
    功能：写直通验收明细
  *******************************************************************************************************************/
  procedure p_idata_IDInsertCheckD(strEnterpriseNo in idata_check_m.enterprise_no%type,
                                   strWareHouseNo  in idata_check_m.warehouse_no%type,
                                   strOwnerNo      in idata_check_m.owner_no%type,
                                   strsImportNo    in idata_check_m.s_import_no%type,
                                   strsCheckNo     in idata_check_m.s_check_no%type,
                                   strImporNo      in idata_check_pal_tmp.s_check_no%type,
                                   strArticleNo    in idata_check_d.article_no%type,
                                   strBarcode      in idata_check_d.barcode%type,
                                   nPackingQty     in idata_check_d.packing_qty%type,
                                   nCheckQty       in idata_check_d.check_qty%type,
                                   strLotNo        in idata_check_d.lot_no%type,
                                   dtProduceDate   in idata_check_d.produce_date%type,
                                   dtExpireDate    in idata_check_d.expire_date%type,
                                   strQuality      in idata_check_d.quality%type,
                                   --strItemType      in idata_check_d.item_type%type,
                                   --strBatchSerialNo in idata_check_d.batch_serial_no%type,
                                   strWorkerNo in idata_check_m.rgst_name%type,
                                   nRowId      out idata_check_d.row_id%type,
                                   strResult   out varchar2) is

    intCheck_row_id idata_check_pal.check_row_id%type; --板rowid
    v_strCheckNo    idata_check_pal.check_no%type;
    v_price         idata_check_d.price%type; --单价
  begin
    strResult := 'N|[p_idata_InsertCheckD]';

    --获取验收单号

    begin
      select check_no
        into v_strCheckNo
        from idata_check_m
       where enterprise_no = strEnterpriseNo
         and wareHouse_no = strWareHouseno
         and owner_no = strOwnerNo
         and import_no = strImporNo
         and s_import_no = strSimportNo
         and s_check_no = strsCheckNo;
    exception
      when no_data_found then
        strResult := 'N|[E20912]'; --查询验收单号为空!
        return;
        if (v_strCheckNo is null) then
          strResult := 'N|[E20912]';
          return;
        end if;
    end;

    --若已经存着属性相同的明细,累加数量
    begin
      select row_id
        into intCheck_row_id
        from idata_check_d t
       where t.enterprise_no = strEnterpriseNo
         and t.WAREHOUSE_NO = strWareHouseNo
         and t.owner_no = strOwnerNo
         and t.check_no = v_strCheckNo
         and t.article_no = strArticleNo
         and t.barcode = strBarcode
         and t.packing_qty = nPackingQty
         and t.lot_no = strLotNo
         and t.produce_date = dtProduceDate
         and t.expire_date = dtExpireDate
         and t.quality = strQuality
            --and t.item_type = strItemType
            --and t.batch_serial_no = strBatchSerialNo
         and t.check_worker1 = strWorkerNo;

      nRowId := intCheck_row_id;

      --更新进货单数量
      update idata_check_d t
         set t.check_qty    = t.check_qty + nCheckQty,
             check_end_date = sysdate
       where t.enterprise_no = strEnterpriseNo
         and t.WAREHOUSE_NO = strWareHouseNo
         and t.owner_no = strOwnerNo
         and t.check_no = v_strCheckNo
         and t.row_id = intCheck_row_id;

    exception
      when no_data_found then
        --若不存着属性相同的明细,新增明细
        --获取最大的CHECK_row_id

        select nvl(max(t.row_id), 0) + 1
          into intCheck_row_id
          from idata_check_d t
         where t.enterprise_no = strEnterpriseNo
           and t.WAREHOUSE_NO = strWareHouseNo
           and t.owner_no = strOwnerNo
           and t.check_no = v_strCheckNo;

        nRowId := intCheck_row_id;

        --取该商品的单价,写入验收明细表
        select distinct t.unit_cost
          into v_price
          from idata_import_d t
         where t.enterprise_no = strEnterPriseNo
           and t.warehouse_no = strWareHouseNo
           and t.article_no = strArticleNo
           and t.import_no =
               (select m.import_no
                  from idata_check_m m
                 where m.check_no = v_strCheckNo
                   and m.enterprise_no = strEnterPriseNo
                   and m.warehouse_no = strWareHouseNo);

        --写验收明细
        insert into idata_check_d
          (WAREHOUSE_NO,
           owner_no,
           check_no,
           article_no,
           barcode,
           packing_qty,
           check_qty,
           lot_no,
           produce_date,
           expire_date,
           quality,
           check_worker1,
           check_end_date,
           row_id,
           enterprise_no,
           price)
        values
          (strWareHouseNo,
           strOwnerNo,
           v_strCheckNo,
           strArticleNo,
           strBarcode,
           nPackingQty,
           nCheckQty,
           strLotNo,
           dtProduceDate,
           dtExpireDate,
           strQuality,
           strWorkerNo,
           sysdate,
           intCheck_row_id,
           strEnterpriseNo,
           v_price);
    end;

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_idata_IDInsertCheckD;
  /******************************以下是从pkob_idata_lich包合并过来的******************************/
  /*
   作者:lich
   日期:  2014-04-23
   功能: 写验收单头档并返回汇总单号
  */
  procedure p_Insert_Idata_Check_M(strEnterpriseNo in idata_check_m.enterprise_no%type,
                                   strWAREHOUSE_NO in idata_check_m.WAREHOUSE_NO%type, --仓别
                                   strOwnerNo      in idata_check_m.owner_no%type, --委托业主编码
                                   strSImportNo    in idata_check_m.s_import_no%type, --进货汇总单号
                                   strDockNo       in idata_check_m.dock_no%type, --码头号
                                   strWorkerNo     in idata_check_m.check_worker%type, --操作人
                                   strPrintGroup   in idata_check_m.printer_group_no%type, --打印机组
                                   strCheckTools   in idata_check_m.check_tools%type, --验收工具
                                   strSCheckNo     out idata_check_m.s_check_no%type, --汇总验收单号
                                   strResult       out varchar2 --返回结果
                                   ) is

    strCheckNo idata_check_m.check_no%type; --验收单号
    strMsg     varchar2(200);

  begin
    strResult := 'N|[p_Insert_Idata_Check_M]';
    --取汇总验收单号
    begin
      PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                 strWAREHOUSE_NO,
                                 CONST_DOCUMENTTYPE.IDATASC,
                                 strSCheckNo,
                                 strMsg);
      if (strSCheckNo is null or substr(strMsg, 1, 1) = 'N') then
        strResult := 'N|[E20909]'; --取汇总验收单号错误!
        return;
      end if;
    end;

    --循环进货单号写入验收单号
    begin
      for A in (select distinct iim.Import_no,
                                iim.supplier_no,
                                iim.import_type,iim.class_type
                  from idata_import_sm ism, idata_import_m iim
                 where ism.WAREHOUSE_NO = iim.WAREHOUSE_NO
                   and ism.enterprise_no = iim.enterprise_no
                   and ism.owner_no = iim.owner_no
                   and ism.import_no = iim.import_no
                   and ism.WAREHOUSE_NO = strWAREHOUSE_NO
                   and ism.enterprise_no = strEnterpriseNo
                   and ism.owner_no = strOwnerNo
                   and ism.s_import_no = strSImportNo
                   and ism.status <> '16'
                   and ism.status <> '13') loop

        --取验收单号
        begin
          strCheckNo := '';
          strMsg     := '';
          PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                     strWAREHOUSE_NO,
                                     CONST_DOCUMENTTYPE.IDATAIC,
                                     strCheckNo,
                                     strMsg);
          if (strCheckNo is null or substr(strMsg, 1, 1) = 'N') then
            strResult := 'N|[E20910]'; --取验收单号错误!
            return;
          end if;
        end;

        --写入验收单头档
        begin
          Insert into idata_check_m
            (enterprise_no,
             WAREHOUSE_NO,
             owner_no,
             check_no,
             s_import_no,
             s_check_no,
             import_type,
             import_no,
             supplier_no,
             dock_no,
             check_worker,
             qc_worker,
             status,
             check_start_date,
             check_end_date,
             rgst_name,
             rgst_date,
             PRINTER_GROUP_NO,
             check_tools,class_type)
          values
            (strEnterpriseNo,
             strWAREHOUSE_NO,
             strOwnerNo,
             strCheckNo,
             strSImportNo,
             strSCheckNo,
             a.import_type,
             a.import_no,
             a.supplier_no,
             strDockNo,
             strWorkerNo,
             strWorkerNo,
             '12',
             sysdate,
             sysdate,
             strWorkerNo,
             sysdate,
             strPrintGroup,
             strCheckTools,a.class_type);
          if (sql%rowcount <= 0) then
            strResult := 'N|[E20911]'; --写入验收单头档错误!
            return;
          end if;
        end;

      end loop;
    end;
    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_Insert_Idata_Check_M;

  /**********************************************************************************************
   作者:lich
   日期:  2014-04-23
   功能: 进货单对象：写入临时板表
  ************************************************************************************************/
  procedure p_Insert_Idata_Check_Pal_Tmp(strEnterprise_no in idata_check_pal_tmp.enterprise_no%type, --企业
                                         strWAREHOUSE_NO  in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                         strOwner_No      in idata_check_pal_tmp.owner_no%type, --委托业主编码
                                         strS_Import_No   in idata_check_m.s_import_no%type, --汇总进货单号
                                         strS_Check_No    in idata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                         strClassType     in idata_import_m.class_type%type,
                                         strArticle_No    in idata_check_pal_tmp.article_no%type, --商品编码
                                         strQuality       in idata_check_pal_tmp.quality%type, --品质
                                         dtProduceDate    in idata_check_pal_tmp.produce_date%type, --生产日期
                                         dtExpireDate     in idata_check_pal_tmp.expire_date%type, --有效日期
                                         strLot_No        in idata_check_pal_tmp.lot_no%type, --批号
                                         strRSV_BATCH1    in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                                         strRSV_BATCH2    in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                                         strRSV_BATCH3    in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                                         strRSV_BATCH4    in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                                         strRSV_BATCH5    in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                                         strRSV_BATCH6    in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                                         strRSV_BATCH7    in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                                         strRSV_BATCH8    in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                                         strTemperature   in idata_check_pal_tmp.temperature%type, --温度
                                         strBarcode       in idata_check_pal_tmp.barcode%type, --商品条码
                                         nPack_Qty        in idata_check_pal_tmp.packing_qty%type, --包装数量
                                         nCheck_Qty       in idata_check_pal_tmp.check_qty%type, --验收数量
                                         strLabel_No      in idata_check_pal_tmp.label_no%type, --板号
                                         strSub_Label_No  in idata_check_pal_tmp.sub_label_no%type, --尾箱标签
                                         strBusiness_Type in idata_check_pal_tmp.business_type%type, --业务类型
                                         strFixpal_Flag   in idata_check_pal_tmp.fixpal_flag%type, --板类型
                                         strPrintGroup    in idata_check_pal_tmp.printer_group_no%type, --打印机组
                                         strDock_No       in idata_check_pal_tmp.dock_no%type, --码头
                                         strStockType     in idata_check_pal_tmp.stock_type%type, --存储类型
                                         strStockValue    in idata_check_pal_tmp.stock_value%type, --存储类型对应值
                                         strWorker_No     in idata_check_pal_tmp.rgst_name%type, --验收人员
                                         --strItem_Type       in idata_check_pal_tmp.item_type%type, --商品类型
                                         strImportType  in idata_check_pal_tmp.import_type%type, --进货单别
                                         strSupplierNo  in idata_check_pal_tmp.supplier_no%type, --供应商
                                         strCheck_Tools in char, --检查工具 1:前台2:RF
                                         --strBatch_serial_No in idata_check_pal_tmp.batch_serial_no%type, --批次流水号
                                         nIsAdd       in integer, --是否累加 0:覆盖 1:累加
                                         strCustNo    in bdef_defcust.cust_no%type,
                                         strCheckType in idata_check_pal_tmp.check_type%type,
                                         nQpalette    in idata_check_pal_tmp.qpalette%type, --0：板型验收；1：箱型验收；2：不上分拣箱验收；3：综合验收
                                         strResult    out varchar2 --返回结果
                                         ) is

    intRowId idata_check_pal_tmp.row_id%type; --记录最大的row_id
  begin
    strResult := 'N|[p_Insert_Idata_Check_Pal_Tmp]';
    --锁临时板明细
    update idata_check_pal_tmp t
       set t.status = status
     where WAREHOUSE_NO = strWAREHOUSE_NO
       and enterprise_no = strEnterprise_no
       and owner_no = strOwner_No
       and S_Check_No = strS_Check_No
       and label_no = strLabel_No
       and packing_qty = nPack_Qty;

    if strLabel_No <> 'N' and (nIsAdd = 0) then
      --取最大的row_id
      begin
        select max(row_id) + 1
          into intRowId
          from idata_check_pal_tmp
         where WAREHOUSE_NO = strWAREHOUSE_NO
           and enterprise_no = strEnterprise_no
           and owner_no = strOwner_No
           and S_Check_No = strS_Check_No
           and label_no = strLabel_No;
      exception
        when no_data_found then
          intRowId := 1;
      end;
      if (intRowId is null) then
        intRowId := 1;
      end if;
      --覆盖式先删除,后增加
      delete from idata_check_pal_tmp icpt
       where icpt.WAREHOUSE_NO = strWAREHOUSE_NO
         and icpt.enterprise_no = strEnterprise_no
         and icpt.owner_no = strOwner_No
         and icpt.S_Check_No = strS_Check_No
         and icpt.label_no = strLabel_No
         and icpt.article_no = strArticle_no
         and icpt.packing_qty = nPack_Qty
         and icpt.produce_date = dtProduceDate
         and icpt.expire_date = dtExpireDate
         and icpt.quality = strQuality
         and icpt.lot_no = strLot_No
         and icpt.RSV_BATCH1 = strRSV_BATCH1
         and icpt.RSV_BATCH2 = strRSV_BATCH2
         and icpt.RSV_BATCH3 = strRSV_BATCH3
         and icpt.RSV_BATCH4 = strRSV_BATCH4
         and icpt.RSV_BATCH5 = strRSV_BATCH5
         and icpt.RSV_BATCH6 = strRSV_BATCH6
         and icpt.RSV_BATCH7 = strRSV_BATCH7
         and icpt.RSV_BATCH8 = strRSV_BATCH8
         and icpt.temperature = strTemperature
         and icpt.rgst_name = strWorker_No;

      insert into idata_check_pal_tmp
        (enterprise_no,
         warehouse_no,
         owner_no,
         s_check_no,
         s_import_no,
         article_no,
         packing_qty,
         check_qty,
         label_no,
         status,
         printer_group_no,
         dock_no,
         sub_label_no,
         barcode,
         produce_date,
         expire_date,
         quality,
         lot_no,
         rsv_batch1,
         rsv_batch2,
         rsv_batch3,
         rsv_batch4,
         rsv_batch5,
         rsv_batch6,
         rsv_batch7,
         rsv_batch8,
         temperature,
         stock_type,
         stock_value,
         check_tools,
         import_type,
         supplier_no,
         fixpal_flag,
         business_type,
         row_id,
         dept_no,
         cust_no,
         check_type,
         qpalette,
         rgst_name,
         rgst_date,class_type)
      values
        (strEnterprise_no,
         strWAREHOUSE_NO,
         strOwner_No,
         strS_Check_No,
         strS_Import_No,
         strArticle_No,
         nPack_Qty,
         nCheck_Qty,
         strLabel_No,
         '10',
         strPrintGroup,
         strDock_No,
         strSub_Label_No,
         strBarcode,
         dtProduceDate,
         dtExpireDate,
         strQuality,
         strLot_No,
         strRSV_BATCH1,
         strRSV_BATCH2,
         strRSV_BATCH3,
         strRSV_BATCH4,
         strRSV_BATCH5,
         strRSV_BATCH6,
         strRSV_BATCH7,
         strRSV_BATCH8,
         strTemperature,
         strStockType,
         strStockValue,
         strCheck_Tools,
         strImportType,
         strSupplierNo,
         strFixpal_Flag,
         strBusiness_Type,
         intRowId,
         'N',
         strCustNo,
         strCheckType,
         nQpalette,
         strWorker_No,
         sysdate,strClassType);
    else
      --更新不了则新增
      update idata_check_pal_tmp
         set Check_Qty = check_qty + nCheck_Qty
       where WAREHOUSE_NO = strWAREHOUSE_NO
         and enterprise_no = strEnterprise_no
         and owner_no = strOwner_No
         and s_import_no = strS_Import_No
         and S_Check_No = strS_Check_No
         and label_no = strLabel_No
         and article_no = strArticle_no
         and barcode = strBarcode
         and packing_qty = nPack_Qty
         and Quality = strQuality
         and stock_type = strStockType
         and stock_value = strStockValue
         and lot_no = strLot_No
         and RSV_BATCH1 = strRSV_BATCH1
         and RSV_BATCH2 = strRSV_BATCH2
         and RSV_BATCH3 = strRSV_BATCH3
         and RSV_BATCH4 = strRSV_BATCH4
         and RSV_BATCH5 = strRSV_BATCH5
         and RSV_BATCH6 = strRSV_BATCH6
         and RSV_BATCH7 = strRSV_BATCH7
         and RSV_BATCH8 = strRSV_BATCH8
         and temperature = strTemperature
         and produce_date = dtProduceDate
         and expire_date = dtExpireDate
         and supplier_no = strSupplierNo
         and import_type = strImportType
         and cust_no = strCustNo
         and rgst_name = strWorker_No;
      if sql%rowcount <= 0 then

        --取最大的row_id
        begin
          select max(row_id) + 1
            into intRowId
            from idata_check_pal_tmp
           where WAREHOUSE_NO = strWAREHOUSE_NO
             and enterprise_no = strEnterprise_no
             and owner_no = strOwner_No
             and S_Check_No = strS_Check_No
             and label_no = strLabel_No;
        exception
          when no_data_found then
            intRowId := 1;
        end;
        if (intRowId is null) then
          intRowId := 1;
        end if;

        insert into idata_check_pal_tmp
          (enterprise_no,
           warehouse_no,
           owner_no,
           s_check_no,
           s_import_no,
           article_no,
           packing_qty,
           check_qty,
           label_no,
           status,
           printer_group_no,
           dock_no,
           sub_label_no,
           barcode,
           produce_date,
           expire_date,
           quality,
           lot_no,
           rsv_batch1,
           rsv_batch2,
           rsv_batch3,
           rsv_batch4,
           rsv_batch5,
           rsv_batch6,
           rsv_batch7,
           rsv_batch8,
           temperature,
           stock_type,
           stock_value,
           check_tools,
           import_type,
           supplier_no,
           fixpal_flag,
           business_type,
           row_id,
           dept_no,
           cust_no,
           check_type,
           qpalette,
           rgst_name,
           rgst_date,class_type)
        values
          (strEnterprise_no,
           strWAREHOUSE_NO,
           strOwner_No,
           strS_Check_No,
           strS_Import_No,
           strArticle_No,
           nPack_Qty,
           nCheck_Qty,
           strLabel_No,
           '10',
           strPrintGroup,
           strDock_No,
           strSub_Label_No,
           strBarcode,
           dtProduceDate,
           dtExpireDate,
           strQuality,
           strLot_No,
           strRSV_BATCH1,
           strRSV_BATCH2,
           strRSV_BATCH3,
           strRSV_BATCH4,
           strRSV_BATCH5,
           strRSV_BATCH6,
           strRSV_BATCH7,
           strRSV_BATCH8,
           strTemperature,
           strStockType,
           strStockValue,
           strCheck_Tools,
           strImportType,
           strSupplierNo,
           strFixpal_Flag,
           strBusiness_Type,
           intRowId,
           'N',
           strCustNo,
           strCheckType,
           nQpalette,
           strWorker_No,
           sysdate,strClassType);
      end if;
    end if;
    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_Insert_Idata_Check_Pal_Tmp;

  /**********************************************************************************************
   作者:lich
   日期:  2014-04-23
   功能: 将临时板数据写入验收明细
  ************************************************************************************************/
  procedure p_insert_idata_check_D(strEnterpriseNo in idata_check_pal_tmp.enterprise_no%type,
                                   strWareHouseNo  in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                   strOwnerNo      in idata_check_pal_tmp.owner_no%type, --委托业主
                                   strSimportNo    in idata_check_m.s_import_no%type, --进货汇总单号
                                   strSCheckNo     in idata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                   strImporNo      in idata_check_pal_tmp.s_check_no%type,
                                   strWorkerNo     in idata_check_pal_tmp.rgst_name%type, --操作人
                                   nCheckQty       in idata_check_pal_tmp.check_qty%type,
                                   intRowId        in idata_check_pal_tmp.row_id%type,
                                   strLabelNo      in idata_check_pal_tmp.label_no%type,
                                   strResult       out varchar2) is

    intCheck_row_id idata_check_pal.check_row_id%type; --板rowid
    v_strCheckNo    idata_check_pal.check_no%type;
    v_iCount        integer;
    v_price         idata_check_d.price%type;
  begin
    strResult := 'N|[p_insert_idata_check_D]';
    v_iCount  := 0;
    --获取验收单号

    begin
      select check_no
        into v_strCheckNo
        from idata_check_m
       where wareHouse_no = strWareHouseno
         and enterprise_no = strEnterpriseNo
         and owner_no = strOwnerNo
         and import_no = strImporNo
         and s_import_no = strSimportNo
         and s_check_no = strsCheckNo;
    exception
      when no_data_found then
        strResult := 'N|[E20912]'; --查询验收单号为空!
        return;
        if (v_strCheckNo is null) then
          strResult := 'N|[E20912]'; --查询验收单号为空!
          return;
        end if;
    end;

    for P in (select *
                from idata_check_pal_tmp
               where WAREHOUSE_NO = strWareHouseNo
                 and enterprise_no = strEnterpriseNo
                 and owner_no = strOwnerNo
                 and s_import_no = strSimportNo
                 and s_check_no = strSCheckNo
                 and label_no = strLabelNo
                 and row_id = intRowId) loop

      v_iCount := v_iCount + 1;
      --若已经存着属性相同的明细,累加数量
      update idata_check_d t
         set t.check_qty    = t.check_qty + nCheckQty,
             check_end_date = sysdate
       where t.WAREHOUSE_NO = strWareHouseNo
         and t.enterprise_no = strEnterpriseNo
         and t.owner_no = strOwnerNo
         and t.check_no = v_strCheckNo
         and t.article_no = p.article_no
         and t.packing_qty = p.packing_qty
         and t.barcode = p.barcode
         and t.produce_date = p.produce_date
         and t.expire_date = p.expire_date
         and t.quality = p.quality
         and t.lot_no = p.lot_no
         and t.rsv_batch1 = p.rsv_batch1
         and t.rsv_batch2 = p.rsv_batch2
         and t.rsv_batch3 = p.rsv_batch3
         and t.rsv_batch4 = p.rsv_batch4
         and t.rsv_batch5 = p.rsv_batch5
         and t.rsv_batch6 = p.rsv_batch6
         and t.rsv_batch7 = p.rsv_batch7
         and t.rsv_batch8 = p.rsv_batch8
         and t.temperature = p.temperature
         and t.check_worker1 = strWorkerNo;

      if sql%notfound then
        --若不存着属性相同的明细,新增明细
        --获取最大的CHECK_row_id
        begin
          select nvl(max(t.row_id), 0) + 1
            into intCheck_row_id
            from idata_check_d t
           where t.WAREHOUSE_NO = strWareHouseNo
             and t.enterprise_no = strEnterpriseNo
             and t.owner_no = strOwnerNo
             and t.check_no = v_strCheckNo;
        exception
          when no_data_found then
            intCheck_row_id := 1;
        end;

        --取该商品的单价,写入验收板明细表
        select distinct t.unit_cost
          into v_price
          from idata_import_d t
         where t.enterprise_no = strEnterPriseNo
           and t.warehouse_no = strWareHouseNo
           and t.article_no = p.article_no
           and t.import_no =
               (select m.import_no
                  from idata_check_m m
                 where m.check_no = v_strCheckNo
                   and m.enterprise_no = strEnterPriseNo
                   and m.warehouse_no = strWareHouseNo);

        --写验收明细
        insert into idata_check_d
          (enterprise_no,
           warehouse_no,
           owner_no,
           check_no,
           row_id,
           article_no,
           packing_qty,
           qc_no,
           barcode,
           produce_date,
           expire_date,
           quality,
           lot_no,
           rsv_batch1,
           rsv_batch2,
           rsv_batch3,
           rsv_batch4,
           rsv_batch5,
           rsv_batch6,
           rsv_batch7,
           rsv_batch8,
           temperature,
           stock_type,
           stock_value,
           dept_no,
           check_qty,
           check_worker1,
           check_start_date,
           check_end_date,
           price)
        values
          (strEnterpriseNo,
           strWareHouseNo,
           strOwnerNo,
           v_strCheckNo,
           intCheck_row_id,
           p.article_no,
           p.packing_qty,
           'N',
           p.barcode,
           p.produce_date,
           p.expire_date,
           p.quality,
           p.lot_no,
           p.rsv_batch1,
           p.rsv_batch2,
           p.rsv_batch3,
           p.rsv_batch4,
           p.rsv_batch5,
           p.rsv_batch6,
           p.rsv_batch7,
           p.rsv_batch8,
           p.temperature,
           p.stock_type,
           p.stock_value,
           p.dept_no,
           nCheckQty,
           strWorkerNo,
           sysdate,
           sysdate,
           v_price);
      end if;
    end loop;
    if v_iCount = 0 then
      strResult := 'N|[E20913]'; --读取临时板明细失败'
      return;
    end if;
    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_insert_idata_check_D;

  /**********************************************************************************************
   作者:lich
   日期:  2014-04-23
   功能: 将临时板数据写入板明细
  ************************************************************************************************/
  procedure p_Insert_Idata_Check_Pal(strEnterpriseNo  in idata_check_pal_tmp.enterprise_no%type,
                                     strWareHouseNo   in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                     strOwnerNo       in idata_check_pal_tmp.owner_no%type, --委托业主
                                     strSimportNo     in idata_check_m.s_import_no%type, --进货汇总单号
                                     strSCheckNo      in idata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                     strImportNo      in idata_check_m.import_no%type, --单号
                                     strWorkerNo      in idata_check_pal_tmp.rgst_name%type, --操作人
                                     nCheckQty        in idata_check_pal_tmp.check_qty%type,
                                     strLabelNo       in idata_check_pal_tmp.label_no%type, --老板号
                                     strNewLabelNo    in idata_check_pal_tmp.label_no%type, --新板号
                                     strNewSubLabelNo in idata_check_pal.sub_label_no%type, --子板号
                                     strContainNo     in idata_check_pal.container_no%type, --内部容器号
                                     nRowId           in idata_check_pal_tmp.row_id%type,
                                     strResult        out varchar2) is

    v_iCount    integer;
    strCheck_No idata_check_m.check_no%type;
    nCheckRowId idata_check_pal.check_row_id%type;
    v_price     idata_check_d.price%type;
  begin
    strResult := 'N|[p_Insert_Idata_Check_Pal]';
    v_iCount  := 0;
    for P in (select *
                from idata_check_pal_tmp
               where WAREHOUSE_NO = strWareHouseNo
                 and enterprise_no = strEnterpriseNo
                 and owner_no = strOwnerNo
                 and s_import_no = strSimportNo
                 and s_check_no = strSCheckNo
                 and label_no = strLabelNo
                 and row_id = nRowId) loop

      v_iCount := v_iCount + 1;
      --取验收单号
      begin
        select check_no
          into strCheck_No
          from idata_check_m
         where WAREHOUSE_NO = strWareHouseNo
           and enterprise_No = strEnterpriseNo
           and owner_no = strOwnerNo
           and import_no = strImportNo
           and s_import_no = strsImportNo
           and status <> '13';
      exception
        when no_data_found then
          strResult := 'N|[E20912]'; --查询验收单号为空!
          return;
          if (strCheck_No is null) then
            strResult := 'N|[E20912]';
            return;
          end if;
      end;
      --获取CHECK_ROW_ID
      begin
        select row_id
          into nCheckRowId
          from idata_check_d t
         where t.WAREHOUSE_NO = strWareHouseNo
           and t.enterprise_no = strEnterpriseNo
           and t.owner_no = strOwnerNo
           and t.check_no = strCheck_No
           and t.article_no = p.article_no
           and t.barcode = p.barcode
           and t.packing_qty = p.packing_qty
           and t.lot_no = p.lot_no
           and t.produce_date = p.produce_date
           and t.expire_date = p.expire_date
           and t.quality = p.quality
           and t.lot_no = p.lot_no
           and t.rsv_batch1 = p.rsv_batch1
           and t.rsv_batch2 = p.rsv_batch2
           and t.rsv_batch3 = p.rsv_batch3
           and t.rsv_batch4 = p.rsv_batch4
           and t.rsv_batch5 = p.rsv_batch5
           and t.rsv_batch6 = p.rsv_batch6
           and t.rsv_batch7 = p.rsv_batch7
           and t.rsv_batch8 = p.rsv_batch8
           and t.check_worker1 = strWorkerNo
           and t.temperature = p.temperature;
      exception
        when no_data_found then
          --若不存着属性相同的明细,
          strResult := 'N|[E20920]'; --查询验收明细为空!
          return;
      end;

      --更新/写入板明细
      update idata_check_pal
         set check_qty = check_qty + nCheckQty
       where WAREHOUSE_NO = strWareHouseNo
         and enterprise_no = strEnterpriseNo
         and owner_no = strOwnerNo
         and S_Check_no = strsCheckNo
         and Check_No = strCheck_No
         and check_row_id = nCheckRowId
         and label_no = strNewLabelNo
         and container_no = strContainNo
         and status = '10';

      if sql%notfound then

        --取该商品的单价,写入验收板明细表
        select distinct t.unit_cost
          into v_price
          from idata_import_d t
         where t.enterprise_no = strEnterPriseNo
           and t.warehouse_no = strWareHouseNo
           and t.article_no = p.article_no
           and t.import_no =
               (select m.import_no
                  from idata_check_m m
                 where m.check_no = strCheck_No
                   and m.enterprise_no = strEnterPriseNo
                   and m.warehouse_no = strWareHouseNo);

        insert into idata_check_pal
          (enterprise_no,
           warehouse_no,
           owner_no,
           s_check_no,
           check_no,
           check_row_id,
           article_no,
           packing_qty,
           check_qty,
           status,
           label_no,
           printer_group_no,
           dock_no,
           sub_label_no,
           barcode,
           produce_date,
           expire_date,
           quality,
           lot_no,
           rsv_batch1,
           rsv_batch2,
           rsv_batch3,
           rsv_batch4,
           rsv_batch5,
           rsv_batch6,
           rsv_batch7,
           rsv_batch8,
           stock_type,
           stock_value,
           dept_no,
           fixpal_flag,
           container_no,
           cust_no, /*sub_cust_no,*/
           business_type,
           rgst_name,
           rgst_date,
           updt_name,
           updt_date,
           price,class_type,import_type)
        values
          (strEnterpriseNo,
           strWareHouseNo,
           strOwnerNo,
           strsCheckNo,
           strCheck_No,
           nCheckRowId,
           p.article_no,
           p.packing_qty,
           nCheckQty,
           '10',
           strNewLabelNo,
           p.printer_group_no,
           p.dock_no,
           strNewSubLabelNo,
           p.barcode,
           p.produce_date,
           p.expire_date,
           p.quality,
           p.lot_no,
           p.rsv_batch1,
           p.rsv_batch2,
           p.rsv_batch3,
           p.rsv_batch4,
           p.rsv_batch5,
           p.rsv_batch6,
           p.rsv_batch7,
           p.rsv_batch8,
           p.stock_type,
           p.stock_value,
           p.dept_no,
           p.fixpal_flag,
           strContainNo,
           p.cust_no,
           p.business_type,
           p.rgst_name,
           p.rgst_date,
           strWorkerNo,
           sysdate,
           v_price,p.class_type,p.import_type);
      end if;
    end loop;
    if v_iCount = 0 then
      strResult := 'N|[E20913]'; --读取临时板明细失败
      return;
    end if;
    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_Insert_Idata_Check_Pal;
  /**********************************************************************************************
   作者:lich
   日期:  2014-04-23
   功能: 更新进货手建单及进货汇总单
  ************************************************************************************************/
  procedure p_Update_Idata_Import_D(strEnterpriseNo in idata_check_pal_tmp.enterprise_no%type, --企业
                                    strWareHouseNo  in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                    strOwnerNo      in idata_check_pal_tmp.owner_no%type, --委托业主
                                    strSImportNo    in idata_check_m.s_import_no%type, --进货汇总单号
                                    strImportNo     in idata_check_m.import_no%type, --进货单号
                                    strArticle_no   in idata_import_d.article_no%type, --商品编码
                                    nPacking_qty    in idata_import_d.packing_qty%type, --包装数量
                                    nCheckQty       in idata_check_pal_tmp.check_qty%type,
                                    strWorkerNo     in idata_check_pal_tmp.rgst_name%type, --操作人
                                    strResult       out varchar2) is
  begin
    strResult := 'N|[p_Update_Idata_Import_D]';
    --更新进货单数量
    update idata_import_d
       set import_qty = import_qty + nCheckQty,
           status     = '12',
           check_name = strWorkerNo,
           check_date = sysdate
     where WAREHOUSE_NO = strWareHouseNo
       and enterprise_no = strEnterpriseNo
       and owner_no = strOwnerNo
       and import_no = strImportNo
       and article_no = strArticle_no
       and packing_qty = nPacking_qty;

    if (sql%rowcount <= 0) then
      strResult := 'N|[E20914]'; --回写进货数量错误!
      return;
    end if;

    --更新汇总进货明细数量
    update idata_import_sd
       set import_qty = import_qty + nCheckQty,
           status     = '12',
           check_name = strWorkerNo,
           check_date = sysdate
     where WAREHOUSE_NO = strWareHouseNo
       and enterprise_no = strEnterpriseNo
       and owner_no = strOwnerNo
       and s_import_no = strSImportNo
       and article_no = strArticle_no
       and packing_qty = nPacking_qty;
    if (sql%rowcount <= 0) then
      strResult := 'N|[E20915]'; --回写进货汇总数量错误!
      return;
    end if;

    strResult := 'Y|';

  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_Update_Idata_Import_D;

  /*****************************************************************************************
      作者:lich
      日期:  2014-04-23
      功能：新增标签号
  *****************************************************************************************/
  procedure p_Insert_Stock_Label_M(strEnterprise_no      in STOCK_LABEL_M.ENTERPRISE_NO%TYPE,
                                   strwarehouse_no       in STOCK_LABEL_M.warehouse_no%type, --仓别
                                   strBATCH_NO           in STOCK_LABEL_M.BATCH_NO%type, --批次
                                   strSOURCE_NO          in STOCK_LABEL_M.SOURCE_NO%type, --来源单号
                                   strLABEL_NO           in STOCK_LABEL_M.LABEL_NO%type, --标签号
                                   strCONTAINER_NO       in STOCK_LABEL_M.CONTAINER_NO%type, --内部容器号
                                   strCONTAINER_TYPE     in STOCK_LABEL_M.CONTAINER_TYPE%type, --容器类型
                                   strDELIVER_AREA       in STOCK_LABEL_M.DELIVER_AREA%type, --发货区储位
                                   strOWNER_CELL_NO      in STOCK_LABEL_M.OWNER_CELL_NO%type, --最后并入储位
                                   strCUST_NO            in STOCK_LABEL_M.CUST_NO%type, --客户编号
                                   strTRUNCK_CELL_NO     in STOCK_LABEL_M.TRUNCK_CELL_NO%type, --笼车上储位编码
                                   strA_SORTER_CHUTE_NO  in STOCK_LABEL_M.A_SORTER_CHUTE_NO%type, --大分拣机滑道号
                                   strCHECK_CHUTE_NO     in STOCK_LABEL_M.CHECK_CHUTE_NO%type, --复核台滑道号
                                   strDELIVER_OBJ        in STOCK_LABEL_M.DELIVER_OBJ%type, --配送对象
                                   strUSE_TYPE           in STOCK_LABEL_M.USE_TYPE%type, --标签用途
                                   strLINE_NO            in STOCK_LABEL_M.LINE_NO%type, --线路
                                   strCURR_AREA          in STOCK_LABEL_M.CURR_AREA%type, --当前位置
                                   strDeviceNo           in STOCK_LABEL_M.device_no%type, --设备类型
                                   strRGST_NAME          in STOCK_LABEL_M.RGST_NAME%type, --添加人员
                                   strREPORT_ID          in STOCK_LABEL_M.REPORT_ID%type, --报表ID
                                   strMID_LABEL_NO       in STOCK_LABEL_M.MID_LABEL_NO%type, --出货物流箱号
                                   strBIG_EXP_NO_FLAG    in STOCK_LABEL_M.BIG_EXP_NO_FLAG%type, --大批量出货单标识
                                   strSTOCK_TYPE         in STOCK_LABEL_M.STOCK_TYPE%type, --存储类型
                                   strCHUTE_LABEL_FLAG   in STOCK_LABEL_M.CHUTE_LABEL_FLAG%type, --是否大分拣机滑道口取号标签,可用于并板,0：不是；1：是
                                   strOWNER_CONTAINER_NO in STOCK_LABEL_M.OWNER_CONTAINER_NO%type, --最后并入容器号
                                   strstatus             in STOCK_LABEL_M.status%type, --状态
                                   strHm_Manual_Flag     in STOCK_LABEL_M.Hm_Manual_Flag%type, --是否储位库存 1储位库存,0标签库存
                                   strWaveNo             in stock_label_m.wave_no%type,
                                   strOutMsg             out varchar2) --返回 执行结果
   is
  begin
    strOutMsg := 'N|[p_Insert_Stock_Label_M]';

    ------------1新增标签头挡---------------------------------------------------
    insert into STOCK_LABEL_M
      (ENTERPRISE_NO,
       WAREHOUSE_NO,
       BATCH_NO,
       SOURCE_NO,
       LABEL_NO,
       CONTAINER_NO,
       CONTAINER_TYPE,
       DELIVER_AREA,
       STATUS, /*LOAD_CONTAINER_NO,*/
       OWNER_CONTAINER_NO,
       OWNER_CELL_NO,
       CUST_NO,
       TRUNCK_CELL_NO,
       A_SORTER_CHUTE_NO,
       CHECK_CHUTE_NO,
       DELIVER_OBJ,
       USE_TYPE,
       LINE_NO,
       CURR_AREA, /* SEQ_VALUE, LENGTH, WIDTH, HEIGHT,*/
       DEVICE_NO,
       REPORT_ID, /*RECHECK_NO,*/
       MID_LABEL_NO,
       BIG_EXP_NO_FLAG, /*CHECK_CHUTE_INSTATUS, */
       STOCK_TYPE, /* EXP_DATE,*/
       CHUTE_LABEL_FLAG,
       HM_MANUAL_FLAG,
       RGST_NAME,
       RGST_DATE,
       wave_no /*,
                                                                     UPDT_NAME, UPDT_DATE*/)
    values
      (strEnterprise_no,
       strwarehouse_no,
       strBATCH_NO,
       strSOURCE_NO,
       strLABEL_NO,
       strCONTAINER_NO,
       strCONTAINER_TYPE,
       strDELIVER_AREA,
       strstatus,
       strOWNER_CONTAINER_NO,
       strOWNER_CELL_NO,
       strCUST_NO,
       strTRUNCK_CELL_NO,
       strA_SORTER_CHUTE_NO,
       strCHECK_CHUTE_NO,
       strDELIVER_OBJ,
       strUSE_TYPE,
       strLINE_NO,
       strCURR_AREA, /* SEQ_VALUE, LENGTH, WIDTH, HEIGHT,*/
       strDeviceNo,
       strREPORT_ID, /*RECHECK_NO,*/ strMID_LABEL_NO,
       strBIG_EXP_NO_FLAG, /*CHECK_CHUTE_INSTATUS, */ strSTOCK_TYPE, /*EXP_DATE,*/
       strCHUTE_LABEL_FLAG,
       strHm_Manual_Flag,
       strRGST_NAME,
       sysdate,
       strWaveNo);
    if sql%rowcount <= 0 then
      --新增失败
      strOutMsg := 'N|[E20916]'; --新增标签头档失败
      return;
    end if;
    ------------2新增标签日志---------------------------------------------------
    p_Insert_Stock_Label_Log(strEnterprise_no,
                             strwarehouse_no,
                             strcontainer_no,
                             strRGST_NAME,
                             0,
                             strstatus,
                             strOutMsg);
    if (substr(strOutMsg, 1, 1) <> 'Y') then
      return;
    end if;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_Insert_Stock_Label_M;

  /*****************************************************************************************
   作者:lich
   日期:  2014-04-23
   功能：新增标签日志
  *****************************************************************************************/
  procedure p_Insert_Stock_Label_Log(strEnterprise_no in STOCK_LABEL_M.ENTERPRISE_NO%TYPE,
                                     strwarehouse_no  in STOCK_LABEL_M.warehouse_no%type, --仓别
                                     strContainerNo   in STOCK_LABEL_M.container_no%type, --容器号
                                     strUSER_ID       in STOCK_LABEL_M.updt_name%type, --员工ID
                                     blInsertFlag     in number, --标签跟踪非插入时,要判断新状态是否与老状态一致,如一致不新增日志
                                     strSTATUS        in STOCK_LABEL_M.status%type, --状态
                                     strOutMsg        out varchar2) --返回值
   is
  begin
    strOutMsg := 'N|[p_Insert_Stock_Label_Log]';
    if (blInsertFlag = 0) then
      insert into STOCK_LABEL_LOG
        (enterprise_no,
         warehouse_no,
         LABEL_NO,
         CONTAINER_NO,
         OWNER_CELL_NO,
         CONTAINER_TYPE,
         OWNER_CONTAINER_NO,
         STATUS,
         RGST_NAME,
         RGST_DATE)
        select m.enterprise_no,
               m.warehouse_no,
               m.label_no,
               m.container_no,
               m.owner_cell_no,
               m.container_type,
               m.owner_container_no,
               strSTATUS,
               strUSER_ID,
               sysdate
          from STOCK_LABEL_M m
         where m.enterprise_no = strEnterprise_no
           and m.warehouse_no = strwarehouse_no
           and m.container_no = strContainerNo;
      if sql%notfound then
        strOutMsg := 'N|[E20917]'; --写标签日志失败
        return;
      end if;
    else
      insert into STOCK_LABEL_LOG
        (enterprise_no,
         warehouse_no,
         LABEL_NO,
         CONTAINER_NO,
         OWNER_CELL_NO,
         CONTAINER_TYPE,
         OWNER_CONTAINER_NO,
         STATUS,
         RGST_NAME,
         RGST_DATE)
        select m.enterprise_no,
               m.warehouse_no,
               m.label_no,
               m.container_no,
               m.owner_cell_no,
               m.container_type,
               m.owner_container_no,
               m.status,
               strUSER_ID,
               sysdate
          from STOCK_LABEL_M m
         where m.enterprise_no = strEnterprise_no
           and m.warehouse_no = strwarehouse_no
           and m.container_no = strContainerNo
           and m.STATUS <> strSTATUS;
    end if;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_Insert_Stock_Label_Log;

  /******************************************************************************************
   作者：lich
   日期：2014-04-25
   功能：写定位指示表
  *****************************************************************************************/
  procedure p_Insert_Idata_Locate_Direct(strEnterpriseNo    in idata_check_pal.enterprise_no%type,
                                         strWareHouseNo     in idata_check_pal.warehouse_no%type, --仓别
                                         strOwnerNo         in idata_locate_direct.owner_no%type, --货主业主编码
                                         strLocateType      in idata_locate_direct.locate_type%type,
                                         strLocateFlag      in idata_locate_direct.container_locate_flag%type, --0按箱定位；1：按商品定位
                                         strAutoLoateFlag   in idata_locate_direct.auto_locate_flag%type, --0:手工定位；1：自动定位
                                         strScheckNo        in idata_check_pal.s_check_no%type, --汇总验收单号
                                         strCellNo          in idata_locate_direct.cell_no%type,
                                         strUser_ID         in idata_check_pal.Rgst_Name%type, --操作人员
                                         strLocateNo        in idata_locate_direct.locate_no%type,
                                         strspecify_cell_no IN idata_locate_direct.specify_cell_no%type, --指定储位
                                         strArticleNo       in idata_locate_direct.article_no%type,
                                         nArticleId         in idata_locate_direct.article_id%type, --商品属性ID
                                         nPackingQty        in idata_locate_direct.packing_qty%type,
                                         strDockNo          in idata_locate_direct.dock_no%type,
                                         strPrinterGroupNo  in idata_locate_direct.printer_group_no%type,
                                         strRgstName        in idata_locate_direct.rgst_name%type,
                                         strStockType       in idata_locate_direct.stock_type %type,
                                         strStockValue      in idata_locate_direct.stock_value%type,
                                         strSubLabelNo      in idata_locate_direct.sub_label_no%type,
                                         strLabelNo         in idata_locate_direct.label_no%type,
                                         strBusinessType    in idata_locate_direct.business_type%type,
                                         strFixpalFlag      in idata_locate_direct.Fixpal_Flag%type,
                                         strSerialNo        in idata_locate_direct.serial_no%type, --进货汇总单流水号
                                         strQuality         in idata_locate_direct.quality%type,
                                         strImport_Type     in idata_locate_direct.import_type%type,
                                         strOutMsg          out varchar2) --返回 执行结果
   is
  begin
    strOutMsg := 'N|[E00025]-p_Insert_Idata_Locate_Direct';
    --写入库定位指示
    insert into Idata_Locate_Direct
      (enterprise_no,
       Warehouse_No,
       Owner_No,
       Locate_No,
       Locate_Type,
       Auto_Locate_Flag,
       Container_Locate_Flag,
       Source_No,
       Cell_No,
       Cell_Id,
       Operate_Type,
       Article_No,
       Article_Id,
       Packing_Qty,
       Article_Qty,
       Dock_No,
       Printer_Group_No,
       Exclude_Cell_No,
       Status,
       Locate_Time,
       Check_Worker,
       Stock_Type,
       Stock_Value,
       Sub_Label_No,
       Label_No,
       Business_Type,
       Fixpal_Flag,
       Rgst_Name,
       Rgst_Date,
       Specify_Cell_No,
       serial_no,
       quality,
       import_type)
      select strEnterpriseNo,
             strWareHouseNo,
             strOwnerNo,
             strLocateNo,
             strLocateType,
             strAutoLoateFlag,
             strLocateFlag,
             strScheckNo,
             strCellNo,
             t.cell_id,
             slm.container_type,
             strArticleNo,
             nArticleId,
             nPackingQty,
             t.qty,
             strDockNo,
             strPrinterGroupNo,
             'N',
             '10',
             sysdate,
             strRgstName,
             strStockType,
             strStockValue,
             strSubLabelNo,
             strLabelNo,
             strBusinessType,
             strFixpalFlag,
             strUser_ID,
             sysdate,
             strspecify_cell_no,
             strSerialNo,
             strQuality,
             strImport_Type
        from stock_content t, stock_label_m slm
       where t.enterprise_no = slm.enterprise_no
         and t.warehouse_no = slm.warehouse_no
         and t.label_no = slm.label_no
         and t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         AND t.owner_no = strOwnerNo
         and t.cell_no = strCellNo
         and t.article_no = strArticleNo
         and t.article_id = nArticleId
         and t.packing_qty = nPackingQty
         and t.stock_type = strStockType
         and t.stock_value = strStockValue
         and t.label_no = strLabelNo;

    if sql%notfound then
      strOutMsg := 'N|[E20918]'; --写入库定位指示失败
      return;
    end if;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end p_Insert_Idata_Locate_Direct;

  /******************************************************************************************************************
   修改人：lich
   日期:2014-04-24
   功能：验收确认
  *******************************************************************************************************************/
  procedure P_Close_Idata_Check(strEnterpriseNo         in idata_check_pal_tmp.enterprise_no%type,
                                strWAREHOUSE_NO         in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码)
                                strS_import_no          in idata_check_m.s_import_no%type, --进货汇总单号
                                strS_Check_no           in idata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                strWorkerNo             in idata_check_pal_tmp.rgst_name%type, --操作人
                                strUnloadWorkerNo       in idata_check_m.unload_worker%type,
                                strIC_ConfirmBuildSheet in wms_defbase.ndefine%type, --0剩余部分手工重新预约,1不自动预约,原汇总单有效,2：自动预约产生新汇总单
                                strDockNo               in pntset_printer_workstation.workstation_no%type, --工作站号
                                strResult               Out varchar2) is
    v_strCloseIdataAllot wms_defbase.sdefine%type;
    v_nCloseIdataAllot   wms_defbase.ndefine%type;
    v_strOwnerNo         idata_import_mm.owner_no%type;
    v_strImportNo        idata_import_sm.import_no%type;
    v_strNewS_Import_No  idata_import_mm.s_import_no%type; --自动集单的新汇总单号
    v_strImportType      idata_import_m.import_type%type;
  begin
    strResult := 'N|[P_Close_Idata_Check]';

    --获取货主信息
    select owner_no,import_type
      into v_strOwnerNo,v_strImportType
      from idata_import_mm
     where enterprise_no = strEnterpriseNo
       and warehouse_no = strWAREHOUSE_NO
       and s_import_no = strS_import_no;

    PKLG_WMS_Public.P_GetIdataOrder(strEnterPriseNo,strWAREHOUSE_NO,v_strOwnerNo,v_strImportType,
        'CLOSE_ALLOT_FLAG',v_strCloseIdataAllot,strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    --更新验收单状态
    update idata_check_m icm
       set icm.status        = '13',
           icm.unload_worker = strUnloadWorkerNo,
           icm.updt_name     = strWorkerNo,
           icm.updt_date     = sysdate
     where icm.enterprise_no = strEnterpriseNo
       and icm.warehouse_no = strWAREHOUSE_NO
       and icm.s_import_no = strS_import_no
       and icm.s_check_no = strS_Check_no
       and icm.status in ('10', '12');

    if sql%notfound then
      strResult := 'N|[E20938]';
      return;
    end if;

    if v_strCloseIdataAllot = '1' then
      update idata_import_allot iia
         set iia.status    = '13',
             iia.updt_name = strWorkerNo,
             iia.updt_date = sysdate
       where iia.enterprise_no = strEnterpriseNo
         and iia.warehouse_no = strWareHouse_NO
         and iia.import_no in
             (select import_no
                from idata_check_m
               where warehouse_no = strWareHouse_NO
                 and enterprise_no = strEnterpriseNo
                 and s_import_no = strS_import_no
                 and s_check_no = strS_check_no);
    end if;

    if strIC_ConfirmBuildSheet = '0' then
      --更新进货汇总明细状态
      update idata_import_sd
         set status = '13'
       where s_import_no = strS_import_no
         and enterprise_no = strEnterpriseNo
         and warehouse_no = strWAREHOUSE_NO
         and status not in ('13', '16');

      update idata_import_sm
         set status = '13', updt_name = strWorkerNo, updt_date = sysdate
       where enterprise_no = strEnterpriseNo
         and warehouse_no = strWAREHOUSE_NO
         and s_import_no = strS_import_no
         and status not in ('13', '16');

      --更新进货汇总头档状态
      update idata_import_mm iim
         set status = '13', updt_name = strWorkerNo, updt_date = sysdate
       where enterprise_no = strEnterpriseNo
         and warehouse_no = strWAREHOUSE_NO
         and s_import_no = strS_import_no
         and status not in ('13', '16');

    end if;

    if strIC_ConfirmBuildSheet = '1' then
      --已全部验收完成的单据也要更新进货汇总单的状态
      update idata_import_sd
         set status = '13'
       where s_import_no = strS_import_no
         and enterprise_no = strEnterpriseNo
         and warehouse_no = strWAREHOUSE_NO
         and not exists (select 'x'
                from idata_import_sd
               where s_import_no = strS_import_no
                 and warehouse_no = strWAREHOUSE_NO
                 and enterprise_no = strEnterpriseNo
                 and po_qty - import_qty > 0);

      update idata_import_sm
         set status = '13', updt_name = strWorkerNo, updt_date = sysdate
       where enterprise_no = strEnterpriseNo
         and warehouse_no = strWAREHOUSE_NO
         and s_import_no = strS_import_no
         and status not in ('13', '16')
         and not exists (select 'x'
                from idata_import_sd
               where s_import_no = strS_import_no
                 and warehouse_no = strWAREHOUSE_NO
                 and enterprise_no = strEnterpriseNo
                 and status not in ('13', '16'));

      --更新进货汇总头档状态
      update idata_import_mm iim
         set status = '13', updt_name = strWorkerNo, updt_date = sysdate
       where enterprise_no = strEnterpriseNo
         and warehouse_no = strWAREHOUSE_NO
         and s_import_no = strS_import_no
         and status not in ('13', '16')
         and not exists (select 'x'
                from idata_import_sm
               where s_import_no = strS_import_no
                 and warehouse_no = strWAREHOUSE_NO
                 and enterprise_no = strEnterpriseNo
                 and status not in ('13', '16'));
    end if;

    if strIC_ConfirmBuildSheet = '2' then
      --自动预约
      --自动集单
      for t in (select *
                  from idata_import_sm
                 where enterprise_no = strEnterpriseNo
                   and warehouse_no = strWAREHOUSE_NO
                   and s_import_no = strS_import_no) loop

        PKLG_IDATA.p_single_set(strEnterpriseNo,
                                strWAREHOUSE_NO,
                                t.import_no,
                                'N',
                                strWorkerNo,
                                v_strNewS_Import_No,
                                strResult);
        if substr(strResult, 1, 1) <> 'Y' then
          return;
        end if;
      end loop;
    end if;

    --更新箱码表数据
    update stock_box_m t
       set t.status = '2'
     where t.status = '1'
       and enterprise_no = strEnterpriseNo
       and warehouse_no = strWAREHOUSE_NO
       and s_import_no = strS_import_no;

    strResult := 'Y|';

  end P_Close_Idata_Check;
  /******************************************************************************************************************
   修改人：lich
   日期:2014-04-24
   功能：对进货单做结案
  *******************************************************************************************************************/
  procedure P_Close_Idata_Import(strEnterprise_no in idata_check_pal_tmp.enterprise_no%type, --企业
                                 strWAREHOUSE_NO  in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码)
                                 strS_import_no   in idata_check_m.s_import_no%type, --进货汇总单号
                                 strWorkerNo      in idata_check_pal_tmp.rgst_name%type, --操作人
                                 strReturnType    in wms_defbase.sdefine%type, --1:一单一验；2：一品多验；3：一单多验
                                 strResult        Out varchar2) is
  begin
    strResult := 'N|[P_Close_Idata_Import]';

    if strReturnType = 1 then
      --更新进货单明细状态
      update idata_import_d
         set status = '13'
       where enterprise_no = strEnterprise_no
         and warehouse_no = strWAREHOUSE_NO
         and import_no in (select import_no
                             from idata_check_m
                            where enterprise_no = strEnterprise_no
                              and warehouse_no = strWAREHOUSE_NO
                              and s_import_no = strS_import_no
                              and status = '13')
         and status not in ('13', '16');

    end if;
    if strReturnType = 3 then
      --一单多验
      --更新进货单明细状态
      update idata_import_d
         set status = '13'
       where enterprise_no = strEnterprise_no
         and warehouse_no = strWAREHOUSE_NO
         and import_no in (select import_no
                             from idata_check_m
                            where enterprise_no = strEnterprise_no
                              and warehouse_no = strWAREHOUSE_NO
                              and s_import_no = strS_import_no
                              and status = '13')
         and status not in ('13', '16')
         and import_qty > 0;

      update idata_import_d
         set status = '10'
       where enterprise_no = strEnterprise_no
         and warehouse_no = strWAREHOUSE_NO
         and import_no in (select import_no
                             from idata_check_m
                            where enterprise_no = strEnterprise_no
                              and warehouse_no = strWAREHOUSE_NO
                              and s_import_no = strS_import_no
                              and status = '13')
         and status not in ('13', '16')
         and import_qty = 0;

    end if;

    if strReturnType = 2 then
      --更新进货单明细状态
      update idata_import_d
         set status = '13'
       where enterprise_no = strEnterprise_no
         and warehouse_no = strWAREHOUSE_NO
         and import_no in (select import_no
                             from idata_check_m
                            where enterprise_no = strEnterprise_no
                              and warehouse_no = strWAREHOUSE_NO
                              and s_import_no = strS_import_no
                              and status = '13')
         and status not in ('13', '16')
         and po_qty = import_qty;
      update idata_import_d
         set status = '10'
       where enterprise_no = strEnterprise_no
         and warehouse_no = strWAREHOUSE_NO
         and import_no in (select import_no
                             from idata_check_m
                            where enterprise_no = strEnterprise_no
                              and warehouse_no = strWAREHOUSE_NO
                              and s_import_no = strS_import_no
                              and status = '13')
         and status not in ('13', '16')
         and po_qty - import_qty > 0;
    end if;

    --更新进货头档状态 若整进货单验收完成改为13

    update idata_import_m
       set status = '13', updt_name = strWorkerNo, updt_date = sysdate
     where enterprise_no = strEnterprise_no
       and warehouse_no = strWAREHOUSE_NO
       and import_no in
           (select iCM.import_no
              from idata_check_m icm, idata_import_d iid
             where icm.import_no = iid.import_no
               and icm.enterprise_no = iid.enterprise_no
               and icm.enterprise_no = strEnterprise_no
               and icm.warehouse_no = iid.warehouse_no
               and icm.warehouse_no = strWAREHOUSE_NO
               and icm.s_import_no = strS_import_no
               and icm.status = '13'
               and not exists
             (select 'x'
                      from idata_check_m a, idata_import_d b
                     where a.enterprise_no = b.enterprise_no
                       and a.enterprise_no = strEnterprise_no
                       and a.warehouse_no = b.warehouse_no
                       and a.warehouse_no = strWAREHOUSE_NO
                       and a.import_no = b.import_no
                       and a.s_import_no = strS_import_no
                       and b.status not in ('13', '16')))
       and status not in ('13', '16');

    --更新进货头档状态 ,将未验收完成的订单状态改为10
    update idata_import_m
       set status = '10', updt_name = strWorkerNo, updt_date = sysdate
     where enterprise_no = strEnterprise_no
       and warehouse_no = strWAREHOUSE_NO
       and import_no in
           (select iCM.import_no
              from idata_check_m icm, idata_import_d iid
             where icm.import_no = iid.import_no
               and icm.enterprise_no = iid.enterprise_no
               and icm.enterprise_no = strEnterprise_no
               and icm.warehouse_no = iid.warehouse_no
               and icm.warehouse_no = strWAREHOUSE_NO
               and icm.s_import_no = strS_import_no
               and icm.status = '13'
               and exists (select 'x'
                      from idata_check_m a, idata_import_d b
                     where a.enterprise_no = b.enterprise_no
                       and a.enterprise_no = strEnterprise_no
                       and a.warehouse_no = b.warehouse_no
                       and a.warehouse_no = strWAREHOUSE_NO
                       and a.import_no = b.import_no
                       and a.s_import_no = strS_import_no
                       and b.status not in ('13', '16')))
       and status not in ('13', '16');
    strResult := 'Y|';

  end P_Close_Idata_Import;

  /******************************************************************************************************************
   修改人：lich
   日期:2014-05-24
   功能：将进货汇总单转历史
  *******************************************************************************************************************/
  procedure P_Idata_sImportToHty(strEnterprise_no in idata_check_mhty.enterprise_no%type, --企业
                                 strWAREHOUSE_NO  in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码)
                                 strOwner_No      in idata_check_mhty.owner_no%type,
                                 strS_import_no   in idata_check_m.s_import_no%type, --进货汇总单号
                                 strResult        Out varchar2) is
    v_iCount integer;
  begin
    strResult := 'N|[P_Idata_ImportToHty]';

    --锁表
    update idata_import_mm
       set status = status
     where enterprise_no = strEnterprise_no
       and warehouse_no = strWAREHOUSE_NO
       and s_import_no = strS_import_no;

    select count(*)
      into v_iCount
      from idata_import_sd iis
     where iis.enterprise_no = strEnterprise_no
       and iis.warehouse_no = strWAREHOUSE_NO
       and iis.s_import_no = strS_import_no
       and iis.status not in ('13', '16');

    if v_iCount = 0 then

      --将进货汇总单明细转历史
      insert into idata_import_sdhty
        (enterprise_no,
         warehouse_no,
         owner_no,
         s_import_no,
         row_id,
         article_no,
         packing_qty,
         po_qty,
         import_qty,
         qc_qty,
         check_name,
         status,
         check_date,
         qc_status,
         out_stock_flag,
         outpace_article_flag,
         item_type,
         plan_across_qty,
         check_across_qty,
         qc_flag)
        select iis.enterprise_no,
               iis.warehouse_no,
               iis.owner_no,
               iis.s_import_no,
               iis.row_id,
               iis.article_no,
               iis.packing_qty,
               iis.po_qty,
               iis.import_qty,
               iis.qc_qty,
               iis.check_name,
               iis.status,
               iis.check_date,
               iis.qc_status,
               iis.out_stock_flag,
               iis.outpace_article_flag,
               iis.item_type,
               iis.plan_across_qty,
               iis.check_across_qty,
               iis.qc_flag
          from idata_import_sd iis
         where iis.enterprise_no = strEnterprise_no
           and iis.warehouse_no = strWAREHOUSE_NO
           and iis.s_import_no = strS_import_no;

      delete from idata_import_sd
       where enterprise_no = strEnterprise_no
         and warehouse_no = strWAREHOUSE_NO
         and s_import_no = strS_import_no;

      --将进货汇总单对应关系转历史
      insert into idata_import_smhty
        (enterprise_no,
         warehouse_no,
         owner_no,
         import_type,
         s_import_no,
         import_no,
         po_no,
         po_type,
         status,
         rgst_name,
         rgst_date,
         updt_name,
         updt_date,
         --huangb 20160509
         REPORT_UP_SERIAL)
        select t.enterprise_no,
               t.warehouse_no,
               t.owner_no,
               t.import_type,
               t.s_import_no,
               t.import_no,
               t.po_no,
               t.po_type,
               t.status,
               t.rgst_name,
               t.rgst_date,
               t.updt_name,
               t.updt_date,
               --huangb 20160509
               REPORT_UP_SERIAL
          from idata_import_sm t
         where t.enterprise_no = strEnterprise_no
           and t.warehouse_no = strWAREHOUSE_NO
           and t.s_import_no = strS_import_no;

      --将进货汇总单头档转历史
      insert into idata_import_mmhty
        (enterprise_no,
         warehouse_no,
         import_type,
         s_import_no,
         owner_no,
         dept_no,
         po_type,
         supplier_no,
         status,
         serial_no,
         stock_type,
         stock_value,
         printer_name,
         printer_date,
         rgst_name,
         rgst_date,
         updt_name,
         updt_date,
         sendcar_no,
         car_no,
         driver_name,
         wave_no,
         --huangb 20160509
         REPORT_UP_SERIAL,class_type)
        select t.enterprise_no,
               t.warehouse_no,
               t.import_type,
               t.s_import_no,
               t.owner_no,
               t.dept_no,
               t.po_type,
               t.supplier_no,
               t.status,
               t.serial_no,
               t.stock_type,
               t.stock_value,
               t.printer_name,
               t.printer_date,
               t.rgst_name,
               t.rgst_date,
               t.updt_name,
               t.updt_date,
               t.sendcar_no,
               t.car_no,
               t.driver_name,
               t.wave_no,
               --huangb 20160509
               REPORT_UP_SERIAL,t.class_type
          from idata_import_mm t
         where t.enterprise_no = strEnterprise_no
           and t.warehouse_no = strWAREHOUSE_NO
           and t.s_import_no = strS_import_no;

      delete from idata_import_sm
       where enterprise_no = strEnterprise_no
         and warehouse_no = strWAREHOUSE_NO
         and s_import_no = strS_import_no;

      delete from idata_import_mm
       where enterprise_no = strEnterprise_no
         and warehouse_no = strWAREHOUSE_NO
         and s_import_no = strS_import_no;
    end if;

    strResult := 'Y|';

  end P_Idata_sImportToHty;

  /******************************************************************************************************************
   日期:2016-7-8
   功能：将某段时间之前的结案的进货单和对应的验收单转历史
  *******************************************************************************************************************/
  procedure P_Idata_ImportToHty(strEnterprise_no in idata_check_mhty.enterprise_no%type, --企业
                                strWAREHOUSE_NO  in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码)
                                strOwner_No      in idata_check_mhty.owner_no%type,
                                nDays            in integer, --结转天数,例如60表示60天以前结案的数据
                                strResult        Out varchar2) is
  begin
    strResult := 'N|[P_Idata_ImportToHty]';

    insert into idata_import_mhty
      (warehouse_no,
       owner_no,
       import_type,
       import_no,
       po_type,
       po_no,
       supplier_no,
       order_date,
       request_date,
       status,
       create_flag,
       import_remark,
       end_date,
       receive_type,
       pay_type_name,
       order_type_name,
       lay_type,
       class_type,
       error_status,
       order_end_date,
       with_code_flag,
       stock_type,
       stock_value,
       quality,
       sample_rate,
       dept_no,
       send_flag,
       rgst_name,
       rgst_date,
       updt_name,
       updt_date,
       enterprise_no,
       org_no,
       take_type,
       rsv_varod1,
       rsv_varod2,
       rsv_varod3,
       rsv_varod4,
       rsv_varod5,
       rsv_varod6,
       rsv_varod7,
       rsv_varod8,
       rsv_num1,
       rsv_num2,
       rsv_num3,
       rsv_date1,
       rsv_date2,
       rsv_date3,
       report_up_serial)
      select iim.warehouse_no,
             iim.owner_no,
             iim.import_type,
             iim.import_no,
             iim.po_type,
             iim.po_no,
             iim.supplier_no,
             iim.order_date,
             iim.request_date,
             iim.status,
             iim.create_flag,
             iim.import_remark,
             iim.end_date,
             iim.receive_type,
             iim.pay_type_name,
             iim.order_type_name,
             iim.lay_type,
             iim.class_type,
             iim.error_status,
             iim.order_end_date,
             iim.with_code_flag,
             iim.stock_type,
             iim.stock_value,
             iim.quality,
             iim.sample_rate,
             iim.dept_no,
             iim.send_flag,
             iim.rgst_name,
             iim.rgst_date,
             iim.updt_name,
             iim.updt_date,
             iim.enterprise_no,
             iim.org_no,
             iim.take_type,
             iim.rsv_varod1,
             iim.rsv_varod2,
             iim.rsv_varod3,
             iim.rsv_varod4,
             iim.rsv_varod5,
             iim.rsv_varod6,
             iim.rsv_varod7,
             iim.rsv_varod8,
             iim.rsv_num1,
             iim.rsv_num2,
             iim.rsv_num3,
             iim.rsv_date1,
             iim.rsv_date2,
             iim.rsv_date3,
             iim.report_up_serial
        from idata_import_m iim
       where iim.enterprise_no = strEnterprise_no
         and iim.warehouse_no = strWAREHOUSE_NO
         and iim.owner_no = strOwner_No
         and iim.status in ('13', '16', '99', '98')
         and trunc(iim.updt_date) = trunc(sysdate - nDays);

    --进货单明细转历史 huangb 20150518
    insert into idata_import_dhty
      (warehouse_no,
       owner_no,
       import_no,
       article_no,
       packing_qty,
       po_qty,
       import_qty,
       po_id,
       unit_cost,
       check_name,
       status,
       check_date,
       out_stock_flag,
       error_status,
       item_type,
       plan_across_qty,
       check_across_qty,
       qc_status,
       qc_flag,
       enterprise_no)
      select iid.warehouse_no,
             iid.owner_no,
             iid.import_no,
             iid.article_no,
             iid.packing_qty,
             iid.po_qty,
             iid.import_qty,
             iid.po_id,
             iid.unit_cost,
             iid.check_name,
             iid.status,
             iid.check_date,
             iid.out_stock_flag,
             iid.error_status,
             iid.item_type,
             iid.plan_across_qty,
             iid.check_across_qty,
             iid.qc_status,
             iid.qc_flag,
             iid.enterprise_no
        from idata_import_d iid, idata_import_m iim
       where iim.enterprise_no = iid.enterprise_no
         and iim.warehouse_no = iid.warehouse_no
         and iim.import_no = iid.import_no
         and iim.enterprise_no = strEnterprise_no
         and iim.warehouse_no = strWAREHOUSE_NO
         and iim.owner_no = strOwner_No
         and iim.status in ('13', '16', '99', '98')
         and trunc(iim.updt_date) = trunc(sysdate - nDays);

    --进货验收头档转历史 huangb 20150518
    insert into idata_check_mhty
      (warehouse_no,
       check_no,
       owner_no,
       s_import_no,
       s_check_no,
       import_type,
       import_no,
       supplier_no,
       dock_no,
       check_worker,
       qc_worker,
       unload_worker,
       status,
       check_start_date,
       check_end_date,
       printer_group_no,
       receiving_no,
       check_tools,
       send_flag,
       print_times,
       down_type,
       rgst_name,
       rgst_date,
       updt_name,
       updt_date,
       enterprise_no,
       memo,
       report_up_serial,class_type)
      select icm.warehouse_no,
             icm.check_no,
             icm.owner_no,
             icm.s_import_no,
             icm.s_check_no,
             icm.import_type,
             icm.import_no,
             icm.supplier_no,
             icm.dock_no,
             icm.check_worker,
             icm.qc_worker,
             icm.unload_worker,
             icm.status,
             icm.check_start_date,
             icm.check_end_date,
             icm.printer_group_no,
             icm.receiving_no,
             icm.check_tools,
             icm.send_flag,
             icm.print_times,
             icm.down_type,
             icm.rgst_name,
             icm.rgst_date,
             icm.updt_name,
             icm.updt_date,
             icm.enterprise_no,
             icm.memo,
             icm.report_up_serial,icm.class_type
        from idata_check_m icm, idata_import_m iim
       where iim.enterprise_no = icm.enterprise_no
         and iim.warehouse_no = icm.warehouse_no
         and iim.import_no = icm.import_no
         and iim.enterprise_no = strEnterprise_no
         and iim.warehouse_no = strWAREHOUSE_NO
         and iim.owner_no = strOwner_No
         and iim.status in ('13', '16', '99', '98')
         and trunc(iim.updt_date) = trunc(sysdate - nDays);

    --进货验收板明细转历史 huangb 20150518
    insert into idata_check_palhty
      (warehouse_no,
       owner_no,
       s_check_no,
       check_no,
       check_row_id,
       article_no,
       packing_qty,
       check_qty,
       status,
       label_no,
       printer_group_no,
       dock_no,
       sub_label_no,
       barcode,
       produce_date,
       expire_date,
       quality,
       lot_no,
       rsv_batch1,
       rsv_batch2,
       rsv_batch3,
       rsv_batch4,
       rsv_batch5,
       rsv_batch6,
       rsv_batch7,
       rsv_batch8,
       stock_type,
       stock_value,
       dept_no,
       fixpal_flag,
       container_no,
       cust_no,
       sub_cust_no,
       business_type,
       rgst_name,
       rgst_date,
       updt_name,
       updt_date,
       price,
       enterprise_no,
       wave_no,
       batch_no,
       device_no,class_type,import_type)
      select icp.warehouse_no,
             icp.owner_no,
             icp.s_check_no,
             icp.check_no,
             icp.check_row_id,
             icp.article_no,
             icp.packing_qty,
             icp.check_qty,
             icp.status,
             icp.label_no,
             icp.printer_group_no,
             icp.dock_no,
             icp.sub_label_no,
             icp.barcode,
             icp.produce_date,
             icp.expire_date,
             icp.quality,
             icp.lot_no,
             icp.rsv_batch1,
             icp.rsv_batch2,
             icp.rsv_batch3,
             icp.rsv_batch4,
             icp.rsv_batch5,
             icp.rsv_batch6,
             icp.rsv_batch7,
             icp.rsv_batch8,
             icp.stock_type,
             icp.stock_value,
             icp.dept_no,
             icp.fixpal_flag,
             icp.container_no,
             icp.cust_no,
             icp.sub_cust_no,
             icp.business_type,
             icp.rgst_name,
             icp.rgst_date,
             icp.updt_name,
             icp.updt_date,
             icp.price,
             icp.enterprise_no,
             icp.wave_no,
             icp.batch_no,
             icp.device_no,icp.class_type,icp.import_type
        from idata_check_pal icp, idata_check_m icm, idata_import_m iim
       where icm.enterprise_no = icp.enterprise_no
         and icm.warehouse_no = icp.warehouse_no
         and icm.check_no = icp.check_no
         and icm.enterprise_no = iim.enterprise_no
         and icm.warehouse_no = iim.warehouse_no
         and icm.import_no = iim.import_no
         and iim.enterprise_no = strEnterprise_no
         and iim.warehouse_no = strWAREHOUSE_NO
         and iim.owner_no = strOwner_No
         and iim.status in ('13', '16', '99', '98')
         and trunc(iim.updt_date) = trunc(sysdate - nDays);

    --进货验收明细转历史 huangb 20150518
    insert into idata_check_dhty
      (warehouse_no,
       owner_no,
       check_no,
       row_id,
       article_no,
       packing_qty,
       qc_no,
       barcode,
       produce_date,
       expire_date,
       quality,
       lot_no,
       rsv_batch1,
       rsv_batch2,
       rsv_batch3,
       rsv_batch4,
       rsv_batch5,
       rsv_batch6,
       rsv_batch7,
       rsv_batch8,
       stock_type,
       stock_value,
       dept_no,
       check_qty,
       check_worker1,
       qc_worker,
       check_start_date,
       check_end_date,
       iqc_status,
       unload_worker,
       authorized_worker,
       out_qty,
       check_worker2,
       price,
       enterprise_no,
       temperature)
      select icd.warehouse_no,
             icd.owner_no,
             icd.check_no,
             icd.row_id,
             icd.article_no,
             icd.packing_qty,
             icd.qc_no,
             icd.barcode,
             icd.produce_date,
             icd.expire_date,
             icd.quality,
             icd.lot_no,
             icd.rsv_batch1,
             icd.rsv_batch2,
             icd.rsv_batch3,
             icd.rsv_batch4,
             icd.rsv_batch5,
             icd.rsv_batch6,
             icd.rsv_batch7,
             icd.rsv_batch8,
             icd.stock_type,
             icd.stock_value,
             icd.dept_no,
             icd.check_qty,
             icd.check_worker1,
             icd.qc_worker,
             icd.check_start_date,
             icd.check_end_date,
             icd.iqc_status,
             icd.unload_worker,
             icd.authorized_worker,
             icd.out_qty,
             icd.check_worker2,
             icd.price,
             icd.enterprise_no,
             icd.temperature
        from idata_check_d icd, idata_check_m icm, idata_import_m iim
       where icm.enterprise_no = icd.enterprise_no
         and icm.warehouse_no = icd.warehouse_no
         and icm.check_no = icd.check_no
         and icm.enterprise_no = iim.enterprise_no
         and icm.warehouse_no = iim.warehouse_no
         and icm.import_no = iim.import_no
         and iim.enterprise_no = strEnterprise_no
         and iim.warehouse_no = strWAREHOUSE_NO
         and iim.owner_no = strOwner_No
         and iim.status in ('13', '16', '99', '98')
         and trunc(iim.updt_date) = trunc(sysdate - nDays);

    --删除正表数据

    delete from idata_check_pal icp
     where icp.enterprise_no = strEnterprise_no
       and icp.warehouse_no = strWAREHOUSE_NO
       and icp.owner_no = strOwner_No
       and icp.check_no in
           (select icm.check_no
              from idata_check_m icm, idata_import_m iim
             where icm.enterprise_no = iim.enterprise_no
               and icm.warehouse_no = iim.warehouse_no
               and icm.import_no = iim.import_no
               and iim.enterprise_no = strEnterprise_no
               and iim.warehouse_no = strWAREHOUSE_NO
               and iim.owner_no = strOwner_No
               and iim.status in ('13', '16', '99', '98')
               and trunc(iim.updt_date) = trunc(sysdate - nDays));

    delete from idata_check_d icd
     where icd.enterprise_no = strEnterprise_no
       and icd.warehouse_no = strWAREHOUSE_NO
       and icd.owner_no = strOwner_No
       and icd.check_no in
           (select icm.check_no
              from idata_check_m icm, idata_import_m iim
             where icm.enterprise_no = iim.enterprise_no
               and icm.warehouse_no = iim.warehouse_no
               and icm.import_no = iim.import_no
               and iim.enterprise_no = strEnterprise_no
               and iim.warehouse_no = strWAREHOUSE_NO
               and iim.owner_no = strOwner_No
               and iim.status in ('13', '16', '99', '98')
               and trunc(iim.updt_date) = trunc(sysdate - nDays));

    delete from idata_check_m icm
     where icm.enterprise_no = strEnterprise_no
       and icm.warehouse_no = strWAREHOUSE_NO
       and icm.owner_no = strOwner_No
       and icm.import_no in
           (select import_no
              from idata_import_m iim
             where iim.enterprise_no = strEnterprise_no
               and iim.warehouse_no = strWAREHOUSE_NO
               and iim.owner_no = strOwner_No
               and iim.status in ('13', '16', '99', '98')
               and trunc(iim.updt_date) = trunc(sysdate - nDays));

    delete from idata_import_d iid
     where iid.enterprise_no = strEnterprise_no
       and iid.warehouse_no = strWAREHOUSE_NO
       and iid.owner_no = strOwner_No
       and iid.import_no in
           (select import_no
              from idata_import_m iim
             where iim.enterprise_no = strEnterprise_no
               and iim.warehouse_no = strWAREHOUSE_NO
               and iim.owner_no = strOwner_No
               and iim.status in ('13', '16', '99', '98')
               and trunc(iim.updt_date) = trunc(sysdate - nDays));

    delete from idata_import_m iim
     where iim.enterprise_no = strEnterprise_no
       and iim.warehouse_no = strWAREHOUSE_NO
       and iim.owner_no = strOwner_No
       and iim.status in ('13', '16', '99', '98')
       and trunc(iim.updt_date) = trunc(sysdate - nDays);

    strResult := 'Y|[成功]';
  end P_Idata_ImportToHty;

  /**********************************************************************************************
   作者:lich
   日期:  2014-05-06
   功能: 上架回单  拆笔新增上架明细
  ************************************************************************************************/
  procedure p_Insert_idata_Instock_D(strWareHouseNo in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                     strOwnerNo     in idata_check_pal_tmp.owner_no%type, --委托业主
                                     strInstockNo   in idata_check_m.s_import_no%type, --进货汇总单号
                                     strInstockId   in idata_instock_d.instock_id%type,
                                     strRealCellNo  in idata_instock_d.real_cell_no%type,
                                     nRealQty       in idata_instock_d.real_qty%type,
                                     strUserId      in idata_instock_m.rgst_name%type, --上架人
                                     strSataus      in idata_instock_d.status%type,
                                     strResult      out varchar2) is

    v_strRowId idata_instock_d.instock_id%type;

  begin
    strResult := 'N|[p_Insert_idata_Instock_D]';

    select nvl(max(instock_id), 0) + 1
      into v_strRowId
      from idata_instock_d
     where warehouse_no = strWareHouseNo
       and owner_no = strOwnerNo
       and instock_no = strInstockNo;

    insert into idata_instock_d
      (warehouse_no,
       owner_no,
       instock_no,
       direct_serial,
       instock_id,
       instock_type,
       cell_no,
       cell_id,
       article_no,
       article_id,
       packing_qty,
       dest_cell_no,
       dest_cell_id,
       article_qty,
       real_cell_no,
       real_qty,
       source_no,
       status,
       authorized_worker,
       sub_label_no,
       label_no,
       business_type,
       rgst_name,
       rgst_date,
       updt_name,
       updt_date,
       stock_type,
       stock_value,
       auto_locate_flag,
       serial_no,
       quality)
      select warehouse_no,
             owner_no,
             instock_no,
             direct_serial,
             v_strRowId,
             instock_type,
             cell_no,
             cell_id,
             article_no,
             article_id,
             packing_qty,
             dest_cell_no,
             dest_cell_id,
             0, --article_qty,
             strRealCellNo,
             nRealQty,
             source_no,
             strSataus,
             authorized_worker,
             sub_label_no,
             label_no,
             business_type,
             strUserId,
             sysdate,
             strUserId,
             sysdate,
             stock_type,
             stock_value,
             auto_locate_flag,
             serial_no,
             iid.quality
        from idata_instock_d iid
       where iid.warehouse_no = strWareHouseNo
         and iid.instock_no = strInstockNo
         and iid.owner_no = strOwnerNo
         and iid.instock_id = strInstockId;

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_Insert_idata_Instock_D;

  /*************************************************************************
  LICH
  2014/05/05
  说明：上架回单
  ****************************************************************************************************/
  procedure P_Update_Idata_Instock(strEnterpriseNo     in idata_instock_m.enterprise_no%type,
                                   strWareHouseNo      in idata_instock_m.warehouse_no%type,
                                   strOwnerNo          in idata_instock_m.owner_no%type,
                                   strInstockNo        in idata_instock_m.instock_no%type,
                                   strInstockId        in idata_instock_d.instock_id%type,
                                   strInstockCellNo    in idata_instock_d.real_cell_no%type,
                                   nRealQty            in idata_instock_d.real_qty%type,
                                   strUserId           in idata_instock_m.rgst_name%type, --上架人
                                   strPaperUserId      in idata_instock_m.rgst_name%type, --回单人
                                   strSataus           in idata_instock_d.status%type,
                                   strUpdateStautsFlag in idata_instock_d.status%type, --0:不拆笔,不差异回单；1：有差异回单不拆笔,2：有差异回单拆笔
                                   strResult           out varchar2) is
    v_iCount   integer;
    v_strRowId idata_instock_d.instock_id%type;
  begin
    strResult := 'N|[P_Update_Idata_Instock]';

    v_iCount := 0;

    for P in (select *
                from idata_instock_d iid
               where iid.enterprise_no = strEnterpriseNo
                 and iid.warehouse_no = strWareHouseNo
                 and iid.owner_no = strOwnerNo
                 and iid.instock_no = strInstockno
                 and iid.instock_id = strInstockId) loop
      v_icount := v_icount + 1;

      if nRealQty > 0 and strUpdateStautsFlag = '2' then
        if P.Article_Qty > nRealQty then
          --------------取instock_id-----------------
          select nvl(max(to_number(instock_id)), 0) + 1
            into v_strRowId
            from idata_instock_d
           where enterprise_no = strEnterpriseNo
             and warehouse_no = strWareHouseNo
             and owner_no = strOwnerNo
             and instock_no = strInstockNo;
          -------------插入上架明细-------------------
          insert into idata_instock_d
            (enterprise_no,
             warehouse_no,
             owner_no,
             instock_no,
             direct_serial,
             instock_id,
             instock_type,
             cell_no,
             cell_id,
             article_no,
             article_id,
             packing_qty,
             dest_cell_no,
             dest_cell_id,
             article_qty,
             real_cell_no,
             real_qty,
             source_no,
             status,
             authorized_worker,
             sub_label_no,
             label_no,
             business_type,
             rgst_name,
             rgst_date,
             stock_type,
             stock_value,
             auto_locate_flag,
             serial_no,
             quality)
            select enterprise_no,
                   warehouse_no,
                   owner_no,
                   instock_no,
                   direct_serial,
                   v_strRowId,
                   instock_type,
                   cell_no,
                   cell_id,
                   article_no,
                   article_id,
                   packing_qty,
                   dest_cell_no,
                   dest_cell_id,
                   article_qty - nRealQty,
                   dest_cell_no,
                   0,
                   source_no,
                   10,
                   authorized_worker,
                   sub_label_no,
                   label_no,
                   business_type,
                   strUserId,
                   sysdate,
                   stock_type,
                   stock_value,
                   auto_locate_flag,
                   serial_no,
                   iid.quality
              from idata_instock_d iid
             where iid.enterprise_no = strEnterpriseNo
               and iid.warehouse_no = strWareHouseNo
               and iid.instock_no = strInstockNo
               and iid.owner_no = strOwnerNo
               and iid.instock_id = strInstockId;
        end if;

        ---------更新上架单头档和明细------------
        update idata_instock_d iid
           set iid.status       = strSataus,
               iid.real_cell_no = strInstockCellNo,
               iid.article_qty  = nRealQty,
               iid.real_qty     = nRealQty,
               iid.updt_name    = strUserId,
               iid.updt_date    = sysdate
         where iid.enterprise_no = strEnterpriseNo
           and iid.warehouse_no = strWareHouseNo
           and iid.owner_no = strOwnerNo
           and iid.instock_no = strInstockno
           and iid.instock_id = strInstockId;

        if sql%rowcount <= 0 then
          strResult := 'N|[E21321]'; --更新上架明细失败
          return;
        end if;
      else
        update idata_instock_d iid
           set iid.status       = strSataus,
               iid.real_cell_no = strInstockCellNo,
               iid.real_qty     = nRealQty,
               iid.updt_name    = strUserId,
               iid.updt_date    = sysdate
         where iid.enterprise_no = strEnterpriseNo
           and iid.warehouse_no = strWareHouseNo
           and iid.owner_no = strOwnerNo
           and iid.instock_no = strInstockno
           and iid.instock_id = strInstockId;

        if sql%rowcount <= 0 then
          strResult := 'N|[E21321]'; --更新上架明细失败
          return;
        end if;
      end if;

    end loop;

    if v_iCount = 0 then
      strResult := 'N|[E21305]'; --没有读取到上架明细
      return;
    end if;

    strResult := 'Y';

  end P_Update_Idata_Instock;

  /***************************************************************************************************
   作者:luozhiling
   日期:  2013-11-11
   功能: 上架回单完成后时将定位指示、上架指示、上架单都转历史,按上架单做转历史处理
  ******************************************************************************************************/
  procedure P_Idate_InstockToHty(strEnterpriseNo in idata_instock_m.enterprise_no%type,
                                 strWareHouseNo  in idata_instock_m.warehouse_no%type, --仓库代码
                                 strLocateNo     in idata_instock_m.locate_no%type, --定位波次号
                                 strInstockNo    in idata_instock_m.instock_no%type, --上架单号
                                 strResult       out varchar2) is

  begin
    strResult := 'N|[P_Idate_InstockToHty]';

    --将此上架单里标签对应的扫描日志数据转历史
    insert into bdef_scan_loghty
      (enterprise_no,
       warehouse_no,
       scan_barcode,
       source_no,
       article_no,
       cell_no,
       label_no,
       qty,
       rgst_name,
       rgst_date,
       check_type,
       operate_date,
       merge_box_no,
       dept_no)
      select enterprise_no,
             warehouse_no,
             t.scan_barcode,
             t.source_no,
             t.article_no,
             t.cell_no,
             t.label_no,
             t.qty,
             t.rgst_name,
             t.rgst_date,
             t.check_type,
             t.operate_date,
             t.merge_box_no,
             t.dept_no
        from bdef_scan_log t
       where t.label_no in (select distinct label_no
                              from idata_instock_d
                             where enterprise_no = strEnterpriseNo
                               and warehouse_no = strWareHouseNo
                               and instock_no = strInstockNo)
         and t.warehouse_no = strWareHouseNo
         and t.enterprise_no = strEnterpriseNo;

    --删除扫描日志表数据
    delete from bdef_scan_log
     where label_no in (select distinct label_no
                          from idata_instock_d
                         where enterprise_no = strEnterpriseNo
                           and warehouse_no = strWareHouseNo
                           and instock_no = strInstockNo)
       AND enterprise_no = strEnterpriseNo
       AND warehouse_no = strWareHouseNo;

    --将上架单对应的定位指示转历史
    insert into idata_locate_directhty
      (enterprise_no,
       warehouse_no,
       row_id,
       owner_no,
       locate_no,
       locate_type,
       auto_locate_flag,
       container_locate_flag,
       source_no,
       cell_no,
       cell_id,
       operate_type,
       article_no,
       article_id,
       packing_qty,
       article_qty,
       dock_no,
       printer_group_no,
       exclude_cell_no,
       status,
       locate_time,
       check_worker,
       stock_type,
       stock_value,
       sub_label_no,
       label_no,
       business_type,
       fixpal_flag,
       rgst_name,
       rgst_date,
       updt_name,
       updt_date,
       specify_cell_no,
       serial_no,
       quality,
       import_type)
      select ild.enterprise_no,
             ild.warehouse_no,
             ild.row_id,
             ild.owner_no,
             ild.locate_no,
             ild.locate_type,
             ild.auto_locate_flag,
             ild.container_locate_flag,
             ild.source_no,
             ild.cell_no,
             ild.cell_id,
             /*ild.container_no,*/
             ild.operate_type,
             ild.article_no,
             ild.article_id,
             ild.packing_qty,
             ild.article_qty,
             ild.dock_no,
             ild.printer_group_no,
             ild.exclude_cell_no,
             ild.status,
             ild.locate_time,
             ild.check_worker,
             ild.stock_type,
             ild.stock_value,
             ild.sub_label_no,
             ild.label_no,
             ild.business_type,
             ild.fixpal_flag,
             ild.rgst_name,
             ild.rgst_date,
             ild.updt_name,
             ild.updt_date,
             ild.specify_cell_no,
             ild.serial_no,
             ild.quality,
             ild.import_type
        from idata_locate_direct ild
       where exists (select 1
                from idata_instock_m iim, idata_instock_d iid
               where ild.enterprise_no = iim.enterprise_no
                 and ild.warehouse_no = iim.warehouse_no
                 and ild.owner_no = iid.owner_no
                 and iim.enterprise_no = iid.enterprise_no
                 and iim.warehouse_no = iid.warehouse_no
                 and iim.instock_no = iid.instock_no
                 and ild.label_no = iid.label_no
                 and ild.sub_label_no = iid.sub_label_no
                    /*and ild.container_no = iid.container_no*/
                 and ild.cell_no = iid.cell_no
                 and ild.source_no = iid.source_no
                 and ild.cell_id = iid.cell_id
                 and iim.instock_no = strInstockNo
                 and iim.status in ('13', '16')
                 and ild.status in ('13', '16'))
         and ild.enterprise_no = strEnterpriseNo
         and ild.warehouse_no = strWareHouseNo;

    --删除上架单对应的定位指示数据
    delete from idata_locate_direct ild
     where ild.enterprise_no = strEnterpriseNo
       and ild.warehouse_no = strWareHouseNo
       and (ild.source_no, ild.label_no, ild.Sub_Label_No, ild.cell_no,
            ild.cell_id) in
           (select iid.source_no,
                   iid.label_no,
                   iid.sub_label_no,
                   iid.cell_no,
                   ild.cell_id
              from idata_instock_m iim, idata_instock_d iid
             where iim.enterprise_no = iid.enterprise_no
               and iim.enterprise_no = strEnterpriseNo
               and iim.warehouse_no = iid.warehouse_no
               and iim.warehouse_no = strWareHouseNo
               and iim.instock_no = strInstockNo
               and iim.locate_no = strLocateNo
               and iim.status in ('13', '16'))
       and ild.status in ('13', '16')
       and ild.locate_no = strLocateNo;

    --将上架单对应的上架指示写历史表
    insert into idata_instock_directhty
      (enterprise_no,
       warehouse_no,
       owner_no,
       locate_type,
       row_id,
       locate_row_id,
       source_no,
       auto_locate_flag,
       operate_type,
       cell_no,
       cell_id,
       /*container_no,*/
       article_no,
       article_id,
       packing_qty,
       dest_cell_no,
       dest_cell_id,
       instock_qty,
       status,
       instock_type,
       check_chute_no,
       container_locate_flag,
       stock_type,
       stock_value,
       sub_label_no,
       label_no,
       business_type,
       rgst_name,
       rgst_date,
       updt_name,
       updt_date,
       locate_no,
       serial_no,
       import_type,
       QUALITY)
      select distinct t.enterprise_no,
                      t.warehouse_no,
                      t.owner_no,
                      t.locate_type,
                      t.row_id,
                      t.locate_row_id,
                      t.source_no,
                      t.auto_locate_flag,
                      t.operate_type,
                      t.cell_no,
                      t.cell_id,
                      /*t.container_no,*/
                      t.article_no,
                      t.article_id,
                      t.packing_qty,
                      t.dest_cell_no,
                      t.dest_cell_id,
                      t.instock_qty,
                      t.status,
                      t.instock_type,
                      t.check_chute_no,
                      t.container_locate_flag,
                      t.stock_type,
                      t.stock_value,
                      t.sub_label_no,
                      t.label_no,
                      t.business_type,
                      t.rgst_name,
                      t.rgst_date,
                      t.updt_name,
                      t.updt_date,
                      t.locate_no,
                      t.serial_no,
                      t.import_type,
                      t.quality
        from idata_instock_direct t
       where exists (select 1
                from idata_instock_d iid
               where t.enterprise_no = iid.enterprise_no
                 and t.warehouse_no = iid.warehouse_no
                 and t.owner_no = iid.owner_no
                 and t.row_id = iid.direct_serial
                 and iid.instock_no = strInstockNo
                 and iid.status in ('13', '16'))
         and t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo;

    --删除上架指示
    delete from idata_instock_direct iid
     where iid.enterprise_no = strEnterpriseNo
       and iid.warehouse_no = strWareHouseNo
       and iid.row_id in (select t.row_id
                            from idata_instock_direct t, idata_instock_d a
                           where t.enterprise_no = a.enterprise_no
                             and t.warehouse_no = a.warehouse_no
                             and t.owner_no = a.owner_no
                             and t.enterprise_no = strEnterpriseNo
                             and t.warehouse_no = strWareHouseNo
                             and t.row_id = a.direct_serial
                             and a.instock_no = strInstockNo
                             and a.status in ('13', '16'))
       and iid.locate_no = strLocateNo;

    --将上架单明细档转历史
    insert into idata_instock_dhty
      (enterprise_no,
       warehouse_no,
       owner_no,
       instock_no,
       direct_serial,
       instock_id,
       instock_type,
       cell_no,
       cell_id,
       /*container_no,*/
       article_no,
       article_id,
       packing_qty,
       dest_cell_no,
       dest_cell_id,
       article_qty,
       real_cell_no,
       real_qty,
       source_no,
       status,
       authorized_worker,
       sub_label_no,
       label_no,
       business_type,
       rgst_name,
       rgst_date,
       updt_name,
       updt_date,
       stock_type,
       stock_value,
       auto_locate_flag,
       serial_no,
       QUALITY)
      select iid.enterprise_no,
             iid.warehouse_no,
             iid.owner_no,
             iid.instock_no,
             iid.direct_serial,
             iid.instock_id,
             iid.instock_type,
             iid.cell_no,
             iid.cell_id,
             /*iid.container_no,*/
             iid.article_no,
             iid.article_id,
             iid.packing_qty,
             iid.dest_cell_no,
             iid.dest_cell_id,
             iid.article_qty,
             iid.real_cell_no,
             iid.real_qty,
             iid.source_no,
             iid.status,
             iid.authorized_worker,
             iid.sub_label_no,
             iid.label_no,
             iid.business_type,
             iid.rgst_name,
             iid.rgst_date,
             iid.updt_name,
             iid.updt_date,
             iid.stock_type,
             iid.stock_value,
             iid.auto_locate_flag,
             iid.serial_no,
             iid.quality
        from idata_instock_d iid, idata_instock_m iim
       where iid.enterprise_no = strEnterpriseNo
         and iid.warehouse_no = strWareHouseNo
         and iid.instock_no = strInstockNo
         and iid.enterprise_no = iim.enterprise_no
         and iid.warehouse_no = iim.warehouse_no
         and iim.instock_no = iid.instock_no
         and iim.locate_no = strLocateNo
         and iim.status = '13';

    --删除上架单明细档
    delete from idata_instock_d iid
     where iid.enterprise_no = strEnterpriseNo
       and iid.warehouse_no = strWareHouseNo
       and iid.instock_no = strInstockNo
       and exists (select 'x'
              from idata_instock_m
             where instock_no = strInstockNo
               and enterprise_no = strEnterpriseNo
               and warehouse_no = strWareHouseNo
               and locate_no = strLocateNo);

    --将上架单头档转历史
    insert into idata_instock_mhty
      (enterprise_no,
       warehouse_no,
       instock_no,
       status,
       dispatch_worker,
       dispatch_date,
       instock_worker,
       instock_date,
       operate_type,
       locate_no,
       locate_type,
       owner_no,
       container_locate_flag,
       rgst_name,
       rgst_date,
       updt_name,
       updt_date,
       --huangb 20160509
       REPORT_UP_SERIAL,
       import_type)
      select iim.enterprise_no,
             iim.warehouse_no,
             iim.instock_no,
             iim.status,
             iim.dispatch_worker,
             iim.dispatch_date,
             iim.instock_worker,
             iim.instock_date,
             iim.operate_type,
             iim.locate_no,
             iim.locate_type,
             iim.owner_no,
             iim.container_locate_flag,
             iim.rgst_name,
             iim.rgst_date,
             iim.updt_name,
             iim.updt_date,
             --huangb 20160509
             REPORT_UP_SERIAL,
             iim.import_type
        from idata_instock_m iim
       where iim.enterprise_no = strEnterpriseNo
         and iim.warehouse_no = strWareHouseNo
         and iim.instock_no = strInstockNo
         and iim.status = '13';

    delete from idata_instock_m iim
     where iim.enterprise_no = strEnterpriseNo
       and iim.warehouse_no = strWareHouseNo
       and iim.instock_no = strInstockNo
       and iim.status = '13';

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_Idate_InstockToHty;

  /***************************************************************************************************
   作者:luozhiling
   日期:  2013-11-11
   功能: 上架回单完成后时将定位指示、上架指示、上架单都转历史,按上架单做转历史处理
  ******************************************************************************************************/
  procedure P_Label_InstockToHty(strWareHouseNo in idata_instock_m.warehouse_no%type, --仓库代码
                                 strLabelNo     in idata_instock_d.label_no%type, --上架单号
                                 strLocateNo    in idata_instock_m.locate_no%type,
                                 strResult      out varchar2) is

  begin
    strResult := 'N|[P_Label_InstockToHty]';

    --将此上架单里标签对应的扫描日志数据转历史
    insert into bdef_scan_loghty
      (warehouse_no,
       scan_barcode,
       source_no,
       article_no,
       cell_no,
       label_no,
       qty,
       rgst_name,
       rgst_date,
       check_type,
       operate_date,
       merge_box_no,
       dept_no)
      select warehouse_no,
             t.scan_barcode,
             t.source_no,
             t.article_no,
             t.cell_no,
             t.label_no,
             t.qty,
             t.rgst_name,
             t.rgst_date,
             t.check_type,
             t.operate_date,
             t.merge_box_no,
             t.dept_no
        from bdef_scan_log t
       where t.label_no in (select distinct label_no
                              from idata_instock_d
                             where warehouse_no = strWareHouseNo
                               and label_no = strLabelNo)
         and warehouse_no = strWareHouseNo;

    --删除扫描日志表数据
    delete from bdef_scan_log
     where label_no in (select distinct label_no
                          from idata_instock_d
                         where warehouse_no = strWareHouseNo
                           and label_no = strLabelNo)
       and warehouse_no = strWareHouseNo;

    --将上架单对应的定位指示转历史
    insert into idata_locate_directhty
      (warehouse_no,
       row_id,
       owner_no,
       locate_no,
       locate_type,
       auto_locate_flag,
       container_locate_flag,
       source_no,
       cell_no,
       cell_id,
       operate_type,
       article_no,
       article_id,
       packing_qty,
       article_qty,
       dock_no,
       printer_group_no,
       exclude_cell_no,
       status,
       locate_time,
       check_worker,
       stock_type,
       stock_value,
       sub_label_no,
       label_no,
       business_type,
       fixpal_flag,
       rgst_name,
       rgst_date,
       updt_name,
       updt_date,
       specify_cell_no,
       serial_no,
       import_type,
       quality)
      select ild.warehouse_no,
             ild.row_id,
             ild.owner_no,
             ild.locate_no,
             ild.locate_type,
             ild.auto_locate_flag,
             ild.container_locate_flag,
             ild.source_no,
             ild.cell_no,
             ild.cell_id,
             ild.operate_type,
             ild.article_no,
             ild.article_id,
             ild.packing_qty,
             ild.article_qty,
             ild.dock_no,
             ild.printer_group_no,
             ild.exclude_cell_no,
             ild.status,
             ild.locate_time,
             ild.check_worker,
             ild.stock_type,
             ild.stock_value,
             ild.sub_label_no,
             ild.label_no,
             ild.business_type,
             ild.fixpal_flag,
             ild.rgst_name,
             ild.rgst_date,
             ild.updt_name,
             ild.updt_date,
             ild.specify_cell_no,
             ild.serial_no,
             ild.import_type,
             ild.quality
        from idata_locate_direct ild,
             idata_instock_m     iim,
             idata_instock_d     iid
       where ild.warehouse_no = iim.warehouse_no
         and ild.owner_no = iid.owner_no
         and iim.warehouse_no = iid.warehouse_no
         and iim.instock_no = iid.instock_no
         and ild.label_no = iid.label_no
         and ild.sub_label_no = iid.sub_label_no
         and ild.cell_no = iid.cell_no
         and ild.source_no = iid.source_no
         and ild.cell_id = iid.cell_id
         and iid.label_no = strLabelNo
         and ild.locate_no = iim.locate_no
         and ild.locate_no = strLocateNo
         and iim.status in ('13', '16')
         and ild.status in ('13', '16');

    --删除上架单对应的定位指示数据
    delete from idata_locate_direct ild
     where ild.warehouse_no = strWareHouseNo
       and (ild.source_no, ild.label_no, ild.Sub_Label_No, ild.cell_no,
            ild.cell_id) in
           (select iid.source_no,
                   iid.label_no,
                   iid.sub_label_no,
                   iid.cell_no,
                   ild.cell_id
              from idata_instock_m iim, idata_instock_d iid
             where iim.warehouse_no = iid.warehouse_no
               and iid.label_no = strLabelNo
               and iim.status in ('13', '16')
               and iim.locate_no = strLocateNo)
       and ild.label_no = strLabelNo
       and ild.locate_no = strLocateNo;

    --将上架单对应的上架指示写历史表
    insert into idata_instock_directhty
      (warehouse_no,
       owner_no,
       locate_type,
       row_id,
       locate_row_id,
       source_no,
       auto_locate_flag,
       operate_type,
       cell_no,
       cell_id,
       article_no,
       article_id,
       packing_qty,
       dest_cell_no,
       dest_cell_id,
       instock_qty,
       status,
       instock_type,
       check_chute_no,
       container_locate_flag,
       stock_type,
       stock_value,
       sub_label_no,
       label_no,
       business_type,
       rgst_name,
       rgst_date,
       updt_name,
       updt_date,
       locate_no,
       serial_no,
       import_type,
       quality)
      select t.warehouse_no,
             t.owner_no,
             t.locate_type,
             t.row_id,
             t.locate_row_id,
             t.source_no,
             t.auto_locate_flag,
             t.operate_type,
             t.cell_no,
             t.cell_id,
             t.article_no,
             t.article_id,
             t.packing_qty,
             t.dest_cell_no,
             t.dest_cell_id,
             t.instock_qty,
             t.status,
             t.instock_type,
             t.check_chute_no,
             t.container_locate_flag,
             t.stock_type,
             t.stock_value,
             t.sub_label_no,
             t.label_no,
             t.business_type,
             t.rgst_name,
             t.rgst_date,
             t.updt_name,
             t.updt_date,
             t.locate_no,
             t.serial_no,
             t.import_type,
             t.quality
        from idata_instock_direct t, idata_instock_d iid
       where t.warehouse_no = iid.warehouse_no
         and t.owner_no = iid.owner_no
         and t.warehouse_no = strWareHouseNo
         and t.row_id = iid.direct_serial
         and t.locate_no = strLocateNo
         and iid.label_no = strLabelNo
         and iid.status in ('13', '16');

    --删除上架指示
    delete from idata_instock_direct iid
     where iid.warehouse_no = strWareHouseNo
       and iid.locate_no = strLocateNo
       and exists (select 'x'
              from idata_instock_direct t, idata_instock_d iid
             where t.warehouse_no = iid.warehouse_no
               and t.owner_no = iid.owner_no
               and t.warehouse_no = strWareHouseNo
               and t.row_id = iid.direct_serial
               and iid.locate_no = strLocateNo
               and iid.label_no = strLabelNo
               and iid.status in ('13', '16'));

    --将上架单明细档转历史
    insert into idata_instock_dhty
      (warehouse_no,
       owner_no,
       instock_no,
       direct_serial,
       instock_id,
       instock_type,
       cell_no,
       cell_id,
       article_no,
       article_id,
       packing_qty,
       dest_cell_no,
       dest_cell_id,
       article_qty,
       real_cell_no,
       real_qty,
       source_no,
       status,
       authorized_worker,
       sub_label_no,
       label_no,
       business_type,
       rgst_name,
       rgst_date,
       updt_name,
       updt_date,
       stock_type,
       stock_value,
       auto_locate_flag,
       serial_no,
       quality)
      select iid.warehouse_no,
             iid.owner_no,
             iid.instock_no,
             iid.direct_serial,
             iid.instock_id,
             iid.instock_type,
             iid.cell_no,
             iid.cell_id,
             iid.article_no,
             iid.article_id,
             iid.packing_qty,
             iid.dest_cell_no,
             iid.dest_cell_id,
             iid.article_qty,
             iid.real_cell_no,
             iid.real_qty,
             iid.source_no,
             iid.status,
             iid.authorized_worker,
             iid.sub_label_no,
             iid.label_no,
             iid.business_type,
             iid.rgst_name,
             iid.rgst_date,
             iid.updt_name,
             iid.updt_date,
             iid.stock_type,
             iid.stock_value,
             iid.auto_locate_flag,
             iid.serial_no,
             iid.quality
        from idata_instock_d iid, idata_instock_m iim
       where iid.warehouse_no = strWareHouseNo
         and iid.label_no = strLabelNo
         and iid.warehouse_no = iim.warehouse_no
         and iim.instock_no = iid.instock_no
         and iim.locate_no = strLocateNo
         and iim.status in ('13', '16');

    --将上架单头档转历史
    insert into idata_instock_mhty
      (warehouse_no,
       instock_no,
       status,
       dispatch_worker,
       dispatch_date,
       instock_worker,
       instock_date,
       operate_type,
       locate_type,
       locate_no,
       owner_no,
       container_locate_flag,
       rgst_name,
       rgst_date,
       updt_name,
       updt_date,
       --huangb 20160509
       REPORT_UP_SERIAL,
       import_type)
      select iim.warehouse_no,
             iim.instock_no,
             iim.status,
             iim.dispatch_worker,
             iim.dispatch_date,
             iim.instock_worker,
             iim.instock_date,
             iim.operate_type,
             iim.locate_type,
             iim.locate_no,
             iim.owner_no,
             iim.container_locate_flag,
             iim.rgst_name,
             iim.rgst_date,
             iim.updt_name,
             iim.updt_date,
             --huangb 20160509
             REPORT_UP_SERIAL,
             iim.import_type
        from idata_instock_m iim
       where iim.warehouse_no = strWareHouseNo
         and iim.instock_no in
             (select instock_no
                from idata_instock_d
               where warehouse_no = strWareHouseNo
                 and label_no = strLabelNo
                 and status in ('13', '16'))
         and iim.status in ('13', '16');

    delete from idata_instock_m iim
     where iim.warehouse_no = strWareHouseNo
       and iim.instock_no in
           (select instock_no
              from idata_instock_d
             where warehouse_no = strWareHouseNo
               and label_no = strLabelNo
               and status in ('13', '16'))
       and iim.status in ('13', '16')
       and iim.locate_no = strLocateNo;

    --删除上架单明细档
    delete from idata_instock_d iid
     where iid.warehouse_no = strWareHouseNo
       and iid.label_no = strLabelNo;
    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_Label_InstockToHty;

  /**********************************************************************************************************
     zhouhuan
     2014.04.29
     功能：写上架单头档
  ***********************************************************************************************************/
  procedure p_InsertInstockM(strEnterpriseNo in idata_instock_direct.enterprise_no%type,
                             strWareHouseNo  in idata_instock_direct.warehouse_no%type, --仓别
                             strWorkerNo     in idata_instock_direct.rgst_name%type, --操作人
                             strLocateNo     in idata_instock_direct.locate_no%type, --定位单号
                             strInstockNo    in idata_instock_d.instock_no%type, --上架单号
                             strResult       out varchar2) is
  begin
    strResult := 'N|[p_InsertInstockM]';

    insert into idata_instock_m
      (enterprise_no,
       warehouse_no,
       instock_no,
       status,
       dispatch_worker,
       dispatch_date,
       operate_type,
       locate_type,
       locate_no,
       owner_no,
       container_locate_flag,
       rgst_name,
       rgst_date,
       import_type)
      select distinct strEnterpriseNo,
                      strWareHouseNo,
                      strInstockNo,
                      '10',
                      strWorkerNo,
                      sysdate,
                      'P',
                      iid.locate_type,
                      strLocateNo,
                      iid.owner_no,
                      iid.container_locate_flag,
                      strWorkerNo,
                      sysdate,
                      iid.import_type
        from idata_instock_direct iid
       where iid.enterprise_no = strEnterpriseNo
         and iid.warehouse_no = strWareHouseNo
         and iid.locate_no = strLocateNo
         and iid.status = '10';

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_InsertInstockM;

  /**********************************************************************************************************
     zhouhuan
     2014.04.29
     功能：写上架单明细档
  ***********************************************************************************************************/
  procedure p_InsertInstockD(strEnterpriseNo in idata_instock_direct.enterprise_no%type,
                             strWareHouseNo  in idata_instock_direct.warehouse_no%type, --仓别
                             strWorkerNo     in idata_instock_direct.rgst_name%type, --操作人
                             strLocateNo     in idata_instock_direct.locate_no%type, --定位单号
                             strInstockNo    in idata_instock_d.instock_no%type, --上架单号
                             strResult       out varchar2) is
  begin
    strResult := 'N|[p_InsertInstockD]';

    insert into IDATA_INSTOCK_D
      (enterprise_no,
       warehouse_no,
       OWNER_NO,
       INSTOCK_NO,
       DIRECT_SERIAL,
       INSTOCK_ID,
       INSTOCK_TYPE,
       CELL_NO,
       CELL_ID,
       ARTICLE_NO,
       ARTICLE_ID,
       PACKING_QTY,
       DEST_CELL_NO,
       DEST_CELL_ID,
       ARTICLE_QTY,
       REAL_CELL_NO,
       REAL_QTY,
       SOURCE_NO,
       STATUS,
       auto_locate_flag,
       AUTHORIZED_WORKER,
       SUB_LABEL_NO,
       LABEL_NO,
       BUSINESS_TYPE,
       STOCK_TYPE,
       STOCK_VALUE,
       RGST_NAME,
       RGST_DATE,
       serial_no,
       quality)
      select strEnterpriseNo,
             strWareHouseNo,
             iid.owner_no,
             strInstockNo,
             iid.row_id,
             rownum,
             iid.instock_type,
             iid.cell_no,
             iid.cell_id,
             iid.article_no,
             iid.article_id,
             iid.packing_qty,
             iid.dest_cell_no,
             iid.dest_cell_id,
             iid.instock_qty,
             iid.dest_cell_no,
             0,
             iid.source_no,
             '10',
             iid.auto_locate_flag,
             strWorkerNo,
             iid.sub_label_no,
             iid.label_no,
             iid.business_type,
             iid.stock_type,
             iid.stock_value,
             strWorkerNo,
             sysdate,
             serial_no,
             iid.quality
        from idata_instock_direct iid
       where iid.enterprise_no = strEnterpriseNo
         and iid.warehouse_no = strWareHouseNo
         and iid.locate_no = strLocateNo
         and iid.status = '10';

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_InsertInstockD;

  /**********************************************************************************************************
     zhouhuan
     2014.04.21
     功能：上架指示转历史
  ***********************************************************************************************************/
  procedure p_InstockDirectToHty(strWareHouseNo in idata_instock_direct.warehouse_no%type, --仓别
                                 strLocateNo    in idata_instock_direct.locate_no%type, --定位单号
                                 strResult      out varchar2) is
  begin
    strResult := 'N|[p_InstockDirectToHty]';

    --将定位单号对应的上架指示转历史
    insert into IDATA_INSTOCK_DIRECTHTY
      (WAREHOUSE_NO,
       OWNER_NO,
       LOCATE_TYPE,
       ROW_ID,
       LOCATE_ROW_ID,
       SOURCE_NO,
       AUTO_LOCATE_FLAG,
       OPERATE_TYPE,
       CELL_NO,
       CELL_ID,
       ARTICLE_NO,
       ARTICLE_ID,
       PACKING_QTY,
       DEST_CELL_NO,
       DEST_CELL_ID,
       INSTOCK_QTY,
       STATUS,
       INSTOCK_TYPE,
       CHECK_CHUTE_NO,
       CONTAINER_LOCATE_FLAG,
       STOCK_TYPE,
       STOCK_VALUE,
       SUB_LABEL_NO,
       LABEL_NO,
       BUSINESS_TYPE,
       RGST_NAME,
       RGST_DATE,
       UPDT_NAME,
       UPDT_DATE,
       LOCATE_NO,
       serial_no,
       import_type,
       quality)
      select strWareHouseNo,
             iid.OWNER_NO,
             iid.LOCATE_TYPE,
             iid.ROW_ID,
             iid.LOCATE_ROW_ID,
             iid.SOURCE_NO,
             iid.AUTO_LOCATE_FLAG,
             iid.OPERATE_TYPE,
             iid.CELL_NO,
             iid.CELL_ID,
             iid.ARTICLE_NO,
             iid.ARTICLE_ID,
             iid.PACKING_QTY,
             iid.DEST_CELL_NO,
             iid.DEST_CELL_ID,
             iid.INSTOCK_QTY,
             iid.STATUS,
             iid.INSTOCK_TYPE,
             iid.CHECK_CHUTE_NO,
             iid.CONTAINER_LOCATE_FLAG,
             iid.STOCK_TYPE,
             iid.STOCK_VALUE,
             iid.SUB_LABEL_NO,
             iid.LABEL_NO,
             iid.BUSINESS_TYPE,
             iid.RGST_NAME,
             iid.RGST_DATE,
             iid.UPDT_NAME,
             iid.UPDT_DATE,
             strLocateNo,
             iid.serial_no,
             iid.import_type,
             iid.quality
        from idata_instock_direct iid
       where iid.warehouse_no = strWareHouseNo
         and iid.locate_no = strLocateNo
         and iid.status in ('13', '16');

    --删除需求单对应的上架指示数据
    delete from idata_instock_direct iid
     where iid.warehouse_no = strWareHouseNo
       and iid.locate_no = strLocateNo
       and iid.status in ('13', '16');

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_InstockDirectToHty;

  /**********************************************************************************************************
     zhouhuan
     2014.04.21
     功能：定位指示转历史
  ***********************************************************************************************************/
  procedure p_LocateDirectToHty(strWareHouseNo in idata_instock_direct.warehouse_no%type, --仓别
                                strLocateNo    in idata_instock_direct.locate_no%type, --定位单号
                                strResult      out varchar2) is
  begin
    strResult := 'N|[p_LocateDirectToHty]';

    --将定位单号对应的定位指示转历史
    insert into IDATA_LOCATE_DIRECTHTY
      (WAREHOUSE_NO,
       ROW_ID,
       OWNER_NO,
       LOCATE_NO,
       LOCATE_TYPE,
       AUTO_LOCATE_FLAG,
       CONTAINER_LOCATE_FLAG,
       SOURCE_NO,
       CELL_NO,
       CELL_ID,
       OPERATE_TYPE,
       ARTICLE_NO,
       ARTICLE_ID,
       PACKING_QTY,
       ARTICLE_QTY,
       DOCK_NO,
       PRINTER_GROUP_NO,
       EXCLUDE_CELL_NO,
       STATUS,
       LOCATE_TIME,
       CHECK_WORKER,
       STOCK_TYPE,
       STOCK_VALUE,
       SUB_LABEL_NO,
       LABEL_NO,
       BUSINESS_TYPE,
       FIXPAL_FLAG,
       RGST_NAME,
       RGST_DATE,
       UPDT_NAME,
       UPDT_DATE,
       SPECIFY_CELL_NO,
       serial_no,
       import_type,
       quality)
      select strWareHouseNo,
             ild.ROW_ID,
             ild.OWNER_NO,
             strLocateNo,
             ild.LOCATE_TYPE,
             ild.AUTO_LOCATE_FLAG,
             ild.CONTAINER_LOCATE_FLAG,
             ild.SOURCE_NO,
             ild.CELL_NO,
             ild.CELL_ID,
             ild.OPERATE_TYPE,
             ild.ARTICLE_NO,
             ild.ARTICLE_ID,
             ild.PACKING_QTY,
             ild.ARTICLE_QTY,
             ild.DOCK_NO,
             ild.PRINTER_GROUP_NO,
             ild.EXCLUDE_CELL_NO,
             ild.STATUS,
             ild.LOCATE_TIME,
             ild.CHECK_WORKER,
             ild.STOCK_TYPE,
             ild.STOCK_VALUE,
             ild.SUB_LABEL_NO,
             ild.LABEL_NO,
             ild.BUSINESS_TYPE,
             ild.FIXPAL_FLAG,
             ild.RGST_NAME,
             ild.RGST_DATE,
             ild.UPDT_NAME,
             ild.UPDT_DATE,
             ild.SPECIFY_CELL_NO,
             ild.serial_no,
             ild.import_type,
             ild.quality
        from idata_locate_direct ild
       where ild.warehouse_no = strWareHouseNo
         and ild.locate_no = strLocateNo
         and ild.status = '13';

    --删除需求单对应的定位指示数据
    delete from idata_locate_direct iid
     where iid.warehouse_no = strWareHouseNo
       and iid.locate_no = strLocateNo
       and iid.status = '13';

    strResult := 'Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_LocateDirectToHty;

  /******************************************************************************************************************
   修改人：luozhiling
   日期:2014-10-24
   功能：天天惠验收确认,天天惠的直通功能：1、一单多验；2：供应商会分多次送货,客户的配量单每天会下传,每天对当天
   的验收单做确认,结束当前的配量,,第二天会重新下传配量,故验收确认单独处理
  *******************************************************************************************************************/
  procedure P_TTHClose_Idata_Check(strWAREHOUSE_NO         in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码)
                                   strS_import_no          in idata_check_m.s_import_no%type, --进货汇总单号
                                   strS_Check_no           in idata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                   strWorkerNo             in idata_check_pal_tmp.rgst_name%type, --操作人
                                   strUnloadWorkerNo       in idata_check_m.unload_worker%type,
                                   strIC_ConfirmBuildSheet in wms_defbase.ndefine%type, --0剩余部分手工重新预约,1不自动预约,原汇总单有效
                                   strDockNo               in pntset_printer_workstation.workstation_no%type, --工作站号
                                   strResult               Out varchar2) is
    v_strImportType idata_import_mm.import_type%type;

  begin
    strResult := 'N|[P_Close_Idata_Check]';

    --获取单据类型
    begin
      select import_type
        into v_strImportType
        from idata_import_mm
       where warehouse_no = strWAREHOUSE_NO
         and s_import_no = strS_import_no;
    exception
      when no_data_found then
        strResult := 'N|[E20903]';
        return;
    end;

    --更新验收单状态
    update idata_check_m icm
       set icm.status        = '13',
           icm.unload_worker = strUnloadWorkerNo,
           icm.updt_name     = strWorkerNo,
           icm.updt_date     = sysdate
     where icm.warehouse_no = strWAREHOUSE_NO
       and icm.s_import_no = strS_import_no
       and icm.s_check_no = strS_Check_no
       and icm.status in ('10', '12');

    if sql%notfound then
      strResult := 'N|[E20938]';
      return;
    end if;

    if v_strImportType = 'ID' then
      --如果是直通单据,更新配量表的数据
      updatE idata_import_allot t
         set status = '13'
       where import_no in (select import_no
                             from idata_check_m
                            where warehouse_no = strWAREHOUSE_NO
                              and s_import_no = strS_import_no
                              and s_check_no = strS_Check_no)
         and warehouse_no = strWAREHOUSE_NO;
    end if;

    if strIC_ConfirmBuildSheet = '0' then
      --更新进货汇总明细状态
      update idata_import_sd
         set status = '13'
       where s_import_no = strS_import_no
         and warehouse_no = strWAREHOUSE_NO
         and status not in ('13', '16');

      update idata_import_sm
         set status = '13', updt_name = strWorkerNo, updt_date = sysdate
       where warehouse_no = strWAREHOUSE_NO
         and s_import_no = strS_import_no
         and status not in ('13', '16');

      --更新进货汇总头档状态
      update idata_import_mm iim
         set status = '13', updt_name = strWorkerNo, updt_date = sysdate
       where warehouse_no = strWAREHOUSE_NO
         and s_import_no = strS_import_no
         and status not in ('13', '16');

    else
      --已全部验收完成的单据也要更新进货汇总单的状态
      update idata_import_sd
         set status = '13'
       where s_import_no = strS_import_no
         and warehouse_no = strWAREHOUSE_NO
         and not exists (select 'x'
                from idata_import_sd
               where s_import_no = strS_import_no
                 and warehouse_no = strWAREHOUSE_NO
                 and po_qty - import_qty > 0);

      update idata_import_sm
         set status = '13', updt_name = strWorkerNo, updt_date = sysdate
       where warehouse_no = strWAREHOUSE_NO
         and s_import_no = strS_import_no
         and status not in ('13', '16')
         and not exists (select 'x'
                from idata_import_sd
               where s_import_no = strS_import_no
                 and warehouse_no = strWAREHOUSE_NO
                 and status not in ('13', '16'));

      --更新进货汇总头档状态
      update idata_import_mm iim
         set status = '13', updt_name = strWorkerNo, updt_date = sysdate
       where warehouse_no = strWAREHOUSE_NO
         and s_import_no = strS_import_no
         and status not in ('13', '16')
         and not exists (select 'x'
                from idata_import_sm
               where s_import_no = strS_import_no
                 and warehouse_no = strWAREHOUSE_NO
                 and status not in ('13', '16'));
    end if;

    --更新箱码表数据
    update stock_box_m t
       set t.status = '2'
     where t.status = '1'
       and warehouse_no = strWAREHOUSE_NO
       and s_import_no = strS_import_no;

    strResult := 'Y|';

  end P_TTHClose_Idata_Check;
  /******************************************************************************************************
  创建人：luozhiling
  创建日期：2014.10.25
  功能说明：验收取消时,更新板明细数据
  ******************************************************************************************************/
  procedure P_Cancel_check_pal(strWarehouseNo in idata_check_pal.warehouse_no%type,
                               strOwnerNo     in idata_check_pal.owner_no%type,
                               strCheckNo     in idata_check_pal.check_no%type,
                               strsCheckNo    in idata_check_pal.s_check_no%type,
                               strLabelNo     in idata_check_pal.label_no%type,
                               strSubLabelNo  in idata_check_pal.sub_label_no%type,
                               nCheckRowId    in idata_check_pal.check_row_id%type,
                               strContainerNo in idata_check_pal.container_no%type,
                               strArticleNo   in idata_check_pal.article_no%type,
                               strCustNo      in idata_check_pal.cust_no%type,
                               nPackingQty    in idata_check_pal.packing_qty%type,
                               nQty           in idata_check_pal.check_qty%type,
                               strWorkerNo    in idata_check_pal.updt_name%type,
                               strResult      out varchar2) is
  begin
    strResult := 'N|[P_Cancel_check_pal]';
    update idata_check_pal
       set check_qty = check_qty + nQty,
           updt_name = strWorkerNo,
           updt_date = sysdate
     where warehouse_no = strWarehouseNo
       and owner_no = strOwnerNo
       and s_check_no = strsCheckNo
       and check_no = strCheckNo
       and check_row_id = nCheckRowId
       and article_no = strArticleNo
       and packing_qty = nPackingQty
       and label_no = strLabelNo
       and container_no = strContainerNo --and sub_label_no=strSubLabelNo
       and cust_no = strCustNo
       and status = '16';
    if sql%notfound then

      insert into idata_check_pal
        (warehouse_no,
         owner_no,
         s_check_no,
         check_no,
         check_row_id,
         article_no,
         packing_qty,
         check_qty,
         status,
         label_no,
         printer_group_no,
         dock_no,
         sub_label_no,
         barcode,
         produce_date,
         expire_date,
         quality,
         lot_no,
         rsv_batch1,
         rsv_batch2,
         rsv_batch3,
         rsv_batch4,
         rsv_batch5,
         rsv_batch6,
         rsv_batch7,
         rsv_batch8,
         stock_type,
         stock_value,
         dept_no,
         fixpal_flag,
         container_no,
         cust_no,
         sub_cust_no,
         business_type,
         rgst_name,
         rgst_date,
         updt_name,
         updt_date,
         price,class_type,import_type)
        select strWarehouseNo,
               strOwnerNo,
               strsCheckNo,
               strCheckNo,
               nCheckRowId,
               strArticleNo,
               nPackingQTY,
               nQty,
               '16',
               strLabelNo,
               t.printer_group_no,
               t.dock_no,
               t.sub_label_no,
               t.barcode,
               t.produce_date,
               t.expire_date,
               t.quality,
               t.lot_no,
               t.rsv_batch1,
               t.rsv_batch2,
               t.rsv_batch3,
               t.rsv_batch4,
               t.rsv_batch5,
               t.rsv_batch6,
               t.rsv_batch7,
               t.rsv_batch8,
               t.stock_type,
               t.stock_value,
               t.dept_no,
               t.fixpal_flag,
               t.container_no,
               t.cust_no,
               t.sub_cust_no,
               t.business_type,
               t.rgst_name,
               t.rgst_date,
               strWorkerNo,
               sysdate,
               t.price,t.class_type,t.import_type
          from idata_check_pal t
         where t.warehouse_no = strWarehouseNo
           and t.owner_no = strOwnerNo
           and t.s_check_no = strsCheckNo
           and t.check_no = strCheckNo
           and t.check_row_id = nCheckRowId
           and t.article_no = strArticleNo
           and t.packing_qty = nPackingQty
           and t.label_no = strLabelNo
           and t.container_no = strContainerNo --and t.sub_label_no=strSubLabelNo
           and t.cust_no = strCustNo
           and rownum = 1;
    end if;

    update idata_check_pal
       set check_qty = check_qty - nQty,
           updt_name = strWorkerNo,
           updt_date = sysdate
     where warehouse_no = strWarehouseNo
       and owner_no = strOwnerNo
       and s_check_no = strsCheckNo
       and check_no = strCheckNo
       and check_row_id = nCheckRowId
       and article_no = strArticleNo
       and packing_qty = nPackingQty
       and label_no = strLabelNo
       and container_no = strContainerNo
       and sub_label_no = strSubLabelNo
       and cust_no = strCustNo
       and status < '16';

    delete idata_check_pal
     where warehouse_no = strWarehouseNo
       and owner_no = strOwnerNo
       and s_check_no = strsCheckNo
       and check_no = strCheckNo
       and check_row_id = nCheckRowId
       and article_no = strArticleNo
       and packing_qty = nPackingQty
       and label_no = strLabelNo
       and container_no = strContainerNo
       and sub_label_no = strSubLabelNo
       and check_qty = 0;

    strResult := 'Y|[成功]';

  end P_Cancel_check_pal;

  /******************************************************************************************************
  创建人：luozhiling
  创建日期：2014.10.25
  功能说明：标签销毁时,若验收单未做验收确认,还原商品至未验收状态
  ******************************************************************************************************/
  procedure P_Label_Cancel_IScheck(strWarehouseNo in idata_check_pal.warehouse_no%type,
                                   strOwnerNo     in idata_check_pal.owner_no%type,
                                   strsCheckNo    in idata_check_pal.s_check_no%type,
                                   strLabelNo     in idata_check_pal.label_no%type,
                                   strCustNo      in stock_label_d.cust_no%type,
                                   strExpNo       in stock_label_d.exp_no%type,
                                   strArticleNo   in stock_label_d.article_no%type,
                                   nArticleId     in stock_label_d.article_id%type,
                                   nPackingQTY    IN idata_check_pal.check_qty%type,
                                   nQty           in idata_check_pal.check_qty%type,
                                   strWorkerNo    in idata_check_pal.updt_name%type,
                                   strResult      out varchar2) is
    nCurrQty   idata_check_pal.check_qty%type;
    nRemainQty idata_check_pal.check_qty%type;
  begin

    strResult  := 'N|[P_Label_Cancel_check]';
    nRemainQty := nQty;

    for GetCheckD in (select icm.s_import_no,
                             icm.import_no,
                             icp.*
                        from idata_check_m      icm,
                             idata_check_d      icd,
                             idata_check_pal    icp,
                             stock_article_info sai
                       where icm.warehouse_no = icd.warehouse_no
                         and icm.check_no = icd.check_no
                         and icm.warehouse_no = icp.warehouse_no
                         and icm.check_no = icp.check_no
                         and icm.s_check_no = icp.s_check_no
                         and icd.row_id = icp.check_row_id
                         and icd.article_no = icp.article_no
                         and icd.article_no = sai.article_no
                         and icd.check_no = sai.import_batch_no
                         and icd.barcode = sai.barcode
                         and icd.quality = sai.quality
                         and icd.produce_date = sai.produce_date
                         and icd.expire_date = sai.expire_date
                         and icd.rsv_batch1 = sai.rsv_batch1
                         and icd.rsv_batch2 = sai.rsv_batch2
                         and icd.rsv_batch3 = sai.rsv_batch3
                         and icd.rsv_batch4 = sai.rsv_batch4
                         and icd.rsv_batch5 = sai.rsv_batch5
                         and icd.rsv_batch6 = sai.rsv_batch6
                         and icd.rsv_batch7 = sai.rsv_batch7
                         and icd.rsv_batch8 = sai.rsv_batch8
                         and icd.lot_no = icp.lot_no
                         and icd.packing_qty = icp.packing_qty
                         and icd.lot_no = sai.lot_no
                         and icd.packing_qty = nPackingQTY
                         and sai.article_id = nArticleId
                         and icp.article_no = strArticleNo
                         and icm.s_check_no = strsCheckNo
                         and icp.label_no = strLabelNo
                         and icm.status < '13'
                         and icp.status <> '16'
                       order by icm.check_no) loop

      if nRemainQty >= GetCheckD.check_qty then
        nCurrQty   := GetCheckD.check_qty;
        nRemainQty := nRemainQty - nCurrQty;
      else
        nCurrQty   := nQty;
        nRemainQty := 0;
      end if;

      pkobj_idata.P_Cancel_check_pal(strWarehouseNo,
                                     strOwnerNo,
                                     GetCheckD.check_no,
                                     strsCheckNo,
                                     strLabelNo,
                                     GetCheckD.sub_label_no,
                                     GetCheckD.check_row_id,
                                     GetCheckD.container_no,
                                     GetCheckD.article_no,
                                     GetCheckD.cust_no,
                                     GetCheckD.packing_qty,
                                     nCurrQty,
                                     strWorkerNo,
                                     strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --扣减验收单数量
      update idata_check_d t
         set t.check_qty = t.check_qty - nCurrQty
       where warehouse_no = strWarehouseNo
         and owner_no = strOwnerNo
         and check_no = GetCheckD.check_no
         and row_id = GetCheckD.check_row_id
         and t.check_qty >= nCurrQty;

      --扣减进货汇总单数量
      update idata_import_sd t
         set t.import_qty = t.import_qty - nCurrQty
       where warehouse_no = strWarehouseNo
         and owner_no = strOwnerNo
         and s_import_no = GetCheckD.s_import_no
         and article_no = GetCheckD.article_no
         and packing_qty = GetCheckD.packing_qty
         and t.import_qty - nCurrQty >= 0
         and rownum = 1;

      --扣减进货单数量
      update idata_import_d t
         set t.import_qty = t.import_qty - nCurrQty
       where warehouse_no = strWarehouseNo
         and owner_no = strOwnerNo
         and import_no = GetCheckD.import_no
         and article_no = GetCheckD.article_no
         and packing_qty = GetCheckD.packing_qty
         and t.import_qty - nCurrQty >= 0
         and rownum = 1;

      if nRemainQty = 0 then
        exit;
      end if;

    end loop;

    strResult := 'Y|[成功]';

  end P_Label_Cancel_IScheck;
  /******************************************************************************************************
  创建人：luozhiling
  创建日期：2014.10.25
  功能说明：直通商品标签销毁时,若验收单未做验收确认,还原商品至未验收状态
  ******************************************************************************************************/
  procedure P_Label_Cancel_IDcheck(strEnterPriseNo in idata_check_m.enterprise_no%type,
                                   strWarehouseNo  in idata_check_pal.warehouse_no%type,
                                   strOwnerNo      in idata_check_pal.owner_no%type,
                                   strsCheckNo     in idata_check_pal.s_check_no%type,
                                   strLabelNo      in idata_check_pal.label_no%type,
                                   strCustNo       in stock_label_d.cust_no%type,
                                   strArticleNo    in stock_label_d.article_no%type,
                                   nArticleId      in stock_label_d.article_id%type,
                                   nPackingQTY     IN idata_check_pal.check_qty%type,
                                   nQty            in idata_check_pal.check_qty%type,
                                   strWorkerNo     in idata_check_pal.updt_name%type,
                                   strResult       out varchar2) is
    nCurrQty        idata_check_pal.check_qty%type;
    nRemainQty      idata_check_pal.check_qty%type;
    nDividCurrQty   idata_check_pal.check_qty%type;
    nDividRemainQty idata_check_pal.check_qty%type;
  begin
    strResult  := 'N|[P_Label_Cancel_IDcheck]';
    nRemainQty := nQty;

    for GetCheckD in (select icm.import_type,
                             icm.s_import_no,
                             icm.import_no,
                             icd.*
                        from idata_check_m      icm,
                             idata_check_d      icd,
                             stock_article_info sai
                       where icm.enterprise_no = icd.enterprise_no
                         and icm.warehouse_no = icd.warehouse_no
                         and icm.check_no = icd.check_no
                         and icm.enterprise_no = strEnterPriseNo
                         and icm.warehouse_no = strWarehouseNo
                         and icd.article_no = sai.article_no
                         and icd.check_no = sai.import_batch_no
                         and icd.barcode = sai.barcode
                         and icd.quality = sai.quality
                         and icd.produce_date = sai.produce_date
                         and icd.expire_date = sai.expire_date
                         and icd.rsv_batch1 = sai.rsv_batch1
                         and icd.rsv_batch2 = sai.rsv_batch2
                         and icd.rsv_batch3 = sai.rsv_batch3
                         and icd.rsv_batch4 = sai.rsv_batch4
                         and icd.rsv_batch5 = sai.rsv_batch5
                         and icd.rsv_batch6 = sai.rsv_batch6
                         and icd.rsv_batch7 = sai.rsv_batch7
                         and icd.rsv_batch8 = sai.rsv_batch8
                         and icd.lot_no = sai.lot_no
                         and icd.packing_qty = nPackingQTY
                         and sai.article_id = nArticleId
                         and icd.article_no = strArticleNo
                         and icm.s_check_no = strsCheckNo
                         and icm.status < '13'
                       order by icm.check_no) loop

      nCurrQty := GetCheckD.check_qty;
      if nCurrQty > nRemainQty then
        nCurrQty := nRemainQty;
      end if;
      nRemainQty := nRemainQty - nCurrQty;

      nDividRemainQty := nCurrQty;

      for GetCheckPal in (select icm.s_import_no,
                                 icm.import_no,
                                 icp.*
                            from idata_check_m      icm,
                                 idata_check_d      icd,
                                 idata_check_pal    icp,
                                 stock_article_info sai
                           where icm.enterprise_no = icd.enterprise_no
                             and icm.enterprise_no = icp.enterprise_no
                             and icm.warehouse_no = icd.warehouse_no
                             and icm.check_no = icd.check_no
                             and icm.enterprise_no = strEnterPriseNo
                             and icm.warehouse_no = strWarehouseNo
                             and icm.warehouse_no = icp.warehouse_no
                             and icm.check_no = icp.check_no
                             and icm.s_check_no = icp.s_check_no
                             and icd.row_id = icp.check_row_id
                             and icd.article_no = icp.article_no
                             and icd.article_no = sai.article_no
                             and icd.check_no = sai.import_batch_no
                             and icd.barcode = sai.barcode
                             and icd.quality = sai.quality
                             and icd.produce_date = sai.produce_date
                             and icd.expire_date = sai.expire_date
                             and icd.rsv_batch1 = sai.rsv_batch1
                             and icd.rsv_batch2 = sai.rsv_batch2
                             and icd.rsv_batch3 = sai.rsv_batch3
                             and icd.rsv_batch4 = sai.rsv_batch4
                             and icd.rsv_batch5 = sai.rsv_batch5
                             and icd.rsv_batch6 = sai.rsv_batch6
                             and icd.rsv_batch7 = sai.rsv_batch7
                             and icd.rsv_batch8 = sai.rsv_batch8
                             and icd.lot_no = icp.lot_no
                             and icd.packing_qty = icp.packing_qty
                             and icd.lot_no = sai.lot_no
                             and icd.packing_qty = nPackingQTY
                             and sai.article_id = nArticleId
                             and icp.article_no = strArticleNo
                             and icm.s_check_no = strsCheckNo
                             and icp.cust_no = strCustNo
                             and (icp.cust_no = 'N' or
                                 (icp.cust_no <> 'N' and
                                 icp.label_no = strLabelNo))
                             and icm.status < '13'
                             and icp.status <> '16'
                           order by icm.check_no) loop

        nDividCurrQty := GetCheckPal.check_qty;
        if nDividCurrQty > nDividRemainQty then
          nDividCurrQty := nDividRemainQty;
        end if;
        nDividRemainQty := nDividRemainQty - nDividCurrQty;

        pkobj_idata.P_Cancel_check_pal(strWarehouseNo,
                                       strOwnerNo,
                                       GetCheckPal.check_no,
                                       strsCheckNo,
                                       strLabelNo,
                                       GetCheckPal.sub_label_no,
                                       GetCheckPal.check_row_id,
                                       GetCheckPal.container_no,
                                       GetCheckPal.article_no,
                                       GetCheckPal.cust_no,
                                       GetCheckPal.packing_qty,
                                       nDividCurrQty,
                                       strWorkerNo,
                                       strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        if nDividRemainQty = 0 then
          exit;
        end if;
      end loop;

      --扣减验收单数量
      update idata_check_d t
         set t.check_qty = t.check_qty - nCurrQty
       where warehouse_no = strWarehouseNo
         and owner_no = strOwnerNo
         and check_no = GetCheckD.check_no
         and row_id = GetCheckD.row_id
         and t.check_qty >= nCurrQty;

      --扣减进货汇总单数量
      update idata_import_sd t
         set t.import_qty = t.import_qty - nCurrQty
       where warehouse_no = strWarehouseNo
         and owner_no = strOwnerNo
         and s_import_no = GetCheckD.s_import_no
         and article_no = GetCheckD.article_no
         and packing_qty = GetCheckD.packing_qty
         and t.import_qty - nCurrQty >= 0
         and rownum = 1;

      --扣减进货单数量
      update idata_import_d t
         set t.import_qty = t.import_qty - nCurrQty
       where warehouse_no = strWarehouseNo
         and owner_no = strOwnerNo
         and import_no = GetCheckD.import_no
         and article_no = GetCheckD.article_no
         and packing_qty = GetCheckD.packing_qty
         and t.import_qty - nCurrQty >= 0
         and rownum = 1;

      --扣减进货门店配量表
      update idata_import_allot t
         set t.allot_qty = t.allot_qty - nCurrQty
       where warehouse_no = strWarehouseNo
         and owner_no = strOwnerNo
         and import_no = GetCheckD.import_no
         and article_no = GetCheckD.article_no
         and packing_qty = GetCheckD.packing_qty
         and t.allot_qty - nCurrQty >= 0
         and t.cust_no = strCustNo
         and t.status < '13';

      if nRemainQty = 0 then
        exit;
      end if;

    end loop;
    strResult := 'Y|[成功]';
  end P_Label_Cancel_IDcheck;

  /*************************************************************************************************
   创建人：hekl
   创建时间：2015.4.14
   功能说明：对采购单进行关单
  **************************************************************************************************/
  procedure P_import_close(strEnterpriseNo in stock_label_m.enterprise_no%type,
                           strWareHouseNo  in idata_import_m.warehouse_no%type,
                           strOwnerNo      in idata_import_m.owner_no%type,
                           strImportNo     in idata_import_m.import_no%type,
                           strUserID       in idata_import_m.updt_name%type,
                           strResult       out varchar2) is
    v_strsImportNo idata_import_m.import_no%type;
    importQty      idata_import_sd.import_qty%type;
    checkQty       idata_check_pal_tmp.check_qty%type;
  begin
    strResult := 'N|[P_import_close]';

    --判断此单据是否有对应的汇总单(是否预约)
    begin
      select distinct s_import_no
        into v_strsImportNo
        from idata_import_sm iis
       where iis.warehouse_no = strWareHouseNo
         and iis.owner_no = strOwnerNo
         and iis.import_no = strImportNo
         and iis.enterprise_no = strEnterpriseNo
         and iis.status <> 13;

    exception
      when no_data_found then
        v_strsImportNo := 'N';
    end;
    if v_strsImportNo <> 'N' then
      --查询此单据是否已验收
      select sum(sd.import_qty)
        into importQty
        from IDATA_IMPORT_SD sd
       where sd.warehouse_no = strWareHouseNo
         and sd.owner_no = strOwnerNo
         and sd.enterprise_no = strEnterpriseNo
         and sd.s_import_no = v_strsImportNo;

      if importQty = 0 then
        --判断此单据是否验收未确认
        select sum(tmp.check_qty)
          into checkQty
          from IDATA_CHECK_PAL_TMP tmp
         where tmp.warehouse_no = strWareHouseNo
           and tmp.owner_no = strOwnerNo
           and tmp.enterprise_no = strEnterpriseNo
           and tmp.s_import_no = v_strsImportNo;

        if checkQty = 0 or checkQty IS NULL then
          --修改进货汇总单状态
          update Idata_Import_Mm t
             set t.status = '13'
           where t.warehouse_no = strWarehouseNo
             and t.s_import_no = v_strsImportNo
             and t.enterprise_no = strEnterpriseNo;

          update Idata_Import_sm t
             set t.status = '13'
           where t.warehouse_no = strWarehouseNo
             and t.s_import_no = v_strsImportNo
             and t.enterprise_no = strEnterpriseNo;

          update Idata_Import_sd t
             set t.status = '13'
           where t.warehouse_no = strWarehouseNo
             and t.owner_no = strOwnerNo
             and t.s_import_no = v_strsImportNo
             and t.enterprise_no = strEnterpriseNo;

          --将该单的进货汇总单转历史
          P_Idata_sImportToHty(strEnterpriseNo,
                               strWareHouseNo,
                               strOwnerNo,
                               v_strsImportNo,
                               strResult);

          --修改该单汇总单状态
          update Idata_Order_Status t
             set t.status    = '13',
                 t.updt_name = strUserID,
                 t.updt_date = sysdate
           where t.warehouse_no = strWarehouseNo
             and t.owner_no = strOwnerNO
             and t.s_import_no = v_strsImportNo
             and t.status = '10'
             and t.enterprise_no = strEnterpriseNo;

          update Idata_Order_Sheet t
             set t.cancel_status = '13'
           where t.warehouse_no = strWarehouseNo
             and t.import_no = strImportNo
             and t.cancel_status = 'N'
             and t.enterprise_no = strEnterpriseNo;

        else
          strResult := 'N|[E31020]';
          return;
        end if;

      else
        strResult := 'N|[E31019]';
        return;
      end if;

    end if;

    --修改手建单状态
    update idata_import_m t
       set t.status = '13', t.updt_name = strUserID, t.updt_date = sysdate
     where t.warehouse_no = strWarehouseNo
       and t.owner_no = strOwnerNO
       and t.import_no = strImportNo
       and t.status in ('10', '11')
       and t.enterprise_no = strEnterpriseNo;

    update idata_import_d t
       set t.status = '13'
     where t.warehouse_no = strWarehouseNo
       and t.owner_no = strOwnerNO
       and t.import_no = strImportNo
       and t.status in ('10', '11')
       and t.enterprise_no = strEnterpriseNo;

    strResult := 'Y|[成功]';
  end P_import_close;

  /*************************************************************************************************
   创建人：hekl
   创建时间：2015.4.14
   功能说明：对采购单进行取消
   修改人：huangcx  2016.5.23 添加返回结果strResult:='Y|[成功]';
  **************************************************************************************************/
  procedure P_import_cancel(strEnterpriseNo in stock_label_m.enterprise_no%type,
                            strWareHouseNo  in idata_import_m.warehouse_no%type,
                            strOwnerNo      in idata_import_m.owner_no%type,
                            strImportNo     in idata_import_m.import_no%type,
                            strUserID       in idata_import_m.updt_name%type,
                            strResult       out varchar2) is
    v_strsImportNo idata_import_m.import_no%type;
    importQty      idata_import_sd.import_qty%type;
    checkQty       idata_check_pal_tmp.check_qty%type;
  begin
    strResult := 'N|[P_import_cancel]';
    --判断此单据是否有对应的汇总单
    begin
      select distinct s_import_no
        into v_strsImportNo
        from idata_import_sm iis
       where iis.warehouse_no = strWareHouseNo
         and iis.owner_no = strOwnerNo
         and iis.import_no = strImportNo
         and iis.enterprise_no = strEnterpriseNo;

    exception
      when no_data_found then
        v_strsImportNo := 'N';
    end;

    if v_strsImportNo <> 'N' then
      --查询此单据是否已验收
      select sum(sd.import_qty)
        into importQty
        from IDATA_IMPORT_SD sd
       where sd.warehouse_no = strWareHouseNo
         and sd.owner_no = strOwnerNo
         and sd.enterprise_no = strEnterpriseNo
         and sd.s_import_no = v_strsImportNo;

      if importQty = 0 then
        --判断此单据是否验收未确认
        select sum(tmp.check_qty)
          into checkQty
          from IDATA_CHECK_PAL_TMP tmp
         where tmp.warehouse_no = strWareHouseNo
           and tmp.owner_no = strOwnerNo
           and tmp.enterprise_no = strEnterpriseNo
           and tmp.s_import_no = v_strsImportNo;

        if checkQty = 0 or checkQty IS NULL then

          --修改进货汇总单状态
          update Idata_Import_Mm t
             set t.status = '16'
           where t.warehouse_no = strWarehouseNo
             and t.s_import_no = v_strsImportNo
             and t.enterprise_no = strEnterpriseNo;

          update Idata_Import_sm t
             set t.status = '16'
           where t.warehouse_no = strWarehouseNo
             and t.s_import_no = v_strsImportNo
             and t.enterprise_no = strEnterpriseNo;

          update Idata_Import_sd t
             set t.status = '16'
           where t.warehouse_no = strWarehouseNo
             and t.owner_no = strOwnerNo
             and t.s_import_no = v_strsImportNo
             and t.enterprise_no = strEnterpriseNo;

          --将该单的进货汇总单转历史
          P_Idata_sImportToHty(strEnterpriseNo,
                               strWareHouseNo,
                               strOwnerNo,
                               v_strsImportNo,
                               strResult);

          --修改该单汇总单状态
          update Idata_Order_Status t
             set t.status    = '16',
                 t.updt_name = strUserID,
                 t.updt_date = sysdate
           where t.warehouse_no = strWarehouseNo
             and t.owner_no = strOwnerNO
             and t.s_import_no = v_strsImportNo
             and t.status = '10'
             and t.enterprise_no = strEnterpriseNo;

          update Idata_Order_Sheet t
             set t.cancel_status = '16'
           where t.warehouse_no = strWarehouseNo
             and t.import_no = strImportNo
             and t.cancel_status = 'N'
             and t.enterprise_no = strEnterpriseNo;

        else
          strResult := 'N|[E31020]';
          return;
        end if;

      else
        strResult := 'N|[E31019]';
        return;
      end if;

    end if;

    --修改手建单状态
    update idata_import_m t
       set t.status = '16', t.updt_name = strUserID, t.updt_date = sysdate
     where t.warehouse_no = strWarehouseNo
       and t.owner_no = strOwnerNO
       and t.import_no = strImportNo
       and t.status in ('10', '11')
       and t.enterprise_no = strEnterpriseNo;

    update idata_import_d t
       set t.status = '16'
     where t.warehouse_no = strWarehouseNo
       and t.owner_no = strOwnerNO
       and t.import_no = strImportNo
       and t.status in ('10', '11')
       and t.enterprise_no = strEnterpriseNo;

    strResult := 'Y|[成功]';
  end P_import_cancel;

  /*=====================================================================================
   insert to 20151212
  进货直通分配格子号试算
  ======================================================================================*/
  PROCEDURE p_scan_CustAllot_LABEL_RG(strEnterPriseNo in idata_import_sm.enterprise_no%type,
                                      strwarehouse_no in idata_import_sm.warehouse_no%type, --仓别
                                      strowner_no     in idata_import_sm.owner_no%type,
                                      strSImportNo    in idata_import_sm.s_import_no%type, --进货汇总单号
                                      strClassType    in wms_warehouse_outorder.exp_type%type,
                                      strDEVICE_NO    in device_divide_m.device_no%type,
                                      strDELIVER_OBJ  in wms_outlocate_strategy_d.deliver_obj_level%type, --配送对象
                                      strUser_Id      in idata_import_sm.rgst_name%type, --操作人员
                                      strDockNo       in idata_check_m.dock_no%type, ---打印码头
                                      n_stockNum      in device_divide_m.cust_qty%type,
                                      strOutMsg       out varchar2) is

    n_count            number(10); --循环行数
    nAddBatchFlag      integer; --是否新增批次 0: 不新增；1：新增
    n_batch_no         cset_cell_supplier.batch_no%type; --批次号
    n_cell_no          cset_cell_supplier.cell_no%type; --可用储位
    n_cell_num         number(10); --可用储位数
    nLabelId           number(10);
    v_strequipment_no  cdef_defcell_dps.DEVICE_NO%type;
    v_strCheckFlag     ridata_untread_m.status%type; --0: 已试算,可直接验收,1:系统拦截,2：需试算
    n_OldBatchNo       cset_cell_supplier.batch_no%type; --批次号
    v_DEVICE_NO        device_divide_m.device_no%type;
    v_strWAVE_TYPE     BSET_WAVE_MANAGE.Wave_Type%type; --从返配单类型取波次表批次类型。
    v_strWAVE_TYPE_tmp varchar2(10); --当前扫描墙目前扫描的单据类型。
    v_strStatus        ridata_untread_mm.status%type;
    v_str_finish       varchar2(1); --1:表示执行结案
    v_str_ri_wave_no   ridata_untread_mm.wave_no%type; --当前返配单已分配的波次号
    strQualityFlag     ridata_untread_m.quality%type;
    --n_stockNum            number(10) ;--用来判断滞销品、过季品是不是按区或按巷道来分配分播墙格子号,0为区,其它为巷道
    ncount               number(5);
    ncount1              number(5);
    ncount2              number(5);
    i                    number(5);
    strDELIVER_OBJ_LEVEL varchar2(2);
    s_wave_no_today      ODATA_DIVIDE_ALLOT.wave_no%type; --当天最大波次号
    s_wave_no            ODATA_DIVIDE_ALLOT.wave_no%type; --波次号
  begin
    strOutMsg      := 'N|[p_scan_CustAllot_LABEL_RG]';
    nAddBatchFlag  := 0;
    n_batch_no     := 0;
    n_cell_num     := 0;
    nLabelId       := 1;
    v_strWAVE_TYPE := '';
    v_str_finish   := '';

    --处理直通,配送对象是“客户”的数据
    if strClassType = 'ID' then
      --判断是不是已经分配
      select count(1)
        into n_count
        from ODATA_DIVIDE_ALLOT oda
       where oda.enterprise_no = strEnterPriseNo
         and oda.warehouse_no = strwarehouse_no
         and oda.owner_no = strowner_no
         and oda.exp_type = strClassType
         and oda.s_import_no = strSImportNo;

      --没有分配才重新分配
      if n_count = 0 then
        --把验收单号做为波次号。
        p_Insert_Idata_Check_M(strEnterpriseNo,
                               strwarehouse_no,
                               strowner_no,
                               strSImportNo,
                               strDockNo,
                               strUser_Id,
                               'N',
                               '2',
                               s_wave_no,
                               strOutMsg);
        if (substr(strOutMsg, 1, 1) = 'N') then
          return;
        end if;

        n_batch_no := 1;
        i          := 1;

        if strDELIVER_OBJ = '0' then

          for bm in (select distinct iis.enterprise_no,
                                     iis.warehouse_no,
                                     iia.owner_no,
                                     iis.import_type,
                                     iis.s_import_no,
                                     iia.cust_no
                       from idata_import_allot iia, idata_import_sm iis
                      where iia.enterprise_no = iis.enterprise_no
                        and iia.warehouse_no = iis.warehouse_no
                        and iia.owner_no = iis.owner_no
                        and iia.import_no = iis.import_no
                        and iis.import_type = strClassType
                        and iis.enterprise_no = strEnterPriseNo
                        and iis.warehouse_no = strwarehouse_no
                        and iis.owner_no = strowner_no
                        and iis.s_import_no = strSImportNo
                      order by cust_no) loop

            if i > n_stockNum then
              n_batch_no := n_batch_no + 1;
              i          := 1;
            end if;

            --写入配送对象为“门店”的数据
            insert into ODATA_DIVIDE_ALLOT
              (Enterprise_No,
               Warehouse_No,
               Owner_No,
               Operate_Date,
               Wave_No,
               BATCH_NO,
               DELIVEROBJ_ORDER,
               Device_No,
               s_Import_No,
               Exp_No,
               dps_cell_no,
               Deliver_Obj,
               Cust_No,
               Status,
               Exp_Type,
               Rgst_Name,
               Rgst_Date,
               Updt_Name,
               Updt_Date)
              select bm.enterprise_no,
                     bm.warehouse_no,
                     bm.owner_no,
                     trunc(sysdate),
                     s_wave_no,
                     n_batch_no,
                     i,
                     strDEVICE_NO,
                     bm.s_import_no,
                     iia.po_no,
                     'N',
                     bm.cust_no,
                     bm.cust_no,
                     '1',
                     bm.import_type,
                     strUser_Id,
                     sysdate,
                     strUser_Id,
                     sysdate
                from idata_import_allot iia, idata_import_sm iis
               where iia.enterprise_no = iis.enterprise_no
                 and iia.warehouse_no = iis.warehouse_no
                 and iia.owner_no = iis.owner_no
                 and iia.import_no = iis.import_no
                 and iis.import_type = strClassType
                 and iis.enterprise_no = strEnterPriseNo
                 and iis.warehouse_no = strwarehouse_no
                 and iis.owner_no = strowner_no
                 and iis.s_import_no = strSImportNo
                 and iia.cust_no = bm.cust_no;

            i := i + 1;

          end loop;
        end if;

        if strDELIVER_OBJ = '1' then
          for bm in (select distinct iis.enterprise_no,
                                     iis.warehouse_no,
                                     iia.owner_no,
                                     iis.import_type,
                                     iis.s_import_no,
                                     iia.cust_no,
                                     iia.po_no
                       from idata_import_allot iia, idata_import_sm iis
                      where iia.enterprise_no = iis.enterprise_no
                        and iia.warehouse_no = iis.warehouse_no
                        and iia.owner_no = iis.owner_no
                        and iia.import_no = iis.import_no
                        and iis.import_type = strClassType
                        and iis.enterprise_no = strEnterPriseNo
                        and iis.warehouse_no = strwarehouse_no
                        and iis.owner_no = strowner_no
                        and iis.s_import_no = strSImportNo
                      order by iia.po_no) loop

            if i > n_stockNum then
              n_batch_no := n_batch_no + 1;
              i          := 1;
            end if;

            --写入配送对象为“门店”的数据
            insert into ODATA_DIVIDE_ALLOT
              (Enterprise_No,
               Warehouse_No,
               Owner_No,
               Operate_Date,
               Wave_No,
               BATCH_NO,
               DELIVEROBJ_ORDER,
               Device_No,
               s_Import_No,
               Exp_No,
               DPS_CELL_NO,
               Deliver_Obj,
               Cust_No,
               Status,
               Exp_Type,
               Rgst_Name,
               Rgst_Date,
               Updt_Name,
               Updt_Date)
            values
              (bm.enterprise_no,
               bm.warehouse_no,
               bm.owner_no,
               trunc(sysdate),
               s_wave_no,
               n_batch_no,
               i,
               strDEVICE_NO,
               bm.s_import_no,
               bm.po_no,
               'N',
               bm.po_no,
               bm.cust_no,
               '1',
               bm.import_type,
               strUser_Id,
               sysdate,
               strUser_Id,
               sysdate);

            i := i + 1;

          end loop;
        end if;
      end if;
      --更新进货汇总单波次号

      update idata_import_mm
         set wave_no = s_wave_no
       where enterprise_no = strEnterPriseNo
         and warehouse_no = strwarehouse_no
         and owner_no = strowner_no
         and s_import_no = strSImportNo;
    end if;

    strOutMsg := 'Y|';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_scan_CustAllot_LABEL_RG;

end pkobj_idata;

/

