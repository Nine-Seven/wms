create view V_SEARCH_9101_5 as
select cdp.enterprise_no,cdp.warehouse_no,cdp.device_no,
cdp.stock_no || '-' || cdp.dps_area as dps_area,
cdp.cell_no,cdp.ctrl_no,cdp.address,
decode(cdp.device_type,'1','扫描枪','2','电子标签','3','巷道灯','4','LED屏','5','音乐器') as device_type,
ccd.cust_no,bc.cust_name
 from cdef_defcell_dps cdp
left join CSET_CUST_DPSCELL ccd
on ccd.enterprise_no=cdp.enterprise_no
and ccd.warehouse_no=cdp.warehouse_no
and ccd.dps_cell_no=cdp.cell_no
left join bdef_defcust bc
on bc.enterprise_no=ccd.enterprise_no
and bc.cust_no=ccd.cust_no
order by cdp.device_no,cdp.stock_no,cdp.dps_area,cdp.address desc


/

