create PACKAGE        CDestroyLabelStatusRange IS

        -- 标签销毁开始值
         DESTROY_BEGIN_STATUS CONSTANT STOCK_LABEL_M.STATUS%TYPE := 'F0';

        -- 标签销毁结束值
         DESTROY_END_STATUS CONSTANT STOCK_LABEL_M.STATUS%TYPE := 'FZ';


end CDestroyLabelStatusRange;


/

