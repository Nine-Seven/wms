create trigger TRG_BDEF_DEFCUST_ROWID
    before insert or update
    on BDEF_DEFCUST
    for each row
declare
  i_id NUMBER;
begin
  select SEQ_BDEF_DEFCUST_ROWID.NEXTVAL into i_id from dual;
  :NEW.ROW_ID := i_id;
end TRG_BDEF_DEFCUST_ROWID;


/

