create view V_SEARCH_9104_4 as
select m.enterprise_no,
       m.warehouse_no,
       nvl(d.owner_no, 'N') owner_no,
       m.label_no,
       m.source_no,
       m.status,
       w.text status_desc,
       nvl(d.cust_no, 'N') cust_no,
       nvl(bdc.cust_name, 'N') cust_name,
       nvl(d.article_no, 'N') article_no,
       nvl(v.ARTICLE_NAME, 'N') ARTICLE_NAME,
       nvl(v.BARCODE, 'N') BARCODE,
       nvl(v.SUPPLIER_NO, 'N') SUPPLIER_NO,
       nvl(d.qty, 0) qty,
       m.use_type,
       w1.text use_type_desc,m.updt_date
  from stock_label_m m
  left join stock_label_d d
    on m.enterprise_no = d.enterprise_no
   and m.warehouse_no = d.warehouse_no
   and m.container_no = d.container_no
  left join v_bdef_defarticle v
    on d.enterprise_no = v.enterprise_no
   and d.owner_no = v.OWNER_NO
   and d.article_no = v.ARTICLE_NO
  left join bdef_defcust bdc
    on d.owner_no = bdc.owner_no
   and d.enterprise_no = bdc.enterprise_no
   and d.cust_no = bdc.cust_no
  left join wms_deffieldval w
    on w.table_name = 'STOCK_LABEL_M'
   and w.colname = 'STATUS'
   and w.value = m.status
  left join wms_deffieldval w1
    on w1.table_name = 'N'
   and w1.colname = 'USE_TYPE'
   and w1.value = m.use_type


/

