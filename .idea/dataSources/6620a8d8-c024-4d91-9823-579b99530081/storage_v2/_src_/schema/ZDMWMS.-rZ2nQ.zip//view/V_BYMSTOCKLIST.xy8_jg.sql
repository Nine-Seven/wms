create view V_BYMSTOCKLIST as
select atc.owner_article_no,atc.article_name,sc.packing_qty,atcp.packing_unit,to_char(sai.produce_date,'yyyyMMdd') produce_date,
to_date(to_char(sai.rgst_date,'yyyyMMdd'),'yyyyMMdd') indate,0.00 DM,sum(sc.qty) NR,0.00 NRM,0.00 QA,sum(sc.qty) sumqty
from stock_content sc ,bdef_defarticle atc,bdef_article_packing atcp,stock_article_info sai
where sc.owner_no = atc.owner_no
  and sc.article_no = atc.article_no
  and atc.article_no = atcp.article_no
  and sc.packing_qty = atcp.packing_qty
  and sc.article_no = sai.article_no
  and sc.article_id = sai.article_id
  group by atc.owner_article_no,atc.article_name,sc.packing_qty,atcp.packing_unit,to_char(sai.produce_date,'yyyyMMdd'),
to_date(to_char(sai.rgst_date,'yyyyMMdd'),'yyyyMMdd')


/

