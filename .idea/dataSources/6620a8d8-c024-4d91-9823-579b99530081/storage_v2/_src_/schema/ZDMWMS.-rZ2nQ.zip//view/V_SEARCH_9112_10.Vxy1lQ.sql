create view V_SEARCH_9112_10 as
select paper_type, --业务类型
       rgst_date, --创建时间
       article_no, --商品ID
       barcode, --商品条码
       article_identifier, --备案货号
       move_qty, --数量
       paper_no, --单据号
       owner_no,
       owner_alias
  from (select scl.paper_type,
               scl.rgst_date,
               scl.article_no,
               scl.barcode,
               bda.article_identifier,
               sum(scl.move_qty) move_qty,
               scl.paper_no,
               scl.owner_no,
               bdo.owner_alias
          from stock_content_list scl
          left join bdef_defarticle bda
            on bda.article_no = scl.article_no
           and bda.enterprise_no = scl.enterprise_no
          left join bdef_defowner bdo
            on bdo.owner_no = scl.owner_no
           and bdo.enterprise_no = scl.enterprise_no
         group by scl.paper_type,
                  scl.rgst_date,
                  scl.article_no,
                  scl.barcode,
                  bda.article_identifier,
                  move_qty,
                  scl.paper_no,
                  scl.owner_no,
                  bdo.owner_alias) c

/

