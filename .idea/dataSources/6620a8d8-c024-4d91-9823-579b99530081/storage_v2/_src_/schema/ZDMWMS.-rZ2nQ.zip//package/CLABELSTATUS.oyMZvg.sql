create PACKAGE        CLabelStatus IS

--入库状态

        -- 已验入
        RECEIVED CONSTANT STOCK_LABEL_M.STATUS%TYPE := '0';
        -- 定位完成
        LOCATE_TOCELL CONSTANT STOCK_LABEL_M.STATUS%TYPE := '25';
        -- 上架发单
        GETTask_TOCELL CONSTANT STOCK_LABEL_M.STATUS%TYPE := '26';

        --上架回单
        INSTOCK_COMFIRE CONSTANT STOCK_LABEL_M.STATUS%TYPE := 'F1';
--出货状态
        -- 拣货发单
        PICK_HAND_OUT CONSTANT STOCK_LABEL_M.STATUS%TYPE := '50';
        -- 拣货零回
        PICK_RETURN_ZERO CONSTANT STOCK_LABEL_M.STATUS%TYPE := 'FF';
        -- 已关联物流箱
        HasRelevanceBox CONSTANT STOCK_LABEL_M.STATUS%TYPE := '51';
        -- 拣货完成（分播）
        PICK_END CONSTANT STOCK_LABEL_M.STATUS%TYPE := '52';
        -- 拣货输送线运输中
        PICK_MOVING CONSTANT STOCK_LABEL_M.STATUS%TYPE := '55';
        -- 新取号
        NEW_LABEL_NO CONSTANT STOCK_LABEL_M.STATUS%TYPE := '60';
        -- 整理中(接收品项并入)
        RECEIVING CONSTANT STOCK_LABEL_M.STATUS%TYPE := '61';
        --已并板
        LOADED_IN_PAL CONSTANT STOCK_LABEL_M.STATUS%TYPE := '62';
        --拆板生成
        DIVIDE_FROM_PAL CONSTANT STOCK_LABEL_M.STATUS%TYPE := '63';
        --已过分拣
        SORTING_PASS CONSTANT STOCK_LABEL_M.STATUS%TYPE := '65';


        -- 整理确认
        CONFIRM CONSTANT STOCK_LABEL_M.STATUS%TYPE := '66';
        --内复核中
        INNER_CHECKING CONSTANT STOCK_LABEL_M.STATUS%TYPE := '6A';
        -- 内复核完成
        INNER_CHECKED CONSTANT STOCK_LABEL_M.STATUS%TYPE := '6B';
        -- 待外复核
        WAIT_OUTER_CHECK CONSTANT STOCK_LABEL_M.STATUS%TYPE := '6C';
        -- 外复核中
        OUTER_CHECKING CONSTANT STOCK_LABEL_M.STATUS%TYPE := '6D';
        -- 外复核完成
        OUTER_CHECKED CONSTANT STOCK_LABEL_M.STATUS%TYPE := '6E';
        -- 已装区
        WAIT_TURN_AREA CONSTANT STOCK_LABEL_M.STATUS%TYPE := '90';
        -- 待装车
        WAIT_LOAD_CAR CONSTANT STOCK_LABEL_M.STATUS%TYPE := 'A0';
        -- 已装车
        LOADED_IN_CAR CONSTANT STOCK_LABEL_M.STATUS%TYPE := 'A1';
        -- 已配送
        DELIVERIED CONSTANT STOCK_LABEL_M.STATUS%TYPE := 'A2';
        -- 撤票锁定
        OM_CANCEL_Lock CONSTANT STOCK_LABEL_M.STATUS%TYPE := 'C0';

        -- 全部分播完毕（释放）
         DIVIDED CONSTANT STOCK_LABEL_M.STATUS%TYPE := 'F3';

        -- 分播取消
         DIVIDED_CANCEL CONSTANT STOCK_LABEL_M.STATUS%TYPE := 'FB';


        -- 整理完成
        ARRANGE_COMPLETE CONSTANT STOCK_LABEL_M.STATUS%TYPE := 'F4';
        -- 拣货转移完成，销毁
        PICK_CLOSE CONSTANT STOCK_LABEL_M.STATUS%TYPE := 'F5';
        -- 拣货取消
        PICK_CANCEL CONSTANT STOCK_LABEL_M.STATUS%TYPE := 'FC';
        -- 内复核取消
        INSIDE_CHECK_CANCEL CONSTANT STOCK_LABEL_M.STATUS%TYPE := 'FD';
        -- 外复核取消
        OUT_CHECK_CANCEL CONSTANT STOCK_LABEL_M.STATUS%TYPE := 'FE';
        --拆板销毁
        SPLIT_LABEL_CANCEL CONSTANT STOCK_LABEL_M.STATUS%TYPE := 'FH';
        -- 撤票销毁
        BillCANCEL_LABEL_CANCEL CONSTANT STOCK_LABEL_M.STATUS%TYPE := 'FI';

        instock_cancel   CONSTANT STOCK_LABEL_M.STATUS%TYPE := 'FA';


        ---移库（补货）
        -- 移库发单
         MOVE_HAND_OUT CONSTANT STOCK_LABEL_M.STATUS%TYPE := '40';

        -- 移库下架
         OUTSTOCKING CONSTANT STOCK_LABEL_M.STATUS%TYPE := '41';

        -- 移库搬运
         MOVING CONSTANT STOCK_LABEL_M.STATUS%TYPE := '42';

        -- 移库部分上架
         INSTOCKING CONSTANT STOCK_LABEL_M.STATUS%TYPE := '43';

        -- 移库上架完成（补货上架完成）
         INSTOCKED CONSTANT STOCK_LABEL_M.STATUS%TYPE := 'F1';


end CLabelStatus;


/

