create package        CREPORT_TYPE is
/*报表类型 huangb 20160621*/
--表单
TYPE_L CONSTANT pntset_module_report.report_type%type := 'L';
--标签头档
TYPE_M CONSTANT pntset_module_report.report_type%type := 'M';
--标签明细
TYPE_D CONSTANT pntset_module_report.report_type%type := 'D';
--面单
TYPE_WAY CONSTANT pntset_module_report.report_type%type := 'WAY';
--发票
TYPE_INV CONSTANT pntset_module_report.report_type%type := 'INV';
--装箱清单
TYPE_BOX CONSTANT pntset_module_report.report_type%type := 'BOX';

end CREPORT_TYPE;


/

