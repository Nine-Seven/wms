create view V_SEARCH_9101_10 as
select cca.enterprise_no,
       cca.warehouse_no,
       cca.owner_no,
       cca.cell_no,
       v.owner_article_no,
       v.barcode,
       cca.article_no,
       v.article_name,
       v.spec,
       v.packing_qty,
       cca.max_qty_a,
       cca.alert_qty_a,
       v.pal_base_qbox,
       v.pal_height_qbox,
       v.QPALETTE,
       cca.keep_cells_a--可用储位数
from cset_cell_article cca,
     v_article_pack_volumn_weight v
where cca.article_no=v.article_no
  and cca.enterprise_no=v.enterprise_no
  and cca.packing_qty=v.packing_qty

/

