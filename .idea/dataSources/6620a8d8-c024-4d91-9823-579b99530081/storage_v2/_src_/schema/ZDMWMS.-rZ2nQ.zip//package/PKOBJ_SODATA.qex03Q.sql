create package        pkobj_sodata is
  /**************************************************************************************************8
   功能说明：写报损手建单头档
   2015.7.25

  ***************************************************************************************************/
  procedure P_InsertWasteHead(strEnterPriseNo in sodata_waste_m.enterprise_no%type,
                               strWarehouseNo in sodata_waste_m.warehouse_no%type, --仓别
                               strOwnerNo     in sodata_waste_m.owner_no%type,
                               strCreateFlag  in sodata_waste_m.create_flag%type,--
                               strStockType   in sodata_waste_m.stock_type%type,
                               strStockValue  in sodata_waste_m.stock_value%type,
                               strOrgNo       in sodata_waste_m.org_no%type,
                               strUserID      in sodata_waste_m.rgst_name%type,
                               strWasteNo     out sodata_waste_m.waste_no%type,
                               strResult      out varchar2);

  /***********************************************************************************************
  功能说明：写报损单明细
  2015.7.27

  ***********************************************************************************************/
  procedure P_InsertWasteItem(strEnterPriseNo in sodata_waste_m.enterprise_no%type,
                                   strWarehouseNo in sodata_waste_m.warehouse_no%type, --仓别
                                   strOwnerNo     in sodata_waste_m.owner_no%type,
                                   strWasteNo     in sodata_waste_m.waste_no%type,
                                   strArticleNo   in sodata_waste_d.article_no%type,
                                   nPackingQty    in sodata_waste_d.packing_qty%type,
                                   strLotNo       in sodata_waste_d.lot_no%type,
                                   strQuality     in sodata_waste_d.quality%type,
                                   nWasteQty      in sodata_waste_d.waste_qty%type,
                                   strOutMsg      out varchar2);

  /**********************************************************************************************
  功能：写报损下架指示
    2015.7.27
  huangb 20160511 移至PKLG_SODATA包
  **********************************************************************************************/
  /*procedure P_InsertSodateDirect(strEnterPriseNo in sodata_waste_m.enterprise_no%type,
                                  strWareHouseNo  in sodata_waste_m.warehouse_no%type,
                                  strWasteNo      in sodata_waste_m.waste_no%type,
                                  strArticleNo    in sodata_waste_d.article_no%type,
                                  strLotNo        in sodata_waste_d.lot_no%type,
                                  dtProduceDate   in sodata_waste_d.produce_date%type,
                                  dtExpireDate    in sodata_waste_d.expire_date%type,
                                  strStockType    in sodata_waste_m.stock_type%type,
                                  strStockValue   in sodata_waste_m.stock_value%type,
                                  strOrgNo        in sodata_waste_m.org_no%type,
                                  strDestCellNo   in cdef_defcell.cell_no%type,
                                  strUserId       in sodata_waste_m.rgst_name%type,
                                  nPoID           in sodata_waste_d.po_id%type,
                                  nQty            in sodata_waste_d.waste_qty%type,
                                  strResult       out varchar2);*/
  /***************************************************************************************************
   功能说明：写报损下架单头档
   2015.7.27

  *****************************************************************************************************/
  procedure P_InsertWasteOutstockHead(strEnterPriseNo in sodata_outstock_m.enterprise_no%type,
                                   strWarehouseNo in sodata_outstock_m.warehouse_no%type, --仓别
                                   strOwnerNo     in sodata_outstock_m.owner_no%type,
                                   strOutStockNo  in sodata_outstock_m.outstock_no%type, --下架单号
                                   strAssignName  in sodata_outstock_m.rgst_name%type, --计划作业人员
                                   strOutMsg      out varchar2);

  /********************************************************************************************
  功能说明：写报损单明细档
  2015.7.27
  *********************************************************************************************/
  procedure P_InserWasteOutStockItem(strEnterPriseNo in sodata_outstock_m.enterprise_no%type,
                                   strWarehouseNo in sodata_outstock_m.warehouse_no%type, --仓别
                                   strOwnerNo     in sodata_outstock_m.owner_no%type,
                                   strOutStockNo  in sodata_outstock_m.outstock_no%type, --下架单号
                                   strUserId      in sodata_outstock_m.rgst_name%type, --计划作业人员
                                   nDirectSerial  in sodata_outstock_d.divide_id%type, --指示序列
                                   strOutMsg      out varchar2);

  /*********************************************************************************************
  功能说明：更新报损下架指示
  2015.7.27

  **********************************************************************************************/
  procedure P_UpdatedWasteDirect(strEnterPriseNo in sodata_outstock_d.enterprise_no%type,
                                 strWarehouseNo in sodata_outstock_d.warehouse_no%type, --仓别
                                 strOwnerNo     in sodata_outstock_d.owner_no%type,
                                 strWasteNo     in sodata_outstock_d.source_no%type, --报损单号
                                 strUserID      in sodata_outstock_d.assign_name%type, --员工ID
                                 strOutMsg      out varchar2);

  /****************************************************************************************************
  功能说明：更新报损下架单头档
  2015.7.27

  *****************************************************************************************************/
  procedure P_UpdateWasteOutStockHeader(strEnterPriseNo in sodata_outstock_m.enterprise_no%type,
                                      strWarehouseNo in sodata_outstock_m.warehouse_no%type, --仓别
                                      strOutStockNo  in sodata_outstock_m.outstock_no%type, --下架单号
                                      strOwnerNo     in sodata_outstock_m.owner_no%type,
                                      strUserId      in sodata_outstock_m.rgst_name%type, --员工ID
                                      strOutMsg      out varchar2);
  /***************************************************************************************************88
  功能说明：更新报损下架单
  2015.7.27
  ***********************************************************************************************/
  procedure P_UpdateWasteOutstockItem(strEnterPriseNo in sodata_outstock_m.enterprise_no%type,
                             strWarehouseNo  in sodata_outstock_d.warehouse_no%type, --仓别
                             strOutStockNo   in sodata_outstock_d.outstock_no%type, --下架单号
                             nRealQty        in sodata_outstock_d.real_qty%type,
                             strOwnerNo      in sodata_outstock_d.owner_no%type,
                             nDivideId          in sodata_outstock_d.DIVIDE_ID%type,
                             strOutstockName in sodata_outstock_d.outstock_name%type, --出货员工ID
                             strOutMsg       out varchar2);


  /******************************************************************************************888
  功能说明：报损下架单转历史
  2015.7.27

  *********************************************************************************************/
  procedure P_UpdateOutStockHistory(strEnterPriseNo in sodata_outstock_m.enterprise_no%type,
                                       strWarehouseNo in sodata_outstock_m.warehouse_no%type, --仓别
                                       strOutStockNo  in sodata_outstock_m.outstock_no%type, --下架单号
                                       strOwnerNo     in sodata_outstock_m.owner_no%type,
                                       strOutMsg      out varchar2);

  /*******************************************************************************************************
  创建人：huangb
  创建时间：2016.05.16
  功能说明：报损单据转历史
  ********************************************************************************************************/
  procedure P_SO_InsertHTY(strEnterPriseNo in sodata_outstock_m.enterprise_no%type,
                           strWarehouseNo  in sodata_outstock_m.warehouse_no%type, --仓别
                           strOwnerNo      in sodata_outstock_m.owner_no%type,
                           strOutstockNo   in sodata_outstock_m.outstock_no%type, --报损下架单
                           strUserID       in sodata_outstock_m.rgst_name%type,
                           strOutMsg       out varchar2);

end pkobj_sodata;


/

