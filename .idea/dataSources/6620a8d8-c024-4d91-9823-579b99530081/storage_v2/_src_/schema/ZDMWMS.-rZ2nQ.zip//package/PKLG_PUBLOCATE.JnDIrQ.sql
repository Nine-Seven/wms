create package        PKLG_PUBLOCATE is

  -- Author  : LIZHIPING
  -- Created : 2013-09-28 10:56:43
  -- Purpose :

  -- Public type declarations
  -- type <TypeName> is <Datatype>;
  TYPE cv_type IS REF CURSOR; --声明游标类型

  -- Public constant declarations
  -- <ConstantName> constant <Datatype> := <Value>;

  -- Public variable declarations
  -- <VariableName> <Datatype>;

  -- Public function and procedure declarations
  -- function <FunctionName>(<Parameter> <Datatype>) return <Datatype>;

  --获取拣货位
  procedure p_get_PickCell(strEnterPriseNo in bdef_defowner.enterprise_no%type,
                           strWareHouseNo  in bset_worker_loc.warehouse_no%type,
                           strOwnerNo      in bdef_defowner.owner_no%type,
                           strArticleNo    in bdef_defarticle.article_no%type,
                           strCPickCellNo  out cset_cell_article.cell_no%type,
                           nCMaxQty        out cset_cell_article.max_qty_a%type,
                           nCKeepCells     out cset_cell_article.keep_cells%type,
                           strBPickCellNo  out cset_cell_article.cell_no%type,
                           nBMaxQty        out cset_cell_article.max_qty_a%type,
                           nBKeepCells     out cset_cell_article.keep_cells%type,
                           nPickLine       out cset_cell_article.line_id%type,
                           nPickCellCount  out number,
                           strErrorMsg     in out varchar2);

  --出货定位配量入口
  procedure p_locate_allot_OM(v_nTmpStockID   in number,
                              strEnterPriseNo in varchar2,
                              strWareHouseNo  in varchar2, --仓库代码
                              strWaveNo       in varchar2, --定位号
                              nGroupNo        in number, --出货组号
                              strArticleNo    in varchar2, --商品代码
                              strStockType    in varchar2, --库存性质
                              strStockValue   in varchar2, --库存值
                              nLocateQty      in number, --需定位量
                              v_nAllotID      out number, --配量表临时序列号
                              strErrorMsg     out varchar2);

  --系统配量入口
  procedure p_locate_allot(v_nAllotID      in number, --配量表临时序列号
                           strEnterPriseNo in varchar2,
                           strWareHouseNo  in varchar2, --仓库代码
                           strSourceNo     in varchar2,
                           strOutstockType varchar2, --出货方式（ID:直通；IS存储）
                           strOperateType  in varchar2,
                           nTotalQty       in number, --需要分配的总数量
                           nUnitQty        in number, --单位分配量
                           strErrorMsg     out varchar2);

end PKLG_PUBLOCATE;


/

