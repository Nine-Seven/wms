create package        PKLG_MDATA is
  /***********************************************************************************************************
   创建人：luozhiling
   时间：2013.11.16
   功能：人工移库
  ***********************************************************************************************************/
  procedure P_mdata_PlanMove(strEnterPriseNo in mdata_plan_m.enterprise_no%type,
                             strWareHouseNo  in mdata_plan_m.warehouse_no%type, --仓库编码
                             strOwnerNo      in mdata_plan_m.owner_no%type,
                             strUserId       in mdata_plan_m.rgst_name%type,
                             strSouceType    in mdata_plan_m.source_type%type, --移库类型；1:商品移库；2：标签移库
                             strOutstockType in mdata_plan_m.outstock_type%type, --下架类型：3：安全量补货；4:人工移库
                             strArticleNo    in mdata_plan_d.article_no%type, --商品编码
                             nPackingQty     in mdata_plan_d.packing_qty%type,
                             dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                             dtExPireDate    in stock_article_info.expire_date%type, --到期日
                             strQUALITY      in stock_article_info.quality%type,
                             strLotNo        in stock_article_info.lot_no%type, --批次号
                             strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                             strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                             strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                             strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                             strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                             strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                             strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                             strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                             nPlanQty        in mdata_plan_d.origin_qty%type, --计划移库量
                             strStockType    in mdata_plan_d.stock_type%type,
                             strStockVAlue   in mdata_plan_d.stock_value%type,
                             strsCellNo      in mdata_plan_d.s_cell_no%type, --来源储位
                             strLabelNo      in mdata_plan_d.s_label_no%type, --来源标签号
                             strSubLabelNo   in mdata_plan_d.s_sub_label_no%type, --来源子标签号
                             strDestCellNo   in mdata_plan_d.d_cell_no%type, --目的储位
                             strsPlanNo      in mdata_plan_d.plan_no%type, --原计划单号
                             strPlanNo       out mdata_plan_m.plan_no%type, --返回的计划单号
                             strResult       OUT varchar2);

  /***********************************************************************************************************
   创建人：luozhiling
   时间：2014.12.15
   功能：安全量补货
  ***********************************************************************************************************/
  procedure P_mdata_HMPlanMove(strEnterPriseNo in mdata_plan_m.enterprise_no%type, --企业号
                               strWareHouseNo  in mdata_plan_m.warehouse_no%type, --仓库编码
                               strOwnerNo      in mdata_plan_m.owner_no%type,
                               strUserId       in mdata_plan_m.rgst_name%type,
                               strSouceType    in mdata_plan_m.source_type%type, --移库类型；1:商品移库；2：标签移库
                               strOutstockType in mdata_plan_m.outstock_type%type, --下架类型：3：安全量补货；4:人工移库
                               strArticleNo    in mdata_plan_d.article_no%type, --商品编码
                               nPackingQty     in mdata_plan_d.packing_qty%type,
                               nPlanQty        in mdata_plan_d.origin_qty%type, --计划移库量
                               strStockType    in mdata_plan_d.stock_type%type,
                               strStockVAlue   in mdata_plan_d.stock_value%type,
                               strDestCellNo   in mdata_plan_d.d_cell_no%type, --目的储位
                               strsPlanNo      in mdata_plan_d.plan_no%type, --原计划单号
                               strPlanNo       out mdata_plan_m.plan_no%type, --返回的计划单号
                               strResult       OUT varchar2);
  /******************************************************************************************
   luozhiling
   2014.12.18
   功能说明：人工移库、安全量补货写定位指示并定位
  ******************************************************************************************/
  procedure P_mdata_Locate_Main(strEnterPriseNo in mdata_plan_m.enterprise_no%type,
                                strWareHouseNo  in mdata_plan_m.warehouse_no%type, --仓库编码
                                strOwnerNo      in mdata_plan_m.owner_no%type,
                                strPlanNo       in mdata_plan_m.plan_no%type, --移库计划头档
                                strUserId       in mdata_plan_m.rgst_name%type,
                                strResult       OUT varchar2);

  --移库人工发单
  procedure p_DoManuHM(strEnterPriseNo in odata_outstock_m.enterprise_no%type,
                       strWAREHOUSE_NO in bdef_warehouse_packing.warehouse_no%type,
                       strOwner_No     in bdef_defowner.owner_no%type,
                       strOutStockType in odata_outstock_m.outstock_type%type, --下架类型4:人工移库；3：安全量补货
                       strMoveSeqType  in varchar2, --1,按来源,2-按目的,3-单一来源+单一目的
                       strPick_Worker  in bdef_defworker.worker_no%type, --预定下架人员
                       strDock_No      in bdef_defdock.dock_no%type, --码头号
                       strUserID       in bdef_defworker.worker_no%type,
                       strReportType   in odata_outstock_m.task_type%type, --打印类型,参考CONST_REPORTID中定义
                       strOutMsg       out varchar2);

  --移库定位、发单
  procedure P_mdata_locateAndSend(strEnterPriseNo in mdata_plan_m.enterprise_no%type, --企业号
                                  strWareHouseNo  in mdata_plan_m.warehouse_no%type, --仓库编码
                                  strOwnerNo      in mdata_plan_m.owner_no%type,
                                  strPlanNo       in mdata_plan_m.plan_no%type, --移库计划头档
                                  strOutStockType in odata_outstock_m.outstock_type%type, --下架类型4:人工移库；3：安全量补货
                                  strMoveSeqType  in varchar2, --1,按来源,2-按目的,3-单一来源+单一目的
                                  strDock_No      in bdef_defdock.dock_no%type, --码头号
                                  strReportType   in odata_outstock_m.task_type%type, --打印类型,参考CONST_REPORTID中定义
                                  strUserId       in mdata_plan_m.rgst_name%type,
                                  strResult       OUT varchar2);

  --移库下架回单
  procedure p_HmOutstock_Return(strEnterPriseNo   in odata_outstock_m.enterprise_no%type,
                                strWarehose_No    in bdef_warehouse_packing.warehouse_no%type,
                                strOwner_No       in bdef_defowner.owner_no%type,
                                strOutstock_No    in odata_outstock_m.outstock_no%type,
                                strArticle_No     in bdef_defarticle.article_no%type,
                                strBarcode        in bdef_defarticle.barcode%type,
                                dtProduceDate     in stock_article_info.produce_date%type,
                                dtExpireDate      in stock_article_info.expire_date%type,
                                strQUALITY        in stock_article_info.quality%type,
                                strLotNo          in stock_article_info.lot_no%type, --批次号
                                strRSV_BATCH1     in stock_article_info.rsv_batch1%type, --预留批属性1
                                strRSV_BATCH2     in stock_article_info.rsv_batch2%type, --预留批属性2
                                strRSV_BATCH3     in stock_article_info.rsv_batch3%type, --预留批属性3
                                strRSV_BATCH4     in stock_article_info.rsv_batch4%type, --预留批属性4
                                strRSV_BATCH5     in stock_article_info.rsv_batch5%type, --预留批属性5
                                strRSV_BATCH6     in stock_article_info.rsv_batch6%type, --预留批属性6
                                strRSV_BATCH7     in stock_article_info.rsv_batch7%type, --预留批属性7
                                strRSV_BATCH8     in stock_article_info.rsv_batch8%type, --预留批属性8
                                strS_Cell_No      in cdef_defcell.cell_no%type, --源储位
                                strD_Cell_No      in cdef_defcell.cell_no%type, --目的储位
                                nArticleQty       in odata_outstock_d.article_qty%type, --计划数量
                                nRealQTY          in odata_outstock_d.article_qty%type,
                                strUserID         in bdef_defworker.worker_no%type, --操作人员ID
                                strInstockUserID  IN bdef_defworker.worker_no%type, --上架人员
                                strOutstockUserID in bdef_defworker.worker_no%type, --下架人员
                                strOutMsg         out varchar2);
  /**********************************************************************************************8
  lich
  20140711
  功能说明：标签移库回单
  ***********************************************************************************************/
  procedure P_TaskLabel_Outstock_Move(strEnterPriseNo in odata_outstock_m.enterprise_no%type,
                                      strWarehose_No  in odata_outstock_m.warehouse_no%type, --仓别
                                      strOutstock_No  in odata_outstock_m.outstock_no%type, --下架单号
                                      strFixLabel_No  in odata_outstock_d.label_no%type, --标签号码
                                      strArticle_No   in odata_outstock_d.article_no%type, --商品编码
                                      nPacking_QTY    in odata_outstock_d.packing_qty%type, --包装数量
                                      strSCell_No     in odata_outstock_d.s_cell_no%type, --来源储位
                                      nArticleQty     in odata_outstock_d.article_qty%type, --计划数量
                                      nReal_QTY       in odata_outstock_d.article_qty%type, --下架数量
                                      strQuality      in idata_check_d.quality%type, --品质
                                      dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                                      dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                                      strLotNo        in stock_article_info.lot_no%type, --批次号
                                      strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                                      strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                                      strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                                      strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                                      strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                                      strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                                      strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                                      strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                                      strDock_No      in odata_outstock_m.dock_no%type, --工作站
                                      strUserID       in odata_outstock_m.rgst_name%type, --回单人
                                      strOutstock_ID  in odata_outstock_d.outstock_name%type, --下架人
                                      strInstock_ID   in odata_outstock_d.instock_name%type, --上架人
                                      strOutMsg       out varchar2);
  /***************************************************************************************************************
  功能说明：获取及时移库建议储位
  创建人:wyf
  创建时间：2015.07.25
  ***************************************************************************************************************/
  procedure proc_HM_MoveCell_GetDCellNo(strEnterPriseNo in stock_content.enterprise_no%type,
                                        strWarehouseNo  in stock_content.warehouse_no%type,
                                        strArticleNo    in stock_content.article_no%type,
                                        strSCellNo      in stock_content.cell_no%type,
                                        strLabelNo      in stock_content.label_no%type,
                                        nPackingQty     in stock_content.packing_qty%type,
                                        nMoveQty        in stock_content.qty%type,
                                        dtProduceDate   in varchar2, --in stock_article_info.produce_date%type,
                                        dtExpireDate    in varchar2, --in stock_article_info.expire_date%type,
                                        strQUALITY      in stock_article_info.quality%type,
                                        strLotNo        in stock_article_info.lot_no%type, --批次号
                                        strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                                        strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                                        strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                                        strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                                        strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                                        strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                                        strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                                        strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                                        strAreaUseType  in cdef_defarea.area_usetype%type, --指定目的区域类型0：不指定，1：普通区，3：退货区，5：异常区
                                        strDCellNo      out stock_content.cell_no%type,
                                        strOutMsg       out varchar2);
  /***************************************************************************************************************
  功能说明：即时移库
  创建人:luozhiling
  创建时间：2014.12.4
  ***************************************************************************************************************/
  procedure proc_SaveMoveCell(strEnterPriseNo  IN stock_content.enterprise_no%type,
                              strWarehouseNo   in stock_content.warehouse_no%type,
                              strArticleNo     in stock_content.article_no%type,
                              strsCellNo       in stock_content.cell_no%type,
                              strLabelNo       in stock_content.label_no%type,
                              strDCellNo       in stock_content.cell_no%type,
                              nPackingQty      in stock_content.packing_qty%type,
                              dtProduceDate    in stock_article_info.produce_date%type,
                              dtExpireDate     in stock_article_info.expire_date%type,
                              strQUALITY       in stock_article_info.quality%type,
                              strLotNo         in stock_article_info.lot_no%type, --批次号
                              strRSV_BATCH1    in stock_article_info.rsv_batch1%type, --预留批属性1
                              strRSV_BATCH2    in stock_article_info.rsv_batch2%type, --预留批属性2
                              strRSV_BATCH3    in stock_article_info.rsv_batch3%type, --预留批属性3
                              strRSV_BATCH4    in stock_article_info.rsv_batch4%type, --预留批属性4
                              strRSV_BATCH5    in stock_article_info.rsv_batch5%type, --预留批属性5
                              strRSV_BATCH6    in stock_article_info.rsv_batch6%type, --预留批属性6
                              strRSV_BATCH7    in stock_article_info.rsv_batch7%type, --预留批属性7
                              strRSV_BATCH8    in stock_article_info.rsv_batch8%type, --预留批属性8
                              NRealQty         in stock_content.qty%type,
                              strTERMINAL_FLAG in stock_content_move.terminal_flag%type,
                              strSourceType    in odata_outstock_m.source_type%type,
                              strUserID        in stock_content.rgst_name%type,
                              strOutMsg        out varchar2);
  /***************************************************************************************************************
  功能说明：标签移库扫标签
  创建人:wyf
  创建时间：2015.07.25
  ***************************************************************************************************************/
  procedure proc_LabelMoveScanLabelNo(strEnterPriseNo IN stock_content.enterprise_no%type,
                                      strWarehouseNo  in stock_content.warehouse_no%type,
                                      strLabelNo      in stock_content.label_no%type,
                                      strDCellNo      out stock_content.cell_no%type,
                                      strOutMsg       out varchar2);
  /***************************************************************************************************************
  功能说明：获取返配标签移库建议储位
  创建人:wyf
  创建时间：2015.07.25
  ***************************************************************************************************************/
  procedure proc_RIGetDCellNo(strEnterPriseNo IN stock_content.enterprise_no%type,
                              strWarehouseNo  in stock_content.warehouse_no%type,
                              strLabelNo      in stock_content.label_no%type,
                              strDCellNo      out stock_content.cell_no%type,
                              strOutMsg       out varchar2);
  /***************************************************************************************************************
  功能说明：标签即时移库,可支持将标签从来源储位直接移库到目的储位
                         可支持将来源标签的库存直接转移到目的储位
  创建人:wyf
  创建时间：2015.07.25
  ***************************************************************************************************************/
  procedure proc_RISaveLabelMoveCell(strEnterPriseNo  IN stock_content.enterprise_no%type,
                                     strWarehouseNo   in stock_content.warehouse_no%type,
                                     strLabelNo       in stock_content.label_no%type,
                                     strDCellNo       in stock_content.cell_no%type, --可传储位和标签号
                                     strdCellUseType  in varchar2, --目的储位类型：1：表示扫描的目的储位；2：表示扫描的目的标签
                                     strTERMINAL_FLAG in stock_content_move.terminal_flag%type,
                                     strSourceType    in odata_outstock_m.source_type%type,
                                     strUserID        in stock_content.rgst_name%type,
                                     strOutMsg        out varchar2);
  /************************************************************************************************************
  功能说明：1、写移库头档
            2、写库明细
            3、移库回单
  创建人：luozhiling
  2015.5.8
  ************************************************************************************************************/
  procedure Proc_LabelBackCell(strEnterPriseNo IN stock_content.enterprise_no%type,
                               strWarehouseNo  in stock_content.warehouse_no%type,
                               strOwnerNo      in stock_content.owner_no%type,
                               strLabelNo      in stock_content.label_no%type, --来源标签
                               strUserID       in stock_content.rgst_name%type,
                               strOutMsg       out varchar2);

  /*****************************************************************************8888
  功能说明：根据移库单进行品质转换
  2015.8.7
  *********************************************************************************/
  procedure P_ChangeQualityOrg(strEnterPriseNo odata_outstock_m.enterprise_no%type,
                               strWareHouseNo  odata_outstock_m.warehouse_no%type,
                               strOutStockNo   odata_outstock_m.outstock_no%type,
                               strWorkerNo     odata_outstock_m.rgst_name%type,
                               strResult       out varchar2);
  /*************************************************************************************************
    创建人：wyf
    创建时间：2015.08.01
    功能说明：过季转应季整理扫描标签获取信息找目的储位
  **************************************************************************************************/
  PROCEDURE P_HM_SEASON_OUT2IN_GETDCELLNO(strEnterPriseNo   in stock_content.enterprise_no%type,
                                          strWarehouseNo    in stock_content.warehouse_no%type,
                                          strLabelNo        in stock_content.warehouse_no%type,
                                          strPrinterGroupNo in STOCK_LABEL_ARRANGE_LOG.printer_group_no%type,
                                          strDockNo         in STOCK_LABEL_ARRANGE_LOG.dock_no%type,
                                          strUserID         in STOCK_LABEL_ARRANGE_LOG.rgst_name%type,
                                          strResult         out varchar2);
  PROCEDURE P_HM_SEASON_OUT2IN_ARRANGE(strEnterPriseNo   in odata_outstock_d.enterprise_no%type,
                                       strWarehouseNo    in odata_outstock_d.warehouse_no%type,
                                       strOwnerNo        in odata_outstock_d.owner_no%type,
                                       strSCellNo        in odata_outstock_d.S_Cell_No%type,
                                       strLabelNo        in odata_outstock_d.label_no%type, --来源标签
                                       strArticleNo      in odata_outstock_d.article_no%type,
                                       nPackingQty       in stock_content.packing_qty%type,
                                       dtProduceDate     in varchar2,
                                       dtExpireDate      in varchar2,
                                       strQUALITY        in stock_article_info.quality%type,
                                       strLotNo          in stock_article_info.lot_no%type, --批次号
                                       nPlanQty          in odata_outstock_d.article_qty%type,
                                       nQty              in odata_outstock_d.real_qty%type,
                                       strDCellNo        in odata_outstock_d.d_Cell_No%type,
                                       strPrinterGroupNo in STOCK_LABEL_ARRANGE_LOG.printer_group_no%type,
                                       strDockNo         in STOCK_LABEL_ARRANGE_LOG.dock_no%type,
                                       strUserID         in STOCK_LABEL_ARRANGE_LOG.rgst_name%type,
                                       strResult         out varchar2);
  /*************************************************************************************************
    创建人：wyf
    创建时间：2015.08.01
    功能说明：获取库存记标签--应季转过季扫描
    获取库存，记库存预上预下
  **************************************************************************************************/
  PROCEDURE P_HM_STOCKSETLABEL_SCAN(strEnterPriseNo   in stock_content.enterprise_no%type,
                                    strWarehouseNo    in stock_content.warehouse_no%type,
                                    strOwnerNo        in stock_content.owner_no%type,
                                    strSCellNo        in stock_content.cell_no%type,
                                    strInSourceNo     in STOCK_LABEL_ARRANGE_LOG.SOURCE_NO%type,
                                    strInLabelNo      in stock_content.label_no%type,
                                    strSLabelNo       in stock_content.label_no%type,
                                    strArticleNo      in stock_content.article_no%type,
                                    nPackingQty       in stock_content.packing_qty%type,
                                    dtProduceDate     in varchar2,
                                    dtExpireDate      in varchar2,
                                    strQUALITY        in stock_article_info.quality%type,
                                    strLotNo          in stock_article_info.lot_no%type, --批次号
                                    nQty              in stock_content.qty%type,
                                    strPrinterGroupNo in STOCK_LABEL_ARRANGE_LOG.PRINTER_GROUP_NO%type,
                                    strDockNo         in STOCK_LABEL_ARRANGE_LOG.DOCK_NO%type,
                                    strUserID         in stock_content.rgst_name%type,
                                    strOutLabelNo     out stock_content.label_no%type, --来源标签
                                    strOutSourceNo    out STOCK_LABEL_ARRANGE_LOG.SOURCE_NO%type,
                                    strResult         out varchar2);
  /*************************************************************************************************
    创建人：wyf
    创建时间：2015.08.01
    功能说明：库存记标签--应季转过季封箱
  **************************************************************************************************/
  PROCEDURE P_HM_STOCKSETLABEL_CLOSEBOX(strEnterPriseNo  in stock_content.enterprise_no%type,
                                        strWarehouseNo   in stock_content.warehouse_no%type,
                                        strOwnerNo       in stock_content.owner_no%type,
                                        strSourceNo      in STOCK_LABEL_ARRANGE_LOG.Source_No%type,
                                        strLabelNo       in STOCK_LABEL_ARRANGE_LOG.label_no%type, --标签
                                        strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                                        strUserID        in stock_content.rgst_name%type,
                                        strResult        out varchar2);

end PKLG_MDATA;


/

