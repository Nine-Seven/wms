create function f_get_workname(v_enterpriseno in varchar2, v_workno in varchar2)
    return varchar2
    is
    v_text            VARCHAR(256);
    begin
       select w.worker_name into v_text from bdef_defworker w where w.enterprise_no=v_enterpriseno and w.worker_no = v_workno;
       return v_text;
    end;


/

