create package PKLG_IDATA is

  -- Author  : LUO
  -- Created : 2013-10-07 9:50:17
  -- Purpose :

  -- Public type declarations
  /************************************************************************************************
       功能：集单
       日期：2015-07-03
       chensr
  *************************************************************************************************/
  procedure p_single_set(v_EnterpriseNo      in idata_import_m.enterprise_no%type,
                         v_WarehouseNo       in idata_import_m.warehouse_no%type,
                         v_Import_No         in idata_import_m.import_no%type,
                         v_OldSImportNo      in idata_import_mm.s_import_no%type, --原汇总单号
                         v_RgstName          in idata_import_mm.rgst_name%type,
                         v_strNewS_Import_No OUT Idata_Import_Mm.S_IMPORT_NO%type, --返回的汇总单号
                         v_OutMsg            out varchar2);

  /************************************************************************************************
       修改人：chensr
       日期：2015-01-27
       功能：进货预约

  *************************************************************************************************/
  procedure p_Idata_Order_Time(v_EnterpriseNo      in idata_import_m.enterprise_no%type,
                               v_WarehouseNo       in idata_import_m.warehouse_no%type,
                               v_Import_No         in idata_import_m.import_no%type,
                               v_Request_Date      in idata_order_status.request_date%type,
                               v_Start_Time        in idata_order_status.start_time%type,
                               v_End_Time          in idata_order_status.end_time%type,
                               v_FirstFlag         in odata_locate_m.SOURCE_TYPE%type, --是否第一张单；0：否；1：是
                               v_OldSImportNo      in idata_import_mm.s_import_no%type, --原汇总单号
                               v_RgstName          in idata_import_mm.rgst_name%type,
                               v_strWorkSpaceNo    in idata_check_m.dock_no%type,
                               v_strDockNo         in idata_order_status.dock_no%type,
                               v_printFlag         in varchar2,
                               v_strNewS_Import_No OUT Idata_Import_Mm.S_IMPORT_NO%type, --返回的汇总单号
                               v_OutMsg            out varchar2);

  /*\*************************************************************************************************
       修改人：luozhiling
       日期：2013-10-20
       功能：验收确认

  *************************************************************************************************\
  procedure P_idata_comfireCheck(strWAREHOUSE_NO in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码)
                                 strS_import_no  in idata_check_m.s_import_no%type, --进货汇总单号
                                 strS_Check_no   in idata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                 strWorkerNo     in idata_check_pal_tmp.rgst_name%type, --操作人
                                 strDockNo       in bset_printer_workstation.workstation_no%type, --工作站号
                                 strResult       Out varchar2);     */
  /*  procedure P_idata_import(strWareHouseNo  in idata_import_tmp.warehouse_no%type,
  strResult    out   varchar2);*/

  /************************************以下是从pklg_idata_lich包合并而来*******************/
  /**********************************************************************************
  lich
  2014-04-23
  功能说明：普通保存验收数据
  **********************************************************************************/
  procedure P_SaveCheckDataIS(strEnterpriseNo   in idata_check_m.enterprise_no%type,
                              strWareHouseNo    in idata_check_m.warehouse_no%type,
                              strOwnerNo        in idata_check_m.owner_no%type,
                              strsImportNo      in idata_check_m.s_import_no%type, --进货汇总单号
                              strArticleNo      in idata_check_d.article_no%type,
                              strBarcode        in idata_check_d.barcode%type,
                              nPackingQty       in idata_check_d.packing_qty%type,
                              nCheckQty         in idata_check_d.check_qty%type,
                              strPrinterGroupNo in idata_check_m.printer_group_no%type, --工作站
                              strDockNo         in idata_check_m.dock_no%type, --码头
                              strWorkerNo       in idata_check_m.rgst_name%type, --操作人
                              strCheckTools     in idata_check_m.check_tools%type, --验收工具
                              nIsAdd            in integer, --是否累加 0:覆盖 1:累加
                              --strBatchSerialNo  in idata_check_d.batch_serial_no%type,
                              --strItemType       in idata_check_d.item_type%type,--商品类型
                              strQuality      in idata_check_d.quality%type, --品质
                              dtProduceDate   in idata_check_d.produce_date%type,
                              dtExpireDate    in idata_check_d.expire_date%type,
                              strLotNo        in idata_check_d.lot_no%type,
                              strRSV_BATCH1   in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                              strRSV_BATCH2   in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                              strRSV_BATCH3   in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                              strRSV_BATCH4   in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                              strRSV_BATCH5   in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                              strRSV_BATCH6   in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                              strRSV_BATCH7   in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                              strRSV_BATCH8   in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                              strTemperature  in idata_check_pal_tmp.temperature%type, --温度
                              strLabelNo      in stock_label_m.label_no%type,
                              strSupLabelNo   in idata_check_pal_tmp.sub_label_no%type, --子标签号
                              strFixPalFlag   in idata_check_pal.Fixpal_Flag%type, --1：固定板号；2：流水板号;
                              strBusinessType in idata_check_pal.Fixpal_Flag%type, --业务类型：0-普通验收；1-直通验收；2-大批量验收；3-客户别；5-越库；6-B/C品
                              strsCheckNo     out idata_check_m.s_check_no%type,
                              strResult       out varchar2);

  /***********************************************************************************************
  lich
  2014.04.23
  功能：封板验收主程序
  ***********************************************************************************************/
  procedure P_Close_Pal_Main(strEnterprise  in idata_check_pal_tmp.enterprise_no%type, --企业
                             strWareHouseNo in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                             strOwnerNo     in idata_check_pal_tmp.owner_no%type, --委托业主编码
                             strsImportNo   in idata_check_m.s_import_no%type, --进货汇总单号
                             strsCheckNo    in idata_check_pal_tmp.s_check_no%type, --验收汇总单号
                             strLabelNo     in idata_check_pal_tmp.label_no%type, --板号
                             strWorkerNo    in idata_check_pal_tmp.rgst_name%type, --操作人
                             strFixPalFlag  in idata_check_pal.Fixpal_Flag%type, --1：固定板号；2：流水板号;3：固定流水混合验收
                             strResult      out varchar2);

  /*************************************************************************************************
     作者:lich
     日期:  2013-10-30
     功能: 固定板人工封板
  *************************************************************************************************/
  procedure P_CheckSplitPal_Fixed(strEnterpriseNo in idata_check_pal_tmp.enterprise_no%type,
                                  strWareHouseNo  in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                  strOwnerNo      in idata_check_pal_tmp.owner_no%type, --委托业主编码
                                  strSimportNo    in idata_check_m.s_import_no%type, --进货汇总单号
                                  strSCheckNo     in idata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                  strLabelNo      in idata_check_pal_tmp.label_no%type, --板号
                                  strWorkerNo     in idata_check_pal_tmp.rgst_name%type, --操作人
                                  strResult       out varchar2);

  /*************************************************************************************************
     作者:lich
     日期:  2013-10-30
     功能: 拆板(流水板)
  *************************************************************************************************/
  procedure P_CheckSplitPal_Qlide(strEnterpriseNo in idata_check_pal_tmp.enterprise_no%type,
                                  strWareHouseNo  in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                  strOwnerNo      in idata_check_pal_tmp.owner_no%type, --委托业主编码
                                  strSimportNo    in idata_check_m.s_import_no%type, --进货汇总单号
                                  strSCheckNo     in idata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                  strLabelNo      in idata_check_pal_tmp.label_no%type, --板号
                                  strWorkerNo     in idata_check_pal_tmp.rgst_name%type, --操作人
                                  strResult       out varchar2);
  /************************************************************************************************
   功能说明：超量验收配量
  ************************************************************************************************/
  procedure P_OverQtyMixAmount(strEnterpriseNo  in idata_check_pal_tmp.enterprise_no%type,
                               strWareHouseNo   in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                               strOwnerNo       in idata_check_pal_tmp.owner_no%type, --委托业主
                               strSimportNo     in idata_check_m.s_import_no%type, --进货汇总单号
                               strSCheckNo      in idata_check_pal_tmp.s_check_no%type, --验收汇总单号
                               strLabelNo       in idata_check_pal_tmp.label_no%type, --扫描的原板号，若没有默认N
                               strNewLabelNo    in idata_check_pal_tmp.label_no%type, --新取板号，流水板验收时用
                               strNewSubLabelNo in idata_check_pal_tmp.sub_label_no%type, --新子容器板号，流水板验收时用
                               strContainerNo   in idata_check_pal.container_no%type,
                               nCheckQty        in idata_check_pal_tmp.check_qty%type,
                               nRowId           in idata_check_pal_tmp.row_id%type,
                               strWorkerNo      idata_check_pal_tmp.rgst_name%type, --操作人
                               strResult        out varchar2);
  /************************************************************************************************
  lich
  2014-04-23
  说明：根据临时板明细写验收数据
  ***********************************************************************************************/
  procedure p_idata_MixAmount(strEnterpriseNo  in idata_check_pal_tmp.enterprise_no%type,
                              strWareHouseNo   in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                              strOwnerNo       in idata_check_pal_tmp.owner_no%type, --委托业主
                              strSimportNo     in idata_check_m.s_import_no%type, --进货汇总单号
                              strSCheckNo      in idata_check_pal_tmp.s_check_no%type, --验收汇总单号
                              strLabelNo       in idata_check_pal_tmp.label_no%type, --扫描的原板号，若没有默认N
                              strNewLabelNo    in idata_check_pal_tmp.label_no%type, --新取板号，流水板验收时用
                              strNewSubLabelNo in idata_check_pal_tmp.sub_label_no%type, --新子容器板号，流水板验收时用
                              strContainerNo   in idata_check_pal.container_no%type,
                              nCheckQty        in idata_check_pal_tmp.check_qty%type,
                              nRowId           in idata_check_pal_tmp.row_id%type,
                              strWorkerNo      in idata_check_pal_tmp.rgst_name%type, --操作人
                              nRemainQty       out idata_check_d.check_qty%type, --剩余验收量
                              strResult        out varchar2);

  /***********************************************************************************************
  修改人:lich
  日期:2014-04-24
  功能：根据验收汇总单写标签数据、定位指示和库存
  ************************************************************************************************/
  procedure p_idata_sCheckLocateInstock(strEnterpriseNo    in stock_label_m.enterprise_no%type, --企业
                                        strWareHouseNo     in stock_label_m.warehouse_no%type, --仓别
                                        strScheckNo        in idata_check_pal.s_check_no%type, --汇总验收单号
                                        strUser_ID         in stock_label_m.Rgst_Name%type, --操作人员
                                        strCheckTool       in idata_check_pal_tmp.check_tools%type, --验收工具
                                        strspecify_cell_no in idata_locate_direct.specify_cell_no%type, --指定储位
                                        strLabelNo         in idata_check_pal.label_no%type, --板号
                                        strLocateNo        OUT idata_locate_direct.locate_no%type,
                                        strOutMsg          out varchar2);
  /*************************************************************************************************
       修改人：luozhiling
       日期：2013-10-20
       功能：验收确认,验收确认,可支持一单一验，一单多验和一品多验,可直接对进货单做结案
  *************************************************************************************************/
  procedure P_Comfire_Idata_Check(strEnterprise_No in idata_check_pal_tmp.enterprise_no%type,
                                  strWAREHOUSE_NO  in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码)
                                  strS_import_no   in idata_check_m.s_import_no%type, --进货汇总单号
                                  strS_Check_no    in idata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                  strWorkerNo      in idata_check_pal_tmp.rgst_name%type, --操作人
                                  strUnloadWorker  in idata_check_m.unload_worker%type, --卸货人
                                  strDockNo        in pntset_printer_workstation.workstation_no%type, --工作站号
                                  strResult        Out varchar2);
  /*************************************************************************************************
       创建人：hekl
       日期：2015-09-17
       功能：验收确认,可支持一单一验，一单多验和一品多验,天天惠
             1、验收确认
             2、将进货单明细总量小于10的单据结案（包括汇总单）
  *************************************************************************************************/
  procedure P_Comfire_Idata_Check_tth(strEnterprise_No in idata_check_pal_tmp.enterprise_no%type, --企业
                                      strWAREHOUSE_NO  in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码)
                                      strS_import_no   in idata_check_m.s_import_no%type, --进货汇总单号
                                      strS_Check_no    in idata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                      strPoNo          in idata_import_m.po_no%type, --采购单号
                                      strWorkerNo      in idata_check_pal_tmp.rgst_name%type, --操作人
                                      strUnloadWorker  in idata_check_m.unload_worker%type, --卸货人
                                      strDockNo        in pntset_printer_workstation.workstation_no%type, --工作站号
                                      strResult        Out varchar2);

  /*************************************************************************************************
       修改人：lich
       日期：2013-05-06
       功能：上架回单
  *************************************************************************************************/
  procedure p_Save_Idata_InStock(strEnterpriseNo in idata_instock_m.enterprise_no%type,
                                 strWareHouseNo  in idata_instock_m.warehouse_no%type,
                                 strInstockNo    in idata_instock_m.instock_no%type,
                                 strDestCellNo   in idata_instock_d.dest_cell_no%type,
                                 strRealCellNo   in idata_instock_d.real_cell_no%type,
                                 strLabelNo      in idata_instock_d.label_no%type,
                                 strArticleNo    in idata_instock_d.article_no%type,
                                 dtProduceDate   in idata_check_d.produce_date%type,
                                 dtExpireDate    in idata_check_d.expire_date%type,
                                 strQuality      in idata_check_d.quality%type, --品质
                                 strLotNo        in idata_check_d.lot_no%type, --批次号
                                 strRSV_BATCH1   in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                                 strRSV_BATCH2   in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                                 strRSV_BATCH3   in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                                 strRSV_BATCH4   in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                                 strRSV_BATCH5   in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                                 strRSV_BATCH6   in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                                 strRSV_BATCH7   in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                                 strRSV_BATCH8   in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                                 nPackingQty     in idata_instock_d.packing_qty%type,
                                 nArticleQty     in idata_instock_d.article_qty%type,
                                 nRealQty        in idata_instock_d.real_qty%type,
                                 strUserId       in idata_instock_m.rgst_name%type, --上架人
                                 strPaperUserId  in idata_instock_m.rgst_name%type, --回单人
                                 strTools        in stock_content_move.terminal_flag%type,
                                 nIsAddFlag      in integer, --是否新增记录 1是0否
                                 strResult       out varchar2);
  /*************************************************************************************************
       修改人：lich
       日期：2013-05-06
       功能：上架回单确认

  *************************************************************************************************/
  procedure p_Comfire_Idata_InStock(strEnterpriseNo in idata_instock_m.enterprise_no%type,
                                    strWareHouseNo  in idata_instock_m.warehouse_no%type,
                                    strInstockNo    in idata_instock_m.instock_no%type,
                                    strUserId       in idata_instock_m.rgst_name%type, --上架人
                                    strPaperUserId  in idata_instock_m.rgst_name%type, --回单人
                                    strTools        in stock_content_move.terminal_flag%type,
                                    strResult       out varchar2);
  /*************************************************************************************************
       修改人：lich
       日期：2013-06-23
       功能：Rf上架回单确认

  *************************************************************************************************/
  procedure p_RfComfire_Idata_InStock(strEnterpriseNo in idata_instock_m.enterprise_no%type,
                                      strWareHouseNo  in idata_instock_m.warehouse_no%type,
                                      strInstockNo    in idata_instock_m.instock_no%type,
                                      strUserId       in idata_instock_m.rgst_name%type, --上架人
                                      strPaperUserId  in idata_instock_m.rgst_name%type, --回单人
                                      strResult       out varchar2);
  /**********************************************************************************************************
     lich
     2014.06.05
     功能：校验能否验收
  ***********************************************************************************************************/
  procedure P_CheckExists(strEnterpriseNo in idata_check_m.enterprise_no%type, --企业
                          strWareHouseNo  in idata_check_m.warehouse_no%type, --仓库编码
                          strOwnerNo      in idata_import_mm.Owner_No%type, --进货汇总单号
                          strSimportNo    in idata_import_mm.s_import_no%type, --进货汇总单号
                          strArticleNo    in idata_check_d.article_no%type, --商品编码
                          strPackingQty   in idata_check_d.packing_qty%type, --商品条码
                          dtProduceDate   in idata_check_d.produce_date%type, --生产日期
                          dtExpireDate    in idata_check_d.expire_date%type, --到期日期
                          nCheckQty       in idata_check_d.check_qty%type, --验收数量
                          strOverFlag     in varchar2, --超品标识，0-正常；1-超品
                          strPromptType   out varchar2, --提示类型1：报警 2冻结 3超量
                          strPromptFlag   out varchar2, --处理方式1：拦截，不允许验入；2：提醒，但可强制验入；3：授权
                          strResult       OUT varchar2);
  /**********************************************************************************************************
     zhouhuan
     2014.4.22
     功能：上架发单
  ***********************************************************************************************************/
  procedure P_InsertInstock(strEnterpriseNo in idata_instock_direct.enterprise_no%type,
                            strWareHouseNo  in idata_instock_direct.warehouse_no%type, --仓别
                            strWorkerNo     in idata_instock_direct.rgst_name%type, --操作人
                            strLocateNo     in idata_instock_direct.locate_no%type, --定位单号
                            strDockNo       in pntset_printer_workstation.workstation_no%type, --工作站号
                            strPrintType    in job_printtask_m.task_type%type, --0:不打印；1:打印报表；2：打印标签
                            strInstockNo    out idata_instock_d.instock_no%type, --上架单号
                            strResult       out varchar2);

  /**************************************************************************************************
  创建人：luozhiling
  创建日期:2014.12.24
  功能说明：整单上架回单
  ***************************************************************************************************/
  procedure P_saveInstockAll(strEnterpriseNo in idata_instock_m.enterprise_no%type,
                             strWarehouseNo  in idata_instock_m.warehouse_no%type,
                             strInstockNo    in idata_instock_m.instock_no%type,
                             strUserId       in idata_instock_m.rgst_name%type, --上架人
                             strPaperUserId  in idata_instock_m.rgst_name%type, --回单人
                             strTools        in stock_content_move.terminal_flag%type,
                             strResult       out varchar2);
  /*****************************************************************************************************
  创建人：luozhiling
  创建时间：2014.10.25.
  功能说明：对上架标签做标签销毁：
  1、未确认标签：修改验收数量，对上架的业务单据做取消，扣减库存
  2、已确认标签：对上架单做回单，并将库存移至销毁区。
  *****************************************************************************************************/
  procedure P_instock_Label_Cancel(strEnterpriseNo in stock_label_m.enterprise_no%type,
                                   strWareHouseNo  in stock_label_m.warehouse_no%type,
                                   strLabelNo      in stock_label_m.label_no%type,
                                   strWorkerNo     in stock_label_m.rgst_name%type,
                                   strResult       out varchar2);
  /*****************************************************************************************************
  创建人：luozhiling
  创建时间：2014.10.25.
  功能说明：对未分播回单的标签进行分播单处理
            1、将对应的分播明细数据置未16
           注意：需考虑存储的分播标签和直通的分播标签
  *****************************************************************************************************/

  procedure P_DivideLabelCancel(strEnterpriseNo in stock_label_m.enterprise_no%type,
                                strWareHouseNo  in stock_label_m.warehouse_no%type,
                                strContainerNo  in stock_label_m.label_no%type, --内部容器号
                                strWorkerNo     in stock_label_m.rgst_name%type,
                                strResult       out varchar2);
  /*****************************************************************************************************
  创建人：luozhiling
  创建时间：2014.10.25.
  功能说明：对客户标签做标签销毁：
            1、根据标签明细判断是否是直通或存储；
            2、如果是存储标签直接将库存转移到销毁区，并且做标签销毁，如果是直通的客户标签，需要判断验收单的状态，
            并且根据验收单状态来判断是否做销毁或验收还原。
  *****************************************************************************************************/

  procedure P_Cust_Label_Cancel(strEnterpriseNo in stock_label_m.enterprise_no%type,
                                strWareHouseNo  in stock_label_m.warehouse_no%type,
                                strLabelNo      in stock_label_m.label_no%type,
                                strWorkerNo     in stock_label_m.rgst_name%type,
                                strResult       out varchar2);
  /*****************************************************************************************************
  创建人：luozhiling
  创建时间：2014.10.25.
  功能说明：对已经被并板或者并板的标签做销毁：，
            1、如果是存储标签直接将库存转移到销毁区，并且做标签销毁，
  *****************************************************************************************************/

  procedure P_LoadPal_Cancel(strEnterpriseNo in stock_label_m.enterprise_no%type,
                             strWareHouseNo  in stock_label_m.warehouse_no%type,
                             strLabelNo      in stock_label_m.label_no%type,
                             strWorkerNo     in stock_label_m.rgst_name%type,
                             strDestCellNo   in stock_label_m.owner_cell_no%type, --目的储位
                             strPaperNo      in stock_label_m.source_no%type, --销毁单号
                             strResult       out varchar2);
  /***********************************************************************************************************
   创建人：luozhiling
   创建时间：2014.10.27
   功能说明：标签销毁时校验标签是否可做销毁
  **********************************************************************************************************/
  procedure PROC_Check_LABEL_CANCEL(strEnterpriseNo in stock_label_m.enterprise_no%type,
                                    strWareHouseNo  in stock_label_m.warehouse_no%type,
                                    strLabelNo      in stock_label_m.label_no%type,
                                    strResult       out varchar2);
  /*****************************************************************************************************
   创建人：luozhiling
   创建时间:2016.3.21
   功能说明：对标签上的单SKU部分做销毁的校验
             1、只能是客户标签才允许做销毁
  ******************************************************************************************************/
  procedure Proc_CheckSku_Label_cancel(strEnterpriseNo     in stock_label_m.enterprise_no%type,
                                       strWareHouseNo      in stock_label_m.warehouse_no%type,
                                       strLabelNo          in stock_label_m.label_no%type,
                                       strLabelProduceFlag out wms_defbase.ndefine%type,
                                       strResult           out varchar2);

  /**********************************************************************************************************
      创建人：luozhiling
      创建时间：2014.10.27
      功能说明：标签销毁，包含存储和直通标签的销毁
  **********************************************************************************************************/
  procedure PROC_LABEL_CANCEL(strEnterpriseNo in stock_label_m.enterprise_no%type,
                              strWareHouseNo  in stock_label_m.warehouse_no%type,
                              strLabelNo      in stock_label_m.label_no%type,
                              strWorkerNo     in stock_label_m.rgst_name%type,
                              strResult       out varchar2);
  /**********************************************************************************************************
      创建人：luozhiling
      创建时间：2016.3.21
      功能说明：对标签上的某个SKU进行销毁，只能处理客户标签，需支持直通和存储的标签,考虑生产日期等属性
  **********************************************************************************************************/
  procedure P_Sku_lab_cancel(strEnterpriseNo     in stock_label_m.enterprise_no%type,
                             strWareHouseNo      in stock_label_m.warehouse_no%type,
                             strLabelNo          in stock_label_m.label_no%type,
                             strArticleNo        in stock_label_d.article_no%type,
                             nPackingQty         in stock_content.packing_qty%type,
                             dtProduceDate       in stock_article_info.produce_date%type,
                             dtExpireDate        in stock_article_info.expire_date%type,
                             nCancelQty          in stock_label_d.qty%type,
                             strWorkerNo         in stock_label_m.rgst_name%type,
                             strLabelProduceFlag in wms_defbase.sdefine%type, ---0:不管生产日期；1:管生产日期
                             strResult           out varchar2);

  /*************************************************************************************************
   创建人：luozhiling
   创建时间：2014.12.14
   功能说明：对采购单进行取消
  **************************************************************************************************/
  procedure P_import_cancel(strEnterpriseNo in stock_label_m.enterprise_no%type,
                            strWareHouseNo  in idata_import_m.warehouse_no%type,
                            strOwnerNo      in idata_import_m.owner_no%type,
                            strImportNo     in idata_import_m.import_no%type,
                            strUserID       in idata_import_m.updt_name%type,
                            strResult       out varchar2);

  /*************************************************************************************************
  创建人：luozhiling
  创建时间：2014.12.24
  功能说明：1、指定储位验收、上架
  ***************************************************************************************************/
  procedure P_checkDirectCell(strEnterpriseNo in idata_check_pal_tmp.enterprise_no%type,
                              strWareHouseNo  in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                              strOwnerNo      in idata_check_pal_tmp.owner_no%type, --委托业主编码
                              strsImportNo    in idata_check_m.s_import_no%type, --进货汇总单号
                              strsCheckNo     in idata_check_pal_tmp.s_check_no%type, --验收汇总单号
                              strCellNo       in idata_locate_direct.cell_no%type, --板号
                              strDockNo       in idata_check_m.dock_no%type,
                              strWorkerNo     in idata_check_pal_tmp.rgst_name%type, --操作人
                              strResult       out varchar2);
  /*****************************************************************************************************************
  lich
  20150209
  功能说明：验收作业，标签号校验
  ***************************************************************************************************************/
  procedure P_CheckLabelNo(strEnterpriseNo in idata_check_m.enterprise_no%type,
                           strWarehouseNo  in idata_check_m.warehouse_no%type,
                           strLabelNo      in stock_label_m.label_no%type,
                           strSImportNo    in idata_check_m.s_import_no%type,
                           strOutMsg       out varchar2);
  /***********************************************************************************************
  lich
  2015.02.09
  功能：RF封板验收
  ***********************************************************************************************/
  procedure P_RF_Close_Pal(strEnterpriseNo in idata_check_pal_tmp.enterprise_no%type, --企业
                           strWareHouseNo  in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                           strOwnerNo      in idata_check_pal_tmp.owner_no%type, --委托业主编码
                           strsImportNo    in idata_check_m.s_import_no%type, --进货汇总单号
                           strsCheckNo     in idata_check_pal_tmp.s_check_no%type, --验收汇总单号
                           strLabelNo      in idata_check_pal_tmp.label_no%type, --板号
                           strWorkerNo     in idata_check_pal_tmp.rgst_name%type, --操作人
                           strPrintType    in job_printtask_m.task_type%type, ----0:不打印；1:打印报表；2：打印标签
                           strFixPalFlag   in idata_check_pal.Fixpal_Flag%type, --1：固定板号；2：流水板号;3：固定流水混合验收
                           strDockNo       in pntset_printer_workstation.workstation_no%type, --工作站号
                           strResult       out varchar2);
  /**********************************************************************************
  lich
  2015-02-09
  功能说明：RF保存验收数据
  **********************************************************************************/
  procedure P_RF_SaveCheckDataIS(strEnterpriseNo   in idata_check_m.enterprise_no%type,
                                 strWareHouseNo    in idata_check_m.warehouse_no%type,
                                 strOwnerNo        in idata_check_m.owner_no%type,
                                 strsImportNo      in idata_check_m.s_import_no%type, --进货汇总单号
                                 strArticleNo      in idata_check_d.article_no%type,
                                 strBarcode        in idata_check_d.barcode%type,
                                 nPackingQty       in idata_check_d.packing_qty%type,
                                 nCheckQty         in idata_check_d.check_qty%type,
                                 strPrinterGroupNo in idata_check_m.printer_group_no%type, --工作站
                                 strDockNo         in idata_check_m.dock_no%type, --码头
                                 strWorkerNo       in idata_check_m.rgst_name%type, --操作人
                                 strCheckTools     in idata_check_m.check_tools%type, --验收工具
                                 nIsAdd            in integer, --是否累加 0:覆盖 1:累加
                                 strQuality        in idata_check_d.quality%type, --品质
                                 dtProduceDate     in idata_check_d.produce_date%type,
                                 dtExpireDate      in idata_check_d.expire_date%type,
                                 strLotNo          in idata_check_d.lot_no%type, --批次号
                                 strRSV_BATCH1     in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                                 strRSV_BATCH2     in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                                 strRSV_BATCH3     in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                                 strRSV_BATCH4     in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                                 strRSV_BATCH5     in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                                 strRSV_BATCH6     in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                                 strRSV_BATCH7     in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                                 strRSV_BATCH8     in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                                 nTemperature      in idata_check_pal_tmp.temperature%type, --温度
                                 strLabelNo        in stock_label_m.label_no%type, --实体标签号
                                 strSupLabelNo     in idata_check_pal_tmp.sub_label_no%type, --子标签号
                                 strPrintType      in job_printtask_m.task_type%type, ----0:不打印；1:打印报表；2：打印标签
                                 strFixPalFlag     in idata_check_pal.Fixpal_Flag%type, --1：固定板号；2：流水板号;
                                 strBusinessType   in idata_check_pal.Fixpal_Flag%type, --业务类型：0-普通验收；1-直通验收；2-大批量验收；3-客户别；5-越库；6-B/C品
                                 strCheckType      in varchar2,
                                 strsCheckNo       out idata_check_m.s_check_no%type,
                                 strResult         out varchar2);

  /**************************************************************************************************
  功能说明：
          1、适用于天天惠的直通扫描验收数据保存。
          2、预配数量；
          3、写临时表；
   创建人：weiyufei
   创建时间：2015.6.30
  ***************************************************************************************************/
  procedure P_SCAN_IDCHECK_TTH(strEnterpriseNo   in idata_check_m.enterprise_no%type,
                               strWareHouseNo    in idata_check_m.warehouse_no%type,
                               strOwnerNo        in idata_check_m.owner_no%type,
                               strsImportNo      in idata_check_m.s_import_no%type, --进货汇总单号
                               strArticleNo      in idata_check_d.article_no%type,
                               strBarcode        in idata_check_d.barcode%type,
                               nPackingQty       in idata_check_d.packing_qty%type,
                               nCheckQty         in idata_check_d.check_qty%type,
                               strPrinterGroupNo in idata_check_m.printer_group_no%type, --工作站
                               strDockNo         in idata_check_m.dock_no%type, --码头
                               strWorkerNo       in idata_check_m.rgst_name%type, --操作人
                               strCheckTools     in idata_check_m.check_tools%type, --验收工具
                               nIsAdd            in integer, --是否累加 0:覆盖 1:累加
                               strQuality        in idata_check_d.quality%type, --品质
                               dtProduceDate     in idata_check_d.produce_date%type,
                               dtExpireDate      in idata_check_d.expire_date%type,
                               strLotNo          in idata_check_d.lot_no%type, --批次号
                               strRSV_BATCH1     in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                               strRSV_BATCH2     in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                               strRSV_BATCH3     in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                               strRSV_BATCH4     in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                               strRSV_BATCH5     in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                               strRSV_BATCH6     in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                               strRSV_BATCH7     in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                               strRSV_BATCH8     in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                               strLabelNo        in stock_label_m.label_no%type, --实体标签号
                               strSubLabelNo     in idata_check_pal_tmp.sub_label_no%type, --子标签号
                               strFixPalFlag     in idata_check_pal.Fixpal_Flag%type, --1：固定板号；2：流水板号;
                               strBusinessType   in idata_check_pal.Business_Type%type, --业务类型：0-普通验收；1-直通验收；2-大批量验收；3-客户别；5-越库；6-B/C品
                               strsCheckNo       out idata_check_m.s_check_no%type,
                               strResult         out varchar2);

  /**********************************************************************************************************
     hekl
     2015.07.13
     功能：进货单据失效
  ***********************************************************************************************************/
  procedure p_idata_expired(strEnterPriseNo in fcdata_plan_m.enterprise_no%type,
                            strWareHouseNo  in fcdata_plan_m.warehouse_no%type, --仓库编码
                            strResult       OUT varchar2);

  /**********************************************************************************************************
     hekl
     2015.08.01
     功能：进货单据失效,用于天天惠一单多验自动结案，不需回传ERP状态
  ***********************************************************************************************************/
  procedure p_idata_expired_tth(strEnterPriseNo in fcdata_plan_m.enterprise_no%type,
                                strWareHouseNo  in fcdata_plan_m.warehouse_no%type, --仓库编码
                                strResult       OUT varchar2);

  /**********************************************************************************************************
     hcx
     2015.08.17
     功能：移动台车验收-客户与电子标签储位校验
  ***********************************************************************************************************/
  procedure P_CheckDpsCellNo(strEnterpriseNo in idata_import_allot.enterprise_no%type,
                             strWarehouseNo  in idata_import_allot.warehouse_no%type,
                             strImportNo     in idata_import_allot.import_no%type,
                             strArticleNo    in idata_import_allot.article_no%type,
                             strResult       out varchar2);

  /**********************************************************************************************************
     sl
     2016.03.14
     功能：直通验收封板后 打印商品信息（小嘴）
  ***********************************************************************************************************/
  procedure P_IDCHECK_PRINT_ARTICLEINFO(strEnterpriseNo in idata_check_m.enterprise_no%type,
                                        strWareHouseNo  in idata_check_m.warehouse_no%type,
                                        strInstockNo    IN idata_instock_d.instock_no%type, --上架单
                                        strDockNo       in idata_check_m.dock_no%type, --码头
                                        strWorkerNo     in idata_check_m.rgst_name%type, --操作人
                                        strResult       out varchar2);

  /*=====================================================================================
  huangb insert to 20160721
  验收差异确认
  ======================================================================================*/
  PROCEDURE p_Check_DiffConfirm(strEnterpriseNo in idata_import_m.enterprise_no%type, --企业号
                                strWarehouseNo  in idata_import_m.warehouse_no%type, --仓别
                                strOwnerNo      in idata_import_m.owner_no%type, --委托业主
                                strImportNo     in idata_import_m.import_no%type, --进货单号
                                strNewPoNo      in idata_import_m.rsv_varod3%type, --海关重新下传的进货原单号
                                strUserId       in stock_label_m.rgst_name%type, --操作人员
                                strOutMsg       out varchar2);

end PKLG_IDATA;


/

