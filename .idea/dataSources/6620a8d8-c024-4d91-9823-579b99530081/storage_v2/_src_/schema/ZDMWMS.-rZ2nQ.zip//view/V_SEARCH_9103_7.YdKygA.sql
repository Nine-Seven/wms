create view V_SEARCH_9103_7 as
select b.enterprise_no,
       b.warehouse_no,
       c.OWNER_NO,
       b.loadpropose_no,
       b.cust_no,
       f.cust_name,
       b.load_name,
       bdw.worker_name,
       a.car_plate,
       b.load_date,
       c.source_no,
       c.exp_no,
       c.article_no,
       e.OWNER_ARTICLE_NO,
       e.article_name,
       e.BARCODE,
       c.packing_qty,
       e.UNIT,
       e.SPEC,
       c.qty,
       trunc(c.qty / c.packing_qty) Box,
       mod(c.qty, c.packing_qty) Dis
  from odata_loadpropose_m a, odata_loadpropose_d b
  left join bdef_defworker bdw
    on b.load_name = bdw.worker_no
   and b.enterprise_no = bdw.enterprise_no, stock_label_dhty c,
 bdef_defarticle e, bdef_defcust f
 where a.LOADPROPOSE_NO = b.LOADPROPOSE_NO
   and a.enterprise_no = b.enterprise_no
   and b.enterprise_no = c.enterprise_no
   and b.container_no = c.container_no
   and c.enterprise_no = e.enterprise_no
   and c.article_no = e.article_no
   and b.enterprise_no = f.enterprise_no
   and b.cust_no = f.cust_no
 order by a.LOADPROPOSE_NO

/

