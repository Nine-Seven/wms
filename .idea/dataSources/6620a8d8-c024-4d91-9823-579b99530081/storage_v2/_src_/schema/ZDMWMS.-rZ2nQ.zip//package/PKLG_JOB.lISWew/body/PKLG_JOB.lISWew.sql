create package body        PKLG_JOB is

  --出货定位任务
  procedure p_out_locate is
    v_strResult varchar2(100);
  begin
    v_strResult := '';
    for v_cs_get_locate_task in (select ot.enterprise_no,
                                        ot.warehouse_no,
                                        ot.wave_no,
                                        ot.task_date,
                                        ot.rgst_name
                                   from odata_locate_task ot) loop

      PKLG_OLOCATE.p_write_log(v_cs_get_locate_task.enterprise_no,
                               v_cs_get_locate_task.warehouse_no,
                               v_cs_get_locate_task.wave_no,
                               '波次【' || v_cs_get_locate_task.wave_no ||
                               '】后台定位开始。',
                               '10');
      PKLG_OLOCATE.p_locate_main(v_cs_get_locate_task.enterprise_no,
                                 v_cs_get_locate_task.warehouse_no,
                                 v_cs_get_locate_task.wave_no,
                                 v_cs_get_locate_task.rgst_name,
                                 v_strResult);
      if substr(v_strResult, 1, 2) = 'N|' then
        --写入日志
        PKLG_OLOCATE.p_write_log(v_cs_get_locate_task.enterprise_no,
                                 v_cs_get_locate_task.warehouse_no,
                                 v_cs_get_locate_task.wave_no,
                                 '波次【' || v_cs_get_locate_task.wave_no ||
                                 '】后台定位失败：' || substr(v_strResult, 3),
                                 '10');
      else
        PKLG_OLOCATE.p_write_log(v_cs_get_locate_task.enterprise_no,
                                 v_cs_get_locate_task.warehouse_no,
                                 v_cs_get_locate_task.wave_no,
                                 '波次【' || v_cs_get_locate_task.wave_no ||
                                 '】后台定位完成。',
                                 '10');
      end if;
      delete odata_locate_task ot
       where ot.enterprise_no = v_cs_get_locate_task.enterprise_no
         and ot.warehouse_no = v_cs_get_locate_task.warehouse_no
         and ot.wave_no = v_cs_get_locate_task.wave_no;
    end loop;
  end p_out_locate;
end PKLG_JOB;

/

