create view V_SEARCH_H102_003 as
select a.enterprise_no,a.warehouse_no,a.owner_no,a.wave_no,a.outstock_no,a.operate_type,a.operate_date,a.updt_date,a.cust_no,bd.cust_name,bw.worker_name,
bd.cust_alias,a.plan_qty,a.real_qty,a.b_plan_qty,a.b_real_qty
from(
select oom.enterprise_no,oom.warehouse_no,oom.owner_no,oom.wave_no,oom.outstock_no,oom.operate_type,oom.operate_date,trunc(oom.updt_date) as updt_date,ood.outstock_name,
ood.cust_no,sum(ood.article_qty/ood.packing_qty)plan_qty,sum(ood.real_qty/ood.packing_qty) real_qty,
sum(ood.article_qty/ood.packing_qty) b_plan_qty,sum(ood.real_qty/ood.packing_qty) b_real_qty
from odata_outstock_m oom,odata_outstock_d ood
where oom.enterprise_no=ood.enterprise_no
and oom.warehouse_no=ood.warehouse_no
and oom.outstock_no=ood.outstock_no and oom.operate_type IN('C','P') and oom.outstock_type='0'
group by oom.enterprise_no,oom.warehouse_no,oom.owner_no,oom.wave_no,oom.outstock_no,oom.operate_type,oom.operate_date,trunc(oom.updt_date),ood.outstock_name,
ood.cust_no
union all
select oom.enterprise_no,oom.warehouse_no,oom.owner_no,oom.wave_no,oom.outstock_no,oom.operate_type,oom.operate_date,trunc(oom.updt_date) as updt_date,ood.outstock_name,
ood.cust_no,sum(ood.article_qty/bd.qmin_operate_packing)plan_qty,sum(ood.real_qty/bd.qmin_operate_packing) real_qty,
count(distinct ood.s_container_no) as b_plan_qty,0 as b_real_qty
from odata_outstock_m oom,odata_outstock_d ood,bdef_defarticle bd
where oom.enterprise_no=ood.enterprise_no
and oom.warehouse_no=ood.warehouse_no
and oom.outstock_no=ood.outstock_no and oom.operate_type='B' and oom.outstock_type='0'
and ood.article_no=bd.article_no
group by oom.enterprise_no,oom.warehouse_no,oom.owner_no,oom.wave_no,oom.outstock_no,oom.operate_type,oom.operate_date,trunc(oom.updt_date),ood.outstock_name,
ood.cust_no
union all
select oom.enterprise_no,oom.warehouse_no,oom.owner_no,oom.wave_no,oom.outstock_no,oom.operate_type,oom.operate_date,trunc(oom.updt_date) as updt_date,ood.outstock_name,
ood.cust_no,sum(ood.article_qty/ood.packing_qty)plan_qty,sum(ood.real_qty/ood.packing_qty) real_qty,
sum(ood.article_qty/ood.packing_qty) b_plan_qty,sum(ood.real_qty/ood.packing_qty) b_real_qty
 from odata_outstock_mhty oom,odata_outstock_dhty ood
where oom.enterprise_no=ood.enterprise_no
and oom.warehouse_no=ood.warehouse_no
and oom.outstock_no=ood.outstock_no and oom.operate_type IN('C','P') and oom.outstock_type='0'
group by oom.enterprise_no,oom.warehouse_no,oom.owner_no,oom.wave_no,oom.outstock_no,oom.operate_type,oom.operate_date,trunc(oom.updt_date),ood.outstock_name,
ood.cust_no
union all
select oom.enterprise_no,oom.warehouse_no,oom.owner_no,oom.wave_no,oom.outstock_no,oom.operate_type,oom.operate_date,trunc(oom.updt_date) as updt_date,ood.outstock_name,
ood.cust_no,sum(ood.article_qty/bd.qmin_operate_packing)plan_qty,sum(ood.real_qty/bd.qmin_operate_packing)  real_qty,
count(distinct ood.s_container_no) as b_plan_qty,count(distinct ood.s_container_no) as b_real_qty
from odata_outstock_mhty oom,odata_outstock_dhty ood,bdef_defarticle bd
where oom.enterprise_no=ood.enterprise_no
and oom.warehouse_no=ood.warehouse_no
and oom.outstock_no=ood.outstock_no and oom.operate_type='B' and oom.outstock_type='0'
and ood.article_no=bd.article_no
group by oom.enterprise_no,oom.warehouse_no,oom.owner_no,oom.wave_no,oom.outstock_no,oom.operate_type,oom.operate_date,trunc(oom.updt_date),ood.outstock_name,
ood.cust_no) a,bdef_defcust bd,bdef_defworker bw
where a.cust_no=bd.cust_no
and bw.enterprise_no(+)=a.enterprise_no
and bw.worker_no(+)=a.outstock_name
order by a.enterprise_no,a.warehouse_no,a.owner_no,a.wave_no,a.operate_date,a.updt_date,a.outstock_no,a.operate_type


/

