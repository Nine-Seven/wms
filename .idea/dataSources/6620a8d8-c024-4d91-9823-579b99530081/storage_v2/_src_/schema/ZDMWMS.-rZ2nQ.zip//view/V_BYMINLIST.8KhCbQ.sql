create view V_BYMINLIST as
select to_date(to_char(m.updt_date,'yyyy-MM-dd'),'yyyy-MM-dd') updt_data,iim.po_no,atc.owner_article_no,atc.article_name,
d.packing_qty,atcp.packing_unit,to_char(d.produce_date,'yyyyMMdd') produce_date,
 sum(d.check_qty) check_qty,0.00 as DM,0.00 as NR,0.00 QA,sum(d.check_qty) sumQty
 from idata_check_m m,idata_check_d d,idata_import_m iim,bdef_defarticle atc,bdef_article_packing atcp
 where m.warehouse_no = d.warehouse_no
   and m.check_no = d.check_no
   and m.warehouse_no = iim.warehouse_no
   and m.import_no = iim.import_no
   and d.owner_no = atc.owner_no
   and d.article_no = atc.article_no
   and atc.article_no = atcp.article_no
   and d.packing_qty = atcp.packing_qty
   and m.warehouse_no in ('001','003')
   and m.owner_no = '001'
   and m.status = '13'
   group by to_date(to_char(m.updt_date,'yyyy-MM-dd'),'yyyy-MM-dd'),iim.po_no,atc.owner_article_no,
   atc.article_name,d.packing_qty,atcp.packing_unit,to_char(d.produce_date,'yyyyMMdd')
 union all
 select to_date(to_char(rcm.updt_date,'yyyy-MM-dd'),'yyyy-MM-dd') updt_date,rum.po_no,atc.owner_article_no,atc.article_name,rcd.packing_qty,atcp.packing_unit,
 to_char(rcd.produce_date,'yyyyMMdd') produce_date,sum(rcd.check_qty) check_qty,0.00 as DM,0.00 as NR,0.00 QA,sum(rcd.check_qty) sumQty
 from ridata_check_m rcm,ridata_check_d rcd,ridata_untread_m rum,bdef_defarticle atc,bdef_article_packing atcp
 where rcm.warehouse_no = rcd.warehouse_no
   and rcm.check_no = rcd.check_no
   and rcm.untread_no = rum.untread_no
   and rcm.warehouse_no = rum.warehouse_no
   and rcd.owner_no = atc.owner_no
   and rcd.article_no = atc.article_no
   and atc.article_no = atcp.article_no
   and rcd.packing_qty = atcp.packing_qty
   and rcm.owner_no = '001'
   and rcm.warehouse_no in ('001','003')
   and rcm.status =13
   group by to_date(to_char(rcm.updt_date,'yyyy-MM-dd'),'yyyy-MM-dd'),rum.po_no,atc.owner_article_no,
   atc.article_name,rcd.packing_qty,atcp.packing_unit,to_char(rcd.produce_date,'yyyyMMdd')

/

