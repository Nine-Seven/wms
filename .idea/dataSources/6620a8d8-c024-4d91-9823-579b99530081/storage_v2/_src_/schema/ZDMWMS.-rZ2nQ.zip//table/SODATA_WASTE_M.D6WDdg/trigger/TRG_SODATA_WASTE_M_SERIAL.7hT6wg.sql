create trigger TRG_SODATA_WASTE_M_SERIAL
    before insert
    on SODATA_WASTE_M
    for each row
declare
  i_report_up_SERIAL NUMBER;
begin
  select SEQ_SODATA_WASTE_M.NEXTVAL into i_report_up_SERIAL from dual;
  :NEW.REPORT_UP_SERIAL := i_report_up_SERIAL;
end TRG_SODATA_WASTE_M_SERIAL;


/

