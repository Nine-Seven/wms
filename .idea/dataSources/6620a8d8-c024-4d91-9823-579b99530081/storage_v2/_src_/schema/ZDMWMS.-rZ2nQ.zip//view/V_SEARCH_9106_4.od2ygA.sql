create view V_SEARCH_9106_4 as
select iim.enterprise_no,
       iim.WAREHOUSE_NO,
       iim.OWNER_NO,
       case iim.po_type when 'IR' then 'E贸易入库' when 'IM' then '验收中' when 'IBC' then '包材入库' when 'IHQ' then '账册结转入区' when 'IYP' then '样品入库'end potypeText,
       iim.import_no,
       iim.po_no,
       iim.supplier_no,
       bs.supplier_name,
       iim.REQUEST_DATE,
       iim.end_date,
       case iim.status when '10' then '初始' when '12' then '验收中' when '13' then '结案' end statusText,
       iid.article_no,
       bda.owner_article_no,
       bda.article_name,
       bag.group_name,
       iid.po_qty,
       iid.import_qty,--验收数量
       iid.po_qty - import_qty marginQty,--差异量
       bw.worker_name,
       iim.rgst_date,
       bda.barcode,
       (select nvl(sum(c.po_qty), 0)
          from idata_import_allot c
         where iim.enterprise_no = c.enterprise_no
           and iim.warehouse_no = c.warehouse_no
           and iim.owner_no = c.owner_no
           and iim.import_no = c.import_no
           and iid.article_no = c.article_no) as ID_QTY
  from idata_import_m     iim,
       idata_import_d     iid,
       bdef_defsupplier   bs,
       bdef_defarticle    bda,
       bdef_article_group bag,
       bdef_defworker     bw
 where iim.enterprise_no = iid.enterprise_no
   and iim.warehouse_no = iid.warehouse_no
   and iim.owner_no = iid.owner_no
   and iim.import_no = iid.import_no
   and iim.enterprise_no = bs.enterprise_no
   and iim.owner_no = bs.owner_no
   and iim.supplier_no = bs.supplier_no
   and iid.enterprise_no = bda.enterprise_no
   and iid.owner_no = bda.owner_no
   and iid.article_no = bda.article_no
   and bda.enterprise_no = bag.enterprise_no
   and bda.owner_no = bag.owner_no
   and bda.group_no = bag.group_no
   and iim.enterprise_no = bw.enterprise_no(+)
   and iim.updt_name = bw.worker_no(+)
 order by iim.enterprise_no, iim.WAREHOUSE_NO, iim.OWNER_NO, iim.import_no


/

