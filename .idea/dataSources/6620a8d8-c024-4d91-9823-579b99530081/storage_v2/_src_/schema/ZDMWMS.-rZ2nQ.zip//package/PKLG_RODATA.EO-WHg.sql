create package        pklg_rodata is
  --退货逻辑
  /*******************************************************************************************
  quzhihui
  功能说明：1、按退货单发单；
            2、调用一次过程产生一张下架单，前台SOURCE传参为N，则按供应商产生下架单，若SOURCE_NO
            传参为退货单号，则一张退货单对应一张捡货单，不区分区域
  ********************************************************************************************/
  --退货发单
  procedure P_RO_OUTSTOCK(strEnterPriseNo  in rodata_outstock_m.enterprise_no%type,
                          strWarehose_No   in rodata_outstock_m.warehouse_no%type,
                          strOwnerNo       in rodata_outstock_m.owner_no%type,
                          strSupplierNo    in rodata_outstock_direct.supplier_no%type,
                          strRecedeType    in rodata_outstock_m.recede_type%type,
                          strClassType     in rodata_outstock_direct.class_type%type,
                          strSourceNo      in rodata_outstock_direct.source_no%type, --来源单号，N-所有单号，其它-退货单号
                          strInOutstockNo  in rodata_outstock_m.outstock_no%type, --传入的单号，传入N，内部取号
                          strDock_No       in bdef_defdock.dock_no%type, --码头号
                          strUserID        in bdef_defworker.worker_no%type,
                          strAssignNo      in bdef_defworker.worker_no%type,
                          strOperateType   in rodata_outstock_m.operate_type%type,
                          strTaskLabelFlag in rodata_outstock_direct.label_pick_flag%type,
                          strDeviceNo      in rodata_outstock_direct.device_no%type,
                          strLocateNo      in rodata_outstock_direct.locate_no%type,
                          strBatchNo       in rodata_outstock_direct.batch_no%type,
                          strPrintFlag     in wms_warehouse_rodataorder.sendprint_type%type, --打印标识，0：不打印，1：打表单，2，打标签，3,表单标签同时打印
                          strOutOutstockNo out rodata_outstock_m.outstock_no%type,
                          strOutMsg        out varchar2);
  /***********************************************************************************************************
  创建人：luozhiling
  创建时间：2014.11.7
  功能说明：退货发单,同一波次下同一供应商按标签和表单两种类型分别分单
  ***********************************************************************************************************/
  procedure P_GetTaskRooutstock(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                                strWarehose_No  in rodata_outstock_m.warehouse_no%type,
                                strOwnerNo      in rodata_outstock_m.owner_no%type,
                                strWaveNo       in rodata_outstock_direct.wave_no%type,
                                strRecedeType   in rodata_recede_m.recede_type%type,
                                strSupplierNo   in rodata_outstock_direct.supplier_no%type,
                                strClassType    in rodata_outstock_direct.class_type%type, --0：清场；1：总仓退货；2：质量问题退货
                                strSourceNo     in rodata_outstock_direct.source_no%type, --来源单号，N-所有单号，其它-退货单号
                                strDock_No      in bdef_defdock.dock_no%type, --码头号
                                strUserID       in bdef_defworker.worker_no%type,
                                strAssignNo     in bdef_defworker.worker_no%type,
                                strOperateType  in rodata_outstock_direct.operate_type%type,
                                strPrintFlag     in wms_warehouse_rodataorder.sendprint_type%type, --打印标识，0：不打印，1：打表单，2，打标签，3,表单标签同时打印
                                strOutMsg       out varchar2);
  /************************************************************************************************************
   创建人：2015.7.21
   创建时间：
   功能说明：清场的标签库存系统自动发单，自动回单，天天惠专业，
             清场定位的时候调用
  ************************************************************************************************************/
  procedure P_CleanOutStock(strEnterPriseNo  in rodata_outstock_m.enterprise_no%type,
                            strWarehose_No   in rodata_outstock_m.warehouse_no%type,
                            strOwnerNo       in rodata_outstock_m.owner_no%type,
                            strWaveNo        in rodata_outstock_direct.wave_no%type,
                            strRecedeType    in rodata_recede_m.recede_type%type,
                            strSupplierNo    in rodata_outstock_direct.supplier_no%type,
                            strClassType     in rodata_outstock_direct.class_type%type, --0：清场；1：总仓退货；2：质量问题退货
                            strSourceNo      in rodata_outstock_direct.source_no%type, --来源单号，N-所有单号，其它-退货单号
                            strUserID        in bdef_defworker.worker_no%type,
                            strTERMINAL_FLAG in stock_content_move.terminal_flag%type,
                            strLabePickFlag  in rodata_outstock_direct.label_pick_flag%type,
                            strDeviceNo      in rodata_outstock_direct.device_no%type,
                            strLocateNo      in rodata_outstock_direct.locate_no%type,
                            strBatchNo       in rodata_outstock_direct.batch_no%type,
                            strDock_No       in bdef_defdock.dock_no%type,
                            strPrintFlag     in wms_warehouse_rodataorder.sendprint_type%type, --打印标识，0：不打印，1：打表单，2，打标签，3,表单标签同时打印
                            strOutMsg        out varchar2);

  --退货回单
  /***********************************************************************************************8
  创建人：luozhiling
  创建时间：2014。11.8
  功能说明：按标签做退货回单
  ************************************************************************************************/
  procedure P_RO_LabelSave(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                           strWarehose_No  in rodata_outstock_m.warehouse_no%type,
                           strOwnerNo      in rodata_outstock_m.owner_no%type,
                           strOutStockNo   in rodata_outstock_d.outstock_no%type,
                           strsLabelNo     in rodata_outstock_d.s_label_no%type,
                           strOutUserID    in rodata_outstock_d.outstock_name%type,
                           strUserID       in rodata_outstock_d.assign_name%type,
                           strDockNo       in bdef_defdock.dock_no%type,
                           strOutMsg       out varchar2);
  /***********************************************************************************************8
  功能说明：按商品明细做拣货回单
           步骤：1、更新拣货明细；
                 2、更新库存；
  ************************************************************************************************/
  procedure P_SaveOutstock(strEnterPriseNo  in rodata_outstock_m.enterprise_no%type,
                           strWarehose_No   in rodata_outstock_m.warehouse_no%type,
                           strOwnerNo       in rodata_outstock_m.owner_no%type,
                           strOutStockNo    in rodata_outstock_d.outstock_no%type,
                           strsLabelNo      in rodata_outstock_d.s_label_no%type,
                           strArticleNo     in rodata_outstock_d.article_no%type,
                           strBarcode      in stock_article_info.barcode%type,
                           nPackingQTY      in rodata_outstock_d.packing_qty%type,
                           strQuality       in idata_check_d.quality%type, --品质
                           dtProduceDate    in stock_article_info.produce_date%type, --生产日期
                           dtExpireDate     in stock_article_info.expire_date%type, --到期日期
                           strLotNo         in stock_article_info.lot_no%type, --批次号
                           strRSV_BATCH1    in stock_article_info.rsv_batch1%type, --预留批属性1
                           strRSV_BATCH2    in stock_article_info.rsv_batch2%type, --预留批属性2
                           strRSV_BATCH3    in stock_article_info.rsv_batch3%type, --预留批属性3
                           strRSV_BATCH4    in stock_article_info.rsv_batch4%type, --预留批属性4
                           strRSV_BATCH5    in stock_article_info.rsv_batch5%type, --预留批属性5
                           strRSV_BATCH6    in stock_article_info.rsv_batch6%type, --预留批属性6
                           strRSV_BATCH7    in stock_article_info.rsv_batch7%type, --预留批属性7
                           strRSV_BATCH8    in stock_article_info.rsv_batch8%type, --预留批属性8
                           strScellNo       in rodata_outstock_d.s_cell_no%type,
                           nArticleQTY      in rodata_outstock_d.article_qty%type,
                           nRealQTY         in rodata_outstock_d.real_qty%type,
                           strRealCellNo    in rodata_outstock_d.outstock_cell_no%type,
                           strOutUserID     in rodata_outstock_d.outstock_name%type,
                           strUserID        in rodata_outstock_d.assign_name%type,
                           strTERMINAL_FLAG in stock_content_move.terminal_flag%type,
                           strOutMsg        out varchar2);
  /***********************************************************************************************8
  功能说明： 用于天天惠惠特殊的清场流程处理，不允许修改储位回单
           步骤：1、更新拣货明细；
                 2、更新库存；

  ************************************************************************************************/
  procedure P_SpecialSaveOutstock(strEnterPriseNo  in rodata_outstock_m.enterprise_no%type,
                                  strWarehose_No   in rodata_outstock_m.warehouse_no%type,
                                  strOwnerNo       in rodata_outstock_m.owner_no%type,
                                  strOutStockNo    in rodata_outstock_d.outstock_no%type,
                                  strsLabelNo      in rodata_outstock_d.s_label_no%type,
                                  strArticleNo     in rodata_outstock_d.article_no%type,
                                  nPackingQTY      in rodata_outstock_d.packing_qty%type,
                                  strQuality       in idata_check_d.quality%type, --品质
                                  dtProduceDate    in stock_article_info.produce_date%type, --生产日期
                                  dtExpireDate     in stock_article_info.expire_date%type, --到期日期
                                  strLotNo         in stock_article_info.lot_no%type, --批次号
                                  strRSV_BATCH1    in stock_article_info.rsv_batch1%type, --预留批属性1
                                  strRSV_BATCH2    in stock_article_info.rsv_batch2%type, --预留批属性2
                                  strRSV_BATCH3    in stock_article_info.rsv_batch3%type, --预留批属性3
                                  strRSV_BATCH4    in stock_article_info.rsv_batch4%type, --预留批属性4
                                  strRSV_BATCH5    in stock_article_info.rsv_batch5%type, --预留批属性5
                                  strRSV_BATCH6    in stock_article_info.rsv_batch6%type, --预留批属性6
                                  strRSV_BATCH7    in stock_article_info.rsv_batch7%type, --预留批属性7
                                  strRSV_BATCH8    in stock_article_info.rsv_batch8%type, --预留批属性8
                                  strScellNo       in rodata_outstock_d.s_cell_no%type,
                                  nArticleQTY      in rodata_outstock_d.article_qty%type,
                                  nRealQTY         in rodata_outstock_d.real_qty%type,
                                  strOutUserID     in rodata_outstock_d.outstock_name%type,
                                  strUserID        in rodata_outstock_d.assign_name%type,
                                  strTERMINAL_FLAG in stock_content_move.terminal_flag%type,
                                  strOutMsg        out varchar2);
  /*********************************************************************************************
  功能说明： 按拣货明细表的数据写退货箱明细，
             1、需整张下架单拣货完成后才写，
             2、因为很多项目的退货是没有标签的，故若没有标签号就将下架单号作为LABEL_NO
             3、此操作不涉及库存的改变；
             4、头档的RECEDE_NO 在项目为一对一退货时可记录退货单号，在多张退货单一起退货时记录N
             5、箱明细产生后，将退货下架单装历史
  创建日期：2015.7.23
  ********************************************************************************************/
  procedure P_CreateRecedeBox(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                              strWarehose_No  in rodata_outstock_m.warehouse_no%type,
                              strOwnerNo      in rodata_outstock_m.owner_no%type,
                              strOutStockNo   in rodata_outstock_d.outstock_no%type,
                              strUserID       in rodata_outstock_d.assign_name%type,
                              strOutMsg       out varchar2);
  /**********************************************************************--退货回单************
   功能说明：用于拣货回单直接产生退货清单的情况
            1、按商品明细进行下架回单；
            2、整单回单；
            3、产生预制退货单；
            4、退货确认
  *********************************************************************************************/
  procedure P_RO_OutstockReturn(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                                strWarehose_No  in rodata_outstock_m.warehouse_no%type,
                                strOwnerNo      in rodata_outstock_m.owner_no%type,
                                strOutStockNo   in rodata_outstock_d.outstock_no%type,
                                strLabelNo      in rodata_outstock_d.label_no%type,
                                strArticleNo    in rodata_outstock_d.article_no%type,
                                strBarcode      in stock_article_info.barcode%type,
                                nPackingQTY     in rodata_outstock_d.packing_qty%type,
                                strQuality      in idata_check_d.quality%type, --品质
                                dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                                dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                                strLotNo        in stock_article_info.lot_no%type, --批次号
                                strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                                strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                                strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                                strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                                strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                                strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                                strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                                strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                                strScellNo      in rodata_outstock_d.s_cell_no%type,
                                nArticleQTY     in rodata_outstock_d.article_qty%type,
                                nRealQTY        in rodata_outstock_d.real_qty%type,
                                strRealCellNo   in rodata_outstock_d.outstock_cell_no%type,
                                strOutUserID    in rodata_outstock_d.outstock_name%type,
                                strUserID       in rodata_outstock_d.assign_name%type,
                                strDockNo       in bdef_defdock.dock_no%type,
                                strOutMsg       out varchar2);

  /*********************************************************************************************
  创建人：luozhiling
  创建时间：2015.11.2
  功能说明：按SKU退货下架回单(支持多生产日期等属性）
  ************************************************************************************************/
  procedure P_MulRsvSaveOutstock(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                                 strWarehose_No  in rodata_outstock_m.warehouse_no%type,
                                 strOwnerNo      in rodata_outstock_m.owner_no%type,
                                 strOutStockNo   in rodata_outstock_d.outstock_no%type,
                                 strsLabelNo     in rodata_outstock_d.s_label_no%type,
                                 strArticleNo    in rodata_outstock_d.article_no%type,
                                 nPackingQTY     in rodata_outstock_d.packing_qty%type,
                                 strQuality      in idata_check_d.quality%type, --品质
                                 dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                                 dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                                 strLotNo        in stock_article_info.lot_no%type, --批次号
                                 strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                                 strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                                 strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                                 strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                                 strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                                 strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                                 strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                                 strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                                 strScellNo      in rodata_outstock_d.s_cell_no%type,
                                 nArticleQTY     in rodata_outstock_d.article_qty%type,
                                 nRealQTY        in rodata_outstock_d.real_qty%type,
                                 strRealCellNo   in rodata_outstock_d.outstock_cell_no%type,
                                 strOutUserID    in rodata_outstock_d.outstock_name%type,
                                 strUserID       in rodata_outstock_d.assign_name%type,
                                 strDockNo       in bdef_defdock.dock_no%type,
                                 strOutMsg       out varchar2);
  /*********************************************************************************************
  创建人：luozhiling
  创建时间：2014.11.8
  功能说明：扫描完成后，对退货单做整单回单，扣减库存处理。
  ************************************************************************************************/
  procedure P_PO_ScanSaveComfire(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                                 strWarehose_No  in rodata_outstock_m.warehouse_no%type,
                                 strOwnerNo      in rodata_outstock_m.owner_no%type,
                                 strOutStockNo   in rodata_outstock_d.outstock_no%type,
                                 strScanUserId   in rodata_outstock_d.outstock_name%type,
                                 strUserID       in rodata_outstock_d.assign_name%type,
                                 strDockNo       in bdef_defdock.dock_no%type,
                                 strOutMsg       out varchar2);

  /*********************************************************************************************
  创建人：luozhiling
  创建时间：2014.11.8
  功能说明：退货下架扫描
  ************************************************************************************************/
  --退货回单
  procedure P_PO_ScanOutstock(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                              strWarehose_No  in rodata_outstock_m.warehouse_no%type,
                              strOwnerNo      in rodata_outstock_m.owner_no%type,
                              strOutStockNo   in rodata_outstock_d.outstock_no%type,
                              strSourceNo     in rodata_outstock_d.source_no%type,
                              strArticleNo    in rodata_outstock_d.article_no%type,
                              strLabelNo      in rodata_outstock_d.label_no%type,
                              nPackingQTY     in rodata_outstock_d.packing_qty%type,
                              nRealQTY        in rodata_outstock_d.real_qty%type,
                              strScanUserId   in rodata_outstock_d.scan_name%type,
                              strDockNo       in bdef_defdock.dock_no%type,
                              strOutMsg       out varchar2);
  /*********************************************************************************************
  创建人：luozhiling
  创建时间：2014.11.8
  功能说明：退货下架扫描封箱
  ************************************************************************************************/
  --退货回单
  procedure P_RO_ScanCloseBox(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                              strWarehose_No  in rodata_outstock_m.warehouse_no%type,
                              strOwnerNo      in rodata_outstock_m.owner_no%type,
                              strLabelNo      in rodata_outstock_d.label_no%type,
                              strUserId       in rodata_outstock_d.scan_name%type,
                              strDockNo       in bdef_defdock.dock_no%type,
                              strOutMsg       out varchar2);
  /*********************************************************************************************
  创建人：luozhiling
  创建时间：2015.3.24
  功能说明：写预制退货单
  ************************************************************************************************/
  procedure P_InsertDeliver_List(strEnterPriseNo IN rodata_outstock_m.enterprise_no%type,
                                 strWarehose_No  in rodata_outstock_m.warehouse_no%type,
                                 strOwnerNo      in rodata_outstock_m.owner_no%type,
                                 strRecedeNo     in rodata_outstock_d.source_no%type,
                                 strUserID       in rodata_outstock_d.assign_name%type,
                                 strDock_No      in bdef_defdock.dock_no%type,
                                 strDeliverNo    out rodata_deliver_m.deliver_no%type,
                                 strOutMsg       out varchar2);
  /*********************************************************************************************
  创建人：luozhiling
  创建时间：2015.3.24
  功能说明：退货确认回单
  ************************************************************************************************/
  procedure P_DeliverConfirm(strEnterPriseNo IN rodata_outstock_m.enterprise_no%type,
                             strWarehose_No  in rodata_outstock_m.warehouse_no%type,
                             strOwnerNo      in rodata_outstock_m.owner_no%type,
                             strDeliverNo    in rodata_outstock_d.source_no%type,
                             strUserID       in rodata_outstock_d.assign_name%type,
                             strDock_No      in bdef_defdock.dock_no%type,
                             strOutMsg       out varchar2);
  /********************************************************************************************************
  功能说明：按商品做退货标签整理
            处理步骤：1、处理箱明细数据；
                      2、写标签整理日志；
                      3、扣减原标签库存；、
                      4、新增目的标签库存
        2015.8.12

  ***********************************************************************************************************/
  procedure P_ArticleMoveLabel(strEnterPriseNo in rodata_box_m.enterprise_no%type,
                               strWarehose_No  in rodata_box_m.warehouse_no%type,
                               strOwnerNo      in rodata_box_m.owner_no%type,
                               strsLabelNo     in rodata_box_m.label_no%type, --原标签
                               strdLabelNo     in rodata_box_m.label_no%type, --目的标签
                               strArticleNo    in rodata_box_d.article_no%type, --商品编码
                               nPackingQty     in rodata_box_d.packing_qty%type,
                               dtProduceDate   in stock_article_info.produce_date%type,
                               dtExpireDate    in stock_article_info.expire_date%type,
                               strQuality      in stock_article_info.quality%type,
                               strLotNo        in stock_article_info.lot_no%type,
                               nMoveQty        in stock_content.qty%type,
                               strUserId       in rodata_outstock_d.scan_name%type,
                               strOutMsg       out varchar2);
  /********************************************************************************************************
  功能说明：整箱转移退货标签
            处理步骤：1、处理箱明细数据；
                      2、写标签整理日志；
                      3、扣减原标签库存；、
                      4、新增目的标签库存
        2015.8.12
   ***********************************************************************************************************/
  procedure P_MoveLabel(strEnterPriseNo in rodata_box_m.enterprise_no%type,
                        strWarehose_No  in rodata_box_m.warehouse_no%type,
                        strOwnerNo      in rodata_box_m.owner_no%type,
                        strsLabelNo     in rodata_box_m.label_no%type, --原标签
                        strdLabelNo     in rodata_box_m.label_no%type, --目的标签
                        strUserId       in rodata_box_m.rgst_name%type,
                        strOutMsg       out varchar2);

  /*************************************************************************************************************
  功能说明：退货标签库存回库
  处理步骤
          1、从退货标签中获取标签信息，
          2、将标签明细的数据循环转移到目的储位上；
          3、打散标签库存；
          4、将退货单库存释放为普通库存stock_value的值置回为N
  2015.10.23
  ************************************************************************************************************/
  procedure P_LabelGetCell(strEnterPriseNo in rodata_box_m.enterprise_no%type,
                           strWarehose_No  in rodata_box_m.warehouse_no%type,
                           strLabelNo      in rodata_box_m.label_no%type, --原标签
                           strUserId       in rodata_box_m.rgst_name%type,
                           strOutMsg       out varchar2);
  /*********************************************************************************************************************
    功能说明：退货确认，用于一张退货单对应一张退货清单的情况
             处理步骤：1、根据退货单获取下架单并写预制退货单；
                       2、退货确认回单
    修改人：luozhiling
    修改时间：2015.03.24
  **********************************************************************************************************************/
  --退货确认
  procedure P_RO_Confirm(strEnterPriseNo IN rodata_outstock_m.enterprise_no%type,
                         strWarehose_No  in rodata_outstock_m.warehouse_no%type,
                         strOwnerNo      in rodata_outstock_m.owner_no%type,
                         strRecedeNo     in rodata_outstock_d.source_no%type,
                         strUserID       in rodata_outstock_d.assign_name%type,
                         strDock_No      in bdef_defdock.dock_no%type,
                         strDeliverNo    out rodata_deliver_d.deliver_no%type,
                         strOutMsg       out varchar2);
  /****************************************************************************************************888
  功能说明：1、将退货下架单的数据转到返配上架单，并写相应的库存，天天惠清场特殊流程
            注意：要求回单是的目的储位的CELL_ID不变
  *********************************************************************************************************/
  procedure P_OutStockToDivide(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                               strWarehose_No  in rodata_outstock_m.warehouse_no%type,
                               strOwnerNo      in rodata_outstock_m.owner_no%type,
                               strOutStockNo   in rodata_outstock_d.outstock_no%type,
                               strUserID       in rodata_outstock_d.assign_name%type,
                               strOutMsg       out varchar2);

  /*********************************************************************************************************************
    功能说明：快速退货扫描保存
    修改人：lizhiping
    修改时间：2016.01.13
  **********************************************************************************************************************/
  procedure p_save_scan_recede(strEnterPriseNo IN rodata_recede_d.enterprise_no%type,
                               strWarehose_No  in rodata_recede_d.warehouse_no%type,
                               strOwnerNo      in rodata_recede_d.owner_no%type,
                               strRecedeNo     in rodata_recede_d.recede_no%type,
                               strArticleNo    in rodata_recede_d.article_no%type,
                               nScanQty        in rodata_recede_d.budget_qty%type,
                               strUserID       in rodata_recede_d_scanlog.rgst_name%type,
                               strOutMsg       out varchar2);

    /*********************************************************************************************************************
    功能说明：快速退货换箱
    修改人：lizhiping
    修改时间：2016.01.15
  **********************************************************************************************************************/
  procedure p_cut_scan_recede(strEnterPriseNo IN rodata_recede_d.enterprise_no%type,
                               strWarehose_No  in rodata_recede_d.warehouse_no%type,
                               strOwnerNo      in rodata_recede_d.owner_no%type,
                               strRecedeNo     in rodata_recede_d.recede_no%type,
                               strUserID       in rodata_recede_d_scanlog.rgst_name%type,
                               strOutMsg       out varchar2);


  /*********************************************************************************************
  功能说明：校验指定目的储位是否合法

  *********************************************************************************************/
  procedure P_CheckLocateCell(strEnterPriseNo in rodata_recede_m.enterprise_no%type,
                                strWareHouseNo  in rodata_recede_m.WAREHOUSE_NO%type, --仓库编码
                                strOwnerNo      in rodata_recede_m.owner_no%type, --委托业主编码
                                strRecedeNo     in rodata_recede_m.recede_no%type, --进货汇总单号
                                strDestCellNo   in cdef_defcell.cell_no%type,
                                strResult       out varchar2);

end pklg_rodata;


/

