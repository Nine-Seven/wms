create view V_SEARCH_9112_5 as
SELECT cell.enterprise_no,
       cell.WAREHOUSE_NO,
       cell.ware_no,
       cell.area_no,
       cell.stock_no,
       cell.cell_no,
       (CASE
         WHEN cell.cell_status = '1' THEN
          '禁用'
         WHEN cell.cell_status = '2' THEN
          '冻结'
         WHEN cell.cell_status = '0' AND
              (cell.enterprise_no,CELL.WAREHOUSE_NO, cell.cell_no) IN
              (SELECT DISTINCT enterprise_no, WAREHOUSE_NO, cell_no
                 FROM STOCK_content
                WHERE (qty + instock_qty) <> 0) THEN
          '有货'
         ELSE
          '空位'
       END) AS cell_status,
       (CASE
         WHEN cell.check_status = '0' THEN
          '可用'
         ELSE
          '盘点'
       END) AS check_status
  FROM cDEF_defcell cell, cDEF_defarea area
 WHERE cell.WAREHOUSE_NO = area.WAREHOUSE_NO
   and cell.enterprise_no = area.enterprise_no
   AND cell.ware_no = area.ware_no
   AND cell.area_no = area.area_no

/

