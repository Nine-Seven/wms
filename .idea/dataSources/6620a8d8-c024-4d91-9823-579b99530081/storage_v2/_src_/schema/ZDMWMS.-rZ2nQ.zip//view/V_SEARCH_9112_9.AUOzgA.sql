create view V_SEARCH_9112_9 as
    (select mm."ENTERPRISE_NO",mm."WAREHOUSE_NO",mm."OWNER_NO",mm."OWNER_NAME",mm."OWNER_ALIAS",mm."ARTICLE_NO",mm."OWNER_ARTICLE_NO",mm."BARCODE",mm."ARTICLE_IDENTIFIER",mm."ARTICLE_NAME",mm."SPEC",mm."UNIT",mm."QTY",mm."RGST_DATE",mm."CELL_NO",mm."IMPORT_BATCH_NO",mm."DELAY_DAYS",mm."PRODUCE_DATE",mm."EXPIRE_DATE",mm."LEFT_DAYS",mm."AREA_NAME",im.po_no from
(select c.enterprise_no,
       c.warehouse_no,
       art.owner_no,
       o.owner_name,
       o.owner_alias,
       art.article_no,
       art.owner_article_no,
       art.barcode,
       art.article_identifier,
       art.article_name,
       art.spec,
       art.unit,
       sum(c.qty) as qty,
       trunc(i.rgst_date) rgst_date,
       ce.cell_no,
       i.import_batch_no,
       trunc(sysdate) - trunc(i.rgst_date) as delay_days,
       i.produce_date,
       i.expire_date,
       i.expire_date - trunc(sysdate) as left_days,
       --o.owner_alias,
       a.area_name
  from stock_content      c,
       stock_article_info i,
       cdef_defarea       a,
       cdef_defcell       ce,
       bdef_defarticle    art,
       bdef_defowner      o
 where c.enterprise_no = ce.enterprise_no
   and c.warehouse_no = ce.warehouse_no
   and c.cell_no = ce.cell_no
   and a.enterprise_no = ce.enterprise_no
   and a.warehouse_no = ce.warehouse_no
   and a.ware_no = ce.ware_no
   and a.area_no = ce.area_no
   and a.area_attribute = '0'
   and a.attribute_type = '0'
   and c.enterprise_no = art.enterprise_no
   and c.article_no = art.article_no
   and art.virtual_flag = '0'
   and c.enterprise_no = i.enterprise_no
   and c.article_no = i.article_no
   and c.article_id = i.article_id
   and c.enterprise_no = o.enterprise_no
   and c.owner_no = o.owner_no
 group by c.enterprise_no,
          c.warehouse_no,
          art.owner_no,
          o.owner_name,
          art.article_no,
          art.owner_article_no,
          art.barcode,
          art.article_name,
          art.spec,
          art.unit,
          art.article_identifier,
          ce.cell_no,
          i.import_batch_no,
          trunc(i.rgst_date),
          i.produce_date,
          i.expire_date,
          o.owner_alias,
          a.area_name
 order by c.enterprise_no,
          c.warehouse_no,
          art.owner_no,
          art.owner_article_no,
          ce.cell_no) mm,
          (select icm.enterprise_no,
               icm.warehouse_no,
               icm.owner_no,
               icm.check_no,
               iim.po_no
          from idata_check_m icm, idata_import_m iim
         where icm.enterprise_no = iim.enterprise_no
           and icm.warehouse_no = iim.warehouse_no
           and icm.owner_no = iim.owner_no
           and icm.import_no = iim.import_no) im
           where mm.enterprise_no = im.enterprise_no(+)
           and mm.warehouse_no = im.warehouse_no(+)
           and mm.owner_no = im.owner_no(+)
           and mm.import_batch_no = im.check_no(+) )


/

