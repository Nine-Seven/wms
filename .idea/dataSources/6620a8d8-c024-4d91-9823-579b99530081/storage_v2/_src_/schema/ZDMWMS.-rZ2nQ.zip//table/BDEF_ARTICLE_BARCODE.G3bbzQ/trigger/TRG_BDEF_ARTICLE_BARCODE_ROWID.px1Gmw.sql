create trigger TRG_BDEF_ARTICLE_BARCODE_ROWID
    before insert or update
    on BDEF_ARTICLE_BARCODE
    for each row
declare
  i_id NUMBER;
begin
  select SEQ_BDEF_ARTICLE_BARCODE_ROWID.NEXTVAL into i_id from dual;
  :NEW.ROW_ID := i_id;
end TRG_BDEF_ARTICLE_BARCODE_ROWID;


/

