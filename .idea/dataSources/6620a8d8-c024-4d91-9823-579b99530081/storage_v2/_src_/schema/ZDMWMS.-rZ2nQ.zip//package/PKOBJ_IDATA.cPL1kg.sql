create package        pkobj_idata is
  ---------------------------------进货单对象-------------------------------------------------------------

  /*************************************************************************************************
       修改人：lich
       日期：2014-03-24
       功能：生成进货汇总单头档信息

  *************************************************************************************************/
  procedure p_Idata_Import_Mm(v_enterprise_no in idata_import_mm.enterprise_no%type,
                              v_warehouse_no  in idata_import_mm.warehouse_no%type,
                              v_s_import_no   in idata_import_mm.s_import_no%type,
                              v_import_type   in idata_import_mm.import_type%type,
                              v_strClassType  in idata_import_mm.class_type%type,
                              v_owner_no      in idata_import_mm.owner_no%type,
                              v_dept_no       in idata_import_mm.dept_no%type,
                              v_po_type       in idata_import_mm.po_type%type,
                              v_supplier_no   in idata_import_mm.supplier_no%type,
                              v_stock_type    in idata_import_mm.stock_type%type,
                              v_stock_value   in idata_import_mm.stock_value%type,
                              v_rgst_name     in idata_import_mm.rgst_name%type,
                              v_OutMsg        out varchar2);

  /******************************************************************************************************************
   作者:lich
   日期:  2014-03-24
   功能: 生成进货汇总单和进货单对应关系
  *******************************************************************************************************************/
  procedure p_Idata_Import_Sm(v_enterprise_no in idata_import_sm.enterprise_no%type,
                              v_warehouse_no  in idata_import_sm.warehouse_no%type,
                              v_s_import_no   in idata_import_sm.s_import_no%type,
                              v_Import_no     in idata_import_sm.import_no%type,
                              v_rgst_name     in idata_import_mm.rgst_name%type,
                              v_OutMsg        out varchar2);

  /******************************************************************************************************************
   作者:lich
   日期:  2014-03-24
   功能: 进货汇总单明细
  *******************************************************************************************************************/
  procedure p_Idata_Import_Sd(v_enterprise_no in idata_import_sm.enterprise_no%type,
                              v_warehouse_no  in idata_import_sm.warehouse_no%type,
                              v_s_import_no   in idata_import_sm.s_import_no%type,
                              v_Import_no     in idata_import_sm.import_no%type,
                              v_OutMsg        out varchar2);

  /******************************************************************************************************************
   作者:Quzhihui
   日期:  2016-7-11
   功能: 进货单明细
  *******************************************************************************************************************/

  procedure p_Idata_Import_d(strEnterprise_no in idata_import_m.enterprise_no%type,
                             strWarehouse_No  in idata_import_m.warehouse_no%type,
                             strOwner_No      in idata_import_m.owner_no%type,
                             strImport_No     in idata_import_m.import_no%type,
                             strArticle_No    in idata_import_d.article_no%type,
                             nPacking_QTY     in idata_import_d.packing_qty%type,
                             nPO_QTY          in idata_import_d.po_qty%type,
                             nImport_QTY      in idata_import_d.import_qty%type,
                             strStatus        in idata_import_d.status%type,
                             v_OutMsg         out varchar2);

  /******************************************************************************************************************
   作者: haungb
   日期: 2016-7-12
   功能: 超品新增进货明细以及汇总明细
  *******************************************************************************************************************/
  procedure p_Inset_ImportDetailByOver(strEnterprise_no in idata_import_m.enterprise_no%type,
                                       strWarehouse_No  in idata_import_m.warehouse_no%type,
                                       strOwner_No      in idata_import_m.owner_no%type,
                                       strS_Import_No   in idata_import_mm.s_import_no%type,
                                       strArticle_No    in idata_import_d.article_no%type,
                                       nPacking_QTY     in idata_import_d.packing_qty%type,
                                       strOutMsg        out varchar2);

  /******************************************************************************************************************
   作者:lich
   日期:  2014-03-24
   功能: 预约状况记录表
  *******************************************************************************************************************/
  procedure p_Idata_Order_Status(v_enterprise_no in idata_import_mm.enterprise_no%type,
                                 v_warehouse_no  in idata_import_mm.warehouse_no%type,
                                 v_owner_no      in idata_import_mm.owner_no%type,--add by huangcx 20160816
                                 v_s_import_no   in idata_import_mm.s_import_no%type,
                                 v_Request_Date  in Idata_Order_Status.Request_Date%type,
                                 v_strDock_no    in Idata_Order_Status.Dock_No%type,
                                 v_Start_Time    in Idata_Order_Status.Start_Time%type,
                                 v_End_Time      in Idata_Order_Status.End_Time%type,
                                 v_rgst_name     in idata_import_mm.rgst_name%type,
                                 v_OutMsg        out varchar2);

  /******************************************************************************************************************
   作者:lich
   日期:  2014-03-24
   功能: 生成预约单号记录档
  *******************************************************************************************************************/
  procedure p_Idata_Order_Sheet(v_enterprise_no in idata_import_sm.enterprise_no%type,
                                v_warehouse_no  in idata_import_sm.warehouse_no%type,
                                v_owner_no     in idata_import_sm.owner_no%type,--add by huangcx 20160816
                                v_s_import_no   in idata_import_sm.s_import_no%type,
                                v_Import_no     in idata_import_sm.import_no%type,
                                v_rgst_name     in idata_import_mm.rgst_name%type,
                                v_OutMsg        out varchar2);
  /*************************************************************************************************************
   创建人：luozhiling
   创建时间：2013.11.25
   功能：直通验收写板明细、进货汇总明细，进货明细
  *************************************************************************************************************/
  procedure p_idata_InsertIDCheckPal(strEnterpriseNo in idata_check_pal_tmp.enterprise_no%type,
                                     strWareHouseNo  in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                     strOwnerNo      in idata_check_pal_tmp.owner_no%type, --委托业主
                                     strsImportNo    in idata_check_m.s_import_no%type, --进货汇总单号
                                     strImportNo     in idata_check_m.import_no%type, --进货单号
                                     strWorkerNo     in idata_check_pal_tmp.rgst_name%type, --操作人
                                     strNewLabelNo   in idata_check_pal_tmp.label_no%type, --新板号
                                     strSubLabelNo   in idata_check_pal_tmp.sub_label_no%type, --子容器号
                                     strContainNo    in idata_check_pal.container_no%type, --内部容器号
                                     strCustNo       in idata_check_pal.cust_no%type, --客户编码 无客户传N
                                     strfixpal_flag  IN idata_check_pal.fixpal_flag%type,
                                     intCheckQty     in idata_check_pal_tmp.check_qty%type, --验收数量
                                     strDockNo       in idata_check_pal.dock_no%type,
                                     intRowId        in idata_check_d.row_id%type, --验收明细ROW_id
                                     strWaveNo       in idata_import_mm.wave_no%type,
                                     strResult       out varchar2);

  /*******************************************************************************************************************
    创建人:luozhiling
    创建时间：2013.11.25
    功能：写直通验收明细
  *******************************************************************************************************************/
  procedure p_idata_IDInsertCheckD(strEnterpriseNo in idata_check_m.enterprise_no%type,
                                   strWareHouseNo  in idata_check_m.warehouse_no%type,
                                   strOwnerNo      in idata_check_m.owner_no%type,
                                   strsImportNo    in idata_check_m.s_import_no%type,
                                   strsCheckNo     in idata_check_m.s_check_no%type,
                                   strImporNo      in idata_check_pal_tmp.s_check_no%type,
                                   strArticleNo    in idata_check_d.article_no%type,
                                   strBarcode      in idata_check_d.barcode%type,
                                   nPackingQty     in idata_check_d.packing_qty%type,
                                   nCheckQty       in idata_check_d.check_qty%type,
                                   strLotNo        in idata_check_d.lot_no%type,
                                   dtProduceDate   in idata_check_d.produce_date%type,
                                   dtExpireDate    in idata_check_d.expire_date%type,
                                   strQuality      in idata_check_d.quality%type,
                                   strWorkerNo     in idata_check_m.rgst_name%type,
                                   nRowId          out idata_check_d.row_id%type,
                                   strResult       out varchar2);

  /**************************以下是从pkobj_idata_lich包合并过来的**************************************/

  /*
   作者:lich
   日期:  2014-04-23
   功能: 写验收单头档并返回汇总单号
  */
  procedure p_Insert_Idata_Check_M(strEnterpriseNo in idata_check_m.enterprise_no%type,
                                   strWAREHOUSE_NO in idata_check_m.WAREHOUSE_NO%type, --仓别
                                   strOwnerNo      in idata_check_m.owner_no%type, --委托业主编码
                                   strSImportNo    in idata_check_m.s_import_no%type, --进货汇总单号
                                   strDockNo       in idata_check_m.dock_no%type, --码头号
                                   strWorkerNo     in idata_check_m.check_worker%type, --操作人
                                   strPrintGroup   in idata_check_m.printer_group_no%type, --打印机组
                                   strCheckTools   in idata_check_m.check_tools%type, --验收工具
                                   strSCheckNo     out idata_check_m.s_check_no%type, --汇总验收单号
                                   strResult       out varchar2 --返回结果
                                   );

  /**********************************************************************************************
   作者:lich
   日期:  2014-04-23
   功能: 进货单对象：写入临时板表
  ************************************************************************************************/
  procedure p_Insert_Idata_Check_Pal_Tmp(strEnterprise_no in idata_check_pal_tmp.enterprise_no%type, --q
                                         strWAREHOUSE_NO  in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                         strOwner_No      in idata_check_pal_tmp.owner_no%type, --委托业主编码
                                         strS_Import_No   in idata_check_m.s_import_no%type, --汇总进货单号
                                         strS_Check_No    in idata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                         strClassType     in idata_import_m.class_type%type,
                                         strArticle_No    in idata_check_pal_tmp.article_no%type, --商品编码
                                         strQuality       in idata_check_pal_tmp.quality%type, --品质
                                         dtProduceDate    in idata_check_pal_tmp.produce_date%type, --生产日期
                                         dtExpireDate     in idata_check_pal_tmp.expire_date%type, --有效日期
                                         strLot_No        in idata_check_pal_tmp.lot_no%type, --批号
                                         strRSV_BATCH1    in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                                         strRSV_BATCH2    in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                                         strRSV_BATCH3    in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                                         strRSV_BATCH4    in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                                         strRSV_BATCH5    in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                                         strRSV_BATCH6    in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                                         strRSV_BATCH7    in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                                         strRSV_BATCH8    in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                                         strTemperature   in idata_check_pal_tmp.temperature%type, --温度
                                         strBarcode       in idata_check_pal_tmp.barcode%type, --商品条码
                                         nPack_Qty        in idata_check_pal_tmp.packing_qty%type, --包装数量
                                         nCheck_Qty       in idata_check_pal_tmp.check_qty%type, --验收数量
                                         strLabel_No      in idata_check_pal_tmp.label_no%type, --板号
                                         strSub_Label_No  in idata_check_pal_tmp.sub_label_no%type, --尾箱标签
                                         strBusiness_Type in idata_check_pal_tmp.business_type%type, --业务类型
                                         strFixpal_Flag   in idata_check_pal_tmp.fixpal_flag%type, --板类型
                                         strPrintGroup    in idata_check_pal_tmp.printer_group_no%type, --打印机组
                                         strDock_No       in idata_check_pal_tmp.dock_no%type, --码头
                                         strStockType     in idata_check_pal_tmp.stock_type%type, --存储类型
                                         strStockValue    in idata_check_pal_tmp.stock_value%type, --存储类型对应值
                                         --strScan_Label_No   in idata_check_pal_tmp.scan_label_no%type, --尾箱标签
                                         strWorker_No in idata_check_pal_tmp.rgst_name%type, --验收人员
                                         --strItem_Type       in idata_check_pal_tmp.item_type%type, --商品类型
                                         strImportType  in idata_check_pal_tmp.import_type%type, --进货单别
                                         strSupplierNo  in idata_check_pal_tmp.supplier_no%type, --供应商
                                         strCheck_Tools in char, --检查工具 1:前台2:RF
                                         --strBatch_serial_No in idata_check_pal_tmp.batch_serial_no%type, --批次流水号
                                         nIsAdd       in integer, --是否累加 0:覆盖 1:累加
                                         strCustNo    in bdef_defcust.cust_no%type,
                                         strCheckType in idata_check_pal_tmp.check_type%type,
                                         nQpalette    in idata_check_pal_tmp.qpalette%type, --0：板型验收；1：箱型验收；2：不上分拣箱验收；3：综合验收
                                         strResult    out varchar2 --返回结果
                                         );
  /**********************************************************************************************
   作者:lich
   日期:  2014-04-23
   功能: 将临时板数据写入验收明细
  ************************************************************************************************/
  procedure p_insert_idata_check_D(strEnterpriseNo in idata_check_pal_tmp.enterprise_no%type,
                                   strWareHouseNo  in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                   strOwnerNo      in idata_check_pal_tmp.owner_no%type, --委托业主
                                   strSimportNo    in idata_check_m.s_import_no%type, --进货汇总单号
                                   strSCheckNo     in idata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                   strImporNo      in idata_check_pal_tmp.s_check_no%type,
                                   strWorkerNo     in idata_check_pal_tmp.rgst_name%type, --操作人
                                   nCheckQty       in idata_check_pal_tmp.check_qty%type,
                                   intRowId        in idata_check_pal_tmp.row_id%type,
                                   strLabelNo      in idata_check_pal_tmp.label_no%type,
                                   strResult       out varchar2);

  /**********************************************************************************************
   作者:lich
   日期:  2014-04-23
   功能: 将临时板数据写入板明细
  ************************************************************************************************/
  procedure p_Insert_Idata_Check_Pal(strEnterpriseNo  in idata_check_pal_tmp.enterprise_no%type,
                                     strWareHouseNo   in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                     strOwnerNo       in idata_check_pal_tmp.owner_no%type, --委托业主
                                     strSimportNo     in idata_check_m.s_import_no%type, --进货汇总单号
                                     strSCheckNo      in idata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                     strImportNo      in idata_check_m.import_no%type, --单号
                                     strWorkerNo      in idata_check_pal_tmp.rgst_name%type, --操作人
                                     nCheckQty        in idata_check_pal_tmp.check_qty%type,
                                     strLabelNo       in idata_check_pal_tmp.label_no%type, --老板号
                                     strNewLabelNo    in idata_check_pal_tmp.label_no%type, --新板号
                                     strNewSubLabelNo in idata_check_pal.sub_label_no%type, --子板号
                                     strContainNo     in idata_check_pal.container_no%type, --内部容器号
                                     nRowId           in idata_check_pal_tmp.row_id%type,
                                     strResult        out varchar2);
  /**********************************************************************************************
   作者:lich
   日期:  2014-04-23
   功能: 更新进货手建单及进货汇总单
  ************************************************************************************************/
  procedure p_Update_Idata_Import_D(strEnterpriseNo in idata_check_pal_tmp.enterprise_no%type,
                                    strWareHouseNo  in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                    strOwnerNo      in idata_check_pal_tmp.owner_no%type, --委托业主
                                    strSImportNo    in idata_check_m.s_import_no%type, --进货汇总单号
                                    strImportNo     in idata_check_m.import_no%type, --进货单号
                                    strArticle_no   in idata_import_d.article_no%type, --商品编码
                                    nPacking_qty    in idata_import_d.packing_qty%type, --包装数量
                                    nCheckQty       in idata_check_pal_tmp.check_qty%type,
                                    strWorkerNo     in idata_check_pal_tmp.rgst_name%type, --操作人
                                    strResult       out varchar2);
  /*****************************************************************************************
      作者:lich
      日期:  2014-04-23
      功能：新增标签号
  *****************************************************************************************/
  procedure p_Insert_Stock_Label_M(strEnterprise_no      in STOCK_LABEL_M.ENTERPRISE_NO%TYPE,
                                   strwarehouse_no       in STOCK_LABEL_M.warehouse_no%type, --仓别
                                   strBATCH_NO           in STOCK_LABEL_M.BATCH_NO%type, --批次
                                   strSOURCE_NO          in STOCK_LABEL_M.SOURCE_NO%type, --来源单号
                                   strLABEL_NO           in STOCK_LABEL_M.LABEL_NO%type, --标签号
                                   strCONTAINER_NO       in STOCK_LABEL_M.CONTAINER_NO%type, --内部容器号
                                   strCONTAINER_TYPE     in STOCK_LABEL_M.CONTAINER_TYPE%type, --容器类型
                                   strDELIVER_AREA       in STOCK_LABEL_M.DELIVER_AREA%type, --发货区储位
                                   strOWNER_CELL_NO      in STOCK_LABEL_M.OWNER_CELL_NO%type, --最后并入储位
                                   strCUST_NO            in STOCK_LABEL_M.CUST_NO%type, --客户编号
                                   strTRUNCK_CELL_NO     in STOCK_LABEL_M.TRUNCK_CELL_NO%type, --笼车上储位编码
                                   strA_SORTER_CHUTE_NO  in STOCK_LABEL_M.A_SORTER_CHUTE_NO%type, --大分拣机滑道号
                                   strCHECK_CHUTE_NO     in STOCK_LABEL_M.CHECK_CHUTE_NO%type, --复核台滑道号
                                   strDELIVER_OBJ        in STOCK_LABEL_M.DELIVER_OBJ%type, --配送对象
                                   strUSE_TYPE           in STOCK_LABEL_M.USE_TYPE%type, --标签用途
                                   strLINE_NO            in STOCK_LABEL_M.LINE_NO%type, --线路
                                   strCURR_AREA          in STOCK_LABEL_M.CURR_AREA%type, --当前位置
                                   strDeviceNo           in STOCK_LABEL_M.device_no%type, --设备类型
                                   strRGST_NAME          in STOCK_LABEL_M.RGST_NAME%type, --添加人员
                                   strREPORT_ID          in STOCK_LABEL_M.REPORT_ID%type, --报表ID
                                   strMID_LABEL_NO       in STOCK_LABEL_M.MID_LABEL_NO%type, --出货物流箱号
                                   strBIG_EXP_NO_FLAG    in STOCK_LABEL_M.BIG_EXP_NO_FLAG%type, --大批量出货单标识
                                   strSTOCK_TYPE         in STOCK_LABEL_M.STOCK_TYPE%type, --存储类型
                                   strCHUTE_LABEL_FLAG   in STOCK_LABEL_M.CHUTE_LABEL_FLAG%type, --是否大分拣机滑道口取号标签，可用于并板，0：不是；1：是
                                   strOWNER_CONTAINER_NO in STOCK_LABEL_M.OWNER_CONTAINER_NO%type, --最后并入容器号
                                   strstatus             in STOCK_LABEL_M.status%type, --状态
                                   strHm_Manual_Flag     in STOCK_LABEL_M.Hm_Manual_Flag%type, --是否储位库存 1储位库存，0标签库存
                                   strWaveNo             in stock_label_m.wave_no%type,
                                   strOutMsg             out varchar2); --返回 执行结果

  /*****************************************************************************************
   作者:lich
   日期:  2014-04-23
   功能：新增标签日志
  *****************************************************************************************/
  procedure p_Insert_Stock_Label_Log(strEnterprise_no in STOCK_LABEL_M.ENTERPRISE_NO%TYPE,
                                     strwarehouse_no  in STOCK_LABEL_M.warehouse_no%type, --仓别
                                     strContainerNo   in STOCK_LABEL_M.container_no%type, --容器号
                                     strUSER_ID       in STOCK_LABEL_M.updt_name%type, --员工ID
                                     blInsertFlag     in number, --标签跟踪非插入时,要判断新状态是否与老状态一致,如一致不新增日志
                                     strSTATUS        in STOCK_LABEL_M.status%type, --状态
                                     strOutMsg        out varchar2); --返回值
  /******************************************************************************************
   作者：lich
   日期：2014-04-25
   功能：写定位指示表
  *****************************************************************************************/
  procedure p_Insert_Idata_Locate_Direct(strEnterpriseNo    in idata_check_pal.enterprise_no%type,
                                         strWareHouseNo     in idata_check_pal.warehouse_no%type, --仓别
                                         strOwnerNo         in idata_locate_direct.owner_no%type, --货主业主编码
                                         strLocateType      in idata_locate_direct.locate_type%type,
                                         strLocateFlag      in idata_locate_direct.container_locate_flag%type, --0按箱定位；1：按商品定位
                                         strAutoLoateFlag   in idata_locate_direct.auto_locate_flag%type, --0:手工定位；1：自动定位
                                         strScheckNo        in idata_check_pal.s_check_no%type, --汇总验收单号
                                         strCellNo          in idata_locate_direct.cell_no%type,
                                         strUser_ID         in idata_check_pal.Rgst_Name%type, --操作人员
                                         strLocateNo        in idata_locate_direct.locate_no%type,
                                         strspecify_cell_no IN idata_locate_direct.specify_cell_no%type, --指定储位
                                         strArticleNo       in idata_locate_direct.article_no%type,
                                         nArticleId         in idata_locate_direct.article_id%type, --商品属性ID
                                         nPackingQty        in idata_locate_direct.packing_qty%type,
                                         strDockNo          in idata_locate_direct.dock_no%type,
                                         strPrinterGroupNo  in idata_locate_direct.printer_group_no%type,
                                         strRgstName        in idata_locate_direct.rgst_name%type,
                                         strStockType       in idata_locate_direct.stock_type %type,
                                         strStockValue      in idata_locate_direct.stock_value%type,
                                         strSubLabelNo      in idata_locate_direct.sub_label_no%type,
                                         strLabelNo         in idata_locate_direct.label_no%type,
                                         strBusinessType    in idata_locate_direct.business_type%type,
                                         strFixpalFlag      in idata_locate_direct.Fixpal_Flag%type,
                                         strSerialNo        in idata_locate_direct.serial_no%type, --进货汇总单流水号
                                         strQuality         in idata_locate_direct.quality%type,
                                         strImport_Type     in idata_locate_direct.import_type%type,
                                         strOutMsg          out varchar2);

  /******************************************************************************************************************
   修改人：lich
   日期:2014-04-24
   功能：验收确认
  *******************************************************************************************************************/
  procedure P_Close_Idata_Check(strEnterpriseNo         in idata_check_pal_tmp.enterprise_no%type,
                                strWAREHOUSE_NO         in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码)
                                strS_import_no          in idata_check_m.s_import_no%type, --进货汇总单号
                                strS_Check_no           in idata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                strWorkerNo             in idata_check_pal_tmp.rgst_name%type, --操作人
                                strUnloadWorkerNo       in idata_check_m.unload_worker%type,
                                strIC_ConfirmBuildSheet in wms_defbase.ndefine%type, --0----剩余部分手工重新预约，1----不自动预约，原汇总单有效
                                strDockNo               in pntset_printer_workstation.workstation_no%type, --工作站号
                                strResult               Out varchar2);
  /******************************************************************************************************************
   修改人：lich
   日期:2014-04-24
   功能：对进货单做结案
  *******************************************************************************************************************/
  procedure P_Close_Idata_Import(strEnterprise_no in idata_check_pal_tmp.enterprise_no%type,
                                 strWAREHOUSE_NO  in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码)
                                 strS_import_no   in idata_check_m.s_import_no%type, --进货汇总单号
                                 strWorkerNo      in idata_check_pal_tmp.rgst_name%type, --操作人
                                 strReturnType    in wms_defbase.sdefine%type, --1:一单一验；2：一单多验；3：一品多验
                                 strResult        Out varchar2);
  /**********************************************************************************************
   作者:lich
   日期:  2014-05-06
   功能: 上架回单  拆笔新增上架明细
  ************************************************************************************************/
  procedure p_Insert_idata_Instock_D(strWareHouseNo in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                     strOwnerNo     in idata_check_pal_tmp.owner_no%type, --委托业主
                                     strInstockNo   in idata_check_m.s_import_no%type, --进货汇总单号
                                     strInstockId   in idata_instock_d.instock_id%type,
                                     strRealCellNo  in idata_instock_d.real_cell_no%type,
                                     nRealQty       in idata_instock_d.real_qty%type,
                                     strUserId      in idata_instock_m.rgst_name%type, --上架人
                                     strSataus      in idata_instock_d.status%type,
                                     strResult      out varchar2);

  /******************************************************************************************************************
   修改人：lich
   日期:2014-05-24
   功能：将进货汇总单转历史
  *******************************************************************************************************************/
  procedure P_Idata_sImportToHty(strEnterprise_no in idata_check_mhty.enterprise_no%type, --企业
                                 strWAREHOUSE_NO  in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码)
                                 strOwner_No      in idata_check_mhty.owner_no%type,
                                 strS_import_no   in idata_check_m.s_import_no%type, --进货汇总单号
                                 strResult        Out varchar2);
  /******************************************************************************************************************
   日期:2016-7-8
   功能：将某段时间之前的结案的进货单和对应的验收单转历史
  *******************************************************************************************************************/
  procedure P_Idata_ImportToHty(strEnterprise_no in idata_check_mhty.enterprise_no%type, --企业
                                strWAREHOUSE_NO  in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码)
                                strOwner_No      in idata_check_mhty.owner_no%type,
                                nDays            in integer, --结转天数，例如60表示60天以前结案的数据
                                strResult        Out varchar2);
  /***************************************************************************************************
  LICH
  2014/05/05
  说明：上架回单
  ****************************************************************************************************/
  procedure P_Update_Idata_Instock(strEnterpriseNo     in idata_instock_m.enterprise_no%type,
                                   strWareHouseNo      in idata_instock_m.warehouse_no%type,
                                   strOwnerNo          in idata_instock_m.owner_no%type,
                                   strInstockNo        in idata_instock_m.instock_no%type,
                                   strInstockId        in idata_instock_d.instock_id%type,
                                   strInstockCellNo    in idata_instock_d.real_cell_no%type,
                                   nRealQty            in idata_instock_d.real_qty%type,
                                   strUserId           in idata_instock_m.rgst_name%type, --上架人
                                   strPaperUserId      in idata_instock_m.rgst_name%type, --回单人
                                   strSataus           in idata_instock_d.status%type,
                                   strUpdateStautsFlag in idata_instock_d.status%type, --0:不拆笔，1：拆笔
                                   strResult           out varchar2);

  /***************************************************************************************************
   作者:luozhiling
   日期:  2013-11-11
   功能: 上架指示转历史
  ****************************************************************************************************/
  procedure P_Idate_InstockToHty(strEnterpriseNo in idata_instock_m.enterprise_no%type,
                                 strWareHouseNo  in idata_instock_m.warehouse_no%type, --仓库代码
                                 strLocateNo     in idata_instock_m.locate_no%type, --定位波次号
                                 strInstockNo    in idata_instock_m.instock_no%type, --上架单号
                                 strResult       out varchar2);

  /***************************************************************************************************
   作者:luozhiling
   日期:  2013-11-11
   功能: 上架回单完成后时将定位指示、上架指示、上架单都转历史，按上架单做转历史处理
  ******************************************************************************************************/
  procedure P_Label_InstockToHty(strWareHouseNo in idata_instock_m.warehouse_no%type, --仓库代码
                                 strLabelNo     in idata_instock_d.label_no%type, --上架单号
                                 strLocateNo    in idata_instock_m.locate_no%type,
                                 strResult      out varchar2);

  /**********************************************************************************************************
     zhouhuan
     2014.04.29
     功能：写上架单头档
  ***********************************************************************************************************/
  procedure p_InsertInstockM(strEnterpriseNo in idata_instock_direct.enterprise_no%type,
                             strWareHouseNo  in idata_instock_direct.warehouse_no%type, --仓别
                             strWorkerNo     in idata_instock_direct.rgst_name%type, --操作人
                             strLocateNo     in idata_instock_direct.locate_no%type, --定位单号
                             strInstockNo    in idata_instock_d.instock_no%type, --上架单号
                             strResult       out varchar2);

  /**********************************************************************************************************
     zhouhuan
     2014.04.29
     功能：写上架单明细档
  ***********************************************************************************************************/
  procedure p_InsertInstockD(strEnterpriseNo in idata_instock_direct.enterprise_no%type,
                             strWareHouseNo  in idata_instock_direct.warehouse_no%type, --仓别
                             strWorkerNo     in idata_instock_direct.rgst_name%type, --操作人
                             strLocateNo     in idata_instock_direct.locate_no%type, --定位单号
                             strInstockNo    in idata_instock_d.instock_no%type, --上架单号
                             strResult       out varchar2);

  /**********************************************************************************************************
     zhouhuan
     2014.04.21
     功能：上架指示转历史
  ***********************************************************************************************************/
  procedure p_InstockDirectToHty(strWareHouseNo in idata_instock_direct.warehouse_no%type, --仓别
                                 strLocateNo    in idata_instock_direct.locate_no%type, --定位单号
                                 strResult      out varchar2);

  /**********************************************************************************************************
     zhouhuan
     2014.04.21
     功能：定位指示转历史
  ***********************************************************************************************************/
  procedure p_LocateDirectToHty(strWareHouseNo in idata_instock_direct.warehouse_no%type, --仓别
                                strLocateNo    in idata_instock_direct.locate_no%type, --定位单号
                                strResult      out varchar2);

  /******************************************************************************************************************
   创建人：luozhiling
   日期:2014-10-24
   功能：天天惠验收确认，天天惠的直通功能：1、一单多验；2：供应商会分多次送货，客户的配量单每天会下传，每天对当天
   的验收单做确认，结束当前的配量，，第二天会重新下传配量，故验收确认单独处理
  *******************************************************************************************************************/
  procedure P_TTHClose_Idata_Check(strWAREHOUSE_NO         in idata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码)
                                   strS_import_no          in idata_check_m.s_import_no%type, --进货汇总单号
                                   strS_Check_no           in idata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                   strWorkerNo             in idata_check_pal_tmp.rgst_name%type, --操作人
                                   strUnloadWorkerNo       in idata_check_m.unload_worker%type,
                                   strIC_ConfirmBuildSheet in wms_defbase.ndefine%type, --0剩余部分手工重新预约，1不自动预约，原汇总单有效
                                   strDockNo               in pntset_printer_workstation.workstation_no%type, --工作站号
                                   strResult               Out varchar2);
  /******************************************************************************************************
  创建人：luozhiling
  创建日期：2014.10.25
  功能说明：验收取消时，更新板明细数据
  ******************************************************************************************************/
  procedure P_Cancel_check_pal(strWarehouseNo in idata_check_pal.warehouse_no%type,
                               strOwnerNo     in idata_check_pal.owner_no%type,
                               strCheckNo     in idata_check_pal.check_no%type,
                               strsCheckNo    in idata_check_pal.s_check_no%type,
                               strLabelNo     in idata_check_pal.label_no%type,
                               strSubLabelNo  in idata_check_pal.sub_label_no%type,
                               nCheckRowId    in idata_check_pal.check_row_id%type,
                               strContainerNo in idata_check_pal.container_no%type,
                               strArticleNo   in idata_check_pal.article_no%type,
                               strCustNo      in idata_check_pal.cust_no%type,
                               nPackingQty    in idata_check_pal.packing_qty%type,
                               nQty           in idata_check_pal.check_qty%type,
                               strWorkerNo    in idata_check_pal.updt_name%type,
                               strResult      out varchar2);

  /******************************************************************************************************
  创建人：luozhiling
  创建日期：2014.10.25
  功能说明：存储商品标签销毁时，若验收单未做验收确认，还原商品至未验收状态
  ******************************************************************************************************/
  procedure P_Label_Cancel_IScheck(strWarehouseNo in idata_check_pal.warehouse_no%type,
                                   strOwnerNo     in idata_check_pal.owner_no%type,
                                   strsCheckNo    in idata_check_pal.s_check_no%type,
                                   strLabelNo     in idata_check_pal.label_no%type,
                                   strCustNo      in stock_label_d.cust_no%type,
                                   strExpNo       in stock_label_d.exp_no%type,
                                   strArticleNo   in stock_label_d.article_no%type,
                                   nArticleId     in stock_label_d.article_id%type,
                                   nPackingQTY    IN idata_check_pal.check_qty%type,
                                   nQty           in idata_check_pal.check_qty%type,
                                   strWorkerNo    in idata_check_pal.updt_name%type,
                                   strResult      out varchar2);
  /******************************************************************************************************
  创建人：luozhiling
  创建日期：2014.10.25
  功能说明：直通商品标签销毁时，若验收单未做验收确认，还原商品至未验收状态
  ******************************************************************************************************/
  procedure P_Label_Cancel_IDcheck(strEnterPriseNo in idata_check_m.enterprise_no%type,
                                   strWarehouseNo  in idata_check_pal.warehouse_no%type,
                                   strOwnerNo      in idata_check_pal.owner_no%type,
                                   strsCheckNo     in idata_check_pal.s_check_no%type,
                                   strLabelNo      in idata_check_pal.label_no%type,
                                   strCustNo       in stock_label_d.cust_no%type,
                                   strArticleNo    in stock_label_d.article_no%type,
                                   nArticleId      in stock_label_d.article_id%type,
                                   nPackingQTY     IN idata_check_pal.check_qty%type,
                                   nQty            in idata_check_pal.check_qty%type,
                                   strWorkerNo     in idata_check_pal.updt_name%type,
                                   strResult       out varchar2);

  /*************************************************************************************************
   创建人：hekl
   创建时间：2015.4.14
   功能说明：对采购单进行关单
  **************************************************************************************************/
  procedure P_import_close(strEnterpriseNo in stock_label_m.enterprise_no%type,
                           strWareHouseNo  in idata_import_m.warehouse_no%type,
                           strOwnerNo      in idata_import_m.owner_no%type,
                           strImportNo     in idata_import_m.import_no%type,
                           strUserID       in idata_import_m.updt_name%type,
                           strResult       out varchar2);

  /*************************************************************************************************
   创建人：hekl
   创建时间：2015.4.14
   功能说明：对采购单进行取消
  **************************************************************************************************/
  procedure P_import_cancel(strEnterpriseNo in stock_label_m.enterprise_no%type,
                            strWareHouseNo  in idata_import_m.warehouse_no%type,
                            strOwnerNo      in idata_import_m.owner_no%type,
                            strImportNo     in idata_import_m.import_no%type,
                            strUserID       in idata_import_m.updt_name%type,
                            strResult       out varchar2);
  /*=====================================================================================
   insert to 20151212
  进货直通分配格子号试算
  ======================================================================================*/
  PROCEDURE p_scan_CustAllot_LABEL_RG(strEnterPriseNo in idata_import_sm.enterprise_no%type,
                                      strwarehouse_no in idata_import_sm.warehouse_no%type, --仓别
                                      strowner_no     in idata_import_sm.owner_no%type,
                                      strSImportNo    in idata_import_sm.s_import_no%type, --进货汇总单号
                                      strClassType    in wms_warehouse_outorder.exp_type%type,
                                      strDEVICE_NO    in device_divide_m.device_no%type,
                                      strDELIVER_OBJ  in wms_outlocate_strategy_d.deliver_obj_level%type, --配送对象
                                      strUser_Id      in idata_import_sm.rgst_name%type, --操作人员
                                      strDockNo       in idata_check_m.dock_no%type, ---打印码头
                                      n_stockNum      in device_divide_m.cust_qty%type,
                                      strOutMsg       out varchar2);
end pkobj_idata;


/

