create package        PKOBJ_ACData is

  -- Author  : LIAOMX
  -- Created : 2014-10-16 14:55:52
  -- Purpose : 分拔中心

  -- Public type declarations
  --入库写接口
  procedure PROC_AC_INSTOCK;

  --入库写库存
  procedure PROC_AC_INSTOCK_AFFIRM(strWarehouseNo in VARCHAR2,strOrderNo in VARCHAR2, strSourceNo in VARCHAR2,strInstockNo in VARCHAR2,strResult out varchar2);

  --出库写接口
  procedure PROC_AC_OUTSTOCK;

  --出库写库存
  procedure PROC_AC_OUTSTOCK_AFFIRM(strHouseNo in VARCHAR2,strOrderNo in VARCHAR2, strSourceNo in VARCHAR2,strOutStockNO in VARCHAR2,strResult out varchar2);

  --接收RF的数据更新接单单据(接口调用)
  procedure PROC_AC_SIGN_RF;

  --接收RF的数据更新入库单据(接口调用)
  procedure PROC_AC_INSTOCK_RF;

  --接收RF的数据更新出库单据(接口调用)
  procedure PROC_AC_OUTSTOCK_RF;
  --接收RF回传数据处理
  procedure PROC_AC_ReceiptData;

end PKOBJ_ACData;


/

