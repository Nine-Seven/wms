create package body        PKOBJ_ADJ is

  -- Initialization
  /************************************************************************************************
  创建人：luozhiling
  创建说明：新增虚拟库存移库，用于通过虚拟储位调账 WMS库存
  创建日期：2014.12.30
  *************************************************************************************************/
    procedure P_InsertStockAdj_d(
           strEnterpriseNo      in        stock_adj_m.enterprise_no%type,
           strWareHouseNo       in        stock_adj_m.warehouse_no%type,
           strOwnerNo           in        stock_adj_m.owner_no%type,
           strAdjType           in        stock_adj_m.adj_type%type,
           strAdjNo             in        stock_adj_m.adj_no%type,
           strArticleNo         in        stock_adj_d.article_no%type,
           nArticleId           in        stock_adj_d.article_id%type,
           nPackingQty          in        stock_adj_d.packing_qty%type,
           dtProduceDate        in        stock_adj_d.produce_date%type,
           dtExpireDate         in        stock_adj_d.expire_date%type,
           strQuality           in        stock_adj_d.quality%type,
           strLotNo             in        stock_adj_d.lot_no%type,
           strRsvBatch1         in        stock_adj_d.rsv_batch1%type,
           strRsvBatch2         in        stock_adj_d.rsv_batch1%type,
           strRsvBatch3         in        stock_adj_d.rsv_batch1%type,
           strRsvBatch4         in        stock_adj_d.rsv_batch1%type,
           strRsvBatch5         in        stock_adj_d.rsv_batch1%type,
           strRsvBatch6         in        stock_adj_d.rsv_batch1%type,
           strRsvBatch7         in        stock_adj_d.rsv_batch1%type,
           strRsvBatch8         in        stock_adj_d.rsv_batch1%type,
           strCellNo            in        stock_adj_d.cell_no%type,
           nPlanQty             in        stock_adj_d.plan_qty%type,
           nRealQty             in        stock_adj_d.real_qty%type,
           strBarcode           IN        stock_adj_d.barcode%type,
           strStockType         in        stock_adj_d.stock_type%type,
           strStockValue        in        stock_adj_d.stock_value%type,
           strLabelNo           in        stock_adj_d.label_no%type,
           strResult            out       varchar2) is
       nRowID                   stock_adj_d.row_id%type;
    begin
         strResult:='N|[P_InsertStockAdj_d]';

         begin
              select nvl(max(row_id)+1,1) into nRowId from stock_adj_d where enterprise_no=strEnterpriseNo and warehouse_no=strWareHouseNo and adj_no=strAdjNo;
         exception when no_data_found then
              nRowId:=1;
         end;

         --写库存调账单头档
         insert into stock_adj_d(row_id,warehouse_no,owner_no,adj_no,article_no,article_id,packing_qty,
                produce_date,expire_date,quality,lot_no,import_batch_no,rsv_batch1,rsv_batch2,rsv_batch3,rsv_batch4,
                rsv_batch5,rsv_batch6,rsv_batch7,rsv_batch8,cell_no,plan_qty,real_qty,barcode,stock_type,stock_value,label_no,enterprise_no)
                values(nRowId,strWareHouseNo,strOwnerNo,strAdjNo,strArticleNo,nArticleId,nPackingQty,dtProduceDate,dtExpireDate,strQuality,
                strLotNo,strAdjNo,strRsvBatch1,strRsvBatch2,strRsvBatch3,strRsvBatch4,strRsvBatch5,strRsvBatch6,
                strRsvBatch7,strRsvBatch8,strCellNo,nPlanQty,nRealQty,strBarcode,strStockType,strStockValue,strLabelNo,strEnterpriseNo);

         strResult:='Y|[成功]';
    end P_InsertStockAdj_d;
/*************************************************************************************
 创建人：luozhiling
 创建时间:2014.12.30
 功能说明：新增虚拟库存调账单头档
****************************************************************************************/
    procedure P_InsertStockAdj_m(
           strEnterpriseNo      in        stock_adj_m.enterprise_no%type,
           strWareHouseNo       in        stock_adj_m.warehouse_no%type,
           strOwnerNo           in        stock_adj_m.owner_no%type,
           strAdjType           in        stock_adj_m.adj_type%type,
           strUserId            in        stock_adj_m.rgst_name%type,
           strAdjNo             out        stock_adj_m.adj_no%type,
           strResult            out       varchar2) is
    begin
         strResult:='N|[P_SaveStockAdj_m]';
          --获取建议单号
          PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,strWareHouseNo,CONST_DOCUMENTTYPE.WMSAD,strAdjNo,strResult);
          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;

         --写虚拟库存调头档
         insert into stock_adj_m(warehouse_no,owner_no,adj_type,adj_no,po_no,
                adj_date,status,create_flag,rgst_name,rgst_date,enterprise_no)
             values(strWareHouseNo,strOwnerNo,strAdjType,strAdjNo,strAdjNo,trunc(sysdate),'10','1',strUserId,sysdate,strEnterpriseNo);

         strResult:='Y|[成功]';
    end P_InsertStockAdj_m;
/***************************************************************************************************************
 创建人：luozhiling
 创建时间：2015.1.4
 创建说明：更新虚拟库存调整单明细
***************************************************************************************************************/
    procedure P_UpdateStockAdj_d(
           strEnterpriseNo      in        stock_adj_m.enterprise_no%type,
           strWareHouseNo       in        stock_adj_m.warehouse_no%type,
           strOwnerNo           in        stock_adj_m.owner_no%type,
           strAdjNo             in        stock_adj_m.adj_no%type,
           nRowId               in        stock_adj_d.row_id%type,
           nRealQty             in        stock_adj_d.real_qty%type,
           strResult            out       varchar2) is
    begin
         strResult:='N|[P_UpdateStockAdj_d]';
         --
         update stock_adj_d t set t.real_qty=nRealQty,t.status='13'
         where t.enterprise_no=strEnterpriseNo and t.warehouse_no=strWareHouseNo and t.owner_no=strOwnerNo and t.adj_no=strAdjNo
               and t.row_id=nRowID and t.status='10';

         strResult:='Y|[成功]';
    end P_UpdateStockAdj_d;

/***************************************************************************************************************
 创建人：luozhiling
 创建时间：2015.1.4
 创建说明：更新虚拟库存调整单头档
***************************************************************************************************************/
    procedure P_UpdateStockAdj_m(
           strEnterpriseNo      in        stock_adj_m.enterprise_no%type,
           strWareHouseNo       in        stock_adj_m.warehouse_no%type,
           strOwnerNo           in        stock_adj_m.owner_no%type,
           strAdjNo             in        stock_adj_m.adj_no%type,
           strUserId            in        stock_adj_m.rgst_name%type,
           strResult            out       varchar2) is
    begin
         strResult:='N|[P_UpdateStockAdj_d]';
         --
         update stock_adj_m t set t.status='13',updt_name=strUserId,updt_date=sysdate
         where t.enterprise_no=strEnterpriseNo and t.warehouse_no=strWareHouseNo and t.owner_no=strOwnerNo and t.adj_no=strAdjNo
               and t.status='10';

         strResult:='Y|[成功]';
    end P_UpdateStockAdj_m;
/*************************************************************************************
 创建人：luozhiling
 创建时间:2014.12.30
 功能说明：新增库存调账单头档
****************************************************************************************/
    procedure P_InsertStockPlan_m(
           strEnterpriseNo      in        stock_plan_m.enterprise_no%type,
           strWareHouseNo       in        stock_plan_m.warehouse_no%type,
           strOwnerNo           in        stock_plan_m.owner_no%type,
           strPlanType          in       stock_plan_m.plan_type%type,
           strPoNo              in       stock_plan_m.po_no%type,
           strCreateFlag        in       stock_plan_m.create_flag%type,
           strOrgNo             in       stock_plan_m.org_no%type,
           strUserId            in        stock_plan_m.rgst_name%type,
           strsRemark           in        stock_plan_m.remark%type,
           strPlanNo            out       stock_plan_m.plan_no%type,
           strResult            out       varchar2) is
    begin
         strResult:='N|[P_InsertStockPlan_m]';
          --获取建议单号
          PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,strWareHouseNo,CONST_DOCUMENTTYPE.STOCKPLAN,strPlanNo,strResult);
          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;

          insert into stock_plan_m(enterprise_no,warehouse_no,owner_no,plan_type,plan_no,plan_date,po_no,
                 status,create_flag,org_no,rgst_name,rgst_date,remark)
              values(strEnterpriseNo,strWareHouseNo,strOwnerNo,strPlanType,strPlanNo,trunc(sysdate),strPoNo,
                '10',strCreateFlag,strOrgNo,strUserId,sysdate,strsRemark);

         strResult:='Y|[成功]';
    end P_InsertStockPlan_m;

  /************************************************************************************************
  创建人：luozhiling
  创建说明：新增库存调账单明细
  创建日期：2014.12.30
  *************************************************************************************************/
    procedure P_InsertStockPlan_d(
           strEnterpriseNo      in        stock_plan_d.enterprise_no%type,
           strWareHouseNo       in        stock_plan_d.warehouse_no%type,
           strOwnerNo           in        stock_plan_d.owner_no%type,
           strPlanNo            in        stock_plan_d.plan_no%type,
           strArticleNo         in        stock_plan_d.article_no%type,
           nPackingQty          in        stock_plan_d.packing_qty%type,
           dtProduceDate        in        stock_plan_d.produce_date%type,
           dtExpireDate         in        stock_plan_d.expire_date%type,
           strQuality           in        stock_plan_d.quality%type,
           strLotNo             in        stock_plan_d.lot_no%type,
           strImportBatchNo     in        stock_plan_d.import_batch_no%type,
           strRsvBatch1         in        stock_plan_d.rsv_batch1%type,
           strRsvBatch2         in        stock_plan_d.rsv_batch1%type,
           strRsvBatch3         in        stock_plan_d.rsv_batch1%type,
           strRsvBatch4         in        stock_plan_d.rsv_batch1%type,
           strRsvBatch5         in        stock_plan_d.rsv_batch1%type,
           strRsvBatch6         in        stock_plan_d.rsv_batch1%type,
           strRsvBatch7         in        stock_plan_d.rsv_batch1%type,
           strRsvBatch8         in        stock_plan_d.rsv_batch1%type,
           strCellNo            in        stock_plan_d.cell_no%type,
           nPlanQty             in        stock_plan_d.plan_qty%type,
           strStockType         in        stock_plan_d.stock_type%type,
           strStockValue        in        stock_plan_d.stock_value%type,
           strLabelNo           in        stock_plan_d.label_no%type,
           strUserID            in        stock_plan_m.rgst_name%type,
           strResult            out       varchar2) is
       nRowID                   stock_adj_d.row_id%type;
    begin
         strResult:='N|[P_InsertStockPlan_d]';

         begin
              select nvl(max(row_id)+1,1) into nRowId from stock_plan_d
              where enterprise_no=strEnterpriseNo and warehouse_no=strWareHouseNo and plan_no=strPlanNo;
         exception when no_data_found then
              nRowId:=1;
         end;

         --写库存调账单头档
         insert into stock_plan_d(enterprise_no,warehouse_no,owner_no,plan_no,row_id,article_no,
              packing_qty,produce_date,expire_date,quality,lot_no,import_batch_no,rsv_batch1,rsv_batch2,
              rsv_batch3,rsv_batch4,rsv_batch5,rsv_batch6,rsv_batch7,rsv_batch8,cell_no,plan_qty,
              real_qty,stock_type,stock_value,label_no,status,rgst_name,rgst_date)
            values(strEnterpriseNo,strWareHouseNo,strOwnerNo,strPlanNo,nRowID,strArticleNo,
              nPackingQty,dtProduceDate,dtExpireDate,strQuality,strLotNo,strImportBatchNo,strRsvBatch1,strRsvBatch2,
              strRsvBatch3,strRsvBatch4,strRsvBatch5,strRsvBatch6,strRsvBatch7,strRsvBatch8,strCellNo,nPlanQty,
              0,strStockType,strStockValue,strLabelNo,'10',strUserId,sysdate);

         strResult:='Y|[成功]';
    end P_InsertStockPlan_d;
 /*************************************************************************************
  功能说明：写库存调账确认单头档
  2015.7.25

 ************************************************************************************/
 procedure P_InsertStockConfirmHead( strEnterpriseNo      in        stock_confirm_m.enterprise_no%type,
           strWareHouseNo       in        stock_confirm_m.warehouse_no%type,
           strOwnerNo           in        stock_confirm_m.owner_no%type,
           strPlanNo             in       stock_confirm_m.plan_no%type,
           strUserId            in        stock_confirm_m.rgst_name%type,
           strConfrimNo         out       stock_confirm_m.plan_no%type,
           strResult            out       varchar2) is
 begin
     strResult:='N|[P_InsertStockConfirmHead]';

      --获取库存调账确认单号
      PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,strWareHouseNo,CONST_DOCUMENTTYPE.STOCKCONFIRM,strConfrimNo,strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
     insert into stock_confirm_m(enterprise_no,warehouse_no,owner_no,confirm_no,plan_no,confirm_date,
            status,rgst_name,rgst_date)
         values(strEnterpriseNo,strWareHouseNo,strOwnerNo,strConfrimNo,strPlanNo,trunc(sysdate),
          '10',strUserId,sysdate);

     strResult:='Y|[]';
 end P_InsertStockConfirmHead;

  /************************************************************************************************
  创建人：luozhiling
  创建说明：新增调账确认单明细
  创建日期：2015.7.25
  *************************************************************************************************/
    procedure P_InsertStockConfirmItem(
           strEnterpriseNo      in        stock_confirm_d.enterprise_no%type,
           strWareHouseNo       in        stock_confirm_d.warehouse_no%type,
           strOwnerNo           in        stock_confirm_d.owner_no%type,
           strConfirmNo         in        stock_confirm_d.confirm_no%type,
           strSourceNo          in        stock_confirm_d.source_no%type,
           strArticleNo         in        stock_confirm_d.article_no%type,
           nArticleId           in        stock_confirm_d.article_id%type,
           nPackingQty          in        stock_confirm_d.packing_qty%type,
           dtProduceDate        in        stock_confirm_d.produce_date%type,
           dtExpireDate         in        stock_confirm_d.expire_date%type,
           strQuality           in        stock_confirm_d.quality%type,
           strLotNo             in        stock_confirm_d.lot_no%type,
           strImportBatchNo     in        stock_confirm_d.import_batch_no%type,
           strRsvBatch1         in        stock_confirm_d.rsv_batch1%type,
           strRsvBatch2         in        stock_confirm_d.rsv_batch1%type,
           strRsvBatch3         in        stock_confirm_d.rsv_batch1%type,
           strRsvBatch4         in        stock_confirm_d.rsv_batch1%type,
           strRsvBatch5         in        stock_confirm_d.rsv_batch1%type,
           strRsvBatch6         in        stock_confirm_d.rsv_batch1%type,
           strRsvBatch7         in        stock_confirm_d.rsv_batch1%type,
           strRsvBatch8         in        stock_confirm_d.rsv_batch1%type,
           strCellNo            in        stock_confirm_d.cell_no%type,
           nArticleQty          in        stock_confirm_d.article_qty%type,
           strStockType         in        stock_confirm_d.stock_type%type,
           strStockValue        in        stock_confirm_d.stock_value%type,
           strLabelNo           in        stock_confirm_d.label_no%type,
           strUserID            in        stock_confirm_d.rgst_name%type,
           strResult            out       varchar2) is
       nRowID                   stock_adj_d.row_id%type;
    begin
         strResult:='N|[P_InsertStockPlan_d]';

         begin
              select nvl(max(row_id)+1,1) into nRowId from stock_confirm_d
              where enterprise_no=strEnterpriseNo and warehouse_no=strWareHouseNo and confirm_NO=strConfirmNo;
         exception when no_data_found then
              nRowId:=1;
         end;

         --写库存调账确认单明细档

         insert into stock_confirm_d(enterprise_no,warehouse_no,owner_no,confirm_no,source_no,row_id,
                article_no,article_id,packing_qty,produce_date,expire_date,quality,lot_no,import_batch_no,
                rsv_batch1,rsv_batch2,rsv_batch3,rsv_batch4,rsv_batch5,rsv_batch6,rsv_batch7,rsv_batch8,
                cell_no,article_qty,real_qty,stock_type,stock_value,label_no,status,
                rgst_name,rgst_date)
            values(strEnterpriseNo,strWareHouseNo,strOwnerNo,strConfirmNo,strSourceNo,nRowID,
                strArticleNo,nArticleId,nPackingQty,dtProduceDate,dtExpireDate,strQuality,strLotNo,strImportBatchNo,
                strRsvBatch1,strRsvBatch2,strRsvBatch3,strRsvBatch4,strRsvBatch5,strRsvBatch6,
                strRsvBatch7,strRsvBatch8,strCellNo,nArticleQty,0,strStockType,strStockValue,
                strLabelNo,'10',strUserID,sysdate);

         strResult:='Y|[成功]';
    end P_InsertStockConfirmItem;

/************************************************************************************************
 功能说明：库存调整确认单回单
      2015.7.25

************************************************************************************************/
   procedure P_updateStockConfirmItem(
           strEnterpriseNo      in        stock_confirm_d.enterprise_no%type,
           strWareHouseNo       in        stock_confirm_d.warehouse_no%type,
           strOwnerNo           in        stock_confirm_d.owner_no%type,
           strConfirmNo         in        stock_confirm_d.confirm_no%type,
           nRowId               in        stock_confirm_d.row_id%type,
           nRealQty             in        stock_confirm_d.real_qty%type,
           strUserId            in        stock_confirm_d.rgst_name%type,
           strResult            out       varchar2) is
    begin
         strResult:='N|[P_UpdateStockAdj_d]';
         --
         update stock_confirm_d t set t.real_qty=nRealQty,t.status='13',updt_name=strUserId,updt_date=sysdate
         where t.enterprise_no=strEnterpriseNo and t.warehouse_no=strWareHouseNo and t.owner_no=strOwnerNo
         and t.confirm_no=strConfirmNo
               and t.row_id=nRowID and t.status='10';

         strResult:='Y|[成功]';
    end P_updateStockConfirmItem;

/***************************************************************************************************************
 创建人：luozhiling
 创建时间：2015.1.4
 创建说明：更新虚拟库存调整单头档
***************************************************************************************************************/
    procedure P_UpdateStockConfirmHead(
           strEnterpriseNo      in        stock_confirm_m.enterprise_no%type,
           strWareHouseNo       in        stock_confirm_m.warehouse_no%type,
           strOwnerNo           in        stock_confirm_m.owner_no%type,
           strConfirmNo         in        stock_confirm_m.confirm_no%type,
           strUserId            in        stock_confirm_m.rgst_name%type,
           strResult            out       varchar2) is
    begin
         strResult:='N|[P_UpdateStockConfirmHead]';
         --
         update stock_confirm_m t set t.status='13',updt_name=strUserId,updt_date=sysdate
         where t.enterprise_no=strEnterpriseNo and t.warehouse_no=strWareHouseNo
         and t.owner_no=strOwnerNo and t.confirm_no=strConfirmNo
               and t.status='10';

         strResult:='Y|[成功]';
    end P_UpdateStockConfirmHead;
/*************************************************************************************
 创建人：huangsq
 创建时间:2015.7.20
 功能说明：新增品质转换单头档
****************************************************************************************/
    procedure P_Insert_QUALITY_CHANGE_m(
           strEnterpriseNo      in        ORG_QUALITY_CHANGE_m.enterprise_no%type,
           strWareHouseNo       in        ORG_QUALITY_CHANGE_m.warehouse_no%type,
           strOwnerNo           in        ORG_QUALITY_CHANGE_m.owner_no%type,
           strChangeType        in        ORG_QUALITY_CHANGE_m.CHANGE_TYPE%type,--品质转换类型，目前传0
           strUserId            in        ORG_QUALITY_CHANGE_m.rgst_name%type,
           strPo_no             in        ORG_QUALITY_CHANGE_m.Po_No%type,
           strChange_No         out       ORG_QUALITY_CHANGE_m.Change_no%type,
           strResult            out       varchar2) is
    begin
         strResult:='N|[P_Insert_QUALITY_CHANGE]';
          --获取建议单号
          PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,strWareHouseNo,CONST_DOCUMENTTYPE.WMSQU,strChange_No,strResult);
          if (substr(strResult, 1, 1) = 'N') then
            return;
          end if;

         --写品质转换单头档
         insert into ORG_QUALITY_CHANGE_m(
              ENTERPRISE_NO,WAREHOUSE_NO,OWNER_NO,CHANGE_TYPE,CHANGE_NO,PO_NO,OPERATE_DATE,
              STATUS,CREATE_FLAG,SEND_FLAG,RGST_NAME,RGST_DATE )
         values(strEnterpriseNo,strWareHouseNo,strOwnerNo,strChangeType,strChange_No,strPo_no,trunc(sysdate),'10','1','10',strUserId,sysdate) ;

         strResult:='Y|[成功]';
    end P_Insert_QUALITY_CHANGE_m;


/*************************************************************************************
 创建人：huangsq
 创建时间:2015.7.20
 功能说明：新增品质转换单明细
****************************************************************************************/
    procedure P_Insert_QUALITY_CHANGE_d(
           strEnterpriseNo      in        ORG_QUALITY_CHANGE_D.enterprise_no%type,
           strWareHouseNo       in        ORG_QUALITY_CHANGE_D.warehouse_no%type,
           strOwnerNo           in        ORG_QUALITY_CHANGE_D.owner_no%type,
           strChangeType        in        ORG_QUALITY_CHANGE_D.Change_No%type,
           strChange_No         in        ORG_QUALITY_CHANGE_D.Change_No%type,
           strArticleNo         in        ORG_QUALITY_CHANGE_D.article_no%type,
           nPackingQty          in        ORG_QUALITY_CHANGE_D.packing_qty%type,
           dtProduceDate        in        org_quality_change_d.produce_date%type,
           dtExpireDate         in        org_quality_change_d.expire_date%type,
           strImportBatchNo     in        org_quality_change_d.import_batch_no%type,
           strLotNo             in        org_quality_change_d.lot_no%type,--批次号
           strRSV_BATCH1        in        org_quality_change_d.rsv_batch1%type, --预留批属性1
           strRSV_BATCH2        in        org_quality_change_d.rsv_batch2%type, --预留批属性2
           strRSV_BATCH3        in        org_quality_change_d.rsv_batch3%type, --预留批属性3
           strRSV_BATCH4        in        org_quality_change_d.rsv_batch4%type, --预留批属性4
           strRSV_BATCH5        in        org_quality_change_d.rsv_batch5%type, --预留批属性5
           strRSV_BATCH6        in        org_quality_change_d.rsv_batch6%type, --预留批属性6
           strRSV_BATCH7        in        org_quality_change_d.rsv_batch7%type, --预留批属性7
           strRSV_BATCH8        in        org_quality_change_d.rsv_batch8%type, --预留批属性8
           strS_ORGNO           in        ORG_QUALITY_CHANGE_D.s_Org_No%type,
           strD_ORGNO           in        ORG_QUALITY_CHANGE_D.d_Org_No%type,
           nChangeQty           in        ORG_QUALITY_CHANGE_D.Change_Qty%type,
           nRealQty             in        ORG_QUALITY_CHANGE_D.real_qty%type,
           strDept_no           in        ORG_QUALITY_CHANGE_D.Dept_No%type,
           strStockType         in        ORG_QUALITY_CHANGE_D.stock_type%type,
           strStockValue        in        ORG_QUALITY_CHANGE_D.stock_value%type,
           strResult            out       varchar2) is
       nRowID                   stock_adj_d.row_id%type;
    begin
         strResult:='N|[P_InsertStockAdj_d]';

         begin
              select nvl(max(row_id)+1,1) into nRowId from ORG_QUALITY_CHANGE_D where enterprise_no=strEnterpriseNo and warehouse_no=strWareHouseNo and change_no=strChange_No;
         exception when no_data_found then
              nRowId:=1;
         end;

         --写增品质转换单明细
         insert into ORG_QUALITY_CHANGE_D (
          ENTERPRISE_NO,WAREHOUSE_NO,OWNER_NO,CHANGE_NO,ROW_ID,ARTICLE_NO,PACKING_QTY,
          S_ORG_NO,D_ORG_NO,CHANGE_QTY,STATUS,DEPT_NO,STOCK_TYPE,STOCK_VALUE,produce_date,Expire_Date,
          Import_Batch_No,lot_no,rsv_batch1,Rsv_Batch2,Rsv_Batch3,Rsv_Batch4,Rsv_Batch5,
          Rsv_Batch6,Rsv_Batch7,Rsv_Batch8)
        values(strEnterpriseNo,strWareHouseNo,strOwnerNo,strChange_No,nRowId,strArticleNo,nPackingQty,
               strS_ORGNO,strD_ORGNO,nChangeQty,'10',strDept_no,strStockType,strStockValue,dtProduceDate,dtExpireDate,
               strImportBatchNo,strLotNo,strRSV_BATCH1,strRSV_BATCH2,strRSV_BATCH3,strRSV_BATCH4,strRSV_BATCH5,
               strRSV_BATCH6,strRSV_BATCH7,strRSV_BATCH1) ;

         strResult:='Y|[成功]';
    end P_Insert_QUALITY_CHANGE_d;

/*************************************************************************************
 创建人：huangsq
 创建时间:2015.7.20
 功能说明：更新品质转换单头档
****************************************************************************************/
    procedure P_Update_QUALITY_CHANGE_m(
           strEnterpriseNo      in        ORG_QUALITY_CHANGE_m.enterprise_no%type,
           strWareHouseNo       in        ORG_QUALITY_CHANGE_m.warehouse_no%type,
           strOwnerNo           in        ORG_QUALITY_CHANGE_m.owner_no%type,
           strChange_No         in    ORG_QUALITY_CHANGE_m.Change_No%type,
           strUserId            in        ORG_QUALITY_CHANGE_m.rgst_name%type,
           strResult            out       varchar2) is
    begin
         strResult:='N|[P_Update_QUALITY_CHANGE_m]';
         --
         update ORG_QUALITY_CHANGE_m t set t.status='13',updt_name=strUserId,updt_date=sysdate
         where t.enterprise_no=strEnterpriseNo and t.warehouse_no=strWareHouseNo and t.owner_no=strOwnerNo and t.change_no=strChange_No
               and t.status='10';

         strResult:='Y|[成功]';
    end P_Update_QUALITY_CHANGE_m;
/*************************************************************************************
 创建人：huangsq
 创建时间:2015.7.20
 功能说明：更新品质转换单明细
****************************************************************************************/
    procedure P_Update_QUALITY_CHANGE_d(
           strEnterpriseNo      in        ORG_QUALITY_CHANGE_m.enterprise_no%type,
           strWareHouseNo       in        ORG_QUALITY_CHANGE_m.warehouse_no%type,
           strOwnerNo           in        ORG_QUALITY_CHANGE_m.owner_no%type,
           strChange_No         in        ORG_QUALITY_CHANGE_m.Change_No%type,
           strArticleNo         in        ORG_QUALITY_CHANGE_D.article_no%type,
           nRealQty             in        ORG_QUALITY_CHANGE_d.real_qty%type,
           nRowID               in        ORG_QUALITY_CHANGE_D.ROW_ID%TYPE,
           strResult            out       varchar2) is
    begin
         strResult:='N|[P_Update_QUALITY_CHANGE_d]';
         /****--20160606 wyf 添加ROW_ID 条件
         *****************************************************/
         update ORG_QUALITY_CHANGE_d t set t.real_qty=nRealQty,t.status='13'
         where t.enterprise_no=strEnterpriseNo and t.warehouse_no=strWareHouseNo and t.owner_no=strOwnerNo and t.change_no=strChange_No
               and t.article_no=strArticleNo  and t.status='10' and t.row_id = nRowID;

         strResult:='Y|[成功]';
    end P_Update_QUALITY_CHANGE_d;

end PKOBJ_ADJ;

/

