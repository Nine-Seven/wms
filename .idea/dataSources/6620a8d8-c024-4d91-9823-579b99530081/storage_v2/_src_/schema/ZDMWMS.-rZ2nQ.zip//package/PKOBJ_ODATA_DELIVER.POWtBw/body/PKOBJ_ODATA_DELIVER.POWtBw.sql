create package body PKOBJ_ODATA_DELIVER is

/**********************************************************************************************************
   luozhiling
   2013.11.10
   功能：新增装车建议单头档
***********************************************************************************************************/
    procedure P_odata_loadcarHead(strEnterprise             in    odata_loadpropose_m.enterprise_no%type,--企业编码
                                  strWareHouseNo            in    odata_loadpropose_m.warehouse_no%type,--仓库编码
                                  strCustNo                 in    Odata_Loadpropose_m.Cust_No%type,--客户编码
                                  strShipperNo              in    odata_loadpropose_m.shipper_no%type,--承运商编码
                                  strLineNo                 in    odata_loadpropose_m.line_no%type,--线路
                                  strCarNo                  in    bdef_defcar.car_no%type,---车辆编码
                                  strUserId                 in    odata_loadpropose_m.rgst_name%type,
                                  strDockNo                 in    odata_loadpropose_m.dock_no%type,
                                  strDivideTrunk            in    odata_loadpropose_m.divide_truck%type,--分车编号
                                  strcarPlanNo              IN    odata_loadpropose_m.car_plan_no%type,--派车计划单
                                  strSealNo                 in    Odata_Loadpropose_m.Seal_No%type,--封条号
                                  strLoadType               in    odata_loadpropose_m.loadtype%type,--装车类型：1：按承运商；2：线路；3：配送对象（客户、单）
                                  strProposeNo              out    odata_loadpropose_m.loadpropose_no%type,--建议单号
                                  strResult                 OUT    varchar2)is

      v_strCarTypeNo        bdef_defcar.cartype_no%type;--车辆类型编码
      v_strCarPlate         bdef_defcar.car_plate%type;--车牌号
      v_strDockNo         bdef_defdock.dock_no%type;--车牌号
    begin
      strResult := 'N|[P_odata_loadcarHead]';

      --获取车辆类型和车牌号
      begin
        select
          bc.cartype_no,
          bc.car_plate
        into
          v_strCarTypeNo,
          v_strCarPlate
        from
          bdef_defcar bc
        where
          bc.CAR_NO = strCarNo
          and bc.warehouse_no=strWareHouseNo
          and bc.enterprise_no=strEnterprise;

      exception
      when no_data_found then
        v_strCarPlate := strCarNo;
        v_strCarTypeNo := 'N';
       -- strResult := 'N|[E22901]';
      --  return;
      end;

      --获取车辆类型和车牌号
      begin
        select
          a.workstation_no
        into
          v_strDockNo
        from
          pntset_printer_workstation a
        where
          a.workstation_no = strDockNo
          and a.warehouse_no=strWareHouseNo
          and a.enterprise_no=strEnterprise;
      exception
      when no_data_found then
        strResult := 'N|[E22902]';
        return;
      end;

      --获取建议单号
      PKLG_WMS_BASE.p_getsheetno(strEnterprise,
                                 strWareHouseNo,
                                 CONST_DOCUMENTTYPE.ODATAOL,
                                 strProposeNo,
                                 strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --新增装车建议单头档
      insert into odata_loadpropose_m(
        enterprise_no,
        warehouse_no,
        operate_date,
        loadpropose_no,
        cartype_no,
        line_no,
        dock_no,
        status,
        car_plate,
        seal_no,
        cust_no,
        divide_truck,
        shipper_no,
        real_shipper_no,
        car_plan_no,
        rgst_name,
        rgst_date,
        loadtype)
      values(
        strEnterprise,
        strWareHouseNo,
        trunc(sysdate),
        strProposeNo,
        v_strCarTypeNo,
        strLineNo,
        strDockNo,
        '10',
        v_strCarPlate,
        strSealNo,
        strCustNo,
        strDivideTrunk,
        strShipperNo,
        strShipperNo,
        strcarPlanNo,
        strUserId,
        sysdate,
        strLoadType);

      strResult:='Y|';
    exception
        when others then
          strResult := 'N|' || SQLERRM ||
                       substr(dbms_utility.format_error_backtrace, 1, 256);
          return;
    end P_odata_loadcarHead;
/**********************************************************************************************************
   luozhiling
   2013.11.10
   功能：新增装车建议单明细
***********************************************************************************************************/
    procedure P_odata_loadcarItem(strEnterpriseNo           in    odata_loadpropose_m.enterprise_no%type,--企业编码
                                  strWareHouseNo            in    odata_loadpropose_m.warehouse_no%type,--仓库编码
                                  strProposeNo              in    odata_loadpropose_m.loadpropose_no%type,
                                  strContainerNo            in    stock_label_m.label_no%type,--标签号
                                  strUserId                 in    odata_loadpropose_m.updt_name%type,--装车人
                                  strPaperUserId            in    odata_loadpropose_m.updt_name%type,--单据人
                                  strResult                 OUT    varchar2)is
    begin
      strResult := 'N|[P_odata_loadcarHead]';

      update odata_loadpropose_m set status=status
        where enterprise_no=strEnterpriseNo and warehouse_no=strWareHouseNo
        and loadpropose_no=strProposeNo and status<'13';

      if sql%notfound then
         strResult:='N|[找不到可装车的装车建议单]';
         return;
      end if;

      --写装车建议单明细
      insert into odata_loadpropose_d(
        enterprise_no,
        warehouse_no,
        loadpropose_no,
        cust_no,
        container_type,
        container_no,
        load_order,
        exp_no,
        status,
        deliver_obj,
        load_name,
        load_date,
        assign_name,
        exp_date,box_num)
      select
        slm.enterprise_no,
        slm.warehouse_no,
        strProposeNo,
        slm.cust_no,
        slm.container_type,
        slm.container_no,
        rownum,
        'N',
        '10',
        slm.deliver_obj,
        strUserId,
        sysdate,
        strPaperUserId,
        slm.exp_date,
        (select sum(floor(sld.qty/sld.packing_qty)) from stock_label_d sld,stock_label_m slm
        where slm.enterprise_no=sld.enterprise_no and slm.warehouse_no=sld.warehouse_no
        and slm.enterprise_no=strEnterpriseNo and slm.warehouse_no=strWareHouseNo
        and slm.container_no=sld.container_no
        and slm.owner_container_no=strContainerNo)
      from
        stock_label_m slm
      where
        slm.label_no=strContainerNo
        and slm.warehouse_no=strWareHouseNo
        and slm.enterprise_no=strEnterpriseNo;

      --更新标签状态
      update
        stock_label_m
      set
        status='A1',
        updt_name=strUserId,
        updt_date=sysdate
      where
        warehouse_no=strWareHouseNo
        and label_no=strContainerNo
        and enterprise_no=strEnterpriseNo;

      if sql%notfound then
          strResult:='N|[E22907]';
          return;
      end if;

      --标签跟踪
      PKOBJ_LABEL.proc_InsertLabel_Log(strEnterpriseNo,
                                       strWareHouseNo,
                                       strContainerNo,
                                       strUserId,
                                       '0',
                                       'A1',
                                       strResult);
      if substr(strResult,1,1)='N' then
          return;
      end if;

      strResult:='Y|';
    exception
        when others then
          strResult := 'N|' || SQLERRM ||
                       substr(dbms_utility.format_error_backtrace, 1, 256);
          return;
    end P_odata_loadcarItem;


/**********************************************************************************************************
   lich
   2014.06.04
   功能：新增出货配送单头档
***********************************************************************************************************/
    procedure P_Insert_Odata_Deliver_M(strEnterpriseNo           in    odata_loadpropose_m.enterprise_no%type,--企业
                                       strWareHouseNo            in    odata_loadpropose_m.warehouse_no%type,--仓库编码
                                       strOwnerNo                in    odata_deliver_m.owner_no%type,
                                       strProposeNo              in    odata_loadpropose_m.loadpropose_no%type,--装车建议单号
                                       strDeliverOBJ             IN    ODATA_LOADPROPOSE_D.Deliver_Obj%type,
                                       strUserId                 in    odata_loadpropose_m.updt_name%type,--装车人
                                       strDeliverNo              out   odata_deliver_m.deliver_no%type,
                                       strResult                 OUT   varchar2)is

    begin
      strResult := 'N|[P_Insert_Odata_Deliver_M]';
      --无配送单，取号
      PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                 strWareHouseNo,
                                 CONST_DOCUMENTTYPE.ODATAOD,
                                 strDeliverNo,
                                 strResult);
      if Substr(strResult,1,1)='N' then
         return;
      end if;

      insert into odata_deliver_m(
        enterprise_no,
        warehouse_no,
        owner_no,
        operate_date,
        loadpropose_no,
        deliver_no,
        line_no,
        cartype_no,
        car_plate,
        send_name,
        status,
        cust_no,
        seal_no,
        send_flag,
        logbox_num,
        dip_flag,
        exp_date,
        car_plan_no,
        deliver_obj,
        rgst_name,
        rgst_date)
      select
        strEnterpriseNo,
        strWareHouseNo,
        strOwnerNo,
        olm.operate_date,
        strProposeNo,
        strDeliverNo,
        olm.line_no,
        olm.cartype_no,
        olm.car_plate,
        strUserId,
        '10',
        od.cust_no,
        olm.seal_no,
        olm.send_flag,
        sum(od.box_num),
        0,
        olm.exp_date,
        olm.car_plan_no,
        strDeliverOBJ,
        strUserId,
        sysdate
      from
        odata_loadpropose_m olm,
        odata_loadpropose_d od
      where
        olm.warehouse_no=od.warehouse_no
        and olm.enterprise_no=od.enterprise_no
        and olm.loadpropose_no=od.loadpropose_no
        and olm.warehouse_no=strWareHouseNo
        and olm.enterprise_no=strEnterpriseNo
        and olm.loadpropose_no=strProposeNo
        and od.deliver_obj=strDeliverOBJ
        and olm.status='10'
      group by
        strEnterpriseNo,
        strWareHouseNo,
        strOwnerNo,
        olm.operate_date,
        olm.line_no,
        olm.cartype_no,
        olm.car_plate,
        od.cust_no,
        olm.seal_no,
        olm.send_flag,
        olm.exp_date,
        olm.car_plan_no;

      strResult:='Y|';
    exception
        when others then
          strResult := 'N|' || SQLERRM ||
                       substr(dbms_utility.format_error_backtrace, 1, 256);
          return;
    end P_Insert_Odata_Deliver_M;
/**********************************************************************************************************
   lich
   2014.06.04
   功能：新增出货配送明细
***********************************************************************************************************/
    procedure P_Insert_Odata_Deliver_D(strEnterpriseNo           in    odata_loadpropose_m.enterprise_no%type,--企业
                                       strWareHouseNo            in    odata_loadpropose_m.warehouse_no%type,--仓库编码
              	                       strDeliverNo              in    odata_deliver_d.deliver_no%type,--分播单号
                                       strProposeNo              in    odata_loadpropose_m.loadpropose_no%type,--装车建议单号
                                       strDeliverObj             in    odata_loadpropose_d.deliver_obj%type,--配送对象
                                       strUserId                 in    odata_loadpropose_m.updt_name%type,--装车人
                                       strResult                 OUT   varchar2)is
    begin
      strResult := 'N|[P_Insert_Odata_Deliver_D]';
      --写配送单明细
      insert into odata_deliver_d(
        enterprise_no,
        warehouse_no,
        owner_no,
        deliver_no,
        container_no,
        container_id,
        exp_type,
        exp_no,
        wave_no,
        article_no,
        barcode,
        packing_qty,
        produce_date,
        expire_date,
        quality,
        lot_no,
        import_batch_no,
        rsv_batch1,
        rsv_batch2,
        rsv_batch3,
        rsv_batch4,
        rsv_batch5,
        rsv_batch6,
        rsv_batch7,
        rsv_batch8,
        qty,
        article_id,
        exp_date,
        real_qty,
        status,
        rgst_name,
        rgst_date,Label_No)
      select
        strEnterpriseNo,
        strWareHouseNo,
        sld.owner_no,
        strDeliverNo,
        sld.container_no,
        rownum,
        sld.exp_type,
        sld.exp_no,
        sld.wave_no,
        sld.article_no,/*sai.supplier_no,*/
        sai.barcode,
        sld.packing_qty,
        sai.produce_date,
        sai.expire_date,
        sai.quality,
        sai.lot_no,
        sai.import_batch_no,/*sai.batch_serial_no,sai.ext_barcode_no,*/
        sai.rsv_batch1,
        sai.rsv_batch2,
        sai.rsv_batch3,
        sai.rsv_batch4,
        sai.rsv_batch5,
        sai.rsv_batch6,
        sai.rsv_batch7,
        sai.rsv_batch8,
        sum(sld.qty),
        sld.article_id,/*sai.item_type,*/
        sld.exp_date,
        0,
        '10',
        strUserId,
        sysdate,slm.label_no
      from
        stock_label_d sld,
        stock_label_m slm,
        stock_article_info sai
      where
        sld.warehouse_no=slm.warehouse_no
        and sld.enterprise_no=slm.enterprise_no
        and sld.containeR_no=slm.container_no
        and sld.article_no=sai.article_no
        and sld.article_id=sai.article_id
        and sld.container_no=slm.container_no
        and slm.owner_container_no in(select
                                  od.container_no
                                from
                                  odata_loadpropose_d od
                                where
                                  od.loadpropose_no=strProposeNo
                                  AND od.warehouse_no=strWareHouseNo
                                  and od.enterprise_no=strEnterpriseNo
                                  and od.deliver_obj=strDeliverObj
                                )
        and sld.enterprise_no= strEnterpriseNo   --add by huangcx 20171116
        and sld.warehouse_no = strWareHouseNo    --add by huangcx 20171116              
      group by
        sld.enterprise_no,
        sld.warehouse_no,
        sld.owner_no,
        sld.container_no,
        rownum,
        sld.exp_type,
        sld.exp_no,
        sld.wave_no,
        sld.article_no,
        sai.barcode,
        sld.packing_qty,
        sai.lot_no,
        sai.produce_date,
        sai.expire_date,
        sai.quality,
        sai.import_batch_no,
        sai.rsv_batch1,
        sai.rsv_batch2,
        sai.rsv_batch3,
        sai.rsv_batch4,
        sai.rsv_batch5,
        sai.rsv_batch6,
        sai.rsv_batch7,
        sai.rsv_batch8,
        sld.article_id,
        sld.exp_date,slm.label_no;

      ---------------新增失败---------------
      if sql%rowcount <= 0 then
        strResult := 'N|[E22908]';
        return;
      end if;

      strResult:='Y|';
    exception
        when others then
          strResult := 'N|' || SQLERRM ||
                       substr(dbms_utility.format_error_backtrace, 1, 256);
          return;
    end P_Insert_Odata_Deliver_D;

  /*******************************************************************************************************
  创建人：huangb
  创建时间：2016.05.17
  功能说明：出货单和装车单据转历史
  ********************************************************************************************************/
  procedure P_Deliver_InsertHTY(strEnterpriseNo in odata_loadpropose_m.enterprise_no%type, --企业编码
                                strWareHouseNo  in odata_loadpropose_m.warehouse_no%type, --仓库编码
                                strProposeNo    in odata_loadpropose_m.loadpropose_no%type,
                                strUserID       in odata_loadpropose_m.rgst_name%type,
                                strOutMsg       out varchar2) is
  begin
   strOutMsg := 'N|[P_Deliver_InsertHTY]';
   --出货单头档转历史
   insert into odata_exp_mhty
     (exp_type, warehouse_no, exp_no, owner_no, owner_cust_no, cust_no, sub_cust_no, sourceexp_type
     , sourceexp_no, exp_date, fast_flag, status, priority, add_exp_no, import_no, deliver_type
     , transport_type, batch_no, line_no, full_line_name, cust_address, cust_address_code, contactor_name, cust_phone
     , cust_mail, error_status, create_flag, return_flag, exp_remark, belong_flag, send_flag, buffer_line_no
     , special_article_group, exp_status, stock_type, order_period, finance_type, kick_flag, real_cust_no, real_cust_name
     , dept_name, agent_no, payment_term, dept_no, cust_exp_no, erpoperate_date, custsend_date, print_flag
     , erp_no, diff_reason, rgst_name, rgst_date, updt_name, updt_date, wave_no, enterprise_no
     , shipper_deliver_no, deliver_address, shipper_no, print_bill_flag, order_source, org_no, rsv_varod1, rsv_varod2
     , rsv_varod3, rsv_varod4, rsv_varod5, rsv_varod6, rsv_varod7, rsv_varod8, rsv_num1, rsv_num2
     , rsv_num3, rsv_date1, rsv_date2, rsv_date3, report_up_serial)
   select oem.exp_type, oem.warehouse_no, oem.exp_no, oem.owner_no, oem.owner_cust_no, oem.cust_no, oem.sub_cust_no, oem.sourceexp_type
     , oem.sourceexp_no, oem.exp_date, oem.fast_flag, oem.status, oem.priority, oem.add_exp_no, oem.import_no, oem.deliver_type
     , oem.transport_type, oem.batch_no, oem.line_no, oem.full_line_name, oem.cust_address, oem.cust_address_code, oem.contactor_name, oem.cust_phone
     , oem.cust_mail, oem.error_status, oem.create_flag, oem.return_flag, oem.exp_remark, oem.belong_flag, oem.send_flag, oem.buffer_line_no
     , oem.special_article_group, oem.exp_status, oem.stock_type, oem.order_period, oem.finance_type, oem.kick_flag, oem.real_cust_no, oem.real_cust_name
     , oem.dept_name, oem.agent_no, oem.payment_term, oem.dept_no, oem.cust_exp_no, oem.erpoperate_date, oem.custsend_date, oem.print_flag
     , oem.erp_no, oem.diff_reason, oem.rgst_name, oem.rgst_date, strUserID, sysdate, oem.wave_no, oem.enterprise_no
     , oem.shipper_deliver_no, oem.deliver_address, oem.shipper_no, oem.print_bill_flag, oem.order_source, oem.org_no, oem.rsv_varod1, oem.rsv_varod2
     , oem.rsv_varod3, oem.rsv_varod4, oem.rsv_varod5, oem.rsv_varod6, oem.rsv_varod7, oem.rsv_varod8, oem.rsv_num1, oem.rsv_num2
     , oem.rsv_num3, oem.rsv_date1, oem.rsv_date2, oem.rsv_date3, oem.report_up_serial
   from odata_exp_m oem
   where oem.enterprise_no = strEnterpriseNo
     and oem.warehouse_no = strWareHouseNo
     and exists
         (select 'X' from odata_deliver_m odm,odata_deliver_d odd
           where odd.enterprise_no = odm.enterprise_no
             and odd.warehouse_no = odm.warehouse_no
             and odd.owner_no = odm.owner_no
             and odd.deliver_no = odm.deliver_no
             and oem.enterprise_no = odd.enterprise_no
             and oem.warehouse_no = odd.warehouse_no
             and oem.owner_no = odd.owner_no
             and oem.exp_no = odd.exp_no
             and odm.enterprise_no = strEnterpriseNo
             and odm.warehouse_no = strWareHouseNo
             and odm.loadpropose_no = strProposeNo);

   --出货单明细转历史
   insert into odata_exp_dhty
     (warehouse_no, owner_no, exp_no, article_no, packing_qty, article_qty, schedule_qty, locate_qty
     , real_qty, unit_cost, owner_article_no, produce_condition, produce_value1, produce_value2, expire_condition, expire_value1
     , expire_value2, quality_condition, quality_value1, quality_value2, lotno_condition, lotno_value1, lotno_value2, rsvbatch1_condition
     , rsvbatch1_value1, rsvbatch1_value2, rsvbatch2_condition, rsvbatch2_value1, rsvbatch2_value2, rsvbatch3_condition, rsvbatch3_value1, rsvbatch3_value2
     , rsvbatch4_condition, rsvbatch4_value1, rsvbatch4_value2, rsvbatch5_condition, rsvbatch5_value1, rsvbatch5_value2, rsvbatch6_condition, rsvbatch6_value1
     , rsvbatch6_value2, rsvbatch7_condition, rsvbatch7_value1, rsvbatch7_value2, rsvbatch8_condition, rsvbatch8_value1, rsvbatch8_value2, specify_field
     , specify_condition, specify_value1, specify_value2, status, error_status, rgst_date, exp_date, enterprise_no, row_id)
   select oed.warehouse_no, oed.owner_no, oed.exp_no, oed.article_no, oed.packing_qty, oed.article_qty, oed.schedule_qty, oed.locate_qty
     , oed.real_qty, oed.unit_cost, oed.owner_article_no, oed.produce_condition, oed.produce_value1, oed.produce_value2, oed.expire_condition, oed.expire_value1
     , oed.expire_value2, oed.quality_condition, oed.quality_value1, oed.quality_value2, oed.lotno_condition, oed.lotno_value1, oed.lotno_value2, oed.rsvbatch1_condition
     , oed.rsvbatch1_value1, oed.rsvbatch1_value2, oed.rsvbatch2_condition, oed.rsvbatch2_value1, oed.rsvbatch2_value2, oed.rsvbatch3_condition, oed.rsvbatch3_value1, oed.rsvbatch3_value2
     , oed.rsvbatch4_condition, oed.rsvbatch4_value1, oed.rsvbatch4_value2, oed.rsvbatch5_condition, oed.rsvbatch5_value1, oed.rsvbatch5_value2, oed.rsvbatch6_condition, oed.rsvbatch6_value1
     , oed.rsvbatch6_value2, oed.rsvbatch7_condition, oed.rsvbatch7_value1, oed.rsvbatch7_value2, oed.rsvbatch8_condition, oed.rsvbatch8_value1, oed.rsvbatch8_value2, oed.specify_field
     , oed.specify_condition, oed.specify_value1, oed.specify_value2, oed.status, oed.error_status, oed.rgst_date, oed.exp_date, oed.enterprise_no, oed.row_id
   from odata_exp_d oed
   where oed.enterprise_no = strEnterpriseNo
     and oed.warehouse_no = strWareHouseNo
     and exists
         (select 'X' from odata_deliver_m odm,odata_deliver_d odd
           where odd.enterprise_no = odm.enterprise_no
             and odd.warehouse_no = odm.warehouse_no
             and odd.owner_no = odm.owner_no
             and odd.deliver_no = odm.deliver_no
             and oed.enterprise_no = odd.enterprise_no
             and oed.warehouse_no = odd.warehouse_no
             and oed.owner_no = odd.owner_no
             and oed.exp_no = odd.exp_no
             and odm.enterprise_no = strEnterpriseNo
             and odm.warehouse_no = strWareHouseNo
             and odm.loadpropose_no = strProposeNo);

   --装车建议单头档转历史
   insert into odata_loadpropose_mhty
     (warehouse_no, operate_date, loadpropose_no, cartype_no, line_no, dock_no, status
     , car_plate, seal_no, cust_no, divide_truck, send_flag, shipper_no, real_shipper_no
     , exp_date, car_plan_no, rgst_name, rgst_date, updt_name, updt_date, loadtype
     , enterprise_no, report_up_serial)
   select olm.warehouse_no, olm.operate_date, olm.loadpropose_no, olm.cartype_no, olm.line_no, olm.dock_no, olm.status
     , olm.car_plate, olm.seal_no, olm.cust_no, olm.divide_truck, olm.send_flag, olm.shipper_no, olm.real_shipper_no
     , olm.exp_date, olm.car_plan_no, olm.rgst_name, olm.rgst_date, strUserID, sysdate, olm.loadtype
     , olm.enterprise_no, olm.report_up_serial
   from odata_loadpropose_m olm
   where olm.enterprise_no = strEnterpriseNo
     and olm.warehouse_no = strWareHouseNo
     and olm.loadpropose_no = strProposeNo;

   --装车建议单明细转历史
   insert into odata_loadpropose_dhty
     (warehouse_no, loadpropose_no, cust_no, container_type, container_no, load_order, exp_no
     , status, deliver_obj, load_name, load_date, assign_name, exp_date, enterprise_no, box_num)
   select olpd.warehouse_no, olpd.loadpropose_no, olpd.cust_no, olpd.container_type, olpd.container_no, olpd.load_order, olpd.exp_no
     , olpd.status, olpd.deliver_obj, olpd.load_name, olpd.load_date, olpd.assign_name, olpd.exp_date, olpd.enterprise_no, olpd.box_num
   from odata_loadpropose_d olpd
   where olpd.enterprise_no = strEnterpriseNo
     and olpd.warehouse_no = strWareHouseNo
     and olpd.loadpropose_no = strProposeNo;

   --封车单明细转历史
   /*insert into odata_deliver_dhty
     (warehouse_no, owner_no, deliver_no, container_no, container_id, exp_type, exp_no
     , wave_no, article_no, barcode, packing_qty, produce_date, expire_date, quality
     , lot_no, import_batch_no, rsv_batch1, rsv_batch2, rsv_batch3, rsv_batch4, rsv_batch5
     , rsv_batch6, rsv_batch7, rsv_batch8, qty, article_id, exp_date, real_qty
     , status, rgst_name, rgst_date, updt_name, updt_date, label_no, enterprise_no)
   select odd.warehouse_no, odd.owner_no, odd.deliver_no, odd.container_no, odd.container_id, odd.exp_type, odd.exp_no
     , odd.wave_no, odd.article_no, odd.barcode, odd.packing_qty, odd.produce_date, odd.expire_date, odd.quality
     , odd.lot_no, odd.import_batch_no, odd.rsv_batch1, odd.rsv_batch2, odd.rsv_batch3, odd.rsv_batch4, odd.rsv_batch5
     , odd.rsv_batch6, odd.rsv_batch7, odd.rsv_batch8, odd.qty, odd.article_id, odd.exp_date, odd.real_qty
     , odd.status, odd.rgst_name, odd.rgst_date, odd.updt_name, odd.updt_date, odd.label_no, odd.enterprise_no
   from odata_deliver_d odd
   where odd.enterprise_no = strEnterpriseNo
     and odd.warehouse_no = strWareHouseNo
     and exists
         (select 'X' from odata_deliver_m odm
           where odd.enterprise_no = odm.enterprise_no
             and odd.warehouse_no = odm.warehouse_no
             and odd.owner_no = odm.owner_no
             and odd.deliver_no = odm.deliver_no
             and odm.enterprise_no = strEnterpriseNo
             and odm.warehouse_no = strWareHouseNo
             and odm.loadpropose_no = strProposeNo);*/

  /* --封车单头档转历史
   insert into odata_deliver_mhty
     (warehouse_no, owner_no, operate_date, loadpropose_no, deliver_no, line_no, cartype_no
     , car_plate, send_name, status, cust_no, seal_no, send_flag, logbox_num
     , dip_flag, exp_date, car_plan_no, rgst_name, rgst_date, updt_name, updt_date
     , enterprise_no, deliver_obj, report_up_serial)
   select odm.warehouse_no, odm.owner_no, odm.operate_date, odm.loadpropose_no, odm.deliver_no, odm.line_no, odm.cartype_no
     , odm.car_plate, odm.send_name, odm.status, odm.cust_no, odm.seal_no, odm.send_flag, odm.logbox_num
     , odm.dip_flag, odm.exp_date, odm.car_plan_no, odm.rgst_name, odm.rgst_date, strUserID, sysdate
     , odm.enterprise_no, odm.deliver_obj, odm.report_up_serial
   from odata_deliver_m odm
   where odm.enterprise_no = strEnterpriseNo
     and odm.warehouse_no = strWareHouseNo
     and odm.loadpropose_no = strProposeNo;*/

   --删除正表数据
   delete odata_exp_m oem
    where oem.enterprise_no = strEnterpriseNo
      and oem.warehouse_no = strWareHouseNo
      and exists
          (select 'X' from odata_deliver_m odm,odata_deliver_d odd
            where odd.enterprise_no = odm.enterprise_no
              and odd.warehouse_no = odm.warehouse_no
              and odd.owner_no = odm.owner_no
              and odd.deliver_no = odm.deliver_no
              and oem.enterprise_no = odd.enterprise_no
              and oem.warehouse_no = odd.warehouse_no
              and oem.owner_no = odd.owner_no
              and oem.exp_no = odd.exp_no
              and odm.enterprise_no = strEnterpriseNo
              and odm.warehouse_no = strWareHouseNo
              and odm.loadpropose_no = strProposeNo);

   delete odata_exp_d oed
    where oed.enterprise_no = strEnterpriseNo
      and oed.warehouse_no = strWareHouseNo
      and exists
          (select 'X' from odata_deliver_m odm,odata_deliver_d odd
            where odd.enterprise_no = odm.enterprise_no
              and odd.warehouse_no = odm.warehouse_no
              and odd.owner_no = odm.owner_no
              and odd.deliver_no = odm.deliver_no
              and oed.enterprise_no = odd.enterprise_no
              and oed.warehouse_no = odd.warehouse_no
              and oed.owner_no = odd.owner_no
              and oed.exp_no = odd.exp_no
              and odm.enterprise_no = strEnterpriseNo
              and odm.warehouse_no = strWareHouseNo
              and odm.loadpropose_no = strProposeNo);

   delete odata_loadpropose_m olm
    where olm.enterprise_no = strEnterpriseNo
      and olm.warehouse_no = strWareHouseNo
      and olm.loadpropose_no = strProposeNo;

   delete odata_loadpropose_d olpd
    where olpd.enterprise_no = strEnterpriseNo
      and olpd.warehouse_no = strWareHouseNo
      and olpd.loadpropose_no = strProposeNo;

   /*delete odata_deliver_d odd
   where odd.enterprise_no = strEnterpriseNo
     and odd.warehouse_no = strWareHouseNo
     and exists
         (select 'X' from odata_deliver_m odm
           where odd.enterprise_no = odm.enterprise_no
             and odd.warehouse_no = odm.warehouse_no
             and odd.owner_no = odm.owner_no
             and odd.deliver_no = odm.deliver_no
             and odm.enterprise_no = strEnterpriseNo
             and odm.warehouse_no = strWareHouseNo
             and odm.loadpropose_no = strProposeNo);

   delete odata_deliver_m odm
    where odm.enterprise_no = strEnterpriseNo
      and odm.warehouse_no = strWareHouseNo
      and odm.loadpropose_no = strProposeNo;*/

  strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|P_Deliver_InsertHTY' || SQLERRM ||
            substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end P_Deliver_InsertHTY;

  /*******************************************************************************************************
  创建人：huangb
  创建时间：2016.05.17
  功能说明：封车单据转历史 供JOB调用
  ********************************************************************************************************/
  procedure P_Deliver_InsertHTYByJob is
   begin

    --封车单明细转历史
    insert into odata_deliver_dhty
      (warehouse_no, owner_no, deliver_no, container_no, container_id, exp_type, exp_no
      , wave_no, article_no, barcode, packing_qty, produce_date, expire_date, quality
      , lot_no, import_batch_no, rsv_batch1, rsv_batch2, rsv_batch3, rsv_batch4, rsv_batch5
      , rsv_batch6, rsv_batch7, rsv_batch8, qty, article_id, exp_date, real_qty
      , status, rgst_name, rgst_date, updt_name, updt_date, label_no, enterprise_no)
    select odd.warehouse_no, odd.owner_no, odd.deliver_no, odd.container_no, odd.container_id, odd.exp_type, odd.exp_no
      , odd.wave_no, odd.article_no, odd.barcode, odd.packing_qty, odd.produce_date, odd.expire_date, odd.quality
      , odd.lot_no, odd.import_batch_no, odd.rsv_batch1, odd.rsv_batch2, odd.rsv_batch3, odd.rsv_batch4, odd.rsv_batch5
      , odd.rsv_batch6, odd.rsv_batch7, odd.rsv_batch8, odd.qty, odd.article_id, odd.exp_date, odd.real_qty
      , odd.status, odd.rgst_name, odd.rgst_date, odd.updt_name, odd.updt_date, odd.label_no, odd.enterprise_no
    from odata_deliver_d odd where odd.status = '13';

    --封车单头档转历史
    insert into odata_deliver_mhty
      (warehouse_no, owner_no, operate_date, loadpropose_no, deliver_no, line_no, cartype_no
      , car_plate, send_name, status, cust_no, seal_no, send_flag, logbox_num
      , dip_flag, exp_date, car_plan_no, rgst_name, rgst_date, updt_name, updt_date
      , enterprise_no, deliver_obj, report_up_serial)
    select odm.warehouse_no, odm.owner_no, odm.operate_date, odm.loadpropose_no, odm.deliver_no, odm.line_no, odm.cartype_no
      , odm.car_plate, odm.send_name, odm.status, odm.cust_no, odm.seal_no, odm.send_flag, odm.logbox_num
      , odm.dip_flag, odm.exp_date, odm.car_plan_no, odm.rgst_name, odm.rgst_date, 'admin', sysdate
      , odm.enterprise_no, odm.deliver_obj, odm.report_up_serial
    from odata_deliver_m odm where odm.status = '13';

    --删除正表数据
    delete odata_deliver_d odd where odd.status = '13';
    delete odata_deliver_m odm where odm.status = '13';

  end P_Deliver_InsertHTYByJob;

  /*******************************************************************************************************
  创建人：huangb
  创建时间：2016.05.17
  功能说明：封车单据转历史 供接口调用
  ********************************************************************************************************/
  procedure P_Deliver_InsertHTYByInterface(strEnterpriseNo   in odata_deliver_mhty.enterprise_no%type, --企业编号
                                           strWareHouseNo    in odata_deliver_mhty.warehouse_no%type, --仓库编码
                                           strReportUpSerial in odata_deliver_mhty.REPORT_UP_SERIAL%type, --上传序列号
                                           strOutMsg         out varchar2) is
   begin
    strOutMsg := 'N|[P_Deliver_InsertHTYByInterface]';

    --封车单明细转历史
    insert into odata_deliver_dhty
      (warehouse_no, owner_no, deliver_no, container_no, container_id, exp_type, exp_no
      , wave_no, article_no, barcode, packing_qty, produce_date, expire_date, quality
      , lot_no, import_batch_no, rsv_batch1, rsv_batch2, rsv_batch3, rsv_batch4, rsv_batch5
      , rsv_batch6, rsv_batch7, rsv_batch8, qty, article_id, exp_date, real_qty
      , status, rgst_name, rgst_date, updt_name, updt_date, label_no, enterprise_no)
    select odd.warehouse_no, odd.owner_no, odd.deliver_no, odd.container_no, odd.container_id, odd.exp_type, odd.exp_no
      , odd.wave_no, odd.article_no, odd.barcode, odd.packing_qty, odd.produce_date, odd.expire_date, odd.quality
      , odd.lot_no, odd.import_batch_no, odd.rsv_batch1, odd.rsv_batch2, odd.rsv_batch3, odd.rsv_batch4, odd.rsv_batch5
      , odd.rsv_batch6, odd.rsv_batch7, odd.rsv_batch8, odd.qty, odd.article_id, odd.exp_date, odd.real_qty
      , odd.status, odd.rgst_name, odd.rgst_date, odd.updt_name, odd.updt_date, odd.label_no, odd.enterprise_no
    from odata_deliver_d odd
    where odd.enterprise_no = strEnterpriseNo
      and odd.warehouse_no = strWareHouseNo
      and exists
          (select 'X' from odata_deliver_m odm
            where odd.enterprise_no = odm.enterprise_no
              and odd.warehouse_no = odm.warehouse_no
              and odd.owner_no = odm.owner_no
              and odd.deliver_no = odm.deliver_no
              and odm.enterprise_no = strEnterpriseNo
              and odm.warehouse_no = strWareHouseNo
              and odm.report_up_serial = strReportUpSerial);

    --封车单头档转历史
    insert into odata_deliver_mhty
      (warehouse_no, owner_no, operate_date, loadpropose_no, deliver_no, line_no, cartype_no
      , car_plate, send_name, status, cust_no, seal_no, send_flag, logbox_num
      , dip_flag, exp_date, car_plan_no, rgst_name, rgst_date, updt_name, updt_date
      , enterprise_no, deliver_obj, report_up_serial)
    select odm.warehouse_no, odm.owner_no, odm.operate_date, odm.loadpropose_no, odm.deliver_no, odm.line_no, odm.cartype_no
      , odm.car_plate, odm.send_name, odm.status, odm.cust_no, odm.seal_no, odm.send_flag, odm.logbox_num
      , odm.dip_flag, odm.exp_date, odm.car_plan_no, odm.rgst_name, odm.rgst_date, 'admin', sysdate
      , odm.enterprise_no, odm.deliver_obj, odm.report_up_serial
    from odata_deliver_m odm
    where odm.enterprise_no = strEnterpriseNo
      and odm.warehouse_no = strWareHouseNo
      and odm.report_up_serial <= strReportUpSerial;

    --删除正表数据
    delete odata_deliver_d odd
    where odd.enterprise_no = strEnterpriseNo
      and odd.warehouse_no = strWareHouseNo
      and exists
          (select 'X' from odata_deliver_m odm
            where odd.enterprise_no = odm.enterprise_no
              and odd.warehouse_no = odm.warehouse_no
              and odd.owner_no = odm.owner_no
              and odd.deliver_no = odm.deliver_no
              and odm.enterprise_no = strEnterpriseNo
              and odm.warehouse_no = strWareHouseNo
              and odm.report_up_serial <= strReportUpSerial);

    delete odata_deliver_m odm
     where odm.enterprise_no = strEnterpriseNo
       and odm.warehouse_no = strWareHouseNo
       and odm.report_up_serial <= strReportUpSerial;

    strOutMsg := 'Y|';
   exception
     when others then
       strOutMsg := 'N|P_Deliver_InsertHTYByInterface' || SQLERRM ||
             substr(dbms_utility.format_error_backtrace, 1, 256);
       return;

  end P_Deliver_InsertHTYByInterface;

end PKOBJ_ODATA_DELIVER;

/

