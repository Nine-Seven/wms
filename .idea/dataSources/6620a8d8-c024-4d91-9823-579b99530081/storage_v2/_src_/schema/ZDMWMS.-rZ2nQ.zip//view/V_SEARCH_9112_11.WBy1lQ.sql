create view V_SEARCH_9112_11 as
SELECT r.enterprise_no,
       r.warehouse_no,
       r.owner_no,
       o.owner_alias,
       r.jc_date,
       a.owner_article_no,
       a.barcode,
       a.article_name,
       a.article_identifier,
       trunc((case
               when 2 * A.UNIT_VOLUMN / 2.16 / 1000000 < 0.0001 then
                0.0001
               else
                2 * A.UNIT_VOLUMN / 2.16 / 1000000
             end),
             6) unit_price,
       r.qc_qty,
       r.out_qty,
       r.in_qty,
       r.qty,
       r.import_batch_no
  FROM stock_content_rj r, bdef_defarticle a, bdef_defowner o
 WHERE r.enterprise_no = o.enterprise_no
   AND r.owner_no = o.owner_no
   AND r.enterprise_no = a.enterprise_no
   AND r.article_no = a.article_no
 ORDER BY r.warehouse_no, r.jc_date, r.owner_no, a.owner_article_no

/

