create package body        pkOBJ_label_odata is
  --出货标签
  -----------------------------------------------------------------------------------------------------------出 货  发 单
  --------------------------------------------------------出货发单写标签入口 begin-------------------------------------------------------------
  --------------------------------------------------------按容器写标签 begin-------------------------------------------------------------
  /*****************************************************************************************
     功能：按容器写标签——M 补货，暂未实现，报表ID未定义
  *****************************************************************************************/
  procedure P_H_WriteLabelContainerNo_M(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                        strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                        strOwnerNo      in odata_outstock_m.owner_no%type,
                                        strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                        strOperateType  in odata_outstock_m.operate_type%type,
                                        strSourceType   in odata_outstock_m.source_type%type,
                                        strPickType     in odata_outstock_m.pick_type%type,
                                        strPrintType    in odata_outstock_m.print_type%type,
                                        strUserID       in stock_label_m.updt_name%type, --员工ID
                                        strOutMsg       out varchar2) --返回值
   is
    nIndex                number(10); --是否进入 明细 循环;
    nContainerIndex       number(10); --是否进入 容器 循环
    strContainerType      varchar2(1); --容器类型
    strContainerNo        varchar2(24); --容器号
    strReport_ID          varchar2(20); --报表ＩＤ
    nRowID                number(10); --标签明细序列号
    strUserType           varchar2(1); --标签用途(1：客户标签，2：分播标签，3：移库标签)
    strStatus             varchar2(2); --标签状态
    strDeliverObj         odata_outstock_direct.deliver_obj%type; --配送对象
    strLabelNo            varchar2(24); --标签号
    strManualFlag         varchar2(1); --库存记录方式（0, 记录在标签上  1，记录在储位上）
    strProduceLableTypeC  varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)
    nProduceLableTypeC    varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)
    odata_outstock_d_Info odata_outstock_d%rowtype;
  begin
    strOutMsg     := 'N|[P_H_WriteLabelContainerNo_M]';
    strManualFlag := '1';

    begin
      pklg_wms_base.p_GetBasePara(strEnterPriseNo,
                                  strwarehouse_no,
                                  strOwnerNo,
                                  'TaskOmProduceLableTypeC',
                                  'O',
                                  'O_TASK',
                                  strProduceLableTypeC,
                                  nProduceLableTypeC,
                                  strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        strOutMsg := 'N|[E22105]';
        return;
      end if;
    exception
      when others then
        strOutMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
        return;
    end;
    if strProduceLableTypeC = '1' then
      strManualFlag := '0';
    end if;
    ---------------循环容器号---------------
    for Om_Container_Info in (SELECT DISTINCT enterprise_no,
                                              warehouse_no,
                                              wave_no,
                                              OUTSTOCK_NO,
                                              S_CONTAINER_NO
                                FROM odata_outstock_d A
                               WHERE A.warehouse_no = strwarehouse_no
                                 and a.enterprise_no = strEnterPriseNo
                                 AND A.OUTSTOCK_NO = strOutStockNo
                               ORDER BY enterprise_no,
                                        warehouse_no,
                                        OUTSTOCK_NO,
                                        S_CONTAINER_NO) loop
      nContainerIndex := 1;
      nRowID          := 1;

      strReport_ID     := CONST_REPORTID.B_HMTask_CD;
      strContainerType := 'P';
      strUserType      := '3';
      strStatus        := '40';
      strContainerNo   := Om_Container_Info.s_Container_No;
      ---------------新增标签明细 ---------------
      for odata_outstock_d_Info in (SELECT A.*
                                      FROM odata_outstock_d A
                                     WHERE A.warehouse_no =
                                           Om_Container_Info.warehouse_no
                                       and a.enterprise_no =
                                           Om_Container_Info.enterprise_no
                                       AND A.Outstock_No =
                                           Om_Container_Info.Outstock_No
                                       and A.wave_no =
                                           Om_Container_Info.wave_no
                                       and A.s_Container_No =
                                           Om_Container_Info.s_Container_No) loop
        ---------------是否进入循环---------------
        nIndex := 1;
        ---------------配送对象---------------
        strDeliverObj := 'N';
        ---------------新增标签明细---------------
        insert into stock_label_d
          (enterprise_no,
           warehouse_no,
           BATCH_NO,
           OWNER_NO,
           SOURCE_NO,
           CONTAINER_NO,
           CONTAINER_TYPE,
           ARTICLE_NO,
           ARTICLE_ID,
           PACKING_QTY,
           QTY,
           EXP_NO,
           WAVE_NO,
           CUST_NO,
           SUB_CUST_NO,
           LINE_NO,
           STATUS,
           DIVIDE_ID,
           RGST_NAME,
           RGST_DATE,
           EXP_TYPE,
           EXP_DATE,
           DPS_CELL_NO,
           DELIVER_OBJ,
           ROW_ID,
           deliverobj_order,
           ADVANCE_CELL_NO)--Modify BY QZH AT 2016-5-25
        values
          (odata_outstock_d_Info.enterprise_no,
           odata_outstock_d_Info.warehouse_no,
           odata_outstock_d_Info.Batch_No,
           odata_outstock_d_Info.Owner_No,
           odata_outstock_d_Info.Outstock_No,
           odata_outstock_d_Info.s_Container_No,
           strContainerType,
           odata_outstock_d_Info.Article_No,
           odata_outstock_d_Info.Article_Id,
           odata_outstock_d_Info.Packing_Qty,
           odata_outstock_d_Info.Article_Qty,
           odata_outstock_d_Info.Exp_No,
           odata_outstock_d_Info.wave_no,
           odata_outstock_d_Info.Cust_No,
           odata_outstock_d_Info.Sub_Cust_No,
           odata_outstock_d_Info.Line_No,
           strStatus,
           odata_outstock_d_Info.Divide_Id,
           strUserID,
           sysdate,
           odata_outstock_d_Info.Exp_Type,
           odata_outstock_d_Info.Exp_Date,
           odata_outstock_d_Info.Dps_Cell_No,
           --strDeliverObj,
           odata_outstock_d_Info.Deliver_Obj,
           nRowID,
           odata_outstock_d_Info.deliverobj_order,
           odata_outstock_d_Info.s_Cell_No);
        ---------------新增失败---------------
        if sql%rowcount <= 0 then
          strOutMsg := 'N|[E22108]';
          return;
        end if;
        ---------------标签取号---------------
        if nRowID = 1 then
          begin
            SELECT SUBSTR(Om_Container_Info.s_Container_No,
                          length(b.container_prefix) + 1)
              into strLabelNo
              FROM WMS_DEFCONTAINER B
             WHERE B.warehouse_no = Om_Container_Info.warehouse_no
               and b.enterprise_no = Om_Container_Info.enterprise_no
               AND B.CONTAINER_TYPE = 'P'
               and rownum <= 1;
          end;
          if sql%notfound then
            strOutMsg := 'N|[E22109]';
            return;
          end if;
          if strLabelNo is null then
            strOutMsg := 'N|[E22109]';
            return;
          end if;
          ---------------写标签头---------------
          PKOBJ_LABEL.proc_Insert_LabelMaster(odata_outstock_d_Info.enterprise_no,
                                              odata_outstock_d_Info.warehouse_no,
                                              odata_outstock_d_Info.Batch_No,
                                              odata_outstock_d_Info.Outstock_No,
                                              strLabelNo,
                                              odata_outstock_d_Info.s_Container_No,
                                              strContainerType,
                                              odata_outstock_d_Info.Deliver_Area,
                                              odata_outstock_d_Info.s_Cell_No,
                                              odata_outstock_d_Info.Cust_No,
                                              odata_outstock_d_Info.Trunck_Cell_No,
                                              odata_outstock_d_Info.a_Sorter_Chute_No,
                                              odata_outstock_d_Info.Check_Chute_No,
                                              strDeliverObj,
                                              strUserType,
                                              odata_outstock_d_Info.Line_No,
                                              odata_outstock_d_Info.Advance_Cell_No,
                                              odata_outstock_d_Info.device_no,
                                              strUserID,
                                              strReport_ID,
                                              '',
                                              '',
                                              odata_outstock_d_Info.Stock_Type,
                                              '0',
                                              odata_outstock_d_Info.s_Container_No,
                                              strStatus,
                                              strManualFlag,
                                              odata_outstock_d_Info.wave_no,
                                              strOutMsg);
          if instr(strOutMsg, 'N', 1, 1) = 1 then
            return;
          end if;
        end if;
        ---------------序列号---------------
        nRowID := nRowID + 1;
      end loop;
      if (nIndex < 1) then
        strOutMsg := 'N|[E22107]';
        return;
      end if;
    end loop;
    if (nContainerIndex < 1) then
      strOutMsg := 'N|[E22107]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_H_WriteLabelContainerNo_M;

  /*****************************************************************************************
     功能：按容器写标签——P 型   出货，
  *****************************************************************************************/
  procedure P_O_WriteLabelContainerNo_P(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                        strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                        strOwnerNo      in odata_outstock_m.owner_no%type,
                                        strExpType      in odata_exp_m.exp_type%type,
                                        strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                        strOperateType  in odata_outstock_m.operate_type%type,
                                        strSourceType   in odata_outstock_m.source_type%type,
                                        strPickType     in odata_outstock_m.pick_type%type,
                                        strPrintType    in odata_outstock_m.print_type%type,
                                        strUserID       in stock_label_m.updt_name%type, --员工ID
                                        strOutMsg       out varchar2) --返回值
   is
    nIndex                number(10); --是否进入明细循环;
    nContainerIndex       number(10); --是否进入容器循环
    strContainerType      varchar2(1); --容器类型
    strContainerNo        odata_outstock_d.s_container_no%type; --容器号
    strReport_ID          varchar2(20); --报表ＩＤ
    nRowID                number(10); --标签明细序列号
    strUserType           varchar2(1); --标签用途(1：客户标签，2：分播标签，3：移库标签)
    strStatus             varchar2(2); --标签状态
    strDeliverObj         odata_outstock_d.deliver_obj%type; --配送对象
    strLabelNo            stock_label_m.label_no%type; --标签号
    strManualFlag         varchar2(1); --库存记录方式（0, 记录在标签上  1，记录在储位上）
    strProduceLableTypeC  varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)
    nProduceLableTypeC    varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)
    odata_outstock_d_Info odata_outstock_d%rowtype;
  begin
    strOutMsg     := 'N|[P_O_WriteLabelContainerNo_P]';
    strManualFlag := '1';

    begin
      pklg_wms_base.p_GetBasePara(strEnterPriseNo,
                                  strwarehouse_no,
                                  strOwnerNo,
                                  'TaskOmProduceLableTypeC',
                                  'O',
                                  'O_TASK',
                                  strProduceLableTypeC,
                                  nProduceLableTypeC,
                                  strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        strOutMsg := 'N|[E22105]';
        return;
      end if;
    exception
      when others then
        strOutMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
        return;
    end;

    if strProduceLableTypeC = '1' then
      strManualFlag := '0';
    end if;
    if strPrintType = '2' or strPrintType = '6' or strSourceType = '4' then
      strReport_ID := CONST_REPORTID.B_CustPickLabel_PM1;
    else
      strReport_ID := CONST_REPORTID.B_CustPickLabel_PD2;
    end if;

    if strSourceType = '4' then
      strManualFlag := '0';
    end if;

    ---------------循环容器号---------------
    for Om_Container_Info in (SELECT DISTINCT enterprise_no,
                                              warehouse_no,
                                              wave_no,
                                              OUTSTOCK_NO,
                                              S_CONTAINER_NO
                                FROM odata_outstock_d A
                               WHERE A.warehouse_no = strwarehouse_no
                                 and a.enterprise_no = strEnterPriseNo
                                 AND A.OUTSTOCK_NO = strOutStockNo
                               ORDER BY enterprise_no,
                                        warehouse_no,
                                        OUTSTOCK_NO,
                                        S_CONTAINER_NO) loop
      nContainerIndex := 1;
      nRowID          := 1;

      strContainerType := 'P';
      strUserType      := 1;
      strStatus        := '50';
      strContainerNo   := Om_Container_Info.s_Container_No;
      ---------------新增标签明细 ---------------
      for odata_outstock_d_Info in (SELECT A.*
                                      FROM odata_outstock_d A
                                     WHERE A.Enterprise_No = strEnterPriseNo
                                       and A.warehouse_no = strwarehouse_no
                                       AND A.Outstock_No = strOutStockNo
                                       and A.wave_no =
                                           Om_Container_Info.wave_no
                                       and A.s_Container_No =
                                           Om_Container_Info.s_Container_No) loop
        ---------------是否进入循环---------------
        nIndex := 1;
        ---------------配送对象---------------
        strDeliverObj := odata_outstock_d_Info.Deliver_Obj;
        ---------------新增标签明细---------------
        insert into stock_label_d
          (enterprise_no,
           warehouse_no,
           BATCH_NO,
           OWNER_NO,
           SOURCE_NO,
           CONTAINER_NO,
           CONTAINER_TYPE,
           ARTICLE_NO,
           ARTICLE_ID,
           PACKING_QTY,
           QTY,
           EXP_NO,
           wave_no,
           CUST_NO,
           SUB_CUST_NO,
           LINE_NO,
           STATUS,
           DIVIDE_ID,
           RGST_NAME,
           RGST_DATE,
           EXP_TYPE,
           EXP_DATE,
           DPS_CELL_NO,
           DELIVER_OBJ,
           ROW_ID,
           deliverobj_order,
           ADVANCE_CELL_NO) --Modify BY QZH AT 2016-5-25
        values
          (strEnterPriseNo,
           odata_outstock_d_Info.warehouse_no,
           odata_outstock_d_Info.Batch_No,
           odata_outstock_d_Info.Owner_No,
           odata_outstock_d_Info.Outstock_No,
           odata_outstock_d_Info.s_Container_No,
           strContainerType,
           odata_outstock_d_Info.Article_No,
           odata_outstock_d_Info.Article_Id,
           odata_outstock_d_Info.Packing_Qty,
           odata_outstock_d_Info.Article_Qty,
           odata_outstock_d_Info.Exp_No,
           odata_outstock_d_Info.wave_no,
           odata_outstock_d_Info.Cust_No,
           odata_outstock_d_Info.Sub_Cust_No,
           odata_outstock_d_Info.Line_No,
           strStatus,
           odata_outstock_d_Info.Divide_Id,
           strUserID,
           sysdate,
           odata_outstock_d_Info.Exp_Type,
           odata_outstock_d_Info.Exp_Date,
           odata_outstock_d_Info.Dps_Cell_No,
           --strDeliverObj,
           odata_outstock_d_Info.Deliver_Obj,
           nRowID,
           odata_outstock_d_Info.deliverobj_order,
           odata_outstock_d_Info.s_cell_no);
        ---------------新增失败---------------
        if sql%rowcount <= 0 then
          strOutMsg := 'N|[E22108]';
          return;
        end if;
        if nRowID = 1 then
          ---------------标签取号---------------
          begin
            SELECT SUBSTR(Om_Container_Info.s_Container_No,
                          length(b.container_prefix) + 1)
              into strLabelNo
              FROM WMS_DEFCONTAINER B
             WHERE B.warehouse_no = Om_Container_Info.warehouse_no
               and b.enterprise_no = strEnterPriseNo
               AND B.CONTAINER_TYPE = 'P'
               and rownum <= 1;
          end;
          if sql%notfound then
            strOutMsg := 'N|[E22109]';
            return;
          end if;
          if strLabelNo is null then
            strOutMsg := 'N|[E22109]';
            return;
          end if;
          ---------------写标签头---------------
          PKOBJ_LABEL.proc_Insert_LabelMaster(strEnterPriseNo,
                                              odata_outstock_d_Info.warehouse_no,
                                              odata_outstock_d_Info.Batch_No,
                                              odata_outstock_d_Info.Outstock_No,
                                              strLabelNo,
                                              odata_outstock_d_Info.s_Container_No,
                                              strContainerType,
                                              odata_outstock_d_Info.Deliver_Area,
                                              odata_outstock_d_Info.s_Cell_No,
                                              odata_outstock_d_Info.Cust_No,
                                              odata_outstock_d_Info.Trunck_Cell_No,
                                              odata_outstock_d_Info.a_Sorter_Chute_No,
                                              odata_outstock_d_Info.Check_Chute_No,
                                              strDeliverObj,
                                              strUserType,
                                              odata_outstock_d_Info.Line_No,
                                              odata_outstock_d_Info.Advance_Cell_No,
                                              odata_outstock_d_Info.device_no,
                                              strUserID,
                                              strReport_ID,
                                              '',
                                              '',
                                              odata_outstock_d_Info.Stock_Type,
                                              '0',
                                              odata_outstock_d_Info.s_Container_No,
                                              strStatus,
                                              strManualFlag,
                                              odata_outstock_d_Info.wave_no,
                                              strOutMsg);
          if instr(strOutMsg, 'N', 1, 1) = 1 then
            return;
          end if;
        end if;
        ---------------序列号---------------
        nRowID := nRowID + 1;
      end loop;
      if (nIndex < 1) then
        strOutMsg := 'N|[E22107]';
        return;
      end if;
    end loop;
    if (nContainerIndex < 1) then
      strOutMsg := 'N|[E22107]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_WriteLabelContainerNo_P;

  /*****************************************************************************************
     功能：按容器写标签——B 型  出货
  *****************************************************************************************/
  procedure P_O_WriteLabelContainerNo_B(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                        strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                        strOwnerNo      in odata_outstock_m.owner_no%type,
                                        strExpType      in odata_exp_m.exp_type%type,
                                        strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                        strOperateType  in odata_outstock_m.operate_type%type,
                                        strSourceType   in odata_outstock_m.source_type%type,
                                        strPickType     in odata_outstock_m.pick_type%type,
                                        strPrintType    in odata_outstock_m.print_type%type,
                                        strUserID       in stock_label_m.updt_name%type, --员工ID
                                        strOutMsg       out varchar2) --返回值
   is
    nIndex           number(10); --是否进入 下架明细 循环;
    nContainerIndex  number(10); --是否进入容器循环
    strContainerType varchar2(1); --容器类型
    strContainerNo   varchar2(24); --容器号
    strReport_ID     varchar2(20); --报表ＩＤ
    nRowID           number(10); --标签明细序列号
    strUserType      varchar2(1); --标签用途(1：客户标签，2：分播标签，3：移库标签)
    strStatus        varchar2(2); --标签状态
    strDeliverObj    odata_outstock_d.deliver_obj%type; --配送对象
    strLabelNo       varchar2(24); --标签号
    strManualFlag    varchar2(1); --库存记录方式（0, 记录在标签上  1，记录在储位上）
    --strProduceLableTypeC  varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)
    --nProduceLableTypeC  varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)
    odata_outstock_d_Info odata_outstock_d%rowtype;
    v_strDeliverObjLevel  WMS_OUTLOCATE_STRATEGY_D.deliver_obj_level%type; --0:按客户；1：按单据
  begin
    strOutMsg     := 'N|[P_O_WriteLabelContainerNo_B]';
    strManualFlag := '1';

    PKLG_OLOCATE.GetDeliverObjLevel(strEnterpriseNo,
                                    strWareHouse_No,
                                    strOwnerNo,
                                    strExpType,
                                    v_strDeliverObjLevel,
                                    strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      strOutMsg := 'N|[E22105]';
      return;
    end if;

    if strPickType = 0 then
      if v_strDeliverObjLevel = '1' then
        strReport_ID := CONST_REPORTID.B_ExpPickTaskLabel_B;
      else
        strReport_ID := CONST_REPORTID.B_CustPickTaskLabel_B;
      end if;
      strUserType   := '1';
      strManualFlag := '0';
    else
      strReport_ID := CONST_REPORTID.B_DividePickTaskLabel_B;
      strUserType  := '2';
    end if;
    strStatus := '50';
    ---------------循环容器号---------------
    for Om_Container_Info in (SELECT DISTINCT a.enterprise_no,
                                              a.warehouse_no,
                                              a.wave_no,
                                              a.OUTSTOCK_NO,
                                              a.s_container_no
                                FROM odata_outstock_d A
                               WHERE A.warehouse_no = strwarehouse_no
                                 and a.enterprise_no = strEnterPriseNo
                                 AND A.OUTSTOCK_NO = strOutStockNo
                               ORDER BY a.enterprise_no,
                                        a.warehouse_no,
                                        a.OUTSTOCK_NO,
                                        a.S_CONTAINER_NO) loop
      nContainerIndex  := 1;
      nRowID           := 1;
      strContainerType := 'B';

      strContainerNo := Om_Container_Info.s_Container_No;
      ---------------新增标签明细 ---------------
      for odata_outstock_d_Info in (SELECT A.*
                                      FROM odata_outstock_d A
                                     WHERE A.warehouse_no = strwarehouse_no
                                       and a.enterprise_no = strEnterPriseNo
                                       AND A.Outstock_No =
                                           Om_Container_Info.Outstock_No
                                       and A.wave_no =
                                           Om_Container_Info.wave_no
                                       and a.s_container_no = strContainerNo) loop
        ---------------是否进入循环---------------
        nIndex := 1;
        ---------------配送对象---------------
        if strPickType = 0 then
          strDeliverObj := odata_outstock_d_Info.Deliver_Obj;
        else
          strDeliverObj := 'N';
        end if;

        --获取row_id
        select nvl(max(row_id + 1), 1)
          into nRowID
          FROM stock_label_d
         where warehouse_no = strwarehouse_no
           and enterprise_no = strEnterPriseNo
           and containeR_no = Om_Container_Info.s_Container_No;

        ---------------新增标签明细---------------
        insert into stock_label_d
          (enterprise_no,
           warehouse_no,
           BATCH_NO,
           OWNER_NO,
           SOURCE_NO,
           CONTAINER_NO,
           CONTAINER_TYPE,
           ARTICLE_NO,
           ARTICLE_ID,
           PACKING_QTY,
           QTY,
           EXP_NO,
           WAVE_NO,
           CUST_NO,
           SUB_CUST_NO,
           LINE_NO,
           STATUS,
           DIVIDE_ID,
           RGST_NAME,
           RGST_DATE,
           EXP_TYPE,
           EXP_DATE,
           DPS_CELL_NO,
           DELIVER_OBJ,
           row_id,
           deliverobj_order,
           ADVANCE_CELL_NO)--Modify BY QZH AT 2016-5-25
        values
          (strEnterPriseNo,
           odata_outstock_d_Info.warehouse_no,
           odata_outstock_d_Info.Batch_No,
           odata_outstock_d_Info.Owner_No,
           odata_outstock_d_Info.Outstock_No,
           strContainerNo,
           strContainerType,
           odata_outstock_d_Info.Article_No,
           odata_outstock_d_Info.Article_Id,
           odata_outstock_d_Info.Packing_Qty,
           odata_outstock_d_Info.Article_Qty,
           odata_outstock_d_Info.Exp_No,
           odata_outstock_d_Info.wave_no,
           odata_outstock_d_Info.Cust_No,
           odata_outstock_d_Info.Sub_Cust_No,
           odata_outstock_d_Info.Line_No,
           strStatus,
           odata_outstock_d_Info.Divide_Id,
           strUserID,
           sysdate,
           odata_outstock_d_Info.Exp_Type,
           odata_outstock_d_Info.Exp_Date,
           odata_outstock_d_Info.Dps_Cell_No,
           --strDeliverObj,
           odata_outstock_d_Info.Deliver_Obj,
           nRowID,
           odata_outstock_d_Info.deliverobj_order,
           odata_outstock_d_Info.s_Cell_No);
        ---------------新增失败---------------
        if sql%rowcount <= 0 then
          strOutMsg := 'N|[E22108]';
          return;
        end if;
        ---------------标签取号---------------
        if nRowID = 1 then
          begin
            SELECT SUBSTR(Om_Container_Info.s_Container_No,
                          length(b.container_prefix) + 1)
              into strLabelNo
              FROM WMS_DEFCONTAINER B
             WHERE B.warehouse_no = Om_Container_Info.warehouse_no
               and b.enterprise_no = strEnterPriseNo
               AND B.CONTAINER_TYPE = 'B'
               and rownum <= 1;
          end;
          if sql%notfound then
            strOutMsg := 'N|[E22109]';
            return;
          end if;
          if strLabelNo is null then
            strOutMsg := 'N|[E22109]';
            return;
          end if;
          ---------------出货摘果 标签加上分拣机滑道号---------------
          if strPickType = 0 then
            strLabelNo := strLabelNo ||
                          odata_outstock_d_Info.a_Sorter_Chute_No || '0';
          end if;
          ---------------写标签头---------------
          PKOBJ_LABEL.proc_Insert_LabelMaster(strEnterPriseNo,
                                              odata_outstock_d_Info.warehouse_no,
                                              odata_outstock_d_Info.Batch_No,
                                              odata_outstock_d_Info.Outstock_No,
                                              strLabelNo,
                                              strContainerNo,
                                              strContainerType,
                                              odata_outstock_d_Info.Deliver_Area,
                                              odata_outstock_d_Info.s_Cell_No,
                                              odata_outstock_d_Info.Cust_No,
                                              odata_outstock_d_Info.Trunck_Cell_No,
                                              odata_outstock_d_Info.a_Sorter_Chute_No,
                                              odata_outstock_d_Info.Check_Chute_No,
                                              strDeliverObj,
                                              strUserType,
                                              odata_outstock_d_Info.Line_No,
                                              odata_outstock_d_Info.Advance_Cell_No,
                                              odata_outstock_d_Info.device_no,
                                              strUserID,
                                              strReport_ID,
                                              '',
                                              '',
                                              odata_outstock_d_Info.Stock_Type,
                                              '0',
                                              odata_outstock_d_Info.s_Container_No,
                                              strStatus,
                                              strManualFlag,
                                              odata_outstock_d_Info.wave_no,
                                              strOutMsg);
          if instr(strOutMsg, 'N', 1, 1) = 1 then
            return;
          end if;
        end if;
        ---------------序列号---------------
        nRowID := nRowID + 1;
      end loop;
      if (nIndex < 1) then
        strOutMsg := 'N|[E22107]';
        return;
      end if;
    end loop;
    if (nContainerIndex < 1) then
      strOutMsg := 'N|[E22107]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_WriteLabelContainerNo_B;

  /*****************************************************************************************
     功能：按容器写标签——D 型  出货
  *****************************************************************************************/
  procedure P_O_WriteLabelContainerNo_D(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                        strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                        strOwnerNo      in odata_outstock_m.owner_no%type,
                                        strExpType      in odata_exp_m.exp_type%type,
                                        strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                        strOperateType  in odata_outstock_m.operate_type%type,
                                        strSourceType   in odata_outstock_m.source_type%type,
                                        strPickType     in odata_outstock_m.pick_type%type,
                                        strPrintType    in odata_outstock_m.print_type%type,
                                        strUserID       in stock_label_m.updt_name%type, --员工ID
                                        strOutMsg       out varchar2) --返回值
   is
    nIndex           number(10); --是否进入 下架明细循环
    nContainerIndex  number(10); -- 是否进入容器循环
    strContainerType varchar2(1); --容器类型
    strContainerNo   varchar2(24); --容器号
    strReport_ID     varchar2(20); --报表ＩＤ
    nRowID           number(10); --标签明细序列号
    --strPickType      varchar2(1); --拣货方式
    strUserType           varchar2(1); --标签用途(1：客户标签，2：分播标签，3：移库标签)
    strStatus             varchar2(2); --标签状态
    strDeliverObj         odata_outstock_direct.deliver_obj%type; --配送对象
    strLabelNo            varchar2(24); --标签号
    strManualFlag         varchar2(1); --库存记录方式（0, 记录在标签上  1，记录在储位上）
    strProduceLableTypeC  varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)
    nProduceLableTypeC    varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)
    odata_outstock_d_Info odata_outstock_d%rowtype;
  begin
    strOutMsg    := 'N|[P_O_WriteLabelContainerNo_D]';
    strReport_ID := CONST_REPORTID.B_DividePickTaskLabel_D;
    strUserType  := '2';
    strStatus    := '50';

    strManualFlag := '1';

    begin
      pklg_wms_base.p_GetBasePara(strEnterPriseNo,
                                  strwarehouse_no,
                                  strOwnerNo,
                                  'TaskOmProduceLableTypeC',
                                  'O',
                                  'O_TASK',
                                  strProduceLableTypeC,
                                  nProduceLableTypeC,
                                  strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        strOutMsg := 'N|[E22105]';
        return;
      end if;
    exception
      when others then
        strOutMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
        return;
    end;
    if strProduceLableTypeC = '1' then
      strManualFlag := '0';
    end if;

    ---------------循环容器号---------------
    for Om_Container_Info in (SELECT DISTINCT enterprise_no,
                                              warehouse_no,
                                              wave_no,
                                              OUTSTOCK_NO,
                                              S_CONTAINER_NO
                                FROM odata_outstock_d A
                               WHERE A.warehouse_no = strwarehouse_no
                                 and a.enterprise_no = strEnterPriseNo
                                 AND A.OUTSTOCK_NO = strOutStockNo
                               ORDER BY enterprise_no,
                                        warehouse_no,
                                        OUTSTOCK_NO,
                                        S_CONTAINER_NO) loop
      nContainerIndex  := 1;
      nRowID           := 1;
      strContainerType := 'B';
      strContainerNo   := Om_Container_Info.s_Container_No;
      ---------------新增标签明细 ---------------
      for odata_outstock_d_Info in (SELECT A.*
                                      FROM odata_outstock_d A
                                     WHERE A.warehouse_no = strwarehouse_no
                                       and a.enterprise_no = strEnterPriseNo
                                       AND A.Outstock_No =
                                           Om_Container_Info.Outstock_No
                                       and A.wave_no =
                                           Om_Container_Info.wave_no
                                       and A.s_Container_No =
                                           Om_Container_Info.s_Container_No) loop
        ---------------是否进入循环---------------
        nIndex := 1;
        ---------------配送对象---------------
        strDeliverObj := 'N';
        ---------------新增标签明细---------------
        insert into stock_label_d
          (enterprise_no,
           warehouse_no,
           BATCH_NO,
           OWNER_NO,
           SOURCE_NO,
           CONTAINER_NO,
           CONTAINER_TYPE,
           ARTICLE_NO,
           ARTICLE_ID,
           PACKING_QTY,
           QTY,
           EXP_NO,
           WAVE_NO,
           CUST_NO,
           SUB_CUST_NO,
           LINE_NO,
           STATUS,
           DIVIDE_ID,
           RGST_NAME,
           RGST_DATE,
           EXP_TYPE,
           EXP_DATE,
           DPS_CELL_NO,
           DELIVER_OBJ,
           ROW_ID,
           deliverobj_order,
           ADVANCE_CELL_NO)--Modify BY QZH AT 2016-5-25
        values
          (strEnterPriseNo,
           odata_outstock_d_Info.warehouse_no,
           odata_outstock_d_Info.Batch_No,
           odata_outstock_d_Info.Owner_No,
           odata_outstock_d_Info.Outstock_No,
           odata_outstock_d_Info.s_Container_No,
           strContainerType,
           odata_outstock_d_Info.Article_No,
           odata_outstock_d_Info.Article_Id,
           odata_outstock_d_Info.Packing_Qty,
           odata_outstock_d_Info.Article_Qty,
           odata_outstock_d_Info.Exp_No,
           odata_outstock_d_Info.wave_no,
           odata_outstock_d_Info.Cust_No,
           odata_outstock_d_Info.Sub_Cust_No,
           odata_outstock_d_Info.Line_No,
           strStatus,
           odata_outstock_d_Info.Divide_Id,
           strUserID,
           sysdate,
           odata_outstock_d_Info.Exp_Type,
           odata_outstock_d_Info.Exp_Date,
           odata_outstock_d_Info.Dps_Cell_No,
           --strDeliverObj,
           odata_outstock_d_Info.Deliver_Obj,
           nRowID,
           odata_outstock_d_Info.deliverobj_order,
           odata_outstock_d_Info.s_Cell_No);
        ---------------新增失败---------------
        if sql%rowcount <= 0 then
          strOutMsg := 'N|[E22108]';
          return;
        end if;
        ---------------标签取号---------------
        if nRowID = 1 then
          begin
            SELECT SUBSTR(Om_Container_Info.s_Container_No,
                          length(b.container_prefix) + 1)
              into strLabelNo
              FROM WMS_DEFCONTAINER B
             WHERE B.warehouse_no = Om_Container_Info.warehouse_no
               and b.enterprise_no = strEnterPriseNo
               AND B.CONTAINER_TYPE = 'B'
               and rownum <= 1;
          end;
          if sql%notfound then
            strOutMsg := 'N|[E22109]';
            return;
          end if;
          if strLabelNo is null then
            strOutMsg := 'N|[E22109]';
            return;
          end if;
          ---------------写标签头---------------
          PKOBJ_LABEL.proc_Insert_LabelMaster(strEnterPriseNo,
                                              odata_outstock_d_Info.warehouse_no,
                                              odata_outstock_d_Info.Batch_No,
                                              odata_outstock_d_Info.Outstock_No,
                                              strLabelNo,
                                              odata_outstock_d_Info.s_Container_No,
                                              strContainerType,
                                              odata_outstock_d_Info.Deliver_Area,
                                              odata_outstock_d_Info.s_Cell_No,
                                              odata_outstock_d_Info.Cust_No,
                                              odata_outstock_d_Info.Trunck_Cell_No,
                                              odata_outstock_d_Info.a_Sorter_Chute_No,
                                              odata_outstock_d_Info.Check_Chute_No,
                                              strDeliverObj,
                                              strUserType,
                                              odata_outstock_d_Info.Line_No,
                                              odata_outstock_d_Info.Advance_Cell_No,
                                              odata_outstock_d_Info.device_no,
                                              strUserID,
                                              strReport_ID,
                                              '',
                                              '',
                                              odata_outstock_d_Info.Stock_Type,
                                              '0',
                                              odata_outstock_d_Info.s_Container_No,
                                              strStatus,
                                              strManualFlag,
                                              odata_outstock_d_Info.wave_no,
                                              strOutMsg);
          if instr(strOutMsg, 'N', 1, 1) = 1 then
            return;
          end if;
        end if;
        ---------------序列号---------------
        nRowID := nRowID + 1;
      end loop;
      if (nIndex < 1) then
        strOutMsg := 'N|[E22107]';
        return;
      end if;
    end loop;
    if (nContainerIndex < 1) then
      strOutMsg := 'N|[E22107]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_WriteLabelContainerNo_D;

  --------------------------------------------------------按容器写标签 end---------------------------------------------------------------

  --------------------------------------------------------写任务标签 begin---------------------------------------------------------------
  /*****************************************************************************************
     功能：写任务标签——C型出货、M 型出货 、大批量出货、 出大Ｐ标签
  *****************************************************************************************/
  procedure P_O_WriteLabelTask_PCM(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                   strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                   strOwnerNo      in odata_outstock_m.owner_no%type,
                                   strExpType      in odata_exp_m.exp_type%type,
                                   strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                   strOperateType  in odata_outstock_m.operate_type%type,
                                   strSourceType   in odata_outstock_m.source_type%type,
                                   strPickType     in odata_outstock_m.pick_type%type,
                                   strPrintType    in odata_outstock_m.print_type%type,
                                   strUserID       in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg       out varchar2) --返回值
   is
    nIndex               number(10); --记录数，以做判断;
    strContainerType     varchar2(1); --容器类型
    strContainerNo       varchar2(24); --容器号
    strReport_ID         varchar2(20); --报表ＩＤ
    nRowID               number(10); --标签明细序列号
    strUserType          varchar2(1); --标签用途(1：客户标签，2：分播标签，3：移库标签)
    strStatus            varchar2(2); --标签状态
    strDeliverObj        odata_outstock_d.deliver_obj%type; --配送对象
    strLabelNo           varchar2(24); --标签号
    strSessionID         varchar2(100); --会话ＩＤ
    strManualFlag        varchar2(1); --库存记录方式（0, 记录在标签上  1，记录在储位上）
    strProduceLableTypeC varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)
    nProduceLableTypeC   varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)
    v_strDeliverObjLevel WMS_OUTLOCATE_STRATEGY_D.deliver_obj_level%type; --0:按客户；1：按单据
  begin
    strOutMsg     := 'N|[P_O_WriteLabelTask_PCM]';
    strManualFlag := '1';

    begin
      pklg_wms_base.p_GetBasePara(strEnterPriseNo,
                                  strwarehouse_no,
                                  strOwnerNo,
                                  'TaskOmProduceLableTypeC',
                                  'O',
                                  'O_TASK',
                                  strProduceLableTypeC,
                                  nProduceLableTypeC,
                                  strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        strOutMsg := 'N|[E22105]';
        return;
      end if;
    exception
      when others then
        strOutMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
        return;
    end;
    if strProduceLableTypeC = '1' then
      strManualFlag := '0';
    end if;

    PKLG_OLOCATE.GetDeliverObjLevel(strEnterpriseNo,
                                    strWareHouse_No,
                                    strOwnerNo,
                                    strExpType,
                                    v_strDeliverObjLevel,
                                    strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      strOutMsg := 'N|[E22105]';
      return;
    end if;

    if strSourceType = '4' then
      --大批量捡货
      strManualFlag := '0'; --库存记录在标签上；
      if strPickType = 0 and strOperateType <> 'P' then
        --摘果时，出客户标签
        if v_strDeliverObjLevel = '1' then
          strReport_ID := CONST_REPORTID.B_ExpPickTaskLabel_B;
        else
          strReport_ID := CONST_REPORTID.B_CustPickTaskLabel_B;
        end if;
        strUserType := '1';
      else
        --大批量播种，库存记录在储位上
        strUserType  := '2';
        strReport_ID := CONST_REPORTID.B_DividePickTaskLabel_C;
      end if;
    end if;

    --正常出货
    if strSourceType <> '4' then
      if strPickType = '0' then
        if v_strDeliverObjLevel = '1' then
          --按单
          if strOperateType = 'P' then
            strReport_ID := CONST_REPORTID.B_ExpPickTaskLabel_PM;
          end if;
          if strOperateType = 'C' then
            strReport_ID := CONST_REPORTID.B_ExpPickTaskLabel_C;
          end if;
          if strOperateType = 'B' then
            strReport_ID := CONST_REPORTID.B_ExpPickTaskLabel_B;
          end if;
        else
          --按客户
          if strOperateType = 'P' then
            strReport_ID := CONST_REPORTID.B_CustPickTaskLabel_PM;
          end if;
          if strOperateType = 'C' then
            strReport_ID := CONST_REPORTID.B_CustPickTaskLabel_C;
          end if;
          if strOperateType = 'B' then
            strReport_ID := CONST_REPORTID.B_CustPickTaskLabel_B;
          end if;
        end if;

        strUserType   := '1';
        strManualFlag := '0';
      end if;
      if strPickType = '1' then

        if strOperateType = 'M' then
          strReport_ID := CONST_REPORTID.B_DividePickTaskLabel_MD;
        else
          strReport_ID := CONST_REPORTID.B_DividePickTaskLabel_C;
        end if;

        strUserType := '2';
      end if;
    end if;

    strStatus        := '50';
    nRowID           := 1;
    strContainerType := 'P';
    -------------------------------取容器号-----------------------------------
    PKLG_WMS_BASE.p_get_ContainerNoBase(strEnterPriseNo,
                                        strwarehouse_no,
                                        strContainerType,
                                        strUserID,
                                        'Y',
                                        1,
                                        '1',
                                        NULL,
                                        strLabelNo,
                                        strContainerNo,
                                        strSessionID,
                                        strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      return;
    end if;
    --------------------循环下架明细写标签明细信息--------------------
    for om_outstock_info in (SELECT A.*
                               FROM odata_outstock_d A
                              WHERE A.warehouse_no = strwarehouse_no
                                and a.enterprise_no = strEnterPriseNo
                                AND A.Outstock_No = strOutStockNo) loop
      --------------------是否进去循环--------------------
      nIndex := 1;
      ---------------配送对象---------------
      if strPickType = 0 then
        strDeliverObj := om_outstock_info.Deliver_Obj;
      else
        strDeliverObj := 'N';
      end if;

      insert into stock_label_d
        (enterprise_no,
         warehouse_no,
         BATCH_NO,
         OWNER_NO,
         SOURCE_NO,
         CONTAINER_NO,
         CONTAINER_TYPE,
         ARTICLE_NO,
         ARTICLE_ID,
         PACKING_QTY,
         QTY,
         EXP_NO,
         WAVE_NO,
         CUST_NO,
         SUB_CUST_NO,
         LINE_NO,
         STATUS,
         DIVIDE_ID,
         RGST_NAME,
         RGST_DATE,
         EXP_TYPE,
         EXP_DATE,
         DPS_CELL_NO,
         DELIVER_OBJ,
         ROW_ID,
         deliverobj_order,
         ADVANCE_CELL_NO)--Modify BY QZH AT 2016-5-25
      values
        (strEnterPriseNo,
         om_outstock_info.warehouse_no,
         om_outstock_info.Batch_No,
         om_outstock_info.Owner_No,
         om_outstock_info.Outstock_No,
         strContainerNo,
         strContainerType,
         om_outstock_info.Article_No,
         om_outstock_info.Article_Id,
         om_outstock_info.Packing_Qty,
         om_outstock_info.Article_Qty,
         om_outstock_info.Exp_No,
         om_outstock_info.wave_no,
         om_outstock_info.Cust_No,
         om_outstock_info.Sub_Cust_No,
         om_outstock_info.Line_No,
         strStatus,
         om_outstock_info.Divide_Id,
         strUserID,
         sysdate,
         om_outstock_info.Exp_Type,
         om_outstock_info.Exp_Date,
         om_outstock_info.Dps_Cell_No,
         om_outstock_info.deliver_obj,
         nRowID,
         om_outstock_info.deliverobj_order,
         om_outstock_info.s_cell_no);
      ---------------新增失败---------------
      if sql%rowcount <= 0 then
        strOutMsg := 'N|[E22108]';
        return;
      end if;
      ---------------写标签头---------------
      if nRowID = 1 then
        PKOBJ_LABEL.proc_Insert_LabelMaster(strEnterPriseNo,
                                            om_outstock_info.warehouse_no,
                                            om_outstock_info.Batch_No,
                                            om_outstock_info.Outstock_No,
                                            strLabelNo,
                                            strContainerNo,
                                            strContainerType,
                                            om_outstock_info.Deliver_Area,
                                            om_outstock_info.s_Cell_No,
                                            om_outstock_info.Cust_No,
                                            om_outstock_info.Trunck_Cell_No,
                                            om_outstock_info.a_Sorter_Chute_No,
                                            om_outstock_info.Check_Chute_No,
                                            strDeliverObj,
                                            strUserType,
                                            om_outstock_info.Line_No,
                                            om_outstock_info.Advance_Cell_No,
                                            om_outstock_info.device_no,
                                            strUserID,
                                            strReport_ID,
                                            '',
                                            '',
                                            om_outstock_info.Stock_Type,
                                            '0',
                                            strContainerNo,
                                            strStatus,
                                            strManualFlag,
                                            om_outstock_info.wave_no,
                                            strOutMsg);
        if instr(strOutMsg, 'N', 1, 1) = 1 then
          return;
        end if;
      end if;
      ---------------序列号---------------
      nRowID := nRowID + 1;
    end loop;
    if (nIndex < 1) then
      strOutMsg := 'N|[E22107]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_WriteLabelTask_PCM;

  /*****************************************************************************************
     功能：写任务标签——MIX标签(出P型标签)
     huangb20160625
  *****************************************************************************************/
  procedure P_O_WriteLabelTask_MIX(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                   strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                   strOwnerNo      in odata_outstock_m.owner_no%type,
                                   strExpType      in odata_exp_m.exp_type%type,
                                   strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                   strOperateType  in odata_outstock_m.operate_type%type,
                                   strSourceType   in odata_outstock_m.source_type%type,
                                   strPickType     in odata_outstock_m.pick_type%type,
                                   strPrintType    in odata_outstock_m.print_type%type,
                                   strUserID       in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg       out varchar2) --返回值
   is
    nIndex               number(10); --记录数，以做判断;
    strContainerType     varchar2(1); --容器类型
    strContainerNo       varchar2(24); --容器号
    strReport_ID         varchar2(20); --报表ＩＤ
    nRowID               number(10); --标签明细序列号
    strUserType          varchar2(1); --标签用途(1：客户标签，2：分播标签，3：移库标签)
    strStatus            varchar2(2); --标签状态
    strDeliverObj        odata_outstock_d.deliver_obj%type; --配送对象
    strLabelNo           varchar2(24); --标签号
    strSessionID         varchar2(100); --会话ＩＤ
    strManualFlag        varchar2(1); --库存记录方式（0, 记录在标签上  1，记录在储位上）

  begin
    strOutMsg        := 'N|[P_O_WriteLabelTask_MIX]';
    strManualFlag    := '1';
    --标签用途 huangb 20160630
    if strPickType = 0 then
      strUserType := '1';
    else
      strUserType := '2';
    end if;
    strReport_ID     := CONST_REPORTID.B_DividePickTaskLabel_MD;
    strStatus        := '50';
    nRowID           := 1;
    strContainerType := 'P';
    -------------------------------取容器号-----------------------------------
    PKLG_WMS_BASE.p_get_ContainerNoBase(strEnterPriseNo,
                                        strwarehouse_no,
                                        strContainerType,
                                        strUserID,
                                        'Y',
                                        1,
                                        '1',
                                        NULL,
                                        strLabelNo,
                                        strContainerNo,
                                        strSessionID,
                                        strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      return;
    end if;
    --------------------循环下架明细写标签明细信息--------------------
    for om_outstock_info in (SELECT A.*
                               FROM odata_outstock_d A
                              WHERE A.warehouse_no = strwarehouse_no
                                and a.enterprise_no = strEnterPriseNo
                                AND A.Outstock_No = strOutStockNo) loop
      --------------------是否进去循环--------------------
      nIndex := 1;
      ---------------配送对象---------------
      if strPickType = 0 then
        strDeliverObj := om_outstock_info.Deliver_Obj;
      else
        strDeliverObj := 'N';
      end if;

      insert into stock_label_d
        (enterprise_no,
         warehouse_no,
         BATCH_NO,
         OWNER_NO,
         SOURCE_NO,
         CONTAINER_NO,
         CONTAINER_TYPE,
         ARTICLE_NO,
         ARTICLE_ID,
         PACKING_QTY,
         QTY,
         EXP_NO,
         WAVE_NO,
         CUST_NO,
         SUB_CUST_NO,
         LINE_NO,
         STATUS,
         DIVIDE_ID,
         RGST_NAME,
         RGST_DATE,
         EXP_TYPE,
         EXP_DATE,
         DPS_CELL_NO,
         DELIVER_OBJ,
         ROW_ID,
         deliverobj_order,
         ADVANCE_CELL_NO)--Modify BY QZH AT 2016-5-25
      values
        (strEnterPriseNo,
         om_outstock_info.warehouse_no,
         om_outstock_info.Batch_No,
         om_outstock_info.Owner_No,
         om_outstock_info.Outstock_No,
         strContainerNo,
         strContainerType,
         om_outstock_info.Article_No,
         om_outstock_info.Article_Id,
         om_outstock_info.Packing_Qty,
         om_outstock_info.Article_Qty,
         om_outstock_info.Exp_No,
         om_outstock_info.wave_no,
         om_outstock_info.Cust_No,
         om_outstock_info.Sub_Cust_No,
         om_outstock_info.Line_No,
         strStatus,
         om_outstock_info.Divide_Id,
         strUserID,
         sysdate,
         om_outstock_info.Exp_Type,
         om_outstock_info.Exp_Date,
         om_outstock_info.Dps_Cell_No,
         om_outstock_info.deliver_obj,
         nRowID,
         om_outstock_info.deliverobj_order,
         om_outstock_info.s_cell_no);
      ---------------新增失败---------------
      if sql%rowcount <= 0 then
        strOutMsg := 'N|[E22108]';
        return;
      end if;
      ---------------写标签头---------------
      if nRowID = 1 then
        PKOBJ_LABEL.proc_Insert_LabelMaster(strEnterPriseNo,
                                            om_outstock_info.warehouse_no,
                                            om_outstock_info.Batch_No,
                                            om_outstock_info.Outstock_No,
                                            strLabelNo,
                                            strContainerNo,
                                            strContainerType,
                                            om_outstock_info.Deliver_Area,
                                            om_outstock_info.s_Cell_No,
                                            om_outstock_info.Cust_No,
                                            om_outstock_info.Trunck_Cell_No,
                                            om_outstock_info.a_Sorter_Chute_No,
                                            om_outstock_info.Check_Chute_No,
                                            strDeliverObj,
                                            strUserType,
                                            om_outstock_info.Line_No,
                                            om_outstock_info.Advance_Cell_No,
                                            om_outstock_info.device_no,
                                            strUserID,
                                            strReport_ID,
                                            '',
                                            '',
                                            om_outstock_info.Stock_Type,
                                            '0',
                                            strContainerNo,
                                            strStatus,
                                            strManualFlag,
                                            om_outstock_info.wave_no,
                                            strOutMsg);
        if instr(strOutMsg, 'N', 1, 1) = 1 then
          return;
        end if;
      end if;
      ---------------序列号---------------
      nRowID := nRowID + 1;
    end loop;
    if (nIndex < 1) then
      strOutMsg := 'N|[E22107]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_WriteLabelTask_MIX;

  /*****************************************************************************************
     功能：写任务标签——D标签(出C型标签)
     huangb20160625
  *****************************************************************************************/
  procedure P_O_WriteLabelTask_D(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                 strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                 strOwnerNo      in odata_outstock_m.owner_no%type,
                                 strExpType      in odata_exp_m.exp_type%type,
                                 strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                 strOperateType  in odata_outstock_m.operate_type%type,
                                 strSourceType   in odata_outstock_m.source_type%type,
                                 strPickType     in odata_outstock_m.pick_type%type,
                                 strPrintType    in odata_outstock_m.print_type%type,
                                 strUserID       in stock_label_m.updt_name%type, --员工ID
                                 strOutMsg       out varchar2) --返回值
   is
    nIndex               number(10); --记录数，以做判断;
    strContainerType     varchar2(1); --容器类型
    strContainerNo       varchar2(24); --容器号
    strReport_ID         varchar2(20); --报表ＩＤ
    nRowID               number(10); --标签明细序列号
    strUserType          varchar2(1); --标签用途(1：客户标签，2：分播标签，3：移库标签)
    strStatus            varchar2(2); --标签状态
    strDeliverObj        odata_outstock_d.deliver_obj%type; --配送对象
    strLabelNo           varchar2(24); --标签号
    strSessionID         varchar2(100); --会话ＩＤ
    strManualFlag        varchar2(1); --库存记录方式（0, 记录在标签上  1，记录在储位上）

  begin
    strOutMsg        := 'N|[P_O_WriteLabelTask_D]';
    strManualFlag    := '1';
    --标签用途 huangb 20160630
    if strPickType = 0 then
      strUserType := '1';
    else
      strUserType := '2';
    end if;
    strReport_ID     := CONST_REPORTID.B_DividePickTaskLabel_MD;
    strStatus        := '50';
    nRowID           := 1;
    strContainerType := 'C';
    -------------------------------取容器号-----------------------------------
    PKLG_WMS_BASE.p_get_ContainerNoBase(strEnterPriseNo,
                                        strwarehouse_no,
                                        strContainerType,
                                        strUserID,
                                        'Y',
                                        1,
                                        '1',
                                        NULL,
                                        strLabelNo,
                                        strContainerNo,
                                        strSessionID,
                                        strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      return;
    end if;
    --------------------循环下架明细写标签明细信息--------------------
    for om_outstock_info in (SELECT A.*
                               FROM odata_outstock_d A
                              WHERE A.warehouse_no = strwarehouse_no
                                and a.enterprise_no = strEnterPriseNo
                                AND A.Outstock_No = strOutStockNo) loop
      --------------------是否进去循环--------------------
      nIndex := 1;
      ---------------配送对象---------------
      if strPickType = 0 then
        strDeliverObj := om_outstock_info.Deliver_Obj;
      else
        strDeliverObj := 'N';
      end if;

      insert into stock_label_d
        (enterprise_no,
         warehouse_no,
         BATCH_NO,
         OWNER_NO,
         SOURCE_NO,
         CONTAINER_NO,
         CONTAINER_TYPE,
         ARTICLE_NO,
         ARTICLE_ID,
         PACKING_QTY,
         QTY,
         EXP_NO,
         WAVE_NO,
         CUST_NO,
         SUB_CUST_NO,
         LINE_NO,
         STATUS,
         DIVIDE_ID,
         RGST_NAME,
         RGST_DATE,
         EXP_TYPE,
         EXP_DATE,
         DPS_CELL_NO,
         DELIVER_OBJ,
         ROW_ID,
         deliverobj_order,
         ADVANCE_CELL_NO)--Modify BY QZH AT 2016-5-25
      values
        (strEnterPriseNo,
         om_outstock_info.warehouse_no,
         om_outstock_info.Batch_No,
         om_outstock_info.Owner_No,
         om_outstock_info.Outstock_No,
         strContainerNo,
         strContainerType,
         om_outstock_info.Article_No,
         om_outstock_info.Article_Id,
         om_outstock_info.Packing_Qty,
         om_outstock_info.Article_Qty,
         om_outstock_info.Exp_No,
         om_outstock_info.wave_no,
         om_outstock_info.Cust_No,
         om_outstock_info.Sub_Cust_No,
         om_outstock_info.Line_No,
         strStatus,
         om_outstock_info.Divide_Id,
         strUserID,
         sysdate,
         om_outstock_info.Exp_Type,
         om_outstock_info.Exp_Date,
         om_outstock_info.Dps_Cell_No,
         om_outstock_info.deliver_obj,
         nRowID,
         om_outstock_info.deliverobj_order,
         om_outstock_info.s_cell_no);
      ---------------新增失败---------------
      if sql%rowcount <= 0 then
        strOutMsg := 'N|[E22108]';
        return;
      end if;
      ---------------写标签头---------------
      if nRowID = 1 then
        PKOBJ_LABEL.proc_Insert_LabelMaster(strEnterPriseNo,
                                            om_outstock_info.warehouse_no,
                                            om_outstock_info.Batch_No,
                                            om_outstock_info.Outstock_No,
                                            strLabelNo,
                                            strContainerNo,
                                            strContainerType,
                                            om_outstock_info.Deliver_Area,
                                            om_outstock_info.s_Cell_No,
                                            om_outstock_info.Cust_No,
                                            om_outstock_info.Trunck_Cell_No,
                                            om_outstock_info.a_Sorter_Chute_No,
                                            om_outstock_info.Check_Chute_No,
                                            strDeliverObj,
                                            strUserType,
                                            om_outstock_info.Line_No,
                                            om_outstock_info.Advance_Cell_No,
                                            om_outstock_info.device_no,
                                            strUserID,
                                            strReport_ID,
                                            '',
                                            '',
                                            om_outstock_info.Stock_Type,
                                            '0',
                                            strContainerNo,
                                            strStatus,
                                            strManualFlag,
                                            om_outstock_info.wave_no,
                                            strOutMsg);
        if instr(strOutMsg, 'N', 1, 1) = 1 then
          return;
        end if;
      end if;
      ---------------序列号---------------
      nRowID := nRowID + 1;
    end loop;
    if (nIndex < 1) then
      strOutMsg := 'N|[E22107]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_WriteLabelTask_D;

  /*****************************************************************************************
     功能：写任务标签——B型补货、C型补货  出大Ｐ标签
  *****************************************************************************************/
  procedure P_H_WriteLabelTask_BC(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                  strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                  strOwnerNo      in odata_outstock_m.owner_no%type,
                                  strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                  strOperateType  in odata_outstock_m.operate_type%type,
                                  strPickType     in odata_outstock_m.pick_type%type,
                                  strTaskType     in odata_outstock_m.task_type%type,
                                  strOutstockType in odata_outstock_m.outstock_type%type,
                                  strPrintType    in odata_outstock_m.print_type%type,
                                  strUserID       in stock_label_m.updt_name%type, --员工ID
                                  strOutMsg       out varchar2) --返回值

   is
    nIndex               number(10); --记录数，以做判断;
    strContainerType     varchar2(1); --容器类型
    strContainerNo       varchar2(24); --容器号
    strReport_ID         varchar2(20); --报表ＩＤ
    nRowID               number(10); --标签明细序列号
    strUserType          varchar2(1); --标签用途(1：客户标签，2：分播标签，3：移库标签)
    strStatus            varchar2(2); --标签状态
    strDeliverObj        odata_outstock_direct.deliver_obj%type; --配送对象
    strLabelNo           varchar2(24); --标签号
    strSessionID         varchar2(100); --会话ＩＤ
    strManualFlag        varchar2(1); --库存记录方式（0, 记录在标签上  1，记录在储位上）
    strProduceLableTypeC varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)
    nProduceLableTypeC   varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)
    v_strLableNo         odata_outstock_d.label_no%type;

  begin
    strOutMsg := 'N|[P_H_WriteLabelTask_BC]';

    strManualFlag := '1';
    select ood.label_no
      into v_strLableNo
      from odata_outstock_d ood, odata_outstock_m oom
     where ood.warehouse_no = strwarehouse_no
       and ood.enterprise_no = strEnterPriseNo
       and ood.outstock_no = strOutStockNo
       and oom.warehouse_no = ood.warehouse_no
       and oom.outstock_no = ood.outstock_no
       and rownum <= 1;

    begin
      pklg_wms_base.p_GetBasePara(strEnterPriseNo,
                                  strwarehouse_no,
                                  strOwnerNo,
                                  'TaskOmProduceLableTypeC',
                                  'O',
                                  'O_TASK',
                                  strProduceLableTypeC,
                                  nProduceLableTypeC,
                                  strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        strOutMsg := 'N|[E22107]';
        return;
      end if;
    exception
      when others then
        strOutMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
        return;
    end;
    if strProduceLableTypeC = '1' then
      strManualFlag := '0';
    end if;
    /*
    if strPrintType = '3' then
      strReport_ID := CONST_REPORTID.B_HMTask_CD;
    end if;

    if strPrintType = '2' then
      strReport_ID := CONST_REPORTID.B_HMTask_C;
    end if;*/

    if strOperateType='B' then
        strReport_ID := CONST_REPORTID.B_HMTask_CD;
    end if;

    if strOperateType='C' then
        strReport_ID := CONST_REPORTID.B_HMTask_CD;
    end if;

    strUserType      := '3';
    strStatus        := '40';
    nRowID           := 1;
    strContainerType := 'P';
    -------------------------------取容器号-----------------------------------
    PKLG_WMS_BASE.p_get_ContainerNoBase(strEnterPriseNo,
                                        strwarehouse_no,
                                        strContainerType,
                                        strUserID,
                                        'Y',
                                        1,
                                        '1',
                                        NULL,
                                        strLabelNo,
                                        strContainerNo,
                                        strSessionID,
                                        strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      return;
    end if;

    if v_strLableNo <> 'N' then
      strLabelNo := v_strLableNo;
    end if;
    --------------------循环下架明细写标签明细信息--------------------
    for om_outstock_info in (SELECT A.*
                               FROM odata_outstock_d A
                              WHERE A.warehouse_no = strwarehouse_no
                                AND A.Outstock_No = strOutStockNo
                                and a.enterprise_no = strEnterPriseNo) loop
      --------------------是否进去循环--------------------
      nIndex := 1;
      ---------------配送对象---------------
      strDeliverObj := 'N';
      insert into stock_label_d
        (enterprise_no,
         warehouse_no,
         BATCH_NO,
         OWNER_NO,
         SOURCE_NO,
         CONTAINER_NO,
         CONTAINER_TYPE,
         ARTICLE_NO,
         ARTICLE_ID,
         PACKING_QTY,
         QTY,
         EXP_NO,
         WAVE_NO,
         CUST_NO,
         SUB_CUST_NO,
         LINE_NO,
         STATUS,
         DIVIDE_ID,
         RGST_NAME,
         RGST_DATE,
         EXP_TYPE,
         EXP_DATE,
         DPS_CELL_NO,
         DELIVER_OBJ,
         ROW_ID,
         deliverobj_order,
         ADVANCE_CELL_NO)--Modify BY QZH AT 2016-5-25
      values
        (strEnterPriseNo,
         om_outstock_info.warehouse_no,
         om_outstock_info.Batch_No,
         om_outstock_info.Owner_No,
         om_outstock_info.Outstock_No,
         strContainerNo,
         strContainerType,
         om_outstock_info.Article_No,
         om_outstock_info.Article_Id,
         om_outstock_info.Packing_Qty,
         om_outstock_info.Article_Qty,
         om_outstock_info.Exp_No,
         om_outstock_info.wave_no,
         om_outstock_info.Cust_No,
         om_outstock_info.Sub_Cust_No,
         om_outstock_info.Line_No,
         strStatus,
         om_outstock_info.Divide_Id,
         strUserID,
         sysdate,
         om_outstock_info.Exp_Type,
         om_outstock_info.Exp_Date,
         om_outstock_info.Dps_Cell_No,
         om_outstock_info.deliver_obj,
         nRowID,
         om_outstock_info.deliverobj_order,
         om_outstock_info.s_cell_no);
      ---------------新增失败---------------
      if sql%rowcount <= 0 then
        strOutMsg := 'N|[E22108]';
        return;
      end if;
      ---------------写标签头---------------
      if nRowID = 1 then
        PKOBJ_LABEL.proc_Insert_LabelMaster(strEnterPriseNo,
                                            om_outstock_info.warehouse_no,
                                            om_outstock_info.Batch_No,
                                            om_outstock_info.Outstock_No,
                                            strLabelNo,
                                            strContainerNo,
                                            strContainerType,
                                            om_outstock_info.Deliver_Area,
                                            om_outstock_info.s_Cell_No,
                                            om_outstock_info.Cust_No,
                                            om_outstock_info.Trunck_Cell_No,
                                            om_outstock_info.a_Sorter_Chute_No,
                                            om_outstock_info.Check_Chute_No,
                                            strDeliverObj,
                                            strUserType,
                                            om_outstock_info.Line_No,
                                            om_outstock_info.Advance_Cell_No,
                                            om_outstock_info.device_no,
                                            strUserID,
                                            strReport_ID,
                                            '',
                                            '',
                                            om_outstock_info.Stock_Type,
                                            '0',
                                            om_outstock_info.s_Container_No,
                                            strStatus,
                                            strManualFlag,
                                            om_outstock_info.wave_no,
                                            strOutMsg);
        if instr(strOutMsg, 'N', 1, 1) = 1 then
          return;
        end if;
      end if;
      ---------------序列号---------------
      nRowID := nRowID + 1;
    end loop;
    if (nIndex < 1) then
      strOutMsg := 'N|[E22107]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_H_WriteLabelTask_BC;

  /*****************************************************************************************
     功能：写任务标签——C型出货、M 型出货  分播  （ 其中不可上分拣 写任务 大 P 标签  ）  出大Ｐ标签
  *****************************************************************************************/
  procedure P_O_WriteLabelTask_CM_S(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                    strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                    strOwnerNo      in odata_outstock_m.owner_no%type,
                                    strExpType      in odata_exp_m.exp_type%type,
                                    strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                    strPickType     in odata_outstock_m.pick_type%type,
                                    strPrintType    in odata_outstock_m.print_type%type,
                                    strSorterFlag   in bdef_article_packing.sorter_flag%type, --是否可上分拣
                                    strUserID       in stock_label_m.updt_name%type, --员工ID
                                    strOutMsg       out varchar2) --返回值
   is
    nIndex               number(10); --记录数，以做判断;
    strContainerType     varchar2(1); --容器类型
    strContainerNo       varchar2(24); --容器号
    strReport_ID         varchar2(20); --报表ＩＤ
    nRowID               number(10); --标签明细序列号
    strUserType          varchar2(1); --标签用途(1：客户标签，2：分播标签，3：移库标签)
    strStatus            varchar2(2); --标签状态
    strDeliverObj        odata_outstock_direct.deliver_obj%type; --配送对象
    strLabelNo           varchar2(24); --标签号
    strSessionID         varchar2(100); --会话ＩＤ
    strManualFlag        varchar2(1); --库存记录方式（0, 记录在标签上  1，记录在储位上）
    strProduceLableTypeC varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)
    nProduceLableTypeC   varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)
    v_strDeliverObjLevel WMS_OUTLOCATE_STRATEGY_D.deliver_obj_level%type; --0:按客户；1：按单据
  begin
    strOutMsg     := 'N|[P_O_WriteLabelTask_CM_S]';
    strManualFlag := '1';

    begin
      pklg_wms_base.p_GetBasePara(strEnterPriseNo,
                                  strwarehouse_no,
                                  strOwnerNo,
                                  'TaskOmProduceLableTypeC',
                                  'O',
                                  'O_TASK',
                                  strProduceLableTypeC,
                                  nProduceLableTypeC,
                                  strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        strOutMsg := 'N|[E22105]';
        return;
      end if;
    exception
      when others then
        strOutMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
        return;
    end;
    if strProduceLableTypeC = '1' then
      strManualFlag := '0';
    end if;

    if strPickType = '0' then
      PKLG_OLOCATE.GetDeliverObjLevel(strEnterpriseNo,
                                      strWareHouse_No,
                                      strOwnerNo,
                                      strExpType,
                                      v_strDeliverObjLevel,
                                      strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        strOutMsg := 'N|[E22105]';
        return;
      end if;
      if v_strDeliverObjLevel = '0' then
        strReport_ID := CONST_REPORTID.B_ExpPickTaskLabel_B;
      else
        strReport_ID := CONST_REPORTID.B_CustPickTaskLabel_B;
      end if;
      strUserType := '1';
    else
      strReport_ID := CONST_REPORTID.B_DividePickTaskLabel_B;
      strUserType  := '2';
    end if;
    strStatus        := '50';
    nRowID           := 1;
    strContainerType := 'P';
    -------------------------------取容器号-----------------------------------
    PKLG_WMS_BASE.p_get_ContainerNoBase(strEnterPriseNo,
                                        strwarehouse_no,
                                        strContainerType,
                                        strUserID,
                                        'Y',
                                        1,
                                        '1',
                                        NULL,
                                        strLabelNo,
                                        strContainerNo,
                                        strSessionID,
                                        strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      return;
    end if;
    --------------------循环下架明细写标签明细信息--------------------
    for om_outstock_info in (SELECT A.*
                               FROM odata_outstock_d A
                              WHERE A.warehouse_no = strwarehouse_no
                                and a.enterprise_no = strEnterPriseNo
                                AND A.Outstock_No = strOutStockNo) loop
      --------------------是否进去循环--------------------
      nIndex := 1;
      ---------------配送对象---------------
      if strPickType = 0 then
        strDeliverObj := om_outstock_info.Deliver_Obj;
      else
        strDeliverObj := 'N';
      end if;
      insert into stock_label_d
        (enterprise_no,
         warehouse_no,
         BATCH_NO,
         OWNER_NO,
         SOURCE_NO,
         CONTAINER_NO,
         CONTAINER_TYPE,
         ARTICLE_NO,
         ARTICLE_ID,
         PACKING_QTY,
         QTY,
         EXP_NO,
         WAVE_NO,
         CUST_NO,
         SUB_CUST_NO,
         LINE_NO,
         STATUS,
         DIVIDE_ID,
         RGST_NAME,
         RGST_DATE,
         EXP_TYPE,
         EXP_DATE,
         DPS_CELL_NO,
         DELIVER_OBJ,
         ROW_ID,
         deliverobj_order,
         ADVANCE_CELL_NO)--Modify BY QZH AT 2016-5-25
      values
        (strEnterPriseNo,
         om_outstock_info.warehouse_no,
         om_outstock_info.Batch_No,
         om_outstock_info.Owner_No,
         om_outstock_info.Outstock_No,
         strContainerNo,
         strContainerType,
         om_outstock_info.Article_No,
         om_outstock_info.Article_Id,
         om_outstock_info.Packing_Qty,
         om_outstock_info.Article_Qty,
         om_outstock_info.Exp_No,
         om_outstock_info.wave_no,
         om_outstock_info.Cust_No,
         om_outstock_info.Sub_Cust_No,
         om_outstock_info.Line_No,
         strStatus,
         om_outstock_info.Divide_Id,
         strUserID,
         sysdate,
         om_outstock_info.Exp_Type,
         om_outstock_info.Exp_Date,
         om_outstock_info.Dps_Cell_No,
         om_outstock_info.deliver_obj,
         nRowID,
         om_outstock_info.deliverobj_order,
         om_outstock_info.s_cell_no);
      ---------------新增失败---------------
      if sql%rowcount <= 0 then
        strOutMsg := 'N|[E22108]';
        return;
      end if;
      ---------------写标签头---------------
      if nRowID = 1 then
        PKOBJ_LABEL.proc_Insert_LabelMaster(strEnterPriseNo,
                                            om_outstock_info.warehouse_no,
                                            om_outstock_info.Batch_No,
                                            om_outstock_info.Outstock_No,
                                            strLabelNo,
                                            strContainerNo,
                                            strContainerType,
                                            om_outstock_info.Deliver_Area,
                                            om_outstock_info.s_Cell_No,
                                            om_outstock_info.Cust_No,
                                            om_outstock_info.Trunck_Cell_No,
                                            om_outstock_info.a_Sorter_Chute_No,
                                            om_outstock_info.Check_Chute_No,
                                            strDeliverObj,
                                            strUserType,
                                            om_outstock_info.Line_No,
                                            om_outstock_info.Advance_Cell_No,
                                            om_outstock_info.device_no,
                                            strUserID,
                                            strReport_ID,
                                            '',
                                            '',
                                            om_outstock_info.Stock_Type,
                                            '0',
                                            om_outstock_info.s_Container_No,
                                            strStatus,
                                            strManualFlag,
                                            om_outstock_info.wave_no,
                                            strOutMsg);
        if instr(strOutMsg, 'N', 1, 1) = 1 then
          return;
        end if;
      end if;
      ---------------序列号---------------
      nRowID := nRowID + 1;
    end loop;
    if (nIndex < 1) then
      strOutMsg := 'N|[E22107]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_WriteLabelTask_CM_S;
  --------------------------------------------------------写任务标签 end-----------------------------------------------------------------

  --------------------------------------------------------写流水标签 begin---------------------------------------------------------------
  /*****************************************************************************************
     功能：写流水标签——P （出货） ( 只出 C 箱标签 )
  *****************************************************************************************/
  procedure P_O_WriteLabelSerial_PT(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                    strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                    strOwnerNo      in odata_outstock_m.owner_no%type,
                                    strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                    strOperateType  in odata_outstock_m.operate_type%type,
                                    strPickType     in odata_outstock_m.pick_type%type,
                                    strTaskType     in odata_outstock_m.task_type%type,
                                    strOutstockType in odata_outstock_m.outstock_type%type,
                                    strUserID       in stock_label_m.updt_name%type, --员工ID
                                    strOutMsg       out varchar2) --返回值

   is
    nIndex           number(10); --记录数，以做判断;
    strContainerType varchar2(1); --容器类型
    strContainerNo   varchar2(24); --容器号
    strNContainerNo  varchar2(24); --容器号
    strReport_ID     varchar2(20); --报表ＩＤ
    nRowID           number(10); --标签明细序列号
    strUserType      varchar2(1); --标签用途(1：客户标签，2：分播标签，3：移库标签)
    strStatus        varchar2(2); --标签状态
    --strDeliverObj    varchar2(15); --配送对象
    strLabelNo   varchar2(24); --标签号
    strSessionID varchar2(100); --会话ＩＤ

    strOldcondition  varchar2(10000); -- 成标签条件
    strCurrCondition varchar2(10000); -- 成标签条件

    strCreateLabelPerCase varchar2(1); --是否按板产生标签 （ 0 否 ，1 是）

    strConversionOperateP varchar2(500); --是否允许C 、M 转 P ( 0 不允许 ，1 允许)
    strProduceLableTypeC  varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)
    strOmLabelPickFlag    varchar2(500); --出货是否支持标签库存箱型拣货 ( 0 不支持(C-->B) , 1-支持(B-->C))

    nConversionOperateP varchar2(500); --是否允许C 、M 转 P ( 0 不允许 ，1 允许)
    nProduceLableTypeC  varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)
    nOmLabelPickFlag    varchar2(500); --出货是否支持标签库存箱型拣货 ( 0 不支持(C-->B) , 1-支持(B-->C))

    --nContainer   number(10); --记录数，取号循环;
    nLabel number(10); --记录数，写标签明细循环;
    --nContainerNo number(10); --记录容器总数;

    nContainerIndex number(10); --记录容器索引;

    nUnAllotQTY stock_content.qty%type; --记录差异量;

    nArticleQTY stock_content.qty%type; --当前商品数量;
    nAllotQTY   stock_content.qty%type; --当前写入明细的数量;

    nContainerQTY number(10); --记录取号数量;
    nLabelDetail  number(10); --是否进入写标签 明细 循环

    --strHaveSupplyDevice varchar2(500);--是否有补货设备，有可能需要按区域来取值，预留 ( 1 提前拣选  0  非提前拣选)
    --strHaveOutstockDevice varchar2(500);--是否有出型拣货设备，如分播线、分拣机等，预留

    strManualFlag   varchar2(1); --库存记录方式（0, 记录在标签上  1，记录在储位上）
    strWContainerNo varchar2(1); --写取号时 是否写入临时表  （  T 写入  D  不写 ）
  begin
    strOutMsg := 'N|[P_O_WriteLabelSerial_PT]';

    strReport_ID := CONST_REPORTID.B_CustPickLabel_PD2;
    strUserType  := '1';
    strStatus    := '50';
    --strHaveOutstockDevice := '1';
    strContainerType := 'P';
    -------------------------------取系统参数-----------------------------------

    pklg_wms_base.p_GetBasePara(strEnterPriseNo,
                                strwarehouse_no,
                                strOwnerNo,
                                'TaskOmConversionOperateP',
                                'O',
                                'O_TASK',
                                strConversionOperateP,
                                nConversionOperateP,
                                strOutMsg);

    if instr(strOutMsg, 'N', 1, 1) = 1 then
      strOutMsg := 'N|[E22106]';
      return;
    end if;

    pklg_wms_base.p_GetBasePara(strEnterPriseNo,
                                strwarehouse_no,
                                strOwnerNo,
                                'TaskOmProduceLableTypeC',
                                'O',
                                'O_TASK',
                                strProduceLableTypeC,
                                nProduceLableTypeC,
                                strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      strOutMsg := 'N|[E22105]';
      return;
    end if;

    pklg_wms_base.p_GetBasePara(strEnterPriseNo,
                                strwarehouse_no,
                                strOwnerNo,
                                'TaskOmLabelPickFlag',
                                'O',
                                'O_TASK',
                                strOmLabelPickFlag,
                                nOmLabelPickFlag,
                                strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      strOutMsg := 'N|[E22110]';
    end if;

    strManualFlag := '1';
    if strProduceLableTypeC = '1' then
      strManualFlag := '0';
    end if;
    strOldcondition := 'N';
    --------------------循环下架明细写标签明细信息--------------------
    for om_Info_p in (SELECT A.*,
                             CAI.BARCODE,
                             CAI.LOT_NO,
                             CAI.PRODUCE_DATE,
                             CAI.EXPIRE_DATE,
                             CAI.QUALITY,
                             nvl(BAP.SORTER_FLAG, '0'),
                             (BAP.QPALETTE * CDA.PAL_OUT_RATE / 100) MIN_PAL_QTY,
                             (SUM(A.ARTICLE_QTY)
                              OVER(PARTITION BY A.ARTICLE_NO,
                                   A.CUST_NO,
                                   A.DELIVER_OBJ,
                                   A.PACKING_QTY,
                                   A.S_CELL_NO,
                                   A.D_CELL_NO,
                                   CAI.BARCODE,
                                   CAI.LOT_NO,
                                   CAI.PRODUCE_DATE,
                                   CAI.EXPIRE_DATE,
                                   CAI.QUALITY,
                                   A.Label_NO)) SUM_CELL_QTY
                        FROM odata_outstock_d A
                       INNER JOIN STOCK_ARTICLE_INFO CAI
                          ON A.ARTICLE_NO = CAI.ARTICLE_NO
                         and a.enterprise_no = cai.enterprise_no
                         AND A.ARTICLE_ID = CAI.ARTICLE_ID
                        LEFT JOIN bdef_article_packing BAP
                          ON A.ARTICLE_NO = BAP.ARTICLE_NO
                         and a.enterprise_no = bap.enterprise_no
                         AND A.PACKING_QTY = BAP.PACKING_QTY
                       INNER JOIN CDEF_DEFCELL CDC
                          ON CDC.warehouse_no = A.warehouse_no
                         AND CDC.CELL_NO = A.S_CELL_NO
                       INNER JOIN CDEF_DEFAREA CDA
                          ON CDA.warehouse_no = CDC.warehouse_no
                         AND CDA.WARE_NO = CDC.WARE_NO
                         AND CDA.AREA_NO = CDC.AREA_NO
                       WHERE A.warehouse_no = strwarehouse_no
                         and a.enterprise_no = strEnterPriseNo
                         AND A.Outstock_No = strOutStockNo
                       ORDER BY A.Label_NO desc,
                                A.S_CELL_NO,
                                A.ARTICLE_NO,
                                A.CUST_NO,
                                A.DELIVER_OBJ,
                                A.PACKING_QTY,
                                CAI.BARCODE,
                                CAI.LOT_NO,
                                CAI.PRODUCE_DATE,
                                CAI.EXPIRE_DATE,
                                CAI.QUALITY) loop
      --------------------是否进去循环--------------------
      nIndex := 1;
      ---------------序列号---------------
      nRowID := nRowID + 1;
      ---------------配送对象---------------
      --strDeliverObj := 'N';
      ---------------是否按板产生标签  默认 否---------------
      --strCreateLabelPerCase := '0';

      strCurrCondition := om_Info_p.s_cell_no || om_Info_p.article_no ||
                          om_Info_p.cust_no || om_Info_p.deliver_obj ||
                          om_Info_p.packing_qty || om_Info_p.Barcode ||
                          om_Info_p.Lot_No || om_Info_p.Quality ||
                          om_Info_p.Produce_Date || om_Info_p.Expire_Date ||
                          om_Info_p.d_Cell_No || om_Info_p.Label_No;
      ---------------修正一张单中一个品项从C、M 转 P 后 所有的品项都转 P 了 ---------------
      strCreateLabelPerCase := '0';
      ---------------原装箱 是否可一箱一标签---------------
      /*if strProduceLableTypeC = '2' then
        ---------------提前拣选---------------
        if om_Info_p.Advancer_Pick_Flag='1' then
         strHaveSupplyDevice := '1';
        end if;
        if strHaveOutstockDevice = '0' then
          strCreateLabelPerCase := '1';
        end if;
        ---------------达一定量 出板型---------------
        if om_Info_p.Sorter_Flag = '0' then
          if om_Info_p.Sum_Cell_Qty >= om_Info_p.Min_Pal_Qty then
            if strConversionOperateP = '1' then
              strCreateLabelPerCase := '1';
            end if;
          end if;
        end if;
        strCreateLabelPerCase := '1';
      end if;*/
      ---------------------是否出板型---------------------------
      /*if strCreateLabelPerCase = '1' then
        if strOldcondition <> strCurrCondition then
          ---------------P 型 出货 不是一箱一标签 且 不可上分拣 按来源容器写标签-------------------
          P_OM_WriteLabelContainerNo_P(strwarehouse_no, --仓别
                                             strOutStockNo, --下架单号
                                             strUserID, --员工ID
                                             strOutMsg);
          if instr(strOutMsg, 'N', 1, 1) = 1 then
            return;
          end if;
          nContainerQTY := 0;
        else
          nContainerQTY := 0;
        end if;
        strReport_ID :=CONST_REPORTID.OmCustPickLabel_P_Detail;
        strContainerType:='P';
      else*/
      if strOldcondition <> strCurrCondition then
        nContainerQTY := ceil(om_Info_p.Sum_Cell_Qty /
                              om_Info_p.Packing_Qty);
      else
        nContainerQTY := 0;
      end if;
      strReport_ID     := CONST_REPORTID.B_CustPickLabel_PD2;
      strContainerType := 'C';
      strWContainerNo  := 'T';
      /*end if;*/
      strOldcondition := strCurrCondition;
      if nContainerQTY > 0 then
        -------------------------------取容器号-----------------------------------
        PKLG_WMS_BASE.p_get_ContainerNoBase(strEnterPriseNo,
                                            strwarehouse_no,
                                            strContainerType,
                                            strUserID,
                                            strWContainerNo,
                                            nContainerQTY,
                                            '1',
                                            NULL,
                                            strLabelNo,
                                            strNContainerNo,
                                            strSessionID,
                                            strOutMsg);
        if instr(strOutMsg, 'N', 1, 1) = 1 then
          return;
        end if;
        ---------------写标签头---------------
        if strWContainerNo = 'T' then
          INSERT INTO stock_label_m
            (enterprise_no,
             warehouse_no,
             BATCH_NO,
             SOURCE_NO,
             REPORT_ID,
             LABEL_NO,
             CONTAINER_NO,
             CONTAINER_TYPE,
             DELIVER_AREA,
             STATUS,
             USE_TYPE,
             OWNER_CELL_NO,
             OWNER_CONTAINER_NO,
             CUST_NO,
             TRUNCK_CELL_NO,
             A_SORTER_CHUTE_NO,
             CHECK_CHUTE_NO,
             DELIVER_OBJ,
             LINE_NO,
             EXP_DATE,
             CURR_AREA,
             RGST_NAME,
             RGST_DATE,
             device_no,
             hm_manual_flag,
             STOCK_TYPE,
             wave_no)
            SELECT a.enterprise_no,
                   A.warehouse_no,
                   A.BATCH_NO,
                   A.OUTSTOCK_NO,
                   strReport_ID,
                   B.Label_No,
                   B.CONTAINER_NO,
                   B.CONTAINER_TYPE,
                   NVL(DELIVER_AREA, 'N'),
                   strStatus,
                   strUserType,
                   A.S_CELL_NO,
                   B.CONTAINER_NO,
                   CUST_NO,
                   A.TRUNCK_CELL_NO,
                   A.A_SORTER_CHUTE_NO,
                   A.CHECK_CHUTE_NO,
                   A.DELIVER_OBJ,
                   A.LINE_NO,
                   A.EXP_DATE,
                   A.ADVANCE_CELL_NO,
                   B.RGST_NAME,
                   SYSDATE,
                   A.device_no,
                   strManualFlag,
                   A.STOCK_TYPE,
                   a.wave_no
              FROM odata_outstock_d A
             INNER JOIN STOCK_NO_LOC B
                ON A.warehouse_no = B.warehouse_no
               and a.enterprise_no = b.enterprise_no
             WHERE A.OUTSTOCK_NO = om_Info_p.Outstock_No
               AND A.warehouse_no = om_Info_p.warehouse_no
               AND A.ARTICLE_NO = om_Info_p.Article_No
               AND A.DIVIDE_ID = om_Info_p.Divide_Id
               AND A.PACKING_QTY = om_Info_p.Packing_Qty
               AND A.S_CELL_NO = om_Info_p.s_Cell_No
               AND A.D_CELL_NO = om_Info_p.d_Cell_No
               AND A.CUST_NO = om_Info_p.Cust_No
               AND A.DELIVER_OBJ = om_Info_p.Deliver_Obj
               AND B.RGST_NAME = strUserID
               AND B.SESSION_ID = strSessionID
               AND B.CONTAINER_TYPE = strContainerType
               AND ROWNUM <= nContainerQTY;
        else
          INSERT INTO stock_label_m
            (enterprise_no,
             warehouse_no,
             BATCH_NO,
             SOURCE_NO,
             REPORT_ID,
             LABEL_NO,
             CONTAINER_NO,
             CONTAINER_TYPE,
             DELIVER_AREA,
             STATUS,
             USE_TYPE,
             OWNER_CELL_NO,
             OWNER_CONTAINER_NO,
             CUST_NO,
             TRUNCK_CELL_NO,
             A_SORTER_CHUTE_NO,
             CHECK_CHUTE_NO,
             DELIVER_OBJ,
             LINE_NO,
             EXP_DATE,
             CURR_AREA,
             RGST_NAME,
             RGST_DATE,
             device_no,
             hm_manual_flag,
             STOCK_TYPE,
             wave_no)
            SELECT a.enterprise_no,
                   A.warehouse_no,
                   A.BATCH_NO,
                   A.OUTSTOCK_NO,
                   strReport_ID,
                   strLabelNo,
                   strNContainerNo,
                   strContainerType,
                   NVL(DELIVER_AREA, 'N'),
                   strStatus,
                   strUserType,
                   A.S_CELL_NO,
                   strNContainerNo,
                   CUST_NO,
                   A.TRUNCK_CELL_NO,
                   A.A_SORTER_CHUTE_NO,
                   A.CHECK_CHUTE_NO,
                   A.DELIVER_OBJ,
                   A.LINE_NO,
                   A.EXP_DATE,
                   A.ADVANCE_CELL_NO,
                   strUserID,
                   SYSDATE,
                   A.device_no,
                   strManualFlag,
                   A.STOCK_TYPE,
                   a.wave_no
              FROM odata_outstock_d A
             WHERE A.OUTSTOCK_NO = om_Info_p.Outstock_No
               AND A.warehouse_no = om_Info_p.warehouse_no
               AND A.ARTICLE_NO = om_Info_p.Article_No
               AND A.DIVIDE_ID = om_Info_p.Divide_Id
               AND A.PACKING_QTY = om_Info_p.Packing_Qty
               AND A.S_CELL_NO = om_Info_p.s_Cell_No
               AND A.D_CELL_NO = om_Info_p.d_Cell_No
               AND A.CUST_NO = om_Info_p.Cust_No
               AND A.DELIVER_OBJ = om_Info_p.Deliver_Obj
               AND ROWNUM <= nContainerQTY;
        end if;

        ---------------新增失败---------------
        if sql%rowcount <= 0 then
          strOutMsg := 'N|[E22108]';
          return;
        end if;
        if sql%rowcount < nContainerQTY then
          strOutMsg := 'N|[E22108]';
          return;
        end if;

        -----------新增标签日志
        if strWContainerNo = 'T' then
          INSERT INTO STOCK_LABEL_LOG
            (enterprise_no,
             warehouse_no,
             LABEL_NO,
             CONTAINER_NO,
             CONTAINER_TYPE,
             OWNER_CONTAINER_NO,
             STATUS,
             RGST_NAME,
             RGST_DATE,
             OWNER_CELL_NO,
             CURR_AREA)
            SELECT a.enterprise_no,
                   A.warehouse_no,
                   B.LABEL_NO,
                   B.CONTAINER_NO,
                   B.CONTAINER_TYPE,
                   B.Container_No,
                   strStatus,
                   strUserID,
                   sysdate,
                   A.s_Cell_No,
                   A.s_Cell_No
              FROM odata_outstock_d A
             INNER JOIN STOCK_NO_LOC B
                ON a.warehouse_no = b.warehouse_no
               and a.enterprise_no = b.enterprise_no
             INNER JOIN WMS_DEFCONTAINER C
                ON B.CONTAINER_TYPE = C.CONTAINER_TYPE
               AND C.warehouse_no = A.warehouse_no
               and a.enterprise_no = c.enterprise_no
             WHERE A.Outstock_No = strOutStockNo
               AND A.warehouse_no = strwarehouse_no
               AND A.ARTICLE_NO = om_Info_p.Article_No
               AND A.DIVIDE_ID = om_Info_p.Divide_Id
               AND A.PACKING_QTY = om_Info_p.Packing_Qty
               AND A.S_CELL_NO = om_Info_p.s_Cell_No
               AND A.D_CELL_NO = om_Info_p.d_Cell_No
               AND A.CUST_NO = om_Info_p.Cust_No
               AND A.DELIVER_OBJ = om_Info_p.Deliver_Obj
               AND B.RGST_NAME = strUserID
               AND B.SESSION_ID = strSessionID
               AND B.CONTAINER_TYPE = strContainerType
               AND ROWNUM <= nContainerQTY;
        else
          INSERT INTO STOCK_LABEL_LOG
            (enterprise_no,
             warehouse_no,
             LABEL_NO,
             CONTAINER_NO,
             CONTAINER_TYPE,
             OWNER_CONTAINER_NO,
             STATUS,
             RGST_NAME,
             RGST_DATE,
             OWNER_CELL_NO,
             CURR_AREA)
            SELECT enterprise_no,
                   warehouse_no,
                   LABEL_NO,
                   CONTAINER_NO,
                   CONTAINER_TYPE,
                   OWNER_CONTAINER_NO,
                   STATUS,
                   RGST_NAME,
                   RGST_DATE,
                   OWNER_CELL_NO,
                   CURR_AREA
              FROM stock_label_m A
             WHERE A.SOURCE_NO = strOutStockNo
               AND A.warehouse_no = strwarehouse_no
               and a.enterprise_no = strEnterPriseNo
               AND A.Label_No = strLabelNo;
        end if;
        ---------------记录容器总数---------------nContainerNo
        /*SELECT count(B.CONTAINER_NO)
         into nContainerNo
         FROM STOCK_NO_LOC B
        WHERE B.warehouse_no = om_Info_p.warehouse_no
          AND B.RGST_NAME = strUserID
          AND B.SESSION_ID = strSessionID
          AND B.CONTAINER_TYPE = strContainerType;*/

        nContainerIndex := 1;
        nRowID          := 1;
        nUnAllotQTY     := 0;
        ---------------取下架明细写标签---------------
        for om_OutStock in (SELECT A.*
                              FROM odata_outstock_d   A,
                                   STOCK_ARTICLE_INFO CAI
                             WHERE A.ARTICLE_NO = CAI.ARTICLE_NO
                               AND A.ARTICLE_ID = CAI.ARTICLE_ID
                               and a.enterprise_no = cai.enterprise_no
                               and a.enterprise_no = strEnterPriseNo
                               AND A.OUTSTOCK_NO = om_Info_p.Outstock_No
                               AND A.warehouse_no = om_Info_p.warehouse_no
                               AND A.ARTICLE_NO = om_Info_p.Article_No
                               AND A.Label_NO = om_Info_p.Label_No
                               AND A.PACKING_QTY = om_Info_p.Packing_Qty
                               AND A.S_CELL_NO = om_Info_p.s_Cell_No
                               AND A.D_CELL_NO = om_Info_p.d_Cell_No
                               AND A.CUST_NO = om_Info_p.Cust_No
                               AND A.DELIVER_OBJ = om_Info_p.Deliver_Obj
                               AND CAI.LOT_NO = om_Info_p.Lot_No
                               AND CAI.QUALITY = om_Info_p.Quality
                               AND CAI.PRODUCE_DATE = om_Info_p.Produce_Date
                               AND CAI.EXPIRE_DATE = om_Info_p.Expire_Date) loop
          nLabel      := 1;
          nArticleQTY := om_OutStock.Article_Qty; --当前商品数量;
          nAllotQTY   := 0; --当前写入明细的数量;

          ---------------循环写标签明细---------------
          loop
            nLabelDetail := 1;
            if nUnAllotQTY > 0 then
              if nUnAllotQTY > nArticleQTY then
                nAllotQTY := nArticleQTY;
              else
                nAllotQTY := nUnAllotQTY;
              end if;
              nUnAllotQTY := nUnAllotQTY - nAllotQTY;
            else
              if nArticleQTY >= om_OutStock.Packing_Qty and
                 strContainerType = 'C' then
                nAllotQTY   := om_OutStock.Packing_Qty;
                nUnAllotQTY := 0;
              else
                nAllotQTY := nArticleQTY;
                if strContainerType = 'C' then
                  nUnAllotQTY := om_OutStock.Packing_Qty - nAllotQTY;
                else
                  nUnAllotQTY := 0;
                end if;
              end if;
            end if;
            ---------------取新容器号---------------
            SELECT B.CONTAINER_NO
              into strContainerNo
              FROM STOCK_NO_LOC B
             WHERE B.warehouse_no = om_Info_p.warehouse_no
               and b.enterprise_no = strEnterPriseNo
               AND B.RGST_NAME = strUserID
               AND B.SESSION_ID = strSessionID
               AND B.CONTAINER_TYPE = strContainerType
               AND rownum = 1
             order by B.container_no;
            if strContainerNo is null then
              strOutMsg := 'N|[E22111]';
              return;
            end if;
            -------------写标签明细--------------
            INSERT INTO stock_label_d
              (enterprise_no,
               warehouse_no,
               BATCH_NO,
               OWNER_NO,
               SOURCE_NO,
               CONTAINER_NO,
               CONTAINER_TYPE,
               ARTICLE_NO,
               ARTICLE_ID,
               PACKING_QTY,
               QTY,
               ROW_ID,
               EXP_NO,
               EXP_TYPE,
               EXP_DATE,
               WAVE_NO,
               CUST_NO,
               SUB_CUST_NO,
               LINE_NO,
               STATUS,
               DIVIDE_ID,
               RGST_NAME,
               RGST_DATE,
               DPS_CELL_NO,
               DELIVER_OBJ,
               deliverobj_order,
               ADVANCE_CELL_NO)--Modify BY QZH AT 2016-5-25
            values
              (strEnterPriseNo,
               om_OutStock.warehouse_no,
               om_OutStock.Batch_No,
               om_OutStock.Owner_No,
               om_OutStock.Outstock_No,
               strContainerNo,
               strContainerType,
               om_OutStock.Article_No,
               om_OutStock.Article_Id,
               om_OutStock.Packing_Qty,
               nAllotQTY,
               nRowID,
               om_OutStock.Exp_No,
               om_OutStock.Exp_Type,
               om_OutStock.Exp_Date,
               om_OutStock.wave_no,
               om_OutStock.Cust_No,
               om_OutStock.Sub_Cust_No,
               om_OutStock.Line_No,
               strStatus,
               om_OutStock.Divide_Id,
               strUserID,
               sysdate,
               om_OutStock.Dps_Cell_No,
               om_OutStock.Deliver_Obj,
               om_OutStock.deliverobj_order,
               om_OutStock.s_Cell_No);
            ---------------新增失败---------------
            if sql%rowcount <= 0 then
              strOutMsg := 'N|[E22108]';
              return;
            end if;
            if nUnAllotQTY <= 0 then
              if strContainerType = 'C' then
                nContainerIndex := nContainerIndex + 1;
                -------------------------删除取号 临时表数据---------------------------
                P_O_DeleteContainerNoLoc(strEnterPriseNo,
                                         strwarehouse_no,
                                         strContainerType, --标签类型
                                         strContainerNo,
                                         strSessionID, --会话ＩＤ
                                         strUserID, --员工ID
                                         strOutMsg);
                if instr(strOutMsg, 'N', 1, 1) = 1 then
                  return;
                end if;
                nRowID := 1;
              else
                nRowID := nRowID + 1;
              end if;
            else
              nRowID := nRowID + 1;
            end if;
            nArticleQTY := nArticleQTY - nAllotQTY;
            ---------------跳出当前循环------------
            if nArticleQTY <= 0 then
              exit;
            end if;
            if nContainerIndex > nContainerQTY then
              exit;
            end if;
          end loop;
          if nLabelDetail < 1 then
            strOutMsg := 'N|[E22107]';
            return;
          end if;
        end loop;
        if (nLabel < 1) then
          strOutMsg := 'N|[E22107]';
          return;
        end if;
      end if;
    end loop;
    if (nIndex < 1) then
      strOutMsg := 'N|[E22107]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_WriteLabelSerial_PT;

  /*****************************************************************************************
     功能：写流水标签——B 型  补货
  *****************************************************************************************/
  procedure P_H_WriteLabelSerial_BT(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                    strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                    strOwnerNo      in odata_outstock_m.owner_no%type,
                                    strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                    strOperateType  in odata_outstock_m.operate_type%type,
                                    strPickType     in odata_outstock_m.pick_type%type,
                                    strTaskType     in odata_outstock_m.task_type%type,
                                    strOutstockType in odata_outstock_m.outstock_type%type,
                                    strUserID       in stock_label_m.updt_name%type, --员工ID
                                    strOutMsg       out varchar2) --返回值
   is
    nIndex           number(10); --记录数，以做判断;
    strContainerType varchar2(1); --容器类型
    strContainerNo   varchar2(24); --容器号
    strNContainerNo  varchar2(24); --容器号
    strReport_ID     varchar2(20); --报表ＩＤ
    nRowID           number(10); --标签明细序列号
    strUserType      varchar2(1); --标签用途(1：客户标签，2：分播标签，3：移库标签)
    strStatus        varchar2(2); --标签状态
    --strDeliverObj    varchar2(15); --配送对象
    strLabelNo   varchar2(24); --标签号
    strSessionID varchar2(100); --会话ＩＤ

    strOldcondition  varchar2(10000); -- 成标签条件
    strCurrCondition varchar2(10000); -- 成标签条件

    strCreateLabelPerCase varchar2(1); --是否按板产生标签 （ 0 否 ，1 是）

    --strConversionOperateP varchar2(500); --是否允许C 、M 转 P ( 0 不允许 ，1 允许)
    strProduceLableTypeC varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)
    --strOmLabelPickFlag    varchar2(500); --出货是否支持标签库存箱型拣货 ( 0 不支持(C-->B) , 1-支持(B-->C))

    --nConversionOperateP varchar2(500); --是否允许C 、M 转 P ( 0 不允许 ，1 允许)
    nProduceLableTypeC varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)
    --nOmLabelPickFlag    varchar2(500); --出货是否支持标签库存箱型拣货 ( 0 不支持(C-->B) , 1-支持(B-->C))

    --nContainer   number(10); --记录数，取号循环;
    nLabel number(10); --记录数，写标签明细循环;
    --nContainerNo number(10); --记录容器总数;

    nContainerIndex number(10); --记录容器索引;

    nUnAllotQTY stock_content.qty%type; --记录差异量;

    nArticleQTY stock_content.qty%type; --当前商品数量;
    nAllotQTY   stock_content.qty%type; --当前写入明细的数量;

    nContainerQTY number(10); --记录取号数量;

    --strHaveSupplyDevice varchar2(500);--是否有补货设备，有可能需要按区域来取值，预留 ( 1 提前拣选  0  非提前拣选)
    --strHaveOutstockDevice varchar2(500);--是否有出型拣货设备，如分播线、分拣机等，预留

    strManualFlag   varchar2(1); --库存记录方式（0, 记录在标签上  1，记录在储位上）
    strWContainerNo varchar2(1); --写取号时 是否写入临时表  （  T 写入  D  不写 ）
  begin
    strOutMsg := 'N|[P_H_WriteLabelSerial_BT]';

    strReport_ID := CONST_REPORTID.B_HMTask_CD;
    strUserType  := '3';
    strStatus    := '40';
    --strHaveOutstockDevice :='1';
    strContainerType := 'P';

    strOldcondition := 'N';

    strManualFlag := '1';

    pklg_wms_base.p_GetBasePara(strEnterPriseNo,
                                strwarehouse_no,
                                strOwnerNo,
                                'TaskOmProduceLableTypeC',
                                'O',
                                'O_TASK',
                                strProduceLableTypeC,
                                nProduceLableTypeC,
                                strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      strOutMsg := 'N|[E22105]';
      return;
    end if;

    if strProduceLableTypeC = '1' then
      strManualFlag := '0';
    end if;
    --------------------循环下架明细写标签明细信息--------------------
    for om_Info in (SELECT A.*,
                           CAI.BARCODE,
                           CAI.LOT_NO,
                           CAI.PRODUCE_DATE,
                           CAI.EXPIRE_DATE,
                           CAI.QUALITY,
                           nvl(BAP.SORTER_FLAG, 0),
                           (BAP.QPALETTE * CDA.PAL_OUT_RATE / 100) MIN_PAL_QTY,
                           CDA2.ADVANCER_PICK_FLAG,
                           CDA2.divide_line_flag,
                           (SUM(A.ARTICLE_QTY)
                            OVER(PARTITION BY A.ARTICLE_NO,
                                 A.CUST_NO,
                                 A.DELIVER_OBJ,
                                 A.PACKING_QTY,
                                 A.S_CELL_NO,
                                 A.D_CELL_NO,
                                 CAI.BARCODE,
                                 CAI.LOT_NO,
                                 CAI.PRODUCE_DATE,
                                 CAI.EXPIRE_DATE,
                                 CAI.QUALITY,
                                 A.Label_NO)) SUM_CELL_QTY
                      FROM odata_outstock_d A
                     INNER JOIN STOCK_ARTICLE_INFO CAI
                        ON A.ARTICLE_NO = CAI.ARTICLE_NO
                       and a.enterprise_no = cai.enterprise_no
                       AND A.ARTICLE_ID = CAI.ARTICLE_ID
                      left JOIN bdef_article_packing BAP
                        ON A.ARTICLE_NO = BAP.ARTICLE_NO
                       and a.enterprise_no = bap.enterprise_no
                       AND A.PACKING_QTY = BAP.PACKING_QTY
                      LEFT JOIN CDEF_DEFCELL CDC
                        ON CDC.warehouse_no = a.warehouse_no
                       and cdc.enterprise_no = a.enterprise_no
                       AND CDC.CELL_NO = A.S_CELL_NO
                      LEFT JOIN CDEF_DEFCELL CDC2
                        ON CDC2.warehouse_no = a.warehouse_no
                       and cdc2.enterprise_no = a.enterprise_no
                       AND CDC2.CELL_NO = A.D_CELL_NO
                      LEFT JOIN CDEF_DEFAREA CDA
                        ON CDA.warehouse_no = CDC.warehouse_no
                       and cda.enterprise_no = cdc.enterprise_no
                       AND CDA.WARE_NO = CDC.WARE_NO
                       AND CDA.AREA_NO = CDC.AREA_NO
                      LEFT JOIN CDEF_DEFAREA CDA2
                        ON CDA2.warehouse_no = CDC2.warehouse_no
                       and cda2.enterprise_no = cdc2.enterprise_no
                       AND CDA2.WARE_NO = CDC2.WARE_NO
                       AND CDA2.AREA_NO = CDC2.AREA_NO
                     WHERE A.warehouse_no = strwarehouse_no
                       AND A.Outstock_No = strOutStockNo
                       and a.enterprise_no = strEnterPriseNo
                     ORDER BY A.Label_NO desc,
                              A.S_CELL_NO,
                              A.ARTICLE_NO,
                              A.CUST_NO,
                              A.DELIVER_OBJ,
                              A.PACKING_QTY,
                              CAI.BARCODE,
                              CAI.LOT_NO,
                              CAI.PRODUCE_DATE,
                              CAI.EXPIRE_DATE,
                              CAI.QUALITY) loop
      --------------------是否进去循环--------------------
      nIndex := 1;
      ---------------序列号---------------
      nRowID := nRowID + 1;
      ---------------配送对象---------------
      --strDeliverObj := 'N';
      ---------------是否按板产生标签  默认 否---------------
      --strCreateLabelPerCase := '0';

      strCurrCondition := om_Info.s_cell_no || om_Info.article_no ||
                          om_Info.cust_no || om_Info.deliver_obj ||
                          om_Info.packing_qty || /*om_Info.Supplier_No ||*/
                          om_Info.Barcode || om_Info.Lot_No ||
                          om_Info.Quality || /*om_Info.Item_Type ||*/
                          om_Info.Produce_Date || om_Info.Expire_Date ||
                          om_Info.d_Cell_No || om_Info.Label_No;
      ---------------修正一张单中一个品项从C、M 转 P 后 所有的品项都转 P 了 ---------------
      strCreateLabelPerCase := '0';

      /*---------------提前拣选---------------
      strHaveSupplyDevice := om_Info.Advancer_Pick_Flag;
      ---------------不可上分拣 出板型---------------
      if om_Info.Sorter_Flag = '0' then
        strCreateLabelPerCase := '1';
      end if;
      if strHaveSupplyDevice = '0' then
        strCreateLabelPerCase := '1';
      end if;*/
      if om_Info.Divide_Line_Flag = '0' then
        strCreateLabelPerCase := '1';
      end if;
      ---------------------是否出板型---------------------------
      if strCreateLabelPerCase = '1' then
        if strOldcondition <> strCurrCondition then
          nContainerQTY := 1;
        else
          nContainerQTY := 0;
        end if;
        --strReport_ID:=CONST_REPORTID.OmCustPickLabel_P_Detail; 补货标签 相同
        strContainerType := 'P';
        strWContainerNo  := 'D';
      else
        if strOldcondition <> strCurrCondition then
          nContainerQTY := ceil(om_Info.Sum_Cell_Qty / om_Info.Packing_Qty);
        else
          nContainerQTY := 0;
        end if;
        --strReport_ID:=CONST_REPORTID.OmCustPickLabel_C_Detail;
        strContainerType := 'C';
        strWContainerNo  := 'T';
      end if;
      strOldcondition := strCurrCondition;
      if nContainerQTY > 0 then
        -------------------------------取容器号-----------------------------------
        PKLG_WMS_BASE.p_get_ContainerNoBase(strEnterPriseNo,
                                            strwarehouse_no,
                                            strContainerType,
                                            strUserID,
                                            strWContainerNo,
                                            nContainerQTY,
                                            '1',
                                            NULL,
                                            strLabelNo,
                                            strNContainerNo,
                                            strSessionID,
                                            strOutMsg);
        if instr(strOutMsg, 'N', 1, 1) = 1 then
          return;
        end if;
        ---------------写标签头---------------
        if strWContainerNo = 'T' then
          INSERT INTO stock_label_m
            (enterprise_no,
             warehouse_no,
             BATCH_NO,
             SOURCE_NO,
             REPORT_ID,
             LABEL_NO,
             CONTAINER_NO,
             CONTAINER_TYPE,
             DELIVER_AREA,
             STATUS,
             USE_TYPE,
             OWNER_CELL_NO,
             OWNER_CONTAINER_NO,
             CUST_NO,
             TRUNCK_CELL_NO,
             A_SORTER_CHUTE_NO,
             CHECK_CHUTE_NO,
             DELIVER_OBJ,
             LINE_NO,
             EXP_DATE,
             CURR_AREA,
             RGST_NAME,
             RGST_DATE,
             device_no,
             hm_manual_flag,
             STOCK_TYPE,
             wave_no)
            SELECT a.enterprise_no,
                   A.warehouse_no,
                   A.BATCH_NO,
                   A.OUTSTOCK_NO,
                   strReport_ID,
                   B.Label_No,
                   B.CONTAINER_NO,
                   B.CONTAINER_TYPE,
                   NVL(DELIVER_AREA, 'N'),
                   strStatus,
                   strUserType,
                   A.S_CELL_NO,
                   B.CONTAINER_NO,
                   CUST_NO,
                   A.TRUNCK_CELL_NO,
                   A.A_SORTER_CHUTE_NO,
                   A.CHECK_CHUTE_NO,
                   A.DELIVER_OBJ,
                   A.LINE_NO,
                   A.EXP_DATE,
                   A.ADVANCE_CELL_NO,
                   B.RGST_NAME,
                   SYSDATE,
                   A.device_no,
                   strManualFlag,
                   A.STOCK_TYPE,
                   a.wave_no
              FROM odata_outstock_d A
             INNER JOIN STOCK_NO_LOC B
                ON A.warehouse_no = A.warehouse_no
               and a.enterprise_no = b.enterprise_no
             WHERE A.OUTSTOCK_NO = om_Info.Outstock_No
               AND A.warehouse_no = om_Info.warehouse_no
               and a.enterprise_no = strEnterPriseNo
               AND A.ARTICLE_NO = om_Info.Article_No
               AND A.DIVIDE_ID = om_Info.Divide_Id
               AND A.PACKING_QTY = om_Info.Packing_Qty
               AND A.S_CELL_NO = om_Info.s_Cell_No
               AND A.D_CELL_NO = om_Info.d_Cell_No
               AND A.CUST_NO = om_Info.Cust_No
               AND A.DELIVER_OBJ = om_Info.Deliver_Obj
               AND B.RGST_NAME = strUserID
               AND B.SESSION_ID = strSessionID
               AND B.CONTAINER_TYPE = strContainerType
               AND ROWNUM <= nContainerQTY;
        else
          INSERT INTO stock_label_m
            (enterprise_no,
             warehouse_no,
             BATCH_NO,
             SOURCE_NO,
             REPORT_ID,
             LABEL_NO,
             CONTAINER_NO,
             CONTAINER_TYPE,
             DELIVER_AREA,
             STATUS,
             USE_TYPE,
             OWNER_CELL_NO,
             OWNER_CONTAINER_NO,
             CUST_NO,
             TRUNCK_CELL_NO,
             A_SORTER_CHUTE_NO,
             CHECK_CHUTE_NO,
             DELIVER_OBJ,
             LINE_NO,
             EXP_DATE,
             CURR_AREA,
             RGST_NAME,
             RGST_DATE,
             device_no,
             hm_manual_flag,
             STOCK_TYPE,
             wave_no)
            SELECT a.enterprise_no,
                   A.warehouse_no,
                   A.BATCH_NO,
                   A.OUTSTOCK_NO,
                   strReport_ID,
                   strLabelNo,
                   strNContainerNo,
                   strContainerType,
                   NVL(DELIVER_AREA, 'N'),
                   strStatus,
                   strUserType,
                   A.S_CELL_NO,
                   strNContainerNo,
                   CUST_NO,
                   A.TRUNCK_CELL_NO,
                   A.A_SORTER_CHUTE_NO,
                   A.CHECK_CHUTE_NO,
                   A.DELIVER_OBJ,
                   A.LINE_NO,
                   A.EXP_DATE,
                   A.ADVANCE_CELL_NO,
                   strUserID,
                   SYSDATE,
                   A.device_no,
                   strManualFlag,
                   A.STOCK_TYPE,
                   a.wave_no
              FROM odata_outstock_d A
             WHERE A.OUTSTOCK_NO = om_Info.Outstock_No
               AND A.warehouse_no = om_Info.warehouse_no
               and a.enterprise_no = strEnterPriseNo
               AND A.ARTICLE_NO = om_Info.Article_No
               AND A.DIVIDE_ID = om_Info.Divide_Id
               AND A.PACKING_QTY = om_Info.Packing_Qty
               AND A.S_CELL_NO = om_Info.s_Cell_No
               AND A.D_CELL_NO = om_Info.d_Cell_No
               AND A.CUST_NO = om_Info.Cust_No
               AND A.DELIVER_OBJ = om_Info.Deliver_Obj
               AND ROWNUM <= nContainerQTY;
        end if;

        ---------------新增失败---------------
        if sql%rowcount <= 0 then
          strOutMsg := 'N|[E22108]';
          return;
        end if;
        if sql%rowcount < nContainerQTY then
          strOutMsg := 'N|[E22108]';
          return;
        end if;
        -----------新增标签日志
        if strWContainerNo = 'T' then
          INSERT INTO STOCK_LABEL_LOG
            (enterprise_no,
             warehouse_no,
             LABEL_NO,
             CONTAINER_NO,
             CONTAINER_TYPE,
             OWNER_CONTAINER_NO,
             STATUS,
             RGST_NAME,
             RGST_DATE,
             OWNER_CELL_NO,
             CURR_AREA)
            SELECT strEnterPriseNo,
                   A.warehouse_no,
                   B.LABEL_NO,
                   B.CONTAINER_NO,
                   B.CONTAINER_TYPE,
                   B.Container_No,
                   strStatus,
                   strUserID,
                   sysdate,
                   A.s_Cell_No,
                   A.s_Cell_No
              FROM odata_outstock_d A
             INNER JOIN STOCK_NO_LOC B
                ON a.warehouse_no = b.warehouse_no
               and a.enterprise_no = b.enterprise_no
             INNER JOIN WMS_DEFCONTAINER C
                ON B.CONTAINER_TYPE = C.CONTAINER_TYPE
               AND C.warehouse_no = A.warehouse_no
               and a.enterprise_no = c.enterprise_no
             WHERE A.Outstock_No = strOutStockNo
               AND A.warehouse_no = strwarehouse_no
               and a.enterprise_no = strEnterPriseNo
               AND A.ARTICLE_NO = om_Info.Article_No
               AND A.DIVIDE_ID = om_Info.Divide_Id
               AND A.PACKING_QTY = om_Info.Packing_Qty
               AND A.S_CELL_NO = om_Info.s_Cell_No
               AND A.D_CELL_NO = om_Info.d_Cell_No
               AND A.CUST_NO = om_Info.Cust_No
               AND A.DELIVER_OBJ = om_Info.Deliver_Obj
               AND B.RGST_NAME = strUserID
               AND B.SESSION_ID = strSessionID
               AND B.CONTAINER_TYPE = strContainerType
               AND ROWNUM <= nContainerQTY;
        else
          INSERT INTO STOCK_LABEL_LOG
            (enterprise_no,
             warehouse_no,
             LABEL_NO,
             CONTAINER_NO,
             CONTAINER_TYPE,
             OWNER_CONTAINER_NO,
             STATUS,
             RGST_NAME,
             RGST_DATE,
             OWNER_CELL_NO,
             CURR_AREA)
            SELECT enterprise_no,
                   warehouse_no,
                   LABEL_NO,
                   CONTAINER_NO,
                   CONTAINER_TYPE,
                   OWNER_CONTAINER_NO,
                   STATUS,
                   RGST_NAME,
                   RGST_DATE,
                   OWNER_CELL_NO,
                   CURR_AREA
              FROM stock_label_m A
             WHERE A.SOURCE_NO = strOutStockNo
               AND A.warehouse_no = strwarehouse_no
               and a.enterprise_no = strEnterPriseNo
               AND A.Label_No = strLabelNo;
        end if;
        ---------------记录容器总数---------------nContainerNo
        /*SELECT count(B.CONTAINER_NO)
         into nContainerNo
         FROM STOCK_NO_LOC B
        WHERE B.warehouse_no = om_Info.warehouse_no
          AND B.RGST_NAME = strUserID
          AND B.SESSION_ID = strSessionID
          AND B.CONTAINER_TYPE =strContainerType;*/

        nContainerIndex := 1;
        nRowID          := 1;
        nUnAllotQTY     := 0;
        ---------------取下架明细写标签---------------
        for om_OutStock in (SELECT A.*
                              FROM odata_outstock_d   A,
                                   STOCK_ARTICLE_INFO CAI
                             WHERE a.enterprise_no = cai.enterprise_no
                               and a.enterprise_no = strEnterPriseNo
                               and a.warehouse_no = strwarehouse_no
                               and A.ARTICLE_NO = CAI.ARTICLE_NO
                               AND A.ARTICLE_ID = CAI.ARTICLE_ID
                               AND A.OUTSTOCK_NO = om_Info.Outstock_No
                               AND A.warehouse_no = om_Info.warehouse_no
                               AND A.ARTICLE_NO = om_Info.Article_No
                               AND A.Label_NO = om_Info.Label_No
                               AND A.PACKING_QTY = om_Info.Packing_Qty
                               AND A.S_CELL_NO = om_Info.s_Cell_No
                               AND A.D_CELL_NO = om_Info.d_Cell_No
                               AND A.CUST_NO = om_Info.Cust_No
                               AND A.DELIVER_OBJ = om_Info.Deliver_Obj
                               AND CAI.LOT_NO = om_Info.Lot_No
                               AND CAI.QUALITY = om_Info.Quality
                               AND CAI.PRODUCE_DATE = om_Info.Produce_Date
                               AND CAI.EXPIRE_DATE = om_Info.Expire_Date) loop
          nLabel      := 1;
          nArticleQTY := om_OutStock.Article_Qty; --当前商品数量;
          nAllotQTY   := 0; --当前写入明细的数量;

          ---------------循环写标签明细---------------
          loop
            if nUnAllotQTY > 0 then
              if nUnAllotQTY > nArticleQTY then
                nAllotQTY := nArticleQTY;
              else
                nAllotQTY := nUnAllotQTY;
              end if;
              nUnAllotQTY := nUnAllotQTY - nAllotQTY;
            else
              if nArticleQTY >= om_OutStock.Packing_Qty and
                 strContainerType = 'C' then
                nAllotQTY   := om_OutStock.Packing_Qty;
                nUnAllotQTY := 0;
              else
                nAllotQTY := nArticleQTY;
                if strContainerType = 'C' then
                  nUnAllotQTY := om_OutStock.Packing_Qty - nAllotQTY;
                else
                  nUnAllotQTY := 0;
                end if;
              end if;
            end if;
            ---------------取新容器号---------------
            if strWContainerNo = 'D' then
              strContainerNo := strNContainerNo;
            else
              SELECT B.CONTAINER_NO
                into strContainerNo
                FROM STOCK_NO_LOC B
               WHERE B.warehouse_no = strwarehouse_no
                 and b.enterprise_no = strEnterPriseNo
                 AND B.RGST_NAME = strUserID
                 AND B.SESSION_ID = strSessionID
                 AND B.CONTAINER_TYPE = strContainerType
                 AND rownum = 1
               order by B.container_no;
              if strContainerNo is null then
                strOutMsg := 'N|[E22111]';
                return;
              end if;
            end if;
            -------------写标签明细--------------
            INSERT INTO stock_label_d
              (enterprise_no,
               warehouse_no,
               BATCH_NO,
               OWNER_NO,
               SOURCE_NO,
               CONTAINER_NO,
               CONTAINER_TYPE,
               ARTICLE_NO,
               ARTICLE_ID,
               PACKING_QTY,
               QTY,
               ROW_ID,
               EXP_NO,
               EXP_TYPE,
               EXP_DATE,
               WAVE_NO,
               CUST_NO,
               SUB_CUST_NO,
               LINE_NO,
               STATUS,
               DIVIDE_ID,
               RGST_NAME,
               RGST_DATE,
               DPS_CELL_NO,
               DELIVER_OBJ,
               deliverobj_order,
               ADVANCE_CELL_NO)--Modify BY QZH AT 2016-5-25
            values
              (strEnterPriseNo,
               om_OutStock.warehouse_no,
               om_OutStock.Batch_No,
               om_OutStock.Owner_No,
               om_OutStock.Outstock_No,
               strContainerNo,
               strContainerType,
               om_OutStock.Article_No,
               om_OutStock.Article_Id,
               om_OutStock.Packing_Qty,
               nAllotQTY,
               nRowID,
               om_OutStock.Exp_No,
               om_OutStock.Exp_Type,
               om_OutStock.Exp_Date,
               om_OutStock.wave_no,
               om_OutStock.Cust_No,
               om_OutStock.Sub_Cust_No,
               om_OutStock.Line_No,
               strStatus,
               om_OutStock.Divide_Id,
               strUserID,
               sysdate,
               om_OutStock.Dps_Cell_No,
               om_OutStock.Deliver_Obj,
               om_OutStock.deliverobj_order,
               om_OutStock.s_Cell_No);
            ---------------新增失败---------------
            if sql%rowcount <= 0 then
              strOutMsg := 'N|[E22108]';
              return;
            end if;
            if nUnAllotQTY <= 0 then
              if strContainerType = 'C' then
                nContainerIndex := nContainerIndex + 1;
                -------------当前取号索引 大于 1 则 调用 删除取号临时表 存储过程
                -------------------------删除取号 临时表数据---------------------------
                P_O_DeleteContainerNoLoc(strEnterPriseNo,
                                         strWareHouse_no,
                                         strContainerType, --标签类型
                                         strContainerNo,
                                         strSessionID, --会话ＩＤ
                                         strUserID, --员工ID
                                         strOutMsg);
                if instr(strOutMsg, 'N', 1, 1) = 1 then
                  return;
                end if;
                nRowID := 1;
              else
                nRowID := nRowID + 1;
              end if;
            else
              nRowID := nRowID + 1;
            end if;
            nArticleQTY := nArticleQTY - nAllotQTY;
            ---------------跳出当前循环------------
            if nArticleQTY <= 0 then
              exit;
            end if;
            if nContainerIndex > nContainerQTY then
              exit;
            end if;
          end loop;
        end loop;
        if (nLabel < 1) then
          strOutMsg := 'N|[E22107]';
          return;
        end if;
      end if;
    end loop;
    if (nIndex < 1) then
      strOutMsg := 'N|[E22107]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_H_WriteLabelSerial_BT;

  /*****************************************************************************************
     功能：写流水标签——C型  出货
  *****************************************************************************************/
  procedure P_O_WriteLabelSerial_CT(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                    strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                    strOwnerNo      in odata_outstock_m.owner_no%type,
                                    strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                    strSorterFlag   in bdef_article_packing.sorter_flag%type, --是否可上分拣
                                    strUserID       in stock_label_m.updt_name%type, --员工ID
                                    strOutMsg       out varchar2) --返回值
   is
    nIndex           number(10); --记录数，以做判断;
    strContainerType varchar2(1); --容器类型
    strContainerNo   varchar2(24); --容器号
    strNContainerNo  varchar2(24); --容器号
    strReport_ID     varchar2(20); --报表ＩＤ
    nRowID           number(10); --标签明细序列号
    strUserType      varchar2(1); --标签用途(1：客户标签，2：分播标签，3：移库标签)
    strStatus        varchar2(2); --标签状态
    strLabelNo       varchar2(24); --标签号
    strSessionID     varchar2(100); --会话ＩＤ

    strOldcondition  varchar2(10000); -- 成标签条件
    strCurrCondition varchar2(10000); -- 成标签条件

    nLabel number(10); --记录数，写标签明细循环;

    nContainerIndex number(10); --记录容器索引;

    nUnAllotQTY stock_content.qty%type; --记录差异量;

    nArticleQTY stock_content.qty%type; --当前商品数量;
    nAllotQTY   stock_content.qty%type; --当前写入明细的数量;

    nContainerQTY number(10); --记录取号数量;

    nLabelDetail number(10); --未进入写标签明细循环

    strManualFlag   varchar2(1); --库存记录方式（0, 记录在标签上  1，记录在储位上）
    strWContainerNo varchar2(1); --写取号时 是否写入临时表  （  T 写入  D  不写 ）
  begin
    strOutMsg := 'N|[P_O_WriteLabelSerial_CT]';

    strReport_ID     := CONST_REPORTID.B_CustPickLabel_PD2;
    strUserType      := '1';
    strStatus        := '50';
    strContainerType := 'C';
    -------------------------------取系统参数-----------------------------------
    strManualFlag := '1';

    strOldcondition := 'N';
    --------------------循环下架明细写标签明细信息--------------------
    for om_Info in (SELECT A.*,
                           (SUM(A.ARTICLE_QTY)
                            OVER(PARTITION BY A.ARTICLE_NO,
                                 a.article_id,
                                 A.CUST_NO,
                                 A.DELIVER_OBJ,
                                 A.PACKING_QTY,
                                 A.S_CELL_NO,
                                 A.D_CELL_NO,
                                 A.Label_NO)) SUM_CELL_QTY
                      FROM odata_outstock_d A
                      left JOIN bdef_article_packing BAP
                        ON A.ARTICLE_NO = BAP.ARTICLE_NO
                       and a.enterprise_no = bap.enterprise_no
                       AND A.PACKING_QTY = BAP.PACKING_QTY
                     INNER JOIN CDEF_DEFCELL CDC
                        ON CDC.warehouse_no = a.warehouse_no
                       and cdc.enterprise_no = a.enterprise_no
                       AND CDC.CELL_NO = A.S_CELL_NO
                     WHERE A.warehouse_no = strwarehouse_no
                       and a.enterprise_no = strEnterPriseNo
                       AND A.Outstock_No = strOutStockNo
                     ORDER BY A.Label_NO desc,
                              A.S_CELL_NO,
                              A.ARTICLE_NO,
                              A.CUST_NO,
                              A.DELIVER_OBJ,
                              A.PACKING_QTY) loop
      --------------------是否进去循环--------------------
      nIndex := 1;
      ---------------序列号---------------
      nRowID := nRowID + 1;

      strCurrCondition := om_Info.s_cell_no || om_Info.article_no ||
                          om_Info.article_id || om_Info.cust_no ||
                          om_Info.deliver_obj || om_Info.packing_qty ||
                          om_Info.d_Cell_No || om_Info.Label_No;

      if strOldcondition <> strCurrCondition then
        nContainerQTY := ceil(om_Info.Sum_Cell_Qty / om_Info.Packing_Qty);
      else
        nContainerQTY := 0;
      end if;
      strReport_ID     := CONST_REPORTID.B_CustPickSerialLabel_C;
      strContainerType := 'C';
      strWContainerNo  := 'T';

      strOldcondition := strCurrCondition;
      if nContainerQTY > 0 then
        -------------------------------取容器号-----------------------------------
        PKLG_WMS_BASE.p_get_ContainerNoBase(strEnterPriseNo,
                                            strwarehouse_no,
                                            strContainerType,
                                            strUserID,
                                            strWContainerNo,
                                            nContainerQTY,
                                            '1',
                                            NULL,
                                            strLabelNo,
                                            strNContainerNo,
                                            strSessionID,
                                            strOutMsg);
        if instr(strOutMsg, 'N', 1, 1) = 1 then
          return;
        end if;
        ---------------写标签头---------------
        if strWContainerNo = 'T' then
          INSERT INTO stock_label_m
            (enterprise_no,
             warehouse_no,
             BATCH_NO,
             SOURCE_NO,
             REPORT_ID,
             LABEL_NO,
             CONTAINER_NO,
             CONTAINER_TYPE,
             DELIVER_AREA,
             STATUS,
             USE_TYPE,
             OWNER_CELL_NO,
             OWNER_CONTAINER_NO,
             CUST_NO,
             TRUNCK_CELL_NO,
             A_SORTER_CHUTE_NO,
             CHECK_CHUTE_NO,
             DELIVER_OBJ,
             LINE_NO,
             EXP_DATE,
             CURR_AREA,
             RGST_NAME,
             RGST_DATE,
             device_no,
             hm_manual_flag,
             STOCK_TYPE,
             wave_no)
            SELECT a.enterprise_no,
                   A.warehouse_no,
                   A.BATCH_NO,
                   A.OUTSTOCK_NO,
                   strReport_ID,
                   B.Label_No,
                   B.CONTAINER_NO,
                   B.CONTAINER_TYPE,
                   NVL(DELIVER_AREA, 'N'),
                   strStatus,
                   strUserType,
                   A.S_CELL_NO,
                   B.CONTAINER_NO,
                   CUST_NO,
                   A.TRUNCK_CELL_NO,
                   A.A_SORTER_CHUTE_NO,
                   A.CHECK_CHUTE_NO,
                   A.DELIVER_OBJ,
                   A.LINE_NO,
                   A.EXP_DATE,
                   A.ADVANCE_CELL_NO,
                   B.RGST_NAME,
                   SYSDATE,
                   A.device_no,
                   strManualFlag,
                   A.STOCK_TYPE,
                   a.wave_no
              FROM odata_outstock_d A
             INNER JOIN STOCK_NO_LOC B
                ON A.warehouse_no = B.warehouse_no
               and a.enterprise_no = b.enterprise_no
             WHERE A.OUTSTOCK_NO = om_Info.Outstock_No
               AND A.warehouse_no = om_Info.warehouse_no
               AND A.ARTICLE_NO = om_Info.Article_No
               and a.article_id = om_Info.article_id
               AND A.DIVIDE_ID = om_Info.Divide_Id
               AND A.PACKING_QTY = om_Info.Packing_Qty
               AND A.S_CELL_NO = om_Info.s_Cell_No
               AND A.D_CELL_NO = om_Info.d_Cell_No
               AND A.CUST_NO = om_Info.Cust_No
               AND A.DELIVER_OBJ = om_Info.Deliver_Obj
               AND B.RGST_NAME = strUserID
               AND B.SESSION_ID = strSessionID
               AND B.CONTAINER_TYPE = strContainerType
               AND ROWNUM <= nContainerQTY;
        else
          INSERT INTO stock_label_m
            (enterprise_no,
             warehouse_no,
             BATCH_NO,
             SOURCE_NO,
             REPORT_ID,
             LABEL_NO,
             CONTAINER_NO,
             CONTAINER_TYPE,
             DELIVER_AREA,
             STATUS,
             USE_TYPE,
             OWNER_CELL_NO,
             OWNER_CONTAINER_NO,
             CUST_NO,
             TRUNCK_CELL_NO,
             A_SORTER_CHUTE_NO,
             CHECK_CHUTE_NO,
             DELIVER_OBJ,
             LINE_NO,
             EXP_DATE,
             CURR_AREA,
             RGST_NAME,
             RGST_DATE,
             device_no,
             hm_manual_flag,
             STOCK_TYPE,
             wave_no)
            SELECT a.enterprise_no,
                   A.warehouse_no,
                   A.BATCH_NO,
                   A.OUTSTOCK_NO,
                   strReport_ID,
                   strLabelNo,
                   strNContainerNo,
                   strContainerType,
                   NVL(DELIVER_AREA, 'N'),
                   strStatus,
                   strUserType,
                   A.S_CELL_NO,
                   strNContainerNo,
                   CUST_NO,
                   A.TRUNCK_CELL_NO,
                   A.A_SORTER_CHUTE_NO,
                   A.CHECK_CHUTE_NO,
                   A.DELIVER_OBJ,
                   A.LINE_NO,
                   A.EXP_DATE,
                   A.ADVANCE_CELL_NO,
                   strUserID,
                   SYSDATE,
                   A.device_no,
                   strManualFlag,
                   A.STOCK_TYPE,
                   a.wave_no
              FROM odata_outstock_d A
             WHERE A.OUTSTOCK_NO = om_Info.Outstock_No
               AND A.warehouse_no = om_Info.warehouse_no
               AND A.ARTICLE_NO = om_Info.Article_No
               and a.article_id = om_Info.article_id
               AND A.DIVIDE_ID = om_Info.Divide_Id
               AND A.PACKING_QTY = om_Info.Packing_Qty
               AND A.S_CELL_NO = om_Info.s_Cell_No
               AND A.D_CELL_NO = om_Info.d_Cell_No
               AND A.CUST_NO = om_Info.Cust_No
               AND A.DELIVER_OBJ = om_Info.Deliver_Obj
               AND ROWNUM <= nContainerQTY;
        end if;

        ---------------新增失败---------------
        if sql%rowcount <= 0 then
          strOutMsg := 'N|[E22108]';
          return;
        end if;
        if sql%rowcount < nContainerQTY then
          strOutMsg := 'N|[E22108]';
          return;
        end if;
        -----------新增标签日志
        if strWContainerNo = 'T' then
          INSERT INTO STOCK_LABEL_LOG
            (enterprise_no,
             warehouse_no,
             LABEL_NO,
             CONTAINER_NO,
             CONTAINER_TYPE,
             OWNER_CONTAINER_NO,
             STATUS,
             RGST_NAME,
             RGST_DATE,
             OWNER_CELL_NO,
             CURR_AREA)
            SELECT a.enterprise_no,
                   A.warehouse_no,
                   B.LABEL_NO,
                   B.CONTAINER_NO,
                   B.CONTAINER_TYPE,
                   B.Container_No,
                   strStatus,
                   strUserID,
                   sysdate,
                   A.s_Cell_No,
                   A.s_Cell_No
              FROM odata_outstock_d A
             INNER JOIN STOCK_NO_LOC B
                ON a.warehouse_no = b.warehouse_no
               and a.enterprise_no = b.enterprise_no
             INNER JOIN WMS_DEFCONTAINER C
                ON B.CONTAINER_TYPE = C.CONTAINER_TYPE
               AND C.warehouse_no = A.warehouse_no
               and c.enterprise_no = a.enterprise_no
             WHERE A.Outstock_No = strOutStockNo
               AND A.warehouse_no = strwarehouse_no
               and a.enterprise_no = strEnterPriseNo
               AND A.ARTICLE_NO = om_Info.Article_No
               and a.article_id = om_Info.article_id
               AND A.DIVIDE_ID = om_Info.Divide_Id
               AND A.PACKING_QTY = om_Info.Packing_Qty
               AND A.S_CELL_NO = om_Info.s_Cell_No
               AND A.D_CELL_NO = om_Info.d_Cell_No
               AND A.CUST_NO = om_Info.Cust_No
               AND A.DELIVER_OBJ = om_Info.Deliver_Obj
               AND B.RGST_NAME = strUserID
               AND B.SESSION_ID = strSessionID
               AND B.CONTAINER_TYPE = strContainerType
               AND ROWNUM <= nContainerQTY;
        else
          INSERT INTO STOCK_LABEL_LOG
            (enterprise_no,
             warehouse_no,
             LABEL_NO,
             CONTAINER_NO,
             CONTAINER_TYPE,
             OWNER_CONTAINER_NO,
             STATUS,
             RGST_NAME,
             RGST_DATE,
             OWNER_CELL_NO,
             CURR_AREA)
            SELECT enterprise_no,
                   warehouse_no,
                   LABEL_NO,
                   CONTAINER_NO,
                   CONTAINER_TYPE,
                   OWNER_CONTAINER_NO,
                   STATUS,
                   RGST_NAME,
                   RGST_DATE,
                   OWNER_CELL_NO,
                   CURR_AREA
              FROM stock_label_m A
             WHERE A.SOURCE_NO = strOutStockNo
               AND A.warehouse_no = strwarehouse_no
               and a.enterprise_no = strEnterPriseNo
               AND A.Label_No = strLabelNo;
        end if;

        nContainerIndex := 1;
        nRowID          := 1;
        nUnAllotQTY     := 0;
        ---------------取下架明细写标签---------------
        for om_OutStock in (SELECT A.*
                              FROM odata_outstock_d A
                             WHERE A.OUTSTOCK_NO = om_Info.Outstock_No
                               AND A.warehouse_no = om_Info.warehouse_no
                               AND A.ARTICLE_NO = om_Info.Article_No
                               AND A.Label_NO = om_Info.Label_No
                               AND A.PACKING_QTY = om_Info.Packing_Qty
                               AND A.S_CELL_NO = om_Info.s_Cell_No
                               AND A.D_CELL_NO = om_Info.d_Cell_No
                               AND A.CUST_NO = om_Info.Cust_No
                               AND A.DELIVER_OBJ = om_Info.Deliver_Obj
                               AND A.article_id = om_Info.article_id
                               AND A.ENTERPRISE_NO = strEnterPriseNo
                               AND A.OWNER_NO = om_Info.OWNER_NO) loop
          nLabel      := 1;
          nArticleQTY := om_OutStock.Article_Qty; --当前商品数量;
          nAllotQTY   := 0; --当前写入明细的数量;

          ---------------循环写标签明细---------------
          loop
            nLabelDetail := 1;
            if nUnAllotQTY > 0 then
              if nUnAllotQTY > nArticleQTY then
                nAllotQTY := nArticleQTY;
              else
                nAllotQTY := nUnAllotQTY;
              end if;
              nUnAllotQTY := nUnAllotQTY - nAllotQTY;
            else
              if nArticleQTY >= om_OutStock.Packing_Qty and
                 strContainerType = 'C' then
                nAllotQTY   := om_OutStock.Packing_Qty;
                nUnAllotQTY := 0;
              else
                nAllotQTY := nArticleQTY;
                if strContainerType = 'C' then
                  nUnAllotQTY := om_OutStock.Packing_Qty - nAllotQTY;
                else
                  nUnAllotQTY := 0;
                end if;
              end if;
            end if;
            ---------------取新容器号---------------
            if strWContainerNo = 'D' then
              strContainerNo := strNContainerNo;
            else
              SELECT CONTAINER_NO
                into strContainerNo
                from (select CONTAINER_NO
                        FROM STOCK_NO_LOC B
                       WHERE B.warehouse_no = strwarehouse_no
                         and b.enterprise_no = strEnterPriseNo
                         AND B.RGST_NAME = strUserID
                         AND B.SESSION_ID = strSessionID
                         AND B.CONTAINER_TYPE = strContainerType
                       order by B.container_no)
               where rownum = 1;
              if strContainerNo is null then
                strOutMsg := 'N|[E22111]';
                return;
              end if;
            end if;
            -------------写标签明细--------------
            INSERT INTO stock_label_d
              (enterprise_no,
               warehouse_no,
               BATCH_NO,
               OWNER_NO,
               SOURCE_NO,
               CONTAINER_NO,
               CONTAINER_TYPE,
               ARTICLE_NO,
               ARTICLE_ID,
               PACKING_QTY,
               QTY,
               ROW_ID,
               EXP_NO,
               EXP_TYPE,
               EXP_DATE,
               WAVE_NO,
               CUST_NO,
               SUB_CUST_NO,
               LINE_NO,
               STATUS,
               DIVIDE_ID,
               RGST_NAME,
               RGST_DATE,
               DPS_CELL_NO,
               DELIVER_OBJ,
               deliverobj_order,
               ADVANCE_CELL_NO)--Modify BY QZH AT 2016-5-25
            values
              (strEnterPriseNo,
               om_OutStock.warehouse_no,
               om_OutStock.Batch_No,
               om_OutStock.Owner_No,
               om_OutStock.Outstock_No,
               strContainerNo,
               strContainerType,
               om_OutStock.Article_No,
               om_OutStock.Article_Id,
               om_OutStock.Packing_Qty,
               nAllotQTY,
               nRowID,
               om_OutStock.Exp_No,
               om_OutStock.Exp_Type,
               om_OutStock.Exp_Date,
               om_OutStock.wave_no,
               om_OutStock.Cust_No,
               om_OutStock.Sub_Cust_No,
               om_OutStock.Line_No,
               strStatus,
               om_OutStock.Divide_Id,
               strUserID,
               sysdate,
               om_OutStock.Dps_Cell_No,
               om_OutStock.Deliver_Obj,
               om_OutStock.deliverobj_order,
               om_Outstock.s_Cell_No);
            ---------------新增失败---------------
            if sql%rowcount <= 0 then
              strOutMsg := 'N|[E22108]';
              return;
            end if;
            if nUnAllotQTY <= 0 then
              if strContainerType = 'C' then
                nContainerIndex := nContainerIndex + 1;
                -------------当前取号索引 大于 1 则 调用 删除取号临时表 存储过程
                -------------------------删除取号 临时表数据---------------------------
                P_O_DeleteContainerNoLoc(strEnterPriseNo,
                                         strWareHouse_NO,
                                         strContainerType, --标签类型
                                         strContainerNo,
                                         strSessionID, --会话ＩＤ
                                         strUserID, --员工ID
                                         strOutMsg);
                if instr(strOutMsg, 'N', 1, 1) = 1 then
                  return;
                end if;
                nRowID := 1;
              else
                nRowID := nRowID + 1;
              end if;
            else
              nRowID := nRowID + 1;
            end if;
            nArticleQTY := nArticleQTY - nAllotQTY;
            ---------------跳出当前循环------------
            if nArticleQTY <= 0 then
              exit;
            end if;
            if nContainerIndex > nContainerQTY then
              exit;
            end if;
          end loop;
          if (nLabelDetail < 1) then
            strOutMsg := 'N|[E22107]';
            return;
          end if;
        end loop;
        if (nLabel < 1) then
          strOutMsg := 'N|[E22107]';
          return;
        end if;
      end if;
    end loop;
    if (nIndex < 1) then
      strOutMsg := 'N|[E22107]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_WriteLabelSerial_CT;

  /*****************************************************************************************
     功能：写流水标签——C （补货） (可出板标签 和 C 箱标签)
  *****************************************************************************************/
  procedure P_H_WriteLabelSerial_CT(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                    strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                    strOwnerNo      in odata_outstock_m.owner_no%type,
                                    strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                    strOperateType  in odata_outstock_m.operate_type%type,
                                    strPickType     in odata_outstock_m.pick_type%type,
                                    strTaskType     in odata_outstock_m.task_type%type,
                                    strOutstockType in odata_outstock_m.outstock_type%type,
                                    strPrintType    in odata_outstock_m.print_type%type,
                                    strUserID       in stock_label_m.updt_name%type, --员工ID
                                    strOutMsg       out varchar2) --返回值
   is
    nIndex           number(10); --记录数，以做判断;
    strContainerType varchar2(1); --容器类型
    strContainerNo   varchar2(24); --容器号
    strNContainerNo  varchar2(24); --容器号
    strReport_ID     varchar2(20); --报表ＩＤ
    nRowID           number(10); --标签明细序列号
    --strPickType      varchar2(1); --拣货方式
    strUserType varchar2(1); --标签用途(1：客户标签，2：分播标签，3：移库标签)
    strStatus   varchar2(2); --标签状态
    --strDeliverObj    varchar2(15); --配送对象
    strLabelNo   varchar2(24); --标签号
    strSessionID varchar2(100); --会话ＩＤ

    strOldcondition  varchar2(10000); -- 成标签条件
    strCurrCondition varchar2(10000); -- 成标签条件

    strCreateLabelPerCase varchar2(1); --是否按板产生标签 （ 0 否 ，1 是）

    --strConversionOperateP varchar2(500); --是否允许C 、M 转 P ( 0 不允许 ，1 允许)
    strProduceLableTypeC varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)
    --strOmLabelPickFlag    varchar2(500); --出货是否支持标签库存箱型拣货 ( 0 不支持(C-->B) , 1-支持(B-->C))

    --nConversionOperateP varchar2(500); --是否允许C 、M 转 P ( 0 不允许 ，1 允许)
    nProduceLableTypeC varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)
    --nOmLabelPickFlag    varchar2(500); --出货是否支持标签库存箱型拣货 ( 0 不支持(C-->B) , 1-支持(B-->C))

    --nContainer   number(10); --记录数，取号循环;
    nLabel number(10); --记录数，写标签明细循环;
    --nContainerNo number(10); --记录容器总数;

    nContainerIndex number(10); --记录容器索引;

    nUnAllotQTY stock_content.qty%type; --记录差异量;

    nArticleQTY stock_content.qty%type; --当前商品数量;
    nAllotQTY   stock_content.qty%type; --当前写入明细的数量;

    nContainerQTY number(10); --记录取号数量;

    nLabelDetail number(10); --是否进入写标签明细信息循环

    strHaveSupplyDevice varchar2(500); --是否有补货设备，有可能需要按区域来取值，预留 ( 1 提前拣选  0  非提前拣选)
    --strHaveOutstockDevice varchar2(500);--是否有出型拣货设备，如分播线、分拣机等，预留

    strManualFlag   varchar2(1); --库存记录方式（0, 记录在标签上  1，记录在储位上）
    strWContainerNo varchar2(1); --写取号时 是否写入临时表  （  T 写入  D  不写 ）
  begin
    strOutMsg := 'N|[E00025]';

    strReport_ID := CONST_REPORTID.B_HMTask_CD;
    strUserType  := '3';
    strStatus    := '40';
    --strHaveOutstockDevice := '1';
    strContainerType := 'P';

    strOldcondition := 'N';
    strManualFlag   := '1';

    pklg_wms_base.p_GetBasePara(strEnterPriseNo,
                                strwarehouse_no,
                                strOwnerNo,
                                'TaskOmProduceLableTypeC',
                                'O',
                                'O_TASK',
                                strProduceLableTypeC,
                                nProduceLableTypeC,
                                strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      strOutMsg := 'N|[E00570]';
      return;
    end if;

    if strProduceLableTypeC = '1' then
      strManualFlag := '0';
    end if;
    --------------------循环下架明细写标签明细信息--------------------
    for om_Info in (SELECT A.*,
                           CAI.BARCODE,
                           CAI.LOT_NO,
                           CAI.PRODUCE_DATE,
                           CAI.EXPIRE_DATE,
                           CAI.QUALITY,
                           nvl(BAP.SORTER_FLAG, '0') Sorter_Flag,
                           (BAP.QPALETTE * CDA.PAL_OUT_RATE / 100) MIN_PAL_QTY,
                           CDA2.ADVANCER_PICK_FLAG,
                           (SUM(A.ARTICLE_QTY)
                            OVER(PARTITION BY A.ARTICLE_NO,
                                 a.article_id,
                                 A.CUST_NO,
                                 A.DELIVER_OBJ,
                                 A.PACKING_QTY,
                                 A.S_CELL_NO,
                                 A.D_CELL_NO,
                                 CAI.BARCODE,
                                 CAI.LOT_NO,
                                 CAI.PRODUCE_DATE,
                                 CAI.EXPIRE_DATE,
                                 CAI.QUALITY,
                                 A.Label_NO)) SUM_CELL_QTY
                      FROM odata_outstock_d A
                     INNER JOIN STOCK_ARTICLE_INFO CAI
                        ON A.ARTICLE_NO = CAI.ARTICLE_NO
                       AND A.ARTICLE_ID = CAI.ARTICLE_ID
                       and a.enterprise_no = cai.enterprise_no
                      LEFT JOIN bdef_article_packing BAP
                        ON A.ARTICLE_NO = BAP.ARTICLE_NO
                       AND A.PACKING_QTY = BAP.PACKING_QTY
                       and a.enterprise_no = bap.enterprise_no
                      LEFT JOIN CDEF_DEFCELL CDC
                        ON CDC.warehouse_no = a.warehouse_no
                       and cdc.enterprise_no = a.enterprise_no
                       AND CDC.CELL_NO = A.S_CELL_NO
                      LEFT JOIN CDEF_DEFCELL CDC2
                        ON CDC2.warehouse_no = a.warehouse_no
                       and cdc2.enterprise_no = a.enterprise_no
                       AND CDC2.CELL_NO = A.D_CELL_NO
                      LEFT JOIN CDEF_DEFAREA CDA
                        ON CDA.warehouse_no = CDC.warehouse_no
                       and cda.enterprise_no = cdc.enterprise_no
                       AND CDA.WARE_NO = CDC.WARE_NO
                       AND CDA.AREA_NO = CDC.AREA_NO
                      LEFT JOIN CDEF_DEFAREA CDA2
                        ON CDA2.warehouse_no = CDC2.warehouse_no
                       and cda2.enterprise_no = cdc2.enterprise_no
                       AND CDA2.WARE_NO = CDC2.WARE_NO
                       AND CDA2.AREA_NO = CDC2.AREA_NO
                     WHERE A.warehouse_no = strwarehouse_no
                       AND A.Outstock_No = strOutStockNo
                     ORDER BY A.Label_NO desc,
                              A.S_CELL_NO,
                              A.ARTICLE_NO,
                              A.CUST_NO,
                              A.DELIVER_OBJ,
                              A.PACKING_QTY,
                              CAI.BARCODE,
                              CAI.LOT_NO,
                              CAI.PRODUCE_DATE,
                              CAI.EXPIRE_DATE,
                              CAI.QUALITY) loop
      --------------------是否进去循环--------------------
      nIndex := 1;
      ---------------序列号---------------
      nRowID := nRowID + 1;
      ---------------配送对象---------------
      --strDeliverObj := 'N';
      ---------------是否按板产生标签  默认 否---------------
      --strCreateLabelPerCase := '0';

      strCurrCondition := om_Info.s_cell_no || om_Info.article_no ||
                          om_Info.cust_no || om_Info.deliver_obj ||
                          om_Info.packing_qty || om_Info.Barcode ||
                          om_Info.Lot_No || om_Info.Quality ||
                          om_Info.Produce_Date || om_Info.Expire_Date ||
                          om_Info.d_Cell_No || om_Info.Label_No;
      ---------------修正一张单中一个品项从C、M 转 P 后 所有的品项都转 P 了 ---------------
      strCreateLabelPerCase := '0';
      ---------------提前拣选---------------
      strHaveSupplyDevice := om_Info.Advancer_Pick_Flag;
      /*if om_Info.Advancer_Pick_Flag='1' then
       strHaveSupplyDevice := '1';
      end if;
      if strHaveOutstockDevice = '0' then
        strCreateLabelPerCase := '1';
      end if;
      ---------------达一定量 出板型---------------
      if om_Info.Sum_Cell_Qty >= om_Info.Min_Pal_Qty then
        if strConversionOperateP = '1' then
          strCreateLabelPerCase := '1';
        end if;
      end if;
      ---------------不可上分拣 出板型---------------
      if om_Info.Sorter_Flag = '0' then
        if strConversionOperateP = '1' then
          strCreateLabelPerCase := '1';
        end if;
      end if;*/
      ---------------不可上分拣 出板型---------------
      if om_Info.Sorter_Flag = '0' then
        strCreateLabelPerCase := '1';
      end if;
      if strHaveSupplyDevice = '0' then
        strCreateLabelPerCase := '1';
      end if;
      ---------------------是否出板型---------------------------
      if strCreateLabelPerCase = '1' then
        if strOldcondition <> strCurrCondition then
          nContainerQTY := 1;
        else
          nContainerQTY := 0;
        end if;
        --strReport_ID :=CONST_REPORTID.HmPickLabel_P_Detail; 补货标签相同
        strContainerType := 'P';
        strWContainerNo  := 'D';
      else
        if strOldcondition <> strCurrCondition then
          nContainerQTY := ceil(om_Info.Sum_Cell_Qty / om_Info.Packing_Qty);
        else
          nContainerQTY := 0;
        end if;
        --strReport_ID :=CONST_REPORTID.HmPickLabel_P_Detail;
        strContainerType := 'C';
        strWContainerNo  := 'T';
      end if;
      strOldcondition := strCurrCondition;
      if nContainerQTY > 0 then
        -------------------------------取容器号-----------------------------------
        PKLG_WMS_BASE.p_get_ContainerNoBase(strEnterPriseNo,
                                            strwarehouse_no,
                                            strContainerType,
                                            strUserID,
                                            strWContainerNo,
                                            nContainerQTY,
                                            '1',
                                            NULL,
                                            strLabelNo,
                                            strNContainerNo,
                                            strSessionID,
                                            strOutMsg);
        if instr(strOutMsg, 'N', 1, 1) = 1 then
          return;
        end if;
        ---------------写标签头---------------
        if strWContainerNo = 'T' then
          INSERT INTO stock_label_m
            (enterprise_no,
             warehouse_no,
             BATCH_NO,
             SOURCE_NO,
             REPORT_ID,
             LABEL_NO,
             CONTAINER_NO,
             CONTAINER_TYPE,
             DELIVER_AREA,
             STATUS,
             USE_TYPE,
             OWNER_CELL_NO,
             OWNER_CONTAINER_NO,
             CUST_NO,
             TRUNCK_CELL_NO,
             A_SORTER_CHUTE_NO,
             CHECK_CHUTE_NO,
             DELIVER_OBJ,
             LINE_NO,
             EXP_DATE,
             CURR_AREA,
             RGST_NAME,
             RGST_DATE,
             device_no,
             hm_manual_flag,
             STOCK_TYPE,
             wave_no)
            SELECT a.enterprise_no,
                   A.warehouse_no,
                   A.BATCH_NO,
                   A.OUTSTOCK_NO,
                   strReport_ID,
                   B.Label_No,
                   B.CONTAINER_NO,
                   B.CONTAINER_TYPE,
                   NVL(DELIVER_AREA, 'N'),
                   strStatus,
                   strUserType,
                   A.S_CELL_NO,
                   B.CONTAINER_NO,
                   CUST_NO,
                   A.TRUNCK_CELL_NO,
                   A.A_SORTER_CHUTE_NO,
                   A.CHECK_CHUTE_NO,
                   A.DELIVER_OBJ,
                   A.LINE_NO,
                   A.EXP_DATE,
                   A.ADVANCE_CELL_NO,
                   B.RGST_NAME,
                   SYSDATE,
                   A.device_no,
                   strManualFlag,
                   A.STOCK_TYPE,
                   a.wave_no
              FROM odata_outstock_d A
             INNER JOIN STOCK_NO_LOC B
                ON A.warehouse_no = B.warehouse_no
               and a.enterprise_no = b.enterprise_no
             WHERE A.OUTSTOCK_NO = om_Info.Outstock_No
               AND A.warehouse_no = om_Info.warehouse_no
               and a.enterprise_no = om_info.enterprise_no
               AND A.ARTICLE_NO = om_Info.Article_No
               and a.article_id = om_Info.article_id
               AND A.DIVIDE_ID = om_Info.Divide_Id
               AND A.PACKING_QTY = om_Info.Packing_Qty
               AND A.S_CELL_NO = om_Info.s_Cell_No
               AND A.D_CELL_NO = om_Info.d_Cell_No
               AND A.CUST_NO = om_Info.Cust_No
               AND A.DELIVER_OBJ = om_Info.Deliver_Obj
               AND B.RGST_NAME = strUserID
               AND B.SESSION_ID = strSessionID
               AND B.CONTAINER_TYPE = strContainerType
               AND ROWNUM <= nContainerQTY;
        else
          INSERT INTO stock_label_m
            (enterprise_no,
             warehouse_no,
             BATCH_NO,
             SOURCE_NO,
             REPORT_ID,
             LABEL_NO,
             CONTAINER_NO,
             CONTAINER_TYPE,
             DELIVER_AREA,
             STATUS,
             USE_TYPE,
             OWNER_CELL_NO,
             OWNER_CONTAINER_NO,
             CUST_NO,
             TRUNCK_CELL_NO,
             A_SORTER_CHUTE_NO,
             CHECK_CHUTE_NO,
             DELIVER_OBJ,
             LINE_NO,
             EXP_DATE,
             CURR_AREA,
             RGST_NAME,
             RGST_DATE,
             device_no,
             hm_manual_flag,
             STOCK_TYPE,
             wave_no)
            SELECT a.enterprise_no,
                   A.warehouse_no,
                   A.BATCH_NO,
                   A.OUTSTOCK_NO,
                   strReport_ID,
                   strLabelNo,
                   strNContainerNo,
                   strContainerType,
                   NVL(DELIVER_AREA, 'N'),
                   strStatus,
                   strUserType,
                   A.S_CELL_NO,
                   strNContainerNo,
                   CUST_NO,
                   A.TRUNCK_CELL_NO,
                   A.A_SORTER_CHUTE_NO,
                   A.CHECK_CHUTE_NO,
                   A.DELIVER_OBJ,
                   A.LINE_NO,
                   A.EXP_DATE,
                   A.ADVANCE_CELL_NO,
                   strUserID,
                   SYSDATE,
                   A.device_no,
                   strManualFlag,
                   A.STOCK_TYPE,
                   a.wave_no
              FROM odata_outstock_d A
             WHERE A.OUTSTOCK_NO = om_Info.Outstock_No
               AND A.warehouse_no = om_Info.warehouse_no
               and a.enterprise_no = strEnterPriseNo
               AND A.ARTICLE_NO = om_Info.Article_No
               and a.article_id = om_Info.article_id
               AND A.DIVIDE_ID = om_Info.Divide_Id
               AND A.PACKING_QTY = om_Info.Packing_Qty
               AND A.S_CELL_NO = om_Info.s_Cell_No
               AND A.D_CELL_NO = om_Info.d_Cell_No
               AND A.CUST_NO = om_Info.Cust_No
               AND A.DELIVER_OBJ = om_Info.Deliver_Obj
               AND ROWNUM <= nContainerQTY;
        end if;

        ---------------新增失败---------------
        if sql%rowcount <= 0 then
          strOutMsg := 'N|[E00688]';
          return;
        end if;
        if sql%rowcount < nContainerQTY then
          strOutMsg := 'N|[E01034]';
          return;
        end if;
        -----------新增标签日志
        if strWContainerNo = 'T' then
          INSERT INTO STOCK_LABEL_LOG
            (enterprise_no,
             warehouse_no,
             LABEL_NO,
             CONTAINER_NO,
             CONTAINER_TYPE,
             OWNER_CONTAINER_NO,
             STATUS,
             RGST_NAME,
             RGST_DATE,
             OWNER_CELL_NO,
             CURR_AREA)
            SELECT a.enterprise_no,
                   A.warehouse_no,
                   B.LABEL_NO,
                   B.CONTAINER_NO,
                   B.CONTAINER_TYPE,
                   B.Container_No,
                   strStatus,
                   strUserID,
                   sysdate,
                   A.s_Cell_No,
                   A.s_Cell_No
              FROM odata_outstock_d A
             INNER JOIN STOCK_NO_LOC B
                ON a.warehouse_no = b.warehouse_no
               and a.enterprise_no = b.enterprise_no
             INNER JOIN WMS_DEFCONTAINER C
                ON B.CONTAINER_TYPE = C.CONTAINER_TYPE
               AND C.warehouse_no = A.warehouse_no
               and c.enterprise_no = b.enterprise_no
             WHERE A.Outstock_No = strOutStockNo
               AND A.warehouse_no = strwarehouse_no
               and a.enterprise_no = strEnterPriseNo
               AND A.ARTICLE_NO = om_Info.Article_No
               and a.article_id = om_Info.article_id
               AND A.DIVIDE_ID = om_Info.Divide_Id
               AND A.PACKING_QTY = om_Info.Packing_Qty
               AND A.S_CELL_NO = om_Info.s_Cell_No
               AND A.D_CELL_NO = om_Info.d_Cell_No
               AND A.CUST_NO = om_Info.Cust_No
               AND A.DELIVER_OBJ = om_Info.Deliver_Obj
               AND B.RGST_NAME = strUserID
               AND B.SESSION_ID = strSessionID
               AND B.CONTAINER_TYPE = strContainerType
               AND ROWNUM <= nContainerQTY;
        else
          INSERT INTO STOCK_LABEL_LOG
            (enterprise_no,
             warehouse_no,
             LABEL_NO,
             CONTAINER_NO,
             CONTAINER_TYPE,
             OWNER_CONTAINER_NO,
             STATUS,
             RGST_NAME,
             RGST_DATE,
             OWNER_CELL_NO,
             CURR_AREA)
            SELECT enterprise_no,
                   warehouse_no,
                   LABEL_NO,
                   CONTAINER_NO,
                   CONTAINER_TYPE,
                   OWNER_CONTAINER_NO,
                   STATUS,
                   RGST_NAME,
                   RGST_DATE,
                   OWNER_CELL_NO,
                   CURR_AREA
              FROM stock_label_m A
             WHERE A.SOURCE_NO = strOutStockNo
               and a.enterprise_no = strEnterPriseNo
               AND A.warehouse_no = strwarehouse_no
               AND A.Label_No = strLabelNo;
        end if;
        ---------------记录容器总数---------------nContainerNo
        /*SELECT count(B.CONTAINER_NO)
         into nContainerNo
         FROM STOCK_NO_LOC B
        WHERE B.warehouse_no = om_Info.warehouse_no
          AND B.RGST_NAME = strUserID
          AND B.SESSION_ID = strSessionID
          AND B.CONTAINER_TYPE = strContainerType;*/

        nContainerIndex := 1;
        nRowID          := 1;
        nUnAllotQTY     := 0;
        ---------------取下架明细写标签---------------
        for om_OutStock in (SELECT A.*
                              FROM odata_outstock_d   A,
                                   STOCK_ARTICLE_INFO CAI
                             WHERE A.ARTICLE_NO = CAI.ARTICLE_NO
                               AND A.ARTICLE_ID = CAI.ARTICLE_ID
                               and a.enterprise_no = cai.enterprise_no
                               AND A.OUTSTOCK_NO = om_Info.Outstock_No
                               AND A.warehouse_no = om_Info.warehouse_no
                               AND A.ARTICLE_NO = om_Info.Article_No
                               AND A.Label_NO = om_Info.Label_NO
                               AND A.PACKING_QTY = om_Info.Packing_Qty
                               AND A.S_CELL_NO = om_Info.s_Cell_No
                               AND A.D_CELL_NO = om_Info.d_Cell_No
                               AND A.CUST_NO = om_Info.Cust_No
                               AND A.DELIVER_OBJ = om_Info.Deliver_Obj
                               AND CAI.LOT_NO = om_Info.Lot_No
                               AND CAI.QUALITY = om_Info.Quality
                               AND CAI.PRODUCE_DATE = om_Info.Produce_Date
                               AND CAI.EXPIRE_DATE = om_Info.Expire_Date
                               and a.article_id = om_Info.article_id) loop
          nLabel      := 1;
          nArticleQTY := om_OutStock.Article_Qty; --当前商品数量;
          nAllotQTY   := 0; --当前写入明细的数量;

          ---------------循环写标签明细---------------
          loop
            nLabelDetail := 1;
            if nUnAllotQTY > 0 then
              if nUnAllotQTY > nArticleQTY then
                nAllotQTY := nArticleQTY;
              else
                nAllotQTY := nUnAllotQTY;
              end if;
              nUnAllotQTY := nUnAllotQTY - nAllotQTY;
            else
              if nArticleQTY >= om_OutStock.Packing_Qty and
                 strContainerType = 'C' then
                nAllotQTY   := om_OutStock.Packing_Qty;
                nUnAllotQTY := 0;
              else
                nAllotQTY := nArticleQTY;
                if strContainerType = 'C' then
                  nUnAllotQTY := om_OutStock.Packing_Qty - nAllotQTY;
                else
                  nUnAllotQTY := 0;
                end if;
              end if;
            end if;
            ---------------取新容器号---------------
            if strWContainerNo = 'D' then
              strContainerNo := strNContainerNo;
            else
              SELECT CONTAINER_NO
                into strContainerNo
                from (select CONTAINER_NO
                        FROM STOCK_NO_LOC B
                       WHERE B.warehouse_no = strwarehouse_no
                         and b.enterprise_no = strEnterPriseNo
                         AND B.RGST_NAME = strUserID
                         AND B.SESSION_ID = strSessionID
                         AND B.CONTAINER_TYPE = strContainerType
                       order by B.container_no)
               where rownum = 1;
              if strContainerNo is null then
                strOutMsg := 'N|[E00689]';
                return;
              end if;
            end if;
            -------------写标签明细--------------
            INSERT INTO stock_label_d
              (enterprise_no,
               warehouse_no,
               BATCH_NO,
               OWNER_NO,
               SOURCE_NO,
               CONTAINER_NO,
               CONTAINER_TYPE,
               ARTICLE_NO,
               ARTICLE_ID,
               PACKING_QTY,
               QTY,
               ROW_ID,
               EXP_NO,
               EXP_TYPE,
               EXP_DATE,
               WAVE_NO,
               CUST_NO,
               SUB_CUST_NO,
               LINE_NO,
               STATUS,
               DIVIDE_ID,
               RGST_NAME,
               RGST_DATE,
               DPS_CELL_NO,
               DELIVER_OBJ,
               deliverobj_order,
               ADVANCE_CELL_NO)--Modify BY QZH AT 2016-5-25
            values
              (strEnterPriseNo,
               om_OutStock.warehouse_no,
               om_OutStock.Batch_No,
               om_OutStock.Owner_No,
               om_OutStock.Outstock_No,
               strContainerNo,
               strContainerType,
               om_OutStock.Article_No,
               om_OutStock.Article_Id,
               om_OutStock.Packing_Qty,
               nAllotQTY,
               nRowID,
               om_OutStock.Exp_No,
               om_OutStock.Exp_Type,
               om_OutStock.Exp_Date,
               om_OutStock.wave_no,
               om_OutStock.Cust_No,
               om_OutStock.Sub_Cust_No,
               om_OutStock.Line_No,
               strStatus,
               om_OutStock.Divide_Id,
               strUserID,
               sysdate,
               om_OutStock.Dps_Cell_No,
               om_OutStock.Deliver_Obj,
               om_OutStock.deliverobj_order,
               om_OutStock.s_Cell_No);
            ---------------新增失败---------------
            if sql%rowcount <= 0 then
              strOutMsg := 'N|[E00690]';
              return;
            end if;
            if nUnAllotQTY <= 0 then
              if strContainerType = 'C' then
                nContainerIndex := nContainerIndex + 1;
                -------------当前取号索引 大于 1 则 调用 删除取号临时表 存储过程
                -------------------------删除取号 临时表数据---------------------------
                P_O_DeleteContainerNoLoc(strEnterPriseNo,
                                         strWareHouse_NO,
                                         strContainerType, --标签类型
                                         strContainerNo,
                                         strSessionID, --会话ＩＤ
                                         strUserID, --员工ID
                                         strOutMsg);
                if instr(strOutMsg, 'N', 1, 1) = 1 then
                  return;
                end if;
                nRowID := 1;
              else
                nRowID := nRowID + 1;
              end if;
            else
              nRowID := nRowID + 1;
            end if;
            nArticleQTY := nArticleQTY - nAllotQTY;
            ---------------跳出当前循环------------
            if nArticleQTY <= 0 then
              exit;
            end if;
            if nContainerIndex > nContainerQTY then
              exit;
            end if;
          end loop;
          if (nLabelDetail < 1) then
            strOutMsg := 'N|[E00691]';
            return;
          end if;
        end loop;
        if (nLabel < 1) then
          strOutMsg := 'N|[E00692]';
          return;
        end if;
      end if;
    end loop;
    if (nIndex < 1) then
      strOutMsg := 'N|[E00694]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_H_WriteLabelSerial_CT;

  /*****************************************************************************************
     功能：写流水标签——M 型  出货
  *****************************************************************************************/
  procedure P_O_WriteLabelSerial_MT(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                    strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                    strOwnerNo      in odata_outstock_m.owner_no%type,
                                    strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                    strOperateType  in odata_outstock_m.operate_type%type,
                                    strPickType     in odata_outstock_m.pick_type%type,
                                    strTaskType     in odata_outstock_m.task_type%type,
                                    strOutstockType in odata_outstock_m.outstock_type%type,
                                    strUserID       in stock_label_m.updt_name%type, --员工ID
                                    strOutMsg       out varchar2) --返回值
   is
    nIndex           number(10); --记录数，以做判断;
    strContainerType varchar2(1); --容器类型
    strContainerNo   varchar2(24); --容器号
    strNContainerNo  varchar2(24); --容器号
    strReport_ID     varchar2(20); --报表ＩＤ
    nRowID           number(10); --标签明细序列号
    strUserType      varchar2(1); --标签用途(1：客户标签，2：分播标签，3：移库标签)
    strStatus        varchar2(2); --标签状态
    strLabelNo       varchar2(24); --标签号
    strSessionID     varchar2(100); --会话ＩＤ

    strOldcondition  varchar2(10000); -- 成标签条件
    strCurrCondition varchar2(10000); -- 成标签条件

    strCreateLabelPerCase varchar2(1); --是否按板产生标签 （ 0 否 ，1 是）

    strConversionOperateP varchar2(500); --是否允许C 、M 转 P ( 0 不允许 ，1 允许)
    strProduceLableTypeC  varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)
    strOmLabelPickFlag    varchar2(500); --出货是否支持标签库存箱型拣货 ( 0 不支持(C-->B) , 1-支持(B-->C))
    strOmQpaletteOperateP varchar2(500); --出货发单（C、M）成标签达到板出比率是否允许转P：0-不允许，1-允许

    nConversionOperateP varchar2(500); --是否允许C 、M 转 P ( 0 不允许 ，1 允许)
    nProduceLableTypeC  varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)
    nOmLabelPickFlag    varchar2(500); --出货是否支持标签库存箱型拣货 ( 0 不支持(C-->B) , 1-支持(B-->C))
    nOmQpaletteOperateP varchar2(500); --出货发单（C、M）成标签达到板出比率是否允许转P：0-不允许，1-允许

    --nContainer   number(10); --记录数，取号循环;
    nLabel number(10); --记录数，写标签明细循环;
    --nContainerNo number(10); --记录容器总数;

    nContainerIndex number(10); --记录容器索引;

    nUnAllotQTY stock_content.qty%type; --记录差异量;

    nArticleQTY stock_content.qty%type; --当前商品数量;
    nAllotQTY   stock_content.qty%type; --当前写入明细的数量;

    nContainerQTY number(10); --记录取号数量;

    nLabelDetail number(10); --是否进入写明细循环

    strHaveOutstockDevice varchar2(500); --是否有出型拣货设备，如分播线、分拣机等，预留

    --strOldSorterFlag varchar2(500);--记录 不可上分拣 条件
    --strCurrSorterFlag varchar2(500);--记录不可上分拣条件

    strManualFlag   varchar2(1); --库存记录方式（0, 记录在标签上  1，记录在储位上）
    strWContainerNo varchar2(1); --写取号时 是否写入临时表  （  T 写入  D  不写 ）
  begin
    strOutMsg := 'N|[E00025]';

    strReport_ID          := CONST_REPORTID.B_CustPickSerialLabel_C;
    strUserType           := '1';
    strStatus             := '50';
    strHaveOutstockDevice := '1';
    strContainerType      := 'C';
    --strOldSorterFlag :='N';
    -------------------------------取系统参数-----------------------------------

    pklg_wms_base.p_GetBasePara(strEnterPriseNo,
                                strwarehouse_no,
                                strOwnerNo,
                                'TaskOmConversionOperateP',
                                'O',
                                'O_TASK',
                                strConversionOperateP,
                                nConversionOperateP,
                                strOutMsg);

    if instr(strOutMsg, 'N', 1, 1) = 1 then
      strOutMsg := 'N|[E00695]';
    end if;

    pklg_wms_base.p_GetBasePara(strEnterPriseNo,
                                strwarehouse_no,
                                strOwnerNo,
                                'TaskOmProduceLableTypeC',
                                'O',
                                'O_TASK',
                                strProduceLableTypeC,
                                nProduceLableTypeC,
                                strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      strOutMsg := 'N|[E00696]';
    end if;

    pklg_wms_base.p_GetBasePara(strEnterPriseNo,
                                strwarehouse_no,
                                strOwnerNo,
                                'TaskOmLabelPickFlag',
                                'O',
                                'O_TASK',
                                strOmLabelPickFlag,
                                nOmLabelPickFlag,
                                strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      strOutMsg := 'N|[E00697]';
    end if;

    pklg_wms_base.p_GetBasePara(strEnterPriseNo,
                                strwarehouse_no,
                                strOwnerNo,
                                'TaskOmQpaletteOperateP',
                                'O',
                                'O_TASK',
                                strOmQpaletteOperateP,
                                nOmQpaletteOperateP,
                                strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      return;
    end if;

    strManualFlag := '1';
    if strProduceLableTypeC = '1' then
      strManualFlag := '0';
    end if;
    strOldcondition := 'N';
    --------------------循环下架明细写标签明细信息--------------------
    for om_Info in (SELECT A.*,
                           CAI.BARCODE,
                           CAI.LOT_NO,
                           CAI.PRODUCE_DATE,
                           CAI.EXPIRE_DATE,
                           CAI.QUALITY,
                           NVL(BAP.SORTER_FLAG, '0') Sorter_Flag,
                           (BAP.QPALETTE * CDA.PAL_OUT_RATE / 100) MIN_PAL_QTY,
                           (SUM(A.ARTICLE_QTY)
                            OVER(PARTITION BY A.ARTICLE_NO,
                                 a.article_id,
                                 A.CUST_NO,
                                 A.DELIVER_OBJ,
                                 A.PACKING_QTY,
                                 A.S_CELL_NO,
                                 A.D_CELL_NO,
                                 CAI.BARCODE,
                                 CAI.LOT_NO,
                                 CAI.PRODUCE_DATE,
                                 CAI.EXPIRE_DATE,
                                 CAI.QUALITY,
                                 A.Label_NO)) SUM_CELL_QTY
                      FROM odata_outstock_d A
                     INNER JOIN STOCK_ARTICLE_INFO CAI
                        ON A.ARTICLE_NO = CAI.ARTICLE_NO
                       AND A.ARTICLE_ID = CAI.ARTICLE_ID
                       and a.enterprise_no = cai.enterprise_no
                      LEFT JOIN bdef_article_packing BAP
                        ON A.ARTICLE_NO = BAP.ARTICLE_NO
                       AND A.PACKING_QTY = BAP.PACKING_QTY
                       and a.enterprise_no = cai.enterprise_no
                     INNER JOIN CDEF_DEFCELL CDC
                        ON CDC.warehouse_no = a.warehouse_no
                       and cdc.enterprise_no = a.enterprise_no
                       AND CDC.CELL_NO = A.S_CELL_NO
                     INNER JOIN CDEF_DEFAREA CDA
                        ON CDA.warehouse_no = CDC.warehouse_no
                       and cda.enterprise_no = cdc.enterprise_no
                       AND CDA.WARE_NO = CDC.WARE_NO
                       AND CDA.AREA_NO = CDC.AREA_NO
                     WHERE A.warehouse_no = strwarehouse_no
                       and a.enterprise_no = strEnterPriseNo
                       AND A.Outstock_No = strOutStockNo
                     ORDER BY A.Label_NO desc,
                              A.S_CELL_NO,
                              A.ARTICLE_NO,
                              A.CUST_NO,
                              A.DELIVER_OBJ,
                              A.PACKING_QTY,
                              CAI.BARCODE,
                              CAI.LOT_NO,
                              CAI.PRODUCE_DATE,
                              CAI.EXPIRE_DATE,
                              CAI.QUALITY) loop
      --------------------是否进去循环--------------------
      nIndex := 1;
      ---------------序列号---------------
      nRowID := nRowID + 1;
      ---------------配送对象---------------
      --strDeliverObj := 'N';
      ---------------是否按板产生标签  默认 否---------------
      --strCreateLabelPerCase := '0';

      strCurrCondition := om_Info.s_cell_no || om_Info.article_no ||
                          om_Info.cust_no || om_Info.deliver_obj ||
                          om_Info.packing_qty || /*om_Info.Supplier_No ||*/
                          om_Info.Barcode || om_Info.Lot_No ||
                          om_Info.Quality || /*om_Info.Item_Type ||*/
                          om_Info.Produce_Date || om_Info.Expire_Date ||
                          om_Info.d_Cell_No || om_Info.Label_NO;
      ---------------修正一张单中一个品项从C、M 转 P 后 所有的品项都转 P 了 ---------------
      strCreateLabelPerCase := '0';

      if strProduceLableTypeC = '2' then
        --出货方式 0 一箱一标签
        if strHaveOutstockDevice = '0' then
          strCreateLabelPerCase := '1';
        end if;
        ---------------达一定量 出板型---------------
        if om_Info.Sum_Cell_Qty >= om_Info.Min_Pal_Qty then
          if om_Info.Sorter_Flag = '1' then
            if strOmQpaletteOperateP = '1' then
              strCreateLabelPerCase := '1';
            end if;
          end if;
        end if;

        if om_Info.Sorter_Flag = '0' then
          if strConversionOperateP = '1' then
            strCreateLabelPerCase := '1';
          end if;
        end if;
      end if;
      ---------------------是否出板型---------------------------
      if strCreateLabelPerCase = '1' then
        if strOldcondition <> strCurrCondition then
          nContainerQTY := 1;
        else
          nContainerQTY := 0;
        end if;
        strReport_ID     := CONST_REPORTID.B_CustPickLabel_PD2;
        strContainerType := 'P';
        strWContainerNo  := 'D';
      else
        if strOldcondition <> strCurrCondition then
          nContainerQTY := ceil(om_Info.Sum_Cell_Qty / om_Info.Packing_Qty);
        else
          nContainerQTY := 0;
        end if;
        strReport_ID     := CONST_REPORTID.B_CustPickSerialLabel_C;
        strContainerType := 'C';
        strWContainerNo  := 'T';
      end if;
      strOldcondition := strCurrCondition;
      if nContainerQTY > 0 then
        -------------------------------取容器号-----------------------------------
        PKLG_WMS_BASE.p_get_ContainerNoBase(strEnterPriseNo,
                                            strwarehouse_no,
                                            strContainerType,
                                            strUserID,
                                            strWContainerNo,
                                            nContainerQTY,
                                            '1',
                                            NULL,
                                            strLabelNo,
                                            strNContainerNo,
                                            strSessionID,
                                            strOutMsg);
        if instr(strOutMsg, 'N', 1, 1) = 1 then
          return;
        end if;
        ---------------写标签头---------------
        if strWContainerNo = 'T' then
          INSERT INTO stock_label_m
            (enterprise_no,
             warehouse_no,
             BATCH_NO,
             SOURCE_NO,
             REPORT_ID,
             LABEL_NO,
             CONTAINER_NO,
             CONTAINER_TYPE,
             DELIVER_AREA,
             STATUS,
             USE_TYPE,
             OWNER_CELL_NO,
             OWNER_CONTAINER_NO,
             CUST_NO,
             TRUNCK_CELL_NO,
             A_SORTER_CHUTE_NO,
             CHECK_CHUTE_NO,
             DELIVER_OBJ,
             LINE_NO,
             EXP_DATE,
             CURR_AREA,
             RGST_NAME,
             RGST_DATE,
             device_no,
             hm_manual_flag,
             STOCK_TYPE,
             wave_no)
            SELECT a.enteRprise_no,
                   A.warehouse_no,
                   A.BATCH_NO,
                   A.OUTSTOCK_NO,
                   strReport_ID,
                   B.Label_No,
                   B.CONTAINER_NO,
                   B.CONTAINER_TYPE,
                   NVL(DELIVER_AREA, 'N'),
                   strStatus,
                   strUserType,
                   A.S_CELL_NO,
                   B.CONTAINER_NO,
                   CUST_NO,
                   A.TRUNCK_CELL_NO,
                   A.A_SORTER_CHUTE_NO,
                   A.CHECK_CHUTE_NO,
                   A.DELIVER_OBJ,
                   A.LINE_NO,
                   A.EXP_DATE,
                   A.ADVANCE_CELL_NO,
                   B.RGST_NAME,
                   SYSDATE,
                   A.device_no,
                   strManualFlag,
                   A.STOCK_TYPE,
                   a.wave_no
              FROM odata_outstock_d A
             INNER JOIN STOCK_NO_LOC B
                ON A.warehouse_no = B.warehouse_no
               and a.enterprise_no = b.enterprise_no
             WHERE A.OUTSTOCK_NO = om_Info.Outstock_No
               AND A.warehouse_no = om_Info.warehouse_no
               and a.enterprise_no = strEnterPriseNo
               AND A.ARTICLE_NO = om_Info.Article_No
               and a.article_id = om_Info.article_id
               AND A.DIVIDE_ID = om_Info.Divide_Id
               AND A.PACKING_QTY = om_Info.Packing_Qty
               AND A.S_CELL_NO = om_Info.s_Cell_No
               AND A.D_CELL_NO = om_Info.d_Cell_No
               AND A.CUST_NO = om_Info.Cust_No
               AND A.DELIVER_OBJ = om_Info.Deliver_Obj
               AND B.RGST_NAME = strUserID
               AND B.SESSION_ID = strSessionID
               AND B.CONTAINER_TYPE = strContainerType
               AND ROWNUM <= nContainerQTY;
        else
          INSERT INTO stock_label_m
            (enterprise_no,
             warehouse_no,
             BATCH_NO,
             SOURCE_NO,
             REPORT_ID,
             LABEL_NO,
             CONTAINER_NO,
             CONTAINER_TYPE,
             DELIVER_AREA,
             STATUS,
             USE_TYPE,
             OWNER_CELL_NO,
             OWNER_CONTAINER_NO,
             CUST_NO,
             TRUNCK_CELL_NO,
             A_SORTER_CHUTE_NO,
             CHECK_CHUTE_NO,
             DELIVER_OBJ,
             LINE_NO,
             EXP_DATE,
             CURR_AREA,
             RGST_NAME,
             RGST_DATE,
             device_no,
             hm_manual_flag,
             STOCK_TYPE,
             wave_no)
            SELECT a.enterprise_no,
                   A.warehouse_no,
                   A.BATCH_NO,
                   A.OUTSTOCK_NO,
                   strReport_ID,
                   strLabelNo,
                   strNContainerNo,
                   strContainerType,
                   NVL(DELIVER_AREA, 'N'),
                   strStatus,
                   strUserType,
                   A.S_CELL_NO,
                   strNContainerNo,
                   CUST_NO,
                   A.TRUNCK_CELL_NO,
                   A.A_SORTER_CHUTE_NO,
                   A.CHECK_CHUTE_NO,
                   A.DELIVER_OBJ,
                   A.LINE_NO,
                   A.EXP_DATE,
                   A.ADVANCE_CELL_NO,
                   strUserID,
                   SYSDATE,
                   A.device_no,
                   strManualFlag,
                   A.STOCK_TYPE,
                   a.wave_no
              FROM odata_outstock_d A
             WHERE A.OUTSTOCK_NO = om_Info.Outstock_No
               AND A.warehouse_no = om_Info.warehouse_no
               and a.enterprise_no = strEnterPriseNo
               AND A.ARTICLE_NO = om_Info.Article_No
               and a.article_id = om_Info.article_id
               AND A.DIVIDE_ID = om_Info.Divide_Id
               AND A.PACKING_QTY = om_Info.Packing_Qty
               AND A.S_CELL_NO = om_Info.s_Cell_No
               AND A.D_CELL_NO = om_Info.d_Cell_No
               AND A.CUST_NO = om_Info.Cust_No
               AND A.DELIVER_OBJ = om_Info.Deliver_Obj
               AND ROWNUM <= nContainerQTY;
        end if;
        ---------------新增失败---------------
        if sql%rowcount <= 0 then
          strOutMsg := 'N|[E00698]';
          return;
        end if;
        if sql%rowcount < nContainerQTY then
          strOutMsg := 'N|[E01035]';
          return;
        end if;
        -----------新增标签日志
        if strWContainerNo = 'T' then
          INSERT INTO STOCK_LABEL_LOG
            (enterprise_no,
             warehouse_no,
             LABEL_NO,
             CONTAINER_NO,
             CONTAINER_TYPE,
             OWNER_CONTAINER_NO,
             STATUS,
             RGST_NAME,
             RGST_DATE,
             OWNER_CELL_NO,
             CURR_AREA)
            SELECT a.enterprise_no,
                   A.warehouse_no,
                   B.LABEL_NO,
                   B.CONTAINER_NO,
                   B.CONTAINER_TYPE,
                   B.Container_No,
                   strStatus,
                   strUserID,
                   sysdate,
                   A.s_Cell_No,
                   A.s_Cell_No
              FROM odata_outstock_d A
             INNER JOIN STOCK_NO_LOC B
                ON a.warehouse_no = b.warehouse_no
               and a.enterprise_no = b.enterprise_no
             INNER JOIN WMS_DEFCONTAINER C
                ON B.CONTAINER_TYPE = C.CONTAINER_TYPE
               AND C.warehouse_no = A.warehouse_no
               and c.enterprise_no = a.enterprise_no
             WHERE A.Outstock_No = strOutStockNo
               AND A.warehouse_no = strwarehouse_no
               and a.enterprise_no = strEnterPriseNo
               AND A.ARTICLE_NO = om_Info.Article_No
               and a.article_id = om_Info.article_id
               AND A.DIVIDE_ID = om_Info.Divide_Id
               AND A.PACKING_QTY = om_Info.Packing_Qty
               AND A.S_CELL_NO = om_Info.s_Cell_No
               AND A.D_CELL_NO = om_Info.d_Cell_No
               AND A.CUST_NO = om_Info.Cust_No
               AND A.DELIVER_OBJ = om_Info.Deliver_Obj
               AND B.RGST_NAME = strUserID
               AND B.SESSION_ID = strSessionID
               AND B.CONTAINER_TYPE = strContainerType
               AND ROWNUM <= nContainerQTY;
        else
          INSERT INTO STOCK_LABEL_LOG
            (enterprise_no,
             warehouse_no,
             LABEL_NO,
             CONTAINER_NO,
             CONTAINER_TYPE,
             OWNER_CONTAINER_NO,
             STATUS,
             RGST_NAME,
             RGST_DATE,
             OWNER_CELL_NO,
             CURR_AREA)
            SELECT enterprise_no,
                   warehouse_no,
                   LABEL_NO,
                   CONTAINER_NO,
                   CONTAINER_TYPE,
                   OWNER_CONTAINER_NO,
                   STATUS,
                   RGST_NAME,
                   RGST_DATE,
                   OWNER_CELL_NO,
                   CURR_AREA
              FROM stock_label_m A
             WHERE A.SOURCE_NO = strOutStockNo
               AND A.warehouse_no = strwarehouse_no
               and a.enterprise_no = strEnterPriseNo
               AND A.Label_No = strLabelNo;
        end if;
        ---------------记录容器总数---------------nContainerNo
        /*SELECT count(B.CONTAINER_NO)
         into nContainerNo
         FROM STOCK_NO_LOC B
        WHERE B.warehouse_no = om_Info.warehouse_no
          AND B.RGST_NAME = strUserID
          AND B.SESSION_ID = strSessionID
          AND B.CONTAINER_TYPE =strContainerType;*/

        nContainerIndex := 1;
        nRowID          := 1;
        nUnAllotQTY     := 0;
        ---------------取下架明细写标签---------------
        for om_OutStock in (SELECT A.*
                              FROM odata_outstock_d   A,
                                   STOCK_ARTICLE_INFO CAI
                             WHERE A.ARTICLE_NO = CAI.ARTICLE_NO
                               AND A.ARTICLE_ID = CAI.ARTICLE_ID
                               and a.enterprise_no = cai.enterprise_no
                               and a.enterprise_no = strEnterPriseNo
                               AND A.OUTSTOCK_NO = om_Info.Outstock_No
                               AND A.warehouse_no = om_Info.warehouse_no
                               AND A.ARTICLE_NO = om_Info.Article_No
                               AND A.Label_NO = om_Info.Label_NO
                               AND A.PACKING_QTY = om_Info.Packing_Qty
                               AND A.S_CELL_NO = om_Info.s_Cell_No
                               AND A.D_CELL_NO = om_Info.d_Cell_No
                               AND A.CUST_NO = om_Info.Cust_No
                               AND A.DELIVER_OBJ = om_Info.Deliver_Obj
                               AND CAI.LOT_NO = om_Info.Lot_No
                               AND CAI.QUALITY = om_Info.Quality
                               AND CAI.PRODUCE_DATE = om_Info.Produce_Date
                               AND CAI.EXPIRE_DATE = om_Info.Expire_Date
                               AND A.OWNER_NO = om_Info.OWNER_NO
                               and a.article_id = om_Info.article_id) loop
          nLabel      := 1;
          nArticleQTY := om_OutStock.Article_Qty; --当前商品数量;
          nAllotQTY   := 0; --当前写入明细的数量;

          ---------------循环写标签明细---------------
          loop
            nLabelDetail := 1;
            if nUnAllotQTY > 0 then
              if nUnAllotQTY > nArticleQTY then
                nAllotQTY := nArticleQTY;
              else
                nAllotQTY := nUnAllotQTY;
              end if;
              nUnAllotQTY := nUnAllotQTY - nAllotQTY;
            else
              if nArticleQTY >= om_OutStock.Packing_Qty and
                 strContainerType = 'C' then
                nAllotQTY   := om_OutStock.Packing_Qty;
                nUnAllotQTY := 0;
              else
                nAllotQTY := nArticleQTY;
                if strContainerType = 'C' then
                  nUnAllotQTY := om_OutStock.Packing_Qty - nAllotQTY;
                else
                  nUnAllotQTY := 0;
                end if;
              end if;
            end if;
            ---------------取新容器号---------------
            if strWContainerNo = 'D' then
              strContainerNo := strNContainerNo;
            else
              SELECT B.CONTAINER_NO
                into strContainerNo
                FROM STOCK_NO_LOC B
               WHERE B.warehouse_no = strwarehouse_no
                 AND B.RGST_NAME = strUserID
                 AND B.SESSION_ID = strSessionID
                 AND B.CONTAINER_TYPE = strContainerType
                 AND rownum = 1
               order by B.container_no;
              if strContainerNo is null then
                strOutMsg := 'N|[E00699]';
                return;
              end if;
            end if;
            ---------------写标签明细---------------
            INSERT INTO stock_label_d
              (enterprise_no,
               warehouse_no,
               BATCH_NO,
               OWNER_NO,
               SOURCE_NO,
               CONTAINER_NO,
               CONTAINER_TYPE,
               ARTICLE_NO,
               ARTICLE_ID,
               PACKING_QTY,
               QTY,
               ROW_ID,
               EXP_NO,
               EXP_TYPE,
               EXP_DATE,
               WAVE_NO,
               CUST_NO,
               SUB_CUST_NO,
               LINE_NO,
               STATUS,
               DIVIDE_ID,
               RGST_NAME,
               RGST_DATE,
               DPS_CELL_NO,
               DELIVER_OBJ,
               deliverobj_order,
               ADVANCE_CELL_NO)--Modify BY QZH AT 2016-5-25
            values
              (strEnterPriseNo,
               om_OutStock.warehouse_no,
               om_OutStock.Batch_No,
               om_OutStock.Owner_No,
               om_OutStock.Outstock_No,
               strContainerNo,
               strContainerType,
               om_OutStock.Article_No,
               om_OutStock.Article_Id,
               om_OutStock.Packing_Qty,
               nAllotQTY,
               nRowID,
               om_OutStock.Exp_No,
               om_OutStock.Exp_Type,
               om_OutStock.Exp_Date,
               om_OutStock.wave_no,
               om_OutStock.Cust_No,
               om_OutStock.Sub_Cust_No,
               om_OutStock.Line_No,
               strStatus,
               om_OutStock.Divide_Id,
               strUserID,
               sysdate,
               om_OutStock.Dps_Cell_No,
               om_OutStock.Deliver_Obj,
               om_OutStock.deliverobj_order,
               om_OutStock.s_Cell_No);
            ---------------新增失败---------------
            if sql%rowcount <= 0 then
              strOutMsg := 'N|[E00700]';
              return;
            end if;
            if nUnAllotQTY <= 0 then
              if strContainerType = 'C' then
                nContainerIndex := nContainerIndex + 1;
                -------------当前取号索引 大于 1 则 调用 删除取号临时表 存储过程
                -------------------------删除取号 临时表数据---------------------------
                P_O_DeleteContainerNoLoc(strEnterPriseNo,
                                         strWareHouse_no,
                                         strContainerType, --标签类型
                                         strContainerNo,
                                         strSessionID, --会话ＩＤ
                                         strUserID, --员工ID
                                         strOutMsg);
                if instr(strOutMsg, 'N', 1, 1) = 1 then
                  return;
                end if;
                nRowID := 1;
              else
                nRowID := nRowID + 1;
              end if;
            else
              nRowID := nRowID + 1;
            end if;
            nArticleQTY := nArticleQTY - nAllotQTY;
            ---------------跳出当前循环------------
            if nArticleQTY <= 0 then
              exit;
            end if;
            if nContainerIndex > nContainerQTY then
              exit;
            end if;
          end loop;
          if (nLabelDetail < 1) then
            strOutMsg := 'N|[E00701]';
            return;
          end if;
        end loop;
        if (nLabel < 1) then
          strOutMsg := 'N|[E00702]';
          return;
        end if;
      end if;
    end loop;
    if (nIndex < 1) then
      strOutMsg := 'N|[E00703]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_WriteLabelSerial_MT;

  /*****************************************************************************************
     功能：写流水标签——出货   客户别出货 外贸客户别 （361）  --非外贸客户别 出 P 标签（ 调按容器写标签  过程 ）   原装箱产生标签 方式  为 一箱一标签
    Modify By HW AT 2013-04-03
  *****************************************************************************************/
  procedure P_O_WriteLabelSerial_Cust(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                      strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                      strOwnerNo      in odata_outstock_m.owner_no%type,
                                      strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                      strOperateType  in odata_outstock_m.operate_type%type,
                                      strPickType     in odata_outstock_m.pick_type%type,
                                      strTaskType     in odata_outstock_m.task_type%type,
                                      strOutstockType in odata_outstock_m.outstock_type%type,
                                      strUserID       in stock_label_m.updt_name%type, --员工ID
                                      strOutMsg       out varchar2) --返回值
   is
    nIndex           number(10); --记录数，以做判断;
    strContainerType varchar2(1); --容器类型
    strContainerNo   varchar2(24); --容器号
    strNContainerNo  varchar2(24); --容器号
    strReport_ID     varchar2(20); --报表ＩＤ
    nRowID           number(10); --标签明细序列号
    --strPickType      varchar2(1); --拣货方式
    strUserType varchar2(1); --标签用途(1：客户标签，2：分播标签，3：移库标签)
    strStatus   varchar2(2); --标签状态
    --strDeliverObj    varchar2(15); --配送对象
    strLabelNo   varchar2(24); --标签号
    strSessionID varchar2(100); --会话ＩＤ

    strOldcondition  varchar2(10000); -- 成标签条件
    strCurrCondition varchar2(10000); -- 成标签条件

    strCreateLabelPerCase varchar2(1); --是否按板产生标签 （ 0 否 ，1 是）

    strConversionOperateP varchar2(500); --是否允许C 、M 转 P ( 0 不允许 ，1 允许)
    strProduceLableTypeC  varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)
    strOmLabelPickFlag    varchar2(500); --出货是否支持标签库存箱型拣货 ( 0 不支持(C-->B) , 1-支持(B-->C))

    nConversionOperateP varchar2(500); --是否允许C 、M 转 P ( 0 不允许 ，1 允许)
    nProduceLableTypeC  varchar2(500); --原装箱出货时产生标签方式 ( 1 一箱一个标签,2 可按板产生标签)
    nOmLabelPickFlag    varchar2(500); --出货是否支持标签库存箱型拣货 ( 0 不支持(C-->B) , 1-支持(B-->C))

    --nContainer   number(10); --记录数，取号循环;
    nLabel number(10); --记录数，写标签明细循环;
    --nContainerNo number(10); --记录容器总数;

    nContainerIndex number(10); --记录容器索引;

    nUnAllotQTY stock_content.qty%type; --记录差异量;

    nArticleQTY stock_content.qty%type; --当前商品数量;
    nAllotQTY   stock_content.qty%type; --当前写入明细的数量;

    nContainerQTY number(10); --记录取号数量;

    nLabelDetail number(10); --是否进入写明细循环

    strHaveOutstockDevice varchar2(500); --是否有出型拣货设备，如分播线、分拣机等，预留

    strTrunkBoxs varchar2(10); --尾箱 标示   （ 0 非尾箱  1  尾箱）

    strCurrCanLabelNo varchar2(10000); --当前尾箱

    strManualFlag   varchar2(1); --库存记录方式（0, 记录在标签上  1，记录在储位上）
    strWContainerNo varchar2(1); --写取号时 是否写入临时表  （  T 写入  D  不写 ）
  begin
    strOutMsg := 'N|[E00025]';

    strReport_ID          := CONST_REPORTID.B_CustPickLabel_PD2;
    strUserType           := '1';
    strStatus             := '50';
    strHaveOutstockDevice := '1';
    strContainerType      := 'C';

    strCurrCanLabelNo := 'N';
    -------------------------------取系统参数-----------------------------------

    pklg_wms_base.p_GetBasePara(strEnterPriseNo,
                                strwarehouse_no,
                                strOwnerNo,
                                'TaskOmConversionOperateP',
                                'O',
                                'O_TASK',
                                strConversionOperateP,
                                nConversionOperateP,
                                strOutMsg);

    if instr(strOutMsg, 'N', 1, 1) = 1 then
      strOutMsg := 'N|[E00704]';
    end if;

    pklg_wms_base.p_GetBasePara(strEnterPriseNo,
                                strwarehouse_no,
                                strOwnerNo,
                                'TaskOmProduceLableTypeC',
                                'O',
                                'O_TASK',
                                strProduceLableTypeC,
                                nProduceLableTypeC,
                                strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      strOutMsg := 'N|[E00705]';
    end if;

    pklg_wms_base.p_GetBasePara(strEnterPriseNo,
                                strwarehouse_no,
                                strOwnerNo,
                                'TaskOmLabelPickFlag',
                                'O',
                                'O_TASK',
                                strOmLabelPickFlag,
                                nOmLabelPickFlag,
                                strOutMsg);
    if instr(strOutMsg, 'N', 1, 1) = 1 then
      strOutMsg := 'N|[E00706]';
    end if;

    strManualFlag := '1';
    if strProduceLableTypeC = '1' then
      strManualFlag := '0';
    end if;
    strOldcondition := 'N';
    --------------------循环下架明细写标签明细信息--------------------
    for om_Info in (SELECT A.*,
                           CAI.BARCODE,
                           CAI.LOT_NO,
                           CAI.PRODUCE_DATE,
                           CAI.EXPIRE_DATE,
                           CAI.QUALITY,
                           NVL(BAP.SORTER_FLAG, '0') Sorter_Flag,
                           (BAP.QPALETTE * CDA.PAL_OUT_RATE / 100) MIN_PAL_QTY,
                           (SUM(A.ARTICLE_QTY)
                            OVER(PARTITION BY A.ARTICLE_NO,
                                 a.article_id,
                                 A.CUST_NO,
                                 A.DELIVER_OBJ,
                                 A.PACKING_QTY,
                                 A.S_CELL_NO,
                                 A.D_CELL_NO,
                                 CAI.BARCODE,
                                 CAI.LOT_NO,
                                 CAI.PRODUCE_DATE,
                                 CAI.EXPIRE_DATE,
                                 CAI.QUALITY,
                                 A.Label_NO)) SUM_CELL_QTY
                      FROM odata_outstock_d A
                     INNER JOIN STOCK_ARTICLE_INFO CAI
                        ON A.ARTICLE_NO = CAI.ARTICLE_NO
                       AND A.ARTICLE_ID = CAI.ARTICLE_ID
                       and a.enterprise_no = cai.enterprise_no
                      LEFT JOIN bdef_article_packing BAP
                        ON A.ARTICLE_NO = BAP.ARTICLE_NO
                       AND A.PACKING_QTY = BAP.PACKING_QTY
                       and a.enterprise_no = bap.enterprise_no
                     INNER JOIN CDEF_DEFCELL CDC
                        ON CDC.warehouse_no = a.warehouse_no
                       and cdc.enterprise_no = a.enterprise_no
                       AND CDC.CELL_NO = A.S_CELL_NO
                     INNER JOIN CDEF_DEFAREA CDA
                        ON CDA.warehouse_no = CDC.warehouse_no
                       and cda.enterprise_no = cdc.enterprise_no
                       AND CDA.WARE_NO = CDC.WARE_NO
                       AND CDA.AREA_NO = CDC.AREA_NO
                     WHERE A.warehouse_no = strwarehouse_no
                       and a.enterprise_no = strEnterPriseNo
                       AND A.Outstock_No = strOutStockNo
                     ORDER BY A.Label_NO desc,
                              A.S_CELL_NO,
                              A.ARTICLE_NO,
                              A.CUST_NO,
                              A.DELIVER_OBJ,
                              A.PACKING_QTY,
                              CAI.BARCODE,
                              CAI.LOT_NO,
                              CAI.PRODUCE_DATE,
                              CAI.EXPIRE_DATE,
                              CAI.QUALITY) loop
      --------------------是否进去循环--------------------
      nIndex := 1;
      ---------------序列号---------------
      nRowID := nRowID + 1;

      strCurrCondition := om_Info.s_cell_no || om_Info.article_no ||
                          om_Info.cust_no || om_Info.deliver_obj ||
                          om_Info.packing_qty || om_Info.Barcode ||
                          om_Info.Lot_No || om_Info.Quality ||
                          om_Info.Produce_Date || om_Info.Expire_Date ||
                          om_Info.d_Cell_No || om_Info.Label_NO;
      ---------------修正一张单中一个品项从C、M 转 P 后 所有的品项都转 P 了 ---------------
      strCreateLabelPerCase := '0';
      -------------------------尾箱判断--------------------------
      if om_Info.Label_NO = '' or om_Info.Label_NO = 'N' or
         om_Info.Label_NO is null then
        strTrunkBoxs := '0'; --不是尾箱
      else
        strTrunkBoxs := '1'; --尾箱
      end if;
      if strProduceLableTypeC = '2' then
        --原装箱出标签方式 不 是 一箱一标签

        if strHaveOutstockDevice = '0' then
          strCreateLabelPerCase := '1';
        end if;
        ---------------达一定量 出板型---------------
        /*if om_Info.Sum_Cell_Qty >= om_Info.Min_Pal_Qty then
          if strConversionOperateP = '1' then
            strCreateLabelPerCase := '1';
          end if;
        end if;*/
        ---------------不可上分拣 出板型---------------
        if om_Info.Sorter_Flag = '0' then
          if strConversionOperateP = '1' then
            --允许 C 转 P
            if strTrunkBoxs = '0' then
              --非尾箱
              strCreateLabelPerCase := '1';
            end if;
          end if;
        end if;
      end if;
      ---------------不可上分拣 出板型---------------

      ---------------------是否出板型---------------------------
      if strCreateLabelPerCase = '1' then
        if strOldcondition <> strCurrCondition then
          nContainerQTY := 1;
        else
          nContainerQTY := 0;
        end if;
        strReport_ID     := CONST_REPORTID.B_CustPickLabel_PD2;
        strContainerType := 'P';
        strWContainerNo  := 'D';
      else
        if strTrunkBoxs = '1' then
          strReport_ID     := CONST_REPORTID.B_CustPickSerialLabel_C;
          strContainerType := 'B';
          strWContainerNo  := 'D';
        else
          strReport_ID     := CONST_REPORTID.B_CustPickSerialLabel_C;
          strContainerType := 'C';
          strWContainerNo  := 'T';
        end if;

        if om_Info.Label_NO = 'N' and strOldcondition = strCurrCondition then
          nContainerQTY := 0;
        else
          if om_Info.Label_NO <> 'N' then
            if strCurrCanLabelNo <> om_Info.Label_NO then
              strCurrCanLabelNo := om_Info.Label_NO;
              nContainerQTY     := 1;
            else
              nContainerQTY := 0;
            end if;
          else
            nContainerQTY := ceil(om_Info.Sum_Cell_Qty /
                                  om_Info.Packing_Qty);
          end if;
          strOldcondition := strCurrCondition;
        end if;
      end if;
      if nContainerQTY > 0 then
        -------------------------------取容器号-----------------------------------
        PKLG_WMS_BASE.p_get_ContainerNoBase(strEnterPriseNo,
                                            strwarehouse_no,
                                            strContainerType,
                                            strUserID,
                                            strWContainerNo,
                                            nContainerQTY,
                                            '1',
                                            NULL,
                                            strLabelNo,
                                            strNContainerNo,
                                            strSessionID,
                                            strOutMsg);
        if instr(strOutMsg, 'N', 1, 1) = 1 then
          return;
        end if;
        ---------------写标签头---------------
        if strWContainerNo = 'T' then
          INSERT INTO stock_label_m
            (enterprise_no,
             warehouse_no,
             BATCH_NO,
             SOURCE_NO,
             REPORT_ID,
             LABEL_NO,
             CONTAINER_NO,
             CONTAINER_TYPE,
             DELIVER_AREA,
             STATUS,
             USE_TYPE,
             OWNER_CELL_NO,
             OWNER_CONTAINER_NO,
             CUST_NO,
             TRUNCK_CELL_NO,
             A_SORTER_CHUTE_NO,
             CHECK_CHUTE_NO,
             DELIVER_OBJ,
             LINE_NO,
             EXP_DATE,
             CURR_AREA,
             RGST_NAME,
             RGST_DATE,
             device_no,
             hm_manual_flag,
             STOCK_TYPE,
             wave_no)
            SELECT a.enterprise_no,
                   A.warehouse_no,
                   A.BATCH_NO,
                   A.OUTSTOCK_NO,
                   strReport_ID,
                   B.Label_No,
                   B.CONTAINER_NO,
                   B.CONTAINER_TYPE,
                   NVL(DELIVER_AREA, 'N'),
                   strStatus,
                   strUserType,
                   A.S_CELL_NO,
                   B.CONTAINER_NO,
                   CUST_NO,
                   A.TRUNCK_CELL_NO,
                   A.A_SORTER_CHUTE_NO,
                   A.CHECK_CHUTE_NO,
                   A.DELIVER_OBJ,
                   A.LINE_NO,
                   A.EXP_DATE,
                   A.ADVANCE_CELL_NO,
                   B.RGST_NAME,
                   SYSDATE,
                   A.device_no,
                   strManualFlag,
                   A.STOCK_TYPE,
                   a.wave_no
              FROM odata_outstock_d A
             INNER JOIN STOCK_NO_LOC B
                ON A.warehouse_no = B.warehouse_no
               and a.enterprise_no = b.enterprise_no
             WHERE A.OUTSTOCK_NO = om_Info.Outstock_No
               AND A.warehouse_no = om_Info.warehouse_no
               and a.enterprise_no = strEnterPriseNo
               AND A.ARTICLE_NO = om_Info.Article_No
               and a.article_id = om_Info.article_id
               AND A.DIVIDE_ID = om_Info.Divide_Id
               AND A.PACKING_QTY = om_Info.Packing_Qty
               AND A.S_CELL_NO = om_Info.s_Cell_No
               AND A.D_CELL_NO = om_Info.d_Cell_No
               AND A.CUST_NO = om_Info.Cust_No
               AND A.DELIVER_OBJ = om_Info.Deliver_Obj
               AND B.RGST_NAME = strUserID
               AND B.SESSION_ID = strSessionID
               AND B.CONTAINER_TYPE = strContainerType
               AND ROWNUM <= nContainerQTY;
        else
          INSERT INTO stock_label_m
            (enterprise_no,
             warehouse_no,
             BATCH_NO,
             SOURCE_NO,
             REPORT_ID,
             LABEL_NO,
             CONTAINER_NO,
             CONTAINER_TYPE,
             DELIVER_AREA,
             STATUS,
             USE_TYPE,
             OWNER_CELL_NO,
             OWNER_CONTAINER_NO,
             CUST_NO,
             TRUNCK_CELL_NO,
             A_SORTER_CHUTE_NO,
             CHECK_CHUTE_NO,
             DELIVER_OBJ,
             LINE_NO,
             EXP_DATE,
             CURR_AREA,
             RGST_NAME,
             RGST_DATE,
             device_no,
             hm_manual_flag,
             STOCK_TYPE,
             wave_no)
            SELECT a.enterprise_no,
                   A.warehouse_no,
                   A.BATCH_NO,
                   A.OUTSTOCK_NO,
                   strReport_ID,
                   strLabelNo,
                   strNContainerNo,
                   strContainerType,
                   NVL(DELIVER_AREA, 'N'),
                   strStatus,
                   strUserType,
                   A.S_CELL_NO,
                   strNContainerNo,
                   CUST_NO,
                   A.TRUNCK_CELL_NO,
                   A.A_SORTER_CHUTE_NO,
                   A.CHECK_CHUTE_NO,
                   A.DELIVER_OBJ,
                   A.LINE_NO,
                   A.EXP_DATE,
                   A.ADVANCE_CELL_NO,
                   strUserID,
                   SYSDATE,
                   A.device_no,
                   strManualFlag,
                   A.STOCK_TYPE,
                   a.wave_no
              FROM odata_outstock_d A
             WHERE A.OUTSTOCK_NO = om_Info.Outstock_No
               AND A.warehouse_no = om_Info.warehouse_no
               and a.enterprise_no = strEnterPriseNo
               AND A.ARTICLE_NO = om_Info.Article_No
               and a.article_id = om_Info.article_id
               AND A.DIVIDE_ID = om_Info.Divide_Id
               AND A.PACKING_QTY = om_Info.Packing_Qty
               AND A.S_CELL_NO = om_Info.s_Cell_No
               AND A.D_CELL_NO = om_Info.d_Cell_No
               AND A.CUST_NO = om_Info.Cust_No
               AND A.DELIVER_OBJ = om_Info.Deliver_Obj
               AND ROWNUM <= nContainerQTY;
        end if;
        ---------------新增失败---------------
        if sql%rowcount <= 0 then
          strOutMsg := 'N|[E00707]';
          return;
        end if;
        if sql%rowcount < nContainerQTY then
          strOutMsg := 'N|[E01036]';
          return;
        end if;
        -----------新增标签日志
        if strWContainerNo = 'T' then
          INSERT INTO STOCK_LABEL_LOG
            (enterprise_no,
             warehouse_no,
             LABEL_NO,
             CONTAINER_NO,
             CONTAINER_TYPE,
             OWNER_CONTAINER_NO,
             STATUS,
             RGST_NAME,
             RGST_DATE,
             OWNER_CELL_NO,
             CURR_AREA)
            SELECT a.enterprise_no,
                   A.warehouse_no,
                   B.LABEL_NO,
                   B.CONTAINER_NO,
                   B.CONTAINER_TYPE,
                   B.Container_No,
                   strStatus,
                   strUserID,
                   sysdate,
                   A.s_Cell_No,
                   A.s_Cell_No
              FROM odata_outstock_d A
             INNER JOIN STOCK_NO_LOC B
                ON a.warehouse_no = b.warehouse_no
               and a.enterprise_no = b.enterprise_no
             INNER JOIN WMS_DEFCONTAINER C
                ON B.CONTAINER_TYPE = C.CONTAINER_TYPE
               AND C.warehouse_no = A.warehouse_no
               and c.enterprise_no = a.enterprise_no
             WHERE A.Outstock_No = strOutStockNo
               AND A.warehouse_no = strwarehouse_no
               and a.enterprise_no = strEnterPriseNo
               AND A.ARTICLE_NO = om_Info.Article_No
               and a.article_id = om_Info.article_id
               AND A.DIVIDE_ID = om_Info.Divide_Id
               AND A.PACKING_QTY = om_Info.Packing_Qty
               AND A.S_CELL_NO = om_Info.s_Cell_No
               AND A.D_CELL_NO = om_Info.d_Cell_No
               AND A.CUST_NO = om_Info.Cust_No
               AND A.DELIVER_OBJ = om_Info.Deliver_Obj
               AND B.RGST_NAME = strUserID
               AND B.SESSION_ID = strSessionID
               AND B.CONTAINER_TYPE = strContainerType
               AND ROWNUM <= nContainerQTY;
        else
          INSERT INTO STOCK_LABEL_LOG
            (enterprise_no,
             warehouse_no,
             LABEL_NO,
             CONTAINER_NO,
             CONTAINER_TYPE,
             OWNER_CONTAINER_NO,
             STATUS,
             RGST_NAME,
             RGST_DATE,
             OWNER_CELL_NO,
             CURR_AREA)
            SELECT enterprise_no,
                   warehouse_no,
                   LABEL_NO,
                   CONTAINER_NO,
                   CONTAINER_TYPE,
                   OWNER_CONTAINER_NO,
                   STATUS,
                   RGST_NAME,
                   RGST_DATE,
                   OWNER_CELL_NO,
                   CURR_AREA
              FROM stock_label_m A
             WHERE A.SOURCE_NO = strOutStockNo
               AND A.warehouse_no = strwarehouse_no
               and a.enterprise_no = strEnterPriseNo
               AND A.Label_No = strLabelNo;
        end if;
        --------------更新客户别尾箱 标签容器类型---------------
        P_O_UpdateLabelByCust(strEnterPriseNo,
                              om_Info.warehouse_no,
                              om_Info.Outstock_No,
                              strLabelNo,
                              strOutMsg);
        if instr(strOutMsg, 'N', 1, 1) = 1 then
          return;
        end if;
        ---------------记录容器总数---------------nContainerNo
        /*SELECT count(B.CONTAINER_NO)
         into nContainerNo
         FROM STOCK_NO_LOC B
        WHERE B.warehouse_no = om_Info.warehouse_no
          AND B.RGST_NAME = strUserID
          AND B.SESSION_ID = strSessionID
          AND B.CONTAINER_TYPE =strContainerType;*/

        nContainerIndex := 1;
        nRowID          := 1;
        nUnAllotQTY     := 0;
        ---------------取下架明细写标签---------------
        for om_OutStock in (SELECT A.*
                              FROM odata_outstock_d A
                             WHERE A.ARTICLE_NO = (case
                                     when strContainerType = 'B' then
                                      A.ARTICLE_NO
                                     else
                                      om_Info.ARTICLE_NO
                                   end)
                               AND A.ARTICLE_ID = (case
                                     when strContainerType = 'B' then
                                      A.ARTICLE_ID
                                     else
                                      om_Info.ARTICLE_ID
                                   end)
                               AND A.OUTSTOCK_NO = om_Info.Outstock_No
                               AND A.warehouse_no = om_Info.warehouse_no
                               and a.enterprise_no = strEnterPriseNo
                               AND A.Label_NO = om_Info.Label_NO
                               AND A.PACKING_QTY = (case
                                     when strContainerType = 'B' then
                                      A.PACKING_QTY
                                     else
                                      om_Info.Packing_Qty
                                   end)
                               AND A.S_CELL_NO = om_Info.s_Cell_No
                               AND A.D_CELL_NO = om_Info.d_Cell_No
                               AND A.CUST_NO = om_Info.Cust_No
                               AND A.DELIVER_OBJ = om_Info.Deliver_Obj
                               AND A.OWNER_NO = om_Info.OWNER_NO
                               and a.article_id = om_Info.article_id) loop
          nLabel      := 1;
          nArticleQTY := om_OutStock.Article_Qty; --当前商品数量;
          nAllotQTY   := 0; --当前写入明细的数量;

          ---------------循环写标签明细---------------
          loop
            nLabelDetail := 1;
            if nUnAllotQTY > 0 then
              if nUnAllotQTY > nArticleQTY then
                nAllotQTY := nArticleQTY;
              else
                nAllotQTY := nUnAllotQTY;
              end if;
              nUnAllotQTY := nUnAllotQTY - nAllotQTY;
            else
              if nArticleQTY >= om_OutStock.Packing_Qty and
                 strContainerType = 'C' then
                nAllotQTY   := om_OutStock.Packing_Qty;
                nUnAllotQTY := 0;
              else
                nAllotQTY := nArticleQTY;
                if strContainerType = 'C' then
                  nUnAllotQTY := om_OutStock.Packing_Qty - nAllotQTY;
                else
                  nUnAllotQTY := 0;
                end if;
              end if;
            end if;
            ---------------取新容器号---------------
            if strWContainerNo = 'D' then
              strContainerNo := strNContainerNo;
            else
              SELECT B.CONTAINER_NO
                into strContainerNo
                FROM STOCK_NO_LOC B
               WHERE B.warehouse_no = strwarehouse_no
                 and b.enterprise_no = strEnterPriseNo
                 AND B.RGST_NAME = strUserID
                 AND B.SESSION_ID = strSessionID
                 AND B.CONTAINER_TYPE = strContainerType
                 AND rownum = 1
               order by B.container_no;
              if strContainerNo is null then
                strOutMsg := 'N|[E00708]';
                return;
              end if;
            end if;
            ---------------写标签明细---------------
            INSERT INTO stock_label_d
              (enterprise_no,
               warehouse_no,
               BATCH_NO,
               OWNER_NO,
               SOURCE_NO,
               CONTAINER_NO,
               CONTAINER_TYPE,
               ARTICLE_NO,
               ARTICLE_ID,
               PACKING_QTY,
               QTY,
               ROW_ID,
               EXP_NO,
               EXP_TYPE,
               EXP_DATE,
               WAVE_NO,
               CUST_NO,
               SUB_CUST_NO,
               LINE_NO,
               STATUS,
               DIVIDE_ID,
               RGST_NAME,
               RGST_DATE,
               DPS_CELL_NO,
               DELIVER_OBJ,
               deliverobj_order,
               ADVANCE_CELL_NO)--Modify BY QZH AT 2016-5-25
            values
              (strEnterPriseNo,
               om_OutStock.warehouse_no,
               om_OutStock.Batch_No,
               om_OutStock.Owner_No,
               om_OutStock.Outstock_No,
               strContainerNo,
               strContainerType,
               om_OutStock.Article_No,
               om_OutStock.Article_Id,
               om_OutStock.Packing_Qty,
               nAllotQTY,
               nRowID,
               om_OutStock.Exp_No,
               om_OutStock.Exp_Type,
               om_OutStock.Exp_Date,
               om_OutStock.wave_no,
               om_OutStock.Cust_No,
               om_OutStock.Sub_Cust_No,
               om_OutStock.Line_No,
               strStatus,
               om_OutStock.Divide_Id,
               strUserID,
               sysdate,
               om_OutStock.Dps_Cell_No,
               om_OutStock.Deliver_Obj,
               om_OutStock.deliverobj_order,
               om_OutStock.S_Cell_No);
            ---------------新增失败---------------
            if sql%rowcount <= 0 then
              strOutMsg := 'N|[E00710]';
              return;
            end if;
            if nUnAllotQTY <= 0 then
              if strContainerType = 'C' then
                nContainerIndex := nContainerIndex + 1;
                -------------当前取号索引 大于 1 则 调用 删除取号临时表 存储过程
                -------------------------删除取号 临时表数据---------------------------
                P_O_DeleteContainerNoLoc(strEnterPriseNo,
                                         strWareHouse_no,
                                         strContainerType, --标签类型
                                         strContainerNo,
                                         strSessionID, --会话ＩＤ
                                         strUserID, --员工ID
                                         strOutMsg);
                if instr(strOutMsg, 'N', 1, 1) = 1 then
                  return;
                end if;
                nRowID := 1;
              else
                nRowID := nRowID + 1;
              end if;
            else
              nRowID := nRowID + 1;
            end if;
            nArticleQTY := nArticleQTY - nAllotQTY;
            ---------------跳出当前循环------------
            if nArticleQTY <= 0 then
              exit;
            end if;
            if nContainerIndex > nContainerQTY then
              exit;
            end if;
          end loop;
          if (nLabelDetail < 1) then
            strOutMsg := 'N|[E00709]';
            return;
          end if;
        end loop;
        if (nLabel < 1) then
          strOutMsg := 'N|[E00711]';
          return;
        end if;
      end if;
    end loop;
    if (nIndex < 1) then
      strOutMsg := 'N|[E00712]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_WriteLabelSerial_Cust;

  /*****************************************************************************************
     功能：删除取号 临时表 数据
  *****************************************************************************************/
  procedure P_O_DeleteContainerNoLoc(strEnterPriseNo  in stock_label_m.enterprise_no%type,
                                     strWareHouseNo   in stock_label_m.warehouse_no%type,
                                     strContainerType in stock_label_m.container_type%type, --标签类型
                                     strContainerNo   in stock_label_m.container_no%type, --容器类型
                                     strSessionId     in number, --会话ＩＤ
                                     strUserID        in stock_label_m.updt_name%type, --员工ID
                                     strOutMsg        out varchar2) --返回值
   is
  begin
    strOutMsg := 'N|[P_O_DeleteContainerNoLoc]';
    DELETE STOCK_NO_LOC B
     WHERE B.RGST_NAME = strUserID
       AND B.SESSION_ID = strSessionId
       AND B.CONTAINER_TYPE = strContainerType
       and B.Container_No = strContainerNo
       and b.enterprise_no = strEnterPriseNo
       and b.warehouse_no = strWareHouseNo;
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E22111]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_DeleteContainerNoLoc;
  --------------------------------------------------------写流水标签 end-----------------------------------------------------------------

  -----------------------------------------------------------------------------------------------------------出 货  回 单
  /*****************************************************************************************
     功能：更新标签明细数量   下架回单更新下架单头时  拣货被销毁的标签处理
  *****************************************************************************************/
  procedure P_O_UpdateLabelDetail(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                  strwarehouse_no in stock_label_d.warehouse_no%type, --标签类型
                                  strOutStockNo   in stock_label_d.source_no%type, --来源单号
                                  strOutStockType in odata_outstock_m.outstock_type%type, --下架类型
                                  strUserId       in stock_label_d.updt_name%type, --操作人员
                                  strStatus       in stock_label_d.status%type, --状态
                                  strOutMsg       out varchar2) --返回值
   is
    nContainerNo          number(10); --数量
    strLabelDetail        varchar2(1); --标签明细是否转历史
    strLabelMaster        varchar2(1); --标签头档是否转历史
    strLabelMaster_Status varchar2(3); --标签头档状态
    --nLabelDetail number(10);-----当前标签未回单的明细记录
  begin
    strOutMsg    := 'N|[P_O_UpdateLabelDetail]';
    nContainerNo := 0;
    --------------------------------循环容器号-----------------------------
    for Label_Info in (SELECT distinct A.Container_No
                         FROM (SELECT b.enterprise_no,
                                      B.warehouse_no,
                                      A.OWNER_NO,
                                      B.SOURCE_NO,
                                      B.LABEL_NO,
                                      B.CONTAINER_NO,
                                      B.CONTAINER_TYPE,
                                      SUM(A.QTY) AS QTY
                                 FROM stock_label_d A
                                INNER JOIN stock_label_m B
                                   ON A.warehouse_no = B.warehouse_no
                                  and a.enterprise_no = b.enterprise_no
                                  AND A.SOURCE_NO = B.SOURCE_NO
                                  AND A.CONTAINER_NO = B.CONTAINER_NO
                                WHERE B.warehouse_no = strwarehouse_no
                                  and b.enterprise_no = strEnterPriseNo
                                  AND B.SOURCE_NO = strOutStockNo
                                  AND A.STATUS = strStatus
                                GROUP BY b.enterprise_no,
                                         B.warehouse_no,
                                         A.OWNER_NO,
                                         B.SOURCE_NO,
                                         B.LABEL_NO,
                                         B.CONTAINER_NO,
                                         B.CONTAINER_TYPE
                                ORDER BY b.enterprise_no,
                                         B.warehouse_no,
                                         A.OWNER_NO,
                                         B.SOURCE_NO,
                                         B.LABEL_NO,
                                         B.CONTAINER_NO,
                                         B.CONTAINER_TYPE) A) loop
      -------------------------更新标签明细信息-------------------------
      update stock_label_d D
         set D.UPDT_NAME = strUserId,
             D.UPDT_DATE = sysdate,
             D.STATUS    = strStatus
       where EXISTS (SELECT 'X'
                FROM stock_label_m M
               WHERE M.CONTAINER_NO = D.CONTAINER_NO
                 AND M.warehouse_no = D.warehouse_no
                 and m.enterprise_no = d.enterprise_no
                 and m.enterprise_no = strEnterPriseNo
                 AND M.CONTAINER_TYPE = D.CONTAINER_TYPE
                 AND M.warehouse_no = strwarehouse_no
                 AND M.CONTAINER_NO = Label_Info.Container_No);
      if sql%rowcount <= 0 then
        strOutMsg := 'N|[E22113]';
        return;
      end if;

      -------------------------删除 标签明细为 0  的数据--------------------------
      DELETE stock_label_d
       WHERE warehouse_no = strwarehouse_no
         and enterprise_no = strEnterPriseNo
         AND CONTAINER_NO = Label_Info.Container_No
         AND STATUS = strStatus
         and QTY = 0;

      if ascii(strStatus) >= ascii('F1') then
        ---------------查询标签明细----------------
        select count(cld.container_no)
          into nContainerNo
          from stock_label_d cld
         inner join stock_label_m clm
            on cld.warehouse_no = clm.warehouse_no
           and cld.container_no = clm.container_no
           and cld.enterprise_no = clm.enterprise_no
         where cld.warehouse_no = strwarehouse_no
           and cld.enterprise_no = strEnterPriseNo
           and cld.container_no = Label_Info.Container_No
           and cld.status not like 'F%';

        strLabelDetail := '0'; --默认
        if nContainerNo > 0 then
          strLabelDetail := '1'; ---存在标签状态不在销毁开始值到标签销毁结束之间的状态
        end if;
        if strLabelDetail = '1' then
          exit;
        end if;
        ---------------查询标签头档----------------
        strLabelMaster_Status := '0';
        strLabelMaster        := '0';
        select clm.status
          into strLabelMaster_Status
          from stock_label_m clm
         where clm.warehouse_no = strwarehouse_no
           and clm.enterprise_no = strEnterPriseNo
           and clm.container_no = Label_Info.Container_No;

        if strLabelMaster_Status is not null then
          if strLabelMaster_Status <> '0' then
            if ascii(strLabelMaster_Status) < ascii('F1') then
              strLabelMaster := '1';
            end if;
          end if;
        end if;
        --有状态不为销毁的 标签头档信息  跳出当前循环
        if strLabelMaster = '1' then
          exit;
        end if;
        -------------标签转历史
        PKOBJ_LABEL.proc_RemoveLabel(strEnterPriseNo,
                                     strwarehouse_no,
                                     Label_Info.Container_No,
                                     strOutMsg);
        if instr(strOutMsg, 'N', 1, 1) = 1 then
          return;
        end if;
      end if;
    end loop;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_UpdateLabelDetail;

  /*****************************************************************************************
     功能：P型 大批量处理 （绑定客户标签【固定板】）
  *****************************************************************************************/
  procedure P_O_UpdateLabelByMass(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                  strwarehouse_no in stock_label_d.warehouse_no%type, --仓别
                                  strOutStockNo   in stock_label_d.source_no%type, --来源单号
                                  strLabelNo      in stock_label_m.label_no%type, --源标签号
                                  strN_LabelNo    in stock_label_m.label_no%type, --目的标签号
                                  strSCellNo      in odata_outstock_d.s_cell_no%type, --来源储位
                                  strDCellNo      in odata_outstock_d.d_cell_no%type, --目的储位
                                  strArticleNo    in stock_label_d.article_no%type, --商品编码
                                  strUserID       in stock_label_d.rgst_name%type, --操作人员
                                  strDivideID     in odata_outstock_d.divide_id%type,
                                  strOutMsg       out varchar2) --返回值
   is
    nLabelNoN            number(24); --固定板标签是否存在
    strBindLabel_N       varchar2(1); --标签未绑定固定板
    strContainerNoS      varchar2(24); --源标签容器号
    strSessionID         varchar2(100); --会话ＩＤ
    strLabelNContainerNo varchar2(24); --固定板容器号
    nOutStockD           varchar2(1); --是否进入下架明细循环

    nLabelDetail number(10); --当前标签是否还有明细 记录数

    strCustNo      varchar2(20); --客户编码
    strDeliverObj  odata_outstock_direct.deliver_obj%type; --配送对象
    strSCustNo     varchar2(20); --来源客户编码
    strSDeliverObj varchar2(15); --来源配送对象
    strTmpLabelNo  stock_label_m.label_no%type;
    nRow_id        stock_label_d.row_id%type;
  begin
    strOutMsg            := 'N|[P_O_UpdateLabelByMass]';
    nLabelNoN            := 0;
    strBindLabel_N       := '0';
    nOutStockD           := '0';
    nLabelDetail         := 0;
    strLabelNContainerNo := 'N';
    ------------------------------------------检查 该标签是否已绑定 或 该固定板是否可用
    --检查固定板是否可用
    select count(clm.label_no)
      into nLabelNoN
      from stock_label_m clm
     where clm.warehouse_no = strwarehouse_no
       and clm.enterprise_no = strEnterPriseNo
       and clm.label_no = strN_LabelNo
       and use_type <> '1';

    if nLabelNoN > 0 then
      strOutMsg := 'N|[E22114]|' || strN_LabelNo;
      return;
    end if;

    select count(clm.label_no)
      into nLabelNoN
      from stock_label_m clm
     where clm.warehouse_no = strwarehouse_no
       and clm.enterprise_no = strEnterPriseNo
       and clm.label_no = strN_LabelNo
       and use_type = '1';

    -------查询源标签容器
    select clm.container_no, clm.cust_no, clm.deliver_obj
      into strContainerNoS, strSCustNo, strSDeliverObj
      from stock_label_m clm
     where clm.warehouse_no = strwarehouse_no
       and clm.enterprise_no = strEnterPriseNo
       and clm.source_no = strOutStockNo
       and clm.label_no = strLabelNo;

    --固定号存在，判断是否可用
    if nLabelNoN > 0 then
      begin
        --取新标签的容器号，配送对象和客户编号
        select clm.container_no, clm.cust_no, clm.deliver_obj
          into strLabelNContainerNo, strCustNo, strDeliverObj
          from stock_label_m clm
         where clm.warehouse_no = strwarehouse_no
           and clm.enterprise_no = strEnterPriseNo
           AND clm.label_no = strN_LabelNo
           and clm.status = '61';
        if strLabelNContainerNo = 'N' or strSCustNo <> strCustNo or
           strSDeliverObj <> strDeliverObj then
          strOutMsg := 'N|[E22114]|' || strN_LabelNo;
          return;
        end if;
      exception
        when no_data_found then
          strOutMsg := 'N|[E22114]|' || strN_LabelNo;
          return;
      end;
    else
      --固定号不存在，新取号
      strBindLabel_N := '1';
    end if;

    ------------------------------------------未绑定固定板  新增标签头
    if strBindLabel_N = '1' then
      -----------新取标签容器号
      PKLG_WMS_BASE.p_get_ContainerNoBase(strEnterPriseNo,
                                          strwarehouse_no,
                                          'P',
                                          strUserID,
                                          'D',
                                          1,
                                          '1',
                                          NULL,
                                          strTmpLabelNo,
                                          strLabelNContainerNo,
                                          strSessionID,
                                          strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        return;
      end if;
      -----------新增标签头档
      insert into stock_label_m
        (enterprise_no,
         warehouse_no,
         REPORT_ID,
         BATCH_NO,
         SOURCE_NO,
         LABEL_NO,
         CONTAINER_NO,
         CONTAINER_TYPE,
         DELIVER_AREA,
         EXP_DATE,
         STATUS,
         LOAD_CONTAINER_NO,
         OWNER_CONTAINER_NO,
         OWNER_CELL_NO,
         CUST_NO,
         TRUNCK_CELL_NO,
         A_SORTER_CHUTE_NO,
         CHECK_CHUTE_NO,
         RGST_NAME,
         RGST_DATE,
         UPDT_NAME,
         STOCK_TYPE,
         mid_label_no,
         UPDT_DATE,
         DELIVER_OBJ,
         USE_TYPE,
         LINE_NO,
         device_no,
         CURR_AREA,
         SEQ_VALUE,
         wave_no)
        select clm.enterprise_no,
               clm.warehouse_no,
               clm.REPORT_ID,
               clm.BATCH_NO,
               clm.SOURCE_NO,
               strN_LabelNo,
               strLabelNContainerNo,
               clm.container_type,
               clm.deliver_area,
               clm.exp_date,
               '61',
               clm.LOAD_CONTAINER_NO,
               strLabelNContainerNo,
               clm.OWNER_CELL_NO,
               clm.CUST_NO,
               clm.TRUNCK_CELL_NO,
               clm.A_SORTER_CHUTE_NO,
               clm.CHECK_CHUTE_NO,
               strUserID,
               clm.RGST_DATE,
               clm.updt_name,
               clm.STOCK_TYPE,
               clm.mid_label_no,
               sysdate,
               clm.DELIVER_OBJ,
               clm.USE_TYPE,
               clm.LINE_NO,
               clm.device_no,
               clm.CURR_AREA,
               clm.SEQ_VALUE,
               clm.wave_no
          from stock_label_m clm
         where clm.warehouse_no = strwarehouse_no
           and clm.enterprise_no = strEnterPriseNo
           AND clm.label_no = strLabelNo;
      if sql%rowcount <= 0 then
        strOutMsg := 'N|[E22108]';
        return;
      end if;

      -----------新增标签日志
      INSERT INTO STOCK_LABEL_LOG
        (enterprise_no,
         warehouse_no,
         LABEL_NO,
         CONTAINER_NO,
         CONTAINER_TYPE,
         OWNER_CONTAINER_NO,
         STATUS,
         RGST_NAME,
         RGST_DATE,
         OWNER_CELL_NO,
         CURR_AREA)
        SELECT enterprise_no,
               warehouse_no,
               LABEL_NO,
               CONTAINER_NO,
               CONTAINER_TYPE,
               OWNER_CONTAINER_NO,
               STATUS,
               RGST_NAME,
               RGST_DATE,
               OWNER_CELL_NO,
               CURR_AREA
          FROM stock_label_m A
         WHERE A.SOURCE_NO = strOutStockNo
           and a.enterprise_no = strEnterPriseNo
           AND A.warehouse_no = strwarehouse_no
           AND A.label_no = strN_LabelNo;
      if sql%rowcount <= 0 then
        strOutMsg := 'N|[E22115]';
        return;
      end if;
    end if;

    -------------------------------------------查询固定板信息
    select clm.container_no, clm.cust_no, clm.deliver_obj
      into strLabelNContainerNo, strCustNo, strDeliverObj
      from stock_label_m clm
     where clm.warehouse_no = strwarehouse_no
       AND clm.label_no = strN_LabelNo
       and rownum <= 1;

    ------------循环下架明细 更新标签明细
    for odata_outstock_d_Info in (SELECT *
                                    FROM odata_outstock_d A
                                   WHERE A.warehouse_no = strwarehouse_no
                                     AND A.OUTSTOCK_NO = strOutStockNo
                                     and a.enterprise_no = strEnterPriseNo
                                     AND A.S_CELL_NO = strSCellNo
                                     AND A.D_CELL_NO = strDCellNo
                                     AND A.CUST_NO = strCustNo
                                     AND A.DELIVER_OBJ = strDeliverObj
                                     AND A.Divide_Id = strDivideID
                                     AND A.ARTICLE_NO = strArticleNo) loop
      nOutStockD := '1';

      select nvl(max(cld.row_id), 0) + 1
        into nRow_id
        from stock_label_d cld
       where cld.warehouse_no = strwarehouse_no
         and cld.enterprise_no = strEnterPriseNo
         and cld.container_no = strLabelNContainerNo;

      ----更新标签明细
      update stock_label_d cld
         set cld.Container_No = strLabelNContainerNo,
             cld.status       = '61',
             cld.UPDT_NAME    = strUserID,
             cld.UPDT_DATE    = sysdate,
             cld.row_id       = nRow_id
       where cld.warehouse_no = strwarehouse_no
         and cld.enterprise_no = strEnterPriseNo
         and cld.source_no = strOutStockNo
         and cld.divide_id = odata_outstock_d_Info.Divide_Id;
      if sql%rowcount <= 0 then
        strOutMsg := 'N|[E22113]';
        return;
      end if;
    end loop;
    -------------------------------------------检查当前绑定的标签是否还存在明细数据
    select count(cld.container_no)
      into nLabelDetail
      from stock_label_d cld
     where cld.warehouse_no = strwarehouse_no
       and cld.enterprise_no = strEnterPriseNo
       and cld.container_no in
           (select clm.container_no
              from stock_label_m clm
             where clm.warehouse_no = strwarehouse_no
               and clm.enterprise_no = strEnterPriseNo
               and clm.label_no = strLabelNo);
    if nLabelDetail <= 0 then
      ------------不存在明细

      ----更新标签头为整理完成状态
      update stock_label_m clm
         set clm.status        = 'F4',
             clm.owner_cell_no = strDCellNo,
             clm.UPDT_NAME     = strUserID,
             clm.UPDT_DATE     = sysdate
       where clm.warehouse_no = strwarehouse_no
         and clm.enterprise_no = strEnterPriseNo
         and clm.source_no = strOutStockNo
         and clm.label_no = strLabelNo;
      if sql%rowcount <= 0 then
        strOutMsg := 'N|[E22116]';
        return;
      end if;

      -----新增标签日志
      INSERT INTO STOCK_LABEL_LOG
        (enterprise_no,
         warehouse_no,
         LABEL_NO,
         CONTAINER_NO,
         CONTAINER_TYPE,
         OWNER_CONTAINER_NO,
         STATUS,
         RGST_NAME,
         RGST_DATE,
         OWNER_CELL_NO,
         CURR_AREA)
        SELECT enterprise_no,
               warehouse_no,
               LABEL_NO,
               CONTAINER_NO,
               CONTAINER_TYPE,
               OWNER_CONTAINER_NO,
               STATUS,
               RGST_NAME,
               RGST_DATE,
               OWNER_CELL_NO,
               CURR_AREA
          FROM stock_label_m A
         WHERE A.SOURCE_NO = strOutStockNo
           and a.enterprise_no = strEnterPriseNo
           AND A.warehouse_no = strwarehouse_no
           AND A.label_no = strLabelNo;
      if sql%rowcount <= 0 then
        strOutMsg := 'N|[E22115]';
        return;
      end if;
      /*------更新库存标签容器号
      PKOBJ_LABEL.proc_UpdtContent_ContainerNo(strwarehouse_no,strLabelNContainerNo,strN_LabelNo,strContainerNoS,strLabelNo,strUserID,strOutMsg);
      if  instr(strOutMsg,'N',1,1) = 1 then
          return;
      end if;*/
      ------标签转历史
      PKOBJ_LABEL.proc_RemoveLabel(strEnterPriseNo,
                                   strwarehouse_no,
                                   strContainerNoS,
                                   strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        return;
      end if;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_UpdateLabelByMass;

  /*****************************************************************************************
     功能：361更新标签表客户别尾箱标签容器号类型
  *****************************************************************************************/
  procedure P_O_UpdateLabelByCust(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                  strwarehouse_no in stock_label_d.warehouse_no%type, --仓别
                                  strOutStockNo   in stock_label_d.source_no%type, --来源单号
                                  strLabelNo      in stock_label_m.label_no%type, --源标签号
                                  strOutMsg       out varchar2) --返回值
   is
  begin
    strOutMsg := 'N|[E00025]';
    update stock_label_m clm
       set clm.container_type = 'C', clm.report_id = 'C2900CD'
     where clm.source_no = strOutStockNo
       and clm.enterprise_no = strEnterPriseNo
       and clm.label_no = strLabelNo
       and clm.warehouse_no = strwarehouse_no
       and clm.stock_type = '2';
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E01113]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_UpdateLabelByCust;

  /*****************************************************************************************
     功能：下架回单更新标签 ( 按单号、按储位、按商品回单 )
  *****************************************************************************************/
  procedure P_O_UpdateLabelByStockArticle(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                          strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                          strOutStockNo   in stock_label_m.source_no%type, --下架单号
                                          strArticleNo    in stock_label_d.article_no%type, --商品编码
                                          strScellNo      in odata_outstock_d.s_cell_no%type, --来源储位编码
                                          strFlagZero     in varchar2, --是否零回标示
                                          strUserID       in stock_label_m.updt_name%type, --操作人员
                                          strOwnerCellNo  in stock_label_m.owner_cell_no%type, --最后并入储位
                                          strOutMsg       out varchar2) --返回值
   is
    nLabelDetail number(10); --记录标签明细数
  begin
    strOutMsg := 'N|[P_O_UpdateLabelByStockArticle]';

    ------------------------更新标签明细
    UPDATE stock_label_d M
       SET M.UPDT_DATE = SYSDATE,
           M.UPDT_NAME = strUserID,
           M.Status = case
                        when strFlagZero = '0' then
                         CASE (SELECT USE_TYPE
                             FROM stock_label_m A
                            WHERE A.warehouse_no = M.warehouse_no
                              and a.enterprise_no = m.enterprise_no
                              AND A.CONTAINER_NO = M.CONTAINER_NO
                              AND A.CONTAINER_TYPE = M.CONTAINER_TYPE)
                           WHEN '3' then
                            'F1'
                           when '2' then
                            '52'
                           else
                            '52'
                         end
                        else
                         CASE (SELECT USE_TYPE
                             FROM stock_label_m A
                            WHERE A.warehouse_no = M.warehouse_no
                              and a.enterprise_no = m.enterprise_no
                              AND A.CONTAINER_NO = M.CONTAINER_NO
                              AND A.CONTAINER_TYPE = M.CONTAINER_TYPE)
                           WHEN '3' then
                            'F1'
                           when '2' then
                            CASE
                              WHEN EXISTS
                               (SELECT 'X'
                                      FROM stock_label_m A, DEVICE_DIVIDE_M ODE
                                     WHERE A.warehouse_no = M.warehouse_no
                                       and a.enterprise_no = m.enterprise_no
                                       and a.enterprise_no = ode.enterprise_no
                                       AND A.CONTAINER_NO = M.CONTAINER_NO
                                       AND A.CONTAINER_TYPE = M.CONTAINER_TYPE
                                       AND A.warehouse_no = ODE.warehouse_no
                                       AND A.device_no = ODE.DEVICE_NO
                                       AND ODE.DEVICE_TYPE = '01') THEN
                               '52'
                              else
                               'FF'
                            end
                           else
                            'FF'
                         end
                      end,
           M.Qty = (case
                     when strFlagZero = '1' then
                      0
                     else
                      NVL(M.QTY, 0)
                   end)
     where M.warehouse_no = strwarehouse_no
       and m.enterprise_no = strEnterPriseNo
       AND (M.STATUS = '40' or M.STATUS = '50')
       AND M.DIVIDE_ID IN
           (select DIVIDE_ID
              from odata_outstock_d ood
             where ood.warehouse_no = strwarehouse_no
               and ood.enterprise_no = strEnterPriseNo
               AND ood.OUTSTOCK_NO = strOutStockNo
               AND ood.S_CELL_NO = strScellNo
               AND ood.ARTICLE_NO = strArticleNo);

    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E22113]';
      return;
    end if;
    -------------------------检查是否还有未处理的标签明细
    select count(M.Source_No)
      into nLabelDetail
      from stock_label_d M
     where M.SOURCE_NO = strOutStockNo
       AND M.warehouse_no = strwarehouse_no
       and m.enterprise_no = strEnterPriseNo
       AND M.ARTICLE_NO = strArticleNo
       AND (M.STATUS = '40' or M.STATUS = '50');

    if nLabelDetail <= 0 then
      --------明细全部处理完成
      ------更新标签头档
      UPDATE stock_label_m M
         SET M.UPDT_DATE     = SYSDATE,
             m.updt_name     = strUserID,
             M.OWNER_CELL_NO = strOwnerCellNo,
             M.STATUS = CASE
                          WHEN (NOT EXISTS
                                (SELECT 'X'
                                   FROM stock_label_d D
                                  WHERE D.CONTAINER_NO = M.CONTAINER_NO
                                    AND D.warehouse_no = M.warehouse_no
                                    and d.enterpriSe_no = m.enterprise_no
                                    AND D.CONTAINER_TYPE = M.CONTAINER_TYPE
                                    AND (D.STATUS = '40' or D.STATUS = '50')) AND
                                EXISTS
                                (SELECT 'X'
                                   FROM stock_label_d D
                                  WHERE D.CONTAINER_NO = M.CONTAINER_NO
                                    AND D.warehouse_no = M.warehouse_no
                                    and d.enterprise_no = m.enterprise_no
                                    AND D.CONTAINER_TYPE = M.CONTAINER_TYPE
                                    AND D.QTY > 0)) THEN
                           (CASE M.USE_TYPE
                             WHEN '1' then
                              '52'
                             when '2' then
                              '52'
                             when '3' then
                              'F1'
                           end)
                          WHEN (NOT EXISTS
                                (SELECT 'X'
                                   FROM stock_label_d D
                                  WHERE D.CONTAINER_NO = M.CONTAINER_NO
                                    AND D.warehouse_no = M.warehouse_no
                                    and d.enterprise_no = m.enterprise_no
                                    AND D.SOURCE_NO = M.SOURCE_NO
                                    AND D.CONTAINER_TYPE = M.CONTAINER_TYPE
                                    AND (D.STATUS = '40' or D.STATUS = '50')) AND
                                NOT EXISTS
                                (SELECT 'X'
                                   FROM stock_label_d D
                                  WHERE D.CONTAINER_NO = M.CONTAINER_NO
                                    AND D.warehouse_no = M.warehouse_no
                                    and d.enterprise_no = m.enterprise_no
                                    AND D.CONTAINER_TYPE = M.CONTAINER_TYPE
                                    AND D.QTY > 0) AND NOT EXISTS
                                (SELECT 'X'
                                   FROM DEVICE_DIVIDE_M ODE
                                  WHERE ODE.warehouse_no = M.warehouse_no
                                    and ode.enterprise_no = m.enterprise_no
                                    AND M.device_no = ODE.DEVICE_NO
                                    AND ODE.DEVICE_TYPE = '01')) THEN
                           (CASE M.USE_TYPE
                             WHEN '1' then
                              'FF'
                             when '2' then
                              'FF'
                             when '3' then
                              'F1'
                           end)
                          WHEN (NOT EXISTS
                                (SELECT 'X'
                                   FROM stock_label_d D
                                  WHERE D.CONTAINER_NO = M.CONTAINER_NO
                                    AND D.warehouse_no = M.warehouse_no
                                    and d.enterprise_no = m.enterprise_no
                                    AND D.SOURCE_NO = M.SOURCE_NO
                                    AND D.CONTAINER_TYPE = M.CONTAINER_TYPE
                                    AND (D.STATUS = '40' or D.STATUS = '50')) AND
                                NOT EXISTS
                                (SELECT 'X'
                                   FROM stock_label_d D
                                  WHERE D.CONTAINER_NO = M.CONTAINER_NO
                                    AND D.warehouse_no = M.warehouse_no
                                    and d.enterprise_no = m.enterprise_no
                                    AND D.CONTAINER_TYPE = M.CONTAINER_TYPE
                                    AND D.QTY > 0) AND EXISTS
                                (SELECT 'X'
                                   FROM DEVICE_DIVIDE_M ODE
                                  WHERE ODE.warehouse_no = M.warehouse_no
                                    and ode.enterprise_no = m.enterprise_no
                                    AND M.device_no = ODE.DEVICE_NO
                                    AND ODE.DEVICE_TYPE = '01')) THEN
                           (CASE M.USE_TYPE
                             WHEN '1' then
                              'FF'
                             when '2' then
                              '52'
                             when '3' then
                              'F1'
                           end)
                          ELSE
                           M.STATUS
                        END
       WHERE M.warehouse_no = strwarehouse_no
         and m.enterprise_no = strEnterPriseNo
         AND EXISTS (select 'X'
                from stock_label_d D
               where D.warehouse_no = M.warehouse_no
                 and d.enterprise_no = m.enterprise_no
                 AND D.SOURCE_NO = M.SOURCE_NO
                 AND D.CONTAINER_NO = M.CONTAINER_NO
                 AND D.CONTAINER_TYPE = M.CONTAINER_TYPE
                 AND D.ARTICLE_NO = strArticleNo
                 AND D.SOURCE_NO = strOutStockNo);

      if sql%rowcount <= 0 then
        strOutMsg := 'N|[E22116]';
        return;
      end if;

      ------新增标签日志
      INSERT INTO STOCK_LABEL_LOG
        (enterprise_no,
         warehouse_no,
         LABEL_NO,
         CONTAINER_NO,
         CONTAINER_TYPE,
         OWNER_CONTAINER_NO,
         STATUS,
         RGST_NAME,
         RGST_DATE,
         OWNER_CELL_NO,
         CURR_AREA)
        SELECT enterprise_no,
               warehouse_no,
               LABEL_NO,
               CONTAINER_NO,
               CONTAINER_TYPE,
               OWNER_CONTAINER_NO,
               STATUS,
               UPDT_NAME,
               UPDT_DATE,
               OWNER_CELL_NO,
               CURR_AREA
          FROM stock_label_m M
         WHERE warehouse_no = strwarehouse_no
           and enterprise_no = strEnterPriseNo
           AND STATUS NOT IN ('40', '50')
           AND EXISTS (select 'X'
                  from stock_label_d D
                 where D.warehouse_no = M.warehouse_no
                   and d.enterprise_no = m.enterprise_no
                   AND D.SOURCE_NO = M.SOURCE_NO
                   AND D.CONTAINER_NO = M.CONTAINER_NO
                   AND D.CONTAINER_TYPE = M.CONTAINER_TYPE
                   AND D.ARTICLE_NO = strArticleNo
                   AND D.SOURCE_NO = strOutStockNo);
      if sql%rowcount <= 0 then
        strOutMsg := 'N|[E22115]';
        return;
      end if;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_UpdateLabelByStockArticle;

  /*****************************************************************************************
     功能：下架回单更新标签 ( 按下架单号整单回单 )
  *****************************************************************************************/
  procedure P_O_UpdateLabelByStockNo(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                     strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                     strOutStockNo   in stock_label_m.source_no%type, --下架单号
                                     strFlagZero     in varchar2, --是否零回标示
                                     strUserID       in stock_label_m.updt_name%type, --操作人员
                                     strOwnerCellNo  in stock_label_m.owner_cell_no%type, --最后并入储位
                                     strOutMsg       out varchar2) --返回值
   is
    nLabelDetail number(10); --记录标签明细数
  begin
    strOutMsg := 'N|[P_O_UpdateLabelByStockNo]';

    ------------------------更新标签明细
    UPDATE stock_label_d M
       SET M.UPDT_DATE = SYSDATE,
           M.UPDT_NAME = strUserID,
           M.Status = case
                        when strFlagZero = '0' then
                         CASE (SELECT USE_TYPE
                             FROM stock_label_m A
                            WHERE A.warehouse_no = M.warehouse_no
                              and a.enterprise_no = m.enterprise_no
                              AND A.CONTAINER_NO = M.CONTAINER_NO
                              AND A.CONTAINER_TYPE = M.CONTAINER_TYPE)
                           WHEN '3' then
                            'F1'
                           when '2' then
                            '52'
                           else
                            '52'
                         end
                        else
                         CASE (SELECT USE_TYPE
                             FROM stock_label_m A
                            WHERE A.warehouse_no = M.warehouse_no
                              and a.enterprise_no = m.enterprise_no
                              AND A.CONTAINER_NO = M.CONTAINER_NO
                              AND A.CONTAINER_TYPE = M.CONTAINER_TYPE)
                           WHEN '3' then
                            'F1'
                           when '2' then
                            CASE
                              WHEN EXISTS
                               (SELECT 'X'
                                      FROM stock_label_m A, DEVICE_DIVIDE_M ODE
                                     WHERE A.warehouse_no = M.warehouse_no
                                       and a.enterprisE_no = m.enterprise_no
                                       AND A.CONTAINER_NO = M.CONTAINER_NO
                                       AND A.CONTAINER_TYPE = M.CONTAINER_TYPE
                                       AND A.warehouse_no = ODE.warehouse_no
                                       AND A.device_no = ODE.DEVICE_NO
                                       AND ODE.DEVICE_TYPE = '01') THEN
                               '52'
                              else
                               'FF'
                            end
                           else
                            'FF'
                         end
                      end,
           M.Qty = (case
                     when strFlagZero = '1' then
                      0
                     else
                      NVL(M.QTY, 0)
                   end)
     where M.warehouse_no = strwarehouse_no
       and m.enterprise_no = strEnterPriseNo
       AND (M.STATUS = '40' or M.STATUS = '50')
       AND M.DIVIDE_ID IN
           (select DIVIDE_ID
              from odata_outstock_d ood
             where ood.warehouse_no = strwarehouse_no
               and ood.enterprise_no = strEnterPriseNo
               AND ood.OUTSTOCK_NO = strOutStockNo);
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E22113]';
      return;
    end if;
    -------------------------检查是否还有未处理的标签明细
    select count(M.Source_No)
      into nLabelDetail
      from stock_label_d M
     where M.SOURCE_NO = strOutStockNo
       AND M.warehouse_no = strwarehouse_no
       and m.enterprise_no = strEnterPriseNo
       AND (M.STATUS = '40' or M.STATUS = '50');
    if nLabelDetail <= 0 then
      --------明细全部处理完成
      ------更新标签头档
      UPDATE stock_label_m M
         SET M.UPDT_DATE     = SYSDATE,
             M.UPDT_NAME     = strUserID,
             M.OWNER_CELL_NO = strOwnerCellNo,
             M.STATUS = CASE
                          WHEN (NOT EXISTS
                                (SELECT 'X'
                                   FROM stock_label_d D
                                  WHERE D.CONTAINER_NO = M.CONTAINER_NO
                                    AND D.warehouse_no = M.warehouse_no
                                    and d.enterprise_no = m.enterprise_no
                                    AND D.CONTAINER_TYPE = M.CONTAINER_TYPE
                                    AND (D.STATUS = '40' or D.STATUS = '50')) AND
                                EXISTS
                                (SELECT 'X'
                                   FROM stock_label_d D
                                  WHERE D.CONTAINER_NO = M.CONTAINER_NO
                                    AND D.warehouse_no = M.warehouse_no
                                    and d.enterprise_no = m.enterprise_no
                                    AND D.CONTAINER_TYPE = M.CONTAINER_TYPE
                                    AND D.QTY > 0)) THEN
                           (CASE M.USE_TYPE
                             WHEN '1' then
                              '52'
                             when '2' then
                              '52'
                             when '3' then
                              'F1'
                           end)
                          WHEN (NOT EXISTS
                                (SELECT 'X'
                                   FROM stock_label_d D
                                  WHERE D.CONTAINER_NO = M.CONTAINER_NO
                                    AND D.warehouse_no = M.warehouse_no
                                    and d.enterprise_no = m.enterprise_no
                                    AND D.SOURCE_NO = M.SOURCE_NO
                                    AND D.CONTAINER_TYPE = M.CONTAINER_TYPE
                                    AND (D.STATUS = '40' or D.STATUS = '50')) AND
                                NOT EXISTS
                                (SELECT 'X'
                                   FROM stock_label_d D
                                  WHERE D.CONTAINER_NO = M.CONTAINER_NO
                                    AND D.warehouse_no = M.warehouse_no
                                    and d.enterprise_no = m.enterprise_no
                                    AND D.CONTAINER_TYPE = M.CONTAINER_TYPE
                                    AND D.QTY > 0) AND NOT EXISTS
                                (SELECT 'X'
                                   FROM DEVICE_DIVIDE_M ODE
                                  WHERE ODE.warehouse_no = M.warehouse_no
                                    and ode.enterprise_no = m.enterprise_no
                                    AND M.device_no = ODE.DEVICE_NO
                                    AND ODE.DEVICE_TYPE = '01')) THEN
                           (CASE M.USE_TYPE
                             WHEN '1' then
                              'FF'
                             when '2' then
                              'FF'
                             when '3' then
                              'F1'
                           end)
                          WHEN (NOT EXISTS
                                (SELECT 'X'
                                   FROM stock_label_d D
                                  WHERE D.CONTAINER_NO = M.CONTAINER_NO
                                    AND D.warehouse_no = M.warehouse_no
                                    and d.enterprise_no = m.enterprise_no
                                    AND D.SOURCE_NO = M.SOURCE_NO
                                    AND D.CONTAINER_TYPE = M.CONTAINER_TYPE
                                    AND (D.STATUS = '40' or D.STATUS = '50')) AND
                                NOT EXISTS
                                (SELECT 'X'
                                   FROM stock_label_d D
                                  WHERE D.CONTAINER_NO = M.CONTAINER_NO
                                    AND D.warehouse_no = M.warehouse_no
                                    and d.enterprise_no = m.enterprise_no
                                    AND D.CONTAINER_TYPE = M.CONTAINER_TYPE
                                    AND D.QTY > 0) AND EXISTS
                                (SELECT 'X'
                                   FROM DEVICE_DIVIDE_M ODE
                                  WHERE ODE.warehouse_no = M.warehouse_no
                                    and ode.enterprise_no = m.enterprise_no
                                    AND M.device_no = ODE.DEVICE_NO
                                    AND ODE.DEVICE_TYPE = '01')) THEN
                           (CASE M.USE_TYPE
                             WHEN '1' then
                              'FF'
                             when '2' then
                              '52'
                             when '3' then
                              'F1'
                           end)
                          ELSE
                           M.STATUS
                        END
       WHERE M.warehouse_no = strwarehouse_no
         and m.enterprise_no = strEnterPriseNo
         AND EXISTS (select 'X'
                from stock_label_d D
               where D.warehouse_no = M.warehouse_no
                 AND D.SOURCE_NO = M.SOURCE_NO
                 AND D.CONTAINER_NO = M.CONTAINER_NO
                 AND D.CONTAINER_TYPE = M.CONTAINER_TYPE
                 AND D.SOURCE_NO = strOutStockNo);
      if sql%rowcount <= 0 then
        strOutMsg := 'N|[E22116]';
        return;
      end if;

      ------新增标签日志
      INSERT INTO STOCK_LABEL_LOG
        (enterprise_no,
         warehouse_no,
         LABEL_NO,
         CONTAINER_NO,
         CONTAINER_TYPE,
         OWNER_CONTAINER_NO,
         STATUS,
         RGST_NAME,
         RGST_DATE,
         OWNER_CELL_NO,
         CURR_AREA)
        SELECT enterprise_no,
               warehouse_no,
               LABEL_NO,
               CONTAINER_NO,
               CONTAINER_TYPE,
               OWNER_CONTAINER_NO,
               STATUS,
               UPDT_NAME,
               UPDT_DATE,
               OWNER_CELL_NO,
               CURR_AREA
          FROM stock_label_m M
         WHERE warehouse_no = strwarehouse_no
           and enterprise_no = strEnterPriseNo
           AND STATUS NOT IN ('40', '50')
           AND EXISTS (select 'X'
                  from stock_label_d D
                 where D.warehouse_no = M.warehouse_no
                   and d.enterprise_no = m.enterprise_no
                   AND D.SOURCE_NO = M.SOURCE_NO
                   AND D.CONTAINER_NO = M.CONTAINER_NO
                   AND D.CONTAINER_TYPE = M.CONTAINER_TYPE
                   AND D.SOURCE_NO = strOutStockNo);
      if sql%rowcount <= 0 then
        strOutMsg := 'N|[E22115]';
        return;
      end if;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_UpdateLabelByStockNo;

  /*****************************************************************************************
     功能：下架回单更新标签 ( B 品 C 型 拣货回单)
  *****************************************************************************************/
  procedure P_O_UpdateLabelByItemTypeB(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                       strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                       strLabelNo      in stock_label_m.label_no%type, --实体标签号
                                       strUserID       in stock_label_m.updt_name%type, --操作人员
                                       strOutMsg       out varchar2) --返回值
   is
    nLabelDetail number(10); --记录标签明细数
  begin
    strOutMsg    := 'N|[E00025]';
    nLabelDetail := 0;
    ------------------更新标签头
    UPDATE stock_label_m M
       SET M.UPDT_DATE = SYSDATE, M.UPDT_NAME = strUserID, M.STATUS = '52'
     WHERE M.warehouse_no = strwarehouse_no
       and m.enterprise_no = strEnterPriseNo
       AND M.LABEL_NO = strLabelNo;
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E01395]';
      return;
    end if;
    ------------------是否存在该标签号的明细信息
    select count(cld.warehouse_no)
      into nLabelDetail
      from stock_label_d cld, stock_label_m clm
     where cld.container_no = clm.container_no
       and cld.warehouse_no = clm.warehouse_no
       and cld.enterprise_no = clm.enterprise_no
       and clm.enterprise_no = strEnterPriseNo
       and cld.status < '52'
       and clm.warehouse_no = strwarehouse_no
       and clm.label_no = strLabelNo;

    if nLabelDetail <= 0 then
      ----------------新增标签日志
      INSERT INTO STOCK_LABEL_LOG
        (enterprise_no,
         warehouse_no,
         LABEL_NO,
         CONTAINER_NO,
         CONTAINER_TYPE,
         OWNER_CONTAINER_NO,
         STATUS,
         RGST_NAME,
         RGST_DATE,
         OWNER_CELL_NO,
         CURR_AREA)
        SELECT enterprise_no,
               warehouse_no,
               LABEL_NO,
               CONTAINER_NO,
               CONTAINER_TYPE,
               OWNER_CONTAINER_NO,
               STATUS,
               UPDT_NAME,
               UPDT_DATE,
               OWNER_CELL_NO,
               CURR_AREA
          FROM stock_label_m
         WHERE warehouse_no = strwarehouse_no
           and enterprise_no = strEnterPriseNo
           AND LABEL_NO = strLabelNo
           AND STATUS NOT IN ('40', '50');
      if sql%rowcount <= 0 then
        strOutMsg := 'N|[E01396]';
        return;
      end if;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_UpdateLabelByItemTypeB;

  /*****************************************************************************************
     功能：表单回单写出货标签明细
  *****************************************************************************************/
  procedure P_O_WriteCustContainer(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                   strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                   strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                   nDivideId       in odata_outstock_d.divide_id%type,
                                   strUserID       in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg       out varchar2) --返回值
   is
    strPickType      varchar2(1); --拣货方式
    strOperateType   odata_outstock_m.operate_type%type;
    strContainerNo   stock_label_d.container_no%type;
    strContainerType stock_label_d.container_type%type;
    --strDeliverObj    odata_outstock_m.outstock_no%type;--配送对象
    odata_outstock_d_Info odata_outstock_d%rowtype;
  begin
    strOutMsg := 'N|[P_O_WriteCustContainer]';

    ---------------获取拣货方式---------------
    begin
      select oom.pick_type, oom.operate_type
        into strPickType, strOperateType
        from odata_outstock_m oom
       where oom.warehouse_no = warehouse_no
         and oom.enterprise_no = strEnterPriseNo
         and oom.outstock_no = strOutStockNo;
    exception
      when no_data_found then
        return;
    end;

    if strOperateType = 'B' then
      strContainerType := CLabelType.LABEL_TYPE_B;
    else
      strContainerType := CLabelType.LABEL_TYPE_P;
    end if;

    ---------------新增标签明细 ---------------
    for odata_outstock_d_Info in (SELECT A.*
                                    FROM odata_outstock_d A,
                                         odata_outstock_m B
                                   where A.OUTSTOCK_NO = B.OUTSTOCK_NO
                                     and A.warehouse_no = b.warehouse_no
                                     and a.enterprise_no = b.enterprise_no
                                     AND A.Outstock_No = strOutStockNo
                                     and a.divide_id = nDivideId
                                     and a.real_qty > 0) loop
      ---------------配送对象---------------
      if strPickType = 0 then
        --strDeliverObj:= odata_outstock_d_Info.Deliver_Obj;
        strContainerNo := odata_outstock_d_Info.d_Container_No;
      else
        --strDeliverObj:= 'N';
        strContainerNo := odata_outstock_d_Info.d_Container_No;
      end if;

      pkobj_label.proc_Insert_LabelDetail(strEnterPriseNo,
                                          strwarehouse_no,
                                          odata_outstock_d_Info.Batch_No,
                                          odata_outstock_d_Info.Owner_No,
                                          strOutStockNo,
                                          strContainerNo,
                                          strContainerType, --'P',
                                          odata_outstock_d_Info.Article_No,
                                          odata_outstock_d_Info.Article_Id,
                                          odata_outstock_d_Info.Packing_Qty,
                                          odata_outstock_d_Info.real_qty,
                                          odata_outstock_d_Info.Exp_No,
                                          odata_outstock_d_Info.wave_no,
                                          odata_outstock_d_Info.Cust_No,
                                          odata_outstock_d_Info.Sub_Cust_No,
                                          odata_outstock_d_Info.Line_No,
                                          CLABELSTATUS.PICK_END,
                                          odata_outstock_d_Info.Divide_Id,
                                          odata_outstock_d_Info.Exp_Type,
                                          odata_outstock_d_Info.Dps_Cell_No,
                                          strUserID,
                                          odata_outstock_d_Info.Deliver_Obj,
                                          odata_outstock_d_Info.deliverobj_order,
                                          odata_outstock_d_Info.Exp_Date,
                                          odata_outstock_d_Info.s_Cell_No,
                                          '',
                                          strOutMsg);
      if instr(strOutMsg, 'N', 1, 1) = 1 then
        return;
      end if;

    end loop;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_O_WriteCustContainer;
end pkOBJ_label_odata;

/

