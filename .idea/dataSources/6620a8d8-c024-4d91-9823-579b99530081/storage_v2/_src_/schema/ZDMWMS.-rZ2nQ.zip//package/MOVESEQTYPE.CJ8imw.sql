create PACKAGE        MoveSeqType is

        -- 按来源
        Source CONSTANT varchar2(1) := '1';             --按来源

        -- 按目的
        Objective CONSTANT varchar2(1) := '2';           --按目的

        --单一来源+单一目的
        Sourceobjective CONSTANT varchar2(1) := '3';             --单一来源+单一目的

 end MoveSeqType;


/

