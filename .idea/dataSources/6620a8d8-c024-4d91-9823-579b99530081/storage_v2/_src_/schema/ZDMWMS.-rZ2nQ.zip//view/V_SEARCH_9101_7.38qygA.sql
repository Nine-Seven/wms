create view V_SEARCH_9101_7 as
select a.owner_article_no,d.barcode,a.article_name,d.box_no,m.s_import_no,m.warehouse_no,m.enterprise_no,m.owner_no
from stock_box_m m ,stock_box_d d,bdef_defarticle a
where m.warehouse_no = d.warehouse_no
  and m.enterprise_no = d.enterprise_no
  and m.owner_no = d.owner_no
  and m.box_no = d.box_no
  and d.enterprise_no = a.enterprise_no
  and d.article_no =  a.article_no
  and d.owner_no = a.owner_no
  and m.status not in (3,4)


/

