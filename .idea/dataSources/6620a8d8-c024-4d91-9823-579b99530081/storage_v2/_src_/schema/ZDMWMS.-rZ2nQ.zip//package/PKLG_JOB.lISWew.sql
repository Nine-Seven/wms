create package        PKLG_JOB is

  -- Author  : ZHIPING
  -- Created : 2015-07-29 15:41:37
  -- Purpose :

  --出货定位任务
  procedure p_out_locate;

end PKLG_JOB;


/

