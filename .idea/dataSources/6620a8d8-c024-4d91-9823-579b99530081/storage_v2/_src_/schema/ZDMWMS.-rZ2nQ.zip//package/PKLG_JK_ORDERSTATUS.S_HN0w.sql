create package        pklg_jk_orderstatus is

  /****************************************************************************************************
     chensr
     2014.9.16
     功能说明：将回单状态增添到JK_ORDER_STATUS
  ******************************************************************************************************/
  procedure p_UpToJkOrderStatus(
                                strWareHouseNo varchar2, strWaveNo varchar2, strWorkNo varchar2,
                             OUTMSG out varchar2);

      /****************************************************************************************************
     chensr
     2014.9.16
     功能说明：将回单状态增添到JK_ORDER_STATUS（封车）
  ******************************************************************************************************/
  procedure p_UpToJkOrderStatusOfOdeliver(strWareHouseNo varchar2,
                                          strProposeNo varchar2,
                                          strWorkNo varchar2,
                                           OUTMSG out varchar2);
end pklg_jk_orderstatus;


/

