create view V_SEARCH_H102_004 as
select a.enterprise_no,a.warehouse_no,a.exp_date,a.wave_no,a.deliver_obj,a.cust_no,bd.cust_name,bd.cust_alias,a.container_type,
case when a.status='50' then '已发单' else
case  when a.status='61' then '已回单'else
case when  a.status='62' then '已并板' else
case when  a.status='A0' then '待装车' else '已配送' end end end end status  ,a.boxqty from(
select slm.enterprise_no,slm.warehouse_no,slm.exp_date,slm.wave_no,slm.deliver_obj,slm.cust_no,slm.container_type,slm.status,count(slm.label_no) boxqty
from stock_label_m slm where slm.use_type='1' and slm.status not like 'F%'
group by  slm.enterprise_no,slm.warehouse_no,slm.exp_date,slm.wave_no,slm.deliver_obj,slm.container_type,slm.cust_no,slm.status
union all
select slm.enterprise_no,slm.warehouse_no,slm.exp_date,slm.wave_no,slm.deliver_obj,slm.cust_no,slm.container_type,slm.status,count(slm.label_no) boxqty
from stock_label_mhty slm where slm.use_type='1' and slm.status not like 'F%'
group by  slm.enterprise_no,slm.warehouse_no,slm.exp_date,slm.wave_no,slm.deliver_obj,slm.container_type,slm.cust_no,slm.status)a,
bdef_defcust bd
where a.cust_no=bd.cust_no
order by a.enterprise_no,a.warehouse_no,a.exp_date,a.wave_no,a.cust_no,a.container_type

/

