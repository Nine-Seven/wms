create trigger TRG_ODATA_DIVIDE_M_SERIAL
    before insert
    on ODATA_DIVIDE_M
    for each row
declare
  i_report_up_SERIAL NUMBER;
begin
  select SEQ_ODATA_DIVIDE_M.NEXTVAL into i_report_up_SERIAL from dual;
  :NEW.REPORT_UP_SERIAL := i_report_up_SERIAL;
end TRG_ODATA_DIVIDE_M_SERIAL;


/

