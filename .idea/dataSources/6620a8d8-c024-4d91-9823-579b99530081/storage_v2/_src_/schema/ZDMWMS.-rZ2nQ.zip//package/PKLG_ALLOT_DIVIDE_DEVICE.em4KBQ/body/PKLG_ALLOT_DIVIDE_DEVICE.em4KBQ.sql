create PACKAGE BODY PKLG_ALLOT_DIVIDE_DEVICE IS
  -- Author  : Lizhiping
  -- Created : 2015-07-20 20:00:00
  -- Purpose : 分播资源试算

  /***分播设备试算主方法***/
  /******/
  procedure P_Divide_Device_Main(strEnterPriseNo IN odata_outstock_direct.enterprise_no%TYPE, --企业
                                 strWarehouseNo  IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
                                 strWaveNo       IN ODATA_OUTSTOCK_DIRECT.WAVE_NO%TYPE, --波次号
                                 strUserId       IN ODATA_OUTSTOCK_DIRECT.UPDT_NAME%TYPE, --员工ID
                                 strErrorMsg     OUT VARCHAR2) is

    v_nCount number;
  begin
    strErrorMsg := 'Y';
    v_nCount    := 0;

    PKLG_OLOCATE.p_write_log(strEnterpriseNo,
                             strWareHouseNo,
                             strWaveNo,
                             '分播资源试算开始。',
                             '10');

    --根据单据类型获取分播设备组，根据设备组获取可分播设备
    for v_GetDeviceType in (select ddm.device_group_no,
                                   ddm.operate_type,
                                   ddm.device_type, --设备类型
                                   (select m.divide_compute_level
                                      from device_divide_m m
                                     where m.enterprise_no =
                                           ddm.enterprise_no
                                       and m.warehouse_no = ddm.warehouse_no
                                       and m.device_type = ddm.device_type
                                       and m.operate_type = ddm.operate_type
                                       and m.status = '0'
                                       and rownum = 1) as divide_compute_level
                              from device_divide_m               ddm,
                                   wms_warehouse_outorder_device wwod,
                                   odata_locate_m                olm
                             where ddm.enterprise_no = wwod.enterprise_no
                               and ddm.warehouse_no = wwod.warehouse_no
                               and ddm.device_group_no =
                                   wwod.device_group_no
                               and wwod.enterprise_no = olm.enterprise_no
                               and wwod.warehouse_no = olm.warehouse_no
                               and wwod.exp_type = olm.exp_type
                               and olm.enterprise_no = strEnterPriseNo
                               and olm.warehouse_no = strWarehouseNo
                               and olm.wave_no = strWaveNo
                               and ddm.status = '0'
                               and exists
                             (select 'x'
                                      from odata_outstock_direct ood
                                     where olm.enterprise_no =
                                           ood.enterprise_no
                                       and olm.warehouse_no =
                                           ood.warehouse_no
                                       and olm.wave_no = ood.wave_no
                                       and ood.outstock_type = '0'
                                       and ood.pick_type = '1')
                             group by ddm.device_group_no,
                                      ddm.enterprise_no,
                                      ddm.warehouse_no,
                                      ddm.operate_type,
                                      ddm.device_type
                             order by ddm.operate_type, ddm.device_type) loop

      v_nCount := v_nCount + 1;
      --人工试算，不分作业类型
      if v_GetDeviceType.divide_compute_level = '2' then
        PKLG_OLOCATE.p_write_log(strEnterpriseNo,
                                 strWareHouseNo,
                                 strWaveNo,
                                 '人工分播资源试算开始。。。',
                                 '10');
        P_DIVIDE_HANDLE(strEnterPriseNo, --企业
                        strWarehouseNo, --仓别
                        strWaveNo, --波次号
                        strUserId, --员工ID
                        strErrorMsg);
        if substr(strErrorMsg, 1, 1) = 'N' then
          return;
        end if;
        PKLG_OLOCATE.p_write_log(strEnterpriseNo,
                                 strWareHouseNo,
                                 strWaveNo,
                                 '人工分播资源试算成功。。。',
                                 '10');
        exit;
      end if;

      if v_GetDeviceType.operate_type = 'B' then
        PKLG_OLOCATE.p_write_log(strEnterpriseNo,
                                 strWareHouseNo,
                                 strWaveNo,
                                 '拆零分播资源试算开始。。。',
                                 '10');

        --电子标签试算
        if v_GetDeviceType.device_type = '02' then
          PKLG_OLOCATE.p_write_log(strEnterpriseNo,
                                   strWareHouseNo,
                                   strWaveNo,
                                   '电子标签分播储位试算开始。。。',
                                   '10');

          --按系统固定配置试算
          if v_GetDeviceType.Divide_Compute_Level = 0 then
            P_B_DIVIDE_DPS(strEnterPriseNo, --企业
                           strWarehouseNo, --仓别
                           strWaveNo, --波次号
                           strUserId, --员工ID
                           strErrorMsg);
            if substr(strErrorMsg, 1, 1) = 'N' then
              return;
            end if;
          end if;

          PKLG_OLOCATE.p_write_log(strEnterpriseNo,
                                   strWareHouseNo,
                                   strWaveNo,
                                   '电子标签分播储位试算成功。。。',
                                   '10');
        end if;

        --分播墙试算
        if v_GetDeviceType.device_type = '05' then
          PKLG_OLOCATE.p_write_log(strEnterpriseNo,
                                   strWareHouseNo,
                                   strWaveNo,
                                   '分播墙格子试算开始。。。',
                                   '10');

          P_B_DIVIDE_WALL(strEnterPriseNo, --企业
                          strWarehouseNo, --仓别
                          strWaveNo, --波次号
                          v_GetDeviceType.Device_Group_No,
                          v_GetDeviceType.Operate_Type,
                          v_GetDeviceType.Device_Type,
                          strUserId, --员工ID
                          strErrorMsg);
          if substr(strErrorMsg, 1, 1) = 'N' then
            return;
          end if;

          PKLG_OLOCATE.p_write_log(strEnterpriseNo,
                                   strWareHouseNo,
                                   strWaveNo,
                                   '分播墙格子试算结束。。。',
                                   '10');
        end if;

        PKLG_OLOCATE.p_write_log(strEnterpriseNo,
                                 strWareHouseNo,
                                 strWaveNo,
                                 '拆零分播资源试算成功。。。',
                                 '10');
      end if;

      if v_GetDeviceType.operate_type = 'C' then
        PKLG_OLOCATE.p_write_log(strEnterpriseNo,
                                 strWareHouseNo,
                                 strWaveNo,
                                 '整箱分播资源试算开始。。。',
                                 '10');

        PKLG_OLOCATE.p_write_log(strEnterpriseNo,
                                 strWareHouseNo,
                                 strWaveNo,
                                 '整箱分播资源试算成功。。。',
                                 '10');
      end if;

    end loop;

    if v_nCount <= 0 then
      PKLG_OLOCATE.p_write_log(strEnterpriseNo,
                               strWareHouseNo,
                               strWaveNo,
                               '无分播指示不需试算分播设备。',
                               '10');
    else
      PKLG_OLOCATE.p_write_log(strEnterpriseNo,
                               strWareHouseNo,
                               strWaveNo,
                               '分播资源试算结束。',
                               '10');

    end if;
  EXCEPTION
    WHEN OTHERS THEN
      strErrorMsg := 'N|' || SQLCODE || ' ' || SQLERRM ||
                     SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
  end P_Divide_Device_Main;

  /***零散分播设备试算***/
  /******/
  PROCEDURE P_B_DIVIDE_DEVICE(strEnterPriseNo IN odata_outstock_direct.enterprise_no%TYPE, --企业
                              strWarehouseNo  IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
                              strWaveNo       IN ODATA_OUTSTOCK_DIRECT.WAVE_NO%TYPE, --波次号
                              strUserId       IN ODATA_OUTSTOCK_DIRECT.UPDT_NAME%TYPE, --员工ID
                              strErrorMsg     OUT VARCHAR2) IS

  BEGIN
    strErrorMsg := 'Y';

    P_SET_DIVIDE_DEVICE(strEnterPriseNo, --企业
                        strWarehouseNo, --仓别
                        strWaveNo, --波次号
                        'B', --作业类型
                        strUserId, --员工ID
                        strErrorMsg);
    if substr(strErrorMsg, 1, 1) = 'N' then
      return;
    end if;

    /***电子标签分播设备试算***/
    P_B_DIVIDE_DPS(strEnterPriseNo, --企业
                   strWarehouseNo, --仓别
                   strWaveNo, --波次号
                   strUserId, --员工ID
                   strErrorMsg);
    if substr(strErrorMsg, 1, 1) = 'N' then
      return;
    end if;

  EXCEPTION
    WHEN OTHERS THEN
      strErrorMsg := 'N|' || SQLCODE || ' ' || SQLERRM ||
                     SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
  END P_B_DIVIDE_DEVICE;

  /***整箱分播设备试算***/
  /******/
  PROCEDURE P_C_DIVIDE_DEVICE(strEnterPriseNo IN odata_outstock_direct.enterprise_no%TYPE, --企业
                              strWarehouseNo  IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
                              strWaveNo       IN ODATA_OUTSTOCK_DIRECT.WAVE_NO%TYPE, --波次号
                              strUserId       IN ODATA_OUTSTOCK_DIRECT.UPDT_NAME%TYPE, --员工ID
                              strErrorMsg     OUT VARCHAR2) IS

  BEGIN
    strErrorMsg := 'Y';

    P_SET_DIVIDE_DEVICE(strEnterPriseNo, --企业
                        strWarehouseNo, --仓别
                        strWaveNo, --波次号
                        'C', --作业类型
                        strUserId, --员工ID
                        strErrorMsg);
    if substr(strErrorMsg, 1, 1) = 'N' then
      return;
    end if;

  EXCEPTION
    WHEN OTHERS THEN
      strErrorMsg := 'N|' || SQLCODE || ' ' || SQLERRM ||
                     SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
  END P_C_DIVIDE_DEVICE;

  /***分播设备试算***/
  PROCEDURE P_SET_DIVIDE_DEVICE(strEnterPriseNo IN odata_outstock_direct.enterprise_no%TYPE, --企业
                                strWarehouseNo  IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
                                strWaveNo       IN ODATA_OUTSTOCK_DIRECT.WAVE_NO%TYPE, --波次号
                                strOperateType  IN ODATA_OUTSTOCK_DIRECT.OPERATE_TYPE%TYPE, --作业类型
                                strUserId       IN ODATA_OUTSTOCK_DIRECT.UPDT_NAME%TYPE, --员工ID
                                strErrorMsg     OUT VARCHAR2) IS

    v_blSetSuccFlag boolean;

    v_nCount number;
    v_strSQL varchar2(1000);

    v_nDivideTime1     ODATA_OUTSTOCK_DIVIDE_ALLOT.DIVIDE_TIME1%type;
    v_nDivideTime2     ODATA_OUTSTOCK_DIVIDE_ALLOT.DIVIDE_TIME1%type;
    v_nDivideTime3     ODATA_OUTSTOCK_DIVIDE_ALLOT.DIVIDE_TIME1%type;
    v_nDivideTime4     ODATA_OUTSTOCK_DIVIDE_ALLOT.DIVIDE_TIME1%type;
    v_nDivideTime5     ODATA_OUTSTOCK_DIVIDE_ALLOT.DIVIDE_TIME1%type;
    v_nDivideTime6     ODATA_OUTSTOCK_DIVIDE_ALLOT.DIVIDE_TIME1%type;
    v_nDivideTime7     ODATA_OUTSTOCK_DIVIDE_ALLOT.DIVIDE_TIME1%type;
    v_nDivideTime8     ODATA_OUTSTOCK_DIVIDE_ALLOT.DIVIDE_TIME1%type;
    v_nDivideTime9     ODATA_OUTSTOCK_DIVIDE_ALLOT.DIVIDE_TIME1%type;
    v_nDivideTimeCurr  ODATA_OUTSTOCK_DIVIDE_ALLOT.DIVIDE_TIME1%type;
    v_nDivideTimeTotal ODATA_OUTSTOCK_DIVIDE_ALLOT.DIVIDE_TIME1%type;
    v_nDivideTimeRate  ODATA_OUTSTOCK_DIVIDE_ALLOT.DIVIDE_TIME1%type;

    v_nDivideLevelTotal ODATA_OUTSTOCK_DIVIDE_ALLOT.DIVIDE_TIME1%type;

    v_strDeviceGrpNo device_divide_m.device_group_no%type;
    v_nGrade         device_divide_m.grade%type;
    v_nDeviceCount   number;
    i                number;
    j                number;

  BEGIN
    strErrorMsg     := 'Y';
    v_blSetSuccFlag := false;

    --预留:此处应该也通过策略

    --获取需分播的批次
    for v_csBatch in (select distinct ood.batch_no
                        from odata_outstock_direct ood
                       where ood.enterprise_no = strEnterPriseNo
                         and ood.warehouse_no = strWarehouseNo
                         and ood.wave_no = strWaveNo
                         and ((strOperateType = 'B' and
                             ood.operate_type = 'B') or
                             (strOperateType = 'C' and
                             ood.operate_type in ('C', 'M', 'S', 'W')))
                         and ood.pick_type = '1') loop

      --删除设备分配表
      delete from ODATA_OUTSTOCK_DIVIDE_ALLOT t
       where t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strWarehouseNo
         and t.wave_no = strWaveNo
         and t.OPERATE_TYPE = strOperateType;
      v_nCount := 1;

      --根据单据类型获取分播设备组，根据设备组获取可分播设备
      for v_csDivide in (select ddm.device_type, --设备类型
                                ddm.produce_capacity_type, --产能计算方式(0:件数  1:记录数)
                                ddm.grade, --设备优先级
                                sum(ddm.produce_capacity) as produce_capacity --设备产能
                           from device_divide_m               ddm,
                                wms_warehouse_outorder_device wwod,
                                odata_locate_m                olm
                          where ddm.enterprise_no = wwod.enterprise_no
                            and ddm.warehouse_no = wwod.warehouse_no
                            and ddm.device_group_no = wwod.device_group_no
                            and ddm.operate_type = strOperateType
                            and ddm.REF_RATE_FLAG = '1'
                            and ddm.produce_capacity > 0
                            and wwod.enterprise_no = olm.enterprise_no
                            and wwod.warehouse_no = olm.warehouse_no
                            and wwod.exp_type = olm.exp_type
                            and olm.enterprise_no = strEnterPriseNo
                            and olm.warehouse_no = strWarehouseNo
                            and olm.wave_no = strWaveNo
                          group by ddm.device_type,
                                   ddm.produce_capacity_type,
                                   ddm.grade
                          order by ddm.grade) loop

        if v_nCount = 1 then
          insert into ODATA_OUTSTOCK_DIVIDE_ALLOT
            (ENTERPRISE_NO,
             WAREHOUSE_NO,
             WAVE_NO,
             OPERATE_TYPE,
             DIRECT_SERIAL,
             SORT_ORDER,
             LOCATE_QTY,
             DIVIDE_TIME1)
            select enterprise_no,
                   warehouse_no,
                   strWaveNo,
                   strOperateType,
                   direct_serial,
                   SORT_ORDER,
                   locate_qty,
                   (sum(DIVIDE_TIME)
                    over(partition by enterprise_no,
                         warehouse_no order by SORT_ORDER))
              from (select ood.enterprise_no,
                           ood.warehouse_no,
                           ood.direct_serial,
                           rownum as SORT_ORDER,
                           ood.locate_qty,
                           case
                             when v_csDivide.Produce_Capacity_Type = '0' then --件计算
                              ood.locate_qty * (3600 / v_csDivide.produce_capacity)
                             else --按记录数计算
                              (3600 / v_csDivide.produce_capacity)
                           end as DIVIDE_TIME
                      from odata_outstock_direct ood
                     where ood.enterprise_no = strEnterPriseNo
                       and ood.warehouse_no = strWarehouseNo
                       and ood.wave_no = strWaveNo
                       and ood.batch_no = v_csBatch.Batch_No
                       and ood.outstock_type = '0' --出货
                       and ((strOperateType = 'B' and ood.operate_type = 'B') or
                           (strOperateType = 'C' and
                           ood.operate_type in ('C', 'M', 'S', 'W')))
                       and ood.pick_type = '1' --播种模式
                     order by ood.locate_qty);

        else

          v_strSQL := 'update ODATA_OUTSTOCK_DIVIDE_ALLOT set DIVIDE_TIME' ||
                      v_nCount || ' = ';
          v_strSQL := v_strSQL || ' case when ' ||
                      v_csDivide.Produce_Capacity_Type || '= 0  then '; --件计算
          v_strSQL := v_strSQL || '         locate_qty * (3600 / ' ||
                      v_csDivide.produce_capacity || ') ';
          v_strSQL := v_strSQL || '       else '; --按记录数计算
          v_strSQL := v_strSQL || '         (3600 / ' ||
                      v_csDivide.produce_capacity || ') ';

          v_strSQL := 'update ODATA_OUTSTOCK_DIVIDE_ALLOT t1 ';
          v_strSQL := v_strSQL || ' set t1.divide_time' || v_nCount ||
                      ' = ';
          v_strSQL := v_strSQL || ' (select qty ';
          v_strSQL := v_strSQL || '    from (select t2.sort_order,';
          v_strSQL := v_strSQL || ' sum( ';
          v_strSQL := v_strSQL || ' case when ' ||
                      v_csDivide.Produce_Capacity_Type || '= 0  then '; --件计算
          v_strSQL := v_strSQL || '         t2.locate_qty * (3600 / ' ||
                      v_csDivide.produce_capacity || ') ';
          v_strSQL := v_strSQL || '       else '; --按记录数计算
          v_strSQL := v_strSQL || '         (3600 / ' ||
                      v_csDivide.produce_capacity || ') ';
          v_strSQL := v_strSQL ||
                      ' ) over(partition by t2.enterprise_no, t2.warehouse_no order by t2.sort_order) as qty ';
          v_strSQL := v_strSQL ||
                      '  from ODATA_OUTSTOCK_DIVIDE_ALLOT t2) t3 ';
          v_strSQL := v_strSQL || ' where t1.sort_order = t3.sort_order) ';
          execute immediate v_strSQL;

        end if;

        v_nCount := v_nCount + 1;
      end loop;
      begin
        select divide_time1,
               divide_time2,
               divide_time3,
               divide_time4,
               divide_time5,
               divide_time6,
               divide_time7,
               divide_time8,
               divide_time9
          into v_nDivideTime1,
               v_nDivideTime2,
               v_nDivideTime3,
               v_nDivideTime4,
               v_nDivideTime5,
               v_nDivideTime6,
               v_nDivideTime7,
               v_nDivideTime8,
               v_nDivideTime9
          from (select divide_time1,
                       divide_time2,
                       divide_time3,
                       divide_time4,
                       divide_time5,
                       divide_time6,
                       divide_time7,
                       divide_time8,
                       divide_time9
                  from ODATA_OUTSTOCK_DIVIDE_ALLOT
                 order by sort_order desc)
         where rownum <= 1;

        v_nDivideTimeRate := 0;

        if v_nDivideTime1 > 0 then
          v_nDivideTimeRate := 1 / v_nDivideTime1;
        end if;

        if v_nDivideTime2 > 0 then
          v_nDivideTimeRate := v_nDivideTimeRate + 1 / v_nDivideTime2;
        end if;

        if v_nDivideTime3 > 0 then
          v_nDivideTimeRate := v_nDivideTimeRate + 1 / v_nDivideTime3;
        end if;

        if v_nDivideTime4 > 0 then
          v_nDivideTimeRate := v_nDivideTimeRate + 1 / v_nDivideTime4;
        end if;

        if v_nDivideTime5 > 0 then
          v_nDivideTimeRate := v_nDivideTimeRate + 1 / v_nDivideTime5;
        end if;

        if v_nDivideTime6 > 0 then
          v_nDivideTimeRate := v_nDivideTimeRate + 1 / v_nDivideTime6;
        end if;

        if v_nDivideTime7 > 0 then
          v_nDivideTimeRate := v_nDivideTimeRate + 1 / v_nDivideTime7;
        end if;

        if v_nDivideTime8 > 0 then
          v_nDivideTimeRate := v_nDivideTimeRate + 1 / v_nDivideTime8;
        end if;

        if v_nDivideTime9 > 0 then
          v_nDivideTimeRate := v_nDivideTimeRate + 1 / v_nDivideTime9;
        end if;

        v_nDivideTimeTotal := 0;
        v_strDeviceGrpNo   := 'N';
        for j in 1 .. 9 loop

          select decode(j,
                        1,
                        v_nDivideTime1,
                        2,
                        v_nDivideTime2,
                        3,
                        v_nDivideTime3,
                        4,
                        v_nDivideTime4,
                        5,
                        v_nDivideTime5,
                        6,
                        v_nDivideTime6,
                        7,
                        v_nDivideTime7,
                        8,
                        v_nDivideTime8,
                        v_nDivideTime9)
            into v_nDivideTimeCurr
            from dual;

          if v_nDivideTimeCurr > 0 then
            v_nDivideLevelTotal := v_nDivideTime1 * (1 / v_nDivideTimeCurr) *
                                   (1 / v_nDivideTimeRate);

            select device_group_no, grade, reco_count
              into v_strDeviceGrpNo, v_nGrade, v_nDeviceCount
              from (select ddm.device_group_no,
                           ddm.grade,
                           count(1) as reco_count,
                           rownum as sort_order
                      from device_divide_m               ddm,
                           wms_warehouse_outorder_device wwod,
                           odata_locate_m                olm
                     where ddm.enterprise_no = wwod.enterprise_no
                       and ddm.warehouse_no = wwod.warehouse_no
                       and ddm.device_group_no = wwod.device_group_no
                       and ddm.operate_type = strOperateType
                       and ddm.REF_RATE_FLAG = '1'
                       and ddm.produce_capacity > 0
                       and wwod.enterprise_no = olm.enterprise_no
                       and wwod.warehouse_no = olm.warehouse_no
                       and wwod.exp_type = olm.exp_type
                       and olm.enterprise_no = strEnterPriseNo
                       and olm.warehouse_no = strWarehouseNo
                       and olm.wave_no = strWaveNo
                     group by ddm.device_group_no, ddm.grade
                     order by ddm.device_group_no, ddm.grade)
             where sort_order = 1;

            for i in 1 .. v_nDeviceCount loop
              v_nDivideTimeTotal := v_nDivideTimeTotal +
                                    v_nDivideLevelTotal / v_nDeviceCount;

              update ODATA_OUTSTOCK_DIVIDE_ALLOT
                 set device_no =
                     (select device_no
                        from (select ddm.device_no, rownum as sort_order
                                from device_divide_m ddm
                               where ddm.enterprise_no = strEnterPriseNo
                                 and ddm.warehouse_no = strWarehouseNo
                                 and ddm.device_group_no = v_strDeviceGrpNo
                                 and ddm.grade = v_nGrade
                                 and ddm.operate_type = strOperateType
                               order by ddm.device_no)
                       where sort_order = i)
               where ENTERPRISE_NO = strEnterPriseNo
                 and WAREHOUSE_NO = strWarehouseNo
                 and DIVIDE_TIME1 <= v_nDivideTimeTotal
                 and device_no is null;
            end loop;

          end if;
        end loop;

        if v_strDeviceGrpNo <> 'N' then
          update ODATA_OUTSTOCK_DIVIDE_ALLOT
             set device_no =
                 (select device_no
                    from (select ddm.device_no, rownum as sort_order
                            from device_divide_m ddm
                           where ddm.enterprise_no = strEnterPriseNo
                             and ddm.warehouse_no = strWarehouseNo
                             and ddm.device_group_no = v_strDeviceGrpNo
                             and ddm.grade = v_nGrade
                             and ddm.operate_type = strOperateType
                           order by ddm.device_no)
                   where sort_order = 1)
           where ENTERPRISE_NO = strEnterPriseNo
             and WAREHOUSE_NO = strWarehouseNo
             and device_no is null;
        end if;
      exception
        when no_data_found then
          v_nDivideTime1 := 0;
      end;

      update odata_outstock_direct ood
         set ood.device_no =
             (select t.device_no
                from ODATA_OUTSTOCK_DIVIDE_ALLOT t
               where t.enterprise_no = ood.enterprise_no
                 and t.warehouse_no = ood.warehouse_no
                 and t.wave_no = ood.wave_no
                 and t.direct_serial = ood.direct_serial)
       where exists (select 'x'
                from ODATA_OUTSTOCK_DIVIDE_ALLOT t
               where t.enterprise_no = ood.enterprise_no
                 and t.warehouse_no = ood.warehouse_no
                 and t.direct_serial = ood.direct_serial
                 and t.enterprise_no = strEnterPriseNo
                 and t.warehouse_no = strWarehouseNo
                 and t.wave_no = strWaveNo
                 and t.operate_type = strOperateType);

    end loop;

    delete from ODATA_OUTSTOCK_DIVIDE_ALLOT t
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strEnterPriseNo
       and t.wave_no = strWaveNo
       and t.OPERATE_TYPE = strOperateType;

    strErrorMsg := 'Y';
  EXCEPTION
    WHEN OTHERS THEN
      strErrorMsg := 'N|' || SQLCODE || ' ' || SQLERRM ||
                     SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
  END P_SET_DIVIDE_DEVICE;

  /***零散分播设备试算***/
  /******/
  PROCEDURE P_B_DIVIDE_DPS(strEnterPriseNo IN odata_outstock_direct.enterprise_no%TYPE, --企业
                           strWarehouseNo  IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
                           strWaveNo       IN ODATA_OUTSTOCK_DIRECT.WAVE_NO%TYPE, --波次号
                           strUserId       IN ODATA_OUTSTOCK_DIRECT.UPDT_NAME%TYPE, --员工ID
                           strErrorMsg     OUT VARCHAR2) IS

    v_blSetSuccFlag boolean;

  BEGIN
    strErrorMsg     := 'Y';
    v_blSetSuccFlag := false;

    --预留:此处应该也通过策略

    --根据对应关系设置
    update odata_outstock_direct ood
       set (ood.dps_cell_no, ood.device_no) =
           (select nvl(ccd.dps_cell_no, 'N'), nvl(ccd.device_no, 'N')
              from cset_cust_dpscell         ccd,
                   bset_article_group_divide bagd,
                   bdef_defarticle           bda
             where ccd.enterprise_no = ood.enterprise_no --关联cset_cust_dpscell获取货位
               and ccd.warehouse_no = ood.warehouse_no
               and ccd.cust_no = ood.cust_no
               and ccd.device_group_no = bagd.device_group_no
               and bagd.warehouse_no = ood.warehouse_no --关联bset_article_group_divide出分播组(device_group_no)
               and bagd.enterprise_no = bda.enterprise_no
               and bagd.group_no = bda.group_no
               and bda.enterprise_no = ood.enterprise_no --关联商品表出组(group_no)
               and bda.article_no = ood.article_no)
     where ood.enterprise_no = strEnterPriseNo
       and ood.warehouse_no = strWarehouseNo
       and ood.wave_no = strWaveNo
       and ood.outstock_type = '0' --出货
       and ood.operate_type in ('B') --零散拣纲
       and ood.pick_type = '1'; --播种模式
    if sql%rowcount > 0 then
      v_blSetSuccFlag := true;
    end if;

    update odata_outstock_direct ood
       set (ood.dps_cell_no, ood.device_no) =
           (select nvl(ccd.dps_cell_no, 'N'), nvl(ccd.device_no, 'N')
              from cset_cust_dpscell ccd, device_divide_group ddg
             where ccd.enterprise_no = ood.enterprise_no --关联cset_cust_dpscell获取货位
               and ccd.warehouse_no = ood.warehouse_no
               and ccd.cust_no = ood.cust_no
               and ccd.device_group_no = ddg.device_group_no
               and ddg.warehouse_no = ood.warehouse_no --关联device_divide_group出分播组(device_group_no)
               and ddg.enterprise_no = ood.enterprise_no
               and ddg.default_flag = '1' --默认
               and ddg.use_type = '1') --出货
     where ood.enterprise_no = strEnterPriseNo
       and ood.warehouse_no = strWarehouseNo
       and ood.wave_no = strWaveNo
       and (ood.device_no = 'N' or ood.device_no is null)
       and ood.outstock_type = '0' --出货
       and ood.operate_type in ('B') --零散拣纲
       and ood.pick_type = '1'; --播种模式
    if sql%rowcount > 0 then
      v_blSetSuccFlag := true;
    end if;

    if v_blSetSuccFlag = true then
      return;
    end if;

    strErrorMsg := 'Y';
  EXCEPTION
    WHEN OTHERS THEN
      strErrorMsg := 'N|' || SQLCODE || ' ' || SQLERRM ||
                     SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
  END P_B_DIVIDE_DPS;

  /***零散分播更换设备***/
  /******/
  PROCEDURE P_B_CHG_DIVIDE_DEVICEGRP(strEnterPriseNo IN odata_outstock_direct.enterprise_no%TYPE, --企业
                                     strWarehouseNo  IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
                                     strLabelNo      IN stock_label_m.label_no%TYPE, --物流箱号
                                     strGroupNo      in device_divide_m.device_group_no%type, --组号
                                     strErrorMsg     OUT VARCHAR2) IS

    v_blSetSuccFlag boolean;
    v_nCount        number(5);

  BEGIN
    strErrorMsg     := 'Y';
    v_blSetSuccFlag := false;

    --预留:此处应该也通过策略
    v_nCount := 0;
    select count(1)
      into v_nCount
      from odata_divide_d ood
     where ood.enterprise_no = strEnterPriseNo
       and ood.warehouse_no = strWarehouseNo
       and ood.s_container_no =
           (select olm.container_no
              from stock_label_m olm
             where olm.enterprise_no = strEnterPriseNo
               and olm.warehouse_no = strWarehouseNo
               and olm.label_no = strLabelNo)
       and not exists (select 'x'
              from cset_cust_dpscell ccd
             where ccd.enterprise_no = ood.enterprise_no --关联cset_cust_dpscell获取货位
               and ccd.warehouse_no = ood.warehouse_no
               and ccd.cust_no = ood.cust_no
               and ccd.device_group_no = strGroupNo);
    if v_nCount > 0 then
      strErrorMsg := 'N|物流箱【' || strLabelNo || '】在设备组【' || strGroupNo ||
                     '】中存在有客户没有配置信息';
      return;
    end if;

    update odata_divide_d ood
       set ood.dps_cell_no =
           (select nvl(ccd.dps_cell_no, 'N')
              from cset_cust_dpscell ccd
             where ccd.enterprise_no = ood.enterprise_no --关联cset_cust_dpscell获取货位
               and ccd.warehouse_no = ood.warehouse_no
               and ccd.cust_no = ood.cust_no
               and ccd.device_group_no = strGroupNo) --出货
     where ood.enterprise_no = strEnterPriseNo
       and ood.warehouse_no = strWarehouseNo
       and ood.s_container_no =
           (select olm.container_no
              from stock_label_m olm
             where olm.enterprise_no = strEnterPriseNo
               and olm.warehouse_no = strWarehouseNo
               and olm.label_no = strLabelNo); --播种模式

    update stock_label_d ood
       set ood.dps_cell_no =
           (select nvl(ccd.dps_cell_no, 'N')
              from cset_cust_dpscell ccd
             where ccd.enterprise_no = ood.enterprise_no --关联cset_cust_dpscell获取货位
               and ccd.warehouse_no = ood.warehouse_no
               and ccd.cust_no = ood.cust_no
               and ccd.device_group_no = strGroupNo) --出货
     where ood.enterprise_no = strEnterPriseNo
       and ood.warehouse_no = strWarehouseNo
       and ood.container_no =
           (select olm.container_no
              from stock_label_m olm
             where olm.enterprise_no = strEnterPriseNo
               and olm.warehouse_no = strWarehouseNo
               and olm.label_no = strLabelNo); --播种模式

    strErrorMsg := 'Y';
  EXCEPTION
    WHEN OTHERS THEN
      strErrorMsg := 'N|' || SQLCODE || ' ' || SQLERRM ||
                     SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
  END P_B_CHG_DIVIDE_DEVICEGRP;

  /***分播手工设备试算***/
  /******/
  PROCEDURE P_DIVIDE_HANDLE(strEnterPriseNo IN odata_outstock_direct.enterprise_no%TYPE, --企业
                            strWarehouseNo  IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
                            strWaveNo       IN ODATA_OUTSTOCK_DIRECT.WAVE_NO%TYPE, --波次号
                            strUserId       IN ODATA_OUTSTOCK_DIRECT.UPDT_NAME%TYPE, --员工ID
                            strErrorMsg     OUT VARCHAR2) IS

    v_blSetSuccFlag boolean;

  BEGIN
    strErrorMsg := 'Y';

    for v_csBatch in (select distinct ood.batch_no
                        from odata_outstock_direct ood
                       where ood.enterprise_no = strEnterPriseNo
                         and ood.warehouse_no = strWarehouseNo
                         and ood.wave_no = strWaveNo
                         and ood.pick_type = '1') loop

      update odata_outstock_direct o
         set o.deliverobj_order =
             (select t.sort_order
                from (select distinct ood.enterprise_no,
                                      ood.warehouse_no,
                                      ood.wave_no,
                                      ood.deliver_obj,
                                      dense_rank() over(order by ood.line_no, ood.deliver_obj) sort_order
                        from odata_outstock_direct ood
                       where ood.enterprise_no = strEnterPriseNo
                         and ood.warehouse_no = strWarehouseNo
                         and ood.wave_no = strWaveNo
                         and ood.batch_no = v_csBatch.Batch_No
                         and ood.pick_type = '1') t
               where o.enterprise_no = t.enterprise_no
                 and o.warehouse_no = t.warehouse_no
                 and o.wave_no = t.wave_no
                 and o.deliver_obj = t.deliver_obj)
       where o.enterprise_no = strEnterPriseNo
         and o.warehouse_no = strWarehouseNo
         and o.wave_no = strWaveNo
         and o.batch_no = v_csBatch.Batch_No
         and o.pick_type = '1';

    end loop;

  EXCEPTION
    WHEN OTHERS THEN
      strErrorMsg := 'N|' || SQLCODE || ' ' || SQLERRM ||
                     SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
  END P_DIVIDE_HANDLE;

  --分播墙试算
  procedure P_B_DIVIDE_WALL(strEnterPriseNo IN odata_outstock_direct.enterprise_no%TYPE, --企业
                            strWarehouseNo  IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
                            strWaveNo       IN ODATA_OUTSTOCK_DIRECT.WAVE_NO%TYPE, --波次号
                            strDeviceGroup  in device_divide_m.device_group_no%type,
                            strOperateType  in device_divide_m.operate_type%type,
                            strDeviceType   in device_divide_m.device_type%type,
                            strUserId       IN ODATA_OUTSTOCK_DIRECT.UPDT_NAME%TYPE, --员工ID
                            strErrorMsg     OUT VARCHAR2) is

    v_nCount         number;
    v_nDeliverObjQty number;
    v_strDeviceNo    device_divide_m.device_no%type;
    strDpsCellNo     ODATA_OUTSTOCK_DIRECT.Dps_Cell_No%type;

  begin
    strErrorMsg := 'Y';
    v_nCount    := 0;

    --获取需要拆零分播设备试算的批次
    for v_GetDivideBatch in (select distinct lb.batch_no
                               from odata_locate_batch lb
                              where lb.enterprise_no = strEnterPriseNo
                                and lb.warehouse_no = strWarehouseNo
                                and lb.wave_no = strWaveNo
                                and lb.b_divide_flag in( '1','2')
                                and exists
                              (select 'x'
                                       from odata_outstock_direct od
                                      where lb.enterprise_no =
                                            od.enterprise_no
                                        and lb.warehouse_no = od.warehouse_no
                                        and lb.wave_no = od.wave_no
                                        and lb.batch_no = od.batch_no
                                        and od.outstock_type = '0'
                                        and od.pick_type = '1'
                                        and od.operate_type in( 'B','D'))
                              order by lb.batch_no) loop
      v_nCount := v_nCount + 1;

      --获取分播墙设备信息
      v_nDeliverObjQty := 0;
      begin
        select m.device_no, m.cust_qty
          into v_strDeviceNo, v_nDeliverObjQty
          from device_divide_m m
         where m.enterprise_no = strEnterPriseNo
           and m.warehouse_no = strWarehouseNo
           and m.device_type = strDeviceType
           and m.device_group_no = strDeviceGroup
           and m.operate_type = strOperateType
           and rownum = 1;
      exception
        when no_data_found then
          strErrorMsg := 'N|[未获取到分播设备信息]';
          return;
      end;

      --查询需分播的配送对象
      for v_GetDivideDeliverObj in (select distinct od.deliver_obj
                                      from odata_outstock_direct od
                                     where od.enterprise_no =
                                           strEnterPriseNo
                                       and od.warehouse_no = strWarehouseNo
                                       and od.wave_no = strWaveNo
                                       and od.batch_no =
                                           v_GetDivideBatch.Batch_No
                                       and od.outstock_type = '0'
                                       and od.operate_type in( 'B','D')) loop

        P_GetCellByDeliverObj(strEnterPriseNo,
                              strWarehouseNo,
                              strWaveNo,
                              v_GetDivideBatch.Batch_No,
                              v_GetDivideDeliverObj.Deliver_Obj,
                              strUserId,
                              v_strDeviceNo,
                              strDpsCellNo,
                              strErrorMsg);

        if substr(strErrorMsg, 1, 1) = 'N' then
          return;
        end if;

        --更新下架指示设备储位
        update odata_outstock_direct od
           set od.device_no   = substr(od.wave_no, 6) || od.batch_no ||
                                v_nCount,
               od.dps_cell_no = strDpsCellNo
         where od.enterprise_no = strEnterPriseNo
           and od.warehouse_no = strWarehouseNo
           and od.wave_no = strWaveNo
           and od.batch_no = v_GetDivideBatch.Batch_No
           and od.outstock_type = '0'
           and od.operate_type in( 'B','D')
           and od.deliver_obj = v_GetDivideDeliverObj.Deliver_Obj;

      end loop;

      --删除临时表数据
      delete tmp_cell_deliverobj t
       where t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strWarehouseNo
         and t.wave_no = strWaveNo
         and t.batch_no = v_GetDivideBatch.Batch_No;

    end loop;

    if v_nCount <= 0 then
      PKLG_OLOCATE.p_write_log(strEnterpriseNo,
                               strWareHouseNo,
                               strWaveNo,
                               '没有需要分播的批次。',
                               '10');

    end if;

  EXCEPTION
    WHEN OTHERS THEN
      strErrorMsg := 'N|' || SQLCODE || ' ' || SQLERRM ||
                     SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
  end P_B_DIVIDE_WALL;

  --获取配送对象分播设备储位
  procedure P_GetCellByDeliverObj(strEnterPriseNo IN odata_outstock_direct.enterprise_no%TYPE, --企业
                                  strWarehouseNo  IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
                                  strWaveNo       IN ODATA_OUTSTOCK_DIRECT.WAVE_NO%TYPE, --波次号
                                  strBatchNo      in ODATA_OUTSTOCK_DIRECT.Batch_No%type,
                                  strDeliverObj   in ODATA_OUTSTOCK_DIRECT.Deliver_Obj%type,
                                  strUserId       IN ODATA_OUTSTOCK_DIRECT.UPDT_NAME%TYPE, --员工ID
                                  strDeviceNo     in ODATA_OUTSTOCK_DIRECT.Device_No%type,
                                  strDpsCellNo    out ODATA_OUTSTOCK_DIRECT.Dps_Cell_No%type,
                                  strErrorMsg     OUT VARCHAR2) is
  begin
    strErrorMsg := 'Y';
    --获取已分配过的储位
    begin
      select t.device_cell_no
        into strDpsCellNo
        from tmp_cell_deliverobj t
       where t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strWarehouseNo
         and t.wave_no = strWaveNo
         and t.batch_no = strBatchNo
         and t.deliver_obj = strDeliverObj
         and t.device_no = strDeviceNo;
    exception
      when no_data_found then
        --没有分配过储位，则取新储位
        begin
          select device_cell_no
            into strDpsCellNo
            from (select d.device_cell_no
                    from device_divide_d d
                   where d.enterprise_no = strEnterPriseNo
                     and d.warehouse_no = strWarehouseNo
                     and d.device_no = strDeviceNo
                     and not exists
                   (select 'x'
                            from tmp_cell_deliverobj t
                           where t.enterprise_no = d.enterprise_no
                             and t.warehouse_no = d.warehouse_no
                             and t.device_no = d.device_no
                             and t.device_cell_no = d.device_cell_no)
                   order by  d.stock_y, d.bay_x)
           where rownum = 1;

          --插入临时表已分配的储位
          insert into tmp_cell_deliverobj
            (enterprise_no,
             warehouse_no,
             wave_no,
             batch_no,
             deliver_obj,
             device_no,
             device_cell_no)
          values
            (strEnterPriseNo,
             strWarehouseNo,
             strWaveNo,
             strBatchNo,
             strDeliverObj,
             strDeviceNo,
             strDpsCellNo);

        exception
          when no_data_found then
            strErrorMsg := 'N|[无法获取分播墙分播储位]';
            return;
        end;
    end;
  EXCEPTION
    WHEN OTHERS THEN
      strErrorMsg := 'N|' || SQLCODE || ' ' || SQLERRM ||
                     SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 256);
  end P_GetCellByDeliverObj;
END PKLG_ALLOT_DIVIDE_DEVICE;

/

