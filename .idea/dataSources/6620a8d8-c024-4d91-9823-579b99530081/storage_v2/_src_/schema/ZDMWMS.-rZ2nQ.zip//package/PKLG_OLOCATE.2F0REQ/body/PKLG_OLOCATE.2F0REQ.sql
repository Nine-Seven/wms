create package body        PKLG_OLOCATE is

  --设置定位提交组别
  procedure p_set_transgroup(strEnterpriseNo in varchar2, --企业
                             strWareHouseNo  in varchar2, --仓库代码
                             strWaveNo       in varchar2, --定位号
                             strWorkNo       in varchar2, --员工代码
                             strErrorMsg     out varchar2) is

    v_CommitType wms_outlocate_strategy_d.COMMIT_TYPE%type;
    v_strOwnerNo odata_locate_m.owner_no%type;
    v_strExpType odata_locate_m.exp_type%type;

  begin
    strErrorMsg := 'Y|';
    --获取单据类型,提交方式
    begin
      select lm.exp_type, lm.owner_no, lb.commit_type
        into v_strExpType, v_strOwnerNo, v_CommitType
        from odata_locate_m lm, odata_locate_batch lb
       where lm.enterprise_no = strEnterpriseNo
         and lm.warehouse_no = strWareHouseNo
         and lm.wave_no = strWaveNo
         and lm.enterprise_no = lb.enterprise_no
         and lm.warehouse_no = lb.warehouse_no
         and lm.wave_no = lb.wave_no
         and rownum = 1;
    exception
      when no_data_found then
        strErrorMsg := 'N|[找不到对应的波次信息-]'||strWaveNo;
        return;
    end;

    if v_CommitType = 0 then
      --提商品提交
      update odata_locate_d od
         set od.TRANS_GROUP_NO =
             (select trans_group_no
                from (select exp_no,
                             row_id,
                             (dense_rank()
                              over(partition by wave_no order by article_no)) as trans_group_no
                        from odata_locate_d iod
                       where iod.warehouse_no = strWareHouseNo
                         and iod.wave_no = strWaveNo
                         and iod.enterprise_no = strEnterpriseNo) c
               where c.row_id = od.row_id
                 and c.exp_no = od.exp_no)
       where od.warehouse_no = strWareHouseNo
         and od.enterprise_no = strEnterpriseNo
         and od.wave_no = strWaveNo;
    end if;

    if v_CommitType = 1 then
      --提订单提交
      update odata_locate_d od
         set od.TRANS_GROUP_NO =
             (select trans_group_no
                from (select exp_no,
                             row_id,
                             (dense_rank()
                              over(partition by wave_no order by exp_no)) as trans_group_no
                        from odata_locate_d iod
                       where iod.warehouse_no = strWareHouseNo
                         and iod.wave_no = strWaveNo
                         and iod.enterprise_no = strEnterpriseNo) c
               where c.row_id = od.row_id
                 and c.exp_no = od.exp_no)
       where od.warehouse_no = strWareHouseNo
         and od.enterprise_no = strEnterpriseNo
         and od.wave_no = strWaveNo;
    end if;

    if v_CommitType = 2 then
      --提客户提交
      update odata_locate_d od
         set od.TRANS_GROUP_NO =
             (select trans_group_no
                from (select exp_no,
                             row_id,
                             (dense_rank()
                              over(partition by wave_no order by cust_no)) as trans_group_no
                        from odata_locate_d iod
                       where iod.warehouse_no = strWareHouseNo
                         and iod.enterprise_no = strEnterpriseNo
                         and iod.wave_no = strWaveNo) c
               where c.row_id = od.row_id
                 and c.exp_no = od.exp_no)
       where od.warehouse_no = strWareHouseNo
         and od.enterprise_no = strEnterpriseNo
         and od.wave_no = strWaveNo;
    end if;

  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_set_transgroup;

  --提交出货任务
  procedure p_locate_task_commit(strEnterpriseNo in odata_locate_m.enterprise_no%type,
                                 strWareHouseNo  in varchar2, --仓库代码
                                 strWaveNo       in varchar2, --定位号
                                 strWorkNo       in varchar2, --员工代码
                                 strErrorMsg     out varchar2) is
  begin
    strErrorMsg := 'Y|';

    insert into ODATA_LOCATE_TASK
      (ENTERPRISE_NO, WAREHOUSE_NO, WAVE_NO, TASK_DATE, RGST_NAME)
    values
      (strEnterpriseNo, strWareHouseNo, strWaveNo, sysdate, strWorkNo);
  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_locate_task_commit;

  --出货定位程序入口
  procedure p_locate_main(strEnterpriseNo in odata_locate_m.enterprise_no%type,
                          strWareHouseNo  in varchar2, --仓库代码
                          strWaveNo       in varchar2, --定位号
                          strWorkNo       in varchar2, --员工代码
                          strErrorMsg     out varchar2) is
    v_strOwnerNo      odata_locate_m.owner_no%type;
    v_strExpType      odata_locate_m.exp_type%type;
    v_nTempCount      number(10);
    v_strShortQtyType odata_locate_batch.shortqty_type%type;
    v_CommitType      odata_locate_batch.commit_type%type;

    v_blPartShortLocFlag boolean;
    v_blAllShortLocFlag  boolean;
    --v_DivideFlag             odata_locate_m.divide_flag%type;
    v_strDeliverComputeLevle ODATA_LOCATE_BATCH.Sendbuf_Compute_Level%type;
    v_SendBufCompute         ODATA_LOCATE_BATCH.SENDBUF_COMPUTE_FLAG%type;
    v_strOperateType         wms_defbase.sdefine%type;
    v_nOperateType           wms_defbase.ndefine%type;

  begin
    strErrorMsg := 'Y|';

    --批次试算
    /*  PKLG_ODISPATCH.P_SET_BATCH(strEnterpriseNo,
                               strWarehouseNo,
                               strWaveNo,
                               strErrorMsg);
    if substr(strErrorMsg, 1, 2) = 'N|' then
      strErrorMsg := 'N|[试算批次失败]';
      return;
    end if;*/

    p_set_transgroup(strEnterpriseNo,
                     strWareHouseNo,
                     strWaveNo,
                     strWorkNo,
                     strErrorMsg);
    if substr(strErrorMsg, 1, 2) = 'N|' then
      strErrorMsg := 'N|[任务组试算失败]'||strErrorMsg;
      return;
    end if;

    --获取单据类型
    begin
      select lm.exp_type,
             lm.owner_no,
             lb.sendbuf_compute_level,
             lb.sendbuf_compute_flag,
             lb.commit_type,
             lb.shortqty_type
        into v_strExpType,
             v_strOwnerNo,
             v_strDeliverComputeLevle,
             v_SendBufCompute,
             v_CommitType,
             v_strShortQtyType
        from odata_locate_m lm, odata_locate_batch lb
       where lm.enterprise_no = strEnterpriseNo
         and lm.warehouse_no = strWareHouseNo
         and lm.wave_no = strWaveNo
         and lm.enterprise_no = lb.enterprise_no
         and lm.warehouse_no = lb.warehouse_no
         and lm.wave_no = lb.wave_no
         and rownum = 1;
    exception
      when no_data_found then
        strErrorMsg := 'N|[获取单据类型找不到对应的波次信息]';
        return;
    end;

    p_write_log(strEnterpriseNo,
                strWareHouseNo,
                strWaveNo,
                '对有生产日期出货限制且不指定批次的门店进行条件限制设置',
                '10');

    update odata_locate_d ld
       set ld.produce_condition = '1',
           ld.produce_value1   =
           (select case
                     when idc.control_type = '1' then
                      sysdate -
                      floor(ibd.expiry_days * idc.control_value / 100)
                     else
                      sysdate - idc.control_value
                   end
              from bdef_defarticle ibd, bdef_defcust idc
             where idc.enterprise_no = ld.enterprise_no
               and idc.owner_no = ld.owner_no
               and idc.cust_no = ld.cust_no
               and ibd.owner_no = ld.owner_no
               and ibd.article_no = ld.article_no
               and ibd.enterprise_no = ld.enterprise_no)
     where ld.warehouse_no = strWareHouseNo
       and ld.enterprise_no = strEnterpriseNo
       and ld.wave_no = strWaveNo
       and ld.status = '10'
       and (ld.produce_condition is null or ld.produce_condition = 'N') --必须是没有指定生产日期的
       and exists (select 'x'
              from bdef_defcust dc
             where dc.enterprise_no = ld.enterprise_no
               and dc.owner_no = ld.owner_no
               and dc.cust_no = ld.cust_no
               and dc.control_type in ('1', '2')) --按比例、按天数
       and exists (select '1'
              from bdef_defarticle ba
             where ba.enterprise_no = ld.enterprise_no
               and ba.owner_no = ld.owner_no
               and ba.article_no = ld.article_no
               and ba.lot_type in ('2', '3')); --管生产日期、管批次及生产日期

    --按任务组查询任务
    for v_cs_get_locate_group in (select distinct od.trans_group_no
                                    from odata_locate_d od
                                   where od.warehouse_no = strWareHouseNo
                                     and od.enterprise_no = strEnterpriseNo
                                     and od.wave_no = strWaveNo
                                     and od.status = '10') loop
      --调用组定位存储过程
      savepoint v_ts_group;

      p_locate_group(strEnterpriseNo,
                     strWareHouseNo,
                     strWaveNo,
                     v_cs_get_locate_group.trans_group_no,
                     strWorkNo,
                     v_blPartShortLocFlag,
                     v_blAllShortLocFlag,
                     strErrorMsg);

      if substr(strErrorMsg, 1, 2) = 'N|' then
        rollback to savepoint v_ts_group;
        --提示到具体原因 huangb 20160810
        p_write_log(strEnterpriseNo,
                    strWareHouseNo,
                    strWaveNo,
                    '定位组【' || v_cs_get_locate_group.trans_group_no ||
                    '】因问题【' || strErrorMsg || '】被回退。',
                    '99');
        goto next_get_group;
      end if;

      --部分缺量定位
      if v_blPartShortLocFlag = true then
        --如果整单提交模式，2、若缺量则踢单；5：部分缺量，不定位，转病单
        if v_CommitType = '1' and v_strShortQtyType in ('2', '5') then
          p_write_log(strEnterpriseNo,
                      strWareHouseNo,
                      strWaveNo,
                      '定位组【' || v_cs_get_locate_group.trans_group_no ||
                      '】因缺量被回退。',
                      '99');
          rollback to savepoint v_ts_group;
          savepoint v_ts_group;
        end if;

        --如果商品提交模式，6：只定足量商品，缺量品转下一次再定
        if v_CommitType = '0' and v_strShortQtyType in ('6') then
          p_write_log(strEnterpriseNo,
                      strWareHouseNo,
                      strWaveNo,
                      '定位组【' || v_cs_get_locate_group.trans_group_no ||
                      '】因缺量被回退。',
                      '99');
          rollback to savepoint v_ts_group;
          savepoint v_ts_group;
        end if;
      end if;

      PKOBJ_ODISPATCH.p_close_locate_d(strEnterpriseNo,
                                       strWareHouseNo,
                                       strWaveNo,
                                       v_cs_get_locate_group.trans_group_no,
                                       strWorkNo,
                                       strErrorMsg);

      if substr(strErrorMsg, 1, 2) = 'N|' then
        rollback to savepoint v_ts_group;
        p_write_log(strEnterpriseNo,
                    strWareHouseNo,
                    strWaveNo,
                    '定位组【' || v_cs_get_locate_group.trans_group_no ||
                    '更新定位指失败：' || substr(strErrorMsg, 3),
                    '99');
        goto next_get_group;
      end if;

      commit;

      <<next_get_group>>
      null;

    end loop;

    --应该校验定位数据是否有异常(比如超量)

    select count(1)
      into v_nTempCount
      from odata_locate_d od
     where od.warehouse_no = strWareHouseNo
       and od.enterprise_no = strEnterpriseNo
       and od.wave_no = strWaveNo;

    if v_nTempCount = 0 then

      /*  p_write_log(strEnterpriseNo,
      strWareHouseNo,
      strWaveNo,
      '对没有包装的商品以及只能出拆零的区域，作业类型置为拆零。',
      '10');*/
      /*--为零散指示拆库存
      p_calculate_bSPlitQty(strEnterpriseNo,
                            strWareHouseNo,
                            strWaveNo,
                            strErrorMsg);
      if substr(strErrorMsg, 1, 1) = 'N' then
        rollback;
        p_write_log(strEnterpriseNo,
                    strWareHouseNo,
                    strWaveNo,
                    '月台序号计算失败 ' || substr(strErrorMsg, 3),
                    '99');
        return;
      end if;*/

      --Modify BY QZH AT 2016-8-30 一个批次只有一个配送对象，强制摘果
      update odata_outstock_direct a
          set a.pick_type = '0'
        where a.pick_type > '0'
        and a.enterprise_no=strEnterpriseNo
        and a.warehouse_no=strWareHouseNo
        and a.wave_no=strWaveNo
        and a.outstock_type='0'
          and exists (select 'x'
                 from odata_outstock_direct b
                where a.enterprise_no = b.enterprise_no
                  and a.warehouse_no = b.warehouse_no
                  and a.wave_no = b.wave_no
                  and a.batch_no = b.batch_no
                  and b.outstock_type='0'  having
                count(distinct b.deliver_obj) <= 1);
      --Modify End

      --计算月台序号
      if v_SendBufCompute = '1' and v_strDeliverComputeLevle = '1' then
        p_write_log(strEnterpriseNo,
                    strWareHouseNo,
                    strWaveNo,
                    '月台序号计算试算开始。。。',
                    '10');

        pklg_Deliveid_calculate.P_Deliver_calculate(strEnterpriseNo,
                                                    strWarehouseNo,
                                                    v_strOwnerNo,
                                                    strWaveNo,
                                                    strErrorMsg);
        if substr(strErrorMsg, 1, 1) = 'N' then
          rollback;
          p_write_log(strEnterpriseNo,
                      strWareHouseNo,
                      strWaveNo,
                      '月台序号计算失败 ' || substr(strErrorMsg, 3),
                      '99');
          return;
        end if;
      end if;

      --获取系统参数
      PKLG_WMS_BASE.p_GetBasePara(strEnterPriseNo,
                                  strWareHouseNo,
                                  v_strOwnerNo,
                                  'operate_type',
                                  'O',
                                  'O_LOCATE',
                                  v_strOperateType,
                                  v_nOperateType,
                                  strErrorMsg);
      if substr(strErrorMsg, 1, 1) = 'N' then
        strErrorMsg := 'N|[E30025]';
        return;
      end if;

      if v_strOperateType = '1' then
        --混合拣货区的下架类型为C
        updatE odata_outstock_direct ood
           set ood.Operate_Type = 'C', ood.s_container_no = 'N'
         where ood.warehouse_no = strWareHouseNo
           and ood.enterprise_no = strEnterpriseNo
           and ood.wave_no = strWaveNo
           and ood.status = 'N'
           and ood.operate_type IN ('P', 'B')
           and ood.outstock_type = '0'
           and ood.s_cell_no in
               (select cc.cell_no
                  from cdef_defarea cd, cdef_defcell cc
                 where cd.enterprise_no = cc.enterprise_no
                   and cd.warehouse_no = cc.warehouse_no
                   and cd.ware_no = cc.ware_no
                   and cd.area_no = cc.area_no
                   and cd.AREA_ATTRIBUTE = '0'
                   and cd.area_type = '8');
      end if;

      if v_strOperateType = '2' then
        updatE odata_outstock_direct ood
           set ood.Operate_Type = 'B', ood.s_container_no = 'N'
         where ood.warehouse_no = strWareHouseNo
           and ood.enterprise_no = strEnterpriseNo
           and ood.wave_no = strWaveNo
           and ood.status = 'N'
           and ood.operate_type in ('C', 'P')
           and ood.outstock_type = '0'
           and ood.s_cell_no in
               (select cc.cell_no
                  from cdef_defarea cd, cdef_defcell cc
                 where cd.enterprise_no = cc.enterprise_no
                   and cd.warehouse_no = cc.warehouse_no
                   and cd.ware_no = cc.ware_no
                   and cd.area_no = cc.area_no
                   and cd.AREA_ATTRIBUTE = '0'
                   and cd.area_type = '8');
      end if;

      --更新状态以及看是否管理包装数,没有则定位是都把操作类型修改为B
      update odata_outstock_direct ood
         set ood.status       = ood.temp_status,
             ood.operate_type = case
                                  when (select count(1)
                                          from bdef_article_packing bap
                                         where bap.article_no = ood.article_no
                                           and bap.enterprise_no =
                                               ood.enterprise_no) = 0 then
                                   'B'
                                  else
                                   ood.operate_type
                                end
       where ood.warehouse_no = strWareHouseNo
         and ood.enterprise_no = strEnterpriseNo
         and ood.wave_no = strWaveNo
         and ood.status = 'N';

      --计算分播设备
      PKLG_ALLOT_DIVIDE_DEVICE.P_Divide_Device_Main(strEnterpriseNo,
                                                    strWareHouseNo,
                                                    strWaveNo,
                                                    strWorkNo,
                                                    strErrorMsg);

      if substr(strErrorMsg, 1, 2) = 'N|' then
        rollback;
        p_write_log(strEnterpriseNo,
                    strWareHouseNo,
                    strWaveNo,
                    '分播资源试算失败：' || substr(strErrorMsg, 3),
                    '99');
        return;
      end if;

      p_write_log(strEnterpriseNo,
                  strWareHouseNo,
                  strWaveNo,
                  '写入波次跟踪表。',
                  '10');
      --Modify BY QZH AT 2016-6-6
      v_blAllShortLocFlag:=false; --前面此值只针对定位组 Modify BY QZH AT 2016-8-10

      update odata_wave_trace t
         set t.status    = '10',
             t.updt_name = strWorkNo,
             T.Updt_Date = sysdate
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.wave_no = strWaveNo;

      if sql%notfound then
        --写入波次跟踪表,没有定到位不写
        insert into ODATA_WAVE_TRACE
          (enterprise_no,
           warehouse_no,
           owner_no,
           wave_no,
           exp_type,
           status,
           exp_date,
           source_type,
           rgst_name,
           rgst_date,
           updt_name,
           updt_date)
          select strEnterpriseNo,
                 warehouse_no,
                 owner_no,
                 wave_no,
                 exp_type,
                 status,
                 exp_date,
                 source_type,
                 strWorkNo,
                 sysdate,
                 strWorkNo,
                 sysdate
            from ODATA_LOCATE_M a
           where a.warehouse_no = strWareHouseNo
             and a.enterprise_no = strEnterpriseNo
             and exists (select 1
                    from odata_outstock_direct ood
                   where a.warehouse_no = ood.warehouse_no
                     and a.owner_no = ood.owner_no
                     and a.wave_no = ood.wave_no
                     and a.enterprise_no = ood.enterprise_no)
             and a.wave_no = strWaveNo;
        if sql%rowcount <= 0 then
          strErrorMsg := 'N|定位失败！，找不到定位成功的下架指示';
          p_write_log(strEnterpriseNo,
                      strWareHouseNo,
                      strWaveNo,
                      strErrorMsg,
                      '99');
          v_blAllShortLocFlag := true;
        end if;
      end if;

      if v_blAllShortLocFlag = false then

        p_write_log(strEnterpriseNo,
                    strWareHouseNo,
                    strWaveNo,
                    '摘果物流箱试算开始。。。',
                    '10');

        PKLG_CONTAINER_CALCULATE.P_CONTAINER_CALCULATE_PICK(strEnterPriseNo,
                                                            strWareHouseNo,
                                                            strWaveNo,
                                                            strWorkNo,
                                                            strErrorMsg);
        if substr(strErrorMsg, 1, 2) = 'N|' then
          rollback;
          p_write_log(strEnterpriseNo,
                      strWareHouseNo,
                      strWaveNo,
                      '摘果物流箱试算失败：' || substr(strErrorMsg, 3),
                      '99');
          return;
        end if;

        /*Modify BY QZH AT 2016-6-6 --如果全部定位完成，则进行物流箱试算
        PKLG_CONTAINER_CALCULATE.P_CUST_CONTAINER_CALCULATE(strEnterpriseNo,
                                                            strWareHouseNo,
                                                            strWaveNo,
                                                            strWorkNo,
                                                            '0',
                                                            '1',
                                                            strErrorMsg);*/
        --如果全部定位完成，则进行物流箱试算
        /*    PKLG_CONTAINER_CALCULATE.P_CUST_ContainerCALC_EC(strEnterpriseNo,
                                                              strWareHouseNo,
                                                              strWaveNo,
                                                              strWorkNo,
                                                              '0',
                                                              '1',
                                                              strErrorMsg);

          if substr(strErrorMsg, 1, 2) = 'N|' then
            rollback;
            p_write_log(strEnterpriseNo,
                        strWareHouseNo,
                        strWaveNo,
                        '客户物流箱试算失败：' || substr(strErrorMsg, 3),
                        '99');
            return;
          end if;
        end if;*/
        p_write_log(strEnterpriseNo,
                    strWareHouseNo,
                    strWaveNo,
                    '摘果物流箱试算结束。',
                    '10');

        p_write_log(strEnterpriseNo,
                    strWareHouseNo,
                    strWaveNo,
                    '分播物流箱试算开始。。。',
                    '10');
        PKLG_CONTAINER_CALCULATE.P_CONTAINER_CALCULATE_DIVIDE(strEnterpriseNo,
                                                              strWareHouseNo,
                                                              strWaveNo,
                                                              strWorkNo,
                                                              strErrorMsg);

        if substr(strErrorMsg, 1, 2) = 'N|' then
          rollback;
          p_write_log(strEnterpriseNo,
                      strWareHouseNo,
                      strWaveNo,
                      '分播物流箱试算失败：' || substr(strErrorMsg, 3),
                      '99');
          return;
        end if;
        p_write_log(strEnterpriseNo,
                    strWareHouseNo,
                    strWaveNo,
                    '分播物流箱试算结束。',
                    '10');

        --暂存区资源试算
        if v_SendBufCompute = '1' then
          p_write_log(strEnterpriseNo,
                      strWareHouseNo,
                      strWaveNo,
                      '暂存区资源试算开始。。。',
                      '10');

          --获取当前波次所有批次
          for v_batchno in (select batch_no
                              from ODATA_LOCATE_BATCH lb
                             where lb.enterprise_no = strEnterpriseNo
                               and lb.warehouse_no = strWareHouseNo
                               and lb.wave_no = strWaveNo) loop
            PKLG_BUFFER_CALCULATE.P_DeliverArea_Cal(strEnterpriseNo,
                                                    strWareHouseNo,
                                                    strWaveNo,
                                                    v_batchno.batch_no,
                                                    strErrorMsg);

            if substr(strErrorMsg, 1, 2) = 'N|' then
              rollback;
              p_write_log(strEnterpriseNo,
                          strWareHouseNo,
                          strWaveNo,
                          '暂存区资源试算失败：' || substr(strErrorMsg, 3),
                          '99');
              return;
            end if;
          end loop;

          p_write_log(strEnterpriseNo,
                      strWareHouseNo,
                      strWaveNo,
                      '暂存区资源试算结束。',
                      '10');
        end if;
      end if;

      p_write_log(strEnterpriseNo,
                  strWareHouseNo,
                  strWaveNo,
                  '关闭定位波次。。。',
                  '10');
      PKOBJ_ODISPATCH.p_close_locate_m(strEnterpriseNo,
                                       strWareHouseNo,
                                       strWaveNo,
                                       strWorkNo,
                                       strErrorMsg);

      if substr(strErrorMsg, 1, 2) = 'N|' then
        rollback;
        p_write_log(strEnterpriseNo,
                    strWareHouseNo,
                    strWaveNo,
                    '关闭定位波次失败：' || substr(strErrorMsg, 3),
                    '99');
        return;
      end if;

      p_write_log(strEnterpriseNo,
                  strWareHouseNo,
                  strWaveNo,
                  '置出货订单状态。',
                  '10');
      --有多少订多少
      if v_strShortQtyType in ('1') then
        update odata_exp_d od
           set od.status = '12'
         where od.warehouse_no = strWareHouseNo
           and od.enterprise_no = strEnterpriseNo
           and exists
         (select 'x'
                  from odata_exp_m om
                 where om.warehouse_no = od.warehouse_no
                   and om.exp_no = od.exp_no
                   and om.warehouse_no = strWareHouseNo
                   and om.wave_no = strWaveNo
                   and om.enterprise_no = strEnterpriseNo);

        update odata_exp_m om
           set om.status     = '12',
               om.updt_date  = sysdate,
               om.exp_status = '05',
               om.exp_date   = trunc(sysdate)
         where om.warehouse_no = strWareHouseNo
           and om.enterprise_no = strEnterpriseNo
           and om.wave_no = strWaveNo
           AND om.status IN ('10','11')
           and exists (select 'x'
                  from odata_exp_d oe
                 where oe.enterprise_no = om.enterprise_no
                   and oe.warehouse_no = om.warehouse_no
                   and oe.owner_no = om.owner_no
                   and oe.exp_no = om.exp_no
                   and oe.locate_qty > 0);

        --预留:此处需要参数来决定状态
        update odata_exp_m om
           set om.status     = '13',
               om.updt_date  = sysdate,
               om.exp_status = '05',
               om.exp_date   = trunc(sysdate)
         where om.warehouse_no = strWareHouseNo
           and om.enterprise_no = strEnterpriseNo
           and om.wave_no = strWaveNo
           and om.status = '11';
      end if;

      --有多少订多少，缺量部分重定位
      if v_strShortQtyType in ('3') then
        update odata_exp_d od
           set od.status = (case
                             when od.article_qty = od.locate_qty then
                              '12'
                             else
                              '10'
                           end)
         where exists (select 'x'
                  from odata_exp_m om
                 where om.enterprise_no = od.enterprise_no
                   and om.warehouse_no = od.warehouse_no
                   and om.owner_no = od.owner_no
                   and om.exp_no = od.exp_no
                   and om.warehouse_no = strWareHouseNo
                   and om.wave_no = strWaveNo
                   and om.enterprise_no = strEnterpriseNo);

        update odata_exp_m om
           set om.status     = '10',
               om.updt_date  = sysdate,
               om.exp_status = '05',
               om.exp_date   = trunc(sysdate)
         where om.warehouse_no = strWareHouseNo
           and om.enterprise_no = strEnterpriseNo
           and om.wave_no = strWaveNo
           and exists (select 'x'
                  from odata_exp_d oe
                 where oe.enterprise_no = om.enterprise_no
                   and oe.warehouse_no = om.warehouse_no
                   and oe.owner_no = om.owner_no
                   and oe.exp_no = om.exp_no
                   and oe.status = '10');

        --
        update odata_exp_m om
           set om.status     = '12',
               om.updt_date  = sysdate,
               om.exp_status = '05',
               om.exp_date   = trunc(sysdate)
         where om.warehouse_no = strWareHouseNo
           and om.enterprise_no = strEnterpriseNo
           and om.wave_no = strWaveNo
           and om.status = '11';
      end if;

      --缺量踢单
      if v_strShortQtyType in ('2') then

        --把整单都没有定到位的置回初始状态，部分有定到位并且做了提交，此部分视为配置出问题
        update odata_exp_m om
           set om.status     = '10',
               om.updt_date  = sysdate,
               om.exp_status = '05',
               om.exp_date   = trunc(sysdate)
         where om.warehouse_no = strWareHouseNo
           and om.enterprise_no = strEnterpriseNo
           and om.wave_no = strWaveNo
           and 0 = (select sum(oe.locate_qty)
                      from odata_exp_d oe
                     where oe.enterprise_no = om.enterprise_no
                       and oe.warehouse_no = om.warehouse_no
                       and oe.owner_no = om.owner_no
                       and oe.exp_no = om.exp_no);

        update odata_exp_d od
           set od.status = '10'
         where exists (select 'x'
                  from odata_exp_m om
                 where om.enterprise_no = od.enterprise_no
                   and om.warehouse_no = od.warehouse_no
                   and om.owner_no = od.owner_no
                   and om.exp_no = od.exp_no
                   and om.warehouse_no = strWareHouseNo
                   and om.wave_no = strWaveNo
                   and om.enterprise_no = strEnterpriseNo
                   and om.status = '10');

        --处理完后，其它的置为12
        update odata_exp_m om
           set om.status     = '12',
               om.updt_date  = sysdate,
               om.exp_status = '05',
               om.exp_date   = trunc(sysdate)
         where om.warehouse_no = strWareHouseNo
           and om.enterprise_no = strEnterpriseNo
           and om.wave_no = strWaveNo
           and om.status = '11';

        update odata_exp_d od
           set od.status = '12'
         where exists (select 'x'
                  from odata_exp_m om
                 where om.enterprise_no = od.enterprise_no
                   and om.warehouse_no = od.warehouse_no
                   and om.owner_no = od.owner_no
                   and om.exp_no = od.exp_no
                   and om.warehouse_no = strWareHouseNo
                   and om.wave_no = strWaveNo
                   and om.enterprise_no = strEnterpriseNo
                   and om.status = '12');
      end if;

      --缺量：4、有多少定多少，转病单；5：部分缺量，不定位，转病单
      if v_strShortQtyType in ('4', '5') then

        if v_strShortQtyType = '5' then

          --把整单都没有定到位的置为病单，部分有定到位并且做了提交，此部分视为配置出问题
          update odata_exp_m oem
             set status = COdataExpStatus.CancelMiddStatus
           where 0 = (select sum(oed.locate_qty)
                        from odata_exp_d oed
                       where oem.warehouse_no = oed.warehouse_no
                         and oem.enterprise_no = oed.enterprise_no
                         and oem.exp_no = oed.exp_no)
             and oem.warehouse_no = strWareHouseNo
             and oem.enterprise_no = strEnterpriseNo
             and oem.wave_no = strWaveNo;

        else
          update odata_exp_m oem
             set status = COdataExpStatus.CancelMiddStatus
           where exists (select '1'
                    from odata_exp_d oed
                   where oem.warehouse_no = oed.warehouse_no
                     and oem.enterprise_no = oed.enterprise_no
                     and oem.exp_no = oed.exp_no
                     and oed.locate_qty < oed.article_qty)
             and oem.warehouse_no = strWareHouseNo
             and oem.enterprise_no = strEnterpriseNo
             and oem.wave_no = strWaveNo;
        end if;

        PKLG_ODATA_EXPCANCEL.P_WaveToexpCancel(strEnterpriseNo,
                                               strWareHouseNo,
                                               v_strownerno,
                                               strWaveNo,
                                               '1',
                                               strWorkNo,
                                               strErrorMsg);

        if substr(strErrorMsg, 1, 2) = 'N|' then
          rollback;
          p_write_log(strEnterpriseNo,
                      strWareHouseNo,
                      strWaveNo,
                      '设置病单失败：' || substr(strErrorMsg, 3),
                      '99');
          return;
        end if;

        update odata_exp_m om
           set om.status     = '12',
               om.updt_date  = sysdate,
               om.exp_status = '05',
               om.exp_date   = trunc(sysdate)
         where om.warehouse_no = strWareHouseNo
           and om.enterprise_no = strEnterpriseNo
           and om.wave_no = strWaveNo
           and om.status = '11';

        update odata_exp_d od
           set od.status = '12'
         where exists (select 'x'
                  from odata_exp_m om
                 where om.enterprise_no = od.enterprise_no
                   and om.warehouse_no = od.warehouse_no
                   and om.owner_no = od.owner_no
                   and om.exp_no = od.exp_no
                   and om.warehouse_no = strWareHouseNo
                   and om.wave_no = strWaveNo
                   and om.enterprise_no = strEnterpriseNo
                   and om.status = '12');

      end if;

      --6：只定足量商品，缺量品再定
      if v_strShortQtyType in ('6') then

        --把没有定到位的置回初始状态
        update odata_exp_m om
           set om.status     = '10',
               om.updt_date  = sysdate,
               om.exp_status = '05',
               om.exp_date   = trunc(sysdate)
         where om.warehouse_no = strWareHouseNo
           and om.enterprise_no = strEnterpriseNo
           and om.wave_no = strWaveNo
           and exists (select 'x'
                  from odata_exp_d oe
                 where oe.enterprise_no = om.enterprise_no
                   and oe.warehouse_no = om.warehouse_no
                   and oe.owner_no = om.owner_no
                   and oe.exp_no = om.exp_no
                   and oe.locate_qty = 0);

        update odata_exp_d od
           set od.status = '10'
         where od.locate_qty = 0
           and exists (select 'x'
                  from odata_exp_m om
                 where om.enterprise_no = od.enterprise_no
                   and om.warehouse_no = od.warehouse_no
                   and om.owner_no = od.owner_no
                   and om.exp_no = od.exp_no
                   and om.warehouse_no = strWareHouseNo
                   and om.wave_no = strWaveNo
                   and om.enterprise_no = strEnterpriseNo
                   and om.status = '10');

        --处理完后，其它的置为12
        update odata_exp_m om
           set om.status     = '12',
               om.updt_date  = sysdate,
               om.exp_status = '05',
               om.exp_date   = trunc(sysdate)
         where om.warehouse_no = strWareHouseNo
           and om.enterprise_no = strEnterpriseNo
           and om.wave_no = strWaveNo
           and om.status = '11';

        update odata_exp_d od
           set od.status = '12'
         where exists (select 'x'
                  from odata_exp_m om
                 where om.enterprise_no = od.enterprise_no
                   and om.warehouse_no = od.warehouse_no
                   and om.owner_no = od.owner_no
                   and om.exp_no = od.exp_no
                   and om.warehouse_no = strWareHouseNo
                   and om.wave_no = strWaveNo
                   and om.enterprise_no = strEnterpriseNo
                   and om.status = '12');
      end if;

      commit;
      p_write_log(strEnterpriseNo,
                  strWareHouseNo,
                  strWaveNo,
                  '定位完成。',
                  '10');

    end if;

  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
      p_write_log(strEnterpriseNo,
                  strWareHouseNo,
                  strWaveNo,
                  '定位失败：' ||
                  substr(dbms_utility.format_error_backtrace, 1, 256),
                  '99');
  end p_locate_main;

  --组定位程序入口
  procedure p_locate_group(strEnterpriseNo    in odata_locate_m.enterprise_no%type,
                           strWareHouseNo     in varchar2, --仓库代码
                           strWaveNo          in varchar2, --定位号
                           nGroupNo           in number, --出货组号
                           strWorkNo          in varchar2, --员工代码
                           blPartShortLocFlag out boolean, --部分缺量标识
                           blAllShortLocFlag  out boolean, --全部缺量标识
                           strErrorMsg        out varchar2) is

    v_strMinBatchNo odata_locate_d.batch_no%type;
    v_strDestCellNo cdef_defcell.cell_no%type;

    v_strOldArticleNo bdef_defarticle.article_no%type;
    v_strOldOwnerNo   bdef_defarticle.owner_no%type;

    v_nLocateQty    odata_locate_d.plan_qty%type;
    v_FIXEDCELLFLAG bdef_defowner.FIXEDCELL_FLAG%type;
    v_ownerno       bdef_defowner.owner_no%type;
    v_strOStrategy  bdef_defarticle.o_strategy%type;

    v_strIMConfirmStock wms_defbase.sdefine%type;
    v_strRIConfirmStock wms_defbase.sdefine%type;
    strAllCelln         wms_defbase.sdefine%type;
    v_nTmpStockID       number;
    v_nAllotID          number;
    --v_Count             number;
    v_strSQL   varchar2(4096);
    v_strWhere varchar2(1024);

  begin
    strErrorMsg := 'Y|';

    blPartShortLocFlag := false;
    blAllShortLocFlag  := true;

    --锁记录，如果锁失败直接退出
    update odata_locate_d od
       set od.status = '12'
     where od.warehouse_no = strWareHouseNo
       and od.wave_no = strWaveNo
       and od.enterprise_no = strEnterpriseNo
       and od.trans_group_no = nGroupNo
       and od.status = '10';
    if sql%rowcount <= 0 then
      return;
    end if;

    --获取最小批次号
    begin
      select min(od.batch_no)
        into v_strMinBatchNo
        from odata_locate_d od
       where od.warehouse_no = strWareHouseNo
         and od.enterprise_no = strEnterpriseNo
         and od.wave_no = strWaveNo;

    exception
      when no_data_found then
        v_strMinBatchNo := 'N';
    end;

    --查看货主是否绑定储位
    begin
      select bd.FIXEDCELL_FLAG, bd.owner_no
        into v_FIXEDCELLFLAG, v_ownerno
        from odata_locate_M om, bdef_defowner bd
       where om.warehouse_no = strWareHouseNo
         and om.enterprise_no = bd.enterprise_no
         and om.enterprise_no = strEnterpriseNo
         and om.wave_no = strWaveNo
         and om.owner_no = bd.owner_no;

    exception
      when no_data_found then
        v_FIXEDCELLFLAG := '0';
    end;

    --获取出货暂存区
    /*    if v_FIXEDCELLFLAG = '0' then*/
    begin
      select cell_no
        into v_strDestCellNo
        from (select cdc.cell_no
                from cdef_defcell cdc, cdef_defarea cda
               where cdc.warehouse_no = cda.warehouse_no
                 and cdc.ware_no = cda.ware_no
                 and cdc.area_no = cda.area_no
                 and cda.warehouse_no = strWareHouseNo
                 and cdc.enterprisE_no = cda.enterprise_no
                 and cda.enterprise_no = strEnterpriseNo
                 and cda.AREA_ATTRIBUTE = '1'
                 and cda.ATTRIBUTE_TYPE = '2'
               order by cdc.cell_no)
       where rownum <= 1;
    exception
      when no_data_found then
        strErrorMsg := 'N|[E3201902]';
        p_write_log(strEnterpriseNo,
                    strWareHouseNo,
                    strWaveNo,
                    '获取出货暂存区失败。',
                    '99');
        return;
    end;
    /*   else
      begin
        select cell_no
          into v_strDestCellNo
          from (select cdc.cell_no
                  from cdef_defcell    cdc,
                       cdef_defarea    cda,
                       Cset_owner_cell coc
                 where cdc.warehouse_no = cda.warehouse_no
                   and cdc.ware_no = cda.ware_no
                   and cdc.area_no = cda.area_no
                   and cdc.enterprise_no = cda.enterprise_no
                   and cdc.enterprise_no = coc.enterprise_no
                   and cda.enterprise_no = strEnterpriseNo
                   and cda.warehouse_no = strWareHouseNo
                   and cda.AREA_ATTRIBUTE = '1'
                   and cda.ATTRIBUTE_TYPE = '2'
                   and cdc.warehouse_no = coc.warehouse_no
                   and coc.owner_no = v_ownerno
                   and cdc.cell_no = coc.cell_no
                 order by cdc.cell_no)
         where rownum <= 1;
      exception
        when no_data_found then
          strErrorMsg := 'N|[E3201902]';
          p_write_log(strEnterpriseNo,
                      strWareHouseNo,
                      strWaveNo,
                      '获取货主【' || v_ownerno || '】出货暂存区失败。',
                      '99');
          return;
      end;
    end if;*/

    --获取系统参数 判断是可以出未验收和未返配的数据
    PKLG_WMS_BASE.p_GetBasePara(strEnterPriseNo,
                                strWareHouseNo,
                                v_ownerno,
                                'Locate_IMConfirmStock',
                                'O',
                                'O_LOCATE',
                                v_strIMConfirmStock,
                                strAllCelln,
                                strErrorMsg);
    if substr(strErrorMsg, 1, 1) = 'N' then
      strErrorMsg := 'N|[E30025]';
      return;
    end if;

    PKLG_WMS_BASE.p_GetBasePara(strEnterPriseNo,
                                strWareHouseNo,
                                v_ownerno,
                                'Locate_RIConfirmStock',
                                'O',
                                'O_LOCATE',
                                v_strRIConfirmStock,
                                strAllCelln,
                                strErrorMsg);
    if substr(strErrorMsg, 1, 1) = 'N' then
      strErrorMsg := 'N|[E30025]';
      return;
    end if;

    --读取定位指示
    v_strOldArticleNo := 'N';
    v_strOldOwnerNo   := 'N';
    v_nLocateQty      := 0;
    for v_cs_locate in (select olm.exp_type,
                               olm.source_type,
                               olm.locate_date,
                               olm.org_no,
                               od.PRIORITY,
                               od.owner_no,
                               od.article_no,
                               case
                                 when od.PRODUCE_CONDITION is null then
                                  'N'
                                 else
                                  od.PRODUCE_CONDITION
                               end as PRODUCE_CONDITION,
                               od.PRODUCE_VALUE1,
                               od.PRODUCE_VALUE2,
                               case
                                 when od.EXPIRE_CONDITION is null then
                                  'N'
                                 else
                                  od.EXPIRE_CONDITION
                               end as EXPIRE_CONDITION,
                               EXPIRE_VALUE1,
                               EXPIRE_VALUE2,
                               case
                                 when od.QUALITY_CONDITION is null then
                                  'N'
                                 else
                                  od.QUALITY_CONDITION
                               end as QUALITY_CONDITION,
                               QUALITY_VALUE1,
                               QUALITY_VALUE2,
                               case
                                 when od.LOTNO_CONDITION is null then
                                  'N'
                                 else
                                  od.LOTNO_CONDITION
                               end as LOTNO_CONDITION,
                               LOTNO_VALUE1,
                               LOTNO_VALUE2,
                               case
                                 when od.SPECIFY_FIELD is null then
                                  'N'
                                 else
                                  od.SPECIFY_FIELD
                               end as SPECIFY_FIELD,
                               SPECIFY_CONDITION,
                               SPECIFY_VALUE1,
                               SPECIFY_VALUE2,

                               od.stock_type,
                               case
                                 when od.stock_type = '1' then
                                  'N'
                                 else
                                  case
                                    when od.stock_type = '2' then
                                     od.cust_no
                                    else
                                     case
                                       when od.stock_type = '3' then
                                        od.exp_no
                                     end
                                  end
                               end as stock_value,
                               sum(od.plan_qty - od.located_qty) as sum_qty
                          from odata_locate_m olm, odata_locate_d od
                         where olm.warehouse_no = od.warehouse_no
                           and olm.enterprise_no = od.enterprise_no
                           and olm.enterprise_no = strEnterpriseNo
                           and olm.wave_no = od.wave_no
                           and od.warehouse_no = strWareHouseNo
                           and od.wave_no = strWaveNo
                           and od.trans_group_no = nGroupNo
                         group by olm.exp_type,
                                  olm.source_type,
                                  olm.locate_date,
                                  olm.org_no,
                                  od.PRIORITY,
                                  od.owner_no,
                                  od.article_no,
                                  case
                                    when od.PRODUCE_CONDITION is null then
                                     'N'
                                    else
                                     od.PRODUCE_CONDITION
                                  end,
                                  od.PRODUCE_VALUE1,
                                  od.PRODUCE_VALUE2,
                                  case
                                    when od.EXPIRE_CONDITION is null then
                                     'N'
                                    else
                                     od.EXPIRE_CONDITION
                                  end,
                                  EXPIRE_VALUE1,
                                  EXPIRE_VALUE2,
                                  case
                                    when od.QUALITY_CONDITION is null then
                                     'N'
                                    else
                                     od.QUALITY_CONDITION
                                  end,
                                  QUALITY_VALUE1,
                                  QUALITY_VALUE2,
                                  case
                                    when od.LOTNO_CONDITION is null then
                                     'N'
                                    else
                                     od.LOTNO_CONDITION
                                  end,
                                  LOTNO_VALUE1,
                                  LOTNO_VALUE2,
                                  case
                                    when od.SPECIFY_FIELD is null then
                                     'N'
                                    else
                                     od.SPECIFY_FIELD
                                  end,
                                  SPECIFY_CONDITION,
                                  SPECIFY_VALUE1,
                                  SPECIFY_VALUE2,
                                  od.stock_type,
                                  case
                                    when od.stock_type = '1' then
                                     'N'
                                    else
                                     case
                                       when od.stock_type = '2' then
                                        od.cust_no
                                       else
                                        case
                                          when od.stock_type = '3' then
                                           od.exp_no
                                        end
                                     end
                                  end
                         order by od.article_no, od.stock_type) loop

      --获取库存临时表序列号
      select SEQ_TMP_STOCK_CONTENT.Nextval into v_nTmpStockID from dual;

      --如果换商品，定位时需要先锁定商品
      if v_strOldArticleNo <> v_cs_locate.article_no then

        --置补货方式
        if v_strOldArticleNo <> 'N' then
          p_setsupp_mode(strEnterpriseNo,
                         strWareHouseNo, --仓库代码
                         strWaveNo, --定位号
                         v_strOldOwnerNo,
                         v_strOldArticleNo, --商品代码
                         strErrorMsg);
          if substr(strErrorMsg, 1, 2) = 'N|' then
            return;
          end if;
        end if;

        v_strOldArticleNo := v_cs_locate.article_no;
        v_strOldOwnerNo   := v_cs_locate.owner_no;
        p_write_log(strEnterpriseNo,
                    strWareHouseNo,
                    strWaveNo,
                    '商品【' || v_strOldArticleNo || '】定位开始。。。',
                    '99');
        update bdef_defarticle b
           set b.status = b.status
         where b.article_no = v_strOldArticleNo;

        --如果之前有定位商品，并且全部定位成功
        if v_strOldArticleNo <> 'N' and v_nLocateQty <= 0 then

          delete from odata_locate_short_log olsl
           where olsl.enterprise_no = strEnterpriseNo
             and olsl.warehouse_no = strWareHouseNo
             and olsl.wave_no = strWaveNo
             and olsl.owner_no = v_cs_locate.owner_no
             and olsl.article_no = v_cs_locate.article_no
             and olsl.trans_group_no = nGroupNo;
        end if;
      end if;

      v_nLocateQty := v_cs_locate.sum_qty;
      --v_nStockRange := 0;
      --根据策略读取规则
      --  RRule_id
      --  1  保拣线按默认规格定位
      --  2  全仓按默认规格定位（不含异常）
      --  3  保拣线按所有规格定位
      --  4  全仓按所有规格定位（不含异常）
      --  5  异常区按默认规格定位
      --  6  异常区按所有规格定位

      --在这里把特殊条件的数据写到临时表 然后在取库存的时候 关联临时表的数据即可
      --条件:1->=；2-<=；3>；4-<；5-=；6-like；7-between；8-优先再其它
      v_strWhere := ' ';

      if v_cs_locate.PRODUCE_CONDITION <> 'N' then
        --生产日期条件

        IF v_cs_locate.PRODUCE_CONDITION = '1' Then
          v_strWhere := v_strWhere ||
                        ' and to_char(sai.PRODUCE_DATE,''yyyy-MM-dd'') >=''' ||
                        to_char(v_cs_locate.PRODUCE_VALUE1, 'yyyy-MM-dd') || '''';
        Elsif v_cs_locate.PRODUCE_CONDITION = '2' Then
          v_strWhere := v_strWhere ||
                        ' and to_char(sai.PRODUCE_DATE,''yyyy-MM-dd'') <=''' ||
                        to_char(v_cs_locate.PRODUCE_VALUE1, 'yyyy-MM-dd') || '''';
        Elsif v_cs_locate.PRODUCE_CONDITION = '3' Then
          v_strWhere := v_strWhere ||
                        ' and to_char(sai.PRODUCE_DATE,''yyyy-MM-dd'') > ''' ||
                        to_char(v_cs_locate.PRODUCE_VALUE1, 'yyyy-MM-dd') || '''';
        Elsif v_cs_locate.PRODUCE_CONDITION = '4' Then
          v_strWhere := v_strWhere ||
                        ' and to_char(sai.PRODUCE_DATE,''yyyy-MM-dd'') < ''' ||
                        to_char(v_cs_locate.PRODUCE_VALUE1, 'yyyy-MM-dd') || '''';
        Elsif v_cs_locate.PRODUCE_CONDITION = '5' Then
          v_strWhere := v_strWhere ||
                        ' and to_char(sai.PRODUCE_DATE,''yyyy-MM-dd'') =''' ||
                        to_char(v_cs_locate.PRODUCE_VALUE1, 'yyyy-MM-dd') || '''';
        Elsif v_cs_locate.PRODUCE_CONDITION = '6' Then
          v_strWhere := v_strWhere ||
                        ' and to_char(sai.PRODUCE_DATE,''yyyy-MM-dd'') Like %''' ||
                        to_char(v_cs_locate.PRODUCE_VALUE1, 'yyyy-MM-dd') ||
                        '%''';
        Elsif v_cs_locate.PRODUCE_CONDITION = '7' Then
          v_strWhere := v_strWhere ||
                        ' and to_char(sai.PRODUCE_DATE,''yyyy-MM-dd'') >=''' ||
                        to_char(v_cs_locate.PRODUCE_VALUE1, 'yyyy-MM-dd') || '''' ||
                        ' and to_char(sai.PRODUCE_DATE,''yyyy-MM-dd'') <=''' ||
                        to_char(v_cs_locate.PRODUCE_VALUE2, 'yyyy-MM-dd') || '''';
        End IF;
      End if;

      IF v_cs_locate.EXPIRE_CONDITION <> 'N' then
        --到期日条件
        IF v_cs_locate.EXPIRE_CONDITION = '1' Then
          v_strWhere := v_strWhere ||
                        ' and to_char(sai.EXPIRE_DATE,''yyyy-MM-dd'') >=''' ||
                        to_char(v_cs_locate.EXPIRE_VALUE1, 'yyyy-MM-dd') || '''';
        Elsif v_cs_locate.EXPIRE_CONDITION = '2' Then
          v_strWhere := v_strWhere ||
                        ' and to_char(sai.EXPIRE_DATE,''yyyy-MM-dd'') <=''' ||
                        to_char(v_cs_locate.EXPIRE_VALUE1, 'yyyy-MM-dd') || '''';
        Elsif v_cs_locate.EXPIRE_CONDITION = '3' Then
          v_strWhere := v_strWhere ||
                        ' and to_char(sai.EXPIRE_DATE,''yyyy-MM-dd'') > ''' ||
                        to_char(v_cs_locate.EXPIRE_VALUE1, 'yyyy-MM-dd') || '''';
        Elsif v_cs_locate.EXPIRE_CONDITION = '4' Then
          v_strWhere := v_strWhere ||
                        ' and to_char(sai.EXPIRE_DATE,''yyyy-MM-dd'') < ''' ||
                        to_char(v_cs_locate.EXPIRE_VALUE1, 'yyyy-MM-dd') || '''';
        Elsif v_cs_locate.EXPIRE_CONDITION = '5' Then
          v_strWhere := v_strWhere ||
                        ' and to_char(sai.EXPIRE_DATE,''yyyy-MM-dd'') =''' ||
                        to_char(v_cs_locate.EXPIRE_VALUE1, 'yyyy-MM-dd') || '''';
        Elsif v_cs_locate.EXPIRE_CONDITION = '6' Then
          v_strWhere := v_strWhere ||
                        ' and to_char(sai.EXPIRE_DATE,''yyyy-MM-dd'') Like %''' ||
                        to_char(v_cs_locate.EXPIRE_VALUE1, 'yyyy-MM-dd') ||
                        '%''';
        Elsif v_cs_locate.EXPIRE_CONDITION = '7' Then
          v_strWhere := v_strWhere ||
                        ' and to_char(sai.EXPIRE_DATE,''yyyy-MM-dd'') >=''' ||
                        to_char(v_cs_locate.EXPIRE_VALUE1, 'yyyy-MM-dd') || '''' ||
                        ' and to_char(sai.EXPIRE_DATE,''yyyy-MM-dd'') <=''' ||
                        to_char(v_cs_locate.EXPIRE_VALUE2, 'yyyy-MM-dd') || '''';
        End IF;
      End if;

      IF v_cs_locate.QUALITY_CONDITION <> 'N' then
        --品质条件
        IF v_cs_locate.QUALITY_CONDITION = '1' Then
          v_strWhere := v_strWhere || ' and sai.QUALITY >=''' ||
                        v_cs_locate.QUALITY_VALUE1 || '''';
        Elsif v_cs_locate.QUALITY_CONDITION = '2' Then
          v_strWhere := v_strWhere || ' and sai.QUALITY <=''' ||
                        v_cs_locate.QUALITY_VALUE1 || '''';
        Elsif v_cs_locate.QUALITY_CONDITION = '3' Then
          v_strWhere := v_strWhere || ' and sai.QUALITY > ''' ||
                        v_cs_locate.QUALITY_VALUE1 || '''';
        Elsif v_cs_locate.QUALITY_CONDITION = '4' Then
          v_strWhere := v_strWhere || ' and sai.QUALITY < ''' ||
                        v_cs_locate.QUALITY_VALUE1 || '''';
        Elsif v_cs_locate.QUALITY_CONDITION = '5' Then
          v_strWhere := v_strWhere || ' and sai.QUALITY =''' ||
                        v_cs_locate.QUALITY_VALUE1 || '''';
        Elsif v_cs_locate.QUALITY_CONDITION = '6' Then
          v_strWhere := v_strWhere || ' and sai.QUALITY Like %''' ||
                        v_cs_locate.QUALITY_VALUE1 || '%''';
        Elsif v_cs_locate.QUALITY_CONDITION = '7' Then
          v_strWhere := v_strWhere || ' and sai.QUALITY >=''' ||
                        v_cs_locate.QUALITY_VALUE1 || '''' ||
                        ' and sai.QUALITY <=''' ||
                        v_cs_locate.QUALITY_VALUE2 || '''';
        End IF;
      End if;

      IF v_cs_locate.LOTNO_CONDITION <> 'N' then
        --批号条件
        IF v_cs_locate.LOTNO_CONDITION = '1' Then
          v_strWhere := v_strWhere || ' and sai.LOT_NO >=''' ||
                        v_cs_locate.LOTNO_VALUE1 || '''';
        Elsif v_cs_locate.LOTNO_CONDITION = '2' Then
          v_strWhere := v_strWhere || ' and sai.LOT_NO <=''' ||
                        v_cs_locate.LOTNO_VALUE1 || '''';
        Elsif v_cs_locate.LOTNO_CONDITION = '3' Then
          v_strWhere := v_strWhere || ' and sai.LOT_NO > ''' ||
                        v_cs_locate.LOTNO_VALUE1 || '''';
        Elsif v_cs_locate.LOTNO_CONDITION = '4' Then
          v_strWhere := v_strWhere || ' and sai.LOT_NO < ''' ||
                        v_cs_locate.LOTNO_VALUE1 || '''';
        Elsif v_cs_locate.LOTNO_CONDITION = '5' Then
          v_strWhere := v_strWhere || ' and sai.LOT_NO =''' ||
                        v_cs_locate.LOTNO_VALUE1 || '''';
        Elsif v_cs_locate.LOTNO_CONDITION = '6' Then
          v_strWhere := v_strWhere || ' and sai.LOT_NO Like %''' ||
                        v_cs_locate.LOTNO_VALUE1 || '%''';
        Elsif v_cs_locate.LOTNO_CONDITION = '7' Then
          v_strWhere := v_strWhere || ' and sai.LOT_NO >=''' ||
                        v_cs_locate.LOTNO_VALUE1 || '''' ||
                        ' and sai.LOT_NO <=''' || v_cs_locate.LOTNO_VALUE2 || '''';
        End IF;
      End if;

      IF v_cs_locate.SPECIFY_FIELD <> 'N' then
        IF v_cs_locate.SPECIFY_CONDITION = '1' Then
          v_strWhere := v_strWhere || ' and sc.' ||
                        v_cs_locate.SPECIFY_FIELD || ' >=''' ||
                        v_cs_locate.SPECIFY_VALUE1 || '''';
        Elsif v_cs_locate.SPECIFY_CONDITION = '2' Then
          v_strWhere := v_strWhere || ' and sc.' ||
                        v_cs_locate.SPECIFY_FIELD || ' <=''' ||
                        v_cs_locate.SPECIFY_VALUE1 || '''';
        Elsif v_cs_locate.SPECIFY_CONDITION = '3' Then
          v_strWhere := v_strWhere || ' and sc.' ||
                        v_cs_locate.SPECIFY_FIELD || ' > ''' ||
                        v_cs_locate.SPECIFY_VALUE1 || '''';
        Elsif v_cs_locate.SPECIFY_CONDITION = '4' Then
          v_strWhere := v_strWhere || ' and sc.' ||
                        v_cs_locate.SPECIFY_FIELD || ' <''' ||
                        v_cs_locate.SPECIFY_VALUE1 || '''';
        Elsif v_cs_locate.SPECIFY_CONDITION = '5' Then
          v_strWhere := v_strWhere || ' and sc.' ||
                        v_cs_locate.SPECIFY_FIELD || ' =''' ||
                        v_cs_locate.SPECIFY_VALUE1 || '''';
        Elsif v_cs_locate.SPECIFY_CONDITION = '6' Then
          v_strWhere := v_strWhere || ' and sc.' ||
                        v_cs_locate.SPECIFY_FIELD || ' like %''' ||
                        v_cs_locate.SPECIFY_VALUE1 || '%''';
        Elsif v_cs_locate.SPECIFY_CONDITION = '7' Then
          v_strWhere := v_strWhere || ' and sc.' ||
                        v_cs_locate.SPECIFY_FIELD || ' >=''' ||
                        v_cs_locate.SPECIFY_VALUE1 || '''' || ' and sc.' ||
                        v_cs_locate.SPECIFY_FIELD || ' <=''' ||
                        v_cs_locate.SPECIFY_VALUE2 || '''';
        End IF;
      end if;

      --MM 141024 批次类型为8优先出的,特殊处理
      if v_cs_locate.LOTNO_CONDITION = '8' Then
        v_strSQL := 'Insert into TMP_STOCK_CONTENT(tmp_id,Enterprise_No,warehouse_no,cell_no,cell_id,SERIAL_FLAG)
                   select ' || v_nTmpStockID ||
                    ', sc.Enterprise_No,sc.warehouse_no,sc.cell_no,sc.cell_id,0
                   From STOCK_CONTENT sc,STOCK_ARTICLE_INFO sai,cdef_defarea ca,cdef_defcell cc,cdef_defware cw
                   where sc.ARTICLE_NO=sai.ARTICLE_NO and sc.ARTICLE_ID=sai.ARTICLE_ID
                         and sc.warehouse_no=ca.warehouse_no and sc.warehouse_no=cc.warehouse_no
                         and sc.enterprise_no=ca.enterprise_no and sc.enterprise_no=cc.enterprise_no
                         and sc.enterprise_no=sai.enterprise_no and sc.enterprise_no= ''' ||
                    strEnterpriseNo || '''
                         and sc.cell_no=cc.cell_no and cc.ware_no=ca.ware_no and cc.area_no=ca.area_no
                         and cw.ENTERPRISE_NO=ca.ENTERPRISE_NO and cw.WAREHOUSE_NO=ca.WAREHOUSE_NO
                         and cw.WARE_NO=ca.WARE_NO
                         and cw.ORG_NO=''' ||v_cs_locate.org_no|| '''
                         and ca.area_usetype in(''1'',''5'',''6'') and ca.AREA_ATTRIBUTE=''0'' and ca.ATTRIBUTE_TYPE=''0''
                         and sc.article_no=''' ||
                    v_cs_locate.article_no || '''
                         and sc.owner_no =''' ||
                    v_cs_locate.owner_no || ''' and sc.WareHouse_No =''' ||
                    strWareHouseNo || '''
                         and sai.LOT_NO >=''' ||
                    v_cs_locate.LOTNO_VALUE1 || '''' ||
                    ' and sai.LOT_NO <=''' || v_cs_locate.LOTNO_VALUE2 || '''';

        execute immediate v_strSQL;

      end if;

      --指定字段优先出库
      if v_cs_locate.SPECIFY_FIELD <> 'N' and
         v_cs_locate.SPECIFY_CONDITION = '8' then
        v_strSQL := 'Insert into TMP_STOCK_CONTENT(tmp_id,Enterprise_No,warehouse_no,cell_no,cell_id,SERIAL_FLAG)
                   select  ' || v_nTmpStockID ||
                    ', sc.Enterprise_No,sc.warehouse_no,sc.cell_no,sc.cell_id,0
                   From STOCK_CONTENT sc,STOCK_ARTICLE_INFO sai,cdef_defarea ca,cdef_defcell cc,cdef_defware cw
                   where sc.ARTICLE_NO=sai.ARTICLE_NO and sc.ARTICLE_ID=sai.ARTICLE_ID
                         and sc.warehouse_no=ca.warehouse_no and sc.warehouse_no=cc.warehouse_no
                         and sc.enterprise_no=ca.enterprise_no and sc.enterprise_no=cc.enterprise_no
                         and sc.enterprise_no=sai.enterprise_no and sc.enterprise_no= ''' ||
                    strEnterpriseNo || '''
                         and sc.cell_no=cc.cell_no and cc.ware_no=ca.ware_no and cc.area_no=ca.area_no
                         and cw.ENTERPRISE_NO=ca.ENTERPRISE_NO and cw.WAREHOUSE_NO=ca.WAREHOUSE_NO
                         and cw.WARE_NO=ca.WARE_NO
                         and cw.ORG_NO=''' ||v_cs_locate.org_no|| '''
                         and ca.area_usetype in(''1'',''5'',''6'') and ca.AREA_ATTRIBUTE=''0'' and ca.ATTRIBUTE_TYPE=''0''
                         and sc.article_no=''' ||
                    v_cs_locate.article_no || '''
                         and sc.owner_no =''' ||
                    v_cs_locate.owner_no || ''' and sc.WareHouse_No =''' ||
                    strWareHouseNo || '''
                         and sc.' ||
                    v_cs_locate.SPECIFY_FIELD || ' >=''' ||
                    v_cs_locate.SPECIFY_VALUE1 || '''' || ' and sc.' ||
                    v_cs_locate.SPECIFY_FIELD || ' <=''' ||
                    v_cs_locate.SPECIFY_VALUE2 || '''';
        execute immediate v_strSQL;

        --客户配量
        v_nAllotID := -1;
        PKLG_PUBLOCATE.p_locate_allot_OM(v_nTmpStockID,
                                         strEnterPriseNo,
                                         strWareHouseNo,
                                         strWaveNo,
                                         nGroupNo,
                                         v_cs_locate.article_no,
                                         v_cs_locate.stock_type,
                                         v_cs_locate.stock_value,
                                         v_nLocateQty,
                                         v_nAllotID,
                                         strErrorMsg);
        if substr(strErrorMsg, 1, 1) = 'N' then
          strErrorMsg := 'N|[配量失败]';
          return;
        end if;

        --指定货位出货,先指定出库出库,再正常出库
        for v_cs_stock in (select sc.owner_no,sc.cell_no,
                                  sc.dept_no,
                                  sc.packing_qty,
                                  sai.produce_date,
                                  sai.quality,
                                  sai.lot_no,
                                  sc.stock_type,
                                  sc.stock_value,
                                  sum(sc.QTY - sc.OUTSTOCK_QTY +
                                      (case sc.Instock_Type
                                        when '1' then
                                         sc.INSTOCK_QTY
                                        else
                                         0
                                      end) + sc.UNUSUAL_QTY) AS S_QTY
                             from cdef_defware       cdw,
                                  cdef_defcell       cdc,
                                  odata_locate_m     olm,
                                  STOCK_CONTENT      sc,
                                  TMP_STOCK_CONTENT  tsc,
                                  stock_article_info sai
                            where cdw.enterprise_no = cdc.enterprise_no
                              and cdw.warehouse_no = cdc.warehouse_no
                              and cdw.ware_no = cdc.warehouse_no
                              and cdw.org_no = olm.org_no
                              and cdc.enterprise_no = sc.enterprise_no
                              and cdc.warehouse_no = sc.warehouse_no
                              and cdc.cell_no = sc.cell_no
                              and sai.article_no = sc.article_no
                              and sai.article_id = sc.article_id
                              and sai.enterprise_no = sc.enterprise_no
                              and sc.enterprise_no = tsc.enterprise_no
                              and sc.warehouse_no = tsc.warehouse_no
                              and sc.cell_no = tsc.cell_no
                              and sc.cell_id = tsc.cell_id
                              and tsc.enterprise_no = olm.enterprise_no
                              and tsc.warehouse_no = olm.warehouse_no
                              and olm.enterprise_no = strEnterpriseNo
                              and olm.warehouse_no = strWareHouseNo
                              and olm.wave_no = strWaveNo
                              and tsc.tmp_id = v_nTmpStockID
                            group by sc.owner_no,sc.cell_no,
                                     sc.dept_no,
                                     sc.packing_qty,
                                     sai.produce_date,
                                     sai.quality,
                                     sai.lot_no,
                                     sc.stock_type,
                                     sc.stock_value) loop

          p_write_direct(v_nTmpStockID,
                         v_nAllotID,
                         strEnterpriseNo,
                         strWareHouseNo,
                         v_cs_stock.owner_no, --货主代码
                         strWaveNo, --定位号
                         nGroupNo, --出货组号
                         v_strDestCellNo, --目的储位
                         'C', --定位类型
                         'N', --定位批次
                         v_cs_locate.article_no, --商品代码
                         v_cs_stock.Cell_No,
                         v_cs_stock.Dept_No,
                         'N', --v_cs_stock.Container_No,
                         v_cs_stock.Packing_Qty,
                         '1',
                         v_cs_stock.Produce_Date,
                         v_cs_stock.Quality, --商品品质
                         v_cs_stock.Lot_No,
                         --v_cs_stock.Supplier_No,
                         v_cs_stock.stock_type, --库存性质
                         v_cs_stock.stock_value, --库存值
                         v_cs_stock.s_qty,
                         v_nLocateQty, --定位量
                         strWorkNo, --员工代码
                         v_cs_locate.exp_type, --单据类型
                         strErrorMsg);

        end loop;
        delete from TMP_STOCK_CONTENT
         where enterprise_no = strEnterpriseNo
           and warehouse_no = strWareHouseNo
           and tmp_id = v_nTmpStockID;

        --删除本次配量结果
        delete from middata_allot_detail md
         where md.warehouse_no = strWareHouseNo
           and md.enterprise_no = strEnterPriseNo
           and md.source_no = strWaveNo
           and md.article_no = v_cs_locate.article_no
           and md.tmp_id = v_nAllotID;

      end if;

      v_strSQL := 'Insert into TMP_STOCK_CONTENT(tmp_id,Enterprise_No,warehouse_no,cell_no,cell_id,SERIAL_FLAG)
                   select ' || v_nTmpStockID ||
                  ',  sc.Enterprise_No,sc.warehouse_no,sc.cell_no,sc.cell_id,1
                   From STOCK_CONTENT sc,STOCK_ARTICLE_INFO sai,cdef_defarea ca,cdef_defcell cc,cdef_defware cw
                   where sc.ARTICLE_NO=sai.ARTICLE_NO and sc.ARTICLE_ID=sai.ARTICLE_ID
                         and sc.warehouse_no=ca.warehouse_no and sc.warehouse_no=cc.warehouse_no
                         and sc.enterprise_no=ca.enterprise_no and sc.enterprise_no=cc.enterprise_no
                         and sc.enterprise_no=sai.enterprise_no and sc.enterprise_no= ''' ||
                  strEnterpriseNo || '''
                         and sc.cell_no=cc.cell_no and cc.ware_no=ca.ware_no and cc.area_no=ca.area_no
                         and cw.ENTERPRISE_NO=ca.ENTERPRISE_NO and cw.WAREHOUSE_NO=ca.WAREHOUSE_NO
                         and cw.WARE_NO=ca.WARE_NO
                         and cw.ORG_NO=''' ||v_cs_locate.org_no|| '''
                         and ca.area_usetype in(''1'',''5'',''6'',''7'') and ca.AREA_ATTRIBUTE=''0'' and ca.ATTRIBUTE_TYPE=''0''
                         and not exists(select ''1'' from TMP_STOCK_CONTENT tsc where tsc.warehouse_no=sc.warehouse_no
                         and tsc.Enterprise_No=sc.Enterprise_No and tsc.cell_no=sc.cell_no and tsc.cell_id=sc.cell_id and tsc.tmp_id =  ''' ||
                  v_nTmpStockID ||
                  '''  )
                         and ca.item_type = ''0''
                         and sc.article_no=''' ||
                  v_cs_locate.article_no || '''
                         and sc.owner_no =''' ||
                  v_cs_locate.owner_no || ''' and sc.WareHouse_No =''' ||
                  strWareHouseNo || '''
                  AND (''' || v_strIMConfirmStock ||
                  ''' = ''1'' or
                      (''' || v_strIMConfirmStock ||
                  ''' = ''0'' and
                      NOT EXISTS
                       (select ''x''
                           from IDATA_check_m icm
                          where sai.import_batch_no =
                                icm.check_no
                            and icm.WAREHOUSE_NO = ''' ||
                  strWareHouseNo || '''
                            and icm.status < ''13''
                            and icm.enterprise_no = ''' ||
                  strEnterPriseNo || ''')))
                  AND (''' || v_strRIConfirmStock ||
                  ''' = ''1'' or
                      (''' || v_strRIConfirmStock ||
                  ''' = ''0'' and
                      NOT EXISTS
                       (select ''x''
                           from RIDATA_check_m ucm
                          where sai.import_batch_no =
                                ucm.check_no
                            and ucm.WAREHOUSE_NO = ''' ||
                  strWareHouseNo || '''
                            and ucm.status < ''13''
                            and ucm.enterprise_no = ''' ||
                  strEnterPriseNo || ''')))' || v_strWhere;

      --记录临时表库存sql
      p_write_log(strEnterpriseNo,
                  strWareHouseNo,
                  strWaveNo,
                  v_strSQL,
                  '10');

      execute immediate v_strSQL;

      --读取商品出货策略取规则
      select nvl(O_STRATEGY, '1')
        into v_strOStrategy
        from bdef_defarticle a
       where article_no = v_cs_locate.article_no
         AND a.enterprise_no = strEnterpriseNo;

      for GetRule in (select wdd.Rule_id
                        from WMS_DEFSTRATEGY_D wdd, WMS_DEFSTRATEGY wd
                       where wdd.strategy_type = wd.strategy_type
                         and wdd.strategy_id = wd.strategy_id
                         and wd.strategy_id = v_strOStrategy
                         and wd.strategy_type = 'O'
                       order by wdd.rule_order) loop
        p_locate_article(v_nTmpStockID,
                         strEnterPriseNo,
                         strWareHouseNo, --仓库代码
                         strWaveNo, --定位号
                         nGroupNo, --出货组号
                         v_strMinBatchNo, --最小批次号
                         v_strDestCellNo,
                         v_cs_locate.owner_no,
                         v_cs_locate.article_no, --商品代码
                         GetRule.Rule_id,
                         v_cs_locate.Source_Type,
                         v_cs_locate.exp_type,
                         v_cs_locate.Priority,
                         v_cs_locate.Locate_Date,
                         --v_cs_locate.Condition, --特殊条件(预留)
                         v_cs_locate.Stock_Type, --库存性质
                         v_cs_locate.stock_value, --库存值
                         --v_cs_locate.Quality, --商品品质
                         v_nLocateQty, --定位量
                         strWorkNo, --员工代码
                         v_nAllotID,
                         strErrorMsg);

        --删除本次配量结果
        delete from middata_allot_detail md
         where md.warehouse_no = strWareHouseNo
           and md.enterprise_no = strEnterPriseNo
           and md.source_no = strWaveNo
           and md.article_no = v_cs_locate.article_no
           and md.tmp_id = v_nAllotID;

        if substr(strErrorMsg, 1, 2) = 'N|' then
          return;
        end if;

       --一旦出现要定位的数量与剩余的定位量不相符，则整单没有定到位不成立
        if v_nLocateQty <> v_cs_locate.sum_qty then
          blAllShortLocFlag := false;
        end if;

        if v_nLocateQty <= 0 then
          exit;
        end if;

      --如果没有定位完成，保拣线定完后，再定全仓
      --if v_nStockRange = 0 then
      --  v_nStockRange := 1;
      --else
      --  exit;
      --end if;
      end loop;

      -- 删除临时表数据
      delete from TMP_STOCK_CONTENT
       where enterprise_no = strEnterpriseNo
         AND warehouse_no = strWareHouseNo
         and tmp_id = v_nTmpStockID;

      <<next_v_cs_locate>>
      null;

      --如果出现还有剩余定位量，说明有缺量
      if v_nLocateQty > 0 then
        blPartShortLocFlag := true;
      end if;

    end loop;

    --置补货方式
    if v_strOldArticleNo <> 'N' then
      p_setsupp_mode(strEnterpriseNo,
                     strWareHouseNo, --仓库代码
                     strWaveNo, --定位号
                     v_strOldOwnerNo,
                     v_strOldArticleNo, --商品代码
                     strErrorMsg);
      if substr(strErrorMsg, 1, 2) = 'N|' then
        return;
      end if;
    end if;

    /*    --如果之前有定位商品，并且全部定位成功
    if v_strOldArticleNo <> 'N' and v_nLocateQty <= 0 then

      delete from odata_locate_short_log olsl
       where olsl.enterprise_no = strEnterpriseNo
         and olsl.warehouse_no = strWareHouseNo
         and olsl.wave_no = strWaveNo
         and olsl.article_no = v_strOldArticleNo
         and olsl.trans_group_no = nGroupNo;
    end if;*/

  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_locate_group;

  --商品定位
  procedure p_locate_article(v_nTmpStockID   in number,
                             strEnterPriseNo in odata_locate_m.enterprise_no%type,
                             strWareHouseNo  in varchar2, --仓库代码
                             strWaveNo       in varchar2, --定位号
                             nGroupNo        in number, --出货组号
                             strMinBatchNo   in varchar2, --最小批次号
                             strDestCellNo   in varchar2,
                             strOwnerNo      in varchar2,
                             strArticleNo    in varchar2, --商品代码
                             nStockRange     in number, --库存范围
                             strSourceType   in varchar2,
                             Strexptype      in varchar2,
                             strPriority     in varchar2,
                             dtLocateDate    in date,
                             --strCondition   in varchar2, --特殊条件(预留)
                             --strItemType    in varchar2, --商品属性
                             strStockType  in varchar2, --库存性质
                             strStockValue in varchar2, --库存值
                             --strQuality     in varchar2, --商品品质
                             nLocateQty  in out number, --定位量
                             strWorkNo   in varchar2, --员工代码
                             v_nAllotID  out number,
                             strErrorMsg out varchar2) is

    v_nOldLocateQty odata_locate_d.plan_qty%type;
    v_nBSuppQty     odata_locate_d.plan_qty%type; --B型补货量

    v_nMinSuppQty odata_locate_d.plan_qty%type; --最小补货量

    v_nCSuppQty    odata_locate_d.plan_qty%type; --C型补货量
    v_nRealSuppQty odata_locate_d.plan_qty%type; --实际已补量

    v_nPalleteQty   bdef_article_packing.packing_qty%type;
    v_strSuppStatus odata_outstock_direct.status%type;
    --v_nMustMinFlag  number(1);

    v_blSuppFlag           boolean;
    v_strBrepLenishType    cdef_defarea.B_REPLENISH_TYPE%type;
    v_strCrepLenishType    cdef_defarea.C_REPLENISH_TYPE%type;
    v_strBrepLenishRule    cdef_defarea.b_replenish_rule%type;
    v_strCrepLenishRule    cdef_defarea.c_replenish_rule%type;
    v_strPFlag             odata_locate_batch.p_flag%type;
    v_strMFlag             odata_locate_batch.m_flag%type;
    v_strDFlag             odata_locate_batch.d_flag%type;
    v_strBDivideFlag       odata_locate_batch.b_divide_flag%type;
    v_strCDivideFlag       odata_locate_batch.c_divide_flag%type;
    v_strCpickFrombackArea wms_defbase.sdefine%type;
    v_strOperateType       odata_outstock_direct.operate_type%type;
    strAllCelln            wms_defbase.sdefine%type;

    v_strCPickCellNo cset_cell_article.cell_no%type;
    v_nCMaxQty       cset_cell_article.max_qty_a%type;
    v_nCKeepCells    cset_cell_article.keep_cells%type;
    v_strBPickCellNo cset_cell_article.cell_no%type;
    v_nBMaxQty       cset_cell_article.max_qty_a%type;
    v_nBKeepCells    cset_cell_article.keep_cells%type;
    v_nPickLine      cset_cell_article.line_id%type;
    --v_nMaxPackQty     stock_content.packing_qty%type; --最大包装
    --v_nCanUseStockQty number; --全库可用库存
    v_nPickCellCount number;
    i                number;

  begin
    strErrorMsg := 'Y|';

    PKLG_PUBLOCATE.p_get_PickCell(strEnterPriseNo,
                                  strWareHouseNo,
                                  strOwnerNo,
                                  strArticleNo,
                                  v_strCPickCellNo,
                                  v_nCMaxQty,
                                  v_nCKeepCells,
                                  v_strBPickCellNo,
                                  v_nBMaxQty,
                                  v_nBKeepCells,
                                  v_nPickLine,
                                  v_nPickCellCount,
                                  strErrorMsg);

    if substr(strErrorMsg, 1, 1) = 'N' then
      return;
    end if;

    p_write_log(strEnterpriseNo,
                strWareHouseNo,
                strWaveNo,
                '商品【' || strArticleNo || '】箱拣货位【' || v_strCPickCellNo || '】【' ||
                v_nCMaxQty || '】,拆零货位【' || v_strBPickCellNo || '】【' ||
                v_nBMaxQty || '】',
                '10');

    --获取补货方式参数
    --v_strBREPLENISHTYPE,v_strCREPLENISHTYPE(1：一次性补足；2：循环补货；3：批次间补货)

    begin
      select distinct cd.B_REPLENISH_TYPE, cd.B_REPLENISH_RULE
        into v_strBrepLenishType, v_strBrepLenishRule
        from cdef_defarea cd, cdef_defcell cca
       where cd.WAREHOUSE_NO = cca.WAREHOUSE_NO
         and cd.enterprise_no = cca.enterprise_no
         and cd.WARE_NO = cca.WARE_NO
         and cd.AREA_NO = cca.AREA_NO
         and cca.enterprise_no = strEnterPriseNo
         and cca.WAREHOUSE_NO = strWareHouseNo
         and cca.cell_no like v_strBPickCellNo || '%';
    exception
      when no_data_found then
        v_strBrepLenishType := '1';
    end;

    begin
      select distinct cd.C_REPLENISH_TYPE, cd.C_REPLENISH_RULE
        into v_strCrepLenishType, v_strCrepLenishRule
        from cdef_defarea cd, cdef_defcell cca
       where cd.WAREHOUSE_NO = cca.WAREHOUSE_NO
         and cd.enterprise_no = cca.enterprise_no
         and cd.WARE_NO = cca.WARE_NO
         and cd.AREA_NO = cca.AREA_NO
         and cca.enterprise_no = strEnterPriseNo
         and cca.WAREHOUSE_NO = strWareHouseNo
         and cca.cell_no like v_strCPickCellNo || '%';
    exception
      when no_data_found then
        v_strCrepLenishType := '1';
    end;

    --获取定位出货标识
    begin
      select lb.p_Flag,
             lb.m_flag,
             lb.d_flag,
             lb.b_divide_flag,
             lb.c_divide_flag
        into v_strPFlag,
             v_strMFlag,
             v_strDFlag,
             v_strBDivideFlag,
             v_strCDivideFlag
        from odata_locate_m lm, odata_locate_batch lb
       where lm.enterprise_no = strEnterpriseNo
         and lm.warehouse_no = strWareHouseNo
         and lm.wave_no = strWaveNo
         and lm.enterprise_no = lb.enterprise_no
         and lm.warehouse_no = lb.warehouse_no
         and lm.wave_no = lb.wave_no
         and rownum = 1;
    exception
      when no_data_found then
        strErrorMsg := 'N|[找不到对应的批次信息]';
        return;
    end;

    --按保拣线定位时，若重型货架、立库或驶入货架区域根据参数判断保管区是否允许箱拣
    PKLG_WMS_BASE.p_GetBasePara(strEnterPriseNo,
                                strWareHouseNo,
                                strOwnerNo,
                                'Locate_PickFlag',
                                'O',
                                'O_LOCATE',
                                v_strCpickFrombackArea,
                                strAllCelln,
                                strErrorMsg);
    if substr(strErrorMsg, 1, 1) = 'N' then
      strErrorMsg := 'N|[E30025]';
      return;
    end if;

    p_write_log(strEnterpriseNo,
                strWareHouseNo,
                strWaveNo,
                '商品【' || strArticleNo || '】配量开始',
                '10');

    --客户配量
    v_nAllotID := -1;
    PKLG_PUBLOCATE.p_locate_allot_OM(v_nTmpStockID,
                                     strEnterPriseNo,
                                     strWareHouseNo,
                                     strWaveNo,
                                     nGroupNo,
                                     strArticleNo,
                                     strStockType,
                                     strStockValue,
                                     nLocateQty,
                                     v_nAllotID,
                                     strErrorMsg);
    if substr(strErrorMsg, 1, 1) = 'N' then
      strErrorMsg := 'N|[配量失败]' || strErrorMsg;
      return;
    end if;

    p_write_log(strEnterpriseNo,
                strWareHouseNo,
                strWaveNo,
                '商品【' || strArticleNo || '】配量成功',
                '10');

    --P型定位
    if v_strPFlag = '1' then

      p_write_log(strEnterpriseNo,
                  strWareHouseNo,
                  strWaveNo,
                  '商品【' || strArticleNo || '】定位P型',
                  '10');

      p_locate_article_otype(v_nTmpStockID,
                             v_nAllotID,
                             strEnterPriseNo,
                             strWareHouseNo, --仓库代码
                             strOwnerNo,
                             strWaveNo, --定位号
                             nGroupNo, --出货组号
                             'P', --定位类型
                             strDestCellNo,
                             'N',
                             strArticleNo, --商品代码
                             nStockRange,
                             v_nPickLine,
                             v_nPickCellCount,
                             v_strCPickCellNo,
                             v_strBPickCellNo,
                             --strCondition, --特殊条件
                             --strItemType, --商品属性
                             strStockType, --库存性质
                             strStockValue, --库存值
                             --strQuality, --商品品质
                             nLocateQty, --定位量
                             strWorkNo, --员工代码
                             Strexptype, --单据类型
                             strErrorMsg);
      if substr(strErrorMsg, 1, 2) = 'N|' then
        return;
      end if;

      if nLocateQty <= 0 then
        return;
      end if;
    end if;

    --M型定位
    if v_strMFlag = '1' and v_strCDivideFlag <> '0' then

      p_write_log(strEnterpriseNo,
                  strWareHouseNo,
                  strWaveNo,
                  '商品【' || strArticleNo || '】定位M型',
                  '10');

      p_locate_article_otype(v_nTmpStockID,
                             v_nAllotID,
                             strEnterPriseNo,
                             strWareHouseNo, --仓库代码
                             strOwnerNo,
                             strWaveNo, --定位号
                             nGroupNo, --出货组号
                             'M', --定位类型
                             strDestCellNo,
                             'N',
                             strArticleNo, --商品代码
                             nStockRange,
                             v_nPickLine,
                             v_nPickCellCount,
                             v_strCPickCellNo,
                             v_strBPickCellNo,
                             --strCondition, --特殊条件
                             --strItemType, --商品属性
                             strStockType, --库存性质
                             strStockValue, --库存值
                             --strQuality, --商品品质
                             nLocateQty, --定位量
                             strWorkNo, --员工代码
                             Strexptype, --单据类型
                             strErrorMsg);
      if substr(strErrorMsg, 1, 2) = 'N|' then
        return;
      end if;

      if nLocateQty <= 0 then
        return;
      end if;
    end if;

    --允许保管位出箱，先定一次箱型
    if v_strCpickFrombackArea = '1' then
      --先出C，再出D
      i := 1;
      for i in 1 .. 2 loop

        if i = 1 then
          v_strOperateType := 'C';
        else
          v_strOperateType := 'D';
        end if;

        p_write_log(strEnterpriseNo,
                    strWareHouseNo,
                    strWaveNo,
                    '商品【' || strArticleNo || '】定位' || v_strOperateType || '型',
                    '10');

        p_locate_article_otype(v_nTmpStockID,
                               v_nAllotID,
                               strEnterPriseNo,
                               strWareHouseNo, --仓库代码
                               strOwnerNo,
                               strWaveNo, --定位号
                               nGroupNo, --出货组号
                               v_strOperateType, --定位类型
                               strDestCellNo,
                               'N',
                               strArticleNo, --商品代码
                               nStockRange,
                               v_nPickLine,
                               v_nPickCellCount,
                               v_strCPickCellNo,
                               v_strBPickCellNo,
                               --strCondition, --特殊条件
                               --strItemType, --商品属性
                               strStockType, --库存性质
                               strStockValue, --库存值
                               --strQuality, --商品品质
                               nLocateQty, --定位量
                               strWorkNo, --员工代码
                               Strexptype, --单据类型
                               strErrorMsg);
        if substr(strErrorMsg, 1, 2) = 'N|' then
          return;
        end if;

        if nLocateQty <= 0 then
          return;
        end if;

        --不可出D，退出循环
        if v_strDFlag = 0 or v_strBDivideFlag = '0' then
          exit;
        end if;
      end loop;
    end if;

    --B型一次性补足，先补货
    if v_strBrepLenishType = '1' and v_strBPickCellNo <> 'N' then
      v_nBSuppQty   := 0;
      v_nMinSuppQty := 0;
      --计算拆零补货量
      p_calculate_suppQty(v_nTmpStockID,
                          strEnterPriseNo,
                          strWareHouseNo, --仓库代码
                          strWaveNo, --定位号
                          nGroupNo, --出货组号
                          strArticleNo, --商品代码
                          'B',
                          v_strBPickCellNo,
                          v_strCPickCellNo,
                          v_strDFlag,
                          v_nCMaxQty,
                          v_nBMaxQty,
                          v_strBrepLenishRule,
                          v_strCrepLenishRule,
                          --strCondition, --特殊条件
                          --strItemType, --商品属性
                          strStockType, --库存性质
                          --strQuality, --商品品质
                          nLocateQty, --定位量
                          v_nBSuppQty,
                          v_nMinSuppQty,
                          strErrorMsg);

       if substr(strErrorMsg, 1, 2) = 'N|' then
          return;
        end if;

      if v_nBSuppQty > 0 then
        --补货
        p_write_log(strEnterpriseNo,
                    strWareHouseNo,
                    strWaveNo,
                    '商品【' || strArticleNo || '】需要做【B】型补货，要求补货量为【' ||
                    v_nBSuppQty || '】',
                    '10');
        v_strSuppStatus := '10';
        v_nRealSuppQty  := 0;
        PKLG_MLOCATE.p_supply_article(v_nTmpStockID,
                                      strEnterPriseNo,
                                      strWareHouseNo, --仓库代码
                                      strOwnerNo,
                                      strWaveNo, --定位号
                                      strMinBatchNo, --批次号
                                      v_strSuppStatus,
                                      'B', --作业类型
                                      '1', --出货类型
                                      strSourceType, --来源类型
                                      v_strCPickCellNo,
                                      v_nCMaxQty,
                                      V_nCKeepCells,
                                      v_strBPickCellNo,
                                      v_nBMaxQty,
                                      v_nBKeepCells,
                                      v_nPickLine,
                                      v_nPickCellCount,
                                      strStockType, --库存性质
                                      strStockValue, --库存值
                                      strPriority,
                                      dtLocateDate,
                                      strArticleNo, --商品代码
                                      v_nBSuppQty,
                                      v_nMinSuppQty,
                                      v_nRealSuppQty,
                                      1,
                                      strWorkNo, --员工代码
                                      nStockRange,
                                      strErrorMsg);
        if substr(strErrorMsg, 1, 2) = 'N|' then
          return;
        end if;
      end if;
    end if;

    --循环补货；后续做处理，通过库存量以及触发量来设置指示状态
    --if v_strBrepLenishType = '2' then
    --暂不支持
    --end if;

    --批次间补货
    --if v_strBrepLenishType = '3' then
    --暂不支持
    --end if;

    --D型定位:暂不支持

    --C型定位
    begin
      select nvl(bwp.QPALETTE, bap.QPALETTE)
        into v_nPalleteQty
        from bdef_article_packing bap
        left join bdef_warehouse_packing bwp
          on bwp.enterprise_no = bap.enterprise_no
         and bwp.article_no = bap.article_no
         and bwp.packing_qty = bap.packing_qty
         and bwp.warehouse_no = strWareHouseNo
         and bwp.enterprise_no = strEnterPriseNo
       where bap.article_no = strArticleNo
         and bap.packing_qty in
             (select nvl(max(sc.packing_qty), max(bap.packing_qty))
                from bdef_article_packing bap
                left join stock_content sc
                  on sc.warehouse_no = strWareHouseNo
                 and sc.article_no = bap.article_no
                 and sc.enterprise_no = bap.enterprise_no
                 and sc.enterprise_no = strEnterPriseNo
               where bap.article_no = strArticleNo)
         and bap.enterprise_no = strEnterPriseNo;
    exception
      when no_data_found then
        v_nPalleteQty := 999999;
    end;

    --C型一次性补足
    if v_strCrepLenishType = 1 then

      --先出C，再出D
      i := 1;
      for i in 1 .. 2 loop

        if i = 1 then
          v_strOperateType := 'C';
        else
          v_strOperateType := 'D';
        end if;

        p_write_log(strEnterpriseNo,
                    strWareHouseNo,
                    strWaveNo,
                    '商品【' || strArticleNo || '】定位' || v_strOperateType || '型',
                    '10');

        p_locate_article_otype(v_nTmpStockID,
                               v_nAllotID,
                               strEnterPriseNo,
                               strWareHouseNo, --仓库代码
                               strOwnerNo,
                               strWaveNo, --定位号
                               nGroupNo, --出货组号
                               v_strOperateType, --定位类型
                               strDestCellNo,
                               'N',
                               strArticleNo, --商品代码
                               nStockRange,
                               v_nPickLine,
                               v_nPickCellCount,
                               v_strCPickCellNo,
                               v_strBPickCellNo,
                               --strCondition, --特殊条件
                               --strItemType, --商品属性
                               strStockType, --库存性质
                               strStockValue, --库存值
                               --strQuality, --商品品质
                               nLocateQty, --定位量
                               strWorkNo, --员工代码
                               Strexptype, --单据类型
                               strErrorMsg);
        if substr(strErrorMsg, 1, 2) = 'N|' then
          return;
        end if;

        if nLocateQty <= 0 then
          return;
        end if;

        --不可出D，退出循环
        if v_strDFlag = 0 or v_strBDivideFlag = '0' then
          exit;
        end if;
      end loop;

      v_nCSuppQty   := 0;
      v_nMinSuppQty := 0;
      if v_strCPickCellNo <> 'N' then
        --计算箱补货量
        p_calculate_suppQty(v_nTmpStockID,
                            strEnterPriseNo,
                            strWareHouseNo, --仓库代码
                            strWaveNo, --定位号
                            nGroupNo, --出货组号
                            strArticleNo, --商品代码
                            'C',
                            v_strBPickCellNo,
                            v_strCPickCellNo,
                            v_strDFlag,
                            v_nCMaxQty,
                            v_nBMaxQty,
                            v_strBrepLenishRule,
                            v_strCrepLenishRule,
                            --strCondition, --特殊条件
                            --strItemType, --商品属性
                            strStockType, --库存性质
                            --strQuality, --商品品质
                            nLocateQty, --定位量
                            v_nCSuppQty,
                            v_nMinSuppQty,
                            strErrorMsg);
      end if;

      v_nRealSuppQty := 0;
      if v_nCSuppQty > 0 then
        --补货
        p_write_log(strEnterpriseNo,
                    strWareHouseNo,
                    strWaveNo,
                    '商品【' || strArticleNo || '】需要做【C】型补货，要求补货量为【' ||
                    v_nCSuppQty || '】',
                    '10');
        v_strSuppStatus := '10';
        PKLG_MLOCATE.p_supply_article(v_nTmpStockID,
                                      strEnterPriseNo,
                                      strWareHouseNo, --仓库代码
                                      strOwnerNo,
                                      strWaveNo, --定位号
                                      strMinBatchNo, --批次号
                                      v_strSuppStatus,
                                      'C', --作业类型
                                      '1', --出货类型
                                      strSourceType, --来源类型
                                      v_strCPickCellNo,
                                      v_nCMaxQty,
                                      V_nCKeepCells,
                                      v_strBPickCellNo,
                                      v_nBMaxQty,
                                      v_nBKeepCells,
                                      v_nPickLine,
                                      v_nPickCellCount,
                                      strStockType, --库存性质
                                      strStockValue, --库存值
                                      strPriority,
                                      dtLocateDate,
                                      strArticleNo, --商品代码
                                      v_nCSuppQty,
                                      v_nMinSuppQty,
                                      v_nRealSuppQty,
                                      1,
                                      strWorkNo, --员工代码
                                      nStockRange,
                                      strErrorMsg);
        if substr(strErrorMsg, 1, 2) = 'N|' then
          return;
        end if;
      end if;

      if v_nRealSuppQty > 0 then
        --先出C，再出D
        i := 1;
        for i in 1 .. 2 loop

          if i = 1 then
            v_strOperateType := 'C';
          else
            v_strOperateType := 'D';
          end if;

          p_write_log(strEnterpriseNo,
                      strWareHouseNo,
                      strWaveNo,
                      '商品【' || strArticleNo || '】定位' || v_strOperateType || '型',
                      '10');

          p_locate_article_otype(v_nTmpStockID,
                                 v_nAllotID,
                                 strEnterPriseNo,
                                 strWareHouseNo, --仓库代码
                                 strOwnerNo,
                                 strWaveNo, --定位号
                                 nGroupNo, --出货组号
                                 v_strOperateType, --定位类型
                                 strDestCellNo,
                                 'N',
                                 strArticleNo, --商品代码
                                 nStockRange,
                                 v_nPickLine,
                                 v_nPickCellCount,
                                 v_strCPickCellNo,
                                 v_strBPickCellNo,
                                 --strCondition, --特殊条件
                                 --strItemType, --商品属性
                                 strStockType, --库存性质
                                 strStockValue, --库存值
                                 --strQuality, --商品品质
                                 nLocateQty, --定位量
                                 strWorkNo, --员工代码
                                 Strexptype, --单据类型
                                 strErrorMsg);
          if substr(strErrorMsg, 1, 2) = 'N|' then
            return;
          end if;

          if nLocateQty <= 0 then
            return;
          end if;

          --不可出D，退出循环
          if v_strDFlag = 0 or v_strCDivideFlag = '0' then
            exit;
          end if;
        end loop;
      end if;

      if nLocateQty <= 0 then
        return;
      end if;
    end if;

    --批次间补货；
    --if v_strCrepLenishType = 3 then
    --暂不支持
    --end if;

    --循环补货
    if v_strCrepLenishType = 2 then
      v_strSuppStatus := '10';
      v_blSuppFlag    := false;
      for v_cs_batch in (select distinct od.batch_no
                           from odata_locate_d od
                          where od.warehouse_no = strWareHouseNo
                            and od.enterprise_no = strEnterPriseNo
                            and od.wave_no = strWaveNo
                            and od.trans_group_no = nGroupNo) loop

        loop

          v_nOldLocateQty := nLocateQty;
          p_locate_article_otype(v_nTmpStockID,
                                 v_nAllotID,
                                 strEnterPriseNo,
                                 strWareHouseNo, --仓库代码
                                 strOwnerNo,
                                 strWaveNo, --定位号
                                 nGroupNo, --出货组号
                                 'C', --定位类型
                                 strDestCellNo,
                                 v_cs_batch.batch_no,
                                 strArticleNo, --商品代码
                                 nStockRange,
                                 v_nPickLine,
                                 v_nPickCellCount,
                                 v_strCPickCellNo,
                                 v_strBPickCellNo,
                                 --strCondition, --特殊条件
                                 --strItemType, --商品属性
                                 strStockType, --库存性质
                                 strStockValue, --库存值
                                 --strQuality, --商品品质
                                 nLocateQty, --定位量
                                 strWorkNo, --员工代码
                                 Strexptype, --单据类型
                                 strErrorMsg);
          if substr(strErrorMsg, 1, 2) = 'N|' then
            return;
          end if;

          if nLocateQty <= 0 then
            return;
          end if;

          --如果有补过货，但又没有定到位则退出
          if v_blSuppFlag = true and v_nOldLocateQty = nLocateQty then
            exit;
          end if;

          --如果定了一部分
          if v_nOldLocateQty > nLocateQty then
            v_strSuppStatus := '11';
          end if;

          if v_strCPickCellNo <> 'N' then
            --计算箱补货量
            p_calculate_suppQty(v_nTmpStockID,
                                strEnterPriseNo,
                                strWareHouseNo, --仓库代码
                                strWaveNo, --定位号
                                nGroupNo, --出货组号
                                strArticleNo, --商品代码
                                'C',
                                v_strBPickCellNo,
                                v_strCPickCellNo,
                                v_strDFlag,
                                v_nCMaxQty,
                                v_nBMaxQty,
                                v_strBrepLenishRule,
                                v_strCrepLenishRule,
                                --strCondition, --特殊条件
                                --strItemType, --商品属性
                                strStockType, --库存性质
                                --strQuality, --商品品质
                                nLocateQty, --定位量
                                v_nCSuppQty,
                                v_nMinSuppQty,
                                strErrorMsg);
          end if;

          --凋用补货
          p_write_log(strEnterpriseNo,
                      strWareHouseNo,
                      strWaveNo,
                      '商品【' || strArticleNo || '】需要做【C】型补货，要求补货量为【' ||
                      v_nCSuppQty || '】',
                      '10');
          v_nRealSuppQty := 0;
          if v_nCSuppQty > 0 then
            PKLG_MLOCATE.p_supply_article(v_nTmpStockID,
                                          strEnterPriseNo,
                                          strWareHouseNo, --仓库代码
                                          strOwnerNo,
                                          strWaveNo, --定位号
                                          v_cs_batch.batch_no, --批次号
                                          v_strSuppStatus,
                                          'C', --作业类型
                                          '1', --出货类型
                                          strSourceType, --来源类型
                                          v_strCPickCellNo,
                                          v_nCMaxQty,
                                          V_nCKeepCells,
                                          v_strBPickCellNo,
                                          v_nBMaxQty,
                                          v_nBKeepCells,
                                          v_nPickLine,
                                          v_nPickCellCount,
                                          strStockType, --库存性质
                                          strStockValue, --库存值
                                          strPriority,
                                          dtLocateDate,
                                          strArticleNo, --商品代码
                                          v_nCSuppQty,
                                          nLocateQty,
                                          v_nRealSuppQty,
                                          1,
                                          strWorkNo, --员工代码
                                          nStockRange - 1,
                                          strErrorMsg);
            if substr(strErrorMsg, 1, 2) = 'N|' then
              return;
            end if;
          end if;
          if v_nRealSuppQty <= 0 then
            exit;
          end if;

          v_blSuppFlag := true;

        end loop;
      end loop;
    end if;

    --如果B一次性补足
    IF v_strBrepLenishType = '1' Then
      --B型定位
      p_write_log(strEnterpriseNo,
                  strWareHouseNo,
                  strWaveNo,
                  '商品【' || strArticleNo || '】定位B型',
                  '10');

      p_locate_article_otype(v_nTmpStockID,
                             v_nAllotID,
                             strEnterPriseNo,
                             strWareHouseNo, --仓库代码
                             strOwnerNo,
                             strWaveNo, --定位号
                             nGroupNo, --出货组号
                             'B', --定位类型
                             strDestCellNo,
                             'N',
                             strArticleNo, --商品代码
                             nStockRange,
                             v_nPickLine,
                             v_nPickCellCount,
                             v_strCPickCellNo,
                             v_strBPickCellNo,
                             --strCondition, --特殊条件
                             --strItemType, --商品属性
                             strStockType, --库存性质
                             strStockValue, --库存值
                             --strQuality, --商品品质
                             nLocateQty, --定位量
                             strWorkNo, --员工代码
                             Strexptype, --单据类型
                             strErrorMsg);
      if substr(strErrorMsg, 1, 2) = 'N|' then
        return;
      end if;

      if nLocateQty <= 0 then
        return;
      end if;
    End if;

  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_locate_article;

  --商品出货类型定位
  procedure p_locate_article_otype(v_nTmpStockID   in number,
                                   v_nAllotID      in number,
                                   strEnterPriseNo in odata_locate_m.enterprise_no%type,
                                   strWareHouseNo  in varchar2, --仓库代码
                                   strOwnerNo      in varchar2, -- 委托业主
                                   strWaveNo       in varchar2, --定位号
                                   nGroupNo        in number, --出货组号
                                   strOperateType  in varchar2, --定位类型
                                   strDestCellNo   in varchar2,
                                   strBatchNo      in varchar2, --定位批次
                                   strArticleNo    in varchar2, --商品代码
                                   nStockRange     in number, --库存范围
                                   nPickLine       in number, --保拣线
                                   nPickCount      in number, --拣货位数
                                   strCPickCellNo  in varchar2,
                                   strBPickCellNo  in varchar2,
                                   --strCondition   in varchar2, --特殊条件(预留)
                                   --strItemType    in varchar2, --商品属性
                                   strStockType  in varchar2, --库存性质
                                   strStockValue in varchar2, --库存值
                                   --strQuality     in varchar2, --商品品质
                                   nLocateQty  in out number, --定位量
                                   strWorkNo   in varchar2, --员工代码
                                   Strexptype  in varchar2, --单据类型
                                   strErrorMsg out varchar2) is

    v_nCanAllotStockQty odata_locate_d.plan_qty%type;
    --v_nRealSplitQTY     odata_locate_d.plan_qty%type; --实际已补量
    --v_strabnormalFlag wms_warehouse_outorder.abnormal_Flag%type;

    v_nCellPACKINGQTY bdef_article_packing.PACKING_QTY%type;

    v_strCpickFrombackArea wms_defbase.sdefine%type;
    strAllCelln            wms_defbase.sdefine%type;
    v_strBpickLimit        wms_defbase.sdefine%type;
    v_strBDivideFlag       odata_locate_batch.b_divide_flag%type;
    v_strCDivideFlag       odata_locate_batch.c_divide_flag%type;
    --v_strAllotBatch        odata_locate_batch.batch_no%type;

    v_nTotalCellQty stock_content.qty%type;
    v_nAllotCellQty stock_content.qty%type;

    v_strCellProduceDateFlag wms_defbase.sdefine%type;

    v_strLineID      cset_cell_article.line_id%type;
    v_nCLocateQty    odata_outstock_direct.locate_qty%type;
    v_nloseQty       stock_content.qty%type;
    v_nTotalBatchQty number;

    v_nBPickCount  number := 0;
    v_nCount       integer := 0;
    v_nProduceFlag number;
    v_strSkuMode  wms_outwaveplan_d.sku_count_mode%type;
    v_strIndustryFlag odata_locate_batch.industry_flag%type;

  begin
    strErrorMsg := 'Y|';

    --预留
    v_nProduceFlag := 1;

    --查找商品默认包装规格
    /*begin
        select PACKING_QTY into v_nPackingQty
        from BDEF_ARTICLE_BARCODE
        where ARTICLE_NO=strArticleNo and PRIMARY_FLAG='1'
        and rownum <= 1;
    exception
        when no_data_found then
            v_nPackingQty :=1;
    end;*/

    --
    v_strLineID := nPickLine; --一定要注意后面的判断值要一样

    if strBPickCellNo <> 'N' then
      v_nBPickCount := 1;
    end if;

    if nPickCount > 0 and nStockRange in (1, 3) then
      --有拣货位
      begin
        --
        if nPickCount <= 1 then
          begin
            select PACKING_QTY
              into v_nCellPackingQty
              from cset_cell_article cca
             where cca.warehouse_no = strWareHouseNo
               and cca.enterprise_no = strEnterPriseNo
               and cca.article_no = strArticleNo;
          exception
            when no_data_found then
              select nvl(max(packing_qty), 1)
                into v_nCellPackingQty
                from bdef_article_packing bap
               where bap.article_no = strArticleNo;
          end;

        else
          begin
            select PACKING_QTY
              into v_nCellPackingQty
              from cset_cell_article cca
             where cca.warehouse_no = strWareHouseNo
               and cca.enterprise_no = strEnterPriseNo
               and cca.article_no = strArticleNo
               and rownum = 1;
          exception
            when no_data_found then
              select nvl(max(packing_qty), 1)
                into v_nCellPackingQty
                from bdef_article_packing bap
               where bap.article_no = strArticleNo;
          end;
        end if;
      exception
        when no_data_found then
          strErrorMsg := 'N|[E3201903]';
          return;
      end;
    end if;

    --获取系统参数 判断同一货位是否要区分生产日期
    PKLG_WMS_BASE.p_GetBasePara(strEnterPriseNo,
                                strWareHouseNo,
                                strOwnerNo,
                                'ProduceDateLevel',
                                'O',
                                'O_LOCATE',
                                v_strCellProduceDateFlag,
                                strAllCelln,
                                strErrorMsg);
    if substr(strErrorMsg, 1, 1) = 'N' then
      strErrorMsg := 'N|[E30025]';
      return;
    end if;
    if v_strCellProduceDateFlag = '0' then
      v_nProduceFlag := 1;
    else
      v_nProduceFlag := 0;
    end if;

    PKLG_WMS_BASE.p_GetBasePara(strEnterPriseNo,
                                strWareHouseNo,
                                strOwnerNo,
                                'Locate_BpickLimmit',
                                'O',
                                'O_LOCATE',
                                v_strBpickLimit,
                                strAllCelln,
                                strErrorMsg);
    if substr(strErrorMsg, 1, 1) = 'N' then
      strErrorMsg := 'N|[E30025]';
      return;
    end if;

    --按保拣线定位时，若重型货架、立库或驶入货架区域根据参数判断保管区是否允许箱拣
    PKLG_WMS_BASE.p_GetBasePara(strEnterPriseNo,
                                strWareHouseNo,
                                strOwnerNo,
                                'Locate_PickFlag',
                                'O',
                                'O_LOCATE',
                                v_strCpickFrombackArea,
                                strAllCelln,
                                strErrorMsg);
    if substr(strErrorMsg, 1, 1) = 'N' then
      strErrorMsg := 'N|[E30025]';
      return;
    end if;

    --获取批次分播标识
    begin
      select lb.b_divide_flag, lb.c_divide_flag,od.sku_count_mode,lb.industry_flag
        into v_strBDivideFlag, v_strCDivideFlag,v_strSkuMode,v_strIndustryFlag
        from odata_locate_batch lb,wms_outwaveplan_d od
       where lb.enterprise_no = strEnterpriseNo
         and lb.warehouse_no = strWareHouseNo
         and lb.wave_no = strWaveNo
         and lb.enterprise_no= od.enterprise_no
         and lb.batch_strategy_id = od.batch_strategy_id
         and lb.batch_rule_id = od.batch_rule_id
         and rownum = 1;
    exception
      when no_data_found then
        strErrorMsg := 'N|[找不到对应的批次信息]';
        return;
    end;

    for v_cs_stock in (SELECT t.*
                         FROM (SELECT S.WAREHOUSE_NO,
                                      S.OWNER_NO,
                                      S.CELL_NO,
                                      S.ARTICLE_NO,
                                      S.DEPT_NO,
                                      CDA.WARE_NO,
                                      CDA.AREA_NO,
                                      CDA.LIMIT_RATE,
                                      CDA.LIMIT_TYPE,
                                      CDA.PAL_OUT_RATE,
                                      CDA.ADVANCER_PICK_FLAG,
                                      S.PACKING_QTY,
                                      S.QUALITY,
                                      S.S_QTY,
                                      S.S_INSTOCK_QTY,
                                      S.S_OUTSTOCK_QTY,
                                      s.flag,
                                      s.EXPIRY_DAYS,
                                      s.qmin_operate_packing,
                                      CDA.O_TYPE,
                                      CDA.AREA_PICK,
                                      CDA.AREA_USETYPE,
                                      CDA.DIVIDE_FLAG,
                                      CDA.B_DIVIDE_FLAG,
                                      s.LOT_NO,
                                      CDA.AREA_TYPE,
                                      CDC.PICK_FLAG,
                                      CDC.MAX_QTY,
                                      case
                                        when v_strLineID >= 0 then --如果有保拣线
                                         NVL((SELECT CAB.A_LEVEL + 1 --加1的作用是把拆零货位给补上
                                               FROM CSET_AREA_BACKUP_D CAB
                                              WHERE CAB.WAREHOUSE_NO =
                                                    strWareHouseNo
                                                and cab.enterprise_no =
                                                    strEnterPriseNo
                                                and CAB.LINE_ID = v_strLineID
                                                AND CAB.WARE_NO = CDC.WARE_NO
                                                AND CAB.AREA_NO = (CASE
                                                      WHEN CAB.AREA_NO = 'N' then
                                                       'N'
                                                      else
                                                       CDC.AREA_NO
                                                    END)
                                                AND CAB.STOCK_NO = (CASE
                                                      WHEN CAB.STOCK_NO = 'N' then
                                                       'N'
                                                      else
                                                       CDC.STOCK_NO
                                                    END)),
                                             nvl((select 0
                                                   from cdef_defcell icca
                                                  where icca.warehouse_no =
                                                        CDC.WAREHOUSE_NO
                                                    and icca.enterprise_no =
                                                        cdc.enterprise_no
                                                    and icca.ware_no =
                                                        cdc.ware_no
                                                    and icca.area_no =
                                                        cdc.area_no
                                                    and icca.enterprise_no =
                                                        strEnterPriseNo
                                                    and icca.warehouse_no =
                                                        strWareHouseNo
                                                    and icca.cell_no like
                                                        strBPickCellNo || '%'),
                                                 case
                                                   when cda.area_pick = '1' then --log20160411 modi by lizhiping 拣货区并入保拣线
                                                    DECODE(CDA.O_TYPE,
                                                           'P',
                                                           2,
                                                           'C',
                                                           1,
                                                           'B',
                                                           0)
                                                   else
                                                    DECODE(CDA.O_TYPE,
                                                           'P',
                                                           2,
                                                           'C',
                                                           3,
                                                           'B',
                                                           4) * -1
                                                 end))
                                        else
                                         DECODE(CDA.O_TYPE,
                                                'P',
                                                2,
                                                'C',
                                                3,
                                                'B',
                                                4) * -1
                                      end SORT_LEVEL,
                                      CASE
                                        WHEN CDA.AREA_TYPE = '1' THEN
                                         CDC.STOCK_X
                                        ELSE
                                         '1'
                                      END SORT_CELL,
                                      case
                                        when nvl(nvl(baw.qpalette,
                                                     BAP.qpalette),
                                                 999999) > 0 then
                                         nvl(nvl(baw.qpalette, BAP.qpalette),
                                             999999)
                                        else
                                         999999
                                      end AS PALLETE_QTY,
                                      nvl(nvl(baw.packing_qty,
                                              BAP.packing_qty),
                                          -1) as pack_packing_qty,
                                      s.produce_date,
                                      S.SORT_DATE,
                                      S.SORT_BATCH,
                                      S.SORT_FLAG,
                                      s.min_expire_date,
                                      S.S_CAN_USE_QTY,
                                      s.SERIAL_FLAG
                                 FROM (select c.enterprise_no,
                                              C.WAREHOUSE_NO,
                                              C.OWNER_NO,
                                              C.DEPT_NO,
                                              C.CELL_NO,
                                              C.ARTICLE_NO,
                                              C.PACKING_QTY,
                                              a.QUALITY,
                                              a.LOT_NO,
                                              b.expiry_days,
                                              b.qmin_operate_packing,
                                              max(c.flag) flag,
                                              min(a.PRODUCE_DATE) as produce_date,
                                              case
                                                when min(b.turn_over_rule) =
                                                     'LIFO' then
                                                 MAX(TRUNC(a.PRODUCE_DATE))
                                                else
                                                 case
                                                   when min(b.turn_over_rule) =
                                                        'FEFO' then
                                                    MIN(TRUNC(a.expire_date))
                                                   else
                                                    MIN(TRUNC(a.PRODUCE_DATE))
                                                 end
                                              end as SORT_DATE,
                                              MIN(TRUNC(a.expire_date)) min_expire_date,
                                              MIN(SUBSTR(a.IMPORT_BATCH_NO,
                                                         2,
                                                         20)) SORT_BATCH,
                                              MAX(C.FLAG) AS SORT_FLAG,
                                              sum(C.QTY - C.OUTSTOCK_QTY +
                                                  (case C.Instock_Type
                                                    when '1' then
                                                     C.INSTOCK_QTY
                                                    else
                                                     0
                                                  end) + C.UNUSUAL_QTY) AS S_QTY,
                                              SUM(case C.Instock_Type
                                                    when '1' then
                                                     C.INSTOCK_QTY
                                                    else
                                                     0
                                                  end) AS S_INSTOCK_QTY,
                                              SUM(C.OUTSTOCK_QTY) AS S_OUTSTOCK_QTY,
                                              SUM(case
                                                    when (C.QTY - C.OUTSTOCK_QTY +
                                                         C.UNUSUAL_QTY) > 0 then
                                                     (C.QTY - C.OUTSTOCK_QTY +
                                                     C.UNUSUAL_QTY)
                                                    else
                                                     0
                                                  end) as S_CAN_USE_QTY,
                                              tmpsc.SERIAL_FLAG
                                         FROM BDEF_DEFARTICLE    B,
                                              STOCK_article_info a,
                                              STOCK_CONTENT      C,
                                              TMP_STOCK_CONTENT  tmpsc
                                        WHERE b.enterprise_no =
                                              c.enterprise_no
                                          and B.ARTICLE_NO = C.ARTICLE_NO
                                          and a.enterprise_no =
                                              c.enterprise_no
                                          and a.article_no = c.article_no
                                          and a.article_id = c.article_id
                                          AND c.ARTICLE_NO = strArticleNo
                                          AND c.stock_type = strStockType
                                          AND c.stock_value = strStockValue
                                          AND C.STATUS = 0
                                             --条件
                                          AND C.FLAG <> '2'
                                          AND (C.INSTOCK_QTY + C.QTY -
                                              C.OUTSTOCK_QTY + C.UNUSUAL_QTY) > 0
                                          AND c.enterprise_no =
                                              tmpsc.enterprise_no
                                          AND c.warehouse_no =
                                              tmpsc.warehouse_no
                                          AND c.cell_no = tmpsc.cell_no
                                          And c.cell_id = tmpsc.cell_id
                                          and tmpsc.warehouse_no =
                                              strWareHouseNo
                                          and tmpsc.enterprise_no =
                                              strEnterPriseNo
                                          and tmpsc.tmp_id = v_nTmpStockID
                                        GROUP BY c.enterprise_no,
                                                 C.WAREHOUSE_NO,
                                                 C.OWNER_NO,
                                                 C.DEPT_NO,
                                                 C.CELL_NO,
                                                 C.ARTICLE_NO,
                                                 C.PACKING_QTY,
                                                 a.QUALITY,
                                                 a.LOT_NO,
                                                 b.expiry_days,
                                                 b.qmin_operate_packing,
                                                 tmpsc.SERIAL_FLAG,
                                                 --预留，严格按生产日期出货此处需要修改
                                                 (case
                                                   when v_strCellProduceDateFlag = '0' then
                                                    a.produce_date
                                                   else
                                                    trunc(sysdate)
                                                 end)
                                        order by s_qty desc) S
                                 left join BDEF_ARTICLE_PACKING BAP
                                   on s.enterprise_no = BAP.enterprise_no
                                  and s.article_no = BAP.article_no
                                  and s.packing_qty = BAP.packing_qty
                                 left join bdef_warehouse_packing baw
                                   on s.enterprise_no = baw.enterprise_no
                                  and s.article_no = baw.article_no
                                  and s.packing_qty = baw.packing_qty
                                  and s.WAREHOUSE_NO = baw.WAREHOUSE_NO,
                                cdef_defware cdw, CDEF_DEFAREA CDA,
                                CDEF_DEFCELL CDC, odata_locate_m olm
                                WHERE cdw.enterprise_no = cda.enterprise_no
                                  and cdw.warehouse_no = cda.warehouse_no
                                  and cdw.ware_no = cda.ware_no
                                  and cdw.org_no = olm.org_no
                                  and olm.enterprise_no = strEnterPriseNo
                                  and olm.warehouse_no = strWareHouseNo
                                  and olm.wave_no = strWaveNo
                                  and cda.enterprise_no = cdc.enterprise_no
                                  and CDA.WAREHOUSE_NO = CDC.WAREHOUSE_NO
                                  AND CDA.WARE_NO = CDC.WARE_NO
                                  AND CDA.AREA_NO = CDC.AREA_NO
                                  AND CDA.AREA_ATTRIBUTE = '0'
                                  and cda.area_usetype in ('1', '5', '6','7')
                                  and cdc.enterprise_no = s.enterprise_no
                                  AND CDC.WAREHOUSE_NO = s.WAREHOUSE_NO
                                  AND CDC.CELL_NO = s.CELL_NO
                                  and cdc.cell_status = '0'
                                  AND CDC.CHECK_STATUS = '0') t
                       --  1  保拣线按默认规格定位
                       --  2  全仓按默认规格定位（不含异常）
                       --  3  保拣线按所有规格定位
                       --  4  全仓按所有规格定位（不含异常）
                       --  5  异常区按默认规格定位
                       --  6  异常区按所有规格定位
                        where ((nStockRange in (1, 3) and t.SORT_LEVEL >= 0) or
                              (nStockRange IN (2, 4) and t.SORT_LEVEL < 0 and
                              area_usetype <> 5) or
                              (nStockRange in (5, 6) and area_usetype = 5))
                        ORDER BY SERIAL_FLAG,
                                 DECODE(t.AREA_USETYPE, 1, 0,7,0, 1),
                                 DECODE(t.flag, '3', 0, 1),
                                 t.SORT_LEVEL DESC,
                                 t.SORT_FLAG DESC,
                                 (case
                                   when t.S_CAN_USE_QTY <> 0 then
                                    0
                                   else
                                    1
                                 end),
                                 t.SORT_DATE,
                                 t.S_CAN_USE_QTY,
                                 t.S_QTY,
                                 t.SORT_CELL,
                                 t.PACKING_QTY,
                                 t.SORT_BATCH,
                                 t.LOT_NO,
                                 t.QUALITY) loop
      --定位完成，退出
      if nLocateQty <= 0 then
        exit;
      end if;

      --如果库存小于最小操作包装，继续下一库存
      /*if v_cs_stock.S_QTY < v_cs_stock.QMIN_OPERATE_PACKING then
        goto next_stock;
      end if;*/

      --如果该储区不能出货
      if v_cs_stock.PICK_FLAG = '0' then
        p_write_short_log(strEnterpriseNo,
                          strWareHouseNo,
                          strWaveNo,
                          strOwnerNo,
                          nGroupNo,
                          'N',
                          'N',
                          'N',
                          v_cs_stock.cell_no,
                          strArticleNo,
                          -1,
                          v_cs_stock.packing_qty,
                          v_cs_stock.s_can_use_qty,
                          nLocateQty,
                          strOperateType,
                          '该储区不能出货');
        goto next_stock;
      end if;

      --电商行业，1单1品才可出预包区库存
      if v_cs_stock.area_usetype = '7' then
          if v_strIndustryFlag = '2' and v_strSkuMode = '1' then
            p_write_log(strEnterpriseNo,
                    strWareHouseNo,
                    strWaveNo,
                    '出预包区库存',
                    '10');
           else
              p_write_log(strEnterpriseNo,
                    strWareHouseNo,
                    strWaveNo,
                    '预包区库存不可出',
                    '10');
              p_write_short_log(strEnterpriseNo,
                              strWareHouseNo,
                              strWaveNo,
                              strOwnerNo,
                              nGroupNo,
                              'N',
                              'N',
                              'N',
                              v_cs_stock.cell_no,
                              strArticleNo,
                              -1,
                              v_cs_stock.packing_qty,
                              v_cs_stock.s_can_use_qty,
                              nLocateQty,
                              strOperateType,
                              '预包区库存不可出');
                goto next_stock;
          end if;
      end if;
      --如果品质不相同
      --if v_cs_stock.QUALITY <> strQuality then
      --  goto next_stock;
      --end if;

      --判断策略判断规格是否能出货
      --1 保拣线按默认规格定位
      if nStockRange = 1 and v_nCellPACKINGQTY <> v_cs_stock.PACKING_QTY then
        p_write_short_log(strEnterpriseNo,
                          strWareHouseNo,
                          strWaveNo,
                          strOwnerNo,
                          nGroupNo,
                          'N',
                          'N',
                          'N',
                          v_cs_stock.cell_no,
                          strArticleNo,
                          -1,
                          v_cs_stock.packing_qty,
                          v_cs_stock.s_can_use_qty,
                          nLocateQty,
                          strOperateType,
                          '保拣线按默认规格定位，拣货位包装【' || v_nCellPACKINGQTY ||
                          '】与库存包装【' || v_cs_stock.PACKING_QTY || '】不同');
        goto next_stock;
      end if;

      --2 全仓按默认规格定位（不含异常）
      if nStockRange = 2 and v_nCellPackingQty <> v_cs_stock.PACKING_QTY then
        p_write_short_log(strEnterpriseNo,
                          strWareHouseNo,
                          strWaveNo,
                          strOwnerNo,
                          nGroupNo,
                          'N',
                          'N',
                          'N',
                          v_cs_stock.cell_no,
                          strArticleNo,
                          -1,
                          v_cs_stock.packing_qty,
                          v_cs_stock.s_can_use_qty,
                          nLocateQty,
                          strOperateType,
                          '全仓按默认规格定位，拣货位包装【' || v_nCellPACKINGQTY ||
                          '】与库存包装【' || v_cs_stock.PACKING_QTY || '】不同');
        goto next_stock;
      end if;

      --异常区按默认规格定位
      if nStockRange = 5 and v_nCellPackingQty <> v_cs_stock.PACKING_QTY then
        p_write_short_log(strEnterpriseNo,
                          strWareHouseNo,
                          strWaveNo,
                          strOwnerNo,
                          nGroupNo,
                          'N',
                          'N',
                          'N',
                          v_cs_stock.cell_no,
                          strArticleNo,
                          -1,
                          v_cs_stock.packing_qty,
                          v_cs_stock.s_can_use_qty,
                          nLocateQty,
                          strOperateType,
                          '异常区按默认规格定位，拣货位包装【' || v_nCellPACKINGQTY ||
                          '】与库存包装【' || v_cs_stock.PACKING_QTY || '】不同');
        goto next_stock;
      end if;

      --如果有拣货位，拣货区只允许定地面堆叠
      /*if ((strOperateType = 'M' or strOperateType = 'P') and
         nPickCount > 0) then

        if ((v_cs_stock.o_type = 'B' or v_cs_stock.AREA_PICK = '1') and
           v_cs_stock.AREA_TYPE <> '3') then
          p_write_short_log(strEnterpriseNo,
                            strWareHouseNo,
                            strWaveNo,
                            strOwnerNo,
                            nGroupNo,
                            'N',
                            'N',
                            'N',
                            v_cs_stock.cell_no,
                            strArticleNo,
                            -1,
                            v_cs_stock.packing_qty,
                            v_cs_stock.s_can_use_qty,
                            nLocateQty,
                            strOperateType,
                            '有拣货位只允许地面堆叠定此作业类型');
          goto next_stock;
        end if;
      end if;*/

      if strOperateType = 'B' then

        if v_cs_stock.o_type <> 'B' then
          --1、有拆零拣货位，不让出
          --2、无拆零拣货位，有箱拣货位，非拣货区不让出 area_pick:0---保管区；1--拣货区
          --4、无拆零拣货位，有箱拣货位，拣货区按参数 area_pick:0---保管区；1--拣货区 Add BY QZH AT 2016-5-3
          --3、无拣货位，非拆零区不允许零散，或允许拆零但在保管位，不出
          if v_nBPickCount > 0 or (v_nBPickCount = 0 and nPickCount > 0 and
             v_cs_stock.AREA_PICK = '0') or
             (v_nBPickCount = 0 and nPickCount > 0 and
             v_cs_stock.AREA_PICK = '1' and v_strBpickLimit = '0') or
             (nPickCount = 0 and
             (v_strBpickLimit = '0' OR
             (v_strBpickLimit = '1' AND v_cs_stock.AREA_PICK = '0'))) then
            p_write_short_log(strEnterpriseNo,
                              strWareHouseNo,
                              strWaveNo,
                              strOwnerNo,
                              nGroupNo,
                              'N',
                              'N',
                              'N',
                              v_cs_stock.cell_no,
                              strArticleNo,
                              -1,
                              v_cs_stock.packing_qty,
                              v_cs_stock.s_can_use_qty,
                              nLocateQty,
                              strOperateType,
                              '非拆零区不允许出拆零');
            goto next_stock;
          end if;
        end if;

        --预留:如果不是全仓定位，且不是零散拣货区及混合区

        v_nCanAllotStockQty := v_cs_stock.s_qty;

        --写定位指示
        p_write_direct(v_nTmpStockID,
                       v_nAllotID,
                       strEnterPriseNo,
                       strWareHouseNo,
                       strOwnerNo, --仓库代码
                       strWaveNo, --定位号
                       nGroupNo, --出货组号
                       strDestCellNo, --目的储位
                       strOperateType, --定位类型
                       strBatchNo, --定位批次
                       strArticleNo, --商品代码
                       v_cs_stock.Cell_No,
                       v_cs_stock.Dept_No,
                       'N', --v_cs_stock.Container_No,
                       v_cs_stock.Packing_Qty,
                       v_nProduceFlag,
                       v_cs_stock.Produce_Date,
                       v_cs_stock.Quality, --商品品质
                       v_cs_stock.Lot_No,
                       --v_cs_stock.Supplier_No,
                       strStockType, --库存性质
                       strStockValue, --库存值
                       v_nCanAllotStockQty,
                       nLocateQty, --定位量
                       strWorkNo, --员工代码
                       Strexptype, --单据类型
                       strErrorMsg);
        if substr(strErrorMsg, 1, 2) = 'N|' then
          return;
        end if;

        if nLocateQty <= 0 then
          exit;
        end if;
        goto next_stock;
      end if;

      if strOperateType in ('C', 'D') then

        -- 没有维护包装不定C型
        if v_cs_stock.pack_packing_qty < 0 then
          p_write_short_log(strEnterpriseNo,
                            strWareHouseNo,
                            strWaveNo,
                            strOwnerNo,
                            nGroupNo,
                            'N',
                            'N',
                            'N',
                            v_cs_stock.cell_no,
                            strArticleNo,
                            -1,
                            v_cs_stock.packing_qty,
                            v_cs_stock.s_can_use_qty,
                            nLocateQty,
                            strOperateType,
                            '无维护包装不能定箱型作业');
          goto next_stock;
        end if;

        --板出区不能出箱
        if v_cs_stock.o_type = 'P' then
          p_write_short_log(strEnterpriseNo,
                            strWareHouseNo,
                            strWaveNo,
                            strOwnerNo,
                            nGroupNo,
                            'N',
                            'N',
                            'N',
                            v_cs_stock.cell_no,
                            strArticleNo,
                            -1,
                            v_cs_stock.packing_qty,
                            v_cs_stock.s_can_use_qty,
                            nLocateQty,
                            strOperateType,
                            '板出区不能出箱');
          goto next_stock;
        end if;

        --批次不允许分播或者储区不允许分播，都不可出D
        if strOperateType = 'D' and
           (v_cs_stock.B_Divide_Flag = '0' or v_strBDivideFlag = '0') then
          p_write_short_log(strEnterpriseNo,
                            strWareHouseNo,
                            strWaveNo,
                            strOwnerNo,
                            nGroupNo,
                            'N',
                            'N',
                            'N',
                            v_cs_stock.cell_no,
                            strArticleNo,
                            -1,
                            v_cs_stock.packing_qty,
                            v_cs_stock.s_can_use_qty,
                            nLocateQty,
                            strOperateType,
                            '区域[' || v_cs_stock.ware_no ||
                            v_cs_stock.area_no || ']不可分播或者批次不可分播，不出D型');
          goto next_stock;
        end if;

        --C是否在可分播区域采用分播作业
        --if v_cs_stock.DIVIDE_FLAG = '1' and v_strCDIVIDEFLAG = '0' then
        --    goto next_stock;
        --end if;

        --按保拣线定位时，若重型货架、立库或驶入货架区域根据参数判断保管区是否允许箱拣
        if nStockRange in (1, 3) and v_strCpickFrombackArea = '0' and
           v_cs_stock.area_type in ('1', '2', '7') and
           v_cs_stock.AREA_PICK = '0' then
          p_write_short_log(strEnterpriseNo,
                            strWareHouseNo,
                            strWaveNo,
                            strOwnerNo,
                            nGroupNo,
                            'N',
                            'N',
                            'N',
                            v_cs_stock.cell_no,
                            strArticleNo,
                            -1,
                            v_cs_stock.packing_qty,
                            v_cs_stock.s_can_use_qty,
                            nLocateQty,
                            strOperateType,
                            '保拣线定位，重型货架、立库或驶入货架保管区不允许出箱');
          goto next_stock;
        end if;

        --如果要货数量小于库存的包装数不出
        --if v_cs_stock.Packing_Qty > nLocateQty then
        select count(1)
          into v_nCount
          from bdef_article_packing bap
         where bap.article_no = v_cs_stock.article_no
           and bap.enterprise_no = strEnterpriseNo
           and bap.packing_qty = v_cs_stock.Packing_Qty;

        if v_nCount <= 0 then
          --库存包装为基础包装或最小操作包装，则不为箱库存
          select count(1)
            into v_nCount
            from bdef_defarticle bda
           where bda.enterprise_no = strEnterPriseNo
             and bda.article_no = v_cs_stock.article_no
             and (bda.qmin_operate_packing = v_cs_stock.packing_qty or
                 bda.unit_packing = v_cs_stock.packing_qty);

          if v_nCount > 0 then
            p_write_short_log(strEnterpriseNo,
                              strWareHouseNo,
                              strWaveNo,
                              strOwnerNo,
                              nGroupNo,
                              'N',
                              'N',
                              'N',
                              v_cs_stock.cell_no,
                              strArticleNo,
                              -1,
                              v_cs_stock.packing_qty,
                              v_cs_stock.s_can_use_qty,
                              nLocateQty,
                              strOperateType,
                              '箱型定位，库存规格不属于箱规格');
            goto next_stock;
          end if;
        end if;

        --预留:如果不是全仓定位，且不是零散拣货区及混合区

        v_nCanAllotStockQty := floor(v_cs_stock.S_QTY /
                                     v_cs_stock.Packing_Qty) *
                               v_cs_stock.Packing_Qty;

        --C形只出整箱
        v_nloseQty    := nLocateQty -
                         floor(nLocateQty / v_cs_stock.Packing_Qty) *
                         v_cs_stock.Packing_Qty;
        v_nCLocateQty := floor(nLocateQty / v_cs_stock.Packing_Qty) *
                         v_cs_stock.Packing_Qty;

        --D型定位
        if strOperateType = 'D' then
          v_nTotalBatchQty := 0;
          --获取各批次汇总配量
          for GetSumBatchAllotQty in (select batch_no,
                                             sum(allot_qty) allot_qty
                                        from middata_allot_detail mad
                                       where mad.warehouse_no =
                                             strWareHouseNo
                                         and mad.source_no = strWaveNo
                                         and mad.article_no = strArticleNo
                                         and mad.enterprise_no =
                                             strEnterPriseNo
                                         and mad.allot_qty > 0
                                         and mad.tmp_id = v_nAllotID
                                       group by batch_no) loop
            --够出D
            if GetSumBatchAllotQty.allot_qty >= v_cs_stock.Packing_Qty then

              v_nTotalBatchQty := GetSumBatchAllotQty.allot_qty;
              v_nTotalBatchQty := floor(v_nTotalBatchQty /
                                        v_cs_stock.Packing_Qty) *
                                  v_cs_stock.Packing_Qty;

              --当前批次要货量小于可用库存量,按要货量配给客户
              if v_nTotalBatchQty < v_nCanAllotStockQty then
                v_nCanAllotStockQty := v_nTotalBatchQty;
              end if;

              --写定位指示
              p_write_direct(v_nTmpStockID,
                             v_nAllotID,
                             strEnterPriseNo,
                             strWareHouseNo,
                             strOwnerNo, --仓库代码
                             strWaveNo, --定位号
                             nGroupNo, --出货组号
                             strDestCellNo, --目的储位
                             strOperateType, --定位类型
                             GetSumBatchAllotQty.batch_no, --定位批次
                             strArticleNo, --商品代码
                             v_cs_stock.Cell_No,
                             v_cs_stock.Dept_No,
                             'N', --v_cs_stock.Container_No,
                             v_cs_stock.Packing_Qty,
                             v_nProduceFlag,
                             v_cs_stock.Produce_Date,
                             v_cs_stock.Quality, --商品品质
                             v_cs_stock.Lot_No,
                             --v_cs_stock.Supplier_No,
                             strStockType, --库存性质
                             strStockValue, --库存值
                             v_nCanAllotStockQty,
                             nLocateQty, --定位量
                             strWorkNo, --员工代码
                             Strexptype, --单据类型
                             strErrorMsg);
              if substr(strErrorMsg, 1, 2) = 'N|' then
                return;
              end if;

              if nLocateQty <= 0 then
                exit;
              end if;
            end if;
          end loop;
          if nLocateQty <= 0 then
            exit;
          end if;
        end if;

        --C型定位
        if strOperateType = 'C' then
          --写定位指示
          p_write_direct(v_nTmpStockID,
                         v_nAllotID,
                         strEnterPriseNo,
                         strWareHouseNo,
                         strOwnerNo, --仓库代码
                         strWaveNo, --定位号
                         nGroupNo, --出货组号
                         strDestCellNo, --目的储位
                         strOperateType, --定位类型
                         strBatchNo, --定位批次
                         strArticleNo, --商品代码
                         v_cs_stock.Cell_No,
                         v_cs_stock.Dept_No,
                         'N', --v_cs_stock.Container_No,
                         v_cs_stock.Packing_Qty,
                         v_nProduceFlag,
                         v_cs_stock.Produce_Date,
                         v_cs_stock.Quality, --商品品质
                         v_cs_stock.Lot_No,
                         --v_cs_stock.Supplier_No,
                         strStockType, --库存性质
                         strStockValue, --库存值
                         v_nCanAllotStockQty,
                         v_nCLocateQty, --定位量
                         strWorkNo, --员工代码
                         Strexptype, --单据类型
                         strErrorMsg);
          if substr(strErrorMsg, 1, 2) = 'N|' then
            return;
          end if;

          nLocateQty := v_nCLocateQty + v_nloseQty;
        end if;
        if nLocateQty <= 0 then
          exit;
        end if;
        goto next_stock;
      end if;

      --批次不允许分播或者储区不允许分播，都不可出M
      if strOperateType = 'M' and
         (v_cs_stock.Divide_Flag = '0' or v_strCDivideFlag = '0') then
        p_write_short_log(strEnterpriseNo,
                          strWareHouseNo,
                          strWaveNo,
                          strOwnerNo,
                          nGroupNo,
                          'N',
                          'N',
                          'N',
                          v_cs_stock.cell_no,
                          strArticleNo,
                          -1,
                          v_cs_stock.packing_qty,
                          v_cs_stock.s_can_use_qty,
                          nLocateQty,
                          strOperateType,
                          '区域[' || v_cs_stock.ware_no || v_cs_stock.area_no ||
                          ']不可分播或者批次不可分播，不出M型');
        goto next_stock;
      end if;

      ----Modify BY QZH AT 2016-4-25
      --如果是补下来的货或有出过货，不出M和P型
      --if (v_cs_stock.S_INSTOCK_QTY > 0 or v_cs_stock.S_OUTSTOCK_QTY > 0) then
      if (((v_cs_stock.s_qty - v_cs_stock.s_instock_qty) /
         v_cs_stock.PALLETE_QTY) * 100 < v_cs_stock.PAL_OUT_RATE and
         v_cs_stock.PAL_OUT_RATE <> 0) then
        p_write_short_log(strEnterpriseNo,
                          strWareHouseNo,
                          strWaveNo,
                          strOwnerNo,
                          nGroupNo,
                          'N',
                          'N',
                          'N',
                          v_cs_stock.cell_no,
                          strArticleNo,
                          -1,
                          v_cs_stock.packing_qty,
                          v_cs_stock.s_can_use_qty,
                          nLocateQty,
                          strOperateType,
                          '补货库存不出M和P型');
        goto next_stock;
      end if;

      --Add BY QZH AT 2016-5-17
      select count(1)
        into v_nCount
        from bdef_article_packing bap
       where bap.article_no = v_cs_stock.article_no
         and bap.enterprise_no = strEnterpriseNo
         and bap.packing_qty = v_cs_stock.Packing_Qty;
      if v_nCount <= 0 then
        --库存包装为基础包装或最小操作包装，则不为箱库存
        select count(1)
          into v_nCount
          from bdef_defarticle bda
         where bda.enterprise_no = strEnterPriseNo
           and bda.article_no = v_cs_stock.article_no
           and (bda.qmin_operate_packing = v_cs_stock.packing_qty or
               bda.unit_packing = v_cs_stock.packing_qty);

        if v_nCount > 0 then
          p_write_short_log(strEnterpriseNo,
                            strWareHouseNo,
                            strWaveNo,
                            strOwnerNo,
                            nGroupNo,
                            'N',
                            'N',
                            'N',
                            v_cs_stock.cell_no,
                            strArticleNo,
                            -1,
                            v_cs_stock.packing_qty,
                            v_cs_stock.s_can_use_qty,
                            nLocateQty,
                            strOperateType,
                            '板型定位，库存规格不属于箱规格');
          goto next_stock;
        end if;
      end if;
      --Add End

      --如果不是整箱，不出P和M型
      --log20160320 modi by lizhiping 且这个货位最大板数为1，或最大板数大于1且库存未达标准堆叠
      if mod(v_cs_stock.S_QTY, v_cs_stock.packing_qty) <> 0 and
         (v_cs_stock.MAX_QTY = 1 or
          (v_cs_stock.MAX_QTY > 1 and
          v_cs_stock.S_QTY < v_cs_stock.PALLETE_QTY)) then
        p_write_short_log(strEnterpriseNo,
                          strWareHouseNo,
                          strWaveNo,
                          strOwnerNo,
                          nGroupNo,
                          'N',
                          'N',
                          'N',
                          v_cs_stock.cell_no,
                          strArticleNo,
                          -1,
                          v_cs_stock.packing_qty,
                          v_cs_stock.s_can_use_qty,
                          nLocateQty,
                          strOperateType,
                          '库存中有散数，且最大板为1或大于1而库存又未到达标准堆叠，不出M和P型');
        goto next_stock;
      end if;

      /*--预留:根据储区限定条件，判断是否可出货
      if (v_cs_stock.S_QTY / v_cs_stock.PALLETE_QTY) * 100 <
         v_cs_stock.PAL_OUT_RATE and v_cs_stock.PAL_OUT_RATE <> 0 and
         strOperateType = 'P' then
        p_write_short_log(strEnterpriseNo,
                          strWareHouseNo,
                          strWaveNo,
                          strOwnerNo,
                          nGroupNo,
                          'N',
                          'N',
                          'N',
                          v_cs_stock.cell_no,
                          strArticleNo,
                          -1,
                          v_cs_stock.packing_qty,
                          v_cs_stock.s_can_use_qty,
                          nLocateQty,
                          strOperateType,
                          '库存量达不到P型可出条件');
        goto next_stock;
      end if;*/

      ----Modify BY QZHAT 2016-4-25
      --如果要货量小于当前储位的数量,且要货量小于标准堆叠
      --if (nLocateQty < v_cs_stock.S_QTY and
      --   nLocateQty < v_cs_stock.PALLETE_QTY) then
      --Modify BY QZHAT 2016-4-25
      --如果要货量小于当前储位的尾板数量,且要货量小于标准堆叠
      if (nLocateQty < mod(v_cs_stock.S_QTY, v_cs_stock.pallete_qty) and
         nLocateQty < v_cs_stock.PALLETE_QTY) then
        p_write_short_log(strEnterpriseNo,
                          strWareHouseNo,
                          strWaveNo,
                          strOwnerNo,
                          nGroupNo,
                          'N',
                          'N',
                          'N',
                          v_cs_stock.cell_no,
                          strArticleNo,
                          -1,
                          v_cs_stock.packing_qty,
                          v_cs_stock.s_can_use_qty,
                          nLocateQty,
                          strOperateType,
                          '要货量小于库存以及堆叠量，不出M和P型');
        goto next_stock;
      end if;
      ----Modify BY QZH AT 2016-4-25
      if ((nLocateQty <
         v_cs_stock.PALLETE_QTY * v_cs_stock.pal_out_rate / 100 or
         v_cs_stock.S_QTY <
         v_cs_stock.PALLETE_QTY * v_cs_stock.pal_out_rate / 100) and
         v_cs_stock.PAL_OUT_RATE <> 0) then
        p_write_short_log(strEnterpriseNo,
                          strWareHouseNo,
                          strWaveNo,
                          strOwnerNo,
                          nGroupNo,
                          'N',
                          'N',
                          'N',
                          v_cs_stock.cell_no,
                          strArticleNo,
                          -1,
                          v_cs_stock.packing_qty,
                          v_cs_stock.s_can_use_qty,
                          nLocateQty,
                          strOperateType,
                          '要货量小于库存量并且库存量没有达到板出条件，不出M和P型');
        goto next_stock;
      end if;

      --要货量大于标准堆叠，可入最大板数为1板，则必须出空才能出P
      if (nLocateQty < v_cs_stock.S_QTY and
         nLocateQty >= v_cs_stock.PALLETE_QTY and v_cs_stock.MAX_QTY = 1) then
        p_write_short_log(strEnterpriseNo,
                          strWareHouseNo,
                          strWaveNo,
                          strOwnerNo,
                          nGroupNo,
                          'N',
                          'N',
                          'N',
                          v_cs_stock.cell_no,
                          strArticleNo,
                          -1,
                          v_cs_stock.packing_qty,
                          v_cs_stock.s_can_use_qty,
                          nLocateQty,
                          strOperateType,
                          '要货量大等于堆叠量且小于库存量，但货位可入板数为1，不出M和P型');
        goto next_stock;
      end if;

      --log20160320 modi by lizhiping 一个货位的最大板数大于1，尽量出空该货位
      v_nTotalCellQty := v_cs_stock.s_qty;
      loop

        if v_cs_stock.MAX_QTY = 1 then
          v_nCanAllotStockQty := v_nTotalCellQty;
        else
          --
          --Modify BY QZH AT 2016-4-25
          if nLocateQty >= mod(v_cs_stock.S_QTY, v_cs_stock.pallete_qty) and
             mod(v_cs_stock.S_QTY, v_cs_stock.pallete_qty) > 0 then
            v_nCanAllotStockQty := mod(v_cs_stock.S_QTY,
                                       v_cs_stock.pallete_qty);
          else
            v_nCanAllotStockQty := v_cs_stock.PALLETE_QTY;
          end if;
        end if;

        if v_nCanAllotStockQty > v_nTotalCellQty then
          v_nCanAllotStockQty := v_nTotalCellQty;
        end if;

        if v_nCanAllotStockQty > nLocateQty then
          v_nCanAllotStockQty := nLocateQty;
        end if;
        v_nCanAllotStockQty := floor(v_nCanAllotStockQty /
                                     v_cs_stock.Packing_Qty) *
                               v_cs_stock.Packing_Qty;

        if v_nCanAllotStockQty <= 0 then
          exit;
        end if;

        v_nAllotCellQty := nLocateQty;
        --写定位指示
        p_write_direct(v_nTmpStockID,
                       v_nAllotID,
                       strEnterPriseNo,
                       strWareHouseNo,
                       strOwnerNo, --仓库代码
                       strWaveNo, --定位号
                       nGroupNo, --出货组号
                       strDestCellNo, --目的储位
                       strOperateType, --定位类型
                       strBatchNo, --定位批次
                       strArticleNo, --商品代码
                       v_cs_stock.Cell_No,
                       v_cs_stock.Dept_No,
                       'N', --v_cs_stock.Container_No,
                       v_cs_stock.Packing_Qty,
                       v_nProduceFlag,
                       v_cs_stock.Produce_Date,
                       v_cs_stock.Quality, --商品品质
                       v_cs_stock.Lot_No,
                       --v_cs_stock.Supplier_No,
                       strStockType, --库存性质
                       strStockValue, --库存值
                       v_nCanAllotStockQty,
                       nLocateQty, --定位量
                       strWorkNo, --员工代码
                       Strexptype, --单据类型
                       strErrorMsg);
        if substr(strErrorMsg, 1, 2) = 'N|' then
          return;
        end if;

        --如果指示没有写足配给的量，退出
        if v_nAllotCellQty - nLocateQty < v_nCanAllotStockQty then
          exit;
        end if;

        --如果当次量已小于标准堆叠，说明能给的都给了
        if v_nCanAllotStockQty < v_cs_stock.PALLETE_QTY then
          exit;
        end if;

        v_nTotalCellQty := v_nTotalCellQty - (v_nAllotCellQty - nLocateQty);
        if v_nTotalCellQty <= 0 then
          exit;
        end if;
      end loop;
      <<next_stock>>
      null;
    end loop;

  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_locate_article_otype;

  --写库存及定位指示
  procedure p_write_direct(v_nTmpStockID   in number,
                           v_nAllotID      in number,
                           strEnterPriseNo in odata_locate_m.enterprise_no%type,
                           strWareHouseNo  in varchar2, --仓库代码
                           strOwnerNo      in odata_locate_m.owner_no%type,
                           strWaveNo       in varchar2, --定位号
                           nGroupNo        in number, --出货组号
                           strDestCellNo   in varchar2, --目的储位
                           strOperateType  in varchar2, --定位类型
                           strBatchNo      in varchar2, --定位批次
                           strArticleNo    in varchar2, --商品代码
                           strCellNo      in varchar2,
                           strDeptNo      in varchar2,
                           strContainerNo in varchar2,
                           nPacking_Qty   in number,
                           nProduceFlag   in number,
                           dtProduceDate  in date,
                           strQuality     in varchar2, --商品品质
                           --strItemType    in varchar2, --商品属性
                           strLotNo in varchar2,
                           --strSupplierNo  in varchar2,
                           strStockType  in varchar2, --库存性质
                           strStockValue in varchar2, --库存值
                           nStockQty     in number, --可定位库存量
                           nLocateQty    in out number, --定位量
                           strWorkNo     in varchar2, --员工代码
                           Strexptype    in varchar2, --单据类型
                           strErrorMsg   out varchar2) is

    v_nStockAllotQty stock_content.qty%type;
    v_nStockTotalQty stock_content.qty%type;

    v_nDirectTotalQty  stock_content.qty%type;
    v_nMiddataAllotQty stock_content.qty%type;
    v_nObjLeftQty      stock_content.qty%type;

    v_nDestCellID stock_content.cell_id%type;

    v_strStatus   odata_outstock_direct.status%type;
    v_strPickType odata_outstock_direct.pick_type%type;

    v_strLabelNo      stock_label_m.label_no%type;
    v_strContainerNo  stock_label_m.container_no%type;
    v_intPriority     wms_warehouse_outorder.PRIORITY%type;
    v_strBContainerNo stock_label_m.container_no%type;
    v_strcpscellno    cdef_defcell.cell_no%type;
    v_strPContainerNo stock_label_m.container_no%type;
    v_strAllotRule    wms_logibox_rule.allot_rule%type;

    v_strSESSION_ID varchar2(100);
    v_strtypecno    WMS_DEFBASE.SDEFINE%type;
  begin
    strErrorMsg := 'Y|';
    v_strcpscellno := 'N';

    --查看是否要允许分播作业

    --根据仓别和货主获取订单配置
    begin
      select Priority
        into v_intPriority
        from wms_warehouse_outorder
       where enterprise_no = strEnterPriseNo
         and warehouse_no = strWareHouseNo
         and owner_no = strOwnerNo
         and exp_type = Strexptype;
    exception
      when no_data_found then
        begin
          select Priority
            into v_intPriority
            from wms_owner_outorder
           where enterprise_no = strEnterPriseNo
             and owner_no = strOwnerNo
             and exp_type = Strexptype;
        exception
          when no_data_found then
            begin
              select Priority
                into v_intPriority
                from wms_outorder
               where enterprise_no = strEnterPriseNo
                 and exp_type = Strexptype;
            exception
              when no_data_found then
                v_intPriority := 100;
            end;
        end;
    end;

    if strOperateType in ('P', 'M') then
      PKLG_WMS_BASE.p_get_ContainerNoBase(strEnterPriseNo,
                                          strWareHouseNo,
                                          'P',
                                          strWorkNo,
                                          'D',
                                          1,
                                          2,
                                          31,
                                          v_strLabelNo,
                                          v_strContainerNo,
                                          v_strSESSION_ID,
                                          strErrorMsg);
      if substr(strErrorMsg, 1, 2) = 'N|' then
        return;
      end if;
    end if;
    v_nStockTotalQty := nStockQty;

    --获取客户总配量
    for Getmadetail in (select cust_no, allot_qty
                          from middata_allot_detail mad
                         where mad.warehouse_no = strWareHouseNo
                           and mad.source_no = strWaveNo
                           and mad.article_no = strArticleNo
                           and mad.enterprise_no = strEnterPriseNo
                           and mad.allot_qty > 0
                           and mad.batch_no = (case
                                 when strBatchNo = 'N' then
                                  mad.batch_no
                                 else
                                  strBatchNo
                               end)
                           and mad.tmp_id = v_nAllotID
                         order by mad.batch_no, mad.cust_no) loop

      p_write_log(strEnterpriseNo,
                  strWareHouseNo,
                  strWaveNo,
                  '获取客户总配量:' || Getmadetail.Cust_No || ',[' ||
                  Getmadetail.Allot_Qty || ']',
                  '10');

      --客户总分配量
      v_nMiddataAllotQty := Getmadetail.allot_qty;

      if nLocateQty <= 0 or v_nStockTotalQty <= 0 or
         v_nMiddataAllotQty <= 0 then
        exit;
      end if;

      --按配送对象要货量分配库存
      for GetDeliverObjQty in (select od.batch_no,
                                      od.deliver_obj,
                                      sum(od.plan_qty - od.located_qty) as Obj_left_qty
                                 from odata_locate_d od
                                where od.warehouse_no = strWareHouseNo
                                  and od.enterprise_no = strEnterPriseNo
                                  and od.wave_no = strWaveNo
                                  and od.trans_group_no = nGroupNo
                                  and od.article_no = strArticleNo
                                  and ((strBatchNo = 'N') or
                                      (strBatchNo <> 'N' and
                                      od.batch_no = strBatchNo))
                                  and od.stock_type = strStockType
                                  and od.cust_no = Getmadetail.cust_no
                                  and (strStockType = '1' or
                                      (strStockType = '2' and
                                      od.cust_no = strStockValue) or
                                      (strStockType = '3' and
                                      od.exp_no = strStockValue))
                                     --and od.quality = strQuality
                                  and od.plan_qty - od.located_qty > 0
                                group by od.batch_no, od.deliver_obj
                                order by od.batch_no, od.deliver_obj) loop

        v_nObjLeftQty := GetDeliverObjQty.Obj_Left_Qty;

        p_write_log(strEnterpriseNo,
                    strWareHouseNo,
                    strWaveNo,
                    '按配送对象要货量分配库存:' || GetDeliverObjQty.deliver_obj || ',[' ||
                    GetDeliverObjQty.Obj_left_qty || ']',
                    '10');

        for v_cs_direct in (select od.*,
                                   lb.b_divide_flag,
                                   lb.c_divide_flag,
                                   od.plan_qty - od.located_qty as left_qty,
                                   lb.last_pick_flag
                              from odata_locate_d od, ODATA_LOCATE_BATCH lb
                             where od.warehouse_no = strWareHouseNo
                               and od.enterprise_no = strEnterPriseNo
                               and od.wave_no = strWaveNo
                               and od.trans_group_no = nGroupNo
                               and od.article_no = strArticleNo
                               and ((strBatchNo = 'N') or
                                   (strBatchNo <> 'N' and
                                   od.batch_no = strBatchNo))
                                  --and (strCondition is null or
                                  --    od.condition = strCondition)
                               and od.stock_type = strStockType
                               and od.cust_no = Getmadetail.cust_no
                               and od.batch_no = GetDeliverObjQty.batch_no
                               and od.deliver_obj =
                                   GetDeliverObjQty.Deliver_Obj
                               and (strStockType = '1' or
                                   (strStockType = '2' and
                                   od.cust_no = strStockValue) or
                                   (strStockType = '3' and
                                   od.exp_no = strStockValue))
                                  --and od.quality = strQuality
                               and od.plan_qty - od.located_qty > 0
                               and od.enterprise_no = lb.enterprise_no
                               and od.warehouse_no = lb.warehouse_no
                               and od.wave_no = lb.wave_no
                               and od.batch_no = lb.batch_no) loop

          if nLocateQty <= 0 or v_nStockTotalQty <= 0 or
             v_nMiddataAllotQty <= 0 or v_nObjLeftQty <= 0 then
            exit;
          end if;

          --Add BY QZH AT 2016-5-5
          v_nDirectTotalQty := v_nObjLeftQty;
          --v_nDirectTotalQty := v_cs_direct.left_qty;

          --判断是否允许拆零，与箱规格判断
          if v_cs_direct.B_OUT_FLAG = '0' or
             strOperateType not in ('B', 'D') then

            if v_nDirectTotalQty < nPacking_Qty then
              --if v_nDirectTotalQty < v_nPacking_QTY then
              p_write_short_log(strEnterpriseNo,
                                strWareHouseNo,
                                strWaveNo,
                                strOwnerNo,
                                nGroupNo,
                                v_cs_direct.exp_no,
                                v_cs_direct.cust_no,
                                v_cs_direct.sub_cust_no,
                                strCellNo,
                                strArticleNo,
                                -1,
                                nPacking_Qty,
                                nStockQty,
                                v_nDirectTotalQty,
                                strOperateType,
                                '客户或订单不允许拆零出货');
              goto next_direct;
            end if;

            v_nDirectTotalQty := floor(v_nDirectTotalQty / nPacking_Qty) *
                                 nPacking_Qty;
          end if;

          if v_nDirectTotalQty > v_cs_direct.left_qty then
            v_nDirectTotalQty := v_cs_direct.left_qty;
          end if;

          if v_nDirectTotalQty > nLocateQty then
            v_nDirectTotalQty := nLocateQty;
          end if;

          if v_nDirectTotalQty > v_nStockTotalQty then
            v_nDirectTotalQty := v_nStockTotalQty;
          end if;

          for v_cs_stock in (select *
                               from (select sc.*,
                                            ca.b_divide_flag,
                                            ca.divide_flag as c_divide_flag,
                                            sai.produce_date,
                                            sc.QTY - sc.OUTSTOCK_QTY +
                                            (case sc.Instock_Type
                                              when '1' then
                                               sc.INSTOCK_QTY
                                              else
                                               0
                                            end) + sC.UNUSUAL_QTY as use_qty,
                                            bda.qmin_operate_packing
                                       from stock_content      sc,
                                            stock_article_info sai,
                                            bdef_defarticle    bda,
                                            cdef_defarea       ca,
                                            cdef_defcell       ce
                                      where bda.enterprise_no =
                                            sc.enterprise_no
                                        and bda.article_no = sc.article_no
                                        and sc.article_no = sai.article_no
                                        and sc.article_id = sai.article_id
                                           --Add BY QZH AT 2016-5-25
                                        and exists
                                      (select 'x'
                                               from tmp_stock_content tmpsc
                                              where sc.enterprise_no =
                                                    tmpsc.enterprise_no
                                                AND sc.warehouse_no =
                                                    tmpsc.warehouse_no
                                                AND sc.cell_no = tmpsc.cell_no
                                                And sc.cell_id = tmpsc.cell_id
                                                and tmpsc.tmp_id =
                                                    v_nTmpStockID)
                                           --Add End
                                        and sc.enterprise_no =
                                            ce.enterprise_no
                                        and sc.warehouse_no = ce.warehouse_no
                                        and sc.cell_no = ce.cell_no
                                        and ce.enterprise_no =
                                            ca.enterprise_no
                                        and ce.warehouse_no = ca.warehouse_no
                                        and ce.ware_no = ca.ware_no
                                        and ce.area_no = ca.area_no
                                        and sc.enterprise_no =
                                            sai.enterprise_no
                                        and sc.enterprise_no =
                                            strEnterPriseNo
                                        and sc.warehouse_no = strWareHouseNo
                                        and sc.dept_no = strDeptNo
                                        and sc.cell_no = strCellNo
                                        and sc.packing_qty = nPacking_Qty
                                        and sc.stock_type = strStockType
                                        and sc.stock_value = strStockValue
                                        and sai.article_no = strArticleNo
                                        and sai.lot_no = strLotNo
                                        and sc.flag <> '2'
                                        and (nProduceFlag = 0 or
                                            (nProduceFlag = 1 and
                                            sai.produce_date =
                                            dtProduceDate))
                                        and sai.quality = strQuality
                                        and sc.QTY - sc.OUTSTOCK_QTY +
                                            sc.INSTOCK_QTY + sC.UNUSUAL_QTY > 0)
                              where use_qty > 0
                              order by produce_date) loop

            if nLocateQty <= 0 then
              exit;
            end if;

            v_nStockAllotQty := v_cs_stock.use_qty;

            /* --log20151222 modi by lizhiping 非B型作业只能取整箱的整数倍的数量
            if strOperateType <> 'B' or v_cs_direct.B_OUT_FLAG = '0' then
              v_nStockAllotQty := floor(v_cs_stock.use_qty /
                                        v_cs_stock.packing_qty) *
                                  v_cs_stock.packing_qty;
            end if;
            --end log20151222*/

            if v_nStockAllotQty > v_nDirectTotalQty then
              v_nStockAllotQty := v_nDirectTotalQty;
            end if;

            --log20160416 add by lizhiping 出货必须是最小操作包装的整数倍
            v_nStockAllotQty := floor(v_nStockAllotQty /
                                      v_cs_stock.qmin_operate_packing) *
                                v_cs_stock.qmin_operate_packing;
            --end log20160416

            --总定位量
            nLocateQty := nLocateQty - v_nStockAllotQty;
            --当前指示要货量
            v_nDirectTotalQty := v_nDirectTotalQty - v_nStockAllotQty;
            --可用库存总量
            v_nStockTotalQty := v_nStockTotalQty - v_nStockAllotQty;
            --客户总配量
            v_nMiddataAllotQty := v_nMiddataAllotQty - v_nStockAllotQty;

            if v_nStockAllotQty <= 0 then
              goto next_stock;
            end if;

            --写库存
            PKOBJ_STOCK.p_UpdtContent_Reservation(strEnterPriseNo,
                                                  strWareHouseNo,
                                                  v_cs_stock.cell_no,
                                                  v_cs_stock.cell_id,
                                                  strDestCellNo,
                                                  'N',
                                                  'N',
                                                  v_nStockAllotQty,
                                                  '0',
                                                  strWorkNo,
                                                  v_nDestCellID,
                                                  strErrorMsg);
            if substr(strErrorMsg, 1, 2) = 'N|' then
              return;
            end if;

            --Add BY QZH AT 2013-12-21 刷手工移库标识
            update stock_content cc
               set cc.mv_hand_flag = '0'
             where cc.cell_no = strDestCellNo
               and cc.warehouse_no = strWareHouseNo
               and cc.enterprise_no = strEnterPriseNo
               and cc.cell_id = v_nDestCellID;

            if v_nStockAllotQty > v_cs_stock.qty - v_cs_stock.outstock_qty +
               v_cs_stock.UNUSUAL_QTY then
              v_strStatus := '11';
            else
              v_strStatus := '10';
            end if;

            v_strPContainerNo := 'N';
            v_strBContainerNo := 'N';

            --获取物流箱试算规则
            begin
              select A.ALLOT_RULE
                into v_strAllotRule
                from WMS_LOGIBOX_RULE A, ODATA_LOCATE_BATCH B
               WHERE A.ENTERPRISE_NO = B.ENTERPRISE_NO
                 AND A.RULE_ID = B.DIVIDE_LOGIBOX_RULE_ID --物流箱试算策略
                 AND B.WAREHOUSE_NO = strWarehouseNo
                 AND B.ENTERPRISE_NO = strEnterPriseNo
                 AND B.Wave_No = strWaveNo
                 AND B.Batch_No = v_cs_direct.batch_no
                 AND rownum = 1;
            exception
              when no_data_found then
                strErrorMsg := 'N|[没获取到批次[' || v_cs_direct.batch_no ||
                               ']物流箱试算规则]';
                return;
            end;

            --pick_type值判断
            if strOperateType = 'P' or (strOperateType in ('D', 'B') and
               (v_cs_direct.b_divide_flag = 0 or
               v_cs_stock.b_divide_flag = 0)) or
               (strOperateType = 'C' and (v_cs_direct.c_divide_flag = 0 or
               v_cs_stock.c_divide_flag = 0)) then
              v_strPickType := '0';
            elsif (strOperateType in ('D', 'B') and
                  v_cs_stock.b_divide_flag = 1
                  and v_cs_direct.b_divide_flag =2 ) or
                  (strOperateType = 'C' and v_cs_stock.c_divide_flag = 1
                  and v_cs_direct.c_divide_flag =2) then
              v_strPickType := '2';
            else
              v_strPickType := '1';
            end if;

            --如果波次策略有配置LAST_PICK_FLAG值，则下架指示统一刷为配置值
            if v_cs_direct.last_pick_flag <> 'N' then
              v_strPickType := v_cs_direct.last_pick_flag;
            end if;

            --写指示
            insert into odata_outstock_direct
              (enterprise_no,
               warehouse_no,
               OUTSTOCK_TYPE,
               SOURCE_TYPE,
               OPERATE_TYPE,
               PICK_TYPE,
               owner_no,
               batch_no,
               operate_date,
               cust_no,
               sub_cust_no,
               article_no,
               article_id,
               STOCK_TYPE,
               packing_qty,
               LOCATE_QTY,
               s_cell_no,
               s_cell_id,
               D_CELL_NO,
               D_CELL_ID,
               s_container_no,
               LABEL_NO,
               exp_type,
               exp_no,
               wave_no,
               deliver_area,
               status,
               TEMP_STATUS,
               line_no,
               PRIORITY,
               deliver_obj,
               exp_date,
               SUPP_COUNT,
               DPS_CELL_NO,
               rgst_name,
               rgst_date,
               updt_name,
               updt_date)
              select strEnterPriseNo,
                     om.warehouse_no,
                     '0',
                     om.source_type,
                     --按商品试算物流箱，统一作业类型为B，方便切单
                     case
                       when (v_strtypecno = '1' or v_strAllotRule = '3') then
                        'B'
                       else
                        strOperateType
                     end,
                     v_strPickType,
                     od.owner_no,
                     od.batch_no,
                     trunc(om.locate_date) as operate_date,
                     od.cust_no,
                     od.sub_cust_no,
                     strArticleNo,
                     v_cs_stock.article_id,
                     v_cs_stock.STOCK_TYPE,
                     nPacking_Qty,
                     v_nStockAllotQty,
                     v_cs_stock.cell_no,
                     v_cs_stock.cell_id,
                     strDestCellNo,
                     v_nDestCellID,
                     case
                       when strOperateType in ('P', 'M') then
                        v_strContainerNo
                       else
                        'N'
                     end,
                     case
                       when strOperateType in ('P', 'M') then
                        v_strLabelNo
                       else
                        v_cs_stock.label_no
                     end,
                     om.exp_type,
                     od.exp_no,
                     om.wave_no,
                     'N',
                     'N',
                     v_strStatus,
                     od.line_no,
                     v_intPriority,
                     case
                       when lb.deliver_obj_level = '1' then
                        oem.sourceexp_no
                       else
                        od.cust_no
                     end,
                     trunc(om.exp_date),
                     nvl((select max(sc.SUPP_COUNT)
                           from odata_outstock_direct sc
                          where sc.warehouse_no = om.warehouse_no
                            and sc.enterprise_no = om.enterprise_no
                            and sc.d_cell_no = v_cs_stock.cell_no
                            and sc.d_cell_id = v_cs_stock.cell_id),
                         0),
                     case
                       when ((strOperateType = 'B' or v_strtypecno = '1') and
                            cda.b_divide_flag = 1 and lb.b_divide_flag = 1) then
                        v_strcpscellno
                       else
                        'N'
                     end,
                     strWorkNo,
                     sysdate,
                     strWorkNo,
                     sysdate
                from cdef_defarea   cda,
                     cdef_defcell   cdc,
                     odata_locate_m om,
                     --WMS_OUTSTOCK_SET wos,
                     odata_locate_d     od,
                     ODATA_LOCATE_BATCH lb,
                     odata_exp_m        oem
               where cda.warehouse_no = cdc.warehouse_no
                 and cda.enterprise_no = cdc.enterprise_no
                 and cdc.enterprise_no = om.enterprise_no
                 and cdc.enterprise_no = od.enterprise_no
                 and oem.enterprise_no = od.enterprise_no
                 and oem.warehouse_no = od.warehouse_no
                 and od.exp_no = oem.exp_no
                 and cdc.enterprise_no = strEnterPriseNo
                 and cda.ware_no = cdc.ware_no
                 and cda.area_no = cdc.area_no
                 and cdc.warehouse_no = strWareHouseNo
                 and cdc.cell_no = v_cs_stock.cell_no
                    --and wos.exp_type = om.exp_type
                 and om.warehouse_no = od.warehouse_no
                 and om.wave_no = od.wave_no
                 and od.warehouse_no = strWareHouseNo
                 and od.wave_no = v_cs_direct.wave_no
                 and od.exp_no = v_cs_direct.exp_no
                 and od.ROW_ID = v_cs_direct.ROW_ID
                 and od.enterprise_no = lb.enterprise_no
                 and od.warehouse_no = lb.warehouse_no
                 and od.wave_no = lb.wave_no
                 and od.batch_no = lb.batch_no;

            if sql%rowcount <= 0 then
              strErrorMsg := 'N|[E3201905]';
              return;
            end if;

            --回写定位指示明细定位量
            update odata_locate_d od
               set od.located_qty = od.located_qty + v_nStockAllotQty
             where od.warehouse_no = strWareHouseNo
               and od.enterprise_no = strEnterPriseNo
               and od.wave_no = v_cs_direct.wave_no
               and od.exp_no = v_cs_direct.exp_no
               and od.ROW_ID = v_cs_direct.ROW_ID;

            --回写出货单明细定位数量
            P_UpdateExpLocateQty(strEnterPriseNo,
                                 strWareHouseNo,
                                 v_cs_direct.owner_no,
                                 v_cs_direct.exp_no,
                                 strArticleNo,
                                 v_nStockAllotQty,
                                 strErrorMsg);
            if substr(strErrorMsg, 1, 2) = 'N|' then
              return;
            end if;

            --单据状态跟踪
            PKOBJ_ODISPATCH.P_Insert_Odata_Exp_Trace(strEnterPriseNo,
                                                     strWareHouseNo,
                                                     v_cs_direct.exp_no,
                                                     '05',
                                                     strWorkNo,
                                                     strErrorMsg);
            if substr(strErrorMsg, 1, 2) = 'N|' then
              return;
            end if;

            --回写客户配量临时表分配量
            update middata_allot_detail mad
               set mad.allot_qty = mad.allot_qty - v_nStockAllotQty
             where mad.warehouse_no = strWareHouseNo
               and mad.source_no = strWaveNo
               and mad.article_no = strArticleNo
               and mad.enterprise_no = strEnterPriseNo
               and mad.allot_qty > 0
               and mad.cust_no = Getmadetail.Cust_No
               and mad.tmp_id = v_nAllotID
               and mad.batch_no = v_cs_direct.batch_no;

            if v_nDirectTotalQty <= 0 then
              exit;
            end if;

            <<next_stock>>
            null;
          end loop;

          <<next_direct>>
          null;
        end loop;

      end loop;
    end loop;
  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_write_direct;

  --计算拆零或者箱拣货补货量
  procedure p_calculate_suppQty(v_nTmpStockID     in number,
                                strEnterPriseNo   in odata_locate_m.enterprise_no%type,
                                strWareHouseNo    in varchar2, --仓库代码
                                strWaveNo         in varchar2, --定位号
                                nGroupNo          in number, --出货组号
                                strArticleNo      in varchar2, --商品代码
                                strPickType       in varchar2, --计算类型 'B','C'
                                strBPickCellNo    in varchar2,
                                strCPickCellNo    in varchar2,
                                strDFlag          in odata_locate_batch.d_flag%type,
                                nCMaxQty          in cset_cell_article.max_qty_a%type,
                                nBMaxQty          in cset_cell_article.max_qty_a%type,
                                strBrepLenishRule in varchar2,
                                strCrepLenishRule in varchar2,
                                --strCondition   in varchar2, --特殊条件
                                --strItemType    in varchar2, --商品属性
                                strStockType in varchar2, --库存性质
                                --strQuality     in varchar2, --商品品质
                                nLocateQty  in number, --定位量
                                nSupQty     out number,
                                nMinSupQty  out number,
                                strErrorMsg out varchar2) is

    v_nBNeedQty   odata_locate_d.plan_qty%type; --B型补货量
    --v_nCNeedQty   odata_locate_d.plan_qty%type; --C型补货量
    --v_nSumNeedQty odata_locate_d.plan_qty%type; --总补货量
    --v_nNeedQty    odata_locate_d.plan_qty%type;

    v_nPickStockQty odata_locate_d.plan_qty%type;
    v_nPickMaxQty   odata_locate_d.plan_qty%type;
    --v_nPickSuppQty  odata_locate_d.plan_qty%type;
    v_strBRule        cdef_defarea.B_REPLENISH_RULE%type;
    v_strCRule        cdef_defarea.C_REPLENISH_RULE%type;
    v_strRuleID       wms_defrule.Rule_id%type;
    v_Divide_Flag     cdef_defarea.divide_flag%type;
    v_nCPickCellCount number(2) := 0;
    v_nBPickCellCount number(2) := 0;
    v_nMaxPackingQty  number(5);

  begin
    strErrorMsg := 'Y|';
    nSupQty     := 0;
    nMinSupQty  := 0;
    --读取策略
    v_strBRule := strBrepLenishRule;
    v_strCRule := strCrepLenishRule;

    --获取商品库存最大包装
    select nvl(max(sc.packing_qty), 1)
      into v_nMaxPackingQty
      from stock_content sc
     where sc.warehouse_no = strWareHouseNo
       and sc.article_no = strArticleNo
       and sc.enterprise_no = strEnterPriseNo;

    /* --取总要货量,总零散量
    select nvl(sum(qty), 0), nvl(sum(SumBqty), 0), nvl(sum(SumCqty), 0)
      into v_nSumNeedQty, v_nBNeedQty, v_nCNeedQty
      from (select od.cust_no,
                   sum(od.plan_qty - od.located_qty) as qty,
                   mod(sum(od.plan_qty - od.located_qty), v_nMaxPackingQty) as SumBqty,
                   trunc(sum(od.plan_qty - od.located_qty) /
                         v_nMaxPackingQty) * v_nMaxPackingQty as SumCqty
              from odata_locate_d od
             where od.warehouse_no = strWareHouseNo
               and od.enterprise_no = strEnterPriseNo
               and od.wave_no = strWaveNo
               and od.trans_group_no = nGroupNo
               and od.article_no = strArticleNo
                  --and od.item_type = strItemType
               and od.stock_type = strStockType
                  --and od.Quality = strQuality
               and od.b_out_flag = '1'
             group by od.cust_no);*/

    if strCPickCellNo <> 'N' then
      v_nCPickCellCount := 1;
    end if;

    if strBPickCellNo <> 'N' then
      v_nBPickCellCount := 1;
    end if;

    v_nBNeedQty := nLocateQty;

    if strPickType = 'B' then
      --有箱拣货位
      if v_nCPickCellCount > 0 then

        select distinct cda.b_divide_flag
          into v_Divide_Flag
          from cdef_defarea cda, cdef_defcell cdc
         where cdc.warehouse_no = cda.warehouse_no
           and cdc.ware_no = cda.ware_no
           and cdc.area_no = cda.area_no
           and cdc.cell_no = strCPickCellNo;

        --不能出D或不允许分播
        if strDFlag = '0' or v_Divide_Flag = '0' then
          select nvl(sum(qty), 0)
            into v_nBNeedQty
            from (select od.cust_no,
                         sum(mod((od.plan_qty - od.located_qty),
                                 v_nMaxPackingQty)) as qty
                    from odata_locate_d od
                   where od.warehouse_no = strWareHouseNo
                     and od.enterprise_no = strEnterPriseNo
                     and od.wave_no = strWaveNo
                     and od.trans_group_no = nGroupNo
                     and od.article_no = strArticleNo
                     and od.stock_type = strStockType
                     and od.b_out_flag = '1'
                   group by od.cust_no);
        else
          v_nBNeedQty := mod(nLocateQty, v_nMaxPackingQty);
        end if;
      end if;
    end if;

    --箱型拣货
    if strPickType = 'C' then
      --有零有箱拣货位
      if v_nCPickCellCount > 0 and v_nBPickCellCount > 0 then
        select nvl(sum(qty), 0)
          into v_nBNeedQty
          from (select od.cust_no,
                       sum(trunc((od.plan_qty - od.located_qty) /
                                 v_nMaxPackingQty) * v_nMaxPackingQty) as qty
                  from odata_locate_d od
                 where od.warehouse_no = strWareHouseNo
                   and od.enterprise_no = strEnterPriseNo
                   and od.wave_no = strWaveNo
                   and od.trans_group_no = nGroupNo
                   and od.article_no = strArticleNo
                   and od.stock_type = strStockType
                 group by od.cust_no);
      end if;
    end if;

    /* --计算补货量
      if v_nCPickCellCount > 0 then
        if strPickType = 'B' then
          select nvl(sum(qty), 0)
            into v_nBNeedQty
            from (select od.cust_no,
                         sum(mod((od.plan_qty - od.located_qty),
                                 v_nMaxPackingQty)) as qty
                    from odata_locate_d od
                   where od.warehouse_no = strWareHouseNo
                     and od.enterprise_no = strEnterPriseNo
                     and od.wave_no = strWaveNo
                     and od.trans_group_no = nGroupNo
                     and od.article_no = strArticleNo
                        --and od.item_type = strItemType
                     and od.stock_type = strStockType
                        --and od.Quality = strQuality
                     and od.b_out_flag = '1'
                   group by od.cust_no);

        else
          --箱补货，有拆零拣货位，只补整箱要货量，没拆零拣货位，补全部要货量
          if strBPickCellNo <> 'N' then
            select nvl(sum(qty), 0)
              into v_nBNeedQty
              from (select od.cust_no,
                           sum(trunc((od.plan_qty - od.located_qty) /
                                     v_nMaxPackingQty) *v_nMaxPackingQty
                               ) as qty
                      from odata_locate_d od
                     where od.warehouse_no = strWareHouseNo
                       and od.enterprise_no = strEnterPriseNo
                       and od.wave_no = strWaveNo
                       and od.trans_group_no = nGroupNo
                       and od.article_no = strArticleNo
                          --and od.item_type = strItemType
                       and od.stock_type = strStockType
                    --and od.Quality = strQuality
                     group by od.cust_no);
          else
            v_nBNeedQty := nLocateQty;
          end if;
        End if;
      else
        v_nBNeedQty := nLocateQty;
      end if;
    */
    if strPickType = 'B' then
      begin
        select nvl(sum(sc.qty - sc.outstock_qty + case
                         when sc.instock_type = '1' then
                          instock_qty
                         else
                          0
                       end),
                   0),
               nBMaxQty
          into v_nPickStockQty, v_nPickMaxQty
          from stock_content   sc,
               cdef_defcell    cd,
               cdef_defarea    cda,
               bdef_defarticle bda
         where sc.enterprise_no = cd.enterprise_no
           and sc.warehouse_no = cd.warehouse_no
           and sc.cell_no = cd.cell_no
           and sc.warehouse_no = strWareHouseNo
           and sc.enterprise_no = strEnterPriseNo
           and cd.enterprise_no = cda.enterprise_no
           and cd.warehouse_no = cda.warehouse_no
           and cd.ware_no = cda.ware_no
           and cd.area_no = cda.area_no
           and cda.area_pick = '1'
           and cda.o_type = 'B'
           and sc.article_no = strArticleNo
              --ADD BY QZH AT 2016-7-4 算库存时，小于最小操作包装的库存不算
           and bda.article_no = sc.article_no
           and bda.enterprise_no = sc.enterprise_no
           and sc.qty + (case sc.instock_type
                 when '1' then
                  sc.instock_qty
                 else
                  0
               end) >= bda.qmin_operate_packing
              --ADD End
           and sc.flag <> 2
           and EXISTS (select 'x'
                  from tmp_stock_content tsc
                 where tsc.warehouse_no = sc.warehouse_no
                   and tsc.enterprise_no = sc.enterprise_no
                   and tsc.cell_no = sc.cell_no
                   and tsc.cell_id = sc.cell_id);
      exception
        when no_data_found then
          v_nPickStockQty := 0;
          select decode(strPickType, 'B', nBMaxQty, nCMaxQty)
            into v_nPickMaxQty
            from dual;
      end;
    end if;

    if strPickType = 'C' then

      begin
        select nvl(sum(sc.qty - sc.outstock_qty + case
                         when sc.instock_type = '1' then
                          instock_qty
                         else
                          0
                       end),
                   0),
               nCMaxQty
          into v_nPickStockQty, v_nPickMaxQty
          from stock_content   sc,
               cdef_defcell    cd,
               cdef_defarea    cda,
               bdef_defarticle bda
         where sc.enterprise_no = cd.enterprise_no
           and sc.warehouse_no = cd.warehouse_no
           and sc.cell_no = cd.cell_no
           and sc.warehouse_no = strWareHouseNo
           and sc.enterprise_no = strEnterPriseNo
           and cd.enterprise_no = cda.enterprise_no
           and cd.warehouse_no = cda.warehouse_no
           and cd.ware_no = cda.ware_no
           and cd.area_no = cda.area_no
           and cda.area_pick = '1'
           and cda.o_type = 'C'
           and sc.article_no = strArticleNo
              --ADD BY QZH AT 2016-7-4 算库存时，小于最小操作包装的库存不算
           and bda.article_no = sc.article_no
           and bda.enterprise_no = sc.enterprise_no
           and sc.qty + (case sc.instock_type
                 when '1' then
                  sc.instock_qty
                 else
                  0
               end) >= bda.qmin_operate_packing
              --ADD End
           and sc.flag <> 2
           and EXISTS (select 'x'
                  from tmp_stock_content tsc
                 where tsc.warehouse_no = sc.warehouse_no
                   and tsc.enterprise_no = sc.enterprise_no
                   and tsc.cell_no = sc.cell_no
                   and tsc.cell_id = sc.cell_id);
      exception
        when no_data_found then
          v_nPickStockQty := 0;
          select decode(strPickType, 'B', nBMaxQty, nCMaxQty)
            into v_nPickMaxQty
            from dual;
      end;
    end if;

    --根据补货策略配置判断需要补
    for GetRuleID in (select wd.RULE_ID
                        from wms_replenish_formula_d wrf, wms_defrule wd
                       where wrf.STRATEGY_TYPE = wd.STRATEGY_TYPE
                         and wrf.RULE_ID = wd.RULE_ID
                         and wrf.strategy_id = case
                               when strPickType = 'B' then
                                v_strBRule
                               else
                                v_strCRule
                             end) loop
      v_strRuleID := GetRuleID.RULE_ID;

      if (v_nPickStockQty >= v_nBNeedQty) then
        --库存量大于需求量
        nSupQty := 0;
      else
        --当拣货位库存量<需求量<储位最大量，补货量=储位最大量-拣货位库存量
        if v_strRuleID = '1' and v_nBNeedQty < v_nPickMaxQty then
          nMinSupQty := v_nBNeedQty - v_nPickStockQty;
          nSupQty    := v_nPickMaxQty - v_nPickStockQty;

        end if;

        --当拣货位库存量<需求量<储位最大量，补货量=储位最大量
        if v_strRuleID = '2' and v_nBNeedQty < v_nPickMaxQty then
          nMinSupQty := v_nBNeedQty - v_nPickStockQty;
          nSupQty    := v_nPickMaxQty;
        end if;

        --当拣货位库存量<需求量<储位最大量，补货量=储位最大量+需求量-拣货位库存量
        if v_strRuleID = '3' and v_nBNeedQty < v_nPickMaxQty then
          nMinSupQty := v_nBNeedQty - v_nPickStockQty;
          nSupQty    := v_nPickMaxQty + v_nBNeedQty - v_nPickStockQty;
        end if;

        --当需求量>=储位最大量，补货量=需求量
        if v_strRuleID = '4' and v_nBNeedQty >= v_nPickMaxQty then
          nMinSupQty := v_nBNeedQty - v_nPickStockQty;
          nSupQty    := v_nBNeedQty;
        end if;

        --当需求量>=储位最大量，补货量=需求量-拣货位库存量+最大存储量
        if v_strRuleID = '5' and v_nBNeedQty >= v_nPickMaxQty then
          nMinSupQty := v_nBNeedQty - v_nPickStockQty;
          nSupQty    := v_nBNeedQty - v_nPickStockQty + v_nPickMaxQty;
        end if;

        --Modify BY QZH AT 2016-7-6 补货量=需求量-拣货位库存量+最大存储量
        if v_strRuleID = '6' then
          nMinSupQty := v_nBNeedQty - v_nPickStockQty;
          nSupQty    := v_nBNeedQty - v_nPickStockQty + v_nPickMaxQty;
        end if;

        --Add BY QZH AT 2016-7-8
        nMinSupQty := ceil(nMinSupQty / v_nMaxPackingQty) *
                      v_nMaxPackingQty;
        nSupQty    := ceil(nSupQty / v_nMaxPackingQty) * v_nMaxPackingQty;

      end if;

    end loop;
  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_calculate_suppQty;

  --计算拆零量
  procedure p_calculate_bSPlitQty(strEnterPriseNo in odata_locate_m.enterprise_no%type,
                                  strWareHouseNo  in varchar2, --仓库代码
                                  strWaveNo       in varchar2, --定位号
                                  strErrorMsg     out varchar2) is

    v_nRealSplitQTY stock_content.qty%type;
    v_nNewCellID    stock_content.cell_id%type := -1;
  begin
    strErrorMsg := 'Y|[p_calculate_bSPlitQty]';

    for v_cs_stock in (select t.s_cell_no,
                              t.s_cell_id,
                              bda.qmin_operate_packing,
                              sc2.packing_qty c_packing_qty,
                              sum(t.locate_qty) locate_qty,
                              nvl(sum(sc2.qty), 0) stock_c_qty,
                              nvl(sum(sc.qty), 0) stock_b_qty
                         from odata_outstock_direct t
                        inner join bdef_defarticle bda
                           on t.enterprise_no = bda.enterprise_no
                          and t.article_no = bda.article_no
                         left join stock_content sc
                           on sc.enterprise_no = t.enterprise_no
                          and sc.warehouse_no = t.warehouse_no
                          and sc.cell_no = t.s_cell_no
                          and sc.cell_id = t.s_cell_id
                          and sc.packing_qty = bda.qmin_operate_packing
                        inner join stock_content sc2
                           on sc2.enterprise_no = t.enterprise_no
                          and sc2.warehouse_no = t.warehouse_no
                          and sc2.cell_no = t.s_cell_no
                          and sc2.cell_id = t.s_cell_id
                          and sc2.packing_qty > bda.qmin_operate_packing
                        where t.enterprise_no = strEnterPriseNo
                          and t.warehouse_no = strWareHouseNo
                          and t.operate_type = 'B'
                          and t.status = '10'
                          and t.wave_no = strWaveNo
                        group by t.s_cell_no,
                                 t.s_cell_id,
                                 bda.qmin_operate_packing,
                                 sc2.packing_qty
                       having sum(t.locate_qty) > nvl(sum(sc.qty), 0)) loop

      --尾数是否足够
      if ((v_cs_stock.stock_c_qty mod v_cs_stock.c_packing_qty) >=
         (v_cs_stock.locate_qty - v_cs_stock.stock_b_qty) mod
          v_cs_stock.c_packing_qty) then
        v_nRealSplitQTY := v_cs_stock.stock_c_qty mod
                           v_cs_stock.c_packing_qty;
        v_nRealSplitQTY := v_nRealSplitQTY +
                           floor((v_cs_stock.locate_qty -
                                 v_cs_stock.stock_b_qty) /
                                 v_cs_stock.c_packing_qty);
      else
        v_nRealSplitQTY := v_cs_stock.stock_c_qty mod
                           v_cs_stock.c_packing_qty;
        v_nRealSplitQTY := v_nRealSplitQTY +
                           ceil((v_cs_stock.locate_qty -
                                v_cs_stock.stock_b_qty) /
                                v_cs_stock.c_packing_qty);
      end if;

      pkobj_stock.p_TransContent_C2B(strEnterPriseNo,
                                     strWareHouseNo,
                                     v_cs_stock.s_cell_no,
                                     v_cs_stock.s_cell_id,
                                     v_nRealSplitQTY,
                                     v_cs_stock.locate_qty -
                                     v_cs_stock.stock_b_qty,
                                     v_cs_stock.qmin_operate_packing,
                                     v_nNewCellID,
                                     strErrorMsg);
      if substr(strErrorMsg, 1, 2) = 'N|' then
        return;
      end if;

      update odata_outstock_direct t
         set t.s_cell_id   = v_nNewCellID,
             t.packing_qty = v_cs_stock.qmin_operate_packing
       where t.s_cell_no = v_cs_stock.s_cell_no
         and t.s_cell_id = v_cs_stock.s_cell_id
         and t.warehouse_no = strWareHouseNo
         and t.enterprise_no = strEnterPriseNo
         and t.wave_no = strWaveNo
         and t.status = '10'
         and t.operate_type = 'B';

    end loop;
  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_calculate_bSPlitQty;

  /**************************************************************************************8
   功能说明：1、做订单取消:
                a、初始状态，并未定位数据可取消；
                b、状态〉10的单据不能做取消
                处理步骤：
                a、将状态置位16,
                b、写订单跟踪；
             2、关单(对于可多次定位的订单，并且按单配送的项目，装车前必须要整订单完成才能做装车，当
               库存不足，需要人为强制结束订单才能做装车，故使用此功能，把状态改为12
                处理步骤：
                a、将状态置位12,
                b、写订单跟踪；
   创建人：luouzhiling
    创建时间：2014.12.4
  ****************************************************************************************/
  procedure p_close_exp(strCurrEnterpriseNo in odata_exp_m.enterprise_no%type,
                        strWareHouseNo      in odata_exp_m.warehouse_no%type,
                        strExpNo            in odata_exp_m.exp_no%type,
                        strOpereateType     in odata_exp_m.fast_flag%type, --1:取消；2：关单
                        strWorkNo           in varchar2, --员工代码
                        strErrorMsg         out varchar2) is
    v_iCount integer;
    v_strStatus      odata_exp_m.status%type;
    nSum_QTY         number;
    v_strOperateType odata_exp_m.fast_flag%type:=strOpereateType; --1:取消；2：关单
    v_strExpType odata_exp_m.exp_type%type;
    v_strIndustry wms_outorder.industry_flag%type;
    v_strUpdateFlag   varchar2(20):='0';          --更新标识，0：不更新；1，更新
    v_strUpdtStatus   odata_exp_m.status%type;--更新状态
    v_strExpStatus    odata_exp_m.exp_status%type;  --订单跟踪状态
    v_strCurrStatus   odata_exp_status.curr_status%type;--当前订单状态
  begin
    strErrorMsg := 'N|[p_close_exp]';

    --检查此出货单是什么状态
    begin
      select sum(d.locate_qty),m.exp_type,od.industry_flag,m.status
        into nSum_QTY,v_strExpType,v_strIndustry,v_strStatus
        from odata_exp_d d,odata_exp_m m,wms_outorder od
       where d.enterprise_no = strCurrEnterpriseNo
         and d.warehouse_no = strWareHouseNo
         and d.exp_no = strExpNo
         and d.enterprise_no = m.enterprise_no
         and d.warehouse_no = m.warehouse_no
         and d.exp_no = m.exp_no
         and m.enterprise_no = od.enterprise_no
         and m.exp_type = od.exp_type
         group by m.exp_type,od.industry_flag,m.status;
     exception when no_data_found then
         strErrorMsg:='N|[找不到订单信息]';
         return;
     end;

     begin
          select t.curr_status into v_strCurrStatus
              from odata_exp_status t where t.enterprise_no=strCurrEnterpriseNo
              and t.warehouse_no=strWareHouseNo and t.exp_no=strExpNo;
     exception when no_data_found then
         strErrorMsg:='N|[找不到订单跟踪信息]';
         return;
     end;

    --取消
    if strOpereateType = '1' then
      --未定位或未定到位，取消订单
      if nSum_QTY = 0 then
         v_strUpdateFlag:='1';
         v_strUpdtStatus:='16';
         v_strExpStatus:='90';
      else--已经定位,电商的单已定位也可以取消，传统的订单已定位不允许取消
          --传统行业
          if v_strStatus not in('13','16') then
             if v_strCurrStatus in ('55','60') then
                strErrorMsg:='N|[已装车的单不允许直接取消]';
                return;
             else
                if v_strIndustry = '1' then
                   strErrorMsg:='N|[已定位的单不允许直接取消]';
                   return;
                else
                    v_strUpdateFlag:='1';
                    v_strUpdtStatus:='16';
                    v_strExpStatus:='90';
                end if;
             end if;
          else
             strErrorMsg:='N|[此订单已结案或已取消，不能更新]';
             return;
          end if;
      end if;
    end if;

    --关单
    if strOpereateType = '2' then
      --已定位，部分缺量
      select t.status
        into v_strStatus
        from odata_exp_m t
       where t.enterprise_no = strCurrEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.exp_no = strExpNo;
      if v_strStatus = '12' then
        -- 已定位，未装车
        strErrorMsg := 'N|[已定位未装车完成的单不能关单]';
        return;
      end if;
      if v_strStatus = '11' then
        -- 已定位，未装车
        strErrorMsg := 'N|[发起状态的单不能关单]';
        return;
      end if;

      if v_strStatus = '10' then
        --检查此通知单是否还有已定位未发单的数据
        select count(*)
          into v_iCount
          from odata_outstock_direct ood
         where ood.warehouse_no = strWareHouseNo
           and ood.exp_no = strExpNo
           and ood.status in ('10', '11')
           and ood.enterprise_no = strCurrEnterpriseNo;
        if v_iCount > 0 then
          strErrorMsg := 'N|[已定过位的单据必须要全部发单完成才能关单]';
          return;
        end if;

        --检查此通知单是否还有未分播回单的数据
        select count(*)
          into v_iCount
          from odata_outstock_d ood
         where ood.warehouse_no = strWareHouseNo
           and ood.exp_no = strExpNo
           and ood.status in ('10', '11', '12')
           and ood.enterprise_no = strCurrEnterpriseNo;
        if v_iCount > 0 then
          strErrorMsg := 'N|[已定过位的单据必须要全部拣货回单完成才能关单]';
          return;
        end if;

        --检查此通知单是否还有未拣货回单数据
        select count(*)
          into v_iCount
          from odata_divide_d ood
         where ood.warehouse_no = strWareHouseNo
           and ood.exp_no = strExpNo
           and ood.status in ('10', '11', '12')
           and ood.enterprise_no = strCurrEnterpriseNo;
        if v_iCount > 0 then
          strErrorMsg := 'N|[已定过位的单据必须要全部分播完成才能关单]';
          return;
        end if;
        v_strUpdateFlag:='1';
        v_strUpdtStatus:='12';
        v_strExpStatus:='30';
      end if;
    end if;

    if v_strUpdateFlag='1' then
        --更新出货通知单状态
      update odata_exp_m t
         set t.status    = v_strUpdtStatus,
             t.updt_name = strWorkNo,
             t.updt_date = sysdate
       where t.enterprise_no = strCurrEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.exp_no = strExpNo;

      --更新出货通知单明细
      update odata_exp_d t
         set t.status = v_strUpdtStatus
       where t.enterprise_no = strCurrEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.exp_no = strExpNo;

      PKOBJ_ODISPATCH.P_Insert_Odata_Exp_Trace(strCurrEnterpriseNo,strWareHouseNo,strExpNo,
               v_strExpStatus,strWorkNo,strErrorMsg);
      if substr(strErrorMsg, 1, 2) = 'N|' then
        return;
      end if;
    end if;


    strErrorMsg := 'Y|[成功]';

  end p_close_exp;


  /**************************************************************************************8
   功能说明：写出货定位日志。
   创建人：lizhiping
   创建时间：2015.7.29
  ****************************************************************************************/
  procedure p_write_log(strEnterpriseNo in odata_locate_m.enterprise_no%type,
                        strWareHouseNo  in varchar2, --仓库代码
                        strWaveNo       in varchar2, --定位号
                        strLogText      in varchar2, --日志
                        strLogStatus    in varchar2) is
    pragma autonomous_transaction;
  begin
    insert into odata_locate_log
      (enterprise_no,
       warehouse_no,
       wave_no,
       thread_id,
       log_serial,
       log_date,
       log_text,
       log_status)
    values
      (strEnterpriseNo,
       strWareHouseNo,
       strWaveNo,
       USERENV('SESSIONID'),
       SEQ_ODATA_LOCATE_LOG.Nextval,
       sysdate,
       strLogText,
       strLogStatus);
    commit;
  end p_write_log;

  /**************************************************************************************8
   功能说明：写出货定位日志。
   创建人：lizhiping
   创建时间：2015.7.29
  ****************************************************************************************/
  procedure p_write_short_log(strEnterpriseNo in odata_locate_m.enterprise_no%type,
                              strWareHouseNo  in varchar2, --仓库代码
                              strWaveNo       in varchar2, --定位号
                              strOwnerNo      in varchar2, --货主
                              nGroupNo        in number, --提交组别
                              strExpNo        in varchar2, --单号
                              strCustNo       in varchar2, --客户代码
                              strSubCustNo    in varchar2, --子客户代码
                              strCellNo       in varchar2, --货位
                              strArticleNo    in varchar2, --商品编码
                              nArticleID      in number, --商品批次ID
                              nPackingQty     in number, --库存包装
                              nStockQty       in number, --库存量
                              nLocateQty      in number, --需求量
                              strOperateType  in varchar2, --定位类型
                              strShortReason  in varchar2) is
    --不能定位原因
    pragma autonomous_transaction;
    --v_iCount            integer;
  begin
    insert into odata_locate_short_log
      (enterprise_no,
       warehouse_no,
       wave_no,
       log_serial,
       owner_no,
       trans_group_no,
       exp_no,
       cust_no,
       sub_cust_no,
       article_no,
       article_id,
       packing_qty,
       cell_no,
       stock_qty,
       locate_qty,
       operate_type,
       short_reason)
    values
      (strEnterpriseNo,
       strWareHouseNo,
       strWaveNo,
       SEQ_odata_locate_short_log.Nextval,
       strOwnerNo,
       nGroupNo,
       strExpNo,
       strCustNo,
       strSubCustNo,
       strArticleNo,
       nArticleID,
       nPackingQty,
       strCellNo,
       nStockQty,
       nLocateQty,
       strOperateType,
       strShortReason);
    commit;
  end p_write_short_log;

  /**************************************************************************************8
   功能说明：设置定位补货方式。
   创建人：lizhiping
   创建时间：2015.7.29
  ****************************************************************************************/
  procedure p_setsupp_mode(strEnterpriseNo in odata_locate_m.enterprise_no%type,
                           strWareHouseNo  in varchar2, --仓库代码
                           strWaveNo       in varchar2, --定位号
                           strOwnerNo      in varchar2,
                           strArticleNo    in varchar2, --商品代码
                           strErrorMsg     out varchar2) is

    v_strBrepLenishType cdef_defarea.b_replenish_type%type;
    v_strCrepLenishType cdef_defarea.b_replenish_type%type;

  begin

    --获取补货方式参数
    --v_strBREPLENISHTYPE,v_strCREPLENISHTYPE(1：一次性补足；2：循环补货；3：批次间补货)
    begin
      select cd.B_REPLENISH_TYPE
        into v_strBrepLenishType
        from cdef_defarea cd, cset_cell_article cca
       where cd.WAREHOUSE_NO = cca.WAREHOUSE_NO
         and cca.OWNER_NO = strOwnerNo
         and cca.enterprise_no = strEnterPriseNo
         and cd.enterprise_no = cca.enterprise_no
         and cca.WAREHOUSE_NO = strWareHouseNo
         and cca.ARTICLE_NO = strArticleNo
         and cd.WARE_NO = cca.WARE_NO
         and cd.AREA_NO = cca.AREA_NO
         and cca.PICK_TYPE = 'B';
    exception
      when no_data_found then
        v_strBrepLenishType := '1';
    end;

    begin
      select cd.C_REPLENISH_TYPE
        into v_strCrepLenishType
        from cdef_defarea cd, cset_cell_article cca
       where cd.WAREHOUSE_NO = cca.WAREHOUSE_NO
         and cca.OWNER_NO = strOwnerNo
         and cd.enterprise_no = cca.enterprise_no
         and cd.enterprise_no = strEnterPriseNo
         and cca.WAREHOUSE_NO = strWareHouseNo
         and cca.ARTICLE_NO = strArticleNo
         and cd.WARE_NO = cca.WARE_NO
         and cd.AREA_NO = cca.AREA_NO
         and cca.PICK_TYPE = 'C';
    exception
      when no_data_found then
        v_strCrepLenishType := '1';
    end;
    null;
  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_setsupp_mode;

  /**************************************************************************************************************
    功能说明：1、对出货单进行集单；目前采用临时表的方式选取单据
             2、定位；
             3、拣货发单

  ***************************************************************************************************************/
  procedure P_LocateAndGetTask(strEnterpriseNo in odata_locate_m.enterprise_no%type, --企业
                               strWarehouseNo  in odata_locate_m.warehouse_no%type, --仓别
                               strOwnerNo      in odata_locate_m.owner_no%type, --货主
                               strExpType      in odata_locate_m.EXP_TYPE%type, --出货单类型
                               strUserId       in odata_locate_m.locate_name%type, --集单人员
                               strExpNo      in odata_exp_m.sourceexp_no%type, --出货通知单
                               strDockNo     in bdef_defdock.dock_no%type,
                               strNewWaveNo  out odata_exp_m.sourceexp_no%type, --返回波次号
                               strResult     out varchar2) is
    v_iCount integer := 0;
  begin
    strResult := 'N|[P_LocateAndGetTask]';
    --写定位指示
    PKLG_ODISPATCH.P_AUTO_LOCATEBYEXPNO(strEnterpriseNo,STRWAREHOUSENO,strOwnerNo,strUserId,
                strExpType,strExpNo,strNewWaveNo,strResult);

    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    --出货定位
    p_locate_main(strEnterpriseNo,
                  strWareHouseNo,
                  strNewWaveNo,
                  strUserId,
                  strResult);

    if substr(strResult, 1, 1) = 'N' then
      return;
    end if;

    --拣货发单
    --获取下架指示数据
    for GetOutstockDirect in (select distinct cd.ware_no || cd.area_no area_no,
                                              ood.operate_type,ood.cust_no,
                                              ood.batch_no
                                from odata_outstock_direct ood,
                                     cdef_defcell          cd
                               where ood.enterprise_no = cd.enterprise_no
                                 and ood.warehouse_no = cd.warehouse_no
                                 and ood.s_cell_no = cd.cell_no
                                 and ood.enterprise_no = strEnterpriseNo
                                 AND ood.warehouse_no = strWarehouseNo
                                 and ood.wave_no = strNewWaveNo
                                 and ood.status = '10') loop
      v_iCount := v_iCount + 1;
      pklg_odata.p_pick_by_ec(strEnterpriseNo,
                                strWareHouseNo,
                                strOwnerNo,
                                strExpType,
                                strNewWaveNo,
                                GetOutstockDirect.Batch_No,
                                GetOutstockDirect.area_no,
                                GetOutstockDirect.Cust_No,
                                'N',
                                strDockNo,
                                strUserId,
                                GetOutstockDirect.operate_type,
                                strUserId,
                                '1',
                                '0',
                                '0',
                                '0',
                                strResult);

      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;

    end loop;

    if v_iCount = 0 then
      strResult := 'N|[找不到发单数据]';
      return;
    end if;

    strResult := 'Y|[成功]';

  end P_LocateAndGetTask;
  /************************************************************************************************************
    读取出货类型的配送级别
    2015.12.12

  *************************************************************************************************************/
  procedure GetDeliverObjLevel(strEnterpriseNo    in varchar2, --企业
                               strWareHouseNo     in varchar2, --仓库代码
                               strOwnerNo         in varchar2,
                               strExpType         in varchar2, --定位号
                               strDelvierObjLevel out varchar2, --配送对象级别
                               strErrorMsg        out varchar2) is
    v_strLocateStrategyId wms_outorder.locate_strategy_id%type;
  begin
    strErrorMsg := 'N|[GetDeliverObjLevel]';
    begin
      select locate_strategy_id
        into v_strLocateStrategyId
        from wms_warehouse_outorder
       where enterprise_no = strEnterPriseNo
         and warehouse_no = strWareHouseNo
         and owner_no = strOwnerNo
         and exp_type = strExpType;
    exception
      when no_data_found then
        begin
          select locate_strategy_id
            into v_strLocateStrategyId
            from wms_owner_outorder
           where enterprise_no = strEnterPriseNo
             and owner_no = strOwnerNo
             and exp_type = strExpType;
        exception
          when no_data_found then
            begin
              select locate_strategy_id
                into v_strLocateStrategyId
                from wms_outorder
               where enterprise_no = strEnterPriseNo
                 and exp_type = strExpType;
            exception
              when no_data_found then
                strErrorMsg := 'N|[读取不到对应出货单别的配置信息]';
                return;
            end;
        end;
    end;

    --获取此策略对应的配送对象级别
    select t.deliver_obj_level
      into strDelvierObjLevel
      from wms_outlocate_strategy_d t
     where t.enterprise_no = strEnterpriseNo
       and t.locate_strategy_id = v_strLocateStrategyId;

    strErrorMsg := 'Y|[成功]';
  end GetDeliverObjLevel;

  /**************************************************************************************
   功能说明：特殊区域快速定位，直接进出货暂存区，不产生拣货任务(比如电商赠品出库)
   创建人：jiangchenglong
   创建时间：2016.6.23
  ****************************************************************************************/
  procedure P_Locate_SpecialArea(strEnterpriseNo  in odata_locate_m.enterprise_no%type,
                                 strWareHouseNo   in varchar2, --仓库代码
                                 strWorkNo        in varchar2, --员工代码
                                 strArticleNo     in bdef_defarticle.article_no%type, --商品
                                 nLocateQty       in out number, --定位量
                                 strItemType      in cdef_defarea.item_type%type, --储区类型(0:普通区域;1:赠品区域)
                                 strSourceCellNo  in cdef_defcell.cell_no%type, --指定储位出货(默认N)
                                 strSourceNo      in stock_content_move.PAPER_NO%type, --来源单号
                                 strExpNo         in odata_exp_m.exp_no%type, --出货单号
                                 strLabelNo       in stock_label_m.label_no%type,
                                 strContainerNo   in stock_label_m.container_no%type,
                                 strContainerType in stock_label_m.container_type%type,
                                 strStatus        in stock_label_d.status%type, --标签状态
                                 strTERMINAL_FLAG in stock_content_move.TERMINAL_FLAG%type, --操作设备
                                 nRealQty         out number, --返回定位数量
                                 strErrorMsg      out varchar2) is

    v_nAllotQty   number;
    strDestCellNo stock_content.cell_no%type;
    nDestCellID   stock_content.cell_id%type;
    nCount        number;
    --v_nExpTotalQty number;

  begin
    strErrorMsg   := 'N|[P_Locate_SpecialArea]';
    strDestCellNo := 'N';
    nRealQty      := 0;
    nDestCellID   := -1;
    v_nAllotQty   := 0;

    --获取出货暂存区
    begin
      select cell_no
        into strDestCellNo
        from (select cdc.cell_no
                from cdef_defcell cdc, cdef_defarea cda
               where cdc.warehouse_no = cda.warehouse_no
                 and cdc.ware_no = cda.ware_no
                 and cdc.area_no = cda.area_no
                 and cda.warehouse_no = strWareHouseNo
                 and cdc.enterprisE_no = cda.enterprise_no
                 and cda.enterprise_no = strEnterpriseNo
                 and cda.AREA_ATTRIBUTE = '1'
                 and cda.ATTRIBUTE_TYPE = '2'
               order by cdc.cell_no)
       where rownum <= 1;
    exception
      when no_data_found then
        strErrorMsg := 'N|[获取出货暂存区失败]';
        return;
    end;

    --循环可用库存
    for v_cs_stock in (select *
                         from (select sc.*,
                                      sai.produce_date,
                                      sc.QTY - sc.OUTSTOCK_QTY +
                                      sC.UNUSUAL_QTY as use_qty,
                                      bda.qmin_operate_packing
                                 from stock_content      sc,
                                      stock_article_info sai,
                                      bdef_defarticle    bda,
                                      cdef_defarea       ca,
                                      cdef_defcell       ce
                                where bda.enterprise_no = sc.enterprise_no
                                  and bda.article_no = sc.article_no
                                  and sc.article_no = sai.article_no
                                  and sc.article_id = sai.article_id
                                  and sc.enterprise_no = sai.enterprise_no
                                  and sc.enterprise_no = strEnterPriseNo
                                  and sc.warehouse_no = strWareHouseNo
                                  and sai.article_no = strArticleNo
                                  and sc.flag <> '2'
                                  and ce.cell_status = '0'
                                  and ce.check_status = '0'
                                  and ca.area_usetype in ('1', '5', '6')
                                  and ca.AREA_ATTRIBUTE = '0'
                                  and ca.ATTRIBUTE_TYPE = '0'
                                  and sc.enterprise_no = ce.enterprise_no
                                  and sc.warehouse_no = ce.warehouse_no
                                  and sc.cell_no = ce.cell_no
                                  and ca.enterprise_no = ce.enterprise_no
                                  and ca.warehouse_no = ce.warehouse_no
                                  and ca.ware_no = ce.ware_no
                                  and ca.area_no = ce.area_no
                                  and ca.item_type = strItemType
                                  and sc.cell_no = (case
                                        when strSourceCellNo = 'N' then
                                         sc.cell_no
                                        else
                                         strSourceCellNo
                                      end)
                                  and sc.QTY - sc.OUTSTOCK_QTY +
                                      sC.UNUSUAL_QTY > 0)
                        where use_qty > 0
                        order by produce_date, cell_no) loop

      if nLocateQty <= 0 then
        exit;
      end if;

      if v_cs_stock.use_qty > nLocateQty then
        v_nAllotQty := nLocateQty;
      else
        v_nAllotQty := v_cs_stock.use_qty;
      end if;

      if v_nAllotQty <= 0 then
        goto next_stock;
      end if;

      --总货量
      nLocateQty := nLocateQty - v_nAllotQty;
      --实际定位量
      nRealQty := nRealQty + v_nAllotQty;

      --减来源储位库存
      PKOBJ_STOCK.p_UpdtContentByCellID(strEnterPriseNo,
                                        strWareHouseNo,
                                        v_cs_stock.cell_id,
                                        v_cs_stock.cell_no,
                                        strDestCellNo,
                                        v_nAllotQty,
                                        strWorkNo,
                                        strSourceNo,
                                        strTERMINAL_FLAG,
                                        strErrorMsg);
      if substr(strErrorMsg, 1, 2) = 'N|' then
        return;
      end if;

      --新增目的储位库存
      PKOBJ_STOCK.p_InstContent_qtyByCellNo(strEnterPriseNo,
                                            strWareHouseNo,
                                            v_cs_stock.owner_no,
                                            v_cs_stock.dept_no,
                                            strArticleNo,
                                            v_cs_stock.article_id,
                                            strDestCellNo,
                                            v_cs_stock.cell_no,
                                            v_cs_stock.packing_qty,
                                            v_nAllotQty,
                                            strLabelNo,
                                            'N',
                                            v_cs_stock.stock_type,
                                            v_cs_stock.stock_value,
                                            strWorkNo,
                                            strSourceNo,
                                            strTERMINAL_FLAG,
                                            '0',
                                            nDestCellID,
                                            strErrorMsg);
      if substr(strErrorMsg, 1, 2) = 'N|' then
        return;
      end if;

      --新增标签明细
      nCount := 0;
      for GetLabelInfo in (select d.batch_no,
                                  d.wave_no,
                                  d.cust_no,
                                  d.sub_cust_no,
                                  d.line_no,
                                  d.deliver_obj,
                                  d.exp_date,
                                  m.exp_type
                             from odata_locate_dhty d, odata_exp_m m
                            where d.enterprise_no = strEnterpriseNo
                              and d.warehouse_no = strWareHouseNo
                              and d.exp_no = strExpNo
                              and m.enterprise_no = strEnterpriseNo
                              and m.warehouse_no = strWareHouseNo
                              and m.exp_no = strExpNo) loop
        nCount := nCount + 1;
        Pkobj_Label.proc_Insert_LabelDetail(strEnterPriseNo,
                                            strWareHouseNo,
                                            GetLabelInfo.Batch_No,
                                            v_cs_stock.owner_no,
                                            strSourceNo,
                                            strContainerNo,
                                            strContainerType,
                                            strArticleNo,
                                            v_cs_stock.article_id,
                                            v_cs_stock.packing_qty,
                                            v_nAllotQty,
                                            strExpNo,
                                            GetLabelInfo.Wave_No,
                                            GetLabelInfo.Cust_No,
                                            GetLabelInfo.Sub_Cust_No,
                                            GetLabelInfo.Line_No,
                                            strStatus,
                                            1,
                                            GetLabelInfo.Exp_Type,
                                            'N',
                                            strWorkNo,
                                            GetLabelInfo.Deliver_Obj,
                                            'N',
                                            GetLabelInfo.Exp_Date,
                                            'N',
                                            '10',
                                            strErrorMsg);

        if substr(strErrorMsg, 1, 2) = 'N|' then
          return;
        end if;

        --回写出货单明细定位数量
        P_UpdateExpLocateQty(strEnterPriseNo,
                             strWareHouseNo,
                             v_cs_stock.owner_no,
                             strExpNo,
                             strArticleNo,
                             v_nAllotQty,
                             strErrorMsg);
        if substr(strErrorMsg, 1, 2) = 'N|' then
          return;
        end if;
        exit;
      end loop;

      if nCount <= 0 then
        strErrorMsg := 'N|[没获取到相关标签明细信息]';
        return;
      end if;
      <<next_stock>>
      null;
    end loop;

    if nLocateQty > 0 then
      strErrorMsg := 'N|[可用库存不够]';
      return;
    end if;
    strErrorMsg := 'Y|[成功]';
  end P_Locate_SpecialArea;

  /**************************************************************************************
   功能说明：定位后回写出货单明细定位数量
   创建人：jiangchenglong
   创建时间：2016.6.23
  ****************************************************************************************/
  procedure P_UpdateExpLocateQty(strEnterPriseNo in odata_exp_d.enterprise_no%type,
                                 strWareHouseNo  in odata_exp_d.warehouse_no%type,
                                 strOwnerNo      in odata_exp_d.owner_no%type,
                                 strExpNo        in odata_exp_d.exp_no%type,
                                 strArticleNo    in odata_exp_d.article_no%type,
                                 nAllotQty       in number,
                                 strErrorMsg     out varchar2) is

    v_nExpTotalQty number;
    v_nExpAllotQty number;

  begin

    strErrorMsg    := 'N|[P_UpdateExpLocateQty]';
    v_nExpTotalQty := nAllotQty;
    for v_cs_exp_d in (select *
                         from odata_exp_d oed
                        where oed.warehouse_no = strWareHouseNo
                          and oed.enterprise_no = strEnterPriseNo
                          and oed.owner_no = strOwnerNo
                          and oed.exp_no = strExpNo
                          and oed.article_no = strArticleNo
                          and oed.article_qty - oed.locate_qty > 0) loop
      --and oed.condition = v_cs_direct.condition
      --and oed.special_batch =v_cs_direct.special_batch) loop

      v_nExpAllotQty := v_cs_exp_d.article_qty - v_cs_exp_d.LOCATE_QTY;

      if v_nExpAllotQty > v_nExpTotalQty then
        v_nExpAllotQty := v_nExpTotalQty;
      end if;

      v_nExpTotalQty := v_nExpTotalQty - v_nExpAllotQty;

      update odata_exp_d oed
         set oed.LOCATE_QTY = oed.LOCATE_QTY + v_nExpAllotQty
       where oed.warehouse_no = strWareHouseNo
         and oed.enterprise_no = strEnterPriseNo
         and oed.owner_no = strOwnerNo
         and oed.exp_no = strExpNo
         and oed.article_no = strArticleNo
         and oed.packing_qty = v_cs_exp_d.packing_qty
         and oed.row_id = v_cs_exp_d.row_id;
      --and oed.condition = v_cs_exp_d.condition
      --and oed.special_batch = v_cs_exp_d.special_batch;

      if v_nExpTotalQty <= 0 then
        exit;
      end if;
    end loop;

    if v_nExpTotalQty > 0 then
      strErrorMsg := 'N|[单号[' || strExpNo || ']商品[' || strArticleNo ||
                     ']没更新到出货单明细或者已超量]';
      return;
    end if;

    strErrorMsg := 'Y|[成功]';
  end P_UpdateExpLocateQty;

end PKLG_OLOCATE;

/

