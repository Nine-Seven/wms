create package        PKLG_ODATA_EXPCANCEL is
  /****************************************************************************************************
   创建人：hcx
   2015.4.27
   病单处理
  ******************************************************************************************************/

  --转病单
  procedure P_TurnOdataExpCancel(strEnterpriseNo in odata_exp_cancel_direct.enterprise_no%type,
                                 strWareHouseNo  in odata_exp_cancel_direct.warehouse_no%type,
                                 strOwnerNo      in odata_exp_cancel_direct.owner_no%type,
                                 strExpNo        in odata_exp_cancel_direct.exp_no%type,
                                 strSourceType   in odata_exp_cancel_direct.source_type%type,
                                 strUserId       in odata_exp_cancel_direct.rgst_Name%type,
                                 strResult       out varchar2);

  --病单发单
  procedure P_CreateOdataExpCancel(strEnterpriseNo in odata_exp_cancel_m.enterprise_no%type,
                                   strWareHouseNo  in odata_exp_cancel_m.warehouse_no%type,
                                   strOwnerNo      in odata_exp_cancel_m.owner_no%type,
                                   strExpNo        in odata_exp_cancel_m.exp_no%type,
                                   strSourceType   in odata_exp_cancel_direct.source_type%type,
                                   strUserId       in odata_exp_cancel_m.rgst_Name%type,
                                   strResult       out varchar2);

  /*****************************************************************************************************
   对某个波次有整单缺量的出货单转病单
   luozhiling
   2015.5.11
  *******************************************************************************************************/
  procedure P_WaveToexpCancel(strEnterpriseNo in odata_exp_cancel_direct.enterprise_no%type, --企业
                              strWareHouseNo  in odata_exp_cancel_direct.warehouse_no%type, --仓别
                              strOwnerNo      in odata_exp_cancel_direct.owner_no%type, --货主
                              strWaveNo       in odata_exp_cancel_direct.exp_no%type, --出货单号
                              strSourceType   in odata_exp_cancel_direct.source_type%type, --病单来源
                              strUserId       in odata_exp_cancel_direct.rgst_Name%type, --操作人员
                              strResult       out varchar2);
  --病单处理-补拣
  procedure P_RepeatLocate(strEnterpriseNo in odata_exp_cancel_m.enterprise_no%type,
                           strWareHouseNo  in odata_exp_cancel_m.warehouse_no%type,
                           strOwnerNo      in odata_exp_cancel_m.owner_no%type,
                           strCancelNo     in odata_exp_cancel_m.cancel_no%type,
                           strExpNo        in odata_exp_cancel_m.exp_no%type,
                           strSourceType   in odata_exp_cancel_m.source_type%type,
                           strUserId       in odata_exp_cancel_m.rgst_Name%type,
                           strResult       out varchar2);
  --病单处理-上传
  procedure P_UpLocate(strEnterpriseNo in odata_exp_cancel_m.enterprise_no%type,
                       strWareHouseNo  in odata_exp_cancel_m.warehouse_no%type,
                       strOwnerNo      in odata_exp_cancel_m.owner_no%type,
                       strCancelNo     in odata_exp_cancel_m.cancel_no%type,
                       strExpNo        in odata_exp_cancel_m.exp_no%type,
                       strUserId       in odata_exp_cancel_label_item.rgst_name%type,
                       strResult       out varchar2);

  /*****************************************************************************************************************
  hekangli
  20150428
  功能说明：病单审核
  ***************************************************************************************************************/
  procedure p_cancel_check(strEnterpriseNo in Odata_Exp_Cancel_m.Enterprise_No%type,
                           strWarehouseNo  in ODATA_EXP_CANCEL_M.Warehouse_No%type,
                           strOwnerNo      in odata_exp_cancel_m.owner_no%type,
                           strCancelNo     in odata_exp_cancel_m.cancel_no%type,
                           strExpNo        in odata_exp_cancel_m.exp_no%type,
                           strWorkerNo     in odata_exp_cancel_m.rgst_name%type,
                           strWorkSpaceNo  IN idata_locate_direct.dock_no%type, --码头号
                           strHandleflag   in odata_exp_cancel_m.handle_flag%type, --处理方式
                           strResult       out varchar2);
  /*****************************************************************************************************************
  hekangli
  20150428
  功能说明：病单审核，处理方式为出货（有多少出多少）
  ***************************************************************************************************************/
  procedure p_cancel_outdata(strEnterpriseNo in Odata_Exp_Cancel_m.Enterprise_No%type,
                             strWarehouseNo  in ODATA_EXP_CANCEL_M.Warehouse_No%type,
                             strOwnerNo      in odata_exp_cancel_m.owner_no%type,
                             strCancelNo     in odata_exp_cancel_m.cancel_no%type,
                             strExpNo        in odata_exp_cancel_m.exp_no%type,
                             strWorkerNo     in odata_exp_cancel_m.rgst_name%type,
                             strResult       out varchar2);

  /*****************************************************************************************************************
   hekangli
  20150428
  功能说明：病单审核，处理方式为取消订单
  ***************************************************************************************************************/
  procedure p_cancel_colsedata(strEnterpriseNo in Odata_Exp_Cancel_m.Enterprise_No%type,
                               strWarehouseNo  in ODATA_EXP_CANCEL_M.Warehouse_No%type,
                               strOwnerNo      in odata_exp_cancel_m.owner_no%type,
                               strCancelNo     in odata_exp_cancel_m.cancel_no%type,
                               strExpNo        in odata_exp_cancel_m.exp_no%type,
                               strWorkerNo     in odata_exp_cancel_m.rgst_name%type, --操作人
                               strWorkSpaceNo  IN idata_locate_direct.dock_no%type, --码头号
                               strResult       out varchar2);

  /**********************************************************************************************
  功能说明：对销毁的标签做自动回库处理
  1、将标签库存移到销毁去；
  2、改变标签状态；
  3、根据标签写移库单；
  4、移库回单
  luozhiling
  2015.05.08
  **********************************************************************************************/
  procedure P_Cancel_LabeltoMove(strEnterpriseNo in stock_label_m.enterprise_no%type,
                                 strWareHouseNo  in stock_label_m.warehouse_no%type,
                                 strLabelNo      in stock_label_m.label_no%type,
                                 strWorkerNo     in stock_label_m.rgst_name%type,
                                 strResult       out varchar2);
end PKLG_ODATA_EXPCANCEL;


/

