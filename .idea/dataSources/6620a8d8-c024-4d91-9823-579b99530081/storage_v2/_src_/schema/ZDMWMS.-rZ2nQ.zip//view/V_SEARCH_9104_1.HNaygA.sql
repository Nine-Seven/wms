create view V_SEARCH_9104_1 as
select sm.enterprise_no,
       sm.warehouse_no,
       sm.label_no,
       sd.source_no,
       sd.article_no,
       b.barcode,
       b.article_name,
       b.UNIT,
       b.SPEC,
       sd.packing_qty,
       sd.qty,
       bd.cust_no,
       bd.cust_name,
       case
         when use_type = '0' then
          '收货标签'
         else
          case
            when use_type = '1' then
             '客户标签'
            else
             case
               when use_type = '2' then
                '分播标签'
               else
                '移库标签'
             end
          end
       end useType,
       sm.status,
       f_get_fieldtext('STOCK_LABEL_M', 'STATUS', sm.status)as statusText
  from stock_label_d     sd,
       stock_label_m     sm,
       bdef_defarticle b,
       bdef_defcust      bd
 where sd.enterprise_no = sm.enterprise_no
   and sd.enterprise_no = b.enterprise_no
   and sd.enterprise_no = bd.enterprise_no
   and sd.warehouse_no = sm.warehouse_no
   and sd.owner_no = b.owner_no
   and sd.owner_no = bd.owner_no
   and sm.container_no = sd.container_no
   and sd.article_no = b.ARTICLE_NO
   and bd.cust_no = sd.cust_no

/

