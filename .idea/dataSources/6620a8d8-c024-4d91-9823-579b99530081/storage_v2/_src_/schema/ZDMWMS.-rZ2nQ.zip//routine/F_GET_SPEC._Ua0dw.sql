create function        f_get_spec(strEnterpriseNo in bdef_defarticle.enterprise_no%type,
                                      strOwnerNo      in bdef_defarticle.owner_no%type,
                                      strArticleNo    in bdef_defarticle.article_no%type,
                                      nPackingQty     in bdef_article_packing.packing_qty%type)
/*******************************
  Add date : 2016-05-27
  Add by wyf
  功能：获取商品规格函数
  *******************************/
 return varchar2 is
  v_text         VARCHAR(256);
  v_strSpec      bdef_defarticle.spec%type;
  v_nQminPacking bdef_defarticle.qmin_operate_packing%type; --最小操作包装
  v_nUnitPacking bdef_defarticle.unit_packing%type; --基本包装
  v_strUnit      bdef_defarticle.unit%type; --基本单位
begin
  v_text := 'N';
  begin
    --取包装表对应包装数量的规格
    select b.spec
      into v_strSpec
      from bdef_article_packing b
     where b.enterprise_no = strEnterpriseNo
       and b.article_no = strArticleNo
       and b.packing_qty = nPackingQty;
  exception
    when no_data_found then
      null;
  end;
  --包装表取不到包装数据
  if v_strSpec is null then
    begin
      --取不到包装规格 获取主档表的基本包装，最小操作包装，基本单位，
      select a.unit_packing, a.qmin_operate_packing, a.unit
        into v_nUnitPacking, v_nQminPacking, v_strUnit
        from bdef_defarticle a
       where a.enterprise_no = strEnterpriseNo
         and a.owner_no = strOwnerNo
         and a.article_no = strArticleNo;
    exception
      when no_data_found then
        return v_text;
    end;
    if nPackingQty = v_nQminPacking then
      --包装为最小操作包装
      v_strSpec := '1*' || v_nQminPacking || v_strUnit;
    end if;
    if nPackingQty = v_nUnitPacking then
      --包装为基本包装
      v_strSpec := '1*' || v_nUnitPacking || v_strUnit;
    end if;
    if nPackingQty <> v_nQminPacking and nPackingQty <> v_nUnitPacking then
      --包装不存在与主档和包装表
      v_strSpec := '1*' || nPackingQty || v_strUnit;
    end if;
  end if;
  v_text := v_strSpec;
  return v_text;
end;


/

