create package        PKLG_PRINT is

  -- Author  :
  -- Created : 2015/4/21 9:56:37
  -- Purpose :

  procedure PIN_JOB_PRINTTASK_M(
          strREPORTID            in     job_printtask_m.report_id%type, --报表ID
          strEnterprise_NO       in     job_printtask_m.enterprise_no%type, --企业
          strWarehouse_No        in     job_printtask_m.warehouse_no%type,--仓别
          strWORKSTATION_NO      in     job_printtask_m.printer_group_no%type,--工作站
          strSOURCE_NO           in     job_printtask_m.source_no%type,--单号
          strHtyFlag             in     job_printtask_m.hty_flag%type,--是否是历史数据
          strRGST_NAME           in     job_printtask_m.rgst_name%type,--打印人
          strOutMsg              out    varchar2); --返回值

end PKLG_PRINT;


/

