create package body        PKLG_ODATA_LICH is
  /**********************************************************************************************8
  lich
  20150120
  功能说明：RF拣货回单
  ***********************************************************************************************/
  procedure P_OmPickReceipt(strEnterprise_No in odata_outstock_m.enterprise_no%type, --仓别
                            strWarehose_No   in odata_outstock_m.warehouse_no%type, --仓别
                            strOutstock_No   in odata_outstock_m.outstock_no%type, --下架单号
                            strSLabel_No     in odata_outstock_d.label_no%type, --源标签号码
                            strDlabel_No     in odata_outstock_d.label_no%type, --目的标签号码
                            strArticle_No    in odata_outstock_d.article_no%type, --商品编码
                            nPacking_QTY     in odata_outstock_d.packing_qty%type, --包装数量
                            strSCell_No      in odata_outstock_d.s_cell_no%type, --来源储位
                            nArticleQty      in odata_outstock_d.article_qty%type, --计划数量
                            nReal_QTY        in odata_outstock_d.article_qty%type, --下架数量
                            strQuality       in idata_check_d.quality%type, --品质
                            dtProduceDate    in stock_article_info.produce_date%type, --生产日期
                            dtExpireDate     in stock_article_info.expire_date%type, --到期日期
                            strLotNo         in stock_article_info.lot_no%type, --批次号
                            strRSV_BATCH1    in stock_article_info.rsv_batch1%type, --预留批属性1
                            strRSV_BATCH2    in stock_article_info.rsv_batch2%type, --预留批属性2
                            strRSV_BATCH3    in stock_article_info.rsv_batch3%type, --预留批属性3
                            strRSV_BATCH4    in stock_article_info.rsv_batch4%type, --预留批属性4
                            strRSV_BATCH5    in stock_article_info.rsv_batch5%type, --预留批属性5
                            strRSV_BATCH6    in stock_article_info.rsv_batch6%type, --预留批属性6
                            strRSV_BATCH7    in stock_article_info.rsv_batch7%type, --预留批属性7
                            strRSV_BATCH8    in stock_article_info.rsv_batch8%type, --预留批属性8
                            strDock_No       in odata_outstock_m.dock_no%type, --工作站
                            strUserID        in odata_outstock_m.rgst_name%type, --回单人
                            strOutstock_ID   in odata_outstock_d.outstock_name%type, --下架人
                            strInstock_ID    in odata_outstock_d.instock_name%type, --上架人
                            strOutMsg        out varchar2) is
    v_strOperate_type odata_outstock_m.operate_type%type;
    --v_strScontainerNo stock_label_m.container_no%type;
    --v_strDcontainerNo stock_label_m.container_no%type;
    v_strOwnerNo      odata_outstock_m.owner_no%type;
    v_strPickDiffFlag wms_outpick_strategy.pick_diff_flag%type; --差异回单
  begin
    --取作业类型
    begin
      select oom.operate_type, oom.owner_no, wos.pick_diff_flag
        into v_strOperate_type, v_strOwnerNo, v_strPickDiffFlag
        from odata_outstock_m     oom,
             odata_locate_batch   olb,
             wms_outpick_strategy wos
       where oom.enterprise_no = olb.enterprise_no
         and oom.warehouse_no = olb.warehouse_no
         and oom.wave_no = olb.wave_no
         and oom.batch_no = olb.batch_no
         and olb.enterprise_no = wos.enterprise_no
         and olb.pick_strategy_id = wos.pick_strategy_id
         and oom.enterprise_no = strEnterprise_No
         and oom.warehouse_no = strWarehose_No
         and oom.outstock_no = strOutstock_No;
    exception
      when no_data_found then
        strOutMsg := 'N|[E22513]';
        return;
    end;

    if v_strPickDiffFlag = '0' then
      --不允许差异回单
      if nArticleQty <> nReal_QTY then
        strOutMsg := 'N|[此拣货单不允许差异回单]';
        return;
      end if;
    end if;

    --回单时间限制
    PKOBJ_ODATA.P_O_check_TimeLimit(strEnterprise_No,
                                    strWarehose_No,
                                    strOutstock_No,
                                    v_strOwnerNo,
                                    strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    --调用回单过程
    P_TaskLabelSave_Odata_Outstock(strEnterprise_No,
                                   strWarehose_No,
                                   strOutstock_No,
                                   strSLabel_No,
                                   strDlabel_No,
                                   strArticle_No,
                                   nPacking_QTY,
                                   strSCell_No,
                                   nArticleQty,
                                   nReal_QTY,
                                   strQuality,
                                   dtProduceDate,
                                   dtExpireDate,
                                   strLotNo,
                                   strRSV_BATCH1,
                                   strRSV_BATCH2,
                                   strRSV_BATCH3,
                                   strRSV_BATCH4,
                                   strRSV_BATCH5,
                                   strRSV_BATCH6,
                                   strRSV_BATCH7,
                                   strRSV_BATCH8,
                                   strDock_No,
                                   strUserID,
                                   strOutstock_ID,
                                   strInstock_ID,
                                   strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    strOutMsg := 'Y|成功！';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_OmPickReceipt;
  /**********************************************************************************************8
  lich
  20140521
  功能说明：表单拣货回单
  ***********************************************************************************************/
  procedure P_Save_Odata_Outstock(strEnterPriseNo in odata_outstock_m.Enterprise_No%type, --企业号
                                  strWarehose_No  in odata_outstock_m.warehouse_no%type, --仓别
                                  strOutstock_No  in odata_outstock_m.outstock_no%type, --下架单号
                                  strFixLabel_No  in odata_outstock_d.label_no%type, --来源标签号码
                                  strArticle_No   in odata_outstock_d.article_no%type, --商品编码
                                  nPacking_QTY    in odata_outstock_d.packing_qty%type, --包装数量
                                  strSCell_No     in odata_outstock_d.s_cell_no%type, --来源储位
                                  nArticleQty     in odata_outstock_d.article_qty%type, --计划数量
                                  nReal_QTY       in odata_outstock_d.article_qty%type, --下架数量
                                  strQuality      in idata_check_d.quality%type, --品质
                                  dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                                  dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                                  strLotNo        in stock_article_info.lot_no%type, --批次号
                                  strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                                  strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                                  strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                                  strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                                  strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                                  strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                                  strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                                  strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                                  strDock_No      in odata_outstock_m.dock_no%type, --工作站
                                  strUserID       in odata_outstock_m.rgst_name%type, --回单人
                                  strOutstock_ID  in odata_outstock_d.outstock_name%type, --下架人
                                  strInstock_ID   in odata_outstock_d.instock_name%type, --上架人
                                  strOutMsg       out varchar2) is
    v_ReportID            stock_label_m.report_id%type := 'N';
    v_UseType             stock_label_m.use_type%type := 'N';
    v_refContainerNO      stock_label_m.container_no%type := 'N';
    v_refContainerType    stock_label_m.container_type%type := 'N';
    v_DeliverObj          stock_label_m.deliver_obj%type := 'N';
    v_LabelStatus         stock_label_m.status%type := 'N';
    v_strHmManualFlag     stock_label_m.hm_manual_flag%type;
    v_TotalQTY            odata_outstock_d.real_qty%type := nReal_QTY;
    v_RealQTY             odata_outstock_d.real_qty%type := 0;
    v_Count               integer := 0;
    v_NewFlag             integer := 0;
    v_strOwnerNo          bdef_defowner.owner_no%type;
    v_strWaveNo           odata_outstock_m.wave_no%type;
    v_strBatchNo          odata_outstock_m.batch_no%type;
    v_strPickDiffFlag     wms_outpick_strategy.pick_diff_flag%type; --差异回单
    v_ExpTraceStatus      odata_exp_m.status%type;
    v_ExpTraceStatusCount integer := 0;

    cursor v_GetOutstockItem is
      select m.outstock_type,
             m.operate_type,
             m.source_type,
             m.pick_type,
             m.task_type,
             d.*
        from odata_outstock_d d, odata_outstock_m m, stock_article_info sai
       where m.enterprise_no = d.enterprise_no
         and m.warehouse_no = d.warehouse_no
         and m.outstock_no = d.outstock_no
         and d.enterprise_no = sai.enterprise_no
         and d.article_no = sai.article_no
         and d.article_id = sai.article_id
         and d.enterprise_no = strEnterPriseNo
         and d.warehouse_no = strWarehose_No
         and d.outstock_no = strOutstock_No
         and d.article_no = strArticle_No
         and d.packing_qty = nPacking_QTY
         and d.s_cell_no = strSCell_No
         and sai.produce_date = dtProduceDate
         and sai.expire_date = dtExpireDate
         and sai.lot_no = strLotNo
         and sai.quality = strQuality
         and sai.rsv_batch1 = strRSV_BATCH1
         and sai.rsv_batch2 = strRSV_BATCH2
         and sai.rsv_batch3 = strRSV_BATCH3
         and sai.rsv_batch4 = strRSV_BATCH4
         and sai.rsv_batch5 = strRSV_BATCH5
         and sai.rsv_batch6 = strRSV_BATCH6
         and sai.rsv_batch7 = strRSV_BATCH7
         and sai.rsv_batch8 = strRSV_BATCH8
         and d.status = '10'
         and m.status = '10';

  begin
    strOutMsg := 'N|[P_Save_Odata_Outstock]';

    update odata_outstock_m m
       set m.updt_date = sysdate, m.updt_name = strUserID
     where m.enterprise_no = strEnterPriseNo
       and m.warehouse_no = strWarehose_No
       and m.outstock_no = strOutstock_No
       and m.status < '13';

    if sql%rowcount <= 0 then
      return;
    end if;

    begin

      select oom.wave_no, oom.batch_no, oom.owner_no, wos.pick_diff_flag
        into v_strWaveNo, v_strBatchNo, v_strOwnerNo, v_strPickDiffFlag
        from odata_outstock_m     oom,
             odata_locate_batch   olb,
             wms_outpick_strategy wos
       where oom.enterprise_no = olb.enterprise_no
         and oom.warehouse_no = olb.warehouse_no
         and oom.wave_no = olb.wave_no
         and oom.batch_no = olb.batch_no
         and olb.enterprise_no = wos.enterprise_no
         and olb.pick_strategy_id = wos.pick_strategy_id
         and oom.enterprise_no = strEnterPriseNo
         and oom.warehouse_no = strWarehose_No
         and oom.outstock_no = strOutstock_No
         and oom.status < '13';
    exception
      when no_data_found then
        strOutMsg := 'N|[找不到需要回单的数据]';
        return;
    end;

    if v_strPickDiffFlag = '0' then
      --不允许差异回单
      if nArticleQty <> nReal_QTY then
        strOutMsg := 'N|[此拣货单不允许差异回单]';
        return;
      end if;
    end if;

    for curOutstockInfo in v_GetOutstockItem loop
      v_Count := v_Count + 1;
      if v_TotalQTY >= curOutstockInfo.Article_Qty then
        v_RealQTY := curOutstockInfo.Article_Qty;
      else
        v_RealQTY := v_TotalQTY;
      end if;

      v_TotalQTY := v_TotalQTY - v_RealQTY;

      --写标签信息  分播
      if curOutstockInfo.Pick_Type = cPickType.BroadCase then
        v_UseType         := CLabelUseType.DIVIDE_LABEL; --分播标签
        v_LabelStatus     := CLABELSTATUS.PICK_END; --CDivideLabel.PICK_END;
        v_DeliverObj      := 'N';
        v_strHmManualFlag := '1';
      else
        v_UseType         := CLabelUseType.CUSTOMER_LABEL; --客户标签
        v_LabelStatus     := CLABELSTATUS.PICK_END; --CCustomerLabel.RECEIVING;
        v_DeliverObj      := curOutstockInfo.Deliver_Obj;
        v_strHmManualFlag := '0';
      end if;

      TransFixNoToSerialNo(strEnterPriseNo,
                           strWarehose_No,
                           strFixLabel_No,
                           strUserID,
                           v_UseType,
                           v_DeliverObj,
                           curOutstockInfo.Operate_Type,
                           v_refContainerType,
                           v_refContainerNO,
                           v_NewFlag,
                           strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      -- cPickType.BroadCase分播
      if curOutstockInfo.Pick_Type = cPickType.BroadCase then
        case v_refContainerType
          when CLabelType.LABEL_TYPE_B then
            --物流箱标签
            v_ReportID := const_reportid.B_DividePickTaskLabel_B;
          when CLabelType.LABEL_TYPE_P then
            --板标签
            v_ReportID := const_reportid.B_DividePickTaskLabel_C;
          else
            v_ReportID := const_reportid.B_DividePickTaskLabel_B;
        end case;
      else
        case v_refContainerType
          when CLabelType.LABEL_TYPE_B then
            v_ReportID := const_reportid.B_DividePickTaskLabel_B;
          when CLabelType.LABEL_TYPE_P then
            v_ReportID := const_reportid.B_DividePickTaskLabel_C;
          else
            v_ReportID := const_reportid.B_DividePickTaskLabel_B;
        end case;
      end if;

      --更新下架明细
      PKOBJ_ODATA_LICH.P_Update_Odata_OutStock_D(strEnterPriseNo,
                                                 strWarehose_No,
                                                 strOutstock_No,
                                                 v_RealQTY,
                                                 v_refContainerNO,
                                                 curOutstockInfo.Owner_No,
                                                 curOutstockInfo.Divide_Id,
                                                 strOutstock_ID,
                                                 strInstock_ID,
                                                 '13',
                                                 strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --更新库存
      PKOBJ_STOCK.proc_OM_Receipt_WriteContent(strEnterPriseNo,
                                               strWarehose_No,
                                               curOutstockInfo.s_Cell_Id,
                                               curOutstockInfo.s_Cell_No,
                                               curOutstockInfo.d_Cell_Id,
                                               curOutstockInfo.d_Cell_No,
                                               v_RealQTY,
                                               curOutstockInfo.Article_Qty,
                                               strOutstock_No,
                                               '1',
                                               strInstock_ID,
                                               strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --新取号标签，新增标签头
      if v_NewFlag = 1 and nReal_QTY > 0 then
        --若有回单数量才需要写标签头档
        PKOBJ_LABEL.proc_Insert_LabelMaster(strEnterPriseNo,
                                            strWarehose_No,
                                            curOutstockInfo.Batch_No,
                                            curOutstockInfo.Outstock_No,
                                            strFixLabel_No,
                                            v_refContainerNO,
                                            v_refContainerType,
                                            curOutstockInfo.Deliver_Area,
                                            curOutstockInfo.d_Cell_No,
                                            curOutstockInfo.Cust_No,
                                            curOutstockInfo.Trunck_Cell_No,
                                            curOutstockInfo.a_Sorter_Chute_No,
                                            curOutstockInfo.Check_Chute_No,
                                            v_DeliverObj,
                                            v_UseType,
                                            curOutstockInfo.Line_No,
                                            curOutstockInfo.Trunck_Cell_No,
                                            curOutstockInfo.device_no,
                                            strOutstock_ID,
                                            v_ReportID,
                                            'N',
                                            'N',
                                            curOutstockInfo.Stock_Type,
                                            'N',
                                            v_refContainerNO,
                                            v_LabelStatus,
                                            v_strHmManualFlag,
                                            curOutstockInfo.wave_no,
                                            strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
      end if;

      --写目的标签明细
      pkOBJ_label_odata.P_O_WriteCustContainer(strEnterPriseNo,
                                               strWarehose_No,
                                               strOutstock_No,
                                               curOutstockInfo.divide_id,
                                               strOutstock_ID,
                                               strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --如果是摘果则需要转移到目的标签
      if curOutstockInfo.Pick_Type = cPickType.Picking then
        --将库存从储位转移到目的标签
        PKOBJ_STOCK.proc_OM_MoveContent_ByContenNo(strEnterPriseNo,
                                                   strWarehose_No,
                                                   strOutstock_No,
                                                   curOutstockInfo.divide_id,
                                                   1,
                                                   strUserId,
                                                   strOutMsg);
        if substr(strOutMsg, 1, 1) = 'N' then
          return;
        end if;
      end if;

      --全部回单
      v_ExpTraceStatus := COdataExpStatus.ExpTracALLReceipt;
      select count(1)
        into v_ExpTraceStatusCount
        from odata_outstock_d d
       where d.warehouse_no = strWarehose_No
         and d.enterprise_no = strEnterPriseNo
         and d.exp_type = curOutstockInfo.Exp_Type
         and d.exp_no = curOutstockInfo.Exp_No
         and d.status < '13';

      if v_ExpTraceStatusCount > 0 then
        v_ExpTraceStatus := COdataExpStatus.ExpTracPartReceipt; --部分回单
      else
        select count(1)
          into v_ExpTraceStatusCount
          from odata_outstock_direct d
         where d.warehouse_no = strWarehose_No
           and d.enterprise_no = strEnterPriseNo
           and d.exp_type = curOutstockInfo.Exp_Type
           and d.exp_no = curOutstockInfo.Exp_No
           and d.status < '13';

        if v_ExpTraceStatusCount > 0 then
          v_ExpTraceStatus := COdataExpStatus.ExpTracPartReceipt; --部分回单
        end if;
      end if;

      --单据状态跟踪
      PKOBJ_ODISPATCH.P_Insert_Odata_Exp_Trace(strEnterPriseNo,
                                               strWarehose_No,
                                               curOutstockInfo.Exp_No,
                                               v_ExpTraceStatus,
                                               strUserId,
                                               strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

    end loop;

    if v_Count = 0 then
      strOutMsg := 'N|[E22512]';
      return;
    end if;

    --处理标签数据

    P_SavePickLabel(strEnterPriseNo,
                    strWarehose_No,
                    v_strWaveNo,
                    v_strBatchNo,
                    strOutstock_No,
                    strFixLabel_No,
                    strDock_No,
                    strUserID,
                    strOutMsg);

    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    --整单确认
    P_ComfireOutstock(strEnterPriseNo,
                      strWarehose_No,
                      strOutstock_No,
                      strUserID,
                      strOutMsg);

    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    select count(1)
      into v_Count
      from odata_outstock_d d
     where d.status in ('10', '11', '12')
       and d.outstock_no = strOutstock_No
       and d.warehouse_no = strWarehose_No;

    if v_Count <= 0 then
      --触发补货指示
      pkobj_odata.P_O_CheckStatusCanOutstock(strEnterPriseNo,
                                             strWarehose_No,
                                             v_strOwnerNo,
                                             strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
    end if;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_Save_Odata_Outstock;

  /**********************************************************************************************8
  lich
  20140521
  功能说明：任务标签拣货回单
  ***********************************************************************************************/
  procedure P_TaskLabelSave_Odata_Outstock(strEnterPriseNo in odata_outstock_m.enterprise_no%type, --企业号
                                           strWarehose_No  in odata_outstock_m.warehouse_no%type, --仓别
                                           strOutstock_No  in odata_outstock_m.outstock_no%type, --下架单号
                                           strFixLabel_No  in odata_outstock_d.label_no%type, --来源标签号码
                                           strDLabelNo     in stock_label_m.label_no%type, --目的标签号
                                           strArticle_No   in odata_outstock_d.article_no%type, --商品编码
                                           nPacking_QTY    in odata_outstock_d.packing_qty%type, --包装数量
                                           strSCell_No     in odata_outstock_d.s_cell_no%type, --来源储位
                                           nArticleQty     in odata_outstock_d.article_qty%type, --计划数量
                                           nReal_QTY       in odata_outstock_d.article_qty%type, --下架数量
                                           strQuality      in idata_check_d.quality%type, --品质
                                           dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                                           dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                                           strLotNo        in stock_article_info.lot_no%type, --批次号
                                           strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                                           strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                                           strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                                           strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                                           strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                                           strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                                           strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                                           strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                                           strDock_No      in odata_outstock_m.dock_no%type, --工作站
                                           strUserID       in odata_outstock_m.rgst_name%type, --回单人
                                           strOutstock_ID  in odata_outstock_d.outstock_name%type, --下架人
                                           strInstock_ID   in odata_outstock_d.instock_name%type, --上架人
                                           strOutMsg       out varchar2) is
    v_strWaveNo       odata_outstock_m.wave_no%type;
    v_strBatchNo      odata_outstock_m.batch_no%type;
    v_strPickDiffFlag wms_outpick_strategy.pick_diff_flag%type; --差异回单
    v_strDLabelNo     stock_label_m.label_no%type;
  begin
    strOutMsg := 'N|[P_TaskLabelSave_Odata_Outstock]';
    update odata_outstock_m m
       set m.updt_date = sysdate, m.updt_name = strUserID
     where m.enterprise_no = strEnterPriseNo
       and m.warehouse_no = strWarehose_No
       and m.outstock_no = strOutstock_No
       and m.status < '13';

    if sql%rowcount <= 0 then
      return;
    end if;

    begin
      select oom.wave_no, oom.batch_no, wos.pick_diff_flag
        into v_strWaveNo, v_strBatchNo, v_strPickDiffFlag
        from odata_outstock_m     oom,
             odata_locate_batch   olb,
             wms_outpick_strategy wos
       where oom.enterprise_no = olb.enterprise_no
         and oom.warehouse_no = olb.warehouse_no
         and oom.wave_no = olb.wave_no
         and oom.batch_no = olb.batch_no
         and olb.enterprise_no = wos.enterprise_no
         and olb.pick_strategy_id = wos.pick_strategy_id
         and oom.enterprise_no = strEnterPriseNo
         and oom.warehouse_no = strWarehose_No
         and oom.outstock_no = strOutstock_No
         and oom.status < '13';
    exception
      when no_data_found then
        strOutMsg := 'N|[找不到需要回单的数据]';
        return;
    end;

    if v_strPickDiffFlag = '0' then
      --不允许差异回单
      if nArticleQty <> nReal_QTY then
        strOutMsg := 'N|[此拣货单不允许差异回单]';
        return;
      end if;
    end if;

    --保存拣货数据
    P_SaveOutstock(strEnterPriseNo,
                   strWarehose_No,
                   strOutstock_No,
                   strFixLabel_No,
                   strDLabelNo,
                   strArticle_No,
                   nPacking_QTY,
                   strSCell_No,
                   nReal_QTY,
                   strQuality,
                   dtProduceDate,
                   dtExpireDate,
                   strLotNo,
                   strRSV_BATCH1,
                   strRSV_BATCH2,
                   strRSV_BATCH3,
                   strRSV_BATCH4,
                   strRSV_BATCH5,
                   strRSV_BATCH6,
                   strRSV_BATCH7,
                   strRSV_BATCH8,
                   strUserID,
                   strOutstock_ID,
                   strInstock_ID,
                   v_strDLabelNo,
                   strOutMsg);

    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    --处理标签数据
    for GetLabelNo in (select distinct label_no from stock_label_m
        where enterprise_no=strEnterPriseNo and warehouse_no=strWarehose_No
        and source_no=strOutstock_No and status<='52') loop

        P_SavePickLabel(strEnterPriseNo,
                        strWarehose_No,
                        v_strWaveNo,
                        v_strBatchNo,
                        strOutstock_No,
                        GetLabelNo.label_no,
                        strDock_No,
                        strUserID,
                        strOutMsg);

        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
    end loop;

    --整单确认
    P_ComfireOutstock(strEnterPriseNo,
                      strWarehose_No,
                      strOutstock_No,
                      strUserID,
                      strOutMsg);

    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_TaskLabelSave_Odata_Outstock;

  /**********************************************************************************************8
  luozhiling
  20150702
  功能说明：按标签上的商品进行回单保存数据:
  1、按商品进行下架回单；
  2、更新库存；
  3、更新标签数据
  ***********************************************************************************************/
  procedure P_SerialLabel_Save(strEnterPriseNo in odata_outstock_m.enterprise_no%type, --企业号
                               strWarehose_No  in odata_outstock_m.warehouse_no%type, --仓别
                               strOutstock_No  in odata_outstock_m.outstock_no%type, --下架单号
                               strFixLabel_No  in odata_outstock_d.label_no%type, --来源标签号码
                               strArticle_No   in odata_outstock_d.article_no%type, --商品编码
                               nPacking_QTY    in odata_outstock_d.packing_qty%type, --包装数量
                               strSCell_No     in odata_outstock_d.s_cell_no%type, --来源储位
                               nReal_QTY       in odata_outstock_d.article_qty%type, --下架数量
                               strQuality      in idata_check_d.quality%type, --品质
                               dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                               dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                               strLotNo        in stock_article_info.lot_no%type, --批次号
                               strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                               strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                               strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                               strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                               strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                               strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                               strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                               strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                               strUserID       in odata_outstock_m.rgst_name%type, --回单人
                               strOutstock_ID  in odata_outstock_d.outstock_name%type, --下架人
                               strInstock_ID   in odata_outstock_d.instock_name%type, --上架人
                               strOutMsg       out varchar2) is

    v_refContainerNO      stock_label_m.container_no%type := 'N';
    v_TotalQTY            odata_outstock_d.real_qty%type := nReal_QTY;
    v_RealQTY             odata_outstock_d.real_qty%type := 0;
    v_strOwnerNo          bdef_defowner.owner_no%type;
    v_Count               integer := 0;
    v_ExpTraceStatus      odata_exp_m.status%type;
    v_ExpTraceStatusCount integer := 0;

    cursor v_GetOutstockItem is
      select m.outstock_type,
             m.operate_type,
             m.source_type,
             m.pick_type,
             m.task_type,
             d.*
        from odata_outstock_d d, odata_outstock_m m, stock_article_info sai
       where d.enterprise_no = m.enterprise_no
         and d.enterprise_no = sai.enterprise_no
         and d.enterprise_no = strEnterPriseNo
         AND m.warehouse_no = d.warehouse_no
         and m.outstock_no = d.outstock_no
         and d.article_no = sai.article_no
         and d.article_id = sai.article_id
         and d.warehouse_no = strWarehose_No
         and d.outstock_no = strOutstock_No
         and d.article_no = strArticle_No
         and d.packing_qty = nPacking_QTY
         and d.s_cell_no = strSCell_No
         and (d.s_container_no = v_refContainerNO or d.s_container_no = 'N')
         and sai.produce_date = dtProduceDate
         and sai.expire_date = dtExpireDate
         and sai.lot_no = strLotNo
         and sai.quality = strQuality
         and sai.rsv_batch1 = strRSV_BATCH1
         and sai.rsv_batch2 = strRSV_BATCH2
         and sai.rsv_batch3 = strRSV_BATCH3
         and sai.rsv_batch4 = strRSV_BATCH4
         and sai.rsv_batch5 = strRSV_BATCH5
         and sai.rsv_batch6 = strRSV_BATCH6
         and sai.rsv_batch7 = strRSV_BATCH7
         and sai.rsv_batch8 = strRSV_BATCH8
         and d.status = '10'
         and m.status = '10';

  begin
    strOutMsg := 'N|[P_SaveOutstock]';

    begin
      select slm.container_no
        into v_refContainerNO
        from stock_label_m slm
       where slm.enterprise_no = strEnterPriseNo
         and slm.warehouse_no = strWarehose_No
         and slm.label_no = strFixLabel_No;
    exception
      when no_data_found then
        strOutMsg := 'N|[E22513]';
        return;
    end;

    for curOutstockInfo in v_GetOutstockItem loop
      v_Count      := v_Count + 1;
      v_strOwnerNo := curOutstockInfo.Owner_No;
      if v_TotalQTY >= curOutstockInfo.Article_Qty then
        v_RealQTY := curOutstockInfo.Article_Qty;
      else
        v_RealQTY := v_TotalQTY;
      end if;

      v_TotalQTY := v_TotalQTY - v_RealQTY;

      --更新下架明细
      update odata_outstock_d ood
         set ood.real_qty      = ood.real_qty + v_RealQTY,
             ood.outstock_name = strOutstock_ID,
             ood.outstock_date = sysdate,
             ood.instock_name  = strOutstock_ID,
             ood.instock_date  = sysdate
       where ood.enterprise_no = strEnterPriseNo
         and ood.warehouse_no = strWarehose_No
         and ood.outstock_no = strOutstock_No
         and ood.divide_id = curOutstockInfo.divide_id
         and ood.article_qty >= ood.real_qty + v_RealQTY;

      if sql%notfound then
        strOutMsg := 'N|[更新不到对应的下架明细]';
        return;
      end if;

      update odata_outstock_d ood
         set ood.status = '13'
       where ood.enterprise_no = strEnterPriseNo
         and ood.warehouse_no = strWarehose_No
         and ood.outstock_no = strOutstock_No
         and ood.divide_id = curOutstockInfo.divide_id
         and ood.article_qty = ood.real_qty;

      --更新库存
      PKOBJ_STOCK.proc_OM_Receipt_WriteContent(strEnterPriseNo,
                                               strWarehose_No,
                                               curOutstockInfo.s_Cell_Id,
                                               curOutstockInfo.s_Cell_No,
                                               curOutstockInfo.d_Cell_Id,
                                               curOutstockInfo.d_Cell_No,
                                               v_RealQTY,
                                               v_RealQTY,
                                               strOutstock_No,
                                               '1',
                                               strOutstock_ID,
                                               strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      PKOBJ_LABEL.P_Updt_OutStock_Label(strEnterPriseNo,
                                        strWarehose_No,
                                        curOutstockInfo.Owner_No,
                                        strOutstock_No,
                                        strFixLabel_No,
                                        v_RealQTY,
                                        curOutstockInfo.d_Cell_No,
                                        curOutstockInfo.divide_id,
                                        strOutstock_ID,
                                        strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      if v_TotalQTY = 0 then
        exit;
      end if;

      --全部回单
      v_ExpTraceStatus := COdataExpStatus.ExpTracALLReceipt;
      select count(1)
        into v_ExpTraceStatusCount
        from odata_outstock_d d
       where d.warehouse_no = strWarehose_No
         and d.enterprise_no = strEnterPriseNo
         and d.exp_type = curOutstockInfo.Exp_Type
         and d.exp_no = curOutstockInfo.Exp_No
         and d.status < '13';

      if v_ExpTraceStatusCount > 0 then
        v_ExpTraceStatus := COdataExpStatus.ExpTracPartReceipt; --部分回单
      else
        select count(1)
          into v_ExpTraceStatusCount
          from odata_outstock_direct d
         where d.warehouse_no = strWarehose_No
           and d.enterprise_no = strEnterPriseNo
           and d.exp_type = curOutstockInfo.Exp_Type
           and d.exp_no = curOutstockInfo.Exp_No
           and d.status < '13';

        if v_ExpTraceStatusCount > 0 then
          v_ExpTraceStatus := COdataExpStatus.ExpTracPartReceipt; --部分回单
        end if;
      end if;

      --单据状态跟踪
      PKOBJ_ODISPATCH.P_Insert_Odata_Exp_Trace(strEnterPriseNo,
                                               strWarehose_No,
                                               curOutstockInfo.Exp_No,
                                               v_ExpTraceStatus,
                                               strOutstock_ID,
                                               strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

    end loop;

    if v_Count = 0 then
      strOutMsg := 'N|[E22512]';
      return;
    end if;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_SerialLabel_Save;

  /**********************************************************************************************8
  luozhiling
  20150702
  功能说明：按标签上的商品进行0回单保存数据:
  1、按商品进行下架回单；
  2、更新库存；
  3、更新标签数据
  ***********************************************************************************************/

  procedure P_SerialLabelCancel(strEnterPriseNo in odata_outstock_m.enterprise_no%type, --企业号
                                strWarehose_No  in odata_outstock_m.warehouse_no%type, --仓别
                                strOutstock_No  in odata_outstock_m.outstock_no%type, --下架单号
                                strFixLabel_No  in odata_outstock_d.label_no%type, --来源标签号码
                                strArticle_No   in odata_outstock_d.article_no%type, --商品编码
                                nPacking_QTY    in odata_outstock_d.packing_qty%type, --包装数量
                                strSCell_No     in odata_outstock_d.s_cell_no%type, --来源储位
                                nReal_QTY       in odata_outstock_d.article_qty%type, --下架数量
                                strQuality      in idata_check_d.quality%type, --品质
                                dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                                dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                                strLotNo        in stock_article_info.lot_no%type, --批次号
                                strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                                strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                                strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                                strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                                strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                                strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                                strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                                strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                                strUserID       in odata_outstock_m.rgst_name%type, --回单人
                                strOutstock_ID  in odata_outstock_d.outstock_name%type, --下架人
                                strInstock_ID   in odata_outstock_d.instock_name%type, --上架人
                                strOutMsg       out varchar2) is

    v_refContainerNO stock_label_m.container_no%type := 'N';
    v_TotalQTY       odata_outstock_d.real_qty%type := nReal_QTY;
    v_RealQTY        odata_outstock_d.real_qty%type := 0;
    v_strOwnerNo     bdef_defowner.owner_no%type;
    v_Count          integer := 0;
    cursor v_GetOutstockItem is
      select m.outstock_type,
             m.operate_type,
             m.source_type,
             m.pick_type,
             m.task_type,
             d.*,
             sld.qty as label_qty
        from odata_outstock_d   d,
             odata_outstock_m   m,
             stock_article_info sai,
             stock_label_d      sld,
             stock_label_m      slm
       where slm.enterprise_no = sld.enterprise_no
         and slm.warehouse_no = sld.warehouse_no
         and slm.container_no = sld.container_no
         and slm.label_no = strFixLabel_No
         and sld.enterprise_no = d.enterprise_no
         and sld.warehouse_no = d.warehouse_no
         and sld.exp_type = d.exp_type
         and sld.exp_no = d.exp_no
         and sld.divide_id = d.divide_id
         and d.enterprise_no = m.enterprise_no
         and d.enterprise_no = sai.enterprise_no
         and d.enterprise_no = strEnterPriseNo
         AND m.warehouse_no = d.warehouse_no
         and m.outstock_no = d.outstock_no
         and d.article_no = sai.article_no
         and d.article_id = sai.article_id
         and d.warehouse_no = strWarehose_No
         and d.outstock_no = strOutstock_No
         and d.article_no = strArticle_No
         and d.packing_qty = nPacking_QTY
         and d.s_cell_no = strSCell_No
         and (d.s_container_no = v_refContainerNO or d.s_container_no = 'N')
         and sai.produce_date = dtProduceDate
         and sai.expire_date = dtExpireDate
         and sai.lot_no = strLotNo
         and sai.quality = strQuality
         and sai.rsv_batch1 = strRSV_BATCH1
         and sai.rsv_batch2 = strRSV_BATCH2
         and sai.rsv_batch3 = strRSV_BATCH3
         and sai.rsv_batch4 = strRSV_BATCH4
         and sai.rsv_batch5 = strRSV_BATCH5
         and sai.rsv_batch6 = strRSV_BATCH6
         and sai.rsv_batch7 = strRSV_BATCH7
         and sai.rsv_batch8 = strRSV_BATCH8
         and d.status = '10'
         and m.status = '10';

  begin
    strOutMsg := 'N|[P_SerialLabelCancel]';

    begin
      select slm.container_no
        into v_refContainerNO
        from stock_label_m slm
       where slm.enterprise_no = strEnterPriseNo
         and slm.warehouse_no = strWarehose_No
         and slm.label_no = strFixLabel_No;
    exception
      when no_data_found then
        strOutMsg := 'N|[E22513]';
        return;
    end;

    for curOutstockInfo in v_GetOutstockItem loop
      v_Count      := v_Count + 1;
      v_strOwnerNo := curOutstockInfo.Owner_No;
      if v_TotalQTY >= curOutstockInfo.Label_Qty then
        v_RealQTY := curOutstockInfo.Label_Qty;
      else
        v_RealQTY := v_TotalQTY;
      end if;

      v_TotalQTY := v_TotalQTY - v_RealQTY;

      --更新下架明细
      update odata_outstock_d ood
         set ood.real_qty      = ood.real_qty + v_RealQTY,
             ood.outstock_name = strOutstock_ID,
             ood.outstock_date = sysdate,
             ood.instock_name  = strOutstock_ID,
             ood.instock_date  = sysdate
       where ood.enterprise_no = strEnterPriseNo
         and ood.warehouse_no = strWarehose_No
         and ood.outstock_no = strOutstock_No
         and ood.divide_id = curOutstockInfo.divide_id
         and ood.article_qty >= ood.real_qty + v_RealQTY;

      if sql%notfound then
        strOutMsg := 'N|[更新不到对应的下架明细]';
        return;
      end if;

      --更新库存
      PKOBJ_STOCK.proc_OM_Receipt_WriteContent(strEnterPriseNo,
                                               strWarehose_No,
                                               curOutstockInfo.s_Cell_Id,
                                               curOutstockInfo.s_Cell_No,
                                               curOutstockInfo.d_Cell_Id,
                                               curOutstockInfo.d_Cell_No,
                                               v_RealQTY,
                                               --curOutstockInfo.Article_Qty, Modify BY QZH AT 2016-5-26
                                               curOutstockInfo.Label_Qty,
                                               strOutstock_No,
                                               '1',
                                               strOutstock_ID,
                                               strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      PKOBJ_LABEL.P_UpdtCancelOutStock_Label(strEnterPriseNo,
                                             strWarehose_No,
                                             strOutstock_No,
                                             strFixLabel_No,
                                             v_RealQTY,
                                             curOutstockInfo.divide_id,
                                             strOutstock_ID,
                                             strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

    /* if v_TotalQTY = 0 then
                                    exit;
                                  end if;*/

    end loop;

    if v_Count = 0 then
      strOutMsg := 'N|[E22512]';
      return;
    end if;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_SerialLabelCancel;

  --外部号转内部号
  procedure TransFixNoToSerialNo(strEnterPriseNo     in stock_label_m.Enterprise_No%type, --企业号
                                 strWAREHOUSE_NO     in stock_label_m.warehouse_no%type,
                                 strLabel_No         in stock_label_m.label_no%type,
                                 strUserID           in stock_label_m.rgst_name%type,
                                 strUseType          in stock_label_m.use_type%type,
                                 strDeliverOBJ       in stock_label_m.deliver_obj%type,
                                 strOperateType      in odata_outstock_m.operate_type%type,
                                 strContainer_Type   out stock_label_m.container_type%type,
                                 strContainer_No     out stock_label_m.container_no%type,
                                 strContainerNewFlag out integer,
                                 strOutMsg           out varchar2) is
    v_strContainerNo stock_label_m.container_no%type := 'N';
    v_strLabelNo     stock_label_m.label_no%type := 'N';
    v_SessionID      varchar2(100) := 'N';
  begin
    strOutMsg           := 'N|';
    strContainerNewFlag := 0;
    CheckContainerStatus(strEnterPriseNo,
                         strWAREHOUSE_NO,
                         strLabel_No,
                         strUserID,
                         strUseType,
                         strDeliverOBJ,
                         strContainer_Type,
                         strContainer_No,
                         strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    if substr(strOutMsg, 1, 1) = 'Y' and strContainer_Type <> 'N' then
      return;
    end if;

    if strContainer_Type = 'N' or strContainer_Type is null then
      if strOperateType = 'B' then
        strContainer_Type := CLabelType.LABEL_TYPE_B;
      else
        strContainer_Type := CLabelType.LABEL_TYPE_P;
      end if;
      PKLG_WMS_BASE.p_get_ContainerNoBase(strEnterPriseNo,
                                          strWAREHOUSE_NO,
                                          strContainer_Type,
                                          strUserID,
                                          CLabelType.LABEL_TYPE_P,
                                          1,
                                          strUseType,
                                          null,
                                          v_strLabelNo,
                                          v_strContainerNo,
                                          v_SessionID,
                                          strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
      strContainer_No := v_strContainerNo;
      --strContainer_Type   := CLabelType.LABEL_TYPE_P;
      strContainerNewFlag := 1;
    end if;
    strOutMsg := 'Y|成功!';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end TransFixNoToSerialNo;

  --检查标签状态
  procedure CheckContainerStatus(strEnterPriseNo   in stock_label_m.enterprise_no%type,
                                 strWAREHOUSE_NO   in stock_label_m.warehouse_no%type,
                                 strLabel_No       in stock_label_m.label_no%type,
                                 strUserID         in stock_label_m.rgst_name%type,
                                 strUseType        in stock_label_m.use_type%type,
                                 strDeliverOBJ     in stock_label_m.deliver_obj%type,
                                 strContainer_Type out stock_label_m.container_type%type,
                                 strContainer_No   out stock_label_m.container_no%type,
                                 strOutMsg         out varchar2) is
    --v_Count                  integer:=0;
    v_ContainerNo   stock_label_m.container_no%type;
    v_ContainerType stock_label_m.container_type%type;
    v_UserType      stock_label_m.use_type%type;
    v_DeliverObj    stock_label_m.deliver_obj%type;
    v_Status        stock_label_m.status%type;
  begin

    begin
      select clm.container_no,
             clm.container_type,
             clm.use_type,
             clm.deliver_obj,
             clm.status
        into v_ContainerNo,
             v_ContainerType,
             v_UserType,
             v_DeliverObj,
             v_Status
        from stock_label_m clm
       where clm.label_no = strLabel_No
         and clm.warehouse_no = strWAREHOUSE_NO
         and clm.enterprise_no = strEnterPriseNo
         and clm.status not between
             CDestroyLabelStatusRange.DESTROY_BEGIN_STATUS and
             CDestroyLabelStatusRange.DESTROY_END_STATUS;
    exception
      when no_data_found then
        v_ContainerNo   := 'N';
        v_ContainerType := 'N';
    end;

    if v_ContainerNo = 'N' and v_ContainerType = 'N' then
      strOutMsg := 'Y|成功!';
      return;
    end if;

    if strUseType <> v_UserType then
      strOutMsg := 'N|[E22514]';
      return;
    end if;

    if v_UserType = CLabelUseType.CUSTOMER_LABEL then
      if v_DeliverObj <> strDeliverOBJ and v_DeliverObj <> 'N' then
        strOutMsg := 'N|[E22515]';
        return;
      end if;
      if v_Status <> CLABELSTATUS.PICK_END and --CCustomerLabel.PICK_END and
         v_Status <> CLABELSTATUS.NEW_LABEL_NO and
         v_Status <> CLABELSTATUS.RECEIVING then
        strOutMsg := 'N|[E22516]';
        return;
      end if;

      --配送对象不一样为新取板号，则更新配送对象
      if v_DeliverObj <> strDeliverOBJ or
         v_Status = CLABELSTATUS.NEW_LABEL_NO then
        UPDATE STOCK_LABEL_M
           SET DELIVER_OBJ = strDeliverOBJ,
               UPDT_DATE   = SYSDATE,
               UPDT_NAME   = strUserID,
               STATUS      = CLABELSTATUS.PICK_END
         WHERE LABEL_NO = strLabel_No
           AND WAREHOUSE_NO = strWAREHOUSE_NO
           and EnterPrise_No = strEnterPriseNo;

        if sql%rowcount <= 0 then
          strOutMsg := 'N|[E22517]';
          return;
        end if;
      end if;
    end if;

    strContainer_Type := v_ContainerType;
    strContainer_No   := v_ContainerNo;
    strOutMsg         := 'Y|成功！';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end CheckContainerStatus;
  /***************************************************************************************************
    功能说明：拣货差异回单处理出货单
    luozhiling
    2015.05.4
  *****************************************************************************************************/
  procedure P_SaveOutstockDiff(strEnterPriseNo in odata_outstock_m.enterprise_no%type,
                               strWareHouseNo  in odata_outstock_m.warehouse_no%type,
                               strWaveNo       in odata_outstock_m.wave_no%type,
                               strBatchNo      in odata_outstock_m.batch_no%type,
                               strOutstockNo   in odata_outstock_m.outstock_no%type,
                               strUserID       in bdef_defworker.worker_no%type, --系统操作人员
                               strOutMsg       out varchar2) is
    v_strShortQtyType odata_locate_batch.shortqty_type%type;
    v_iCount          integer;
    v_nOutstockQty    odata_outstock_d.real_qty%type;
  begin
    strOutMsg := 'N|[P_SaveOutstockDiff]';

    --读取此出货单对应的缺量处理方式
    begin
      select t.shortqty_type
        into v_strShortQtyType
        from odata_locate_batch t
       where t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strWareHouseNo
         and t.wave_no = strWaveNo
         and t.batch_no = strBatchNo;
    exception
      when no_data_found then
        strOutMsg := 'N|[读取不到对应的配置信息]';
        return;
    end;

    if v_strShortQtyType = '3' then
      --重定位

      pkobj_odata_lich.P_O_DiffOutstock(strEnterPriseNo,
                                        strWareHouseNo,
                                        strOutstockNo,
                                        strUserID,
                                        strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
    end if;

    if v_strShortQtyType = '4' then
      --
      for GetOutstockItem in (select distinct ood.wave_no,
                                              ood.owner_no,
                                              ood.exp_no
                                from odata_outstock_d ood
                               where ood.enterprise_no = strEnterPriseNo
                                 and ood.warehouse_no = strWareHouseNo
                                 and ood.outstock_no = strOutstockNo
                                 and ood.article_qty <> ood.real_qty
                                 and ood.status = '13') loop

        PKLG_ODATA_EXPCANCEL.P_TurnOdataExpCancel(strEnterpriseNo,
                                                  strWareHouseNo,
                                                  GetOutstockItem.owner_no,
                                                  GetOutstockItem.exp_no,
                                                  '2',
                                                  strUserID,
                                                  strOutMsg);

        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;

        --判断是否全部发单
        select count(*)
          into v_iCount
          from odata_outstock_direct ood
         where ood.enterprise_no = strEnterPriseNo
           and ood.warehouse_no = strWareHouseNo
           and ood.exp_no = GetOutstockItem.exp_no
           and ood.status in ('10', '11', '12');

        if v_iCount = 0 then

          --首先判断此出货单是否全部回单，若未全部回单，继续下一单
          select count(*)
            into v_iCount
            from odata_outstock_d ood
           where ood.enterprise_no = strEnterPriseNo
             and ood.warehouse_no = strWareHouseNo
             and ood.exp_no = GetOutstockItem.exp_no
             and ood.status in ('10', '11', '12');

          if v_iCount = 0 then
            --

            --计算数量

            select a.qty + b.qty
              into v_nOutstockQty
              from (select nvl(sum(ood.real_qty), 0) qty
                      from odata_outstock_d ood
                     where ood.enterprise_no = strEnterPriseNo
                       and ood.warehouse_no = strWareHouseNo
                       and ood.exp_no = GetOutstockItem.exp_no) a,
                   (select nvl(sum(qty), 0) qty
                      from stock_label_d sld
                     where sld.enterprise_no = strEnterPriseNo
                       and sld.warehouse_no = strWareHouseNo
                       and sld.exp_no = GetOutstockItem.exp_no
                       and sld.wave_no = GetOutstockItem.wave_no) b;

            if v_nOutstockQty = 0 then
              PKLG_ODATA_EXPCANCEL.P_CreateOdataExpCancel(strEnterpriseNo,
                                                          strWareHouseNo,
                                                          GetOutstockItem.owner_no,
                                                          GetOutstockItem.exp_no,
                                                          '2',
                                                          strUserID,
                                                          strOutMsg);

              if substr(strOutMsg, 1, 1) <> 'Y' then
                return;
              end if;
            end if;
          end if;
        end if;
      end loop;
    end if;
    strOutMsg := 'Y|[成功]';
  end P_SaveOutstockDiff;

  /**********************************************************************************************8
  luozhiling
  20150702
  功能说明：按标签上的商品进行回单保存数据:
  1、按商品进行下架回单；
  2、更新库存；
  3、更新标签数据
  ***********************************************************************************************/
  procedure P_SaveOutstock(strEnterPriseNo in odata_outstock_m.enterprise_no%type, --企业号
                           strWarehose_No  in odata_outstock_m.warehouse_no%type, --仓别
                           strOutstock_No  in odata_outstock_m.outstock_no%type, --下架单号
                           strFixLabel_No  in odata_outstock_d.label_no%type, --来源标签号码
                           strDLabelNo     in stock_label_m.label_no%type, --目的标签号
                           strArticle_No   in odata_outstock_d.article_no%type, --商品编码
                           nPacking_QTY    in odata_outstock_d.packing_qty%type, --包装数量
                           strSCell_No     in odata_outstock_d.s_cell_no%type, --来源储位
                           nReal_QTY       in odata_outstock_d.article_qty%type, --下架数量
                           strQuality      in idata_check_d.quality%type, --品质
                           dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                           dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                           strLotNo        in stock_article_info.lot_no%type, --批次号
                           strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                           strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                           strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                           strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                           strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                           strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                           strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                           strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                           strUserID       in odata_outstock_m.rgst_name%type, --回单人
                           strOutstock_ID  in odata_outstock_d.outstock_name%type, --下架人
                           strInstock_ID   in odata_outstock_d.instock_name%type, --上架人
                           strOutLabelNo   out stock_label_m.label_no%type,
                           strOutMsg       out varchar2) is

    v_refContainerNO      stock_label_m.container_no%type := 'N'; --来源内部容器号
    v_strDcontainerNo     stock_label_m.container_no%type := 'N'; --目的标签内部容器号
    strSessionID          varchar2(10);
    strLabelNoTmp         stock_label_m.label_no%type;
    v_TotalQTY            odata_outstock_d.real_qty%type := nReal_QTY;
    v_Container_Mete      wms_defcontainer.container_material%type;
    v_RealQTY             odata_outstock_d.real_qty%type := 0;
    v_strOwnerNo          bdef_defowner.owner_no%type;
    v_Count               integer := 0;
    v_strReportId         stock_label_m.report_id%type;
    v_ExpTraceStatus      odata_exp_m.status%type;
    v_ExpTraceStatusCount integer := 0;
    v_strsContainerType   stock_label_m.container_type%type;

    cursor v_GetOutstockItem is
      select m.outstock_type,
             m.operate_type,
             m.source_type,
             m.pick_type,
             m.task_type,
             olb.industry_flag,
             oem.shipper_deliver_no,
             d.*
        from odata_outstock_d   d,
             odata_outstock_m   m,
             stock_article_info sai,
             odata_locate_batch olb,
             odata_exp_m        oem
       where d.enterprise_no = m.enterprise_no
         and d.enterprise_no = sai.enterprise_no
         and d.enterprise_no = strEnterPriseNo
         AND m.warehouse_no = d.warehouse_no
         and m.outstock_no = d.outstock_no
         and d.article_no = sai.article_no
         and d.article_id = sai.article_id
         and m.enterprise_no = olb.enterprise_no
         and m.warehouse_no = olb.warehouse_no
         and d.enterprise_no = oem.enterprise_no
         and d.warehouse_no = oem.warehouse_no
         and d.exp_no = oem.exp_no
         and m.wave_no = olb.wave_no
         and m.batch_no = olb.batch_no
         and d.warehouse_no = strWarehose_No
         and d.outstock_no = strOutstock_No
         and d.article_no = strArticle_No
         and d.packing_qty = nPacking_QTY
         and d.s_cell_no = strSCell_No
         and (d.s_container_no = v_refContainerNO or d.s_container_no = 'N')
         and sai.produce_date = dtProduceDate
         and sai.expire_date = dtExpireDate
         and sai.lot_no = strLotNo
         and sai.quality = strQuality
         and sai.rsv_batch1 = strRSV_BATCH1
         and sai.rsv_batch2 = strRSV_BATCH2
         and sai.rsv_batch3 = strRSV_BATCH3
         and sai.rsv_batch4 = strRSV_BATCH4
         and sai.rsv_batch5 = strRSV_BATCH5
         and sai.rsv_batch6 = strRSV_BATCH6
         and sai.rsv_batch7 = strRSV_BATCH7
         and sai.rsv_batch8 = strRSV_BATCH8
         and d.status = '10'
         and m.status = '10';

  begin
    strOutMsg := 'N|[P_SaveOutstock]';
    --来源内部容器号
    begin
      select slm.container_no, slm.report_id,slm.container_type
        into v_refContainerNO, v_strReportId,v_strsContainerType
        from stock_label_m slm
       where slm.enterprise_no = strEnterPriseNo
         and slm.warehouse_no = strWarehose_No
         and slm.label_no = strFixLabel_No;
    exception
      when no_data_found then
        strOutMsg := 'N|[E22513]';
        return;
    end;

    if strDLabelNo='N' then
       strOutMsg:='N|[' || strDLabelNo || ']目的标签不正确]';
       return;
    end if;

    --Add BY QZH AT 2016-8-13
    if v_strsContainerType='B' then
      v_Container_Mete:='11';
    else
      v_Container_Mete:='31';
    end if;
    --Add End

    for curOutstockInfo in v_GetOutstockItem loop
      v_Count      := v_Count + 1;
      v_strOwnerNo := curOutstockInfo.Owner_No;
      if v_TotalQTY >= curOutstockInfo.Article_Qty then
        v_RealQTY := curOutstockInfo.Article_Qty;
      else
        v_RealQTY := v_TotalQTY;
      end if;

      v_TotalQTY := v_TotalQTY - v_RealQTY;

      --获取目的内部容器号
      if strFixLabel_No <> strDLabelNo or
         (curOutstockInfo.pick_type = '0' and
         curOutstockInfo.industry_flag = '2') then
        --做标签转换 --

        if curOutstockInfo.pick_type = '0' then
          if curOutstockInfo.industry_flag = '2' then
            --电商
            strOutLabelNo := curOutstockInfo.shipper_deliver_no;
          end if;
        else
          strOutLabelNo := strDLabelNo;
        end if;
        --1.转换目的标签,没有则生成标签,写入标签表
        begin
          SELECT CONTAINER_NO
            INTO v_strDcontainerNo
            FROM STOCK_LABEL_M
           WHERE warehouse_no = strWarehose_No
             and enterprise_no = strEnterPriseNo
             AND LABEL_NO = strOutLabelNo;

          update stock_label_m slm
             set slm.source_no = strOutstock_No,
                 slm.updt_name = strOutstock_ID,
                 slm.updt_date = sysdate
           where slm.enterprise_no = strEnterPriseNo
             and slm.warehouse_no = strWarehose_No
             and slm.label_no = strDLabelNo
             and slm.source_no <> strOutstock_No;

        exception
          when no_data_found then
            pklg_wms_base.p_get_ContainerNoBase(strEnterPriseNo,
                                                strWarehose_No,
                                                v_strsContainerType,
                                                strUserID,
                                                'D',
                                                1,
                                                '2',
                                                v_Container_Mete,
                                                strLabelNoTmp,
                                                v_strDcontainerNo,
                                                strSessionID,
                                                strOutMsg);
            if (substr(strOutMsg, 1, 1) = 'N') then
              return;
            end if;

            pkobj_label.proc_Insert_LabelMaster(strEnterPriseNo,
                                                strWarehose_No,
                                                curOutstockInfo.batch_no,
                                                strOutstock_No,
                                                strOutLabelNo,
                                                v_strDcontainerNo,
                                                v_strsContainerType,
                                                'N',
                                                curOutstockInfo.d_cell_no,
                                                curOutstockInfo.cust_no,
                                                curOutstockInfo.TRUNCK_CELL_NO,
                                                curOutstockInfo.a_sorter_chute_no,
                                                curOutstockInfo.CHECK_CHUTE_NO,
                                                curOutstockInfo.DELIVER_OBJ,
                                                CLabelUseType.CUSTOMER_LABEL,
                                                curOutstockInfo.line_no,
                                                'N',
                                                'N',
                                                strUserID,
                                                v_strReportId,
                                                'N',
                                                'N',
                                                '1',
                                                '0',
                                                v_strDcontainerNo,
                                                '50',
                                                '0',
                                                curOutstockInfo.wave_no,
                                                strOutMsg);
            if (substr(strOutMsg, 1, 1) = 'N') then
              return;
            end if;
        end;
      else
        strOutLabelNo     := strFixLabel_No;
        v_strDcontainerNo := v_refContainerNO;
      end if;

      --更新下架明细
      PKOBJ_ODATA_LICH.P_Update_Odata_OutStock_D(strEnterPriseNo,
                                                 strWarehose_No,
                                                 strOutstock_No,
                                                 v_RealQTY,
                                                 v_strDcontainerNo,
                                                 curOutstockInfo.Owner_No,
                                                 curOutstockInfo.Divide_Id,
                                                 strOutstock_ID,
                                                 strInstock_ID,
                                                 '13',
                                                 strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --更新库存
      PKOBJ_STOCK.proc_OM_Receipt_WriteContent(strEnterPriseNo,
                                               strWarehose_No,
                                               curOutstockInfo.s_Cell_Id,
                                               curOutstockInfo.s_Cell_No,
                                               curOutstockInfo.d_Cell_Id,
                                               curOutstockInfo.d_Cell_No,
                                               v_RealQTY,
                                               curOutstockInfo.Article_Qty,
                                               strOutstock_No,
                                               '1',
                                               strOutstock_ID,
                                               strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      PKOBJ_LABEL.P_Updt_OutStock_Label(strEnterPriseNo,
                                        strWarehose_No,
                                        curOutstockInfo.Owner_No,
                                        strOutstock_No,
                                        strFixLabel_No,
                                        v_RealQTY,
                                        curOutstockInfo.d_Cell_No,
                                        curOutstockInfo.divide_id,
                                        strOutstock_ID,
                                        strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --如果是摘果则需要转移到目的标签
      if curOutstockInfo.Pick_Type = cPickType.Picking then
        if strFixLabel_No <> strOutLabelNo then
          --增加目的标签商品数量,减少源标签商品数量
          PKOBJ_ODATA_LICH.P_odata_move_label(strEnterPriseNo,
                                              strWarehose_No,
                                              curOutstockInfo.Owner_No,
                                              curOutstockInfo.exp_type,
                                              strOutstock_No,
                                              v_refContainerNO,
                                              v_strDcontainerNo,
                                              curOutstockInfo.DIVIDE_ID,
                                              strArticle_no,
                                              curOutstockInfo.ARTICLE_ID,
                                              curOutstockInfo.PACKING_QTY,
                                              curOutstockInfo.EXP_NO,
                                              v_RealQTY,
                                              curOutstockInfo.cust_no,
                                              strOutstock_ID,
                                              strOutMsg);
          if (substr(strOutMsg, 1, 1) = 'N') then
            return;
          end if;
        end if;
        --将库存从储位转移到目的标签
        PKOBJ_STOCK.proc_OM_MoveContent_ByContenNo(strEnterPriseNo,
                                                   strWarehose_No,
                                                   strOutstock_No,
                                                   curOutstockInfo.divide_id,
                                                   1,
                                                   strOutstock_ID,
                                                   strOutMsg);
        if substr(strOutMsg, 1, 1) = 'N' then
          return;
        end if;
      end if;

      --全部回单
      v_ExpTraceStatus := COdataExpStatus.ExpTracALLReceipt;
      select count(1)
        into v_ExpTraceStatusCount
        from odata_outstock_d d
       where d.warehouse_no = strWarehose_No
         and d.enterprise_no = strEnterPriseNo
         and d.exp_type = curOutstockInfo.Exp_Type
         and d.exp_no = curOutstockInfo.Exp_No
         and d.status < '13';

      if v_ExpTraceStatusCount > 0 then
        v_ExpTraceStatus := COdataExpStatus.ExpTracPartReceipt; --部分回单
      else
        select count(1)
          into v_ExpTraceStatusCount
          from odata_outstock_direct d
         where d.warehouse_no = strWarehose_No
           and d.enterprise_no = strEnterPriseNo
           and d.exp_type = curOutstockInfo.Exp_Type
           and d.exp_no = curOutstockInfo.Exp_No
           and d.status < '13';

        if v_ExpTraceStatusCount > 0 then
          v_ExpTraceStatus := COdataExpStatus.ExpTracPartReceipt; --部分回单
        end if;
      end if;

      --单据状态跟踪
      PKOBJ_ODISPATCH.P_Insert_Odata_Exp_Trace(strEnterPriseNo,
                                               strWarehose_No,
                                               curOutstockInfo.Exp_No,
                                               v_ExpTraceStatus,
                                               strOutstock_ID,
                                               strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
    end loop;

    if v_Count = 0 then
      strOutMsg := 'N|[E22512]';
      return;
    end if;

    --触发补货指示
    pkobj_odata.P_O_CheckStatusCanOutstock(strEnterPriseNo,
                                           strWarehose_No,
                                           v_strOwnerNo,
                                           strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_SaveOutstock;

  /**********************************************************************************************8
  Quzhihui
  边拣边分
  20160621
  ***********************************************************************************************/
  procedure P_Outstock_PickDivide(strEnterPriseNo in odata_outstock_m.enterprise_no%type, --企业号
                                  strWarehose_No  in odata_outstock_m.warehouse_no%type, --仓别
                                  strOutstock_No  in odata_outstock_m.outstock_no%type, --下架单号
                                  strDivide_No    in odata_divide_m.divide_no%type,  --分播单号
                                  strS_Label_No   in odata_outstock_d.label_no%type, --来源标签号码
                                  strD_Label_No   in odata_outstock_d.d_container_no%type, --目的格子号
                                  strDeliver_Obj  in odata_outstock_d.deliver_obj%type, --配送对象
                                  strArticle_No   in odata_outstock_d.article_no%type, --商品编码
                                  nPacking_QTY    in odata_outstock_d.packing_qty%type, --包装数量
                                  strSCell_No     in odata_outstock_d.s_cell_no%type, --来源储位
                                  nArticleQty     in odata_outstock_d.article_qty%type, -- 计划数量
                                  nReal_QTY       in odata_outstock_d.article_qty%type, --下架数量
                                  strQuality      in idata_check_d.quality%type, --品质
                                  dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                                  dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                                  strLotNo        in stock_article_info.lot_no%type, --批次号
                                  strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                                  strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                                  strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                                  strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                                  strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                                  strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                                  strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                                  strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                                  strUserID       in odata_outstock_m.rgst_name%type, --回单人
                                  strOutstock_ID  in odata_outstock_d.outstock_name%type, --下架人
                                  strInstock_ID   in odata_outstock_d.instock_name%type, --上架人
                                  strOutMsg       out varchar2) is

    v_refContainerNO      stock_label_m.container_no%type := 'N';
    v_TotalQTY            odata_outstock_d.real_qty%type := nReal_QTY;
    v_RealQTY             odata_outstock_d.real_qty%type := 0;
    v_strOwnerNo          bdef_defowner.owner_no%type;
    v_Count               integer := 0;
    --v_Divide_No           odata_divide_m.divide_no%type := 'N';
    v_strPickDiffFlag     wms_outpick_strategy.pick_diff_flag%type; --差异回单
    v_Indus               odata_locate_batch.industry_flag%type;
    v_D_Label_No          odata_outstock_d.d_container_no%type;
    v_OUTSTOCK_TYPE       odata_outstock_m.outstock_type%type;
    v_ExpTraceStatus      odata_exp_m.status%type;
    v_ExpTraceStatusCount integer := 0;
    cursor v_GetOutstockItem is
      select m.outstock_type,
             m.operate_type,
             m.source_type,
             m.pick_type,
             m.task_type,
             oem.shipper_deliver_no,
             d.*
        from odata_outstock_d   d,
             odata_outstock_m   m,
             stock_article_info sai,
             odata_exp_m        oem
       where oem.enterprise_no = d.enterprise_no
         and oem.warehouse_no = d.warehouse_no
         and oem.exp_no = d.exp_no
         and oem.exp_type = d.exp_type
         and d.enterprise_no = m.enterprise_no
         and d.enterprise_no = sai.enterprise_no
         and d.enterprise_no = strEnterPriseNo
         AND m.warehouse_no = d.warehouse_no
         and m.outstock_no = d.outstock_no
         and d.article_no = sai.article_no
         and d.article_id = sai.article_id
         and d.warehouse_no = strWarehose_No
         and d.outstock_no = strOutstock_No
         and d.article_no = strArticle_No
         and d.packing_qty = nPacking_QTY
         and d.s_cell_no = strSCell_No
         and d.deliver_obj = strDeliver_Obj
         and (d.s_container_no = v_refContainerNO or d.s_container_no = 'N')
         and sai.produce_date = dtProduceDate
         and sai.expire_date = dtExpireDate
         and sai.lot_no = strLotNo
         and sai.quality = strQuality
         and sai.rsv_batch1 = strRSV_BATCH1
         and sai.rsv_batch2 = strRSV_BATCH2
         and sai.rsv_batch3 = strRSV_BATCH3
         and sai.rsv_batch4 = strRSV_BATCH4
         and sai.rsv_batch5 = strRSV_BATCH5
         and sai.rsv_batch6 = strRSV_BATCH6
         and sai.rsv_batch7 = strRSV_BATCH7
         and sai.rsv_batch8 = strRSV_BATCH8
         and d.status = '10'
         and m.status = '10'
         and d.dps_cell_no = strD_Label_No;

  begin
    strOutMsg := 'N|[P_Outstock_PickDivide]';

    --取拣货配置类型
    begin
      select wos.pick_diff_flag, olb.industry_flag, oom.outstock_type
        into v_strPickDiffFlag, v_Indus, v_OUTSTOCK_TYPE
        from odata_outstock_m     oom,
             odata_locate_batch   olb,
             wms_outpick_strategy wos
       where oom.enterprise_no = olb.enterprise_no
         and oom.warehouse_no = olb.warehouse_no
         and oom.wave_no = olb.wave_no
         and oom.batch_no = olb.batch_no
         and olb.enterprise_no = wos.enterprise_no
         and olb.pick_strategy_id = wos.pick_strategy_id
         and oom.enterprise_no = strEnterPriseNo
         and oom.warehouse_no = strWarehose_No
         and oom.outstock_no = strOutstock_No;
    exception
      when no_data_found then
        strOutMsg := 'N|[E22513]';
        return;
    end;

    if v_strPickDiffFlag = '0' or v_OUTSTOCK_TYPE = '1' then
      --不允许差异回单
      if nArticleQty <> nReal_QTY then
        strOutMsg := 'N|[此拣货单不允许差异回单]';
        return;
      end if;
    end if;

    begin
      select slm.container_no
        into v_refContainerNO
        from stock_label_m slm
       where slm.enterprise_no = strEnterPriseNo
         and slm.warehouse_no = strWarehose_No
         and slm.label_no = strS_Label_No;
    exception
      when no_data_found then
        strOutMsg := 'N|[E22513]';
        return;
    end;

    v_Count := 0;
    for curOutstockInfo in v_GetOutstockItem loop
      if curOutstockInfo.Pick_Type <> cPickType.PickingDivide then
        strOutMsg := 'N|拣货单[' || strOutstock_No || '非边拣边分拣货单';
        return;
      end if;
      v_Count      := v_Count + 1;
      v_strOwnerNo := curOutstockInfo.Owner_No;
      if v_TotalQTY >= curOutstockInfo.Article_Qty then
        v_RealQTY := curOutstockInfo.Article_Qty;
      else
        v_RealQTY := v_TotalQTY;
      end if;

      v_TotalQTY := v_TotalQTY - v_RealQTY;

      --更新下架明细
      PKOBJ_ODATA_LICH.P_Update_Odata_OutStock_D(strEnterPriseNo,
                                                 strWarehose_No,
                                                 strOutstock_No,
                                                 v_RealQTY,
                                                 v_refContainerNO,
                                                 curOutstockInfo.Owner_No,
                                                 curOutstockInfo.Divide_Id,
                                                 strOutstock_ID,
                                                 strInstock_ID,
                                                 '13',
                                                 strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --更新库存
      PKOBJ_STOCK.proc_OM_Receipt_WriteContent(strEnterPriseNo,
                                               strWarehose_No,
                                               curOutstockInfo.s_Cell_Id,
                                               curOutstockInfo.s_Cell_No,
                                               curOutstockInfo.d_Cell_Id,
                                               curOutstockInfo.d_Cell_No,
                                               v_RealQTY,
                                               curOutstockInfo.Article_Qty,
                                               strOutstock_No,
                                               '1',
                                               strOutstock_ID,
                                               strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      PKOBJ_LABEL.P_Updt_OutStock_Label(strEnterPriseNo,
                                        strWarehose_No,
                                        curOutstockInfo.Owner_No,
                                        strOutstock_No,
                                        strS_Label_No,
                                        v_RealQTY,
                                        curOutstockInfo.d_Cell_No,
                                        curOutstockInfo.divide_id,
                                        strOutstock_ID,
                                        strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --全部回单
      v_ExpTraceStatus := COdataExpStatus.ExpTracALLReceipt;

      select count(1)
        into v_ExpTraceStatusCount
        from odata_outstock_d d
       where d.warehouse_no = strWarehose_No
         and d.enterprise_no = strEnterPriseNo
         and d.exp_type = curOutstockInfo.Exp_Type
         and d.exp_no = curOutstockInfo.Exp_No
         and d.status < '13';

      if v_ExpTraceStatusCount > 0 then
        v_ExpTraceStatus := COdataExpStatus.ExpTracPartReceipt; --部分回单
      else
        select count(1)
          into v_ExpTraceStatusCount
          from odata_outstock_direct d
         where d.warehouse_no = strWarehose_No
           and d.enterprise_no = strEnterPriseNo
           and d.exp_type = curOutstockInfo.Exp_Type
           and d.exp_no = curOutstockInfo.Exp_No
           and d.status < '13';

        if v_ExpTraceStatusCount > 0 then
          v_ExpTraceStatus := COdataExpStatus.ExpTracPartReceipt; --部分回单
        end if;
      end if;

      --单据状态跟踪
      PKOBJ_ODISPATCH.P_Insert_Odata_Exp_Trace(strEnterPriseNo,
                                               strWarehose_No,
                                               curOutstockInfo.Exp_No,
                                               v_ExpTraceStatus,
                                               strOutstock_ID,
                                               strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      /*--如果是摘果则需要转移到目的标签
      if curOutstockInfo.Pick_Type = cPickType.Picking then
        --将库存从储位转移到目的标签
        PKOBJ_STOCK.proc_OM_MoveContent_ByContenNo(strEnterPriseNo,
                                                   strWarehose_No,
                                                   strOutstock_No,
                                                   curOutstockInfo.divide_id,
                                                   1,
                                                   strOutstock_ID,
                                                   strOutMsg);
        if substr(strOutMsg, 1, 1) = 'N' then
          return;
        end if;
      end if;*/

      --更新分播明细
      update ODATA_DIVIDE_D ODD
         set odd.article_qty   = v_RealQTY,
             odd.outstock_date = sysdate
       where warehouse_no = strWarehose_No
         and enterprise_no = strEnterPriseNo
         and OWNER_NO = curOutstockInfo.Owner_No
         and ODD.SOURCE_NO = strOutstock_No
         and odd.divide_id = curOutstockInfo.Divide_Id;

      if v_Indus = '2' then
        --电商
        v_D_Label_No := curOutstockInfo.Shipper_Deliver_No; --面单号
      else
        v_D_Label_No := strD_Label_No;
      end if;

      --分播回单
      PKLG_ODATA_DIVIDE.p_Save_Odata_divide(strEnterPriseNo,
                                            strWarehose_No,
                                            curOutstockInfo.Owner_No,
                                            strDivide_No,
                                            curOutstockInfo.Article_No,
                                            v_D_Label_No,
                                            v_RealQTY,
                                            v_RealQTY,
                                            strUserID,
                                            curOutstockInfo.Batch_No,
                                            strQuality,
                                            dtProduceDate,
                                            dtExpireDate,
                                            strLotNo,
                                            strRSV_BATCH1,
                                            strRSV_BATCH2,
                                            strRSV_BATCH3,
                                            strRSV_BATCH4,
                                            strRSV_BATCH5,
                                            strRSV_BATCH6,
                                            strRSV_BATCH7,
                                            strRSV_BATCH8,
                                            curOutstockInfo.d_cell_no,
                                            v_refContainerNO,
                                            curOutstockInfo.Cust_No,
                                            curOutstockInfo.Deliver_Obj,
                                            strUserID,
                                            '2',
                                            'B',
                                            strOutMsg);
      if substr(strOutMsg, 1, 1) = 'N' then
        return;
      end if;

    end loop;

    if v_Count = 0 then
      strOutMsg := 'N|[E22512]';
      return;
    end if;

    --触发补货指示
    pkobj_odata.P_O_CheckStatusCanOutstock(strEnterPriseNo,
                                           strWarehose_No,
                                           v_strOwnerNo,
                                           strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    --整单确认
    P_ComfireOutstock(strEnterPriseNo,
                      strWarehose_No,
                      strOutstock_No,
                      strUserID,
                      strOutMsg);

    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_Outstock_PickDivide;

  /**********************************************************************************************8
  luozhiling
  20140702
  功能说明：拣货回单对于标签的处理
  ***********************************************************************************************/
  procedure P_SavePickLabel(strEnterPriseNo in odata_outstock_m.enterprise_no%type, --企业号
                            strWarehose_No  in odata_outstock_m.warehouse_no%type, --仓别
                            strWaveNo       in odata_outstock_m.wave_no%type,
                            strBatchNo      in odata_outstock_m.batch_no%type,
                            strOutstock_No  in odata_outstock_m.outstock_no%type, --下架单号
                            strFixLabel_No  in odata_outstock_d.label_no%type, --标签号码
                            strDock_No      in odata_outstock_m.dock_no%type, --工作站
                            strUserID       in odata_outstock_m.rgst_name%type, --拣货人
                            strOutMsg       out varchar2) is
    v_strPickType           odata_outstock_m.pick_type%type := 'N';
    v_strWaveNo             odata_outstock_d.wave_no%type := 'N';
    v_refContainerNO        stock_label_m.container_no%type := 'N';
    v_Count                 integer := 0;
    v_strOwnerNo            bdef_defowner.owner_no%type;
    v_strTaskType           odata_outstock_m.task_type%type;
    v_strSourceType         odata_outstock_m.source_type%type;
    v_strExpType            odata_outstock_d.exp_type%type;
    v_strWorkFlowStrategy   odata_locate_batch.workflow_strategy_id%type;
    v_strBWorkFlowFlag      wms_outorder_flow_m.b_work_flow_flag%type; --摘果拣货是否调用工作流0:不调用；1：调用
    v_strOperateType        odata_outstock_m.operate_type%type;
    v_strPickStrategy       odata_locate_batch.pick_strategy_id%type;
    v_strAutoGetDivideFlag  wms_outpick_strategy.auto_getdivide_flag%type;
    v_strAutoSaveDivideFlag wms_outpick_strategy.auto_dividesave_flag%type; --是否需要自动分播回答0：不需要；1：自动
    v_strCWorkFlowFlag      wms_outorder_flow_m.b_work_flow_flag%type; --箱型摘果是否需要调用工作流0：不调用；1：调用
  begin
    strOutMsg := 'Y|[成功]';

    select count(1)
      into v_Count
      from stock_label_m slm,stock_label_d sld
     where slm.enterprise_no=sld.enterprise_no
     and slm.warehouse_no=sld.warehouse_no
     and slm.container_no=sld.container_no
     and slm.enterprise_no = strEnterPriseNo
       and slm.label_no = strFixLabel_No
       and slm.warehouse_no = strWarehose_No
       and sld.status = clabelstatus.PICK_HAND_OUT;

    if v_Count = 0 then

      --更新标签头档状态
      update stock_label_m slm set slm.status=clabelstatus.PICK_END,
            slm.updt_name=strUserID,slm.updt_date=sysdate
            where slm.enterprise_no = strEnterPriseNo
             and slm.label_no = strFixLabel_No
             and slm.warehouse_no = strWarehose_No
             and slm.status=clabelstatus.PICK_HAND_OUT;
      --此标签拣货回单完成
      select container_no
        into v_refContainerNO
        from stock_label_m slm
       where slm.enterprise_no = strEnterPriseNo
         and slm.label_no = strFixLabel_No
         and slm.warehouse_no = strWarehose_No;

      select distinct m.pick_type,
                      d.wave_no,
                      m.task_type,
                      m.source_type,
                      d.exp_type,
                      m.owner_no,
                      m.operate_type
        into v_strPickType,
             v_strWaveNo,
             v_strTaskType,
             v_strSourceType,
             v_strExpType,
             v_strOwnerNo,
             v_strOperateType
        from odata_outstock_m m, odata_outstock_d d
       where m.enterprise_no = d.enterprise_no
         and m.enterprise_no = strEnterPriseNo
         and m.warehouse_no = d.warehouse_no
         and m.outstock_no = d.outstock_no
         and m.warehouse_no = strWarehose_No
         and m.outstock_no = strOutstock_No
         and m.status < '13';

      if sql%rowcount <= 0 then
        return;
      end if;

      --读取此出货单对应的缺量处理方式
      begin
        select t.workflow_strategy_id, t.pick_strategy_id
          into v_strWorkFlowStrategy, v_strPickStrategy
          from odata_locate_batch t
         where t.enterprise_no = strEnterPriseNo
           and t.warehouse_no = strWarehose_No
           and t.wave_no = strWaveNo
           and t.batch_no = strBatchNo;
      exception
        when no_data_found then
          strOutMsg := 'N|[读取不到对应的配置信息]';
          return;
      end;

      --
      begin
        select b_work_flow_flag, c_work_flow_flag
          into v_strBWorkFlowFlag, v_strCWorkFlowFlag
          from wms_outorder_flow_m t
         where t.workflow_strategy_id = v_strWorkFlowStrategy;
      exception
        when no_data_found then
          strOutMsg := 'N|[读取不到对应出货单别的配置信息]';
          return;
      end;

      if v_strPickType = '0' then
        --摘果标签
        if (v_strOperateType = 'B' and v_strBWorkFlowFlag = '1') or
           (v_strOperateType <> 'B' and v_strCWorkFlowFlag = '1') then

          --调工作流
          PKOBJ_HB.p_OM_OutWorkflow(strEnterPriseNo,
                                    strWarehose_No,
                                    v_strOwnerNo,
                                    v_strExpType,
                                    v_refContainerNO,
                                    strUserID,
                                    strDock_No,
                                    strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        end if;

        if v_strOperateType = 'B' then
          --若物流箱标签，写标签的箱号
          update stock_label_m t
             set t.seq_value = 1
           where t.enterprise_no = strEnterPriseNo
             and t.label_no = strFixLabel_No
             and t.warehouse_no = strWarehose_No;
        end if;
      end if;

      --如果是分播则写分播指示
      if v_strPickType = cPickType.BroadCase and
         v_strTaskType <> CONST_REPORTID.PrintSerialLabel then
        --写分播指示表
        PKOBJ_ODATA_DIVIDE.P_Insert_Odata_Divide_Direct(strEnterPriseNo,
                                                        strWarehose_No,
                                                        strOutstock_No,
                                                        v_refContainerNO,
                                                        strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;

        --
        begin
          select t.auto_getdivide_flag, t.auto_dividesave_flag
            into v_strAutoGetDivideFlag, v_strAutoSaveDivideFlag
            from wms_outpick_strategy t
           where t.enterprise_no = strEnterPriseNo
             and t.pick_strategy_id = v_strPickStrategy;
        exception
          when no_data_found then
            strOutMsg := 'N|[读取不到拣货策略配置]';
            return;
        end;

        if v_strAutoGetDivideFlag = '1' then
          PKLG_ODATA_DIVIDE.P_OutStock_Divide(strEnterPriseNo,
                                              strWarehose_No,
                                              v_strOwnerNo,
                                              strDock_No,
                                              strOutstock_No,
                                              v_refContainerNO,
                                              strUserID,
                                              strUserID,
                                              '0',
                                              strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;
        end if;
        --获取分播单号

        if v_strAutoSaveDivideFlag = '1' then
          --自动回分播单
          for getDivideNo in (select distinct t.divide_no
                                from odata_divide_d t
                               where t.enterprise_no = strEnterPriseNo
                                 and t.warehouse_no = strWarehose_No
                                 and t.source_no = strOutstock_No
                                 and t.s_container_no = v_refContainerNO
                                 and t.status = '10') loop
            PKLG_ODATA_DIVIDE.p_AllSaveDivide(strEnterPriseNo,
                                              strWarehose_No,
                                              v_strOwnerNo,
                                              getDivideNo.divide_no,
                                              strUserID,
                                              strOutMsg);
            if substr(strOutMsg, 1, 1) <> 'Y' then
              return;
            end if;
          end loop;
        end if;

      end if;
    else
      return;
    end if;

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_SavePickLabel;
  /**********************************************************************************************8
  luozhiling
  20150702
  功能说明：拣货回单整单确认：
            1、更新波次管理表；
            2、更新标签头档状态；
            3、转历史
  ***********************************************************************************************/
  procedure P_ComfireOutstock(strEnterPriseNo in odata_outstock_m.enterprise_no%type, --企业号
                              strWarehose_No  in odata_outstock_m.warehouse_no%type, --仓别
                              strOutstock_No  in odata_outstock_m.outstock_no%type, --下架单号
                              strUserID       in odata_outstock_m.rgst_name%type, --回单人
                              strOutMsg       out varchar2) is
    v_strWaveNo  odata_outstock_m.wave_no%type;
    v_strBatchNo odata_outstock_m.batch_no%type;
    v_Count      integer := 0;

  begin
    strOutMsg := 'N|[P_ComfireOutstock]';

    --获取波次号
    begin
      select wave_no, batch_no
        into v_strWaveNo, v_strBatchNo
        from odata_outstock_m ood
       where ood.enterprise_no = strEnterPriseNo
         and ood.warehouse_no = strWarehose_No
         and ood.outstock_no = strOutstock_No;
    exception
      when no_data_found then
        strOutMsg := 'N|[P_ComfireOutstock]';
        return;
    end;

    --要检查下这个波次是不是全部都拣货完成了，如果完成了，要更新odata_wave_trace表的状态为拣货完成
    select count(1)
      into v_Count
      from odata_outstock_d d
     where d.enterprise_no = strEnterPriseNo
       and d.warehouse_no = strWarehose_No
       and d.status in ('10', '11', '12')
       and d.wave_no = v_strWaveNo;

    if v_count = 0 then
      --检查是否都已发单
      select count(1)
        into v_Count
        from odata_outstock_direct d
       where d.enterprise_no = strEnterPriseNo
         and d.warehouse_no = strWarehose_No
         and d.status in ('10', '11', '12')
         and d.wave_no = v_strWaveNo;

      if v_Count = 0 then
        update odata_wave_trace owt
           set owt.status = '13'
         where owt.enterprise_no = strEnterPriseNo
           and owt.wave_no = v_strWaveNo
           and owt.warehouse_no = strWarehose_No
           and owt.status = '11';
      end if;
    end if;

    select count(1)
      into v_Count
      from odata_outstock_d d
     where d.enterprise_no = strEnterPriseNo
       and d.warehouse_no = strWarehose_No
       and d.status in ('10', '11', '12')
       and d.outstock_no = strOutstock_No
       and d.wave_no = v_strWaveNo;

    if v_Count = 0 then

      --更新下架单头
      PKOBJ_ODATA_LICH.P_Update_Odata_OutStock_M(strEnterPriseNo,
                                                 strWarehose_No,
                                                 strOutstock_No,
                                                 strUserID,
                                                 strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      P_SaveOutstockDiff(strEnterPriseNo,
                         strWarehose_No,
                         v_strWaveNo,
                         v_strBatchNo,
                         strOutstock_No,
                         strUserID,
                         strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --转历史
      PKOBJ_ODATA.P_O_UpdateOmOutStockHistory(strEnterPriseNo,
                                              strWarehose_No,
                                              strOutstock_No,
                                              strUserID,
                                              '0',
                                              strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
    end if;

    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_ComfireOutstock;

  /*************************************************************************************************
  功能说明：1、整单回单
             适用于对于整下架单的所有标签进行无差异回单
  ************************************************************************************************/
  procedure p_Save_all_outstock(strEnterprise_No in odata_outstock_m.enterprise_no%type, --仓别
                                strWarehose_No   in odata_outstock_m.warehouse_no%type, --仓别
                                strOutstock_No   in odata_outstock_m.outstock_no%type, --下架单号
                                strUserID        in odata_outstock_m.rgst_name%type, --回单人
                                strOutstock_ID   in odata_outstock_d.outstock_name%type, --下架人
                                strInstock_ID    in odata_outstock_d.instock_name%type, --上架人
                                strOutMsg        out varchar2) is
    v_strOwnerNo bdef_defowner.owner_no%type;
    v_strWaveNo  odata_outstock_m.wave_no%type;
    v_strBatchNo odata_outstock_m.batch_no%type;
  begin
    strOutMsg := 'N|[p_Save_all_outstock]';

    update odata_outstock_m t
       set t.status = status
     where t.enterprise_no = strEnterprise_No
       and t.warehouse_no = strWarehose_No
       and t.outstock_no = strOutstock_No
       and t.status = '10';

    if sql%notfound then
      strOutMsg := 'N|[找不到对应的下架单]';
      return;
    end if;

    select wave_no, batch_no
      into v_strWaveNo, v_strBatchNo
      from odata_outstock_m m
     where m.enterprise_no = strEnterprise_No
       and m.warehouse_no = strWarehose_No
       and m.outstock_no = strOutstock_No;

    --获取货主

    select owner_no
      into v_strOwnerNo
      from odata_outstock_d
     where enterprise_no = strEnterprise_No
       and warehouse_no = strWarehose_No
       and outstock_no = strOutstock_No
       and rownum = 1;

    --回单时间限制
    PKOBJ_ODATA.P_O_check_TimeLimit(strEnterprise_No,
                                    strWarehose_No,
                                    strOutstock_No,
                                    v_strOwnerNo,
                                    strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    --获取标签号
    for GetLabelNo in (select *
                         from stock_label_m slm
                        where slm.enterprise_no = strEnterprise_No
                          and slm.warehouse_no = strWarehose_No
                          and slm.source_no = strOutstock_No
                          and slm.status = '50'
                        order by slm.label_no) loop

      p_Save_Labelall_outstock(strEnterprise_No,
                               strWarehose_No,
                               strOutstock_No,
                               GetLabelNo.label_no,
                               strUserID,
                               strOutstock_ID,
                               strInstock_ID,
                               strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

      --处理标签数据

      P_SavePickLabel(strEnterprise_No,
                      strWarehose_No,
                      v_strWaveNo,
                      v_strBatchNo,
                      strOutstock_No,
                      GetLabelNo.label_no,
                      'N',
                      strUserID,
                      strOutMsg);

      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;
    end loop;

    --触发补货指示
    pkobj_odata.P_O_CheckStatusCanOutstock(strEnterprise_No,
                                           strWarehose_No,
                                           v_strOwnerNo,
                                           strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    --整单确认
    P_ComfireOutstock(strEnterprise_No,
                      strWarehose_No,
                      strOutstock_No,
                      strUserID,
                      strOutMsg);

    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    strOutMsg := 'Y|[]';

  end p_Save_all_outstock;

  /*************************************************************************************************
  功能说明：1、整标签回单
             适用于对于某下架单上的某一标签进行无差异回单
  ************************************************************************************************/
  procedure p_Save_Labelall_outstock(strEnterprise_No in odata_outstock_m.enterprise_no%type, --仓别
                                     strWarehose_No   in odata_outstock_m.warehouse_no%type, --仓别
                                     strOutstock_No   in odata_outstock_m.outstock_no%type, --下架单号
                                     strLabelNo       in stock_label_m.label_no%type,
                                     strUserID        in odata_outstock_m.rgst_name%type, --回单人
                                     strOutstock_ID   in odata_outstock_d.outstock_name%type, --下架人
                                     strInstock_ID    in odata_outstock_d.instock_name%type, --上架人
                                     strOutMsg        out varchar2) is

  begin
    strOutMsg := 'N|[p_Save_Labelall_outstock]';

    --获取标签号
    for GetLabelNo in (select sld.article_no,
                              sld.packing_qty,
                              ood.s_cell_no,
                              sai.quality,
                              sai.produce_date,
                              sai.expire_date,
                              sai.lot_no,
                              sai.rsv_batch1,
                              sai.rsv_batch2,
                              sai.rsv_batch3,
                              sai.rsv_batch4,
                              sai.rsv_batch5,
                              sai.rsv_batch6,
                              sai.rsv_batch7,
                              sai.rsv_batch8,
                              sum(sld.qty) qty
                         from stock_label_m      slm,
                              stock_label_d      sld,
                              stock_article_info sai,
                              odata_outstock_d   ood
                        where slm.enterprise_no = sld.enterprise_no
                          and slm.warehouse_no = sld.warehouse_no
                          and slm.container_no = sld.container_no
                          and sld.article_no = sai.article_no
                          and slm.enterprise_no = ood.enterprise_no
                          and slm.warehouse_no = ood.warehouse_no
                          and slm.source_no = ood.outstock_no
                          and sld.divide_id = ood.divide_id
                          and sld.article_id = sai.article_id
                          and slm.enterprise_no = strEnterprise_No
                          and slm.warehouse_no = strWarehose_No
                          and slm.source_no = strOutstock_No
                          and slm.label_no = strLabelNo
                          and slm.status = '50'
                          and ood.status = '10'
                        group by sld.article_no,
                                 sld.packing_qty,
                                 ood.s_cell_no,
                                 sai.quality,
                                 sai.produce_date,
                                 sai.expire_date,
                                 sai.lot_no,
                                 sai.rsv_batch1,
                                 sai.rsv_batch2,
                                 sai.rsv_batch3,
                                 sai.rsv_batch4,
                                 sai.rsv_batch5,
                                 sai.rsv_batch6,
                                 sai.rsv_batch7,
                                 sai.rsv_batch8) loop

      --调用回单过程
      P_SerialLabel_Save(strEnterprise_No,
                         strWarehose_No,
                         strOutstock_No,
                         strLabelNo,
                         GetLabelNo.article_no,
                         GetLabelNo.packing_qty,
                         GetLabelNo.s_cell_no,
                         GetLabelNo.qty,
                         GetLabelNo.quality,
                         GetLabelNo.produce_date,
                         GetLabelNo.expire_date,
                         GetLabelNo.lot_no,
                         GetLabelNo.rsv_batch1,
                         GetLabelNo.rsv_batch2,
                         GetLabelNo.rsv_batch3,
                         GetLabelNo.rsv_batch4,
                         GetLabelNo.rsv_batch5,
                         GetLabelNo.rsv_batch6,
                         GetLabelNo.rsv_batch7,
                         GetLabelNo.rsv_batch8,
                         strUserID,
                         strOutstock_ID,
                         strInstock_ID,
                         strOutMsg);
      if substr(strOutMsg, 1, 1) <> 'Y' then
        return;
      end if;

    end loop;

    strOutMsg := 'Y|[]';

  end p_Save_Labelall_outstock;

  /*************************************************************************************************
  功能说明：1、整单标签0回单
             适用于对于下架单流水箱标签进行0回单
  ************************************************************************************************/
  procedure P_SaveLabelCancelOutStock(strEnterPriseNo in odata_outstock_m.enterprise_no%type, --企业号
                                      strWarehose_No  in odata_outstock_m.warehouse_no%type, --仓别
                                      strOutstock_No  in odata_outstock_m.outstock_no%type, --下架单号
                                      strDock_No      in odata_outstock_m.dock_no%type, --工作站
                                      strUserID       in odata_outstock_m.rgst_name%type, --拣货人
                                      strOutMsg       out varchar2) is
    v_strOwnerNo bdef_defowner.owner_no%type;
    v_iCount     integer := 0;
  begin
    strOutMsg := 'N|[P_SaveLabelCancelOutStock]';

    update odata_outstock_m t
       set t.status = status
     where t.enterprise_no = strEnterPriseNo
       and t.warehouse_no = strWarehose_No
       and t.outstock_no = strOutstock_No
       and t.status = '10';

    if sql%notfound then
      strOutMsg := 'N|[找不到对应的下架单]';
      return;
    end if;

    --获取标签号
    for GetLabelNo in (select sld.owner_no,
                              slm.label_no,
                              slm.owner_cell_no,
                              sld.article_no,
                              sld.article_id,
                              sld.divide_id,
                              sum(sld.qty)
                         from stock_label_m slm, stock_label_d sld
                        where slm.enterprise_no = sld.enterprise_no
                          and slm.warehouse_no = sld.warehouse_no
                          and slm.container_no = sld.container_no
                          and slm.enterprise_no = strEnterPriseNo
                          and slm.warehouse_no = strWarehose_No
                          and slm.source_no = strOutstock_No
                          and slm.status = '50'
                        group by sld.owner_no,
                                 slm.label_no,
                                 slm.owner_cell_no,
                                 sld.article_no,
                                 sld.article_id,
                                 sld.divide_id
                        order by slm.label_no,
                                 slm.owner_cell_no,
                                 sld.article_no,
                                 sld.article_id) loop
      v_iCount     := v_iCount + 1;
      v_strOwnerNo := GetLabelNo.owner_no;
      --获取标签号
      for GetLabelNoItem in (select sld.article_no,
                                    sld.packing_qty,
                                    ood.s_cell_no,
                                    sai.quality,
                                    sai.produce_date,
                                    sai.expire_date,
                                    sai.lot_no,
                                    sai.rsv_batch1,
                                    sai.rsv_batch2,
                                    sai.rsv_batch3,
                                    sai.rsv_batch4,
                                    sai.rsv_batch5,
                                    sai.rsv_batch6,
                                    sai.rsv_batch7,
                                    sai.rsv_batch8,
                                    sum(sld.qty) qty
                               from stock_label_m      slm,
                                    stock_label_d      sld,
                                    stock_article_info sai,
                                    odata_outstock_d   ood
                              where slm.enterprise_no = sld.enterprise_no
                                and slm.warehouse_no = sld.warehouse_no
                                and slm.container_no = sld.container_no
                                and sld.article_no = sai.article_no
                                and slm.enterprise_no = ood.enterprise_no
                                and slm.warehouse_no = ood.warehouse_no
                                and slm.source_no = ood.outstock_no
                                and sld.divide_id = ood.divide_id
                                and sld.article_id = sai.article_id
                                and slm.enterprise_no = strEnterPriseNo
                                and slm.warehouse_no = strWarehose_No
                                and slm.source_no = strOutstock_No
                                and slm.label_no = GetLabelNo.label_no
                                and slm.status = '50'
                                and ood.status = '10'
                                and slm.owner_cell_no =
                                    GetLabelNo.owner_cell_no
                                and sld.article_no = GetLabelNo.article_no
                                and sld.article_id = GetLabelNo.article_id
                                and sld.divide_id = GetLabelNo.divide_id
                              group by sld.article_no,
                                       sld.packing_qty,
                                       ood.s_cell_no,
                                       sai.quality,
                                       sai.produce_date,
                                       sai.expire_date,
                                       sai.lot_no,
                                       sai.rsv_batch1,
                                       sai.rsv_batch2,
                                       sai.rsv_batch3,
                                       sai.rsv_batch4,
                                       sai.rsv_batch5,
                                       sai.rsv_batch6,
                                       sai.rsv_batch7,
                                       sai.rsv_batch8) loop

        --调用回单过程
        P_SerialLabelCancel(strEnterPriseNo,
                            strWarehose_No,
                            strOutstock_No,
                            GetLabelNo.label_no,
                            GetLabelNoItem.article_no,
                            GetLabelNoItem.packing_qty,
                            GetLabelNoItem.s_cell_no,
                            0,
                            GetLabelNoItem.quality,
                            GetLabelNoItem.produce_date,
                            GetLabelNoItem.expire_date,
                            GetLabelNoItem.lot_no,
                            GetLabelNoItem.rsv_batch1,
                            GetLabelNoItem.rsv_batch2,
                            GetLabelNoItem.rsv_batch3,
                            GetLabelNoItem.rsv_batch4,
                            GetLabelNoItem.rsv_batch5,
                            GetLabelNoItem.rsv_batch6,
                            GetLabelNoItem.rsv_batch7,
                            GetLabelNoItem.rsv_batch8,
                            strUserID,
                            strUserID,
                            strUserID,
                            strOutMsg);
        if substr(strOutMsg, 1, 1) <> 'Y' then
          return;
        end if;
      end loop;

      update odata_outstock_d ood
         set ood.status = '13'
       where ood.enterprise_no = strEnterPriseNo
         and ood.warehouse_no = strWarehose_No
         and ood.outstock_no = strOutstock_No
         and ood.divide_id = GetLabelNo.divide_id
         and not exists (select 'x'
                from stock_label_d sld
               where sld.enterprise_no = ood.enterprise_no
                 and sld.warehouse_no = ood.warehouse_no
                 and sld.source_no = ood.outstock_no
                 and sld.divide_id = ood.divide_id
                 and sld.status = '50');

    end loop;

    if v_iCount = 0 then
      strOutMsg := 'N|[找不到对应的下架信息]';
      return;
    end if;
    --触发补货指示
    pkobj_odata.P_O_CheckStatusCanOutstock(strEnterPriseNo,
                                           strWarehose_No,
                                           v_strOwnerNo,
                                           strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    --整单确认
    P_ComfireOutstock(strEnterPriseNo,
                      strWarehose_No,
                      strOutstock_No,
                      strUserID,
                      strOutMsg);

    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;

    strOutMsg := 'Y|[]';

  end P_SaveLabelCancelOutStock;

  /*************************************************************************************************
  功能说明：RF索单 Add by sunl 20160526
           1. 校验工作站是否有效
           2. 校验员工是否有效
           3. 校验员工索取任务是否已到上限
           4. 写打印任务
           5. 更新打印状态，索单状态。
  ************************************************************************************************/
  PROCEDURE P_CLAIMORDER(STRENTERPRISENO IN ODATA_OUTSTOCK_M.ENTERPRISE_NO%TYPE, --企业号
                         STRWAREHOSE_NO  IN ODATA_OUTSTOCK_M.WAREHOUSE_NO%TYPE, --仓别
                         STRUSERID       IN ODATA_OUTSTOCK_M.RGST_NAME%TYPE, --索单人
                         STROPERATE_TYPE IN ODATA_OUTSTOCK_M.OPERATE_TYPE%TYPE, --类型 B OR C
                         STRDOCK_NO      IN ODATA_OUTSTOCK_M.DOCK_NO%TYPE, --工作站
                         STROUTMSG       OUT VARCHAR2,
                         STROUTSTOCK_NO  OUT ODATA_OUTSTOCK_M.OUTSTOCK_NO%TYPE --下架单号
                         ) IS
    V_ICOUNT     INTEGER := 0;
    V_CLAIMCOUNT INTEGER := 0; --用户索单上限 取配置返回值
    V_NOWCOUNT   INTEGER := 0; --用户当前索单任务数
    V_Outsdefine VARCHAR2(200) := ''; --字符值 取配置返回值
  BEGIN
    STROUTMSG := 'N|[P_CLAIMORDER]';

    --校验工作站是否有效
    BEGIN
      SELECT COUNT(0)
        INTO V_ICOUNT
        FROM PNTSET_PRINTER_WORKSTATION C
       WHERE C.WAREHOUSE_NO = STRWAREHOSE_NO
         AND C.ENTERPRISE_NO = STRENTERPRISENO
         AND C.WORKSTATION_NO = STRDOCK_NO;
      IF V_ICOUNT = 0 THEN
        STROUTMSG := 'N|[工作站' || STRDOCK_NO || '无效或不存在！]';
        RETURN;
      END IF;
      V_ICOUNT := 0;
    END;

    /*--校验工作站是否存在未被获取的任务
    BEGIN
      SELECT COUNT(0)
        INTO V_ICOUNT
        FROM ODATA_OUTSTOCK_M M
       WHERE M.WAREHOUSE_NO = STRWAREHOSE_NO
         AND M.ENTERPRISE_NO = STRENTERPRISENO
         AND M.DOCK_NO = STRDOCK_NO
         AND M.OPERATE_TYPE = STROPERATE_TYPE
         AND M.HANDOUT_NAME IS NULL
         AND M.STATUS = '10'
         AND M.PRINT_STATUS = '0';
      IF V_ICOUNT = 0 THEN
        STROUTMSG := 'N|[工作站' || STRDOCK_NO || '暂无任务可以索取！]';
        RETURN;
      END IF;
      V_ICOUNT := 0;
    END;*/

    --校验员工是否有效
    BEGIN
      SELECT COUNT(0)
        INTO V_ICOUNT
        FROM BDEF_DEFWORKER W
       WHERE W.WAREHOUSE_NO = STRWAREHOSE_NO
         AND W.ENTERPRISE_NO = STRENTERPRISENO
         AND W.WORKER_NO = STRUSERID
         AND W.STATUS = '1';
      IF V_ICOUNT = 0 THEN
        STROUTMSG := 'N|[员工号' || STRUSERID || '无效或不存在！]';
        RETURN;
      END IF;
      V_ICOUNT := 0;
    END;

    --校验员工索取任务是否已到上限
    BEGIN
      --1. 获取用户索单上限
      BEGIN
        PKLG_WMS_BASE.p_GetBasePara(STRENTERPRISENO,
                                    STRWAREHOSE_NO,
                                    '',
                                    'TaskCount',
                                    'O',
                                    'O_TASK',
                                    V_Outsdefine,
                                    V_CLAIMCOUNT,
                                    STROUTMSG);
        IF INSTR(STROUTMSG, 'N', 1, 1) = 1 THEN
          RETURN;
        END IF;
      END;

      --2. 获取当前用户已获取的任务数
      SELECT COUNT(0)
        INTO V_NOWCOUNT
        FROM ODATA_OUTSTOCK_M M
       WHERE M.WAREHOUSE_NO = STRWAREHOSE_NO
         AND M.ENTERPRISE_NO = STRENTERPRISENO
         AND M.HANDOUT_NAME = STRUSERID
            --AND M.DOCK_NO = STRDOCK_NO
         AND M.STATUS = '10';

      IF (V_NOWCOUNT >= V_CLAIMCOUNT) THEN
        STROUTMSG := 'N|[员工号' || STRUSERID || '已索取了' || V_NOWCOUNT ||
                     '个任务，请完成任务后重试！]';
        RETURN;
      END IF;
    END;
    --获取一个下架单号 STROUTSTOCK_NO
    BEGIN
      SELECT M.OUTSTOCK_NO
        INTO STROUTSTOCK_NO
        FROM ODATA_OUTSTOCK_M M
       WHERE /*M.DOCK_NO = STRDOCK_NO
                                       AND*/
       M.WAREHOUSE_NO = STRWAREHOSE_NO
       AND M.ENTERPRISE_NO = STRENTERPRISENO
       AND M.OPERATE_TYPE = STROPERATE_TYPE
       AND M.HANDOUT_NAME IS NULL
       AND M.STATUS = '10'
       AND m.print_status = '0'
       AND rownum = 1
       ORDER BY M.OUTSTOCK_NO ASC;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        STROUTMSG := 'N|[找不到有效的拣货任务]';
        RETURN;
    END;

    --锁任务
    BEGIN
      UPDATE ODATA_OUTSTOCK_M M
         SET M.PRINT_STATUS = M.PRINT_STATUS
       WHERE /*M.DOCK_NO = STRDOCK_NO
                                       AND*/
       M.OPERATE_TYPE = STROPERATE_TYPE
       AND M.STATUS = '10'
       AND M.OUTSTOCK_NO = STROUTSTOCK_NO;

      IF SQL%NOTFOUND THEN
        STROUTMSG := 'N|[找不到有效的拣货任务]';
        RETURN;
      END IF;
    END;

    --写打印任务
    BEGIN
      PKLG_ODATA.P_WritePrintJob2(STRENTERPRISENO,
                                  STRWAREHOSE_NO,
                                  STROUTSTOCK_NO,
                                  CONST_REPORTID.Print_MD, --STRDOCK_NO,
                                  STRUSERID,
                                  STRDOCK_NO,
                                  STROUTMSG);
      IF INSTR(STROUTMSG, 'N', 1, 1) = 1 THEN
        RETURN;
      END IF;
    END;

    --更新打印状态，索单状态
    BEGIN
      UPDATE ODATA_OUTSTOCK_M M
         SET M.PRINT_STATUS = '1',
             M.HANDOUT_NAME = STRUSERID,
             M.HANDOUT_DATE = SYSDATE
       WHERE M.WAREHOUSE_NO = STRWAREHOSE_NO
         AND M.ENTERPRISE_NO = STRENTERPRISENO
            --AND M.DOCK_NO = STRDOCK_NO
         AND M.OPERATE_TYPE = STROPERATE_TYPE
         AND M.OUTSTOCK_NO = STROUTSTOCK_NO;
      IF SQL%NOTFOUND THEN
        STROUTMSG := 'N|[更新单据索单状态失败]';
        RETURN;
      END IF;
    END;

    STROUTMSG := 'Y|[]';
  END P_CLAIMORDER;

end PKLG_ODATA_LICH;

/

