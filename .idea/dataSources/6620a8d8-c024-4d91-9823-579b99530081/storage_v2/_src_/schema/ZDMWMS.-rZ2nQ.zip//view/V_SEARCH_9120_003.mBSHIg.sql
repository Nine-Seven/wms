create view V_SEARCH_9120_003 as
SELECT a.article_no, NVL(a.qty,0) KCZL,NVL(b.qty,0) PSSL,(NVL(a.qty,0)-NVL(b.qty,0))/a.qty * 100 ||'%' ZKWHL FROM (
SELECT SUM(c.qc_qty - c.out_qty + c.in_qty) / (TRUNC(to_date('20160114','YYYYMMDD')) - TRUNC(to_date('20160113','YYYYMMDD'))+1) qty,c.article_no FROM stock_content_rj c
 WHERE c.jc_date >= TRUNC( to_date('20160113','YYYYMMDD') ) AND c.jc_date <= TRUNC( to_date('20160114','YYYYMMDD') )
 GROUP BY c.article_no
 ) A,
--在库完好率（KPI3）标准值为99.8%
--在库完好率=（当前仓库存储所有SKU库存数量–期间破损SKU数量）/（当前仓库存储SKU库存数量）*100%
 ( SELECT sum(d.real_qty) qty, d.article_no FROM sodata_waste_d d ,sodata_waste_m m
 WHERE d.real_qty>0 AND m.enterprise_no = d.enterprise_no AND m.warehouse_no = d.warehouse_no AND m.waste_no = d.waste_no
 AND m.rgst_date >= TRUNC( to_date('20160113','YYYYMMDD') ) AND m.rgst_date <= TRUNC( to_date('20160114','YYYYMMDD') )
 GROUP BY d.article_no) B
 WHERE a.article_no =b.article_no(+)

/

