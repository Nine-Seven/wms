create view V_SEARCH_9102_2 as
select enterprise_no,
       warehouse_no,
       owner_no,
       instock_no,
       label_no,
       rgst_name,
       rgst_date,
       instock_name,
       instock_date,
       status,
       article_no,
       ARTICLE_NAME,
       BARCODE,
       packing_qty,
       UNIT,
       SPEC,
       cell_no,
       sum(article_qty) article_qty,
       sum(trunc(article_qty / packing_qty)) as planBox,
       sum(mod(article_qty,packing_qty)) as planDis,
       real_cell_no,
       real_label_no,
       sum(real_qty) as realQty,
       sum(trunc(real_qty / packing_qty)) as realBox,
       sum(mod(real_qty, packing_qty)) as realDis,
       produce_date,supplierInfo,wave_no
from
(select a.enterprise_no,
       a.warehouse_no,
       a.owner_no,
       a.instock_no,
       b.label_no,
       a.rgst_name,
       a.rgst_date,
       b.instock_name,
       b.instock_date,
       b.status,
       b.article_no,
       c.ARTICLE_NAME,
       c.BARCODE,
       b.packing_qty,
       c.UNIT,
       c.SPEC,
       b.cell_no,
       b.article_qty,
       b.real_cell_no,
       b.real_qty,
       to_char(d.produce_date, 'yyyy-mm-dd') as produce_date,
       b.real_label_no,'['||s.supplier_no||']'||s.supplier_name supplierInfo,b.wave_no||'-'||b.batch_no as wave_no
  from ridata_instock_m a,
  ridata_instock_d b,
  bdef_defarticle c,
  stock_article_info d,
  bdef_defsupplier s
 where a.enterprise_no = b.enterprise_no
   and a.warehouse_no = b.warehouse_no
   and a.instock_no = b.instock_no
   and a.enterprise_no = c.enterprise_no
   and b.article_no = c.article_no
   and a.enterprise_no = d.enterprise_no
   and b.article_id = d.article_id
   and b.article_no = d.article_no
   and c.enterprise_no=s.enterprise_no(+)
   and c.owner_no=s.owner_no(+)
   and c.supplier_no=s.supplier_no(+)
union all
select a.enterprise_no,
       a.warehouse_no,
       a.owner_no,
       a.instock_no,
       b.label_no,
       a.rgst_name,
       a.rgst_date,
       b.instock_name,
       b.instock_date,
       b.status,
       b.article_no,
       c.ARTICLE_NAME,
       c.BARCODE,
       b.packing_qty,
       c.UNIT,
       c.SPEC,
       b.cell_no,
       b.article_qty,
       b.real_cell_no,
       b.real_qty,
       to_char(d.produce_date, 'yyyy-mm-dd') as produce_date,
       b.real_label_no,'['||s.supplier_no||']'||s.supplier_name supplierInfo,b.wave_no||'-'||b.batch_no  as wave_no
  from ridata_instock_mhty a,
  ridata_instock_dhty b,
  bdef_defarticle c,
  stock_article_info d,
  bdef_defsupplier s
 where a.enterprise_no = b.enterprise_no
   and a.warehouse_no = b.warehouse_no
   and a.instock_no = b.instock_no
   and a.enterprise_no = c.enterprise_no
   and b.article_no = c.article_no
   and a.enterprise_no = d.enterprise_no
   and b.article_id = d.article_id
   and b.article_no = d.article_no
   and c.enterprise_no=s.enterprise_no(+)
   and c.owner_no=s.owner_no(+)
   and c.supplier_no=s.supplier_no(+))   aa
 group by enterprise_no,
       warehouse_no,
       owner_no,
       instock_no,
       label_no,
       rgst_name,
       rgst_date,
       instock_name,
       instock_date,
       status,
       article_no,
       ARTICLE_NAME,
       BARCODE,
       packing_qty,
       UNIT,
       SPEC,
       cell_no,
       real_cell_no,
       real_label_no,
       produce_date,supplierInfo,wave_no
order by instock_no,label_no, real_label_no


/

