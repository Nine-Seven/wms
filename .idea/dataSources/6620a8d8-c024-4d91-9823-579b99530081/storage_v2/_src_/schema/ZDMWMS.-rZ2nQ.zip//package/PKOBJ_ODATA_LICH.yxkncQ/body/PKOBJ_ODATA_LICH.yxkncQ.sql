create package body        PKOBJ_ODATA_LICH is
  /*****************************************************************************************
      LICH
      20140521
     功能：修改出货下架明细信息
  *****************************************************************************************/
  procedure P_Update_Odata_OutStock_D(strEnterPriseNo      in odata_outstock_d.enterprise_no%type, --企业号
                                      strWarehouse_no      in odata_outstock_d.warehouse_no%type, --仓别
                                      strOutStockNo     in odata_outstock_d.outstock_no%type, --下架单号
                                      strRealQty        in odata_outstock_d.real_qty%type,
                                      strCustContainerNo   in odata_outstock_d.d_container_no%type,
                                      strOwnerNo        in odata_outstock_d.owner_no%type,
                                      strDivideId       in odata_outstock_d.divide_id%type,
                                      strOutstockName   in odata_outstock_d.outstock_name%type, --出货员工ID
                                      strInstockName    in odata_outstock_d.instock_name%type, --出货员工ID
                                      strStatus         in odata_outstock_d.status%type, --状态
                                      strOutMsg         out varchar2) --返回值
   is
  begin
    strOutMsg := 'N|[P_Update_Odata_OutStock_D]';
    ------------------更新下架单明细信息------------------
    update
      odata_outstock_d ood
    set
      ood.outstock_name  = strOutstockName,
      ood.outstock_date  = sysdate,
      ood.instock_name = strInstockName,
      ood.instock_date = sysdate,
      ood.real_qty       = nvl(ood.real_qty,0) + strRealQty,
      ood.s_container_no= nvl(s_container_no,'N'),
      ood.d_container_no = strCustContainerNo,
      ood.status = 13
     where
       ood.warehouse_no = strWarehouse_no
       and ood.enterprise_no = strEnterPriseNo
       and ood.owner_no = strOwnerNo
       and ood.outstock_no = strOutStockNo
       and ood.divide_id = strDivideId;
/*       and ood.status < strStatus;*/
    if sql%rowcount <=0 then
      strOutMsg := 'N|[E22301]';
      return;
    end if;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_Update_Odata_OutStock_D;


  /****************************************************************************************************
     quzhihui
     2013.11.25
     功能说明：更新下架单头档
  ******************************************************************************************************/
  procedure p_Update_Odata_Outstock_M(strEnterPriseNo      in odata_outstock_d.enterprise_no%type, --企业号
                                      strWAREHOUSE_NO in odata_outstock_m.warehouse_no%type,
                                      strOutstockNo   in odata_outstock_m.outstock_no%type,
                                      strUserID       in odata_outstock_m.rgst_name%type,
                                      strOutMsg       out varchar2) is
    v_iCount integer := 0;
  begin
    strOutMsg := 'N|';
    select count(1)
      into v_iCount
      from odata_outstock_d d
     where d.warehouse_no = strWAREHOUSE_NO
       and d.enterprise_no = strEnterPriseNo
       and d.outstock_no = strOutstockNo
       and d.status = '10';

    if v_iCount > 0 then
      strOutMsg := 'Y|成功';
      return;
    end if;

    update
      odata_outstock_m m
    set
      m.status = '13',
      m.updt_name = strUserID,
      m.updt_date = sysdate
    where
      m.warehouse_no = strWAREHOUSE_NO
      and m.enterprise_no = strEnterPriseNo
      and m.outstock_no = strOutstockNo;

    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E22302]';
      return;
    end if;
    strOutMsg := 'Y|成功';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_Update_Odata_Outstock_M;

/*****************************************************************************************
     功能：下架回单 数据转历史处理
  *****************************************************************************************/
  procedure P_Update_Odata_OutStock_Hty(strEnterPriseNo      in odata_outstock_d.enterprise_no%type, --企业号
                                        v_warehouse_no      in odata_outstock_m.warehouse_no%type, --仓别
                                        strOutStockNo in odata_outstock_m.outstock_no%type, --下架单号
                                        strUserId     in odata_outstock_m.rgst_name%type, --员工ID
                                        strFlagZero   in varchar2,--拣货零回标示
                                        strOutMsg     out varchar2) --返回值
  is

    strOutStockDirect varchar2(2);--下架指示转历史标示

    strOutStockType varchar2(1); --下架类型
    strPickType varchar2(1); --拣货类型
    strTaskType varchar2(1); --发单方式
    strOperateType varchar2(1); --作业类型
  begin
    strOutMsg := 'N|[P_Update_Odata_OutStock_Hty]';
    strOutStockDirect := '0';

    select
      oom.outstock_type,
      oom.pick_type,
      oom.task_type,
      oom.operate_type
    into
      strOutStockType,
      strPickType,
      strTaskType,
      strOperateType
    from
      odata_outstock_m oom
    where
      oom.warehouse_no = v_warehouse_no
      and oom.outstock_no = strOutStockNo
      and oom.enterprise_no = strEnterPriseNo;

    if strOutStockType = '1' then
      --------------出货量补货处理
      --更新标签 并转历史
      pkOBJ_label_odata.P_O_UpdateLabelDetail(strEnterPriseNo,
                                              v_warehouse_no,
                                              strOutStockNo,
                                              strOutStockType,
                                              strUserId,
                                              'F1',
                                              strOutMsg);
      if  instr(strOutMsg,'N',1,1) = 1 then
        return;
      end if;
    end if;

    if strOutStockType = '0' or strOutStockType = '3' or strOutStockType = '4' then
      --------------出货下架、安全量补货、人工移库 被销毁的 标签处理
      pkOBJ_label_odata.P_O_UpdateLabelDetail(strEnterPriseNo,
                                              v_warehouse_no,
                                              strOutStockNo,
                                              strOutStockType,
                                              strUserId,
                                              'FF',
                                              strOutMsg);
      if  instr(strOutMsg,'N',1,1) = 1 then
        return;
      end if;
    end if;

    ---------------下架单头 转历史
    insert into odata_outstock_mHTY(
      UPDT_DATE,
      UPDT_NAME,
      RGST_DATE,
      RGST_NAME,
      PRINT_STATUS,
      HANDOUT_NAME,
      HANDIN_NAME,
      HANDOUT_DATE,
      HANDIN_DATE,
      DOCK_NO,
      PRIORITY,
      STATUS,
      TASK_TYPE,
      PICK_TYPE,
      OPERATE_TYPE,
      BATCH_NO,
      OUTSTOCK_TYPE,
      OPERATE_DATE,
      OUTSTOCK_NO,
      warehouse_no,
      SOURCE_TYPE,
      EXP_DATE,
      OWNER_NO,
      Enterprise_No,
      --huangb 20160509
      REPORT_UP_SERIAL)
    select
      UPDT_DATE,
      UPDT_NAME,
      RGST_DATE,
      RGST_NAME,
      PRINT_STATUS,
      HANDOUT_NAME,
      HANDIN_NAME,
      HANDOUT_DATE,
      HANDIN_DATE,
      DOCK_NO,
      PRIORITY,
      STATUS,
      TASK_TYPE,
      PICK_TYPE,
      OPERATE_TYPE,
      BATCH_NO,
      OUTSTOCK_TYPE,
      OPERATE_DATE,
      OUTSTOCK_NO,
      warehouse_no,
      SOURCE_TYPE,
      EXP_DATE,
      OWNER_NO,
      Enterprise_No,
      --huangb 20160509
      REPORT_UP_SERIAL
    from
      odata_outstock_m
    where
      warehouse_no = v_warehouse_no
      and OUTSTOCK_NO = strOutStockNo
      and Enterprise_No = strEnterPriseNo;
    if sql%rowcount <=0 then
      strOutMsg := 'N|[E22303]';
      return;
    end if;

    delete
    from
      odata_outstock_m
    where
      warehouse_no = v_warehouse_no
      and OUTSTOCK_NO = strOutStockNo
      and Enterprise_No = strEnterPriseNo;

    ---------------下架指示转历史
    if strOutStockType = '0' then
      if strPickType='0' or strOperateType = 'P' or strOperateType = 'C' then
        strOutStockDirect := '1';--写指示 标示
      end if;
    end if;

    if strOutStockType <> '0'   then
      strOutStockDirect := '1';--写指示 标示
    end if;
    if strFlagZero='0' then
      strOutStockDirect := '1';--写指示 标示
    end if;

    if strOutStockDirect = '1' then
      insert into odata_outstock_dIRECTHTY(
        EXP_DATE,
        TEMP_STATUS,
        UPDT_DATE,
        UPDT_NAME,
        RGST_DATE,
        RGST_NAME,
        DPS_CELL_NO,
        device_no,
        SUPP_COUNT,
        DELIVER_OBJ,
        CHECK_CHUTE_NO,
        A_SORTER_CHUTE_NO,
        PRIORITY,
        LINE_NO,
        DELIVER_AREA,
        STATUS,
        LOCATE_QTY,
        D_CELL_ID,
        D_CELL_NO,
        S_CONTAINER_NO,
        S_CELL_ID,
        S_CELL_NO,
        PACKING_QTY,
        ARTICLE_ID,
        ARTICLE_NO,
        SUB_CUST_NO,
        CUST_NO,
        EXP_NO,
        EXP_TYPE,
        WAVE_NO,
        DIRECT_SERIAL,
        BATCH_NO,
        PICK_TYPE,
        OPERATE_DATE,
        OPERATE_TYPE,
        OUTSTOCK_TYPE,
        OWNER_NO,
        warehouse_no,
        STOCK_TYPE,
        source_type,
        Enterprise_No)
      select
        dir.EXP_DATE,
        dir.TEMP_STATUS,
        dir.UPDT_DATE,
        dir.UPDT_NAME,
        dir.RGST_DATE,
        dir.RGST_NAME,
        dir.DPS_CELL_NO,
        dir.device_no,
        dir.SUPP_COUNT,
        dir.DELIVER_OBJ,
        dir.CHECK_CHUTE_NO,
        dir.A_SORTER_CHUTE_NO,
        dir.PRIORITY,
        dir.LINE_NO,
        dir.DELIVER_AREA,
        dir.STATUS,
        dir.LOCATE_QTY,
        dir.D_CELL_ID,
        dir.D_CELL_NO,
        dir.S_CONTAINER_NO,
        dir.S_CELL_ID,
        dir.S_CELL_NO,
        dir.PACKING_QTY,
        dir.ARTICLE_ID,
        dir.ARTICLE_NO,
        dir.SUB_CUST_NO,
        dir.CUST_NO,
        dir.EXP_NO,
        dir.EXP_TYPE,
        dir.WAVE_NO,
        dir.DIRECT_SERIAL,
        dir.BATCH_NO,
        dir.PICK_TYPE,
        dir.OPERATE_DATE,
        dir.OPERATE_TYPE,
        dir.OUTSTOCK_TYPE,
        dir.OWNER_NO,
        dir.warehouse_no,
        dir.STOCK_TYPE,
        dir.source_type,
        dir.Enterprise_No
      from
        odata_outstock_dIRECT dir,
        odata_outstock_d d
      where
        d.warehouse_no = v_warehouse_no
        and d.enterprise_no = strEnterPriseNo
        and d.OUTSTOCK_NO = strOutStockNo
        and d.DIVIDE_ID = dir.DIRECT_SERIAL
        and d.warehouse_no=dir.warehouse_no
        and d.enterprise_no=dir.enterprise_no;
      /*if strOutStockType <>'5' and strOutStockType <>'4' then--差异移库，即时移库，没有下架指示，不判断
        if sql%rowcount <=0 then
            strOutMsg := 'N|[写下架指示历史表失败]';
            return;
        end if;
      end if;*/
      delete
      from
        odata_outstock_dIRECT
      where
        warehouse_no = v_warehouse_no
        and enterprise_no=strEnterPriseNo
        and DIRECT_SERIAL in
               (select
                  d.DIVIDE_ID as DIRECT_SERIAL
                from
                  odata_outstock_d d
                where
                  d.warehouse_no = v_warehouse_no
                  and d.OUTSTOCK_NO = strOutStockNo
                 );
    end if;
    ---------------下架明细转历史
    insert into odata_outstock_dHTY(
      CHECK_CHUTE_NO,
      A_SORTER_CHUTE_NO,
      TRUNCK_CELL_NO,
      LINE_NO,
      STATUS,
      DELIVER_AREA,
      REAL_QTY,
      ARTICLE_QTY,
      d_CONTAINER_NO,
      D_CELL_ID,
      D_CELL_NO,
      S_CONTAINER_NO,
      S_CELL_ID,
      S_CELL_NO,
      PACKING_QTY,
      ARTICLE_ID,
      ARTICLE_NO,
      SUB_CUST_NO,
      CUST_NO,
      WAVE_NO,
      EXP_NO,
      EXP_TYPE,
      BATCH_NO,
      OPERATE_DATE,
      DIVIDE_ID,
      OUTSTOCK_NO,
      OWNER_NO,
      warehouse_no,
      PICK_DEVICE,
      EXP_DATE,
      PRIORITY,
      device_no,
      DPS_CELL_NO,
      INSTOCK_DATE,
      OUTSTOCK_DATE,
      INSTOCK_NAME,
      OUTSTOCK_NAME,
      ASSIGN_NAME,
      ADVANCE_CELL_NO,
      DELIVER_OBJ,
      ADVANCE_PICK_NAME,
      ADVANCE_PICK_DATE,
      STOCK_TYPE,
      UNBOX_FLAG，
      SUB_LABEL_NO,LABEL_NO,
      Enterprise_No)
    select
      CHECK_CHUTE_NO,
      A_SORTER_CHUTE_NO,
      TRUNCK_CELL_NO,
      LINE_NO,
      STATUS,
      DELIVER_AREA,
      REAL_QTY,
      ARTICLE_QTY,
      d_CONTAINER_NO,
      D_CELL_ID,
      D_CELL_NO,
      S_CONTAINER_NO,
      S_CELL_ID,
      S_CELL_NO,
      PACKING_QTY,
      ARTICLE_ID,
      ARTICLE_NO,
      SUB_CUST_NO,
      CUST_NO,
      wave_no,
      EXP_NO,
      EXP_TYPE,
      BATCH_NO,
      OPERATE_DATE,
      DIVIDE_ID,
      OUTSTOCK_NO,
      OWNER_NO,
      warehouse_no,
      PICK_DEVICE,
      EXP_DATE,
      PRIORITY,
      device_no,
      DPS_CELL_NO,
      INSTOCK_DATE,
      OUTSTOCK_DATE,
      INSTOCK_NAME,
      OUTSTOCK_NAME,
      ASSIGN_NAME,
      ADVANCE_CELL_NO,
      DELIVER_OBJ,
      ADVANCE_PICK_NAME,
      ADVANCE_PICK_DATE,
      STOCK_TYPE,
      UNBOX_FLAG，
      SUB_LABEL_NO,LABEL_NO,
      Enterprise_No
    from
      odata_outstock_d
    where
      warehouse_no = v_warehouse_no
      and OUTSTOCK_NO = strOutStockNo
      and Enterprise_No = strEnterPriseNo;
    if sql%rowcount <=0 then
      strOutMsg := 'N|[E22304]';
      return;
    end if;

    delete
    from
      odata_outstock_d
    where
      warehouse_no = v_warehouse_no
      and OUTSTOCK_NO = strOutStockNo
      and Enterprise_No = strEnterPriseNo;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_Update_Odata_OutStock_Hty;

 /************************************************************************************************
  功能说明：拣货差异回单时可支持重定位
  创建人：luozhiling
  创建时间：2014.12.3
************************************************************************************************/
  procedure P_O_DiffOutstock(strEnterPriseNo  in  odata_outstock_m.enterprise_no%type,
                             strWareHouseNo          in     odata_outstock_m.warehouse_no%type,
                             strOutstockNo         in     odata_outstock_m.outstock_no%type,
                             strUserID             in     bdef_defworker.worker_no%type, --系统操作人员
                             strOutMsg             out   varchar2)is

      v_nCurrQty             odata_outstock_d.real_qty%type;
      v_nRemainQty           odata_outstock_d.real_qty%type;
  begin
     strOutMsg:='N|[P_O_DiffOutstock]';



     for v_GetOutstockItem  in(select ood.*
                              from odata_outstock_d ood,odata_outstock_m oom
                              where oom.outstock_no=ood.outstock_no
                              and oom.warehouse_no=ood.warehouse_no
                              and oom.enterprise_no=ood.enterprise_no
                              and oom.warehouse_no=strWareHouseNo
                              and oom.enterprise_no=strEnterPriseNo
                              and oom.outstock_no=strOutstockNo
                              and oom.status='13' and oom.outstock_type='0'
                              and ood.article_qty-ood.real_qty>0) loop


        v_nRemainQty:= v_GetOutstockItem.article_qty-v_GetOutstockItem.real_qty;

        for GetExpItem in(select * from odata_exp_d oed where oed.enterprise_no=strEnterPriseNo
        and oed.warehouse_no=strWareHouseNo and oed.exp_no=v_GetOutstockItem.exp_no
        and oed.article_no=v_GetOutstockItem.article_no
        and oed.article_no=oed.article_no ) loop
            if v_nRemainQty>=GetExpItem.locate_qty then

               v_nCurrQty:=GetExpItem.locate_qty;
            else
               v_nCurrQty:=v_nRemainQty;
            end if;

            v_nRemainQty:=v_nRemainQty-v_nCurrQty;

            update odata_exp_d od
            set od.locate_qty=od.locate_qty-v_nCurrQty,
                status='10'
            where
              od.exp_no=v_GetOutstockItem.exp_no
              and od.article_no=v_GetOutstockItem.article_no
              and od.locate_qty>=v_nCurrQty
              and od.warehouse_no=strWareHouseNo
              and od.enterprise_no=strEnterPriseNo
              and od.row_id=GetExpItem.row_id;
         end loop;

        update odata_exp_m om set om.status='10' ,updt_date=sysdate,updt_name=strUserID
        where
          om.warehouse_no=strWareHouseNo
          and om.enterprise_no=strEnterPriseNo
          and om.exp_no=v_GetOutstockItem.exp_no;

     end loop;
     strOutMsg:='Y|[成功]';

  end P_O_DiffOutstock;
 /*****************************************************************************************
      LICH
      20150416
     功能：根据波次更新出货手建单
  *****************************************************************************************/
  procedure P_Update_Odata_Exp_By_WaveNo(strEnterPriseNo   in odata_locate_m.enterprise_no%type, --企业号
                                      strWarehouse_no      in odata_locate_m.warehouse_no%type, --仓别
                                      strWaveNo            in odata_locate_m.wave_no%type, --波次
                                      strUpdateName        in odata_locate_m.locate_name%type, --出货员工ID
                                      strOutMsg         out varchar2) --返回值
   is
  begin
    strOutMsg := 'N|[P_Update_Odata_Exp_By_WaveNo]';
    ------------------更新下架单明细信息------------------
    for p in(select *
        from
          odata_locate_d a
        where a.enterprise_no=strEnterPriseNo
          and a.warehouse_no=strWarehouse_no
          and a.wave_no=strWaveNo)
    loop
      update
        odata_exp_m a
      set
        a.cust_no=p.cust_no,
        a.sub_cust_no=p.sub_cust_no,
        a.line_no=p.line_no,
        a.batch_no=p.batch_no,
        a.wave_no=p.wave_no,
        --a.exp_date='',
        a.updt_name=strUpdateName,
        a.status='11'
       where
         a.enterprise_no=strEnterPriseNo
         and a.warehouse_no=strWarehouse_no
         and a.exp_no=p.exp_no;
    end loop;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_Update_Odata_Exp_By_WaveNo;
  /***************************************************************************88
  功能说明：将来源标签明细转移到目的标签明细

  ********************************************************************************/
  procedure P_odata_move_label(strEnterPriseNo    in stock_label_d.enterprise_no%type,
                                 strWareHouseNo     in stock_label_d.warehouse_no%type, --仓库编码
                                 strOwner_No        in stock_label_d.owner_no%type,
                                 strExp_Type        in stock_label_d.exp_type%type,
                                 strSourceNo        in stock_label_d.source_no%type, --来源单号
                                 strsContainerNo    in stock_label_d.container_no%type, --来源容器号
                                 strDestContainerNo in stock_label_d.container_no%type, --目的容器号
                                 nDivideId          in stock_label_d.divide_id%type, --
                                 strArticleNo       in stock_label_d.article_no%type,
                                 nArticleId         in stock_label_d.article_id%type,
                                 nPackingQty        in stock_label_d.packing_qty%type,
                                 strExpNo           in stock_label_d.exp_no%type,
                                 nRealQty           in stock_label_d.qty%type,
                                 strCustNo          in stock_label_d.Cust_No%type, --客户编码
                                 strUserId          in stock_label_m.rgst_name%type,
                                 strResult          OUT varchar2) is
    v_iCount      integer;
    tmpQty        stock_label_d.qty%type;
    v_strStatus   stock_label_m.status%type;
    v_strFlowFlag wms_deflabel_status.flow_flag%type;
    v_strAutoFlag wms_deflabel_status.must_run%type := '0';

  begin
    strResult := 'N|[P_odata_move_label]';

    --增加目的标签明细
    update stock_label_d sld
       set sld.qty       = qty + nRealQty,
           sld.updt_name = strUserId,
           sld.updt_date = sysdate
     where sld.warehouse_no = strWareHouseNo
       and sld.enterprise_no = strEnterPriseNo
       and sld.container_no = strdestContainerNo
       and sld.source_no = strSourceNo
       and sld.article_no = strArticleNo
       and sld.article_id = nArticleId
       and sld.Exp_No = strExpNo
       and sld.divide_id = nDivideId
       and rownum = 1;
    if sql%notfound then
      --获取标签明细的ROW_ID
      select nvl(max(row_id), 0)
        into v_iCount
        from stock_label_d sld
       where sld.container_no = strDestContainerNo
         and sld.warehouse_no = strWareHouseNo
         and sld.enterprise_no = strEnterPriseNo;

      insert into stock_label_d
        (enterprise_no,
         warehouse_no,
         batch_no,
         owner_no,
         source_no,
         container_no,
         container_type,
         article_no,
         article_id,
         packing_qty,
         qty,
         exp_no,
         wave_no,
         cust_no,
         sub_cust_no,
         line_no,
         status,
         divide_id,
         row_id,
         exp_type,
         dps_cell_no,
         deliver_obj,
         exp_date,
         advance_cell_no,
         advance_status,
         rgst_name,
         rgst_date,
         updt_name,
         updt_date,
         deliverobj_order)
        select sld.enterprise_no,
               strWareHouseNo,
               sld.batch_no,
               sld.owner_no,
               strSourceNo,
               strDestContainerNo,
               sld.container_type,
               strArticleNo,
               nArticleId,
               nPackingQty,
               nRealQty,
               sld.exp_no,
               sld.wave_no,
               strCustNo,
               sld.sub_cust_no,
               sld.line_no,
               sld.status,
               nDivideId,
               v_iCount + 1,
               sld.exp_type,
               sld.dps_cell_no,
               sld.deliver_obj,
               sld.exp_date,
               sld.advance_cell_no,
               sld.advance_status,
               sld.rgst_name,
               sld.rgst_date,
               strUserId,
               sysdate,
               sld.deliverobj_order
          from stock_label_d sld
         where sld.warehouse_no = strWareHouseNo
           and sld.enterprise_no = strEnterPriseNo
           and sld.source_no = strSourceNo
           and sld.container_no=strsContainerNo
           and sld.article_no = strArticleNo
           and sld.article_id = nArticleId
           and sld.Exp_No = strExpNo
           and sld.divide_id = nDivideId
           and rownum = 1;
      if sql%rowcount <= 0 then
        strResult := 'N|[新增目的标签明细失败(0行)]';
        return;
      end if;
    end if;

    --扣减来源标签明细
    update stock_label_d sld
       set sld.qty       = qty - nRealQty,
           sld.updt_name = strUserId,
           sld.updt_date = sysdate
     where sld.warehouse_no = strWareHouseNo
       and sld.enterprise_no = strEnterPriseNo
       and sld.container_no = strsContainerNo
       and sld.source_no = strSourceNo
       and sld.article_no = strArticleNo
       and sld.article_id = nArticleId
       and sld.Exp_No = strExpNo
       and sld.divide_id = nDivideId
       and rownum = 1;
    if sql%notfound then
      strResult := 'N|[E22511]';
      return;
    end if;

    -------------------------删除 标签明细为 0  的数据--------------------------
    DELETE stock_label_d
     WHERE warehouse_no = strWareHouseNo
       and enterprise_no = strEnterPriseNo
       AND CONTAINER_NO = strsContainerNo
       and QTY = 0;

    --检查标签明细是否都已检货完成
    select nvl(sum(qty), 0)
      into tmpQty
      from stock_label_d sld
     where sld.warehouse_no = strWareHouseNo
       and sld.enterprise_no = strEnterPriseNo
       AND CONTAINER_NO = strsContainerNo;

    if tmpQty = 0 then
      --标签明细已检货完成,需要置标签头档状态
      update stock_label_m t
         set t.status  = CLABELSTATUS.DIVIDED,
             updt_name = strUserId,
             updt_date = sysdate
       where t.warehouse_no = strWareHouseNo
         and t.enterprise_no = strEnterPriseNo
         AND t.CONTAINER_NO = strsContainerNo;
      -------------标签转历史
      PKOBJ_LABEL.proc_RemoveLabel(strEnterPriseNo,
                                   strwarehouseno,
                                   strsContainerNo,
                                   strResult);
      if instr(strResult, 'N', 1, 1) = 1 then
        return;
      end if;

      --更新目的标签头档的状态
      update stock_label_m t
         set t.status  = '52',
             updt_name = strUserId,
             updt_date = sysdate
       where t.warehouse_no = strWareHouseNo
         and t.enterprise_no = strEnterPriseNo
         AND t.source_no = strSourceNo
         and t.container_no=strDestContainerNo;
    end if;
    strResult := 'Y';
  end P_odata_move_label;

end PKOBJ_ODATA_LICH;

/

