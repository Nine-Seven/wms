create package        PKLG_ROLOCATE is
  /******************************************************************************************************************
   创建人：luozhiling
   创建时间：2013.11.21特殊版，天天惠特有流程
   功能：1、退货定位
         2、退货发单
  ****************************************************************************************************************/
  PROCEDURE P_Special_LOCATEAndTask(strEnterPriseNo in rodata_recede_m.enterprise_no%type,
                               strWareHouseNo  in rodata_recede_m.warehouse_no%type,
                               strOwnerNo      in rodata_recede_m.owner_no%type,
                               strRecedeNo     in rodata_recede_m.recede_no%type,
                               strSupplierNo   in rodata_recede_m.supplier_no%type, --若供应商为空，程序内取供应商
                               strClassType    in rodata_recede_m.class_type%type, --0：清场
                               strUserId       in rodata_recede_m.rgst_name%type,
                               strDockNo       in bdef_defdock.dock_no%type,
                               strDestCellNo   in cdef_defcell.cell_no%type,--指定目的储位定位，目前用于第一次快速清场的流程
                               strWaveNo       out rodata_recede_m.wave_no%type, --返回的波次号
                               strResult       out varchar2);
  /******************************************************************************************************************
   创建人：luozhiling
   创建时间：2013.11.21
   功能：退货区的定位
  ****************************************************************************************************************/
  PROCEDURE P_RODATA_LOCATEAndTask(strEnterPriseNo in rodata_recede_m.enterprise_no%type,
                               strWareHouseNo  in rodata_recede_m.warehouse_no%type,
                               strOwnerNo      in rodata_recede_m.owner_no%type,
                               strRecedeNo     in rodata_recede_m.recede_no%type,
                               strSupplierNo   in rodata_recede_m.supplier_no%type, --若供应商为空，程序内取供应商
                               strClassType    in rodata_recede_m.class_type%type, --0：清场
                               strUserId       in rodata_recede_m.rgst_name%type,
                               strDockNo       in bdef_defdock.dock_no%type,
                               strWaveNo       out rodata_recede_m.wave_no%type, --返回的波次号
                               strResult       out varchar2) ;
 /*************************************************************************************
  功能说明：退厂定位主程序
  *************************************************************************************/
  PROCEDURE P_RODATA_LOCATE_Main(strEnterPriseNo in rodata_recede_m.enterprise_no%type,
                            strWareHouseNo  in rodata_recede_m.warehouse_no%type,
                            strOwnerNo      in rodata_recede_m.owner_no%type,
                            strRecedeNo     in rodata_recede_m.recede_no%type,
                            strFirstFlag    in rodata_recede_m.stock_type%type, --1：第一单；0：不是第一单
                            strUserId       in rodata_recede_m.rgst_name%type,
                            strOldWaveNo    in rodata_recede_m.wave_no%type, --原波次号
                            strWaveNo       out rodata_recede_m.wave_no%type, --返回的波次号
                            strResult       out varchar2);
 /*************************************************************************************
  功能说明：退厂定位主程序,适用于天天惠的特殊清场定位，
             第一次只能定位总仓的库存
             第二次定位清场区的库存
  *************************************************************************************/
  PROCEDURE P_SPECIAL_LOCATE_Main(strEnterPriseNo in rodata_recede_m.enterprise_no%type,
                            strWareHouseNo  in rodata_recede_m.warehouse_no%type,
                            strOwnerNo      in rodata_recede_m.owner_no%type,
                            strRecedeNo     in rodata_recede_m.recede_no%type,
                            strFirstFlag    in rodata_recede_m.stock_type%type, --1：第一单；0：不是第一单
                            strUserId       in rodata_recede_m.rgst_name%type,
                            strOldWaveNo    in rodata_recede_m.wave_no%type, --原波次号
                            strDestCellNo   in cdef_defcell.cell_no%type,--指定目的储位定位，目前用于第一次快速清场的流程
                            strWaveNo       out rodata_recede_m.wave_no%type, --返回的波次号
                            strResult       out varchar2) ;
  /********************************************************************************
   功能说明：根据退货类型配置的策略对退货单进行定位
   huangb 20150511 增加order_rsv03-退厂定位规格类型(0-不管规格；1-优先退厂明细规格；2-按退厂规格) 参数
  ********************************************************************************/
  PROCEDURE P_RODATA_LOCATE(strEnterPriseNo in rodata_recede_m.enterprise_no%type,
                            strWareHouseNo  in rodata_recede_m.warehouse_no%type,
                            strRecedeNo     in rodata_recede_m.recede_no%type,
                            strWaveNo       in rodata_recede_m.wave_no%type, --返回的波次号
                            strStrategyId   in wms_rodataorder.strategy_id%type,
                            strDestCellNo   in cdef_defcell.cell_no%type,
                            strUserId       in bdef_defworker.worker_no%type,
                            strORDER_RSV03  in wms_rodataorder.order_rsv03%type, --退厂定位规格类型(0-不管规格；1-优先退厂明细规格；2-按退厂规格)
                            strResult       out varchar2);
  /******************************************************************************************************************
   创建人：wyf
   创建时间：2013.11.21
   功能：退货定位写下架指示和库存
  ****************************************************************************************************************/
  PROCEDURE P_RODATA_WRITE_DIRECT(strEnterPriseNo in rodata_recede_m.enterprise_no%type,
                                  strWareHouseNo  in rodata_recede_m.warehouse_no%type,
                                  strRecedeNo     in rodata_recede_m.recede_no%type,
                                  strWaveNo       in rodata_recede_m.wave_no%type, --返回的波次号
                                  strSupplierNo   in rodata_recede_m.supplier_no%type,
                                  strUserId       in rodata_recede_m.rgst_name%type,
                                  strClassType    in rodata_recede_m.class_type%type,
                                  strRecedeType   in rodata_recede_m.recede_type%type,
                                  strDeptNo       in rodata_recede_m.DEPT_NO%type, --部门编号 huangb 20160514
                                  nPoID           in rodata_recede_d.po_id%type,
                                  nQty            in out rodata_recede_d.recede_qty%type,
                                  strDestCellNo   in stock_content.cell_no%type,
                                  strSql          in varchar2,
                                  strResult       out varchar2);

  /******************************************************************************************************************
   创建人：lizhiping
   创建时间：2016.1.8
   功能：退货区分播资源试算
  ****************************************************************************************************************/
  PROCEDURE p_allot_dpscell(strEnterPriseNo in rodata_recede_m.enterprise_no%type,
                               strWareHouseNo  in rodata_recede_m.warehouse_no%type,
                               strWaveNo       in rodata_recede_m.wave_no%type, --返回的波次号
                               strClassType    in rodata_recede_m.class_type%type, --0：清场
                               strUserId       in rodata_recede_m.rgst_name%type,
                               strResult       out varchar2);
  /********************************************************************************
  功能说明：超量定位，以WMS的库存作为可用库存
  ********************************************************************************/
  PROCEDURE P_OverQtyDeal(strEnterPriseNo in rodata_recede_m.enterprise_no%type,
                          strWareHouseNo  in rodata_recede_m.warehouse_no%type,
                          strOwnerNo      in rodata_recede_m.owner_no%type,
                          strRecedeNo     in rodata_recede_m.recede_no%type,
                          strRecedeType   in rodata_recede_m.recede_type%type,
                          strResult       out varchar2);

  /********************************************************************************************************
   功能说明：清场流程第二次,整单审核，处理流程：
   1、退货定位，若定位数量和扫描数量有差异，系统给予拦截，不进行后续操作
   3、若定位量和扫描数量相等，退货发单，不打印
   4、退货回单
   5、退货确认，打印退货清单
  *********************************************************************************************************/
  PROCEDURE P_reviewRecedeNo(strEnterPriseNo in rodata_recede_m.enterprise_no%type,
                               strWareHouseNo  in rodata_recede_m.warehouse_no%type,
                               strOwnerNo      in rodata_recede_m.owner_no%type,
                               strRecedeNo     in rodata_recede_m.recede_no%type,
                               strSupplierNo   in rodata_recede_m.supplier_no%type, --若供应商为空，程序内取供应商
                               strClassType    in rodata_recede_m.class_type%type, --0：清场
                               strUserId       in rodata_recede_m.rgst_name%type,
                               strDockNo       in bdef_defdock.dock_no%type,
                               strWaveNo       out rodata_recede_m.wave_no%type, --返回的波次号
                               strResult       out varchar2);
end PKLG_ROLOCATE;


/

