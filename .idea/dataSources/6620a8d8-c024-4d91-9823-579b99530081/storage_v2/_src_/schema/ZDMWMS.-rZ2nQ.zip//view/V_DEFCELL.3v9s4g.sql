create view V_DEFCELL as
select w.org_no,a.o_type,a.area_type,a.area_usetype,a.area_quality,
a.divide_flag,a.b_divide_flag,a.area_attribute,a.attribute_type,a.b_pick,a.area_pick,
d.enterprise_no,d.warehouse_no,d.ware_no,d.area_no,d.stock_no,d.stock_x,d.bay_x,d.stock_y,
d.cell_no,d.mix_flag,d.mix_supplier,d.cell_status,d.check_status,d.a_flag
 from cdef_defware w,cdef_defarea a,cdef_defcell d
where w.enterprise_no=a.enterprise_no and w.enterprise_no=d.enterprise_no
and w.warehouse_no=a.warehouse_no and w.warehouse_no=d.warehouse_no
and w.ware_no=a.ware_no and w.ware_no=d.ware_no
and a.area_no=d.area_no


/

