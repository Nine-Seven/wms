create PACKAGE        SorterFlag is

        -- 禁止上分拣
        No CONSTANT bdef_article_packing.sorter_flag%type := '0';             --禁止上分拣

        -- 允许上分拣
        Yes CONSTANT bdef_article_packing.sorter_flag%type := '1';        --允许上分拣


end SorterFlag;


/

