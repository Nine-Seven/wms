create package        PKOBJ_COST is
  /***********************************************************************************************
  wyf
  201501204
  功能说明：根据取值策略生成消费清单
  根据计费项目策略产生的清单（固定费用只在结算日期产生）
  ***********************************************************************************************/
  procedure P_EXPENSES_LIST(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                            strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                            strOwnerNo         cost_formulaset.owner_no%type, --货主
                            strBilling_project cost_formulaset.billing_project%type, --计费项目 支持传空值
                            strBillingType     cost_formulaset.billing_type%type, --计费项目类型 支持传空值
                            dtDate             cost_expenses_list.build_date%type, --生成日期
                            strFlag            cost_expenses_list.flag%type, --是否重算，0:代表正常日结生成，1：代表重算
                            strWorkerNo        cost_expenses_list.rgst_name%type,
                            strOutMsg          out varchar2);

  /***********************************************************************************************
  wyf
  20150630
  功能说明：根据取值策略生成固定费用类型的消费清单
  ***********************************************************************************************/
  procedure P_GCLD_FIXED(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                         strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                         strOwnerNo         cost_formulaset.owner_no%type, --货主
                         strBilling_project cost_formulaset.billing_project%type, --计费项目
                         strBillingType     cost_formulaset.billing_type%type, --计费项目类型
                         dtDate             cost_expenses_list.build_date%type, --产生日期
                         strFlag            cost_expenses_list.flag%type, --0:代表正常日结生成，1：代表重算
                         strWorkerNo        cost_expenses_list.rgst_name%type,
                         strOutMsg          out varchar2);
  /***********************************************************************************************
  wyf
  20160524
  功能说明：根据取值策略生成动态费用类型的消费清单
  ***********************************************************************************************/
  procedure P_GCLD_DYNAMIC_NEW(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                               strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                               strOwnerNo         cost_formulaset.owner_no%type, --货主
                               strBilling_project cost_formulaset.billing_project%type, --计费项目
                               strBillingType     cost_formulaset.billing_type%type, --计费项目类型
                               dtDate             cost_expenses_list.build_date%type, --生成日期
                               strFlag            cost_expenses_list.flag%type, --是否重算，0:代表正常日结生成，1：代表重算
                               strWorkerNo        cost_expenses_list.rgst_name%type,
                               strOutMsg          out varchar2);
  /***********************************************************************************************
  wyf
  20160524
  功能说明：获取消费数据
  ***********************************************************************************************/
  procedure P_GC_COMM_LIST(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                           strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                           strOwnerNo         cost_formulaset.owner_no%type, --货主
                           strBilling_project cost_formulaset.billing_project%type, --计费项目
                           strBillingType     cost_formulaset.billing_type%type, --计费项目类型
                           strStandardFlag    cost_formulaset.standard_flag%type, --是否标准策略
                           strBillingUnit     cost_formulaset.billing_unit%type, --计费单位
                           strValueFlag       cost_formulaset.value_flag%type, --取值方式
                           dtDate             cost_expenses_list.build_date%type, --生成日期
                           strFlag            cost_expenses_list.flag%type, --是否重算，0:代表正常日结生成，1：代表重算
                           strWorkerNo        cost_expenses_list.rgst_name%type,
                           strOutMsg          out varchar2);
  /***********************************************************************************************
  wyf
  20160525
  功能说明：新增消费清单
  ***********************************************************************************************/
  procedure P_INSERT_EXPENSES_LIST_NEW(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                                       strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                                       strOwnerNo         cost_formulaset.owner_no%type, --货主
                                       strBilling_project cost_formulaset.billing_project%type, --计费项目 支持传空值
                                       strBillingType     cost_formulaset.billing_type%type, --计费项目类型 支持传空值
                                       strBillingUnit     cost_formulaset.billing_unit%type,
                                       strFamilyNo        cost_formula_articlefamily.family_no%type,
                                       dtDate             cost_formulaset.rgst_date%type, --开始日期
                                       strSourceNo        cost_expenses_list.source_no%type, --来源单号
                                       nQty               cost_expenses_list.qty%type, --计费量
                                       strFlag            cost_expenses_list.flag%type, --是否重算，0:代表正常日结生成，1：代表重算
                                       strWorkerNo        cost_expenses_list.rgst_name%type,
                                       strOutMsg          out varchar2);

  /***********************************************************************************************
  lich
  20140729
  功能说明：根据消费清单生成费用明细表
  ***********************************************************************************************/
  procedure P_COST_DETAILS(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                           strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                           strOwnerNo         cost_formulaset.owner_no%type, --货主
                           strBilling_project cost_formulaset.billing_project%type, --计费项目 支持传空值
                           strBillingType     cost_formulaset.billing_type%type, --计费项目类型 支持传空值
                           dtDate             cost_formulaset.rgst_date%type, --开始日期
                           strFlag            cost_expenses_list.flag%type, --是否重算，0:代表正常日结生成，1：代表重算
                           strWorkerNo        cost_expenses_list.rgst_name%type,
                           strOutMsg          out varchar2); --返回值
  /***********************************************************************************************
  hcx
  20160125
  功能说明：手工生成费用明细
  ***********************************************************************************************/
  procedure P_COST_DETAILS_BYHAND(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                                  strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                                  strOwnerNo         cost_formulaset.owner_no%type, --货主
                                  dtDate             cost_cost_list.build_date%type,
                                  dtStart            cost_cost_list.begin_date%type,
                                  dtEnd              cost_cost_list.end_date%type,
                                  strBilling_project cost_formulaset.billing_project%type, --计费项目编码
                                  strBillingType     cost_formulaset.billing_type%type, --计费项目类型
                                  strFlag            cost_expenses_list.flag%type, --是否重算 0:首次生成费用 , 1:重算
                                  strDiscountFlag    varchar2, --是否使用优惠策略--0:不使用，1:使用
                                  strWorkerNo        cost_financial.rgst_name%type,
                                  strOutMsg          out varchar2); --返回值
  /***********************************************************************************************
  wyf
  20151210
  功能说明：通过计费项目优惠策略计算优惠后金额
  ***********************************************************************************************/
  procedure P_PROJECT_DISCOUNT(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                               strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                               strOwnerNo         cost_formulaset.owner_no%type, --货主
                               strBilling_project cost_formulaset.billing_project%type, --计费项目
                               strBillingType     cost_formulaset.billing_type%type, --计费项目类型
                               nQty               cost_cost_list.qty%type,
                               nAmount            cost_cost_list.amount%type,
                               nFavAmount         out cost_cost_list.favourable_amount%type, --优惠金额
                               strOutMsg          out varchar2);
  /***********************************************************************************************
  wyf
  20151214
  功能说明：费用明细回退
  ***********************************************************************************************/
  procedure P_REBACK_COST_DETAILS(strEnterpriseNo    cost_formulaset.enterprise_no%type, --企业
                                  strWarehouseNo     cost_formulaset.warehouse_no%type, --仓别
                                  strOwnerNo         cost_formulaset.owner_no%type, --货主
                                  strBilling_project cost_formulaset.billing_project%type, --计费项目 支持传空值
                                  strBillingType     cost_formulaset.billing_type%type, --计费项目类型 支持传空值
                                  dtDate             cost_formulaset.rgst_date%type, --开始日期
                                  strSerialNo        cost_cost_list.serial_no%type, --流水号
                                  strOutMsg          out varchar2);
  /***********************************************************************************************
  lich
  20140729
  功能说明：根据消费清单生成费用明细表
  ***********************************************************************************************/
  procedure P_FINANCIAL_DETAILS_BYAUTO(strEnterpriseNo cost_formulaset.enterprise_no%type, --企业
                                       strWarehouseNo  cost_formulaset.warehouse_no%type, --仓别
                                       strOwnerNo      cost_formulaset.owner_no%type, --货主
                                       --strMonth         varchar, --月份
                                       dtDate            cost_cost_list.build_date%type,
                                       strAccountGroupNo cost_account_d.account_group_no%type, --科目组编码（允许为空，但重算时必须传）
                                       --strAccountNo      cost_financial.account_no%type, --科目编码（允许为空，但重算时必须传）
                                       strCheckNo  cost_financial.check_no%type, --对账单号（允许为空，但重算时必须传）
                                       strFlag     cost_expenses_list.flag%type, --是否重算，0:代表正常日结生成，1：代表重算
                                       strWorkerNo cost_financial.rgst_name%type,
                                       strOutMsg   out varchar2);
  /***********************************************************************************************
  wyf
  20151210
  功能说明：手工出对账单
  ***********************************************************************************************/
  procedure P_FINANCIAL_DETAILS_BYHAND(strEnterpriseNo cost_formulaset.enterprise_no%type, --企业
                                       strWarehouseNo  cost_formulaset.warehouse_no%type, --仓别
                                       strOwnerNo      cost_formulaset.owner_no%type, --货主
                                       dtDate          cost_cost_list.build_date%type,
                                       dtStart         cost_cost_list.begin_date%type,
                                       dtEnd           cost_cost_list.end_date%type,
                                       strAccountNo    cost_financial.account_no%type, --科目编码（允许为空，但重算时必须传）
                                       strCheckNo      cost_financial.check_no%type, --对账单号（允许为空，但重算时必须传）
                                       strFlag         cost_expenses_list.flag%type, --是否重算 0:首次出账 , 1:重算
                                       strDiscountFlag varchar2, --是否使用优惠策略--0:不使用，1:使用
                                       strWorkerNo     cost_financial.rgst_name%type,
                                       strOutMsg       out varchar2);
  /***********************************************************************************************
  weiyf
  20151211
  功能说明：根据消费清单自动生成账单
  ***********************************************************************************************/
  procedure P_INSERT_FINANCIAL(strEnterpriseNo cost_formulaset.enterprise_no%type, --企业
                               strWarehouseNo  cost_formulaset.warehouse_no%type, --仓别
                               strOwnerNo      cost_formulaset.owner_no%type, --货主
                               dtDate          cost_cost_list.build_date%type,
                               dtStart         cost_cost_list.begin_date%type,
                               dtEnd           cost_cost_list.end_date%type,
                               strAccountNo    cost_account_d.account_no%type, --科目组编码
                               strCheckNo      in out cost_financial.check_no%type, --对账单号（允许为空，但重算时必须传）
                               strFlag         cost_expenses_list.flag%type, --是否重算 0:自动 , 1:重算
                               strWorkerNo     cost_financial.rgst_name%type,
                               strOutMsg       out varchar2);
  /***********************************************************************************************
  wyf
  20151210
  功能说明：其他费用出对账单
  ***********************************************************************************************/
  procedure P_OTHERCOST_DETAILS(strEnterpriseNo cost_formulaset.enterprise_no%type, --企业
                                strWarehouseNo  cost_formulaset.warehouse_no%type, --仓别
                                strOwnerNo      cost_formulaset.owner_no%type, --货主
                                dtDate          cost_cost_list.build_date%type,
                                dtStart         cost_cost_list.begin_date%type,
                                dtEnd           cost_cost_list.end_date%type,
                                strCheckNo      in out cost_financial.check_no%type, --对账单号
                                strFlag         cost_expenses_list.flag%type, --是否重算 0:首次出账 , 1:重算
                                strCreateFlag   cost_financial.create_flag%type, --0:自动出账，1:人工出账
                                strWorkerNo     cost_financial.rgst_name%type,
                                strOutMsg       out varchar2);
  /***********************************************************************************************
  wyf
  20151210
  功能说明：计算周期起始时间
  ***********************************************************************************************/
  procedure P_GETCYCLE_BEGINTOEND(strCycle    cost_formulaset.billing_cycle%type,
                                  strLastDay  cost_formulaset.balance_day%type,
                                  dtDate      cost_cost_list.build_date%type,
                                  dtStart     out cost_cost_list.begin_date%type, --起始日期
                                  dtEnd       out cost_cost_list.end_date%type, --结束日期
                                  strNextFlag out varchar2, --是否跳过  0：否 ，1：是
                                  strOutMsg   out varchar2);
  /***********************************************************************************************
  wyf
  20151210
  功能说明：通过科目优惠策略计算优惠后金额
  ***********************************************************************************************/
  procedure P_ACCOUNT_DISCOUNT(strEnterpriseNo cost_formulaset.enterprise_no%type, --企业
                               strWarehouseNo  cost_formulaset.warehouse_no%type, --仓别
                               strOwnerNo      cost_formulaset.owner_no%type, --货主
                               strAccountNo    cost_financial.account_no%type, --科目编码
                               dtStart         cost_financial.build_date%type,
                               dtEnd           cost_financial.build_date%type,
                               nAmount         cost_cost_list.amount%type,
                               nDiscountAmount out cost_cost_list.amount%type,
                               strOutMsg       out varchar2);
  /***********************************************************************************************
  wyf
  20151214
  功能说明：账单回退
  ***********************************************************************************************/
  procedure P_REBACK_FINANCIAL(strEnterpriseNo cost_formulaset.enterprise_no%type, --企业
                               strWarehouseNo  cost_formulaset.warehouse_no%type, --仓别
                               strOwnerNo      cost_formulaset.owner_no%type, --货主
                               strCheckNo      cost_financial.check_no%type, --对账单号
                               strOutMsg       out varchar2);
  /***********************************************************************************************
  wyf
  20150727
  功能说明：生成计费
  ***********************************************************************************************/
  procedure P_GENERATE_BILL;
  /***********************************************************************************************
  wyf
  20160104
  功能说明：重算消费清单（可重算所有货主-内部使用）
  ***********************************************************************************************/
  procedure P_RETRY_COST(strOwnerNo         cost_formulaset.owner_no%type,
                         strBilling_project cost_formulaset.billing_project%type, --计费项目 支持传空值
                         strBillingType     cost_formulaset.billing_type%type, --计费项目类型 支持传空值
                         dtStart            in date, --开始时间
                         dtEnd              in date, --结束时间
                         strOutMsg          out varchar2);
end PKOBJ_COST;


/

