create view V_SEARCH_9103_020 as
select ocld.enterprise_no,
       ocld.warehouse_no,
       ocld.owner_no,
       bdo.owner_name,
       bdo.owner_alias,
       oem.sourceexp_no source_no,
       oem.shipper_deliver_no,
       oem.cust_no,
       bdc.cust_name,
       to_char(oem.rgst_date, 'yyyy-mm-dd') rgst_date,
       ocld.lable_no s_lable_no,
       --   slm.label_no d_lable_no,
       sp.article_name bc_name,
       ocld.article_no,
       bda.ARTICLE_NAME,
       bda.OWNER_ARTICLE_NO,
       bda.BARCODE,
       ocld.packing_qty,
       ocld.check_name worker_no,
       ocld.check_date check_date,
       sum(ocld.article_qty) article_qty,
       sum(ocld.real_qty) move_qty,
       sum(ocld.article_qty - ocld.real_qty) diff_qty,
       bdw.worker_name
  from (select warehouse_no,
               enterprise_no,
               container_no,
               owner_no,
               exp_no,
               check_name,
               check_date,
               article_no,
               lable_no,
               packing_qty,
               article_qty,
               real_qty
          from odata_check_label_d
        union
        select warehouse_no,
               enterprise_no,
               container_no,
               owner_no,
               exp_no,
               check_name,
               check_date,
               article_no,
               lable_no,
               packing_qty,
               article_qty,
               real_qty
          from odata_check_label_dhty) ocld
  left join (select b.enterprise_no,
                    b.warehouse_no,
                    b.owner_no,
                    b.plan_no,
                    b.po_no,
                    c.article_no,
                    bda.article_name
               from stock_plan_m b
               join stock_plan_d c
                 on b.enterprise_no = c.enterprise_no
                and b.warehouse_no = c.warehouse_no
                and b.owner_no = c.owner_no
                and b.plan_no = c.plan_no
                and b.plan_type = '4'
               join bdef_defarticle bda
                 on bda.enterprise_no = c.enterprise_no
                and bda.article_no = c.article_no
                and bda.owner_no = c.owner_no) sp
    on sp.enterprise_no = ocld.enterprise_no
   and ocld.warehouse_no = sp.warehouse_no
   and ocld.exp_no = sp.po_no
/*  left join (select *
            from stock_label_m
          union
          select *
            from stock_label_mhty) slm
 on ocld.enterprise_no = slm.enterprise_no
and ocld.warehouse_no = slm.warehouse_no
and ocld.container_no = slm.container_no*/
 inner join bdef_defowner bdo
    on ocld.enterprise_no = bdo.enterprise_no
   and ocld.owner_no = bdo.owner_no
 inner join odata_exp_m oem
    on ocld.enterprise_no = oem.enterprise_no
   and ocld.warehouse_no = oem.warehouse_no
   and ocld.owner_no = oem.owner_no
   and ocld.exp_no = oem.exp_no
 inner join bdef_defcust bdc
    on oem.enterprise_no = bdc.enterprise_no
   and oem.owner_no = bdc.owner_no
   and oem.cust_no = bdc.cust_no
 inner join bdef_defworker bdw
    on ocld.enterprise_no = bdw.enterprise_no
   and ocld.check_name = bdw.worker_no
 inner join bdef_defarticle bda
    on ocld.enterprise_no = bda.enterprise_no
   and ocld.owner_no = bda.owner_no
   and ocld.article_no = bda.article_no
 group by ocld.enterprise_no,
          ocld.warehouse_no,
          ocld.owner_no,
          oem.sourceexp_no,
          oem.shipper_deliver_no,
          oem.cust_no,
          oem.rgst_date,
          ocld.lable_no,
          sp.article_name,
          ocld.article_no,
          ocld.packing_qty,
          --  slm.label_no,
          ocld.check_name,
          ocld.check_date,
          bdo.owner_name,
          bdo.owner_alias,
          bdc.cust_name,
          bda.ARTICLE_NAME,
          bda.OWNER_ARTICLE_NO,
          bda.BARCODE,
          bdw.worker_name
order by oem.rgst_date  desc

/

