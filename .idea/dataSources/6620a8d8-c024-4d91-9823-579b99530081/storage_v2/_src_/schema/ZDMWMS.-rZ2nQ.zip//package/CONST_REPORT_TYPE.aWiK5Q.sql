create PACKAGE        CONST_REPORT_TYPE is
  --报表取单据类型的常量定义
  IDATAIMPORTID CONSTANT pntset_module_report.paper_type%type := 'ID'; --直通进货
  IDATAIMPORTIS CONSTANT pntset_module_report.paper_type%type := 'IS'; --存储进货
  IDATAIMPORTSS CONSTANT pntset_module_report.paper_type%type := 'SS'; --直通汇总单 huangb 20160624
  IDATAIMPORTSD CONSTANT pntset_module_report.paper_type%type := 'SD'; --存储汇总单 huangb 20160624
  IDATAIL       CONSTANT pntset_module_report.paper_type%type := 'IL'; --定位指示号
  IDATAIP       CONSTANT pntset_module_report.paper_type%type := 'IP'; --进货上架
  IDATASC       CONSTANT pntset_module_report.paper_type%type := 'SC'; --取汇总验收单号；
  IDATAIC       CONSTANT pntset_module_report.paper_type%type := 'IC'; --取验收单号；

  ODATAHO    CONSTANT pntset_module_report.paper_type%type := 'HO'; --出货下架单号
  ODATAOE    CONSTANT pntset_module_report.paper_type%type := 'OE'; --出货手建单号
  ODATAB2C   CONSTANT pntset_module_report.paper_type%type := 'B2C'; --电商出货单 发票，面单，装车清单用 huangb 20160625
  ODATAOC    CONSTANT pntset_module_report.paper_type%type := 'OC'; --病单单号 (复核单头档单号)
  ODATACT    CONSTANT pntset_module_report.paper_type%type := 'CT'; --整理单号
  ODATALO    CONSTANT pntset_module_report.paper_type%type := 'LO'; --波次号
  ODATAWO    CONSTANT pntset_module_report.paper_type%type := 'WO'; --定位指示号；
  ODATARL    CONSTANT pntset_module_report.paper_type%type := 'RL'; --下架单号；
  ODATAOL    CONSTANT pntset_module_report.paper_type%type := 'OL'; --装车建议单；
  ODATAOL1   CONSTANT pntset_module_report.paper_type%type := 'OL1'; --装车建议单 交运单总表专用 haungb 20160625；
  ODATAOD    CONSTANT pntset_module_report.paper_type%type := 'OD'; --出货配送单；
  ODATAODBOX CONSTANT pntset_module_report.paper_type%type := 'ODBOX';--出货容器明细（配送箱明细）haungb 20160804
  ODATARD    CONSTANT pntset_module_report.paper_type%type := 'RD'; --取分播单号；

  FCDATACP CONSTANT pntset_module_report.paper_type%type := 'CP'; --盘点计划单号；
  FCDATACR CONSTANT pntset_module_report.paper_type%type := 'CR'; --盘点需求单号；
  FCDATACH CONSTANT pntset_module_report.paper_type%type := 'CH'; --盘点单号；
  FCDATACD CONSTANT pntset_module_report.paper_type%type := 'CD'; --取差异单号；

  RIDATAUM CONSTANT pntset_module_report.paper_type%type := 'UM'; --返配单号
  RISC     CONSTANT pntset_module_report.paper_type%type := 'UMSC'; --返配验收单 报表专用 huangb 20160816
  RIDATAVM CONSTANT pntset_module_report.paper_type%type := 'VM'; --返配汇总单号

  RODATARE CONSTANT pntset_module_report.paper_type%type := 'RE'; --退货单号

  MDATAHC CONSTANT pntset_module_report.paper_type%type := 'HC'; --移库计划单；
  MDATAHS CONSTANT pntset_module_report.paper_type%type := 'HS'; --移库下架单

  WMSQU CONSTANT pntset_module_report.paper_type%type := 'QU'; --品质转换单号；

  WMSAD CONSTANT pntset_module_report.paper_type%type := 'AD'; --虚拟移库单号；

  STOCKPLAN CONSTANT pntset_module_report.paper_type%TYPE := 'SP'; --库存调整单

  STOCKCONFIRM CONSTANT pntset_module_report.paper_type%TYPE := 'ST'; --库存调整确认单

  PRINTPT CONSTANT pntset_module_report.paper_type%type := 'PT'; --打印

  LABELXH CONSTANT pntset_module_report.paper_type%type := 'XH'; --标签销毁单号

  SOPLAN    CONSTANT pntset_module_report.paper_type%type := 'SM'; --报损通知单
  SOSEND    CONSTANT pntset_module_report.paper_type%type := 'SMSEN'; --报损下架单打印 huangb 20160804
  SODELIVER CONSTANT pntset_module_report.paper_type%type := 'SMDEL'; --报损清单单打印 huangb 20160804

  ARTICLE CONSTANT pntset_module_report.paper_type%TYPE := 'SKU'; --商品编码

  COST CONSTANT pntset_module_report.paper_type%TYPE := 'CB'; --计费对账单号

end CONST_REPORT_TYPE;


/

