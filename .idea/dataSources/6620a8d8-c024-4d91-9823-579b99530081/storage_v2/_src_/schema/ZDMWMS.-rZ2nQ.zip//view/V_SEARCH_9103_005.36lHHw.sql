create view V_SEARCH_9103_005 as
select "ENTERPRISE_NO",
       "WAREHOUSE_NO",
       "OWNER_NO",
       "CUST_NO",
       "CUST_NAME",
       "WAVE_NO",
       "BATCH_NO",
       "SUM_CASE_NUM",
       "LABEL_NO",
       "LOCATE_DATE",
       "STATUS",
       "UPDT_DATE",
       "DEVICE_NO"
  from (SELECT /*+rule*/
         oem.enterprise_no,
         oem.warehouse_no,
         oem.owner_no,
         oem.cust_no,
         bdc.cust_name,
         ood.wave_no,
         ood.batch_no,
         CEIL(SUM(ood.locate_qty / ood.packing_qty)) sum_case_num,
         clm.label_no,
         TRUNC(ood.operate_date) locate_date,
         wdf.text status,
         clm.updt_date,
         clm.device_no
          FROM odata_exp_m oem
         INNER JOIN (select *
                      from odata_outstock_direct
                    union
                    select *
                      from odata_outstock_directhty) ood
            ON ood.warehouse_no = oem.warehouse_no
           AND ood.owner_no = oem.owner_no
           AND ood.cust_no = oem.cust_no
           AND ood.exp_no = oem.exp_no
          LEFT JOIN (SELECT warehouse_no,enterprise_no,owner_no,article_no,container_no,article_id,exp_no
                      FROM stock_label_d
                    UNION
                    SELECT warehouse_no,enterprise_no,owner_no,article_no,container_no,article_id,exp_no
                      FROM stock_label_dhty) cld
            ON cld.warehouse_no = ood.warehouse_no
           and cld.enterprise_no = ood.enterprise_no
           and cld.owner_no = ood.owner_no
           and cld.article_no = ood.article_no
           and cld.article_id = ood.article_id
           AND cld.exp_no = oem.exp_no
          LEFT JOIN (SELECT warehouse_no,enterprise_no,container_no,status,label_no,updt_date,device_no
                      FROM stock_label_m
                    UNION
                    SELECT warehouse_no,enterprise_no,container_no,status,label_no,updt_date,device_no
                      FROM stock_label_mhty) clm
            ON clm.warehouse_no = cld.warehouse_no
           and clm.enterprise_no = cld.enterprise_no
           AND clm.container_no = cld.container_no
           AND clm.status <> '60'
          LEFT JOIN wms_deffieldval wdf
            ON wdf.table_name = 'STOCK_LABEL_M'
           AND wdf.colname = 'STATUS'
           AND wdf.VALUE = clm.status
          join bdef_defcust bdc
            on oem.owner_no = bdc.owner_no
           and oem.enterprise_no = bdc.enterprise_no
           and oem.cust_no = bdc.cust_no
         GROUP BY oem.enterprise_no,
                  oem.warehouse_no,
                  oem.owner_no,
                  oem.cust_no,
                  bdc.cust_name,
                  ood.wave_no,
                  ood.batch_no,
                  clm.label_no,
                  TRUNC(ood.operate_date),
                  wdf.text,
                  clm.updt_date,
                  clm.device_no) c

/

