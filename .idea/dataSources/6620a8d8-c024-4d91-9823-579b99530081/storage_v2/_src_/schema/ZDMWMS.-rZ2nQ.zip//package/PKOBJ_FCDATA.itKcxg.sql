create package        PKOBJ_FCDATA is

/**********************************************************************************************************
   luozhiling
   2013.11.16
   功能：按盘点计划成需求,一盘点计划单成一张需求单
***********************************************************************************************************/
    procedure P_Fcdata_Request(strEnterPriseNo         in    fcdata_plan_m.enterprise_no%type,
                               strWareHouseNo          in    fcdata_plan_m.warehouse_no%type,--仓库编码
                               strOwnerNo              in    fcdata_plan_m.owner_no%type,
                               strUserId               in    fcdata_plan_m.rgst_name%type,
                               strPlanNo               in    fcdata_plan_m.plan_no%type,--盘点计划单号
                               strRequstNo             OUT   fcdata_request_m.request_no%type,--盘点需求单号
                               strResult               OUT    varchar2);
/***************************************************************************************************************
  luozhiling
  2015.4.1
  功能：储位盘的找储位规则
***************************************************************************************************************/

    procedure P_CellCheckGetCell(strEnterPriseNo         in    fcdata_plan_m.enterprise_no%type,
                                  strWareHouseNo         in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo             in    fcdata_plan_m.owner_no%type,
                                  strRequstNo            IN    fcdata_request_m.request_no%type,--需求单号
                                  StrFIXEDCELLFLAG       in    bdef_defowner.FIXEDCELL_FLAG%type,
                                  strAllCells            in    WMS_DEFBASE.sdefine%type,--是否盘需求单范围全部储位
                                  strResult               OUT    varchar2);
/***************************************************************************************************************
  luozhiling
  2015.4.1
  功能：商品盘找储位规则
***************************************************************************************************************/

    procedure P_ArtCheckGetCell(strEnterPriseNo         in    fcdata_plan_m.enterprise_no%type,
                                  strWareHouseNo         in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo             in    fcdata_plan_m.owner_no%type,
                                  strRequstNo            IN    fcdata_request_m.request_no%type,--需求单号
                                  strFullCellarts        in    WMS_DEFBASE.sdefine%type,--是否盘当前商品有帐的储位
                                  strVIRCellarts         in    WMS_DEFBASE.sdefine%type,--若当前商品无库存，是否盘异常储位
                                  strResult               OUT    varchar2);

/***************************************************************************************************************
  luozhiling
  2015.4.1
  功能：动销盘找储位规则
***************************************************************************************************************/

    procedure P_dynamicCheckGetCell(strEnterPriseNo      in    fcdata_plan_m.enterprise_no%type,
                                  strWareHouseNo         in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo             in    fcdata_plan_m.owner_no%type,
                                  strRequstNo            IN    fcdata_request_m.request_no%type,--需求单号
                                  stroutstockCells       in    WMS_DEFBASE.sdefine%type,--找存在下架动作的储位
                                  strinstockCells        in    WMS_DEFBASE.sdefine%type,--找存在上架动作的储位
                                  dtBEGIN_DATE           IN    fcdata_plan_m.BEGIN_DATE%type,
                                  dtEND_DATE             IN    fcdata_plan_m.end_date%type,
                                  strResult               OUT    varchar2);
/**********************************************************************************************************
   luozhiling
   2013.11.16
   功能：按盘点计划成需求,一盘点计划单成一张需求单
***********************************************************************************************************/
    procedure P_Fcdata_LocateDiect(strEnterPriseNo        in    fcdata_plan_m.enterprise_no%type,
                                  strWareHouseNo          in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_plan_m.owner_no%type,
                                  strUserId               in    fcdata_plan_m.rgst_name%type,
                                  strRequstNo             IN    fcdata_plan_m.plan_no%type,--移库计划头档
                                  strResult               OUT    varchar2);

/**********************************************************************************************************
   luozhiling
   2015.4.1
   功能：写储位盘定位指示
***********************************************************************************************************/
    procedure P_InsertCellLocateDiect(strEnterPriseNo        in    fcdata_plan_m.enterprise_no%type,
                                  strWareHouseNo          in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_plan_m.owner_no%type,
                                  strPlanNo               in    fcdata_plan_m.plan_no%type,
                                  strRequstNo             in    fcdata_request_m.request_no%type,
                                  strUserId               in    fcdata_plan_m.rgst_name%type,
                                  strFcdataType           in    fcdata_plan_m.fcdata_type%type,
                                  dtRequestDate           in    fcdata_request_m.request_date%type,
                                  strResult               OUT    varchar2);
/**********************************************************************************************************
   luozhiling
   2015.10.17
   功能：储位检查只抓取储位的储位盘定位指示
***********************************************************************************************************/
    procedure P_InsertGetCellLocateDiect(strEnterPriseNo        in    fcdata_plan_m.enterprise_no%type,
                                  strWareHouseNo          in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_plan_m.owner_no%type,
                                  strPlanNo               in    fcdata_plan_m.plan_no%type,
                                  strRequstNo             in    fcdata_request_m.request_no%type,
                                  strUserId               in    fcdata_plan_m.rgst_name%type,
                                  strFcdataType           in    fcdata_plan_m.fcdata_type%type,
                                  dtRequestDate           in    fcdata_request_m.request_date%type,
                                  strResult               OUT    varchar2);
/**********************************************************************************************************
   luozhiling
   2015.4.1
   功能：写商品盘定位指示P_InsertGetCellLocateDiect
***********************************************************************************************************/
    procedure P_InsertArtLocateDiect(strEnterPriseNo        in    fcdata_plan_m.enterprise_no%type,
                                  strWareHouseNo          in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_plan_m.owner_no%type,
                                  strPlanNo               in    fcdata_plan_m.plan_no%type,
                                  strRequstNo             in    fcdata_request_m.request_no%type,
                                  strUserId               in    fcdata_plan_m.rgst_name%type,
                                  strFcdataType           in    fcdata_plan_m.fcdata_type%type,
                                  dtRequestDate           in    fcdata_request_m.request_date%type,
                                  strResult               OUT    varchar2);
/**********************************************************************************************************
   luozhiling
   2013.11.16
   功能：按盘点指示发盘点单,按通道发单
***********************************************************************************************************/
    procedure P_Fcdata_GetTask(strEnterPriseNo           in     fcdata_plan_m.enterprise_no%type,
                               strWareHouseNo            in     fcdata_plan_m.warehouse_no%type,--仓库编码
                               strOwnerNo                in     fcdata_plan_m.owner_no%type,
                               strUserId                 in     fcdata_plan_m.rgst_name%type,--作业人
                               strPaperUserId            in     fcdata_plan_m.rgst_name%type,--单据人
                               strRequstNo               in     fcdata_plan_m.plan_no%type,--需求单号
                               strResult                 OUT    varchar2);
/**********************************************************************************************************
    功能：校验储位的混载属性
    1、若该储位是不可混商品属性的储位，则不可放不同属性的商品；若储位是不可混载储位，只能存放同商品同属性
    2、该储位是否混货主储位，若可混，可存放多货主商品，若不可混，只能存放单货主商品

***********************************************************************************************************/
     procedure P_CheckMixOwnerArt(strEnterPriseNo         in    fcdata_plan_m.enterprise_no%type,
                                  strWareHouseNo          in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_plan_m.owner_no%type,
                                  strCheckNo              in    fcdata_plan_m.plan_no%type,--需求单号
                                  strCellNo               in    fcdata_check_d.cell_no%type,--盘点储位
                                  strArticleNo            in    fcdata_check_d.article_no%type,
                                  dtProduceDate           in    fcdata_check_d.produce_date%type,
                                  dtExpireDate            in    fcdata_check_d.expire_date%type,
                                  strQuality              in    fcdata_check_d.quality%type,
                                  strLotNo                in    fcdata_check_d.lot_no%type,
                                  strLabelNo              in    fcdata_check_d.label_no%type,
                                  strSubLabelNo           in    fcdata_check_d.sub_label_no%type,
                                  strStockType            in    fcdata_check_d.stock_type%type,
                                  strStockValue           in    fcdata_check_d.stock_value%type,
                                  strRsvBatch1            in    fcdata_check_d.rsv_batch1%type,
                                  strRsvBatch2            in    fcdata_check_d.rsv_batch2%type,
                                  strRsvBatch3            in    fcdata_check_d.rsv_batch3%type,
                                  strRsvBatch4            in    fcdata_check_d.rsv_batch4%type,
                                  strRsvBatch5            in    fcdata_check_d.rsv_batch5%type,
                                  strRsvBatch6            in    fcdata_check_d.rsv_batch6%type,
                                  strRsvBatch7            in    fcdata_check_d.rsv_batch7%type,
                                  strRsvBatch8            in    fcdata_check_d.rsv_batch8%type,
                                  strResult               OUT    varchar2);
/**********************************************************************************************************
   luozhiling
   2013.11.16
   功能：盘点回单,循环复盘
***********************************************************************************************************/
     procedure P_Fcdata_SaveCheck(strEnterPriseNo         in    fcdata_plan_m.enterprise_no%type,
                                  strWareHouseNo          in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_plan_m.owner_no%type,
                                  strOperateType          in    fcdata_check_m.check_type%type,--1:初盘；2：复盘；3三盘
                                  strUserId               in    fcdata_plan_m.rgst_name%type,--作业人
                                  strCheckNo              in    fcdata_plan_m.plan_no%type,--需求单号
                                  strCellNo               in    fcdata_check_d.cell_no%type,--盘点储位
                                  strArticleNo            in    fcdata_check_d.article_no%type,
                                  nPackingQty             in    fcdata_check_d.packing_qty%type,
                                  dtProduceDate           in    fcdata_check_d.produce_date%type,
                                  dtExpireDate            in    fcdata_check_d.expire_date%type,
                                  strQuality              in    fcdata_check_d.quality%type,
                                  strLotNo                in    fcdata_check_d.lot_no%type,
                                  nCheckQty               in    fcdata_check_d.check_qty%type,
                                  strLabelNo              in    fcdata_check_d.label_no%type,
                                  strSubLabelNo           in    fcdata_check_d.sub_label_no%type,
                                  strStockType            in    fcdata_check_d.stock_type%type,
                                  strStockValue           in    fcdata_check_d.stock_value%type,
                                  strRsvBatch1            in    fcdata_check_d.rsv_batch1%type,
                                  strRsvBatch2            in    fcdata_check_d.rsv_batch2%type,
                                  strRsvBatch3            in    fcdata_check_d.rsv_batch3%type,
                                  strRsvBatch4            in    fcdata_check_d.rsv_batch4%type,
                                  strRsvBatch5            in    fcdata_check_d.rsv_batch5%type,
                                  strRsvBatch6            in    fcdata_check_d.rsv_batch6%type,
                                  strRsvBatch7            in    fcdata_check_d.rsv_batch7%type,
                                  strRsvBatch8            in    fcdata_check_d.rsv_batch8%type,
                                  strAddFlag              in    fcdata_check_m.check_type%type,--1：按总量盘点；2：累加数量盘点
                                  strResult               OUT    varchar2);
/********************************************************************************************************
   创建人：luozhiling
   创建时间：2013.11.22
   功能说明：盘点回单确认
*********************************************************************************************************/
    procedure P_fcdata_comfireCheck(strEnterPriseNo       in    fcdata_plan_m.enterprise_no%type,
                                  strWareHouseNo          in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_plan_m.owner_no%type,
                                  strOperateType          in    fcdata_check_m.check_type%type,--1:初盘；2：复盘；3三盘
                                  strUserId               in    fcdata_plan_m.rgst_name%type,--作业人
                                  strCheckNo              in    fcdata_plan_m.plan_no%type,--盘点单号
                                  strResult               OUT    varchar2);
/************************************************************************************************
  创建人：luozhiling
  创建时间：2013.11.23
  功能说明：盘点结案
************************************************************************************************/
    /*procedure P_fcdata_closePlan(strWareHouseNo       in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_plan_m.owner_no%type,
                                  strPlanNo               in    fcdata_plan_m.plan_no%type,--盘点计划单号
                                  strUserId               in    fcdata_plan_m.rgst_name%type,--作业人
                                  strResult               OUT    varchar2);*/
/**********************************************************************************************************
   zhouhuan
   2014.4.17
   功能：写需求单号头档
   ***********************************************************************************************************/
   procedure P_Fcdata_InsertRequestM(strEnterPriseNo      in    fcdata_plan_m.enterprise_no%type,
                                  strWareHouseNo          in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_plan_m.owner_no%type,
                                  strUserId               in    fcdata_plan_m.rgst_name%type,
                                  strPlanNo               in    fcdata_plan_m.plan_no%type,--盘点计划单号
                                  strRequstNo             OUT   fcdata_request_m.request_no%type,--盘点需求单号
                                  strResult               OUT   varchar2);
/**********************************************************************************************************
   MM
   2014.4.17
   功能：写盘点单头档
   ***********************************************************************************************************/
   procedure P_Fcdata_Insertpdm(strEnterPriseNo           in    fcdata_check_m.enterprise_no%type,
                                strWareHouseNo            in    fcdata_check_m.warehouse_no%type,--仓库编码
                                strOwnerNo                in    fcdata_check_m.owner_no%type,
                                strUserId                 in    fcdata_check_m.rgst_name%type,
                                strPlanNo                 in    fcdata_check_m.plan_no%type,--盘点计划单号
                                strResult                 OUT   varchar2);
 /**********************************************************************************************************
   MM
   2014.4.17
   功能：写写盘点单明细档
   ***********************************************************************************************************/
   procedure P_Fcdata_Insertpdd(strEnterPriseNo           in    fcdata_check_m.enterprise_no%type,
                                strWareHouseNo            in    fcdata_check_m.warehouse_no%type,--仓库编码
                                strOwnerNo                in    fcdata_check_m.owner_no%type,
                                strPlanNo                 in    fcdata_check_m.plan_no%type,--盘点计划单号
                                strUserId                 in    fcdata_check_m.rgst_name%type,
                                strResult                 OUT   varchar2);
/**********************************************************************************************************
   MM
   2014.4.17
   功能：写差异单明细档
   ***********************************************************************************************************/
   procedure P_Fcdata_InsertdifferentD(strEnterPriseNo    in    fcdata_check_m.enterprise_no%type,
                                  strWareHouseNo          in    fcdata_check_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_check_m.owner_no%type,
                                  strDiffNo               in    fcdata_different_m.different_no%type,
                                  strcheckno              in    fcdata_check_m.check_no %type,
                                  strResult               OUT    varchar2);
   /**********************************************************************************************************
   MM
   2014.4.17
   功能：写差异单头档
   ***********************************************************************************************************/
   procedure P_Fcdata_Insertdifferentm(strEnterPriseNo    in    fcdata_check_m.enterprise_no%type,
                                  strWareHouseNo          in    fcdata_check_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_check_m.owner_no%type,
                                  strUserId               in    fcdata_check_m.rgst_name%type,
                                  strrequestno            in    fcdata_check_m.request_no %type,
                                  strcheckno              in    fcdata_check_m.check_no %type,
                                  strPlanNo               in   fcdata_check_m.plan_no%type,--盘点计划单号
                                  strDiffNo               OUT  fcdata_different_m.different_no%type,--盘点需求单号
                                  strResult               OUT    varchar2) ;


/**********************************************************************************************************
   zhouhuan
   2014.04.21
   功能：盘点发单--》切单-->写盘点单头档
***********************************************************************************************************/
    procedure P_InsertCheckM(strEnterPriseNo           in    fcdata_plan_m.enterprise_no%type,
                             strWareHouseNo            in    fcdata_plan_m.warehouse_no%type,--仓库编码
                             strOwnerNo                in    fcdata_plan_m.owner_no%type,
                             strUserId                 in    fcdata_plan_m.rgst_name%type,--作业人
                             strPaperUserId            in    fcdata_plan_m.rgst_name%type,--单据人
                             strDirectSerial           in   fcdata_check_direct.Direct_Serial%type,--指示序号
                             strCheckNo                OUT   fcdata_check_m.check_no%type,--盘点单号
                             strResult                 OUT    varchar2);

 /**********************************************************************************************************
   zhouhuan
   2014.04.21
   功能：盘点发单--》切单
***********************************************************************************************************/
  procedure P_InsertCheckD(strEnterPriseNo          in    fcdata_plan_m.enterprise_no%type,
                           strWareHouseNo           in    fcdata_plan_m.warehouse_no%type,--仓库编码
                           strOwnerNo               in    fcdata_plan_m.owner_no%type,--货主编号
                           strPaperUserid           in    fcdata_plan_m.rgst_name%type,--单据人
                           strCheckNo               in    fcdata_check_m.check_no%type,--盘点单号
                           strRowId                 in    fcdata_check_m.check_no%type,--行号
                           strOrderId               in    fcdata_check_m.check_no%type,--储位顺序
                           strSubOrderId            in    fcdata_check_m.check_no%type,--储位上商品顺序
                           strDirectSerial          in    fcdata_check_direct.Direct_Serial%type,--指示序号
                           strResult                OUT   varchar2);
 /**********************************************************************************************************
   luozhiling
   2015.10.17
   功能：储位检查时按储位写检查单的实时库存，目前这种方式只适用于RF的储位检查
***********************************************************************************************************/
  procedure P_InsertCellToCheckD(strEnterPriseNo          in    fcdata_plan_m.enterprise_no%type,
                           strWareHouseNo           in    fcdata_plan_m.warehouse_no%type,--仓库编码
                           strOwnerNo               in    fcdata_plan_m.owner_no%type,--货主编号
                           strCheckNo               in    fcdata_check_m.check_no%type,--盘点单号
                           strCellNo                in    fcdata_check_d.cell_no%type,
                           strUserId                in    fcdata_check_m.rgst_name%type,--盘点人
                           strResult                OUT   varchar2);
 /**********************************************************************************************************
   zhouhuan
   2014.04.21
   功能：定位指示转历史
***********************************************************************************************************/
   procedure P_CheckDirectToHty(strEnterPriseNo       in    fcdata_plan_m.enterprise_no%type,
                            strWareHouseNo            in    fcdata_check_direct.warehouse_no%type,--仓库编码
                            strOwnerNo                in    fcdata_check_direct.owner_no%type,--货主编号
                            strRequestNo              in    fcdata_check_direct.request_no%type,--需求单号
                            strResult                 out   varchar2);


/**********************************************************************************************************
   zhouhuan
   2014.05.6
   功能：盘点需求转历史
***********************************************************************************************************/
   procedure P_CheckRequestToHty(strEnterPriseNo      in    fcdata_plan_m.enterprise_no%type,
                            strWareHouseNo            in    fcdata_request_m.warehouse_no%type,--仓库编码
                            strOwnerNo                in    fcdata_request_m.owner_no%type,--货主编号
                            strRequestNo              in    fcdata_request_m.request_no%type,--需求单号
                            strResult                 out   varchar2);

   /**********************************************************************************************************
   JUN
   2014.05.6
   功能：更新盘点头档
   ***********************************************************************************************************/
   procedure P_Update_Fcdata_CheckM(strEnterPriseNo        in       fcdata_check_m.enterprise_no%type,
                                    strWareHouseNo         in       fcdata_check_m.warehouse_no%type,
                                    strOwnerNo             in       fcdata_check_m.owner_no%type,
                                    strCheckNo             in       fcdata_check_m.check_no%type,
                                    strUserId              in       fcdata_check_m.rgst_name%type,
                                    strCheckType           in       fcdata_check_m.check_type%type,
                                    strStatus              in       fcdata_check_m.status%type,
                                    strResult              out      varchar2);

   /**********************************************************************************************************
   JUN
   2014.05.6
   功能：更新盘点明细
   ***********************************************************************************************************/
  procedure P_Update_Fcdata_CheckD(strEnterPriseNo         in      fcdata_check_m.enterprise_no%type,
                                   strWareHouseNo          in      fcdata_check_d.warehouse_no%type,
                                    strOwnerNo             in      fcdata_check_d.owner_no%type,
                                    strCheckNo             in      fcdata_check_d.check_no%type,
                                    strCellNo              in      fcdata_check_d.cell_no%type,
                                    strCheckType           in      fcdata_check_d.check_type%type,
                                    strStatus              in      fcdata_check_d.status%type,
                                    strResult              out      varchar2);

   /*******************************************************************************************************
  创建人：huangb
  创建时间：2016.05.17
  功能说明：盘点单据转历史
  ********************************************************************************************************/
  procedure P_FC_InsertHTY(strEnterPriseNo in  fcdata_plan_m.enterprise_no%type,
                           strWareHouseNo  in  fcdata_plan_m.warehouse_no%type,--仓库编码
                           strOwnerNo      in  fcdata_plan_m.owner_no%type,
                           strPlanNo       in  fcdata_plan_m.plan_no%type,--盘点计划单号
                           strUserId       in  fcdata_plan_m.rgst_name%type,--作业人
                           strOutMsg       OUT varchar2);

  /*******************************************************************************************************
  创建人：huangb
  创建时间：2016.05.17
  功能说明：盘点差异以及盘点确认装历史 供接口调用
  ********************************************************************************************************/
  procedure P_FC_DiffAndPDHTYByInterface(strEnterpriseNo   in fcdata_different_mhty.enterprise_no%type, --企业编号
                                         strWareHouseNo    in fcdata_different_mhty.warehouse_no%type, --仓库编码
                                         strOwnerNo        in fcdata_different_mhty.owner_no%type,
                                         strReportUpSerial in fcdata_different_mhty.REPORT_UP_SERIAL%type, --上传序列号
                                         strOutMsg         out varchar2);

end PKOBJ_FCDATA;


/

