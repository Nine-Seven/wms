create package body PKLG_ILOCATE is
  /*Modify BY QZH AT 2016-5-24 增加拣货位（区）数量限制检查
   拣货位，拣货区的数量限制检查不再参考板数，
   按拣货位设置的最大量来判断 f_check_QTY
  */
  PickCell                      number := 1; --拣货位
  PickArea                      number := 2; --拣货区
  SaveArea_SameSKU_PickLine     number := 3; --按保拣线升序定有同品的保管区
  SaveArea_SameSKU_PickLine_Des number := 4; --按保拣线降序定有同品保管区
  SplitC_To_PickCell_B          number := 5; --拆箱进拆零拣货位
  AddToCell_PickLine            number := 6; --根据保拣线找不满板货位并入
  SaveArea_PickLine             number := 7; --按保拣线升序定保管区
  SaveArea_PickLine_Des         number := 8; --按保拣线降序定保管区
  --FamilyArea                    number := 9; --按类别到拣货区
  MinStockArea number := 10; --最小库存储位

  BadReturnArea  number := 20; --不良品退货区
  GoodReturnArea number := 21; --良品退货区

  ToSpecialArea number := 999; --异常区
  Merger_MergFirst CONSTANT cset_area_backup_d.merger_flag%type := 1; --先合并，再找空储位
  Merger_EmptyOnly CONSTANT cset_area_backup_d.merger_flag%type := 3; --只找空储位
  --Merger_EmptyFirst CONSTANT cset_area_backup_d.merger_flag%type := 2; --先空再合

  --进货定位程序入口
  procedure p_locate_main(strEnterPriseNo in varchar2,
                          strWareHouseNo  in varchar2, --仓库代码
                          strOwnerNo      in varchar2, --货主代码
                          strLocateNo     in varchar2, --定位号
                          strPrintFlag    in varchar2, --是否后台打印
                          strWorkNo       in varchar2, --员工代码
                          strPrintTaskNo  out varchar2, --打印任务号
                          strErrorMsg     out varchar2) is

    v_decSumQty         idata_locate_direct.article_qty%type; --容器商品汇总定位量
    v_strLocateCellNo   idata_instock_direct.cell_no%type; --定位储位
    v_strPreContainerNo idata_instock_direct.LABEL_NO%type; --上一个定位容器
    v_strPreLabeNo      idata_instock_direct.label_no%type; --上一个定位标签
    v_strAbnormalCellNo idata_instock_direct.cell_no%type; --异常储位
    v_blSplitCtoB       boolean := false;
    v_strPreArticleNo   idata_instock_direct.article_no%type; --上一个定位商品
  begin
    strErrorMsg := 'Y|';

    --获取异常储位
    begin
      select cell_no
        into v_strAbnormalCellNo
        from (select CDC.CELL_NO
                from cdef_defcell cdc, cdef_defarea cdd
               where cdc.enterprise_no = cdd.enterprise_no
                 and cdc.enterprise_no = strEnterPriseNo
                 and cdc.warehouse_no = cdd.warehouse_no
                 and cdc.ware_no = cdd.ware_no
                 and cdc.area_no = cdd.area_no
                 AND CDC.CELL_STATUS = '0'
                 AND CDC.CHECK_STATUS = 0
                 and cdd.AREA_ATTRIBUTE = '0'
                 and cdd.AREA_USETYPE = '5'
                 and cdd.warehouse_no = strWareHouseNo
               order by CDC.CELL_NO)
       where rownum <= 1;
    exception
      when no_data_found then
        strErrorMsg := 'N|[E21706]'; --获取异常区储位失败
        return;
    end;

    v_decSumQty         := 0;
    v_strPreContainerNo := 'N';
    v_strPreLabeNo      := 'N';
    v_strPreArticleNo   := 'N';
    --读取定位指示
    for v_cs_locate_direct in (select ild.*,
                                      sild.BARCODE,
                                      sild.LOT_NO,
                                      sild.PRODUCE_DATE,
                                      sild.EXPIRE_DATE,
                                      sild.sum_qty
                                 from bdef_defarticle bd,
                                      stock_article_info sai,
                                      (select ild.enterprise_no,
                                              ild.warehouse_no,
                                              ild.owner_no,
                                              ild.locate_no,
                                              ild.LABEL_NO,
                                              ild.article_no,
                                              ild.packing_qty,
                                              sai.BARCODE,
                                              sai.LOT_NO,
                                              sai.PRODUCE_DATE,
                                              sai.EXPIRE_DATE,
                                              sum(ild.article_qty) as sum_qty
                                         from stock_article_info  sai,
                                              idata_locate_direct ild
                                        where sai.enterprise_no =
                                              ild.enterprise_no
                                          and sai.article_no = ild.article_no
                                          and sai.article_id = ild.article_id
                                          and ild.enterprise_no =
                                              strEnterPriseNo
                                          and ild.warehouse_no =
                                              strWareHouseNo
                                          and ild.locate_no = strLocateNo
                                        group by ild.enterprise_no,
                                                 ild.warehouse_no,
                                                 ild.owner_no,
                                                 ild.locate_no,
                                                 ild.LABEL_NO,
                                                 ild.article_no,
                                                 ild.packing_qty,
                                                 sai.BARCODE,
                                                 sai.LOT_NO,
                                                 sai.PRODUCE_DATE,
                                                 sai.EXPIRE_DATE) sild,
                                      idata_locate_direct ild
                                where bd.enterprise_no = sai.enterprise_no
                                  and bd.enterprise_no = ild.enterprise_no
                                  and bd.enterprise_no = sild.enterprise_no
                                  and bd.enterprise_no = strEnterPriseNo
                                  and bd.article_no = ild.article_no
                                  and sai.article_no = ild.article_no
                                  and sai.article_id = ild.article_id
                                  and sai.expire_date = sild.expire_date
                                  and sai.produce_date = sild.produce_date
                                  and ild.warehouse_no = sild.warehouse_no
                                  and ild.owner_no = sild.owner_no
                                  and ild.locate_no = sild.locate_no
                                  and ild.LABEL_NO = sild.LABEL_NO
                                  and ild.article_no = sild.article_no
                                  and ild.packing_qty = sild.packing_qty
                                  and ild.warehouse_no = strWareHouseNo
                                  and ild.locate_no = strLocateNo
                                  and ild.status = '10'
                                ORDER BY CASE
                                           WHEN ild.OPERATE_TYPE = 'B' THEN
                                            0
                                           ELSE
                                            CASE
                                              WHEN ild.OPERATE_TYPE = 'C' THEN
                                               1
                                              ELSE
                                               2
                                            END
                                         END,
                                         ild.enterprise_no,
                                         ild.warehouse_no,
                                         ild.OWNER_NO,
                                         ild.LABEL_NO,
                                         ild.ARTICLE_NO,
                                         sai.BARCODE,
                                         sai.LOT_NO,
                                         sai.PRODUCE_DATE,
                                         sai.EXPIRE_DATE,
                                         ild.PACKING_QTY) loop
      strErrorMsg := 'Y|';

      if v_strPreLabeNo <> v_cs_locate_direct.LABEL_NO then

        --获取内部容器号
        begin
          select container_no
            into v_strPreContainerNo
            from stock_label_m
           where enterprise_no = strEnterPriseNo
             and warehouse_no = strWareHouseNo
             and label_no = v_cs_locate_direct.LABEL_NO
             and use_type = '0'
             and rownum <= 1;
        exception
          when no_data_found then
            strErrorMsg := 'N|[E21707]'; --找不到对应的标签
            return;
        end;

        pkobj_label.p_updt_label_status(strEnterPriseNo,
                                        strWareHouseNo,
                                        v_strPreContainerNo,
                                        strWorkNo,
                                        CLabelStatus.LOCATE_TOCELL,
                                        strErrorMsg);
        if substr(strErrorMsg, 1, 2) = 'N|' then
          return;
        end if;
      end if;
      /*如果没有定过位
        如果按物流箱定位且换新物流箱
      */
      if v_decSumQty = 0 or (v_cs_locate_direct.CONTAINER_LOCATE_FLAG = 0 and
         v_strPreLabeNo <> v_cs_locate_direct.LABEL_NO) or
         (v_cs_locate_direct.CONTAINER_LOCATE_FLAG = 1 and
         (v_strPreLabeNo <> v_cs_locate_direct.LABEL_NO or
         v_strPreArticleNo <> v_cs_locate_direct.article_no)) then

        v_strPreArticleNo := v_cs_locate_direct.article_no;
        v_strPreLabeNo    := v_cs_locate_direct.LABEL_NO;
        v_decSumQty       := v_cs_locate_direct.sum_qty;
        v_strLocateCellNo := 'N';
        --如果指定储位
        if v_cs_locate_direct.specify_CELL_NO is not null and
           v_cs_locate_direct.specify_CELL_NO <> 'N' then
          v_strLocateCellNo := v_cs_locate_direct.specify_CELL_NO;
        end if;

        --根据品质定位(暂预留)

        --客户别定位(暂预留)

        --正常定位
        if v_strLocateCellNo = 'N' then
          if v_cs_locate_direct.quality >= '0' and
             v_cs_locate_direct.QUALITY <= '9' then

            --if v_strPreArticleNo <> v_cs_locate_direct.article_no then
            p_locate_good(strEnterPriseNo,
                          strWareHouseNo,
                          strOwnerNo,
                          v_cs_locate_direct.Article_No,
                          v_cs_locate_direct.article_id,
                          v_cs_locate_direct.row_id,
                          v_cs_locate_direct.Operate_Type,
                          v_cs_locate_direct.Packing_Qty,
                          v_decSumQty,
                          strWorkNo,
                          v_blSplitCtoB,
                          v_strLocateCellNo,
                          strErrorMsg);
            if substr(strErrorMsg, 1, 2) = 'N|' then
              return;
            end if;
            --end if;
          else
            --不良品定位
            p_locate_bad(strEnterPriseNo,
                         strWareHouseNo,
                         strOwnerNo,
                         v_cs_locate_direct.Article_No,
                         v_cs_locate_direct.article_id,
                         v_cs_locate_direct.Packing_Qty,
                         v_decSumQty,
                         v_strLocateCellNo,
                         strErrorMsg);
            if substr(strErrorMsg, 1, 2) = 'N|' then
              return;
            end if;
          end if;
        end if;

        --如果都没有定着，获取异常储位
        if v_strLocateCellNo = 'N' then
          v_strLocateCellNo := v_strAbnormalCellNo;
        end if;
      end if;

      /*写后续指示*/
      --C拆B在循环内写指示和库存
      if v_blSplitCtoB = false then
        p_write_instockdirect(strEnterPriseNo,
                              strWareHouseNo,
                              v_cs_locate_direct.Row_id,
                              v_strLocateCellNo,
                              v_cs_locate_direct.ARTICLE_QTY,
                              strWorkNo,
                              strErrorMsg);
        if substr(strErrorMsg, 1, 1) = 'N' then
          return;
        end if;
      end if;
      v_decSumQty := v_decSumQty - v_cs_locate_direct.article_qty;
    end loop;

    /*    if v_strPreLabeNo <> 'N' then

      --获取内部容器号
      begin
        select container_no into v_strPreContainerNo from stock_label_m where warehouse_no=strWareHouseNo
               and label_no=v_strPreLabeNo and use_type='0';
      exception when no_data_found then
           strErrorMsg:='N|找不到对应的标签!';
           return;
      end;
      pkobj_label.p_updt_label_status(strWareHouseNo,
                                      v_strPreContainerNo,
                                      strWorkNo,
                                      CLabelStatus.LOCATE_TOCELL,
                                      strErrorMsg);
      if substr(strErrorMsg, 1, 2) = 'N|' then
        return;
      end if;
    end if;*/

  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_locate_main;

  --良品商品定位入口
  procedure p_locate_good(strEnterPriseNo in varchar2,
                          strWareHouseNo  in varchar2, --仓库代码
                          strOwnerNo      in varchar2, --货主代码
                          strArticleNo    in varchar2, --商品代码
                          nArticleID      in stock_content.article_id%type,
                          nDirectRow_ID   in idata_locate_direct.row_id%type,
                          strOperateType  in varchar2, --定位类型
                          nPackingQty     in number,
                          nLocateQty      in number,
                          strWorker       in bdef_defworker.worker_no%type,
                          blSplitCToB     in out boolean,
                          strLocateCellNo in out varchar2,
                          strErrorMsg     in out varchar2) is

    v_nExpiryDays BDEF_DEFARTICLE.Expiry_Days%type;
    v_strWareNo   CSET_CELL_ARTICLE.Ware_No%type;
    v_strAreaNo   CSET_CELL_ARTICLE.Area_No%type;
    v_AreaPick    CDEF_DEFAREA.AREA_PICK%TYPE; --是否拣货区
    v_strStockNo  Cdef_Defcell.Stock_No%type;
    v_strStockX   Cdef_Defcell.Stock_x%type;

    v_strSWareNo  CSET_CELL_ARTICLE.Ware_No%type;
    v_strSAreaNo  CSET_CELL_ARTICLE.Area_No%type;
    v_strSStockNo Cdef_Defcell.Stock_No%type;
    v_strSStockX  Cdef_Defcell.Stock_x%type;

    v_strLimitType   cdef_defarea.limit_type%type;
    v_nLimitRate     cdef_defarea.limit_rate%type;
    blSameSKU        boolean := false; --相同SKU
    v_strStockY      Cdef_Defcell.Stock_y%type;
    v_strBayX        CDEF_DEFCELL.Bay_x%type;
    v_strPickCellNo  CDEF_DEFCELL.Cell_No%type;
    v_nMaxQty        CSET_CELL_ARTICLE.Max_Qty_a%type;
    v_nKeepCells     CSET_CELL_ARTICLE.Keep_Cells%type;
    v_nPickKeepCells CSET_CELL_ARTICLE.Keep_Cells%type;
    v_nMergerFlag    CSET_AREA_BACKUP_D.MERGER_FLAG%type;
    v_nStockFlag     CSET_AREA_BACKUP_D.STOCK_FLAG%type;
    v_nFloorFlag     CSET_AREA_BACKUP_D.FLOOR_FLAG%type;
    v_nStockXFlag    CSET_AREA_BACKUP_D.STOCKX_FLAG%type;
    v_nBayFlag       CSET_AREA_BACKUP_D.BAY_FLAG%type;
    v_nSortFlag      CSET_AREA_BACKUP_D.SORT_FLAG%type;

    v_strCPickCellNo cset_cell_article.cell_no%type;
    v_nCMaxQty       cset_cell_article.max_qty_a%type;
    v_nCKeepCells    cset_cell_article.keep_cells%type;
    v_strBPickCellNo cset_cell_article.cell_no%type;
    v_nBMaxQty       cset_cell_article.max_qty_a%type;
    v_nBKeepCells    cset_cell_article.keep_cells%type;
    v_nPickLine      cset_cell_article.line_id%type;
    v_nPickCellCount number;

    v_strTempPickCellNo cset_cell_article.cell_no%type;
    v_nTempMaxQty       cset_cell_article.max_qty_a%type;
    v_nTempKeepCells    cset_cell_article.keep_cells%type;

    v_strSQL             varchar2(4096);
    v_cs_get_area_backup cv_type;

  begin
    strErrorMsg := 'Y|';

    PKLG_PUBLOCATE.p_get_PickCell(strEnterPriseNo,
                                  strWareHouseNo,
                                  strOwnerNo,
                                  strArticleNo,
                                  v_strCPickCellNo,
                                  v_nCMaxQty,
                                  v_nCKeepCells,
                                  v_strBPickCellNo,
                                  v_nBMaxQty,
                                  v_nBKeepCells,
                                  v_nPickLine,
                                  v_nPickCellCount,
                                  strErrorMsg);
    if substr(strErrorMsg, 1, 1) = 'N' then
      return;
    end if;

    --拆零定位
    if strOperateType = 'B' then
      if v_strBPickCellNo = 'N' then
        return;
      end if;
      p_locate_pickcell_B(strEnterPriseNo,
                          strWareHouseNo,
                          strOwnerNo,
                          strArticleNo,
                          nPackingQty,
                          nArticleID,
                          nLocateQty,
                          v_strBPickCellNo,
                          v_nBMaxQty,
                          v_nBKeepCells,
                          strLocateCellNo,
                          strErrorMsg);
      if substr(strErrorMsg, 1, 1) = 'Y' then
        return;
      end if;
    else
      if v_nPickCellCount > 0 and v_strCPickCellNo <> 'N' then
        v_strTempPickCellNo := v_strCPickCellNo;
        v_nTempMaxQty       := v_nCMaxQty;
        v_nTempKeepCells    := v_nCKeepCells;
      else
        v_strTempPickCellNo := v_strBPickCellNo;
        v_nTempMaxQty       := v_nBMaxQty;
        v_nTempKeepCells    := v_nBKeepCells;
      end if;

      --定位整箱和板
      for curLocateRule in (select *
                              from (select *
                                      from wms_defstrategy_d d
                                     where d.STRATEGY_TYPE = 'I'
                                          --Add BY QZH AT 2016-7-11
                                       and d.limmit_quality = '0'
                                       and exists (select 'x'
                                              from bdef_defarticle bda
                                             where bda.enterprise_no =
                                                   strEnterPriseNo
                                               and bda.article_no =
                                                   strArticleNo
                                               and bda.I_STRATEGY =
                                                   d.STRATEGY_ID)
                                       and not exists
                                     (select 'x'
                                              from bdef_warehouse_article bwa
                                             where bwa.enterprise_no =
                                                   strEnterPriseNo
                                               and bwa.warehouse_no =
                                                   strWareHouseNo
                                               and bwa.article_no =
                                                   strArticleNo
                                               and bwa.i_strategy =
                                                   d.strategy_id)
                                    union
                                    select *
                                      from wms_defstrategy_d d
                                     where d.STRATEGY_TYPE = 'I'
                                          --Add BY QZH AT 2016-7-11
                                       and d.limmit_quality = '0'
                                       and exists
                                     (select 'x'
                                              from bdef_warehouse_article bwa
                                             where bwa.enterprise_no =
                                                   strEnterPriseNo
                                               and bwa.warehouse_no =
                                                   strWareHouseNo
                                               and bwa.article_no =
                                                   strArticleNo
                                               and bwa.i_strategy =
                                                   d.strategy_id))
                             order by RULE_ORDER) loop

        blSplitCToB := false;
        --拣货位
        if curLocateRule.Rule_Id = PickCell and v_nPickCellCount > 0 then
          p_locate_pickcell_C(strEnterPriseNo,
                              strWareHouseNo,
                              strOwnerNo,
                              strArticleNo,
                              nPackingQty,
                              nArticleID,
                              nLocateQty,
                              v_strTempPickCellNo,
                              v_nTempMaxQty,
                              v_nTempKeepCells,
                              curLocateRule.Rule_Order,
                              strLocateCellNo,
                              strErrorMsg);
          if substr(strErrorMsg, 1, 1) = 'Y' then
            return;
          end if;
        end if;

        --拣货区
        if curLocateRule.Rule_Id = PickArea and v_nPickCellCount > 0 then
          p_locate_pickArea(strEnterPriseNo,
                            strWareHouseNo,
                            strOwnerNo,
                            strArticleNo,
                            nPackingQty,
                            nArticleID,
                            strOperateType,
                            nLocateQty,
                            v_strTempPickCellNo,
                            v_nTempMaxQty,
                            v_nTempKeepCells,
                            curLocateRule.Rule_Order,
                            strLocateCellNo,
                            strErrorMsg);
          if substr(strErrorMsg, 1, 1) = 'Y' then
            return;
          end if;
        end if;

        --按保拣线升（降）序定（有同品）保管区
        if curLocateRule.Rule_Id in
           (SaveArea_SameSKU_PickLine,
            SaveArea_SameSKU_PickLine_Des,
            SaveArea_PickLine,
            SaveArea_PickLine_Des) and v_nPickCellCount > 0 then

          if curLocateRule.Rule_Id in
             (SaveArea_SameSKU_PickLine, SaveArea_SameSKU_PickLine_Des) then
            blSameSKU := true;
          else
            blSameSKU := false;
          end if;

          v_strSQL := f_get_PickLine(strEnterPriseNo,
                                     strWareHouseNo,
                                     strOwnerNo,
                                     strArticleNo,
                                     v_strTempPickCellNo,
                                     v_nPickLine,
                                     curLocateRule.Rule_Id);

          open v_cs_get_area_backup for v_strSQL;
          loop
            fetch v_cs_get_area_backup
              into v_nExpiryDays,
                   v_strWareNo,
                   v_strAreaNo,
                   v_AreaPick,
                   v_strStockNo,
                   v_strStockX,
                   v_strStockY,
                   v_strBayX,
                   v_strPickCellNo,
                   v_strSWareNo,
                   v_strSAreaNo,
                   v_strSStockNo,
                   v_strSStockX,
                   v_nKeepCells,
                   v_strLimitType,
                   v_nLimitRate,
                   v_nMergerFlag,
                   v_nStockFlag,
                   v_nFloorFlag,
                   v_nStockXFlag,
                   v_nBayFlag,
                   v_nSortFlag;
            EXIT WHEN v_cs_get_area_backup%NOTFOUND;
            v_nMaxQty        := v_nTempMaxQty;
            v_nPickKeepCells := v_nTempKeepCells;
            --拣货区
            --if v_strWareNo = v_strSWareNo and v_strAreaNo = v_strSAreaNo then
            if v_AreaPick = 1 then
              goto next_v_cs_get_area_backup;
            end if;

            --按比率限制
            if v_strLimitType = '1' then
              if f_check_LimitRate(strEnterPriseNo,
                                   strArticleNo,
                                   nPackingQty,
                                   nLocateQty,
                                   v_nLimitRate) = false then
                p_write_short_log(strEnterPriseNo,
                                  strWareHouseNo,
                                  'N',
                                  strOwnerNo,
                                  'N',
                                  strArticleNo,
                                  nArticleID,
                                  nPackingQty,
                                  nLocateQTY,
                                  strOperateType,
                                  '判断是否可入（按入库比率）:' || v_strSWareNo ||
                                  v_strSAreaNo || v_strSStockNo);
                goto next_v_cs_get_area_backup;
              end if;
            end if;

            --按箱数限制
            if v_strLimitType = '2' then
              if f_check_LimitCase(nPackingQty, nLocateQty, v_nLimitRate) =
                 false then
                p_write_short_log(strEnterPriseNo,
                                  strWareHouseNo,
                                  'N',
                                  strOwnerNo,
                                  'N',
                                  strArticleNo,
                                  nArticleID,
                                  nPackingQty,
                                  nLocateQTY,
                                  strOperateType,
                                  '判断是否可入（按箱数限制）:' || v_strSWareNo ||
                                  v_strSAreaNo || v_strSStockNo);
                goto next_v_cs_get_area_backup;
              end if;
            end if;

            --保管区
            p_SaveCellByPickLine(strEnterPriseNo,
                                 strWareHouseNo,
                                 strOwnerNo,
                                 strArticleNo,
                                 nArticleID,
                                 nPackingQty,
                                 blSameSKU,
                                 --strOperateType,
                                 v_strSWareNo,
                                 v_strSAreaNo,
                                 v_strSStockNo,
                                 v_strStockNo,
                                 v_strStockX,
                                 v_strStockY,
                                 v_strBayX,
                                 --v_strPickCellNo,
                                 nLocateQty,
                                 --v_nMaxQty,
                                 v_nKeepCells,
                                 v_nMergerFlag,
                                 v_nStockFlag,
                                 v_nFloorFlag,
                                 v_nStockXFlag,
                                 v_nBayFlag,
                                 v_nSortFlag,
                                 curLocateRule.Rule_Order,
                                 strLocateCellNo,
                                 strErrorMsg);

            if substr(strErrorMsg, 1, 2) = 'N|' then
              goto next_v_cs_get_area_backup;
            end if;

            if strLocateCellNo <> 'N' then
              return;
            end if;

            <<next_v_cs_get_area_backup>>
            null;
          end loop;
          close v_cs_get_area_backup;
        end if;

        --根据保拣线找不满板货位并入
        if curLocateRule.Rule_Id = AddToCell_PickLine and
           v_nPickCellCount > 0 then

          v_strSQL := f_get_PickLine(strEnterPriseNo,
                                     strWareHouseNo,
                                     strOwnerNo,
                                     strArticleNo,
                                     v_strTempPickCellNo,
                                     v_nPickLine,
                                     curLocateRule.Rule_Id);

          open v_cs_get_area_backup for v_strSQL;
          loop
            fetch v_cs_get_area_backup
              into v_nExpiryDays,
                   v_strWareNo,
                   v_strAreaNo,
                   v_AreaPick,
                   v_strStockNo,
                   v_strStockX,
                   v_strStockY,
                   v_strBayX,
                   v_strPickCellNo,
                   v_strSWareNo,
                   v_strSAreaNo,
                   v_strSStockNo,
                   v_strSStockX,
                   v_nKeepCells,
                   v_strLimitType,
                   v_nLimitRate,
                   v_nMergerFlag,
                   v_nStockFlag,
                   v_nFloorFlag,
                   v_nStockXFlag,
                   v_nBayFlag,
                   v_nSortFlag;
            EXIT WHEN v_cs_get_area_backup%NOTFOUND;

            v_nMaxQty        := v_nTempMaxQty;
            v_nPickKeepCells := v_nTempKeepCells;
            v_nMergerFlag    := Merger_MergFirst;
            --拣货区
            --if v_strWareNo = v_strSWareNo and v_strAreaNo = v_strSAreaNo then
            if v_AreaPick = '1' then
              p_PickCellByPickLine(strEnterPriseNo,
                                   strWareHouseNo,
                                   strOwnerNo,
                                   strArticleNo,
                                   nArticleID,
                                   nPackingQty,
                                   --strOperateType,
                                   v_strSWareNo,
                                   v_strSAreaNo,
                                   v_strSStockNo,
                                   v_strStockNo,
                                   v_strStockX,
                                   v_strStockY,
                                   v_strBayX,
                                   --v_strPickCellNo,
                                   nLocateQty,
                                   --v_nMaxQty,
                                   v_nKeepCells,
                                   v_nMergerFlag,
                                   v_nStockFlag,
                                   v_nFloorFlag,
                                   v_nStockXFlag,
                                   v_nBayFlag,
                                   v_nSortFlag,
                                   curLocateRule.Rule_Order,
                                   strLocateCellNo,
                                   strErrorMsg);

            else
              --保管区
              p_SaveCellByPickLine(strEnterPriseNo,
                                   strWareHouseNo,
                                   strOwnerNo,
                                   strArticleNo,
                                   nArticleID,
                                   nPackingQty,
                                   blSameSKU,
                                   --strOperateType,
                                   v_strSWareNo,
                                   v_strSAreaNo,
                                   v_strSStockNo,
                                   v_strStockNo,
                                   v_strStockX,
                                   v_strStockY,
                                   v_strBayX,
                                   --v_strPickCellNo,
                                   nLocateQty,
                                   --v_nMaxQty,
                                   v_nKeepCells,
                                   v_nMergerFlag,
                                   v_nStockFlag,
                                   v_nFloorFlag,
                                   v_nStockXFlag,
                                   v_nBayFlag,
                                   v_nSortFlag,
                                   curLocateRule.Rule_Order,
                                   strLocateCellNo,
                                   strErrorMsg);
            end if;

            if substr(strErrorMsg, 1, 2) = 'N|' then
              goto next_v_cs_get_area_backup;
            end if;

            if strLocateCellNo <> 'N' then
              return;
            end if;

            <<next_v_cs_get_area_backup>>
            null;
          end loop;
          close v_cs_get_area_backup;
          if substr(strErrorMsg, 1, 1) = 'Y' then
            return;
          end if;
        end if;

        --拆箱进拆零拣货位
        if curLocateRule.Rule_Id = SplitC_To_PickCell_B and
           v_nPickCellCount > 0 then
          blSplitCToB := true;
          p_locate_SplitCtoB(strEnterPriseNo,
                             strWareHouseNo,
                             strOwnerNo,
                             strArticleNo,
                             nDirectRow_ID,
                             nLocateQty,
                             v_strBPickCellNo,
                             v_nBMaxQty,
                             v_nBKeepCells,
                             strWorker,
                             strLocateCellNo,
                             strErrorMsg);
          if substr(strErrorMsg, 1, 1) = 'Y' then
            return;
          end if;
        end if;

        --找最小库存的储位
        if curLocateRule.Rule_Id = MinStockArea and v_nPickCellCount > 0 then
          p_locate_MinStockArea(strEnterPriseNo,
                                strWareHouseNo,
                                strOwnerNo,
                                strArticleNo,
                                nPackingQty,
                                nArticleID,
                                nLocateQty,
                                curLocateRule.Rule_Order,
                                strLocateCellNo,
                                strErrorMsg);
          if substr(strErrorMsg, 1, 1) = 'Y' then
            return;
          end if;
        end if;

        --异常区
        if curLocateRule.Rule_Id = ToSpecialArea then
          p_locate_special(strEnterPriseNo,
                           strWareHouseNo,
                           strOwnerNo,
                           strArticleNo,
                           nArticleID,
                           nPackingQty,
                           curLocateRule.Rule_Order,
                           nLocateQty,
                           strLocateCellNo,
                           strErrorMsg);
          if substr(strErrorMsg, 1, 1) = 'Y' then
            return;
          end if;
        end if;

      end loop;
    end if;
  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_locate_good;

  --不良品商品定位入口
  procedure p_locate_bad(strEnterPriseNo in varchar2,
                         strWareHouseNo  in varchar2, --仓库代码
                         strOwnerNo      in varchar2, --货主代码
                         strArticleNo    in varchar2, --商品代码
                         nArticleID      in stock_content.article_id%type,
                         nPackingQty     in number,
                         nLocateQty      in number,
                         strLocateCellNo in out varchar2,
                         strErrorMsg     in out varchar2) is

  begin
    strErrorMsg := 'Y|';

    for curLocateRule in (select *
                            from (select *
                                    from wms_defstrategy_d d
                                   where d.STRATEGY_TYPE = 'I'
                                        --Add BY QZH AT 2016-7-11
                                     and d.limmit_quality = 'A'
                                     and exists
                                   (select 'x'
                                            from bdef_defarticle bda
                                           where bda.enterprise_no =
                                                 strEnterPriseNo
                                             and bda.article_no = strArticleNo
                                             and bda.I_STRATEGY =
                                                 d.STRATEGY_ID)
                                     and not exists
                                   (select 'x'
                                            from bdef_warehouse_article bwa
                                           where bwa.enterprise_no =
                                                 strEnterPriseNo
                                             and bwa.warehouse_no =
                                                 strWareHouseNo
                                             and bwa.article_no = strArticleNo
                                             and bwa.i_strategy =
                                                 d.strategy_id)
                                  union
                                  select *
                                    from wms_defstrategy_d d
                                   where d.STRATEGY_TYPE = 'I'
                                        --Add BY QZH AT 2016-7-11
                                     and d.limmit_quality = 'A'
                                     and exists
                                   (select 'x'
                                            from bdef_warehouse_article bwa
                                           where bwa.enterprise_no =
                                                 strEnterPriseNo
                                             and bwa.warehouse_no =
                                                 strWareHouseNo
                                             and bwa.article_no = strArticleNo
                                             and bwa.i_strategy =
                                                 d.strategy_id))
                           order by RULE_ORDER) loop

      p_locate_special(strEnterPriseNo,
                       strWareHouseNo,
                       strOwnerNo,
                       strArticleNo,
                       nArticleID,
                       nPackingQty,
                       curLocateRule.Rule_Order,
                       nLocateQty,
                       strLocateCellNo,
                       strErrorMsg);
      if substr(strErrorMsg, 1, 1) = 'Y' then
        return;
      end if;
    end loop;

  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_locate_bad;

  --获取C型拣货位数量
  function f_GetCPickNum(strEnterPriseNo in cdef_defware.enterprise_no%type,
                         strWareHouseNo  in cdef_defware.warehouse_no%type,
                         strArticleNo    in bdef_defarticle.article_no%type)
    return integer is
    v_Count integer := 0;
  begin
    select count(1)
      into v_Count
      from CSET_CELL_ARTICLE cca
     where cca.enterprise_no = strEnterPriseNo
       and cca.warehouse_no = strWareHouseNo
       and cca.article_no = strArticleNo
       and cca.PICK_TYPE = 'C';
    return v_Count;
  exception
    when others then
      return v_Count;
  end;

  --判断是否可入（按入库比率）
  function f_check_LimitRate(strEnterPriseNo in bdef_defarticle.enterprise_no%type,
                             strArticleNo    in bdef_defarticle.article_no%type,
                             nPackingQTY     in bdef_article_packing.packing_qty%type,
                             nLocateQTY      in number,
                             nLimitRate      in cdef_defarea.limit_rate%type)
    return boolean is
    v_Result     boolean := false;
    v_ArticlePal bdef_article_packing.qpalette%type; --商品堆叠
  begin

    --无限制
    if nLimitRate <= 0 then
      v_Result := true;
      return v_Result;
    end if;

    --商品堆叠
    begin
      SELECT NVL(bwp.qpalette, bap.qpalette) qpalette
        into v_ArticlePal
        FROM bdef_article_packing bap, bdef_warehouse_packing bwp
       where bap.enterprise_no = bwp.enterprise_no(+)
         and bap.enterprise_no = strEnterPriseNo
         and bap.article_no = bwp.ARTICLE_NO(+)
         AND bap.packing_qty = bwp.packing_qty(+)
         and bap.article_no = strArticleNo
         and bap.packing_qty = nPackingQTY;
      /*      select bap.qpalette
       into v_ArticlePal
       from bdef_article_packing bap
      where bap.article_no = strArticleNo
        and bap.packing_qty = nPackingQTY;*/
    exception
      when no_data_found then
        v_ArticlePal := 999999;
        --  return v_Result;
    end;
    --资料错误
    if v_ArticlePal = 0 then
      return v_Result;
    end if;

    if round(nLocateQTY / v_ArticlePal, 4) * 100 >= nLimitRate then
      v_Result := true;
    end if;

    return v_Result;
  exception
    when others then
      return false;
  end;

  --判断是否可入（按入库箱数）
  function f_check_LimitCase(nPackingQTY in bdef_article_packing.packing_qty%type,
                             nLocateQTY  in number,
                             nLimitCase  in cdef_defarea.limit_rate%type)
    return boolean is
    v_Result boolean := false;
  begin

    --无限制
    if nLimitCase <= 0 then
      v_Result := true;
      return v_Result;
    end if;

    --商品箱数
    if nPackingQTY > 1 then
      if floor(nLocateQTY / nPackingQTY) >= nLimitCase then
        v_Result := true;
        return v_Result;
      end if;
    end if;

    return v_Result;
  exception
    when others then
      return false;
  end;

  --定到箱型拣货位
  procedure p_locate_pickcell_C(strEnterPriseNo in varchar2,
                                strWareHouseNo  in varchar2, --仓库代码
                                strOwnerNo      in varchar2, --货主代码
                                strArticleNo    in varchar2, --商品代码
                                nPackingQTY     in bdef_article_packing.packing_qty%type,
                                nArticleID      in number,
                                nLocateQty      in number, --定位数量
                                strPickCellNo   in cset_cell_article.cell_no%type,
                                nCellMaxQTY     in cset_cell_article.max_qty_a%type,
                                nMaxCellUse     in cset_cell_article.keep_cells%type,
                                nRuleOrder      in number, --规则顺序
                                strLocateCellNo out varchar2,
                                strErrorMsg     out varchar2) is

    v_ArticleGroupNo bdef_defarticle.group_no%type;
    v_ArticleWeight  bdef_defarticle.unit_weight%type;
    v_Count          integer := 0;
    v_nUsedCells     cset_cell_article.keep_cells%type := 0;
  begin
    strErrorMsg     := 'N|';
    strLocateCellNo := 'N';

    --查找商品拣货位信息
    begin
      select bda.unit_weight, bda.group_no
        into v_ArticleWeight, v_ArticleGroupNo
        from bdef_defarticle bda
       where bda.enterprise_no = strEnterPriseNo
         and bda.article_no = strArticleNo;
    exception
      when no_data_found then
        strErrorMsg := 'N|[商品:' || strArticleNo || '没有商品信息！]';
        return;
    end;

    for curLocateRule in (select *
                            from wms_defstrategy_d d
                           where d.strategy_type = 'I'
                             and d.RULE_ORDER = nRuleOrder
                             and exists
                           (select 'x'
                                    from bdef_defarticle bda
                                   where bda.enterprise_no = strEnterPriseNo
                                     and bda.article_no = strArticleNo
                                     and bda.I_STRATEGY = d.STRATEGY_ID)) loop

      --数量限制
      if curLocateRule.Limmit_Maxqty = '1' then
        --Modify BY QZH AT 2016-5-24 拣货位的最大量
        if nLocateQty > nCellMaxQTY then
          p_write_short_log(strEnterPriseNo,
                            strWareHouseNo,
                            'N',
                            strOwnerNo,
                            'N',
                            strArticleNo,
                            nArticleID,
                            nPackingQty,
                            nLocateQTY,
                            'N',
                            '超过箱型拣货位的最大量:' || strPickCellNo || ',' ||
                            nCellMaxQTY);
          return;
        end if;
      end if;

      for curLocateCell in (select cdc.warehouse_no, cdc.cell_no
                              from cdef_defcell cdc, bdef_defowner o
                             where cdc.enterprise_no = strEnterPriseNo
                               and cdc.cell_status = '0'
                               and cdc.check_status = '0'
                               and cdc.WAREHOUSE_NO = strWareHouseNo
                               and cdc.cell_no like strPickCellNo || '%'
                               and o.enterprise_no = strEnterPriseNo
                               and o.owner_no = strOwnerNo
                               and ((o.fixedcell_flag = 0 and
                                   (cdc.mix_owner = 1 or
                                   (cdc.mix_owner = 0 and not exists
                                    (select 'x'
                                          from stock_content sc
                                         where sc.enterprise_no =
                                               cdc.enterprise_no
                                           and sc.warehouse_no =
                                               cdc.warehouse_no
                                           and sc.cell_no = cdc.cell_no
                                           and sc.owner_no <> strOwnerNo)))) or
                                   (o.fixedcell_flag = 1 and exists
                                    (select 'x'
                                        from cset_owner_cell coc
                                       where coc.enterprise_no =
                                             cdc.enterprise_no
                                         and coc.warehouse_no =
                                             cdc.warehouse_no
                                         and coc.cell_no = cdc.cell_no
                                         and coc.owner_no = strOwnerNo)))) loop

        --加锁
        update cdef_defcell cdc
           set cdc.cell_status = cdc.cell_status
         where cdc.enterprise_no = strEnterPriseNo
           and cdc.warehouse_no = curLocateCell.Warehouse_No
           and cdc.cell_no = curLocateCell.Cell_No;

        if curLocateRule.Limmit_Celluse = '1' then
          v_nUsedCells := f_check_UseCells(strEnterPriseNo,
                                           strWareHouseNo,
                                           strArticleNo,
                                           curLocateCell.Cell_No);
          --已超过可用储位数
          if nMaxCellUse > 0 and v_nUsedCells > nMaxCellUse then
            p_write_short_log(strEnterPriseNo,
                              strWareHouseNo,
                              'N',
                              strOwnerNo,
                              curLocateCell.Cell_No,
                              strArticleNo,
                              nArticleID,
                              nPackingQty,
                              nLocateQTY,
                              'N',
                              '检查已使用的储位数:' || v_nUsedCells || '>' ||
                              nMaxCellUse);
            exit;
          end if;

          if v_nUsedCells = nMaxCellUse and nMaxCellUse > 0 then
            select count(distinct cell_no)
              into v_Count
              from stock_content
             where enterprise_no = strEnterPriseNo
               and article_no = strArticleNo
               and qty + instock_qty > 0
               and WAREHOUSE_NO = strWareHouseNo
               and cell_no = curLocateCell.Cell_No;

            if v_Count <= 0 then
              p_write_short_log(strEnterPriseNo,
                                strWareHouseNo,
                                'N',
                                strOwnerNo,
                                curLocateCell.Cell_No,
                                strArticleNo,
                                nArticleID,
                                nPackingQty,
                                nLocateQTY,
                                'N',
                                '检查已使用的储位数:' || v_nUsedCells || '=' ||
                                nMaxCellUse);
              exit;
            end if;
          end if;
        end if;

        --数量限制
        if curLocateRule.Limmit_Maxqty = '1' then
          if f_check_QTY(strEnterPriseNo,
                         strWareHouseNo,
                         --strOwnerNo,
                         strArticleNo,
                         nCellMaxQTY,
                         nLocateQty,
                         curLocateCell.Cell_No) = false then
            goto next_Cell_No;
          end if;
        end if;

        --混批限制
        if curLocateRule.Limmit_Mixbatch = '1' then
          if f_check_ArticleBatch(strEnterPriseNo,
                                  strWareHouseNo,
                                  strOwnerNo,
                                  strArticleNo,
                                  nArticleID,
                                  curLocateCell.Cell_No) = false then
            goto next_Cell_No;
          end if;
        end if;

        --混载
        if curLocateRule.Limmit_Mixarticle = '1' then
          if f_check_ArticleMix(strEnterPriseNo,
                                strWareHouseNo,
                                strOwnerNo,
                                strArticleNo,
                                nArticleID,
                                curLocateCell.Cell_No) = false then
            goto next_Cell_No;
          end if;
        end if;

        --箱数
        if curLocateRule.Limmit_Maxcase = '1' then
          if f_check_CaseQTY(strEnterPriseNo,
                             strWareHouseNo,
                             --strOwnerNo,
                             --strArticleNo,
                             nPackingQTY,
                             nLocateQty,
                             curLocateCell.Cell_No) = false then
            goto next_Cell_No;
          end if;
        end if;

        --重量限制
        if curLocateRule.Limmit_Maxweight = '1' then
          if f_check_Weight(strEnterPriseNo,
                            strWareHouseNo,
                            --strOwnerNo,
                            strArticleNo,
                            nLocateQty,
                            curLocateCell.Cell_No) = false then
            goto next_Cell_No;
          end if;
        end if;

        --限制类别
        if curLocateRule.Limmit_Maxgroupno = '1' then
          if f_check_Group(strEnterPriseNo,
                           strWareHouseNo,
                           --strOwnerNo,
                           strArticleNo,
                           curLocateCell.Cell_No) = false then
            goto next_Cell_No;
          end if;
        end if;

        strLocateCellNo := curLocateCell.Cell_No;
        strErrorMsg     := 'Y|';
        exit;
        <<next_Cell_No>>
        null;
      end loop;
    end loop;

  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_locate_pickcell_C;

  --拆箱入零散拣货位
  procedure p_locate_SplitCtoB(strEnterPriseNo in cdef_defware.enterprise_no%type,
                               strWareHouseNo  in cdef_defware.warehouse_no%type, --仓库代码
                               strOwnerNo      in bdef_defowner.owner_no%type, --货主代码
                               strArticleNo    in bdef_defarticle.article_no%type, --商品代码
                               nDirectRow_ID   in idata_locate_direct.row_id%type,
                               nLocateQty      in number, --定位数量
                               strPickCellNo   in cset_cell_article.cell_no%type,
                               nCellMaxQTY     in cset_cell_article.max_qty_a%type,
                               nMaxCellUse     in cset_cell_article.keep_cells%type,
                               strWorkNo       in bdef_defworker.worker_no%type,
                               strLocateCellNo out cdef_defcell.cell_no%type,
                               strErrorMsg     out varchar2) is

    v_Count integer := 0;
    --v_StockWeight    bdef_article_packing.packing_weight%type;
    v_nTotalLocateQty number := nLocateQty;
    v_nLocateQTY      number := 0;
    v_nUsedCells      cset_cell_article.keep_cells%type := 0;
  begin
    strErrorMsg     := 'N|';
    strLocateCellNo := 'N';

    --查找商品拣货位信息
    if strPickCellNo = 'N' then
      strErrorMsg := 'N|[商品:' || strArticleNo || '没有B' || '型拣货位！]';
      return;
    end if;

    while v_nTotalLocateQty > 0 loop
      if v_nTotalLocateQty > nCellMaxQTY and nCellMaxQTY > 0 then
        v_nLocateQTY := nCellMaxQTY;
      else
        v_nLocateQTY := v_nTotalLocateQty;
      end if;

      for curLocateCell in (select cdc.warehouse_no, cdc.cell_no
                              from cdef_defcell cdc, bdef_defowner o
                             where cdc.enterprise_no = strEnterPriseNo
                               and cdc.cell_status = '0'
                               and cdc.check_status = '0'
                               and cdc.WAREHOUSE_NO = strWareHouseNo
                               and cdc.cell_no like strPickCellNo || '%'
                               and not exists
                             (select 'x'
                                      from stock_content sc
                                     where sc.enterprise_no =
                                           cdc.enterprise_no
                                       and sc.cell_no = cdc.cell_no
                                       and sc.WAREHOUSE_NO = cdc.WAREHOUSE_NO
                                       and sc.qty > 0)
                               and o.enterprise_no = strEnterPriseNo
                               and o.owner_no = strOwnerNo
                               and ((o.fixedcell_flag = 0 and
                                   (cdc.mix_owner = 1 or
                                   (cdc.mix_owner = 0 and not exists
                                    (select 'x'
                                          from stock_content sc
                                         where sc.enterprise_no =
                                               cdc.enterprise_no
                                           and sc.warehouse_no =
                                               cdc.warehouse_no
                                           and sc.cell_no = cdc.cell_no
                                           and sc.owner_no <> strOwnerNo)))) or
                                   (o.fixedcell_flag = 1 and exists
                                    (select 'x'
                                        from cset_owner_cell coc
                                       where coc.enterprise_no =
                                             cdc.enterprise_no
                                         and coc.warehouse_no =
                                             cdc.warehouse_no
                                         and coc.cell_no = cdc.cell_no
                                         and coc.owner_no = strOwnerNo)))) loop

        --加锁
        update cdef_defcell cdc
           set cdc.cell_status = cdc.cell_status
         where cdc.enterprise_no = strEnterPriseNo
           and cdc.warehouse_no = curLocateCell.Warehouse_No
           and cdc.cell_no = curLocateCell.Cell_No;

        --检查已使用的储位数
        v_nUsedCells := f_check_UseCells(strEnterPriseNo,
                                         strWareHouseNo,
                                         --strOwnerNo,
                                         strArticleNo,
                                         curLocateCell.Cell_No);
        if nMaxCellUse > 0 and v_nUsedCells > nMaxCellUse then
          p_write_short_log(strEnterPriseNo,
                            strWareHouseNo,
                            'N',
                            strOwnerNo,
                            curLocateCell.Cell_No,
                            strArticleNo,
                            -1,
                            -1,
                            nLocateQTY,
                            'N',
                            '检查已使用的储位数:' || v_nUsedCells || '>' ||
                            nMaxCellUse);
          return;
        end if;

        if v_nUsedCells = nMaxCellUse and nMaxCellUse > 0 then
          select count(distinct cell_no)
            into v_Count
            from stock_content
           where enterprise_no = strEnterPriseNo
             and article_no = strArticleNo
             and qty + instock_qty > 0
             and WAREHOUSE_NO = strWareHouseNo
             and cell_no = curLocateCell.Cell_No;
          if v_Count <= 0 then
            p_write_short_log(strEnterPriseNo,
                              strWareHouseNo,
                              'N',
                              strOwnerNo,
                              curLocateCell.Cell_No,
                              strArticleNo,
                              -1,
                              -1,
                              nLocateQTY,
                              'N',
                              '检查已使用的储位数:' || v_nUsedCells || '=' ||
                              nMaxCellUse);
            return;
          end if;
        end if;

        strLocateCellNo := curLocateCell.Cell_No;
        p_write_instockdirect(strEnterPriseNo,
                              strWareHouseNo,
                              nDirectRow_ID,
                              strLocateCellNo,
                              v_nLocateQTY,
                              strWorkNo,
                              strErrorMsg);
        if substr(strErrorMsg, 1, 2) = 'N|' then
          return;
        end if;
        exit;
      end loop;
      v_nTotalLocateQty := v_nTotalLocateQty - v_nLocateQTY;
      if v_nTotalLocateQty <= 0 then
        exit;
      end if;
    end loop;

  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_locate_SplitCtoB;

  --定到零散拣货位
  procedure p_locate_pickcell_B(strEnterPriseNo in cdef_defware.enterprise_no%type,
                                strWareHouseNo  in cdef_defware.warehouse_no%type, --仓库代码
                                strOwnerNo      in bdef_defowner.owner_no%type, --货主代码
                                strArticleNo    in bdef_defarticle.article_no%type, --商品代码
                                nPackingQTY     in bdef_article_packing.packing_qty%type,
                                nArticleID      in stock_article_info.article_id%type,
                                nLocateQty      in number, --定位数量
                                strPickCellNo   in cset_cell_article.cell_no%type,
                                nCellMaxQTY     in cset_cell_article.max_qty_a%type,
                                nMaxCellUse     in cset_cell_article.keep_cells%type,
                                strLocateCellNo out cdef_defcell.cell_no%type,
                                strErrorMsg     out varchar2) is

    v_Count           integer := 0;
    v_ArticleGroupNo  bdef_defarticle.group_no%type;
    v_ArticleWeight   bdef_defarticle.unit_weight%type;
    v_nTotalLocateQty number := nLocateQty;
    v_nLocateQTY      number := 0;
    v_nUsedCells      cset_cell_article.keep_cells%type := 0;
  begin
    strErrorMsg     := 'N|';
    strLocateCellNo := 'N';

    begin
      select bda.unit_weight, bda.group_no
        into v_ArticleWeight, v_ArticleGroupNo
        from bdef_defarticle bda
       where bda.enterprise_no = strEnterPriseNo
         and bda.article_no = strArticleNo;
    exception
      when no_data_found then
        strErrorMsg := 'Y|';
        return;
    end;

    --大于拣货位最大量，找混载储位
    if v_nTotalLocateQty > nCellMaxQTY then
      for curLocateCell in (select cdc.warehouse_no, cdc.cell_no
                              from cdef_defcell cdc, bdef_defowner o
                             where cdc.enterprise_no = strEnterPriseNo
                               and cdc.cell_status = '0'
                               and cdc.check_status = '0'
                               and cdc.WAREHOUSE_NO = strWareHouseNo
                               and cdc.MIX_FLAG > 0 --可混
                               and exists
                             (select 'x'
                                      from cdef_defcell b
                                     where b.enterprise_no = strEnterPriseNo
                                       and b.cell_no like
                                           strPickCellNo || '%'
                                       and b.WAREHOUSE_NO = cdc.WAREHOUSE_NO
                                       and b.ware_no = cdc.ware_no
                                       and b.area_no = cdc.area_no)
                               and o.enterprise_no = strEnterPriseNo
                               and o.owner_no = strOwnerNo
                               and ((o.fixedcell_flag = 0 and
                                   (cdc.mix_owner = 1 or
                                   (cdc.mix_owner = 0 and not exists
                                    (select 'x'
                                          from stock_content sc
                                         where sc.enterprise_no =
                                               cdc.enterprise_no
                                           and sc.warehouse_no =
                                               cdc.warehouse_no
                                           and sc.cell_no = cdc.cell_no
                                           and sc.owner_no <> strOwnerNo)))) or
                                   (o.fixedcell_flag = 1 and exists
                                    (select 'x'
                                        from cset_owner_cell coc
                                       where coc.enterprise_no =
                                             cdc.enterprise_no
                                         and coc.warehouse_no =
                                             cdc.warehouse_no
                                         and coc.cell_no = cdc.cell_no
                                         and coc.owner_no = strOwnerNo)))
                             order by cdc.cell_no) loop

        --加锁
        update cdef_defcell cdc
           set cdc.cell_status = cdc.cell_status
         where cdc.enterprise_no = strEnterPriseNo
           and cdc.warehouse_no = curLocateCell.Warehouse_No
           and cdc.cell_no = curLocateCell.Cell_No;

        strLocateCellNo := curLocateCell.Cell_No;
        strErrorMsg     := 'Y|';
        exit;
      end loop;
    else
      for curLocateCell in (select cdc.warehouse_no, cdc.cell_no
                              from cdef_defcell cdc, bdef_defowner o
                             where cdc.enterprise_no = strEnterPriseNo
                               and cdc.cell_status = '0'
                               and cdc.check_status = '0'
                               and cdc.WAREHOUSE_NO = strWareHouseNo
                               and cdc.cell_no like strPickCellNo || '%'
                               and o.enterprise_no = strEnterPriseNo
                               and o.owner_no = strOwnerNo
                               and ((o.fixedcell_flag = 0 and
                                   (cdc.mix_owner = 1 or
                                   (cdc.mix_owner = 0 and not exists
                                    (select 'x'
                                          from stock_content sc
                                         where sc.enterprise_no =
                                               cdc.enterprise_no
                                           and sc.warehouse_no =
                                               cdc.warehouse_no
                                           and sc.cell_no = cdc.cell_no
                                           and sc.owner_no <> strOwnerNo)))) or
                                   (o.fixedcell_flag = 1 and exists
                                    (select 'x'
                                        from cset_owner_cell coc
                                       where coc.enterprise_no =
                                             cdc.enterprise_no
                                         and coc.warehouse_no =
                                             cdc.warehouse_no
                                         and coc.cell_no = cdc.cell_no
                                         and coc.owner_no = strOwnerNo)))) loop
        --加锁
        update cdef_defcell cdc
           set cdc.cell_status = cdc.cell_status
         where cdc.enterprise_no = strEnterPriseNo
           and cdc.warehouse_no = curLocateCell.Warehouse_No
           and cdc.cell_no = curLocateCell.Cell_No;

        --检查已使用的储位数
        v_nUsedCells := f_check_UseCells(strEnterPriseNo,
                                         strWareHouseNo,
                                         --strOwnerNo,
                                         strArticleNo,
                                         curLocateCell.Cell_No);
        if nMaxCellUse > 0 and v_nUsedCells > nMaxCellUse then
          p_write_short_log(strEnterPriseNo,
                            strWareHouseNo,
                            'N',
                            strOwnerNo,
                            curLocateCell.Cell_No,
                            strArticleNo,
                            nArticleID,
                            nPackingQty,
                            nLocateQTY,
                            'N',
                            '检查已使用的储位数:' || v_nUsedCells || '>' ||
                            nMaxCellUse);
          return;
        end if;

        if v_nUsedCells = nMaxCellUse and nMaxCellUse > 0 then
          select count(distinct cell_no)
            into v_Count
            from stock_content
           where enterprise_no = strEnterPriseNo
             and article_no = strArticleNo
             and qty + instock_qty > 0
             and WAREHOUSE_NO = strWareHouseNo
             and cell_no = curLocateCell.Cell_No;
          if v_Count <= 0 then
            p_write_short_log(strEnterPriseNo,
                              strWareHouseNo,
                              'N',
                              strOwnerNo,
                              curLocateCell.Cell_No,
                              strArticleNo,
                              nArticleID,
                              nPackingQty,
                              nLocateQTY,
                              'N',
                              '检查已使用的储位数:' || v_nUsedCells || '=' ||
                              nMaxCellUse);
            return;
          end if;
        end if;

        --Modify BY QZH AT 2016-5-24 数量限制, 零散拣货位
        if f_check_QTY(strEnterPriseNo,
                       strWareHouseNo,
                       --strOwnerNo,
                       strArticleNo,
                       nCellMaxQTY,
                       v_nLocateQTY,
                       curLocateCell.Cell_No) = false then
          goto next_Cell_No;
        end if;

        --混批限制
        if f_check_ArticleBatch(strEnterPriseNo,
                                strWareHouseNo,
                                strOwnerNo,
                                strArticleNo,
                                nArticleID,
                                curLocateCell.Cell_No) = false then
          goto next_Cell_No;
        end if;

        --混载
        if f_check_ArticleMix(strEnterPriseNo,
                              strWareHouseNo,
                              strOwnerNo,
                              strArticleNo,
                              nArticleID,
                              curLocateCell.Cell_No) = false then
          goto next_Cell_No;
        end if;

        --箱数
        if f_check_CaseQTY(strEnterPriseNo,
                           strWareHouseNo,
                           --strOwnerNo,
                           --strArticleNo,
                           nPackingQTY,
                           v_nLocateQTY,
                           curLocateCell.Cell_No) = false then
          goto next_Cell_No;
        end if;

        --重量限制
        if f_check_Weight(strEnterPriseNo,
                          strWareHouseNo,
                          --strOwnerNo,
                          strArticleNo,
                          v_nLocateQTY,
                          curLocateCell.Cell_No) = false then
          goto next_Cell_No;
        end if;

        /*        --限制类别
        if f_check_Group(strEnterPriseNo,
                         strWareHouseNo,
                         --strOwnerNo,
                         strArticleNo,
                         curLocateCell.Cell_No) = false then
          goto next_Cell_No;
        end if;*/

        strLocateCellNo := curLocateCell.Cell_No;
        strErrorMsg     := 'Y|';
        return;
        <<next_Cell_No>>
        null;
      end loop;

      for curLocateCell in (select cdc.warehouse_no, cdc.cell_no
                              from cdef_defcell cdc, bdef_defowner o
                             where cdc.enterprise_no = strEnterPriseNo
                               and cdc.cell_status = '0'
                               and cdc.check_status = '0'
                               and cdc.WAREHOUSE_NO = strWareHouseNo
                               and cdc.MIX_FLAG > 0 --可混
                               and exists
                             (select 'x'
                                      from cdef_defcell b
                                     where b.enterprise_no = strEnterPriseNo
                                       and b.cell_no like
                                           strPickCellNo || '%'
                                       and b.WAREHOUSE_NO = cdc.WAREHOUSE_NO
                                       and b.ware_no = cdc.ware_no
                                       and b.area_no = cdc.area_no)
                               and not exists
                             (select 'x'
                                      from stock_content sc
                                     where sc.enterprise_no = strEnterPriseNo
                                       and sc.cell_no = cdc.cell_no
                                       and sc.WAREHOUSE_NO = cdc.WAREHOUSE_NO
                                       and sc.qty > 0)
                               and o.enterprise_no = strEnterPriseNo
                               and o.owner_no = strOwnerNo
                               and ((o.fixedcell_flag = 0 and
                                   (cdc.mix_owner = 1 or
                                   (cdc.mix_owner = 0 and not exists
                                    (select 'x'
                                          from stock_content sc
                                         where sc.enterprise_no =
                                               cdc.enterprise_no
                                           and sc.warehouse_no =
                                               cdc.warehouse_no
                                           and sc.cell_no = cdc.cell_no
                                           and sc.owner_no <> strOwnerNo)))) or
                                   (o.fixedcell_flag = 1 and exists
                                    (select 'x'
                                        from cset_owner_cell coc
                                       where coc.enterprise_no =
                                             cdc.enterprise_no
                                         and coc.warehouse_no =
                                             cdc.warehouse_no
                                         and coc.cell_no = cdc.cell_no
                                         and coc.owner_no = strOwnerNo)))
                             order by cdc.mix_flag desc, cdc.cell_no) loop
        --加锁
        update cdef_defcell cdc
           set cdc.cell_status = cdc.cell_status
         where cdc.enterprise_no = strEnterPriseNo
           and cdc.warehouse_no = curLocateCell.Warehouse_No
           and cdc.cell_no = curLocateCell.Cell_No;

        strLocateCellNo := curLocateCell.Cell_No;
        strErrorMsg     := 'Y|';
        return;
      end loop;
    end if;

  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_locate_pickcell_B;

  --定到拣货区
  procedure p_locate_pickArea(strEnterPriseNo in varchar2,
                              strWareHouseNo  in varchar2, --仓库代码
                              strOwnerNo      in varchar2, --货主代码
                              strArticleNo    in varchar2, --商品代码
                              nPackingQTY     in bdef_article_packing.packing_qty%type,
                              nArticleID      in number,
                              strOperateType  in varchar2, --定位类型
                              nLocateQty      in number, --定位数量
                              strPickCellNo   in cset_cell_article.cell_no%type,
                              nCellMaxQTY     in cset_cell_article.max_qty_a%type,
                              nMaxCellUse     in cset_cell_article.keep_cells%type,
                              nRuleOrder      in number, --规则顺序
                              strLocateCellNo out varchar2,
                              strErrorMsg     out varchar2) is

    v_nUsedCells cset_cell_article.keep_cells%type := 0;
    --v_StockWeight    bdef_article_packing.packing_weight%type;
    v_ArticleGroupNo bdef_defarticle.group_no%type;
    v_ArticleWeight  bdef_defarticle.unit_weight%type;
  begin
    strErrorMsg     := 'N|';
    strLocateCellNo := 'N';

    --查找商品拣货位信息
    begin
      select bda.unit_weight, bda.group_no
        into v_ArticleWeight, v_ArticleGroupNo
        from bdef_defarticle bda
       where bda.enterprise_no = strEnterPriseNo
         and bda.article_no = strArticleNo;
    exception
      when no_data_found then
        strErrorMsg := 'N|[商品:' || strArticleNo || '没有商品资料！]';
        return;
    end;

    for curLocateRule in (select *
                            from wms_defstrategy_d d
                           where d.strategy_type = 'I'
                             and d.RULE_ORDER = nRuleOrder
                             and exists
                           (select 'x'
                                    from bdef_defarticle bda
                                   where bda.enterprise_no = strEnterPriseNo
                                     and bda.article_no = strArticleNo
                                     and bda.I_STRATEGY = d.STRATEGY_ID)) loop
      --板数量限制
      if curLocateRule.Limmit_Maxqty = '1' then
        --Modify BY QZH AT 2016-4-22 拣货区参考拣货位的最大量，不参考储位最大量
        if nLocateQty > nCellMaxQTY then
          p_write_short_log(strEnterPriseNo,
                            strWareHouseNo,
                            'N',
                            strOwnerNo,
                            'N',
                            strArticleNo,
                            nArticleID,
                            nPackingQty,
                            nLocateQTY,
                            'N',
                            '定位到拣货区-超过储位最大量:' || strPickCellNo || ',' ||
                            nCellMaxQTY);
          return;
        end if;
      end if;

      --空储位
      for curLocateCell in (select cdc.warehouse_no, cdc.cell_no
                              from cdef_defcell cdc, bdef_defowner o
                             where cdc.cell_status <> '1'
                               and cdc.check_status = '0'
                               and cdc.enterprise_no = strEnterPriseNo
                               and cdc.WAREHOUSE_NO = strWareHouseNo
                               and exists
                             (select 'x'
                                      from cdef_defcell c
                                     where cdc.enterprise_no =
                                           c.enterprise_no
                                       and cdc.warehouse_no = c.warehouse_no
                                       and cdc.ware_no = c.ware_no
                                       and cdc.area_no = c.area_no
                                       and c.cell_no like
                                           strPickCellNo || '%')
                               and not exists
                             (select 'x'
                                      from stock_content sc
                                     where sc.WAREHOUSE_NO = cdc.WAREHOUSE_NO
                                       and sc.enterprise_no =
                                           cdc.enterprise_no
                                       and sc.cell_no = cdc.cell_no
                                       and sc.qty + sc.instock_qty > 0)
                               and not exists
                             (select 'x'
                                      from cset_cell_article cc
                                     where cc.WAREHOUSE_NO = cdc.WAREHOUSE_NO
                                       and cc.enterprise_no =
                                           cdc.enterprise_no
                                       and cc.cell_no = cdc.cell_no
                                       and cc.article_no <> strArticleNo)
                               and o.enterprise_no = strEnterPriseNo
                               and o.owner_no = strOwnerNo
                               and ((o.fixedcell_flag = 0 and
                                   (cdc.mix_owner = 1 or
                                   (cdc.mix_owner = 0 and not exists
                                    (select 'x'
                                          from stock_content sc
                                         where sc.enterprise_no =
                                               cdc.enterprise_no
                                           and sc.warehouse_no =
                                               cdc.warehouse_no
                                           and sc.cell_no = cdc.cell_no
                                           and sc.owner_no <> strOwnerNo)))) or
                                   (o.fixedcell_flag = 1 and exists
                                    (select 'x'
                                        from cset_owner_cell coc
                                       where coc.enterprise_no =
                                             cdc.enterprise_no
                                         and coc.warehouse_no =
                                             cdc.warehouse_no
                                         and coc.cell_no = cdc.cell_no
                                         and coc.owner_no = strOwnerNo)))) loop

        --加锁
        update cdef_defcell cdc
           set cdc.cell_status = cdc.cell_status
         where cdc.enterprise_no = strEnterPriseNo
           and cdc.warehouse_no = curLocateCell.Warehouse_No
           and cdc.cell_no = curLocateCell.Cell_No;

        --检查已使用的储位数
        if curLocateRule.Limmit_Celluse = '1' then
          v_nUsedCells := f_check_UseCells(strEnterPriseNo,
                                           strWareHouseNo,
                                           --strOwnerNo,
                                           strArticleNo,
                                           curLocateCell.Cell_No);
          if nMaxCellUse > 0 and v_nUsedCells >= nMaxCellUse then
            p_write_short_log(strEnterPriseNo,
                              strWareHouseNo,
                              'N',
                              strOwnerNo,
                              curLocateCell.Cell_No,
                              strArticleNo,
                              nArticleID,
                              nPackingQty,
                              nLocateQTY,
                              'N',
                              '检查已使用的储位数:' || v_nUsedCells || '>' ||
                              nMaxCellUse);
            return;
          end if;
        end if;

        --Modify BY QZH AT 2016-5-24 拣货区参考拣货位的最大量
        --数量限制
        if curLocateRule.Limmit_Maxqty = '1' then
          if f_check_QTY(strEnterPriseNo,
                         strWareHouseNo,
                         --strOwnerNo,
                         strArticleNo,
                         nCellMaxQTY,
                         nLocateQty,
                         curLocateCell.Cell_No) = false then
            goto next_Cell_No;
          end if;

        end if;

        --混批限制
        if curLocateRule.Limmit_Mixbatch = '1' then
          if f_check_ArticleBatch(strEnterPriseNo,
                                  strWareHouseNo,
                                  strOwnerNo,
                                  strArticleNo,
                                  nArticleID,
                                  curLocateCell.Cell_No) = false then
            goto next_Cell_No;
          end if;
        end if;

        --混载
        if curLocateRule.Limmit_Mixarticle = '1' then
          if f_check_ArticleMix(strEnterPriseNo,
                                strWareHouseNo,
                                strOwnerNo,
                                strArticleNo,
                                nArticleID,
                                curLocateCell.Cell_No) = false then
            goto next_Cell_No;
          end if;
        end if;

        --箱数
        if curLocateRule.Limmit_Maxcase = '1' then
          if f_check_CaseQTY(strEnterPriseNo,
                             strWareHouseNo,
                             --strOwnerNo,
                             --strArticleNo,
                             nPackingQTY,
                             nLocateQty,
                             curLocateCell.Cell_No) = false then
            goto next_Cell_No;
          end if;
        end if;

        --重量限制
        if curLocateRule.Limmit_Maxweight = '1' then
          if f_check_Weight(strEnterPriseNo,
                            strWareHouseNo,
                            --strOwnerNo,
                            strArticleNo,
                            nLocateQty,
                            curLocateCell.Cell_No) = false then
            goto next_Cell_No;
          end if;
        end if;

        --限制类别
        if curLocateRule.Limmit_Maxgroupno = '1' then
          if f_check_Group(strEnterPriseNo,
                           strWareHouseNo,
                           --strOwnerNo,
                           strArticleNo,
                           curLocateCell.Cell_No) = false then
            goto next_Cell_No;
          end if;
        end if;

        strLocateCellNo := curLocateCell.Cell_No;
        strErrorMsg     := 'Y|';
        exit;
        <<next_Cell_No>>
        null;
      end loop;
    end loop;

  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_locate_pickArea;

  --定位到异常区
  procedure p_locate_special(strEnterPriseNo in cdef_defware.enterprise_no%type,
                             strWareHouseNo  in cdef_defware.warehouse_no%type,
                             strOwnerNo      in bdef_defowner.owner_no%type, --货主代码
                             strArticleNo    in bdef_defarticle.article_no%type,
                             nArticleID      in stock_article_info.article_id%type,
                             nPackingQTY     in bdef_article_packing.packing_qty%type,
                             nRuleOrder      in wms_defstrategy_d.rule_order%type, --规则顺序
                             nLocateQty      in number,
                             strLocateCellNo out cdef_defcell.cell_no%type,
                             strErrorMsg     out varchar2) is

    v_PickMaxCellUse cset_cell_article.keep_cells%type := 0;
    v_nUsedCells     cset_cell_article.keep_cells%type := 0;

    v_AreaUseType cdef_defarea.area_usetype%type;
    v_AreaQuality cdef_defarea.area_quality%type;

    v_Count integer := 0;
  begin
    strErrorMsg := 'N|';

    for curLocateRule in (select *
                            from wms_defstrategy_d d
                           where d.strategy_type = 'I'
                             and d.RULE_ORDER = nRuleOrder
                             and exists
                           (select 'x'
                                    from bdef_defarticle bda
                                   where bda.enterprise_no = strEnterPriseNo
                                     and bda.article_no = strArticleNo
                                     and bda.I_STRATEGY = d.STRATEGY_ID)) loop
      --异常区
      if curLocateRule.Rule_Id = ToSpecialArea then
        v_AreaUseType := '5';
        v_AreaQuality := '0';
      end if;

      --不良品退货区
      if curLocateRule.Rule_Id = BadReturnArea then
        v_AreaUseType := '3';
        v_AreaQuality := 'A';
      end if;

      --良品退货区
      if curLocateRule.Rule_Id = GoodReturnArea then
        v_AreaUseType := '3';
        v_AreaQuality := '0';
      end if;
      
      --不良品区
      if curLocateRule.Rule_Id = '22' then
        v_AreaUseType := '1';
        v_AreaQuality := 'A';
      end if;

      for curLocateCell in (select CDC.Warehouse_No, CDC.CELL_NO
                              from cdef_defcell cdc, cdef_defarea cdd
                             where cdc.enterprise_no = cdd.enterprise_no
                               and cdc.enterprise_no = strEnterPriseNo
                               and cdc.warehouse_no = cdd.warehouse_no
                               and cdc.ware_no = cdd.ware_no
                               and cdc.area_no = cdd.area_no
                               AND CDC.CELL_STATUS = '0'
                               AND CDC.CHECK_STATUS = 0
                               and cdd.AREA_ATTRIBUTE = '0'
                               and cdd.AREA_USETYPE = v_AreaUseType --'5'

                               and ((cdd.area_quality >= '0' and
                                   cdd.area_quality <= '9' and
                                   v_AreaQuality = '0') or
                                   (cdd.area_quality >= 'A' and
                                   cdd.area_quality <= 'Z' and
                                   v_AreaQuality = 'A'))

                               and cdd.warehouse_no = strWareHouseNo
                            --预留
                             order by CDD.PICK_LEVEL, CDC.CELL_NO) loop

        --加锁
        update cdef_defcell cdc
           set cdc.cell_status = cdc.cell_status
         where cdc.enterprise_no = strEnterPriseNo
           and cdc.warehouse_no = curLocateCell.Warehouse_No
           and cdc.cell_no = curLocateCell.Cell_No;

        --检查已使用的储位数
        if curLocateRule.Limmit_Celluse = '1' then
          v_nUsedCells := f_check_UseCells(strEnterPriseNo,
                                           strWareHouseNo,
                                           --strOwnerNo,
                                           strArticleNo,
                                           curLocateCell.Cell_No);
          if v_PickMaxCellUse > 0 and v_nUsedCells > v_PickMaxCellUse then
            p_write_short_log(strEnterPriseNo,
                              strWareHouseNo,
                              'N',
                              strOwnerNo,
                              curLocateCell.Cell_No,
                              strArticleNo,
                              nArticleID,
                              nPackingQty,
                              nLocateQTY,
                              'N',
                              '定位到特殊区-超过已使用的储位数' || v_nUsedCells || '>' ||
                              v_PickMaxCellUse);
            return;
          end if;

          if v_PickMaxCellUse > 0 and v_nUsedCells = v_PickMaxCellUse then
            select count(distinct cell_no)
              into v_Count
              from stock_content
             where enterprise_no = strEnterPriseNo
               and article_no = strArticleNo
               and qty + instock_qty > 0
               and WAREHOUSE_NO = strWareHouseNo
               and cell_no = curLocateCell.Cell_No;
            if v_Count <= 0 then
              p_write_short_log(strEnterPriseNo,
                                strWareHouseNo,
                                'N',
                                strOwnerNo,
                                curLocateCell.Cell_No,
                                strArticleNo,
                                nArticleID,
                                nPackingQty,
                                nLocateQTY,
                                'N',
                                '定位到特殊区-超过已使用的储位数' || v_nUsedCells || '>' ||
                                v_PickMaxCellUse);
              return;
            end if;
          end if;
        end if;

        --板数量限制
        if curLocateRule.Limmit_Maxqty = '1' then
          if f_check_PalQTY(strEnterPriseNo,
                            strWareHouseNo,
                            --strOwnerNo,
                            strArticleNo,
                            nPackingQTY,
                            nLocateQty,
                            curLocateCell.Cell_No) = false then
            goto next_Cell_No;
          end if;
        end if;

        --混批限制
        if curLocateRule.Limmit_Mixbatch = '1' then
          if f_check_ArticleBatch(strEnterPriseNo,
                                  strWareHouseNo,
                                  strOwnerNo,
                                  strArticleNo,
                                  nArticleID,
                                  curLocateCell.Cell_No) = false then
            goto next_Cell_No;
          end if;
        end if;

        --混载
        if curLocateRule.Limmit_Mixarticle = '1' then
          if f_check_ArticleMix(strEnterPriseNo,
                                strWareHouseNo,
                                strOwnerNo,
                                strArticleNo,
                                nArticleID,
                                curLocateCell.Cell_No) = false then
            goto next_Cell_No;
          end if;
        end if;

        --箱数
        if curLocateRule.Limmit_Maxcase = '1' then
          if f_check_CaseQTY(strEnterPriseNo,
                             strWareHouseNo,
                             --strOwnerNo,
                             --strArticleNo,
                             nPackingQTY,
                             nLocateQty,
                             curLocateCell.Cell_No) = false then
            goto next_Cell_No;
          end if;
        end if;

        --重量限制
        if curLocateRule.Limmit_Maxweight = '1' then
          if f_check_Weight(strEnterPriseNo,
                            strWareHouseNo,
                            --strOwnerNo,
                            strArticleNo,
                            nLocateQty,
                            curLocateCell.Cell_No) = false then
            goto next_Cell_No;
          end if;
        end if;

        --限制类别
        if curLocateRule.Limmit_Maxgroupno = '1' then
          if f_check_Group(strEnterPriseNo,
                           strWareHouseNo,
                           --strOwnerNo,
                           strArticleNo,
                           curLocateCell.Cell_No) = false then
            goto next_Cell_No;
          end if;
        end if;

        strLocateCellNo := curLocateCell.Cell_No;
        strErrorMsg     := 'Y|';
        exit;
        <<next_Cell_No>>
        null;
      end loop;
    end loop;

  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_locate_special;

  --检查板数量
  function f_check_PalQTY(strEnterPriseNo in cdef_defware.enterprise_no%type,
                          strWareHouseNo  in cdef_defware.warehouse_no%type,
                          --strOwnerNo     in bdef_defowner.owner_no%type,
                          strArticleNo in bdef_defarticle.article_no%type,
                          nPackingQTY  in bdef_article_packing.packing_qty%type,
                          nLocateQTY   in number,
                          strCellNo    in cdef_defcell.cell_no%type)
    return boolean is
    v_Result      boolean := false;
    v_MaxPal      cdef_defcell.max_qty%type := 0; --最大板数
    v_StockPalQTY stock_content.qty%type; --库存板数
    v_ArticlePal  bdef_article_packing.qpalette%type; --商品堆叠
  begin

    --储位最大量
    begin
      select cdc.max_qty
        into v_MaxPal
        from cdef_defcell cdc
       where cdc.enterprise_no = strEnterPriseNo
         and cdc.warehouse_no = strWareHouseNo
         and cdc.cell_no = strCellNo;
    exception
      when no_data_found then
        return v_Result;
    end;

    --商品堆叠
    begin
      SELECT NVL(bwp.qpalette, bap.qpalette) qpalette
        into v_ArticlePal
        FROM bdef_article_packing bap
        left join bdef_warehouse_packing bwp
          on bwp.warehouse_no = strWareHouseNo
         and bwp.enterprise_no = bap.enterprise_no
         and bwp.article_no = bap.article_no
         and bwp.packing_qty = bap.packing_qty
       where bap.article_no = strArticleNo
         and bap.packing_qty = nPackingQTY
         and bap.enterprise_no = strEnterpriseNo;

    exception
      when no_data_found then
        --return v_Result;
        v_ArticlePal := 999999;
    end;

    if v_ArticlePal = 0 then
      p_write_short_log(strEnterPriseNo,
                        strWareHouseNo,
                        'N',
                        'N',
                        strCellNo,
                        strArticleNo,
                        -1,
                        nPackingQTY,
                        nLocateQTY,
                        'N',
                        '检查板数量-商品堆叠为0');
      return v_Result;
    end if;

    --无箱数板数限制
    if v_MaxPal <= 0 then
      v_Result := true;
      return v_Result;
    end if;

    select sum((cc.qty + cc.instock_qty) / nvl(a.qpalette, 999999)) pal_qty
      into v_StockPalQTY
      from stock_content cc,
           (SELECT bap.article_no,
                   bap.packing_qty,
                   NVL(bwp.qpalette, bap.qpalette) qpalette
              FROM bdef_article_packing bap, bdef_warehouse_packing bwp
             where bap.enterprise_no = bwp.enterprise_no(+)
               and bap.enterprise_no = strEnterPriseNo
               and bap.article_no = bwp.ARTICLE_NO(+)
               AND bap.packing_qty = bwp.packing_qty(+)) a
     where cc.warehouse_no = strWareHouseNo
       and cc.cell_no = strCellNo
       and cc.article_no = a.article_no(+)
       and cc.packing_qty = a.packing_qty(+);

    if v_StockPalQTY + (nLocateQTY / v_ArticlePal) >= v_MaxPal then
      v_Result := false;
      p_write_short_log(strEnterPriseNo,
                        strWareHouseNo,
                        'N',
                        'N',
                        strCellNo,
                        strArticleNo,
                        -1,
                        nPackingQTY,
                        nLocateQTY,
                        'N',
                        '检查板数量-超过储位最大量:' || v_MaxPal);
      return v_Result;
    end if;

    v_Result := true;
    return v_Result;
  exception
    when others then
      return false;
  end;

  --检查拣货位（区）数量
  function f_check_QTY(strEnterPriseNo in cdef_defware.enterprise_no%type,
                       strWareHouseNo  in cdef_defware.warehouse_no%type,
                       strArticleNo    in bdef_defarticle.article_no%type,
                       nCellMaxQTY     in cset_cell_article.max_qty_a%type,
                       nLocateQTY      in number,
                       strCellNo       in cdef_defcell.cell_no%type)
    return boolean is
    v_Result      boolean := false;
    v_StockPalQTY stock_content.qty%type; --库存板数
  begin

    --储位最大量
    if nCellMaxQTY <= 0 then
      --无限制
      v_Result := true;
      return v_Result;
    end if;

    select sum(cc.qty + cc.instock_qty)
      into v_StockPalQTY
      from stock_content cc
     where cc.warehouse_no = strWareHouseNo
       and cc.cell_no = strCellNo
       and cc.article_no = strArticleNo
       and cc.enterprise_no = strEnterPriseNo;

    if v_StockPalQTY + nLocateQTY > nCellMaxQTY then
      v_Result := false;
      p_write_short_log(strEnterPriseNo,
                        strWareHouseNo,
                        'N',
                        'N',
                        strCellNo,
                        strArticleNo,
                        -1,
                        -1,
                        nLocateQTY,
                        'N',
                        '检查拣货位（区）数量-超过储位最大量:' || nCellMaxQTY);

      return v_Result;
    end if;

    v_Result := true;
    return v_Result;
  exception
    when others then
      return false;
  end;

  --检查箱数量
  function f_check_CaseQTY(strEnterPriseNo in cdef_defware.enterprise_no%type,
                           strWareHouseNo  in cdef_defware.warehouse_no%type,
                           nPackingQTY     in bdef_article_packing.packing_qty%type,
                           nLocateQTY      in number,
                           strCellNo       in cdef_defcell.cell_no%type)
    return boolean is
    v_Result       boolean := false;
    v_MaxCase      cdef_defcell.max_case%type := 0; --最大箱数
    v_StockCaseQTY stock_content.qty%type; --库存箱数
    v_LocateCase   stock_content.qty%type; --定位箱数
  begin

    --储位最大量
    begin
      select cdc.max_case
        into v_MaxCase
        from cdef_defcell cdc
       where cdc.enterprise_no = strEnterPriseNo
         and cdc.warehouse_no = strWareHouseNo
         and cdc.cell_no = strCellNo;
    exception
      when no_data_found then
        return v_Result;
    end;

    --无箱数限制
    if v_MaxCase <= 0 then
      v_Result := true;
      return v_Result;
    end if;

    --此段待讨论
    if nPackingQTY > 1 then
      if nLocateQTY < nPackingQTY then
        v_LocateCase := 1;
      else
        v_LocateCase := ceil(nLocateQTY / nPackingQTY);
      end if;
    else
      v_LocateCase := 1;
    end if;

    select ceil(sum((cc.qty + cc.instock_qty) / nvl(cc.packing_qty, 1))) case_qty
      into v_StockCaseQTY
      from stock_content cc, bdef_article_packing bap
     where cc.enterprise_no = bap.enterprise_no(+)
       and cc.enterprise_no = strEnterPriseNo
       and cc.warehouse_no = strWareHouseNo
       and cc.cell_no = strCellNo
       and cc.article_no = bap.article_no(+)
       and cc.packing_qty = bap.packing_qty(+)
       and cc.packing_qty > 0; --？

    if v_StockCaseQTY + v_LocateCase >= v_MaxCase then
      v_Result := false;
      p_write_short_log(strEnterPriseNo,
                        strWareHouseNo,
                        'N',
                        'N',
                        strCellNo,
                        'N',
                        -1,
                        -1,
                        nLocateQTY,
                        'N',
                        '检查箱数量-超过储位最大量:' || v_MaxCase);

      return v_Result;
    end if;

    v_Result := true;
    return v_Result;
  exception
    when others then
      return false;
  end;

  --检查重量
  function f_check_Weight(strEnterPriseNo in cdef_defware.enterprise_no%type,
                          strWareHouseNo  in cdef_defware.warehouse_no%type,
                          --strOwnerNo     in bdef_defowner.owner_no%type,
                          strArticleNo in bdef_defarticle.article_no%type,
                          nLocateQTY   in number,
                          strCellNo    in cdef_defcell.cell_no%type)
    return boolean is
    v_Result        boolean := false;
    v_MaxWeight     cdef_defcell.max_weight%type := 0; --最大重量
    v_StockWeight   cdef_defcell.max_weight%type;
    v_ArticleWeight bdef_defarticle.unit_weight%type;
  begin

    --储位最大重量
    begin
      select cdc.max_weight
        into v_MaxWeight
        from cdef_defcell cdc
       where cdc.enterprise_no = strEnterPriseNo
         and cdc.warehouse_no = strWareHouseNo
         and cdc.cell_no = strCellNo;
    exception
      when no_data_found then
        return v_Result;
    end;

    --无重量限制
    if v_MaxWeight <= 0 then
      v_Result := true;
      return v_Result;
    end if;

    begin
      select bda.unit_weight
        into v_ArticleWeight
        from bdef_defarticle bda
       where bda.enterprise_no = strEnterPriseNo
         and bda.article_no = strArticleNo;
    exception
      when others then
        return v_Result;
    end;

    select sum((cc.qty + cc.instock_qty) * bda.unit_weight) stock_weight
      into v_StockWeight
      from stock_content cc, bdef_defarticle bda
     where cc.enterprise_no = bda.enterprise_no
       and cc.enterprise_no = strEnterPriseNo
       and cc.warehouse_no = strWareHouseNo
       and cc.cell_no = strCellNo
       and cc.article_no = bda.article_no;

    if v_StockWeight + v_ArticleWeight * nLocateQTY > v_MaxWeight then
      p_write_short_log(strEnterPriseNo,
                        strWareHouseNo,
                        'N',
                        'N',
                        strCellNo,
                        strArticleNo,
                        -1,
                        -1,
                        nLocateQTY,
                        'N',
                        '检查重量-超过储位最大重量:' || v_MaxWeight);
      return v_Result;
    end if;

    v_Result := true;
    return v_Result;
  exception
    when others then
      return v_Result;
  end;

  --检查类别
  function f_check_Group(strEnterPriseNo in cdef_defware.enterprise_no%type,
                         strWareHouseNo  in cdef_defware.warehouse_no%type,
                         --strOwnerNo     in bdef_defowner.owner_no%type,
                         strArticleNo in bdef_defarticle.article_no%type,
                         strCellNo    in cdef_defcell.cell_no%type)
    return boolean is
    v_Result         boolean := false;
    v_Count          integer;
    v_ArticleGroupNo bdef_defarticle.group_no%type;
  begin

    begin
      select bda.group_no
        into v_ArticleGroupNo
        from bdef_defarticle bda
       where bda.enterprise_no = strEnterPriseNo
         and bda.article_no = strArticleNo;
    exception
      when others then
        return v_Result;
    end;

    select count(distinct bda.group_no)
      into v_Count
      from stock_content cc, bdef_defarticle bda
     where cc.enterprise_no = bda.enterprise_no
       and cc.enterprise_no = strEnterPriseNo
       and cc.warehouse_no = strWareHouseNo
       and cc.cell_no = strCellNo
       and cc.article_no = bda.article_no
       and (cc.qty > 0 or cc.instock_qty > 0)
       and bda.group_no <> v_ArticleGroupNo;

    if v_Count > 0 then
      p_write_short_log(strEnterPriseNo,
                        strWareHouseNo,
                        'N',
                        'N',
                        strCellNo,
                        strArticleNo,
                        -1,
                        -1,
                        -1,
                        'N',
                        '检查类别-:存在不同商品类别:' || v_ArticleGroupNo);
      return v_Result;
    end if;

    v_Result := true;
    return v_Result;
  exception
    when others then
      return v_Result;
  end;

  --检查已使用的储位数
  function f_check_UseCells(strEnterPriseNo in cdef_defware.enterprise_no%type,
                            strWareHouseNo  in cdef_defware.warehouse_no%type,
                            strArticleNo    in bdef_defarticle.article_no%type,
                            strCellNo       in cdef_defcell.cell_no%type)
    return integer is

    v_Count   integer := -1;
    v_Ware_No cdef_defcell.ware_no%type;
    v_Area_No cdef_defcell.area_no%type;
  begin

    begin
      select cdc.ware_no, cdc.area_no
        into v_Ware_No, v_Area_No
        from cdef_defcell cdc
       where cdc.enterprise_no = strEnterPriseNo
         and cdc.warehouse_no = strWareHouseNo
         and cdc.cell_no = strCellNo;
    exception
      when others then
        return v_Count;
    end;

    select count(distinct cdc.cell_no)
      into v_Count
      from stock_content cc, cdef_defcell cdc
     where cc.enterprise_no = cdc.enterprise_no
       and cc.enterprise_no = strEnterPriseNo
       and cc.warehouse_no = strWareHouseNo
       and cc.cell_no = cdc.cell_no
       and cdc.ware_no = v_Ware_No
       and cdc.area_no = v_Area_No
       and cc.warehouse_no = cdc.warehouse_no
       and cc.article_no = strArticleNo
       and (cc.qty > 0 or cc.instock_qty > 0);

    return v_Count;
  exception
    when others then
      return v_Count;
  end;

  --检查混批
  function f_check_ArticleBatch(strEnterPriseNo in cdef_defware.enterprise_no%type,
                                strWareHouseNo  in cdef_defware.warehouse_no%type,
                                strOwnerNo      in bdef_defowner.owner_no%type,
                                strArticleNo    in bdef_defarticle.article_no%type,
                                nArticleID      in stock_article_info.article_id%type,
                                strCellNo       in cdef_defcell.cell_no%type)
    return boolean is
    v_Result boolean := true;
    v_Count  integer := 0;
    i        integer := 0;

    v_strSQL varchar(2048);
  begin

    v_strSQL := ' select count(1)
          from stock_content cc, stock_article_info sai
         where cc.enterprise_no = sai.enterprise_no
           and cc.enterprise_no = ''' || strEnterPriseNo || '''
           and cc.warehouse_no = ''' || strWareHouseNo || '''
           and cc.owner_no = ''' || strOwnerNo || '''
           and cc.cell_no = ''' || strCellNo || '''
           and cc.article_no = ''' || strArticleNo || '''
           and cc.article_no = sai.article_no
           and cc.article_id = sai.article_id
           and (cc.qty > 0 or cc.instock_qty > 0)
           and exists (select ''x''
                  from stock_article_info t
                 where t.enterprise_no = sai.enterprise_no
                   and t.article_no = sai.article_no
                   and t.article_id = ' || nArticleID;

    for curBatch in (select *
                       from bset_article_batch_d d
                      where exists
                      (select 'x'
                               from bdef_defarticle bda
                              where bda.enterprise_no = strEnterPriseNo
                                and bda.article_no = strArticleNo
                                and bda.batch_id = d.batch_id)) loop

      if i = 0 then
        v_strSQL := v_strSQL || '  and ( ';
      else
        v_strSQL := v_strSQL || '  or ';
      end if;

      v_strSQL := v_strSQL || ' t.' || curBatch.Field_Id || '  <> sai.' ||
                  curBatch.Field_Id;

      i := i + 1;
    end loop;

    if i > 0 then
      v_strSQL := v_strSQL || ' )';
    end if;

    v_strSQL := v_strSQL || ' )';

    execute immediate v_strSQL
      into v_Count;

    if v_Count > 0 then
      p_write_short_log(strEnterPriseNo,
                        strWareHouseNo,
                        'N',
                        strOwnerNo,
                        strCellNo,
                        strArticleNo,
                        nArticleID,
                        -1,
                        -1,
                        'N',
                        '检查混批-:');
      v_Result := false;
    end if;

    return v_Result;
  exception
    when others then
      return false;
  end;

  --检查商品混载
  function f_check_ArticleMix(strEnterPriseNo in cdef_defware.enterprise_no%type,
                              strWareHouseNo  in cdef_defware.warehouse_no%type,
                              strOwnerNo      in bdef_defowner.owner_no%type,
                              strArticleNo    in bdef_defarticle.article_no%type,
                              nArticleID      in stock_article_info.article_id%type,
                              strCellNo       in cdef_defcell.cell_no%type)
    return boolean is
    v_Result      boolean := false;
    v_CellMixFlag cdef_defcell.mix_flag%type; --储位混载标识
    v_Count       integer := 0;
  begin

    begin
      select mix_flag
        into v_CellMixFlag
        from cdef_defcell cdc
       where cdc.enterprise_no = strEnterPriseNo
         and cdc.warehouse_no = strWareHouseNo
         and cdc.cell_no = strCellNo;
    exception
      when others then
        return v_Result;
    end;

    if v_CellMixFlag = 2 then
      --可混载不同商品
      v_Result := true;
      return v_Result;
    end if;

    if v_CellMixFlag = 0 then
      --不可混
      select count(1)
        into v_Count
        from stock_content cc, stock_article_info sai
       where cc.enterprise_no = sai.enterprise_no
         and cc.enterprise_no = strEnterPriseNo
         and cc.warehouse_no = strWareHouseNo
         and cc.owner_no = strOwnerNo
         and cc.cell_no = strCellNo
         and cc.article_no = sai.article_no
         and cc.article_id = sai.article_id
         and (cc.qty > 0 or cc.instock_qty > 0)
         and (cc.article_no <> strArticleNo or sai.article_id <> nArticleID);

      if v_Count > 0 then
        p_write_short_log(strEnterPriseNo,
                          strWareHouseNo,
                          'N',
                          strOwnerNo,
                          strCellNo,
                          strArticleNo,
                          nArticleID,
                          -1,
                          -1,
                          'N',
                          '检查商品混载-储位不可混');
        return v_Result;
      end if;
    end if;

    if v_CellMixFlag = 1 then
      --可混同商品
      select count(1)
        into v_Count
        from stock_content cc, stock_article_info sai
       where cc.enterprise_no = sai.enterprise_no
         and cc.enterprise_no = strEnterPriseNo
         and cc.warehouse_no = strWareHouseNo
         and cc.owner_no = strOwnerNo
         and cc.cell_no = strCellNo
         and cc.article_no = sai.article_no
         and cc.article_id = sai.article_id
         and (cc.qty > 0 or cc.instock_qty > 0)
         and cc.article_no <> strArticleNo;

      if v_Count > 0 then
        p_write_short_log(strEnterPriseNo,
                          strWareHouseNo,
                          'N',
                          strOwnerNo,
                          strCellNo,
                          strArticleNo,
                          nArticleID,
                          -1,
                          -1,
                          'N',
                          '检查商品混载-储位不可混同不同商品');
        return v_Result;
      end if;
    end if;

    v_Result := true;
    return v_Result;
  exception
    when others then
      return false;
  end;

  --定位到拣货位
  procedure p_PickCellByPickLine(strEnterPriseNo in varchar2,
                                 strWareHouseNo  in varchar2, --仓库代码
                                 strOwnerNo      in varchar2, --货主代码
                                 strArticleNo    in varchar2, --商品代码
                                 nArticleID      in stock_article_info.article_id%type,
                                 nPackingQTY     in bdef_article_packing.packing_qty%type,
                                 --strOperateType in varchar2, --定位类型
                                 strWareNo     in varchar2, --拣货位所在库
                                 strAreaNo     in varchar2, --拣货位所在储区
                                 strStockNo    in varchar2, --拣货位所在通道（如何拣货位到区，下面几个字段没有参考意义）
                                 strStockX     in varchar2, --拣货位所在格
                                 strStockY     in varchar2, --拣货位所在层
                                 strBayX       in varchar2, --拣货位所在位
                                 strPickCellNo in varchar2, --拣货位储位
                                 nLocateQty    in number, --定位数量
                                 --nMaxQty         in number, --拣货位最大量
                                 nKeepCells  in number, --允许占用最大储位数
                                 nMergerFlag in number, --是否并入
                                 nStockFlag  in number, --
                                 nFloorFlag  in number, --
                                 nStockXFlag in number, --
                                 nBayFlag    in number, --
                                 nSortFlag   in number, --
                                 --nForceFlag      in number, --是否允许强制进入
                                 nRuleOrder      in number, --规则顺序
                                 strLocateCellNo in out varchar2,
                                 strErrorMsg     in out varchar2) is

    v_strSQL         varchar2(4096);
    v_strCellSortStr varchar2(1024);
    --v_Count          integer := 0;
    v_cs_get_cell cv_type;

    v_strCellNo       cdef_defcell.cell_no%type;
    v_nMaxQty         stock_content.qty%type;
    v_nArticleQty     stock_content.qty%type;
    v_nStockUsedCells number;
    v_nMixFlag        cdef_defcell.mix_flag%type;

    v_strOldCellNo cdef_defcell.cell_no%type;
    v_nUsedCells   number;
    v_nOwnerUsedCells number;

  begin

    strErrorMsg := 'Y|';

    --组查找SQL
    v_strSQL := 'select cdf.cell_no,cdf.Mix_Flag, ';
    v_strSQL := v_strSQL || '    cdf.MAX_CASE, ';
    v_strSQL := v_strSQL ||
                '    (select nvl(sum(cc.qty + cc.instock_qty), 0) ';
    v_strSQL := v_strSQL || '    from stock_content cc ';
    v_strSQL := v_strSQL ||
                '    where cc.enterprise_no=cdf.enterprise_no and cc.WAREHOUSE_NO = cdf.WAREHOUSE_NO ';
    v_strSQL := v_strSQL || '    and cc.cell_no = cdf.cell_no ';
    v_strSQL := v_strSQL || '    and cc.article_no=''' || strArticleNo ||
                ''') as article_qty,1 as stockno_used_cells, ';
    --Add BY QZH AT 2016-8-8
    v_strSQL := v_strSQL ||
                '(select count(distinct sc.cell_no) from stock_content sc,cdef_defcell icdf ';
    v_strSQL := v_strSQL ||
                ' where sc.enterprise_no=icdf.enterprise_no and sc.WAREHOUSE_NO=icdf.WAREHOUSE_NO ';
    v_strSQL := v_strSQL ||' and icdf.enterprise_no(+)=cdf.enterprise_no ';
    v_strSQL := v_strSQL ||' and icdf.warehouse_no(+)=cdf.warehouse_no ';
    v_strSQL := v_strSQL ||' and icdf.ware_no(+)=cdf.ware_no ';
    v_strSQL := v_strSQL ||' and icdf.area_no(+)=cdf.area_no ';
    v_strSQL := v_strSQL ||' and icdf.stock_no(+)=cdf.stock_no ';
    v_strSQL := v_strSQL ||
                ' and sc.owner_no='''||strOwnerNo|| ''' and sc.cell_no=icdf.cell_no ) as owner_used_cells ';
    v_strSQL := v_strSQL ||
                '   from cdef_defcell cdf, cdef_DEFAREA CDA,bdef_defowner o ';
    v_strSQL := v_strSQL || '   where (not exists (select ''x'' ';
    v_strSQL := v_strSQL || '   from CSET_CELL_ARTICLE cca ';
    v_strSQL := v_strSQL ||
                '   where cca.enterprise_no=cdf.enterprise_no and cca.WAREHOUSE_NO = cdf.WAREHOUSE_NO ';
    v_strSQL := v_strSQL || '   and cca.cell_no = cdf.cell_no ';
    v_strSQL := v_strSQL || '   and cca.article_no <> ''' || strArticleNo ||
                ''') or exists ';
    v_strSQL := v_strSQL || '   (select ''x'' ';
    v_strSQL := v_strSQL || '   from CSET_CELL_ARTICLE cca ';
    v_strSQL := v_strSQL ||
                '   where cca.enterprise_no=cdf.enterprise_no and cca.WAREHOUSE_NO = cdf.WAREHOUSE_NO ';
    v_strSQL := v_strSQL || '   and cca.cell_no = cdf.cell_no ';
    v_strSQL := v_strSQL || '   and cca.article_no = ''' || strArticleNo ||
                ''')) ';
    v_strSQL := v_strSQL || '   and cda.enterprise_no = cdf.enterprise_no ';
    v_strSQL := v_strSQL || '   and cda.warehouse_no = cdf.warehouse_no ';
    v_strSQL := v_strSQL || '   and cda.ware_no = cdf.ware_no ';
    v_strSQL := v_strSQL || '   and cda.area_no = cdf.area_no ';
    v_strSQL := v_strSQL || '   and CDF.CELL_STATUS in (''0'', ''3'') ';
    v_strSQL := v_strSQL || '   and cdf.CHECK_STATUS = ''0'' ';
    v_strSQL := v_strSQL || '   and cdf.enterprise_no = ''' ||
                strEnterPriseNo || ''' ';
    v_strSQL := v_strSQL || '   and cdf.WAREHOUSE_NO = ''' ||
                strWareHouseNo || ''' ';
    v_strSQL := v_strSQL || '   and cdf.ware_no = ''' || strWareNo || ''' ';
    v_strSQL := v_strSQL || '   and cdf.area_no = ''' || strAreaNo || ''' ';
    if strStockNo is not null then
      v_strSQL := v_strSQL || '    and cdf.stock_no = ''' || strStockNo ||
                  ''' ';
    end if;

    --货主关系
    v_strSQL := v_strSQL || '   and o.enterprise_no = ''' ||
                strEnterPriseNo || ''' ';
    v_strSQL := v_strSQL || '   and o.owner_no = ''' || strOwnerNo || ''' ';
    v_strSQL := v_strSQL ||
                '   and ((o.fixedcell_flag = 0
                                     and (cdf.mix_owner = 1 or
                                     (cdf.mix_owner = 0 and not exists(
                                     select ''x'' from stock_content sc
                                     where sc.enterprise_no = cdf.enterprise_no
                                       and sc.warehouse_no = cdf.warehouse_no
                                       and sc.cell_no = cdf.cell_no
                                       and sc.owner_no <> ''' ||
                strOwnerNo || '''
                                     )))) or  ';
    v_strSQL := v_strSQL || '        (o.fixedcell_flag = 1 and  ';
    v_strSQL := v_strSQL ||
                ' exists (select ''x'' from cset_owner_cell coc ';
    v_strSQL := v_strSQL || ' where coc.enterprise_no = cdf.enterprise_no ';
    v_strSQL := v_strSQL || '   and coc.warehouse_no = cdf.warehouse_no  ';
    v_strSQL := v_strSQL ||
                '   and coc.cell_no = cdf.cell_no  and coc.owner_no = ''' ||
                strOwnerNo || '''))) ';

    --只找空储位
    if nMergerFlag = Merger_EmptyOnly then
      v_strSQL := v_strSQL ||
                  '  and  not exists (select ''x'' from stock_content sc ';
      v_strSQL := v_strSQL ||
                  '  where sc.enterprise_no=cdf.enterprise_no and sc.warehouse_no=cdf.warehouse_no ';
      v_strSQL := v_strSQL ||
                  '  and sc.cell_no=cdf.cell_no and sc.QTY+sc.INSTOCK_QTY>0 ) ';
    end if;

    v_strSQL := v_strSQL || '    and (cdf.mix_flag = 2 or ';
    v_strSQL := v_strSQL || '    (cdf.mix_flag in (0,1) and ';
    v_strSQL := v_strSQL ||
                '    not exists (select ''x'' from stock_content sc ';
    v_strSQL := v_strSQL ||
                '    where sc.enterprise_no=cdf.enterprise_no and sc.warehouse_no=cdf.warehouse_no ';
    v_strSQL := v_strSQL || '    and sc.cell_no=cdf.cell_no ';
    v_strSQL := v_strSQL || '    and sc.article_no<>''' || strArticleNo ||
                ''')))';

    /*v_strSQL := v_strSQL || '    and not exists (select ''x'' ';
    v_strSQL := v_strSQL ||
                '           from CDEF_STOCK_GROUP csg, bdef_defarticle bda ';
    v_strSQL := v_strSQL ||
                '          where csg.warehouse_no = cds.warehouse_no ';
    v_strSQL := v_strSQL || '            and csg.ware_no = cds.ware_no ';
    v_strSQL := v_strSQL || '            and csg.area_no = cds.area_no ';
    v_strSQL := v_strSQL || '            and csg.stock_no = cds.stock_no ';
    v_strSQL := v_strSQL || '            and bda.group_no = csg.group_no ';
    v_strSQL := v_strSQL || '            and bda.article_no = ''' ||
                strArticleNo || ''') ';*/

    v_strSQL := v_strSQL ||
                '    AND (CDA.ITEM_TYPE = '''' OR CDA.ITEM_TYPE = ''0'') ';
    v_strSQL := v_strSQL || '  order by  case when  cdf.cell_no = ''' ||
                strPickCellNo || ''' then 0 else 1 end,';
    if nMergerFlag = Merger_MergFirst then
      v_strSQL := v_strSQL || '  article_qty desc, '; --先找有商品的储位
    else
      v_strSQL := v_strSQL || '  article_qty , ';
    end if;
    v_strSQL := v_strSQL || '    cdf.mix_flag  '; --再根据混载标识

    v_strCellSortStr := f_get_sortstring(strStockNo,
                                         strStockX,
                                         strStockY,
                                         strBayX,
                                         nStockFlag,
                                         nFloorFlag,
                                         nStockXFlag,
                                         nBayFlag,
                                         nSortFlag);

    if length(v_strCellSortStr) > 0 then
      v_strSQL := v_strSQL || ',' || v_strCellSortStr;
    end if;

    v_strOldCellNo := 'N';
    v_nUsedCells   := 0;
    for curLocateRule in (select *
                            from wms_defstrategy_d d
                           where d.strategy_type = 'I'
                             and d.RULE_ORDER = nRuleOrder
                             and exists
                           (select 'x'
                                    from bdef_defarticle bda
                                   where bda.enterprise_no = strEnterPriseNo
                                     and bda.article_no = strArticleNo
                                     and bda.I_STRATEGY = d.STRATEGY_ID)) loop
      open v_cs_get_cell for v_strSQL;
      loop

        fetch v_cs_get_cell
          into v_strCellNo,
               v_nMixFlag,
               v_nMaxQty,
               v_nArticleQty,
               v_nStockUsedCells,
               v_nOwnerUsedCells; --Modify BY QZH AT 2016-8-8
        EXIT WHEN v_cs_get_cell%NOTFOUND;

        v_nUsedCells := f_check_UseCells(strEnterPriseNo,
                                         strWareHouseNo,
                                         --strOwnerNo,
                                         strArticleNo,
                                         v_strCellNo);
        --加锁
        update cdef_defcell cdc
           set cdc.cell_status = cdc.cell_status
         where cdc.enterprise_no = strEnterPriseNo
           and cdc.warehouse_no = strWareHouseNo
           and cdc.cell_no = v_strCellNo;

        if curLocateRule.Limmit_Celluse = '1' and v_nArticleQty <= 0 then

          if nKeepCells > 0 and v_nUsedCells > nKeepCells then
            p_write_short_log(strEnterPriseNo,
                              strWareHouseNo,
                              v_strCellNo,
                              strOwnerNo,
                              'N',
                              strArticleNo,
                              nArticleID,
                              nPackingQty,
                              nLocateQTY,
                              'N',
                              '按保拣线定位到拣货区-超过最大可用储位数:' || v_nUsedCells || '>' ||
                              nKeepCells);
            exit;
          end if;

          /*if v_nUsedCells = nKeepCells then
            select count(distinct cell_no)
              into v_Count
              from stock_content
             where enterprise_no = strEnterPriseNo
               and article_no = strArticleNo
               and qty + instock_qty > 0
               and WAREHOUSE_NO = strWareHouseNo
               and cell_no = v_strCellNo;

            if v_Count <= 0 then
              exit;
            end if;
          end if;*/
        end if;

        begin
          select decode(bda.abc, 'A', cca.max_qty_a, cca.max_qty_na)
            into v_nMaxQty
            from cset_cell_article cca, bdef_defarticle bda
           where cca.warehouse_no = strWareHouseNo
             and cca.enterprise_no = strEnterPriseNo
             and cca.article_no = strArticleNo
             and cca.ware_no = strWareNo
             and cca.area_no = strAreaNo
             and cca.enterprise_no = bda.enterprise_no
             and cca.article_no = bda.article_no
             and (cca.stock_no = strStockNo or cca.stock_no = 'N');
        exception
          when no_data_found then
            v_nMaxQty := 0;
        end;

        --数量限制
        if curLocateRule.Limmit_Maxqty = '1' then
          if f_check_QTY(strEnterPriseNo,
                         strWareHouseNo,
                         --strOwnerNo,
                         strArticleNo,
                         v_nMaxQty,
                         nLocateQty,
                         v_strCellNo) = false then
            goto next_v_cs_get_cell;
          end if;
        end if;

        --箱数
        if curLocateRule.Limmit_Maxcase = '1' then
          if f_check_CaseQTY(strEnterPriseNo,
                             strWareHouseNo,
                             --strOwnerNo,
                             --strArticleNo,
                             nPackingQTY,
                             nLocateQty,
                             v_strCellNo) = false then
            goto next_v_cs_get_cell;
          end if;
        end if;

        --重量限制
        if curLocateRule.Limmit_Maxweight = '1' then
          if f_check_Weight(strEnterPriseNo,
                            strWareHouseNo,
                            --strOwnerNo,
                            strArticleNo,
                            nLocateQty,
                            v_strCellNo) = false then
            goto next_v_cs_get_cell;
          end if;
        end if;

        --非空储位
        if v_nArticleQty > 0 then
          --只找空储位
          if nMergerFlag = Merger_EmptyOnly then
            goto next_v_cs_get_cell;
          end if;

          --混批限制
          if curLocateRule.Limmit_Mixbatch = '1' then
            if f_check_ArticleBatch(strEnterPriseNo,
                                    strWareHouseNo,
                                    strOwnerNo,
                                    strArticleNo,
                                    nArticleID,
                                    v_strCellNo) = false then
              goto next_v_cs_get_cell;
            end if;
          end if;

          --混载
          if curLocateRule.Limmit_Mixarticle = '1' then
            if f_check_ArticleMix(strEnterPriseNo,
                                  strWareHouseNo,
                                  strOwnerNo,
                                  strArticleNo,
                                  nArticleID,
                                  v_strCellNo) = false then
              goto next_v_cs_get_cell;
            end if;
          end if;

          --限制类别
          if curLocateRule.Limmit_Maxgroupno = '1' then
            if f_check_Group(strEnterPriseNo,
                             strWareHouseNo,
                             --strOwnerNo,
                             strArticleNo,
                             v_strCellNo) = false then
              goto next_v_cs_get_cell;
            end if;
          end if;

          --log20160320 modi by lizhiping 因前面已做板、箱、重量判断，能到此处就可定位该货位
          --看是否可以并储位
          /*if v_nArticleQty + nLocateQty <= v_nMaxQty * nPackingQTY or
             v_nMaxQty <= 0 then
            strLocateCellNo := v_strCellNo;
            strErrorMsg     := 'Y|';
            return;
          end if;
          goto next_v_cs_get_cell;*/
        end if;

        --不能并入
        /*if nKeepCells > 0 and v_nUsedCells >= nKeepCells then
          exit;
        end if;*/

        strLocateCellNo := v_strCellNo;
        exit;
        <<next_v_cs_get_cell>>
        null;
      end loop;
    end loop;
  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_PickCellbyPickLine;

  --定位到保管位
  procedure p_SaveCellByPickLine(strEnterPriseNo in varchar2,
                                 strWareHouseNo  in varchar2, --仓库代码
                                 strOwnerNo      in varchar2, --货主代码
                                 strArticleNo    in varchar2, --商品代码
                                 nArticleID      in stock_article_info.article_id%type,
                                 nPackingQTY     in bdef_article_packing.packing_qty%type,
                                 blSameArticle   in boolean,
                                 --strOperateType in varchar2, --定位类型
                                 strSWareNo  in varchar2, --保管库
                                 strSAreaNo  in varchar2, --保管储区
                                 strSStockNo in varchar2, --保管通道
                                 strStockNo  in varchar2, --拣货位所在通道（如何拣货位到区，下面几个字段没有参考意义）
                                 strStockX   in varchar2, --拣货位所在格
                                 strStockY   in varchar2, --拣货位所在层
                                 strBayX     in varchar2, --拣货位所在位
                                 nLocateQty  in number, --定位数量
                                 nKeepCells  in number, --允许占用最大储位数
                                 nMergerFlag in number, --是否并入
                                 nStockFlag  in number, --
                                 nFloorFlag  in number, --
                                 nStockXFlag in number, --
                                 nBayFlag    in number, --
                                 nSortFlag   in number, --
                                 --nForceFlag      in number, --是否允许强制进入
                                 --nRuleID         in wms_defstrategy_d.rule_id%type,
                                 nRuleOrder      in wms_defstrategy_d.rule_order%type, --规则顺序
                                 strLocateCellNo in out varchar2,
                                 strErrorMsg     in out varchar2) is

    v_strSQL         varchar2(8192);
    v_strCellSortStr varchar2(4096);
    v_Count          integer := 0;
    v_cs_get_cell    cv_type;

    v_strCellNo       cdef_defcell.cell_no%type;
    v_nMaxQty         stock_content.qty%type;
    v_nArticleQty     stock_content.qty%type;
    v_nStockUsedCells number;
    v_nMixFlag        cdef_defcell.mix_flag%type;

    v_strOldCellNo cdef_defcell.cell_no%type;
    v_nUsedCells   number;
    v_nOwnerUsedCells number;

  begin

    strErrorMsg := 'N|';

    --组查找SQL
    v_strSQL := 'select cdf.cell_no,cdf.Mix_Flag, ';
    v_strSQL := v_strSQL || '   cdf.MAX_CASE, ';
    v_strSQL := v_strSQL ||
                '   (select nvl(sum(cc.qty + cc.instock_qty), 0) ';
    v_strSQL := v_strSQL || '   from stock_content cc ';
    v_strSQL := v_strSQL ||
                '   where cc.enterprise_no=cdf.enterprise_no and cc.WAREHOUSE_NO = cdf.WAREHOUSE_NO ';
    v_strSQL := v_strSQL || '   and cc.cell_no = cdf.cell_no ';
    v_strSQL := v_strSQL || '   and cc.article_no=''' || strArticleNo ||
                ''') as article_qty,';
    v_strSQL := v_strSQL ||
                '(select count(distinct sc.cell_no) from stock_content sc,cdef_defcell icdf ';
    v_strSQL := v_strSQL ||
                ' where sc.enterprise_no=icdf.enterprise_no and sc.WAREHOUSE_NO=icdf.WAREHOUSE_NO ';
    --Add BY QZH AT 2016-8-8
    v_strSQL := v_strSQL ||' and icdf.enterprise_no(+)=cdf.enterprise_no ';
    v_strSQL := v_strSQL ||' and icdf.warehouse_no(+)=cdf.warehouse_no ';
    v_strSQL := v_strSQL ||' and icdf.ware_no(+)=cdf.ware_no ';
    v_strSQL := v_strSQL ||' and icdf.area_no(+)=cdf.area_no ';
    v_strSQL := v_strSQL ||' and icdf.stock_no(+)=cdf.stock_no ';
    v_strSQL := v_strSQL ||
                '   and sc.cell_no=icdf.cell_no) as stockno_used_cells, ';
    v_strSQL := v_strSQL ||
                '(select count(distinct sc.cell_no) from stock_content sc,cdef_defcell icdf ';
    v_strSQL := v_strSQL ||
                ' where sc.enterprise_no=icdf.enterprise_no and sc.WAREHOUSE_NO=icdf.WAREHOUSE_NO ';
    v_strSQL := v_strSQL ||' and icdf.enterprise_no(+)=cdf.enterprise_no ';
    v_strSQL := v_strSQL ||' and icdf.warehouse_no(+)=cdf.warehouse_no ';
    v_strSQL := v_strSQL ||' and icdf.ware_no(+)=cdf.ware_no ';
    v_strSQL := v_strSQL ||' and icdf.area_no(+)=cdf.area_no ';
    v_strSQL := v_strSQL ||' and icdf.stock_no(+)=cdf.stock_no ';
    v_strSQL := v_strSQL ||
                ' and sc.owner_no='''||strOwnerNo|| ''' and sc.cell_no=icdf.cell_no ) as owner_used_cells ';
    v_strSQL := v_strSQL ||
                '   from cdef_defcell cdf, cdef_DEFAREA CDA,bdef_defowner o ';
    v_strSQL := v_strSQL ||
                '  where cdf.enterprise_no=cda.enterprise_no and cdf.WAREHOUSE_NO = cda.WAREHOUSE_NO ';
    v_strSQL := v_strSQL || '    and cdf.ware_no = cda.ware_no ';
    v_strSQL := v_strSQL || '    and cdf.area_no = cda.area_no ';

    v_strSQL := v_strSQL || '    and CDF.CELL_STATUS in (''0'', ''3'') ';
    v_strSQL := v_strSQL || '    and cdf.CHECK_STATUS = ''0'' ';
    v_strSQL := v_strSQL || '    and cda.WAREHOUSE_NO = ''' ||
                strWareHouseNo || ''' ';
    v_strSQL := v_strSQL || '    and cda.enterprise_no = ''' ||
                strEnterPriseNo || ''' ';
    v_strSQL := v_strSQL || '    and cda.ware_no = ''' || strSWareNo ||
                ''' ';
    v_strSQL := v_strSQL || '    and cda.area_no = ''' || strSAreaNo ||
                ''' ';
    if strSStockNo <> 'N' then
      v_strSQL := v_strSQL || '    and cdf.stock_no = ''' || strSStockNo ||
                  ''' ';
    end if;

    --货主关系
    v_strSQL := v_strSQL || '   and o.enterprise_no = ''' ||
                strEnterPriseNo || ''' ';
    v_strSQL := v_strSQL || '   and o.owner_no = ''' || strOwnerNo || ''' ';
    v_strSQL := v_strSQL ||
                '   and ((o.fixedcell_flag = ''0''
                                     and (cdf.mix_owner = ''1'' or
                                     (cdf.mix_owner = ''0'' and not exists(
                                     select ''x'' from stock_content sc
                                     where sc.enterprise_no = cdf.enterprise_no
                                       and sc.warehouse_no = cdf.warehouse_no
                                       and sc.cell_no = cdf.cell_no
                                       and sc.owner_no <> ''' ||
                strOwnerNo || '''
                                     )))) or  ';
    v_strSQL := v_strSQL || '        (o.fixedcell_flag = ''1'' and  ';
    v_strSQL := v_strSQL ||
                ' exists (select ''x'' from cset_owner_cell coc ';
    v_strSQL := v_strSQL || ' where coc.enterprise_no = cdf.enterprise_no ';
    v_strSQL := v_strSQL || '   and coc.warehouse_no = cdf.warehouse_no  ';
    v_strSQL := v_strSQL ||
                '   and coc.cell_no = cdf.cell_no  and coc.owner_no = ''' ||
                strOwnerNo || '''))) ';

    --同区相同商品
    if blSameArticle = true then
      v_strSQL := v_strSQL ||
                  '  and exists (select ''x'' from stock_content sc,cdef_defcell cdc ';
      v_strSQL := v_strSQL ||
                  ',stock_article_info sci1,stock_article_info sci2 ';
      v_strSQL := v_strSQL ||
                  '  where sc.enterprise_no=cdc.enterprise_no and cdc.enterprise_no=cda.enterprise_no  ';
      v_strSQL := v_strSQL ||
                  ' and sc.warehouse_no=cdc.warehouse_no and cdc.warehouse_no=CDA.warehouse_no ';
      v_strSQL := v_strSQL ||
                  ' and sci1.article_no=sc.article_no   and sci1.article_id=sc.article_id';
      v_strSQL := v_strSQL ||
                  ' and sci1.article_no=sci2.article_no   and sci1.BARCODE=sci2.BARCODE';
      v_strSQL := v_strSQL ||
                  ' and sci1.produce_date=sci2.produce_date   and sci1.expire_date=sci2.expire_date';
      v_strSQL := v_strSQL ||
                  ' and sci1.quality=sci2.quality   and sci1.lot_no=sci2.lot_no';
      v_strSQL := v_strSQL ||
                  ' and sci1.rsv_batch1=sci2.rsv_batch1 and  sci1.rsv_batch2=sci2.rsv_batch2';
      v_strSQL := v_strSQL ||
                  ' and sci1.rsv_batch3=sci2.rsv_batch3 and  sci1.rsv_batch4=sci2.rsv_batch4';
      v_strSQL := v_strSQL ||
                  ' and sci1.rsv_batch5=sci2.rsv_batch5 and  sci1.rsv_batch6=sci2.rsv_batch6';
      v_strSQL := v_strSQL ||
                  ' and sci1.rsv_batch7=sci2.rsv_batch7 and  sci1.rsv_batch8=sci2.rsv_batch8';
      v_strSQL := v_strSQL || '           and cdc.WARE_NO=CDA.WARE_NO ';
      v_strSQL := v_strSQL || '           and cdc.AREA_NO=CDA.AREA_NO ';
      v_strSQL := v_strSQL || '            and sc.cell_no=cdc.cell_no ';
      v_strSQL := v_strSQL || '            and sci1.article_id=' ||
                  nArticleID;
      v_strSQL := v_strSQL || '            and sc.article_no=''' ||
                  strArticleNo || ''')';
    end if;

    --只找空储位
    if nMergerFlag = Merger_EmptyOnly then
      v_strSQL := v_strSQL ||
                  '      and  not exists (select ''x'' from stock_content sc ';
      v_strSQL := v_strSQL ||
                  '      where sc.enterprise_no=cdf.enterprise_no and sc.warehouse_no=cdf.warehouse_no ';
      v_strSQL := v_strSQL ||
                  '      and sc.cell_no=cdf.cell_no and sc.QTY+sc.INSTOCK_QTY>0 ) ';
    end if;

    /*    v_strSQL := v_strSQL || '    and (cdf.mix_flag = 2 or ';
    v_strSQL := v_strSQL || '    (cdf.mix_flag in (0,1) and ';*/
    v_strSQL := v_strSQL ||
                '  and  not exists (select ''x'' from stock_content sc ';
    v_strSQL := v_strSQL ||
                '     where sc.enterprise_no=cdf.enterprise_no and sc.warehouse_no=cdf.warehouse_no ';
    v_strSQL := v_strSQL || '    and sc.cell_no=cdf.cell_no ';
    v_strSQL := v_strSQL || '    and sc.article_no<>''' || strArticleNo ||
                ''')';
    /* v_strSQL := v_strSQL || '    and not exists (select ''x'' ';
    v_strSQL := v_strSQL ||
                '           from CDEF_STOCK_GROUP csg, bdef_defarticle bda ';
    v_strSQL := v_strSQL ||
                '          where csg.warehouse_no = cds.warehouse_no ';
    v_strSQL := v_strSQL || '            and csg.ware_no = cds.ware_no ';
    v_strSQL := v_strSQL || '            and csg.area_no = cds.area_no ';
    v_strSQL := v_strSQL || '            and csg.stock_no = cds.stock_no ';
    v_strSQL := v_strSQL || '            and bda.group_no = csg.group_no ';
    v_strSQL := v_strSQL || '            and bda.article_no = ''' ||
                strArticleNo || ''') ';*/

    v_strSQL := v_strSQL ||
                '    AND (CDA.ITEM_TYPE = '''' OR CDA.ITEM_TYPE = ''0'') ';
    if nMergerFlag = Merger_MergFirst then
      --先合并
      v_strSQL := v_strSQL || '  order by article_qty desc, '; --先找有商品的储位
    else
      v_strSQL := v_strSQL || '  order by article_qty , ';
    end if;

    v_strSQL := v_strSQL || '           cdf.mix_flag '; --再根据混载标识
    dbms_output.put_line(v_strSQL);
    v_strCellSortStr := PKLG_ILOCATE.f_get_sortstring(strStockNo,
                                                      strStockX,
                                                      strStockY,
                                                      strBayX,
                                                      nStockFlag,
                                                      nFloorFlag,
                                                      nStockXFlag,
                                                      nBayFlag,
                                                      nSortFlag);
    if length(v_strCellSortStr) > 0 then
      v_strSQL := v_strSQL || ',' || v_strCellSortStr;
    end if;


    v_strOldCellNo := 'N';
    v_nUsedCells   := 0;
    for curLocateRule in (select *
                            from wms_defstrategy_d d
                           where d.strategy_type = 'I'
                             and d.RULE_ORDER = nRuleOrder
                             and exists
                           (select 'x'
                                    from bdef_defarticle bda
                                   where bda.enterprise_no = strEnterPriseNo
                                     and bda.article_no = strArticleNo
                                     and bda.I_STRATEGY = d.STRATEGY_ID)) loop

      dbms_output.put_line(v_strSQL);
      open v_cs_get_cell for v_strSQL;
      loop
        fetch v_cs_get_cell
          into v_strCellNo,
               v_nMixFlag,
               v_nMaxQty,
               v_nArticleQty,
               v_nStockUsedCells,
               v_nOwnerUsedCells; --Modify BY QZH AT 2016-8-8
        EXIT WHEN v_cs_get_cell%NOTFOUND;

        --加锁
        update cdef_defcell cdc
           set cdc.cell_status = cdc.cell_status
         where cdc.enterprise_no = strEnterPriseNo
           and cdc.warehouse_no = strWareHouseNo
           and cdc.cell_no = v_strCellNo;

        --最大可用储位数
        if curLocateRule.Limmit_Celluse = '1' and v_nArticleQty <= 0 then
          v_nUsedCells := f_check_UseCells(strEnterPriseNo,
                                           strWareHouseNo,
                                           --strOwnerNo,
                                           strArticleNo,
                                           v_strCellNo);
          if nKeepCells > 0 and v_nUsedCells > nKeepCells then
            p_write_short_log(strEnterPriseNo,
                              strWareHouseNo,
                              v_strCellNo,
                              strOwnerNo,
                              'N',
                              strArticleNo,
                              nArticleID,
                              nPackingQty,
                              nLocateQTY,
                              'N',
                              '按保拣线定位到保管区-超过最大可用储位数:' || v_nUsedCells || '>' ||
                              nKeepCells);
            exit;
          end if;
          if  nKeepCells > 0 and  v_nUsedCells = nKeepCells then
            select count(distinct cell_no)
              into v_Count
              from stock_content
             where enterprise_no = strEnterPriseNo
               and article_no = strArticleNo
               and qty + instock_qty > 0
               and WAREHOUSE_NO = strWareHouseNo
               and cell_no = v_strCellNo;

            if v_Count <= 0 then
              p_write_short_log(strEnterPriseNo,
                                strWareHouseNo,
                                v_strCellNo,
                                strOwnerNo,
                                'N',
                                strArticleNo,
                                nArticleID,
                                nPackingQty,
                                nLocateQTY,
                                'N',
                                '按保拣线定位到保管区-超过最大可用储位数:' || v_nUsedCells || '=' ||
                                nKeepCells);
              exit;
            end if;
          end if;
        end if;

        --板数量限制
        if curLocateRule.Limmit_Maxqty = '1' then
          if f_check_PalQTY(strEnterPriseNo,
                            strWareHouseNo,
                            --strOwnerNo,
                            strArticleNo,
                            nPackingQTY,
                            nLocateQty,
                            v_strCellNo) = false then
            goto next_v_cs_get_cell;
          end if;
        end if;

        --箱数
        if curLocateRule.Limmit_Maxcase = '1' then
          if f_check_CaseQTY(strEnterPriseNo,
                             strWareHouseNo,
                             --strOwnerNo,
                             --strArticleNo,
                             nPackingQTY,
                             nLocateQty,
                             v_strCellNo) = false then
            goto next_v_cs_get_cell;
          end if;
        end if;

        --重量限制
        if curLocateRule.Limmit_Maxweight = '1' then
          if f_check_Weight(strEnterPriseNo,
                            strWareHouseNo,
                            --strOwnerNo,
                            strArticleNo,
                            nLocateQty,
                            v_strCellNo) = false then
            goto next_v_cs_get_cell;
          end if;
        end if;

        if v_nArticleQty > 0 then

          --只找空储位
          if nMergerFlag = Merger_EmptyOnly then
            p_write_short_log(strEnterPriseNo,
                              strWareHouseNo,
                              v_strCellNo,
                              strOwnerNo,
                              'N',
                              strArticleNo,
                              nArticleID,
                              nPackingQty,
                              nLocateQTY,
                              'N',
                              '按保拣线定位到保管区-非空储位:');
            goto next_v_cs_get_cell;
          end if;

          --混批限制
          if curLocateRule.Limmit_Mixbatch = '1' then
            if f_check_ArticleBatch(strEnterPriseNo,
                                    strWareHouseNo,
                                    strOwnerNo,
                                    strArticleNo,
                                    nArticleID,
                                    v_strCellNo) = false then
              goto next_v_cs_get_cell;
            end if;
          end if;

          --混载
          if curLocateRule.Limmit_Mixarticle = '1' then
            if f_check_ArticleMix(strEnterPriseNo,
                                  strWareHouseNo,
                                  strOwnerNo,
                                  strArticleNo,
                                  nArticleID,
                                  v_strCellNo) = false then
              goto next_v_cs_get_cell;
            end if;
          end if;

          --限制类别
          if curLocateRule.Limmit_Maxgroupno = '1' then
            if f_check_Group(strEnterPriseNo,
                             strWareHouseNo,
                             --strOwnerNo,
                             strArticleNo,
                             v_strCellNo) = false then
              goto next_v_cs_get_cell;
            end if;
          end if;

        end if;

        strLocateCellNo := v_strCellNo;
        strErrorMsg     := 'Y|';
        exit;

        <<next_v_cs_get_cell>>
        null;
      end loop;
    end loop;
  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_SaveCellbyPickLine;

  --写上架指示
  procedure p_write_instockdirect(strEnterPriseNo in varchar2,
                                  strWareHouseNo  in varchar2, --仓库代码
                                  nRowid          in number, --定位指示行号
                                  strLocateCellNo in varchar2, --定位储位
                                  nLocate_QTY     in number, --定位数量
                                  strWorkNo       in varchar2, --员工代码
                                  strErrorMsg     in out varchar2) is

    v_nDestCellID stock_content.cell_id%type;

    v_strS_Cell_no  stock_content.cell_no%type; --来源储位
    v_nS_Cell_id    stock_content.cell_id%type; --来源储位ID
    v_strD_Label_No stock_content.label_no%type;
    v_strSubLaeblNo stock_content.sub_label_no%type;
    v_nQty          stock_content.qty%type := nLocate_QTY; --定位数量
    --v_strInstock_type stock_content.Instock_type%type;

  begin

    strErrorMsg := 'Y|';

    begin
      select ild.cell_no, ild.cell_id, ild.label_no, ild.sub_label_no --, ild.ARTICLE_QTY
        into v_strS_Cell_no, v_nS_Cell_id, v_strD_Label_No, v_strSubLaeblNo --, v_nQty
        from idata_locate_direct ild
       where ild.row_id = nRowid;
    exception
      when no_data_found then
        strErrorMsg := 'N|[E21708]'; --查原指示记录失败
        return;
    end;

    v_nQty := nLocate_QTY;

    --写库存信息
    PKOBJ_STOCK.p_UpdtContent_Reservation(strEnterPriseNo,
                                          strWareHouseNo, --仓库编码
                                          v_strS_Cell_no, --来源储位
                                          v_nS_Cell_id, --来源储位ID
                                          strLocateCellNo, --目的储位
                                          v_strD_Label_No,
                                          v_strSubLaeblNo,
                                          v_nQty, --商品包装
                                          '0', --预上类型
                                          strWorkNo, --操作人员
                                          v_nDestCellID, --储位id
                                          strErrorMsg);
    if substr(strErrorMsg, 1, 2) = 'N|' then
      return;
    end if;

    --写上架指示
    insert into idata_instock_direct
      (enterprise_no,
       warehouse_no,
       owner_no,
       locate_type,
       locate_row_id,
       source_no,
       auto_locate_flag,
       operate_type,
       cell_no,
       cell_id,
       article_no,
       article_id,
       packing_qty,
       dest_cell_no,
       dest_cell_id,
       instock_qty,
       status,
       check_chute_no,
       container_locate_flag,
       stock_type,
       stock_value,
       sub_label_no,
       label_no,
       business_type,
       locate_no,
       rgst_name,
       rgst_date,
       updt_name,
       updt_date,
       serial_no,
       import_type,
       quality)
      select ild.enterprise_no,
             ild.warehouse_no,
             ild.owner_no,
             ild.locate_type,
             ild.row_id,
             ild.source_no,
             ild.auto_locate_flag,
             ild.operate_type,
             ild.cell_no,
             ild.cell_id,
             ild.article_no,
             ild.article_id,
             ild.packing_qty,
             strLocateCellNo,
             v_nDestCellID,
             ild.article_qty,
             '10',
             'N',
             ild.container_locate_flag,
             ild.stock_type,
             ild.stock_value,
             ild.sub_label_no,
             ild.label_no,
             ild.business_type,
             ild.locate_no,
             strWorkNo,
             sysdate,
             strWorkNo,
             sysdate,
             ild.serial_no,
             ild.import_type,
             ild.quality
        from idata_locate_direct ild
       where ild.row_id = nRowid;

    if sql%rowcount <= 0 then
      strErrorMsg := 'N|[E21709]'; --新增上架指示失败
    end if;

    --写定位指示状态
    update idata_locate_direct ild
       set ild.status    = '13',
           ild.updt_name = strWorkNo,
           ild.updt_date = sysdate
     where ild.row_id = nRowid
       and ild.status = '10';
    if sql%rowcount <= 0 then
      strErrorMsg := 'N|[E21710]'; --更新定位指示失败
    end if;

  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_write_instockdirect;

  --获取保拣线
  function f_get_PickLine(strEnterPriseNo in bdef_defowner.enterprise_no%type,
                          strWareHouseNo  in bset_worker_loc.warehouse_no%type,
                          strOwnerNo      in bdef_defowner.owner_no%type,
                          strArticleNo    in bdef_defarticle.article_no%type,
                          strPickCellNo   in cset_cell_article.cell_no%type,
                          nLineID         in cset_cell_article.line_id%type,
                          nRuleID         in WMS_DEFSTRATEGY_D.Rule_Id%type)
    return varchar2 is
    v_strSQL    varchar2(4096);
    v_nPickNums integer := 0;
  begin

    v_nPickNums := f_GetCPickNum(strEnterPriseNo,
                                 strWareHouseNo,
                                 strArticleNo);
    v_strSQL    := ' SELECT bda.Expiry_Days,
       cam.s_ware_no as ware_no,
       cam.s_area_no as area_no,
       scdf.AREA_PICK,
       cdc.stock_no ,
       cdc.stock_x ,
       cdc.stock_y ,
       cdc.bay_x ,
       cdc.CELL_NO,
       cab.ware_no as s_ware_no,
       cab.area_no as s_area_no,
       cab.stock_no as s_stock_no,
       cab.STOCKX_FLAG,
       cab.Keep_Cells,
       SCDF.LIMIT_TYPE,
       SCDF.LIMIT_RATE,
       MERGER_FLAG,
       STOCK_FLAG,
       FLOOR_FLAG,
       STOCKX_FLAG,
       BAY_FLAG,
       SORT_FLAG
  FROM CSET_AREA_BACKUP_M CAM,CSET_AREA_BACKUP_D CAB,
  CDEF_DEFAREA SCDF,bdef_defarticle bda,
  (select c.enterprise_no,c.warehouse_no,c.ware_no,c.area_no,c.stock_no,c.stock_x,
    c.stock_y,c.bay_x,min(c.cell_no) cell_no
    from CDEF_DEFCELL c where c.enterprise_no=''' ||
                   strEnterPriseNo || ''' and c.warehouse_no=''' ||
                   strWareHouseNo || ''' and c.cell_no like ''' ||
                   strPickCellNo || '%''
    and  c.CELL_STATUS <> 1 and  c.CHECK_STATUS <> 3
    group by c.enterprise_no,c.warehouse_no,c.ware_no,c.area_no,c.stock_no,c.stock_x,
    c.stock_y,c.bay_x) CDC
    left join cset_cell_article cca on cca.enterprise_no = cdc.enterprise_no
    and cca.warehouse_no = cdc.warehouse_no
    and cca.article_no = ''' || strArticleNo || '''
    and cca.cell_no = ''' || strPickCellNo || '''
    left join CDEF_DEFAREA cda
    on cda.warehouse_no=cca.warehouse_no
    and cda.enterprise_no=cca.enterprise_no
    and cda.ware_no=cca.ware_no
    and cda.area_no=cca.area_no
  WHERE SCDF.WAREHOUSE_NO = cab.WAREHOUSE_NO
   and SCDF.enterprise_no = cab.enterprise_no
   AND SCDF.WARE_NO = cab.WARE_NO
   AND SCDF.AREA_NO = cab.AREA_NO
   and cab.enterprise_no = cam.enterprise_no
   and cab.warehouse_no = cam.warehouse_no
   and cab.line_id = cam.line_id
   and CAM.enterprise_no = ''' || strEnterPriseNo || '''
   AND CAM.warehouse_no = ''' || strWareHouseNo || '''
   and CAM.Line_Id = ' || nLineID || '
   and bda.ARTICLE_NO = ''' || strArticleNo || '''';

    /*v_strSQL := ' SELECT bda.Expiry_Days,cda.ware_no, ';
    v_strSQL := v_strSQL || '   cda.area_no,scdf.AREA_PICK,';
    v_strSQL := v_strSQL || '   nvl(cdc.stock_no, ''N'') stock_no,';
    v_strSQL := v_strSQL || '   nvl(cdc.stock_x, ''0'') stock_x,';
    v_strSQL := v_strSQL || '   nvl(cdc.stock_y, ''0'') stock_y,';
    v_strSQL := v_strSQL || '   nvl(cdc.bay_x, ''0'') bay_x,';
    v_strSQL := v_strSQL || '   NVL(cca.CELL_NO, ''N'') CELL_NO,';

    v_strSQL := v_strSQL || '   nvl(cab.ware_no,cda.ware_no) as s_ware_no,';
    v_strSQL := v_strSQL || '   nvl(cab.area_no,cda.area_no) as s_area_no,';
    v_strSQL := v_strSQL || '   nvl(cab.stock_no,''N''),';
    v_strSQL := v_strSQL || '   nvl(cab.STOCKX_FLAG,''0''),';
    v_strSQL := v_strSQL || '   nvl(cab.Keep_Cells,';
    v_strSQL := v_strSQL ||
                '   (CASE cda.a_flag WHEN ''1'' THEN cca.KEEP_CELLS_A ';
    v_strSQL := v_strSQL || '   ELSE cca.KEEP_CELLS END)) KEEP_CELLS,';
    v_strSQL := v_strSQL || '   SCDF.LIMIT_TYPE,SCDF.LIMIT_RATE,';

    v_strSQL := v_strSQL ||
                '   (CASE cda.a_flag WHEN ''1'' THEN cca.MAX_QTY_A';
    v_strSQL := v_strSQL || '   ELSE cca.MAX_QTY_NA END) MAX_QTY, ';
    v_strSQL := v_strSQL ||
                '   (CASE cda.a_flag WHEN ''1'' THEN cca.KEEP_CELLS_A ELSE ';
    v_strSQL := v_strSQL ||
                '    cca.KEEP_CELLS END) PICK_KEEP_CELLS,NVL(MERGER_FLAG, 1), ';
    v_strSQL := v_strSQL ||
                '    NVL(STOCK_FLAG, -1),NVL(FLOOR_FLAG, -1),NVL(STOCKX_FLAG, -1), ';
    v_strSQL := v_strSQL ||
                '    NVL(BAY_FLAG, -1),NVL(SORT_FLAG, -1)  FROM CSET_CELL_ARTICLE CCA ';
    v_strSQL := v_strSQL ||
                '  INNER JOIN bdef_defarticle bda ON bda.ARTICLE_NO = CCA.ARTICLE_NO ';
    v_strSQL := v_strSQL ||
                '  INNER JOIN CDEF_DEFAREA CDA ON cda.enterprise_no =cca.enterprise_no  ';
    v_strSQL := v_strSQL ||
                '  and CDA.warehouse_no = CCA.warehouse_no AND CDA.WARE_NO = CCA.WARE_NO ';
    v_strSQL := v_strSQL ||
                '  AND CDA.AREA_NO = CCA.AREA_NO AND cda.AREA_PICK = ''1'' ';
    v_strSQL := v_strSQL ||
                '   LEFT JOIN CDEF_DEFCELL CDC ON CDC.warehouse_no = CCA.warehouse_no ';
    v_strSQL := v_strSQL ||
                '   and cdc.enterprise_no=cca.enterprise_no AND CDC.CELL_NO = CCA.CELL_NO ';
    v_strSQL := v_strSQL ||
                '   LEFT JOIN CSET_AREA_BACKUP_D CAB ON CAB.WAREHOUSE_NO = CCA.WAREHOUSE_NO ';
    v_strSQL := v_strSQL ||
                '   AND CAB.LINE_ID = CCA.LINE_ID and cab.enterprise_no=cca.enterprise_no ';

    v_strSQL := v_strSQL ||
                '   LEFT JOIN CDEF_DEFAREA SCDF ON CAB.WAREHOUSE_NO = SCDF.WAREHOUSE_NO ';
    v_strSQL := v_strSQL ||
                '   and cab.enterprise_no=scdf.enterprise_no AND CAB.WARE_NO = SCDF.WARE_NO ';
    v_strSQL := v_strSQL || '   AND CAB.AREA_NO = SCDF.AREA_NO ';

    v_strSQL := v_strSQL || '  WHERE CCA.warehouse_no = ''' ||
                strWareHouseNo || ''' ';
    v_strSQL := v_strSQL || '  AND CCA.enterprise_no = ''' ||
                strEnterPriseNo || ''' ';
    v_strSQL := v_strSQL || '  AND CCA.OWNER_NO = ''' || strOwnerNo ||
                ''' ';
    v_strSQL := v_strSQL || '    AND CCA.ARTICLE_NO = ''' || strArticleNo ||
                ''' ';
    if v_nPickNums > 0 then
      v_strSQL := v_strSQL || ' AND CCA.PICK_TYPE = ''C'' ';
    else
      v_strSQL := v_strSQL || '  AND CCA.PICK_TYPE = ''B'' ';
    end if;
    v_strSQL := v_strSQL || '    AND NOT EXISTS ';
    v_strSQL := v_strSQL || '  (SELECT ''X'' ';
    v_strSQL := v_strSQL || '      FROM CDEF_DEFCELL CDC ';
    v_strSQL := v_strSQL ||
                '       WHERE CDC.warehouse_no = CCA.warehouse_no and cdc.enterprise_no=cca.enterprise_no ';
    v_strSQL := v_strSQL || '      AND CDC.CELL_NO = CCA.CELL_NO ';
    v_strSQL := v_strSQL ||
                '      AND (CDC.CELL_STATUS = ''1'' OR CDC.CHECK_STATUS = ''3'')) ';*/

    if nRuleID in (SaveArea_SameSKU_PickLine_Des, SaveArea_PickLine_Des) then
      v_strSQL := v_strSQL || ' order by CAB.A_LEVEL desc';
    else
      v_strSQL := v_strSQL || ' order by CAB.A_LEVEL ';
    end if;
    return v_strSQL;
  end;

  --获取储位排序字串,储位表的别名为cdf,每个通道已占储位数量为stockno_used_cells
  function f_get_sortstring(strStockNo  in varchar2, --拣货位所在通道（如何拣货位到区，下面几个字段没有参考意义）
                            strStockX   in varchar2, --拣货位所在格
                            strStockY   in varchar2, --拣货位所在层
                            strBayX     in varchar2, --拣货位所在位
                            nStockFlag  in number, --通道查找顺序
                            nFloorFlag  in number, --层数查找顺序
                            nStockXFlag in number, --储格查找顺序
                            nBayFlag    in number, --BAY查找顺序
                            nSortFlag   in number) --排列顺序
   return varchar2 is
    v_strSQL varchar2(1024);

    v_strStockNoSort varchar2(200);
    v_strFloorSort   varchar2(200);
    v_strBaySort     varchar2(200);
    v_strStockXSort  varchar2(200);
  begin

    v_strSQL := '';

    -------------------------------------
    --通道排序
    -------------------------------------
    v_strStockNoSort := '';
    --0:按通道平分
    if nStockFlag = 0 then
      v_strStockNoSort := 'stockno_used_cells||cdf.stock_no';
    end if;
    --1:按通道从小到大查找
    if nStockFlag = 1 then
      v_strStockNoSort := 'cdf.stock_no';
    end if;
    --2:从拣货位通道开始，左右偏移
    if nStockFlag = 2 then
      v_strStockNoSort := 'abs(to_number(cdf.stock_no) - ' || strStockNo || ')';
    end if;

    --ADD BY QZH AT 2016-8-8
    --3:按委托业主有货的通道开始
    if nStockFlag = 3 then
      v_strStockNoSort := '-owner_used_cells||cdf.stock_no';
    end if;

     --4:按委托业主有货的通道开始倒序
    if nStockFlag = 4 then
      v_strStockNoSort := 'owner_used_cells||cdf.stock_no';
    end if;

    ---------------------------------------
    --层数排序
    ---------------------------------------
    --0：从低到高；
    if nFloorFlag = 0 then
      v_strFloorSort := 'cdf.stock_y';
    end if;
    --1：从高到低；
    if nFloorFlag = 1 then
      v_strFloorSort := 'cdf.stock_y desc';
    end if;
    --2：从拣货位层数开始，上下偏移';
    if nFloorFlag = 2 then
      v_strFloorSort := 'abs(to_number(cdf.stock_y) - ' || strStockY || ')';
    end if;

    ---------------------------------------
    --BAY数排序
    ---------------------------------------
    --0：从小到大；
    if nBayFlag = 0 then
      v_strBaySort := 'cdf.stock_x || cdf.bay_x';
    end if;
    --1：从大到小；
    if nBayFlag = 1 then
      v_strBaySort := 'cdf.stock_x || cdf.bay_x desc';
    end if;
    --2：从拣货位BAY开始，左右偏移';
    if nBayFlag = 2 then
      v_strBaySort := 'abs(to_number(cdf.stock_x || cdf.bay_x) - to_number(' ||
                      strStockX || strBayX || '))';
    end if;

    ---------------------------------------
    --组排序串
    ---------------------------------------
    if nSortFlag = 0 then
      --先通道，再到层，再到BAY
      v_strSQL := v_strStockNoSort || ',' || v_strFloorSort || ',' ||
                  v_strBaySort;
    end if;

    if nSortFlag = 1 then
      --先通道，再到BAY，再到层
      v_strSQL := v_strStockNoSort || ',' || v_strBaySort || ',' ||
                  v_strFloorSort;
    end if;

    --拣货位列按从低到高排序
    v_strStockXSort := 'case when abs(to_number(cdf.stock_x || cdf.bay_x) - to_number(' ||
                       strStockX || strBayX ||
                       ')) = 0 then cdf.stock_y else ''100'' end';
    if nSortFlag = 2 then
      --先通道，再满足拣货位列，再到层，再到BAY
      v_strSQL := v_strStockNoSort || ',' || v_strStockXSort || ',' ||
                  v_strFloorSort || ',' || v_strBaySort;
    end if;

    if nSortFlag = 3 then
      --先通道，再满足拣货位列，再到BAY，再到层
      v_strSQL := v_strStockNoSort || ',' || v_strStockXSort || ',' ||
                  v_strBaySort || ',' || v_strFloorSort;
    end if;

    ---------------------------------------
    --储格排序
    ---------------------------------------
    --0：从小到大；
    if nStockXFlag = 0 then
      v_strStockXSort := 'cdf.stock_x';
    end if;
    --1：从大到小；
    if nStockXFlag = 1 then
      v_strStockXSort := 'cdf.stock_x desc';
    end if;
    --2：从拣货位BAY开始，左右偏移';
    if nStockXFlag = 2 then
      v_strStockXSort := 'abs(to_number(cdf.stock_x ) - ' || strStockX || ')';
    end if;

    if nSortFlag = 4 then
      --先通道，再储格，再到BAY，再到层
      v_strSQL := v_strStockNoSort || ',' || v_strStockXSort || ',' ||
                  v_strBaySort || ',' || v_strFloorSort;
    end if;

    if nSortFlag = 5 then
      --先通道，再储格，再到层，再到BAY
      v_strSQL := v_strStockNoSort || ',' || v_strStockXSort || ',' ||
                  v_strFloorSort || ',' || v_strBaySort;
    end if;
    return v_strSQL;
  end;

  --定位到最小库存的储位
  procedure p_locate_MinStockArea(strEnterPriseNo in varchar2,
                                  strWareHouseNo  in varchar2, --仓库代码
                                  strOwnerNo      in varchar2, --货主代码
                                  strArticleNo    in varchar2, --商品代码
                                  nPackingQTY     in bdef_article_packing.packing_qty%type,
                                  nArticleID      in number,
                                  nLocateQty      in number, --定位数量
                                  nRuleOrder      in number, --规则顺序
                                  strLocateCellNo out varchar2,
                                  strErrorMsg     out varchar2) is

    --v_PickMaxCellUse    cset_cell_article.keep_cells%type;
    --v_nUsedCells        cset_cell_article.keep_cells%type := 0;
    v_strAbnormalCellNo idata_instock_direct.cell_no%type; --异常储位

  begin
    strErrorMsg     := 'N|';
    strLocateCellNo := 'N';
    --获取异常储位
    begin
      select cell_no
        into v_strAbnormalCellNo
        from (select CDC.CELL_NO
                from cdef_defcell cdc, cdef_defarea cdd
               where cdc.enterprise_no = cdd.enterprise_no
                 and cdc.enterprise_no = strEnterPriseNo
                 and cdc.warehouse_no = cdd.warehouse_no
                 and cdc.ware_no = cdd.ware_no
                 and cdc.area_no = cdd.area_no
                 AND CDC.CELL_STATUS = '0'
                 AND CDC.CHECK_STATUS = 0
                 and cdd.AREA_ATTRIBUTE = '0'
                 and cdd.AREA_USETYPE = '5'
                 and cdd.warehouse_no = strWareHouseNo
               order by CDC.CELL_NO)
       where rownum <= 1;
    exception
      when no_data_found then
        strErrorMsg := 'N|[E21706]'; --获取异常区储位失败
        return;
    end;

    for curLocateRule in (select *
                            from wms_defstrategy_d d
                           where d.strategy_type = 'I'
                             and d.RULE_ORDER = nRuleOrder
                             and exists
                           (select 'x'
                                    from bdef_defarticle bda
                                   where bda.enterprise_no = strEnterPriseNo
                                     and bda.article_no = strArticleNo
                                     and bda.I_STRATEGY = d.STRATEGY_ID)) loop
      --最小库存的储位
      for curLocateCell in (select cdc.*
                              from cdef_defcell cdc,
                                   bdef_defowner o,
                                   (select sc.enterprise_no,
                                           sc.warehouse_no,
                                           sc.cell_no,
                                           sum(sc.qty - sc.outstock_qty) qty
                                      from stock_content sc
                                     where sc.enterprise_no = strEnterPriseNo
                                       and sc.warehouse_no = strWareHouseNo
                                       and sc.article_no = strArticleNo
                                     group by sc.enterprise_no,
                                              sc.warehouse_no,
                                              sc.cell_no) sc,
                                   cdef_defarea cd
                             where cdc.enterprise_no = cd.enterprise_no
                               and cdc.warehouse_no = cd.warehouse_no
                               and cdc.ware_no = cd.ware_no
                               and cdc.area_no = cd.area_no
                               and cd.area_usetype in ('1', '5', '6')
                               and cd.AREA_ATTRIBUTE = '0'
                               and cdc.cell_status <> '1'
                               and cdc.check_status = '0'
                               and cdc.enterprise_no = strEnterPriseNo
                               and cdc.WAREHOUSE_NO = strWareHouseNo
                               and cdc.enterprise_no = sc.enterprise_no
                               and cdc.warehouse_no = sc.warehouse_no
                               and cdc.cell_no = sc.cell_no
                               and sc.cell_no <> v_strAbnormalCellNo

                                  --不是其它商品拣货位
                               and not exists
                             (select 'x'
                                      from cset_cell_article cc
                                     where cc.WAREHOUSE_NO = cdc.WAREHOUSE_NO
                                       and cc.enterprise_no =
                                           cdc.enterprise_no
                                       and cc.cell_no = cdc.cell_no
                                       and cc.article_no <> strArticleNo)
                               and o.enterprise_no = strEnterPriseNo
                               and o.owner_no = strOwnerNo
                               and (o.fixedcell_flag = 0 or
                                   (o.fixedcell_flag = 1 and exists
                                    (select 'x'
                                        from cset_owner_cell coc
                                       where coc.enterprise_no =
                                             cdc.enterprise_no
                                         and coc.warehouse_no =
                                             cdc.warehouse_no
                                         and coc.cell_no = cdc.cell_no
                                         and coc.owner_no = strOwnerNo)))
                            --排序暂定这样
                             order by sc.qty, cdc.cell_no) loop

        --加锁
        update cdef_defcell cdc
           set cdc.cell_status = cdc.cell_status
         where cdc.enterprise_no = strEnterPriseNo
           and cdc.warehouse_no = curLocateCell.Warehouse_No
           and cdc.cell_no = curLocateCell.Cell_No;

        --板数量限制
        if curLocateRule.Limmit_Maxqty = '1' then
          if f_check_PalQTY(strEnterPriseNo,
                            strWareHouseNo,
                            --strOwnerNo,
                            strArticleNo,
                            nPackingQTY,
                            nLocateQty,
                            curLocateCell.Cell_No) = false then
            goto next_Cell_No;
          end if;
        end if;

        --混批限制
        if curLocateRule.Limmit_Mixbatch = '1' then
          if f_check_ArticleBatch(strEnterPriseNo,
                                  strWareHouseNo,
                                  strOwnerNo,
                                  strArticleNo,
                                  nArticleID,
                                  curLocateCell.Cell_No) = false then
            goto next_Cell_No;
          end if;
        end if;

        --混载
        if curLocateRule.Limmit_Mixarticle = '1' then
          if f_check_ArticleMix(strEnterPriseNo,
                                strWareHouseNo,
                                strOwnerNo,
                                strArticleNo,
                                nArticleID,
                                curLocateCell.Cell_No) = false then
            goto next_Cell_No;
          end if;
        end if;

        --箱数
        if curLocateRule.Limmit_Maxcase = '1' then
          if f_check_CaseQTY(strEnterPriseNo,
                             strWareHouseNo,
                             --strOwnerNo,
                             --strArticleNo,
                             nPackingQTY,
                             nLocateQty,
                             curLocateCell.Cell_No) = false then
            goto next_Cell_No;
          end if;
        end if;

        --重量限制
        if curLocateRule.Limmit_Maxweight = '1' then
          if f_check_Weight(strEnterPriseNo,
                            strWareHouseNo,
                            --strOwnerNo,
                            strArticleNo,
                            nLocateQty,
                            curLocateCell.Cell_No) = false then
            goto next_Cell_No;
          end if;
        end if;

        --限制类别
        if curLocateRule.Limmit_Maxgroupno = '1' then
          if f_check_Group(strEnterPriseNo,
                           strWareHouseNo,
                           --strOwnerNo,
                           strArticleNo,
                           curLocateCell.Cell_No) = false then
            goto next_Cell_No;
          end if;
        end if;

        strLocateCellNo := curLocateCell.Cell_No;
        strErrorMsg     := 'Y|';
        exit;
        <<next_Cell_No>>
        null;
      end loop;
    end loop;

  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_locate_MinStockArea;

  procedure p_write_short_log(strEnterpriseNo in idata_locate_direct.enterprise_no%type,
                              strWareHouseNo  in idata_locate_direct.warehouse_no%type, --仓库代码
                              strSourceNo     in idata_locate_direct.source_no%type, --定位号
                              strOwnerNo      in idata_locate_direct.owner_no%type, --货主
                              strCellNo       in idata_locate_direct.cell_no%type, --货位
                              strArticleNo    in idata_locate_direct.article_no%type, --商品编码
                              nArticleID      in idata_locate_direct.article_id%type, --商品批次ID
                              nPackingQty     in idata_locate_direct.packing_qty%type, --库存包装
                              nLocateQty      in idata_locate_direct.article_qty%type, --需求量
                              strOperateType  in idata_locate_direct.operate_type%type, --定位类型
                              strShortReason  in varchar2) is
    --不能定位原因
    pragma autonomous_transaction;
    --v_iCount            integer;
  begin
    insert into idata_locate_short_log
      (enterprise_no,
       warehouse_no,
       source_no,
       LOG_SERIAL,
       owner_no,
       article_no,
       article_id,
       packing_qty,
       cell_no,
       locate_qty,
       operate_type,
       fail_reason)
    values
      (strEnterpriseNo,
       strWareHouseNo,
       strSourceNo,
       SEQ_IDATA_LOCATE_SHORT_LOG.Nextval,
       strOwnerNo,
       strArticleNo,
       nArticleID,
       nPackingQty,
       strCellNo,
       nLocateQty,
       strOperateType,
       strShortReason);

    commit;
  end p_write_short_log;
end PKLG_ILOCATE;

/

