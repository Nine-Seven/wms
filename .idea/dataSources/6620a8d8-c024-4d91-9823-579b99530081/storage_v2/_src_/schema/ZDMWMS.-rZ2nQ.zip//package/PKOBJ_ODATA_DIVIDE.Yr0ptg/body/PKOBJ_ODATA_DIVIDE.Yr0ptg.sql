create package body        PKOBJ_ODATA_DIVIDE is

  procedure P_Odata_divide_label(strEnterPriseNo    in odata_divide_d.enterprise_no%type,
                                 strWareHouseNo     in odata_divide_d.warehouse_no%type, --仓库编码
                                 strOwner_No        in odata_divide_d.owner_no%type,
                                 strExp_Type        in odata_exp_m.exp_type%type,
                                 strSourceNo        in odata_divide_d.source_no%type, --来源单号
                                 strDivideNo        in odata_divide_d.divide_no%type, --分播单号
                                 strsContainerNo    in odata_divide_d.s_container_no%type, --来源容器号
                                 strDestContainerNo in odata_divide_d.cust_container_no%type, --目的容器号
                                 nDivideId          in odata_divide_d.divide_id%type, --
                                 strArticleNo       in odata_divide_d.article_no%type,
                                 nArticleId         in odata_divide_d.article_id%type,
                                 nPackingQty        in odata_divide_d.packing_qty%type,
                                 strExpNo           in odata_divide_d.exp_no%type,
                                 nRealQty           in odata_divide_d.real_qty%type,
                                 strCustNo          in odata_divide_d.Cust_No%type, --客户编码
                                 strUserId          in odata_divide_m.rgst_name%type,
                                 strResult          OUT varchar2) is
    v_iCount      integer;
    tmpQty        odata_divide_d.article_qty%type;
    v_strStatus   stock_label_m.status%type;
    v_strFlowFlag wms_deflabel_status.flow_flag%type;
    v_strAutoFlag wms_deflabel_status.must_run%type := '0';

  begin
    strResult := 'N|[P_Odata_divide_label]';

    --获取标签状态
    begin
      select status
        into v_strStatus
        from stock_label_m t
       where t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strWareHouseNo
         and t.container_no = strDestContainerNo;
    exception
      when no_data_found then
        strResult := 'N|[P_Odata_divide_label]';
        return;
    end;

    if v_strStatus = '60' then

      --获取标签类型
      pkobj_hb.p_getlabelnoFlow(strEnterPriseNo,
                                strWareHouseNo,
                                strOwner_No,
                                strExp_Type,
                                strsContainerNo,
                                v_strFlowFlag,
                                strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;

      if v_strFlowFlag = '0' then
        --获取下一标签状态
        pkobj_hb.p_GetLabelStatusFromWorkflow(strEnterPriseNo,
                                              strWareHouseNo,
                                              strOwner_No,
                                              strExp_Type,
                                              strsContainerNo,
                                              v_strStatus,
                                              v_strAutoFlag,
                                              strResult);
        if substr(strResult, 1, 1) <> 'Y' then
          return;
        end if;
      else
        v_strStatus := '61';
      end if;
    end if;

    --增加目的标签明细
    update stock_label_d sld
       set sld.qty       = qty + nRealQty,
           sld.updt_name = strUserId,
           sld.updt_date = sysdate
     where sld.warehouse_no = strWareHouseNo
       and sld.enterprise_no = strEnterPriseNo
       and sld.container_no = strdestContainerNo
       and sld.source_no = strSourceNo
       and sld.article_no = strArticleNo
       and sld.article_id = nArticleId
       and sld.Exp_No = strExpNo
       and sld.divide_id = nDivideId
       and rownum = 1;
    if sql%notfound then
      --获取标签明细的ROW_ID
      select nvl(max(row_id), 0)
        into v_iCount
        from stock_label_d sld
       where sld.container_no = strDestContainerNo
         and sld.warehouse_no = strWareHouseNo
         and sld.enterprise_no = strEnterPriseNo;

      insert into stock_label_d
        (enterprise_no,
         warehouse_no,
         batch_no,
         owner_no,
         source_no,
         container_no,
         container_type,
         article_no,
         article_id,
         packing_qty,
         qty,
         exp_no,
         wave_no,
         cust_no,
         sub_cust_no,
         line_no,
         status,
         divide_id,
         row_id,
         exp_type,
         dps_cell_no,
         deliver_obj,
         exp_date,
         advance_cell_no,
         advance_status,
         rgst_name,
         rgst_date,
         updt_name,
         updt_date,
         deliverobj_order)
        select sld.enterprise_no,
               strWareHouseNo,
               sld.batch_no,
               sld.owner_no,
               strSourceNo,
               strDestContainerNo,
               sld.container_type,
               strArticleNo,
               nArticleId,
               nPackingQty,
               nRealQty,
               sld.exp_no,
               sld.wave_no,
               strCustNo,
               sld.sub_cust_no,
               sld.line_no,
               v_strStatus,
               nDivideId,
               v_iCount + 1,
               sld.exp_type,
               sld.dps_cell_no,
               sld.deliver_obj,
               sld.exp_date,
               sld.advance_cell_no,
               sld.advance_status,
               sld.rgst_name,
               sld.rgst_date,
               strUserId,
               sysdate,
               sld.deliverobj_order
          from stock_label_d sld
         where sld.warehouse_no = strWareHouseNo
           and sld.enterprise_no = strEnterPriseNo
           and sld.container_no = strsContainerNo
           and sld.source_no = strSourceNo
           and sld.article_no = strArticleNo
           and sld.article_id = nArticleId
           and sld.Exp_No = strExpNo
           and sld.divide_id = nDivideId
           and rownum = 1;
      if sql%rowcount <= 0 then
        strResult := 'N|[新增目的标签明细失败(0行)]';
        return;
      end if;
    end if;

    --扣减来源标签明细
    update stock_label_d sld
       set sld.qty       = qty - nRealQty,
           sld.updt_name = strUserId,
           sld.updt_date = sysdate
     where sld.warehouse_no = strWareHouseNo
       and sld.enterprise_no = strEnterPriseNo
       and sld.container_no = strsContainerNo
       and sld.source_no = strSourceNo
       and sld.article_no = strArticleNo
       and sld.article_id = nArticleId
       and sld.Exp_No = strExpNo
       and sld.divide_id = nDivideId
       and rownum = 1;
    if sql%notfound then
      strResult := 'N|[E22511]';
      return;
    end if;

    -------------------------删除 标签明细为 0  的数据--------------------------
    DELETE stock_label_d
     WHERE warehouse_no = strWareHouseNo
       and enterprise_no = strEnterPriseNo
       AND CONTAINER_NO = strsContainerNo
       and QTY = 0;

    --检查标签明细是否都已分播完成
    select nvl(sum(qty), 0)
      into tmpQty
      from stock_label_d sld
     where sld.warehouse_no = strWareHouseNo
       and sld.enterprise_no = strEnterPriseNo
       AND CONTAINER_NO = strsContainerNo;

    if tmpQty = 0 then
      --标签明细已分播完成,需要置标签头档状态
      update stock_label_m t
         set t.status  = CLABELSTATUS.DIVIDED,
             updt_name = strUserId,
             updt_date = sysdate
       where t.warehouse_no = strWareHouseNo
         and t.enterprise_no = strEnterPriseNo
         AND t.CONTAINER_NO = strsContainerNo;
      -------------标签转历史
      PKOBJ_LABEL.proc_RemoveLabel(strEnterPriseNo,
                                   strwarehouseno,
                                   strsContainerNo,
                                   strResult);
      if instr(strResult, 'N', 1, 1) = 1 then
        return;
      end if;
    end if;
    strResult := 'Y';
  end P_Odata_divide_label;

  /****************************************************************************************************
     lich
     2015.05.29
     功能说明：分播墙回更新分播回单明细
  ******************************************************************************************************/
  procedure p_Wall_Update_Odata_Divide_D(strEnterPriseNo in odata_divide_d.enterprise_no%type,
                                         strWarehouseNo  in odata_divide_d.warehouse_no%type,
                                         strOwnerNo      in odata_divide_d.owner_no%type, --货主
                                         strDivideNO     in odata_divide_d.divide_no%type, --分播单号
                                         strDivideId     in odata_divide_d.divide_id%type, --指示序列
                                         nQty            in odata_divide_d.real_qty%type, --实际分播数量
                                         --  strCustContainerNo      in odata_divide_d.cust_container_no%type,--客户容器编码
                                         strDivideName in odata_divide_d.divide_name%type, --实际分播人员
                                         strOutMsg     out varchar2) is
  begin
    strOutMsg := 'N|[p_Wall_Update_Odata_Divide_D]';

    update ODATA_DIVIDE_D
       set REAL_QTY = real_qty + nQty,
           -- CUST_CONTAINER_NO = strCustContainerNo,
           DIVIDE_NAME = strDivideName,
           divide_date = sysdate
     where warehouse_no = strWarehouseNo
       and enterprise_no = strEnterPriseNo
       and OWNER_NO = strOwnerNo
       and DIVIDE_NO = strDivideNO
       and DIVIDE_ID = strDivideId;
    if sql%rowcount <= 0 then
      strOutMsg := 'N|';
      return;
    end if;
    strOutMsg := 'Y|成功';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_Wall_Update_Odata_Divide_D;

  /****************************************************************************************************
     lich
     2014.05.23
     功能说明：写分播单头档
  ******************************************************************************************************/
  procedure P_Insert_Odata_Divide_M(strEnterPriseNo in odata_divide_m.enterprise_no%type, --企业号
                                    strWarehouseNo  in odata_divide_m.warehouse_no%type, --仓别
                                    strOwnerNo      in odata_divide_m.owner_no%type, --货主
                                    dtOperateDate   in odata_divide_m.operate_date%type, --操作日期
                                    strDivideType   in odata_divide_m.divide_type%type, --分播类型  A:按商品分播；B:按容器分播；C:按客户分播
                                    strSourceType   in odata_divide_m.source_type%type,
                                    strWave_No      in odata_divide_m.wave_no%type,
                                    strBatchNo      in odata_divide_m.batch_no%type, --批次
                                    strDeviceNo     in odata_divide_m.device_no%type, --分播组号
                                    dtExpDate       in odata_divide_m.exp_date%type, --更新日期
                                    strRgstName     in odata_divide_m.rgst_name%type, --建立人员
                                    strDivideNo     out odata_divide_m.divide_no%type, --分播单号
                                    strOutMsg       out varchar2) is

  begin
    strOutMsg := 'N|[P_Insert_Odata_Divide_M]';
    --取分播单号
    PKLG_WMS_BASE.p_getsheetno(strEnterPriseNo,
                               strWarehouseNo,
                               CONST_DOCUMENTTYPE.ODATARD,
                               strDivideNo,
                               strOutMsg);
    if substr(strOutMsg, 1, 1) <> 'Y' then
      return;
    end if;
    --写分播单头档
    insert into odata_divide_m
      (enterprise_no,
       warehouse_no,
       owner_no,
       source_type,
       device_no,
       divide_no,
       operate_date,
       divide_type,
       wave_no,
       batch_no,
       status,
       exp_date,
       rgst_name,
       rgst_date)
    values
      (strEnterPriseNo,
       strWarehouseNo,
       strOwnerNo,
       strSourceType,
       strDeviceNo,
       strDivideNo,
       dtOperateDate,
       strDivideType,
       strWave_No,
       strBatchNo,
       '10',
       dtExpDate,
       strRgstName,
       sysdate);
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_Insert_Odata_Divide_M;

  /****************************************************************************************************
     lich
     2014.05.23
     功能说明：写分播单明细
  ******************************************************************************************************/
  procedure P_Insert_Odata_Divide_D(strEnterPriseNo    in odata_divide_d.enterprise_no%type,
                                    strWarehouseNo     in odata_divide_d.warehouse_no%type,
                                    strOwnerNo         in odata_divide_d.owner_no%type,
                                    strBatchNo         in odata_divide_d.batch_no%type,
                                    strDivideNo        in odata_divide_d.divide_no%type,
                                    strSourceNo        in odata_divide_d.source_no%type,
                                    strDivideId        in odata_divide_d.divide_id%type,
                                    dtOperateDate      in odata_divide_d.operate_date%type,
                                    strCustNo          in odata_divide_d.cust_no%type,
                                    strSubCustNo       in odata_divide_d.sub_cust_no%type,
                                    strExpType         in odata_divide_d.exp_type%type,
                                    strExpNo           in odata_divide_d.exp_no%type,
                                    strWaveNo          in odata_divide_d.wave_no%type,
                                    strArticleNo       in odata_divide_d.article_no%type,
                                    strArticleId       in odata_divide_d.article_id%type,
                                    strPackingQty      in odata_divide_d.packing_qty%type,
                                    strArticleQty      in odata_divide_d.article_qty%type,
                                    strSCellNo         in odata_divide_d.s_cell_no%type,
                                    strSCellId         in odata_divide_d.s_cell_id%type,
                                    strSContainerNo    in odata_divide_d.s_container_no%type,
                                    strDeliverArea     in odata_divide_d.deliver_area%type,
                                    strLineNo          in odata_divide_d.line_no%type,
                                    strTrunckCellNo    in odata_divide_d.trunck_cell_no%type,
                                    strCheckChuteNo    in odata_divide_d.check_chute_no%type,
                                    strDeliverObj      in odata_divide_d.deliver_obj%type,
                                    strDeliverobjOrder in odata_divide_d.deliverobj_order%type,
                                    dtOutstockDate     in odata_divide_d.outstock_date%type,
                                    strAssignNo        in odata_divide_d.assign_name%type,
                                    strDpsCellNo       in odata_divide_d.dps_cell_no%type,
                                    strASorterChuteNo  in odata_divide_d.a_sorter_chute_no%type,
                                    dtExpDate          in odata_divide_d.exp_date%type,
                                    strD_Label_No      in stock_label_m.label_no%type,
                                    strOutMsg          out varchar2) is
    nRowID integer;
  begin
    strOutMsg := 'N|[P_Insert_Odata_Divide_D]';

    --获取最大的单内序号
    select nvl(max(row_id) + 1, 1)
      into nRowId
      from odata_divide_d
     where enterprise_no = strEnterPriseNo
       and warehouse_no = strWarehouseNo
       and divide_no = strDivideNO;

    insert into odata_divide_d
      (enterprise_no,
       warehouse_no,
       owner_no,
       batch_no,
       divide_no,
       source_no,
       divide_id,
       row_id,
       operate_date,
       cust_no,
       sub_cust_no,
       exp_type,
       exp_no,
       wave_no,
       article_no,
       article_id,
       packing_qty,
       article_qty,
       real_qty,
       s_cell_no,
       s_cell_id,
       s_container_no,
       d_cell_no,
       d_cell_id,
       cust_container_no,
       deliver_area,
       status,
       line_no,
       trunck_cell_no,
       check_chute_no,
       deliver_obj,
       outstock_date,
       assign_name,
       dps_cell_no,
       a_sorter_chute_no,
       exp_date,
       deliverobj_order)
    values
      (strEnterPriseNo,
       strWarehouseNo,
       strOwnerNo,
       strBatchNo,
       strDivideNo,
       strSourceNo,
       strDivideId,
       nRowId,
       dtOperateDate,
       strCustNo,
       strSubCustNo,
       strExpType,
       strExpNo,
       strWaveNo,
       strArticleNo,
       strArticleId,
       strPackingQty,
       strArticleQty,
       0,
       strSCellNo,
       strSCellId,
       strSContainerNo,
       strSCellNo,
       -1,
       strD_Label_No,
       strDeliverArea,
       '10',
       strLineNo,
       strTrunckCellNo,
       strCheckChuteNo,
       strDeliverObj,
       dtOutstockDate,
       strAssignNo,
       strDpsCellNo,
       strASorterChuteNo,
       dtExpDate,
       strDeliverobjOrder);
    strOutMsg := 'Y|成功';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_Insert_Odata_Divide_D;

  /****************************************************************************************************
     lich
     2014.05.23
     功能说明：写分播单指示
  ******************************************************************************************************/
  procedure P_Insert_Odata_Divide_Direct(strEnterPriseNo in odata_divide_d.enterprise_no%type,
                                         strWarehouseNo  in odata_divide_d.warehouse_no%type,
                                         strSourceNo     in odata_divide_d.source_no%type,
                                         strContainerNo  in odata_divide_d.s_container_no%type,
                                         strOutMsg       out varchar2) is
  begin
    strOutMsg := 'N|[P_Insert_Odata_Divide_Direct]';
    Insert into ODATA_DIVIDE_DIRECT
      (enterprise_no,
       WAREHOUSE_NO,
       OWNER_NO,
       source_type,
       BATCH_NO,
       SOURCE_NO,
       DIVIDE_ID,
       OPERATE_DATE,
       CUST_NO,
       SUB_CUST_NO,
       device_no,
       ARTICLE_NO,
       ARTICLE_ID,
       PACKING_QTY,
       ARTICLE_QTY,
       S_CELL_NO,
       S_CELL_ID,
       S_CONTAINER_NO,
       EXP_TYPE,
       EXP_NO,
       WAVE_NO,
       DELIVER_AREA,
       STATUS,
       LINE_NO,
       TRUNCK_CELL_NO,
       CHECK_CHUTE_NO,
       DELIVER_OBJ,
       ADVANCE_CELL_NO,
       OUTSTOCK_DATE,
       DPS_CELL_NO,
       A_SORTER_CHUTE_NO,
       EXP_DATE,
       RGST_NAME,
       RGST_DATE,
       UPDT_NAME,
       UPDT_DATE,
       deliverobj_order)
      select a.enterprise_no,
             b.WAREHOUSE_NO,
             b.OWNER_NO,
             a.source_type,
             b.BATCH_NO,
             b.outstock_no,
             b.DIVIDE_ID,
             trunc(sysdate),
             b.CUST_NO,
             b.SUB_CUST_NO,
             b.device_no,
             b.ARTICLE_NO,
             b.ARTICLE_ID,
             b.PACKING_QTY,
             b.real_qty,
             b.d_cell_no,
             b.d_cell_id,
             b.d_CONTAINER_NO, --Modify BY QZH AT 2016-7-18 b.d_CONTAINER_NO,
             b.EXP_TYPE,
             b.EXP_NO,
             b.WAVE_NO,
             b.deliver_area,
             '10',
             b.LINE_NO,
             b.trunck_cell_no,
             b.check_chute_no,
             b.DELIVER_OBJ,
             b.ADVANCE_CELL_NO,
             b.outstock_date,
             b.DPS_CELL_NO,
             b.a_sorter_chute_no,
             b.exp_date,
             a.rgst_name,
             sysdate,
             a.updt_name,
             sysdate,
             b.deliverobj_order
        from odata_outstock_m a, odata_outstock_d b
       where a.warehouse_no = b.warehouse_no
         and a.outstock_no = b.outstock_no
         and a.enterprise_no = b.enterprise_no
         and a.warehouse_no = strWarehouseNo
         and a.enterprise_no = strEnterPriseNo
         and a.outstock_no = strSourceNo
         and b.real_qty > 0
         and b.divide_id in
             (select divide_id
                from stock_label_m slm, stock_label_d sld
               where slm.enterprise_no = sld.enterprise_no
                 and slm.warehouse_no = sld.warehouse_no
                 and slm.container_no = sld.container_no
                 and slm.enterprise_no = strEnterPriseNo
                 and slm.warehouse_no = strWarehouseNo
                 and slm.source_no = strSourceNo
                 and slm.container_no = strContainerNo);
    strOutMsg := 'Y|成功';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_Insert_Odata_Divide_Direct;

  /****************************************************************************************************
     lich
     2014.05.23
     功能说明：写分播单指示
  ******************************************************************************************************/
  procedure P_Insert_Divide_Direct(strEnterPriseNo in odata_divide_d.enterprise_no%type,
                                   strWarehouseNo  in odata_divide_d.warehouse_no%type,
                                   strSourceNo     in odata_divide_d.source_no%type,
                                   strContainerNo  in odata_divide_d.s_container_no%type,
                                   strOutMsg       out varchar2) is
  begin
    strOutMsg := 'N|[P_Insert_Odata_Divide_Direct]';
    Insert into ODATA_DIVIDE_DIRECT
      (enterprise_no,
       WAREHOUSE_NO,
       OWNER_NO,
       source_type,
       BATCH_NO,
       SOURCE_NO,
       DIVIDE_ID,
       OPERATE_DATE,
       CUST_NO,
       SUB_CUST_NO,
       device_no,
       ARTICLE_NO,
       ARTICLE_ID,
       PACKING_QTY,
       ARTICLE_QTY,
       S_CELL_NO,
       S_CELL_ID,
       S_CONTAINER_NO,
       EXP_TYPE,
       EXP_NO,
       WAVE_NO,
       DELIVER_AREA,
       STATUS,
       LINE_NO,
       TRUNCK_CELL_NO,
       CHECK_CHUTE_NO,
       DELIVER_OBJ,
       ADVANCE_CELL_NO,
       OUTSTOCK_DATE,
       DPS_CELL_NO,
       A_SORTER_CHUTE_NO,
       EXP_DATE,
       RGST_NAME,
       RGST_DATE,
       UPDT_NAME,
       UPDT_DATE,
       deliverobj_order)
      select a.enterprise_no,
             b.WAREHOUSE_NO,
             b.OWNER_NO,
             a.source_type,
             b.BATCH_NO,
             b.outstock_no,
             b.DIVIDE_ID,
             trunc(sysdate),
             b.CUST_NO,
             b.SUB_CUST_NO,
             b.device_no,
             b.ARTICLE_NO,
             b.ARTICLE_ID,
             b.PACKING_QTY,
             b.article_qty,
             b.d_cell_no,
             b.d_cell_id,
             strContainerNo, --Modify BY QZH AT 2016-7-18 b.d_CONTAINER_NO,
             b.EXP_TYPE,
             b.EXP_NO,
             b.WAVE_NO,
             b.deliver_area,
             '10',
             b.LINE_NO,
             b.trunck_cell_no,
             b.check_chute_no,
             b.DELIVER_OBJ,
             b.ADVANCE_CELL_NO,
             nvl(b.outstock_date,sysdate),
             b.DPS_CELL_NO,
             b.a_sorter_chute_no,
             b.exp_date,
             a.rgst_name,
             sysdate,
             a.updt_name,
             sysdate,
             b.deliverobj_order
        from odata_outstock_m a, odata_outstock_d b
       where a.warehouse_no = b.warehouse_no
         and a.outstock_no = b.outstock_no
         and a.enterprise_no = b.enterprise_no
         and a.warehouse_no = strWarehouseNo
         and a.enterprise_no = strEnterPriseNo
         and a.outstock_no = strSourceNo
         and b.divide_id in
             (select divide_id
                from stock_label_m slm, stock_label_d sld
               where slm.enterprise_no = sld.enterprise_no
                 and slm.warehouse_no = sld.warehouse_no
                 and slm.container_no = sld.container_no
                 and slm.enterprise_no = strEnterPriseNo
                 and slm.warehouse_no = strWarehouseNo
                 and slm.source_no = strSourceNo
                 and slm.container_no = strContainerNo);
    strOutMsg := 'Y|成功';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_Insert_Divide_Direct;

  /****************************************************************************************************
     lich
     2014.05.29
     功能说明：更新分播回单明细
  ******************************************************************************************************/
  procedure p_Update_Odata_Divide_D(strEnterPriseNo    in odata_divide_d.enterprise_no%type,
                                    strWarehouseNo     in odata_divide_d.warehouse_no%type,
                                    strOwnerNo         in odata_divide_d.owner_no%type, --货主
                                    strDivideNO        in odata_divide_d.divide_no%type, --分播单号
                                    strRowId           in odata_divide_d.row_id%type, --指示序列
                                    nQty               in odata_divide_d.real_qty%type, --实际分播数量
                                    strCustContainerNo in odata_divide_d.cust_container_no%type, --客户容器编码
                                    strDivideName      in odata_divide_d.divide_name%type, --实际分播人员
                                    strAddFlag         in odata_divide_m.divide_type%type, --1：按数量回单（单指示拆分多箱）;2：按记录数回单; 3-按数量不拆指示
                                    strOutMsg          out varchar2) is
    v_iCount integer := 0;
    nRowId   integer;
  begin
    strOutMsg := 'N|[p_Update_Odata_Divide_D]';

    if strAddFlag = '2' then
      --按记录更新
      update ODATA_DIVIDE_D
         set REAL_QTY          = nQty,
             CUST_CONTAINER_NO = strCustContainerNo,
             STATUS            = 13,
             DIVIDE_NAME       = strDivideName,
             divide_date       = sysdate
       where warehouse_no = strWarehouseNo
         and enterprise_no = strEnterPriseNo
         and OWNER_NO = strOwnerNo
         and DIVIDE_NO = strDivideNO
         and row_id = strRowId;
      if sql%rowcount <= 0 then
        strOutMsg := 'N|[p_Update_Odata_Divide_D]';
        return;
      end if;
    end if;

    --累加数量的方式回单(不拆指示分箱)
    if strAddFlag = '3' then
      --按记录更新
      update ODATA_DIVIDE_D
         set REAL_QTY          = REAL_QTY + nQty,
             CUST_CONTAINER_NO = strCustContainerNo,
             STATUS = case
                        when REAL_QTY+nQty >= ARTICLE_QTY THEN
                         '13'
                        ELSE
                         '10'
                      END,
             DIVIDE_NAME       = strDivideName,
             divide_date       = sysdate
       where warehouse_no = strWarehouseNo
         and enterprise_no = strEnterPriseNo
         and OWNER_NO = strOwnerNo
         and DIVIDE_NO = strDivideNO
         and ARTICLE_QTY >= REAL_QTY + nQty
         and row_id = strRowId;
      if sql%rowcount <= 0 then
        strOutMsg := 'N|[p_Update_Odata_Divide_D]';
        return;
      end if;
    end if;

    --累加数量的方式回单（一次一个箱子）
    if strAddFlag = '1' then
      for GetDivideItem in (select *
                              from odata_divide_d t
                             where t.enterprise_no = strEnterPriseNo
                               and t.warehouse_no = t.warehouse_no
                               and t.divide_no = strDivideNO
                               and t.row_id = strRowId
                               and t.status = '10') loop
        v_icount := v_icount + 1;

        if GetDivideItem.article_qty <> nQty then
          -- 当数量出现差异，拆分分播明细

          --获取最大的单内序号
          select nvl(max(row_id) + 1, 1)
            into nRowId
            from odata_divide_d
           where enterprise_no = strEnterPriseNo
             and warehouse_no = strWarehouseNo
             and divide_no = strDivideNO;

          insert into odata_divide_d
            (enterprise_no,
             warehouse_no,
             owner_no,
             batch_no,
             divide_no,
             source_no,
             divide_id,
             row_id,
             operate_date,
             cust_no,
             sub_cust_no,
             exp_type,
             exp_no,
             wave_no,
             article_no,
             article_id,
             packing_qty,
             article_qty,
             real_qty,
             s_cell_no,
             s_cell_id,
             s_container_no,
             d_cell_no,
             d_cell_id,
             cust_container_no,
             deliver_area,
             status,
             line_no,
             trunck_cell_no,
             check_chute_no,
             deliver_obj,
             outstock_date,
             assign_name,
             dps_cell_no,
             a_sorter_chute_no,
             exp_date,
             deliverobj_order)
            select strEnterpriseNo,
                   strWarehouseNo,
                   strOwnerNo,
                   ood.batch_no,
                   strDivideNo,
                   ood.source_no,
                   ood.divide_id,
                   nRowId,
                   ood.operate_date,
                   ood.cust_no,
                   ood.sub_cust_no,
                   ood.exp_type,
                   ood.exp_no,
                   ood.wave_no,
                   ood.article_no,
                   ood.article_id,
                   ood.packing_qty,
                   ood.article_qty - nQty,
                   0,
                   ood.s_cell_no,
                   ood.s_cell_id,
                   ood.s_container_no,
                   ood.d_cell_no,
                   ood.d_cell_id,
                   ood.cust_container_no,
                   ood.deliver_area,
                   '10',
                   ood.line_no,
                   ood.trunck_cell_no,
                   ood.check_chute_no,
                   ood.deliver_obj,
                   ood.outstock_date,
                   ood.assign_name,
                   ood.dps_cell_no,
                   ood.a_sorter_chute_no,
                   ood.exp_date,
                   ood.deliverobj_order
              from odata_divide_d ood
             where ood.enterprise_no = strEnterpriseNo
               and warehouse_no = strWareHouseNo
               and ood.divide_no = strDivideNo
               and ood.row_id = strRowId;

          --更新分播单明细

          update ODATA_DIVIDE_D
             set article_qty       = nqty,
                 REAL_QTY          = nQty,
                 CUST_CONTAINER_NO = strCustContainerNo,
                 STATUS            = 13,
                 DIVIDE_NAME       = strDivideName,
                 divide_date       = sysdate
           where warehouse_no = strWarehouseNo
             and enterprise_no = strEnterPriseNo
             and OWNER_NO = strOwnerNo
             and DIVIDE_NO = strDivideNO
             and row_id = strRowId;
          if sql%rowcount <= 0 then
            strOutMsg := 'N|[p_Update_Odata_Divide_D]';
            return;
          end if;
        else
          update ODATA_DIVIDE_D
             set REAL_QTY          = nQty,
                 CUST_CONTAINER_NO = strCustContainerNo,
                 STATUS            = 13,
                 DIVIDE_NAME       = strDivideName,
                 divide_date       = sysdate
           where warehouse_no = strWarehouseNo
             and enterprise_no = strEnterPriseNo
             and OWNER_NO = strOwnerNo
             and DIVIDE_NO = strDivideNO
             and row_id = strRowId;
          if sql%rowcount <= 0 then
            strOutMsg := 'N|[p_Update_Odata_Divide_D]';
            return;
          end if;
        end if;
      end loop;

      if v_icount = 0 then
        strOutMsg := 'N|[p_Update_Odata_Divide_D]';
        return;
      end if;
    end if;

    strOutMsg := 'Y|成功';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_Update_Odata_Divide_D;
  /****************************************************************************************************
     lich
     2014.05.29
     功能说明：更新分播回单头档
  ******************************************************************************************************/
  procedure p_Update_Odata_Divide_M(strEnterPriseNo in ODATA_divide_m.enterprise_no%type,
                                    strWarehouseNo  in ODATA_divide_m.warehouse_no%type,
                                    strDivideNo     in ODATA_divide_m.Divide_No%type,
                                    strUpdtName     in ODATA_divide_m.Updt_Name%type,
                                    strOutMsg       out varchar2) is
    v_iCount integer := 0;
  begin
    strOutMsg := 'N|[p_Update_Odata_Divide_M]';

    select count(*)
      into v_iCount
      from odata_divide_d d
     where d.divide_no = strDivideNo
       and d.warehouse_no = strWarehouseNo
       and d.enterprise_no = strEnterPriseNo
       and d.status <> 13;

    if v_iCount = 0 then
      --更新分播单主档
      update ODATA_divide_m
         set status    = '13',
             UPDT_NAME = strUpdtName,
             UPDT_DATE = sysdate,
             exp_date  = sysdate
       where warehouse_no = strWarehouseNo
         and enterprise_no = strEnterPriseNo
         and DIVIDE_NO = strDivideNo;

      if sql%rowcount <= 0 then
        strOutMsg := 'N|';
        return;
      end if;
    end if;
    strOutMsg := 'Y|成功';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_Update_Odata_Divide_M;
  /****************************************************************************************************
     lich
     2014.05.29
     功能说明：分播回单转历史
  ******************************************************************************************************/
  procedure p_Update_Odata_Divide_Hty(strEnterPriseNo in ODATA_divide_m.enterprise_no%type,
                                      strWarehouseNo  in ODATA_divide_m.warehouse_no%type,
                                      strOwnerNo      in odata_divide_m.owner_no%type,
                                      strDivideNo     in ODATA_divide_m.Divide_No%type,
                                      strOutMsg       out varchar2) is
  begin
    strOutMsg := 'N|[p_Update_Odata_Divide_Hty]';

    insert into ODATA_divide_mhty
      (Enterprise_No,
       source_type,
       warehouse_no,
       owner_no,
       DIVIDE_NO,
       OPERATE_DATE,
       DIVIDE_TYPE,
       BATCH_NO,
       WAVE_NO,
       STATUS,
       exp_date,
       device_no,
       RGST_NAME,
       RGST_DATE,
       UPDT_NAME,
       UPDT_DATE,
       --huangb 20160509
       REPORT_UP_SERIAL)
      select b.enterprise_no,
             b.source_type,
             b.warehouse_no,
             b.owner_no,
             b.DIVIDE_NO,
             b.OPERATE_DATE,
             b.DIVIDE_TYPE,
             b.BATCH_NO,
             b.wave_no,
             b.STATUS,
             b.exp_date,
             b.device_no,
             b.RGST_NAME,
             b.RGST_DATE,
             b.UPDT_NAME,
             b.UPDT_DATE,
             --huangb 20160509
             REPORT_UP_SERIAL
        from ODATA_divide_m b
       where b.warehouse_no = strWarehouseNo
         and b.enterprise_no = strEnterPriseNo
         and b.DIVIDE_NO = strDivideNo;

    insert into ODATA_divide_dhty
      (enterprise_no,
       warehouse_no,
       owner_no,
       batch_no,
       divide_no,
       source_no,
       divide_id,
       row_id,
       operate_date,
       cust_no,
       sub_cust_no,
       exp_type,
       exp_no,
       wave_no,
       article_no,
       article_id,
       packing_qty,
       article_qty,
       real_qty,
       s_cell_no,
       s_cell_id,
       s_container_no,
       d_cell_no,
       d_cell_id,
       cust_container_no,
       deliver_area,
       status,
       line_no,
       trunck_cell_no,
       check_chute_no,
       deliver_obj,
       outstock_date,
       assign_name,
       divide_name,
       Divide_Date,
       dps_cell_no,
       a_sorter_chute_no,
       exp_date,
       deliverobj_order)
      select b.enterprise_no,
             b.warehouse_no,
             b.owner_no,
             b.batch_no,
             b.divide_no,
             b.source_no,
             b.divide_id,
             b.row_id,
             b.operate_date,
             b.cust_no,
             b.sub_cust_no,
             b.exp_type,
             b.exp_no,
             b.wave_no,
             b.article_no,
             b.article_id,
             b.packing_qty,
             b.article_qty,
             b.real_qty,
             b.s_cell_no,
             b.s_cell_id,
             b.s_container_no,
             b.d_cell_no,
             b.d_cell_id,
             b.cust_container_no,
             b.deliver_area,
             b.status,
             b.line_no,
             b.trunck_cell_no,
             b.check_chute_no,
             b.deliver_obj,
             b.outstock_date,
             b.assign_name,
             b.divide_name,
             b.divide_date,
             b.dps_cell_no,
             b.a_sorter_chute_no,
             b.exp_date,
             b.deliverobj_order
        from ODATA_divide_d b
       where b.warehouse_no = strWarehouseNo
         and b.enterprise_no = strEnterPriseNo
         and b.DIVIDE_NO = strDivideNo;

    --分播指示数据转历史
    insert into ODATA_DIVIDE_DIRECThty
      (Enterprise_No,
       warehouse_no,
       OWNER_NO,
       BATCH_NO,
       SOURCE_NO,
       DIVIDE_ID,
       OPERATE_DATE,
       CUST_NO,
       SUB_CUST_NO,
       ARTICLE_NO,
       ARTICLE_ID,
       PACKING_QTY,
       ARTICLE_QTY,
       S_CELL_NO,
       S_CELL_ID,
       S_CONTAINER_NO,
       EXP_TYPE,
       EXP_NO,
       wAVE_NO,
       DELIVER_AREA,
       STATUS,
       LINE_NO,
       TRUNCK_CELL_NO,
       CHECK_CHUTE_NO,
       DELIVER_OBJ,
       ADVANCE_CELL_NO,
       OUTSTOCK_DATE,
       DPS_CELL_NO,
       RGST_NAME,
       RGST_DATE,
       UPDT_NAME,
       UPDT_DATE,
       A_SORTER_CHUTE_NO,
       exp_date,
       source_type,
       device_no,
       deliverobj_order)
      select b.enterprise_no,
             b.warehouse_no,
             b.OWNER_NO,
             b.BATCH_NO,
             b.SOURCE_NO,
             b.DIVIDE_ID,
             b.OPERATE_DATE,
             b.CUST_NO,
             b.SUB_CUST_NO,
             b.ARTICLE_NO,
             b.ARTICLE_ID,
             b.PACKING_QTY,
             b.ARTICLE_QTY,
             b.S_CELL_NO,
             b.S_CELL_ID,
             b.S_CONTAINER_NO,
             b.EXP_TYPE,
             b.EXP_NO,
             b.WAVE_NO,
             b.DELIVER_AREA,
             b.STATUS,
             b.LINE_NO,
             b.TRUNCK_CELL_NO,
             b.CHECK_CHUTE_NO,
             b.DELIVER_OBJ,
             b.ADVANCE_CELL_NO,
             b.OUTSTOCK_DATE,
             b.DPS_CELL_NO,
             b.RGST_NAME,
             b.RGST_DATE,
             b.UPDT_NAME,
             b.UPDT_DATE,
             b.A_SORTER_CHUTE_NO,
             b.exp_date,
             b.source_type,
             b.device_no,
             b.deliverobj_order
        from ODATA_DIVIDE_DIRECT b, ODATA_DIVIDE_D ODD
       where B.WAREHOUSE_NO = ODD.WAREHOUSE_NO
         and b.enterprise_no = odd.enterprise_no
         AND B.OWNER_NO = ODD.OWNER_NO
         AND B.DIVIDE_ID = ODD.DIVIDE_ID
         AND B.SOURCE_NO = ODD.SOURCE_NO
         and b.enterprise_no = strEnterPriseNo
         AND b.warehouse_no = strWarehouseNo
            -- and b.OWNER_NO = strOwnerNo
         and ODD.DIVIDE_NO = strDivideNo;

    delete from ODATA_DIVIDE_DIRECT
     where warehouse_no = strWarehouseNo
       and enterprise_no = strEnterPriseNo
       and divide_id in (select divide_id
                           from odata_divide_d
                          where warehouse_no = strWarehouseNo
                            and enterprise_no = strEnterPriseNo
                            and divide_no = strDivideNo)
       and owner_no = strOwnerNo;

    delete from ODATA_divide_d
     where warehouse_no = strWarehouseNo
       and enterprise_no = strEnterPriseNo
       and DIVIDE_NO = strDivideNo;

    delete from ODATA_divide_m
     where warehouse_no = strWarehouseNo
       and enterprise_no = strEnterPriseNo
       and DIVIDE_NO = strDivideNo;

    strOutMsg := 'Y|成功';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_Update_Odata_Divide_Hty;
end PKOBJ_ODATA_DIVIDE;

/

