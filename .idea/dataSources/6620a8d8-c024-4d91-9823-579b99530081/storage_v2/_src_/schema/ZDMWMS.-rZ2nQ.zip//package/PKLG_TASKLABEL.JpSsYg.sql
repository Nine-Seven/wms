create PACKAGE        pkLG_Tasklabel IS

--------------------------------------------------------出货发单写标签入口 begin-------------------------------------------------------------
  /*****************************************************************************************
     功能：写出货流水标签入口
  *****************************************************************************************/
  procedure P_O_WriteLabelSerial(strEnterPriseNo    in stock_label_m.enterprise_no%type,
                                 strwarehouse_no    in stock_label_m.warehouse_no%type, --仓别
                                 strOwnerNo         in odata_outstock_m.owner_no%type,
                                 strExpType         in odata_exp_m.exp_type%type,
                                 strOutStockNo      in odata_outstock_m.outstock_no%type, --下架单号
                                 strOperateType     in odata_outstock_m.operate_type%type,
                                 strSourceType      in odata_outstock_m.source_type%type,
                                 strPickType        in odata_outstock_m.pick_type%type,
                                 strTaskType        in odata_outstock_m.task_type%type,
                                 strPrintType       in odata_outstock_m.print_type%type,
                                 strOutstockType    in odata_outstock_m.outstock_type%type,
                                 strUserID          in stock_label_m.updt_name%type, --员工ID
                                 strOutMsg          out varchar2); --返回值

  /*****************************************************************************************
     功能：写补货流水标签入口
  *****************************************************************************************/
  procedure P_H_WriteLabelSerial(strEnterPriseNo      in stock_label_m.enterprise_no%type,
                                 strwarehouse_no      in stock_label_m.warehouse_no%type, --仓别
                                 strOwnerNo           in odata_outstock_m.owner_no%type,
                                 strOutStockNo        in odata_outstock_m.outstock_no%type, --下架单号
                                 strOperateType       in odata_outstock_m.operate_type%type,
                                 strSourceType        in odata_outstock_m.source_type%type,
                                 strPickType          in odata_outstock_m.pick_type%type,
                                 strTaskType          in odata_outstock_m.task_type%type,
                                 strPrintType         in odata_outstock_m.print_type%type,
                                 strOutstockType      in odata_outstock_m.outstock_type%type,
                                 strUserID            in stock_label_m.updt_name%type, --员工ID
                                 strOutMsg            out varchar2); --返回值

  /*****************************************************************************************
     功能：写出货任务标签入口
  *****************************************************************************************/
  procedure P_O_WriteLabelTask(strEnterPriseNo    in stock_label_m.enterprise_no%type,
                                 strwarehouse_no    in stock_label_m.warehouse_no%type, --仓别
                                 strOwnerNo         in odata_outstock_m.owner_no%type,
                                 strExpType         in odata_exp_m.exp_type%type,
                                 strOutStockNo      in odata_outstock_m.outstock_no%type, --下架单号
                                 strOperateType     in odata_outstock_m.operate_type%type,
                                 strSourceType      in odata_outstock_m.source_type%type,
                                 strPickType        in odata_outstock_m.pick_type%type,
                                 strTaskType        in odata_outstock_m.task_type%type,
                                 strPrintType       in odata_outstock_m.print_type%type,
                                 strOutstockType    in odata_outstock_m.outstock_type%type,
                                 strUserID          in stock_label_m.updt_name%type, --员工ID
                                 strOutMsg          out varchar2); --返回值

  /*****************************************************************************************
     功能：写补货任务标签入口
  *****************************************************************************************/
  procedure P_H_WriteLabelTask(strEnterPriseNo      in stock_label_m.enterprise_no%type,
                               strwarehouse_no      in stock_label_m.warehouse_no%type, --仓别
                               strOwnerNo           in odata_outstock_m.owner_no%type,
                               strOutStockNo        in odata_outstock_m.outstock_no%type, --下架单号
                               strOperateType       in odata_outstock_m.operate_type%type,
                               strSourceType        in odata_outstock_m.source_type%type,
                               strPickType          in odata_outstock_m.pick_type%type,
                               strTaskType          in odata_outstock_m.task_type%type,
                               strPrintType         in odata_outstock_m.print_type%type,
                               strOutstockType      in odata_outstock_m.outstock_type%type,
                               strUserID            in stock_label_m.updt_name%type, --员工ID
                               strOutMsg            out varchar2); --返回值

  --------------------------------------------------------出货发单写标签入口 end-------------------------------------------------------------


  --------------------------------------------------------出货流水标签 begin-------------------------------------------------------------
  /*****************************************************************************************
     功能：写出货流水标签——P 型
  *****************************************************************************************/
  procedure P_O_WriteLabelSerial_P(strEnterPriseNo      in stock_label_m.enterprise_no%type,
                                   strwarehouse_no      in stock_label_m.warehouse_no%type, --仓别
                                   strExpType           in odata_exp_m.exp_type%type,
                                   strOwnerNo           in odata_outstock_m.owner_no%type,
                                   strOutStockNo       in odata_outstock_m.outstock_no%type, --下架单号
                                   strOperateType      in odata_outstock_m.operate_type%type,
                                   strPickType         in odata_outstock_m.pick_type%type,
                                   strTaskType         in odata_outstock_m.task_type%type,
                                   strOutstockType     in odata_outstock_m.outstock_type%type,
                                   strSourceType       in odata_outstock_m.source_type%type,
                                   strPrintType        in odata_outstock_m.print_type%type,
                                   strUserID           in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg           out varchar2); --返回值

  /*****************************************************************************************
     功能：写出货流水标签——C 型
  *****************************************************************************************/
  procedure P_O_WriteLabelSerial_C(strEnterPriseNo      in stock_label_m.enterprise_no%type,
                                   strwarehouse_no      in stock_label_m.warehouse_no%type, --仓别
                                   strExpType           in odata_exp_m.exp_type%type,
                                   strOwnerNo           in odata_outstock_m.owner_no%type,
                                   strOutStockNo       in odata_outstock_m.outstock_no%type, --下架单号
                                   strPickType         in odata_outstock_m.pick_type%type,
                                   strPrintType        in odata_outstock_m.print_type%type,
                                   strUserID           in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg           out varchar2); --返回值

  /*****************************************************************************************
     功能：写出货流水标签——M 型

  *****************************************************************************************/
  procedure P_O_WriteLabelSerial_M(strEnterPriseNo      in stock_label_m.enterprise_no%type,
                                   strwarehouse_no      in stock_label_m.warehouse_no%type, --仓别
                                   strExpType           in odata_exp_m.exp_type%type,
                                   strOwnerNo           in odata_outstock_m.owner_no%type,
                                   strOutStockNo       in odata_outstock_m.outstock_no%type, --下架单号
                                   strOperateType      in odata_outstock_m.operate_type%type,
                                   strPickType         in odata_outstock_m.pick_type%type,
                                   strTaskType         in odata_outstock_m.task_type%type,
                                   strOutstockType     in odata_outstock_m.outstock_type%type,
                                   strSourceType       in odata_outstock_m.source_type%type,
                                   strPrintType        in odata_outstock_m.print_type%type,
                                   strUserID           in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg           out varchar2); --返回值

  --------------------------------------------------------出货流水标签 end---------------------------------------------------------------

  /*****************************************************************************************
     功能：写补货流水标签——C 型

  *****************************************************************************************/
  procedure P_H_WriteLabelSerial_C(strEnterPriseNo       in stock_label_m.enterprise_no%type,
                                   strwarehouse_no       in stock_label_m.warehouse_no%type, --仓别
                                   strOwnerNo            in odata_outstock_m.owner_no%type,
                                   strOutStockNo         in odata_outstock_m.outstock_no%type, --下架单号
                                   strOperateType        in odata_outstock_m.operate_type%type,
                                   strPickType           in odata_outstock_m.pick_type%type,
                                   strSourceType         in odata_outstock_m.source_type%type,--来源类型
                                   strTaskType           in odata_outstock_m.task_type%type,
                                   strOutstockType       in odata_outstock_m.outstock_type%type,
                                   strPrintType          in odata_outstock_m.print_type%type,
                                   strUserID             in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg             out varchar2); --返回值

  /*****************************************************************************************
     功能：写补货流水标签——B 型

  *****************************************************************************************/
  procedure P_H_WriteLabelSerial_B(strEnterPriseNo       in stock_label_m.enterprise_no%type,
                                   strwarehouse_no       in stock_label_m.warehouse_no%type, --仓别
                                   strOwnerNo            in odata_outstock_m.owner_no%type,
                                   strOutStockNo         in odata_outstock_m.outstock_no%type, --下架单号
                                   strOperateType        in odata_outstock_m.operate_type%type,
                                   strPickType           in odata_outstock_m.pick_type%type,
                                   strSourceType         in odata_outstock_m.source_type%type,--来源类型
                                   strTaskType           in odata_outstock_m.task_type%type,
                                   strOutstockType       in odata_outstock_m.outstock_type%type,
                                   strPrintType          in odata_outstock_m.print_type%type,
                                   strUserID             in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg             out varchar2); --返回值

  /*****************************************************************************************
     功能：写补货流水标签——M 型  判断参数 CreateLabelByOutstockNo  （ 0 一单多标签  1 一单一标签） 一单一标签 则按容器写标签

  *****************************************************************************************/
  procedure P_H_WriteLabelSerial_M(strEnterPriseNo       in stock_label_m.enterprise_no%type,
                                   strwarehouse_no       in stock_label_m.warehouse_no%type, --仓别
                                   strOwnerNo            in odata_outstock_m.owner_no%type,
                                   strOutStockNo         in odata_outstock_m.outstock_no%type, --下架单号
                                   strOperateType        in odata_outstock_m.operate_type%type,
                                   strPickType           in odata_outstock_m.pick_type%type,
                                   strSourceType         in odata_outstock_m.source_type%type,--来源类型
                                   strTaskType           in odata_outstock_m.task_type%type,
                                   strOutstockType       in odata_outstock_m.outstock_type%type,
                                   strPrintType          in odata_outstock_m.print_type%type,
                                   strUserID             in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg             out varchar2); --返回值

  --------------------------------------------------------补货流水标签 end---------------------------------------------------------------

  --------------------------------------------------------出货任务标签 begin-------------------------------------------------------------
  /*****************************************************************************************
     功能：写出货任务标签——P 型

  *****************************************************************************************/
  procedure P_O_WriteLabelTask_P(strEnterPriseNo      in stock_label_m.enterprise_no%type,
                                   strwarehouse_no      in stock_label_m.warehouse_no%type, --仓别
                                   strExpType           in odata_exp_m.exp_type%type,
                                   strOwnerNo           in odata_outstock_m.owner_no%type,
                                   strOutStockNo       in odata_outstock_m.outstock_no%type, --下架单号
                                   strOperateType      in odata_outstock_m.operate_type%type,
                                   strPickType         in odata_outstock_m.pick_type%type,
                                   strTaskType         in odata_outstock_m.task_type%type,
                                   strOutstockType     in odata_outstock_m.outstock_type%type,
                                   strSourceType       in odata_outstock_m.source_type%type,
                                   strPrintType        in odata_outstock_m.print_type%type,
                                   strUserID           in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg           out varchar); --返回值

  /*****************************************************************************************
     功能：写出货任务标签——C 型

  *****************************************************************************************/
  procedure P_O_WriteLabelTask_C(strEnterPriseNo      in stock_label_m.enterprise_no%type,
                                   strwarehouse_no      in stock_label_m.warehouse_no%type, --仓别
                                   strExpType           in odata_exp_m.exp_type%type,
                                   strOwnerNo           in odata_outstock_m.owner_no%type,
                                   strOutStockNo       in odata_outstock_m.outstock_no%type, --下架单号
                                   strOperateType      in odata_outstock_m.operate_type%type,
                                   strPickType         in odata_outstock_m.pick_type%type,
                                   strTaskType         in odata_outstock_m.task_type%type,
                                   strOutstockType     in odata_outstock_m.outstock_type%type,
                                   strSourceType       in odata_outstock_m.source_type%type,
                                   strPrintType        in odata_outstock_m.print_type%type,
                                   strUserID           in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg           out varchar); --返回值

  /*****************************************************************************************
     功能：写出货任务标签——D型
     huangb 20160625
  *****************************************************************************************/
  procedure P_O_WriteLabelTask_D(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                 strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                 strExpType      in odata_exp_m.exp_type%type,
                                 strOwnerNo      in odata_outstock_m.owner_no%type,
                                 strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                 strOperateType  in odata_outstock_m.operate_type%type,
                                 strPickType     in odata_outstock_m.pick_type%type,
                                 strTaskType     in odata_outstock_m.task_type%type,
                                 strOutstockType in odata_outstock_m.outstock_type%type,
                                 strSourceType   in odata_outstock_m.source_type%type,
                                 strPrintType    in odata_outstock_m.print_type%type,
                                 strUserID       in stock_label_m.updt_name%type, --员工ID
                                 strOutMsg       out varchar);

  /*****************************************************************************************
     功能：写出货任务标签——M 型

  *****************************************************************************************/
  procedure P_O_WriteLabelTask_M(strEnterPriseNo      in stock_label_m.enterprise_no%type,
                                   strwarehouse_no      in stock_label_m.warehouse_no%type, --仓别
                                   strExpType           in odata_exp_m.exp_type%type,
                                   strOwnerNo           in odata_outstock_m.owner_no%type,
                                   strOutStockNo       in odata_outstock_m.outstock_no%type, --下架单号
                                   strOperateType      in odata_outstock_m.operate_type%type,
                                   strPickType         in odata_outstock_m.pick_type%type,
                                   strTaskType         in odata_outstock_m.task_type%type,
                                   strOutstockType     in odata_outstock_m.outstock_type%type,
                                   strSourceType       in odata_outstock_m.source_type%type,
                                   strPrintType        in odata_outstock_m.print_type%type,
                                   strUserID           in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg           out varchar); --返回值

  /*****************************************************************************************
     功能：写出货任务标签——MIX型
     huangb 20160625
  *****************************************************************************************/
  procedure P_O_WriteLabelTask_MIX(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                   strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                   strExpType      in odata_exp_m.exp_type%type,
                                   strOwnerNo      in odata_outstock_m.owner_no%type,
                                   strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                   strOperateType  in odata_outstock_m.operate_type%type,
                                   strPickType     in odata_outstock_m.pick_type%type,
                                   strTaskType     in odata_outstock_m.task_type%type,
                                   strOutstockType in odata_outstock_m.outstock_type%type,
                                   strSourceType   in odata_outstock_m.source_type%type,
                                   strPrintType    in odata_outstock_m.print_type%type,
                                   strUserID       in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg       out varchar);

  --------------------------------------------------------出货任务标签 end---------------------------------------------------------------

  --------------------------------------------------------补货任务标签 begin-------------------------------------------------------------
  /*****************************************************************************************
     功能：写补货任务标签——C 型

  *****************************************************************************************/
  procedure P_H_WriteLabelTask_C(strEnterPriseNo       in stock_label_m.enterprise_no%type,
                                   strwarehouse_no       in stock_label_m.warehouse_no%type, --仓别
                                   strOwnerNo            in odata_outstock_m.owner_no%type,
                                   strOutStockNo         in odata_outstock_m.outstock_no%type, --下架单号
                                   strOperateType        in odata_outstock_m.operate_type%type,
                                   strPickType           in odata_outstock_m.pick_type%type,
                                   strSourceType         in odata_outstock_m.source_type%type,--来源类型
                                   strTaskType           in odata_outstock_m.task_type%type,
                                   strOutstockType       in odata_outstock_m.outstock_type%type,
                                   strPrintType          in odata_outstock_m.print_type%type,
                                   strUserID             in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg             out varchar2); --返回值

  /*****************************************************************************************
     功能：写补货任务标签——B 型

  *****************************************************************************************/
  procedure P_H_WriteLabelTask_B(strEnterPriseNo       in stock_label_m.enterprise_no%type,
                                   strwarehouse_no       in stock_label_m.warehouse_no%type, --仓别
                                   strOwnerNo            in odata_outstock_m.owner_no%type,
                                   strOutStockNo         in odata_outstock_m.outstock_no%type, --下架单号
                                   strOperateType        in odata_outstock_m.operate_type%type,
                                   strPickType           in odata_outstock_m.pick_type%type,
                                   strSourceType         in odata_outstock_m.source_type%type,--来源类型
                                   strTaskType           in odata_outstock_m.task_type%type,
                                   strOutstockType       in odata_outstock_m.outstock_type%type,
                                   strPrintType          in odata_outstock_m.print_type%type,
                                   strUserID             in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg             out varchar2); --返回值

  /*****************************************************************************************
     功能：写补货任务标签——M 型

  *****************************************************************************************/
  procedure P_H_WriteLabelTask_M(strEnterPriseNo       in stock_label_m.enterprise_no%type,
                                   strwarehouse_no       in stock_label_m.warehouse_no%type, --仓别
                                   strOwnerNo            in odata_outstock_m.owner_no%type,
                                   strOutStockNo         in odata_outstock_m.outstock_no%type, --下架单号
                                   strOperateType        in odata_outstock_m.operate_type%type,
                                   strPickType           in odata_outstock_m.pick_type%type,
                                   strSourceType         in odata_outstock_m.source_type%type,--来源类型
                                   strTaskType           in odata_outstock_m.task_type%type,
                                   strOutstockType       in odata_outstock_m.outstock_type%type,
                                   strPrintType          in odata_outstock_m.print_type%type,
                                   strUserID             in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg             out varchar2); --返回值

  --------------------------------------------------------补货任务标签 end---------------------------------------------------------------

end pkLG_Tasklabel;


/

