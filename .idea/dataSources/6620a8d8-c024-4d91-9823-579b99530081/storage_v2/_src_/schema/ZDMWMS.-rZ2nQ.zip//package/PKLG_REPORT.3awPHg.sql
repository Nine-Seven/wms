create package        PKLG_REPORT is

  -- Author  :
  -- Created : 2015/4/21 9:56:37
  -- Purpose :

  PROCEDURE P_Create_ArticlInvAcc_View(beginDate in stock_content_rj.jc_date%type, --查询日期
                                       endDate   in stock_content_rj.jc_date%type,
                                       strOutMsg   out varchar2); --返回值

  PROCEDURE P_GetMaxDay (strYear   in integer,
               strMonth  in integer,
               strDay    out integer);

  PROCEDURE P_CreatSql(
               strMonth  in integer,
               strDay    in integer,
               strFlag   in varchar2, --1：初期库存；2：出入库；4：结算库存
               strSql    in out VARCHAR2 );

end PKLG_REPORT;


/

