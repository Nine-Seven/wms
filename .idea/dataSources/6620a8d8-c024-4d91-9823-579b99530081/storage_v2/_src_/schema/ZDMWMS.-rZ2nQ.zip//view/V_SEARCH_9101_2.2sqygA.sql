create view V_SEARCH_9101_2 as
SELECT c.owner_no,c.owner_cust_no,
     c.cust_no,c.cust_flag,
     c.cust_type,c.shipping_method,
     c.box_deliver,c.cust_name,
     c.cust_alias,c.cust_address,
     c.cust_postcode,c.delivery_address,
     c.cust_phone1,c.cust_fax1,c.cust_email1，
     c.contactor_name1,c.status,
     c.create_flag,c.enterprise_no,
     f_get_fieldtext('N','CREATE_FLAG',c.create_flag) as creatFlagText,
     c.divide_order,
     c.cust_notecode,C.INVOICE_NO,
     f_get_fieldtext('N','DEF_STATUS',c.status) as statusText
  FROM bdef_defcust c,BDEF_DEFOWNER o
  where c.OWNER_NO = o.OWNER_NO
  and c.enterprise_no =c.enterprise_no


/

