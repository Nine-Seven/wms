create view V_SEARCH_9109_2 as
select
   a.WAREHOUSE_NO,
   a.OWNER_NO,
   a.instock_no,
   a.INSTOCK_WORKER,
   a.WORKER_NAME,
   INSTOCK_DATE,
   sum(LABELCOUNT)LABELCOUNT,
   sum(InstockQty)InstockQty,
   sum(INSTOCKBOX)INSTOCKBOX,
   sum(INSTOCKDIS)INSTOCKDIS,
   sum(VOLUMN)VOLUMN,
   sum(WEIGHT)WEIGHT
from (
   select iim.warehouse_no,
       iim.owner_no,
       iim.instock_no,
       iim.instock_worker,
       bdw.worker_name,
       iid.article_no,
       iid.packing_qty,
       vapvw.packing_volumn,
       vapvw.packing_weight,
       to_char(iid.updt_date,'yyyy-mm-dd') as INSTOCK_DATE,
       count(distinct iid.real_cell_no) as labelCount,
       sum(iid.real_qty) InstockQty,
       trunc(sum(iid.real_qty/iid.packing_qty)) InstockBox,
       sum(mod(iid.real_qty,iid.packing_qty)) InstockDis,
       trunc(sum(iid.real_qty/iid.packing_qty))*vapvw.packing_volumn volumn,
       trunc(sum(iid.real_qty/iid.packing_qty))*vapvw.packing_weight weight
  from idata_instock_mhty iim,
       idata_instock_dhty iid,
       bdef_defworker     bdw,
       v_article_pack_volumn_weight vapvw
  where iim.instock_no = iid.instock_no
    and iim.instock_worker = bdw.worker_no
    and iid.article_no=vapvw.article_no
    and iid.packing_qty=vapvw.packing_qty
  group by
    iim.warehouse_no,
    iim.owner_no,
    iim.instock_no,
    iim.instock_worker,
    bdw.worker_name,
    iid.article_no,
    iid.packing_qty,
    vapvw.packing_volumn,
    vapvw.packing_weight，
    to_char(iid.updt_date,'yyyy-mm-dd')
) a
group by
   a.WAREHOUSE_NO,
   a.OWNER_NO,
   a.instock_no,
   a.INSTOCK_WORKER,
   a.WORKER_NAME,
   INSTOCK_DATE
order by
   a.instock_no desc


/

