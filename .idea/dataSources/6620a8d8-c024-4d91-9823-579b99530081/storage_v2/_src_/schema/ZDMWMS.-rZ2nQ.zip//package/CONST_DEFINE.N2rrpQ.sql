create PACKAGE        Const_DEFINE IS

        -- 按仓
        cAllotRule_Ware CONSTANT  varchar2(1) := '1';
        --按储区
        cAllotRule_Area CONSTANT  varchar2(1) := '2';
        --按巷道
        cAllotRule_Stock CONSTANT  varchar2(1) := '3';
        --按储区+层
        cAllotRule_Area_Layer CONSTANT  varchar2(1) := '4';
        --按巷道+层
        cAllotRule_Stock_Layer CONSTANT  varchar2(1) := '5';
        --按电子标签区域
        cAllotRule_DPS_Area CONSTANT  varchar2(1) := '6';
        --按来源单号
        cAllotRule_Source_No CONSTANT  varchar2(1) := '7';

        --切单标识,不切单
        cSplitFlag_No_Cute CONSTANT  varchar2(1) := '0';
        --切单标识,切单
        cSplitFlag_Cute CONSTANT  varchar2(1) := '1';

        --一般存储
        cOutTaskType_cStorage CONSTANT  varchar2(1) := '1';
        --客户
        cOutTaskType_cCust CONSTANT  varchar2(1) := '2';
        --订单
        cOutTaskType_cOrder CONSTANT  varchar2(1) := '3';
        --供应商
        cOutTaskType_cSuppliers CONSTANT  varchar2(1) := '4';

        -- 出货下架
        COutStockType_OmOutstock constant odata_outstock_m.outstock_type%type:='0';

        --出货补货
         COutStockType_Replenishment constant odata_outstock_m.outstock_type%type:= '1';

        -- 批次补货
         COutStockType_BatReplenishment constant odata_outstock_m.outstock_type%type:= '2';

        -- 安全量补货
         COutStockType_SafeVolume constant odata_outstock_m.outstock_type%type:= '3';

        -- 人工移库
         COutStockType_Artificially constant odata_outstock_m.outstock_type%type:= '4';

        -- 直通出货
         COutStockType_OMIDOutstock constant odata_outstock_m.outstock_type%type:= '5';

        -- 虚拟商品出货
         COutStockType_VirtualOutstock constant odata_outstock_m.outstock_type%type:= '6';

        -- 移库类型（人工移库、安全量、出货补货、批次补货）
         COutStockType_MoveType constant odata_outstock_m.outstock_type%type:= '7';

        -- 越库出货
         COutStockType_OverWare constant odata_outstock_m.outstock_type%type:= '8';

         -- <summary> 普通
         CSource_Type_COMMON CONSTANT  varchar2(1) := '1';
        -- <summary> 标签
         CSource_Type_LABEL CONSTANT  varchar2(1) := '2';
        -- <summary> 客户别

         CSource_Type_CUST CONSTANT  varchar2(1) := '3';
        -- <summary> 大批量

         CSource_Type_MASS CONSTANT  varchar2(1) := '4';
        -- <summary> 外贸客户别

         CSource_Type_TRADE_CUST CONSTANT  varchar2(1) := '5';
        -- <summary> 直通

         CSource_Type_STRAIGHT CONSTANT  varchar2(1) := '6';
        -- <summary> 赠品

         CSource_Type_GIFT CONSTANT  varchar2(1) := '7';
        -- <summary> 特殊
         CSource_Type_SPECIAL CONSTANT  varchar2(1) := '8';

        -- 不切单（按区域等切单）
        cBoxFlag_No_Cute CONSTANT  varchar2(1):= '0';

        -- 按拣货物流箱号
        cBoxFlag_Cute_By_Cases CONSTANT  varchar2(1) := '1';

        -- 按标准堆叠板切单
        cBoxFlag_Cute_By_Pals_Stack CONSTANT  varchar2(1) := '2';

        -- 按一板一单+品项数限制
        cBoxFlag_Cute_By_PAL_Items CONSTANT  varchar2(1) := '3';

        -- 4：按一板一单+重量
        cBoxFlag_Cute_By_PAL_Weight CONSTANT  varchar2(1) := '4';

        -- 5：按一板一单+箱数
        cBoxFlag_Cute_By_PAL_Cases CONSTANT  varchar2(1) := '5';

        -- 按来源板号
        cBoxFlag_Cute_By_PalNo CONSTANT  varchar2(1) := '6';





END CONST_DEFINE;


/

