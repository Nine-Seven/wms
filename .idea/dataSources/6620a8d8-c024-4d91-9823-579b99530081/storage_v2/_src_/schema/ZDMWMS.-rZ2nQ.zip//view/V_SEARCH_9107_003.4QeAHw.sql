create view V_SEARCH_9107_003 as
select c."ENTERPRISE_NO",c."WAREHOUSE_NO",c."OWNER_NO",c."OUTSTOCK_NO",c."OPERATE_DATE",c."SOURCE_NO",c."ARTICLE_QTY",c."OUTSTOCK_QTY",c."REAL_QTY",c."ARTICLE_NO",c."ARTICLE_NAME",c."BARCODE",c."SUPPLIER_NO",c.outstock_qty-real_qty notscanqty
  from (select rod.enterprise_no,
               rod.warehouse_no,
               rod.owner_no,
               rod.outstock_no,
               trunc(rom.operate_date) operate_date,
               rod.source_no,
               sum(rod.outstock_qty) article_qty,
               sum(rod.outstock_qty) outstock_qty,
               sum(rod.real_qty) real_qty,
               rod.article_no,
               v.ARTICLE_NAME,
               v.BARCODE,
               v.SUPPLIER_NO
          from rodata_outstock_m rom
          join rodata_outstock_d rod
            on rom.enterprise_no = rod.enterprise_no
           and rom.warehouse_no = rod.warehouse_no
           and rom.owner_no = rod.owner_no
           and rom.outstock_no = rod.outstock_no
          join bdef_defarticle v
            on rod.owner_no = v.OWNER_NO
           and rod.enterprise_no = v.ENTERPRISE_NO
           and rod.article_no = v.ARTICLE_NO
         where rom.status = '11'
         having sum(rod.outstock_qty) - sum(rod.real_qty) > 0
         group by rod.enterprise_no,
                  rod.warehouse_no,
                  rod.owner_no,
                  rod.outstock_no,
                  rom.operate_date,
                  rod.source_no,
                  rod.article_no,
                  v.ARTICLE_NAME,
                  v.BARCODE,
                  v.SUPPLIER_NO) c
 order by c.outstock_no, c.supplier_no, c.article_no


/

