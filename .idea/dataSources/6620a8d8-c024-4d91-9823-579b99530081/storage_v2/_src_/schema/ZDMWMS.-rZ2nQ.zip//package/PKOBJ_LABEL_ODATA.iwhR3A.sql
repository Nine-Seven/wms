create PACKAGE        pkOBJ_label_odata IS

  --------------------------------------------------------出货发单写标签入口 begin-------------------------------------------------------------
  --------------------------------------------------------按容器写标签 begin-------------------------------------------------------------
  /*****************************************************************************************
     功能：按容器写标签——M 补货，暂未实现，报表ID未定义
  *****************************************************************************************/
  procedure P_H_WriteLabelContainerNo_M(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                        strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                        strOwnerNo      in odata_outstock_m.owner_no%type,
                                        strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                        strOperateType  in odata_outstock_m.operate_type%type,
                                        strSourceType   in odata_outstock_m.source_type%type,
                                        strPickType     in odata_outstock_m.pick_type%type,
                                        strPrintType    in odata_outstock_m.print_type%type,
                                        strUserID       in stock_label_m.updt_name%type, --员工ID
                                        strOutMsg       out varchar2); --返回值

  /*****************************************************************************************
     功能：按容器写标签——P 型   出货，

  *****************************************************************************************/
  procedure P_O_WriteLabelContainerNo_P(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                        strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                        strOwnerNo      in odata_outstock_m.owner_no%type,
                                        strExpType      in odata_exp_m.exp_type%type,
                                        strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                        strOperateType  in odata_outstock_m.operate_type%type,
                                        strSourceType   in odata_outstock_m.source_type%type,
                                        strPickType     in odata_outstock_m.pick_type%type,
                                        strPrintType    in odata_outstock_m.print_type%type,
                                        strUserID       in stock_label_m.updt_name%type, --员工ID
                                        strOutMsg       out varchar2); --返回值

  /*****************************************************************************************
     功能：按容器写标签——B 型  出货，

  *****************************************************************************************/
  procedure P_O_WriteLabelContainerNo_B(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                        strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                        strOwnerNo      in odata_outstock_m.owner_no%type,
                                        strExpType      in odata_exp_m.exp_type%type,
                                        strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                        strOperateType  in odata_outstock_m.operate_type%type,
                                        strSourceType   in odata_outstock_m.source_type%type,
                                        strPickType     in odata_outstock_m.pick_type%type,
                                        strPrintType    in odata_outstock_m.print_type%type,
                                        strUserID       in stock_label_m.updt_name%type, --员工ID
                                        strOutMsg       out varchar2); --返回值

  /*****************************************************************************************
     功能：按容器写标签——D 型  出货
  *****************************************************************************************/
  procedure P_O_WriteLabelContainerNo_D(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                        strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                        strOwnerNo      in odata_outstock_m.owner_no%type,
                                        strExpType      in odata_exp_m.exp_type%type,
                                        strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                        strOperateType  in odata_outstock_m.operate_type%type,
                                        strSourceType   in odata_outstock_m.source_type%type,
                                        strPickType     in odata_outstock_m.pick_type%type,
                                        strPrintType    in odata_outstock_m.print_type%type,
                                        strUserID       in stock_label_m.updt_name%type, --员工ID
                                        strOutMsg       out varchar2); --返回值

  --------------------------------------------------------按容器写标签 end---------------------------------------------------------------

  --------------------------------------------------------写任务标签 begin---------------------------------------------------------------
  /*****************************************************************************************
     功能：写任务标签——C型出货、M 型出货 、大批量出货、 出大Ｐ标签
  *****************************************************************************************/
  procedure P_O_WriteLabelTask_PCM(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                   strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                   strOwnerNo      in odata_outstock_m.owner_no%type,
                                   strExpType      in odata_exp_m.exp_type%type,
                                   strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                   strOperateType  in odata_outstock_m.operate_type%type,
                                   strSourceType   in odata_outstock_m.source_type%type,
                                   strPickType     in odata_outstock_m.pick_type%type,
                                   strPrintType    in odata_outstock_m.print_type%type,
                                   strUserID       in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg       out varchar2); --返回值

  /*****************************************************************************************
     功能：写任务标签——MIX标签(出P型标签)
     huangb20160625
  *****************************************************************************************/
  procedure P_O_WriteLabelTask_MIX(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                   strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                   strOwnerNo      in odata_outstock_m.owner_no%type,
                                   strExpType      in odata_exp_m.exp_type%type,
                                   strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                   strOperateType  in odata_outstock_m.operate_type%type,
                                   strSourceType   in odata_outstock_m.source_type%type,
                                   strPickType     in odata_outstock_m.pick_type%type,
                                   strPrintType    in odata_outstock_m.print_type%type,
                                   strUserID       in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg       out varchar2);

  /*****************************************************************************************
     功能：写任务标签——D标签(出C型标签)
     huangb20160625
  *****************************************************************************************/
  procedure P_O_WriteLabelTask_D(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                 strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                 strOwnerNo      in odata_outstock_m.owner_no%type,
                                 strExpType      in odata_exp_m.exp_type%type,
                                 strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                 strOperateType  in odata_outstock_m.operate_type%type,
                                 strSourceType   in odata_outstock_m.source_type%type,
                                 strPickType     in odata_outstock_m.pick_type%type,
                                 strPrintType    in odata_outstock_m.print_type%type,
                                 strUserID       in stock_label_m.updt_name%type, --员工ID
                                 strOutMsg       out varchar2);

  /*****************************************************************************************
     功能：写任务标签——B型补货、C型补货  出大Ｐ标签
  *****************************************************************************************/
  procedure P_H_WriteLabelTask_BC(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                  strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                  strOwnerNo      in odata_outstock_m.owner_no%type,
                                  strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                  strOperateType  in odata_outstock_m.operate_type%type,
                                  strPickType     in odata_outstock_m.pick_type%type,
                                  strTaskType     in odata_outstock_m.task_type%type,
                                  strOutstockType in odata_outstock_m.outstock_type%type,
                                  strPrintType    in odata_outstock_m.print_type%type,
                                  strUserID       in stock_label_m.updt_name%type, --员工ID
                                  strOutMsg       out varchar2); --返回值

  /*****************************************************************************************
     功能：写任务标签——C型出货、M 型出货  分播  （ 其中不可上分拣 写任务 大 P 标签  ）  出大Ｐ标签

  *****************************************************************************************/
  procedure P_O_WriteLabelTask_CM_S(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                    strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                    strOwnerNo      in odata_outstock_m.owner_no%type,
                                    strExpType      in odata_exp_m.exp_type%type,
                                    strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                    strPickType     in odata_outstock_m.pick_type%type,
                                    strPrintType    in odata_outstock_m.print_type%type,
                                    strSorterFlag   in bdef_article_packing.sorter_flag%type, --是否可上分拣
                                    strUserID       in stock_label_m.updt_name%type, --员工ID
                                    strOutMsg       out varchar2); --返回值
  --------------------------------------------------------写任务标签 end-----------------------------------------------------------------

  --------------------------------------------------------写流水标签 begin---------------------------------------------------------------
  /*****************************************************************************************
     功能：写流水标签——P 、型 出货 ( 只出  C 箱标签)

  *****************************************************************************************/
  procedure P_O_WriteLabelSerial_PT(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                    strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                    strOwnerNo      in odata_outstock_m.owner_no%type,
                                    strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                    strOperateType  in odata_outstock_m.operate_type%type,
                                    strPickType     in odata_outstock_m.pick_type%type,
                                    strTaskType     in odata_outstock_m.task_type%type,
                                    strOutstockType in odata_outstock_m.outstock_type%type,
                                    strUserID       in stock_label_m.updt_name%type, --员工ID
                                    strOutMsg       out varchar2); --返回值

  /*****************************************************************************************
     功能：写流水标签——B 型  补货
  *****************************************************************************************/
  procedure P_H_WriteLabelSerial_BT(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                    strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                    strOwnerNo      in odata_outstock_m.owner_no%type,
                                    strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                    strOperateType  in odata_outstock_m.operate_type%type,
                                    strPickType     in odata_outstock_m.pick_type%type,
                                    strTaskType     in odata_outstock_m.task_type%type,
                                    strOutstockType in odata_outstock_m.outstock_type%type,
                                    strUserID       in stock_label_m.updt_name%type, --员工ID
                                    strOutMsg       out varchar2); --返回值

  /*****************************************************************************************
     功能：写流水标签——C型  出货
  *****************************************************************************************/
  procedure P_O_WriteLabelSerial_CT(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                    strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                    strOwnerNo      in odata_outstock_m.owner_no%type,
                                    strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                    strSorterFlag   in bdef_article_packing.sorter_flag%type, --是否可上分拣
                                    strUserID       in stock_label_m.updt_name%type, --员工ID
                                    strOutMsg       out varchar2); --返回值

  /*****************************************************************************************
     功能：写流水标签——C （补货） (可出板标签 和 C 箱标签)
  *****************************************************************************************/
  procedure P_H_WriteLabelSerial_CT(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                    strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                    strOwnerNo      in odata_outstock_m.owner_no%type,
                                    strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                    strOperateType  in odata_outstock_m.operate_type%type,
                                    strPickType     in odata_outstock_m.pick_type%type,
                                    strTaskType     in odata_outstock_m.task_type%type,
                                    strOutstockType in odata_outstock_m.outstock_type%type,
                                    strPrintType    in odata_outstock_m.print_type%type,
                                    strUserID       in stock_label_m.updt_name%type, --员工ID
                                    strOutMsg       out varchar2); --返回值

  /*****************************************************************************************
     功能：写流水标签——M 型  出货
  *****************************************************************************************/
  procedure P_O_WriteLabelSerial_MT(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                    strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                    strOwnerNo      in odata_outstock_m.owner_no%type,
                                    strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                    strOperateType  in odata_outstock_m.operate_type%type,
                                    strPickType     in odata_outstock_m.pick_type%type,
                                    strTaskType     in odata_outstock_m.task_type%type,
                                    strOutstockType in odata_outstock_m.outstock_type%type,
                                    strUserID       in stock_label_m.updt_name%type, --员工ID
                                    strOutMsg       out varchar2); --返回值

  /*****************************************************************************************
     功能：写流水标签——出货   客户别出货 外贸客户别   --非外贸客户别 出 P 标签（ 调按容器写标签  过程 ）   原装箱产生标签 方式  为 一箱一标签 否则
  *****************************************************************************************/
  procedure P_O_WriteLabelSerial_Cust(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                      strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                      strOwnerNo      in odata_outstock_m.owner_no%type,
                                      strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                      strOperateType  in odata_outstock_m.operate_type%type,
                                      strPickType     in odata_outstock_m.pick_type%type,
                                      strTaskType     in odata_outstock_m.task_type%type,
                                      strOutstockType in odata_outstock_m.outstock_type%type,
                                      strUserID       in stock_label_m.updt_name%type, --员工ID
                                      strOutMsg       out varchar2); --返回值

  /*****************************************************************************************
     功能：删除取号 临时表 数据
  *****************************************************************************************/
  procedure P_O_DeleteContainerNoLoc(strEnterPriseNo  in stock_label_m.enterprise_no%type,
                                     strWareHouseNo   in stock_label_m.warehouse_no%type,
                                     strContainerType in stock_label_m.container_type%type, --标签类型
                                     strContainerNo   in stock_label_m.container_no%type, --容器类型
                                     strSessionId     in number, --会话ＩＤ
                                     strUserID        in stock_label_m.updt_name%type, --员工ID
                                     strOutMsg        out varchar2); --返回值

  -----------------------------------------------------------------------------------------------------------出 货  回 单
  /*****************************************************************************************
     功能：P型 大批量处理 （绑定客户标签【固定板】）
  *****************************************************************************************/
  procedure P_O_UpdateLabelByMass(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                  strwarehouse_no in stock_label_d.warehouse_no%type, --仓别
                                  strOutStockNo   in stock_label_d.source_no%type, --来源单号
                                  strLabelNo      in stock_label_m.label_no%type, --源标签号
                                  strN_LabelNo    in stock_label_m.label_no%type, --目的标签号
                                  strSCellNo      in odata_outstock_d.s_cell_no%type, --来源储位
                                  strDCellNo      in odata_outstock_d.d_cell_no%type, --目的储位
                                  strArticleNo    in stock_label_d.article_no%type, --商品编码
                                  strUserID       in stock_label_d.rgst_name%type, --操作人员
                                  strDivideID     in odata_outstock_d.divide_id%type,
                                  strOutMsg       out varchar2); --返回值

  /*****************************************************************************************
     功能： 更新标签表客户别尾箱标签容器号类型
  *****************************************************************************************/
  procedure P_O_UpdateLabelByCust(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                  strwarehouse_no in stock_label_d.warehouse_no%type, --仓别
                                  strOutStockNo   in stock_label_d.source_no%type, --来源单号
                                  strLabelNo      in stock_label_m.label_no%type, --源标签号
                                  strOutMsg       out varchar2); --返回值
  /*****************************************************************************************
     功能：更新标签明细数量   下架回单更新下架单头时  拣货被销毁的标签处理
  *****************************************************************************************/
  procedure P_O_UpdateLabelDetail(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                  strwarehouse_no in stock_label_d.warehouse_no%type, --标签类型
                                  strOutStockNo   in stock_label_d.source_no%type, --来源单号
                                  strOutStockType in odata_outstock_m.outstock_type%type, --下架类型
                                  strUserId       in stock_label_d.updt_name%type, --操作人员
                                  strStatus       in stock_label_d.status%type, --状态
                                  strOutMsg       out varchar2);

  /*****************************************************************************************
     功能：下架回单更新标签 ( 按单号、按储位、按商品回单 )
  *****************************************************************************************/
  procedure P_O_UpdateLabelByStockArticle(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                          strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                          strOutStockNo   in stock_label_m.source_no%type, --下架单号
                                          strArticleNo    in stock_label_d.article_no%type, --商品编码
                                          strScellNo      in odata_outstock_d.s_cell_no%type, --来源储位编码
                                          strFlagZero     in varchar2, --是否零回标示
                                          strUserID       in stock_label_m.updt_name%type, --操作人员
                                          strOwnerCellNo  in stock_label_m.owner_cell_no%type, --最后并入储位
                                          strOutMsg       out varchar2); --返回值

  /*****************************************************************************************
     功能：下架回单更新标签 ( 按下架单号整单回单 )
  *****************************************************************************************/
  procedure P_O_UpdateLabelByStockNo(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                     strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                     strOutStockNo   in stock_label_m.source_no%type, --下架单号
                                     strFlagZero     in varchar2, --是否零回标示
                                     strUserID       in stock_label_m.updt_name%type, --操作人员
                                     strOwnerCellNo  in stock_label_m.owner_cell_no%type, --最后并入储位
                                     strOutMsg       out varchar2); --返回值

  /*****************************************************************************************
     功能：下架回单更新标签 ( B 品 C 型 拣货回单)
  *****************************************************************************************/
  procedure P_O_UpdateLabelByItemTypeB(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                       strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                       strLabelNo      in stock_label_m.label_no%type, --实体标签号
                                       strUserID       in stock_label_m.updt_name%type, --操作人员
                                       strOutMsg       out varchar2); --返回值

  /*****************************************************************************************
     功能：表单回单写出货标签明细
  *****************************************************************************************/
  procedure P_O_WriteCustContainer(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                   strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                   strOutStockNo   in odata_outstock_m.outstock_no%type, --下架单号
                                   nDivideId       in odata_outstock_d.divide_id%type,
                                   strUserID       in stock_label_m.updt_name%type, --员工ID
                                   strOutMsg       out varchar2);

end pkOBJ_label_odata;


/

