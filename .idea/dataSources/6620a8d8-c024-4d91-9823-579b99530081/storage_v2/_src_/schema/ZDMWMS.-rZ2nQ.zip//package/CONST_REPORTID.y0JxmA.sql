create package        CONST_REPORTID is

  -- Author  : LIZHIPING
  -- Created : 2013-04-05 15:48:00
  -- Purpose :

  --定义报表常量

  ------------------------------------------------------------------------------------出货
  PrintPaper CONSTANT odata_outstock_m.task_type%type :='1';
  PrintTaskLabel CONSTANT odata_outstock_m.task_type%type :='2';
  PrintSerialLabel CONSTANT odata_outstock_m.task_type%type :='0';


  Print_MD CONSTANT odata_outstock_m.task_type%type :='1';        --打印标签头、明细
  Print_M CONSTANT odata_outstock_m.task_type%type :='2';         --打印标签头
  Print_D CONSTANT odata_outstock_m.task_type%type :='3';         --打印标签明细
  Print_Report CONSTANT odata_outstock_m.task_type%type :='4';    --打印报表
  Print_MD_Report CONSTANT odata_outstock_m.task_type%type :='5'; --打印报表,标签头、明细
  Print_M_Report CONSTANT odata_outstock_m.task_type%type :='6';  --打印报表,标签头
  Print_D_Report CONSTANT odata_outstock_m.task_type%type :='7';  --打印报表,标签明细

  /**********************************************************************************************
  进货报表
  ***********************************************************************************************/
  --存储(直通）预计到货单报表
  L_IS_READY_CHECK constant job_printtask_m.report_id%type := 'L_IS_ORDER1';
  --直通预计到货单报表（目前暂未使用)
  L_ID_READY_CHECK constant job_printtask_m.report_id%type := 'L_ID_ORDER1';
  --存储(直通）预计到货单标签（目前暂未使用)
  B_IS_READY_CHECK constant job_printtask_m.report_id%type := 'B_IS_ORDER1';
  --直通预计到货单标签（目前暂未使用)
  B_ID_READY_CHECK constant job_printtask_m.report_id%type := 'B_ID_ORDER1';
  ---门卫登记标签
  B_DOOR_RECODE constant job_printtask_m.report_id%type := 'B_ID_DOOR1';
  --存储箱型验收板标签( 适用于单一商品的整箱和整板）
  B_I_INSTOCKP constant job_printtask_m.report_id%type:='B_I_INSTOCKP1';
    --存储箱型验收散箱标签( 适用于单一商品的整箱和整板）
  B_I_INSTOCKB constant job_printtask_m.report_id%type:='B_I_INSTOCKB1';
    --存储箱型验收板标签( 适用于混载整箱和整板）（目前暂未使用)
  B_I_INSTOCKMIXSUK constant job_printtask_m.report_id%type:='B_I_INSTOCKMIX1';
  --存储上架单
  L_INSTOCK constant job_printtask_m.report_id%type:='L_I_INSTOCK1';
  --进货验收单
  L_I_CHECK constant job_printtask_m.report_id%type:='L_I_CHECK1';
  -----P型直通分播标签
  IM_ID_DIVIDE_P CONSTANT varchar2(20) := 'B_ID_DIVIDEP1';
  -----B型直通分播标签
  IM_ID_DIVIDE_B CONSTANT varchar2(20) := 'B_ID_DIVIDEB1';
  --直通验收客户标签(按客户配送）
  IM_ID_Cust_type_p CONSTANT varchar2(20) := 'IDCustP001';
   -----直通分播单
  L_ID_DIVIDE_P CONSTANT varchar2(20) := 'L_ID_DIVIDE_P1';

  --直通验收客户标签（按单配送）
  IM_ID_Exp_type_p CONSTANT varchar2(20) := 'IDExpP001';
  --封箱箱标签 ( 按客户)
  B_CLOSECustBOX CONSTANT varchar2(20):='B_CloseCustB';
    --封箱箱标签 ( 按单)
  B_CLOSEExpBOX CONSTANT varchar2(20):='B_CloseExpB';
  /***********************************************************************************
  出货报表
  ***********************************************************************************/
  -----出货C型拣货(播种）任务标签
  B_DividePickTaskLabel_C CONSTANT varchar2(20) := 'B_DividePickC1';
  -----出货B型拣货(播种）任务标签
  B_DividePickTaskLabel_B CONSTANT varchar2(20) := 'B_DividePickB1';
  -----出货B型摘果标签任务标签
  B_CustPickTaskLabel_B CONSTANT varchar2(20) := 'B_CustPickB1';
  -----出货B型摘果标签任务标签
  B_ExpPickTaskLabel_B CONSTANT varchar2(20) := 'B_ExpPickB1';
  -----出货B型摘果标签(竖排显示)
  B_CustPickTaskLabel_B2 CONSTANT varchar2(20) := 'B_CustPickB2';
  -----出货C型摘果任务标签（按客户）
  B_CustPickTaskLabel_C CONSTANT varchar2(20) := 'B_CustPickC1';
  -----出货C型摘果任务标签(按单）
  B_ExpPickTaskLabel_C CONSTANT varchar2(20) := 'B_ExpPickC1';
  -----出货C型摘果流水标签(流水标签)按客户
  B_CustPickSerialLabel_C CONSTANT varchar2(20) := 'B_CustPickC2';
    -----出货C型摘果流水标签(流水标签)按单
  B_EXPPickSerialLabel_C CONSTANT varchar2(20) := 'B_ExpPickC2';
  -----出货P型摘果任务标签头（按客户）
  B_CustPickTaskLabel_PM CONSTANT varchar2(20) := 'B_CustPickPM1';
    -----出货P型摘果任务标签头（按单）
  B_ExpPickTaskLabel_PM CONSTANT varchar2(20) := 'B_ExpPickPM1';
  --出货下架单(拣货单/摘果)
  L_CustPick CONSTANT job_printtask_m.report_id%type:='L_CustPick';
  -----出货C型摘果标签头
  B_CustPickTaskLabel_CM CONSTANT varchar2(20) := 'B_CustPickCM';
  -----出货C型摘果标签明细
  B_CustPickTaskLabel_CD CONSTANT varchar2(20) := 'B_CustPickCD';
  -----出货B型摘果标签头
  B_CustPickTaskLabel_BM CONSTANT varchar2(20) := 'B_CustPickBM';
  -----出货B型摘果标签明细
  B_CustPickTaskLabel_BD CONSTANT varchar2(20) := 'B_CustPickBD';
  /***************************************************************************************
  暂未使用
  ****************************************************************************************/
  -----出货P型摘果任务标签头(竖排显示)
  B_CustPickLabel_PM1 CONSTANT varchar2(20) := 'B_CustPickPM2';
  -----出货P型摘果标签明细  (竖排显示)
  B_CustPickLabel_PD1 CONSTANT varchar2(20) := 'B_CustPickPD1';
  -----出货P型摘果标签明细
  B_CustPickLabel_PD2 CONSTANT varchar2(20) := 'B_CustPickPD2';
 -----出货B型分播拣货标签头
  B_DividePickTaskLabel_BM CONSTANT varchar2(20) := 'B_DividePickBM1';
  -----出货D型标签头
  B_DividePickTaskLabel_DM CONSTANT varchar2(20) := 'B_DividePickDM';
  -----出货D型标签头
  B_DividePickTaskLabel_D CONSTANT varchar2(20) := 'B_DividePickDM';
  -----出货板型分播拣货标签头
  B_DividePickTaskLabel_MM CONSTANT varchar2(20) := 'B_DividePickMM';
  -----出货板型分播拣货标签头明细
  B_DividePickTaskLabel_MD CONSTANT varchar2(20) := 'B_DividePickMD';--'C2700PD';


  -----客户取号物流箱标签ID
/*  OmNewCustLabel_B CONSTANT varchar2(20) := 'E9700H'; */
  -----客户取号板标签ID
  OmNewCustLabel_P CONSTANT varchar2(20) := 'E9800H';
  -----出货配送总单
  OmAllDeliver_P CONSTANT varchar2(20) := 'FC000';
------------------------------------------------------------------------------------补货
  -----补货C型标签头
  B_HMTask_C CONSTANT varchar2(20) := 'B_HMTask_C';
  --补货下架单
  L_HMTask_C CONSTANT job_printtask_m.report_id%type :='L_HMTask_C';
  -----补货C型标签明细
  B_HMTask_CD CONSTANT varchar2(20) := 'B_HMTask_CD';
    -----补货B型标签明细
  B_HMTask_BD CONSTANT varchar2(20) := 'B_HMTask_BD';



  -----补货B型标签头
  HmPickLabel_B_Head CONSTANT varchar2(20) := 'HM8100BM';--' C2800M'


  --库存录标签
  HmStockSetLabel CONSTANT varchar2(20) := 'HM8200BD';

  --标签--空储位标签
  LBL_WM_D CONSTANT varchar2(20):= 'VM2100D';

------------------------------------------------------------------------------------进货
  ------------------------------------------------------------------------------------报表

  RPT_UM_READY_CHECK  constant job_printtask_m.report_id%type:='UM8500R';--返配预验收单
  RPT_UM_CHECK   constant job_printtask_m.report_id%type:='UM8600R';--返配验收单
  RPT_UM_INSTOCK constant job_printtask_m.report_id%type:='UM8700R';--返配上架单
  RPT_UM_INSTOCKB constant job_printtask_m.report_id%type:='UM8700B';--返配上架标签


  --直通分播单
  OmDivideReport CONSTANT job_printtask_m.report_id%type:='OM7700R';

  -----出货配送总单
  RPT_OM_Deliver CONSTANT varchar2(20) := 'FC000';

  --出货容器明细（配送箱明细）
  RPT_OM_Container_List CONSTANT varchar2(20) := 'FD000';
  ------出货装车汇总单
  RPT_OM_LoadTotalReport CONSTANT varchar2(20) := 'FA000';

  ------------------------------------------------------------------------------------补货


   --退货下架单
  RPT_WM_PICK CONSTANT varchar2(20):= 'VM2100R'; --退货下架单


   --退货下架单
  RPT_WM_PICKLabel CONSTANT varchar2(20):= 'VM2200R'; --退货下架单(标签拣货单）

  --退厂发单--报表--拣货单明细跟踪表
  RPT_WM_LIST CONSTANT varchar2(20):= 'VM2300R';

  RPT_WM_BOXNO  CONSTANT varchar2(20):= 'VM2700R';

  RPT_WM_BOXITEM  CONSTANT varchar2(20):= 'VM2800R';




  --退厂确认--报表--预制提货单
  RPT_WM_BILL CONSTANT varchar2(20):= 'VM2500R';

  --退厂确认--报表--退货清单
  RPT_WM_DELIVER CONSTANT varchar2(20):= 'VM2600R';

  --退厂确认--报表--退厂交运总单
  RPT_WM_DELIVERTotalReport CONSTANT varchar2(20):= 'L_RODELIVER01';

  RPT_CH_CHECK1 CONSTANT job_printtask_m.Report_Id%TYPE:='CH2100R'; --初盘单报表
  RPT_CH_CHECK1_B CONSTANT job_printtask_m.Report_Id%TYPE:='CH2100B'; --初盘标签
  RPT_CH_CHECKLabel1 CONSTANT job_printtask_m.Report_Id%TYPE:='CH2101R'; --初盘单标签
  RPT_CH_CHECK2 CONSTANT job_printtask_m.Report_Id%TYPE:='CH2200R'; --复盘单
  RPT_CH_CHECK3 CONSTANT job_printtask_m.Report_Id%TYPE:='CH2300R'; --三盘单

  L_FC_DIFF1 CONSTANT job_printtask_m.Report_Id%TYPE:='L_FC_DIFF1';--初盘差异单
  L_FC_DIFF2 CONSTANT job_printtask_m.Report_Id%TYPE:='L_FC_DIFF2';--复盘差异单
  L_FC_DIFF3 CONSTANT job_printtask_m.Report_Id%TYPE:='L_FC_DIFF3';--三盘差异单


  RPT_UM_CHECKBOX CONSTANT varchar2(20):='UM10001';--返配验收箱标签
  RPT_UM_CHECKCLOSEBOX CONSTANT varchar2(20):='UM10002';--返配上架箱标签
  RPT_UM_IntstockBoxItem CONSTANT varchar2(20):='UM10003';--返配上架箱明细
  RPT_BD_HAGTAG CONSTANT varchar2(20):='BD10003'; --吊牌打印
  RPT_BD_S_HAGTAG CONSTANT varchar2(20):='BD10004'; --小吊牌打印
  RPT_BD_BARCODE CONSTANT varchar2(20):='BD10005'; --条码打印

  RPT_OM_PICKGOODSFENBO CONSTANT varchar2(20):='OM7101R';--拣货单(分播)
  RPT_OM_PICKGOODSZHAIGUO CONSTANT varchar2(20):='OM7500CM';--拣货单(摘果)
  RPT_OM_FENBOORDER CONSTANT varchar2(20):='OM7700R';--分播单
  RPT_OL_ZHUANGCHEJIANYIDAN CONSTANT varchar2(20):='OL0001';--装车建议单

  RPT_BOXITEM CONSTANT VARCHAR2(20):='OM8000CM';--装箱单

  RPT_WasteOutstock constant varchar2(20):='L_WasteOut01';--报损下架单
  rpt_wasteDelive   constant varchar2(20):='L_WasteDelive01';--报损清单
  rpt_stockConfirm  CONSTANT VARCHAR2(20):='L_STOCKCONFIRM1';--调整确认单
end CONST_REPORTID;


/

