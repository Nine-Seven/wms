create package PKLG_ODATA_MOVE_JUN is

  /*****************************************************************************************
   功能：容器整理
  Modify By JUN AT 2014-06-03
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure p_container_arrange(strEnterpriseNo in stock_label_m.enterprise_no%type, --仓别
                                strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                                strSLabelNo     in stock_label_m.label_no%type, --来源标签
                                strDLabelNo     in stock_label_m.label_no%type, --目的标签
                                strDeliverOBJ   in stock_label_d.deliver_obj%type, --配送对象
                                strArticleNo    in stock_label_d.article_no%type, --商品编码
                                nPackingQty     in stock_label_d.packing_qty%type, --商品包装
                                nMoveQty        in stock_label_d.qty%type, --移动数量
                                strQuality      in stock_article_info.quality%type, --品质
                                dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                                dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                                strLotNo        in stock_article_info.lot_no%type, --批号
                                strRsvBatch1    in stock_article_info.rsv_batch1%type, --预留批属性1
                                strRsvBatch2    in stock_article_info.rsv_batch2%type, --预留批属性2
                                strRsvBatch3    in stock_article_info.rsv_batch3%type, --预留批属性3
                                strRsvBatch4    in stock_article_info.rsv_batch4%type, --预留批属性4
                                strRsvBatch5    in stock_article_info.rsv_batch5%type, --预留批属性5
                                strRsvBatch6    in stock_article_info.rsv_batch6%type, --预留批属性6
                                strRsvBatch7    in stock_article_info.rsv_batch7%type, --预留批属性7
                                strRsvBatch8    in stock_article_info.rsv_batch8%type, --预留批属性8
                                strUserId       in stock_label_m.rgst_name%type, --操作人员
                                strTerminalFlag in varchar2, --操作设备
                                strResult       out varchar2); --返回 执行结果

  /*****************************************************************************************
   功能：校验源容器号是否合法
  Modify By JUN AT 2014-06-03
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure p_check_strScontainerNo(strEnterpriseNo in stock_label_m.enterprise_no%type,
                                    strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                                    strLabelNO      in stock_label_m.label_no%type, --源容器号
                                    strResult       out varchar2);

  /*****************************************************************************************
   功能：校验源容器号是否可移目的容器号
  Modify By JUN AT 2014-06-03
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure p_contrast_containerNo(strEnterpriseNo in stock_label_m.enterprise_no%type,
                                   strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                                   strSLabelNo     in stock_label_m.label_no%type, --源容器号
                                   strDLabelNo     in stock_label_m.label_no%type, --目的容器号
                                   strResult       out varchar2);

  /*****************************************************************************************
   功能：容器并板前校验
  Modify By JUN AT 2014-06-03
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure p_check_merge(strEnterpriseNo in stock_label_m.enterprise_no%type,
                          strWarehouseNo  in stock_label_m.warehouse_no%type,
                          strSLabelNo     in stock_label_m.label_no%type,
                          strDLabelNo     in stock_label_m.label_no%type,
                          strResult       out varchar2);

  /*****************************************************************************************
   功能：容器并板
  Modify By JUN AT 2014-06-03
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure p_merge_container(strEnterpriseNo in stock_label_m.enterprise_no%type,
                              strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                              strScontainerNo in stock_label_m.container_no%type, --源容器号
                              strDcontainerNo in stock_label_m.container_no%type, --目的容器号
                              strArticleNo    in stock_label_d.article_no%type, --商品编码
                              nPackingQty     in stock_label_d.packing_qty%type, --商品包装
                              nMoveQty        in stock_label_d.qty%type, --移动数量
                              strQuality      in stock_article_info.quality%type, --品质
                              dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                              dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                              strLotNo        in stock_article_info.lot_no%type, --批号
                              strRsvBatch1    in stock_article_info.rsv_batch1%type, --预留批属性1
                              strRsvBatch2    in stock_article_info.rsv_batch2%type, --预留批属性2
                              strRsvBatch3    in stock_article_info.rsv_batch3%type, --预留批属性3
                              strRsvBatch4    in stock_article_info.rsv_batch4%type, --预留批属性4
                              strRsvBatch5    in stock_article_info.rsv_batch5%type, --预留批属性5
                              strRsvBatch6    in stock_article_info.rsv_batch6%type, --预留批属性6
                              strRsvBatch7    in stock_article_info.rsv_batch7%type, --预留批属性7
                              strRsvBatch8    in stock_article_info.rsv_batch8%type, --预留批属性8
                              strUserId       in stock_label_m.rgst_name%type, --操作人员
                              strTerminalFlag in varchar2, --操作设备
                              strResult       out varchar2);

  /*****************************************************************************************
   功能：出货整理新取标签号码
  Modify By lich AT 2014-11-07
  *****************************************************************************************/
  procedure p_getnew_containerNo(strEnterpriseNo  in stock_label_m.enterprise_no%type,
                                 strWarehouseNo   in stock_label_m.warehouse_no%type, --仓别
                                 strSLabelNo      in stock_label_m.label_no%type, --源容器号
                                 strContainerType in stock_label_m.container_type%type, ----P：栈板；B物流箱
                                 strUserId        in bdef_defworker.worker_no%type,
                                 strDLabelNo      out stock_label_m.label_no%type, --目的容器号
                                 strResult        out varchar2);

  /*****************************************************************************************
   功能：装并板新取号，用固定板号或者流水板号
  *****************************************************************************************/
  procedure p_getNewMergeLabel(strEnterpriseNo  in stock_label_m.enterprise_no%type,
                               strWarehouseNo   in stock_label_m.warehouse_no%type, --仓别
                               strSLabelNo      in stock_label_m.label_no%type, --源容器号
                               strdLableNo      in stock_label_m.label_no%type, --目的标签号，传N流水板号，否则固定板号
                               strContainerType in stock_label_m.container_type%type, ----P：栈板；B物流箱
                               strUserId        in bdef_defworker.worker_no%type,
                               strDLabelNo      out stock_label_m.label_no%type, --目的容器号
                               strResult        out varchar2);
  /*****************************************************************************************
   功能：用于电商复核打包的取标签号（电商特殊功能，一复核单对应多个配送对象，按复核标签明细的信息产生标签号

  20160605
  *****************************************************************************************/

  procedure P_DeliverObjLableNo(strEnterpriseNo  in stock_label_m.enterprise_no%type,
                                strWarehouseNo   in stock_label_m.warehouse_no%type, --仓别
                                strCheckNo       in stock_label_m.label_no%type, --源容器号
                                strDeliverObj    in stock_label_m.deliver_obj%type,
                                strContainerType in stock_label_m.container_type%type, ----P：栈板；B物流箱
                                strUserId        in bdef_defworker.worker_no%type,
                                strResult        out varchar2);
  /*****************************************************************************************
  2015.12.4
  功能说明：1、根据l来源标签的信息进行取号
            2、打印
  ******************************************************************************************/
  procedure GetDeliverObjLabelAndPrint(strEnterPriseNo  in stock_label_m.Enterprise_No%type, --企业号
                                       strWareHouseNo   in stock_label_m.warehouse_no%type, --仓别
                                       strsLabelNo      in stock_label_m.label_no%type, --来源标签号
                                       strDockNo        in bdef_defdock.dock_no%type, --工作站
                                       strContainerType in stock_label_m.container_type%type, --P：栈板；
                                       strUserId        in stock_label_m.rgst_name%type,
                                       strDLabelNo      out stock_label_m.label_no%type, --目的标签号
                                       strOutMsg        out varchar2);
  /*****************************************************************************************
   功能：出货整理扫描条码保存商品
  Modify By lich AT 2014-11-07
  *****************************************************************************************/
  procedure p_Arrange_Save_Article(strEnterpriseNo in stock_label_m.enterprise_no%type,
                                   strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                                   strSLabelNo     in stock_label_m.label_no%type, --源容器号
                                   strDLabelNo     in stock_label_m.label_no%type, --目的容器号
                                   strDeliverOBJ   in stock_label_m.deliver_obj%type, --配送对象
                                   strArticleNo    in stock_label_d.article_no%type, --商品编码
                                   nPacking_QTY    in odata_check_d.packing_qty%type, --包装数量
                                   strQuality      in stock_article_info.quality%type, --品质
                                   dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                                   dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                                   strLotNo        in stock_article_info.lot_no%type, --批次号
                                   strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                                   strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                                   strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                                   strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                                   strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                                   strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                                   strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                                   strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                                   strBarcode      in stock_article_info.barcode%type,
                                   iQty            in stock_label_d.qty%type, --数量
                                   strUserId       in stock_label_m.rgst_name%type, --操作人
                                   strResult       out varchar2);
  /*****************************************************************************************
  出货整理打包》源标签号检验
  Modify By lich AT 2014-11-10
  *****************************************************************************************/
  procedure p_check_SLabelNo(strEnterpriseNo in stock_label_m.enterprise_no%type,
                             strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                             strLabelNo      in stock_label_m.label_no%type, --源容器号
                             strResult       out varchar2);
  /***********************************************************************************************
   功能说明 ：
            根据任务号或者箱号写复核单，目前用于电商的复核

  ***********************************************************************************************/

  procedure p_creat_odata_check(strEnterpriseNo in odata_check_m.enterprise_no%type,
                                strWareHouseNo  in odata_check_m.warehouse_no%type,
                                strCheckChuteNo in odata_check_m.check_chute_no%type, --复核台滑道号
                                strTaksNo       in stock_label_m.source_no%type, --任务号，没有则传N
                                strBoxNo        in stock_label_m.label_no%type, --箱号/ 快递单号
                                strCheckType    in varchar2, --复核类型：1:按任务复核或按箱号,2:快递单号复核
                                strUserId       in odata_check_m.rgst_name%type,
                                strCheckNo      out odata_check_m.check_no%type,
                                strResult       out varchar2);

  /***********************************************************************************************
   功能说明 ：
            根据任务号或者箱号写复核单，目前用于电商的复核

  ***********************************************************************************************/
  procedure P_CheckAndCreate(strEnterpriseNo in odata_check_m.enterprise_no%type,
                             strWareHouseNo  in odata_check_m.warehouse_no%type,
                             strCheckChuteNo in odata_check_m.check_chute_no%type, --复核台滑道号
                             strTaksNo       in stock_label_m.source_no%type, --任务号，没有则传N
                             strBoxNo        in stock_label_m.label_no%type, --箱号/ 快递单号
                             strCheckType    in varchar2, --复核类型：1:按任务复核\按箱号；2：快递单号复核
                             strUserId       in odata_check_m.rgst_name%type,
                             strAutoOutstock in varchar2, --是否可自动下架回单:Y-可以,N-不可以
                             strCheckNo      out odata_check_m.check_no%type,
                             strResult       out varchar2);

  /*****************************************************************************************
  根据箱号号写复核单数据
  chensr  2015.4.27
  *****************************************************************************************/
  procedure p_creat_odata_check_by_label(strEnterpriseNo in odata_check_m.enterprise_no%type,
                                         strWareHouseNo  in odata_check_m.warehouse_no%type,
                                         strLabelNo      in stock_label_m.label_no%type, --箱号号
                                         strCheckChuteNo in odata_check_m.check_chute_no%type, --复核台滑道号
                                         strUserId       in odata_check_m.rgst_name%type,
                                         strResult       out varchar2);

  /************************************************************************************************
  功能说明：复核单校验：
           1、支持按任务号校验；
           2、支持按箱号校验
  ************************************************************************************************/
  procedure P_TaskAndBoxCheck(strEnterpriseNo in odata_check_m.enterprise_no%type,
                              strWareHouseNo  in odata_check_m.warehouse_no%type,
                              strCheckChuteNo in odata_check_m.check_chute_no%type, --复核台滑道号
                              strTaksNo       in stock_label_m.source_no%type, --任务号，没有则传N
                              strBoxNo        in stock_label_m.label_no%type, --箱号/ 快递单号
                              strCheckType    in varchar2, --复核类型：1:按任务复核；2：按箱号或快递单号复核
                              strCheckNo      out odata_check_m.check_no%type,
                              strResult       out varchar2);
  /***********************************************************************************************
   --扫描商品条码-整理容器（电商）
     chensr  2015.4.30
  ***********************************************************************************************/
  procedure P_CheckLabelArticle(strEnterpriseNo in odata_check_m.enterprise_no%type,
                                strWareHouseNo  in odata_check_m.warehouse_no%type,
                                strCheckNo      in odata_check_m.check_no%type,
                                strArticle_No   in odata_check_d.article_no%type, --商品编码
                                nPacking_QTY    in odata_check_d.packing_qty%type, --包装数量
                                strQuality      in stock_article_info.quality%type, --品质
                                dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                                dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                                strLotNo        in stock_article_info.lot_no%type, --批次号
                                strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                                strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                                strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                                strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                                strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                                strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                                strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                                strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                                strBarcode      in stock_article_info.barcode%type,
                                strSLabelNo     in odata_check_label_d.lable_no%type, --来源标签
                                strDLabelNo     in stock_label_m.label_no%type, --目的标签
                                nRealQty        in odata_check_d.real_qty%type, --回单数量
                                strUserId       in odata_check_m.rgst_name%type,
                                strResult       out varchar2);

  /***********************************************************************************************
   --扫描商品条码-整理容器（电商）
   功能说明：根据复核单里的商品进行复核，需循环按商品抓取标签号再进行处理
   chensr
   2015.5.5
  ***********************************************************************************************/
  procedure P_CheckArticle(strEnterpriseNo in odata_check_m.enterprise_no%type,
                           strWareHouseNo  in odata_check_m.warehouse_no%type,
                           strCheckNo      in odata_check_m.check_no%type,
                           strDeliverObj   in odata_check_m.deliver_obj%type,
                           strArticle_No   in odata_check_d.article_no%type, --商品编码
                           nPacking_QTY    in odata_check_d.packing_qty%type, --包装数量
                           strQuality      in stock_article_info.quality%type, --品质
                           dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                           dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                           strLotNo        in stock_article_info.lot_no%type, --批次号
                           strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                           strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                           strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                           strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                           strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                           strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                           strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                           strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                           strBarcode      in stock_article_info.barcode%type,
                           strsLabelNo     in stock_label_m.label_no%type,
                           strDLabelNo     in stock_label_m.label_no%type, --目的标签
                           nRealQty        in odata_check_d.real_qty%type, --回单数量
                           strUserId       in odata_check_m.rgst_name%type,
                           strResult       out varchar2);

  /**************************************************************************************************
  功能说明：复核差异回单
  luozhiling
  2015.5.5
  **************************************************************************************************/
  procedure P_DiffCheckSave(strEnterpriseNo in odata_check_m.enterprise_no%type,
                            strWareHouseNo  in odata_check_m.warehouse_no%type,
                            strCheckNo      in odata_check_m.check_no%type,
                            strDeliverObj   in odata_check_m.deliver_obj%type,
                            strUserId       in odata_check_m.updt_name%type,
                            strResult       out varchar2);

  /***********************************************************************************************
   --扫描商品条码-整理容器（电商）--自动封箱，转病单
   功能说明：按复核单上的商品进行复核
   chensr
   2015.5.5
   功能描述：1、根据条码取订单；
             2、若此订单未产生复核标签，新取号
             3、若此订单已有复核标签，复核保存
             4、若整订单扫描完成，自动封箱

  ***********************************************************************************************/
  procedure p_scanArticle_cutBox_sickOrder(strEnterpriseNo  in odata_check_m.enterprise_no%type,
                                           strWareHouseNo   in odata_check_m.warehouse_no%type,
                                           strCheckNo       in odata_check_m.check_no%type,
                                           strTaksNo        in stock_label_m.source_no%type, --任务号或快递单号
                                           strDeliverObj    in odata_check_m.deliver_obj%type, --第一次传N，后面用返回的值
                                           strArticle_No    in odata_check_d.article_no%type, --商品编码
                                           nRealQty         in odata_check_d.real_qty%type, --回单数量
                                           strUserId        in odata_check_m.rgst_name%type,
                                           strDockNo        in ridata_check_m.dock_no%type,
                                           strPrintWayBill  in odata_outstock_m.task_type%type, --是否打印快递面单，0：不打印，1：打印
                                           strPrintPackList in odata_outstock_m.task_type%type, --是否打印装箱清单，0：不打印，1：打印
                                           strPrintInVoice  in odata_outstock_m.task_type%type, --是否打印发票，0：不打印，1：打印
                                           strCheckType     in varchar2, --复核类型：1:按任务复核或箱号；2：快递单号复核
                                           strCloseFlag     out varchar2, --复核完成标识，'Y' 完成；‘N'未完成
                                           strOutDeliverObj out stock_label_m.deliver_obj%type,
                                           strOutLabelNo    out stock_label_m.label_no%type,
                                           strPackMateMsg   out bdef_defarticle.article_name%type, --提示的包材名称
                                           strOutFinishFlag out varchar2, --复核完成标识，'Y' 完成；‘N'未完成
                                           strResult        out varchar2);

  /*订单取消*/
  procedure p_OrderCancel(strEnterpriseNo in odata_check_m.enterprise_no%type,
                          strWareHouseNo  in odata_check_m.warehouse_no%type,
                          strCheckNo      in odata_check_m.check_no%type, --复核单号
                          strSource_No    in odata_exp_m.shipper_deliver_no%type, --面单号或原订单号
                          strCheckType    in varchar2, --复核类型：1:按原订单号；2：快递单号复核
                          strUserID       in odata_check_m.rgst_name%type,
                          strResult       out varchar2);
  /***********************************************************************************************
   对转病单的标签进行解锁
   chensr
   2015.5.5
  ***********************************************************************************************/
  procedure P_UnlockLabel(strEnterpriseNo in stock_label_m.Enterprise_No%type,
                          strWarehouseNo  in stock_label_m.Warehouse_No%type,
                          strDeliverObj   in stock_label_m.source_no%type,
                          strWorkerNo     in stock_label_m.rgst_name%type,
                          strResult       out varchar2);

  /*****************************************************************************************
   功能：出货整理扫描条码保存商品(根据箱号)
  chensr 2015-06-26
  *****************************************************************************************/
  procedure P_scanArticle_by_labelNo(strEnterpriseNo in odata_check_m.enterprise_no%type,
                                     strWareHouseNo  in odata_check_m.warehouse_no%type,
                                     strCheckNo      in odata_check_m.check_no%type,
                                     strArticle_No   in odata_check_d.article_no%type, --商品编码
                                     nPacking_QTY    in odata_check_d.packing_qty%type, --包装数量
                                     strQuality      in stock_article_info.quality%type, --品质
                                     dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                                     dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                                     strLotNo        in stock_article_info.lot_no%type, --批次号
                                     strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                                     strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                                     strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                                     strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                                     strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                                     strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                                     strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                                     strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                                     strBarcode      in stock_article_info.barcode%type,
                                     strsLabelNo     in stock_label_m.label_no%type, --来源标签
                                     strDLabelNo     in stock_label_m.label_no%type, --目的标签
                                     nRealQty        in odata_check_d.real_qty%type, --回单数量
                                     strUserId       in odata_check_m.rgst_name%type,
                                     strDockNo       in bdef_defdock.dock_no%type,
                                     strResult       out varchar2);
  /*****************************************************************************************
    功能：取消扫描、
    201511.05
  *****************************************************************************************/
  procedure p_CancelScanLabel(strEnterPriseNo in stock_label_m.enterprise_no%type,
                              strWareHouseNo  in stock_label_m.warehouse_no%type, --仓别
                              strUserId       in stock_label_m.rgst_name%type, --封箱人
                              strCheckNo      in odata_check_m.check_no%type,
                              strLabelNo      in stock_label_m.label_no%type, --标签号
                              strResult       out varchar2);
  /*****************************************************************************************
    功能：复核封箱打标签（天天惠）
    20150703
    chensr
  *****************************************************************************************/
  procedure P_ODATA_CHECK_CUTBOX(strEnterPriseNo   in stock_label_m.enterprise_no%type,
                                 strWareHouseNo    in stock_label_m.warehouse_no%type, --仓别
                                 strUserId         in stock_label_m.rgst_name%type, --封箱人
                                 strLabelNo        in stock_label_m.label_no%type, --标签号
                                 strPrinterGroupNo in ridata_check_m.printer_group_no%type,
                                 strResult         out varchar2);

  /*****************************************************************************************
    功能：复核封箱
  *****************************************************************************************/
  procedure P_ODATA_CHECK_CLOSEBOX(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                   strWareHouseNo  in stock_label_m.warehouse_no%type, --仓别
                                   strUserId       in stock_label_m.rgst_name%type, --封箱人
                                   strLabelNo      in stock_label_m.label_no%type, --标签号
                                   --strPrinterGroupNo in ridata_check_m.printer_group_no%type,
                                   strResult out varchar2);

  /*****************************************************************************************
    功能：复核封箱
  *****************************************************************************************/
  procedure P_CLOSEBOX(strEnterPriseNo in stock_label_m.enterprise_no%type,
                       strWareHouseNo  in stock_label_m.warehouse_no%type, --仓别
                       strUserId       in stock_label_m.rgst_name%type, --封箱人
                       strLabelNo      in stock_label_m.label_no%type, --标签号
                       strResult       out varchar2);

  /*****************************************************************************************
    功能：复核封箱回单（天天惠）
    20151010
    chensr
  *****************************************************************************************/
  procedure P_PROC_Receipt(strEnterPriseNo in stock_label_m.enterprise_no%type,
                           strWareHouseNo  in stock_label_m.warehouse_no%type, --仓别
                           strCheckNo      in odata_check_m.check_no%type,
                           strResult       out varchar2);
  /*************************************************************************************************************
  功能说明：
          1、装并板
          支持板、物流箱和原装箱往板标签上并

  *************************************************************************************************************/
  procedure p_merge_Pal(strEnterpriseNo in stock_label_m.enterprise_no%type, --仓别
                        strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                        strSLabelNo     in stock_label_m.label_no%type, --原标签(被并板标签）
                        strDLabelNo     in stock_label_m.label_no%type, --目的标签
                        strUserId       in stock_label_m.updt_name%type,
                        strResult       out varchar2);

  /* 装并板 标签检查 （此方法为小嘴所用） Add by sunl
  * 用于校验当前预装板的标签（来源标签）是否属于当前被装的板（目的标签）
  * 此方法内部会调用 P_MergePal_Slabel_Check 过程，用于校验当前的标签是否有效
  * 此方法内部会调用 P_Check_Mergelabel 过程，用于校验当前源标签是否可以并到目的标签
  * 此方法内部会调用 PKLG_ODATA_MOVE_JUN.p_merge_Pal 过程，用于执行装并板操作
  */
  procedure P_MergePal_Label_CheckAndSave(strEnterpriseNo in stock_label_m.enterprise_no%type,
                                          strWarehouseNo  in stock_label_m.warehouse_no%type,
                                          strSLabelNo     in stock_label_m.label_no%type, --来源标签
                                          strDLabelNo     in stock_label_m.label_no%type, --目的标签（往上放货的容器）
                                          strUserID       IN stock_label_m.rgst_name%TYPE, --操作用户
                                          strUseType      in stock_label_m.use_type%type, --1：仅检查标签是否可用 2：检查标签是否可用，且进行装板操作
                                          strStatusText   out wms_deffieldval.text%type, --标签状态描述
                                          strCustName     out bdef_defcust.cust_name%type, --客户名称
                                          strOutMsg       out varchar2);

  /*******************************************************************************************************
    整理确认校验
    功能说明：1、校验是否能做整理确认
              若拣货未完成，不能整理确认，若拣货完成，返回波次号、客户名称、月台货位、总箱数
              目前用于小嘴的装车
  ********************************************************************************************************/
  procedure P_ArrangeCheck(strEnterpriseNo in stock_label_m.enterprise_no%type,
                           strWarehouseNo  in stock_label_m.warehouse_no%type,
                           strsLabelNo     in stock_label_m.label_no%type, --来源标签
                           strUserID       IN stock_label_m.rgst_name%TYPE, --操作用户
                           strDeliverObj   out stock_label_m.deliver_obj%type,
                           strDeliverArea  out stock_label_m.deliver_area%type,
                           strWaveNo       out stock_label_m.wave_no%type,
                           strCustName     out bdef_defcust.cust_name%type, --客户名称
                           nLabelNum       out integer,
                           strOutMsg       out varchar2);

  /*=====================================================================================
  huangb insert to 20160720
  标签称重
  ======================================================================================*/
  PROCEDURE p_Save_LabelWeigh(strEnterpriseNo in STOCK_LABEL_M.enterprise_no%type, --企业号
                              strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                              strDockNo       in bdef_defdock.dock_no%type, --码头
                              strLabelNo      in stock_label_m.label_No%type, --标签号
                              nWeigh          in stock_label_m.weight%type, --重量
                              strUserId       in stock_label_m.rgst_name%type, --操作人员
                              strOutMsg       out varchar2);

  /*=====================================================================================
  功能说明：包材处理
           1、根据快递面单写库存调帐单；
           2、根据库存调帐单定位并回单；

  ======================================================================================*/
  PROCEDURE P_strPackMateDeal(strEnterpriseNo in STOCK_LABEL_M.enterprise_no%type, --企业号
                              strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                              strLabelNo      in stock_label_m.label_no%type,--快递面单，电商的快递面单等于标签
                              strArticlNo     in stock_label_d.article_no%type,--包材编码=商品编码
                              nRealQty        in stock_content.qty%type,--包材出货数量
                              strUserId       in stock_label_m.rgst_name%type, --操作人员
                              strOutMsg       out varchar2);

end PKLG_ODATA_MOVE_JUN;


/

