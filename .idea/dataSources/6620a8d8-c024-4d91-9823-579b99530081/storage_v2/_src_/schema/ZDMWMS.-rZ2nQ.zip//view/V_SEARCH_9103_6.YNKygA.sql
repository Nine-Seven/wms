create view V_SEARCH_9103_6 as
select a.enterprise_no,
       a.WAREHOUSE_NO,
       a.OWNER_NO,
       a.OPERATE_DATE,
       a.OPERATE_TYPE,
       a.PLANARTICLECOUNT,
       a.ARTICLE_QTY,
       nvl(b.realArticleCount, 0) realArticleCount,
       a.REAL_QTY
  from (select b.enterprise_no,
               b.warehouse_no,
               b.owner_no,
               a.operate_date,
               a.operate_type,
               count(distinct b.article_no) planArticleCount,
               sum(b.article_qty) article_qty,
               sum(b.real_qty) real_qty
          from odata_outstock_mhty a, odata_outstock_dhty b
         where a.outstock_no = b.outstock_no
           and a.enterprise_no =b.enterprise_no
           and a.outstock_type = 0
         group by b.enterprise_no, b.warehouse_no, b.owner_no, a.operate_date, a.operate_type) a
  left join (select b.enterprise_no,
                    b.warehouse_no,
                    b.owner_no,
                    a.operate_date,
                    a.operate_type,
                    count(distinct b.article_no) realArticleCount
               from odata_outstock_mhty a, odata_outstock_dhty b
              where a.outstock_no = b.outstock_no
                and a.enterprise_no =b.enterprise_no
                and a.outstock_type = 0
                and b.real_qty > 0
              group by b.enterprise_no,
                       b.warehouse_no,
                       b.owner_no,
                       a.operate_date,
                       a.operate_type) b
    on a.WAREHOUSE_NO = b.warehouse_no
   and a.enterprise_no =b.enterprise_no
   and a.OWNER_NO = b.owner_no
   and a.operate_date = b.operate_date
   and a.operate_type = b.operate_type
 where 1 = 1
 order by a.operate_date

/

