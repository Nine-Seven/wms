create package        PKOBJ_FCDATA_CHECK is


/**********************************************************************************************************
   zhouhuan
   2014.04.21
   功能：盘点发单--》切单-->写盘点单头档
***********************************************************************************************************/
    procedure P_Fcdata_InsertCheckM(strWareHouseNo            in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_plan_m.owner_no%type,
                                  strUserId               in    fcdata_plan_m.rgst_name%type,--作业人
                                  strPaperUserId          in    fcdata_plan_m.rgst_name%type,--单据人
                                  strDirectSerial         in   fcdata_check_direct.Direct_Serial%type,--指示序号
                                  strCheckNo             OUT   fcdata_check_m.check_no%type,--盘点单号
                                  strResult               OUT    varchar2);

 /**********************************************************************************************************
   zhouhuan
   2014.04.21
   功能：盘点发单--》切单
***********************************************************************************************************/
  procedure P_Fcdata_InsertCheckD(strWareHouseNo            in    fcdata_plan_m.warehouse_no%type,--仓库编码
                            strOwnerNo              in    fcdata_plan_m.owner_no%type,--货主编号
                            strPaperUserid               in    fcdata_plan_m.rgst_name%type,--单据人
                            strCheckNo              in   fcdata_check_m.check_no%type,--盘点单号
                            strRowId                in   fcdata_check_m.check_no%type,--行号
                            strOrderId              in   fcdata_check_m.check_no%type,--储位顺序
                            strSubOrderId           in   fcdata_check_m.check_no%type,--储位上商品顺序
                            strDirectSerial         in   fcdata_check_direct.Direct_Serial%type,--指示序号
                            strResult               OUT    varchar2);

 /**********************************************************************************************************
   zhouhuan
   2014.04.21
   功能：定位指示转历史
***********************************************************************************************************/
   procedure P_FcdataCheck_CheckDirectHty( strWareHouseNo            in    fcdata_check_direct.warehouse_no%type,--仓库编码
                            strOwnerNo                               in    fcdata_check_direct.owner_no%type,--货主编号
                            strRequestNo                             in    fcdata_check_direct.request_no%type,--需求单号
                            strResult                                out   varchar2);

end PKOBJ_FCDATA_CHECK;


/

