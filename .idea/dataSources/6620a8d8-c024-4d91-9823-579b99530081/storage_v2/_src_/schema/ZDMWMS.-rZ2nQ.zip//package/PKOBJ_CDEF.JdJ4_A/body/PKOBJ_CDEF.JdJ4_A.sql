create package body PKOBJ_CDEF is

 /**********************************************************************************************************
   功能：添加储位
***********************************************************************************************************/
PROCEDURE p_create_cell_no(strEnterpriseNo   in cdef_defcell.enterprise_no%type,
                                strWareHouseNo    in cdef_defcell.warehouse_no%type,
                                strWareNo         in cdef_defcell.ware_no%type,
                                strAreaNo         in cdef_defcell.area_no%type,
                                nMinStockNo       in varchar2,--通道
                                nMaxStockNo       in varchar2,
                                nMinStockY        in varchar2,--层  若为空则给值0
                                nMaxStockY        in varchar2,
                                nMinStockX        in varchar2,--格
                                nMaxStockX        in varchar2,
                                nMinBayX          in varchar2,--位，若为空则给值0
                                nMaxBayX          in varchar2,
                                strCodePrefix     in varchar2,--前缀
                                nMixFlag          in cdef_defcell.mix_flag%type,
                                strMixSupplier    in cdef_defcell.mix_supplier%type,
                                strMixOwner       in cdef_defcell.mix_owner%type,
                                nMaxQty           in cdef_defcell.max_qty%type,
                                nMaxWeight        in cdef_defcell.max_weight%type,
                                nMaxVolume        in cdef_defcell.max_volume%type,
                                nMaxCase          in cdef_defcell.max_case%type,
                                strLimitType      in cdef_defcell.limit_type%type,
                                nlimitRate        in cdef_defcell.limit_rate%type,
                                strBPick          in cdef_defcell.b_pick%type,
                                strCellStatus     in cdef_defcell.cell_status%type,
                                strCheckStatus    in cdef_defcell.check_status%type,
                                strAFlag          in cdef_defcell.a_flag%type,
                                strPickFlag       in cdef_defcell.pick_flag%type,
                                strPerf1          in varchar,
                                strPerf2          in varchar,
                                strPerf3          in varchar,
                                strPerf4          in varchar,
                                strRgstName       in cdef_defcell.rgst_name%type,
                                strKeepLabelFlag  in cdef_defcell.keep_label_flag%type,
                                strCellRule      in varchar,
                                strResult         out varchar2
                                ) IS
  nTempStockNo     number;
  nTempStockY      number;
  nTempStockX      number;
  nTempBayX        number;

  v_stockNoMax     number;
  v_stockYMax      number;
  v_stockXMax      number;
  v_bayXMax        number;

  stockLength      number;                  --通道长度
  stockXLength     number;                  --格长度
  bayXLength       number;                  --位长度
  stockYLength     number;                  --层长度

  strTempCellNo cdef_defcell.cell_no%type;
  strDispCellNo cdef_defcell.disp_cell_no%type;
  BEGIN
    strResult := 'N|[p_create_cell_no]';
    --获取通道长度
    select length(nMaxStockNo) into stockLength  from dual;

    --获取格长度
    select length(nMaxStockX) into stockXLength  from dual;

    --获取位长度
    select length(nMaxBayX) into bayXLength  from dual;

    --获取层长度
     select length(nMaxStockY) into stockYLength  from dual;


    --通道
    select to_number(nMinStockNo) into nTempStockNo from dual;
    select to_number(nMaxStockNo) into v_stockNoMax from dual;
    while nTempStockNo <= v_stockNoMax loop

     --层
      select to_number(nMinStockY) into nTempStockY from dual;
      select to_number(nMaxStockY) into v_stockYMax from dual;
      while nTempStockY <= v_stockYMax loop

        --格
        select to_number(nMinStockX) into nTempStockX from dual;
        select to_number(nMaxStockX) into v_stockXMax from dual;
        while nTempStockX<=v_stockXMax loop

          --位
          select to_number(nMinBayX) into nTempBayX from dual;
          select to_number(nMaxBayX) into v_bayXMax from dual;

            while nTempBayX<=v_bayXMax loop
              --#代表不用前缀
              if strCodePrefix = '#' then
                strTempCellNo := '';
                strDispCellNo :='';
              else
                strTempCellNo := strCodePrefix;
                strDispCellNo := strCodePrefix;
              end if;
              --负1代表不拼接通道
              if nTempStockNo <>-1 then
                strTempCellNo := strTempCellNo||lpad(nTempStockNo,stockLength, '0');

                if strPerf1='2' and strDispCellNo is not null then
                  strDispCellNo := strDispCellNo||'-'||lpad(nTempStockNo,stockLength, '0');
                elsif strPerf1='3'  then
                   strDispCellNo := strDispCellNo||'('||lpad(nTempStockNo,stockLength, '0')||')';
                else
                  strDispCellNo := strDispCellNo||lpad(nTempStockNo,stockLength, '0');
                end if;

              end if;

              ---------
              strTempCellNo := strTempCellNo||lpad(nTempStockX,stockXLength,'0');

              if strPerf2='2' and strDispCellNo is not null then
                 strDispCellNo:=strDispCellNo||'-'||lpad(nTempStockX,stockXLength,'0');
              elsif strPerf2='3' then
                 strDispCellNo:=strDispCellNo||'('||lpad(nTempStockX,stockXLength,'0')||')';
              else
                 strDispCellNo := strDispCellNo||lpad(nTempStockX,stockXLength,'0');
              end if;
              ---------

              if strCellRule = '1' then
              if nTempBayX <> -1 then
                strTempCellNo := strTempCellNo ||
                                 lpad(nTempBayX, bayXLength, '0');
              
                if strPerf3 = '2' then
                  strDispCellNo := strDispCellNo || '-' ||
                                   lpad(nTempBayX, bayXLength, '0');
                elsif strPerf3 = '3' then
                  strDispCellNo := strDispCellNo || '(' ||
                                   lpad(nTempBayX, bayXLength, '0') || ')';
                else
                  strDispCellNo := strDispCellNo ||
                                   lpad(nTempBayX, bayXLength, '0');
                end if;
              
              end if;
            
              if nTempStockY <> -1 then
                strTempCellNo := strTempCellNo ||
                                 lpad(nTempStockY, stockYLength, '0');
              
                if strPerf4 = '2' then
                  strDispCellNo := strDispCellNo || '-' ||
                                   lpad(nTempStockY, stockYLength, '0');
                elsif strPerf4 = '3' then
                  strDispCellNo := strDispCellNo || '(' ||
                                   lpad(nTempStockY, stockYLength, '0') || ')';
                else
                  strDispCellNo := strDispCellNo ||
                                   lpad(nTempStockY, stockYLength, '0');
                end if;
              end if;
              elsif strCellRule = '2' then
                if nTempStockY <> -1 then
                strTempCellNo := strTempCellNo ||
                                 lpad(nTempStockY, stockYLength, '0');
              
                if strPerf4 = '2' then
                  strDispCellNo := strDispCellNo || '-' ||
                                   lpad(nTempStockY, stockYLength, '0');
                elsif strPerf4 = '3' then
                  strDispCellNo := strDispCellNo || '(' ||
                                   lpad(nTempStockY, stockYLength, '0') || ')';
                else
                  strDispCellNo := strDispCellNo ||
                                   lpad(nTempStockY, stockYLength, '0');
                end if;
                if nTempBayX <> -1 then
                strTempCellNo := strTempCellNo ||
                                 lpad(nTempBayX, bayXLength, '0');
              
                if strPerf3 = '2' then
                  strDispCellNo := strDispCellNo || '-' ||
                                   lpad(nTempBayX, bayXLength, '0');
                elsif strPerf3 = '3' then
                  strDispCellNo := strDispCellNo || '(' ||
                                   lpad(nTempBayX, bayXLength, '0') || ')';
                else
                  strDispCellNo := strDispCellNo ||
                                   lpad(nTempBayX, bayXLength, '0');
                end if;
              
              end if;
              end if;
           end if;


              --检查储位是否已存在
              update
                cdef_defcell a
              set a.cell_status=a.cell_status
              where
                a.enterprise_no=strEnterpriseNo
                and a.warehouse_no=strWareHouseNo
                and a.cell_no=strTempCellNo;

              if sql%rowcount > 0 then
                strResult := 'N|[储位'||strTempCellNo||'已存在，请检查设置！]';--储位已存在，请检查设置！
                return;
              end if;
              insert into cdef_defcell(
                warehouse_no,
                ware_no,
                area_no,
                stock_no,
                stock_x,
                bay_x,
                stock_y,
                cell_no,
                mix_flag,
                mix_supplier,mix_owner,
                max_qty,
                max_weight,
                max_volume,
                max_case,
                limit_type,
                limit_rate,
                b_pick,
                cell_status,
                check_status,
                a_flag,
                pick_flag,
                rgst_name,
                rgst_date,
                enterprise_no,
                prefix,
                disp_cell_no,keep_label_flag)
              values(
                strWareHouseNo,
                strWareNo,
                strAreaNo,
                case when nTempStockNo=-1 then '-1' else lpad(nTempStockNo,stockLength, '0') end,
                lpad(nTempStockX,stockXLength,'0'),
                case when nTempBayX=-1 then '-1' else lpad(nTempBayX,bayXLength,'0') end,
                case when nTempStockY=-1 then '-1' else lpad(nTempStockY,stockYLength,'0') end,
                strTempCellNo,
                nMixFlag,
                strMixSupplier,strMixOwner,
                nMaxQty,
                nMaxWeight,
                nMaxVolume,
                nMaxCase,
                strLimitType,
                nlimitRate,
                strBPick,
                strCellStatus,
                strCheckStatus,
                strAFlag,
                strPickFlag,
                strRgstName,
                sysdate,
                strEnterpriseNo,
                strCodePrefix,
                strDispCellNo,strKeepLabelFlag);
              nTempBayX :=nTempBayX+1;
            end loop;
          nTempStockX:=nTempStockX+1;
        end loop;
        nTempStockY :=nTempStockY+1;
      end loop;
      nTempStockNo:=nTempStockNo+1;
    end loop;
    strResult :='Y|';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_create_cell_no;

  /**********************************************************************************************************
   chensr
   2015.9.14
   功能：添加格子号
  ***********************************************************************************************************/
  PROCEDURE p_create_divide_d(strEnterpriseNo in device_divide_d.enterprise_no%type,
                              strWareHouseNo  in device_divide_d.warehouse_no%type,
                              strPerfix       in device_divide_d.bay_x%type,
                              strBayMin       in device_divide_d.bay_x%type,
                              strBayMax       in device_divide_d.bay_x%type,
                              strFloorMin     in device_divide_d.stock_y%type,
                              strFloorMax     in device_divide_d.stock_y%type,
                              strDeviceGroup  in device_divide_d.device_group_no%type,
                              strDeviceNo     in device_divide_d.device_no%type,
                              strMixflag      in device_divide_d.mix_flag%type,
                              strMixSupplier  in device_divide_d.mix_supplier%type,
                              strMaxQty       in device_divide_d.max_qty%type,
                              strMaxCase      in device_divide_d.max_case%type,
                              strMaxVolume    in device_divide_d.max_volume%type,
                              strMaxWeigth    in device_divide_d.max_weight%type,
                              strStatus       in device_divide_d.status%type,
                              strWorkerNo     in device_divide_d.rgst_name%type,
                              strResult       out varchar2)is

       v_bayMin           number;           --bayX循环最小值
       v_bayMax           number;           --bayX循环最大值
       v_floorMin         number;           --stockY循环最小值
       v_floorMax         number;           --stockY循环最大值
       v_bayTmp           number;
       v_floorTmp         number;

       v_bayLength        number;           --bayX的长度
       v_floorLength      number;           --stockY的长度

       v_bayXTmp          device_divide_d.bay_x%type;

     begin
       strResult:='Y|success';
       --获取bayX的循环最小值和最大值
       select to_number(strBayMin) into v_bayMin from dual;
       select to_number(strBayMax) into v_bayMax from dual;

       --获取stock_y的最小值和最大值
       select to_number(strFloorMin) into v_floorMin from dual;
       select to_number(strFloorMax) into v_floorMax from dual;

       --获取bayX的长度
       select length(strBayMax) into v_bayLength from dual;
       --获取stock_y的长度
       select length(strFloorMax) into v_floorLength from dual;

       --保存格子号
       v_bayTmp:=v_bayMin;
       while v_bayTmp <=v_bayMax loop
         --获取bayX

          v_bayXTmp := to_char(strPerfix)||to_char(lpad(v_bayTmp,v_bayLength, '0'));

          v_floorTmp:=v_floorMin;
          while v_floorTmp<=v_floorMax loop
            insert into device_divide_d(enterprise_no,
                                        warehouse_no,
                                        device_group_no,
                                        device_no,
                                        bay_x,
                                        stock_y,
                                        device_cell_no,
                                        mix_flag,
                                        mix_supplier,
                                        max_qty,
                                        max_weight,
                                        max_volume,
                                        max_case,
                                        status,
                                        check_status,
                                        rgst_name,
                                        rgst_date,
                                        pick_order)
                                values( strEnterpriseNo,
                                        strWareHouseNo,
                                        strDeviceGroup,
                                        strDeviceNo,
                                        v_bayXTmp,
                                        lpad(v_floorTmp,v_floorLength, '0'),
                                        v_bayXTmp || lpad(v_floorTmp,v_floorLength, '0'),
                                        strMixflag,
                                        strMixSupplier,
                                        strMaxQty,
                                        strMaxWeigth,
                                        strMaxVolume,
                                        strMaxCase,
                                        strStatus,
                                        '0',
                                        strWorkerNo,
                                        sysdate,
                                        0);
             if sql%rowcount <= 0 then
               strResult:='N|保存失败';
               return ;
             end if;
             v_floorTmp:=v_floorTmp+1;
          end loop;
          v_bayTmp:= v_bayTmp+1;
       end loop;

    end p_create_divide_d;


  /**********************************************************************************************************
   hekl
   2015.3.27
   功能：插入商品储位对应关系
***********************************************************************************************************/
  PROCEDURE saveOrUpdateCset_Cell_Article(strEnterpriseNo   in cdef_defcell.enterprise_no%type,
                                strWareHouseNo    in cdef_defcell.warehouse_no%type,
                                strOwnerNo        in cset_cell_article.Owner_No%type,
                                strWareNo         in cdef_defcell.ware_no%type,--库区
                                strAreaNo         in cdef_defcell.area_no%type,--储区
                                strStockNo        in cset_cell_article.stock_no%type, --通道
                                strAStockNo       in cset_cell_article.a_stock_no%type,--库区+储区+通道
                                strCellNo         in cset_cell_article.cell_no%type,--储位
                                strGroupNo        in bdef_article_group.group_no%type,--类别
                                strArticleNo      in bdef_article_group.group_no%type,--商品编码
                                strPackingQty     in bdef_article_packing.Packing_Qty%type,--包装数量
                                strLineId         in cset_cell_article.line_id%type,--线路
                                strMaxQtyA        in cset_cell_article.max_qty_a%type,--A类最大存储量
                                strAlertQtyA      in cset_cell_article.alert_qty_a%type,--A类补货警示量
                                strSuppQtyA       in cset_cell_article.supp_qty_a%type,--A类循环补货触发量
                                strMaxQtyNa       in cset_cell_article.max_qty_na%type,--非A类最大存储量
                                strAlertQtyNa     in cset_cell_article.alert_qty_na%type,--非A类补货警示量
                                strSuppQtyNa      in cset_cell_article.supp_qty_na%type,--非A类循环补货触发量
                                strKeepCells      in cset_cell_article.keep_cells%type,--非A类最大可用储位数
                                strPickType       in cset_cell_article.pick_type%type,--拣货类型
                                strKeepCellsA     in cset_cell_article.keep_cells_a%type, --A类最大可用储位数
                                strRgstName       in cdef_defcell.rgst_name%type,
                                strResult         out varchar2
                                ) is
    v_strCELLNo              cset_cell_article.cell_no%type;
    v_strStockX              cset_cell_article.stock_x%type;
    v_strPackingQty          cset_cell_article.packing_qty%type;
  BEGIN
    strResult := 'N|[saveOrUpdateCset_Cell_Article]';
    --判断cell_no是否为空
    if strCellNo='N' or strCellNo is null then
      --定义储位
      select  max(cel.prefix) into v_strCELLNo from cdef_defcell cel
          where cel.enterprise_no=strEnterpriseNo and cel.warehouse_no=strWareHouseNo
          and cel.ware_no=strWareNo and cel.area_no=strAreaNo
          and cel.stock_no=strStockNo;
      v_strCELLNo := v_strCELLNo||strStockNo;
      --定义储格
      v_strStockX :='N';
    else
      --定义储位
      v_strCELLNo :=strCellNo;
      --定义储格
      select cel.stock_x into v_strStockX from cdef_defcell cel
          where cel.enterprise_no=strEnterpriseNo and cel.warehouse_no=strWareHouseNo
          and cel.ware_no=strWareNo and cel.area_no=strAreaNo
          and cel.stock_no=strStockNo and cel.cell_no like strCellNo ||'%';
    end if;

  --判断商品编码是否有值(如果有值则是修改保存，没值则是新增保存)
    if strArticleNo='N' or strArticleNo is null then--新增保存
      --根据商品类别查询商品编码
      for no in(select d.ARTICLE_NO from bdef_defarticle d
                where d.enterprise_no=strEnterpriseNo and d.OWNER_NO=strOwnerNo
                and d.GROUP_NO=strGroupNo
        )loop

        --获取商品的最大包装
        select max(pk.packing_qty) into v_strPackingQty from bdef_article_packing pk
          where pk.enterprise_no=strEnterpriseNo and pk.article_no=no.article_no;

        --写商品储位对应关系表
        insert into Cset_Cell_Article(
               enterprise_no, Warehouse_No,
				       Owner_No, Ware_No, Area_No, Stock_No, a_Stock_No,
				       Stock_x, Cell_No, Article_No, Packing_Qty, Line_Id,
				       Max_Qty_a, Alert_Qty_a, Supp_Qty_a, Max_Qty_Na,
				       Alert_Qty_Na, Supp_Qty_Na, Keep_Cells, Pick_Type,
				       Keep_Cells_a, Rgst_Name, Rgst_Date
        )values(
               strEnterpriseNo,strWareHouseNo,strOwnerNo,strWareNo,strAreaNo,strStockNo,
               strAStockNo,v_strStockX,v_strCELLNo,no.article_no,v_strPackingQty,strLineId,
               strMaxQtyA,strAlertQtyA,strSuppQtyA,strMaxQtyNa,strAlertQtyNa,strSuppQtyNa,
               strKeepCells,strPickType,strKeepCellsA,strRgstName,sysdate
        );

        if sql%rowcount <= 0 then
           strResult := 'N|[E20501]';--写表失败];
           return;
        end if;

      end loop;


    else--修改保存
      update Cset_Cell_Article cle set cle.ware_no=strWareNo,cle.area_no=strAreaNo,cle.stock_no=strStockNo,
          cle.a_stock_no=strAStockNo,cle.stock_x=v_strStockX,cle.cell_no=v_strCELLNo,cle.line_id=strLineId,
          cle.max_qty_a=strMaxQtyA,cle.alert_qty_a=strAlertQtyA,cle.supp_qty_a=strSuppQtyA,cle.max_qty_na=strMaxQtyNa,
          cle.alert_qty_na=strMaxQtyNa,cle.supp_qty_na=strSuppQtyA,cle.keep_cells=strKeepCells,cle.keep_cells_a=strKeepCellsA,
          cle.updt_name=strRgstName,cle.updt_date=sysdate
          where cle.enterprise_no=strEnterpriseNo and cle.warehouse_no=strWareHouseNo and cle.owner_no=strOwnerNo
          and cle.article_no=strArticleNo and cle.packing_qty=strPackingQty and cle.pick_type=strPickType;


     --写商品储位对应关系日志表
        insert into Cset_Cell_Article_Log(
               enterprise_no, Warehouse_No,
				       Owner_No, Ware_No, Area_No, Stock_No, a_Stock_No,
				       Stock_x, Cell_No, Article_No, Packing_Qty, Line_Id,
				       Max_Qty_a, Alert_Qty_a, Supp_Qty_a, Max_Qty_Na,
				       Alert_Qty_Na, Supp_Qty_Na, Keep_Cells, Pick_Type,
				       Keep_Cells_a, Rgst_Name, Rgst_Date
               )
               select n.enterprise_no,n.warehouse_no,n.owner_no,n.ware_no,n.area_no,
                  n.stock_no,n.a_stock_no,n.stock_x,n.cell_no,n.article_no,n.packing_qty,
                  n.line_id,n.max_qty_a,n.alert_qty_a,n.supp_qty_a,n.max_qty_na,n.alert_qty_na,
                  n.supp_qty_na,n.keep_cells,n.pick_type,n.keep_cells_a,n.rgst_name,sysdate
               from Cset_Cell_Article n where n.enterprise_no=strEnterpriseNo and n.warehouse_no=strWareHouseNo
                  and n.owner_no=strOwnerNo and n.article_no=strArticleNo and n.packing_qty=strPackingQty
                  and n.pick_type=strPickType;

        if sql%rowcount <= 0 then
           strResult := 'N|[E60001]';--写日志表失败];
           return;
        end if;

    end if;
    strResult := 'Y';

end saveOrUpdateCset_Cell_Article;


  /**********************************************************************************************************
   hekl
   2015.12.14
   功能：储位修改保存
***********************************************************************************************************/
 PROCEDURE p_update_cell(strEnterpriseNo   in cdef_defcell.enterprise_no%type,
                                strWareHouseNo    in cdef_defcell.warehouse_no%type,
                                strCellNo         in cdef_defcell.cell_no%type,
                                strMixFlag          in cdef_defcell.mix_flag%type,
                                strMixSupplier    in cdef_defcell.mix_supplier%type,
                                strMixOwner       in cdef_defcell.mix_owner%type,
                                strMaxQty           in cdef_defcell.max_qty%type,
                                strMaxWeight        in cdef_defcell.max_weight%type,
                                strMaxVolume        in cdef_defcell.max_volume%type,
                                strMaxCase          in cdef_defcell.max_case%type,
                                strLimitType      in cdef_defcell.limit_type%type,
                                strlimitRate        in cdef_defcell.limit_rate%type,
                                strBPick          in cdef_defcell.b_pick%type,
                                strCellStatus     in cdef_defcell.cell_status%type,
                                strCheckStatus    in cdef_defcell.check_status%type,
                                strAFlag          in cdef_defcell.a_flag%type,
                                strPickFlag       in cdef_defcell.pick_flag%type,
                                strRgstName       in cdef_defcell.rgst_name%type,
                                strKeepLabelFlag  in cdef_defcell.keep_label_flag%type,
                                strResult         out varchar2)is
  v_strCount    number;
  v_article_no  bdef_defarticle.article_no%type;
  begin
    strResult:='N|[p_update_cell]';
    --判断该储位下是否有库存
     select count(*) into v_strCount from stock_content t where t.enterprise_no=strEnterpriseNo and
         t.warehouse_no=strWareHouseNo and t.cell_no=strCellNo;
     --有库存
     if v_strCount > 0 then

       --如果是禁用储位，如果有库存则不能禁用;
       if strCellStatus = '1' or strCellStatus = '2' then
          strResult:='N|[该货位下有库存，状态不能禁用或者冻结]';
          return;
       end if;

      --混属性(储位)的判断
      --当mix_flag的标识要从2、1改为0时或者从2改到1，
      --1、首先判断是否有多个商品的库存，若有，系统给予拦截
      --2、若有库存，且为单商品单一属性的，直接做修改，并且释放其他商品与该储位的对应关系，
      --3、若无库存，释放商品与该储位的对应关系
       if strMixFlag ='0' or strMixFlag ='1' then
           select count(*) into v_strCount from(select count(*) from stock_content t where t.enterprise_no=strEnterpriseNo
             and t.warehouse_no=strWareHouseNo and t.cell_no=strCellNo group by t.article_no);
           if v_strCount > 1 then
             strResult:='N|[该货位下有多商品库存，混属性标识不能修改]';
             return;
           end if;


          select count(*) into v_strCount from (select  t.cell_no,info.article_no,info.barcode,info.produce_date,info.expire_date,
             info.quality,info.lot_no,info.rsv_batch1, info.rsv_batch2, info.rsv_batch3, info.rsv_batch4,
             info.rsv_batch5,info.rsv_batch6,info.rsv_batch7, info.rsv_batch8
          from stock_content t,stock_article_info info where t.enterprise_no=strEnterpriseNo
             and t.warehouse_no=strWareHouseNo and t.cell_no=strCellNo and t.enterprise_no=info.enterprise_no
             and t.article_no=info.article_no and t.article_id=info.article_id
             group by t.cell_no, info.article_no,info.barcode,info.produce_date,info.expire_date,
             info.quality,info.lot_no,info.rsv_batch1, info.rsv_batch2, info.rsv_batch3, info.rsv_batch4,
             info.rsv_batch5, info.rsv_batch6,info.rsv_batch7, info.rsv_batch8);

          --如果该储位上的库存混属性,并且混属性标识为0（不可以混）则拦截
          if v_strCount > 1 and  strMixFlag ='0' then
            strResult:='N|[该货位下的库存是混属性商品，混属性标识不能修改为不可以混]';
            return;
          elsif v_strCount = 1 or strMixFlag ='1'  then --单商品属性库存或者混属性标识为混属性，释放其他商品与该储位的对应关系
            delete from stock_art_cell l where l.warehouse_no=strWareHouseNo
              and l.enterprise_no=strEnterpriseNo and l.article_no not in(select t.article_no from stock_content t
              where t.enterprise_no=strEnterpriseNo and t.warehouse_no=strWareHouseNo and t.cell_no=strCellNo);
          end if;

        end if;

       --混货主标识的判断
       --1、当混货主的标识修改成0不可混时，首先需要判断此储位是否是空储位（无库存），若空储位，直接删除stock_owner_cell表当前储位的数据
       --2、非空储位，判断是否已存在多个货主的库存，若存在，系统拦截，不允许修改
       --3、若不存在多货主库存，删除stock_owner_cell表无库存的货主的数据
       if strMixOwner='0' then
          select count(*) into v_strCount from(select t.owner_no from stock_content t where t.enterprise_no=strEnterpriseNo and t.warehouse_no=strWareHouseNo
            and t.cell_no=strCellNo group by t.owner_no);

          if v_strCount >1  then
             strResult:='N|[该货位下的库存在多个货主，混货主标识不能修改为可混]';
             return;
          else
            delete from stock_owner_cell l where l.warehouse_no=strWareHouseNo
               and l.enterprise_no=strEnterpriseNo and l.owner_no not in(select t.owner_no from stock_content t
               where t.enterprise_no=strEnterpriseNo and t.warehouse_no=strWareHouseNo and t.cell_no=strCellNo);
          end if;
       end if;
     else--无库存
         -- 1、释放商品与该储位的对应关系
         -- 2、删除stock_owner_cell表当前储位的数据
         delete from stock_art_cell l where l.warehouse_no=strWareHouseNo
              and l.enterprise_no=strEnterpriseNo and l.cell_no=strCellNo;

         delete from stock_owner_cell l where l.warehouse_no=strWareHouseNo
              and l.enterprise_no=strEnterpriseNo and l.cell_no=strCellNo;
     end if;

     --修改储位
     update cdef_defcell l set l.mix_flag=strMixFlag,l.mix_supplier=strMixSupplier,
         l.mix_owner=strMixOwner,l.max_qty=strMaxQty,l.max_weight=strMaxWeight,
         l.max_volume=strMaxVolume,l.max_case=strMaxCase,l.limit_type=strLimitType,
         l.limit_rate=strlimitRate,l.b_pick=strBPick,l.cell_status=strCellStatus,
         l.check_status=strCheckStatus,l.a_flag=strAFlag,l.pick_flag=strPickFlag,
         l.updt_name=strRgstName,l.updt_date=sysdate,l.keep_label_flag=strKeepLabelFlag
     where l.warehouse_no=strWareHouseNo and l.enterprise_no=strEnterpriseNo and l.cell_no=strCellNo;

     strResult:='Y';
 end p_update_cell;

 /*=====================================================================================
  hb insert to 20160526
  拣货位采集-检查商品对应的储位合法性
  ======================================================================================*/
  PROCEDURE p_Check_ArticleCell(strEnterPriseNo  in cdef_defcell.enterprise_no%type,--企业号,
                                strwarehouse_no  in cdef_defcell.warehouse_no%type, --仓别
                                strOwnerNo       in stock_content.owner_no%type, --货主编码
                                strLineId        in varchar2, --保拣线
                                strCellNo        in cdef_defcell.cell_no%type, --储位编号
                                strPickType      in cset_cell_article.pick_type%type, --拣货位类型
                                strArticleNo     in bdef_defarticle.article_no%type, --商品编号
                                strCellArticleNo out varchar2, --返回储位对应的商品编号
                                strOutMsg        out varchar2) is

    v_count         number;
    v_LineFlag      number; --保拣线是否正确标志 0-不正确；1-正确
    v_CellStatus    cdef_defcell.CELL_STATUS%type; --储位状态
    v_CheckStatus   cdef_defcell.CHECK_STATUS%type; --储位盘点状态
    v_AreaNo        cdef_defarea.area_no%type; --储区
    v_AreaUsetype   cdef_defarea.area_usetype%type; --储区用途：1:普通存储区；2：报损区；3：退货区；5：异常区；6:贵重品区
    v_AreaAttribute cdef_defarea.area_attribute%type; --0：作业区；1：暂存区；2;已配送区；3:问题区；4：虚拟区。选择作业区时，暂存区性质不可见，选择暂存区时，储区性质不可见；问题区、虚拟区和已配送区时，两个都不可见。移库时，作业区内可以互移，暂存区不可移入不同性质的暂存区，作业区和暂存区都不可移到已配送区；暂存区可往作业区移，作业区不可移入暂存区；作业区和问题区可互移。
    v_AreaPick      cdef_defarea.area_pick%type; --是否拣货区，0---保管区；1--拣货区
    v_Otype         cdef_defarea.o_type%type; --P-栈板；C-整箱；B-零散
    v_MixFlag       cdef_defarea.mix_flag%type; --0:不可混；1：同商品不同属性混；2：不同商品混
    v_ListLineId    varchar2(100); --保拣线
    v_CellArticleNo bdef_defarticle.article_no%type; --当前储位对应的商品编号

  begin
    strOutMsg := 'N|[p_Check_ArticleCell]';

    --判断储位是否存在 以及状态是否被禁用
    begin
      select CELL_STATUS, CHECK_STATUS into v_CellStatus, v_CheckStatus from cdef_defcell
      where enterprise_no = strEnterPriseNo and warehouse_no = strwarehouse_no and cell_no = strCellNo;
    exception
      when no_data_found then
        strOutMsg := 'N|[储位('|| strCellNo ||')不存在]';
        return;
    end;

    if v_CellStatus <> '0' then
      strOutMsg := 'N|[储位('|| strCellNo ||')状态不可用]';
      return;
    end if;

    if v_CheckStatus <> '0' then
      strOutMsg := 'N|[储位('|| strCellNo ||')盘点状态不可用]';
      return;
    end if;

    --判断储区属性是否允许设置为拣货位
    begin
      select cda.area_no, cda.AREA_USETYPE, cda.AREA_ATTRIBUTE, cda.AREA_PICK, cda.o_type, cda.mix_flag
        into v_AreaNo, v_AreaUsetype, v_AreaAttribute, v_AreaPick, v_Otype, v_MixFlag
        from cdef_defarea cda, cdef_defcell cdc
       where cda.enterprise_no = cdc.enterprise_no
         and cda.warehouse_no = cdc.warehouse_no
         and cda.ware_no = cdc.ware_no
         and cda.area_no = cdc.area_no
         and cdc.enterprise_no = strEnterPriseNo
         and cdc.warehouse_no = strwarehouse_no
         and cdc.cell_no = strCellNo;
   exception
      when no_data_found then
        strOutMsg := 'N|[储位('|| strCellNo ||')不存在储区信息]';
        return;
    end;

    if v_AreaUsetype <> '1' then
      strOutMsg := 'N|[储位('|| strCellNo ||')的储区('|| v_AreaNo ||')不是普通存储区]';
      return;
    end if;
    if v_AreaAttribute <> '0' then
      strOutMsg := 'N|[储位('|| strCellNo ||')的储区('|| v_AreaNo ||')不是作业区]';
      return;
    end if;
    if v_AreaPick <> '1' then
      strOutMsg := 'N|[储位('|| strCellNo ||')的储区('|| v_AreaNo ||')不是拣货区]';
      return;
    end if;
    if v_Otype <> strPickType then
      strOutMsg := 'N|[储位('|| strCellNo ||')的储区('|| v_AreaNo ||')下架方式和设置拣货位方式不一致]';
      return;
    end if;

    --判断保拣线是否为当前储区的保拣线
    if strLineId <> 'N' then
      v_ListLineId := 'N';
      v_LineFlag   := 0;
      for v_cabm in (select cabm.line_id
                       from cset_area_backup_m cabm, cdef_defcell cdc
                      where cabm.enterprise_no = cdc.enterprise_no
                        and cabm.warehouse_no = cdc.warehouse_no
                        and cabm.s_ware_no = cdc.ware_no
                        and cabm.s_area_no = cdc.area_no
                        and cdc.enterprise_no = strEnterPriseNo
                        and cdc.warehouse_no = strwarehouse_no
                        and cdc.cell_no = strCellNo ) loop

        v_ListLineId := v_ListLineId || v_cabm.line_id || ',';
        if v_cabm.line_id = to_number(strLineId) then
          v_LineFlag := 1;
          exit;
        end if;
      end loop;
      if v_ListLineId = 'N' then
        strOutMsg := 'N|[储位('|| strCellNo ||')的储区('|| v_AreaNo ||')没有保拣线]';
        return;
      end if;

      --如果输入的保拣线和储位对应的保拣线不匹配 则报错
      if v_LineFlag <> 1 then
        v_ListLineId := substr(v_ListLineId,2,length(v_ListLineId) - 1);
        strOutMsg := 'N|[储位('|| strCellNo ||')的储区('|| v_AreaNo ||')对应的保拣线('|| v_ListLineId ||')不包含保拣线('|| strLineId ||')]';
        return;
      end if;
    end if;

    --如果当前储区为不可混载 则做一下判断
    v_CellArticleNo  := 'N';
    strCellArticleNo := 'N';
    if v_MixFlag <> '2' then

      --判断储位是否为别的商品的保拣线
      begin
        select article_no into v_CellArticleNo from cset_cell_article
        where enterprise_no = strEnterPriseNo and warehouse_no = strwarehouse_no and owner_no = strOwnerNo
          and cell_no = strCellNo and pick_type = strPickType and article_no <> strArticleNo and rownum = 1;
      exception
        when no_data_found then
          v_CellArticleNo := 'N';
      end;

      --判断储位是否存在非当前商品的库存
      v_count   := 0;
      select count(1) into v_count
        from stock_content
       where enterprise_no = strEnterPriseNo and warehouse_no = strwarehouse_no and owner_no = strOwnerNo
         and cell_no = strCellNo and article_no <> strArticleNo;
      if v_count > 0 then
        strOutMsg := 'N|[储位('|| strCellNo ||')存在别的商品库存]';
        return;
      end if;

      --如果当前储位是别的商品的储位 且 不存在库存 则 返回界面判断是否删除
      if v_CellArticleNo <> 'N' and v_count <= 0 then
        strCellArticleNo := v_CellArticleNo;
        strOutMsg := 'X|[储位('|| strCellNo ||')为商品('|| strCellArticleNo ||')的拣货位,且不存在库存]';
        return;
      end if;

    end if;

    strOutMsg := 'Y|';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_Check_ArticleCell;

  /*=====================================================================================
  hb insert to 20160526
  拣货位采集-删除当前储位与原有商品的对应关系
  ======================================================================================*/
  PROCEDURE p_delete_ArticleCell(strEnterPriseNo  in cset_cell_article.enterprise_no%type,--企业号,
                                 strwarehouse_no  in cset_cell_article.warehouse_no%type, --仓别
                                 strOwnerNo       in cset_cell_article.owner_no%type, --货主编码
                                 strPickType      in cset_cell_article.pick_type%type, --拣货位类型
                                 strCellArticleNo in bdef_defarticle.article_no%type, --商品编号
                                 strOutMsg        out varchar2) is

  begin
    strOutMsg := 'N|[p_delete_ArticleCell]';

    --删除当前储位与原有商品的对应关系
    delete cset_cell_article
    where enterprise_no = strEnterPriseNo and warehouse_no = strwarehouse_no
      and article_no = strCellArticleNo and owner_no = strOwnerNo and pick_type = strPickType;
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[删除商品('|| strCellArticleNo ||')对应的拣货位失败(删除0行)]';
      return;
    end if;

    strOutMsg := 'Y|';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_delete_ArticleCell;

  /*=====================================================================================
  hb insert to 20160526
  拣货位采集-保存商品与储位对应关系
  ======================================================================================*/
  PROCEDURE p_save_ArticleCell(strEnterPriseNo    in cset_cell_article.enterprise_no%type,--企业号,
                               strwarehouse_no  in cset_cell_article.warehouse_no%type, --仓别
                               strOwnerNo       in cset_cell_article.owner_no%type, --货主编码
                               strPickType      in cset_cell_article.pick_type%type, --拣货位类型
                               strCellNo        in cdef_defcell.cell_no%type, --储位
                               nPackingQty      in cset_cell_article.packing_qty%type, --包装数量
                               nLineId          in cset_area_backup_m.line_id%type, --拣货线
                               nMaxQtyA         in cset_cell_article.MAX_QTY_A%type, --最大存储量（箱）
                               nAlertQtyA       in cset_cell_article.ALERT_QTY_A%type, --补货警示量（箱）
                               nSuppQtyA        in cset_cell_article.SUPP_QTY_A%type, --循环补货触发量（箱）
                               nKeepCells       in cset_cell_article.KEEP_CELLS%type, --可用货位数
                               strArticleNo     in bdef_defarticle.article_no%type, --商品编号
                               strUser_Id       in cset_cell_article.rgst_name%type, --操作人员
                               strOutMsg        out varchar2) is

    v_WareNo  cdef_defcell.WARE_NO%type;
    v_AreaNo  cdef_defcell.area_no%type;
    v_StockNo cdef_defcell.stock_no%type;
    v_StockX  cdef_defcell.stock_x%type;

  begin
    strOutMsg := 'N|[p_save_ArticleCell]';

    --获取当前储位储区信息
    begin
      select WARE_NO, area_no, stock_no, stock_x
        into v_WareNo, v_AreaNo, v_StockNo, v_StockX
       from cdef_defcell
      where enterprise_no = strEnterPriseNo and warehouse_no = strwarehouse_no and cell_no = strCellNo;
    exception
      when no_data_found then
        strOutMsg := 'N|[储位('|| strCellNo ||')信息不存在]';
        return;
    end;

    --更新商品储位对应关系
    update cset_cell_article
       set WARE_NO = v_WareNo, AREA_NO = v_AreaNo, STOCK_NO = v_StockNo, A_STOCK_NO = v_StockNo
           , STOCK_X = v_StockX, CELL_NO = strCellNo, PACKING_QTY = nPackingQty, LINE_ID = nLineId
           , MAX_QTY_A = nMaxQtyA, ALERT_QTY_A = nAlertQtyA, SUPP_QTY_A = nSuppQtyA, MAX_QTY_NA = nMaxQtyA
           , ALERT_QTY_NA = nAlertQtyA, SUPP_QTY_NA = nSuppQtyA, KEEP_CELLS = nKeepCells, KEEP_CELLS_A = nKeepCells
           , UPDT_NAME = strUser_Id, UPDT_DATE = sysdate
    where enterprise_no = strEnterPriseNo and warehouse_no = strwarehouse_no
      and article_no = strArticleNo and owner_no = strOwnerNo and pick_type = strPickType;
    --更新不到则新增
    if sql%rowcount <= 0 then
      insert into cset_cell_article
        (warehouse_no, owner_no, ware_no, area_no, stock_no
        , a_stock_no, stock_x, cell_no, article_no, packing_qty
        , line_id, max_qty_a, alert_qty_a, supp_qty_a, max_qty_na
        , alert_qty_na, supp_qty_na, keep_cells, pick_type, keep_cells_a
        , rgst_name, rgst_date, enterprise_no)
      values
        (strwarehouse_no, strOwnerNo, v_WareNo, v_AreaNo, v_StockNo
        , v_StockNo, v_StockX, strCellNo, strArticleNo, nPackingQty
        , nLineId, nMaxQtyA, nAlertQtyA, nSuppQtyA, nMaxQtyA
        , nAlertQtyA, nSuppQtyA, nKeepCells, strPickType, nKeepCells
        , strUser_Id, sysdate, strEnterPriseNo);
      if sql%rowcount <= 0 then
        strOutMsg := 'N|[新增商品('|| strArticleNo ||')与储位('|| strCellNo ||')对应关系失败(新增0行)]';
        return;
      end if;
    end if;

    strOutMsg := 'Y|';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_save_ArticleCell;

end PKOBJ_CDEF;

/

