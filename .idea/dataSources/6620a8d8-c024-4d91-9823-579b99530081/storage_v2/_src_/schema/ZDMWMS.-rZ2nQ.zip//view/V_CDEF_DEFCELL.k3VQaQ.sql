create view V_CDEF_DEFCELL as
select a.enterprise_no, a."WAREHOUSE_NO",a."WARE_NO",a."AREA_NO",a."STOCK_NO",a."STOCK_X",a."BAY_X",a."STOCK_Y",a."CELL_NO",a."MIX_FLAG",a."MIX_SUPPLIER",a."MAX_QTY",a."MAX_WEIGHT",a."MAX_VOLUME",a."MAX_CASE",a."LIMIT_TYPE",a."LIMIT_RATE",a."B_PICK",a."CELL_STATUS",a."CHECK_STATUS",a."A_FLAG",a."PICK_FLAG",a."RGST_NAME",a."RGST_DATE",a."UPDT_NAME",a."UPDT_DATE",a.cell_no||','|| case
when a.cell_status=1 then a.cell_status
when a.cell_status<>1 and b.qty is not null then '2'
when a.cell_status<>1 and b.qty is null then '3'
/*when a.cell_status<>1 and t.cell_no is not null then '4'
*/  end cell_no_and_cell_status
from cdef_defcell a left join stock_content b on a.cell_no=b.cell_no
and a.warehouse_no=b.warehouse_no
and a.enterprise_no=b.enterprise_no
/*left join cset_cell_article t on a.enterprise_no=t.enterprise_no and a.warehouse_no=t.warehouse_no and a.cell_no=t.cell_no;
*/


/

