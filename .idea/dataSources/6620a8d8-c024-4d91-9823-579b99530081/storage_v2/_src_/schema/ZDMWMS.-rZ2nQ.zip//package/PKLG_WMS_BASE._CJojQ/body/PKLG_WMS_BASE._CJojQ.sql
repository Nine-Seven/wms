create package body        PKLG_WMS_BASE is
  /*****************************************************************************************
   功能：产生单号
  Modify By luozhiling AT 2013-9-28
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure p_getsheetno(strEnterPriseNo in bdef_paperno.enterprise_no%type,
                         strWareHouseNo  in bdef_paperno.warehouse_no%type, --仓别
                         SheetType       in bdef_paperno.papertype%type, --单头
                         cSheetNo        out varchar2, --返回单号
                         strOutMsg       out varchar2) --返回 执行结果
   is
    pragma autonomous_transaction;
    v_strPaperType bdef_paperno.papertype%type;
    strDate        char(6);
    nSerialLen     bdef_paperno.length%type;
    serialno       bdef_paperno.serialno%type;
    chgdate        bdef_paperno.chgdate%type;
    cserial        bdef_paperno.serialno%type;
  begin
    v_strPaperType := UPPER(SheetType);
    strDate        := to_char(sysdate, 'yymmdd');

    begin
      strOutMsg := 'N|[p_getsheetno]';
      begin
        select serialno, chgdate, length
          into serialno, chgdate, nSerialLen
          from bdef_paperno
         where papertype = v_strPaperType
           and wareHouse_No = strWareHouseNo
           and enterprise_no = strEnterPriseNo
           for update;
      exception
        when no_data_found then
          insert into bdef_paperno
            (enterprise_no,
             warehouse_no,
             papertype,
             serialno,
             length,
             chgdate,
             chgtime)
          values
            (strEnterPriseNo,
             strWareHouseNo,
             v_strPaperType,
             '00000',
             5,
             to_char(sysdate, 'yymmdd'),
             to_char(sysdate, 'hh24:mi'));

          select serialno, chgdate, length
            into serialno, chgdate, nSerialLen
            from bdef_paperno
           where enterprise_no = strEnterPriseNo
             and papertype = v_strPaperType
             and wareHouse_No = strWareHouseNo
             for update;
      end;

      if strDate = chgdate then
        --判断日期是否等于当天
        serialno := serialno + 1;
      else
        --不等于，serialno =1
        serialno := 1;
      end if;

      cserial  := LPAD(serialno, nSerialLen, '0');
      cSheetNo := v_strPaperType || strWareHouseNo || strDate || cserial;

      update bdef_paperno
         set serialno = cserial,
             chgtime  = to_char(sysdate, 'hh24:mi'),
             chgdate  = strDate
       where papertype = v_strPaperType
         and warehouse_no = strWareHouseNo
         and enterprise_no = strEnterPriseNo;
      if sql%notfound then
        rollback;
        strOutMsg := 'N|[E00012]';
        return;
      end if;

      strOutMsg := 'Y';
      commit;
    end;
  end p_getsheetno;
  /*****************************************************************************************
   功能：产生基础资料编码
  Modify By wyf AT 2015-11-03
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure p_getBaseNo(strEnterPriseNo in bdef_paperno.enterprise_no%type,
                       strOwnerNo      bdef_paperno.warehouse_no%type, --货主编码
                       SheetType       in bdef_paperno.papertype%type, --类型 SKU：商品，CUST：客户，SUP：供应商
                       cSheetNo        out varchar2, --返回编码
                       strOutMsg       out varchar2) --返回 执行结果
   is
    pragma autonomous_transaction;
    v_strPaperType bdef_paperno.papertype%type;
    strDate        char(6);
    nSerialLen     bdef_paperno.length%type;
    serialno       bdef_paperno.serialno%type;
    chgdate        bdef_paperno.chgdate%type;
    cserial        bdef_paperno.serialno%type;
  begin
    v_strPaperType := UPPER(SheetType);
    strDate        := to_char(sysdate, 'yymmdd');

    begin
      strOutMsg := 'N|[p_getsheetno]';
      begin
        select serialno, chgdate, length
          into serialno, chgdate, nSerialLen
          from bdef_paperno
         where papertype = v_strPaperType
           and wareHouse_No = strOwnerNo
           and enterprise_no = strEnterPriseNo
           for update;
      exception
        when no_data_found then
          insert into bdef_paperno
            (enterprise_no,
             warehouse_no,
             papertype,
             serialno,
             length,
             chgdate,
             chgtime)
          values
            (strEnterPriseNo,
             strOwnerNo,
             v_strPaperType,
             '0000000',
             7,
             to_char(sysdate, 'yymmdd'),
             to_char(sysdate, 'hh24:mi'));

          select serialno, chgdate, length
            into serialno, chgdate, nSerialLen
            from bdef_paperno
           where enterprise_no = strEnterPriseNo
             and papertype = v_strPaperType
             and wareHouse_No = strOwnerNo
             for update;
      end;

      --编码取值
      serialno := serialno + 1;
      cserial  := LPAD(serialno, nSerialLen, '0');
      cSheetNo := strOwnerNo || cserial;

      update bdef_paperno
         set serialno = cserial,
             chgtime  = to_char(sysdate, 'hh24:mi'),
             chgdate  = strDate
       where papertype = v_strPaperType
         and warehouse_no = strOwnerNo
         and enterprise_no = strEnterPriseNo;
      if sql%notfound then
        rollback;
        strOutMsg := 'N|[E00012]';
        return;
      end if;
      strOutMsg := 'Y';
      commit;
    end;
  end p_getBaseNo;
  /*****************************************************************************************
   功能：读取系统参数
  Modify By luozhiling AT 2013-10-4
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure p_GetBasePara(strEnterpriseNo in wms_warehouse_owner_base.enterprise_no%type,
                          strWareHouseNo  in wms_warehouse_owner_base.warehouse_no%type, --仓别
                          strOwner_NO     in wms_warehouse_owner_base.owner_no%type, --委托业主
                          strCOLNAME      in WMS_DEFBASE.Colname%type, --参数名
                          strGROUP_NO     in WMS_DEFBASE.Group_No%type, --模块号
                          strsubgroup_no  in WMS_DEFBASE.SUB_GROUP_NO%type, --子模块号
                          Outsdefine      out WMS_DEFBASE.Sdefine%type, --参数的字符性值
                          Outndefine      out WMS_DEFBASE.Ndefine%type, --参数的整数值
                          strOutMsg       out varchar2) --返回 执行结果
   is
  begin
    begin
      select sdefine, ndefine
        into Outsdefine, Outndefine
        from wms_warehouse_owner_base
       where OWNER_NO = strOwner_NO
         and warehouse_no = strWareHouseNo
         and enterprise_no = strEnterpriseNo
         and upper(colname) = upper(strCOLNAME)
         and group_no = strGROUP_NO
         and SUB_GROUP_NO = strsubgroup_no;
    exception
      when no_data_found then
        begin
          select sdefine, ndefine
            into Outsdefine, Outndefine
            from wms_owner_base
           where OWNER_NO = strOwner_NO
             and upper(colname) = upper(strCOLNAME)
             and group_no = strGROUP_NO
             and SUB_GROUP_NO = strsubgroup_no;
        exception
          when no_data_found then
            begin
              select sdefine, ndefine
                into Outsdefine, Outndefine
                from WMS_WAREHOUSE_BASE
               where WAREHOUSE_NO = strWareHouseNo
                 and enterprise_no = strEnterpriseNo
                 and upper(colname) = upper(strCOLNAME)
                 and group_no = strGROUP_NO
                 and SUB_GROUP_NO = strsubgroup_no;
            exception
              when no_data_found then
                select sdefine, ndefine
                  into Outsdefine, Outndefine
                  from WMS_DEFBASE
                 where upper(colname) = upper(strCOLNAME)
                   and group_no = strGROUP_NO
                   and enterprise_no = strEnterpriseNo
                   and SUB_GROUP_NO = strsubgroup_no;

            end;
        end;
    end;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end p_GetBasePara;

  /*****************************************************************************************
   功能：读取系统参数
  add  By lizhiping AT 2015-7-9
  pragma autonomous_transaction;
  *****************************************************************************************/
  function f_GetBaseParaStr(strEnterpriseNo in wms_warehouse_owner_base.enterprise_no%type,
                            strWareHouseNo  in wms_warehouse_owner_base.warehouse_no%type, --仓别
                            strOwner_NO     in wms_warehouse_owner_base.owner_no%type, --委托业主
                            strCOLNAME      in WMS_DEFBASE.Colname%type, --参数名
                            strGROUP_NO     in WMS_DEFBASE.Group_No%type, --模块号
                            strsubgroup_no  in WMS_DEFBASE.SUB_GROUP_NO%type)
    return varchar2 --返回 执行结果
   is
    Result WMS_DEFBASE.Sdefine%type;
  begin
    begin
      select sdefine
        into Result
        from wms_warehouse_owner_base
       where OWNER_NO = strOwner_NO
         and warehouse_no = strWareHouseNo
         and enterprise_no = strEnterpriseNo
         and upper(colname) = upper(strCOLNAME)
         and group_no = strGROUP_NO
         and SUB_GROUP_NO = strsubgroup_no;
    exception
      when no_data_found then
        begin
          select sdefine
            into Result
            from wms_owner_base
           where OWNER_NO = strOwner_NO
             and upper(colname) = upper(strCOLNAME)
             and group_no = strGROUP_NO
             and SUB_GROUP_NO = strsubgroup_no;
        exception
          when no_data_found then
            begin
              select sdefine
                into Result
                from WMS_WAREHOUSE_BASE
               where WAREHOUSE_NO = strWareHouseNo
                 and enterprise_no = strEnterpriseNo
                 and upper(colname) = upper(strCOLNAME)
                 and group_no = strGROUP_NO
                 and SUB_GROUP_NO = strsubgroup_no;
            exception
              when no_data_found then
                select sdefine
                  into Result
                  from WMS_DEFBASE
                 where upper(colname) = upper(strCOLNAME)
                   and group_no = strGROUP_NO
                   and enterprise_no = strEnterpriseNo
                   and SUB_GROUP_NO = strsubgroup_no;

            end;
        end;
    end;
    return(Result);
  exception
    when others then

      return('ERROR');

  end f_GetBaseParaStr;

  /*****************************************************************************************
   功能：读取系统参数
  add  By lizhiping AT 2015-7-9
  pragma autonomous_transaction;
  *****************************************************************************************/
  function f_GetBaseParaInt(strEnterpriseNo in wms_warehouse_owner_base.enterprise_no%type,
                            strWareHouseNo  in wms_warehouse_owner_base.warehouse_no%type, --仓别
                            strOwner_NO     in wms_warehouse_owner_base.owner_no%type, --委托业主
                            strCOLNAME      in WMS_DEFBASE.Colname%type, --参数名
                            strGROUP_NO     in WMS_DEFBASE.Group_No%type, --模块号
                            strsubgroup_no  in WMS_DEFBASE.SUB_GROUP_NO%type)
    return number --返回 执行结果
   is
    Result WMS_DEFBASE.Ndefine%type;
  begin
    begin
      select Ndefine
        into Result
        from wms_warehouse_owner_base
       where OWNER_NO = strOwner_NO
         and warehouse_no = strWareHouseNo
         and enterprise_no = strEnterpriseNo
         and upper(colname) = upper(strCOLNAME)
         and group_no = strGROUP_NO
         and SUB_GROUP_NO = strsubgroup_no;
    exception
      when no_data_found then
        begin
          select Ndefine
            into Result
            from wms_owner_base
           where OWNER_NO = strOwner_NO
             and upper(colname) = upper(strCOLNAME)
             and group_no = strGROUP_NO
             and SUB_GROUP_NO = strsubgroup_no;
        exception
          when no_data_found then
            begin
              select Ndefine
                into Result
                from WMS_WAREHOUSE_BASE
               where WAREHOUSE_NO = strWareHouseNo
                 and enterprise_no = strEnterpriseNo
                 and upper(colname) = upper(strCOLNAME)
                 and group_no = strGROUP_NO
                 and SUB_GROUP_NO = strsubgroup_no;
            exception
              when no_data_found then
                select Ndefine
                  into Result
                  from WMS_DEFBASE
                 where upper(colname) = upper(strCOLNAME)
                   and group_no = strGROUP_NO
                   and enterprise_no = strEnterpriseNo
                   and SUB_GROUP_NO = strsubgroup_no;

            end;
        end;
    end;
    return(Result);
  exception
    when others then

      return(-99999);

  end f_GetBaseParaInt;

  /*****************************************************************************************
   功能：获取商品属性ID
  Modify By luozhiling AT 2013-10-4
  pragma autonomous_transaction;
  *****************************************************************************************/
  procedure p_getArticleID(strEnterpriseNo in stock_article_info.enterprise_no%type,
                           strArticle_No   in stock_article_info.Article_No%type, --商品编号
                           strBarcode      in stock_article_info.Barcode%type, --条码
                           strlot_no       in stock_article_info.lot_no%type, --批号
                           nProduce_Date   in stock_article_info.Produce_Date%type, --生产日期
                           nexpire_date    in stock_article_info.expire_date%type, --到期日期
                           --stritem_type       in stock_article_info.item_type%type, --类型
                           strquality in stock_article_info.quality%type, --品质
                           --strbatch_serial_no in stock_article_info.batch_serial_no%type, --批次流水号
                           --strSupplier_No     in stock_article_info.Supplier_No%type, --供应商
                           strRSV_BATCH1      in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                           strRSV_BATCH2      in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                           strRSV_BATCH3      in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                           strRSV_BATCH4      in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                           strRSV_BATCH5      in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                           strRSV_BATCH6      in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                           strRSV_BATCH7      in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                           strRSV_BATCH8      in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                           strimport_batch_no in stock_article_info.import_batch_no%type, --验收批次号
                           blInsertFlag       IN varchar2, --不存在是否新增Article_id 0:新增，1不新增
                           strUserId          in stock_article_info.rgst_name%type,
                           strPrice           in stock_article_info.price%type,--单价
                           nArticle_id        out stock_article_info.article_id%type, --商品属性ID
                           strOutMsg          out varchar2) --返回是否成功
   is
    v_strQuality           stock_article_info.quality%type:='0';
    pragma autonomous_transaction;
  begin

    strOutMsg := 'N|[p_getArticleID]';
    begin
      select
       article_id
        into nArticle_id
        from stock_article_info
       where enterprise_no = strEnterpriseNo
         and article_no = strArticle_No
         and Barcode = strBarcode
         and lot_no = strlot_no
         and produce_date = nProduce_Date
         and expire_date = nexpire_date
         and quality = v_strQuality --strquality Modify BY QZH AT 2016-7-12 不在商品属性中区分品质
         and import_batch_no = strimport_batch_no
         and ((strPrice is not null and price = strPrice) or (strPrice is null and price is null))
         and RSV_BATCH1 = strRSV_BATCH1
         and RSV_BATCH2 = strRSV_BATCH2
         and RSV_BATCH3 = strRSV_BATCH3
         and RSV_BATCH4 = strRSV_BATCH4
         and RSV_BATCH5 = strRSV_BATCH5
         and RSV_BATCH6 = strRSV_BATCH6
         and RSV_BATCH7 = strRSV_BATCH7
         and RSV_BATCH8 = strRSV_BATCH8;
    exception
      when no_data_found then
        if blInsertFlag = 0 then

          --------------------没有取到,新增商品属性ID------------------------------------
          ------------------------1。锁商品主档表---------------------------------------
          update bdef_defarticle
             set status = status
           where article_no = strArticle_No
             and enterprise_no = strEnterpriseNo;
          ------------------------2。取最大商品ID----------------------------------------
          select nvl(max(Article_ID), 0) + 1 article_id
            into nArticle_id
            from stock_article_info
           where article_no = strArticle_No
             and enterprise_no = strEnterpriseNo;
          ---------------------3。新增商品属性ID-----------------------------------------
          insert into stock_article_info
            (enterprise_no,
             article_no,
             article_id,
             barcode,
             lot_no,
             produce_date,
             expire_date,
             quality,
             rsv_batch1,
             rsv_batch2,
             rsv_batch3,
             rsv_batch4,
             rsv_batch5,
             rsv_batch6,
             rsv_batch7,
             rsv_batch8,
             import_batch_no,
             rgst_name,
             rgst_date,price)
          values
            (strEnterPriseNo,
             strArticle_No,
             nArticle_id,
             strBarcode,
             strlot_no,
             nProduce_Date,
             nexpire_date,
             v_strQuality,--strquality,不在商品属性中区分品质 Modify BY QZH AT 2016-7-12
             strRSV_BATCH1,
             strRSV_BATCH2,
             strRSV_BATCH3,
             strRSV_BATCH4,
             strRSV_BATCH5,
             strRSV_BATCH6,
             strRSV_BATCH7,
             strRSV_BATCH8,
             strimport_batch_no,
             strUserId,
             sysdate,strPrice);
          if sql%rowcount <= 0 then
            rollback;
            strOutMsg := 'N|[E00013]';
            return;
          end if;
        else
          strOutMsg := 'N|[E00013]';
          return;
        end if;
    end;
    commit;
    strOutMsg := 'Y';
  end p_getArticleID;

  /*****************************************************************************************
   功能：获取容器号
   luozhiling
   2013-10-10
  *****************************************************************************************/
  procedure p_get_ContainerNoBase(strEnterpriseNo       in wms_defcontainer.enterprise_no%type,
                                  strWareHouseNo        in WMS_DEFCONTAINER.warehouse_no%type, --仓别
                                  strPaperType          in WMS_DEFCONTAINER.CONTAINER_TYPE%type, --类型
                                  strUser_ID            in WMS_DEFCONTAINER.rgst_name%type, --添加人员
                                  strGetType            in varchar2, --返回类型，为'T'时，不返回标签号，直接写入container_no_loc表
                                  nGetNum               in number, --产生容器号数量
                                  strUse_Type           in WMS_DEFCONTAINER.use_type%type, --标签用途
                                  strContainer_Material in WMS_DEFCONTAINER.Container_Material%type, --容器材质
                                  strOutLabelNo         out stock_label_m.label_no%type, --返回标签号
                                  strOutContainerNo     out stock_label_m.container_no%type, --返回容器号
                                  strSESSION_ID         out varchar2, --不返回标签号时，返回sessionID号
                                  strOutMsg             out varchar2) --返回 执行结果
   is
    pragma autonomous_transaction;
    v_strWareHouseNo         varchar2(10); --仓别
    strDefine                varchar2(2); --读取系统参数使用
    strLabelNo               varchar2(50); --序列号
    strSerialNo              varchar2(50); --当前流水号
    strLabel_Prefix          varchar2(50); --标签前缀
    strPreFix                WMS_DEFCONTAINER.CONTAINER_PREFIX%type; --容器号前缀
    nSerialLen               WMS_DEFCONTAINER.CODE_LENGTH%type; --序列长度
    strNewContainer_Material WMS_DEFCONTAINER.Container_Material%type; --容器材质
    nSerialNo                number; --序列号
    nMaxSerial               number; --最大序列
    v_nDefine                wms_defbase.sdefine%type;
  begin
    strOutMsg := 'N|[p_get_ContainerNoBase]';

    if strPaperType is null then
      strOutMsg := 'N|[E00012]';
      return;
    end if;
    if strContainer_Material is null then
      if strPaperType = 'P' then
        strNewContainer_Material := '31';
      end if;
      if strPaperType = 'B' then
        strNewContainer_Material := '11';
      end if;
      if strPaperType = 'C' then
        strNewContainer_Material := '21';
      end if;
    else
      strNewContainer_Material := strContainer_Material;
    end if;

    PKLG_WMS_BASE.p_GetBasePara(strEnterpriseNo,
                                strWareHouseNo,
                                'N',
                                'GetContainerNoFixedLocno',
                                'SYS',
                                'SYS',
                                strDefine,
                                v_nDefine,
                                strOutMsg);
    if substr(strOutMsg, 1, 1) = 'N' then
      strOutMsg := 'N|[E30025]';
      return;
    end if;

    if strDefine = '1' then
      --不分仓别时，默认为 001 仓
      v_strWareHouseNo := '001';
    else
      v_strWareHouseNo := strWareHouseNo;
    end if;
    begin
      select wdc.code_length, wdc.container_prefix, wdc.Label_Prefix
        into nSerialLen, strPreFix, strLabel_Prefix
        from WMS_DEFCONTAINER wdc
       where wdc.container_type = strPaperType
         and wdc.use_type = strUse_Type
         and wdc.container_material = strNewContainer_Material
         and warehouse_no = strWareHouseNo
         and enterprise_no = strEnterpriseNo
         and rownum = 1
       order by Use_Type;
    exception
      when no_data_found then
        strOutMsg := 'N|[E00005]';
        return;
    end;

    for i in 1 .. nSerialLen loop
      strSerialNo := strSerialNo || '9';
    end loop;
    nMaxSerial := to_number(strSerialNo);

    begin
      select TO_NUMBER(nvl(serialno, 1))
        into nSerialNo
        from bdef_paperno
       where papertype = strPaperType
         and warehouse_no = v_strWareHouseNo
         and enterprise_no = strEnterpriseNo
         and length = nSerialLen
         for update;
    exception
      when no_data_found then
        nSerialNo := 1;
    end;

    if nSerialNo + nGetNum > nMaxSerial then
      --检查 当前序列号+ 取号数 是否大于  最大序列号
      strOutMsg := 'N|[E00014]';
      return;
    else
      update bdef_paperno a
         set serialno = serialno + nGetNum,
             chgtime  = to_char(sysdate, 'hh24:mi')
       where a.papertype = strPaperType
         and warehouse_no = v_strWareHouseNo
         and enterprise_no = strEnterpriseNo
         and length = nSerialLen;
      if sql%notfound then
        --未修改到，添加一条
        insert into bdef_paperno
          (enterprise_no,
           warehouse_no,
           papertype,
           chgdate,
           serialno,
           chgtime,
           LENGTH)
        values
          (strEnterpriseNo,
           v_strWareHouseNo,
           strPaperType,
           to_char(sysdate, 'yymmdd'),
           to_char(nSerialNo + nGetNum),
           to_char(sysdate, 'hh24:mi'),
           nSerialLen);
        if sql%notfound then
          strOutMsg := 'N|[E00014]';
          return;
        end if;
      end if;
    end if;

    if strGetType = 'T' then
      strLabelNo := strLabel_Prefix || to_char(nSerialNo);
      insert into stock_no_loc
        (enterprise_no,
         container_no,
         container_status,
         container_type,
         rgst_name,
         session_id,
         label_no,
         warehouse_no)
        select strEnterpriseNo,
               strPreFix || strLabel_Prefix ||
               LPAD(nSerialNo + rownum - 1,
                    nSerialLen - length(strLabel_Prefix),
                    0),
               'N',
               strPaperType,
               strUser_ID,
               userenv('sessionid'),
               strLabel_Prefix || LPAD(nSerialNo + rownum - 1,
                                       nSerialLen - length(strLabel_Prefix),
                                       0),
               v_strWareHouseNo
          from all_objects
         where rownum <= nGetNum;
      ----添加行数 小于  nGetNum(取号数) -----
      if sql%rowcount < nGetNum then
        strOutMsg := 'N|[E00013]';
        return;
      end if;
      select userenv('sessionid') into strSESSION_ID from dual;
    else
      strSerialNo := LPAD(nSerialNo,
                          nSerialLen - length(strLabel_Prefix),
                          '0');
      strLabelNo  := strLabel_Prefix || strSerialNo;
    end if;
    strOutLabelNo     := strLabelNo;
    strOutContainerNo := strPreFix || strLabelNo;
    strOutMsg         := 'Y';
    commit;

  end p_get_ContainerNoBase;

  /**********************************************************************************************************
    lich
    2015.05.21
    功能：高阶查询的预处理
  ***********************************************************************************************************/
  procedure p_exce_beforeTreatment(strPgmId  in wms_defsearch_m.pgm_id%type,
                                   nFlag     number,
                                   strOutMsg out varchar2) is
    v_sql varchar2(6000);
  begin
    strOutMsg := 'N|[p_exce_beforeTreatment]';

    if nFlag = 1 then
      select a.before_treatment
        into v_sql
        from wms_defsearch_m a
       where a.pgm_id = strPgmId;
    else
      select a.after_treatment
        into v_sql
        from wms_defsearch_m a
       where a.pgm_id = strPgmId;
    end if;

    for p in (select column_value from table(strsplit(v_sql, ';'))) loop
      if p.column_value is not null then
        execute immediate p.column_value;
      else
        exit;
      end if;
    end loop;
    strOutMsg := 'Y|';
  end p_exce_beforeTreatment;

end PKLG_WMS_BASE;

/

