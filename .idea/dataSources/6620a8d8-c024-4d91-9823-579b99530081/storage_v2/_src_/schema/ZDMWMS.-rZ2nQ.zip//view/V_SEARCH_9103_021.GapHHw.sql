create view V_SEARCH_9103_021 as
select distinct ocld.enterprise_no,
       ocld.warehouse_no,
       ocld.owner_no,
       ocm.cust_no,
       bdc.cust_name,
       ocld.lable_no,
       ocld.d_label_no,
       max(ocld.check_date) check_date,
       ocm.check_chute_no,
       ocld.check_name,
       bdw.worker_name,
       ocld.status
  from (select *
          from odata_check_label_d
        union
        select *
          from odata_check_label_dhty) ocld
 inner join (select *
               from odata_check_m
             union
             select *
               from odata_check_mhty) ocm
    on ocld.enterprise_no = ocm.enterprise_no
   and ocld.warehouse_no = ocm.warehouse_no
   and ocld.owner_no = ocm.owner_no
   and ocld.check_no = ocm.check_no
  inner join bdef_defcust bdc
    on ocm.enterprise_no = bdc.enterprise_no
   and ocm.owner_no = bdc.owner_no
   and ocm.cust_no = bdc.cust_no
 inner join bdef_defworker bdw
    on ocld.enterprise_no = bdw.enterprise_no
   and ocld.check_name = bdw.worker_no
 group by ocld.enterprise_no,
          ocld.warehouse_no,
          ocld.owner_no,
          ocm.cust_no,
          bdc.cust_name,
          ocld.lable_no,
          ocld.container_no,
          ocld.status,
          ocld.check_name,
          bdw.worker_name,
          ocld.d_label_no,
          ocm.check_chute_no
 order by check_date desc,ocld.d_label_no


/

