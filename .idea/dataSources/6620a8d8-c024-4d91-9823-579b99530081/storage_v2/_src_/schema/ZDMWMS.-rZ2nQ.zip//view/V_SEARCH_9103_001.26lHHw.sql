create view V_SEARCH_9103_001 as
select "ENTERPRISE_NO",
       "WAREHOUSE_NO",
       "OWNER_NO",
       "OWNER_NAME",
       "EXP_NO",
       "SOURCEEXP_NO",
       "EXP_TYPE",
       "EXP_DATE",
       "CUST_NO",
       "CUST_NAME",
       "STATUS",
       "STATUS_DESC",
       "ARTICLE_NO",
       "ARTICLE_NAME",
       "ARTICLE_QTY",
       "LOCATE_QTY",
       "WEIGHT",
       --"REAL_QTY",
       check_qty, --复核数量
       "OWNER_ARTICLE_NO",
       "BARCODE",
       "GROUP_NO",
       "GROUP_NAME",
       "ARTICLE_IDENTIFIER",
       shipper_deliver_no,
       owner_alias,
       shipper_no,
       shipper_name,
       rsv_varod4, --海关批次号
       contactor_name,
       cust_address,
       cust_phone,
       receive_province,
       receive_city,
       receive_zone,
       send_name,
       send_address,
       send_mobile_phone,
       send_telephone,
       s_cell_no, --拣货位
       outstock_no,
       rgst_name,
       rgst_date,
       to_char(rgst_date, 'yyyy-mm-dd') create_date,
       outstock_name,
       outstock_date,
       b_check_name,
       b_check_date,
       locate_name,
       locate_date,
       close_name,
       close_date,
       wave_no
--s_cell_no,
--outstock_no,
  from (select oem.enterprise_no,
               oem.warehouse_no,
               oem.owner_no,
               bdo.owner_name,
               oem.exp_no,
               oem.sourceexp_no,
               (case oem.exp_type
                 when 'B2C' then
                  'B2C出库'
                 when 'B2C1' then
                  '预包出库'
                 when ' OJ' then
                  '客户自提出库'
                 when 'OCJ' then
                  '国检送检出库'
                 when 'OBC' then
                  '包材出库'
                 when 'OYP' then
                  '样品担保出库'
                 when 'OHQ' then
                  '账册结转出区'
                 when 'OS' then
                  '紧急单出库'
                 when 'B2C' then
                  '一般贸易出库'
                 else
                  'N'
               end) as exp_type,
               oem.shipper_no,
               bds.shipper_name,
               oem.rsv_varod4,
               oem.contactor_name,
               oem.cust_address,
               oem.cust_phone,
               oem.receive_province,
               oem.receive_city,
               oem.receive_zone,
               oem.send_name,
               oem.send_address,
               oem.send_mobile_phone,
               oem.send_telephone,
               oem.shipper_deliver_no,
               a.s_cell_no,
               a.outstock_no,
               bda.ARTICLE_IDENTIFIER,
               trunc(oem.exp_date) exp_date,
               oem.cust_no,
               bdc.cust_name,
               oem.status,
               wdv.text status_desc,
               oed.article_no,
               bda.article_name,
               oed.article_qty,
               oed.locate_qty,
               (oed.article_qty * bda.UNIT_WEIGHT) as WEIGHT,
               -- oed.real_qty,
               bda.owner_article_no,
               bda.barcode,
               bda.GROUP_NO,
               bda.GROUP_NAME,
               --trunc(oem.rgst_date) rgst_date,
               bdo.owner_alias,
               f_get_workname(os.enterprise_no, os.rgst_name) as rgst_name, --创建人
               os.rgst_date, --创建时间
               f_get_workname(os.enterprise_no, os.locate_name) as locate_name, --定位人
               os.locate_date, --定位时间
               f_get_workname(os.enterprise_no, os.outstock_name) as outstock_name, --拣货人
               os.outstock_date, --拣货时间
               f_get_workname(os.enterprise_no, os.b_check_name) as b_check_name, --复核人
               os.b_check_date, --复核时间
               f_get_workname(os.enterprise_no, os.close_name) as close_name, --封车人
               os.close_date, --封车时间
               --ood.wave_no,--波次号
               --ood.s_cell_no,--来源货位
               --ood.outstock_no,--下架单号
               oem.wave_no,
               ocl.real_qty as check_qty --实际复核数量
          from odata_exp_m oem
          join odata_exp_d oed
            on oem.enterprise_no = oed.enterprise_no
           and oem.warehouse_no = oed.warehouse_no
           and oem.owner_no = oed.owner_no
           and oem.exp_no = oed.exp_no
          left join wms_deffieldval wdv
            on oem.status = wdv.value
           and wdv.table_name = 'ODATA_EXP_M'
           and wdv.colname = 'STATUS'
          join bdef_defowner bdo
            on oem.owner_no = bdo.owner_no
           and oem.enterprise_no = bdo.enterprise_no
          join bdef_defcust bdc
            on oem.owner_no = bdc.owner_no
           and oem.enterprise_no = bdc.enterprise_no
           and oem.cust_no = bdc.cust_no
          join v_bdef_defarticle bda
            on oed.owner_no = bda.owner_no
           and oed.enterprise_no = bda.enterprise_no
           and oed.article_no = bda.article_no
           and oed.owner_no = bda.OWNER_NO
          left join bdef_defshipper bds
            on bds.shipper_no = oem.shipper_no
           and bds.enterprise_no = oem.enterprise_no
           and bds.warehouse_no = oem.warehouse_no
          left join odata_exp_status os
            on os.exp_no = oem.exp_no
           and os.enterprise_no = oem.enterprise_no
           and os.warehouse_no = oem.warehouse_no
           and os.owner_no = oem.owner_no
          left JOIN (select ood.article_no, --查拣货位和下架单号
                           sum（ood.real_qty）real_qty,
                           ood.enterprise_no,
                           ood.warehouse_no,
                           ood.owner_no,
                           ood.deliver_obj,
                           ood.outstock_no,
                           ood.wave_no,
                           ood.s_cell_no,
                           ood.exp_no
                      from Odata_Outstock_dhty ood
                     where ood.exp_type <> 'N'
                     group by ood.article_no,
                              ood.exp_no,
                              ood.enterprise_no,
                              ood.warehouse_no,
                              ood.deliver_obj,
                              ood.outstock_no,
                              ood.wave_no,
                              ood.owner_no,
                              ood.s_cell_no) A
            ON A.enterprise_no = oed.enterprise_no
           and A.warehouse_no = oed.warehouse_no
           and A.owner_no = oed.owner_no
           and a.exp_no = oed.exp_no
           and A.article_no = oed.article_no
           and a.deliver_obj = oem.sourceexp_no
           and a.wave_no = oem.wave_no --
          LEFT JOIN odata_outstock_mhty OOM
            ON a.enterprise_no = OOM.enterprise_no
           and a.warehouse_no = OOM.warehouse_no
           and a.outstock_no = OOM.outstock_no
           and a.owner_no = oom.owner_no
           and a.wave_no = oom.wave_no
        -- left join odata_outstock_dhty ood
        -- on ood.exp_no=oem.exp_no
        --  and ood.enterprise_no = oem.enterprise_no
        --  and ood.warehouse_no = oem.warehouse_no
          left join (select sum(a.real_qty) real_qty,
                           a.enterprise_no,
                           a.warehouse_no,
                           a.exp_no,
                           a.article_no
                      from odata_check_label_dhty a
                     group by a.enterprise_no,
                              a.warehouse_no,
                              a.exp_no,
                              a.article_no) ocl
            on ocl.exp_no = oed.exp_no
           and ocl.article_no = oed.article_no
           and ocl.enterprise_no = oed.enterprise_no
           and ocl.warehouse_no = oed.warehouse_no) c
 order by rgst_date desc


/

