create package body PKLG_PUBLOCATE is

  --获取拣货位
  procedure p_get_PickCell(strEnterPriseNo in bdef_defowner.enterprise_no%type,
                           strWareHouseNo  in bset_worker_loc.warehouse_no%type,
                           strOwnerNo      in bdef_defowner.owner_no%type,
                           strArticleNo    in bdef_defarticle.article_no%type,
                           strCPickCellNo  out cset_cell_article.cell_no%type,
                           nCMaxQty        out cset_cell_article.max_qty_a%type,
                           nCKeepCells     out cset_cell_article.keep_cells%type,
                           strBPickCellNo  out cset_cell_article.cell_no%type,
                           nBMaxQty        out cset_cell_article.max_qty_a%type,
                           nBKeepCells     out cset_cell_article.keep_cells%type,
                           nPickLine       out cset_cell_article.line_id%type,
                           nPickCellCount  out number,
                           strErrorMsg     in out varchar2) is

    v_strPickStrategy bdef_defarticle.rsv_strategy1%type;
     --Modify BY QZH AT 2017-3-13
    v_nBMaxQtyTmp  cset_cell_article.max_qty_a%type;
    v_nCMaxQtyTmp  cset_cell_article.max_qty_a%type;
    
  begin
    strErrorMsg    := 'Y|';
    strCPickCellNo := 'N';
    strBPickCellNo := 'N';
    nPickCellCount := 0;
    nPickLine      := -1;

    --读取商品出货策略取规则
    select nvl(rsv_strategy1, '1')
      into v_strPickStrategy
      from bdef_defarticle a
     where article_no = strArticleNo
       AND a.enterprise_no = strEnterpriseNo;

    for GetRule in (select wdd.Rule_id
                      from WMS_DEFSTRATEGY_D wdd,
                           WMS_DEFSTRATEGY   wd,
                           wms_defrule       rl
                     where wdd.strategy_type = wd.strategy_type
                       and wdd.strategy_id = wd.strategy_id
                       and wd.strategy_id = v_strPickStrategy
                       and wd.strategy_type = 'PICKCELL'
                       and wdd.strategy_type = rl.strategy_type
                       and wdd.rule_id = rl.rule_id
                     order by wdd.rule_order) loop

      --从商品对照关系中获取
      if GetRule.Rule_Id = '1' then
        --获取拆零拣货位
        begin
          select cca.cell_no,
                 cca.line_id,
                 decode(cda.a_flag, '1', cca.MAX_QTY_A, cca.max_qty_na),
                 decode(cda.a_flag, '1', cca.keep_cells_a, cca.keep_cells)
            into strBPickCellNo, nPickLine, nBMaxQty, nBKeepCells
            from cset_cell_article cca, cdef_defarea cda
           where cda.enterprise_no = cca.enterprise_no
             and cda.warehouse_no = cca.warehouse_no
             and cda.ware_no = cca.ware_no
             and cda.area_no = cca.area_no
             and cca.enterprise_no = strEnterPriseNo
             and cca.warehouse_no = strWareHouseNo
             and cca.owner_no = strOwnerNo
             and cca.article_no = strArticleNo
             and cca.pick_type = 'B';

          nPickCellCount := nPickCellCount + 1;
        exception
          when no_data_found then
            strBPickCellNo := 'N';
        end;

        --获取整箱拣货位
        begin
          select cca.cell_no,
                 cca.line_id,
                 decode(cda.a_flag, '1', cca.MAX_QTY_A, cca.max_qty_na),
                 decode(cda.a_flag, '1', cca.keep_cells_a, cca.keep_cells)
            into strCPickCellNo, nPickLine, nCMaxQty, nCKeepCells
            from cset_cell_article cca, cdef_defarea cda
           where cda.enterprise_no = cca.enterprise_no
             and cda.warehouse_no = cca.warehouse_no
             and cda.ware_no = cca.ware_no
             and cda.area_no = cca.area_no
             and cca.enterprise_no = strEnterPriseNo
             and cca.warehouse_no = strWareHouseNo
             and cca.owner_no = strOwnerNo
             and cca.article_no = strArticleNo
             and cca.pick_type = 'C';

          nPickCellCount := nPickCellCount + 1;
        exception
          when no_data_found then
            strCPickCellNo := 'N';
        end;

        if nPickCellCount > 0 then
          return;
        end if;
      end if;

      --根据商品在拣货区所在的库存找拣货位
      if GetRule.Rule_Id in ('2', '3') then
        begin
          --获取拆零拣货位
          select a.cell_no, a.line_id
            into strBPickCellNo, nPickLine
            from (select sc.enterprise_no,
                         sc.warehouse_no,
                         bd.line_id,
                         min(sc.cell_no) cell_no
                    from stock_content      sc,
                         cdef_defcell       cdc,
                         cdef_defarea       cdf,
                         cset_area_backup_d bd
                   where cdf.enterprise_no = cdc.enterprise_no
                     and cdf.warehouse_no = cdc.warehouse_no
                     and cdf.ware_no = cdc.ware_no
                     and cdf.area_no = cdc.area_no
                     and cdf.area_pick = '1'
                     and cdf.o_type = 'B'
                     and cdf.area_attribute = '0'
                     and cdf.attribute_type = '0'
                     and cdf.item_type = '0'
                     and cdf.area_usetype = '1'
                     and cdc.enterprise_no = sc.enterprise_no
                     and cdc.warehouse_no = sc.warehouse_no
                     and cdc.cell_status = '0'
                     and cdc.cell_no = sc.cell_no
                     and sc.enterprise_no = strEnterPriseNo
                     and sc.warehouse_no = strWareHouseNo
                     and sc.owner_no = strOwnerNo
                     and sc.article_no = strArticleNo
                     and cdf.enterprise_no = bd.enterprise_no
                     and cdf.warehouse_no = bd.warehouse_no
                     and cdf.ware_no = bd.ware_no
                     and cdf.area_no = bd.area_no
                   group by sc.enterprise_no,
                            sc.warehouse_no,
                            bd.line_id,
                            bd.a_level
                   order by (case
                              when GetRule.Rule_Id = '2' then
                               bd.a_level
                              else
                               -bd.a_level
                            end)) a
           where rownum = 1;

          nPickCellCount := nPickCellCount + 1;
        exception
          when no_data_found then
            strBPickCellNo := 'N';
        end;

        --获取整箱拣货位
        begin
          select a.cell_no, a.line_id
            into strCPickCellNo, nPickLine
            from (select sc.enterprise_no,
                         sc.warehouse_no,
                         bd.line_id,
                         min(sc.cell_no) cell_no
                    from stock_content      sc,
                         cdef_defcell       cdc,
                         cdef_defarea       cdf,
                         cset_area_backup_d bd
                   where cdf.enterprise_no = cdc.enterprise_no
                     and cdf.warehouse_no = cdc.warehouse_no
                     and cdf.ware_no = cdc.ware_no
                     and cdf.area_no = cdc.area_no
                     and cdf.area_pick = '1'
                     and cdf.o_type = 'C'
                     and cdf.area_attribute = '0'
                     and cdf.attribute_type = '0'
                     and cdf.item_type = '0'
                     and cdf.area_usetype = '1'
                     and cdc.enterprise_no = sc.enterprise_no
                     and cdc.warehouse_no = sc.warehouse_no
                     and cdc.cell_status = '0'
                     and cdc.cell_no = sc.cell_no
                     and sc.enterprise_no = strEnterPriseNo
                     and sc.warehouse_no = strWareHouseNo
                     and sc.owner_no = strOwnerNo
                     and sc.article_no = strArticleNo
                     and cdf.enterprise_no = bd.enterprise_no
                     and cdf.warehouse_no = bd.warehouse_no
                     and cdf.ware_no = bd.ware_no
                     and cdf.area_no = bd.area_no
                   group by sc.enterprise_no,
                            sc.warehouse_no,
                            bd.line_id,
                            bd.a_level
                   order by (case
                              when GetRule.Rule_Id = '2' then
                               bd.a_level
                              else
                               -bd.a_level
                            end)) a
           where rownum = 1;

          nPickCellCount := nPickCellCount + 1;
        exception
          when no_data_found then
            strCPickCellNo := 'N';
        end;
      end if;

      --根据商品在拣货区曾占用的储位找拣货位
      if GetRule.Rule_Id in ('4', '5') then
        --获取拆零拣货位
        begin
          select a.cell_no, a.line_id
            into strBPickCellNo, nPickLine
            from (select sc.enterprise_no,
                         sc.warehouse_no,
                         bd.line_id,
                         min(sc.cell_no) cell_no
                    from stock_art_cell     sc,
                         cdef_defcell       cdc,
                         cdef_defarea       cdf,
                         cset_area_backup_d bd
                   where cdf.enterprise_no = cdc.enterprise_no
                     and cdf.warehouse_no = cdc.warehouse_no
                     and cdf.ware_no = cdc.ware_no
                     and cdf.area_no = cdc.area_no
                     and cdf.area_pick = '1'
                     and cdf.o_type = 'B'
                     and cdf.area_attribute = '0'
                     and cdf.attribute_type = '0'
                     and cdf.item_type = '0'
                     and cdf.area_usetype = '1'
                     and cdc.enterprise_no = sc.enterprise_no
                     and cdc.warehouse_no = sc.warehouse_no
                     and cdc.cell_status = '0'
                     and cdc.cell_no = sc.cell_no
                     and sc.enterprise_no = strEnterPriseNo
                     and sc.warehouse_no = strWareHouseNo
                     and sc.article_no = strArticleNo
                     and cdf.enterprise_no = bd.enterprise_no
                     and cdf.warehouse_no = bd.warehouse_no
                     and cdf.ware_no = bd.ware_no
                     and cdf.area_no = bd.area_no
                     and not exists
                   (select 'x'
                            from stock_content ct
                           where cdc.enterprise_no = ct.enterprise_no
                             and cdc.warehouse_no = ct.warehouse_no
                             and cdc.cell_no = ct.cell_no
                             and ct.article_no <> strArticleNo)
                   group by sc.enterprise_no,
                            sc.warehouse_no,
                            bd.line_id,
                            bd.a_level
                   order by (case
                              when GetRule.Rule_Id = '4' then
                               bd.a_level
                              else
                               -bd.a_level
                            end)) a
           where rownum = 1;

          nPickCellCount := nPickCellCount + 1;
        exception
          when no_data_found then
            strBPickCellNo := 'N';
        end;

        --获取整箱拣货位
        begin
          select a.cell_no, a.line_id
            into strCPickCellNo, nPickLine
            from (select sc.enterprise_no,
                         sc.warehouse_no,
                         bd.line_id,
                         min(sc.cell_no) cell_no
                    from stock_art_cell     sc,
                         cdef_defcell       cdc,
                         cdef_defarea       cdf,
                         cset_area_backup_d bd
                   where cdf.enterprise_no = cdc.enterprise_no
                     and cdf.warehouse_no = cdc.warehouse_no
                     and cdf.ware_no = cdc.ware_no
                     and cdf.area_no = cdc.area_no
                     and cdf.area_pick = '1'
                     and cdf.o_type = 'C'
                     and cdf.area_attribute = '0'
                     and cdf.attribute_type = '0'
                     and cdf.item_type = '0'
                     and cdf.area_usetype = '1'
                     and cdc.enterprise_no = sc.enterprise_no
                     and cdc.warehouse_no = sc.warehouse_no
                     and cdc.cell_status = '0'
                     and cdc.cell_no = sc.cell_no
                     and sc.enterprise_no = strEnterPriseNo
                     and sc.warehouse_no = strWareHouseNo
                     and sc.article_no = strArticleNo
                     and cdf.enterprise_no = bd.enterprise_no
                     and cdf.warehouse_no = bd.warehouse_no
                     and cdf.ware_no = bd.ware_no
                     and cdf.area_no = bd.area_no
                     and not exists
                   (select 'x'
                            from stock_content ct
                           where cdc.enterprise_no = ct.enterprise_no
                             and cdc.warehouse_no = ct.warehouse_no
                             and cdc.cell_no = ct.cell_no
                             and ct.article_no <> strArticleNo)
                   group by sc.enterprise_no,
                            sc.warehouse_no,
                            bd.line_id,
                            bd.a_level
                   order by (case
                              when GetRule.Rule_Id = '4' then
                               bd.a_level
                              else
                               -bd.a_level
                            end)) a
           where rownum = 1;

          nPickCellCount := nPickCellCount + 1;
        exception
          when no_data_found then
            strCPickCellNo := 'N';
            --  return;
        end;
      end if;

      --从商品群组对照关系中获取
      if GetRule.Rule_Id in ('6', '7') then
        --获取拆零拣货位
        begin
          select cca.cell_no,
                 cca.line_id,
                 decode(cda.a_flag, '1', cca.MAX_QTY_A, cca.max_qty_na),
                 decode(cda.a_flag, '1', cca.keep_cells_a, cca.keep_cells)
            into strBPickCellNo, nPickLine, nBMaxQty, nBKeepCells
            from cset_cell_article_family cca, cdef_defarea cda
           where cda.enterprise_no = cca.enterprise_no
             and cda.warehouse_no = cca.warehouse_no
             and cda.ware_no = cca.ware_no
             and cda.area_no = cca.area_no
             and cda.o_type = 'B'
             and cca.enterprise_no = strEnterPriseNo
             and cca.warehouse_no = strWareHouseNo
             and cca.owner_no = strOwnerNo
             and exists (select 'x'
                    from bdef_article_family_d baf
                   where baf.enterprise_no = cca.enterprise_no
                     and baf.family_no = cca.family_no
                     and baf.owner_no = cca.owner_no
                     and baf.article_no = strArticleNo)
             and rownum = 1;

          nPickCellCount := nPickCellCount + 1;
        exception
          when no_data_found then
            strBPickCellNo := 'N';
        end;

        --获取整箱拣货位
        begin
          select cca.cell_no,
                 cca.line_id,
                 decode(cda.a_flag, '1', cca.MAX_QTY_A, cca.max_qty_na),
                 decode(cda.a_flag, '1', cca.keep_cells_a, cca.keep_cells)
            into strCPickCellNo, nPickLine, nCMaxQty, nCKeepCells
            from cset_cell_article_family cca, cdef_defarea cda
           where cda.enterprise_no = cca.enterprise_no
             and cda.warehouse_no = cca.warehouse_no
             and cda.ware_no = cca.ware_no
             and cda.area_no = cca.area_no
             and cda.o_type = 'C'
             and cca.enterprise_no = strEnterPriseNo
             and cca.warehouse_no = strWareHouseNo
             and cca.owner_no = strOwnerNo
             and exists (select 'x'
                    from bdef_article_family_d baf
                   where baf.enterprise_no = cca.enterprise_no
                     and baf.family_no = cca.family_no
                     and baf.owner_no = cca.owner_no
                     and baf.article_no = strArticleNo)
             and rownum = 1;

          nPickCellCount := nPickCellCount + 1;
        exception
          when no_data_found then
            strCPickCellNo := 'N';
        end;

        if nPickCellCount > 0 then
          return;
        end if;
      end if;

      --找同类别的在拣货区所在的库存找拣货位
      if GetRule.Rule_Id in ('8', '9') then

        begin
          --获取拆零拣货位
          select a.cell_no, a.line_id
            into strBPickCellNo, nPickLine
            from (select sc.enterprise_no,
                         sc.warehouse_no,
                         bd.line_id,
                         min(sc.cell_no) cell_no
                    from stock_content      sc,
                         cdef_defcell       cdc,
                         cdef_defarea       cdf,
                         cset_area_backup_d bd,
                         bdef_defarticle    at,
                         bdef_defarticle    at1
                   where cdf.enterprise_no = cdc.enterprise_no
                     and cdf.warehouse_no = cdc.warehouse_no
                     and cdf.ware_no = cdc.ware_no
                     and cdf.area_no = cdc.area_no
                     and cdf.area_pick = '1'
                     and cdf.o_type = 'B'
                     and cdf.area_attribute = '0'
                     and cdf.attribute_type = '0'
                     and cdf.item_type = '0'
                     and cdf.area_usetype = '1'
                     and cdc.enterprise_no = sc.enterprise_no
                     and cdc.warehouse_no = sc.warehouse_no
                     and cdc.cell_status = '0'
                     and cdc.cell_no = sc.cell_no
                     and sc.enterprise_no = strEnterPriseNo
                     and sc.warehouse_no = strWareHouseNo
                     and sc.owner_no = strOwnerNo
                     and sc.article_no = at1.article_no
                     and at.enterprise_no = sc.enterprise_no
                     and at.article_no = strArticleNo
                     and at1.enterprise_no = at.enterprise_no
                     and at1.owner_no = at.owner_no
                     and at1.group_no = at.group_no
                     and cdf.enterprise_no = bd.enterprise_no
                     and cdf.warehouse_no = bd.warehouse_no
                     and cdf.ware_no = bd.ware_no
                     and cdf.area_no = bd.area_no
                   group by sc.enterprise_no,
                            sc.warehouse_no,
                            bd.line_id,
                            bd.a_level
                   order by (case
                              when GetRule.Rule_Id = '8' then
                               bd.a_level
                              else
                               -bd.a_level
                            end)) a

           where rownum = 1;

          nPickCellCount := nPickCellCount + 1;
        exception
          when no_data_found then
            strBPickCellNo := 'N';
        end;

        --获取整箱拣货位
        begin
          select a.cell_no, a.line_id
            into strCPickCellNo, nPickLine
            from (select sc.enterprise_no,
                         sc.warehouse_no,
                         bd.line_id,
                         min(sc.cell_no) cell_no
                    from stock_content      sc,
                         cdef_defcell       cdc,
                         cdef_defarea       cdf,
                         cset_area_backup_d bd,
                         bdef_defarticle    at,
                         bdef_defarticle    at1
                   where cdf.enterprise_no = cdc.enterprise_no
                     and cdf.warehouse_no = cdc.warehouse_no
                     and cdf.ware_no = cdc.ware_no
                     and cdf.area_no = cdc.area_no
                     and cdf.area_pick = '1'
                     and cdf.o_type = 'C'
                     and cdf.area_attribute = '0'
                     and cdf.attribute_type = '0'
                     and cdf.item_type = '0'
                     and cdf.area_usetype = '1'
                     and cdc.enterprise_no = sc.enterprise_no
                     and cdc.warehouse_no = sc.warehouse_no
                     and cdc.cell_status = '0'
                     and cdc.cell_no = sc.cell_no
                     and sc.enterprise_no = strEnterPriseNo
                     and sc.warehouse_no = strWareHouseNo
                     and sc.owner_no = strOwnerNo
                     and sc.article_no = at1.article_no
                     and at.enterprise_no = sc.enterprise_no
                     and at.article_no = strArticleNo
                     and at1.enterprise_no = at.enterprise_no
                     and at1.owner_no = at.owner_no
                     and at1.group_no = at.group_no
                     and cdf.enterprise_no = bd.enterprise_no
                     and cdf.warehouse_no = bd.warehouse_no
                     and cdf.ware_no = bd.ware_no
                     and cdf.area_no = bd.area_no
                   group by sc.enterprise_no,
                            sc.warehouse_no,
                            bd.line_id,
                            bd.a_level
                   order by (case
                              when GetRule.Rule_Id = '8' then
                               bd.a_level
                              else
                               -bd.a_level
                            end)) a

           where rownum = 1;

          nPickCellCount := nPickCellCount + 1;
        exception
          when no_data_found then
            strCPickCellNo := 'N';
        end;
      end if;
      
      --找空货位
       if GetRule.Rule_Id in ('10') THEN
         IF strCPickCellNo = 'N' THEN
            begin
          --获取整箱拣货位
          SELECT A.CELL_NO, A.LINE_ID
          INTO strCPickCellNo, NPICKLINE
          FROM (SELECT CDC.ENTERPRISE_NO,
                       CDC.WAREHOUSE_NO,
                       BD.LINE_ID,
                       MIN(CDC.CELL_NO) CELL_NO
                  FROM CDEF_DEFCELL CDC, CDEF_DEFAREA CDF, CSET_AREA_BACKUP_D BD
                 WHERE CDF.ENTERPRISE_NO = CDC.ENTERPRISE_NO
                   AND CDF.WAREHOUSE_NO = CDC.WAREHOUSE_NO
                   AND CDF.WARE_NO = CDC.WARE_NO
                   AND CDF.AREA_NO = CDC.AREA_NO
                   AND CDF.AREA_PICK = '1'
                   AND CDF.O_TYPE = 'C'
                   AND CDF.AREA_ATTRIBUTE = '0'
                   AND CDF.ATTRIBUTE_TYPE = '0'
                   AND CDF.ITEM_TYPE = '0'
                   AND CDF.AREA_USETYPE = '1'
                   AND CDC.CELL_STATUS = '0'
                   AND CDC.CHECK_STATUS = '0'
                   AND CDC.ENTERPRISE_NO = strEnterPriseNo
                   AND CDC.WAREHOUSE_NO = strWareHouseNo
                   AND CDF.ENTERPRISE_NO = BD.ENTERPRISE_NO
                   AND CDF.WAREHOUSE_NO = BD.WAREHOUSE_NO
                   AND CDF.WARE_NO = BD.WARE_NO
                   AND CDF.AREA_NO = BD.AREA_NO
                   --该通道存在当前货主的货
                   AND EXISTS(SELECT 'x' FROM stock_content cc,cdef_defcell ce
                   WHERE  cc.enterprise_no = ce.enterprise_no
                   AND cc.warehouse_no = ce.warehouse_no
                   AND cc.cell_no = ce.cell_no
                   and cc.enterprise_no = strEnterPriseNo
                   and cc.warehouse_no = strWareHouseNo
                   and cc.owner_no = strOwnerNo
                   AND cdc.enterprise_no = ce.enterprise_no
                   AND cdc.warehouse_no = ce.warehouse_no
                   AND cdc.ware_no = ce.ware_no
                   AND cdc.area_no = ce.area_no
                   AND cdc.stock_no = ce.stock_no)
                   AND NOT EXISTS (SELECT 'x'
                          FROM STOCK_CONTENT CC
                         WHERE CDC.ENTERPRISE_NO = CC.ENTERPRISE_NO
                           AND CDC.WAREHOUSE_NO = CC.WAREHOUSE_NO
                           AND CDC.CELL_NO = CC.CELL_NO)
                 GROUP BY CDC.ENTERPRISE_NO,
                          CDC.WAREHOUSE_NO,
                          BD.LINE_ID,
                          BD.A_LEVEL) A
         WHERE ROWNUM = 1;

          nPickCellCount := nPickCellCount + 1;
        exception
          when no_data_found then
            strCPickCellNo := 'N';
        end;
         END IF;
         
         IF strBPickCellNo = 'N' THEN
        begin
          --获取拆零拣货位
          SELECT A.CELL_NO, A.LINE_ID
          INTO STRBPICKCELLNO, NPICKLINE
          FROM (SELECT CDC.ENTERPRISE_NO,
                       CDC.WAREHOUSE_NO,
                       BD.LINE_ID,
                       MIN(CDC.CELL_NO) CELL_NO
                  FROM CDEF_DEFCELL CDC, CDEF_DEFAREA CDF, CSET_AREA_BACKUP_D BD
                 WHERE CDF.ENTERPRISE_NO = CDC.ENTERPRISE_NO
                   AND CDF.WAREHOUSE_NO = CDC.WAREHOUSE_NO
                   AND CDF.WARE_NO = CDC.WARE_NO
                   AND CDF.AREA_NO = CDC.AREA_NO
                   AND CDF.AREA_PICK = '1'
                   AND CDF.O_TYPE = 'B'
                   AND CDF.AREA_ATTRIBUTE = '0'
                   AND CDF.ATTRIBUTE_TYPE = '0'
                   AND CDF.ITEM_TYPE = '0'
                   AND CDF.AREA_USETYPE = '1'
                   AND CDC.CELL_STATUS = '0'
                   AND CDC.CHECK_STATUS = '0'
                   AND CDC.ENTERPRISE_NO = strEnterPriseNo
                   AND CDC.WAREHOUSE_NO = strWareHouseNo
                   AND CDF.ENTERPRISE_NO = BD.ENTERPRISE_NO
                   AND CDF.WAREHOUSE_NO = BD.WAREHOUSE_NO
                   AND CDF.WARE_NO = BD.WARE_NO
                   AND CDF.AREA_NO = BD.AREA_NO
                   --该通道存在当前货主的货
                   AND EXISTS(SELECT 'x' FROM stock_content cc,cdef_defcell ce
                   WHERE  cc.enterprise_no = ce.enterprise_no
                   AND cc.warehouse_no = ce.warehouse_no
                   AND cc.cell_no = ce.cell_no
                   and cc.enterprise_no = strEnterPriseNo
                   and cc.warehouse_no = strWareHouseNo
                   and cc.owner_no = strOwnerNo
                   AND cdc.enterprise_no = ce.enterprise_no
                   AND cdc.warehouse_no = ce.warehouse_no
                   AND cdc.ware_no = ce.ware_no
                   AND cdc.area_no = ce.area_no
                   AND cdc.stock_no = ce.stock_no)
                   AND NOT EXISTS (SELECT 'x'
                          FROM STOCK_CONTENT CC
                         WHERE CDC.ENTERPRISE_NO = CC.ENTERPRISE_NO
                           AND CDC.WAREHOUSE_NO = CC.WAREHOUSE_NO
                           AND CDC.CELL_NO = CC.CELL_NO)
                 GROUP BY CDC.ENTERPRISE_NO,
                          CDC.WAREHOUSE_NO,
                          BD.LINE_ID,
                          BD.A_LEVEL) A
         WHERE ROWNUM = 1;

          nPickCellCount := nPickCellCount + 1;
        exception
          when no_data_found then
            strBPickCellNo := 'N';
        end;
        END IF;
       END IF;
       
      if nPickCellCount > 1 then
          nCKeepCells := 1;
        nBKeepCells := 1;
        begin
          select (CASE WHEN art.max_qty_c <> 0 THEN art.max_qty_c ELSE nvl(bap.qpalette, 1) END),
                 (CASE WHEN art.max_qty_b <> 0 THEN art.max_qty_b ELSE nvl(bap.packing_qty * bap.pal_base_qbox, 1) END)
            into nCMaxQty, nBMaxQty
            from bdef_article_packing bap,bdef_defarticle art
           where bap.enterprise_no = strEnterPriseNo
             and bap.article_no = strArticleNo
             and bap.packing_qty =
                 (select max(packing_qty)
                    from bdef_article_packing b
                   where b.enterprise_no = strEnterPriseNo
                     and b.article_no = strArticleNo)
              AND art.enterprise_no = bap.enterprise_no
              AND art.article_no = bap.article_no;
        exception
          when no_data_found THEN
            SELECT (CASE WHEN art.max_qty_c <> 0 THEN art.max_qty_c ELSE 1 END),
             (CASE WHEN art.max_qty_b <> 0 THEN art.max_qty_b ELSE 1 END)
               into nCMaxQty, nBMaxQty
             FROM bdef_defarticle art
              where art.enterprise_no = strEnterPriseNo
             and art.article_no = strArticleNo;
        END;
          return;
        end if;
    end loop;
    
    if nPickCellCount > 0 then
        nCKeepCells := 1;
        nBKeepCells := 1;
        begin
          select (CASE WHEN art.max_qty_c <> 0 THEN art.max_qty_c ELSE nvl(bap.qpalette, 1) END),
                 (CASE WHEN art.max_qty_b <> 0 THEN art.max_qty_b ELSE nvl(bap.packing_qty * bap.pal_base_qbox, 1) END)
            into v_nCMaxQtyTmp, v_nBMaxQtyTmp
            from bdef_article_packing bap,bdef_defarticle art
           where bap.enterprise_no = strEnterPriseNo
             and bap.article_no = strArticleNo
             and bap.packing_qty =
                 (select max(packing_qty)
                    from bdef_article_packing b
                   where b.enterprise_no = strEnterPriseNo
                     and b.article_no = strArticleNo)
              AND art.enterprise_no = bap.enterprise_no
              AND art.article_no = bap.article_no;
        exception
          when no_data_found THEN
            SELECT (CASE WHEN art.max_qty_c <> 0 THEN art.max_qty_c ELSE 1 END),
             (CASE WHEN art.max_qty_b <> 0 THEN art.max_qty_b ELSE 1 END)
               into v_nCMaxQtyTmp, v_nBMaxQtyTmp
             FROM bdef_defarticle art
              where art.enterprise_no = strEnterPriseNo
             and art.article_no = strArticleNo;
        END;

          --Modify BY QZH AT 2017-3-13
        if nCMaxQty =0 OR nCMaxQty IS NULL then
           nCMaxQty:=v_nCMaxQtyTmp;
        end if;
        if  nBMaxQty=0 OR nBMaxQty IS NULL  then
           nBMaxQty:=v_nBMaxQtyTmp;
        end if;
        --Modify End QZH AT 2017-3-13
      end if;
      
  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_get_PickCell;

  --出货定位配量入口
  procedure p_locate_allot_OM(v_nTmpStockID   in number,
                              strEnterPriseNo in varchar2,
                              strWareHouseNo  in varchar2, --仓库代码
                              strWaveNo       in varchar2, --定位号
                              nGroupNo        in number, --出货组号
                              strArticleNo    in varchar2, --商品代码
                              strStockType    in varchar2, --库存性质
                              strStockValue   in varchar2, --库存值
                              nLocateQty      in number, --需定位量
                              v_nAllotID      out number, --配量表临时序列号
                              strErrorMsg     out varchar2) is

    v_nMaxPackQty     stock_content.packing_qty%type; --最大包装
    v_nCanUseStockQty number; --全库可用库存
  begin

    strErrorMsg := 'N|';

    --按客户读取数据,先入配量表,调用配量过程
    select seq_middata_allot_detail.nextval into v_nAllotID from dual;

    insert into middata_allot_detail
      (tmp_id,
       enterprise_no,
       warehouse_no,
       source_no,
       outstock_type,
       article_no,
       cust_no,
       po_no,
       plan_qty,
       allot_qty,
       batch_no)
      select v_nAllotID,
             od.enterprise_no,
             od.warehouse_no,
             od.wave_no,
             'OE',
             od.article_no,
             od.cust_no,
             'N',
             sum(od.plan_qty - od.located_qty),
             0,
             od.batch_no
        from odata_locate_d od
       where od.warehouse_no = strWareHouseNo
         and od.enterprise_no = strEnterPriseNo
         and od.wave_no = strWaveNo
         and od.trans_group_no = nGroupNo
         and od.article_no = strArticleNo
            --and (strCondition is null or
            --    od.condition = strCondition)
            --and od.item_type = strItemType
         and od.stock_type = strStockType
         and (strStockType = '1' or
             (strStockType = '2' and od.cust_no = strStockValue) or
             (strStockType = '3' and od.exp_no = strStockValue))
            --and od.quality = strQuality
         and od.plan_qty - od.located_qty > 0
       group by od.enterprise_no,
                od.warehouse_no,
                od.wave_no,
                od.article_no,
                od.cust_no,
                od.batch_no;

    if sql%rowcount <= 0 then
      strErrorMsg := 'N|商品[' || strArticleNo || ']没有可需要定位的数量';
      return;
    end if;

    --获取可用总库存
    v_nMaxPackQty     := 0;
    v_nCanUseStockQty := 0;
    select max(nvl(nvl(baw.packing_qty, BAP.packing_qty), 1)),
           sum(C.QTY - C.OUTSTOCK_QTY + (case C.Instock_Type
                 when '1' then
                  C.INSTOCK_QTY
                 else
                  0
               end) + C.UNUSUAL_QTY)
      into v_nMaxPackQty, v_nCanUseStockQty
      FROM BDEF_DEFARTICLE B, STOCK_article_info a, STOCK_CONTENT C
      left join BDEF_ARTICLE_PACKING BAP
        on c.enterprise_no = BAP.enterprise_no
       and c.article_no = BAP.article_no
       and c.packing_qty = BAP.packing_qty
      left join bdef_warehouse_packing baw
        on c.enterprise_no = baw.enterprise_no
       and c.article_no = baw.article_no
       and c.packing_qty = baw.packing_qty
       and c.WAREHOUSE_NO = baw.WAREHOUSE_NO, cdef_defware cdw,
     CDEF_DEFAREA CDA, CDEF_DEFCELL CDC, odata_locate_m olm,
     TMP_STOCK_CONTENT tmpsc
     WHERE b.enterprise_no = c.enterprise_no
       and B.ARTICLE_NO = C.ARTICLE_NO
       and a.enterprise_no = c.enterprise_no
       and a.article_no = c.article_no
       and a.article_id = c.article_id

       AND c.ARTICLE_NO = strArticleNo
       AND c.stock_type = strStockType
       AND c.stock_value = strStockValue

       AND C.STATUS = 0
          --条件
       AND C.FLAG <> '2'
       AND (C.INSTOCK_QTY + C.QTY - C.OUTSTOCK_QTY + C.UNUSUAL_QTY) > 0
       AND c.enterprise_no = tmpsc.enterprise_no
       AND c.warehouse_no = tmpsc.warehouse_no
       AND c.cell_no = tmpsc.cell_no
       And c.cell_id = tmpsc.cell_id

       and tmpsc.warehouse_no = strWareHouseNo
       and tmpsc.enterprise_no = strEnterPriseNo
       and tmpsc.tmp_id = v_nTmpStockID
       and olm.enterprise_no = strEnterPriseNo
       and olm.warehouse_no = strWareHouseNo
       and olm.wave_no = strWaveNo

       and cdw.enterprise_no = cda.enterprise_no
       and cdw.warehouse_no = cda.warehouse_no
       and cdw.ware_no = cda.ware_no
       and cdw.org_no = olm.org_no
       and cda.enterprise_no = cdc.enterprise_no
       and CDA.WAREHOUSE_NO = CDC.WAREHOUSE_NO
       AND CDA.WARE_NO = CDC.WARE_NO
       AND CDA.AREA_NO = CDC.AREA_NO
       AND CDA.AREA_ATTRIBUTE = '0'
       and cda.area_usetype in ('1', '5', '6')
       and cdc.enterprise_no = c.enterprise_no
       AND CDC.WAREHOUSE_NO = c.WAREHOUSE_NO
       AND CDC.CELL_NO = c.CELL_NO
       and cdc.cell_status = '0'
       AND CDC.CHECK_STATUS = '0';

    if v_nCanUseStockQty = 0 then
      strErrorMsg := 'N|[没有可定位库存]';
      return;
    end if;

    --开始配量
    Pklg_Publocate.p_locate_allot(v_nAllotID,
                                  strEnterPriseNo,
                                  strWareHouseNo,
                                  strWaveNo,
                                  'OE',
                                  'C',
                                  case when nLocateQty >= v_nCanUseStockQty then
                                  v_nCanUseStockQty else nLocateQty end,
                                  v_nMaxPackQty,
                                  strErrorMsg);
    if substr(strErrorMsg, 1, 2) = 'N|' then
      return;
    end if;
    strErrorMsg := 'Y|';
  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_locate_allot_OM;

  --系统配量入口
  procedure p_locate_allot(v_nAllotID      in number, --配量表临时序列号
                           strEnterPriseNo in varchar2,
                           strWareHouseNo  in varchar2, --仓库代码
                           strSourceNo     in varchar2,
                           strOutstockType varchar2, --出货方式（ID:直通；IS存储）
                           strOperateType  in varchar2,
                           nTotalQty       in number, --需要分配的总数量
                           nUnitQty        in number, --单位分配量
                           strErrorMsg     out varchar2) is

    v_strSQL         varchar2(5000); --动态SQL语句脚本
    v_cs_get_unallot cv_type;
    v_nTotalQty      MIDDATA_ALLOT_DETAIL.PLAN_QTY%type;
    v_nAllotQty      MIDDATA_ALLOT_DETAIL.PLAN_QTY%type;

    v_nExcessRate bdef_defarticle.check_excess%type;

    v_nCustLevel       varchar2(20);
    v_strCustPrioType  bdef_defcust.prio_type%type;
    v_strCustNo        bdef_defcust.cust_no%type;
    v_strPoNo          MIDDATA_ALLOT_DETAIL.Po_No%type;
    v_nPlanQty         MIDDATA_ALLOT_DETAIL.Plan_Qty%type;
    v_nUnAllotQty      MIDDATA_ALLOT_DETAIL.Plan_Qty%type;
    v_nUnAllotTotalQty MIDDATA_ALLOT_DETAIL.Plan_Qty%type;
    v_nPlanTotalQty    MIDDATA_ALLOT_DETAIL.Plan_Qty%type;

    v_blFirstOrder      boolean;
    v_blCircleHandlFlag boolean;

    v_blChgUnitFlag boolean;
    v_blAllotedFlag boolean;

    v_blAllotExcessFlag boolean;
    v_blExcessFlag      boolean;
  begin
    strErrorMsg := 'Y|';

    v_nTotalQty         := nTotalQty;
    v_blAllotExcessFlag := false;
    v_blExcessFlag      := false;

    --
    begin
      select decode(mad.outstock_type,
                    'IS',
                    bda.pick_excess,
                    'ID',
                    bda.check_excess,
                    'RI',
                    bda.um_check_excess) as excess_rate,
             sum(mad.plan_qty - mad.allot_qty)
        into v_nExcessRate, v_nUnAllotTotalQty
        from MIDDATA_ALLOT_DETAIL mad, bdef_defarticle bda
       where bda.article_no = mad.article_no
         and mad.enterprise_no = bda.enterprise_no
         and mad.enterprise_no = strEnterPriseNo
         and mad.warehouse_no = strWareHouseNo
         and mad.source_no = strSourceNo
         and mad.outstock_type = strOutstockType
         and mad.tmp_id = v_nAllotID
       group by mad.outstock_type,
                bda.pick_excess,
                bda.check_excess,
                bda.um_check_excess;
      if v_nUnAllotTotalQty < nTotalQty and v_nExcessRate <= 0 then
        strErrorMsg := 'N|[E00022]';
        return;
      end if;

      if v_nUnAllotTotalQty <= nTotalQty then

        update MIDDATA_ALLOT_DETAIL mad
           set mad.allot_qty = mad.plan_qty
         where mad.warehouse_no = strWareHouseNo
           and mad.enterprise_no = strEnterPriseNo
           and mad.source_no = strSourceNo
           and mad.outstock_type = strOutstockType
           and mad.tmp_id = v_nAllotID;

        if v_nUnAllotTotalQty = nTotalQty then
          return;
        end if;
        v_blAllotExcessFlag := true;
        v_blExcessFlag      := true;

      end if;

      /*if mod(nTotalQty, nUnitQty) > 0 then
        strErrorMsg := 'N|需要分配的数量必须是配量单位的整数倍';
        return;
      end if;*/

    exception
      when no_data_found then
        strErrorMsg := 'N|[E00023]';
        return;
    end;

    v_blChgUnitFlag := false;
    loop
      for v_cs_get_direct in (select war.allot_order,
                                     war.allot_type,
                                     war.prio_type,
                                     war.hand_type,
                                     war.prio_level,
                                     war.value
                                from wms_allot_rule war
                               where war.warehouse_no = strWareHouseNo
                                 and war.enterprise_no = strEnterPriseNo
                                 and war.outstock_type = strOutstockType
                                 and war.operate_type = strOperateType
                               order by war.allot_order) loop
        v_strSQL := 'select *
                             from (select sum(mad.plan_qty - mad.allot_qty) over(partition by mad.source_no) as unAllot_Tatol_Qty,
                                          sum(mad.plan_qty) over(partition by mad.source_no) as Plan_Tatol_Qty,
                                          decode(mad.outstock_type,
                                                 ''IS'',
                                                 bda.pick_excess,
                                                 ''ID'',
                                                 bda.check_excess,
                                                 ''RI'',
                                                 bda.um_check_excess) as excess_rate,
                                          lpad(dc.prio_level,10,''0'') as cust_level,
                                          nvl(dc.prio_type,''N'')  as cust_prio_type,
                                          mad.cust_no,
                                          mad.po_no,
                                          mad.plan_qty,
                                          mad.plan_qty - mad.allot_qty as unallot_qty
                                     from MIDDATA_ALLOT_DETAIL mad,
                                          bdef_defcust         dc,
                                          bdef_defarticle      bda
                                    where mad.enterprise_no=dc.enterprise_no
                                     and mad.enterprise_no=bda.enterprise_no
                                     and mad.enterprise_no= ''' ||
                    strEnterPriseNo || '''
                                      and mad.tmp_id = ''' ||
                    v_nAllotID || '''
                                      and bda.article_no = mad.article_no
                                      and dc.cust_no = mad.cust_no ';
        v_strSQL := v_strSQL ||
                    '                   and mad.warehouse_no = ''' ||
                    strWareHouseNo || '''';
        v_strSQL := v_strSQL || '                   and mad.source_no = ''' ||
                    strSourceNo || '''';
        v_strSQL := v_strSQL ||
                    '                   and mad.outstock_type = ''' ||
                    strOutstockType || ''' ';
        if v_cs_get_direct.ALLOT_TYPE in ('PRIO_CUST', 'RATE_CUST') then

          v_strSQL := v_strSQL || '   and dc.prio_level = ' ||
                      v_cs_get_direct.prio_level;
        end if;

        v_strSQL := v_strSQL || ') t order by ';

        v_blFirstOrder := true;
        if v_cs_get_direct.ALLOT_TYPE in ('RATE', 'RATE_CUST') and
           v_cs_get_direct.PRIO_TYPE in ('QTY_RATE') then

          v_strSQL       := v_strSQL ||
                            '   case when  (unallot_qty / unAllot_Tatol_Qty) * 100 >= ' ||
                            v_cs_get_direct.value || ' then 0 else 1 end ';
          v_blFirstOrder := false;
        end if;

        for v_cs_order in (select wao.sort_condition, wao.sort_type
                             from wms_allot_order wao
                            where wao.warehouse_no = strWareHouseNo
                              and wao.enterprise_no = strEnterPriseNo
                              and wao.outstock_type = strOutstockType
                              and wao.operate_type = strOperateType
                              and wao.allot_order =
                                  v_cs_get_direct.allot_order
                            order by wao.sort_order) loop
          if v_blFirstOrder = false then
            v_strSQL := v_strSQL || ',';
          end if;
          v_strSQL       := v_strSQL || case v_cs_order.sort_condition
                              when 'LEFT_QTY' then
                               'unallot_qty '
                              when 'TOTAL_QTY' then
                               'plan_qty '
                              when 'CUST_NO' then
                               'cust_no '
                              when 'ORDER_NO' then
                               'po_no '
                              when 'CUST_LEVEL' then
                               'cust_level '
                              when 'CUST_PRIO_TYPE' then
                               'cust_prio_type '
                              when 'CUST_PRIO_TYPE_LEVEL' then
                               'cust_prio_type || ''|'' || cust_level '
                            end;
          v_strSQL       := v_strSQL || case v_cs_order.sort_type
                              when 'DESC' then
                               ' desc '
                            end;
          v_blFirstOrder := false;
        end loop;

        v_blCircleHandlFlag := false;
        loop

          v_blAllotedFlag := false;
          open v_cs_get_unallot for v_strSQL;
          loop
            fetch v_cs_get_unallot
              into v_nUnAllotTotalQty,
                   v_nPlanTotalQty,
                   v_nExcessRate,
                   v_nCustLevel,
                   v_strCustPrioType,
                   v_strCustNo,
                   v_strPoNo,
                   v_nPlanQty,
                   v_nUnAllotQty;
            EXIT WHEN v_cs_get_unallot%NOTFOUND;
            if v_nExcessRate > 0 then
              v_blAllotExcessFlag := true;
            end if;
            case
            --优先配量
              when v_cs_get_direct.ALLOT_TYPE in ('PRIO', 'PRIO_CUST') then
                begin
                  if v_blExcessFlag = false then
                    v_nAllotQty := v_nUnAllotQty;
                  else
                    v_nAllotQty := floor(v_nPlanQty * v_nExcessRate);
                  end if;

                  if v_nAllotQty > v_nTotalQty then
                    v_nAllotQty := v_nTotalQty;
                  end if;

                  if v_blChgUnitFlag = false then
                    v_nAllotQty := floor(v_nAllotQty / nUnitQty) * nUnitQty;
                  end if;

                  if v_cs_get_direct.HAND_TYPE = 'CIRCLE' then
                    v_blCircleHandlFlag := true;
                    if v_nAllotQty > 0 then
                      v_nAllotQty := nUnitQty;
                    end if;
                  end if;

                end;

            --按比率配量
              when v_cs_get_direct.ALLOT_TYPE in ('RATE', 'RATE_CUST') then
                begin

                  if v_blExcessFlag = false then

                    --加入这个条件就是防止，本来就不需要再配了，还配一个最小单位的量给它
                    if v_nUnAllotQty > 0 then
                      v_nAllotQty := round((v_nTotalQty * v_nUnAllotQty) /
                                           v_nUnAllotTotalQty);
                      if v_blChgUnitFlag = false then
                        v_nAllotQty := floor(v_nAllotQty / nUnitQty) *
                                       nUnitQty;
                      end if;

                      --如果不够一个配量单位，补足一个配量单位
                      if v_nAllotQty < 1 and v_nUnAllotQty > nUnitQty and
                         v_nTotalQty >= nUnitQty then
                        v_nAllotQty := nUnitQty;
                      end if;
                    else
                      v_nAllotQty := 0;
                    end if;

                  else
                    --取计划量与总计划量的比例
                    v_nAllotQty := round((v_nTotalQty * v_nPlanQty) /
                                         v_nPlanTotalQty);

                    --超过超量比率，还是得控制在超量范围内
                    if v_nAllotQty > floor(v_nPlanQty * v_nExcessRate) then
                      v_nAllotQty := floor(v_nPlanQty * v_nExcessRate);
                    end if;

                    if v_blChgUnitFlag = false then
                      v_nAllotQty := floor(v_nAllotQty / nUnitQty) *
                                     nUnitQty;
                    end if;

                    --如果不够一个配量单位，补足一个配量单位
                    if v_nAllotQty < 1 and v_nTotalQty >= nUnitQty and
                       nUnitQty <= floor(v_nPlanQty * v_nExcessRate) then
                      v_nAllotQty := nUnitQty;
                    end if;

                  end if;

                end;
              else
                strErrorMsg := 'N|[E00024]';
                return;
            end case;

            v_nTotalQty := v_nTotalQty - v_nAllotQty;

            if v_nAllotQty > 0 then
              v_blAllotedFlag := true;
            end if;
            update MIDDATA_ALLOT_DETAIL mad
               set mad.allot_qty = mad.allot_qty + v_nAllotQty
             where mad.warehouse_no = strWareHouseNo
               and mad.enterprise_no = strEnterPriseNo
               and mad.source_no = strSourceNo
               and mad.outstock_type = strOutstockType
               and mad.cust_no = v_strCustNo
               and mad.po_no = v_strPoNo
               and mad.tmp_id = v_nAllotID;

            if v_nTotalQty <= 0 then
              exit;
            end if;

          end loop;
          close v_cs_get_unallot;

          --如果一次量都没有配到,说明是单位有问题
          if v_blAllotedFlag = false then
            exit;
          end if;

          --如果不是循环发放或全部配完，退出该循环
          if v_blCircleHandlFlag = false or v_nTotalQty <= 0 then
            exit;
          end if;

        end loop;

      end loop;

      if v_nTotalQty <= 0 then
        exit;
      end if;

      --不允许超量或者已做过超量配比 ,并且已按最小单位配过
      if (v_blAllotExcessFlag = false or v_blExcessFlag = true) and
         v_blChgUnitFlag = true then

        strErrorMsg := 'N|[E00022]';
        return;

      end if;

      --有两种情况，一种是被拆，一种是超量
      --如果没有做过超量，首先先换单位试一下，试后还有余量才让做超量配
      --如果做过超量，就让换单位试下就行
      if v_blExcessFlag = false then
        if v_blChgUnitFlag = false then
          v_blChgUnitFlag := true;
        else
          v_blExcessFlag  := true;
          v_blChgUnitFlag := false;
        end if;
      else
        if v_blChgUnitFlag = false then
          v_blChgUnitFlag := true;
        end if;

      end if;

    end loop;

  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_locate_allot;

end PKLG_PUBLOCATE;

/

