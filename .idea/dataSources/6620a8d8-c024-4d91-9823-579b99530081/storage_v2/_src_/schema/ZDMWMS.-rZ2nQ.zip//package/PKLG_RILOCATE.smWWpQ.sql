create package        PKLG_RILOCATE is
--返配定位
   --定位入口
  procedure p_locate_main(strEnterPriseNo   in  ridata_locate_direct.enterprise_no%type,
                          strWareHouseNo in ridata_locate_direct.warehouse_no%type, --仓库代码
                          strOwnerNo     in ridata_locate_direct.owner_no%type, --货主代码
                          strLocateNo    in ridata_locate_direct.locate_no%type,
                          strDockNo      in ridata_locate_direct.dock_no%type,
                          strUserID      in ridata_locate_direct.rgst_name%type,
                          strOutMsg      out varchar2);

  /****************************************************************************************************
    返配定位写库存以及上架指示 huangb 20160809
  ***************************************************************************************************/
  procedure p_Ridata_Write_direct(strEnterPriseNo in ridata_locate_direct.enterprise_no%type,
                                  strWareHouseNo  in ridata_locate_direct.warehouse_no%type, --仓库代码
                                  strOwnerNo      in ridata_locate_direct.owner_no%type, --货主代码
                                  strLocateNo     in ridata_locate_direct.locate_no%type,
                                  strUntreadType  in ridata_check_pal.untread_type%type, --单据类型
                                  strClassType    in ridata_check_pal.class_type%type, --0:一般返配；1：仓调返配
                                  strQualityFlag  in ridata_check_pal.quality%type,
                                  strDockNo       in ridata_locate_direct.dock_no%type,
                                  strUserID       in ridata_locate_direct.rgst_name%type,
                                  strOutMsg       out varchar2);

  /****************************************************************************************************
    返配定位查找储位 huangb 20160809
  ***************************************************************************************************/
  procedure p_Ridata_SelectInstockCellNo(strEnterPriseNo      in ridata_locate_direct.enterprise_no%type,
                                         strWareHouseNo       in ridata_locate_direct.warehouse_no%type, --仓库代码
                                         strAreaQuality       in cdef_defarea.area_quality%type,
                                         strRuleId            in wms_defrule.rule_id%type, --规则ID
                                         strReturnInstockCell out cdef_defcell.cell_no%type, --返回上架储位
                                         strOutMsg            out varchar2);

/****************************************************************************************************
    定位到退货区

***************************************************************************************************/
  procedure p_RecedeGoodslocate_main(strEnterPriseNo  in  ridata_locate_direct.enterprise_no%type,
                          strWareHouseNo in ridata_locate_direct.warehouse_no%type, --仓库代码
                          strOwnerNo     in ridata_locate_direct.owner_no%type, --货主代码
                          strLocateNo    in ridata_locate_direct.locate_no%type,
                          strQualityFlag in ridata_locate_direct.quality_flag%type,
                          strDockNo      in ridata_locate_direct.dock_no%type,
                          strUserID      in ridata_locate_direct.rgst_name%type,
                          strOutMsg      out varchar2);
/****************************************************************************************************
    定位到次品仓

***************************************************************************************************/
  procedure p_BadGoodslocate_main(strEnterPriseNo  in  ridata_locate_direct.enterprise_no%type,
                          strWareHouseNo in ridata_locate_direct.warehouse_no%type, --仓库代码
                          strOwnerNo     in ridata_locate_direct.owner_no%type, --货主代码
                          strLocateNo    in ridata_locate_direct.locate_no%type,
                          strQualityFlag in ridata_locate_direct.quality_flag%type,
                          strDockNo      in ridata_locate_direct.dock_no%type,
                          strUserID      in ridata_locate_direct.rgst_name%type,
                          strOutMsg      out varchar2);
/****************************************************************************************************
    功能说明：定位到过季品仓
    luozhiling
    2015.7.18
***************************************************************************************************/
  procedure p_OutofSeasonGoodslocate_main(strEnterPriseNo  in  ridata_locate_direct.enterprise_no%type,
                          strWareHouseNo in ridata_locate_direct.warehouse_no%type, --仓库代码
                          strOwnerNo     in ridata_locate_direct.owner_no%type, --货主代码
                          strLocateNo    in ridata_locate_direct.locate_no%type,
                          strQualityFlag in ridata_locate_direct.quality_flag%type,
                          strDockNo      in ridata_locate_direct.dock_no%type,
                          strUserID      in ridata_locate_direct.rgst_name%type,
                          strOutMsg      out varchar2);
/****************************************************************************************************
    良品转正常入库
    功能说明：1、更新返配定位指示为13状态，
             2、写对应的入库定位指示；
             3、入库定位；
             4、入库发单；
     创建人：luozhiling
     创建时间：2014.12.9
     返配定位根据策略来 huangb 20160809
***************************************************************************************************/
  procedure p_GoodLoate_Main(strEnterPriseNo in  ridata_locate_direct.enterprise_no%type,
                             strWareHouseNo  in ridata_locate_direct.warehouse_no%type, --仓库代码
                             strOwnerNo      in ridata_locate_direct.owner_no%type, --货主代码
                             strLocateNo     in ridata_locate_direct.locate_no%type,
                             strUntreadType  in ridata_check_pal.untread_type%type, --单据类型 huangb 20160809
                             strClassType    in ridata_check_pal.class_type%type, --0:一般返配；1：仓调返配 huangb 20160809
                             strQualityFlag  in ridata_check_pal.quality%type, --品质标识 huangb 20160809
                             strDockNo       in ridata_locate_direct.dock_no%type,
                             strUserID       in ridata_locate_direct.rgst_name%type,
                             strOutMsg       out varchar2);


  --写上架指示
  procedure p_write_instockdirect(strEnterPriseNo in ridata_instock_direct.enterprise_no%type,
                                  strWareHouseNo  in ridata_instock_direct.warehouse_no%type, --仓库代码
                                  nRowid          in ridata_instock_direct.row_id%type, --定位指示行号
                                  strLocateCellNo in ridata_instock_direct.dest_cell_no%type, --定位储位
                                  nLocateCellID   in ridata_instock_direct.dest_cell_id%type,
                                  strUserID       in ridata_instock_direct.rgst_name%type, --员工代码
                                  strOutMsg       out varchar2);
  /*********************************************************************************************8

  功能说明：查找过季品储位
  ***********************************************************************************************/

  procedure p_OutofSeasonCellNo(strEnterPriseNo in ridata_instock_direct.enterprise_no%type,
                           strWareHouseNo in ridata_instock_direct.warehouse_no%type,
                           strArticleNo   in stock_article_info.article_no%type,
                           strCellNo      out ridata_instock_direct.dest_cell_no%type,
                           strOutMsg      out varchar2);
  --查找储位
  /********************************************************************************************
  创建人：luozhiling
  创建时间：2014.12.12
  功能说明：定位到退货区
  **********************************************************************************************/
  procedure p_RecedeLocate(strEnterPriseNo in ridata_instock_direct.enterprise_no%type,
                           strWareHouseNo in ridata_instock_direct.warehouse_no%type,
                           strQuality     in stock_article_info.quality%type,
                           strArticleNo   in stock_article_info.article_no%type,
                           strCellNo      out ridata_instock_direct.dest_cell_no%type,
                           strOutMsg      out varchar2);
 --查找储位
  /********************************************************************************************
  创建人：luozhiling
  创建时间：2015.7.18
  功能说明：定位到报损库
  **********************************************************************************************/
  procedure p_BadGoodLocate(strEnterPriseNo in ridata_instock_direct.enterprise_no%type,
                           strWareHouseNo in ridata_instock_direct.warehouse_no%type,
                           strArticleNo   in stock_article_info.article_no%type,
                           strCellNo      out ridata_instock_direct.dest_cell_no%type,
                           strOutMsg      out varchar2);
end PKLG_RILOCATE;


/

