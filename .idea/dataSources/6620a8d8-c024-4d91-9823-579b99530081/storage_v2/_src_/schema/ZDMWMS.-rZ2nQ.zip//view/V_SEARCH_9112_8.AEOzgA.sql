create view V_SEARCH_9112_8 as
select SC.ENTERPRISE_NO,
       SC.WAREHOUSE_NO,
       SC.OWNER_NO,
       SC.ARTICLE_NO,
       SC.CELL_NO,
       BDA.ARTICLE_NAME,
       BDA.UNIT,
       BDA.SPEC,
       BDA.OWNER_ARTICLE_NO,
       BDA.ARTICLE_IDENTIFIER,
       BDA.BARCODE,
       CDA.AREA_NO,
       CDA.AREA_NAME
  from stock_content   sc,
       CDEF_DEFCELL    CD,
       cdef_defarea    CDA,
       BDEF_DEFARTICLE BDA
 where SC.ENTERPRISE_NO = CD.ENTERPRISE_NO
   AND SC.WAREHOUSE_NO = CD.WAREHOUSE_NO
   AND SC.CELL_NO = CD.CELL_NO
   and CDA.ENTERPRISE_NO = CD.ENTERPRISE_NO
   AND CDA.WAREHOUSE_NO = CD.WAREHOUSE_NO
   AND CDA.WARE_NO = CD.WARE_NO
   AND CDA.AREA_NO = CD.AREA_NO
   and cda.area_pick <> 1
   and BDA.ENTERPRISE_NO = SC.ENTERPRISE_NO
   AND BDA.ARTICLE_NO = SC.ARTICLE_NO
   and (sc.enterprise_no, sc.article_no) not in
       (select enterprise_no, article_no from cset_cell_article)

/

