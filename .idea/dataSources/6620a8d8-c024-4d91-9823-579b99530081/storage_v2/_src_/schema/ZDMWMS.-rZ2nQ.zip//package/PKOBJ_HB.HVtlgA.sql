create package        PKOBJ_HB is

/*=====================================================================================
  hb insert to 20140607
  出货工作流
  ======================================================================================*/
  PROCEDURE p_OM_OutWorkflow(strEnterPriseNo in STOCK_LABEL_M.enterprise_no%type, --企业号
                             strwarehouse_no in STOCK_LABEL_M.warehouse_no%type, --仓别
                             strOwner_No     in bdef_defowner.owner_no%type,
                             strExp_Type     in odata_exp_m.exp_type%type,
                             strContainer_No in stock_label_m.container_no%type, --系统内部容器号
                             strUser_Id      in stock_label_m.rgst_name%type, --操作人员
                             strDockNo       in Bdef_Defdock.dock_no%TYPE, --自动封车打印使用，若不需要则传'N'
                             strOutMsg       out varchar2);

  /***************************************************************************************************************88888
  功能说明：通过出货工作流获取标签状态
  luozhiling
  2015.05.14
  *******************************************************************************************************************/
  PROCEDURE p_getlabelnoFlow(strEnterPriseNo in STOCK_LABEL_M.enterprise_no%type, --企业号
                             strwarehouse_no in STOCK_LABEL_M.warehouse_no%type, --仓别
                             strOwner_No     in bdef_defowner.owner_no%type,
                             strExp_Type     in odata_exp_m.exp_type%type,
                             strContainer_No in stock_label_m.container_no%type, --系统内部容器号
                             strFlowFlag     out wms_outorder_flow_d.flow_flag%type, --状态区间
                             strOutMsg       out varchar2) ;

  /************************************************************************************
  功能说明：根据标签获取当前可工作流，并判断此工作流是否处于执行状态
  2015.7.29

  *************************************************************************************/
  PROCEDURE p_GetLabelStatusFromWorkflow(strEnterPriseNo in STOCK_LABEL_M.enterprise_no%type, --企业号
                                         strwarehouse_no in STOCK_LABEL_M.warehouse_no%type, --仓别
                                         strOwner_No     in bdef_defowner.owner_no%type,
                                         strExp_Type     in odata_exp_m.exp_type%type,
                                         strContainer_No in stock_label_m.container_no%type, --系统内部容器号
                                         n_status_type   out wms_deflabel_status.status_type%type, --状态区间
                                         strAutoFlag     out wms_deflabel_status.must_run%type, --是否需要自动执行
                                         strOutMsg       out varchar2);
  /*=====================================================================================
  hb insert to 20140719
  容器整理确认扫描标签检验
  ======================================================================================*/
  PROCEDURE p_OM_AerrangeConfirmScanLabel(strEnterPriseNo    in STOCK_LABEL_M.enterprise_no%type,--企业号
                                          strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                          strLabel_No     in stock_label_m.label_No%type, --标签号
                                          strOutMsg       out varchar2);
  /*************************************************************************************
  功能说明：
            1、扫描客户、
            2、扫描标签，校验当前标签是否属于当前客户
            2015.9.19
  ************************************************************************************/
  PROCEDURE P_CheckCustLabelScan(strEnterPriseNo    in STOCK_LABEL_M.enterprise_no%type,--企业号
                                          strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                          strCurCustNo    in bdef_defcust.cust_no%type,--若没有，则传值为N
                                          strLabel_No     in stock_label_m.label_No%type, --标签号
                                          strOutMsg       out varchar2);

  /*=====================================================================================
  hb insert to 20140719
  容器整理确认扫描标签检验
  ======================================================================================*/
  PROCEDURE p_OM_AerrangeConfirm(strEnterPriseNo    in STOCK_LABEL_M.enterprise_no%type,--企业号
                                 strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
                                 strLabel_No     in stock_label_m.label_No%type, --标签号
                                 strUser_Id      in stock_label_m.rgst_name%type, --操作人员
                                 strOutMsg       out varchar2);
 /*&*********************************************************************************************
 功能：1、自动装并板
       2整理确认
 ************************************************************************************************/
 PROCEDURE P_loadPalAndComfire(strEnterPriseNo    in STOCK_LABEL_M.enterprise_no%type,--企业号,
               strwarehouse_no in stock_label_m.warehouse_no%type, --仓别
               strLabelNo     in stock_label_m.label_No%type, --标签号
               strDeliverObj  in stock_label_m.deliver_obj%type,
               strWaveNo      in stock_label_m.wave_no%type,
               strUserId      in stock_label_m.rgst_name%type, --操作人员
               strOutMsg       out varchar2);

 /*=====================================================================================
  hb insert to 20160520
  出库扫描-整单扫描
  ======================================================================================*/
  PROCEDURE p_ODATA_ExpCheckScanOrder(strEnterPriseNo in odata_exp_check_m.enterprise_no%type,--企业号,
                                      strwarehouse_no in odata_exp_check_m.warehouse_no%type, --仓别
                                      strSourceexp_No in odata_exp_check_m.sourceexp_no%type, --出货来源单号
                                      strUser_Id      in odata_exp_check_m.rgst_name%type, --操作人员
                                      strOutMsg       out varchar2);

  /*=====================================================================================
  hb insert to 20160522
  出库扫描-商品扫描
  ======================================================================================*/
  PROCEDURE p_ODATA_ExpCheckScanArticle(strEnterPriseNo   in odata_exp_check_m.enterprise_no%type, --企业号
                                        strwarehouse_no   in odata_exp_check_m.warehouse_no%type, --仓别
                                        strSourceexp_No   in odata_exp_check_m.sourceexp_no%type, --出货来源单号
                                        strScan_No        in odata_exp_check_d.scan_no%type, --扫描码
                                        strArticle_No     in odata_exp_check_d.article_no%type, --商品编码
                                        nScanPackingQty   in odata_exp_check_d.scan_packing_qty%type, --扫描商品所对应的包装
                                        nScanQty          in odata_exp_check_d.scan_qty%type, --扫描量
                                        nRow_Id           in odata_exp_check_d.row_id%type, --出货扫描明细行号
                                        strUser_Id        in odata_exp_check_m.rgst_name%type, --操作人员
                                        strScanFlag       out varchar2, --返回当前单据是否已经全部扫描完成(0-不是；1-是)
                                        strOutMsg         out varchar2);

  /*=====================================================================================
  hb insert to 20160522
  出库扫描-修改强制整单扫描完成单据复核单据为已审核
  ======================================================================================*/
  PROCEDURE p_ODATA_ExpCheckUpdtMaster(strEnterPriseNo in odata_exp_check_m.enterprise_no%type,--企业号,
                                       strwarehouse_no in odata_exp_check_m.warehouse_no%type, --仓别
                                       strSourceexp_No in odata_exp_check_m.sourceexp_no%type, --出货来源单号
                                       strUser_Id      in odata_exp_check_m.rgst_name%type, --操作人员
                                       strOutMsg       out varchar2);
end PKOBJ_HB;


/

