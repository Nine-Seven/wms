create package        PKLG_CONTAINER_CALCULATE is

  -- Author  : weiyufei
  -- Created : 2015-05-13 16:00:09
  -- Purpose : 物流箱资源试算
  /***客户物流箱试算***/
  /******/
  /* PROCEDURE P_CUST_CONTAINER_CALCULATE(strEnterPriseNo IN odata_outstock_direct.enterprise_no%TYPE, --企业
  strWarehouseNo  IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
  strWaveNo       IN ODATA_OUTSTOCK_DIRECT.WAVE_NO%TYPE, --波次号
  strUserId       IN ODATA_OUTSTOCK_DIRECT.UPDT_NAME%TYPE, --员工ID
  strPickBoxFlag  IN VARCHAR2,
  strCustBoxFlag  IN VARCHAR2,
  strErrorMsg     OUT VARCHAR2);*/

  --计算摘果物流箱--支持电商规则 Add BY QZH AT 2016-6-6
  PROCEDURE P_CONTAINER_CALCULATE_PICK(strEnterPriseNo IN odata_outstock_direct.enterprise_no%TYPE, --企业
                                       strWarehouseNo  IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
                                       strWaveNo       IN ODATA_OUTSTOCK_DIRECT.WAVE_NO%TYPE, --波次号
                                       strUserId       IN ODATA_OUTSTOCK_DIRECT.UPDT_NAME%TYPE, --员工ID
                                       --strPickBoxFlag  IN VARCHAR2,
                                       --strCustBoxFlag  IN VARCHAR2,
                                       strErrorMsg OUT VARCHAR2);

  PROCEDURE P_GET_SYS_PARAM(strEnterPriseNo IN odata_outstock_direct.enterprise_no%TYPE, --企业
                            strWarehouseNo  IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
                            strOwnerNo      IN ODATA_OUTSTOCK_DIRECT.OWNER_NO%TYPE, --货主
                            nUseType        IN NUMBER, --物流箱类型
                            --blCalcuWeight   OUT BOOLEAN, --是否计算重量
                            --blCalcuVol      OUT BOOLEAN, --是否计算材积
                            --blCalcuPackQTY  OUT BOOLEAN, --是否计算包装量
                            --blSplitCustBox  OUT BOOLEAN, --是否拆分客户物流箱
                            --blSplitPickBox  OUT BOOLEAN, --是否拆分客户物流箱
                            nMax_Vol    OUT NUMBER,
                            nMax_Weight OUT NUMBER,
                            strErrorMsg OUT VARCHAR2);
  PROCEDURE P_GET_CONTAINER_VOLUMN(strEnterPriseNo      IN odata_outstock_direct.enterprise_no%TYPE, --企业
                                   strWarehouseNo       IN WMS_DEFCONTAINER.WAREHOUSE_NO%TYPE, --仓别
                                   strContainerType     IN WMS_DEFCONTAINER.CONTAINER_TYPE%TYPE, --容器类型
                                   strUseType           IN WMS_DEFCONTAINER.USE_TYPE%TYPE, --用途
                                   strLabelPrefix       IN WMS_DEFCONTAINER.LABEL_PREFIX%TYPE, --标签前缀
                                   strContainerMeterial IN WMS_DEFCONTAINER.CONTAINER_MATERIAL%TYPE, --容器材质
                                   nDecVolumn           OUT NUMBER,
                                   nDecWeight           OUT NUMBER,
                                   strErrorMsg          OUT VARCHAR2);
  /***分播物流箱***/
  /******/
  PROCEDURE P_CONTAINER_CALCULATE_DIVIDE(strEnterPriseNo IN odata_outstock_direct.enterprise_no%TYPE, --企业
                                         strWarehouseNo  IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
                                         strWaveNo       IN ODATA_OUTSTOCK_DIRECT.WAVE_NO%TYPE, --波次号
                                         strUserId       IN ODATA_OUTSTOCK_DIRECT.UPDT_NAME%TYPE, --员工ID
                                         --strPickBoxFlag  IN VARCHAR2,
                                         --strCustBoxFlag  IN VARCHAR2,
                                         strErrorMsg OUT VARCHAR2);
  /***拆下架指示***/
  /******/
  PROCEDURE P_SPLIT_OUTSTOCKDIRECT(strEnterPriseNo    IN odata_outstock_direct.enterprise_no%TYPE, --企业
                                   strWarehouseNo     IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
                                   nSerial            IN ODATA_OUTSTOCK_DIRECT.DIRECT_SERIAL%TYPE, --指示ID
                                   nLocateQty         in ODATA_OUTSTOCK_DIRECT.Locate_Qty%type,
                                   nQMinPackQty       in number,
                                   nMax_Weight        IN NUMBER,
                                   nMax_Vol           IN NUMBER,
                                   nMax_PackRate      IN NUMBER,
                                   nUnit_Weight       IN NUMBER,
                                   nUnit_Vol          IN NUMBER,
                                   nUnit_PackRate     IN NUMBER,
                                   nCumulative_Volumn IN NUMBER,
                                   --nCustFlag          in NUMBER, --1为客户标签，0为拣货标签
                                   nUseType          in number,
                                   strUserId         IN ODATA_OUTSTOCK_DIRECT.UPDT_NAME%TYPE, --员工ID
                                   blCalcuWeight     IN BOOLEAN,
                                   blCalcuVol        IN BOOLEAN,
                                   blCalcuPackQTY    IN BOOLEAN,
                                   nUnallot_Weight   IN OUT NUMBER,
                                   nUnAllot_Vol      IN OUT NUMBER,
                                   nUnAllot_PackRate IN OUT NUMBER,

                                   nCurr_Weight   IN OUT NUMBER,
                                   nCurr_Vol      IN OUT NUMBER,
                                   nCurr_PackRate IN OUT NUMBER,

                                   strContainerNo IN OUT ODATA_OUTSTOCK_DIRECT.s_Container_No%TYPE,
                                   strErrorMsg    OUT VARCHAR2);
  /*\***铁越特殊处理***\
    \******\
    PROCEDURE P_Container_CALCULATE(strEnterPriseNo IN odata_outstock_direct.enterprise_no%TYPE, --企业
                                    strWarehouseNo  IN ODATA_OUTSTOCK_DIRECT.WAREHOUSE_NO%TYPE, --仓别
                                    strWaveNo       IN ODATA_OUTSTOCK_DIRECT.WAVE_NO%TYPE, --波次号
                                    strUserId       IN ODATA_OUTSTOCK_DIRECT.UPDT_NAME%TYPE, --员工ID
                                    strErrorMsg     OUT VARCHAR2);
  */
end PKLG_CONTAINER_CALCULATE;


/

