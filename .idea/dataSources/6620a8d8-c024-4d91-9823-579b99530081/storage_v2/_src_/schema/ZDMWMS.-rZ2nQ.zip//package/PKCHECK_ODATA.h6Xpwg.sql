create package        pkcheck_odata is

  -- Author  : LICH
  -- Created : 2015-01-20 10:26:23
  -- Purpose :

  /*****************************************************************************************************************
  lich
  20150120
  功能说明：拣货回单，标签号校验
  支持扫描下架单号 huangb 20160722
  ***************************************************************************************************************/
  procedure P_CheckLabelNo(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                           strWarehouseNo  in stock_label_m.warehouse_no%type,
                           strLabelNo      in stock_label_m.label_no%type, --标签或下架单号 huangb 20160722
                           strUserID       in odata_outstock_m.rgst_name%type,
                           strOutLabelNo   out stock_label_m.label_no%type, --返回标签号 huangb 20160722
                           strOutDivideNo  out odata_divide_m.divide_no%type, --分播单号
                           strOutMsg       out varchar2);

  /*****************************************************************************************************************
  lich
  20150126
  功能说明：分播回单，标签号校验
  ***************************************************************************************************************/
  procedure P_DivideCheckSLabelNo(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                                  strWarehouseNo  in stock_label_m.warehouse_no%type,
                                  strLabelNo      in stock_label_m.label_no%type,
                                  strOutMsg       out varchar2);
  /*****************************************************************************************************************
  lich
  20150126
  功能说明：分播回单，目的标签号校验
  ***************************************************************************************************************/
  procedure P_DivideCheckDLabelNo(strEnterpriseNo in odata_outstock_m.enterprise_no%type,
                                  strWarehouseNo  in stock_label_m.warehouse_no%type,
                                  strOwnerNo      in bdef_defowner.owner_no%type,
                                  strSContainerNo in stock_label_m.container_no%type, --来源标签内部容器号
                                  strDLabelNo     in stock_label_m.label_no%type,
                                  strDelvierObj   in stock_label_m.deliver_obj%type, --当前分播数据对应配送对象
                                  strCustNo       in odata_divide_d.cust_no%type,
                                  strArticleNo    in odata_divide_d.article_no%type,
                                  strOutMsg       out varchar2);

  /**************************************************************************************************88
  功能说明：装并板的来源标签的校验
  1、只有客户标签才能并板；
  2、已装并板状态的标签不能并板；
  4、A1状态的标签不能并板
  5、已存在并板标签的标签不能并板
  ***********************************************************************************************/
  procedure P_MergePal_Slabel_Check(strEnterpriseNo in stock_label_m.enterprise_no%type,
                                    strWarehouseNo  in stock_label_m.warehouse_no%type,
                                    strLabelNo      in stock_label_m.label_no%type, --来源标签
                                    strLabelType    in stock_label_m.use_type%type, --1：源标签，2：目的标签（往上放货的容器）
                                    strStatus       out stock_label_m.status%type,
                                    strCustNo       out stock_label_m.cust_no%type,
                                    strOutMsg       out varchar2);

  /*****************************************************************************************
   功能：校验源标签是否可并板到目的标签
  *****************************************************************************************/
  procedure P_Check_Mergelabel(strEnterpriseNo in stock_label_m.enterprise_no%type, --仓别
                               strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                               strSLabelNo     in stock_label_m.label_no%type, --原标签
                               strDLabelNo     in stock_label_m.label_no%type, --目的标签
                               strStatus       out stock_label_m.status%type, --目的标签状态
                               strCustNo       out stock_label_m.cust_no%type, --目的标签对应的客户
                               strResult       out varchar2);

end pkcheck_odata;


/

