create package body        pkobj_rodata is
  --写退货下架单头
  procedure P_RO_WriteOutStockHead(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                                   strWarehouseNo in rodata_outstock_m.warehouse_no%type, --仓别
                                   strOwnerNo     in rodata_outstock_m.owner_no%type,
                                   strOutStockNo  in rodata_outstock_m.outstock_no%type, --下架单号
                                   strOperateType in rodata_outstock_m.operate_type%type, --作业类型
                                   strRecedeType  in rodata_outstock_m.recede_type%type,--退货类型
                                   strClassType   in rodata_outstock_m.class_type%type,--0:正常；1：质量问题；2：总仓
                                   strUserID      in rodata_outstock_m.rgst_name%type, --员工ID
                                   strTaskType    in rodata_outstock_m.task_type%type,
                                   strOutMsg      out varchar2) is
  begin
    strOutMsg := 'N|[P_RO_WriteOutStockHead]';

    INSERT INTO rodata_outstock_m
      (enterprise_no,warehouse_no,
       OWNER_NO,
       OUTSTOCK_NO,
       OPERATE_DATE,
       OPERATE_TYPE,
       STATUS,
       RGST_NAME,
       RGST_DATE,
       updt_name,
       updt_date,
       task_type,class_type,recede_type)
    VALUES
      (strEnterPriseNo,strWarehouseNo,
       strOwnerNo,
       strOutStockNo,
       trunc(sysdate),
       strOperateType,
       '10',
       strUserID,
       sysdate,
       strUserID,
       sysdate,
       strTaskType,strClassType,strRecedeType);
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E25202]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_RO_WriteOutStockHead;

  --写退货下架明细
  procedure P_RO_WriteOutStockItem(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                                   strWarehouseNo in rodata_outstock_direct.warehouse_no%type, --仓别
                                   strOwnerNo     in rodata_outstock_direct.owner_no%type,
                                   strOutStockNo  in rodata_outstock_d.outstock_no%type, --下架单号
                                   strAssignName  in rodata_outstock_d.assign_name%type, --计划作业人员
                                   dOperateDate   in rodata_outstock_direct.operate_date%type,
                                   nDirectSerial  in rodata_outstock_direct.direct_serial%type, --指示序列
                                   strOutMsg      out varchar2) is
      v_iCount                    integer;
  begin
    strOutMsg := 'N|[P_RO_WriteOutStockItem]';

    --获取ROW_id
    select nvl(max(row_id)+1,1) into v_iCount from rodata_outstock_d ood
           where ood.enterprise_no=strEnterPriseNo and ood.warehouse_no=strWarehouseNo
           and ood.outstock_no=strOutStockNo;
    insert into rodata_outstock_d
      (enterprise_no,warehouse_no,
       owner_no,
       outstock_no,
       divide_id,
       source_no,
       po_id,
       article_no,
       article_id,
       packing_qty,
       article_qty,
       real_qty,
       s_cell_no,
       s_cell_id,
       d_cell_no,
       d_cell_id,
       outstock_cell_no,
       status,
       assign_name,
       stock_type,
       stock_value,wave_no,s_label_no,label_no,sub_label_no,row_id,
       locate_no,batch_no,device_no,dps_cell_no)
      select d.enterprise_no,d.warehouse_no,
             d.owner_no,
             strOutStockNo,
             d.direct_serial,
             d.source_no,
             d.po_id,
             d.article_no,
             d.article_id,
             d.packing_qty,
             d.locate_qty,
             0,
             d.s_cell_no,
             d.s_cell_id,
             d.d_cell_no,
             d.d_cell_id,
             d.d_cell_no,
             '10',
             strAssignName,
             d.stock_type,
             d.stock_value,d.wave_no,d.label_no,
             case when d.label_pick_flag='2' then d.label_no else 'N' end label_no,
             case when d.label_pick_flag='2' then d.label_no else 'N' end sub_label_no,v_iCount,
             d.locate_no,d.batch_no,d.device_no,d.dps_cell_no
        from rodata_outstock_direct d
       where d.enterprise_no=strEnterPriseNo
         and d.warehouse_no = strWarehouseNo
         and d.owner_no = strOwnerNo
         and d.direct_serial = nDirectSerial
         and d.operate_date = dOperateDate;
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E25203]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_RO_WriteOutStockItem;

  --新增拆分的退货下架明细
  procedure P_RO_InsertOutStockItem(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                                    strWarehouseNo in rodata_outstock_direct.warehouse_no%type, --仓别
                                    strOwnerNo     in rodata_outstock_direct.owner_no%type,
                                    strOutStockNo  in rodata_outstock_d.outstock_no%type, --下架单号
                                    strArticleNO   IN rodata_outstock_d.article_no%type,
                                    strScellNo     in rodata_outstock_d.s_cell_no%type,
                                    strsCellId     in rodata_outstock_d.s_cell_id%type,
                                    nArticleQTY    in rodata_outstock_d.article_qty%type, --预计拆分数量
                                    nRealQTY       in rodata_outstock_d.article_qty%type, --实际拆分数量
                                    strRealCellNo  in rodata_outstock_d.d_cell_no%type,
                                    strsLablNo     in rodata_outstock_d.s_label_no%type,--来源标签
                                    strLabelNo     in rodata_outstock_d.label_no%type,--目的标签
                                    nDivideId      in rodata_outstock_d.divide_id%type, --指示序列
                                    strScanName    in rodata_outstock_d.scan_name%type,--扫描人
                                    strOutMsg      out varchar2) is
    v_iCount   rodata_outstock_d.row_id%type;
  begin
    strOutMsg := 'N|[P_RO_InsertOutStockItem]';

    select nvl(max(row_id),0) into v_iCount from rodata_outstock_d sld
     where sld.enterprise_no=strEnterPriseNo and sld.warehouse_no=strWarehouseNo
     and sld.outstock_no=strOutStockNo ;

    insert into rodata_outstock_d
      (enterprise_no,warehouse_no,
       owner_no,
       outstock_no,
       divide_id,
       source_no,
       po_id,
       article_no,
       article_id,
       packing_qty,
       article_qty,
       real_qty,
       s_cell_no,
       s_cell_id,
       d_cell_no,
       d_cell_id,
       outstock_cell_no,
       status,
       assign_name,
       stock_type,
       stock_value,s_label_no,label_no,sub_label_no,outstock_qty,outstock_name,
       outstock_date,wave_no,scan_name,scan_date,ROW_ID,
       locate_no,batch_no,device_no,dps_cell_no)
      select d.enterprise_no,d.warehouse_no,
             d.owner_no,
             strOutStockNo,
             d.divide_id,
             d.source_no,
             d.po_id,
             d.article_no,
             d.article_id,
             d.packing_qty,
             nArticleQTY,
             nRealQTY,
             d.s_cell_no,
             d.s_cell_id,
             d.d_cell_no,
             d.d_cell_id,
             strRealCellNo,
             '11',
             d.assign_name,
             d.stock_type,
             d.stock_value,d.s_label_no,strLabelNo,strLabelNo,nRealQTY,d.outstock_name,
             d.outstock_date,d.wave_no,strScanName,sysdate,v_iCount+1,
             d.locate_no,d.batch_no,d.device_no,d.dps_cell_no
        from rodata_outstock_d d
       where d.enterprise_no=strEnterPriseNo and d.warehouse_no = strWarehouseNo
         and d.owner_no = strOwnerNo
         and d.divide_id = nDivideId
         and d.outstock_no=strOutStockNo
         and d.article_no=strArticleNO
         and d.s_cell_no=strScellNo
         and d.s_cell_id=strsCellId
         and d.s_label_no=strsLablNo
         and rownum <= 1;

    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E25203]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_RO_InsertOutStockItem;

  --更新退货下架指示
  procedure P_RO_UpdatedOutStockDirect(strEnterPriseNo in rodata_outstock_d.enterprise_no%type,
                                       strWarehouseNo in rodata_outstock_d.warehouse_no%type, --仓别
                                       strOwnerNo     in rodata_outstock_d.owner_no%type,
                                       strOutStockNo  in rodata_outstock_d.outstock_no%type, --下架单号
                                       strUserID      in rodata_outstock_d.assign_name%type, --员工ID
                                       strOutMsg      out varchar2) --返回值
   is
  begin
    strOutMsg := 'N|[P_RO_UpdatedOutStockDirect]';

    update rodata_outstock_direct t
       set UPDT_DATE = SYSDATE, t.status = '13', t.updt_name = strUserID
     where t.enterprise_no=strEnterPriseNo and t.warehouse_no = strWarehouseNo
       and t.owner_no = strOwnerNo
       and t.status = '10'
       and t.DIRECT_SERIAL in
           (select d.divide_id
              from rodata_outstock_d d
             where d.enterprise_no=strEnterPriseNo and d.warehouse_no=strWarehouseNo and d.outstock_no = strOutStockNo);
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E25204]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_RO_UpdatedOutStockDirect;


  --将退货下架指示转历史
  procedure P_RO_InsertOutStockDirectHTY(strEnterPriseNo in rodata_outstock_d.enterprise_no%type,
                                       strWarehouseNo in rodata_outstock_d.warehouse_no%type, --仓别
                                       strOwnerNo     in rodata_outstock_d.owner_no%type,
                                       DivideId       in rodata_outstock_d.divide_id%type, --下架序列号
                                       strUserID      in rodata_outstock_d.assign_name%type, --员工ID
                                       strOutMsg      out varchar2) --返回值
   is
  begin
    strOutMsg := 'N|[P_RO_InsertOutStockDirectHTY]';


    insert into rodata_outstock_directhty(warehouse_no, owner_no,
    direct_serial, operate_date, source_no, operate_type,
    article_no, article_id, packing_qty, s_cell_no,
    s_cell_id, s_container_no, d_cell_no, d_cell_id,
    locate_qty, status, supplier_no, class_type, po_id,
    stock_type, stock_value, rgst_name, rgst_date,
    updt_name, updt_date, label_no, sub_label_no,
    wave_no, enterprise_no,label_pick_flag,
    locate_no,batch_no,device_no,dps_cell_no,recede_type)
    select warehouse_no, owner_no,
    direct_serial, operate_date, source_no, operate_type,
    article_no, article_id, packing_qty, s_cell_no,
    s_cell_id, s_container_no, d_cell_no, d_cell_id,
    locate_qty, status, supplier_no, class_type, po_id,
    stock_type, stock_value, rgst_name, rgst_date,
    updt_name, updt_date, label_no, sub_label_no,
    wave_no, enterprise_no,label_pick_flag,
    locate_no,batch_no,device_no,dps_cell_no,recede_type
    from rodata_outstock_direct
    where enterprise_no=strEnterPriseNo
    and warehouse_no=strWarehouseNo
    and direct_serial=DivideId;

    --删除该下架指示
    delete rodata_outstock_direct t where t.enterprise_no=strEnterPriseNo
      and t.warehouse_no=strWarehouseNo and t.direct_serial=DivideId
      and t.status='13';

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_RO_InsertOutStockDirectHTY;

  --更新退货单头档
  procedure P_RO_UpdateRecedeHeader(strEnterPriseNo in rodata_recede_m.enterprise_no%type,
                                    strWarehouseNo in rodata_recede_m.warehouse_no%type, --仓别
                                    strDeliverNo   in rodata_deliver_m.deliver_no%type, --下架单号
                                    strOwnerNo     in rodata_recede_m.owner_no%type,
                                    strUserId      in rodata_recede_m.rgst_name%type, --员工ID
                                    strStatus      in rodata_recede_m.status%type,
                                    strOutMsg      out varchar2) --返回值
   is
  begin
    strOutMsg := 'N|[P_RO_UpdateRecedeHeader]';

    ---更新退货单头档
    UPDATE rodata_recede_m OOM
       SET OOM.UPDT_DATE = SYSDATE,
           OOM.UPDT_NAME = strUserId,
           OOM.STATUS    = strStatus
     where oom.enterprise_no=strEnterPriseNo and oom.warehouse_no = strWarehouseNo
       and oom.recede_no in
           (select distinct d.recede_no
              from rodata_deliver_d d
             where d.enterprise_no=strEnterPriseNo and d.warehouse_no = strWarehouseNo
               and d.owner_no = strOwnerNo
               and d.deliver_no = strDeliverNo)
            and oom.recede_no not in (select source_no from rodata_outstock_direct
            where warehouse_no=strWarehouseNo and enterprise_no=strEnterPriseNo AND owner_no=strOwnerNo
            and status<'13')
            and oom.recede_no not in (select source_no from rodata_outstock_d
            where warehouse_no=strWarehouseNo and enterprise_no=strEnterPriseNo AND owner_no=strOwnerNo
            and status<'13')
            and oom.recede_no not in (select recede_no from rodata_recede_d
            where warehouse_no=strWarehouseNo and enterprise_no=strEnterPriseNo AND owner_no=strOwnerNo
            and status='10')
       and oom.owner_no = strOwnerNo;
    --and oom.status < 13;
/*    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E25402]';
      return;
    end if;*/

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_RO_UpdateRecedeHeader;

  --修改退货下架单头档
  procedure P_RO_UpdateOutStockHeader(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                                      strWarehouseNo in rodata_outstock_m.warehouse_no%type, --仓别
                                      strOutStockNo  in rodata_outstock_m.outstock_no%type, --下架单号
                                      strOwnerNo     in rodata_outstock_m.owner_no%type,
                                      strUserId      in rodata_outstock_m.rgst_name%type, --员工ID
                                      strOutMsg      out varchar2) --返回值
   is
  begin
    strOutMsg := 'N|[P_RO_UpdateOutStockHeader]';

    ---更新下架单头档
    UPDATE rodata_outstock_m OOM
       SET OOM.UPDT_DATE = SYSDATE,
           OOM.UPDT_NAME = strUserId,
           OOM.STATUS    = 13
     where oom.enterprise_no=strEnterPriseNo and oom.warehouse_no = strWarehouseNo
       and oom.outstock_no = strOutStockNo
       and oom.owner_no = strOwnerNo
       and oom.status < 13;
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E25202]';
      return;
    end if;

    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_RO_UpdateOutStockHeader;



  --更新退货下架明细
  /***************************************************************************************************88
  创建人：quzhihui
  功能说明：更新下架明细，会更新预计退货数量

  ***********************************************************************************************/
  procedure P_RO_UpdatedOutStockItem(strEnterPriseNo in rodata_outstock_d.enterprise_no%type,
                                     strWarehouseNo  in rodata_outstock_d.warehouse_no%type, --仓别
                                     strOutStockNo   in rodata_outstock_d.outstock_no%type, --下架单号
                                     nArticleQTY     in rodata_outstock_d.article_qty%type,
                                     nRealQty        in rodata_outstock_d.real_qty%type,
                                     strRealCellNo   in rodata_outstock_d.outstock_cell_no%type,
                                     strOwnerNo      in rodata_outstock_d.owner_no%type,
                                     nRowID          in rodata_outstock_d.Row_Id%type,
                                     strLabelNo      in rodata_outstock_d.label_no%type,
                                     strOutstockName in rodata_outstock_d.outstock_name%type, --出货员工ID
                                     strStatus       in rodata_outstock_d.status%type, --状态
                                     strOutMsg       out varchar2) is
  begin
    strOutMsg := 'N|[P_RO_UpdatedOutStockItem]';
    update rodata_outstock_d d
       set d.article_qty      = nArticleQTY,
           d.outstock_qty  =nRealQty,
           d.real_qty         = nRealQty,
           d.outstock_cell_no = strRealCellNo,
           d.outstock_name    = strOutstockName,
           d.outstock_date    = sysdate,
           d.status           = strStatus,
           d.label_no=strLabelNo,d.s_label_no=strLabelNo
     where d.enterprise_no=strEnterPriseNo and d.warehouse_no = strWarehouseNo
       and d.outstock_no = strOutStockNo
       and d.owner_no = strOwnerNo
       and d.row_id = nRowID;
  /*     and d.label_no=strLabelNo;*/
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E25203]';
      return;
    end if;
    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_RO_UpdatedOutStockItem;

  --更新退货下架明细
  /***************************************************************************************************88
  创建人：quzhihui
  功能说明：更新下架明细，只更新实际退货数量

  ***********************************************************************************************/
  procedure P_UpdatedRealQty(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                             strWarehouseNo  in rodata_outstock_d.warehouse_no%type, --仓别
                             strOutStockNo   in rodata_outstock_d.outstock_no%type, --下架单号
                             nArticleQTY     in rodata_outstock_d.article_qty%type,
                             nRealQty        in rodata_outstock_d.real_qty%type,
                             strRealCellNo   in rodata_outstock_d.outstock_cell_no%type,
                             strOwnerNo      in rodata_outstock_d.owner_no%type,
                             nRowId          in rodata_outstock_d.row_id%type,
                             strLabelNo      in rodata_outstock_d.label_no%type,
                             strOutstockName in rodata_outstock_d.outstock_name%type, --出货员工ID
                             strStatus       in rodata_outstock_d.status%type, --状态
                             strOutMsg       out varchar2) is
  begin
    strOutMsg := 'N|[P_UpdatedRealQty]';
    update rodata_outstock_d d
       set d.real_qty         = nRealQty,
           d.scan_name=strOutstockName
     where d.enterprise_no=strEnterPriseNo and d.warehouse_no = strWarehouseNo
       and d.outstock_no = strOutStockNo
       and d.owner_no = strOwnerNo
       and d.row_id = nRowId
       and d.label_no=strLabelNo;
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E25203]';
      return;
    end if;
    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_UpdatedRealQty;

  --退货下架单转历史
  procedure P_RO_UpdateOutStockHistory(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                                       strWarehouseNo in rodata_outstock_m.warehouse_no%type, --仓别
                                       strOutStockNo  in rodata_outstock_m.outstock_no%type, --下架单号
                                       strOwnerNo     in rodata_outstock_m.owner_no%type,
                                       strOutMsg      out varchar2) is

    iCount integer := 0;
  begin

    strOutMsg := 'N|[P_RO_UpdateOutStockHistory]';
    select count(1)
      into iCount
      from rodata_outstock_d d
     where d.enterprise_no=strEnterPriseNo and d.warehouse_no = strWarehouseNo
       and d.owner_no = strOwnerNo
       and d.outstock_no = strOutStockNo
       and d.status = '10';
    if iCount > 0 then
      strOutMsg := 'Y|';
      return;
    end if;

    insert into rodata_outstock_dhty
      (enterprise_no,warehouse_no,
       owner_no,
       outstock_no,
       divide_id,
       source_no,
       po_id,
       article_no,
       article_id,
       packing_qty,
       article_qty,
       real_qty,
       s_cell_no,
       s_cell_id,
       d_cell_no,
       d_cell_id,
       outstock_cell_no,
       outstock_cell_id,
       outstock_container_no,
       status,
       ASSIGN_NAME,
       outstock_name,
       outstock_date,
       STOCK_TYPE,
       STOCK_VALUE,row_id,s_label_no,LABEL_NO,sub_label_no,scan_date,outstock_qty,
       locate_no,batch_no,device_no,dps_cell_no)
      select enterprise_no,warehouse_no,
             owner_no,
             outstock_no,
             divide_id,
             source_no,
             po_id,
             article_no,
             article_id,
             packing_qty,
             article_qty,
             real_qty,
             s_cell_no,
             s_cell_id,
             d_cell_no,
             d_cell_id,
             outstock_cell_no,
             outstock_cell_id,
             outstock_container_no,
             status,
             ASSIGN_NAME,
             outstock_name,
             outstock_date,
             STOCK_TYPE,
             STOCK_VALUE,ROW_ID,s_label_no,LABEL_NO,sub_label_no,scan_date,outstock_qty,
             locate_no,batch_no,device_no,dps_cell_no
        from rodata_outstock_d
       where enterprise_no=strEnterPriseNo and warehouse_no = strWarehouseNo
         and owner_no = strOwnerNo
         and outstock_no = strOutStockNo;
    delete rodata_outstock_d
     where enterprise_no=strEnterPriseNo and warehouse_no = strWarehouseNo
       and owner_no = strOwnerNo
       and outstock_no = strOutStockNo;
    insert into rodata_outstock_mhty
      (enterprise_no,warehouse_no,
       owner_no,
       outstock_no,
       operate_date,
       operate_type,
       status,
       rgst_name,
       rgst_date,
       updt_name,
       updt_date,recede_type,task_type,class_type,
       --huangb 20160509
       REPORT_UP_SERIAL)
      select enterprise_no,warehouse_no,
             owner_no,
             outstock_no,
             operate_date,
             operate_type,
             status,
             rgst_name,
             rgst_date,
             updt_name,
             updt_date,recede_type,task_type,class_type,
             --huangb 20160509
             REPORT_UP_SERIAL
        from rodata_outstock_m
       where enterprise_no=strEnterPriseNo and warehouse_no = strWarehouseNo
         and owner_no = strOwnerNo
         and outstock_no = strOutStockNo;
    delete rodata_outstock_m
     where enterprise_no=strEnterPriseNo and warehouse_no = strWarehouseNo
       and owner_no = strOwnerNo
       and outstock_no = strOutStockNo;
    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_RO_UpdateOutStockHistory;
  /*************************************************************************************8
  功能说明：根据写退货箱头档
  2015.7.23

  **************************************************************************************/
  procedure P_InsertRodataBoxM(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                                    strWarehouseNo in rodata_outstock_m.warehouse_no%type, --仓别
                                    strOwnerNo     in rodata_outstock_m.owner_no%type,
                                    strLabelNo     in rodata_box_m.label_no%type,
                                    strRecedeNo    in rodata_box_m.recede_no%type,
                                    strOwnerCellNo in rodata_box_m.owner_cell_no%type,
                                    strUserID      in rodata_deliver_m.rgst_name%type,
                                    strStatus      in rodata_deliver_m.status%type,
                                    strOutMsg      out varchar2) is
  begin
       strOutMsg:='N|[P_InsertRodataBoxM]';

       insert into rodata_box_m(enterprise_no,warehouse_no,owner_no,label_no,
              status,recede_no,rgst_name,rgst_date,owner_cell_no)
           values(strEnterPriseNo,strWarehouseNo,strOwnerNo,strLabelNo,
              '0',strRecedeNo,strUserID,sysdate,strOwnerCellNo);
        if sql%rowcount <= 0 then
          strOutMsg := 'N|[P_InsertRodataBoxM]';
          return;
        end if;

       strOutMsg:='Y|[]';
  end P_InsertRodataBoxM;

  /*************************************************************************************8
  功能说明：根据写退货箱明细
  2015.7.23

  **************************************************************************************/
  procedure P_InsertRodataBoxItem(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                                    strWarehouseNo in rodata_outstock_m.warehouse_no%type, --仓别
                                    strOwnerNo     in rodata_outstock_m.owner_no%type,
                                    strOutstockNo  in rodata_outstock_d.outstock_no%type,
                                    strLabelNo     in rodata_box_m.label_no%type,
                                    strRecedeNo    in rodata_box_m.recede_no%type,
                                    strUserID      in rodata_deliver_m.rgst_name%type,
                                    strStatus      in rodata_deliver_m.status%type,
                                    strOutMsg      out varchar2)is
  begin
       strOutMsg:='N|[P_InsertRodataBoxItem]';
       insert into rodata_box_d(enterprise_no,warehouse_no,owner_no,Label_No,Row_Id,status,
              outstock_no,recede_no,po_id,article_no,article_id,article_qty,
              sub_label_no,rgst_name,rgst_date,packing_qty)
          select ood.enterprise_no,ood.warehouse_no,ood.owner_no,
          case when ood.label_no='N' then outstock_no else ood.label_no end as label_no,
          rownum,'0',
          ood.outstock_no,ood.source_no,ood.po_id,ood.article_no,ood.article_id,sum(ood.real_qty),
          case when ood.sub_label_no='N' then outstock_no else ood.sub_label_no end as sub_label_no,
          strUserID,sysdate,ood.packing_qty
          from rodata_outstock_d ood where ood.enterprise_no=strEnterPriseNo
          and ood.warehouse_no=strWarehouseNo and ood.outstock_no=strOutstockNo
          and ood.label_no=strLabelNo and ood.real_qty>0
          group by ood.enterprise_no,ood.warehouse_no,ood.owner_no,ood.label_no,rownum,
              ood.outstock_no,ood.source_no,ood.po_id,ood.article_no,ood.article_id,ood.packing_qty,
              ood.sub_label_no;

        if sql%rowcount <= 0 then
          strOutMsg := 'N|[P_InsertRodataBoxItem]';
          return;
        end if;

       strOutMsg:='Y|[]';
  end P_InsertRodataBoxItem;

  /*********************************************************************************************
  功能说明：1、新增或更新退货箱明细
         2015.8.13

  **********************************************************************************************/
  procedure P_updateInsertBoxItem(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                                    strWarehouseNo in rodata_outstock_m.warehouse_no%type, --仓别
                                    strOwnerNo     in rodata_outstock_m.owner_no%type,
                                    strOutstockNo  in rodata_outstock_d.outstock_no%type,
                                    strLabelNo     in rodata_box_m.label_no%type,
                                    strRecedeNo    in rodata_box_m.recede_no%type,
                                    nRowID         in rodata_box_d.row_id%type,
                                    strArticleNo   in rodata_box_d.article_no%type,
                                    nArticleId     in rodata_box_d.article_id%type,
                                    nPackingQty    in rodata_box_d.packing_qty%type,
                                    nPoId          in rodata_box_d.po_id%type,
                                    nRealQty       in rodata_box_d.article_qty%type,
                                    strUserID      in rodata_deliver_m.rgst_name%type,
                                    strStatus      in rodata_deliver_m.status%type,
                                    strOutMsg      out varchar2)is
     v_nRowid                       integer;
  begin
       strOutMsg:='N|[P_updateInsertBoxItem]';
       update rodata_box_d t set t.article_qty=t.article_qty+nRealQty
              where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWarehouseNo
              and t.recede_no=strRecedeNo and t.label_no=strLabelNo
              and t.row_id=nRowID and t.article_qty+nRealQty>=0;

       if sql%rowcount <= 0 then
          --获取最大的row_id
          select nvl(max(t.row_id),0)+1 into v_nRowid from rodata_box_d t
          where t.enterprise_no=strEnterPriseNo and t.Warehouse_No=strWarehouseNo
          and t.owner_no=strOwnerNo AND T.Label_No=strLabelNo
          and t.recede_no=strRecedeNo;

          insert into rodata_box_d(enterprise_no,warehouse_no,owner_no,Label_No,Row_Id,
              outstock_no,recede_no,po_id,article_no,article_id,article_qty,
              sub_label_no,rgst_name,rgst_date,packing_qty)
            values(strEnterPriseNo,strWarehouseNo,strOwnerNo,strLabelNo,v_nRowid,
              strOutstockNo,strRecedeNo,nPoId,strArticleNo,nArticleId,nRealQty,
              strLabelNo,strUserID,sysdate,nPackingQty);

       end if;

       --删除数量为0的数据
       delete from rodata_box_d t where t.enterprise_no=strEnterPriseNo
              and t.warehouse_no=strWarehouseNo and t.label_no=strLabelNo
              and t.article_Qty=0;


       strOutMsg:='Y|[]';
  end P_updateInsertBoxItem;

  /*********************************************************************************************
  功能说明：1、新增或更新退货箱明细
         2015.8.13

  **********************************************************************************************/
  procedure P_DeleteBoxHead(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                            strWarehouseNo in rodata_outstock_m.warehouse_no%type, --仓别
                            strOwnerNo     in rodata_outstock_m.owner_no%type,
                            strLabelNo     in rodata_box_m.label_no%type,
                            strOutMsg      out varchar2)is
     v_iCount               integer;
  begin
       strOutMsg:='N|[P_DeleteBoxHead]';

       --判断明细是否有数据
       select count(*) into v_iCount from rodata_box_d t where t.enterprise_no=strEnterPriseNo
              and t.warehouse_no=strWarehouseNo and t.label_no=strLabelNo;
       if v_iCount=0 then
          --删除标签头档数据
          delete from rodata_box_m t  where t.enterprise_no=strEnterPriseNo
              and t.warehouse_no=strWarehouseNo and t.label_no=strLabelNo;
       end if;

       strOutMsg:='Y';

  end P_DeleteBoxHead;


  /*********************************************************************************************
  功能说明：1、写标签整理日志
         2015.8.13

  **********************************************************************************************/
  procedure P_InsertLabelMoveLog(strEnterPriseNo in rodata_box_m.enterprise_no%type,
                            strWarehouseNo in rodata_box_m.warehouse_no%type, --仓别
                            strOwnerNo     in rodata_box_m.owner_no%type,
                            strRecedeNo    in rodata_box_m.recede_no%type,
                            strsLabelNo    in rodata_box_m.label_no%type,--来源标签
                            strdLabelNo    in rodata_box_m.label_no%type,--目的标签
                            strArticleNo   in rodata_box_d.article_no%type,
                            nPackingQty    in rodata_box_d.packing_qty%type,
                            nQty           in rodata_box_d.article_qty%type,
                            dtProduceDate  in stock_article_info.produce_date%type,
                            dtExpireDate   in stock_article_info.expire_date%type,
                            strQuality     in stock_article_info.quality%type,
                            strLotNo       in stock_article_info.lot_no%type,
                            strsCellNo     in stock_content.cell_no%type,
                            strdCellNo     in stock_content.cell_no%type,
                            strUserId      in bdef_defworker.worker_no%type,
                            strArrangeType in stock_label_arrange_log.arrange_type%type,--0：上架整理，1：过季转应季整理，2：应季转过季打包（库存录标签），3：退厂打包';
                            strOutMsg      out varchar2)is
     v_nRowId               integer;
  begin
       strOutMsg:='N|[P_InsertLabelMoveLog]';

       --获取序号
       select nvl(max(row_id),0)+1 into v_nRowId from stock_label_arrange_log
       where enterprise_no=strEnterPriseNo and warehouse_no=strWarehouseNo
       and owner_no=strOwnerNo and source_no=strRecedeNo and s_label_no=strsLabelNo
       and label_no=strdLabelNo;

       insert into stock_label_arrange_log(enterprise_no,warehouse_no,owner_no,source_no,
              s_label_no,label_no,row_id,article_no,packing_qty,qty,produce_date,
              expire_date,quality,lot_no,s_cell_no,d_cell_no,rgst_name,rgst_date,arrange_type)
          values(strEnterPriseNo,strWarehouseNo,strOwnerNo,strRecedeNo,
             strsLabelNo,strdLabelNo,v_nRowId,strArticleNo,nPackingQty,nQty,dtProduceDate,
             dtExpireDate,strQuality,strLotNo,strsCellNo,strdCellNo,strUserId,sysdate,strArrangeType);

       strOutMsg:='Y|[]';
  end P_InsertLabelMoveLog;


  --写退货清单头档
  procedure P_RO_WriteWmDeliverHead(strEnterPriseNo in rodata_outstock_m.enterprise_no%type,
                                    strWarehouseNo in rodata_outstock_m.warehouse_no%type, --仓别
                                    strOwnerNo     in rodata_outstock_m.owner_no%type,
                                    strDeliverNo   in rodata_deliver_m.deliver_no%type,
                                    strUserID      in rodata_deliver_m.rgst_name%type,
                                    strStatus      in rodata_deliver_m.status%type,
                                    strOutMsg      out varchar2) is
  begin
    strOutMsg := 'N|[P_RO_WriteWmDeliverHead]';
    insert into rodata_deliver_m
      (enterprise_no,warehouse_no,
       owner_no,
       deliver_no,
       operate_date,
       status,
       send_flag,
       recede_people,
       rgst_name,
       rgst_date)
    values
      (strEnterPriseNo,strWarehouseNo,
       strOwnerNo,
       strDeliverNo,
       trunc(sysdate),
       strStatus,
       '10',
       'N',
       strUserID,
       sysdate);
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E25403]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_RO_WriteWmDeliverHead;

  --写退货清单明细
  procedure P_RO_WriteWmDeliverItem(strEnterPriseNo in rodata_deliver_d.enterprise_no%type,
                                    strWarehouseNo in rodata_deliver_d.warehouse_no%type, --仓别
                                    strOwnerNo     in rodata_deliver_d.owner_no%type,
                                    strDeliverNo   in rodata_deliver_d.deliver_no%type,
                                    strRECEDE_NO   in rodata_deliver_d.recede_no%type,
                                    nPO_ID         in rodata_deliver_d.po_id%type,
                                    strARTICLE_NO  in rodata_deliver_d.article_no%type,
                                    nARTICLE_ID    in rodata_deliver_d.article_id%type,
                                    nPACKING_QTY   in rodata_deliver_d.packing_qty%type,
                                    nARTICLE_QTY   in rodata_deliver_d.article_qty%type,
                                    nRealQTY       in rodata_deliver_d.real_qty%type,
                                    strCELL_NO     in rodata_deliver_d.cell_no%type,
                                    strLabelNo     in rodata_deliver_d.label_no%type,
                                    strSubLabelNo  in rodata_deliver_d.sub_label_no%type,
                                    strRECEDE_NAME in rodata_deliver_d.recede_name%type,
                                    strOutMsg      out varchar2) is
  begin
    strOutMsg := 'N|[P_RO_WriteWmDeliverItem]';
    insert into rodata_deliver_d
      (enterprise_no,warehouse_no,
       owner_no,
       deliver_no,
       recede_no,
       po_id,
       article_no,
       article_id,
       barcode,
       packing_qty,
       lot_no,
       produce_date,
       expire_date,
       quality,
       import_batch_no,
       article_qty,
       real_qty,
       cell_no,
       recede_name,
       recede_date,
       label_no,sub_label_no,rsv_batch1,rsv_batch2,rsv_batch3,rsv_batch4,
       rsv_batch5,rsv_batch6,rsv_batch7,rsv_batch8)
      select strEnterPriseNo,strWarehouseNo,
             strOwnerNo,
             strDeliverNo,
             strRECEDE_NO,
             nPO_ID,
             strARTICLE_NO,
             nARTICLE_ID,
             sai.barcode,
             nPACKING_QTY,
             sai.lot_no,
             sai.produce_date,
             sai.expire_date,
             sai.quality,
             sai.import_batch_no,
             nARTICLE_QTY,
             nRealQTY,
             strCELL_NO,
             strRECEDE_NAME,
             trunc(sysdate),
             strLabelNo,strSubLabelNo,sai.rsv_batch1,sai.rsv_batch2,sai.rsv_batch3,sai.rsv_batch4,
             sai.rsv_batch5,sai.rsv_batch6,sai.rsv_batch7,sai.rsv_batch8
        from stock_article_info sai
       where sai.enterprise_no=strEnterPriseNo and sai.article_no = strARTICLE_NO
         and sai.article_id = nARTICLE_ID;
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E25404]';
      return;
    end if;
    strOutMsg := 'Y';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_RO_WriteWmDeliverItem;

  --更新退货下架明细
  /*******************************************************************************************************
  创建人：luozhiling
  创建时间：2014.11.19
  功能说明：更新退货下架明细的outstock_qty为拣货下架数量，并且更新下架单状态，用于下架完成后再扫描打包的流程
  ********************************************************************************************************/
  procedure P_RO_UpdateOutstockQty(strEnterPriseNo in rodata_outstock_d.enterprise_no%type,
                                   strWarehouseNo  in rodata_outstock_d.warehouse_no%type, --仓别
                                   strOutStockNo   in rodata_outstock_d.outstock_no%type, --下架单号
                                   nRealQty        in rodata_outstock_d.real_qty%type,
                                   strRealCellNo   in rodata_outstock_d.outstock_cell_no%type,
                                   strOwnerNo      in rodata_outstock_d.owner_no%type,
                                   nRowId          in rodata_outstock_d.row_id%type,
                                   strOutstockName in rodata_outstock_d.outstock_name%type, --出货员工ID
                                   strOutMsg       out varchar2) is
  begin
    strOutMsg := 'N|[P_RO_UpdateOutstockQty]';
    update rodata_outstock_d d
       set d.outstock_qty  =nRealQty,
           d.outstock_cell_no = strRealCellNo,
           d.outstock_name    = strOutstockName,
           d.outstock_date    = sysdate,
           d.status           = '11'
     where d.enterprise_no=strEnterPriseNo and d.warehouse_no = strWarehouseNo
       and d.outstock_no = strOutStockNo
       and d.owner_no = strOwnerNo
       and d.row_id = nRowId;
    if sql%rowcount <= 0 then
      strOutMsg := 'N|[E25203]';
      return;
    end if;
    strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
      return;
  end P_RO_UpdateOutstockQty;


  /*******************************************************************************************************
  创建人：hekl
  创建时间：2015.08.11
  功能说明：将退货标签头档转历史，按整单转历史
  ********************************************************************************************************/
  procedure P_RO_InsertBoxMHTY(strEnterPriseNo in rodata_outstock_d.enterprise_no%type,
                               strWarehouseNo  in rodata_outstock_d.warehouse_no%type, --仓别
                               strOwnerNo      in rodata_outstock_m.owner_no%type,
                               strRecedeNo    in rodata_outstock_d.source_no%type,--退货单号
                               strUserID      in rodata_box_d.label_no%type,
                               strOutMsg       out varchar2) is
  begin
    strOutMsg := 'N|[P_RO_InsertBoxMHTY]';

    insert into rodata_box_mhty(enterprise_no, warehouse_no,
      owner_no, label_no, status, recede_no, rgst_name,
      rgst_date, updt_name, updt_date,owner_cell_no,
      --huangb 20160509
      REPORT_UP_SERIAL)
    select de.enterprise_no,de.warehouse_no,de.owner_no,
      de.label_no,de.status,de.recede_no,de.rgst_name,
      de.rgst_date,de.updt_name,de.updt_date,de.owner_cell_no,
      --huangb 20160509
      REPORT_UP_SERIAL
    from rodata_box_m de
      where de.enterprise_no=strEnterPriseNo
      and de.warehouse_no=strWarehouseNo and de.recede_no=strRecedeNo;

    delete rodata_box_m where enterprise_no=strEnterPriseNo and warehouse_no=strWarehouseNo
      and label_no in (select de.label_no from rodata_box_m de
      where de.enterprise_no=strEnterPriseNo
      and de.warehouse_no=strWarehouseNo and de.recede_no=strRecedeNo) and status in('1','9');

    strOutMsg := 'Y|';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
            substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end P_RO_InsertBoxMHTY;


  /*******************************************************************************************************
  创建人：hekl
  创建时间：2015.08.11
  功能说明：将退货标签明细转历史,按整张退货单转历史
  ********************************************************************************************************/
  procedure P_RO_InsertBoxDHTY(strEnterPriseNo in rodata_outstock_d.enterprise_no%type,
                                   strWarehouseNo  in rodata_outstock_d.warehouse_no%type, --仓别
                                   strRecedeNo    in rodata_outstock_d.source_no%type,--退货单号
                                   strOutMsg       out varchar2) is
  begin
    strOutMsg := 'N|[P_RO_InsertBoxDHTY]';

    insert into rodata_box_dhty(enterprise_no, warehouse_no,
      owner_no, label_no, outstock_no, row_id, status, recede_no,
      po_id, article_no, article_id, packing_qty, article_qty,
      sub_label_no, rgst_name, rgst_date, updt_name, updt_date)
    select enterprise_no, warehouse_no,
      owner_no, label_no, outstock_no, row_id, status, recede_no,
      po_id, article_no, article_id, packing_qty, article_qty,
      sub_label_no, rgst_name, rgst_date, updt_name, updt_date from rodata_box_d
    where enterprise_no=strEnterPriseNo and warehouse_no=strWarehouseNo
      and recede_no=strRecedeNo;

    delete rodata_box_d where enterprise_no=strEnterPriseNo and warehouse_no=strWarehouseNo
      and recede_no=strRecedeNo and status in('1','9');


    strOutMsg := 'Y|';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
            substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end P_RO_InsertBoxDHTY;


  /*******************************************************************************************************
  创建人：hekl
  创建时间：2015.08.11
  功能说明：将退货标签头档转历史，按标签转历史
  ********************************************************************************************************/
  procedure P_ForLabelInsertBoxMHTY(strEnterPriseNo in rodata_outstock_d.enterprise_no%type,
                               strWarehouseNo  in rodata_outstock_d.warehouse_no%type, --仓别
                               strOwnerNo      in rodata_outstock_m.owner_no%type,
                               strLableNo    in rodata_outstock_d.label_no%type,--退货单号
                               strUserID      in rodata_box_d.label_no%type,
                               strOutMsg       out varchar2) is
  begin
    strOutMsg := 'N|[P_ForLabelInsertBoxMHTY]';

    insert into rodata_box_mhty(enterprise_no, warehouse_no,
      owner_no, label_no, status, recede_no, rgst_name,
      rgst_date, updt_name, updt_date,owner_cell_no,
      --huangb 20160509
      REPORT_UP_SERIAL)
    select de.enterprise_no,de.warehouse_no,de.owner_no,
      de.label_no,de.status,de.recede_no,de.rgst_name,
      de.rgst_date,de.updt_name,de.updt_date,de.owner_cell_no,
      --huangb 20160509
      REPORT_UP_SERIAL
    from rodata_box_m de
      where de.enterprise_no=strEnterPriseNo
      and de.warehouse_no=strWarehouseNo and de.label_no=strLableNo;

    delete rodata_box_m where enterprise_no=strEnterPriseNo and warehouse_no=strWarehouseNo
      and label_no =strLableNo;

    strOutMsg := 'Y|';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
            substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end P_ForLabelInsertBoxMHTY;


  /*******************************************************************************************************
  创建人：hekl
  创建时间：2015.08.11
  功能说明：将退货标签明细转历史,按标签转历史
  ********************************************************************************************************/
  procedure P_ForLabelInsertBoxDHTY(strEnterPriseNo in rodata_outstock_d.enterprise_no%type,
                                   strWarehouseNo  in rodata_outstock_d.warehouse_no%type, --仓别
                                   strLabelNo    in rodata_outstock_d.label_no%type,--标签号
                                   strOutMsg       out varchar2) is
  begin
    strOutMsg := 'N|[P_ForLabelInsertBoxDHTY]';

    insert into rodata_box_dhty(enterprise_no, warehouse_no,
      owner_no, label_no, outstock_no, row_id, status, recede_no,
      po_id, article_no, article_id, packing_qty, article_qty,
      sub_label_no, rgst_name, rgst_date, updt_name, updt_date)
    select enterprise_no, warehouse_no,
      owner_no, label_no, outstock_no, row_id, status, recede_no,
      po_id, article_no, article_id, packing_qty, article_qty,
      sub_label_no, rgst_name, rgst_date, updt_name, updt_date from rodata_box_d
    where enterprise_no=strEnterPriseNo and warehouse_no=strWarehouseNo
      and label_no=strLabelNo;

    delete rodata_box_d where enterprise_no=strEnterPriseNo and warehouse_no=strWarehouseNo
      and label_no=strLabelNo;


    strOutMsg := 'Y|';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
            substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end P_ForLabelInsertBoxDHTY;

  /*******************************************************************************************************
  创建人：huangb
  创建时间：2016.05.16
  功能说明：退厂单据转历史
  ********************************************************************************************************/
  procedure P_RO_InsertHTY(strEnterPriseNo in rodata_deliver_mhty.enterprise_no%type,
                           strWarehouseNo  in rodata_deliver_mhty.warehouse_no%type, --仓别
                           strOwnerNo      in rodata_deliver_mhty.owner_no%type,
                           strDeliverNo    in rodata_deliver_mhty.deliver_no%type, --预制退货单号
                           strUserID       in rodata_deliver_mhty.rgst_name%type,
                           strOutMsg       out varchar2) is
  begin
   strOutMsg := 'N|[P_RO_InsertHTY]';
   --退厂单明细转历史
   insert into rodata_recede_dhty
     (warehouse_no, owner_no, recede_no, owner_article_no, article_no, packing_qty, lot_no, quality
     , produce_date, expire_date, recede_qty, outstock_qty, real_qty, po_id, unit_cost, recede_des, error_status
     , budget_qty, enterprise_no, cell_no, locate_qty, status, ref_recede_qty)
   select rrd.warehouse_no, rrd.owner_no, rrd.recede_no, rrd.owner_article_no, rrd.article_no, rrd.packing_qty, rrd.lot_no, rrd.quality
     , rrd.produce_date, rrd.expire_date, rrd.recede_qty, rrd.outstock_qty, rrd.real_qty, rrd.po_id, rrd.unit_cost, rrd.recede_des, rrd.error_status
     , rrd.budget_qty, rrd.enterprise_no, rrd.cell_no, rrd.locate_qty, rrd.status, rrd.ref_recede_qty
   from rodata_recede_d rrd,rodata_recede_m rrm
   where rrd.enterprise_no = rrm.enterprise_no
     and rrd.warehouse_no = rrm.warehouse_no
     and rrd.owner_no = rrm.owner_no
     and rrd.recede_no = rrm.recede_no
     and rrm.status in ('13', '16')
     and rrm.enterprise_no = strEnterPriseNo
     and rrm.warehouse_no = strWarehouseNo
     and rrm.owner_no = strOwnerNo
     and rrm.recede_no in
         (select rdd.recede_no
            from rodata_deliver_d rdd
           where rdd.enterprise_no = strEnterPriseNo
             and rdd.warehouse_no = strWarehouseNo
             and rdd.owner_no = strOwnerNo
             and rdd.deliver_no = strDeliverNo);

   --退厂单头档转历史
   insert into rodata_recede_mhty
     (warehouse_no, owner_no, recede_type, recede_no, po_type, po_no, supplier_no, class_type, untread_no
     , recede_date, status, create_flag, error_status, send_flag, stock_type, stock_value, quality, recede_remark
     , request_date, dept_no, rgst_name, rgst_date, updt_name, updt_date, wave_no, enterprise_no, org_no
     , locate_times, take_type, rsv_varod1, rsv_varod2, rsv_varod3, rsv_varod4, rsv_varod5, rsv_varod6, rsv_varod7
     , rsv_varod8, rsv_num1, rsv_num2, rsv_num3, rsv_date1, rsv_date2, rsv_date3, report_up_serial,GROSS_WEIGHT)
   select rrm.warehouse_no, rrm.owner_no, rrm.recede_type, rrm.recede_no, rrm.po_type, rrm.po_no, rrm.supplier_no, rrm.class_type, rrm.untread_no
     , rrm.recede_date, rrm.status, rrm.create_flag, rrm.error_status, rrm.send_flag, rrm.stock_type, rrm.stock_value, rrm.quality, rrm.recede_remark
     , rrm.request_date, rrm.dept_no, rrm.rgst_name, rrm.rgst_date, strUserID, sysdate, rrm.wave_no, rrm.enterprise_no, rrm.org_no
     , rrm.locate_times, rrm.take_type, rrm.rsv_varod1, rrm.rsv_varod2, rrm.rsv_varod3, rrm.rsv_varod4, rrm.rsv_varod5, rrm.rsv_varod6, rrm.rsv_varod7
     , rrm.rsv_varod8, rrm.rsv_num1, rrm.rsv_num2, rrm.rsv_num3, rrm.rsv_date1, rrm.rsv_date2, rrm.rsv_date3, rrm.report_up_serial,rrm.gross_weight
   from rodata_recede_m rrm
   where rrm.status in ('13', '16')
     and rrm.enterprise_no = strEnterPriseNo
     and rrm.warehouse_no = strWarehouseNo
     and rrm.owner_no = strOwnerNo
     and rrm.recede_no in
         (select rdd.recede_no
            from rodata_deliver_d rdd
           where rdd.enterprise_no = strEnterPriseNo
             and rdd.warehouse_no = strWarehouseNo
             and rdd.owner_no = strOwnerNo
             and rdd.deliver_no = strDeliverNo);

   --退厂下架单头档转历史
   insert into rodata_outstock_mhty
     (warehouse_no, owner_no, outstock_no, operate_date, operate_type, status, rgst_name, rgst_date, updt_name
     , updt_date, task_type, enterprise_no, class_type, recede_type, report_up_serial)
   select rom.warehouse_no, rom.owner_no, rom.outstock_no, rom.operate_date, rom.operate_type, rom.status, rom.rgst_name, rom.rgst_date, strUserID
     , sysdate, rom.task_type, rom.enterprise_no, rom.class_type, rom.recede_type, rom.report_up_serial
   from rodata_outstock_m rom,rodata_outstock_d rod
   where rom.enterprise_no = rod.enterprise_no
     and rom.warehouse_no = rod.warehouse_no
     and rom.owner_no = rod.owner_no
     and rom.outstock_no = rod.outstock_no
     and rom.status in ('13', '16')
     and rom.enterprise_no = strEnterPriseNo
     and rom.warehouse_no = strWarehouseNo
     and rom.owner_no = strOwnerNo
     and rod.source_no in
         (select rdd.recede_no
            from rodata_deliver_d rdd
           where rdd.enterprise_no = strEnterPriseNo
             and rdd.warehouse_no = strWarehouseNo
             and rdd.owner_no = strOwnerNo
             and rdd.deliver_no = strDeliverNo);

   --退厂下架单明细转历史
   insert into rodata_outstock_dhty
     (warehouse_no, owner_no, outstock_no, divide_id, source_no, po_id, article_no, article_id, packing_qty
     , article_qty, real_qty, s_cell_no, s_cell_id, s_label_no, d_cell_no, d_cell_id, outstock_cell_no, outstock_cell_id
     , outstock_container_no, status, assign_name, outstock_name, outstock_date, stock_type, stock_value, scan_name, outstock_qty
     , scan_date, label_no, sub_label_no, wave_no, enterprise_no, row_id, locate_no, batch_no, device_no, dps_cell_no)
   select rod.warehouse_no, rod.owner_no, rod.outstock_no, rod.divide_id, rod.source_no, rod.po_id, rod.article_no, rod.article_id, rod.packing_qty
     , rod.article_qty, rod.real_qty, rod.s_cell_no, rod.s_cell_id, rod.s_label_no, rod.d_cell_no, rod.d_cell_id, rod.outstock_cell_no, rod.outstock_cell_id
     , rod.outstock_container_no, rod.status, rod.assign_name, rod.outstock_name, rod.outstock_date, rod.stock_type, rod.stock_value, rod.scan_name, rod.outstock_qty
     , rod.scan_date, rod.label_no, rod.sub_label_no, rod.wave_no, rod.enterprise_no, rod.row_id, rod.locate_no, rod.batch_no, rod.device_no, rod.dps_cell_no
   from rodata_outstock_d rod
   where rod.enterprise_no = strEnterPriseNo
     and rod.warehouse_no = strWarehouseNo
     and rod.owner_no = strOwnerNo
     and rod.status in ('13', '16')
     and rod.source_no in
         (select rdd.recede_no
            from rodata_deliver_d rdd
           where rdd.enterprise_no = strEnterPriseNo
             and rdd.warehouse_no = strWarehouseNo
             and rdd.owner_no = strOwnerNo
             and rdd.deliver_no = strDeliverNo);

   --退厂预制集单明细转历史
   insert into rodata_deliver_dhty
     (warehouse_no, owner_no, deliver_no, recede_no, po_id, article_no, article_id, barcode, packing_qty
     , lot_no, produce_date, expire_date, quality, import_batch_no, article_qty, real_qty, cell_no, recede_name
     , recede_date, enterprise_no, label_no, sub_label_no, rsv_batch1, rsv_batch2, rsv_batch3, rsv_batch4, rsv_batch5
     , rsv_batch6, rsv_batch7, rsv_batch8)
   select rdd.warehouse_no, rdd.owner_no, rdd.deliver_no, rdd.recede_no, rdd.po_id, rdd.article_no, rdd.article_id, rdd.barcode, rdd.packing_qty
     , rdd.lot_no, rdd.produce_date, rdd.expire_date, rdd.quality, rdd.import_batch_no, rdd.article_qty, rdd.real_qty, rdd.cell_no, rdd.recede_name
     , rdd.recede_date, rdd.enterprise_no, rdd.label_no, rdd.sub_label_no, rdd.rsv_batch1, rdd.rsv_batch2, rdd.rsv_batch3, rdd.rsv_batch4, rdd.rsv_batch5
     , rdd.rsv_batch6, rdd.rsv_batch7, rdd.rsv_batch8
   from rodata_deliver_d rdd
   where rdd.enterprise_no = strEnterPriseNo
     and rdd.warehouse_no = strWarehouseNo
     and rdd.owner_no = strOwnerNo
     and rdd.deliver_no = strDeliverNo;

   --退厂预制集单头档转历史
   insert into rodata_deliver_mhty
     (warehouse_no, owner_no, deliver_no, operate_date, status, send_flag, total_volumn, recede_people, rgst_name
     , rgst_date, updt_name, updt_date, enterprise_no, report_up_serial)
   select rdm.warehouse_no, rdm.owner_no, rdm.deliver_no, rdm.operate_date, rdm.status, rdm.send_flag, rdm.total_volumn, rdm.recede_people, rdm.rgst_name
     , rdm.rgst_date, strUserID, sysdate, rdm.enterprise_no, rdm.report_up_serial
   from rodata_deliver_m rdm
   where rdm.enterprise_no = strEnterPriseNo
     and rdm.warehouse_no = strWarehouseNo
     and rdm.owner_no = strOwnerNo
     and rdm.deliver_no = strDeliverNo;

   --删除正表
   delete rodata_recede_d rrd
    where rrd.enterprise_no = strEnterPriseNo
      and rrd.warehouse_no = strWarehouseNo
      and rrd.owner_no = strOwnerNo
      and exists
          (select 'X' from rodata_recede_m rrm,rodata_deliver_d rdd
            where rdd.enterprise_no = rrm.enterprise_no
              and rdd.warehouse_no = rrm.warehouse_no
              and rdd.owner_no = rrm.owner_no
              and rdd.recede_no = rrm.recede_no
              and rrm.enterprise_no = rrd.enterprise_no
              and rrm.warehouse_no = rrd.warehouse_no
              and rrm.owner_no = rrd.owner_no
              and rrm.recede_no = rrd.recede_no
              and rdd.deliver_no = strDeliverNo
              and rrm.status in ('13', '16'));

   delete rodata_recede_m rrm
    where rrm.status in ('13', '16')
      and rrm.enterprise_no = strEnterPriseNo
      and rrm.warehouse_no = strWarehouseNo
      and rrm.owner_no = strOwnerNo
      and rrm.recede_no in
          (select rdd.recede_no
             from rodata_deliver_d rdd
            where rdd.enterprise_no = strEnterPriseNo
              and rdd.warehouse_no = strWarehouseNo
              and rdd.owner_no = strOwnerNo
              and rdd.deliver_no = strDeliverNo);

   delete rodata_outstock_m rom
    where rom.enterprise_no = strEnterPriseNo
      and rom.warehouse_no = strWarehouseNo
      and rom.owner_no = strOwnerNo
      and rom.status in ('13', '16')
      and exists
          (select 'X' from rodata_outstock_d rod,rodata_deliver_d rdd
            where rod.enterprise_no = rdd.enterprise_no
              and rod.warehouse_no = rdd.warehouse_no
              and rod.owner_no = rdd.owner_no
              and rod.source_no = rdd.recede_no
              and rom.enterprise_no = rod.enterprise_no
              and rom.warehouse_no = rod.warehouse_no
              and rom.owner_no = rod.owner_no
              and rom.outstock_no = rod.outstock_no
              and rdd.deliver_no = strDeliverNo);

   delete rodata_outstock_d rod
    where rod.enterprise_no = strEnterPriseNo
      and rod.warehouse_no = strWarehouseNo
      and rod.owner_no = strOwnerNo
      and rod.status in ('13', '16')
      and rod.source_no in
          (select rdd.recede_no
             from rodata_deliver_d rdd
            where rdd.enterprise_no = strEnterPriseNo
              and rdd.warehouse_no = strWarehouseNo
              and rdd.owner_no = strOwnerNo
              and rdd.deliver_no = strDeliverNo);

   delete rodata_deliver_d rdd
    where rdd.enterprise_no = strEnterPriseNo
      and rdd.warehouse_no = strWarehouseNo
      and rdd.owner_no = strOwnerNo
      and rdd.deliver_no = strDeliverNo;

   delete rodata_deliver_m rdm
    where rdm.enterprise_no = strEnterPriseNo
      and rdm.warehouse_no = strWarehouseNo
      and rdm.owner_no = strOwnerNo
      and rdm.deliver_no = strDeliverNo;

  strOutMsg := 'Y|';
  exception
    when others then
      strOutMsg := 'N|P_RO_InsertHTY' || SQLERRM ||
            substr(dbms_utility.format_error_backtrace, 1, 256);
      return;

  end P_RO_InsertHTY;

 end pkobj_rodata;

/

