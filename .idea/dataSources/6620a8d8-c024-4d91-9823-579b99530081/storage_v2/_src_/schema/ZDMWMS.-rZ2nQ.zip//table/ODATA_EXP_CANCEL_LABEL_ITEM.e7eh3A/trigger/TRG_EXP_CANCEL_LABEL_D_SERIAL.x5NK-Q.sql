create trigger TRG_EXP_CANCEL_LABEL_D_SERIAL
    before insert
    on ODATA_EXP_CANCEL_LABEL_ITEM
    for each row
declare
  i_report_up_SERIAL NUMBER;
begin
  select SEQ_EXP_CANCEL_LABEL_ITEM.NEXTVAL into i_report_up_SERIAL from dual;
  :NEW.REPORT_UP_SERIAL := i_report_up_SERIAL;
end TRG_EXP_CANCEL_LABEL_D_SERIAL;


/

