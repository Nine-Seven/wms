create trigger TRG_RIDATA_UNTREAD_SM_SERIAL
    before insert
    on RIDATA_UNTREAD_SM
    for each row
declare
  i_report_up_SERIAL NUMBER;
begin
  select SEQ_RIDATA_UNTREAD_SM.NEXTVAL into i_report_up_SERIAL from dual;
  :NEW.REPORT_UP_SERIAL := i_report_up_SERIAL;
end TRG_RIDATA_UNTREAD_SM_SERIAL;


/

