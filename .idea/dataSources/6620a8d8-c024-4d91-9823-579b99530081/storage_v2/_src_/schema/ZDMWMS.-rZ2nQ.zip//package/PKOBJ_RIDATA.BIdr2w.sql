create package        pkobj_Ridata is
   /**********************************************************************************************
   作者:hekl
   日期:  2015-04-07
   功能: 返配手建单对象：写汇总头档表
  ************************************************************************************************/
 procedure p_ridata_saveUntreadmm(
              strEnterpriseNo in ridata_untread_m.enterprise_no%type,
              strWareHouseNo in ridata_untread_m.warehouse_no%type,
              strUntreadNo in ridata_untread_m.untread_no%type,
              v_strQType   in ridata_untread_m.po_type%type ,
              v_strClassType in ridata_untread_m.class_type%type,
              v_strCust      in ridata_untread_m.cust_no%type,
              strSUntreadNo in ridata_untread_mm.s_untread_no%type,--返配汇总单
              v_strOwner    in ridata_untread_m.owner_no%type,
              v_strPoNo    in ridata_untread_m.po_no%type,
              v_strRgstName  in ridata_untread_m.rgst_name%type,
              strResult out varchar2
    );
  /**********************************************************************************************
   作者:hekl
   日期:  2015-04-07
   功能: 返配手建单对象：写汇总明细表
  ************************************************************************************************/
  procedure p_ridata_saveUntreadsm(
                           strEnterpriseNo in ridata_untread_m.enterprise_no%type,
                           strWareHouseNo in ridata_untread_m.warehouse_no%type,
                           strUntreadNo in ridata_untread_m.untread_no%type,
                           strSUntreadNo in ridata_untread_mm.s_untread_no%type,
                           strResult out varchar2
    );
  ---------------------------------进货单对象-------------------------------------------------------------
  /**********************************************************************************************
   作者:luozhiling
   日期:  2013-09-29
   功能: 返配单对象：写入临时板表
  ************************************************************************************************/
  procedure p_InsertPalTmp(strEnterPriseNo    in ridata_check_pal_tmp.enterprise_no%type,
                           strWAREHOUSE_NO    in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                           strOwner_No        in ridata_check_pal_tmp.owner_no%type, --委托业主编码
                           strsUntreadNo      in ridata_untread_sm.s_untread_no%type,
                           strS_Check_No      in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                           strArticle_No      in ridata_check_pal_tmp.article_no%type, --商品编码
                           strBarcode         in ridata_check_pal_tmp.barcode%type, --商品条码
                           strQuality         in  ridata_check_d.quality%type,--品质
                           dtProduceDate      in  ridata_check_d.produce_date%type,
                           dtExpireDate       in  Ridata_check_d.expire_date%type,
                           strLotNo           in  ridata_check_d.lot_no%type,--批次号
                           strRSV_BATCH1      in  ridata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                           strRSV_BATCH2      in  ridata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                           strRSV_BATCH3      in  ridata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                           strRSV_BATCH4      in  ridata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                           strRSV_BATCH5      in  ridata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                           strRSV_BATCH6      in  ridata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                           strRSV_BATCH7      in  ridata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                           strRSV_BATCH8      in  ridata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                           nPack_Qty          in ridata_check_pal_tmp.packing_qty%type, --包装数量
                           nCheck_Qty         in ridata_check_pal_tmp.check_qty%type, --验收数量
                           strLabel_No        in ridata_check_pal_tmp.label_no%type, --板号
                           strLabelId         in ridata_check_pal_tmp.label_id%type,
                           strBusiness_Type   in ridata_check_pal_tmp.business_type%type, --业务类型
                           strFixpal_Flag     in ridata_check_pal_tmp.fixpal_flag%type, --板类型
                           strPrintGroup      in ridata_check_pal_tmp.printer_group_no%type, --打印机组
                           strDock_No         in ridata_check_pal_tmp.dock_no%type, --码头
                           strStockType       in ridata_check_pal_tmp.stock_type%type, --存储类型
                           strStockValue      in ridata_check_pal_tmp.stock_value%type, --存储类型对应值
                           strSub_Label_No   in ridata_check_pal_tmp.sub_label_no%type, --尾箱标签
                           strWorker_No       in ridata_check_pal_tmp.rgst_name%type, --验收人员
                           strUntreadType     in ridata_check_pal_tmp.untread_type%type, --返配单别
                           strSupplierNo      in ridata_check_pal_tmp.supplier_no%type, --供应商
                           strCheck_Tools     in char, --检查工具 1:前台2:RF
                           strWaveNo          in ridata_check_pal_tmp.wave_no%type,
                           strBatchNo         in ridata_check_pal_tmp.batch_no%type,
                           strCellNo          in ridata_check_pal_tmp.cell_no%type,
                           strDeviceNo        in ridata_check_pal_tmp.device_no%type,
                           strQualityFlag     in ridata_check_pal_tmp.quality_flag%type,--品质类型0滞销品，1过季品，A质量问题，B次品
                           strClassType       in ridata_untread_mm.class_type%type,
                           nIsAdd             in integer, --是否累加 0:覆盖 1:累加
                           strResult          out varchar2);
  -----------------------------------【存储验收begin】---------------------------------------------------
  /**********************************************************************************************
   作者:luozhiling
   日期:  2015-10-20
   功能: 返配单对象：写入临时板表日志
  ************************************************************************************************/
  procedure p_InsertPalTmp_Log(strEnterPriseNo    in ridata_check_pal_tmp.enterprise_no%type,
                           strWAREHOUSE_NO    in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                           strOwner_No        in ridata_check_pal_tmp.owner_no%type, --委托业主编码
                           strsUntreadNo      in ridata_untread_sm.s_untread_no%type,
                           strS_Check_No      in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                           strArticle_No      in ridata_check_pal_tmp.article_no%type, --商品编码
                           strBarcode         in ridata_check_pal_tmp.barcode%type, --商品条码
                           strQuality         in  ridata_check_d.quality%type,--品质
                           dtProduceDate      in  ridata_check_d.produce_date%type,
                           dtExpireDate       in  Ridata_check_d.expire_date%type,
                           strLotNo           in  ridata_check_d.lot_no%type,--批次号
                           strRSV_BATCH1      in  ridata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                           strRSV_BATCH2      in  ridata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                           strRSV_BATCH3      in  ridata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                           strRSV_BATCH4      in  ridata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                           strRSV_BATCH5      in  ridata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                           strRSV_BATCH6      in  ridata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                           strRSV_BATCH7      in  ridata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                           strRSV_BATCH8      in  ridata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                           nPack_Qty          in ridata_check_pal_tmp.packing_qty%type, --包装数量
                           nCheck_Qty         in ridata_check_pal_tmp.check_qty%type, --验收数量
                           strLabel_No        in ridata_check_pal_tmp.label_no%type, --板号
                           strLabelId         in ridata_check_pal_tmp.label_id%type,
                           strBusiness_Type   in ridata_check_pal_tmp.business_type%type, --业务类型
                           strFixpal_Flag     in ridata_check_pal_tmp.fixpal_flag%type, --板类型
                           strPrintGroup      in ridata_check_pal_tmp.printer_group_no%type, --打印机组
                           strDock_No         in ridata_check_pal_tmp.dock_no%type, --码头
                           strStockType       in ridata_check_pal_tmp.stock_type%type, --存储类型
                           strStockValue      in ridata_check_pal_tmp.stock_value%type, --存储类型对应值
                           strSub_Label_No   in ridata_check_pal_tmp.sub_label_no%type, --尾箱标签
                           strWorker_No       in ridata_check_pal_tmp.rgst_name%type, --验收人员
                           strUntreadType     in ridata_check_pal_tmp.untread_type%type, --返配单别
                           strSupplierNo      in ridata_check_pal_tmp.supplier_no%type, --供应商
                           strCheck_Tools     in char, --检查工具 1:前台2:RF
                           strWaveNo          in ridata_check_pal_tmp.wave_no%type,
                           strBatchNo         in ridata_check_pal_tmp.batch_no%type,
                           strCellNo          in ridata_check_pal_tmp.cell_no%type,
                           strDeviceNo        in ridata_check_pal_tmp.device_no%type,
                           strQualityFlag     in ridata_check_pal_tmp.quality_flag%type,--品质类型0滞销品，1过季品，A质量问题，B次品
                           nIsAdd             in integer, --是否累加 0:覆盖 1:累加
                           strResult          out varchar2);
  ---2、通过临时板表写板明细、汇总单明细、进货汇总明细；
  -----------------------------------【存储验收begin】----------------------------------------------------------------------

  /*
   作者:luozhiling
   日期:  2013-10-02
   功能: 将临时板数据写入板明细、汇总进货明细、进货明细
  */
  procedure p_InsertCheckNo(strEnterPriseNo       in ridata_check_pal_tmp.enterprise_no%type,
                            strWareHouseNo        in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                            strOwnerNo            in ridata_check_pal_tmp.owner_no%type, --委托业主
                            strUntreadNo          in ridata_check_m.untread_no%type, --返配单号
                            strsCheckNo           in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                            strWorkerNo           in ridata_check_pal_tmp.rgst_name%type, --操作人
                            strLabelNo            in ridata_check_pal_tmp.label_no%type, --老板号
                            strNewLabelNo         in ridata_check_pal_tmp.label_no%type, --新板号
                            strContainNo          in ridata_check_pal.container_no%type, --内部容器号
                            intCheckQty           in ridata_check_pal_tmp.check_qty%type, --验收数量
                            intRowId              in ridata_check_pal_tmp.row_id%type, --临时板id
                            strResult             out varchar2);

  -------------------------------------------------------------进货单对象end----------------------------------------------------

  -----------------------------------------------------------验收对象begin-----------------------------------------------------
  -------1.锁定进货汇总单头档

  -------2、根据验收板明细写验收明细
  /*
   作者:luozhiling
   日期:  2013-10-04
   功能: 验收板明细写验收明细
  */

  procedure p_OverSkuInsertCheckNo(strEnterPriseNo in ridata_check_pal_tmp.enterprise_no%type,
                                   strWareHouseNo in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                                   strOwnerNo     in ridata_check_pal_tmp.owner_no%type, --委托业主
                                   strUntreadNo   in ridata_check_m.untread_no%type, --返配单号
                                   strsCheckNo    in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                                   strWorkerNo    in ridata_check_pal_tmp.rgst_name%type, --操作人
                                   strLabelNo     in ridata_check_pal_tmp.label_no%type, --老板号
                                   strNewLabelNo  in ridata_check_pal_tmp.label_no%type, --新板号
                                   strContainNo   in ridata_check_pal.container_no%type, --内部容器号
                                   intCheckQty    in ridata_check_pal_tmp.check_qty%type, --验收数量
                                   intRowId       in ridata_check_pal_tmp.row_id%type, --临时板id
                                   strResult      out varchar2);
  /***********************************************************************************************
   作者:luozhiling
   日期:  2013-10-04
   功能: 写返配验收单头档并返回汇总单号
  **************************************************************************************************/
  procedure p_InsertImCheckMaster(strEnterPriseNo        in ridata_check_m.enterprise_no%type,
                                  strWAREHOUSE_NO        in ridata_check_m.WAREHOUSE_NO%type, --仓库编码
                                  strOwnerNo             in ridata_check_m.owner_no%type, --委托业主编码
                                  strSImportNo           in ridata_untread_mm.s_untread_no%type, --返配汇总单号
                                  strDockNo              in ridata_check_m.dock_no%type, --码头号
                                  strWorkerNo            in ridata_check_m.check_worker%type, --操作人
                                  strPrintGroup          in ridata_check_m.printer_group_no%type, --打印机组
                                  strCheckTools          in ridata_check_m.check_tools%type, --验收工具
                                  strSCheckNo            out ridata_check_m.s_check_no%type, --汇总验收单号
                                  strResult              out varchar2);

  /*****************************************************************************************************

  Luozhiling
  2013-10-10
  功能：更新进货单状态
  *******************************************************************************************************/
  procedure P_UpdateIdata(strEnterPriseNo      in ridata_check_m.enterprise_no%type,
                          strWareHouseNo       in ridata_check_m.warehouse_no%type,
                          strOwnerNo           in ridata_check_m.owner_no%type,
                          strUntreadNo         in ridata_untread_sm.s_untread_no%type,
                          strResult            out varchar2);
  /*************************************************************************************
   作者:luozhiling
   日期:  2014-11-09
   功能: 返配单对象：将临时板数据写入板明细、汇总返配明细、返配明细,超量
  **************************************************************************************/

  procedure p_InsertCheckD(strEnterPriseNo       in ridata_check_pal_tmp.enterprise_no%type,
                           strWareHouseNo        in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                           strOwnerNo            in ridata_check_pal_tmp.owner_no%type, --委托业主
                           strsUntreadNo         in ridata_untread_sm.s_untread_no%type, --返配汇总单号
                           strSCheckNo           in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                           strUntreadNo          in ridata_check_pal_tmp.s_check_no%type,
                           strWorkerNo           in ridata_check_pal_tmp.rgst_name%type, --操作人
                           nCheckQty             in ridata_check_pal_tmp.check_qty%type,
                           intRowId              in ridata_check_pal_tmp.row_id%type,
                           strLabelNo            in ridata_check_pal_tmp.label_no%type,
                           strResult             out varchar2);

  /******************************************************************************************************************
   修改人：luozhiling
   日期:2013-11-8
   功能：按验收汇总单做验收确认
  *******************************************************************************************************************/
  procedure P_CloseCheck(strEnterPriseNo      in ridata_untread_m.enterprise_no%type,
                         strWAREHOUSE_NO      in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码)
                         strsUntreadNo        in ridata_untread_sm.s_untread_no%type, --返配汇总单号
                         strS_Check_no        in ridata_check_pal_tmp.s_check_no%type, --验收汇总单号
                         strDockNo            in pntset_printer_workstation.workstation_no%type, --工作站号
                         strWorkerNo          in ridata_check_pal_tmp.rgst_name%type, --操作人
                         strResult            Out varchar2);

  /******************************************************************************************************************
   修改人：luozhiling
   日期:2013-11-8
   功能：对进货单做结案
  *******************************************************************************************************************/
  procedure P_CloseImport(strEnterPriseNo        in ridata_check_pal_tmp.enterprise_no%type,
                          strWAREHOUSE_NO        in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码)
                          strsCheckNo            in ridata_check_pal_tmp.s_untread_no%type, --返配汇总单号
                          strWorkerNo            in ridata_check_pal_tmp.rgst_name%type, --操作人
                          strResult              Out varchar2);

  /******************************************************************************************************************
   修改人：luozhiling
   日期:2013-11-8
   功能：将进货汇总单转历史
  *******************************************************************************************************************/
  procedure P_untreadToHty(strEnterPriseNo        in ridata_check_pal_tmp.enterprise_no%type,
                           strWAREHOUSE_NO        in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码)
                           strsUntreadNo          in ridata_untread_sm.s_untread_no%type, --返配汇总单号
                           strResult              Out varchar2);

  -----------------------------------【存储验收end】-----------------------------------------------------------------------*/
  /*****************************************************************************************************************
   作者:luozhiling
   日期:  2013-10-18
   功能: 上架发单
  *******************************************************************************************************************/

  procedure P_insertInstock(strEnterPriseNo       in ridata_check_m.enterprise_no%type,
                            strWareHouseNo        in ridata_instock_direct.warehouse_no%type, --仓别
                            strWorkerNo           in ridata_instock_direct.rgst_name%type, --操作人
                            strLocateNo           in ridata_instock_direct.locate_no%type,
                            strDockNo             in ridata_check_m.dock_no%type,
                            strPrintFlag          in job_printtask_m.reprint_flag%type,--打印标识，0：不打印，1：打印
                            strInstockNo          out ridata_instock_d.instock_no%type, --上架单号
                            strResult             out varchar2);

  /*************************************************************************
  luozhiling
  2013/10/23
  说明：上架回单
  ****************************************************************************************************/
  procedure P_UpdateInstock(strEnterPriseNo         in ridata_instock_m.enterprise_no%type,
                            strWareHouseNo          in ridata_instock_m.warehouse_no%type,
                            strInstockNo            in ridata_instock_m.instock_no%type,
                            strInstockId            in ridata_instock_d.instock_id%type,
                            strInstockCellNo        in ridata_instock_d.real_cell_no%type,
                            nRealQty                in ridata_instock_d.real_qty%type,
                            strUserId               in ridata_instock_m.rgst_name%type, --上架人
                            strPaperUserId          in ridata_instock_m.rgst_name%type, --回单人
                            strSataus               in ridata_instock_d.status%type,
                            strResult               out varchar2);

  /*************************************************************************
  luozhiling
  2014/6/21
  说明：DPS返配上架更新上架明细，需要写实际上架的标签号
  ****************************************************************************************************/
  procedure P_UpdateDPSInstock(strEnterPriseNo      in ridata_instock_m.enterprise_no%type,
                               strWareHouseNo       in ridata_instock_m.warehouse_no%type,
                               strInstockNo         in ridata_instock_m.instock_no%type,
                               strInstockId         in ridata_instock_d.instock_id%type,
                               strInstockCellNo     in ridata_instock_d.real_cell_no%type,
                               strRealLabelNo       in ridata_instock_d.real_label_no%type,
                               strRealSubLabelNo    in   ridata_instock_d.real_sub_label_no%type,
                               nRealQty             in ridata_instock_d.real_qty%type,
                               strUserId            in ridata_instock_m.rgst_name%type, --上架人
                               strPaperUserId       in ridata_instock_m.rgst_name%type, --回单人
                               strResult            out varchar2) ;

  /*
   作者:luozhiling
   日期:  2013-11-11
   功能: 上架指示转历史
  */
  procedure P_InstockToHty(strEnterPriseNo      in ridata_instock_m.enterprise_no%type,
                           strWareHouseNo       in ridata_instock_m.warehouse_no%type, --仓库代码
                           strInstockNo         in ridata_instock_m.instock_no%type, --上架单号
                           strResult            out varchar2);

  /**********************************************************************************************
   作者:luozhiling
   日期:  2014-06-20
   功能: 上架回单  拆笔新增上架明细
  ************************************************************************************************/
  procedure p_Insert_Instock_D(strEnterPriseNo      in ridata_instock_m.enterprise_no%type,
                               strWareHouseNo       in ridata_check_m.WAREHOUSE_NO%type, --仓库编码
                               strOwnerNo           in ridata_instock_m.owner_no%type, --委托业主
                               strInstockNo         in ridata_instock_m.instock_no%type, --进货汇总单号
                               strInstockId         in ridata_instock_d.instock_id%type,
                               nRealQty             in ridata_instock_d.real_qty%type,
                               strUserId            in ridata_instock_m.rgst_name%type, --上架人
                               strSataus            in ridata_instock_d.status%type,
                               strResult            out varchar2);

--试算扫描墙资源
PROCEDURE p_scan_calculate(strEnterPriseNo    in ridata_check_m.enterprise_no%type,
                              strwarehouse_no    in ridata_untread_sm.warehouse_no%type, --仓别
                              strSUntreadNo      in ridata_untread_sm.s_untread_no%type, --返配汇总单号
                              --strDockNo       in ridata_check_m.dock_no%type,--扫描台
                              strDeviceNo        in device_divide_m.device_no%type,--扫描墙号
                              strWAVE_TYPE       in BSET_WAVE_MANAGE.Wave_Type%type ,
                              strQualityFlag     in ridata_untread_m.quality%type,--品质类型
                              strUser_Id         in ridata_untread_sm.rgst_name%type, --操作人员
                              str_ri_wave_no     in ridata_untread_mm.wave_no%type,--当前返配单已分配的波次号
                              n_stockNum         in device_divide_m.cust_qty%type,--用来判断滞销品、过季品是不是按区或按巷道来分配分播墙格子号,0为区，其它为巷道
                              n_add_LabelNum     out number,--需要在扫描墙上增加的临时格子数
                              strOutMsg          out varchar2) ;

/*  PROCEDURE p_RI_SupperAllotCell(strEnterPriseNo in ridata_untread_sm.enterprise_no%type,
                                 strwarehouse_no in ridata_untread_sm.warehouse_no%type, --仓别
                                 strowner_no     in ridata_untread_sm.owner_no%type,
                                 strSUntreadNo   in ridata_untread_sm.s_untread_no%type, --返配汇总单号
                                 strDockNo       in ridata_check_m.dock_no%type,--扫描台
                                 strDeviceNo     in device_divide_m.device_no%type,--扫描墙号
                                 strUser_Id      in ridata_untread_sm.rgst_name%type, --操作人员
                                 strQuality      in ridata_untread_d.quality%type,--界面传入的品质类型,不传默认为‘N';如果不为'N',那么根据传入值进行判断。
                                 strBoxCount     out integer,--需要的物流箱数目
                                 strOutMsg       out varchar2);      */

 /**********************************************************************************************
   作者:hekl
   日期:2015-07-24
   功能:扫描墙资源表转历史（ridata_boxhty）
  ************************************************************************************************/
  procedure p_Insert_box_hty(strEnterPriseNo      in ridata_check_pal_tmp.enterprise_no%type,
                          strWareHouseNo       in ridata_check_pal_tmp.WAREHOUSE_NO%type, --仓库编码
                          strWaveNo            in ridata_check_pal_tmp.wave_no%type, --波次号
                          strDeviceNo          in ridata_check_pal_tmp.device_no%type,--扫描墙号
                          strLabelId           in ridata_check_pal_tmp.label_id%type,--扫描墙储位（格子号）
                          strResult            out varchar2);

      /**********************************************************************************************
   作者:lizhiping
   日期:2016-01-08
   功能:分配分播墙
  ************************************************************************************************/
  procedure p_allot_supp_dpscell(strEnterPriseNo      in cset_cell_supplier.enterprise_no%type,
                          strWareHouseNo       in cset_cell_supplier.WAREHOUSE_NO%type, --仓库编码
                          strWaveNo            in out cset_cell_supplier.wave_no%type, --波次
                          nBatchNo             in out cset_cell_supplier.batch_no%type,
                          strDpsDeviceNo       in out cset_cell_supplier.device_no%type,
                          strDpsCellNo         in out cset_cell_supplier.cell_no%type,
                          strWaveType          in varchar2,
                          strOwnerNo           in cset_cell_supplier.owner_no%type,
                          strSupplierNo        in cset_cell_supplier.supplier_no%type,
                          strStyle             in cset_cell_supplier.style%type,
                          strUserID            in cset_cell_supplier.rgst_name%type,
                          strOutMsg            out varchar2);

  /*******************************************************************************************************
  创建人：huangb
  创建时间：2016.05.18
  功能说明：返配单、返配验收单、返配验收板明细转历史
  ********************************************************************************************************/
  procedure P_Ridata_UnteradCheckHTY(strEnterPriseNo in  ridata_check_mhty.enterprise_no%type,
                                     strWAREHOUSE_NO in  ridata_check_mhty.WAREHOUSE_NO%type, --仓库编码)
                                     strOwnerNo      in  ridata_check_mhty.owner_no%type,
                                     strSuntreadNo   in  ridata_check_mhty.S_UNTREAD_NO%type, --返配汇总单号
                                     strWorkerNo     in  ridata_check_mhty.rgst_name%type, --操作人
                                     strOutMsg       Out varchar2);

  --获取返配单据类型
  function f_get_untread_type(strQuality in ridata_untread_m.quality%type,
                            strClasstype  in ridata_untread_m.class_type%type)
    return varchar2;

end pkobj_ridata;


/

