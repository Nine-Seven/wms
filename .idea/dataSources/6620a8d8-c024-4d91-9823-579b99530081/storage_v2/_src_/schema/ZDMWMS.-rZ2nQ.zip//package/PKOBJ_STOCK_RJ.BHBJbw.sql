create package PKOBJ_STOCK_RJ is
	/**************************************
  修改功能：修改P_RETRY_STOCK_CONTENT_RJ重算日结库存账,P_STOCK_CONTENT_RJ生成昨天的库存日结账写日结数据添加lot_no 
  修改人 hcx
  修改日期 20170602 10:56~59
  ***************************************/
  /****************************************************
  功能说明：新增计费库存重算功能
  修改人：wyf
  修改时间：2017-03-15 11:40~2017-03-15 11:46
  ****************************************************/


  /****************************************************
  重算日结库存账 wyf 2016-10-09
  ****************************************************/
  procedure P_RETRY_STOCK_CONTENT_RJ(dtStart   in date, --开始时间
                                     dtEnd     in date, --结束时间 结束日期最大为今天日期
                                     strResult out varchar2);
  /****************************************************
  生成昨天的库存日结账 wyf 2016-10-09
  ****************************************************/
  procedure P_STOCK_CONTENT_RJ;
  procedure P_comp_Owner_Usedcell;

  
  /*****************************************************************************************************
  功能说明：进货验收的三级帐处理
  luozhiling
  2017.3.6
  *****************************************************************************************************/
  procedure P_IdataCheckAcount(strEnterprise_No in idata_check_m.enterprise_no%type, --企业
                              strWAREHOUSE_NO  in idata_check_m.WAREHOUSE_NO%type, --仓库编码)
                              strOwnerNo       in idata_check_m.owner_no%type,
                              strS_import_no   in idata_check_m.s_import_no%type, --进货汇总单号
                              strS_Check_no    in idata_check_m.s_check_no%type, --验收汇总单号
                              strWorkerNo      in idata_check_m.rgst_name%type, --操作人
                              strResult        Out varchar2);

end PKOBJ_STOCK_RJ;


/

