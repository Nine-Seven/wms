create package body        PKLG_IDATA_ID is

  /************************************************************************************************
       修改人：wyf
       日期：2015-07-15
       功能：扫描验收保存
  *************************************************************************************************/
  procedure P_SCAN_IDCHECK(strEnterpriseNo   in idata_check_m.enterprise_no%type,
                           strWareHouseNo    in idata_check_m.warehouse_no%type,
                           strOwnerNo        in idata_check_m.owner_no%type,
                           strsImportNo      in idata_check_m.s_import_no%type, --进货汇总单号
                           strArticleNo      in idata_check_d.article_no%type,
                           strBarcode        in idata_check_d.barcode%type,
                           nPackingQty       in idata_check_d.packing_qty%type,
                           nCheckQty         in idata_check_d.check_qty%type,
                           strPrinterGroupNo in idata_check_m.printer_group_no%type, --工作站
                           strDockNo         in idata_check_m.dock_no%type, --码头
                           strWorkerNo       in idata_check_m.rgst_name%type, --操作人
                           strCheckTools     in idata_check_m.check_tools%type, --验收工具
                           nIsAdd            in integer, --是否累加 0:覆盖 1:累加
                           strQuality        in idata_check_d.quality%type, --品质
                           dtProduceDate     in idata_check_d.produce_date%type,
                           dtExpireDate      in idata_check_d.expire_date%type,
                           strLotNo          in idata_check_d.lot_no%type, --批次号
                           strRSV_BATCH1     in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                           strRSV_BATCH2     in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                           strRSV_BATCH3     in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                           strRSV_BATCH4     in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                           strRSV_BATCH5     in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                           strRSV_BATCH6     in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                           strRSV_BATCH7     in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                           strRSV_BATCH8     in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                           strLabelNo        in stock_label_m.label_no%type, --实体标签号
                           strInDeviceNo     in idata_check_pal_tmp.sub_label_no%type, --子标签号 传入保存设备号
                           strFixPalFlag     in idata_check_pal_tmp.Fixpal_Flag%type, --1：固定板号；2：流水板号;
                           strBusinessType   in idata_check_pal_tmp.Business_Type%type, --业务类型：0-普通验收；1-直通验收；2-大批量验收；3-客户别；5-越库；6-B/C品
                           strOutDeviceNo    out idata_check_pal_tmp.sub_label_no%type, --子标签号 传出保存设备号
                           strResult         out varchar2) is
    v_stockType  idata_import_mm.stock_type%type;
    v_stockValue idata_import_mm.stock_value%type;

    v_nSumPoQty      idata_import_sd.po_qty%type; --总剩余验收数量
    v_nAcrossQty     idata_import_sd.check_across_qty%type; --直通剩余数量
    v_nCurrRemainQty idata_import_sd.po_qty%type; --当前剩余验收数量
    v_nScanQty       idata_import_sd.po_qty%type; --临时表记录的已扫描数量

    v_strCustNo        idata_check_pal_tmp.cust_no%type := 'N'; --客户编码
    v_strDeviceGroupNo device_divide_group.device_group_no%type := 'N'; --设备组
    v_strComputeflag   device_divide_m.Divide_Compute_Flag%type; --是否进行资源试算，0：不试算（按系统设置分配），1：试算（需要读取策略表，按试算策略进行试算）
    v_strInstockFlag   varchar2(1);
    v_strDeviceNo      idata_check_pal_tmp.sub_label_no%type;
    v_strClassType     idata_import_mm.class_type%type;
    --v_nDeviceQty idata_import_sd.po_qty%type; --设备剩余要货量

    --v_nCount number;

    v_CurrScanQty idata_check_d.check_qty%type; --当前扫描量
    v_nNeedQty    idata_check_d.check_qty%type; --每次需要量
    v_nQty        idata_check_d.check_qty%type; --每次剩余量
    v_CurrQty     idata_check_d.check_qty%type; --当前量
  begin
    strResult      := 'N|[P_SCAN_IDCHECK]';
    strOutDeviceNo := 'N';
    v_CurrQty      := nCheckQty;
    v_strDeviceNo  := strInDeviceNo;
    v_nNeedQty     := nCheckQty;
    begin
      select stock_type, a.stock_value,a.class_type
        into v_stockType, v_stockValue,v_strClassType
        from idata_import_mm a
       where warehouse_no = strWareHouseNo
         and enterprise_no = strEnterpriseNo
         and owner_no = strOwnerNo
         and s_import_no = strsImportNo;
    exception
      when no_data_found then
        strResult := 'N|[E20903]'; --取进货汇总单信息失败
        return;
    end;
    --读取未验量,检查是否超量
    --锁定进货汇总单头档
    update idata_import_mm mm
       set mm.status = mm.status
     where mm.warehouse_no = strWareHouseNo
       and mm.enterprise_no = strEnterpriseNo
       and mm.s_import_no = strsImportNo
       and mm.owner_no = strOwnerNo;

    --获取商品的未验收数量
    select sum(t.po_qty - t.import_qty) sumQty
      into v_nSumPoQty
      from idata_import_sd t
     where t.warehouse_no = strWareHouseNo
       and t.enterprise_no = strEnterpriseNo
       and t.owner_no = strOwnerNo
       and t.s_import_no = strsImportNo
       and t.article_no = strArticleNo
       and t.packing_qty = nPackingQty;

    --获取商品的直通出货数量
    select nvl(sum(t.po_qty - t.allot_qty), 0)
      into v_nAcrossQty
      from idata_import_allot t, idata_import_sm iis
     where t.enterprise_no = iis.enterprise_no
       and t.warehouse_no = iis.warehouse_no
       and t.owner_no = iis.owner_no
       and t.import_no = iis.import_no
       and t.warehouse_no = strWareHouseNo
       and t.owner_no = strOwnerNo
       and t.article_no = strArticleNo
       and t.packing_qty = nPackingQty
       and t.enterprise_no = strEnterpriseNo
       and iis.s_import_no = strsImportNo
       AND t.status not in ('13', '16');

    --获取临时表中已扫描的数量
    select nvl(sum(t.check_qty), 0)
      into v_nScanQty
      from idata_check_pal_tmp t
     where t.warehouse_no = strWareHouseNo
       and t.owner_no = strOwnerNo
       and t.article_no = strArticleNo
       and t.packing_qty = nPackingQty
       and t.enterprise_no = strEnterpriseNo
       and t.s_import_no = strsImportNo
       and t.quality = strQuality
       and trunc(t.produce_date) = trunc(dtProduceDate)
       and trunc(t.expire_date) = trunc(dtExpireDate)
       and t.lot_no = strLotNo
       and t.rsv_batch1 = strRSV_BATCH1
       and t.rsv_batch2 = strRSV_BATCH2
       and t.rsv_batch3 = strRSV_BATCH3
       and t.rsv_batch4 = strRSV_BATCH4
       and t.rsv_batch5 = strRSV_BATCH5
       and t.rsv_batch6 = strRSV_BATCH6
       and t.rsv_batch7 = strRSV_BATCH7
       and t.rsv_batch8 = strRSV_BATCH8;
    --未验量包含临时表中已扫描数量
    v_nSumPoQty := v_nSumPoQty - v_nScanQty;
    --v_nAcrossQty := v_nAcrossQty - v_nScanQty;
    if v_nSumPoQty < nCheckQty then
      --暂不支持超量
      strResult := 'N|[E00022]';
      return;
    end if;
    --扫描输入负数
    if v_CurrQty < 0 then
      select nvl(sum(t.check_qty), 0)
        into v_CurrScanQty
        from idata_check_pal_tmp t
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.owner_no = strOwnerNo
         and t.s_import_no = strsImportNo
         and t.article_no = strArticleNo
         and t.packing_qty = nPackingQty
         and t.barcode = strBarcode
         and t.printer_group_no = strPrinterGroupNo
         and t.dock_no = strDockNo
         and t.check_tools = strCheckTools
         and t.label_no = strLabelNo
         and t.sub_label_no = v_strDeviceNo
         and t.quality = strQuality
         and trunc(t.produce_date) = trunc(dtProduceDate)
         and trunc(t.expire_date) = trunc(dtExpireDate)
         and t.lot_no = strLotNo
         and t.rsv_batch1 = strRSV_BATCH1
         and t.rsv_batch2 = strRSV_BATCH2
         and t.rsv_batch3 = strRSV_BATCH3
         and t.rsv_batch4 = strRSV_BATCH4
         and t.rsv_batch5 = strRSV_BATCH5
         and t.rsv_batch6 = strRSV_BATCH6
         and t.rsv_batch7 = strRSV_BATCH7
         and t.rsv_batch8 = strRSV_BATCH8;
      if v_CurrScanQty < -v_CurrQty then
        strResult := 'N|[扣减的数量超过已扫描数量，请审核后在输入数量！]';
        return;
      end if;
      P_SCAN_DEDUCTION(strEnterpriseNo,
                       strWareHouseNo,
                       strOwnerNo,
                       strsImportNo,
                       strArticleNo,
                       strBarcode,
                       nPackingQty,
                       nCheckQty,
                       strPrinterGroupNo,
                       strDockNo,
                       strWorkerNo,
                       strCheckTools,
                       strQuality,
                       dtProduceDate,
                       dtExpireDate,
                       strLotNo,
                       strRSV_BATCH1,
                       strRSV_BATCH2,
                       strRSV_BATCH3,
                       strRSV_BATCH4,
                       strRSV_BATCH5,
                       strRSV_BATCH6,
                       strRSV_BATCH7,
                       strRSV_BATCH8,
                       strLabelNo,
                       v_strDeviceNo,
                       strResult);
      return;
    end if;

    --若直通数量-已扫描<=0，且为第一次保存，则直接转存储验收
    if v_nAcrossQty - v_nScanQty <= 0 and
       (v_strDeviceNo is null or v_strDeviceNo = 'N') then
      v_strInstockFlag := '1';
      /*select count(1)
        into v_nCount
        from idata_check_pal_tmp t
       where t.warehouse_no = strWareHouseNo
         and t.enterprise_no = strEnterpriseNo
         and t.owner_no = strOwnerNo
         and t.printer_group_no = strPrinterGroupNo
         and t.dock_no = strDockNo;
      if v_nCount > 0 then
        strResult := 'N|[扫描台有未封箱的数据，请先封箱！]';
        return;
      end if;*/
      goto SCAN_SAVE;
    else
      v_strInstockFlag := '0';
    end if;

    if nCheckQty > v_nAcrossQty - v_nScanQty then
      v_nCurrRemainQty := nCheckQty - (v_nAcrossQty - v_nScanQty);
    end if;
    --验收数量大于直通数量时，剩余部分转存储
    if v_nCurrRemainQty > 0 and nIsAdd = 1 then
      strResult := 'N|[已满足直通数量，请先封箱后，再扫描！]';
      return;
    elsif v_nCurrRemainQty > 0 and nIsAdd = 0 then
      strResult := 'N|[输入数量已超出需要直通的数量，请修改数量后再操作！]';
      return;
    end if;

    --获取单据类型对应设备试算配置
    v_strComputeflag := '0';
    /*select sd.divide_compute_flag into v_strComputeflag
     from wms_outorder od,WMS_COMPUTE_STRATEGY_d sd
    where od.enterprise_no = strEnterpriseNo
    and od.exp_type = 'ID'
    and od.enterprise_no = sd.enterprise_no
    and od.compute_strategy_id = sd.compute_strategy_id;*/

    --获取设备组
    if v_strDeviceNo is not null and v_strDeviceNo <> 'N' then
      select distinct d.device_group_no
        into v_strDeviceGroupNo
        from device_divide_m m, device_divide_group d
       where m.enterprise_no = d.enterprise_no
         and m.warehouse_no = d.warehouse_no
         and m.device_group_no = d.device_group_no
         and m.device_no = v_strDeviceNo
         and m.enterprise_no = strEnterpriseNo
         and m.warehouse_no = strWareHouseNo;
    else
      begin
        select distinct t.device_group_no
          into v_strDeviceGroupNo
          from BSET_WORKSTATION_DIVIDE d, device_divide_group t
         where d.enterprise_no = t.enterprise_no
           and d.warehouse_no = t.warehouse_no
           and d.device_group_no = t.device_group_no
           and d.enterprise_no = strEnterpriseNo
           and d.warehouse_no = strWareHouseNo
           and d.workstation_no = strDockNo;
      exception
        when no_data_found then
          begin
            select t.device_group_no
              into v_strDeviceGroupNo
              from device_divide_group       t,
                   bset_article_group_divide bagd,
                   bdef_defarticle           bda
             where t.ENTERPRISE_NO = strEnterpriseNo
               and t.WAREHOUSE_NO = strWareHouseNo
               and t.use_type = '1'
               and t.status = '1'
               and t.default_flag = '0'
               and t.ENTERPRISE_NO = bagd.ENTERPRISE_NO
               and t.WAREHOUSE_NO = bagd.WAREHOUSE_NO
               and t.DEVICE_GROUP_NO = bagd.DEVICE_GROUP_NO
               and bda.ENTERPRISE_NO = bagd.ENTERPRISE_NO
               and bda.GROUP_NO = bagd.GROUP_NO
               and bda.ARTICLE_NO = strArticleNo;
          exception
            when no_data_found then
              select t.device_group_no
                into v_strDeviceGroupNo
                from device_divide_group t
               where t.ENTERPRISE_NO = strEnterpriseNo
                 and t.WAREHOUSE_NO = strWareHouseNo
                 and t.use_type = '1'
                 and t.status = '1'
                 and t.default_flag = '1';
          end;
      end;
    end if;
    --试算标识 0：不试算，1：试算
    <<NextCust>>
    if v_strComputeflag = '0' then
      --已扫描数据有分配设备线路的直接查找客户，没有的则需要先分配设备线路
      /*if strDeviceNo is null or strDeviceNo = 'N' then*/
      P_SCAN_IDALLOT_GETDEVICE(strEnterpriseNo,
                               strWareHouseNo,
                               strOwnerNo,
                               strSImportNo,
                               strArticleNo,
                               nPackingQty,
                               v_CurrQty,
                               strPrinterGroupNo,
                               strDockNo,
                               v_strDeviceGroupNo,
                               v_strDeviceNo,
                               strOutDeviceNo,
                               strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
      v_strDeviceNo := strOutDeviceNo;
      /*end if;*/

      --根据设备线路获取客户
      P_SCAN_IDALLOT_GETCUST(strEnterpriseNo,
                             strWareHouseNo,
                             strOwnerNo,
                             strSImportNo,
                             strArticleNo,
                             nPackingQty,
                             v_CurrQty,
                             strPrinterGroupNo,
                             strDockNo,
                             strWorkerNo,
                             strOutDeviceNo,
                             v_strCustNo,
                             v_nNeedQty,
                             v_nQty,
                             strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
    else
      strResult := 'N|[按策略试算未实现]';
      return;
    end if;

    <<SCAN_SAVE>>
    null;
    if v_strInstockFlag = '0' and
       (v_strCustNo is null or v_strCustNo = 'N') then
      strResult := 'N|[未获取到需要保存的客户！]';
      return;
    end if;
    --添加扫描纪录
    --写临时板表；
    PKOBJ_IDATA.p_Insert_Idata_Check_Pal_Tmp(strEnterpriseNo,
                                             strWareHouseNo,
                                             strOwnerNo,
                                             strSImportNo,
                                             'N', --v_strsCheckNo,
                                             v_strClassType,
                                             strArticleNo,
                                             strQuality,
                                             dtProduceDate,
                                             dtExpireDate,
                                             strLotNo,
                                             strRSV_BATCH1,
                                             strRSV_BATCH2,
                                             strRSV_BATCH3,
                                             strRSV_BATCH4,
                                             strRSV_BATCH5,
                                             strRSV_BATCH6,
                                             strRSV_BATCH7,
                                             strRSV_BATCH8,
                                             '', --温度
                                             strBarcode,
                                             nPackingQty,
                                             v_nNeedQty,
                                             strLabelNo,
                                             strOutDeviceNo,
                                             strBusinessType,
                                             strFixPalFlag,
                                             strPrinterGroupNo,
                                             strDockNo,
                                             v_stockType,
                                             v_stockValue,
                                             strWorkerNo,
                                             'ID',
                                             'N',
                                             strCheckTools,
                                             nIsAdd,
                                             v_strCustNo, --'N',
                                             '',
                                             '',
                                             strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;
    if v_nQty > 0 then
      v_CurrQty := v_nQty;
      goto NextCust;
    end if;
    /*--调用打印吊牌和条码存储过程
    P_IDCHECK_PRINT(strEnterpriseNo,
                    strWareHouseNo,
                    strArticleNo,
                    strBarcode,
                    nCheckQty,
                    strDockNo,
                    strWorkerNo,
                    strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;*/
    strResult := 'Y|成功!';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_SCAN_IDCHECK;

  /************************************************************************************************
       修改人：wyf
       日期：2015-07-15
       功能：扫描验收保存找设备线路
  *************************************************************************************************/
  procedure P_SCAN_IDALLOT_GETDEVICE(strEnterpriseNo   in idata_check_m.enterprise_no%type,
                                     strWareHouseNo    in idata_check_m.warehouse_no%type,
                                     strOwnerNo        in idata_check_m.owner_no%type,
                                     strsImportNo      in idata_check_m.s_import_no%type, --进货汇总单号
                                     strArticleNo      in idata_check_d.article_no%type,
                                     nPackingQty       in idata_check_d.packing_qty%type,
                                     nCheckQty         in idata_check_d.check_qty%type,
                                     strPrinterGroupNo in idata_check_m.printer_group_no%type, --工作站
                                     strDockNo         in idata_check_m.dock_no%type, --码头
                                     --strWorkerNo       in idata_check_m.rgst_name%type, --操作人
                                     --strCheckTools     in idata_check_m.check_tools%type, --验收工具
                                     --strQuality        in idata_check_d.quality%type, --品质
                                     --dtProduceDate     in idata_check_d.produce_date%type,
                                     --dtExpireDate      in idata_check_d.expire_date%type,
                                     --strLotNo          in idata_check_d.lot_no%type, --批次号strLabelNo        in stock_label_m.label_no%type, --实体标签号
                                     strDeviceGroupNo in device_divide_group.device_group_no%type,
                                     strDeviceNo      in idata_check_pal_tmp.sub_label_no%type, --子标签号 保存设备号
                                     strOutDeviceNo   out idata_check_pal_tmp.sub_label_no%type,
                                     strResult        out varchar2) is
    /*分配设备线路*/
    v_nDeviceQty idata_import_allot.allot_qty%type; --设备线路剩余直通要货量
    v_nCount     number := 0;
  begin
    strResult := 'N|[P_SCAN_IDALLOT_GETDEVICE]';
    --无扫描纪录，则选择工作量最低设备线路
    if strDeviceNo is null or strDeviceNo = 'N' then
      for p in (select count(distinct slm.label_no) +
                       count(distinct icp.PRINTER_GROUP_NO) LQty,
                       odd.device_no
                /*,(case
                  when icp.sub_label_no is null then
                   1
                  else
                   0
                end) scan_flag --已有扫描数据：0， 没有扫描数据：1*/
                  from device_divide_m odd
                  left join stock_label_m slm
                    on odd.warehouse_no = slm.warehouse_no
                   and odd.enterprise_no = slm.enterprise_no
                   and odd.device_no = slm.device_no
                   and slm.status = CLabelStatus.PICK_END
                  left join idata_check_pal_tmp icp
                    on odd.enterprise_no = icp.enterprise_no
                   and odd.warehouse_no = icp.warehouse_no
                   and odd.device_no = icp.sub_label_no --线路（设备号）
                 where odd.enterprise_no = strEnterpriseNo
                   and odd.warehouse_no = strWareHouseNo
                   and odd.device_group_no = strDeviceGroupNo
                 group by odd.device_no
                 order by count(distinct slm.label_no) +
                          count(distinct icp.PRINTER_GROUP_NO),
                          odd.device_no) loop
        --获取设备线路要货量
        select sum(c.po_qty - c.allot_qty - nvl(icp.sum_check_qty, 0))
          into v_nDeviceQty
          from idata_import_allot c
          join cset_cust_dpscell b
            on b.warehouse_no = c.warehouse_no
           and b.enterprise_no = c.enterprise_no
           and b.owner_no = c.owner_no
           and b.cust_no = c.cust_no
           and b.status = '1'
          join cdef_defcell_dps a
            on a.warehouse_no = b.warehouse_no
           and a.enterprise_no = b.enterprise_no
           and a.cell_no = b.dps_cell_no
           and a.DEVICE_NO = p.device_no
          join idata_import_sm d
            on c.enterprise_no = d.enterprise_no
           and c.warehouse_no = d.warehouse_no
           and c.owner_no = d.owner_no
           and c.import_no = d.import_no
          left join (select ii.enterprise_no,
                            ii.warehouse_no,
                            ii.owner_no,
                            ii.s_import_no,
                            ii.article_no,
                            ii.packing_qty,
                            ii.cust_no,
                            sum(ii.check_qty) as sum_check_qty
                       from idata_check_pal_tmp ii
                      where ii.enterprise_no = strEnterpriseNo
                        and ii.warehouse_no = strWareHouseNo
                        and ii.s_import_no = strsImportNo
                        and ii.owner_no = strOwnerNo
                        and ii.article_no = strArticleNo
                        and ii.packing_qty = nPackingQty
                      group by ii.enterprise_no,
                               ii.warehouse_no,
                               ii.owner_no,
                               ii.s_import_no,
                               ii.article_no,
                               ii.packing_qty,
                               ii.cust_no) icp
            on icp.enterprise_no = d.enterprise_no
           and icp.warehouse_no = d.warehouse_no
           and icp.owner_no = d.owner_no
           and icp.s_import_no = d.s_import_no
              --and icp.sub_label_no = a.DEVICE_NO
           and icp.article_no = c.article_no
           and icp.cust_no = c.cust_no
         where c.warehouse_no = strWareHouseNo
           and c.enterprise_no = strEnterpriseNo
           and c.owner_no = strOwnerNo
           and c.article_no = strArticleNo
           and d.s_import_no = strsImportNo
           and c.packing_qty = nPackingQty;
        if v_nDeviceQty >= nCheckQty then
          select count(1)
            into v_nCount
            from idata_check_pal_tmp t
           where t.enterprise_no = strEnterpriseNo
             and t.warehouse_no = strWareHouseNo
             and t.owner_no = strOwnerNo
             and t.printer_group_no = strPrinterGroupNo
             and t.dock_no = strDockNo
             and t.sub_label_no <> p.device_no;
          if v_nCount > 0 then
            strResult := 'N|[扫描台有需要封箱的数据，请先封箱再做扫描！]';
            return;
          end if;
          strOutDeviceNo := p.device_no;
          exit;
        end if;
      end loop;
      if strOutDeviceNo is null or strOutDeviceNo = 'N' then
        strResult := 'N|[未查找到可用的设备线路或者有客户未维护电子标签储位，请检查！]';
        return;
      end if;
    else
      select sum(c.po_qty - c.allot_qty - nvl(icp.sum_check_qty, 0))
        into v_nDeviceQty
        from idata_import_allot c
        join cset_cust_dpscell b
          on b.warehouse_no = c.warehouse_no
         and b.enterprise_no = c.enterprise_no
         and b.owner_no = c.owner_no
         and b.cust_no = c.cust_no
         and b.status = '1'
        join cdef_defcell_dps a
          on a.warehouse_no = b.warehouse_no
         and a.enterprise_no = b.enterprise_no
         and a.cell_no = b.dps_cell_no
         and a.DEVICE_NO = strDeviceNo
        join idata_import_sm d
          on c.enterprise_no = d.enterprise_no
         and c.warehouse_no = d.warehouse_no
         and c.owner_no = d.owner_no
         and c.import_no = d.import_no
        left join (select ii.enterprise_no,
                          ii.warehouse_no,
                          ii.owner_no,
                          ii.s_import_no,
                          ii.article_no,
                          ii.packing_qty,
                          ii.cust_no,
                          sum(ii.check_qty) as sum_check_qty
                     from idata_check_pal_tmp ii
                    where ii.enterprise_no = strEnterpriseNo
                      and ii.warehouse_no = strWareHouseNo
                      and ii.s_import_no = strsImportNo
                      and ii.owner_no = strOwnerNo
                      and ii.article_no = strArticleNo
                      and ii.packing_qty = nPackingQty
                    group by ii.enterprise_no,
                             ii.warehouse_no,
                             ii.owner_no,
                             ii.s_import_no,
                             ii.article_no,
                             ii.packing_qty,
                             ii.cust_no) icp
          on icp.enterprise_no = d.enterprise_no
         and icp.warehouse_no = d.warehouse_no
         and icp.owner_no = d.owner_no
         and icp.s_import_no = d.s_import_no
            --and icp.sub_label_no = a.DEVICE_NO
         and icp.article_no = c.article_no
         and icp.cust_no = c.cust_no
       where c.warehouse_no = strWareHouseNo
         and c.enterprise_no = strEnterpriseNo
         and c.owner_no = strOwnerNo
         and c.article_no = strArticleNo
         and c.packing_qty = nPackingQty
         and d.s_import_no = strsImportNo;
      if v_nDeviceQty <= 0 then
        strResult := 'N|[超出设备直通要货量,请封箱！]';
        return;
      end if;
      strOutDeviceNo := strDeviceNo;
    end if;

    strResult := 'Y|成功!';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_SCAN_IDALLOT_GETDEVICE;

  /************************************************************************************************
       修改人：wyf
       日期：2015-07-15
       功能：扫描验收保存找客户
  *************************************************************************************************/
  procedure P_SCAN_IDALLOT_GETCUST(strEnterpriseNo   in idata_check_m.enterprise_no%type,
                                   strWareHouseNo    in idata_check_m.warehouse_no%type,
                                   strOwnerNo        in idata_check_m.owner_no%type,
                                   strSImportNo      in idata_check_m.s_import_no%type, --进货汇总单号
                                   strArticleNo      in idata_check_d.article_no%type,
                                   nPackingQty       in idata_check_d.packing_qty%type,
                                   nCheckQty         in idata_check_d.check_qty%type,
                                   strPrinterGroupNo in idata_check_m.printer_group_no%type, --工作站
                                   strDockNo         in idata_check_m.dock_no%type, --码头
                                   strWorkerNo       in idata_check_m.rgst_name%type, --操作人
                                   --strCheckTools     in idata_check_m.check_tools%type, --验收工具
                                   --strQuality        in idata_check_d.quality%type, --品质
                                   --dtProduceDate     in idata_check_d.produce_date%type,
                                   --dtExpireDate      in idata_check_d.expire_date%type,
                                   --strLotNo          in idata_check_d.lot_no%type, --批次号strLabelNo        in stock_label_m.label_no%type, --实体标签号
                                   strDeviceNo in idata_check_pal_tmp.sub_label_no%type, --子标签号 保存设备号
                                   --strFixPalFlag     in idata_check_pal_tmp.Fixpal_Flag%type, --1：固定板号；2：流水板号;
                                   --strBusinessType   in idata_check_pal_tmp.Business_Type%type, --业务类型：0-普通验收；1-直通验收；2-大批量验收；3-客户别；5-越库；6-B/C品
                                   strCustNo out idata_check_pal_tmp.cust_no%type,
                                   nNeedQty  out idata_check_pal_tmp.check_qty%type, --分配客户数量
                                   nQty      out idata_check_pal_tmp.check_qty%type, --剩余数量
                                   strResult out varchar2) is
    /*直通验收累加扫描配量获取客户*/
    v_nAcrossQty    idata_import_allot.allot_qty%type; --客户直通要货量
    v_nCustCheckQty idata_check_pal_tmp.check_qty%type; --客户已验收数量
    --v_nDeviceQty idata_import_allot.allot_qty%type; --设备线路剩余直通要货量
    v_nCount number := 0;

    v_nCurrQty idata_check_pal_tmp.check_qty%type := 0; --当前验收数量
    --v_nMidQty  idata_check_pal_tmp.check_qty%type := 0; --中间量
  begin
    strResult  := 'N|[P_SCAN_IDALLOT_GETCUST]';
    v_nCurrQty := nCheckQty;
    --首先获取原有扫描纪录中的客户，判断客户直通要货量是否满足，未满足累加，满足则获取新的客户
    for p in (select t.cust_no
                from idata_check_pal_tmp t
               where t.enterprise_no = strEnterpriseNo
                 and t.warehouse_no = strWareHouseNo
                 and t.owner_no = strOwnerNo
                 and t.s_import_no = strSImportNo
                 and t.article_no = strArticleNo
                 and t.packing_qty = nPackingQty
                 and t.sub_label_no = strDeviceNo
                 and t.rgst_name = strWorkerNo
                 and t.dock_no = strDockNo
                 and t.printer_group_no = strPrinterGroupNo) loop
      --获取客户剩余直通要货量
      select nvl(sum(t.po_qty - t.allot_qty), 0)
        into v_nAcrossQty
        from idata_import_allot t, idata_import_sm iis
       where t.enterprise_no = iis.enterprise_no
         and t.warehouse_no = iis.warehouse_no
         and t.owner_no = iis.owner_no
         and t.import_no = iis.import_no
         and t.warehouse_no = strWareHouseNo
         and t.owner_no = strOwnerNo
         and t.article_no = strArticleNo
         and t.packing_qty = nPackingQty
         and t.enterprise_no = strEnterpriseNo
         and iis.s_import_no = strsImportNo
         and t.cust_no = p.cust_no
         AND t.status not in ('13', '16');
      --获取客户已扫描数量
      select sum(t.check_qty)
        into v_nCustCheckQty
        from idata_check_pal_tmp t
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.owner_no = strOwnerNo
         and t.s_import_no = strSImportNo
         and t.article_no = strArticleNo
         and t.packing_qty = nPackingQty
         and t.cust_no = p.cust_no;
      if v_nAcrossQty - v_nCustCheckQty > 0 then
        --若客户剩余直通要货量>客户已扫描数量，则使用这个客户
        if v_nAcrossQty - v_nCustCheckQty >= v_nCurrQty then
          strCustNo := p.cust_no;
          nNeedQty  := v_nCurrQty;
          nQty      := 0;
          exit;
        else
          --直通剩余要货量小于验收数量时
          --客户需要数量为客户直通剩余要货量
          strCustNo := p.cust_no;
          nNeedQty  := v_nAcrossQty - v_nCustCheckQty;
          nQty      := v_nCurrQty - (v_nAcrossQty - v_nCustCheckQty); --剩余配量
          exit;
        end if;
      end if;
    end loop;
    --已扫描数据未找到客户，则开始查找新的客户
    if strCustNo is null or strCustNo = 'N' then
      for p in (select c.*
                  from (select (c.po_qty - c.allot_qty -
                               nvl(icp.sum_check_qty, 0)) qty,
                               c.cust_no,
                               bdc.PRIO_LEVEL,
                               b.dps_cell_no
                          from idata_import_allot c
                          join cset_cust_dpscell b
                            on b.warehouse_no = c.warehouse_no
                           and b.enterprise_no = c.enterprise_no
                           and b.owner_no = c.owner_no
                           and b.cust_no = c.cust_no
                           and b.status = '1'
                          join cdef_defcell_dps a
                            on a.warehouse_no = b.warehouse_no
                           and a.enterprise_no = b.enterprise_no
                           and a.cell_no = b.dps_cell_no
                           and a.DEVICE_NO = strDeviceNo
                           and b.dps_cell_no = a.cell_no
                          join idata_import_sm d
                            on c.enterprise_no = d.enterprise_no
                           and c.warehouse_no = d.warehouse_no
                           and c.owner_no = d.owner_no
                           and c.import_no = d.import_no
                          left join (select ii.enterprise_no,
                                           ii.warehouse_no,
                                           ii.owner_no,
                                           ii.s_import_no,
                                           ii.article_no,
                                           ii.packing_qty,
                                           ii.cust_no,
                                           sum(ii.check_qty) as sum_check_qty
                                      from idata_check_pal_tmp ii
                                     where ii.enterprise_no = strEnterpriseNo
                                       and ii.warehouse_no = strWareHouseNo
                                       and ii.s_import_no = strsImportNo
                                       and ii.owner_no = strOwnerNo
                                       and ii.article_no = strArticleNo
                                       and ii.packing_qty = nPackingQty
                                     group by ii.enterprise_no,
                                              ii.warehouse_no,
                                              ii.owner_no,
                                              ii.s_import_no,
                                              ii.article_no,
                                              ii.packing_qty,
                                              ii.cust_no) icp
                            on icp.enterprise_no = d.enterprise_no
                           and icp.warehouse_no = d.warehouse_no
                           and icp.owner_no = d.owner_no
                           and icp.s_import_no = d.s_import_no
                           and icp.article_no = c.article_no
                           and icp.packing_qty = c.packing_qty
                           and icp.cust_no = c.cust_no
                          join bdef_defcust bdc
                            on b.enterprise_no = bdc.enterprise_no
                           and b.cust_no = bdc.cust_no
                           and b.owner_no = bdc.owner_no
                         where c.warehouse_no = strWareHouseNo
                           and c.enterprise_no = strEnterpriseNo
                           and c.owner_no = strOwnerNo
                           and c.article_no = strArticleNo
                           and c.packing_qty = nPackingQty
                           and d.s_import_no = strsImportNo
                           and (c.po_qty - c.allot_qty -
                               nvl(icp.sum_check_qty, 0)) > 0) c
                 order by case
                            when (select count(1)
                                    from idata_check_pal_tmp i
                                   where i.warehouse_no = strWareHouseNo
                                     and i.owner_no = strOwnerNo
                                     and i.s_import_no = strsImportNo
                                     and i.article_no = strArticleNo
                                     and i.packing_qty = nPackingQty
                                     and i.cust_no = c.cust_no) > 0 then
                             1
                            else
                             0
                          end,
                          c.PRIO_LEVEL,
                          c.cust_no,
                          c.dps_cell_no) loop

        --验收数量大于客户剩余要货量
        if v_nCurrQty > p.qty then
          nNeedQty := p.qty;
          nQty     := v_nCurrQty - nNeedQty;
          --goto NextOne;
          /*strResult := 'N|[有客户未维护电子标签储位]';
          return;*/
        else
          nNeedQty := v_nCurrQty;
          nQty     := 0;
        end if;
        if p.dps_cell_no is null then
          strResult := 'N|[有客户未维护电子标签储位]';
          return;
        else
          strCustNo := p.cust_no;
          exit;
        end if;

      end loop;
      if strCustNo is null or strCustNo = 'N' then
        select count(1)
          into v_nCount
          from idata_import_allot c
          join idata_import_sm d
            on c.enterprise_no = d.enterprise_no
           and c.warehouse_no = d.warehouse_no
           and c.owner_no = d.owner_no
           and c.import_no = d.import_no
         where c.warehouse_no = strWareHouseNo
           and c.enterprise_no = strEnterpriseNo
           and c.owner_no = strOwnerNo
           and c.article_no = strArticleNo
           and d.s_import_no = strsImportNo
           and not exists (select 1
                  from cset_cust_dpscell b
                  join cdef_defcell_dps a
                    on a.warehouse_no = b.warehouse_no
                   and a.enterprise_no = b.enterprise_no
                   and a.cell_no = b.dps_cell_no
                 where b.warehouse_no = c.warehouse_no
                   and b.enterprise_no = c.enterprise_no
                   and b.owner_no = c.owner_no
                   and b.cust_no = c.cust_no
                   and b.status = '1'
                   and a.DEVICE_NO = strDeviceNo
                   and b.dps_cell_no = a.cell_no);
        if v_nCount > 0 then
          strResult := 'N|[有客户未维护电子标签储位]';
          return;
        end if;
      end if;
    end if;

    strResult := 'Y|成功!';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_SCAN_IDALLOT_GETCUST;

  /************************************************************************************************
       修改人：wyf
       日期：2015-07-15
       功能：RF封箱
  *************************************************************************************************/
  procedure P_RF_IDCLOSEBOX(strEnterpriseNo   in idata_check_m.enterprise_no%type,
                            strWareHouseNo    in idata_check_m.warehouse_no%type,
                            strOwnerNo        in idata_check_m.owner_no%type,
                            strsImportNo      in idata_check_m.s_import_no%type, --进货汇总单号
                            strArticleNo      in idata_check_d.article_no%type,
                            strBarcode        in idata_check_d.barcode%type,
                            nPackingQty       in idata_check_d.packing_qty%type,
                            nCheckQty         in idata_check_d.check_qty%type, --RF封箱传0
                            strPrinterGroupNo in idata_check_m.printer_group_no%type, --工作站
                            strDockNo         in idata_check_m.dock_no%type, --码头
                            strWorkerNo       in idata_check_m.rgst_name%type, --操作人
                            strCheckTools     in idata_check_m.check_tools%type, --验收工具
                            strQuality        in idata_check_d.quality%type, --品质
                            dtProduceDate     in idata_check_d.produce_date%type,
                            dtExpireDate      in idata_check_d.expire_date%type,
                            strLotNo          in idata_check_d.lot_no%type, --批次号
                            strRSV_BATCH1     in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                            strRSV_BATCH2     in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                            strRSV_BATCH3     in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                            strRSV_BATCH4     in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                            strRSV_BATCH5     in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                            strRSV_BATCH6     in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                            strRSV_BATCH7     in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                            strRSV_BATCH8     in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                            strLabelNo        in stock_label_m.label_no%type, --实体标签号
                            strDeviceNo       in idata_check_pal_tmp.sub_label_no%type, --子标签号 设备线路号
                            strPrintFlag      in bdef_defarticle.print_flag%type,
                            --strFixPalFlag     in idata_check_pal.Fixpal_Flag%type, --1：固定板号；2：流水板号;
                            --strBusinessType   in idata_check_pal.Fixpal_Flag%type, --业务类型：0-普通验收；1-直通验收；2-大批量验收；3-客户别；5-越库；6-B/C品
                            strsCheckNo out idata_check_m.s_check_no%type,
                            strResult   out varchar2) is
    /*RF封箱*/
    v_nCheckQty idata_check_d.check_qty%type;
  begin
    strResult := 'N|[P_RF_IDCLOSEBOX]';
    /*2016-05-26  weiyufei
    RF封箱动作是单独的，此处不锁单，有可能导致一单多个人同时验收，产生不同的汇总验收单号，从而导致封箱失败，获取到多个汇总验收单号异常
    */
    update idata_import_mm mm
       set mm.status = mm.status
     where mm.warehouse_no = strWareHouseNo
       and mm.enterprise_no = strEnterpriseNo
       and mm.s_import_no = strsImportNo
       and mm.owner_no = strOwnerNo;
    --RF扫描封箱的数量通过临时表取
    if nCheckQty = 0 and strCheckTools = '2' then
      select nvl(sum(t.check_qty), 0)
        into v_nCheckQty
        from idata_check_pal_tmp t
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.owner_no = strOwnerNo
         and t.s_import_no = strsImportNo
         and t.article_no = strArticleNo
         and t.packing_qty = nPackingQty
         and t.label_no = strLabelNo
         and t.sub_label_no = strDeviceNo
         and t.printer_group_no = strPrinterGroupNo
         and t.dock_no = strDockNo
         and t.check_tools = strCheckTools;
    else
      v_nCheckQty := nCheckQty;
    end if;

    if v_nCheckQty <= 0 then
      strResult := 'N|[不存在需要封箱的数据或者已被封箱!]';
      return;
    end if;
    --子标签号代表设备线路号
    if strDeviceNo is not null and strDeviceNo <> 'N' then
      --直通封箱
      P_SAVE_IDCLOSEBOX(strEnterpriseNo,
                        strWareHouseNo,
                        strOwnerNo,
                        strsImportNo,
                        strArticleNo,
                        strBarcode,
                        nPackingQty,
                        v_nCheckQty,
                        strPrinterGroupNo,
                        strDockNo,
                        strWorkerNo,
                        strCheckTools,
                        strQuality,
                        dtProduceDate,
                        dtExpireDate,
                        strLotNo,
                        strRSV_BATCH1,
                        strRSV_BATCH2,
                        strRSV_BATCH3,
                        strRSV_BATCH4,
                        strRSV_BATCH5,
                        strRSV_BATCH6,
                        strRSV_BATCH7,
                        strRSV_BATCH8,
                        strLabelNo,
                        strDeviceNo,
                        '',
                        strPrintFlag,
                        strsCheckNo,
                        strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
    else
      --存储封箱
      --删除临时表数据
      delete from idata_check_pal_tmp t
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.owner_no = strOwnerNo
         and t.s_import_no = strsImportNo
         and t.article_no = strArticleNo
         and t.packing_qty = nPackingQty
         and t.label_no = strLabelNo
         and t.sub_label_no = strDeviceNo
         and t.printer_group_no = strPrinterGroupNo
         and t.dock_no = strDockNo
         and t.check_tools = strCheckTools;
      --调用直通转存储存储过程
      P_SAVE_ID2IS(strEnterpriseNo,
                   strWareHouseNo,
                   strOwnerNo,
                   strsImportNo,
                   strArticleNo,
                   strBarcode,
                   nPackingQty,
                   v_nCheckQty,
                   strPrinterGroupNo,
                   strDockNo,
                   strWorkerNo,
                   strCheckTools,
                   strQuality,
                   dtProduceDate,
                   dtExpireDate,
                   strLotNo,
                   strRSV_BATCH1,
                   strRSV_BATCH2,
                   strRSV_BATCH3,
                   strRSV_BATCH4,
                   strRSV_BATCH5,
                   strRSV_BATCH6,
                   strRSV_BATCH7,
                   strRSV_BATCH8,
                   'N',
                   'N',
                   '2',
                   '0',
                   strsCheckNo,
                   strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
      --存储打印吊牌
      P_IDCHECK_PRINT(strEnterpriseNo,
                      strWareHouseNo,
                      strArticleNo,
                      strBarcode,
                      v_nCheckQty,
                      strDockNo,
                      strWorkerNo,
                      'N',
                      strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
    end if;

    strResult := 'Y|成功!';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_RF_IDCLOSEBOX;

  /************************************************************************************************
       修改人：wyf
       日期：2015-07-15
       功能：前台验收保存
  *************************************************************************************************/
  procedure P_PC_SAVE_IDCHECK(strEnterpriseNo   in idata_check_m.enterprise_no%type,
                              strWareHouseNo    in idata_check_m.warehouse_no%type,
                              strOwnerNo        in idata_check_m.owner_no%type,
                              strsImportNo      in idata_check_m.s_import_no%type, --进货汇总单号
                              strArticleNo      in idata_check_d.article_no%type,
                              strBarcode        in idata_check_d.barcode%type,
                              nPackingQty       in idata_check_d.packing_qty%type,
                              nCheckQty         in idata_check_d.check_qty%type,
                              strPrinterGroupNo in idata_check_m.printer_group_no%type, --工作站
                              strDockNo         in idata_check_m.dock_no%type, --码头
                              strWorkerNo       in idata_check_m.rgst_name%type, --操作人
                              strCheckTools     in idata_check_m.check_tools%type, --验收工具
                              --nIsAdd            in integer, --是否累加 0:覆盖 1:累加
                              strQuality    in idata_check_d.quality%type, --品质
                              dtProduceDate in idata_check_d.produce_date%type,
                              dtExpireDate  in idata_check_d.expire_date%type,
                              strLotNo      in idata_check_d.lot_no%type, --批次号
                              strRSV_BATCH1 in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                              strRSV_BATCH2 in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                              strRSV_BATCH3 in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                              strRSV_BATCH4 in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                              strRSV_BATCH5 in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                              strRSV_BATCH6 in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                              strRSV_BATCH7 in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                              strRSV_BATCH8 in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                              strLabelNo    in stock_label_m.label_no%type, --实体标签号
                              strSubLabelNo in idata_check_pal_tmp.sub_label_no%type, --子标签号
                              strPrintFlag  in bdef_defarticle.print_flag%type, --打印商品条码标识
                              --strFixPalFlag     in idata_check_pal.Fixpal_Flag%type, --1：固定板号；2：流水板号;
                              --strBusinessType   in idata_check_pal.Fixpal_Flag%type, --业务类型：0-普通验收；1-直通验收；2-大批量验收；3-客户别；5-越库；6-B/C品
                              strResult out varchar2) is
    /*未配量直通验收保存方法*/
    v_stockType  idata_import_mm.stock_type%type;
    v_stockValue idata_import_mm.stock_value%type;

    v_nSumPoQty      idata_import_sd.po_qty%type; --总剩余验收数量
    v_nAcrossQty     idata_import_sd.check_across_qty%type; --直通剩余数量
    v_nCurrRemainQty idata_import_sd.po_qty%type; --当前剩余验收数量
    v_nScanQty       idata_import_sd.po_qty%type; --临时表记录的已扫描数量
    v_strsCheckNo    idata_check_m.s_check_no%type;

    v_strDeviceGroupNo device_divide_group.device_group_no%type := 'N'; --设备组
    --v_strComputeflag   WMS_COMPUTE_STRATEGY_d.Divide_Compute_Flag%type; --是否进行资源试算，0：不试算（按系统设置分配），1：试算（需要读取策略表，按试算策略进行试算）
    v_strDeviceNo      idata_check_pal_tmp.sub_label_no%type;
  begin
    strResult := 'N|[P_PC_SAVE_IDCHECK]';

    if nCheckQty <= 0 then
      strResult := 'N|[不存在需要封箱的数据或者已被封箱!]';
      return;
    end if;
    begin
      select stock_type, a.stock_value
        into v_stockType, v_stockValue
        from idata_import_mm a
       where warehouse_no = strWareHouseNo
         and enterprise_no = strEnterpriseNo
         and owner_no = strOwnerNo
         and s_import_no = strsImportNo;
    exception
      when no_data_found then
        strResult := 'N|[E20903]'; --取进货汇总单信息失败
        return;
    end;
    --读取未验量,检查是否超量
    --锁定进货汇总单头档
    update idata_import_mm mm
       set mm.status = mm.status
     where mm.warehouse_no = strWareHouseNo
       and mm.enterprise_no = strEnterpriseNo
       and mm.s_import_no = strsImportNo
       and mm.owner_no = strOwnerNo;

    --获取商品的未验收数量
    select sum(t.po_qty - t.import_qty) sumQty
      into v_nSumPoQty
      from idata_import_sd t
     where t.warehouse_no = strWareHouseNo
       and t.enterprise_no = strEnterpriseNo
       and t.owner_no = strOwnerNo
       and t.s_import_no = strsImportNo
       and t.article_no = strArticleNo
       and t.packing_qty = nPackingQty;

    --获取商品的直通出货数量
    select nvl(sum(t.po_qty - t.allot_qty), 0)
      into v_nAcrossQty
      from idata_import_allot t, idata_import_sm iis
     where t.enterprise_no = iis.enterprise_no
       and t.warehouse_no = iis.warehouse_no
       and t.owner_no = iis.owner_no
       and t.import_no = iis.import_no
       and t.warehouse_no = strWareHouseNo
       and t.owner_no = strOwnerNo
       and t.article_no = strArticleNo
       and t.packing_qty = nPackingQty
       and t.enterprise_no = strEnterpriseNo
       and iis.s_import_no = strsImportNo
       AND t.status not in ('13', '16');

    --获取临时表中已扫描的数量
    select nvl(sum(t.check_qty), 0)
      into v_nScanQty
      from idata_check_pal_tmp t
     where t.warehouse_no = strWareHouseNo
       and t.owner_no = strOwnerNo
       and t.article_no = strArticleNo
       and t.packing_qty = nPackingQty
       and t.enterprise_no = strEnterpriseNo
       and t.s_import_no = strsImportNo;
    --未验量包含临时表中已扫描数量
    v_nSumPoQty  := v_nSumPoQty - v_nScanQty;
    v_nAcrossQty := v_nAcrossQty - v_nScanQty;
    if v_nSumPoQty < nCheckQty then
      --暂不支持超量
      strResult := 'N|[E00022]';
      return;
    end if;

    if nCheckQty > v_nAcrossQty then
      v_nCurrRemainQty := nCheckQty - v_nAcrossQty;
    else
      v_nAcrossQty := nCheckQty;
    end if;
    --验收数量大于直通数量时，剩余部分转存储
    /*  if v_nCurrRemainQty > 0 and nIsAdd = 1 then
      strResult := 'N|[已满足直通数量，请先封箱后，再扫描！]';
      return;
    elsif v_nCurrRemainQty > 0 and nIsAdd = 0 then
      strResult := 'N|[输入数量已超出需要直通的数量，请修改数量后再操作！]';
      return;
    end if;*/
    if v_nAcrossQty > 0 then

      --获取设备组
      if v_strDeviceNo is not null and v_strDeviceNo <> 'N' then
        select distinct d.device_group_no
          into v_strDeviceGroupNo
          from device_divide_m m, device_divide_group d
         where m.enterprise_no = d.enterprise_no
           and m.warehouse_no = d.warehouse_no
           and m.device_group_no = d.device_group_no
           and m.device_no = v_strDeviceNo
           and m.enterprise_no = strEnterpriseNo
           and m.warehouse_no = strWareHouseNo;
      else
        begin
          select distinct t.device_group_no
            into v_strDeviceGroupNo
            from BSET_WORKSTATION_DIVIDE d, device_divide_group t
           where d.enterprise_no = t.enterprise_no
             and d.warehouse_no = t.warehouse_no
             and d.device_group_no = t.device_group_no
             and d.enterprise_no = strEnterpriseNo
             and d.warehouse_no = strWareHouseNo
             and d.workstation_no = strDockNo;
        exception
          when no_data_found then
            begin
              select t.device_group_no
                into v_strDeviceGroupNo
                from device_divide_group       t,
                     bset_article_group_divide bagd,
                     bdef_defarticle           bda
               where t.ENTERPRISE_NO = strEnterpriseNo
                 and t.WAREHOUSE_NO = strWareHouseNo
                 and t.use_type = '1'
                 and t.status = '1'
                 and t.default_flag = '0'
                 and t.ENTERPRISE_NO = bagd.ENTERPRISE_NO
                 and t.WAREHOUSE_NO = bagd.WAREHOUSE_NO
                 and t.DEVICE_GROUP_NO = bagd.DEVICE_GROUP_NO
                 and bda.ENTERPRISE_NO = bagd.ENTERPRISE_NO
                 and bda.GROUP_NO = bagd.GROUP_NO
                 and bda.ARTICLE_NO = strArticleNo;
            exception
              when no_data_found then
                select t.device_group_no
                  into v_strDeviceGroupNo
                  from device_divide_group t
                 where t.ENTERPRISE_NO = strEnterpriseNo
                   and t.WAREHOUSE_NO = strWareHouseNo
                   and t.use_type = '1'
                   and t.status = '1'
                   and t.default_flag = '1';
            end;
        end;
      end if;
      --调用直通封箱过程
      P_SAVE_IDCLOSEBOX(strEnterpriseNo,
                        strWareHouseNo,
                        strOwnerNo,
                        strsImportNo,
                        strArticleNo,
                        strBarcode,
                        nPackingQty,
                        v_nAcrossQty,
                        strPrinterGroupNo,
                        strDockNo,
                        strWorkerNo,
                        strCheckTools,
                        strQuality,
                        dtProduceDate,
                        dtExpireDate,
                        strLotNo,
                        strRSV_BATCH1,
                        strRSV_BATCH2,
                        strRSV_BATCH3,
                        strRSV_BATCH4,
                        strRSV_BATCH5,
                        strRSV_BATCH6,
                        strRSV_BATCH7,
                        strRSV_BATCH8,
                        strLabelNo,
                        strSubLabelNo,
                        v_strDeviceGroupNo,
                        strPrintFlag,
                        v_strsCheckNo,
                        strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
    end if;

    if v_nCurrRemainQty > 0 then
      --直通单剩余部分转存储
      P_SAVE_ID2IS(strEnterpriseNo,
                   strWareHouseNo,
                   strOwnerNo,
                   strsImportNo,
                   strArticleNo,
                   strBarcode,
                   nPackingQty,
                   v_nCurrRemainQty,
                   strPrinterGroupNo,
                   strDockNo,
                   strWorkerNo,
                   strCheckTools,
                   strQuality,
                   dtProduceDate,
                   dtExpireDate,
                   strLotNo,
                   strRSV_BATCH1,
                   strRSV_BATCH2,
                   strRSV_BATCH3,
                   strRSV_BATCH4,
                   strRSV_BATCH5,
                   strRSV_BATCH6,
                   strRSV_BATCH7,
                   strRSV_BATCH8,
                   strLabelNo,
                   strSubLabelNo,
                   '2',
                   '0',
                   v_strsCheckNo,
                   strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
      --打印吊牌
      P_IDCHECK_PRINT(strEnterpriseNo,
                      strWareHouseNo,
                      strArticleNo,
                      strBarcode,
                      v_nCurrRemainQty,
                      strDockNo,
                      strWorkerNo,
                      strPrintFlag,
                      strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
    end if;

    strResult := 'Y|成功!';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_PC_SAVE_IDCHECK;

  /************************************************************************************************
       修改人：wyf
       日期：2015-07-15
       功能：封箱
  *************************************************************************************************/
  procedure P_SAVE_IDCLOSEBOX(strEnterpriseNo   in idata_check_m.enterprise_no%type,
                              strWareHouseNo    in idata_check_m.warehouse_no%type,
                              strOwnerNo        in idata_check_m.owner_no%type,
                              strsImportNo      in idata_check_m.s_import_no%type, --进货汇总单号
                              strArticleNo      in idata_check_d.article_no%type,
                              strBarcode        in idata_check_d.barcode%type,
                              nPackingQty       in idata_check_d.packing_qty%type,
                              nCheckQty         in idata_check_d.check_qty%type, --RF封箱传0
                              strPrinterGroupNo in idata_check_m.printer_group_no%type, --工作站
                              strDockNo         in idata_check_m.dock_no%type, --码头
                              strWorkerNo       in idata_check_m.rgst_name%type, --操作人
                              strCheckTools     in idata_check_m.check_tools%type, --验收工具
                              strQuality        in idata_check_d.quality%type, --品质
                              dtProduceDate     in idata_check_d.produce_date%type,
                              dtExpireDate      in idata_check_d.expire_date%type,
                              strLotNo          in idata_check_d.lot_no%type, --批次号
                              strRSV_BATCH1     in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                              strRSV_BATCH2     in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                              strRSV_BATCH3     in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                              strRSV_BATCH4     in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                              strRSV_BATCH5     in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                              strRSV_BATCH6     in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                              strRSV_BATCH7     in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                              strRSV_BATCH8     in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                              strLabelNo        in stock_label_m.label_no%type, --实体标签号
                              strDeviceNo       in idata_check_pal_tmp.sub_label_no%type, --子标签号
                              --strFixPalFlag     in idata_check_pal.Fixpal_Flag%type, --1：固定板号；2：流水板号;
                              --strBusinessType   in idata_check_pal.Fixpal_Flag%type, --业务类型：0-普通验收；1-直通验收；2-大批量验收；3-客户别；5-越库；6-B/C品
                              strDeviceGroupNo in device_divide_group.device_group_no%type, --设备组
                              strPrintFlag     in bdef_defarticle.print_flag%type,
                              strsCheckNo      out idata_check_m.s_check_no%type,
                              strResult        out varchar2) is
    /*直通封箱*/
    v_stockType  idata_import_mm.stock_type%type;
    v_stockValue idata_import_mm.stock_value%type;

    v_strsCheckNo idata_check_m.s_check_no%type;

    v_strContainerNo stock_label_m.container_no%type;
    v_strCellNo      stock_content.cell_no%type;

    v_PrintTaskNo job_printtask_m.task_no%type;
    v_strWaveNo   idata_import_mm.wave_no%type;
  begin
    strResult := 'N|[P_SAVE_IDCLOSEBOX]';

    begin
      select stock_type, a.stock_value,a.wave_no
        into v_stockType, v_stockValue,v_strWaveNo
        from idata_import_mm a
       where warehouse_no = strWareHouseNo
         and enterprise_no = strEnterpriseNo
         and owner_no = strOwnerNo
         and s_import_no = strsImportNo;
    exception
      when no_data_found then
        strResult := 'N|[E20903]'; --取进货汇总单信息失败
        return;
    end;

    --直通配量
    P_SAVE_ID_ALLOT(strEnterpriseNo,
                    strWareHouseNo,
                    strOwnerNo,
                    strsImportNo,
                    strArticleNo,
                    nPackingQty,
                    nCheckQty,
                    strCheckTools,
                    strPrinterGroupNo,
                    strDockNo,
                    strLabelNo,
                    strDeviceNo,
                    strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;
    --取汇总验收单号；
    begin
      select distinct s_check_no
        into v_strsCheckNo
        from idata_check_m
       where enterprise_no = strEnterpriseNo
         and warehouse_no = strWareHouseNo
         and owner_no = strOwnerNo
         and s_import_no = strsImportNo
         and status <> '13';
    exception
      when no_data_found then

        --若取不到汇总验收单号，则写验收头档；
        PKOBJ_IDATA.p_Insert_Idata_Check_M(strEnterpriseNo,
                                           strWareHouseNo,
                                           strOwnerNo,
                                           strSImportNo,
                                           strDockNo,
                                           strWorkerNo,
                                           strPrinterGroupNo,
                                           strCheckTools,
                                           v_strsCheckNo,
                                           strResult);
        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;
    end;

    begin
      select cell_no
        into v_strCellNo
        from (select CDC.CELL_NO
                FROM Cdef_DEFAREA CDA, Cdef_DEFCELL CDC
               WHERE CDA.Enterprise_No = CDC.Enterprise_No
                 and CDA.warehouse_no = CDC.warehouse_no
                 AND CDA.WARE_NO = CDC.WARE_NO
                 AND CDA.AREA_NO = CDC.AREA_NO
                 and CDA.Enterprise_No = strEnterpriseNo
                 and CDA.WAREHOUSE_NO = strWareHouseNo
                 AND CDA.AREA_ATTRIBUTE = '1' --暂存区
                 and CDA.AREA_USETYPE = '1' --普通区
                 AND CDA.ATTRIBUTE_TYPE = '2' --进货区或者存储区
                 and cdc.cell_status = '0'
                 and cdc.check_status = '0'
               ORDER BY CDA.ATTRIBUTE_TYPE DESC, CDC.cell_no)
       where rownum < 2;
    exception
      when no_data_found then
        strResult := 'N|[E00100]';
        return;
    end;

    strsCheckNo := v_strsCheckNo;

    for p in (select distinct c.device_no
                from middata_allot_detail t,
                     cset_cust_dpscell    a,
                     cdef_defcell_dps     b,
                     device_divide_m      c
               where t.enterprise_no = a.enterprise_no
                 and t.warehouse_no = a.warehouse_no
                 and t.cust_no = a.cust_no
                 and a.enterprise_no = b.enterprise_no
                 and a.warehouse_no = b.warehouse_no
                 and a.dps_cell_no = b.cell_no
                 and b.enterprise_no = c.enterprise_no
                 and b.warehouse_no = c.warehouse_no
                 and b.DEVICE_NO = c.device_no
                 and a.status = '1'
                 and t.ALLOT_QTY > 0
                 and t.enterprise_no = strEnterpriseNo
                 and t.warehouse_no = strWareHouseNo
                 and t.source_no = strsImportNo
                 and t.article_no = strArticleNo
                 and ((c.device_no = strDeviceNo or
                     (strDeviceNo is null or strDeviceNo = 'N')) and
                     (c.device_group_no = strDeviceGroupNo or
                     (strDeviceGroupNo is null or strDeviceGroupNo = 'N')))) loop
      --写标签，分播指示，更新进货表
      P_SAVE_ID_LOCATE(strEnterpriseNo,
                       strWareHouseNo,
                       strOwnerNo,
                       strsImportNo,
                       strArticleNo,
                       strBarcode,
                       nPackingQty,
                       strWorkerNo,
                       strQuality,
                       dtProduceDate,
                       dtExpireDate,
                       strLotNo,
                       strRSV_BATCH1,
                       strRSV_BATCH2,
                       strRSV_BATCH3,
                       strRSV_BATCH4,
                       strRSV_BATCH5,
                       strRSV_BATCH6,
                       strRSV_BATCH7,
                       strRSV_BATCH8,
                       strLabelNo,
                       p.device_no,
                       strsCheckNo,
                       v_strCellNo,
                       v_stockType,
                       strDockNo,v_strWaveNo,
                       v_strContainerNo,
                       strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
      --分播发单
      PKLG_ODATA_DIVIDE.P_OutStock_Divide(strEnterpriseNo,
                                          strwarehouseNo,
                                          strOwnerNo,
                                          strDockNo,
                                          strsCheckNo,
                                          v_strContainerNo,
                                          strWorkerNo,
                                          strWorkerNo,
                                          '0',
                                          strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      --写分播标签打印任务
      --写打印任务
      if v_PrintTaskNo is null then
        PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                   strWareHouseNo,
                                   CONST_DOCUMENTTYPE.PRINTPT,
                                   v_PrintTaskNo,
                                   strResult);
        if substr(strResult, 1, 1) <> 'Y' then
          return;
        end if;

        PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterpriseNo,
                                            strWareHouseNo,
                                            v_strsCheckNo,
                                            '0',
                                            CONST_REPORTID.IM_ID_DIVIDE_P,
                                            strDockNo,
                                            '0',
                                            strWorkerNo,
                                            v_PrintTaskNo,
                                            strResult);
        if substr(strResult, 1, 1) <> 'Y' then
          return;
        end if;
      end if;
      PKOBJ_PRINTTASK.p_insert_taskdetail(strEnterpriseNo,
                                          strWareHouseNo,
                                          v_PrintTaskNo,
                                          v_strContainerNo,
                                          1,
                                          1,
                                          strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;
    end loop;

    --删除本次配量结果
    delete from middata_allot_detail md
     where md.enterprise_no = strEnterpriseNo
       and md.warehouse_no = strWareHouseNo
       and md.source_no = strsImportNo
       and md.article_no = strArticleNo;
    --删除临时表数据
    delete from idata_check_pal_tmp t
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWareHouseNo
       and t.owner_no = strOwnerNo
       and t.s_import_no = strsImportNo
       and t.article_no = strArticleNo
       and t.packing_qty = nPackingQty
       and t.label_no = strLabelNo
       and t.sub_label_no = strDeviceNo
       and t.printer_group_no = strPrinterGroupNo
       and t.dock_no = strDockNo
       and t.check_tools = strCheckTools;

    --打印吊牌
    P_IDCHECK_PRINT(strEnterpriseNo,
                    strWareHouseNo,
                    strArticleNo,
                    strBarcode,
                    nCheckQty,
                    strDockNo,
                    strWorkerNo,
                    strPrintFlag,
                    strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;
    strResult := 'Y|成功!';

  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_SAVE_IDCLOSEBOX;

  /************************************************************************************************
       修改人：wyf
       日期：2015-07-15
       功能：直通验收封箱配量
  *************************************************************************************************/
  procedure P_SAVE_ID_ALLOT(strEnterpriseNo   in idata_check_m.enterprise_no%type,
                            strWareHouseNo    in idata_check_m.warehouse_no%type,
                            strOwnerNo        in idata_check_m.owner_no%type,
                            strsImportNo      in idata_check_m.s_import_no%type, --进货汇总单号
                            strArticleNo      in idata_check_d.article_no%type,
                            nPackingQty       in idata_check_d.packing_qty%type,
                            nCheckQty         in idata_check_d.check_qty%type,
                            strCheckTools     in idata_check_m.check_tools%type, --验收工具
                            strPrinterGroupNo in idata_check_m.printer_group_no%type, --工作站
                            strDockNo         in idata_check_m.dock_no%type, --码头
                            strLabelNo        in idata_check_pal_tmp.label_no%type,
                            strDeviceNo       in idata_check_pal_tmp.sub_label_no%type, --子标签号
                            strResult         out varchar2) is

  v_nAllotID   number;

  begin
    strResult := 'N|[P_SAVE_ID_ALLOT]';
    select seq_middata_allot_detail.nextval into v_nAllotID from dual;
    insert into middata_allot_detail
      (tmp_id,
       warehouse_no,
       source_no,
       outstock_type,
       article_no,
       cust_no,
       po_no,
       plan_qty,
       allot_qty,
       enterprise_no)
      select v_nAllotID,sm.warehouse_no,
             sm.s_import_no,
             'ID',
             sa.article_no,
             sa.cust_no,
             sa.po_no,
             sum(sa.po_qty - sa.allot_qty),
             0,
             sm.enterprise_no
        from Idata_Import_Allot sa, idata_import_sm sm
       where sa.enterprise_no = sm.enterprise_no
         and sa.warehouse_no = sm.warehouse_no
         and sa.import_no = sm.import_no
         and sa.owner_no = sm.owner_no
         and sa.article_no = strArticleNo
         and sm.enterprise_no = strEnterpriseNo
         and sm.warehouse_no = strWareHouseNo
         and sm.s_import_no = strsImportNo
         and sa.status < '13'
       group by sm.enterprise_no,
                sm.warehouse_no,
                sm.s_import_no,
                sa.article_no,
                sa.cust_no,
                sa.po_no;

    if strCheckTools = '1' then
      --前台操作使用配量存储过程
      Pklg_Publocate.p_locate_allot(v_nAllotID,strEnterpriseNo,
                                    strWareHouseNo,
                                    strsImportNo,
                                    'ID',
                                    'C',
                                    nCheckQty,
                                    nPackingQty,
                                    strResult);
      if substr(strResult, 1, 2) = 'N|' then
        return;
      end if;
    elsif strCheckTools = '2' then
      --RF操作通过idata_check_pal_tmp表更新配量middata_allot_detail
      for p in (select sum(t.check_qty) cust_qty, t.cust_no, t.article_no
                  from idata_check_pal_tmp t
                 where t.enterprise_no = strEnterpriseNo
                   and t.warehouse_no = strWareHouseNo
                   and t.owner_no = strOwnerNo
                   and t.s_import_no = strsImportNo
                   and t.article_no = strArticleNo
                   and t.printer_group_no = strPrinterGroupNo
                   and t.dock_no = strDockNo
                   and t.label_no = strLabelNo
                   and t.sub_label_no = strDeviceNo
                 group by t.cust_no, t.article_no) loop
        update middata_allot_detail m
           set m.allot_qty = p.cust_qty
         where m.cust_no = p.cust_no
           and m.enterprise_no = strEnterpriseNo
           and m.warehouse_no = strWareHouseNo
           and m.source_no = strsImportNo
           and m.article_no = strArticleNo;
      end loop;
    else
      strResult := 'N|[操作工具选择有误！]';
      return;
    end if;
    strResult := 'Y|成功!';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_SAVE_ID_ALLOT;

  /************************************************************************************************
       修改人：wyf
       日期：2015-07-15
       功能：直通封箱写标签，分播指示，更新进货表
  *************************************************************************************************/
  procedure P_SAVE_ID_LOCATE(strEnterpriseNo in idata_check_m.enterprise_no%type,
                             strWareHouseNo  in idata_check_m.warehouse_no%type,
                             strOwnerNo      in idata_check_m.owner_no%type,
                             strsImportNo    in idata_check_m.s_import_no%type, --进货汇总单号
                             strArticleNo    in idata_check_d.article_no%type,
                             strBarcode      in idata_check_d.barcode%type,
                             nPackingQty     in idata_check_d.packing_qty%type,
                             strWorkerNo     in idata_check_m.rgst_name%type, --操作人
                             strQuality      in idata_check_d.quality%type, --品质
                             dtProduceDate   in idata_check_d.produce_date%type,
                             dtExpireDate    in idata_check_d.expire_date%type,
                             strLotNo        in idata_check_d.lot_no%type, --批次号
                             strRSV_BATCH1   in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                             strRSV_BATCH2   in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                             strRSV_BATCH3   in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                             strRSV_BATCH4   in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                             strRSV_BATCH5   in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                             strRSV_BATCH6   in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                             strRSV_BATCH7   in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                             strRSV_BATCH8   in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                             strLabelNo      in stock_label_m.label_no%type, --实体标签号
                             strDeviceNo     in idata_check_pal_tmp.sub_label_no%type,
                             strsCheckNo     in idata_check_m.s_check_no%type,
                             strCellNo       in stock_content.cell_no%type,
                             strStockType    in idata_import_mm.stock_type%type,
                             strDockNo       in idata_check_pal.dock_no%type,
                             strWaveNo       in idata_import_mm.wave_no%type,
                             strContainerNo  out stock_label_m.label_no%type, --内部容器号z
                             strResult       out varchar2) is
    v_strLabelNoTmp stock_label_m.label_no%type; --板号
    v_strSessionID  varchar2(10);

    v_nRoWid idata_check_d.row_id%type;

    v_blExcessFlag  boolean;
    v_nCustTotalQty idata_import_d.po_qty%type; --门店预配量
    v_nCustAllotQty idata_import_d.po_qty%type;

    v_nArticleId stock_article_info.article_id%type;

    v_nCellID      stock_content.cell_id%type;
    v_nDIVIDEID    stock_label_d.divide_id%type;
    v_strBatchNo   bset_defbatch.batch_no%type := 'N';
    v_strDpsCellNo cset_cust_dpscell.dps_cell_no%type;

  begin
    strResult := 'N|[P_SAVE_ID_LOCATE]';
    --取P标签 只取一个标签
    begin
      select a.container_no
        into strContainerNo
        from STOCK_LABEL_M a
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWareHouseNo
         and a.source_no = strsCheckNo
         and a.label_no = strLabelNo;
    exception
      when no_data_found then
        pklg_wms_base.p_get_ContainerNoBase(strEnterpriseNo,
                                            strWareHouseNo,
                                            'P',
                                            strWorkerNo,
                                            'D',
                                            1,
                                            '2',
                                            '31',
                                            v_strLabelNoTmp,
                                            strContainerNo,
                                            v_strSessionID,
                                            strResult);
        if (substr(strResult, 1, 1) = 'N') then
          strResult := 'N|[E00005]';
          return;
        end if;

        --判断传入的标签是否为N
        if strLabelNo <> 'N' then
          v_strLabelNoTmp := strLabelNo;
        end if;

        --写标签
        pkobj_label.proc_Insert_LabelMaster(strEnterpriseNo,
                                            strWareHouseNo,
                                            v_strBatchNo,
                                            strsCheckNo,
                                            v_strLabelNoTmp,
                                            strContainerNo,
                                            'P',
                                            'N',
                                            strCellNo,
                                            'N', --strCUST_NO
                                            'N', --strTRUNCK_CELL_NO
                                            'N', --strA_SORTER_CHUTE_NO
                                            'N', --strCHECK_CHUTE_NO
                                            'N', --strDELIVER_OBJ
                                            '2', --strUSE_TYPE
                                            'N', --strLINE_NO
                                            'N', --strCURR_AREA
                                            strDeviceNo, --strEQUIPMENT_NO
                                            strWorkerNo, --strRGST_NAME
                                            CONST_REPORTID.IM_ID_DIVIDE_P, --'N', --strREPORT_ID
                                            'N', --strMID_LABEL_NO
                                            'N', --strBIG_EXP_NO_FLAG
                                            strStockType, --strSTOCK_TYPE
                                            '0', --strCHUTE_LABEL_FLAG
                                            strContainerNo, --strOWNER_CONTAINER_NO
                                            CLabelStatus.PICK_END, --strstatus
                                            '1',strWaveNo, --strHm_Manual_Flag
                                            strResult); --strOutMsg
        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;
    end;

    --判断传入的标签是否为N
    if strLabelNo <> 'N' then
      v_strLabelNoTmp := strLabelNo;
    end if;

    for v_cs_allot in (select distinct md.*
                         from middata_allot_detail md,
                              cset_cust_dpscell    a,
                              cdef_defcell_dps     b,
                              device_divide_m      c
                        where md.enterprise_no = a.enterprise_no
                          and md.warehouse_no = a.warehouse_no
                          and md.cust_no = a.cust_no
                          and a.enterprise_no = b.enterprise_no
                          and a.warehouse_no = b.warehouse_no
                          and a.dps_cell_no = b.cell_no
                          and b.enterprise_no = c.enterprise_no
                          and b.warehouse_no = c.warehouse_no
                          and b.DEVICE_NO = c.device_no
                          and a.status = '1'
                          and md.enterprise_no = strEnterpriseNo
                          and md.warehouse_no = strWareHouseNo
                          and md.source_no = strsImportNo
                          and md.article_no = strArticleNo
                          and c.device_no = strDeviceNo
                          and md.allot_qty > 0) loop
      v_nCustTotalQty := v_cs_allot.allot_qty;

      v_blExcessFlag := false;

      <<continue_allot>>
      for v_cs_cust in (select icm.import_type,
                               sa.import_no,
                               icm.check_no,
                               sa.packing_qty,
                               sa.cust_no,
                               sa.sub_cust_no,
                               sa.po_no,icd.price,
                               (sa.po_qty - sa.allot_qty) as unallot_qty
                          from Idata_Import_Allot sa,
                               idata_import_sm    sm,
                               idata_check_m      icm,
                               idata_check_d      icd
                         where icm.enterprise_no = sm.enterprise_no
                           and icm.warehouse_no = sm.warehouse_no
                           and icm.import_no = sm.import_no
                           and icm.s_check_no = strsCheckNo
                           and icm.enterprise_no=icd.enterprise_no
                           and icm.warehouse_no=icd.warehouse_no
                           and icm.check_no=icd.check_no
                           and sa.article_no=icd.article_no
                           and sa.packing_qty=icd.packing_qty
                           and sa.warehouse_no = sm.warehouse_no
                           and sa.enterprise_no = strEnterpriseNo
                           and sa.enterprise_no = sm.enterprise_no
                           and sa.import_no = sm.import_no
                           and sa.owner_no = sm.owner_no
                           and sa.article_no = strArticleNo
                           and sa.cust_no = v_cs_allot.cust_no
                           and sm.warehouse_no = strWareHouseNo
                           and sm.s_import_no = strsImportNo
                         order by case
                                    when sa.packing_qty = nPackingQty then
                                     0
                                    else
                                     1
                                  end) loop
        if v_blExcessFlag = false then
          v_nCustAllotQty := v_cs_cust.unallot_qty;
          if v_nCustAllotQty > v_nCustTotalQty then
            v_nCustAllotQty := v_nCustTotalQty;
          end if;
        else
          v_nCustAllotQty := v_nCustTotalQty;
        end if;

        v_nCustTotalQty := v_nCustTotalQty - v_nCustAllotQty;

        --获取商品属性ID
        PKLG_WMS_BASE.p_getArticleID(strEnterpriseNo,
                                     strArticleNo,
                                     strBarcode,
                                     strLotNo,
                                     dtProduceDate,
                                     dtExpireDate,
                                     strQuality,
                                     strRSV_BATCH1,
                                     strRSV_BATCH2,
                                     strRSV_BATCH3,
                                     strRSV_BATCH4,
                                     strRSV_BATCH5,
                                     strRSV_BATCH6,
                                     strRSV_BATCH7,
                                     strRSV_BATCH8,
                                     v_cs_cust.check_no,
                                     '0',
                                     strWorkerNo,v_cs_cust.price,
                                     v_nArticleId,
                                     strResult);
        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        --写验收明细
        PKOBJ_IDATA.p_idata_IDInsertCheckD(strEnterpriseNo,
                                           strWareHouseNo,
                                           strOwnerNo,
                                           strsImportNo,
                                           strsCheckNo,
                                           v_cs_cust.import_no,
                                           strArticleNo,
                                           strBarcode,
                                           nPackingQty,
                                           v_nCustAllotQty,
                                           strLotNo,
                                           dtProduceDate,
                                           dtExpireDate,
                                           strQuality,
                                           strWorkerNo,
                                           v_nRoWid,
                                           strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        --写板明细
        PKOBJ_IDATA.p_idata_InsertIDCheckPal(strEnterpriseNo,
                                             strWareHouseNo,
                                             strOwnerNo,
                                             strsImportNo,
                                             v_cs_cust.import_no,
                                             strWorkerNo,
                                             v_strLabelNoTmp,
                                             strDeviceNo,
                                             strContainerNo,
                                             v_cs_cust.cust_no,
                                             1,
                                             v_nCustAllotQty,
                                             strDockNo,
                                             v_nRoWid, strWaveNo,
                                             strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        --更新进货汇总明细表
        update IDATA_IMPORT_SD
           set IMPORT_QTY = IMPORT_QTY + v_nCustAllotQty, status = '12'
         where enterprise_no = strEnterpriseNo
           and WAREHOUSE_NO = strWareHouseNo
           and OWNER_NO = strOwnerNo
           and S_IMPORT_NO = strsImportNo
           and Article_No = strArticleNo
           and PACKING_QTY = v_cs_cust.packing_qty;

        --更新进货单明细表
        update IDATA_IMPORT_D
           set IMPORT_QTY = IMPORT_QTY + v_nCustAllotQty, status = '12'
         where enterprise_no = strEnterpriseNo
           and WAREHOUSE_NO = strWareHouseNo
           and OWNER_NO = strOwnerNo
           and IMPORT_NO = v_cs_cust.import_no
           and Article_No = strArticleNo
           and PACKING_QTY = v_cs_cust.packing_qty;

        --更新进货配量细表
        update Idata_Import_Allot
           set allot_qty = allot_qty + v_nCustAllotQty,
               status    = '12',
               updt_name = strWorkerNo,
               updt_date = sysdate
         where enterprise_no = strEnterpriseNo
           and WAREHOUSE_NO = strWareHouseNo
           and OWNER_NO = strOwnerNo
           and import_no = v_cs_cust.import_no
           and cust_no = v_cs_cust.cust_no
           and sub_cust_no = v_cs_cust.sub_cust_no
           and Article_No = strArticleNo
           and PACKING_QTY = v_cs_cust.packing_qty;

        v_nDIVIDEID := SEQ_ODATA_OUTSTOCK_DIRECT.NEXTVAL;
        --获取该客户的电子标签储位；
        begin
          select dps_cell_no
            into v_strDpsCellNo
            from cset_cust_dpsCell
           where enterprise_no = strEnterpriseNo
             and warehouse_no = strWareHouseNo
             and cust_no = v_cs_cust.cust_no
             and device_no = strDeviceNo
             and rownum = 1;
        exception
          when no_data_found then

            --锁定客户电子标签储位对照表
            update cset_cust_dpscell
               set status = status
             where warehouse_no = strWareHouseNo;

            begin
              select a.cell_no
                INTO v_strDpsCellNo
                from (select *
                        from DEVICE_DIVIDE_M ode,
                             cdef_defcell    cd,
                             cdef_defarea    a
                       where ode.enterprise_no = cd.enterprise_no
                         and ode.warehouse_no = cd.warehouse_no
                         and ode.a_stock_no =
                             cd.ware_no || cd.area_no || cd.stock_no
                         and ode.warehouse_no = cd.warehouse_no
                         and cd.ware_no || cd.area_no =
                             a.ware_no || a.area_no
                         and cd.enterprise_no = a.enterprise_no
                         and cd.warehouse_no = a.warehouse_no
                         and a.area_usetype = '1'
                         and a.area_attribute = '1'
                         and a.attribute_type = '9'
                         and cd.cell_status = '0'
                         and cd.cell_no not in
                             (select dps_cell_no from cset_cust_dpscell)
                         and cd.warehouse_no = strWareHouseNo
                         and cd.enterprise_no = strEnterpriseNo
                         and ode.status = '0'
                       order by cd.stock_y desc) a
               where rownum = 1;
            exception
              when no_data_found then
                strResult := 'N|[E20939]';
                return;
            end;
            --自动新增一个储位
            insert into cset_cust_dpscell
              (warehouse_no,
               owner_no,
               cust_no,
               dps_cell_no,
               rgst_name,
               rgst_date,
               enterprise_no)
            values
              (strWareHouseNo,
               strOwnerNo,
               v_cs_cust.cust_no,
               v_strDpsCellNo,
               strWorkerNo,
               sysdate,
               strEnterpriseNo);

          /*                    strResult:='N|[E20939]';
          return;*/
        end;

        --新增标签明细
        PKOBJ_LABEL.proc_Insert_LabelDetail(strEnterpriseNo,
                                            strWareHouseNo,
                                            v_strBatchNo,
                                            strOwnerNo,
                                            strsCheckNo,
                                            strContainerNo,
                                            'P',
                                            strArticleNo,
                                            v_nArticleId,
                                            nPackingQty,
                                            v_nCustAllotQty,
                                            v_cs_cust.po_no,
                                            strsCheckNo,
                                            v_cs_cust.cust_no,
                                            v_cs_cust.sub_cust_no,
                                            'N',
                                            CLabelStatus.PICK_END,
                                            v_nDIVIDEID,
                                            'ID',
                                            v_strDpsCellNo,
                                            strWorkerNo,
                                            v_cs_cust.cust_no,'N',
                                            trunc(sysdate),
                                            strCellNo,--Modify BY QZH AT 2016-5-25
                                            '10',
                                            strResult);
        if substr(strResult, 1, 1) <> 'Y' then
          return;
        end if;

        --写库存
        PKOBJ_STOCK.p_Idata_InsertIdStockItem(strEnterpriseNo,
                                              strWareHouseNo,
                                              strsCheckNo,
                                              strArticleNo,
                                              strContainerNo,
                                              strBarcode,
                                              strLotNo,
                                              dtProduceDate,
                                              dtExpireDate,
                                              strQuality,
                                              v_nArticleId,
                                              nPackingQty,
                                              v_nRoWid,
                                              v_nCustAllotQty,
                                              v_cs_cust.check_no,
                                              '1',
                                              strWorkerNo,
                                              strCellNo,
                                              v_nCellID,
                                              strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;
        --更新板明细状态
        update idata_check_pal icp
           set icp.status    = '13',
               icp.updt_name = strWorkerNo,
               icp.updt_date = sysdate
         where icp.enterprise_no = strEnterpriseNo
           and icp.warehouse_no = strWareHouseNo
           and icp.owner_no = strOwnerNo
           and icp.s_check_no = strsCheckNo
           and icp.check_no = v_cs_cust.check_no
           and icp.check_row_id = v_nRoWid
           and icp.container_no = strContainerNo
           and icp.label_no = v_strLabelNoTmp
           and icp.sub_label_no = strDeviceNo
           and icp.cust_no = v_cs_cust.cust_no;
        --写分播指示
        Insert into ODATA_DIVIDE_DIRECT
          (WAREHOUSE_NO,
           OWNER_NO,
           BATCH_NO,
           SOURCE_NO,
           DIVIDE_ID,
           OPERATE_DATE,
           CUST_NO,
           SUB_CUST_NO,
           ARTICLE_NO,
           ARTICLE_ID,
           PACKING_QTY,
           ARTICLE_QTY,
           S_CELL_NO,
           S_CELL_ID,
           S_CONTAINER_NO, --CUST_CONTAINER_NO,
           EXP_TYPE,
           EXP_NO,
           WAVE_NO,
           DELIVER_AREA,
           STATUS,
           LINE_NO,
           TRUNCK_CELL_NO,
           CHECK_CHUTE_NO,
           DELIVER_OBJ,
           ADVANCE_CELL_NO,
           OUTSTOCK_DATE,
           DPS_CELL_NO,
           A_SORTER_CHUTE_NO,
           EXP_DATE,
           RGST_NAME,
           RGST_DATE,
           UPDT_NAME,
           UPDT_DATE,
           DEVICE_NO,
           enterprise_no)
        values
          (strWareHouseNo,
           strOwnerNo,
           'N',
           strsCheckNo,
           v_nDIVIDEID,
           trunc(sysdate),
           v_cs_cust.cust_no,
           v_cs_cust.sub_cust_no,
           strArticleNo,
           v_nArticleId,
           nPackingQty,
           v_nCustAllotQty,
           strCellNo,
           v_nCellID,
           strContainerNo, --'N',
           v_cs_cust.import_type,
           v_cs_cust.po_no,
           strsCheckNo,
           'N',
           '10',
           'N',
           'N', --TRUNCK_CELL_NO
           'N',
           v_cs_cust.cust_no,
           'N',
           sysdate,
           v_strDpsCellNo,
           'N', --A_SORTER_CHUTE_NO 预留
           trunc(sysdate),
           strWorkerNo,
           sysdate,
           strWorkerNo,
           sysdate,
           strDeviceNo,
           strEnterpriseNo);

        if v_nCustTotalQty <= 0 then
          exit;
        end if;

      end loop;

      --如果按量没有配完，说明是超量
      if v_nCustTotalQty > 0 then
        v_blExcessFlag := true;
        goto continue_allot;
      end if;

    end loop;

    strResult := 'Y|成功!';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_SAVE_ID_LOCATE;
  /************************************************************************************************
       修改人：wyf
       日期：2015-07-15
       功能：直通转存储
  *************************************************************************************************/
  procedure P_SAVE_ID2IS(strEnterpriseNo   in idata_check_m.enterprise_no%type,
                         strWareHouseNo    in idata_check_m.warehouse_no%type,
                         strOwnerNo        in idata_check_m.owner_no%type,
                         strsImportNo      in idata_check_m.s_import_no%type, --进货汇总单号
                         strArticleNo      in idata_check_d.article_no%type,
                         strBarcode        in idata_check_d.barcode%type,
                         nPackingQty       in idata_check_d.packing_qty%type,
                         nCheckQty         in idata_check_d.check_qty%type, --当前剩余验收数量
                         strPrinterGroupNo in idata_check_m.printer_group_no%type, --工作站
                         strDockNo         in idata_check_m.dock_no%type, --码头
                         strWorkerNo       in idata_check_m.rgst_name%type, --操作人
                         strCheckTools     in idata_check_m.check_tools%type, --验收工具
                         strQuality        in idata_check_d.quality%type, --品质
                         dtProduceDate     in idata_check_d.produce_date%type,
                         dtExpireDate      in idata_check_d.expire_date%type,
                         strLotNo          in idata_check_d.lot_no%type, --批次号
                         strRSV_BATCH1     in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                         strRSV_BATCH2     in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                         strRSV_BATCH3     in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                         strRSV_BATCH4     in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                         strRSV_BATCH5     in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                         strRSV_BATCH6     in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                         strRSV_BATCH7     in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                         strRSV_BATCH8     in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                         strLabelNo        in stock_label_m.label_no%type, --实体标签号
                         strSubLabelNo     in idata_check_pal_tmp.sub_label_no%type, --子标签号
                         strFixPalFlag     in idata_check_pal.Fixpal_Flag%type, --1：固定板号；2：流水板号;
                         strBusinessType   in idata_check_pal.business_type%type, --业务类型：0-普通验收；1-直通验收；2-大批量验收；3-客户别；5-越库；6-B/C品
                         strsCheckNo       out idata_check_m.s_check_no%type,
                         strResult         out varchar2) is
    /*直通转存储*/
    v_strLocateNo    idata_locate_direct.locate_no%type;
    v_strPrintTaskNo job_printtask_m.task_no%type;
    v_strInstockNo   idata_instock_m.instock_no%type;

    v_strLabelNoTmp    stock_label_m.label_no%type;
    v_strSubLabelNoTmp idata_check_pal_tmp.sub_label_no%type;
    v_strContainNo     idata_check_pal.container_no%type;
    v_strSessionID     varchar2(10);
  begin
    strResult := 'N|[P_SAVE_ID2IS]';
    if strFixPalFlag = '3' then
      --混合板，重新获取标签
      --取标签
      pklg_wms_base.p_get_ContainerNoBase(strEnterpriseNo,
                                          strWareHouseNo,
                                          'P',
                                          strWorkerNo,
                                          'D',
                                          1,
                                          2, --标签用途
                                          '31', --容器材质(板)
                                          v_strLabelNoTmp,
                                          v_strContainNo,
                                          v_strSessionID,
                                          strResult);
      if substr(strResult, 1, 1) = 'N' then
        return;
      end if;
      v_strSubLabelNoTmp := v_strLabelNoTmp;
    else
      v_strLabelNoTmp    := strLabelNo;
      v_strSubLabelNoTmp := strSubLabelNo;
    end if;
    --直通单剩余部分转存储
    --写临时板明细
    pklg_idata.P_SaveCheckDataIS(strEnterpriseNo,
                                 strWareHouseNo,
                                 strOwnerNo,
                                 strsImportNo,
                                 strArticleNo,
                                 strBarcode,
                                 nPackingQty,
                                 nCheckQty,
                                 strPrinterGroupNo,
                                 strDockNo,
                                 strWorkerNo,
                                 strCheckTools,
                                 0,
                                 strQuality,
                                 dtProduceDate,
                                 dtExpireDate,
                                 strLotNo,
                                 strRSV_BATCH1,
                                 strRSV_BATCH2,
                                 strRSV_BATCH3,
                                 strRSV_BATCH4,
                                 strRSV_BATCH5,
                                 strRSV_BATCH6,
                                 strRSV_BATCH7,
                                 strRSV_BATCH8,
                                 'N', --温度
                                 v_strLabelNoTmp,
                                 v_strSubLabelNoTmp,
                                 strFixPalFlag,
                                 strBusinessType,
                                 strsCheckNo,
                                 strResult);

    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    --封板
    PKLG_IDATA.P_Close_Pal_Main(strEnterpriseNo,
                                strWareHouseNo,
                                strOwnerNo,
                                strsImportNo,
                                strsCheckNo,
                                v_strLabelNoTmp,
                                strWorkerNo,
                                strFixPalFlag,
                                strResult);

    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;

    --循环封板
    for a in (select distinct t.label_no
                from idata_check_pal t
               where t.warehouse_no = strWareHouseNo
                 AND T.owner_no = strOwnerNo
                 and t.s_check_no = strsCheckNo
                 AND t.status = '10'
                 and t.rgst_name = strWorkerNo
                 and t.BUSINESS_TYPE = strBusinessType) loop
      PKLG_IDATA.p_idata_sCheckLocateInstock(strEnterpriseNo,
                                             strWareHouseNO,
                                             strsCheckNo,
                                             strWorkerNo,
                                             strCheckTools,
                                             'N',
                                             a.label_no,
                                             v_strLocateNo,
                                             strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
      --入库定位
      PKLG_ILOCATE.p_locate_main(strEnterpriseNo,
                                 strWareHouseNo,
                                 strOwnerNo,
                                 v_strLocateNo,
                                 '0',
                                 strWorkerNo,
                                 v_strPrintTaskNo,
                                 strResult);

      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
      --上架发单
      pklg_idata.P_InsertInstock(strEnterpriseNo,
                                 strWareHouseNo,
                                 strWorkerNo,
                                 v_strLocateNo,
                                 strDockNo,
                                 '2',
                                 v_strInstockNo,
                                 strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

    end loop;
    strResult := 'Y|成功!';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_SAVE_ID2IS;

  /************************************************************************************************
       修改人：wyf
       日期：2015-07-15
       功能：扫描扣减数量
  *************************************************************************************************/
  procedure P_SCAN_DEDUCTION(strEnterpriseNo   in idata_check_m.enterprise_no%type,
                             strWareHouseNo    in idata_check_m.warehouse_no%type,
                             strOwnerNo        in idata_check_m.owner_no%type,
                             strsImportNo      in idata_check_m.s_import_no%type, --进货汇总单号
                             strArticleNo      in idata_check_d.article_no%type,
                             strBarcode        in idata_check_d.barcode%type,
                             nPackingQty       in idata_check_d.packing_qty%type,
                             nCheckQty         in idata_check_d.check_qty%type,
                             strPrinterGroupNo in idata_check_m.printer_group_no%type, --工作站
                             strDockNo         in idata_check_m.dock_no%type, --码头
                             strWorkerNo       in idata_check_m.rgst_name%type, --操作人
                             strCheckTools     in idata_check_m.check_tools%type, --验收工具
                             strQuality        in idata_check_d.quality%type, --品质
                             dtProduceDate     in idata_check_d.produce_date%type,
                             dtExpireDate      in idata_check_d.expire_date%type,
                             strLotNo          in idata_check_d.lot_no%type, --批次号
                             strRSV_BATCH1     in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                             strRSV_BATCH2     in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                             strRSV_BATCH3     in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                             strRSV_BATCH4     in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                             strRSV_BATCH5     in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                             strRSV_BATCH6     in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                             strRSV_BATCH7     in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                             strRSV_BATCH8     in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                             strLabelNo        in stock_label_m.label_no%type, --实体标签号
                             strDeviceNo       in idata_check_pal_tmp.sub_label_no%type, --子标签号 保存设备号
                             strResult         out varchar2) is

    v_CurrQty idata_check_d.check_qty%type; --扣减数量
    v_MidQty  idata_check_d.check_qty%type; --剩余数量
    v_nCount  integer := 0;
  begin
    strResult := 'N|[P_SCAN_DEDUCTION]';
    v_CurrQty := -nCheckQty;
    for p in (select t.check_qty, t.cust_no
                from idata_check_pal_tmp t
               where t.enterprise_no = strEnterpriseNo
                 and t.warehouse_no = strWareHouseNo
                 and t.owner_no = strOwnerNo
                 and t.s_import_no = strsImportNo
                 and t.article_no = strArticleNo
                 and t.packing_qty = nPackingQty
                 and t.barcode = strBarcode
                 and t.printer_group_no = strPrinterGroupNo
                 and t.dock_no = strDockNo
                 and t.check_tools = strCheckTools
                 and t.label_no = strLabelNo
                 and t.sub_label_no = strDeviceNo
                 and t.quality = strQuality
                 and trunc(t.produce_date) = trunc(dtProduceDate)
                 and trunc(t.expire_date) = trunc(dtExpireDate)
                 and t.lot_no = strLotNo
                 and t.rsv_batch1 = strRSV_BATCH1
                 and t.rsv_batch2 = strRSV_BATCH2
                 and t.rsv_batch3 = strRSV_BATCH3
                 and t.rsv_batch4 = strRSV_BATCH4
                 and t.rsv_batch5 = strRSV_BATCH5
                 and t.rsv_batch6 = strRSV_BATCH6
                 and t.rsv_batch7 = strRSV_BATCH7
                 and t.rsv_batch8 = strRSV_BATCH8
               order by t.RGST_DATE DESC) loop
      v_nCount := v_nCount + 1;
      if v_CurrQty >= p.check_qty then
        v_MidQty := v_CurrQty - p.check_qty;
        --若输入数量大于等于某一笔的数量，直接删除扫描纪录
        delete from idata_check_pal_tmp t
         where t.enterprise_no = strEnterpriseNo
           and t.warehouse_no = strWareHouseNo
           and t.owner_no = strOwnerNo
           and t.s_import_no = strsImportNo
           and t.article_no = strArticleNo
           and t.packing_qty = nPackingQty
           and t.barcode = strBarcode
           and t.printer_group_no = strPrinterGroupNo
           and t.dock_no = strDockNo
           and t.check_tools = strCheckTools
           and t.label_no = strLabelNo
           and t.sub_label_no = strDeviceNo
           and t.quality = strQuality
           and trunc(t.produce_date) = trunc(dtProduceDate)
           and trunc(t.expire_date) = trunc(dtExpireDate)
           and t.lot_no = strLotNo
           and t.rsv_batch1 = strRSV_BATCH1
           and t.rsv_batch2 = strRSV_BATCH2
           and t.rsv_batch3 = strRSV_BATCH3
           and t.rsv_batch4 = strRSV_BATCH4
           and t.rsv_batch5 = strRSV_BATCH5
           and t.rsv_batch6 = strRSV_BATCH6
           and t.rsv_batch7 = strRSV_BATCH7
           and t.rsv_batch8 = strRSV_BATCH8
           and t.cust_no = p.cust_no;
      else
        v_MidQty := 0;
        --若输入数量小于某一笔数量，扣减输入数量
        update idata_check_pal_tmp t
           set t.check_qty = t.check_qty - v_CurrQty
         where t.enterprise_no = strEnterpriseNo
           and t.warehouse_no = strWareHouseNo
           and t.owner_no = strOwnerNo
           and t.s_import_no = strsImportNo
           and t.article_no = strArticleNo
           and t.packing_qty = nPackingQty
           and t.barcode = strBarcode
           and t.printer_group_no = strPrinterGroupNo
           and t.dock_no = strDockNo
           and t.check_tools = strCheckTools
           and t.label_no = strLabelNo
           and t.sub_label_no = strDeviceNo
           and t.quality = strQuality
           and trunc(t.produce_date) = trunc(dtProduceDate)
           and trunc(t.expire_date) = trunc(dtExpireDate)
           and t.lot_no = strLotNo
           and t.rsv_batch1 = strRSV_BATCH1
           and t.rsv_batch2 = strRSV_BATCH2
           and t.rsv_batch3 = strRSV_BATCH3
           and t.rsv_batch4 = strRSV_BATCH4
           and t.rsv_batch5 = strRSV_BATCH5
           and t.rsv_batch6 = strRSV_BATCH6
           and t.rsv_batch7 = strRSV_BATCH7
           and t.rsv_batch8 = strRSV_BATCH8
           and t.cust_no = p.cust_no;
      end if;
      if v_MidQty = 0 then
        exit;
      end if;

      v_CurrQty := v_MidQty;
    end loop;
    if v_nCount <= 0 then
      strResult := 'N|[没有需啊扣减的扫描数据]!';
      return;
    end if;
    strResult := 'Y|成功!';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_SCAN_DEDUCTION;

  /************************************************************************************************
       修改人：wyf
       日期：2015-07-15
       功能：打印吊牌和条码
  *************************************************************************************************/
  procedure P_IDCHECK_PRINT(strEnterpriseNo in idata_check_m.enterprise_no%type,
                            strWareHouseNo  in idata_check_m.warehouse_no%type,
                            strArticleNo    in idata_check_d.article_no%type,
                            strBarcode      in idata_check_d.barcode%type,
                            nCheckQty       in idata_check_d.check_qty%type,
                            --strPrinterGroupNo in idata_check_m.printer_group_no%type, --工作站
                            strDockNo    in idata_check_m.dock_no%type, --码头
                            strWorkerNo  in idata_check_m.rgst_name%type, --操作人
                            strPrintFlag in bdef_defarticle.print_flag%type,
                            strResult    out varchar2) is

    v_strPrintFlag bdef_defarticle.print_flag%type;
    v_PrintTaskNo  job_printtask_m.task_no%type;
  begin
    strResult := 'N|[P_IDCHECK_PRINT]';
    if strPrintFlag = 'N' then
      --判断商品是否需要打印吊牌和条码
      select bd.print_flag
        into v_strPrintFlag
        from bdef_defarticle bd
       where bd.article_no = strArticleNo;
    else
      v_strPrintFlag := strPrintFlag;
    end if;

    for p in (select t.report_id
                from pnt_article_group_report t
               where t.enterprise_no = strEnterpriseNo
                 and t.print_flag = v_strPrintFlag) loop
      --取打印任务号
      PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                 strWareHouseNo,
                                 CONST_DOCUMENTTYPE.PRINTPT,
                                 v_PrintTaskNo,
                                 strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;
      --写任务头档
      PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterpriseNo,
                                          strWareHouseNo,
                                          strArticleNo,
                                          '0',
                                          p.report_id,
                                          strDockNo,
                                          '0',
                                          strWorkerNo,
                                          v_PrintTaskNo,
                                          strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;
      --写任务明细
      PKOBJ_PRINTTASK.p_insert_taskdetail(strEnterpriseNo,
                                          strWareHouseNo,
                                          v_PrintTaskNo,
                                          strBarcode,
                                          1,
                                          nCheckQty,
                                          strResult);
      if substr(strResult, 1, 1) <> 'Y' then
        return;
      end if;
    end loop;

    strResult := 'Y|成功!';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_IDCHECK_PRINT;
  /************************************************************************************************
       修改人：wyf
       日期：2015-11-30
       功能：1、直通验收；
             2、分播发单；
             3、剩余商品转存储验收；
             4、存储定位；
             5、上架发单
             （不支持电子标签储位分播）
  *************************************************************************************************/
  procedure P_SAVE_IDCHECK(strEnterpriseNo   in idata_check_m.enterprise_no%type,
                           strWareHouseNo    in idata_check_m.warehouse_no%type,
                           strOwnerNo        in idata_check_m.owner_no%type,
                           strsImportNo      in idata_check_m.s_import_no%type, --进货汇总单号
                           strArticleNo      in idata_check_d.article_no%type,
                           strBarcode        in idata_check_d.barcode%type,
                           nPackingQty       in idata_check_d.packing_qty%type,
                           nCheckQty         in idata_check_d.check_qty%type,
                           strPrinterGroupNo in idata_check_m.printer_group_no%type, --工作站
                           strDockNo         in idata_check_m.dock_no%type, --码头
                           strWorkerNo       in idata_check_m.rgst_name%type, --操作人
                           strCheckTools     in idata_check_m.check_tools%type, --验收工具
                           nIsAdd            in integer, --是否累加 0:覆盖 1:累加
                           strQuality        in idata_check_d.quality%type, --品质
                           dtProduceDate     in idata_check_d.produce_date%type,
                           dtExpireDate      in idata_check_d.expire_date%type,
                           strLotNo          in idata_check_d.lot_no%type, --批次号
                           --strTemperature    in idata_check_pal_tmp.temperature%type,--温度
                           strRSV_BATCH1   in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                           strRSV_BATCH2   in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                           strRSV_BATCH3   in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                           strRSV_BATCH4   in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                           strRSV_BATCH5   in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                           strRSV_BATCH6   in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                           strRSV_BATCH7   in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                           strRSV_BATCH8   in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                           strLabelNo      in stock_label_m.label_no%type, --实体标签号
                           strSubLabelNo   in idata_check_pal_tmp.sub_label_no%type, --子标签号
                           strArtPrintFlag    in bdef_defarticle.print_flag%type, --打印商品条码标识
                           strFixPalFlag   in idata_check_pal.Fixpal_Flag%type, --1：固定板号；2：流水板号;
                           strBusinessType in idata_check_pal.Fixpal_Flag%type, --业务类型：0-普通验收；1-直通验收；2-大批量验收；3-客户别；5-越库；6-B/C品
                           strPrintFlag      in varchar2,--单据打印标识 0 不打印，1：打印表单，2：打印标签
                           strResult       out varchar2) IS
    v_stockType  idata_import_mm.stock_type%type;
    v_stockValue idata_import_mm.stock_value%type;

    v_nSumPoQty      idata_import_sd.po_qty%type; --总剩余验收数量
    v_nAcrossQty     idata_import_sd.check_across_qty%type; --直通剩余数量
    v_nCurrRemainQty idata_import_sd.po_qty%type; --当前剩余验收数量
    v_nScanQty       idata_import_sd.po_qty%type; --临时表记录的已扫描数量
    v_strsCheckNo    idata_check_m.s_check_no%type;
    v_strWaveNo         idata_import_mm.wave_no%type;--波次号
    v_strImportType     idata_import_mm.import_type%type;
  BEGIN
    strResult := 'N|[P_SAVE_IDCHECK]';
    if nCheckQty <= 0 then
      strResult := 'N|[验收数量须大于0!]';
      return;
    end if;


      --update by sunl 20160429
      --校验生产日期不能大于今天。
      if (dtProduceDate > sysdate) then
         strResult:='N|[商品生产日期不能大于今天！]';
         return;
      end if;


    begin
      select stock_type, a.stock_value,a.wave_no,a.import_type
        into v_stockType, v_stockValue,v_strWaveNo,v_strImportType
        from idata_import_mm a
       where warehouse_no = strWareHouseNo
         and enterprise_no = strEnterpriseNo
         and owner_no = strOwnerNo
         and s_import_no = strsImportNo;
    exception
      when no_data_found then
        strResult := 'N|[E20903]'; --取进货汇总单信息失败
        return;
    end;

    --读取未验量,检查是否超量
    --锁定进货汇总单头档
    update idata_import_mm mm
       set mm.status = mm.status
     where mm.warehouse_no = strWareHouseNo
       and mm.enterprise_no = strEnterpriseNo
       and mm.s_import_no = strsImportNo
       and mm.owner_no = strOwnerNo;

    if v_strWaveNo='N' then --未资源试算
       P_I_CustAllot_Label_RG(strEnterPriseNo,strWareHouseNo,strOwnerNo,strSImportNo,
           v_strImportType,strWorkerNo,strDockNo,strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      begin
        select a.wave_no
          into v_strWaveNo
          from idata_import_mm a
         where warehouse_no = strWareHouseNo
           and enterprise_no = strEnterpriseNo
           and owner_no = strOwnerNo
           and s_import_no = strsImportNo;
      exception
        when no_data_found then
          strResult := 'N|[E20903]'; --取进货汇总单信息失败
          return;
      end;
    end if;

    --获取商品的未验收数量
    select sum(t.po_qty - t.import_qty) sumQty
      into v_nSumPoQty
      from idata_import_sd t
     where t.warehouse_no = strWareHouseNo
       and t.enterprise_no = strEnterpriseNo
       and t.owner_no = strOwnerNo
       and t.s_import_no = strsImportNo
       and t.article_no = strArticleNo
       and t.packing_qty = nPackingQty;

    --获取商品的直通出货数量
    select nvl(sum(t.po_qty - t.allot_qty), 0)
      into v_nAcrossQty
      from idata_import_allot t, idata_import_sm iis
     where t.enterprise_no = iis.enterprise_no
       and t.warehouse_no = iis.warehouse_no
       and t.owner_no = iis.owner_no
       and t.import_no = iis.import_no
       and t.warehouse_no = strWareHouseNo
       and t.owner_no = strOwnerNo
       and t.article_no = strArticleNo
       and t.packing_qty = nPackingQty
       and t.enterprise_no = strEnterpriseNo
       and iis.s_import_no = strsImportNo
       AND t.status not in ('13', '16');

    --获取临时表中已扫描的数量
    select nvl(sum(t.check_qty), 0)
      into v_nScanQty
      from idata_check_pal_tmp t
     where t.warehouse_no = strWareHouseNo
       and t.owner_no = strOwnerNo
       and t.article_no = strArticleNo
       and t.packing_qty = nPackingQty
       and t.enterprise_no = strEnterpriseNo
       and t.s_import_no = strsImportNo
       and t.quality = strQuality
       and trunc(t.produce_date) = trunc(dtProduceDate)
       and trunc(t.expire_date) = trunc(dtExpireDate)
       and t.lot_no = strLotNo
       and t.rsv_batch1 = strRSV_BATCH1
       and t.rsv_batch2 = strRSV_BATCH2
       and t.rsv_batch3 = strRSV_BATCH3
       and t.rsv_batch4 = strRSV_BATCH4
       and t.rsv_batch5 = strRSV_BATCH5
       and t.rsv_batch6 = strRSV_BATCH6
       and t.rsv_batch7 = strRSV_BATCH7
       and t.rsv_batch8 = strRSV_BATCH8;
    --未验量包含临时表中已扫描数量
    v_nSumPoQty  := v_nSumPoQty - v_nScanQty;
    v_nAcrossQty := v_nAcrossQty - v_nScanQty;
    if v_nSumPoQty < nCheckQty then
      --暂不支持超量
      strResult := 'N|[E00022]';
      return;
    end if;

    if nCheckQty > v_nAcrossQty then
      v_nCurrRemainQty := nCheckQty - v_nAcrossQty;
    else
      v_nAcrossQty := nCheckQty;
    end if;

    if v_nAcrossQty > 0 then
      --直通保存
      P_SAVE_IDCLOSEPAL(strEnterpriseNo,
                        strWareHouseNo,
                        strOwnerNo,
                        strsImportNo,
                        strArticleNo,
                        strBarcode,
                        nPackingQty,
                        v_nAcrossQty,
                        strPrinterGroupNo,
                        strDockNo,
                        strWorkerNo,
                        strCheckTools,
                        strQuality,
                        dtProduceDate,
                        dtExpireDate,
                        strLotNo,
                        strRSV_BATCH1,
                        strRSV_BATCH2,
                        strRSV_BATCH3,
                        strRSV_BATCH4,
                        strRSV_BATCH5,
                        strRSV_BATCH6,
                        strRSV_BATCH7,
                        strRSV_BATCH8,
                        strLabelNo,
                        strSubLabelNo,
                        strFixPalFlag,
                        strBusinessType,
                        strArtPrintFlag,
                        v_strWaveNo,
                        v_strImportType,
                        strPrintFlag,
                        v_strsCheckNo,
                        strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
    end if;
    if v_nCurrRemainQty > 0 then
      --直通单剩余部分转存储
      P_SAVE_ID2IS(strEnterpriseNo,
                   strWareHouseNo,
                   strOwnerNo,
                   strsImportNo,
                   strArticleNo,
                   strBarcode,
                   nPackingQty,
                   v_nCurrRemainQty,
                   strPrinterGroupNo,
                   strDockNo,
                   strWorkerNo,
                   strCheckTools,
                   strQuality,
                   dtProduceDate,
                   dtExpireDate,
                   strLotNo,
                   strRSV_BATCH1,
                   strRSV_BATCH2,
                   strRSV_BATCH3,
                   strRSV_BATCH4,
                   strRSV_BATCH5,
                   strRSV_BATCH6,
                   strRSV_BATCH7,
                   strRSV_BATCH8,
                   strLabelNo,
                   strSubLabelNo,
                   strFixPalFlag,
                   strBusinessType,
                   v_strsCheckNo,
                   strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
      --打印吊牌
      P_IDCHECK_PRINT(strEnterpriseNo,
                      strWareHouseNo,
                      strArticleNo,
                      strBarcode,
                      v_nCurrRemainQty,
                      strDockNo,
                      strWorkerNo,
                      strArtPrintFlag,
                      strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
    end if;
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_SAVE_IDCHECK;

  /************************************************************************************************
       修改人：wyf
       日期：2015-11-30
       功能：直通封板(无电子标签分配)，可根据单据类型的配置来判断是否可有单门店整板
  *************************************************************************************************/
  procedure P_SAVE_IDCLOSEPAL(strEnterpriseNo   in idata_check_m.enterprise_no%type,
                              strWareHouseNo    in idata_check_m.warehouse_no%type,
                              strOwnerNo        in idata_check_m.owner_no%type,
                              strsImportNo      in idata_check_m.s_import_no%type, --进货汇总单号
                              strArticleNo      in idata_check_d.article_no%type,
                              strBarcode        in idata_check_d.barcode%type,
                              nPackingQty       in idata_check_d.packing_qty%type,
                              nCheckQty         in idata_check_d.check_qty%type, --RF封箱传0
                              strPrinterGroupNo in idata_check_m.printer_group_no%type, --工作站
                              strDockNo         in idata_check_m.dock_no%type, --码头
                              strWorkerNo       in idata_check_m.rgst_name%type, --操作人
                              strCheckTools     in idata_check_m.check_tools%type, --验收工具
                              strQuality        in idata_check_d.quality%type, --品质
                              dtProduceDate     in idata_check_d.produce_date%type,
                              dtExpireDate      in idata_check_d.expire_date%type,
                              strLotNo          in idata_check_d.lot_no%type, --批次号
                              strRSV_BATCH1     in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                              strRSV_BATCH2     in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                              strRSV_BATCH3     in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                              strRSV_BATCH4     in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                              strRSV_BATCH5     in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                              strRSV_BATCH6     in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                              strRSV_BATCH7     in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                              strRSV_BATCH8     in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                              strLabelNo        in stock_label_m.label_no%type, --实体标签号
                              strSubLabelNo     in idata_check_pal_tmp.sub_label_no%type, --子标签号
                              strFixPalFlag     in idata_check_pal.Fixpal_Flag%type, --1：固定板号；2：流水板号;
                              strBusinessType   in idata_check_pal.Fixpal_Flag%type, --业务类型：0-普通验收；1-直通验收；2-大批量验收；3-客户别；5-越库；6-B/C品
                              strArtPrintFlag      in bdef_defarticle.print_flag%type,
                              strWaveNo         in idata_import_mm.wave_no%type,
                              strImportType     in idata_import_mm.import_type%type,
                              strPrintFlag      in varchar2,--单据打印标识 0 不打印，1：打印表单，2：打印标签
                              strSCheckNo       out idata_check_m.s_check_no%type,
                              strResult         out varchar2) IS
    v_stockType  idata_import_mm.stock_type%type;
    v_stockValue idata_import_mm.stock_value%type;

    v_strsCheckNo idata_check_m.s_check_no%type;

    v_strContainerNo stock_label_m.container_no%type;
    v_strCellNo      stock_content.cell_no%type;

    v_PrintTaskNo job_printtask_m.task_no%type;
    v_iCount      integer;
      v_nAllotID   number;
  BEGIN
    strResult := 'N|[P_SAVE_IDCLOSEPAL]';
    begin
      select stock_type, a.stock_value
        into v_stockType, v_stockValue
        from idata_import_mm a
       where warehouse_no = strWareHouseNo
         and enterprise_no = strEnterpriseNo
         and owner_no = strOwnerNo
         and s_import_no = strsImportNo;
    exception
      when no_data_found then
        strResult := 'N|[E20903]'; --取进货汇总单信息失败
        return;
    end;

    --直通配量
      select seq_middata_allot_detail.nextval into v_nAllotID from dual;
    insert into middata_allot_detail
      (tmp_id,warehouse_no,
       source_no,
       outstock_type,
       article_no,
       cust_no,
       po_no,
       plan_qty,
       allot_qty,
       enterprise_no)
      select v_nAllotID,sm.warehouse_no,
             sm.s_import_no,
             'ID',
             sa.article_no,
             sa.cust_no,
             sa.po_no,
             sum(sa.po_qty - sa.allot_qty),
             0,
             sm.enterprise_no
        from Idata_Import_Allot sa, idata_import_sm sm
       where sa.enterprise_no = sm.enterprise_no
         and sa.warehouse_no = sm.warehouse_no
         and sa.import_no = sm.import_no
         and sa.owner_no = sm.owner_no
         and sa.article_no = strArticleNo
         and sm.enterprise_no = strEnterpriseNo
         and sm.warehouse_no = strWareHouseNo
         and sm.s_import_no = strsImportNo
         and sa.status < '13'
       group by sm.enterprise_no,
                sm.warehouse_no,
                sm.s_import_no,
                sa.article_no,
                sa.cust_no,
                sa.po_no;
    Pklg_Publocate.p_locate_allot(v_nAllotID,strEnterpriseNo,
                                  strWareHouseNo,
                                  strsImportNo,
                                  'ID',
                                  'C',
                                  nCheckQty,
                                  nPackingQty,
                                  strResult);
    if substr(strResult, 1, 2) = 'N|' then
      return;
    end if;

    --取汇总验收单号；
    begin
      select distinct s_check_no
        into v_strsCheckNo
        from idata_check_m
       where enterprise_no = strEnterpriseNo
         and warehouse_no = strWareHouseNo
         and owner_no = strOwnerNo
         and s_import_no = strsImportNo
         and status <> '13';
    exception
      when no_data_found then

        --若取不到汇总验收单号，则写验收头档；
        PKOBJ_IDATA.p_Insert_Idata_Check_M(strEnterpriseNo,
                                           strWareHouseNo,
                                           strOwnerNo,
                                           strSImportNo,
                                           strDockNo,
                                           strWorkerNo,
                                           strPrinterGroupNo,
                                           strCheckTools,
                                           v_strsCheckNo,
                                           strResult);
        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;
    end;

    begin
      select cell_no
        into v_strCellNo
        from (select CDC.CELL_NO
                FROM Cdef_DEFAREA CDA, Cdef_DEFCELL CDC
               WHERE CDA.Enterprise_No = CDC.Enterprise_No
                 and CDA.warehouse_no = CDC.warehouse_no
                 AND CDA.WARE_NO = CDC.WARE_NO
                 AND CDA.AREA_NO = CDC.AREA_NO
                 and CDA.Enterprise_No = strEnterpriseNo
                 and CDA.WAREHOUSE_NO = strWareHouseNo
                 AND CDA.AREA_ATTRIBUTE = '1' --暂存区
                 and CDA.AREA_USETYPE = '1' --普通区
                 AND CDA.ATTRIBUTE_TYPE = '2' --进货区或者存储区
                 and cdc.cell_status = '0'
                 and cdc.check_status = '0'
               ORDER BY CDA.ATTRIBUTE_TYPE DESC, CDC.cell_no)
       where rownum < 2;
    exception
      when no_data_found then
        strResult := 'N|[E00100]';
        return;
    end;

    strsCheckNo := v_strsCheckNo;
    --获取批次，获取不到取出N
    for p in (select distinct nvl(b.batch_no, 'N') batch_no
                from middata_allot_detail a
                left join odata_divide_allot b
                  on a.ENTERPRISE_NO = b.ENTERPRISE_NO
                 and a.WAREHOUSE_NO = b.WAREHOUSE_NO
                 and a.source_no = b.s_import_no
                 and a.cust_no = b.cust_no
                 and (b.wave_no = strWaveNo or strWaveNo='N')
               where a.source_no = strsImportNo
                 and a.enterprise_no = strEnterpriseNo
                 and a.warehouse_no = strWareHouseNo
                 and a.article_no = strArticleNo
                 and a.allot_qty > 0) loop
      --写标签，分播指示，更新进货表
      P_SAVE_IDWIRTEDIRECT(strEnterpriseNo,
                           strWareHouseNo,
                           strOwnerNo,
                           strsImportNo,
                           strArticleNo,
                           strBarcode,
                           nPackingQty,
                           strWorkerNo,
                           strQuality,
                           dtProduceDate,
                           dtExpireDate,
                           strLotNo,
                           strRSV_BATCH1,
                           strRSV_BATCH2,
                           strRSV_BATCH3,
                           strRSV_BATCH4,
                           strRSV_BATCH5,
                           strRSV_BATCH6,
                           strRSV_BATCH7,
                           strRSV_BATCH8,
                           strLabelNo,
                           strSubLabelNo,
                           strsCheckNo,
                           v_strCellNo,
                           v_stockType,
                           strDockNo,
                           strFixPalFlag,
                           strWaveNo,
                           strImportType,
                           p.batch_no,
                           v_strContainerNo,
                           strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;
      --判断是否有单门店整板的数据
      P_Chang_DivideSingCust(strEnterpriseNo,
                             strWareHouseNo,
                             strOwnerNo,
                             strDockNo,
                             strsCheckNo,
                             v_strContainerNo,
                             strWorkerNo,
                             '1',
                             strResult);
      if (substr(strResult, 1, 1) = 'N') then
        return;
      end if;

      select count(*)
        into v_iCount
        from odata_divide_direct t
       where t.enterprise_no = strEnterpriseNo
         and t.warehouse_no = strWareHouseNo
         and t.s_container_no = v_strContainerNo
         and t.source_no = strsCheckNo
         and t.status = '10';

      if v_iCOUNT > 0 then

        --分播发单
        PKLG_ODATA_DIVIDE.P_OutStock_Divide(strEnterpriseNo,
                                            strwarehouseNo,
                                            strOwnerNo,
                                            strDockNo,
                                            strsCheckNo,
                                            v_strContainerNo,
                                            strWorkerNo,
                                            strWorkerNo,
                                            '0',
                                            strResult);
        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        --写分播标签打印任务
        if strPrintFlag = '2' then
          --写打印任务
          if v_PrintTaskNo is null then
            PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                       strWareHouseNo,
                                       CONST_DOCUMENTTYPE.PRINTPT,
                                       v_PrintTaskNo,
                                       strResult);
            if substr(strResult, 1, 1) <> 'Y' then
              return;
            end if;

            PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterpriseNo,
                                                strWareHouseNo,
                                                v_strsCheckNo,
                                                '0',
                                                CONST_REPORTID.IM_ID_DIVIDE_P,
                                                strDockNo,
                                                '0',
                                                strWorkerNo,
                                                v_PrintTaskNo,
                                                strResult);
            if substr(strResult, 1, 1) <> 'Y' then
              return;
            end if;
          end if;
          PKOBJ_PRINTTASK.p_insert_taskdetail(strEnterpriseNo,
                                              strWareHouseNo,
                                              v_PrintTaskNo,
                                              v_strContainerNo,
                                              1,
                                              1,
                                              strResult);
          if substr(strResult, 1, 1) <> 'Y' then
            return;
          end if;
        elsif strPrintFlag = '1' then
        	--打印表单
          --写打印任务
          if v_PrintTaskNo is null then
            PKLG_WMS_BASE.p_getsheetno(strEnterpriseNo,
                                       strWareHouseNo,
                                       CONST_DOCUMENTTYPE.PRINTPT,
                                       v_PrintTaskNo,
                                       strResult);
            if substr(strResult, 1, 1) <> 'Y' then
              return;
            end if;

            PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterpriseNo,
                                                strWareHouseNo,
                                                v_strContainerNo,
                                                '0',
                                                CONST_REPORTID.OmDivideReport,
                                                strDockNo,
                                                '0',
                                                strWorkerNo,
                                                v_PrintTaskNo,
                                                strResult);
            if substr(strResult, 1, 1) <> 'Y' then
              return;
            end if;
          end if;
        end if;
      end if;
    end loop;

    --删除本次配量结果
    delete from middata_allot_detail md
     where md.enterprise_no = strEnterpriseNo
       and md.warehouse_no = strWareHouseNo
       and md.source_no = strsImportNo
       and md.article_no = strArticleNo;
    --删除临时表数据
    delete from idata_check_pal_tmp t
     where t.enterprise_no = strEnterpriseNo
       and t.warehouse_no = strWareHouseNo
       and t.owner_no = strOwnerNo
       and t.s_import_no = strsImportNo
       and t.article_no = strArticleNo
       and t.packing_qty = nPackingQty
       and t.label_no = strLabelNo
       and t.sub_label_no = strSubLabelNo
       and t.printer_group_no = strPrinterGroupNo
       and t.dock_no = strDockNo
       and t.check_tools = strCheckTools;

    --打印吊牌
    P_IDCHECK_PRINT(strEnterpriseNo,
                    strWareHouseNo,
                    strArticleNo,
                    strBarcode,
                    nCheckQty,
                    strDockNo,
                    strWorkerNo,
                    strArtPrintFlag,
                    strResult);
    if (substr(strResult, 1, 1) = 'N') then
      return;
    end if;
    strResult := 'Y|成功!';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  END P_SAVE_IDCLOSEPAL;

  /************************************************************************************************
       修改人：wyf
       日期：2015-11-30
       功能：直通封箱写标签，分播指示，更新进货表(无电子标签分配)
  *************************************************************************************************/
  procedure P_SAVE_IDWIRTEDIRECT(strEnterpriseNo in idata_check_m.enterprise_no%type,
                                 strWareHouseNo  in idata_check_m.warehouse_no%type,
                                 strOwnerNo      in idata_check_m.owner_no%type,
                                 strsImportNo    in idata_check_m.s_import_no%type, --进货汇总单号
                                 strArticleNo    in idata_check_d.article_no%type,
                                 strBarcode      in idata_check_d.barcode%type,
                                 nPackingQty     in idata_check_d.packing_qty%type,
                                 strWorkerNo     in idata_check_m.rgst_name%type, --操作人
                                 strQuality      in idata_check_d.quality%type, --品质
                                 dtProduceDate   in idata_check_d.produce_date%type,
                                 dtExpireDate    in idata_check_d.expire_date%type,
                                 strLotNo        in idata_check_d.lot_no%type, --批次号
                                 strRSV_BATCH1   in idata_check_pal_tmp.rsv_batch1%type, --预留批属性1
                                 strRSV_BATCH2   in idata_check_pal_tmp.rsv_batch2%type, --预留批属性2
                                 strRSV_BATCH3   in idata_check_pal_tmp.rsv_batch3%type, --预留批属性3
                                 strRSV_BATCH4   in idata_check_pal_tmp.rsv_batch4%type, --预留批属性4
                                 strRSV_BATCH5   in idata_check_pal_tmp.rsv_batch5%type, --预留批属性5
                                 strRSV_BATCH6   in idata_check_pal_tmp.rsv_batch6%type, --预留批属性6
                                 strRSV_BATCH7   in idata_check_pal_tmp.rsv_batch7%type, --预留批属性7
                                 strRSV_BATCH8   in idata_check_pal_tmp.rsv_batch8%type, --预留批属性8
                                 strLabelNo      in stock_label_m.label_no%type, --实体标签号
                                 strSubLabelNo   in idata_check_pal_tmp.sub_label_no%type,
                                 strsCheckNo     in idata_check_m.s_check_no%type,
                                 strCellNo       in stock_content.cell_no%type,
                                 strStockType    in idata_import_mm.stock_type%type,
                                 strDockNo       in idata_check_pal.dock_no%type,
                                 strFixPalFlag   in idata_check_pal.Fixpal_Flag%type, --1：固定板号；2：流水板号;
                                 strWaveNo       in idata_import_mm.wave_no%type,
                                 strImportType   in idata_import_mm.import_type%type,
                                 strBatchNo      in odata_divide_allot.batch_no%type,
                                 strContainerNo  out stock_label_m.label_no%type, --内部容器号z
                                 strResult       out varchar2) is
    v_strLabelNoTmp    stock_label_m.label_no%type; --板号
    v_strSubLabelNoTmp idata_check_pal.sub_label_no%type; --子标签号
    v_strSessionID     varchar2(10);

    v_nRoWid idata_check_d.row_id%type;

    v_blExcessFlag  boolean;
    v_nCustTotalQty idata_import_d.po_qty%type; --门店预配量
    v_nCustAllotQty idata_import_d.po_qty%type;

    v_nArticleId stock_article_info.article_id%type;

    v_nCellID    stock_content.cell_id%type;
    v_nDIVIDEID  stock_label_d.divide_id%type;
    strDelvierObjLevel wms_outlocate_strategy_d.deliver_obj_level%type;
    v_strDeliverObj    odata_exp_m.exp_no%type;--配送对象
 /*   v_strDpsCellNo     cdef_defcell.cell_no%type:='N';*/
    v_strDeliverObjOrder  odata_divide_allot.deliverobj_order%type:='N';
 begin
    strResult := 'N|[P_SAVE_ID_LOCATE]';

    PKLG_OLOCATE.GetDeliverObjLevel(strEnterpriseNo,strWareHouseNo,strOwnerNo,strImportType,strDelvierObjLevel,strResult);
    if (substr(strResult, 1, 1) = 'N') then
      strResult := 'N|[E00005]';
      return;
    end if;

    --取P标签 只取一个标签
    begin
      select a.container_no
        into strContainerNo
        from STOCK_LABEL_M a
       where a.enterprise_no = strEnterpriseNo
         and a.warehouse_no = strWareHouseNo
         and a.source_no = strsCheckNo
         and a.label_no = strLabelNo;
    exception
      when no_data_found then
        pklg_wms_base.p_get_ContainerNoBase(strEnterpriseNo,
                                            strWareHouseNo,
                                            'P',
                                            strWorkerNo,
                                            'D',
                                            1,
                                            '2',
                                            '31',
                                            v_strLabelNoTmp,
                                            strContainerNo,
                                            v_strSessionID,
                                            strResult);
        if (substr(strResult, 1, 1) = 'N') then
          strResult := 'N|[E00005]';
          return;
        end if;

        --判断传入的标签是否为N
        if strLabelNo <> 'N' then
          v_strLabelNoTmp := strLabelNo;
        end if;
        if strSubLabelNo <> 'N' then
          v_strSubLabelNoTmp := strSubLabelNo;
        else
          v_strSubLabelNoTmp := v_strLabelNoTmp;
        end if;
        --写标签
        pkobj_label.proc_Insert_LabelMaster(strEnterpriseNo,
                                            strWareHouseNo,
                                            strBatchNo,
                                            strsCheckNo,
                                            v_strLabelNoTmp,
                                            strContainerNo,
                                            'P',
                                            'N',
                                            strCellNo,
                                            'N', --strCUST_NO
                                            'N', --strTRUNCK_CELL_NO
                                            'N', --strA_SORTER_CHUTE_NO
                                            'N', --strCHECK_CHUTE_NO
                                            'N', --strDELIVER_OBJ
                                            '2', --strUSE_TYPE
                                            'N', --strLINE_NO
                                            'N', --strCURR_AREA
                                            'N', --strEQUIPMENT_NO
                                            strWorkerNo, --strRGST_NAME
                                            CONST_REPORTID.IM_ID_DIVIDE_P, --'N', --strREPORT_ID
                                            'N', --strMID_LABEL_NO
                                            'N', --strBIG_EXP_NO_FLAG
                                            strStockType, --strSTOCK_TYPE
                                            '0', --strCHUTE_LABEL_FLAG
                                            strContainerNo, --strOWNER_CONTAINER_NO
                                            CLabelStatus.PICK_END, --strstatus
                                            '1',strWaveNo, --strHm_Manual_Flag
                                            strResult); --strOutMsg
        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;
    end;

    for v_cs_allot in (select distinct md.*
                         from middata_allot_detail md
                         left join odata_divide_allot d
                          on md.ENTERPRISE_NO = d.ENTERPRISE_NO
                         and md.WAREHOUSE_NO = d.WAREHOUSE_NO
                         and md.source_no = d.s_import_no
                         and md.cust_no = d.cust_no
                        where md.enterprise_no = strEnterpriseNo
                          and md.warehouse_no = strWareHouseNo
                          and md.source_no = strsImportNo
                          and md.article_no = strArticleNo
                           and (d.wave_no = strWaveNo or strWaveNo='N')
                           and (d.batch_no = strBatchNo or strBatchNo='N')
                          and md.allot_qty > 0) loop
      v_nCustTotalQty := v_cs_allot.allot_qty;

      v_blExcessFlag := false;

      <<continue_allot>>
      for v_cs_cust in (select icm.import_type,
                               sa.import_no,
                               icm.check_no,
                               sa.packing_qty,
                               sa.cust_no,
                               sa.sub_cust_no,
                               sa.po_no,iid.unit_cost,
                               (sa.po_qty - sa.allot_qty) as unallot_qty
                          from Idata_Import_Allot sa,
                               idata_import_sm    sm,
                               idata_check_m      icm,
                               idata_import_d      iid
                         where icm.enterprise_no = sm.enterprise_no
                           and icm.warehouse_no = sm.warehouse_no
                           and icm.import_no = sm.import_no
                           and icm.s_check_no = strsCheckNo
                           and icm.enterprise_no = iid.enterprise_no
                           and icm.warehouse_no = iid.warehouse_no
                           and icm.import_no = iid.import_no
                           and sa.article_no = iid.article_no
                           and sa.packing_qty = iid.packing_qty
                           and sa.warehouse_no = sm.warehouse_no
                           and sa.enterprise_no = strEnterpriseNo
                           and sa.enterprise_no = sm.enterprise_no
                           and sa.import_no = sm.import_no
                           and sa.owner_no = sm.owner_no
                           and sa.article_no = strArticleNo
                           and sa.cust_no = v_cs_allot.cust_no
                           and sm.warehouse_no = strWareHouseNo
                           and sm.s_import_no = strsImportNo
                         order by case
                                    when sa.packing_qty = nPackingQty then
                                     0
                                    else
                                     1
                                  end) loop

        if strDelvierObjLevel='1' then
           v_strDeliverObj:=v_cs_cust.po_no;
        else
           v_strDeliverObj:=v_cs_cust.cust_no;
        end if;

        if v_blExcessFlag = false then
          v_nCustAllotQty := v_cs_cust.unallot_qty;
          if v_nCustAllotQty > v_nCustTotalQty then
            v_nCustAllotQty := v_nCustTotalQty;
          end if;
        else
          v_nCustAllotQty := v_nCustTotalQty;
        end if;

        v_nCustTotalQty := v_nCustTotalQty - v_nCustAllotQty;

        --获取商品属性ID
        PKLG_WMS_BASE.p_getArticleID(strEnterpriseNo,
                                     strArticleNo,
                                     strBarcode,
                                     strLotNo,
                                     dtProduceDate,
                                     dtExpireDate,
                                     strQuality,
                                     strRSV_BATCH1,
                                     strRSV_BATCH2,
                                     strRSV_BATCH3,
                                     strRSV_BATCH4,
                                     strRSV_BATCH5,
                                     strRSV_BATCH6,
                                     strRSV_BATCH7,
                                     strRSV_BATCH8,
                                     v_cs_cust.check_no,
                                     '0',
                                     strWorkerNo,v_cs_cust.unit_cost,
                                     v_nArticleId,
                                     strResult);
        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        --写验收明细
        PKOBJ_IDATA.p_idata_IDInsertCheckD(strEnterpriseNo,
                                           strWareHouseNo,
                                           strOwnerNo,
                                           strsImportNo,
                                           strsCheckNo,
                                           v_cs_cust.import_no,
                                           strArticleNo,
                                           strBarcode,
                                           nPackingQty,
                                           v_nCustAllotQty,
                                           strLotNo,
                                           dtProduceDate,
                                           dtExpireDate,
                                           strQuality,
                                           strWorkerNo,
                                           v_nRoWid,
                                           strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        --写板明细
        PKOBJ_IDATA.p_idata_InsertIDCheckPal(strEnterpriseNo,
                                             strWareHouseNo,
                                             strOwnerNo,
                                             strsImportNo,
                                             v_cs_cust.import_no,
                                             strWorkerNo,
                                             v_strLabelNoTmp,
                                             v_strSubLabelNoTmp,
                                             strContainerNo,
                                             v_cs_cust.cust_no,
                                             strFixPalFlag,
                                             v_nCustAllotQty,
                                             strDockNo,
                                             v_nRoWid,strWaveNo,
                                             strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;

        --更新进货汇总明细表
        update IDATA_IMPORT_SD
           set IMPORT_QTY = IMPORT_QTY + v_nCustAllotQty, status = '12'
         where enterprise_no = strEnterpriseNo
           and WAREHOUSE_NO = strWareHouseNo
           and OWNER_NO = strOwnerNo
           and S_IMPORT_NO = strsImportNo
           and Article_No = strArticleNo
           and PACKING_QTY = v_cs_cust.packing_qty;

        --更新进货单明细表
        update IDATA_IMPORT_D
           set IMPORT_QTY = IMPORT_QTY + v_nCustAllotQty, status = '12'
         where enterprise_no = strEnterpriseNo
           and WAREHOUSE_NO = strWareHouseNo
           and OWNER_NO = strOwnerNo
           and IMPORT_NO = v_cs_cust.import_no
           and Article_No = strArticleNo
           and PACKING_QTY = v_cs_cust.packing_qty;

        --更新进货配量细表
        update Idata_Import_Allot
           set allot_qty = allot_qty + v_nCustAllotQty,
               status    = '12',
               updt_name = strWorkerNo,
               updt_date = sysdate
         where enterprise_no = strEnterpriseNo
           and WAREHOUSE_NO = strWareHouseNo
           and OWNER_NO = strOwnerNo
           and import_no = v_cs_cust.import_no
           and cust_no = v_cs_cust.cust_no
           and sub_cust_no = v_cs_cust.sub_cust_no
           and Article_No = strArticleNo
           and PACKING_QTY = v_cs_cust.packing_qty;

        v_nDIVIDEID := SEQ_ODATA_OUTSTOCK_DIRECT.NEXTVAL;

        --获取储位
        begin
            select deliverobj_order into v_strDeliverObjOrder from odata_divide_allot
            where enterprise_no=strEnterpriseNo and warehouse_no=strWareHouseNo
            and wave_no=strWaveNo and s_import_no=strsImportNo
            and cust_no=v_cs_cust.cust_no and exp_no=v_cs_cust.po_no
            and deliver_obj=v_strDeliverObj;

        exception when no_data_found then
            v_strDeliverObjOrder:='N';
        end;

        --新增标签明细
        PKOBJ_LABEL.proc_Insert_LabelDetail(strEnterpriseNo,
                                            strWareHouseNo,
                                            strBatchNo,
                                            strOwnerNo,
                                            strsCheckNo,
                                            strContainerNo,
                                            'P',
                                            strArticleNo,
                                            v_nArticleId,
                                            nPackingQty,
                                            v_nCustAllotQty,
                                            v_cs_cust.po_no,
                                            case when strWaveNo='N' then strsCheckNo else strWaveNo end,
                                            v_cs_cust.cust_no,
                                            v_cs_cust.sub_cust_no,
                                            'N',
                                            CLabelStatus.PICK_END,
                                            v_nDIVIDEID,
                                            'ID',
                                            'N',
                                            strWorkerNo,
                                            v_strDeliverObj,v_strDeliverObjOrder,
                                            trunc(sysdate),
                                            strCellNo,--Modify BY QZH AT 2016-5-25
                                            '10',
                                            strResult);
        if substr(strResult, 1, 1) <> 'Y' then
          return;
        end if;

        --写库存
        PKOBJ_STOCK.p_Idata_InsertIdStockItem(strEnterpriseNo,
                                              strWareHouseNo,
                                              strsCheckNo,
                                              strArticleNo,
                                              strContainerNo,
                                              strBarcode,
                                              strLotNo,
                                              dtProduceDate,
                                              dtExpireDate,
                                              strQuality,
                                              v_nArticleId,
                                              nPackingQty,
                                              v_nRoWid,
                                              v_nCustAllotQty,
                                              v_cs_cust.check_no,
                                              '1',
                                              strWorkerNo,
                                              strCellNo,
                                              v_nCellID,
                                              strResult);

        if (substr(strResult, 1, 1) = 'N') then
          return;
        end if;
        --更新板明细状态
        update idata_check_pal icp
           set icp.status    = '13',
               icp.updt_name = strWorkerNo,
               icp.updt_date = sysdate
         where icp.enterprise_no = strEnterpriseNo
           and icp.warehouse_no = strWareHouseNo
           and icp.owner_no = strOwnerNo
           and icp.s_check_no = strsCheckNo
           and icp.check_no = v_cs_cust.check_no
           and icp.check_row_id = v_nRoWid
           and icp.container_no = strContainerNo
           and icp.label_no = v_strLabelNoTmp
           and icp.sub_label_no = v_strSubLabelNoTmp
           and icp.cust_no = v_cs_cust.cust_no;

        --获取储位

        --写分播指示
        Insert into ODATA_DIVIDE_DIRECT
          (WAREHOUSE_NO,OWNER_NO,BATCH_NO,SOURCE_NO,DIVIDE_ID,
           OPERATE_DATE,CUST_NO,SUB_CUST_NO,ARTICLE_NO,ARTICLE_ID,
           PACKING_QTY,ARTICLE_QTY,S_CELL_NO,S_CELL_ID,S_CONTAINER_NO,
           EXP_TYPE,EXP_NO,WAVE_NO,DELIVER_AREA,STATUS,LINE_NO,
           TRUNCK_CELL_NO,CHECK_CHUTE_NO,DELIVER_OBJ,ADVANCE_CELL_NO,
           OUTSTOCK_DATE,DPS_CELL_NO,A_SORTER_CHUTE_NO,EXP_DATE,
           RGST_NAME,RGST_DATE,UPDT_NAME,UPDT_DATE,DEVICE_NO,enterprise_no,deliverobj_order)
        values
          (strWareHouseNo,strOwnerNo,strBatchNo,strsCheckNo,v_nDIVIDEID,
           trunc(sysdate),v_cs_cust.cust_no,v_cs_cust.sub_cust_no,strArticleNo,v_nArticleId,
           nPackingQty,v_nCustAllotQty,strCellNo,v_nCellID,strContainerNo,
           v_cs_cust.import_type,v_cs_cust.po_no,strsCheckNo,'N','10','N',
           'N','N',v_strDeliverObj,'N',
           sysdate,'N','N',trunc(sysdate),
           strWorkerNo,sysdate,strWorkerNo,sysdate,'N',
           strEnterpriseNo,v_strDeliverObjOrder);

        if v_nCustTotalQty <= 0 then
          exit;
        end if;

      end loop;

      --如果按量没有配完，说明是超量
      if v_nCustTotalQty > 0 then
        v_blExcessFlag := true;
        goto continue_allot;
      end if;

    end loop;

    strResult := 'Y|成功!';
  exception
    when others then
      strResult := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_SAVE_IDWIRTEDIRECT;

  /************************************************************************************************
       日期：2015-12-5
       功能：根据单据配置判断是否走门店整板，目前只适用于配送对象按客户的业务模式
  *************************************************************************************************/
  procedure P_Chang_DivideSingCust(strEnterPriseNo   in ODATA_DIVIDE_D.Enterprise_No%type, --企业号
                                   strWareHouseNo    in ODATA_DIVIDE_D.warehouse_no%type, --仓别
                                   strOWNER_NO       in ODATA_DIVIDE_D.OWNER_NO%type, --委托业主
                                   strDockNo         in bdef_defdock.dock_no%type, --码头
                                   strSource_No      in odata_divide_direct.source_no%type, --来源单号
                                   strS_CONTAINER_NO in odata_divide_direct.S_CONTAINER_NO%type, --来源容器
                                   strUserID         in bdef_defworker.worker_no%type, --系统操作人员
                                   strPrint_Flag     in varchar, --是否打印
                                   strOutMsg         out varchar2) is
    v_strExpType  odata_exp_m.exp_type%type;
    v_strPFlag    wms_outlocate_strategy_d.p_flag%type;
    v_iCount      integer;
    v_UpdateCount integer := 0;
    v_PrintTaskNo job_printtask_m.task_no%type;
    v_strLabelNo  stock_label_m.label_no%type;
    v_strDelierObjLevel  wms_outlocate_strategy_d.deliver_obj_level%type;
    v_strLocateStrategyId      wms_outorder.locate_strategy_id%type;
    v_strReportId        job_printtask_m.report_id%type;
  begin
    strOutMsg := 'N|[P_Chang_DivideSingCust]';

    --获取分播指示数据
    select d.exp_type
      into v_strExpType
      from odata_divide_direct d
     where d.WAREHOUSE_NO = strWareHouseNo
       and d.enterprise_no = strEnterPriseNo
       and d.OWNER_NO = strOWNER_NO
       and d.SOURCE_NO = strSource_No
       and d.s_container_no = strS_CONTAINER_NO
       and d.status = 10
       and rownum = 1;

    --获取定位策略
    PKLG_WMS_Public.p_OM_GetOutOrder(strEnterPriseNo,strWareHouseNo,strowner_no,v_strExpType,
       'locate_strategy_Id',v_strLocateStrategyId,strOutMsg);
    if (substr(strOutMsg, 1, 1) = 'N') then
      return;
    end if ;

    --获取此策略对应的配送对象级别
    select t.p_flag,t.deliver_obj_level into v_strPFlag,v_strDelierObjLevel
           from wms_outlocate_strategy_d t where t.enterprise_no=strEnterpriseNo
           and t.locate_strategy_id=v_strLocateStrategyId;


    if v_strPFlag = '1' then
      --单门店可不走分播

      --获取此分播标签的配送对象数
      select count(distinct t.deliver_obj)
        into v_iCount
        from odata_divide_direct t
       where t.enterprise_no = strEnterPriseNo
         and t.warehouse_no = strWareHouseNo
         and t.s_container_no = strS_CONTAINER_NO;

      if v_iCount = 1 then
        --单门店标签

        for GetDivideInf in (select slm.label_no, d.*
                               from odata_divide_direct d, stock_label_m slm
                              where d.enterprise_no = slm.enterprise_no
                                and d.warehouse_no = slm.warehouse_no
                                and d.s_container_no = slm.container_no
                                and d.WAREHOUSE_NO = strWareHouseNo
                                and d.enterprise_no = strEnterPriseNo
                                and d.OWNER_NO = strOWNER_NO
                                and d.SOURCE_NO = strSource_No
                                and d.s_container_no = strS_CONTAINER_NO) loop

          v_UpdateCount := 1;
          v_strLabelNo:=GetDivideInf.label_no;
          --将对应的标签头档转为客户标签
          update stock_label_m t
             set t.cust_no           = GetDivideInf.cust_no,
                 t.deliver_obj       = GetDivideInf.deliver_obj,
                 t.a_sorter_chute_no = GetDivideInf.a_sorter_chute_no,
                 t.check_chute_no    = GetDivideInf.check_chute_no,
                 t.line_no           = GetDivideInf.line_no,
                 t.use_type          = '1',
                 t.HM_MANUAL_FLAG    = '0',
                 t.report_id=CONST_REPORTID.IM_ID_Cust_type_p
           where t.warehouse_no = strWareHouseNo
             and t.enterprise_no = strEnterPriseNo
             and t.container_no = strS_CONTAINER_NO
             and t.use_type = '2';

          --调工作流
          PKOBJ_HB.p_OM_OutWorkflow(strEnterPriseNo,
                                    strWareHouseNo,
                                    GetDivideInf.Owner_No,
                                    GetDivideInf.Exp_Type,
                                    strS_CONTAINER_NO,
                                    strUserID,
                                    strDockNo,
                                    strOutMsg);
          if substr(strOutMsg, 1, 1) <> 'Y' then
            return;
          end if;

          --将库存转为标签库存

          PKOBJ_STOCK.proc_DivideCellToLabel(strEnterPriseNo,
                                             strWareHouseNo,
                                             strSource_No,
                                             GetDivideInf.divide_id,
                                             '1',
                                             strUserID,
                                             strOutMsg);

          if (substr(strOutMsg, 1, 1) = 'N') then
            return;
          end if;
        end loop;
      end if;

      --
      if v_UpdateCount = 1 then
        --写打印任务
        if strPrint_Flag = 1 then
           if v_strDelierObjLevel='1' then
              v_strReportId:=CONST_REPORTID.IM_ID_Exp_type_p;
           else
              v_strReportId:=CONST_REPORTID.IM_ID_Cust_type_p;
           end if;

          PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterpriseNo,
                                              strWareHouseNo,
                                              v_strLabelNo,
                                              '0',
                                              v_strReportId,
                                              strDockNo,
                                              '0',
                                              strUserID,
                                              v_PrintTaskNo,
                                              strOutMsg);

          if (substr(strOutMsg, 1, 1) = 'N') then
            return;
          end if;

        end if;


          --将分播指示的数据转历史；
          insert into ODATA_DIVIDE_DIRECThty
            (Enterprise_No,
             warehouse_no,
             OWNER_NO,
             BATCH_NO,
             SOURCE_NO,
             DIVIDE_ID,
             OPERATE_DATE,
             CUST_NO,
             SUB_CUST_NO,
             ARTICLE_NO,
             ARTICLE_ID,
             PACKING_QTY,
             ARTICLE_QTY,
             S_CELL_NO,
             S_CELL_ID,
             S_CONTAINER_NO,
             EXP_TYPE,
             EXP_NO,
             wAVE_NO,
             DELIVER_AREA,
             STATUS,
             LINE_NO,
             TRUNCK_CELL_NO,
             CHECK_CHUTE_NO,
             DELIVER_OBJ,
             ADVANCE_CELL_NO,
             OUTSTOCK_DATE,
             DPS_CELL_NO,
             RGST_NAME,
             RGST_DATE,
             UPDT_NAME,
             UPDT_DATE,
             A_SORTER_CHUTE_NO,
             exp_date,
             source_type,
             device_no)
            select strEnterPriseNo,
                   strWareHouseNo,
                   d.owner_no,
                   d.BATCH_NO,
                   d.SOURCE_NO,
                   d.DIVIDE_ID,
                   d.OPERATE_DATE,
                   d.CUST_NO,
                   d.SUB_CUST_NO,
                   d.ARTICLE_NO,
                   d.ARTICLE_ID,
                   d.PACKING_QTY,
                   d.ARTICLE_QTY,
                   d.S_CELL_NO,
                   d.S_CELL_ID,
                   d.S_CONTAINER_NO,
                   d.EXP_TYPE,
                   d.EXP_NO,
                   d.wAVE_NO,
                   d.DELIVER_AREA,
                   '13',
                   d.LINE_NO,
                   d.TRUNCK_CELL_NO,
                   d.CHECK_CHUTE_NO,
                   d.DELIVER_OBJ,
                   d.ADVANCE_CELL_NO,
                   d.OUTSTOCK_DATE,
                   d.DPS_CELL_NO,
                   d.RGST_NAME,
                   d.RGST_DATE,
                   d.UPDT_NAME,
                   d.UPDT_DATE,
                   d.A_SORTER_CHUTE_NO,
                   d.exp_date,
                   d.source_type,
                   d.device_no
              from odata_divide_direct d
             where d.enterprise_no = strEnterPriseNo
               and d.warehouse_no = strWareHouseNo
               and d.s_container_no = strS_CONTAINER_NO;

          delete from odata_divide_direct d
           where d.enterprise_no = strEnterPriseNo
             and d.warehouse_no = strWareHouseNo
             and d.s_container_no = strS_CONTAINER_NO;
      end if;


    end if;
    strOutMsg := 'Y|[]';

  end P_Chang_DivideSingCust;


    /*=====================================================================================
   insert to 20151212
  进货直通分配格子号
  ======================================================================================*/
    PROCEDURE p_I_CustAllot_LABEL_RG(strEnterPriseNo in idata_import_sm.enterprise_no%type,
                                 strwarehouse_no in idata_import_sm.warehouse_no%type, --仓别
                                 strowner_no     in idata_import_sm.owner_no%type,
                                 strSImportNo   in idata_import_sm.s_import_no%type, --进货汇总单号
                                 strClassType    in wms_warehouse_outorder.exp_type%type,
                                 strUser_Id      in idata_import_sm.rgst_name%type, --操作人员
                                 strDockNo       in idata_check_m.dock_no%type,---打印码头
                                 strOutMsg       out varchar2) is

    n_count       number(10); --循环行数
    v_DEVICE_NO              device_divide_m.device_no%type ;
    n_stockNum            number(10) ;--用来判断滞销品、过季品是不是按区或按巷道来分配分播墙格子号,0为区，其它为巷道
    ncount      number(5) ;
    strDELIVER_OBJ_LEVEL varchar2(2);
    v_nBatchStrategyId          wms_outorder.autobatch_strategy_id%type;
    v_nLocateStrategyId         wms_outorder.locate_strategy_id%type;
  begin
    strOutMsg     := 'N|[p_RI_SupperAllotCell]';
    --获取批次规则策略
    PKLG_WMS_Public.p_OM_GetOutOrder(strEnterPriseNo,strwarehouse_no,strowner_no,strClassType,
       'autobatch_strategy_id',v_nBatchStrategyId,strOutMsg);
    if (substr(strOutMsg, 1, 1) = 'N') then
      return;
    end if ;

    --获取定位策略
    PKLG_WMS_Public.p_OM_GetOutOrder(strEnterPriseNo,strwarehouse_no,strowner_no,strClassType,
       'locate_strategy_Id',v_nLocateStrategyId,strOutMsg);
    if (substr(strOutMsg, 1, 1) = 'N') then
      return;
    end if ;

    --根据策略取批次试算对应的值
    --判断wms_warehouse_outorder是否存在数据 ,是不是存在“人工分播方式”
    select count(1) into nCount from wms_outwaveplan_d wod where wod.enterprise_no=strEnterPriseNo
    and wod.batch_strategy_id=v_nBatchStrategyId and wod.batch_compute='2';--目前直通的不根据规则划分波次策略

    if ncount>0 then
        --首先判断是否设定配送对象分播资料（“人工分播方式”）；
        select count(1),nvl(max(ddm.cust_qty),0),nvl(max(ddm.device_no),'N') into n_count,n_stockNum,v_DEVICE_NO
        from device_divide_m ddm,wms_warehouse_outorder_device ddg
        where ddm.enterprise_no=ddg.enterprise_no and ddm.warehouse_no=ddg.warehouse_no
        and ddm.device_group_no=ddg.device_group_no  and ddg.exp_type=strClassType
        AND DDM.DEVICE_TYPE='04'  and ddm.enterprise_no=strEnterPriseNo
        and ddm.warehouse_no=strwarehouse_no;
        if n_count = 0 then
            strOutMsg:='N|[没有设定人工分播资源，请增加资料！]';
            return;
        end if ;

        --获取定位策略 当前配送对象是“客户”还是“单据”
        begin
            select DELIVER_OBJ_LEVEL into strDELIVER_OBJ_LEVEL from wms_outlocate_strategy_d
            where enterprise_no=strEnterPriseNo and locate_strategy_id=v_nLocateStrategyId;
        exception when no_data_found then
            strOutMsg:='N|[取不到直通单对应的定位策略，请检查配置！]';
            return;
        end;


        --由于当前（20151214）只支持一个直通单只能在一个波次，所以先按最大数处理。
       n_stockNum :=99999;
       --************************调用资源分配存储过程*****************************************
        pkobj_idata.p_scan_CustAllot_LABEL_RG(strEnterPriseNo,strwarehouse_no,strowner_no,
                                    strSImportNo,strClassType,v_DEVICE_NO,strDELIVER_OBJ_LEVEL,
                                    strUser_Id,strDockNo,n_stockNum,strOutMsg);
        if (substr(strOutMsg, 1, 1) = 'N') then
          return;
        end if ;
    END IF ;


    strOutMsg := 'Y|';

  exception
    when others then
      strOutMsg := 'N|' || SQLERRM ||
                   substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_I_CustAllot_LABEL_RG;
end PKLG_IDATA_ID;

/

