create package        PKOBJ_ODATA_DIVIDE is

  --分播回单标签转移
  procedure P_Odata_divide_label(strEnterPriseNo    in odata_divide_d.enterprise_no%type,
                                 strWareHouseNo     in odata_divide_d.warehouse_no%type, --仓库编码
                                 strOwner_No        in odata_divide_d.owner_no%type,
                                 strExp_Type        in odata_exp_m.exp_type%type,
                                 strSourceNo        in odata_divide_d.source_no%type, --来源单号
                                 strDivideNo        in odata_divide_d.divide_no%type, --分播单号
                                 strsContainerNo    in odata_divide_d.s_container_no%type, --来源容器号
                                 strDestContainerNo in odata_divide_d.cust_container_no%type, --目的容器号
                                 nDivideId          in odata_divide_d.divide_id%type, --
                                 strArticleNo       in odata_divide_d.article_no%type,
                                 nArticleId         in odata_divide_d.article_id%type,
                                 nPackingQty        in odata_divide_d.packing_qty%type,
                                 strExpNo           in odata_divide_d.exp_no%type,
                                 nRealQty           in odata_divide_d.real_qty%type,
                                 strCustNo          in odata_divide_d.Cust_No%type, --客户编码
                                 strUserId          in odata_divide_m.rgst_name%type,
                                 strResult          OUT varchar2);

  /****************************************************************************************************
     lich
     2015.05.29
     功能说明：分播墙回更新分播回单明细
  ******************************************************************************************************/
  procedure p_Wall_Update_Odata_Divide_D(strEnterPriseNo in odata_divide_d.enterprise_no%type,
                                         strWarehouseNo  in odata_divide_d.warehouse_no%type,
                                         strOwnerNo      in odata_divide_d.owner_no%type, --货主
                                         strDivideNO     in odata_divide_d.divide_no%type, --分播单号
                                         strDivideId     in odata_divide_d.divide_id%type, --指示序列
                                         nQty            in odata_divide_d.real_qty%type, --实际分播数量
                                         --   strCustContainerNo      in odata_divide_d.cust_container_no%type,--客户容器编码
                                         strDivideName in odata_divide_d.divide_name%type, --实际分播人员
                                         strOutMsg     out varchar2);

  /****************************************************************************************************
     lich
     2014.05.23
     功能说明：写分播单头档
  ******************************************************************************************************/
  procedure P_Insert_Odata_Divide_M(strEnterPriseNo in odata_divide_m.enterprise_no%type, --企业号
                                    strWarehouseNo  in odata_divide_m.warehouse_no%type, --仓别
                                    strOwnerNo      in odata_divide_m.owner_no%type, --货主
                                    dtOperateDate   in odata_divide_m.operate_date%type, --操作日期
                                    strDivideType   in odata_divide_m.divide_type%type, --分播类型  A:按商品分播；B:按容器分播；C:按客户分播
                                    strSourceType   in odata_divide_m.source_type%type,
                                    strWave_No      in odata_divide_m.wave_no%type,
                                    strBatchNo      in odata_divide_m.batch_no%type, --批次
                                    strDeviceNo     in odata_divide_m.device_no%type, --分播组号
                                    dtExpDate       in odata_divide_m.exp_date%type, --更新日期
                                    strRgstName     in odata_divide_m.rgst_name%type, --建立人员
                                    strDivideNo     out odata_divide_m.divide_no%type, --分播单号
                                    strOutMsg       out varchar2);
  /****************************************************************************************************
     lich
     2014.05.23
     功能说明：写分播单明细
  ******************************************************************************************************/
  procedure P_Insert_Odata_Divide_D(strEnterPriseNo    in odata_divide_d.enterprise_no%type,
                                    strWarehouseNo     in odata_divide_d.warehouse_no%type,
                                    strOwnerNo         in odata_divide_d.owner_no%type,
                                    strBatchNo         in odata_divide_d.batch_no%type,
                                    strDivideNo        in odata_divide_d.divide_no%type,
                                    strSourceNo        in odata_divide_d.source_no%type,
                                    strDivideId        in odata_divide_d.divide_id%type,
                                    dtOperateDate      in odata_divide_d.operate_date%type,
                                    strCustNo          in odata_divide_d.cust_no%type,
                                    strSubCustNo       in odata_divide_d.sub_cust_no%type,
                                    strExpType         in odata_divide_d.exp_type%type,
                                    strExpNo           in odata_divide_d.exp_no%type,
                                    strWaveNo          in odata_divide_d.wave_no%type,
                                    strArticleNo       in odata_divide_d.article_no%type,
                                    strArticleId       in odata_divide_d.article_id%type,
                                    strPackingQty      in odata_divide_d.packing_qty%type,
                                    strArticleQty      in odata_divide_d.article_qty%type,
                                    strSCellNo         in odata_divide_d.s_cell_no%type,
                                    strSCellId         in odata_divide_d.s_cell_id%type,
                                    strSContainerNo    in odata_divide_d.s_container_no%type,
                                    strDeliverArea     in odata_divide_d.deliver_area%type,
                                    strLineNo          in odata_divide_d.line_no%type,
                                    strTrunckCellNo    in odata_divide_d.trunck_cell_no%type,
                                    strCheckChuteNo    in odata_divide_d.check_chute_no%type,
                                    strDeliverObj      in odata_divide_d.deliver_obj%type,
                                    strDeliverobjOrder in odata_divide_d.deliverobj_order%type,
                                    dtOutstockDate     in odata_divide_d.outstock_date%type,
                                    strAssignNo        in odata_divide_d.assign_name%type,
                                    strDpsCellNo       in odata_divide_d.dps_cell_no%type,
                                    strASorterChuteNo  in odata_divide_d.a_sorter_chute_no%type,
                                    dtExpDate          in odata_divide_d.exp_date%type,
                                    strD_Label_No      in stock_label_m.label_no%type,
                                    strOutMsg          out varchar2);
  /****************************************************************************************************
     lich
     2014.05.23
     功能说明：写分播单指示
  ******************************************************************************************************/
  procedure P_Insert_Odata_Divide_Direct(strEnterPriseNo in odata_divide_d.enterprise_no%type,
                                         strWarehouseNo  in odata_divide_d.warehouse_no%type,
                                         strSourceNo     in odata_divide_d.source_no%type,
                                         strContainerNo  in odata_divide_d.s_container_no%type,
                                         strOutMsg       out varchar2);

  procedure P_Insert_Divide_Direct(strEnterPriseNo in odata_divide_d.enterprise_no%type,
                                   strWarehouseNo  in odata_divide_d.warehouse_no%type,
                                   strSourceNo     in odata_divide_d.source_no%type,
                                   strContainerNo  in odata_divide_d.s_container_no%type,
                                   strOutMsg       out varchar2);
  /****************************************************************************************************
     lich
     2014.05.29
     功能说明：更新分播回单明细
  ******************************************************************************************************/
  procedure p_Update_Odata_Divide_D(strEnterPriseNo    in odata_divide_d.enterprise_no%type,
                                    strWarehouseNo     in odata_divide_d.warehouse_no%type,
                                    strOwnerNo         in odata_divide_d.owner_no%type, --货主
                                    strDivideNO        in odata_divide_d.divide_no%type, --分播单号
                                    strRowId           in odata_divide_d.row_id%type, --指示序列
                                    nQty               in odata_divide_d.real_qty%type, --实际分播数量
                                    strCustContainerNo in odata_divide_d.cust_container_no%type, --客户容器编码
                                    strDivideName      in odata_divide_d.divide_name%type, --实际分播人员
                                    strAddFlag         in odata_divide_m.divide_type%type, --1：按数量回单；2：按记录数回单
                                    strOutMsg          out varchar2);
  /****************************************************************************************************
     lich
     2014.05.29
     功能说明：更新分播回单头档
  ******************************************************************************************************/
  procedure p_Update_Odata_Divide_M(strEnterPriseNo in ODATA_divide_m.enterprise_no%type,
                                    strWarehouseNo  in ODATA_divide_m.warehouse_no%type,
                                    strDivideNo     in ODATA_divide_m.Divide_No%type,
                                    strUpdtName     in ODATA_divide_m.Updt_Name%type,
                                    strOutMsg       out varchar2);
  /****************************************************************************************************
     lich
     2014.05.29
     功能说明：分播回单转历史
  ******************************************************************************************************/
  procedure p_Update_Odata_Divide_Hty(strEnterPriseNo in ODATA_divide_m.enterprise_no%type,
                                      strWarehouseNo  in ODATA_divide_m.warehouse_no%type,
                                      strOwnerNo      in odata_divide_m.owner_no%type,
                                      strDivideNo     in ODATA_divide_m.Divide_No%type,
                                      strOutMsg       out varchar2);
end PKOBJ_ODATA_DIVIDE;


/

