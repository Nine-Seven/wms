create FUNCTION        is_date(parameter VARCHAR2) RETURN NUMBER IS
  val DATE;
BEGIN
  val := TO_DATE(NVL(parameter, 'a'), 'yyyy-mm-dd');
  RETURN 1;
EXCEPTION
  WHEN OTHERS THEN
    RETURN 0;
END;


/

