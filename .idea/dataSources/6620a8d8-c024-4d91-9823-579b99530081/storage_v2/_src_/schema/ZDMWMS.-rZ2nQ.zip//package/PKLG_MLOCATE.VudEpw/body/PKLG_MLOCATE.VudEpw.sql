create package body        PKLG_MLOCATE is

  --商品补货定位
  procedure p_supply_article(v_nTmpStockID   in number,
                             strEnterpriseNo in odata_locate_m.enterprise_no%type,
                             strWareHouseNo  in varchar2, --仓库代码
                             strOwnerNo      in varchar2,
                             strSourceNo     in varchar2, --定位号
                             strBatchNo      in varchar2, --批次号
                             strStatus       in varchar2,
                             strOperateType  in varchar2, --作业类型
                             strOutstockType in varchar2, --出货类型
                             strSourceType   in varchar2, --来源类型
                             strCPickCellNo  in cset_cell_article.cell_no%type,
                             nCMaxQty        in cset_cell_article.max_qty_a%type,
                             nCKeepCells     in cset_cell_article.keep_cells%type,
                             strBPickCellNo  in cset_cell_article.cell_no%type,
                             nBMaxQty        in cset_cell_article.max_qty_a%type,
                             nBKeepCells     in cset_cell_article.keep_cells%type,
                             nPickLine       in cset_cell_article.line_id%type,
                             nPickCellCount  in number,
                             strStockType    in varchar2,
                             strStockValue   in varchar2,
                             strPrioity      in varchar2,
                             dtLocateDate    in date,
                             strArticleNo    in varchar2, --商品代码
                             nNeedSuppQty    in number,
                             nMinSuppQty     in number,
                             nRealSuppQty    in out number,
                             nMustMinFlag    in number,
                             strWorkNo       in varchar2, --员工代码
                             nSuppType       in varchar2,
                             strErrorMsg     out varchar2) is

    v_strCellWareNo  cdef_defcell.ware_no%type;
    v_strCellAreaNo  cdef_defcell.area_no%type;
    v_strCellStockNo cdef_defcell.stock_no%type;

    v_nCurrSuppQty   odata_outstock_direct.locate_qty%type;
    v_nSingleSuppQty odata_outstock_direct.locate_qty%type;
    v_nDirectSuppQty odata_outstock_direct.locate_qty%type;

    v_nMinSuppQty  odata_outstock_direct.locate_qty%type;
    v_nNeedSuppQty odata_outstock_direct.locate_qty%type;

    v_nCellMaxQty cset_cell_article.max_qty_a%type;
    v_nCellKeeps  cset_cell_article.keep_cells%type := nBKeepCells;
    v_strLine_ID  cset_cell_article.line_id%type := nPickLine;

    v_nPickCount number(2) := nPickCellCount; --拣货位个数

    v_nSuppLevel     number(2); --当前补货级别
    v_nCurrSuppLevel number(2);
    v_nPickAreaType cdef_defarea.area_type%type; --拣纲位的储区类型
    v_nPalleteQty        bdef_article_packing.qpalette%type;
    v_strCellProdateCtrl wms_defbase.sdefine%type;

    v_nSuppType number(1); --补货类型（0：保拣线补到拣货位；1：全仓补到拣货位；2：保拣线补到保管位；3：全仓补到保管位）

    v_blExitFlag boolean;

    v_blIgnoreFlag boolean;
    v_nProduceFlag number;
    --v_strAllCelln  wms_defbase.ndefine%type;
    strAllCelln    wms_defbase.sdefine%type;

    v_nBackLevelClass number;

    v_nCount number;

  begin
    strErrorMsg := 'Y|';

    --如果是定位到异常区，不补货
    if nSuppType in (5, 6) then
      return;
    end if;

    --如果有箱拣货位，补拆零时，因为采用箱线保管级别需要提升一级
    v_nBackLevelClass := 0;
    if strOperateType = 'B' and strCPickCellNo <> 'N' then
      v_nBackLevelClass := 1;
    end if;

    --预留
    v_nProduceFlag := 0;

    v_nMinSuppQty   := nMinSuppQty;
    v_nNeedSuppQty  := nNeedSuppQty;
    v_strCellWareNo := 'N';

    if v_nPickCount > 0 then
      --有拣货位
      begin
        --
        if strOperateType = 'B' or v_nPickCount <= 1 then

          select distinct c.ware_no   as ware_no,
                          c.area_no   as area_no,
                          c.stock_no  as stock_no,
                          cda.max_qty,
                          cda.area_type
            into v_strCellWareNo,
                 v_strCellAreaNo,
                 v_strCellStockNo,
                 v_nCellMaxQty,
                 v_nPickAreaType
            from cdef_defarea cda, cdef_defcell c
           where cda.enterprise_no = c.enterprise_no
             and cda.warehouse_no = c.warehouse_no
             and cda.ware_no = c.ware_no
             and cda.area_no = c.area_no
             and c.enterprise_no = strEnterPriseNo
             and c.warehouse_no = strWareHouseNo
             and c.cell_no like
                 decode(strOperateType,
                        'B',
                        strBPickCellNo,
                        decode(strCPickCellNo,
                               'N',
                               strBPickCellNo,
                               strCPickCellNo)) || '%';

          v_nSuppLevel := 0;

        else
           select distinct c.ware_no     as ware_no,
                          c.area_no     as area_no,
                          c.stock_no    as stock_no,
                          cda.area_type
            into v_strCellWareNo,
                 v_strCellAreaNo,
                 v_strCellStockNo,
                 v_nPickAreaType
            from cdef_defcell c, cdef_defarea cda
           where cda.enterprise_no = c.enterprise_no
             and cda.warehouse_no = c.warehouse_no
             and cda.ware_no = c.ware_no
             and cda.area_no = c.area_no
             and c.enterprise_no = strEnterPriseNo
             and c.warehouse_no = strWareHouseNo
             and c.cell_no like strCPickCellNo || '%';
          v_nSuppLevel := 0;

        end if;
      exception
        when no_data_found then
          --预留
          v_strCellWareNo := 'N';
          return;
      end;
    end if;

    --获取系统参数 判断同一货位是不需要严格管生产日期
    PKLG_WMS_BASE.p_GetBasePara(strEnterPriseNo,
                                strWareHouseNo,
                                strOwnerNo,
                                'ProduceDateLevel',
                                'O',
                                'O_LOCATE',
                                v_strCellProdateCtrl,
                                strAllCelln,
                                strErrorMsg);
    if substr(strErrorMsg, 1, 1) = 'N' then
      strErrorMsg := 'N|[E30025]';
      return;
    end if;

    --补货类型（0：保拣线补到拣货位；1：全仓补到拣货位；2：保拣线补到保管位；3：全仓补到保管位）
    v_nSuppType := case
                     when nSuppType in (1, 3) then
                      0
                     else
                      1
                   end;
    v_blExitFlag := false;

    v_nCurrSuppQty   := v_nNeedSuppQty;
    v_nCurrSuppLevel := v_nSuppLevel;

    loop
      v_blIgnoreFlag := false;
      for v_cs_stock in (SELECT t.*
                           FROM (SELECT s.enterprise_no,
                                        S.WAREHOUSE_NO,
                                        S.OWNER_NO,
                                        S.CELL_NO,
                                        S.ARTICLE_NO,
                                        S.DEPT_NO,
                                        S.LABEL_NO,
                                        CDA.WARE_NO,
                                        CDA.AREA_NO,
                                        CDA.LIMIT_RATE,
                                        CDA.LIMIT_TYPE,
                                        CDA.PAL_OUT_RATE,
                                        CDA.ADVANCER_PICK_FLAG,
                                        S.PACKING_QTY,
                                        S.QUALITY,
                                        S.S_QTY,
                                        S.S_INSTOCK_QTY,
                                        S.S_OUTSTOCK_QTY,
                                        s.flag,
                                        BDA.EXPIRY_DAYS,
                                        CDA.O_TYPE,
                                        CDA.AREA_PICK,
                                        CDA.AREA_USETYPE,
                                        CDA.DIVIDE_FLAG,
                                        CDA.B_DIVIDE_FLAG,
                                        s.LOT_NO,
                                        --S.SUPPLIER_NO,
                                        CDA.AREA_TYPE,
                                        CDC.PICK_FLAG,
                                        CDC.MAX_QTY,
                                        case
                                          when v_strCellWareNo <> 'N' and
                                               v_nSuppType in (0, 2) then --如果有保拣线
                                           NVL((SELECT CAB.A_LEVEL +
                                                      v_nBackLevelClass
                                                 FROM CSET_AREA_BACKUP_D CAB
                                                WHERE CAB.WAREHOUSE_NO =
                                                      CDC.WAREHOUSE_NO
                                                  and cab.enterprise_no =
                                                      cdc.enterprise_no
                                                  AND CAB.WARE_NO =
                                                      CDC.WARE_NO
                                                  AND CAB.AREA_NO = (CASE
                                                        WHEN CAB.AREA_NO = 'N' then
                                                         'N'
                                                        else
                                                         CDC.AREA_NO
                                                      END)
                                                  AND CAB.STOCK_NO = (CASE
                                                        WHEN CAB.STOCK_NO = 'N' then
                                                         'N'
                                                        else
                                                         CDC.STOCK_NO
                                                      END)
                                                  AND CAB.Line_ID =
                                                      v_strLine_ID),
                                               DECODE(CDA.O_TYPE,
                                                      'P',
                                                      2,
                                                      'C',
                                                      3,
                                                      'B',
                                                      4) * -1)
                                          else
                                           DECODE(CDA.O_TYPE,
                                                  'P',
                                                  2,
                                                  'C',
                                                  3,
                                                  'B',
                                                  4) * -1
                                        end SORT_LEVEL,
                                        CASE
                                          WHEN CDA.AREA_TYPE = '1' THEN
                                           CDC.STOCK_X
                                          ELSE
                                           '1'
                                        END SORT_CELL,
                                        --nvl(baw.qpalette, BAP.QPALETTE) AS PALLETE_QTY,
                                        s.produce_date,
                                        s.article_id,
                                        S.SORT_DATE,
                                        S.SORT_BATCH,
                                        S.SORT_FLAG,
                                        s.min_expire_date,
                                        S.S_CAN_USE_QTY
                                   FROM BDEF_DEFARTICLE BDA,
                                        (select c.enterprise_no,
                                                C.WAREHOUSE_NO,
                                                C.OWNER_NO,
                                                C.DEPT_NO,
                                                C.CELL_NO,
                                                C.LABEL_NO,
                                                C.ARTICLE_NO,
                                                C.PACKING_QTY,
                                                a.QUALITY,
                                                a.LOT_NO,
                                                --a.SUPPLIER_NO,
                                                max(c.flag) flag,
                                                min(a.PRODUCE_DATE) as produce_date,
                                                min(a.article_id) as article_id,
                                                --MIN(TRUNC(a.PRODUCE_DATE)) SORT_DATE,
                                                case
                                                  when min(b.turn_over_rule) =
                                                       'LIFO' then
                                                   MAX(TRUNC(a.PRODUCE_DATE))
                                                  else
                                                   case
                                                     when min(b.turn_over_rule) =
                                                          'FEFO' then
                                                      MIN(TRUNC(a.expire_date))
                                                     else
                                                      MIN(TRUNC(a.PRODUCE_DATE))
                                                   end
                                                end as SORT_DATE,
                                                MIN(TRUNC(a.expire_date)) min_expire_date,
                                                MIN(SUBSTR(a.IMPORT_BATCH_NO,
                                                           2,
                                                           20)) SORT_BATCH,
                                                MAX(C.FLAG) AS SORT_FLAG,
                                                sum(C.QTY - C.OUTSTOCK_QTY +
                                                    (case C.Instock_Type
                                                      when '1' then
                                                       C.INSTOCK_QTY
                                                      else
                                                       0
                                                    end) + C.UNUSUAL_QTY) AS S_QTY,
                                                SUM(case C.Instock_Type
                                                      when '1' then
                                                       C.INSTOCK_QTY
                                                      else
                                                       0
                                                    end) AS S_INSTOCK_QTY,
                                                SUM(C.OUTSTOCK_QTY) AS S_OUTSTOCK_QTY,
                                                SUM(case
                                                      when (C.QTY - C.OUTSTOCK_QTY +
                                                           C.UNUSUAL_QTY) > 0 then
                                                       (C.QTY - C.OUTSTOCK_QTY +
                                                       C.UNUSUAL_QTY)
                                                      else
                                                       0
                                                    end) as S_CAN_USE_QTY
                                           FROM BDEF_DEFARTICLE    B,
                                                STOCK_CONTENT      C,
                                                STOCK_article_info a,
                                                TMP_STOCK_CONTENT  tmpsc
                                          WHERE b.enterprise_no =
                                                c.enterprise_no
                                            and b.enterprise_no =
                                                a.enterprise_no
                                            and b.enterprise_no =
                                                strEnterPriseNO
                                            and B.OWNER_NO = C.OWNER_NO
                                            AND B.ARTICLE_NO = C.ARTICLE_NO
                                            and a.article_no = c.article_no
                                            and b.enterprise_no =
                                                tmpsc.enterprise_no
                                            AND c.warehouse_no =
                                                tmpsc.warehouse_no
                                            AND c.cell_no = tmpsc.cell_no
                                            And c.cell_id = tmpsc.cell_id

                                            and a.article_id = c.article_id
                                            AND c.WAREHOUSE_NO =
                                                strWareHouseNo
                                            AND a.ARTICLE_NO = strArticleNo
                                            AND c.stock_type = strStockType
                                            AND c.stock_value = strStockValue
                                            AND C.STATUS = 0
                                               --条件
                                               -- AND C.HM_MANUAL_FLAG = ''
                                            AND C.FLAG <> '2'
                                            AND (C.INSTOCK_QTY + C.QTY -
                                                C.OUTSTOCK_QTY +
                                                C.UNUSUAL_QTY) > 0
                                          GROUP BY c.enterprise_no,
                                                   C.WAREHOUSE_NO,
                                                   C.OWNER_NO,
                                                   C.DEPT_NO,
                                                   C.CELL_NO,
                                                   C.LABEL_NO,
                                                   C.ARTICLE_NO,
                                                   C.PACKING_QTY,
                                                   a.QUALITY,
                                                   a.LOT_NO,
                                                   --a.SUPPLIER_NO,
                                                   --预留，严格按生产日期出货此处需要修改
                                                   (case
                                                     when v_strCellProdateCtrl = 0 then
                                                      a.produce_date
                                                     else
                                                      trunc(sysdate)
                                                   end)
                                          order by s_qty desc) S,
                                        CDEF_DEFAREA CDA,
                                        CDEF_DEFCELL CDC
                                  WHERE CDA.WAREHOUSE_NO = CDC.WAREHOUSE_NO
                                    and cda.enterprise_no = cdc.enterprise_no
                                    and cda.enterprise_no = s.enterprise_no
                                    and cda.enterprise_no = bda.enterprise_no
                                    AND CDA.WARE_NO = CDC.WARE_NO
                                    AND CDA.AREA_NO = CDC.AREA_NO
                                    AND CDA.AREA_ATTRIBUTE = '0'
                                    AND CDC.WAREHOUSE_NO = s.WAREHOUSE_NO
                                    AND CDC.CELL_NO = s.CELL_NO
                                    AND BDA.ARTICLE_NO = s.ARTICLE_NO
                                    and cdc.cell_status = '0'
                                    AND CDC.CHECK_STATUS = '0') t
                         --补货类型（0：保拣线补到拣货位；1：全仓补到拣货位；2：保拣线补到保管位；3：全仓补到保管位）
                          where ((v_nSuppType in (0, 2) and
                                t.SORT_LEVEL >= 0) or
                                (v_nSuppType in (1, 3) and t.SORT_LEVEL < 0))
                            and s_qty > 0
                          ORDER BY (case
                                     when t.AREA_USETYPE = 1 then
                                      0
                                     else
                                      1
                                   end),
                                   (case
                                     when t.flag = '3' then
                                      0
                                     else
                                      1
                                   end),
                                   t.sort_level,
                                   /*                                   case
                                     when v_nSuppType in (2, 3) then
                                      t.SORT_LEVEL * -1
                                     else
                                      t.SORT_LEVEL * -1
                                   end DESC,*/
                                   (case
                                     when t.S_CAN_USE_QTY <> 0 then
                                      0
                                     else
                                      1
                                   end),
                                   t.SORT_DATE,
                                   t.S_CAN_USE_QTY,
                                   t.S_QTY,
                                   t.SORT_CELL,
                                   t.SORT_DATE,
                                   t.SORT_BATCH,
                                   t.LOT_NO,
                                   t.QUALITY,
                                   t.PACKING_QTY
                         --t.SUPPLIER_NO
                         ) loop
        --定位完成，退出
        if v_nCurrSuppQty <= 0 then
          exit;
        end if;

       begin
           select nvl(baw.qpalette, BAP.QPALETTE)
            into v_nPalleteQty
            from BDEF_ARTICLE_PACKING BAP
            left join bdef_warehouse_packing baw
              on baw.warehouse_no = strWareHouseNo
             and baw.enterprise_no = strEnterPriseNO
             and baw.article_no = bap.article_no
             and baw.packing_qty = bap.packing_qty
           where bap.enterprise_no = strEnterPriseNo
             AND BAP.ARTICLE_NO = v_cs_stock.ARTICLE_NO
             AND BAP.PACKING_QTY = v_cs_stock.PACKING_QTY;
        exception
            when others then
            v_nPalleteQty := 1;
         end;

        --相同级别不做补货
        if v_cs_stock.SORT_LEVEL = v_nCurrSuppLevel then
          goto next_cs_stock;
        end if;

        --当前区域的下架类型与补货类型相同，并且是补到拣货位，不做补货
        if strOperateType = v_cs_stock.o_type and v_nSuppType in (0, 1) and
           v_cs_stock.AREA_PICK = '1' then
          goto next_cs_stock;
        end if;

        --零出区不往箱区补
        if strOperateType = 'C' and v_cs_stock.o_type = 'B' then
          goto next_cs_stock;
        end if;

        --箱型补货，流理架、轻型货架、混合型区、混合拣货区不做补货
        if strOperateType = 'C' and
           v_cs_stock.AREA_TYPE in ('4', '5', '6', '8') then
          goto next_cs_stock;
        end if;

        v_nSingleSuppQty := v_cs_stock.s_qty;
        if v_nCurrSuppQty < v_nSingleSuppQty then
          if v_cs_stock.o_type = 'P' and strOperateType = 'B' and
             v_nSuppType in (0, 1) then
            v_blIgnoreFlag := true;
            goto next_cs_stock;

          end if;

          if strOperateType = 'B' and v_nSuppType in (0, 1) then
            --如果最大量有做限制，并且不是整零合一拣货位
            if v_nCellMaxQty <> 0 and v_nPickCount > 1 then
              v_nSingleSuppQty := ceil(v_nCurrSuppQty /
                                       v_cs_stock.packing_qty) *
                                  v_cs_stock.packing_qty;

              --如果超过拣货位最大量，但扣减一箱后还能满足最小补货量，则少补一箱
              if v_nSingleSuppQty > v_nCellKeeps * v_nCellMaxQty and
                 (v_nSingleSuppQty - v_cs_stock.packing_qty) >
                 v_nMinSuppQty then
                v_nSingleSuppQty := v_nSingleSuppQty -
                                    v_cs_stock.packing_qty;
              end if;

              if v_nSingleSuppQty > v_cs_stock.s_qty then
                v_nSingleSuppQty := v_cs_stock.s_qty;
              end if;
            end if;

            --ADD by qzh at 2016-4-23 流理架、轻型货架、混合型区、混合拣货区补货参考储位最大量
            if  v_nPickAreaType in ('4', '5', '6', '8') then
               if v_nNeedSuppQty>=nBMaxQty then
                  v_nSingleSuppQty:=v_nNeedSuppQty;
               else
                  v_nSingleSuppQty:=nBMaxQty;
               end if;
            end if;
            --Add End
          end if;

          if strOperateType = 'C' and v_nSuppType in (0, 1) then
            --如果箱补，库存量比标准量小则清空
            if v_nSingleSuppQty <= v_nPalleteQty then
              v_nSingleSuppQty := floor(v_nSingleSuppQty /
                                        v_cs_stock.packing_qty) *
                                  v_cs_stock.packing_qty;
            else
              v_nSingleSuppQty := floor(v_nCurrSuppQty /
                                        v_cs_stock.packing_qty) *
                                  v_cs_stock.packing_qty;
            end if;
          end if;

          --补到保管位，如果保管位是箱拣货位补到最大量，否则补一个标准堆叠量
          if v_nSuppType in (2, 3) then

            select count(1)
              into v_nCount
              from cdef_defcell cdc
             where cdc.enterprise_no = strEnterpriseNo
               and cdc.warehouse_no = strWareHouseNo
               and cdc.cell_no like strCPickCellNo || '%'
               and cdc.ware_no = v_cs_stock.ware_no
               and cdc.area_no = v_cs_stock.area_no;

            if v_nCount > 0 then
              if v_nSingleSuppQty > nCMaxQty then
                v_nSingleSuppQty := nCMaxQty;
              end if;
            else
              if v_nSingleSuppQty > v_nPalleteQty then
                v_nSingleSuppQty := v_nPalleteQty;
              end if;
            end if;

          end if;

        else
          if strOperateType <> 'B' then
            v_nSingleSuppQty := floor(v_nSingleSuppQty /
                                      v_cs_stock.packing_qty) *
                                v_cs_stock.packing_qty;
          end if;

        end if;

        if v_nSingleSuppQty <= 0 then

          goto next_cs_stock;
        end if;

        --写下架指示
        v_nDirectSuppQty := 0;
        p_write_direct(v_nTmpStockID,
                       strEnterPriseNO,
                       strWareHouseNo, --仓库代码
                       strOwnerNo,
                       strSourceNo, --定位号
                       strOutstockType, --出货类型
                       strSourceType, --来源类型
                       strOperateType, --定位类型
                       strBPickCellNo,
                       strCPickCellNo,
                       v_nCellKeeps, --Modify BY QZH AT 2016-4-22
                       nPickLine,
                       strBatchNo, --定位批次
                       v_nSuppType, --补货类型
                       v_nCurrSuppLevel, --补货级别
                       strStatus,
                       strPrioity,
                       dtLocateDate,
                       strArticleNo, --商品代码
                       v_cs_stock.article_id,
                       v_cs_stock.Cell_No,
                       v_cs_stock.Dept_No,
                       v_cs_stock.LABEL_NO,
                       v_cs_stock.Packing_Qty,
                       v_nProduceFlag,
                       v_cs_stock.Produce_Date,
                       v_cs_stock.Quality, --商品品质
                       v_cs_stock.Lot_No,
                       --v_cs_stock.Supplier_No,
                       strStockType, --库存性质
                       strStockValue, --库存值
                       v_nSingleSuppQty, --定位量
                       v_nDirectSuppQty,
                       strWorkNo, --员工代码
                       strErrorMsg);
        if substr(strErrorMsg, 1, 2) = 'N|' then
          return;
        end if;
        --可能因为补货目的储位设置问题，造成补货不成功
        if v_nDirectSuppQty <= 0 then
          exit;
        end if;

        if v_nSuppType in (0, 1) then
          nRealSuppQty   := nRealSuppQty + v_nDirectSuppQty;
          v_nMinSuppQty  := v_nMinSuppQty - v_nDirectSuppQty;
          v_nNeedSuppQty := v_nNeedSuppQty - v_nDirectSuppQty;
          v_nCurrSuppQty := v_nCurrSuppQty - v_nDirectSuppQty;

          --如果不需要补足量，则退出
          if nMustMinFlag = 0 then
            v_blExitFlag := true;
            exit;
          end if;

          --如果补足最小量，也退出
          if v_nMinSuppQty <= 0 then
            v_blExitFlag := true;
            exit;
          end if;
        else
          if v_nDirectSuppQty > 0 then
            exit;
          end if;
        end if;

        <<next_cs_stock>>
        null;
        /*if v_blIgnoreFlag = true then
          exit;
        end if;*/

      end loop; --end loop v_cs_stock

      if v_blExitFlag = true then
        exit;
      end if;
      ------------------------------------------------------------------------------------------
      --以下控制比较复杂，根据需要再进行调整，特别是往保管位补
      --补货类型（0：保拣线补到拣货位；1：全仓补到拣货位；2：保拣线补到保管位；3：全仓补到保管位）

      --如果被忽略，则需要做保管位往保管位补
      if v_blIgnoreFlag = true then
        if v_nSuppType = 0 then
          v_nSuppType := 2;
        else
          v_nSuppType := 3;
        end if;
        v_nCurrSuppLevel := v_nCurrSuppLevel + 1;

        --补一个标准堆叠
        v_nCurrSuppQty := v_nPalleteQty;
      else

        if v_nSuppType in (0, 1) then
          if v_nSuppType = 0 then
            if nMinSuppQty > nRealSuppQty then
              v_nSuppType := 1;
            else
              exit;
            end if;
          else
            exit;
          end if;
        else
          if v_nDirectSuppQty <= 0 then
            exit;
          end if;
          v_nSuppType      := 0;
          v_nCurrSuppLevel := v_nSuppLevel;
        end if;
        v_nCurrSuppQty := v_nNeedSuppQty;

      end if;

    end loop;

  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_supply_article;

  --写库存及定位指示
  procedure p_write_direct(v_nTmpStockID   in number,
                           strEnterpriseNo in odata_locate_m.enterprise_no%type,
                           strWareHouseNo  in varchar2, --仓库代码
                           strOwnerNo      in varchar2,
                           strSourceNo     in varchar2, --定位号
                           strOutstockType in varchar2, --出货类型
                           strSourceType   in varchar2, --来源类型
                           strOperateType  in varchar2, --定位类型
                           strBPickCellNo  in cset_cell_article.cell_no%type,
                           strCPickCellNo  in cset_cell_article.cell_no%type,
                           nKeepCells      in cset_cell_article.keep_cells%type, --Modify BY QZH AT 2016-4-22
                           nPickLine       in cset_cell_article.line_id%type,
                           strBatchNo      in varchar2, --定位批次
                           nSuppType       in number, --补货类型
                           nCurrSuppLevel  in number, --补货级别
                           strStatus       in varchar2,
                           strPrioity      in varchar2,
                           dtLocateData    in date,
                           strArticleNo    in varchar2, --商品代码
                           nArticleID      in number, --Article_ID
                           strCellNo       in varchar2,
                           strDeptNo       in varchar2,
                           strContainerNo  in varchar2,
                           nPacking_Qty    in number,
                           nProduceFlag    in number,
                           dtProduceDate   in date,
                           strQuality      in varchar2, --商品品质
                           --strItemType     in varchar2, --商品属性
                           strLotNo in varchar2,
                           --strSupplierNo   in varchar2,
                           strStockType   in varchar2, --库存性质
                           strStockValue  in varchar2, --库存值
                           nLocateQty     in number, --定位量
                           nRealLocateQty in out number,
                           strWorkNo      in varchar2, --员工代码
                           strErrorMsg    out varchar2) is

    v_nStockAllotQty  stock_content.qty%type;
    v_nDirectTotalQty stock_content.qty%type;

    v_nDestCellID stock_content.cell_id%type;

    v_strStatus odata_outstock_direct.status%type;

    v_strDestCellNo cdef_defcell.cell_no%type;
    v_strExpType    odata_locate_m.exp_type%type;
  begin
    strErrorMsg := 'Y|';

    --modify by mm 20140712 取单据类型,取不到为N
    begin
      select olm.exp_type
        into v_strExpType
        from odata_locate_m olm
       where olm.enterprise_no = strEnterPriseNO
         and olm.warehouse_no = strWareHouseNo
         --and olm.owner_no = strOwnerNo
         and olm.wave_no = strSourceNo;
    exception
      when no_data_found then
        v_strExpType := 'N';
    end;

    --获取补货储位
    p_get_supp_cell(strEnterPriseNO,
                    strWareHouseNo, --仓库代码
                    strOwnerNo,
                    strOperateType, --定位类型
                    strBPickCellNo,
                    strCPickCellNo,
                    nKeepCells, --Modify BY QZH AT 2016-4-22
                    nPickLine,
                    nSuppType, --补货类型
                    nCurrSuppLevel, --补货级别
                    strArticleNo, --商品代码
                    nArticleID,
                    nPacking_Qty,
                    nLocateQty,
                    strDeptNo,
                    nProduceFlag,
                    dtProduceDate,
                    strQuality, --商品品质
                    --strItemType, --商品属性
                    strLotNo,
                    strStockType, --库存性质
                    strStockValue, --库存值
                    v_strDestCellNo,
                    strErrorMsg);
    if substr(strErrorMsg, 1, 2) = 'N|' then
      return;
    end if;

    --modify mm 20140729 没有拣货位不补
    if v_strDestCellNo = 'N' then
      return;
    end if;

    p_set_cell_suppcount(strEnterPriseNO,
                         strWareHouseNo,
                         v_strDestCellNo,
                         strArticleNo,
                         strErrorMsg);
    if substr(strErrorMsg, 1, 2) = 'N|' then
      return;
    end if;

    v_nDirectTotalQty := nLocateQty;
    for v_cs_stock in (select *
                         from (select sc.*,
                                      sc.QTY - sc.OUTSTOCK_QTY +
                                      (case sc.Instock_Type
                                        when '1' then
                                         sc.INSTOCK_QTY
                                        else
                                         0
                                      end) + sC.UNUSUAL_QTY as use_qty
                                 from stock_content      sc,
                                      stock_article_info sai
                                where sc.enterprise_no = sai.enterprise_no
                                  and sc.enterprise_no = strEnterPriseNO
                                  and sc.article_no = sai.article_no
                                  and sc.article_id = sai.article_id
                                  and sc.warehouse_no = strWareHouseNo
                                  and sc.dept_no = strDeptNo
                                  and sc.cell_no = strCellNo
                                  and sc.packing_qty = nPacking_Qty
                                  and sc.stock_type = strStockType
                                  and sc.stock_value = strStockValue
                                  and sai.article_no = strArticleNo
                                  and sai.lot_no = strLotNo
                                     --Add BY QZH AT 2016-5-25
                                  and ((strOutstockType = '1' and exists
                                       (select 'x'
                                           from tmp_stock_content tmp
                                          where tmp.enterprise_no =
                                                sc.enterprise_no
                                            and tmp.warehouse_no =
                                                sc.warehouse_no
                                            and tmp.cell_no = sc.cell_no
                                            and tmp.cell_id = sc.cell_id) or
                                       strOutstockType <> '1'))
                                     --Add End
                                  and (nProduceFlag = 0 or
                                      (nProduceFlag = 1 and
                                      sai.produce_date = dtProduceDate))
                                  and sai.quality = strQuality
                                  and sc.QTY - sc.OUTSTOCK_QTY +
                                      sc.INSTOCK_QTY + sC.UNUSUAL_QTY > 0)
                        where use_qty > 0) loop

      if v_nDirectTotalQty <= 0 then
        exit;
      end if;

      v_nStockAllotQty := v_cs_stock.use_qty;
      if v_nStockAllotQty > v_nDirectTotalQty then
        v_nStockAllotQty := v_nDirectTotalQty;
      end if;

      v_nDirectTotalQty := v_nDirectTotalQty - v_nStockAllotQty;
      nRealLocateQty    := nRealLocateQty + v_nStockAllotQty;

      --写库存
      PKOBJ_STOCK.p_UpdtContent_Reservation(strEnterPriseNO,
                                            strWareHouseNo,
                                            v_cs_stock.cell_no,
                                            v_cs_stock.cell_id,
                                            v_strDestCellNo,
                                            'N',
                                            'N',
                                            v_nStockAllotQty,
                                            '1', --补货预上
                                            strWorkNo,
                                            v_nDestCellID,
                                            strErrorMsg);
      if substr(strErrorMsg, 1, 2) = 'N|' then
        return;
      end if;

      -- mm 20140712 写临时表
      delete from TMP_STOCK_CONTENT t
       where enterprise_no = strEnterPriseNO
         and warehouse_no = strWareHouseNo
         and cell_no = v_strDestCellNo
         and cell_id = v_nDestCellID
         and t.tmp_id = v_nTmpStockID;

      Insert into TMP_STOCK_CONTENT
        (tmp_id, enterprise_no, warehouse_no, cell_no, cell_id)
        select v_nTmpStockID, enterprise_no, warehouse_no, cell_no, cell_id
          from STOCK_CONTENT
         where enterprise_no = strEnterPriseNO
           and warehouse_no = strWareHouseNo
           and owner_no = strOwnerNo
           and cell_no = v_strDestCellNo
           and cell_id = v_nDestCellID;

      if v_nStockAllotQty >
         v_cs_stock.qty - v_cs_stock.outstock_qty + v_cs_stock.UNUSUAL_QTY then
        v_strStatus := '12';
      else
        v_strStatus := strStatus;
      end if;

      --写指示
      insert into odata_outstock_direct
        (enterprise_no,
         warehouse_no,
         OUTSTOCK_TYPE,
         SOURCE_TYPE,
         OPERATE_TYPE,
         PICK_TYPE,
         owner_no,
         batch_no,
         operate_date,
         cust_no,
         sub_cust_no,
         article_no,
         article_id,
         STOCK_TYPE,
         packing_qty,
         LOCATE_QTY,
         s_cell_no,
         s_cell_id,
         D_CELL_NO,
         D_CELL_ID,
         LABEL_NO,
         exp_type,
         exp_no,
         wave_no,
         deliver_area,
         status,
         TEMP_STATUS,
         line_no,
         PRIORITY,
         deliver_obj,
         exp_date,
         SUPP_COUNT,
         rgst_name,
         rgst_date,
         updt_name,
         updt_date)
        select strEnterPriseNO,
               strWareHouseNo,
               strOutstockType,
               strSourceType,
               'C', --strOperateType,共速达采用C型补货，暂时写死
               '0',
               strOwnerNo,
               strBatchNo,
               trunc(dtLocateData),
               'N',
               'N',
               v_cs_stock.article_no,
               v_cs_stock.article_id,
               v_cs_stock.STOCK_TYPE,
               nPacking_Qty,
               v_nStockAllotQty,
               v_cs_stock.cell_no,
               v_cs_stock.cell_id,
               v_strDestCellNo,
               v_nDestCellID,
               v_cs_stock.label_no,
               v_strExpType,
               strSourceNo,
               -- 'N',
               -- 'N',
               strSourceNo,
               'N', --此部分预留
               'N',
               v_strStatus,
               'N',
               strPrioity,
               'N',
               trunc(dtLocateData),
               SUPP_COUNT,
               strWorkNo,
               sysdate,
               strWorkNo,
               sysdate
          from cdef_defcell_suppcount
         where enterprise_no = strEnterPriseNO
           and warehouse_no = strWareHouseNo
           and cell_no = v_strDestCellNo
           and article_no = strArticleNo;

      if sql%rowcount <= 0 then
        strErrorMsg := 'N|[E3201905]';
        return;
      end if;

    end loop;

  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_write_direct;

  --读取补货目的储位
  procedure p_get_supp_cell(strEnterpriseNo in odata_locate_m.enterprise_no%type,
                            strWareHouseNo  in varchar2, --仓库代码
                            strOwnerNo      in varchar2,
                            strOperateType  in varchar2, --定位类型
                            strBPickCellNo  in cset_cell_article.cell_no%type,
                            strCPickCellNo  in cset_cell_article.cell_no%type,
                            nKeepCells      in cset_cell_article.keep_cells%type, --Modify BY QZH AT 2016-4-22
                            nPickLine       in cset_cell_article.line_id%type,
                            nSuppType       in number, --补货类型
                            nCurrSuppLevel  in number, --补货级别
                            strArticleNo    in varchar2, --商品代码
                            nArticleID      in number, --Article_ID
                            nPacking_Qty    in bdef_article_packing.packing_qty%type,
                            nLocateQty      in stock_content.qty%type,
                            strDeptNo       in varchar2,
                            nProduceFlag    in number,
                            dtProduceDate   in date,
                            strQuality      in varchar2, --商品品质
                            --strItemType    in varchar2, --商品属性
                            strLotNo      in varchar2,
                            strStockType  in varchar2, --库存性质
                            strStockValue in varchar2, --库存值
                            strDestCellNo out varchar2,
                            strErrorMsg   out varchar2) is

    v_strWareNo     CSET_CELL_ARTICLE.Ware_No%type;
    v_strAreaNo     CSET_CELL_ARTICLE.Area_No%type;
    v_strStockNo    Cdef_Defcell.Stock_No%type;
    v_strStockX     Cdef_Defcell.Stock_x%type;
    v_nMaxQTY       cset_cell_article.max_qty_a%type;
    v_strStockY     Cdef_Defcell.Stock_y%type;
    v_strBayX       CDEF_DEFCELL.Bay_x%type;
    v_strPickCellNo CDEF_DEFCELL.Cell_No%type;
    v_nKeepCells    CSET_CELL_ARTICLE.Keep_Cells%type := nKeepCells;
    v_nMergerFlag   CSET_AREA_BACKUP_D.MERGER_FLAG%type;
    v_nStockFlag    CSET_AREA_BACKUP_D.STOCK_FLAG%type;
    v_nFloorFlag    CSET_AREA_BACKUP_D.FLOOR_FLAG%type;
    v_nStockXFlag   CSET_AREA_BACKUP_D.STOCKX_FLAG%type;
    v_nBayFlag      CSET_AREA_BACKUP_D.BAY_FLAG%type;
    v_nSortFlag     CSET_AREA_BACKUP_D.SORT_FLAG%type;

    v_strTempPickCellNo CDEF_DEFCELL.Cell_No%type;
    --v_nCount            number;
  begin
    strErrorMsg   := 'Y|';
    strDestCellNo := 'N';

    begin

      select cdc.cell_no
        into v_strTempPickCellNo
        from cdef_defcell cdc
       where cdc.enterprise_no = strEnterPriseNO
         and cdc.warehouse_no = strWareHouseNo
         and cdc.cell_no = decode(strOperateType,
                                  'B',
                                  strBPickCellNo,
                                  decode(strCPickCellNo,
                                         'N',
                                         strBPickCellNo,
                                         strCPickCellNo));
      --Modify BY QZH AT 2016-4-22
      if v_nKeepCells = 1 then
        strDestCellNo := v_strTempPickCellNo;
        return;
      end if;

    exception
      when no_data_found then
        select cell_no
          into v_strTempPickCellNo
          from (select cdc.cell_no, nvl(sc.qty, 0) as qty
                  from cdef_defcell cdc
                  left join stock_content sc
                    on sc.enterprise_no = cdc.enterprise_no
                   and sc.warehouse_no = cdc.warehouse_no
                   and sc.cell_no = cdc.cell_no
                   and sc.article_no = strArticleNo
                 where cdc.enterprise_no = strEnterPriseNO
                   and cdc.warehouse_no = strWareHouseNo
                   and not exists
                 (select 'x'
                          from cset_cell_article cca
                         where cca.enterprise_no = sc.enterprise_no
                           and cca.warehouse_no = sc.warehouse_no
                           and cca.cell_no = sc.cell_no
                           and cca.article_no <> strArticleNo)
                   and cdc.cell_no like
                       decode(strOperateType,
                              'B',
                              strBPickCellNo,
                              decode(strCPickCellNo,
                                     'N',
                                     strBPickCellNo,
                                     strCPickCellNo)) || '%'
                 order by qty desc)
         where rownum <= 1;

        strDestCellNo := v_strTempPickCellNo;
        return;
    end;

    /*Modify BY QZH AT 2016-5-24
    strDestCellNo := v_strTempPickCellNo;
    return;*/

    begin
      select distinct cdc.ware_no,
                      cdc.area_no,
                      cdc.stock_no,
                      cdc.stock_x,
                      cdc.stock_y,
                      cdc.bay_x,
                      cad.merger_flag,
                      cad.stock_flag,
                      cad.floor_flag,
                      cad.stockx_flag,
                      cad.bay_flag,
                      cad.sort_flag,
                      cdc.cell_no,
                      cdc.max_qty
        into v_strWareNo, --拣货位所在库
             v_strAreaNo, --拣货位所在储区
             v_strStockNo, --拣货位所在通道（如果拣货位到区，下面几个字段没有参考意义）
             v_strStockX, --拣货位所在格
             v_strStockY, --拣货位所在层
             v_strBayX, --拣货位所在位
             v_nMergerFlag, --是否并入
             v_nStockFlag, --
             v_nFloorFlag, --
             v_nStockXFlag, --
             v_nBayFlag, --
             v_nSortFlag, --
             v_strPickCellNo, --拣货位储位
             v_nMaxQTY
        from cdef_defcell cdc
       inner join cdef_defarea cda
          on cda.enterprise_no = cdc.enterprise_no
         and cda.warehouse_no = cdc.warehouse_no
         and cda.ware_no = cdc.ware_no
         and cda.area_no = cdc.area_no
       inner join cset_area_backup_d cad
          on cad.enterprise_no = cdc.enterprise_no
         and cad.warehouse_no = cdc.warehouse_no
         and cad.line_id = nPickLine
         and cad.a_level = case
               when nSuppType in (0, 1) then
                0
               else
                nCurrSuppLevel
             end
       where cdc.enterprise_no = strEnterPriseNO
         and cdc.warehouse_no = strWareHouseNo
         and cdc.cell_no = v_strTempPickCellNo;

      v_nKeepCells := 0;
    exception
      when no_data_found then
        v_strWareNo := 'N';
    end;
    --注意：该函数必须全部做优化，目前只做管单的往拣货位上补
    if nSuppType in (0, 1) then

      if v_strWareNo <> 'N' then
        PKLG_ILOCATE.p_PickCellByPickLine(strEnterPriseNo,
                                          strWareHouseNo, --仓库代码
                                          strOwnerNo, --货主代码
                                          strArticleNo, --商品代码
                                          nArticleID,
                                          nPacking_Qty,
                                          v_strWareNo, --拣货位所在库
                                          v_strAreaNo, --拣货位所在储区
                                          v_strStockNo, --拣货位所在通道（如何拣货位到区，下面几个字段没有参考意义）
                                          v_strStockX, --拣货位所在格
                                          v_strStockY, --拣货位所在层
                                          v_strBayX, --拣货位所在位
                                          v_strPickCellNo, --拣货位储位
                                          nLocateQty, --定位数量
                                          --v_nMaxQTY,
                                          v_nKeepCells, --允许占用最大储位数
                                          v_nMergerFlag, --是否并入
                                          v_nStockFlag, --
                                          v_nFloorFlag, --
                                          v_nStockXFlag, --
                                          v_nBayFlag, --
                                          v_nSortFlag, --
                                          '1', --规则顺序
                                          strDestCellNo,
                                          strErrorMsg);
        if substr(strErrorMsg, 1, 1) = 'N' then
          strDestCellNo := 'N';
        end if;
      end if;

      if strDestCellNo = 'N' then
        begin
          select cdc.cell_no
            into strDestCellNo
            from cset_cell_article cca, cdef_defcell cdc
           where cca.enterprise_no = cdc.enterprise_no
             and cca.enterprise_no = strEnterPriseNO
             and cdc.warehouse_no = cca.warehouse_no
             and cdc.cell_no = cca.cell_no
             and cca.warehouse_no = strWareHouseNo
             and cca.article_no = strArticleNo
             and cca.pick_type = strOperateType;
        exception
          when no_data_found then
            strDestCellNo := v_strTempPickCellNo;
        end;
      end if;
    else

      if v_strWareNo <> 'N' then
        PKLG_ILOCATE.p_SaveCellByPickLine(strEnterPriseNo,
                                          strWareHouseNo, --仓库代码
                                          strOwnerNo, --货主代码
                                          strArticleNo, --商品代码
                                          nArticleID,
                                          nPacking_Qty,
                                          false,
                                          v_strWareNo, --拣货位所在库
                                          v_strAreaNo, --拣货位所在储区
                                          v_strStockNo, --拣货位所在通道（如何拣货位到区，下面几个字段没有参考意义）
                                          v_strStockX, --拣货位所在格
                                          v_strStockY, --拣货位所在层
                                          v_strBayX, --拣货位所在位
                                          v_strPickCellNo, --拣货位储位
                                          nLocateQty, --定位数量
                                          v_nKeepCells, --允许占用最大储位数
                                          v_nMergerFlag, --是否并入
                                          v_nStockFlag, --
                                          v_nFloorFlag, --
                                          v_nStockXFlag, --
                                          v_nBayFlag, --
                                          v_nSortFlag, --
                                          '1', --规则顺序
                                          strDestCellNo,
                                          strErrorMsg);
        if substr(strErrorMsg, 1, 1) = 'N' then
          strDestCellNo := 'N';
        end if;
      end if;
    end if;
  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_get_supp_cell;

  /*-----------------------------------------------
  设置储位商品补货次数
  ------------------------------------------------*/
  procedure p_set_cell_suppcount(strEnterpriseNo in odata_locate_m.enterprise_no%type,
                                 strWareHouseNo  in varchar2, --仓库代码
                                 strCellNo       in varchar2,
                                 strArticleNo    in varchar2, --商品代码
                                 strErrorMsg     out varchar2) is
  begin
    strErrorMsg := 'Y|';

    update cdef_defcell_suppcount cds
       set cds.SUPP_COUNT = cds.SUPP_COUNT + 1
     where cds.enterprise_no = strEnterPriseNO
       and cds.warehouse_no = strWareHouseNo
       and cds.cell_no = strCellNo
       and cds.article_no = strArticleNo;

    if sql%rowcount <= 0 then
      insert into cdef_defcell_suppcount
        (enterprise_no, warehouse_no, cell_no, article_no, supp_count)
      values
        (strEnterPriseNO, strWareHouseNo, strCellNo, strArticleNo, 1);
    end if;

  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_set_cell_suppcount;

  /*-----------------------------------------------
  安全量补货入口
  ------------------------------------------------*/
  procedure p_securitysupply_main(strEnterpriseNo in odata_locate_m.enterprise_no%type,
                                  strWareHouseNo  in varchar2, --仓库代码
                                  strOwnerNo      in varchar2,
                                  strPlanNo       in varchar2, --计划单号
                                  strWorkNo       in varchar2, --操作人员
                                  strErrorMsg     out varchar2) is
    v_strSDeFine    WMS_DEFBASE.Sdefine%type;
    v_strNDeFine    WMS_DEFBASE.Ndefine%type;
    --v_nPickCount    number(3);
    --v_nMaxQty       cset_cell_article.max_qty_a%type;
    --v_nKeepCell     cset_cell_article.keep_cells%type;
    v_nSupplyQty    number(12, 4);
    v_nPickStockQty number(12, 4);
    v_nRealSuppQty  number(12, 4);
    v_nSuppType     number(3);
    v_noSupplyQty   number(12, 4);
    v_noRealSuppQty number(12, 4);
  begin
    strErrorMsg := 'Y|';

    --读取策略
    --安全量判断补货计量:1:只补拣货位 2:补满拣货位和可用储位数
    PKLG_WMS_BASE.p_GetBasePara(strEnterpriseNo,
                                strWareHouseNo,
                                strOwnerNo,
                                'msupplytype',
                                'M',
                                'M_LOCATE',
                                v_strSDeFine,
                                v_strNDeFine,
                                strErrorMsg);
    if substr(strErrorMsg, 1, 1) = 'N' then
      strErrorMsg := 'N|[E30025]';
      return;
    end if;

    --获取补货的数量
    for getData in (select *
                      from mdata_locate_direct mld
                     where mld.warehouse_no = strWareHouseNo
                       and mld.enterprise_no = strEnterpriseNo
                       and mld.plan_no = strPlanNo
                       and mld.outstock_type = '3'
                       and mld.status = '10') loop
      --计算安全补货量
      for getSetca in (select cca.ware_no,
                              cca.area_no,
                              cca.stock_no,
                              cca.cell_no,
                              case
                                when cda.a_flag = '1' then
                                 cca.max_qty_a
                                else
                                 cca.max_qty_na
                              end max_qty,
                              case
                                when cda.a_flag = '1' then
                                 cca.alert_qty_a
                                else
                                 cca.alert_qty_na
                              end alert_qty,
                              case
                                when cda.a_flag = '1' then
                                 cca.keep_cells_a
                                else
                                 cca.keep_cells
                              end keep_cells,
                              cca.line_id,
                              cca.pick_type
                         from cdef_defarea cda, cset_cell_article cca
                        where cda.warehouse_no = cca.warehouse_no
                          and cda.enterprise_no = cca.enterprise_no
                          and cda.ware_no = cca.ware_no
                          and cda.area_no = cca.area_no
                          and cca.warehouse_no = strWareHouseNo
                          and cca.enterprise_no = strEnterpriseNo
                          and cca.article_no = getData.Article_No
                          and cca.cell_no=getData.d_Cell_No --Add BY QZH AT 2016-7-14
                          ) loop
        v_nSupplyQty    := 0;
        v_nSuppType     := 0;
        v_noRealSuppQty := 0;

        --如果只补拣货位 库存量大于补货警示量 下一条
        if v_strSDeFine = '1' then
          --查找当前储位库存
          begin
            select nvl(sum(sc.Qty + case
                             when sc.instock_type = '1' then
                              instock_qty
                             else
                              0
                           end),
                       0)
              into v_nPickStockQty
              from stock_content sc
             where sc.warehouse_no = strWareHouseNo
               and sc.enterprise_no = strEnterpriseNo
               and sc.cell_no = getSetca.Cell_No
               and sc.article_no = getData.Article_No
               and sc.flag <> 2;
          exception
            when no_data_found then
              v_nPickStockQty := 0;
          end;
          --拣货位库存
          if v_nPickStockQty > getSetca.alert_qty then
            goto next_row;
          else
            v_nSupplyQty := getSetca.Max_Qty - v_nPickStockQty;
          end if;
        end if;

        --补到拣货位和可用储位 计算补货量 =最大量*可用储位 -拣货区的库存量
        if v_strSDeFine = '2' then
          begin
            select nvl(sum(sc.qty + case
                             when sc.instock_type = '1' then
                              sc.instock_qty
                             else
                              0
                           end),
                       0)
              into v_nPickStockQty
              from cdef_defcell cdc
              left join stock_content sc
                on sc.warehouse_no = cdc.warehouse_no
               and sc.enterprise_no = cdc.enterprise_no
               and sc.cell_no = cdc.cell_no
               and sc.article_no = getData.Article_No
               and sc.flag <> 2, cdef_defarea cda, cset_cell_article cca
             where cda.warehouse_no = cdc.warehouse_no
               and cda.enterprise_no = cdc.enterprise_no
               and cdc.enterprise_no = cca.enterprise_no
               and cda.ware_no = cdc.ware_no
               and cda.area_no = cdc.area_no
               and cdc.warehouse_no = cca.warehouse_no
               and cdc.ware_no = cca.ware_no
               and cdc.area_no = cca.area_no
               and cca.warehouse_no = strWareHouseNo
               and cca.enterprise_no = strEnterpriseNo
               and cca.article_no = getData.Article_No
               and cca.pick_type = getSetca.Pick_Type;
          exception
            when no_data_found then
              v_nPickStockQty := 0;
          end;

          v_nSupplyQty := getSetca.Max_Qty * getSetca.Keep_Cells -
                          v_nPickStockQty;
          if v_nSupplyQty <= 0 then
            goto next_row;
          end if;

        end if;

        v_noSupplyQty := v_nSupplyQty;

        --查找库存
        --根据补货类型（0：保拣线补到拣货位；1：全仓补到拣货位；）
        loop

          P_SECURITYSUPPLY_ARTICLE(strEnterpriseNo, --企业编号
                                   strWareHouseNo, --仓库代码
                                   strOwnerNo,
                                   strPlanNo, --定位号
                                   getSetca.Pick_Type, --下架类型 C或者B
                                   '3', --出货类型 3:安全量补货
                                   getData.Source_Type, --来源类型 1:普通
                                   'N', --定位批次 默认为N
                                   getData.Article_No, --商品代码
                                   getData.Article_Id,
                                   v_nSupplyQty, --补货量
                                   v_nRealSuppQty, --定位量
                                   getData.Move_Date,
                                   v_nSuppType, --补货类型0：保拣线补到拣货位；1：全仓补到拣货位
                                   getSetca.Line_Id, --保拣线
                                   strWorkNo, --员工代码
                                   v_strSDeFine,
                                   getSetca.Cell_No,
                                   strErrorMsg);
          if substr(strErrorMsg, 1, 2) = 'N|' then
            return;
          end if;

          --如果补货完成退出
          v_noRealSuppQty := v_noRealSuppQty + v_nRealSuppQty;
          if v_noRealSuppQty >= v_noSupplyQty then
            exit;
          end if;

          --如果补不到货 也退出
          if v_nSuppType > 1 then
            exit;
          end if;
          v_nSuppType := v_nSuppType + 1;

        end loop;

        <<next_row>>
        null;
      end loop;

    end loop;

    --更新状态为13
    update mdata_locate_direct mld
       set status = '13'
     where mld.warehouse_no = strWareHouseNo
       and mld.plan_no = strPlanNo;

    update odata_outstock_direct ood
       set ood.status = '10'
     where ood.warehouse_no = strWareHouseNo
       and ood.wave_no = strPlanNo;

  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);

  end p_securitysupply_main;

  --商品补货定位
  procedure p_securitysupply_article(strEnterpriseNo in varchar2,
                                     strWareHouseNo  in varchar2, --仓库代码
                                     strOwnerNo      in varchar2,
                                     strPlanNo       in varchar2, --定位号
                                     strPickType     in varchar2, --下架类型 C或者B
                                     strOutstockType in varchar2, --出货类型 3:安全量补货
                                     strSourceType   in varchar2, --来源类型 1:普通
                                     strBatchNo      in varchar2, --定位批次 默认为N
                                     strArticleNo    in varchar2, --商品代码
                                     strArticleID    in varchar2,
                                     nNeedSuppQty    in number, --补货量
                                     nRealSuppQty    in out number, --定位量
                                     dtLocateDate    in date,
                                     nSuppType       in varchar2, --补货类型0：保拣线补到拣货位；1：全仓补到拣货位
                                     strLineID       in varchar2, --保拣线
                                     strWorkNo       in varchar2, --员工代码
                                     strSDeFine      in varchar2, --是否只补拣货位
                                     strPickCellNO   in varchar2, --拣货位
                                     strErrorMsg     out varchar2) is

    v_strCellWareNo  cdef_defcell.ware_no%type;
    --v_strCellAreaNo  cdef_defcell.area_no%type;
    --v_strCellStockNo cdef_defcell.stock_no%type;

    v_nCurrSuppQty   odata_outstock_direct.locate_qty%type;
    v_nSingleSuppQty odata_outstock_direct.locate_qty%type;
    v_nDirectSuppQty odata_outstock_direct.locate_qty%type;

    --v_nMinSuppQty  odata_outstock_direct.locate_qty%type;
    v_nNeedSuppQty odata_outstock_direct.locate_qty%type;

    --v_nCellMaxQty      cset_cell_article.max_qty_a%type;
    --v_nPickCellCMaxQty cset_cell_article.max_qty_a%type;
    --v_nCellKeeps       cset_cell_article.keep_cells%type;
    --v_strLine_ID       cset_cell_article.line_id%type;

    --v_nPickCount number(2); --拣货位个数

    --v_nSuppLevel     number(2); --当前补货级别
    v_nCurrSuppLevel number(2);

    v_strSQL varchar2(4096);

    v_nPalleteQty bdef_article_packing.qpalette%type;

    v_nSuppType number(1); --补货类型（0：保拣线补到拣货位；1：全仓补到拣货位；）

    --v_blExitFlag boolean;

    --v_blIgnoreFlag boolean;
    v_nProduceFlag number;
    --v_strAllCelln  wms_defbase.ndefine%type;
    --strAllCelln    wms_defbase.sdefine%type;
    strDestCellNo  cdef_defcell.cell_no%type;

    v_nExpiryDays BDEF_DEFARTICLE.Expiry_Days%type;
    v_strWareNo   CSET_CELL_ARTICLE.Ware_No%type;
    v_strAreaNo   CSET_CELL_ARTICLE.Area_No%type;
    v_AreaPick    CDEF_DEFAREA.AREA_PICK%TYPE; --是否拣货区
    v_strStockNo  cdef_defcell.Stock_No%type;
    v_strStockX   Cdef_Defcell.Stock_x%type;

    v_strSWareNo  CSET_CELL_ARTICLE.Ware_No%type;
    v_strSAreaNo  CSET_CELL_ARTICLE.Area_No%type;
    v_strSStockNo cdef_defcell.Stock_No%type;
    v_strSStockX  Cdef_Defcell.Stock_x%type;

    v_strLimitType       cdef_defarea.limit_type%type;
    v_nLimitRate         cdef_defarea.limit_rate%type;
    --blSameSKU            boolean := false; --相同SKU
    v_strStockY          Cdef_Defcell.Stock_y%type;
    v_strBayX            CDEF_DEFCELL.Bay_x%type;
    v_strPickCellNo      CDEF_DEFCELL.Cell_No%type;
    v_nMaxQty            CSET_CELL_ARTICLE.Max_Qty_a%type;
    v_nKeepCells         CSET_CELL_ARTICLE.Keep_Cells%type;
    v_nPickKeepCells     CSET_CELL_ARTICLE.Keep_Cells%type;
    v_nMergerFlag        CSET_AREA_BACKUP_D.MERGER_FLAG%type;
    v_nStockFlag         CSET_AREA_BACKUP_D.STOCK_FLAG%type;
    v_nFloorFlag         CSET_AREA_BACKUP_D.FLOOR_FLAG%type;
    v_nStockXFlag        CSET_AREA_BACKUP_D.STOCKX_FLAG%type;
    v_nBayFlag           CSET_AREA_BACKUP_D.BAY_FLAG%type;
    v_nSortFlag          CSET_AREA_BACKUP_D.SORT_FLAG%type;
    v_cs_get_area_backup cv_type;
    v_ArticlePal         bdef_article_packing.packing_qty%type;

    v_strCPickCellNo cset_cell_article.cell_no%type;
    v_nCMaxQty       cset_cell_article.max_qty_a%type;
    v_nCKeepCells    cset_cell_article.keep_cells%type;
    v_strBPickCellNo cset_cell_article.cell_no%type;
    v_nBMaxQty       cset_cell_article.max_qty_a%type;
    v_nBKeepCells    cset_cell_article.keep_cells%type;
    v_nPickLine      cset_cell_article.line_id%type;
    v_nPickCellCount number;

  begin
    strErrorMsg := 'Y|';

    --预留
    PKLG_PUBLOCATE.p_get_PickCell(strEnterPriseNo,
                                  strWareHouseNo,
                                  strOwnerNo,
                                  strArticleNo,
                                  v_strCPickCellNo,
                                  v_nCMaxQty,
                                  v_nCKeepCells,
                                  v_strBPickCellNo,
                                  v_nBMaxQty,
                                  v_nBKeepCells,
                                  v_nPickLine,
                                  v_nPickCellCount,
                                  strErrorMsg);

    if substr(strErrorMsg, 1, 1) = 'N' then
      return;
    end if;

    v_nProduceFlag := 0;

    --预留

    v_nNeedSuppQty  := nNeedSuppQty;
    v_strCellWareNo := 'Y';
    nRealSuppQty    := 0;

    --补货类型（0：保拣线补到拣货位；1：全仓补到拣货位；）
    v_nSuppType := nSuppType;

    v_nCurrSuppQty   := v_nNeedSuppQty;
    v_nCurrSuppLevel := case
                          when strPickType = 'B' then
                           '0'
                          else
                           '1'
                        end;

    for v_cs_stock in (SELECT t.*
                         FROM (SELECT S.WAREHOUSE_NO,
                                      S.OWNER_NO,
                                      S.CELL_NO,
                                      S.ARTICLE_NO,
                                      S.DEPT_NO,
                                      S.LABEL_NO,
                                      CDA.WARE_NO,
                                      CDA.AREA_NO,
                                      CDA.LIMIT_RATE,
                                      CDA.LIMIT_TYPE,
                                      CDA.PAL_OUT_RATE,
                                      CDA.ADVANCER_PICK_FLAG,
                                      S.PACKING_QTY,
                                      S.QUALITY,
                                      S.S_QTY,
                                      S.S_INSTOCK_QTY,
                                      S.S_OUTSTOCK_QTY,
                                      s.flag,
                                      BDA.EXPIRY_DAYS,
                                      CDA.O_TYPE,
                                      CDA.AREA_PICK,
                                      CDA.AREA_USETYPE,
                                      CDA.DIVIDE_FLAG,
                                      CDA.B_DIVIDE_FLAG,
                                      s.LOT_NO,
                                      --S.SUPPLIER_NO,
                                      CDA.AREA_TYPE,
                                      CDC.PICK_FLAG,
                                      CDC.MAX_QTY,
                                      case
                                        when v_strCellWareNo <> 'N' then --如果有保拣线
                                         NVL((SELECT CAB.A_LEVEL
                                               FROM CSET_AREA_BACKUP_D CAB
                                              WHERE CAB.WAREHOUSE_NO =
                                                    CDC.WAREHOUSE_NO
                                                and cab.enterprise_no =
                                                    cdc.enterprise_no
                                                AND CAB.WARE_NO = CDC.WARE_NO
                                                AND CAB.AREA_NO = (CASE
                                                      WHEN CAB.AREA_NO = 'N' then
                                                       'N'
                                                      else
                                                       CDC.AREA_NO
                                                    END)
                                                AND CAB.STOCK_NO = (CASE
                                                      WHEN CAB.STOCK_NO = 'N' then
                                                       'N'
                                                      else
                                                       CDC.STOCK_NO
                                                    END)
                                                AND CAB.Line_ID = strLineID
                                             /*AND CAB.WARE_NO =
                                                 v_strCellWareNo
                                             AND CAB.AREA_NO =
                                                 v_strCellAreaNo
                                             AND CAB.STOCK_NO =
                                                 (CASE WHEN
                                                  CAB.STOCK_NO = 'N' then 'N' else
                                                  v_strCellStockNo END)*/
                                             ),
                                             DECODE(CDA.O_TYPE,
                                                    'P',
                                                    2,
                                                    'C',
                                                    3,
                                                    'B',
                                                    4) * -1)
                                        else
                                         DECODE(CDA.O_TYPE,
                                                'P',
                                                2,
                                                'C',
                                                3,
                                                'B',
                                                4) * -1
                                      end SORT_LEVEL,
                                      CASE
                                        WHEN CDA.AREA_TYPE = '1' THEN
                                         CDC.STOCK_X
                                        ELSE
                                         '1'
                                      END SORT_CELL,
                                      nvl(baw.qpalette, BAP.QPALETTE) AS PALLETE_QTY,
                                      s.produce_date,
                                      S.SORT_DATE,
                                      S.SORT_BATCH,
                                      S.SORT_FLAG,
                                      s.min_expire_date,
                                      S.S_CAN_USE_QTY,
                                      s.stock_type,
                                      s.stock_value
                                 FROM BDEF_DEFARTICLE BDA,
                                      (select C.WAREHOUSE_NO,
                                              c.enterprise_no,
                                              C.OWNER_NO,
                                              C.DEPT_NO,
                                              C.CELL_NO,
                                              C.LABEL_NO,
                                              C.ARTICLE_NO,
                                              C.PACKING_QTY,
                                              a.QUALITY,
                                              a.LOT_NO,
                                              c.stock_type,
                                              c.stock_value,
                                              --a.SUPPLIER_NO,
                                              max(c.flag) flag,
                                              min(a.PRODUCE_DATE) as produce_date,
                                              --MIN(TRUNC(a.PRODUCE_DATE)) SORT_DATE,
                                              case
                                                when min(b.turn_over_rule) =
                                                     'LIFO' then
                                                 MAX(TRUNC(a.PRODUCE_DATE))
                                                else
                                                 case
                                                   when min(b.turn_over_rule) =
                                                        'FEFO' then
                                                    MIN(TRUNC(a.expire_date))
                                                   else
                                                    MIN(TRUNC(a.PRODUCE_DATE))
                                                 end
                                              end as SORT_DATE,
                                              MIN(TRUNC(a.expire_date)) min_expire_date,
                                              MIN(SUBSTR(a.IMPORT_BATCH_NO,
                                                         2,
                                                         20)) SORT_BATCH,
                                              MAX(C.FLAG) AS SORT_FLAG,
                                              sum(C.QTY - C.OUTSTOCK_QTY +
                                                  (case C.Instock_Type
                                                    when '1' then
                                                     C.INSTOCK_QTY
                                                    else
                                                     0
                                                  end) + C.UNUSUAL_QTY) AS S_QTY,
                                              SUM(case C.Instock_Type
                                                    when '1' then
                                                     C.INSTOCK_QTY
                                                    else
                                                     0
                                                  end) AS S_INSTOCK_QTY,
                                              SUM(C.OUTSTOCK_QTY) AS S_OUTSTOCK_QTY,
                                              SUM(case
                                                    when (C.QTY - C.OUTSTOCK_QTY +
                                                         C.UNUSUAL_QTY) > 0 then
                                                     (C.QTY - C.OUTSTOCK_QTY +
                                                     C.UNUSUAL_QTY)
                                                    else
                                                     0
                                                  end) as S_CAN_USE_QTY
                                         FROM BDEF_DEFARTICLE    B,
                                              STOCK_CONTENT      C,
                                              STOCK_article_info a
                                        WHERE B.OWNER_NO = C.OWNER_NO
                                          and b.enterprise_no =
                                              c.enterprise_no
                                          and a.enterprise_no =
                                              c.enterprise_no
                                          AND B.ARTICLE_NO = C.ARTICLE_NO
                                          and a.article_no = c.article_no
                                          and a.article_id = c.article_id
                                          AND c.WAREHOUSE_NO = strWareHouseNo
                                          and c.enterprise_no =
                                              strEnterpriseNo
                                          AND a.ARTICLE_NO = strArticleNo
                                          AND C.STATUS = 0
                                             --条件
                                             -- AND C.HM_MANUAL_FLAG = ''
                                          AND C.FLAG <> '2'
                                          AND (C.INSTOCK_QTY + C.QTY -
                                              C.OUTSTOCK_QTY + C.UNUSUAL_QTY) > 0
                                        GROUP BY c.enterprise_no,
                                                 C.WAREHOUSE_NO,
                                                 C.OWNER_NO,
                                                 C.DEPT_NO,
                                                 C.CELL_NO,
                                                 C.LABEL_NO,
                                                 C.ARTICLE_NO,
                                                 C.PACKING_QTY,
                                                 a.QUALITY,
                                                 a.LOT_NO,
                                                 c.stock_type,
                                                 c.stock_value,
                                                 --预留，严格按生产日期出货此处需要修改
                                                 (case
                                                   when 1 = 0 then
                                                    a.produce_date
                                                 end)
                                        order by s_qty desc) S,
                                      --CDEF_DEFSTOCK CDS,
                                      CDEF_DEFAREA         CDA,
                                      CDEF_DEFCELL         CDC,
                                      BDEF_ARTICLE_PACKING BAP
                                 left join bdef_warehouse_packing baw
                                   on baw.warehouse_no = strWareHouseNo
                                  and baw.enterprise_no = strEnterpriseNo
                                  and baw.article_no = bap.article_no
                                  and baw.packing_qty = bap.packing_qty
                                WHERE CDA.WAREHOUSE_NO = CDC.WAREHOUSE_NO
                                  and cda.enterprise_no = cdc.enterprise_no
                                  and bda.enterprise_no = cdc.enterprise_no
                                  and bap.enterprise_no = cdc.enterprise_no
                                  AND CDA.WARE_NO = CDC.WARE_NO
                                  AND CDA.AREA_NO = CDC.AREA_NO
                                  AND CDA.AREA_ATTRIBUTE = '0'
                                     --AND CDS.WAREHOUSE_NO = CDC.WAREHOUSE_NO
                                     --AND CDS.WARE_NO = CDC.WARE_NO
                                     --AND CDS.AREA_NO = CDC.AREA_NO
                                     --AND CDS.STOCK_NO = CDC.STOCK_NO
                                  AND CDC.WAREHOUSE_NO = s.WAREHOUSE_NO
                                  and cdc.enterprise_no = s.enterprise_no
                                  AND CDC.CELL_NO = s.CELL_NO
                                  AND BAP.ARTICLE_NO = s.ARTICLE_NO
                                  AND BAP.PACKING_QTY = s.PACKING_QTY
                                  AND BDA.ARTICLE_NO = s.ARTICLE_NO
                                  AND CDC.CHECK_STATUS = '0') t
                       --补货类型（0：保拣线补到拣货位；1：全仓补到拣货位）
                        where ((v_nSuppType in (0) and t.SORT_LEVEL >= 0) or
                              (v_nSuppType in (1) and t.SORT_LEVEL < 0))
                          and s_qty > 0
                        ORDER BY (case
                                   when t.AREA_USETYPE = 1 then
                                    0
                                   else
                                    1
                                 end),
                                 (case
                                   when t.flag = '3' then
                                    0
                                   else
                                    1
                                 end),
                                 t.sort_level,
                                 (case
                                   when t.S_CAN_USE_QTY <> 0 then
                                    0
                                   else
                                    1
                                 end),
                                 t.SORT_DATE,
                                 t.S_CAN_USE_QTY,
                                 t.S_QTY,
                                 t.SORT_CELL,
                                 t.SORT_DATE,
                                 t.SORT_BATCH,
                                 t.LOT_NO,
                                 t.QUALITY,
                                 t.PACKING_QTY) loop
      --定位完成，退出
      if v_nCurrSuppQty <= 0 then
        exit;
      end if;

      v_nPalleteQty := v_cs_stock.PALLETE_QTY;

      --相同级别不做补货
      if v_cs_stock.SORT_LEVEL = 0 then
        goto next_cs_stock;
      end if;

      --当前区域的下架类型与补货类型相同，并且是补到拣货位，不做补货
      if strPickType = v_cs_stock.o_type and v_nSuppType in (0, 1) and
         --Modify BY QZH AT 2016-7-14 v_cs_stock.PICK_FLAG = 1 then
         v_cs_stock.area_pick = 1 then
        goto next_cs_stock;
      end if;

      --零出区不往箱区补
      if strPickType = 'C' and v_cs_stock.o_type = 'B' then
        goto next_cs_stock;
      end if;

      --箱型补货，流理架、轻型货架、混合型区、混合拣货区不做补货
      if strPickType = 'C' and v_cs_stock.AREA_TYPE in ('4', '5', '6', '8') then
        goto next_cs_stock;
      end if;

      v_nSingleSuppQty := v_cs_stock.s_qty;
      --取商品堆叠
      begin
        SELECT NVL(bwp.qpalette, bap.qpalette) qpalette
          into v_ArticlePal
          FROM bdef_article_packing bap,
               (select *
                  from bdef_warehouse_packing bw
                 where bw.warehouse_no = strWareHouseNo
                   and bw.enterprise_no = strEnterpriseNo) bwp
         where bap.article_no = bwp.ARTICLE_NO(+)
           AND bap.packing_qty = bwp.packing_qty(+)
           and bap.enterprise_no = bwp.enterprise_no(+)
           and bap.article_no = strArticleNo
           and bap.packing_qty = v_cs_stock.packing_qty;
      exception
        when no_data_found then
          goto next_cs_stock;
      end;

      if v_nSingleSuppQty > v_nCurrSuppQty then
        if v_nCurrSuppQty > v_ArticlePal then
          v_nSingleSuppQty := floor(v_nCurrSuppQty / v_ArticlePal) *
                              v_ArticlePal;
        else
          v_nSingleSuppQty := 0;
        end if;
      end if;

      if v_nSingleSuppQty <= 0 then
        goto next_cs_stock;
      end if;

      --如果补足可用储位才查找 否则补到拣货位
      if strSDeFine = '2' then

        --查找拣货位信息
        v_strSQL := pklg_ilocate.f_get_PickLine(strEnterpriseNo,
                                                strWareHouseNo,
                                                strOwnerNo,
                                                strArticleNo,
                                                strPickCellNO,
                                                v_nPickLine,
                                                '1');

        open v_cs_get_area_backup for v_strSQL;
        loop
          fetch v_cs_get_area_backup
            into v_nExpiryDays,
                 v_strWareNo,
                 v_strAreaNo,
                 v_AreaPick,
                 v_strStockNo,
                 v_strStockX,
                 v_strStockY,
                 v_strBayX,
                 v_strPickCellNo,
                 v_strSWareNo,
                 v_strSAreaNo,
                 v_strSStockNo,
                 v_strSStockX,
                 v_nKeepCells,
                 v_strLimitType,
                 v_nLimitRate,
                 v_nMaxQty,
                 v_nPickKeepCells,
                 v_nMergerFlag,
                 v_nStockFlag,
                 v_nFloorFlag,
                 v_nStockXFlag,
                 v_nBayFlag,
                 v_nSortFlag;
          EXIT WHEN v_cs_get_area_backup%NOTFOUND;

          --查找可放入的储位
          pklg_ilocate.p_PickCellByPickLine(strEnterpriseNo,
                                            strWareHouseNo,
                                            strOwnerNo,
                                            strArticleNo,
                                            strArticleID,
                                            v_cs_stock.Packing_Qty,
                                            v_strWareNo,
                                            v_strAreaNo,
                                            v_strStockNo,
                                            --v_strStockNo,
                                            v_strStockX,
                                            v_strStockY,
                                            v_strBayX,
                                            v_strPickCellNo,
                                            v_nSingleSuppQty,
                                            --v_nMaxQty,
                                            v_nKeepCells,
                                            v_nMergerFlag,
                                            v_nStockFlag,
                                            v_nFloorFlag,
                                            v_nStockXFlag,
                                            v_nBayFlag,
                                            v_nSortFlag,
                                            '1',
                                            strDestCellNo,
                                            strErrorMsg);
          if substr(strErrorMsg, 1, 2) = 'N|' then
            goto next_v_cs_get_area_backup;
          end if;

          if strDestCellNo <> 'N' then
            exit;
          end if;

          <<next_v_cs_get_area_backup>>
          null;
        end loop;

        close v_cs_get_area_backup;
      else
        strDestCellNo := strPickCellNO;
      end if;

      --写下架指示
      if strDestCellNo = 'N' or strDestCellNo is null then
        goto next_cs_stock;
      end if;

      v_nDirectSuppQty := 0;
      p_securitywrite_direct(strEnterpriseNo,
                             strWareHouseNo, --仓库代码
                             strOwnerNo,
                             strPlanNo, --定位号
                             strOutstockType, --出货类型
                             strSourceType, --来源类型
                             strPickType, --定位类型
                             strBatchNo, --定位批次
                             v_nSuppType, --补货类型
                             v_nCurrSuppLevel, --补货级别
                             '10',
                             '100',
                             dtLocateDate,
                             strArticleNo, --商品代码
                             v_cs_stock.Cell_No,
                             strDestCellNo,
                             v_cs_stock.Dept_No,
                             v_cs_stock.LABEL_NO,
                             v_cs_stock.Packing_Qty,
                             v_nProduceFlag,
                             v_cs_stock.Produce_Date,
                             v_cs_stock.Quality, --商品品质
                             v_cs_stock.Lot_No,
                             v_cs_stock.stock_type, --库存性质
                             v_cs_stock.stock_value, --库存值
                             v_nSingleSuppQty, --定位量
                             v_nDirectSuppQty,
                             strWorkNo, --员工代码
                             strErrorMsg);
      if substr(strErrorMsg, 1, 2) = 'N|' then
        return;
      end if;
      --可能因为补货目的储位设置问题，造成补货不成功
      if v_nDirectSuppQty <= 0 then
        exit;
      end if;

      nRealSuppQty   := nRealSuppQty + v_nDirectSuppQty;
      v_nNeedSuppQty := v_nNeedSuppQty - v_nDirectSuppQty;
      v_nCurrSuppQty := v_nCurrSuppQty - v_nDirectSuppQty;

      <<next_cs_stock>>
      null;

    end loop;

  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
  end P_SECURITYSUPPLY_ARTICLE;

  /*-----------------------------------------------
  安全量补货写定位指示
  ------------------------------------------------*/
  procedure p_securitywrite_direct(strEnterpriseNo in varchar2,
                                   strWareHouseNo  in varchar2, --仓库代码
                                   strOwnerNo      in varchar2,
                                   strSourceNo     in varchar2, --定位号
                                   strOutstockType in varchar2, --出货类型
                                   strSourceType   in varchar2, --来源类型
                                   strOperateType  in varchar2, --定位类型
                                   strBatchNo      in varchar2, --定位批次
                                   nSuppType       in number, --补货类型
                                   nCurrSuppLevel  in number, --补货级别
                                   strStatus       in varchar2,
                                   strPrioity      in varchar2,
                                   dtLocateData    in date,
                                   strArticleNo    in varchar2, --商品代码
                                   strCellNo       in varchar2,
                                   strDestCellNo   in varchar2,
                                   strDeptNo       in varchar2,
                                   strContainerNo  in varchar2,
                                   nPacking_Qty    in number,
                                   nProduceFlag    in number,
                                   dtProduceDate   in date,
                                   strQuality      in varchar2, --商品品质
                                   strLotNo        in varchar2, --批号
                                   strStockType    in varchar2, --库存性质
                                   strStockValue   in varchar2, --库存值
                                   nLocateQty      in number, --定位量
                                   nRealLocateQty  in out number,
                                   strWorkNo       in varchar2, --员工代码
                                   strErrorMsg     out varchar2) is
    v_nStockAllotQty  stock_content.qty%type;
    v_nDirectTotalQty stock_content.qty%type;

    v_nDestCellID stock_content.cell_id%type;

    v_strStatus odata_outstock_direct.status%type;

    v_strDestCellNo cdef_defcell.cell_no%type;
    v_strExpType    odata_locate_m.exp_type%type;
  begin
    strErrorMsg := 'Y|';

    v_nDirectTotalQty := nLocateQty;
    v_strDestCellNo   := strDestCellNo;

    v_strExpType := 'N';

    p_set_cell_suppcount(strEnterpriseNo,
                         strWareHouseNo,
                         v_strDestCellNo,
                         strArticleNo,
                         strErrorMsg);
    if substr(strErrorMsg, 1, 2) = 'N|' then
      return;
    end if;

    for v_cs_stock in (select *
                         from (select sc.*,
                                      sc.QTY - sc.OUTSTOCK_QTY as use_qty
                                 from stock_content      sc,
                                      stock_article_info sai
                                where sc.article_no = sai.article_no
                                  and sc.article_id = sai.article_id
                                  and sc.enterprise_no = sai.enterprise_no
                                  and sc.enterprise_no = strEnterpriseNo
                                  and sc.warehouse_no = strWareHouseNo
                                  and sc.dept_no = strDeptNo
                                  and sc.cell_no = strCellNo
                                  and sc.packing_qty = nPacking_Qty
                                  and sc.stock_type = strStockType
                                  and sc.stock_value = strStockValue
                                  and sai.article_no = strArticleNo
                                  and sai.lot_no = strLotNo
                                  and (nProduceFlag = 0 or
                                      (nProduceFlag = 1 and
                                      sai.produce_date = dtProduceDate))
                                  and sai.quality = strQuality
                                  and sc.QTY - sc.OUTSTOCK_QTY +
                                      sc.INSTOCK_QTY + sC.UNUSUAL_QTY > 0)
                        where use_qty > 0) loop

      if v_nDirectTotalQty <= 0 then
        exit;
      end if;

      v_nStockAllotQty := v_cs_stock.use_qty;
      if v_nStockAllotQty > v_nDirectTotalQty then
        v_nStockAllotQty := v_nDirectTotalQty;
      end if;

      v_nDirectTotalQty := v_nDirectTotalQty - v_nStockAllotQty;
      nRealLocateQty    := nRealLocateQty + v_nStockAllotQty;

      --写库存
      PKOBJ_STOCK.p_UpdtContent_Reservation(strEnterpriseNo,
                                            strWareHouseNo,
                                            v_cs_stock.cell_no,
                                            v_cs_stock.cell_id,
                                            v_strDestCellNo,
                                            'N',
                                            'N',
                                            v_nStockAllotQty,
                                            '1', --补货预上
                                            strWorkNo,
                                            v_nDestCellID,
                                            strErrorMsg);
      if substr(strErrorMsg, 1, 2) = 'N|' then
        return;
      end if;

      --写指示
      insert into odata_outstock_direct
        (warehouse_no,
         OUTSTOCK_TYPE,
         SOURCE_TYPE,
         OPERATE_TYPE,
         PICK_TYPE,
         owner_no,
         batch_no,
         operate_date,
         cust_no,
         sub_cust_no,
         article_no,
         article_id,
         STOCK_TYPE,
         packing_qty,
         LOCATE_QTY,
         s_cell_no,
         s_cell_id,
         D_CELL_NO,
         D_CELL_ID,
         LABEL_NO,
         exp_type,
         exp_no,
         wave_no,
         deliver_area,
         status,
         TEMP_STATUS,
         line_no,
         PRIORITY,
         deliver_obj,
         exp_date,
         SUPP_COUNT,
         rgst_name,
         rgst_date,
         updt_name,
         updt_date,
         enterprise_no)
        select strWareHouseNo,
               strOutstockType,
               strSourceType,
               'C', --strOperateType,共速达采用C型补货，暂时写死
               '0',
               strOwnerNo,
               strBatchNo,
               trunc(dtLocateData),
               'N',
               'N',
               v_cs_stock.article_no,
               v_cs_stock.article_id,
               v_cs_stock.STOCK_TYPE,
               nPacking_Qty,
               v_nStockAllotQty,
               v_cs_stock.cell_no,
               v_cs_stock.cell_id,
               v_strDestCellNo,
               v_nDestCellID,
               v_cs_stock.label_no,
               v_strExpType,
               strSourceNo,
               -- 'N',
               -- 'N',
               strSourceNo,
               'N', --此部分预留
               'N',
               v_strStatus,
               'N',
               strPrioity,
               'N',
               trunc(dtLocateData),
               SUPP_COUNT,
               strWorkNo,
               sysdate,
               strWorkNo,
               sysdate,
               strEnterpriseNo
          from cdef_defcell_suppcount
         where warehouse_no = strWareHouseNo
           and enterprise_no = strEnterpriseNo
           and cell_no = v_strDestCellNo
           and article_no = strArticleNo;

      if sql%rowcount <= 0 then
        strErrorMsg := 'N|[E3201905]';
        return;
      end if;

    end loop;

  exception
    when others then
      strErrorMsg := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);
  end p_securitywrite_direct;

end PKLG_MLOCATE;

/

