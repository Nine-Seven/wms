create view V_ODATA_OUTSTOCK_M as
select warehouse_no,outstock_no,operate_date,outstock_type,batch_no,operate_type,pick_type,
task_type,status,priority,dock_no,handin_date,handout_date,handin_name,handout_name,
print_status,exp_date,source_type,rgst_name,rgst_date,updt_name,updt_date,owner_no
from ODATA_OUTSTOCK_M
union all
select warehouse_no,outstock_no,operate_date,outstock_type,batch_no,operate_type,pick_type,
task_type,status,priority,dock_no,handin_date,handout_date,handin_name,handout_name,
print_status,exp_date,source_type,rgst_name,rgst_date,updt_name,updt_date,owner_no
from ODATA_OUTSTOCK_MHTY

/

