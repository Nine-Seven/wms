create view V_SEARCH_9120_002 as
SELECT SKUZS,CYSKU ,(SKUZS-CYSKU) / DECODE(SKUZS,0 ,1) * 100 || '%' CWPDFHL
--财务盘点符合率（KPI2）标准值为100%
--财务盘点符合率=（当前仓库存储所有SKU数–有差异SKU数）/（当前仓库存储所有SKU数）*100%
FROM ( SELECT
(SELECT COUNT(DISTINCT c.article_no) FROM fcdata_different_d c ) SKUZS,
(SELECT COUNT(DISTINCT c.article_no) FROM fcdata_different_d c WHERE c.article_qty <> c.real_qty) CYSKU
 FROM dual)

/

