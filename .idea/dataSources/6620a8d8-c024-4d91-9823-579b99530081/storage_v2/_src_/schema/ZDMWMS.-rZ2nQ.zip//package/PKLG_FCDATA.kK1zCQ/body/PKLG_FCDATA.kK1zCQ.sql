create package body PKLG_FCDATA is

/**********************************************************************************************************
   luozhiling
   2013.11.16
   功能：按盘点计划成需求,并对需求单进行定位
***********************************************************************************************************/
    procedure P_Fcdata_RequestLocate(strEnterPriseNo        in    fcdata_plan_m.enterprise_no%type,
                                  strWareHouseNo            in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_plan_m.owner_no%type,--若多货主同时盘点，则为N
                                  strUserId               in    fcdata_plan_m.rgst_name%type,
                                  strPlanNo               in   fcdata_plan_m.plan_no%type,--盘点计划单号
                                  strRequstNo             OUT  fcdata_request_m.request_no%type,--盘点需求单号
                                  strResult               OUT    varchar2)is
     begin
      strResult := 'N|[P_Fcdata_PlanHead]';

      --成需求单
      P_Fcdata_RequestDirect(strEnterPriseNo,strWareHouseNo,strOwnerNo,strUserId,strPlanNo,strRequstNo,strResult);
      if substr(strResult,1,1)='N' then
         return;
      end if;
      strResult:='Y';
    end P_Fcdata_RequestLocate;
 /*******************************************************************************************************************
  功能说明：
  1、按需求单定位；
  2、盘点切单；
 ******************************************************************************************************************/
    procedure P_LocateDirectAndCutTask(strEnterPriseNo         in    fcdata_plan_m.enterprise_no%type,
                                  strWareHouseNo            in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_plan_m.owner_no%type,
                                  strUserId               in    fcdata_plan_m.rgst_name%type,
                                  strRequstNo             IN   fcdata_request_m.request_no%type,--移库计划头档
                                  dtBEGIN_DATE            in   fcdata_plan_m.BEGIN_DATE%type,
                                  dtEND_DATE              in   fcdata_plan_m.END_DATE%type,
                                  strCutFlag              in   fcdata_check_m.fcdata_type%type,--1:按通道；2：按通道+层
                                  strResult               OUT    varchar2)is
      v_iCount                    integer;
   begin
      strResult:='N|[P_LocateDirectAndCutTask]';

      update fcdata_plan_m t set t.begin_date=dtBEGIN_DATE,t.end_date=dtEND_DATE
      where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo
      and t.plan_no in(select plan_no from fcdata_request_m frm where frm.enterprise_no=strEnterPriseNo
      and frm.warehouse_no=strWareHouseNo and frm.request_no=strRequstNo and frm.owner_no=strOwnerNo);


      P_Fcdata_LocateDirect(strEnterPriseNo,strWareHouseNo,strOwnerNo,strUserId,strRequstNo,dtBEGIN_DATE,dtEND_DATE,strResult);
      if substr(strResult,1,1)='N' then
          return;
      end if;

      --判断是否有定到位
      select count(*) into v_iCount
      from fcdata_check_direct a
      where a.enterprise_no=strEnterPriseNo
        and a.warehouse_no=strWareHouseNo
        and a.request_no=strRequstNo;

      if v_iCount<=0 then
        strResult:='N|['|| strRequstNo || '没有要盘点的数据 ]';
        return;
      end if;

      P_GetTask(strEnterPriseNo,strWareHouseNo,strOwnerNo,strUserId,strUserId,strRequstNo,strCutFlag,'U',strResult);
      if substr(strResult,1,1)='N' then
          return;
      end if;
      strResult:='Y|[成功]';
   end P_LocateDirectAndCutTask;
/**********************************************************************************************************
   MM
   2014.4.17
   功能：按需求单写盘点定位指示
***********************************************************************************************************/

    procedure P_Fcdata_LocateDirect(strEnterPriseNo         in    fcdata_plan_m.enterprise_no%type,
                                  strWareHouseNo            in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo              in    fcdata_plan_m.owner_no%type,
                                  strUserId               in    fcdata_plan_m.rgst_name%type,
                                  strRequstNo             IN   fcdata_request_m.request_no%type,--移库计划头档
                                  dtBEGIN_DATE            in   fcdata_plan_m.BEGIN_DATE%type,
                                  dtEND_DATE              in   fcdata_plan_m.END_DATE%type,
                                  strResult               OUT    varchar2)is
         v_strPlanType            fcdata_request_m.plan_type%type;
         v_strPlanNo              fcdata_request_m.plan_no%type;
         dtRequestDate            fcdata_request_m.request_date%type;
         v_strFCDATA_TYPE         fcdata_plan_m.FCDATA_TYPE%type ;
         StrFIXEDCELLFLAG         bdef_defowner.FIXEDCELL_FLAG%type ;
         strAllCells              WMS_DEFBASE.sdefine%type ;
         strAllCelln              WMS_DEFBASE.ndefine%type ;

         strVIRCellarts           WMS_DEFBASE.sdefine%type ;
         strVIRCellartn           WMS_DEFBASE.ndefine%type ;

         strFullCellarts          WMS_DEFBASE.sdefine%type ;
         strFullCellartn          WMS_DEFBASE.ndefine%type ;

         stroutstockCells         WMS_DEFBASE.sdefine%type ;
         stroutstockCelln         WMS_DEFBASE.ndefine%type ;
         strinstockCells          WMS_DEFBASE.sdefine%type ;
         strinstockCelln          WMS_DEFBASE.ndefine%type ;
         v_strCellCheckType       wms_defbase.sdefine%type;
         v_nCellCheckType         wms_defbase.ndefine%type;

    begin
      strResult := 'N|[P_Fcdata_LocateDirect]';

      begin
          select fpm.plan_type,fpm.plan_no,fpm.request_date into v_strPlanType,v_strPlanNo,dtRequestDate--1：储位盘；0：商品盘
          from fcdata_request_m fpm where fpm.warehouse_no=strWareHouseNo  and fpm.owner_no=strOwnerNo
                 and fpm.enterprise_no=strEnterPriseNo
                 and fpm.request_no=strRequstNo and fpm.status='10';
      exception when no_data_found then
          strResult:='N|[E30008]';
          return;
      end;


      begin
          --FCDATA_TYPE:1、盘点（指大盘）2、循环盘（储位检查）；3、动销盘（储位检查）
          select fpm.FCDATA_TYPE  into v_strFCDATA_TYPE
          from fcdata_plan_m fpm
          where fpm.warehouse_no=strWareHouseNo  and fpm.owner_no=strOwnerNo and fpm.enterprise_no=strEnterPriseNo
                 and fpm.plan_no=v_strPlanNo;
      exception when no_data_found then
          strResult:='N|[E30006]';
          return;
      end;

      if v_strFCDATA_TYPE='2' or v_strFCDATA_TYPE='3' then --如果是储位检查需要确定定位只 确定储位还是需要抓取库存

          --读取
          PKLG_WMS_BASE.p_GetBasePara(strEnterPriseNo,strWareHouseNo,strOwnerNo,'CellCheckType',
                'FC','FC_LOCATE',v_strCellCheckType,v_nCellCheckType,strResult);
          if substr(strResult,1,1)='N' then
                 strResult:='N|[E30025]';
                 return;
          end if;
      end if;

      --货主是否绑定固定储位 0：不绑定固定储位；1：绑定固定储位；
      begin
             select FIXEDCELL_FLAG into StrFIXEDCELLFLAG from bdef_defowner where owner_no=strOwnerNo and enterprise_no=strEnterPriseNo;
      exception when no_data_found then
          StrFIXEDCELLFLAG :='0';
      end;

      --读取货主策略
      PKLG_WMS_BASE.p_GetBasePara(strEnterPriseNo,strWareHouseNo,strOwnerNo,'FCR_AllCell','FC','FCR',strAllCells,strAllCelln,strResult);
      if substr(strResult,1,1)='N' then
             strResult:='N|[E30025]';
             return;
      end if;


      --读取商品策略

      if v_strPlanType='0' then
          PKLG_WMS_BASE.p_GetBasePara(strEnterPriseNo,strWareHouseNo,strOwnerNo,'FCL_FullCell','FC','FCL',strFullCellarts,strFullCellartn,strResult);
          if substr(strResult,1,1)='N' then
                 strResult:='N|[E30025]';
                 return;
          end if;

          PKLG_WMS_BASE.p_GetBasePara(strEnterPriseNo,strWareHouseNo,strOwnerNo,'FCL_VIRCell','FC','FCL',strVIRCellarts,strVIRCellartn,strResult);
          if substr(strResult,1,1)='N' then
                 strResult:='N|[E30025]';
                 return;
          end if;
      end if;

      -- 大盘/循环
      if v_strFCDATA_TYPE='1' or (v_strFCDATA_TYPE='2' and v_strCellCheckType='1') then
         if v_strPlanType=1  then --大盘储位盘
            --锁临时表
            update tmp_requstcell t set t.cell_no=t.cell_no where t.enterprise_no=strEnterPriseNo
                   and t.warehouse_no=strWareHouseNo and t.request_no=strRequstNo;

            --获取要盘点的储位
            PKOBJ_Fcdata.P_CellCheckGetCell(strEnterPriseNo,strWareHouseNo,strOwnerNo,strRequstNo,StrFIXEDCELLFLAG,
                 strAllCells,strResult);

            if substr(strResult,1,1)='N' then
                   strResult:='N|[P_CellCheckGetCell]';
                   return;
            end if;

            pkobj_fcdata.P_InsertCellLocateDiect(strEnterPriseNo,strWareHouseNo,strOwnerNo,v_strPlanNo,
                        strRequstNo,strUserId,v_strFCDATA_TYPE,dtRequestDate,strResult);
            if substr(strResult,1,1)='N' then
               strResult:='N|[E30011]';
               return;
            end if;
         else--商品盘
            --锁临时表
            update tmp_requstarticle t set t.cell_no=t.cell_no where t.enterprise_no=strEnterPriseNo
                   and t.warehouse_no=strWareHouseNo and t.request_no=strRequstNo;
            --获取要盘点的储位
            PKOBJ_Fcdata.P_ArtCheckGetCell(strEnterPriseNo,strWareHouseNo,strOwnerNo,strRequstNo,
                 strFullCellarts,strVIRCellarts,strResult);

            if substr(strResult,1,1)='N' then
                   strResult:='N|[P_ArtCheckGetCell]';
                   return;
            end if;
            pkobj_fcdata.P_InsertArtLocateDiect(strEnterPriseNo,strWareHouseNo,strOwnerNo,v_strPlanNo,
                        strRequstNo,strUserId,v_strFCDATA_TYPE,dtRequestDate,strResult);
            if substr(strResult,1,1)='N' then
               strResult:='N|[E30011]';
               return;
            end if;
         end if;
      end if;

      --储位拣货只定位储位
      if v_strFCDATA_TYPE='2' and v_strCellCheckType='0' then--
         if v_strPlanType=1  then --储位盘
            --锁临时表
            update tmp_requstcell t set t.cell_no=t.cell_no where t.enterprise_no=strEnterPriseNo
                   and t.warehouse_no=strWareHouseNo and t.request_no=strRequstNo;

            --获取要盘点的储位
            PKOBJ_Fcdata.P_CellCheckGetCell(strEnterPriseNo,strWareHouseNo,strOwnerNo,strRequstNo,StrFIXEDCELLFLAG,
                 strAllCells,strResult);

            if substr(strResult,1,1)='N' then
                   strResult:='N|[P_CellCheckGetCell]';
                   return;
            end if;

            pkobj_fcdata.P_InsertGetCellLocateDiect(strEnterPriseNo,strWareHouseNo,strOwnerNo,v_strPlanNo,
                        strRequstNo,strUserId,v_strFCDATA_TYPE,dtRequestDate,strResult);
            if substr(strResult,1,1)='N' then
               strResult:='N|[E30011]';
               return;
            end if;
         else
               strResult:='N|[目前暂不支持按商品的储位检查]';
               return;
         end if;
      end if;


      --动销盘
      if v_strFCDATA_TYPE=3  then
          --读取动销策略
          PKLG_WMS_BASE.p_GetBasePara(strEnterPriseNo,strWareHouseNo,strOwnerNo,'FCL_outstockCell','FC','FCL',stroutstockCells,stroutstockCelln,strResult);
          if substr(strResult,1,1)='N' then
             strResult:='N|[E30025]';
             return;
          end if;
          PKLG_WMS_BASE.p_GetBasePara(strEnterPriseNo,strWareHouseNo,strOwnerNo,'FCL_instockCell','FC','FCL',strinstockCells,strinstockCelln,strResult);
          if substr(strResult,1,1)='N' then
             strResult:='N|[E30025]';
             return;
          end if;

            --锁临时表
            update tmp_requstcell t set t.cell_no=t.cell_no where t.enterprise_no=strEnterPriseNo
                   and t.warehouse_no=strWareHouseNo and t.request_no=strRequstNo;
          --MM 141201 增加货位区域等条件过虑

          PKOBJ_FCDATA.P_dynamicCheckGetCell(strEnterPriseNo,strWareHouseNo,strOwnerNo,strRequstNo,stroutstockCells,strinstockCells,
               dtBEGIN_DATE,dtEND_DATE,strResult);

          if substr(strResult,1,1)='N' then
             strResult:='N|[P_dynamicCheckGetCell]';
             return;
          end if;

          if v_strCellCheckType='1' then

              pkobj_fcdata.P_InsertCellLocateDiect(strEnterPriseNo,strWareHouseNo,strOwnerNo,v_strPlanNo,
                          strRequstNo,strUserId,v_strFCDATA_TYPE,dtRequestDate,strResult);
              if substr(strResult,1,1)='N' then
                 strResult:='N|[没有需要盘点的数据]';--update by huangcx 20160715
                 return;
              end if;
          else
              pkobj_fcdata.P_InsertGetCellLocateDiect(strEnterPriseNo,strWareHouseNo,strOwnerNo,v_strPlanNo,
                          strRequstNo,strUserId,v_strFCDATA_TYPE,dtRequestDate,strResult);
              if substr(strResult,1,1)='N' then
                 strResult:='N|[没有需要盘点的数据]';--update by huangcx 20160715
                 return;
              end if;
          end if;

      end if;

      --更新需求单
      update fcdata_request_m set status='13',updt_name=strUserId,updt_date=sysdate
      where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo and owner_no=strOwnerNo
      AND request_no=strRequstNo and status='10';

      if sql%notfound then
          strResult:='N|[E30013]';
          return;
      end if;

      strResult:='Y|';
   end P_Fcdata_LocateDirect;




/**********************************************************************************************************
   luozhiling
   2013.11.16
   功能：按盘点计划成需求,并对需求单进行定位,暂存区不做盘点
***********************************************************************************************************/
   procedure P_Fcdata_RequestDirect(strEnterPriseNo         in    fcdata_plan_m.enterprise_no%type,
                                  strWareHouseNo            in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                  strOwnerNo                in    fcdata_plan_m.owner_no%type,
                                  strUserId                 in    fcdata_plan_m.rgst_name%type,
                                  strPlanNo                 in   fcdata_plan_m.plan_no%type,--盘点计划单号
                                  strRequstNo               OUT  fcdata_request_m.request_no%type,--盘点需求单号
                                  strResult                 OUT    varchar2)is
                  v_strPlanType            fcdata_request_m.plan_type%type;
    begin
      strResult := 'N|[P_Fcdata_RequestDirect]';

       begin
          select fpm.plan_type into v_strPlanType
          from fcdata_plan_m fpm where fpm.enterprise_no=strEnterPriseNo and
               fpm.warehouse_no=strWareHouseNo  and fpm.owner_no=strOwnerNo
               and fpm.plan_no=strPlanNo;
      exception when no_data_found then
          strResult:='N|[E30005]';
          return;
      end;

      --锁单
      update fcdata_plan_m t set t.status=status where t.enterprise_no=strEnterPriseNo
      and t.warehouse_no=strWareHouseNo and t.plan_no=strPlanNo;

      --按储位盘点成需求
      if v_strPlanType='1' then
         for GetWareArea in (select distinct fdm.org_no,fpd.enterprise_no,fpd.ware_no,fpd.area_no
          from fcdata_plan_d fpd,fcdata_plan_m fdm
           where fpd.enterprise_no=fdm.enterprise_no and fdm.warehouse_no=fpd.warehouse_no
           and fdm.plan_no=fpd.plan_no and fpd.enterprise_no=strEnterPriseNo and fpd.warehouse_no=strWareHouseNo
           and fpd.owner_no=strOwnerNo and fpd.plan_no=strPlanNo) loop

             if UPPER(GetWareArea.Ware_No)='ALL' then
               for GetDifWareArea in (select distinct cda.enterprise_no,cda.ware_no,cda.area_no,'all' as stock_no,'all' as cell_no
                    from cdef_defarea cda,cdef_defware cd where cd.enterprise_no=cda.enterprise_no
                    and cd.warehouse_no=cda.warehouse_no and cd.ware_no=cda.ware_no and cd.org_no=GetWareArea.org_no
                    and cda.enterprise_no=strEnterPriseNo and cda.WareHouse_No=strWareHouseNo
                    and cda.area_attribute not in('1','2')) loop
                   pkobj_fcdata.p_fcdata_insertRequestM(strEnterPriseNo,strWareHouseNo,strOwnerNo,strUserId,strPlanNo,strRequstNo,strResult);
                   if substr(strResult,1,1)='N' then
                       return;
                   end if;

                   insert into fcdata_request_d(enterprise_no,warehouse_no,owner_no,request_no,ware_no,
                       area_no,stock_no,article_no,group_no,cell_no)
                      values(strEnterPriseNo, strWareHouseNo,strOwnerNo, strRequstNo,GetDifWareArea.ware_no,
                      GetDifWareArea.area_no,'ALL','N','N','ALL');
               end loop;
             end if;

             if UPPER(GetWareArea.Ware_No)<>'ALL'and UPPER(GetWareArea.Area_No)='ALL' then
                 for GetDifWareArea in (select distinct cda.enterprise_no,cda.ware_no,cda.area_no,'all' as stock_no,'all' as cell_no
                 from cdef_defarea cda where cda.enterprise_no=strEnterPriseNo and cda.WareHouse_No=strWareHouseNo
                 and cda.ware_no=GetWareArea.Ware_No and cda.area_attribute not in('1','2')) loop

                   pkobj_fcdata.p_fcdata_insertRequestM(strEnterPriseNo,strWareHouseNo,strOwnerNo,strUserId,strPlanNo,strRequstNo,strResult);
                   if substr(strResult,1,1)='N' then
                       return;
                   end if;

                   insert into fcdata_request_d(enterprise_no,warehouse_no,owner_no,request_no,ware_no,
                       area_no,stock_no,article_no,group_no,cell_no)
                      values(strEnterPriseNo, strWareHouseNo,strOwnerNo, strRequstNo,GetDifWareArea.ware_no,
                      GetDifWareArea.area_no,'ALL','N','N','ALL');
               end loop;
             end if;

             if UPPER(GetWareArea.Ware_No)<>'ALL'and UPPER(GetWareArea.Area_No)<>'ALL' then

                    pkobj_fcdata.p_fcdata_insertRequestM(strEnterPriseNo,strWareHouseNo,strOwnerNo,strUserId,strPlanNo,strRequstNo,strResult);
                    if substr(strResult,1,1)='N' then
                       return;
                    end if;

                    insert into fcdata_request_d(enterprise_no,warehouse_no,owner_no,request_no,ware_no,
                       area_no,stock_no,article_no,group_no,cell_no)
                      select strEnterPriseNo,strWareHouseNo,strOwnerNo, strRequstNo,
                      fpd.ware_no,fpd.area_no,fpd.stock_no,fpd.article_no,fpd.group_no,fpd.cell_no
                      from fcdata_plan_d fpd where fpd.enterprise_no=strEnterPriseNo and fpd.warehouse_no=strWareHouseNo
                      and fpd.owner_no=strOwnerNO and fpd.plan_no=strPlanNo
                      and fpd.ware_no=GetWareArea.Ware_No and fpd.area_no=GetWareArea.Area_No;

             end if;
         end loop;
       --按商品盘点成需求
       else
          pkobj_fcdata.p_fcdata_insertRequestM(strEnterPriseNo,strWareHouseNo,strOwnerNo,strUserId,strPlanNo,strRequstNo,strResult);
          if substr(strResult,1,1)='N' then
             return;
          end if;

          insert into fcdata_request_d(enterprise_no,warehouse_no,owner_no,request_no,ware_no,
             area_no,stock_no,article_no,group_no,cell_no)
            select strEnterPriseNo,strWareHouseNo,strOwnerNo, strRequstNo,fpd.ware_no,
            fpd.area_no,fpd.stock_no,fpd.article_no,fpd.group_no,fpd.cell_no
            from fcdata_plan_d fpd where fpd.enterprise_no=strEnterPriseNo and fpd.warehouse_no=strWareHouseNo
            and fpd.owner_no=strOwnerNO and fpd.plan_no=strPlanNo;

      end if;

      --更新盘点计划单头档
      update fcdata_plan_m set status='11' where status='10' and owner_no=strOwnerNo
      and enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo and plan_no=strPlanNo;

      strResult:='Y';
    end P_Fcdata_RequestDirect;

    /************************************************************************************************
  创建人：luozhiling
  创建时间：2013.11.23
  功能说明：盘点结案
************************************************************************************************/
    procedure P_fcdata_closePlan(strEnterPriseNo      in    fcdata_plan_m.enterprise_no%type,
                                 strWareHouseNo       in    fcdata_plan_m.warehouse_no%type,--仓库编码
                                 strOwnerNo              in    fcdata_plan_m.owner_no%type,
                                 strPlanNo               in    fcdata_plan_m.plan_no%type,--盘点计划单号
                                 strUserId               in    fcdata_plan_m.rgst_name%type,--作业人
                                 strResult               OUT    varchar2)is
      strDiffFlag       fcdata_check_d.different_flag%type;
      strDiffNo fcdata_different_m.different_no%type; --差异单号
      v_iCount  integer;
      v_iCount1  integer;
      v_strStatus       fcdata_plan_m.status%type;
      cursor v_getCheckItem is
        select m.plan_no,m.request_no,m.check_no
         from fcdata_check_m m
         where m.enterprise_no=strEnterPriseNo and m.plan_no = strPlanNo
           and m.owner_no = strOwnerNo and m.warehouse_no = strWareHouseNo
           and m.status='13';

    begin
      strResult := 'N|[P_fcdata_closePlan]';
      --读取盘点计划单状态

      select status into v_strStatus from fcdata_plan_m where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo
      and owner_no=strOwnerNo and plan_no=strPlanNo;
      if v_strStatus='10' then
         strResult:='N|[E30014]';
         return;
      end if;

      if v_strStatus='11' then--已经成需求
         --是否全部定位
         select count(*) into v_icount from fcdata_request_m where warehouse_no=strWareHouseNo
         and enterprise_no=strEnterPriseNo and owner_no=strOwnerNo and plan_no=strPlanNo and status='13';

         select count(*) into v_icount1 from fcdata_request_m where warehouse_no=strWareHouseNo
         and enterprise_no=strEnterPriseNo and owner_no=strOwnerNo and plan_no=strPlanNo and status='10';

         if v_iCount>0 and v_iCount1>0 then
            strResult:='N|[E30015]';
            return;
         end if;

         --检查是否还有需求单未发单
         select count(*) into v_icount from fcdata_check_direct where warehouse_no=strWareHouseNo
         and enterprise_no=strEnterPriseNo and owner_no=strOwnerNo and plan_no=strPlanNo and status='10';
         if v_iCount>0 then
            strResult:='N|[E30016]';
            return;
         end if;

         select count(*) into v_icount from fcdata_check_m where warehouse_no=strWareHouseNo
         and enterprise_no= strEnterPriseNo and owner_no=strOwnerNo and plan_no=strPlanNo and status<>'13';
         if v_iCount>0 then
            strResult:='N|[E30017]';
            return;
         end if;
      end if;

      v_iCount:=0;
      for GetCheckItem in v_getCheckItem loop
          v_iCount:=1;
          Pkobj_Stock.P_fcdata_insetStock(strEnterPriseNo,strWareHouseNo,strOwnerNo,GetCheckItem.check_no,strUserId,strDiffFlag,strResult);
          if substr(strResult,1,1)='N' then
             strResult:='N|[E30018]';
             return;
          end if;
          if strDiffFlag='1' then --此盘点单有差异，需要写盘点差异数据

              --写差异单头档
              pkobj_fcdata.P_Fcdata_Insertdifferentm(strEnterPriseNo,strWareHouseNo,strOwnerNo,strUserId,GetCheckItem.request_no,
              GetCheckItem.check_no,GetCheckItem.plan_no,strDiffNo,strResult);
              if substr(strResult,1,1)='N' then
                 return;
              end if;

              --写差异单明细档
              pkobj_fcdata.P_Fcdata_InsertdifferentD(strEnterPriseNo,strWareHouseNo,strOwnerNo,strDiffNo,GetCheckItem.check_no,strResult);
              if substr(strResult,1,1)='N' then
                 return;
              end if;

          end if;
      end loop;

      if v_iCount=0 then
          strResult:='N|[E30019]';
          return;
      end if;

      --将储位解禁
      update cdef_defcell cdef
         SET cdef.check_status = '0'
       where exists (select 1
                from fcdata_check_d ccd, fcdata_check_m ccm
               where ccd.enterprise_no=ccm.enterprise_no and ccd.enterprise_no=strEnterPriseNo and ccd.check_no = ccm.check_no
                 and ccd.warehouse_no = ccm.warehouse_no
                 --and ccd.owner_no = ccm.owner_no
                 and ccd.warehouse_no = strWareHouseNo
                 and ccm.owner_no = strOwnerNo
                 and ccd.cell_no = cdef.cell_no
                 and ccm.plan_no = strPlanNo);

      --将库存解禁
      update stock_content cc
         set cc.status = '0'
       where exists (select 'x'
                from fcdata_check_d ccd, fcdata_check_m ccm
               where ccd.enterprise_no=ccm.enterprise_no and ccd.enterprise_no=strEnterPriseNo and ccd.check_no = ccm.check_no
                 and ccd.warehouse_no = ccm.warehouse_no
                 --and ccd.owner_no = ccm.owner_no
                 and ccd.warehouse_no = strWareHouseNo
                 and ccm.owner_no = strOwnerno
                 and ccd.cell_no = cc.cell_no
                 and ccm.plan_no = strPlanNo);

      --更新盘点头档
      update fcdata_check_m m
         set m.status = '13', updt_name = strUserId, updt_date = sysdate
       where m.enterprise_no=strEnterPriseNo and m.plan_no = strPlanNo
         and m.owner_no = strOwnerno
         and m.warehouse_no = strWareHouseNo;

      --更新计划单头
      update fcdata_plan_m m
         set m.status = '13'
       where m.enterprise_no=strEnterPriseNo and m.plan_no = strPlanNo
         and m.owner_no = strOwnerno
         and m.warehouse_no = strWareHouseNo;

      --写盘点头档表
      pkobj_fcdata.P_Fcdata_Insertpdm(strEnterPriseNo,strWareHouseNo,strOwnerNo,strUserId,strPlanNo,strResult);
      if substr(strResult,1,1)='N' then
         return;
      end if;

      --写盘点明细档
      pkobj_fcdata.P_Fcdata_Insertpdd(strEnterPriseNo,strWareHouseNo,strOwnerNo,strPlanNo,strUserId,strResult);
      if substr(strResult,1,1)='N' then
         return;
      end if;

      --盘点有差异的写进出帐表
      Pkobj_Stock.P_stock_Insertaccount(strEnterPriseNo,strWareHouseNo,strOwnerNo,strPlanNo,strUserId,strResult);
      if substr(strResult,1,1)='N' then
         return;
      end if;

      --盘点单据转历史 huangb 20160517
      PKOBJ_FCDATA.P_FC_InsertHTY(strEnterPriseNo,strWareHouseNo,strOwnerNo,strPlanNo,strUserId,strResult);
      if substr(strResult,1,1)='N' then
         return;
      end if;

      strResult := 'Y|';
    end P_fcdata_closePlan;

 /**********************************************************************************************************
   zhouhuan
   2014.4.21
   功能：盘点切单
***********************************************************************************************************/
    procedure P_GetTask(strEnterPriseNo         in    fcdata_plan_m.enterprise_no%type,
                        strWareHouseNo          in    fcdata_plan_m.warehouse_no%type,--仓库编码
                        strOwnerNo              in    fcdata_plan_m.owner_no%type,
                        strUserId               in    fcdata_plan_m.rgst_name%type,--作业人
                        strPaperUserId          in    fcdata_plan_m.rgst_name%type,--单据人
                        strRequstNo             in   fcdata_plan_m.plan_no%type,--需求单号
                        strCutFlag              in   fcdata_check_m.fcdata_type%type,--1:按通道；2：按通道+层
                        strMoveType             in   fcdata_check_m.fcdata_type%type,--1：U型；2：W型
                        strResult               OUT    varchar2)is
         v_iCount                 integer;
         v_strAStockNo            cdef_defcell.cell_no%type;
         v_strCheckNo             fcdata_check_m.check_no%type;
         nRowId                   integer;
         v_nOrderId             fcdata_check_d.order_id%type;
         v_nSubOrderId          fcdata_check_d.sub_order_id%type;
         v_strStockY             cdef_defcell.stock_y%type;
         v_strCellNo             fcdata_check_direct.cell_no%type;
         v_strArticleNo          fcdata_check_direct.article_no%type;
         v_strOldCheckNo         fcdata_check_m.check_no%type;

  begin
      strResult := 'N|P_GetTask';
      v_iCount:=0;
      v_strAStockNo:='N';
      v_strStockY:='N';
      v_strCellNo:='N';
      v_strArticleNo:='N';
      v_strOldCheckNo:='N';

      --锁定定位指示表
       update fcdata_check_direct fcd
       set fcd.status = fcd.status
       where fcd.enterprise_no=strEnterPriseNo
       and fcd.warehouse_no = strWareHouseNo
       and fcd.owner_no=strOwnerNo
       and fcd.request_no=strRequstNo
       and fcd.status='10';

      if strCutFlag = '1' then--按通道切单
          for GetCheckDirect in(select distinct cd.prefix||cd.stock_no as a_stock_no,cd.pick_order,fcd.*
              from fcdata_check_direct fcd,cdef_defcell cd
              where fcd.enterprise_no=cd.enterprise_no and fcd.enterprise_no=strEnterPriseNo
              and fcd.warehouse_no=cd.warehouse_no and fcd.cell_no=cd.cell_no
              and fcd.warehouse_no=strWareHouseNo and fcd.request_no=strRequstNo and fcd.status='10'
              order by a_stock_no,fcd.cell_no,cd.pick_order,fcd.article_no) loop
              v_iCount:=v_iCount+1;

              if GetCheckDirect.a_stock_no<>v_strAStockNo then
                  --写盘点单头档
                  PKOBj_FCDATA.P_InsertCheckM(strEnterPriseNo,strWareHouseNo,strOwnerNo,strUserId,strPaperUserid,
                  GetCheckDirect.Direct_Serial, v_strCheckNo,strResult);
                    if substr(strResult,1,1)='N' then
                       return;
                    end if;
              end if;

              if  v_strOldCheckNo<>v_strCheckNo then--分单重置ORDERid和suborder_id
                  v_nOrderId:=0;
                  v_nSubOrderId:=1;
              end if;

              --获取最大的行号
              select nvl(max(row_id),0) into nRowId from fcdata_check_d where enterprise_no=strEnterPriseNo
              and warehouse_no=strWareHouseNo and check_no=v_strCheckNo;

              if GetCheckDirect.cell_no<>v_strCellNo  then
                 v_nOrderId:=v_nOrderId+1;
              end if;

              if GetCheckDirect.cell_no=v_strCellNo and GetCheckDirect.article_no<>v_strArticleNo then
                 v_nSubOrderId:=v_nSubOrderId+1;
              end if;

               PKOBj_FCDATA.P_InsertCheckD(strEnterPriseNo,strWareHouseNo,GetCheckDirect.owner_no,strPaperUserid, v_strCheckNo,
               nRowId,v_nOrderId,v_nSubOrderId,GetCheckDirect.Direct_Serial, strResult);
               if substr(strResult,1,1)='N' then
                 return;
               end if;

               v_strOldCheckNo:=v_strCheckNo;
               v_strAStockNo:=GetCheckDirect.a_stock_no;
               v_strCellNo:=GetCheckDirect.cell_no;
               v_strArticleNo:=GetCheckDirect.article_no;
          end loop;

      end if;
      if strCutFlag = '2' then --按通道+层切单
          for GetCheckDirect in (select distinct cd.prefix||cd.stock_no as a_stock_no,cd.pick_order,cd.stock_y,fcd.*
                from fcdata_check_direct fcd,cdef_defcell cd
                where fcd.enterprise_no=cd.enterprise_no and fcd.enterprise_no=strEnterPriseNo
                and fcd.warehouse_no=cd.warehouse_no and fcd.cell_no=cd.cell_no
                and fcd.warehouse_no=strWareHouseNo
                and fcd.request_no=strRequstNo and fcd.status='10'
                order by a_stock_no,cd.stock_y,fcd.cell_no,cd.pick_order,fcd.article_no)loop
                v_iCount:=v_iCount+1;

                if GetCheckDirect.a_stock_no<>v_strAStockNo or GetCheckDirect.stock_y<>v_strStockY then
                    --写盘点单头档
                    PKOBj_FCDATA.P_InsertCheckM(strEnterPriseNo,strWareHouseNo,strOwnerNo,strUserId,strPaperUserid,
                    GetCheckDirect.Direct_Serial, v_strCheckNo,strResult);
                      if substr(strResult,1,1)='N' then
                         return;
                      end if;
                end if;

                if  v_strOldCheckNo<>v_strCheckNo then--分单重置ORDERid和suborder_id
                    v_nOrderId:=0;
                    v_nSubOrderId:=1;
                end if;

                --获取最大的行号
                select nvl(max(row_id),0) into nRowId from fcdata_check_d where warehouse_no=strWareHouseNo
                and enterprise_no=strEnterPriseNo and check_no=v_strCheckNo;

                if GetCheckDirect.cell_no<>v_strCellNo then
                   v_nOrderId:=v_nOrderId+1;
                end if;

                if GetCheckDirect.cell_no=v_strCellNo and GetCheckDirect.article_no<>v_strArticleNo then
                   v_nSubOrderId:=v_nSubOrderId+1;
                end if;

                 PKOBj_FCDATA.P_InsertCheckD(strEnterPriseNo,strWareHouseNo,GetCheckDirect.owner_no,strPaperUserid, v_strCheckNo,
                 nRowId,v_nOrderId,v_nSubOrderId,GetCheckDirect.Direct_Serial, strResult);
                 if substr(strResult,1,1)='N' then
                   return;
                 end if;
                 v_strOldCheckNo:=v_strCheckNo;
                 v_strCellNo:=GetCheckDirect.cell_no;
                 v_strArticleNo:=GetCheckDirect.article_no;
                 v_strAStockNo:=GetCheckDirect.a_stock_no;
                 v_strStockY:=GetCheckDirect.stock_y;
          end loop;
      end if;

      if v_iCount=0 then
          strResult:='N|[E30202]';
          return;
      end if;
      --更新盘点指示状态
       update fcdata_check_direct set status='13' ,updt_name=strUserId,updt_date=sysdate
              where enterprise_no=strEnterPriseNo and warehouse_no=strWareHouseNo
              and request_no=strRequstNo and status='10';
       if sql%notfound then
          strResult:='N|[E30203]';
          return;
       end if;

      --定位指示转历史
      PKOBj_FCDATA.P_CheckDirectToHty(strEnterPriseNo,strWareHouseNo,strOwnerNo,strRequstNo, strResult);
      if substr(strResult,1,1)='N' then
        return;
      end if;

      --需求单转历史
      PKOBj_FCDATA.P_CheckRequestToHty(strEnterPriseNo,strWareHouseNo,strOwnerNo,strRequstNo, strResult);
      if substr(strResult,1,1)='N' then
        return;
      end if;

      strResult:='Y|';

    end P_GetTask;

/**********************************************************************************************************
   zhouhuan
   2014.4.22
   功能：初盘发单
***********************************************************************************************************/
    procedure P_SendTask(strEnterPriseNo         in    fcdata_plan_m.enterprise_no%type,
                         strWareHouseNo          in    fcdata_plan_m.warehouse_no%type,--仓库编码
                         strOwnerNo              in    fcdata_plan_m.owner_no%type,
                         strUserId               in    fcdata_plan_m.rgst_name%type,--作业人
                         strCheckNo              in    fcdata_plan_m.plan_no%type,--盘点单号
                         strCheckType            in    fcdata_check_m.check_type%type,--1:初盘
                         strDockNo               in    pntset_printer_dock.dock_no%type,
                         strFcdataType           in    fcdata_check_m.fcdata_type%type,--1:盘点；2：循环盘；3：动销盘
                         strPrintType            in    fcdata_check_d.check_type%type,--1:打印报表；2：打印标签;0:不打印
                         strResult               OUT    varchar2)is
         v_strReportId            stock_label_m.report_id%type;
         v_strPrtTask             fcdata_plan_m.plan_no%type;
    begin
      strResult := 'N|[P_SendTask]';

      --更新盘点单头档
      update fcdata_check_m t set t.status='10',t.check_type=strCheckType,
             t.assign_no=strUserId,t.updt_name=strUserId,t.updt_date=sysdate
          where t.enterprise_no=strEnterPriseNo and t.warehouse_no=strWareHouseNo and t.owner_no=strOwnerNo
          and t.status='11' and t.check_no=strCheckNo;
      if sql%notfound then
         strResult:='N|[E30204]';
         return;
      end if;

      if strFcdataType='1' or strFcdataType='2' or strFcdataType='3' then
        if strPrintType='1' then
            --获取报表id
             v_strReportId:=CONST_REPORTID.RPT_CH_CHECK1;

        elsif strPrintType='2'  then
             --获取报表id
             v_strReportId:=CONST_REPORTID.RPT_CH_CHECK1_B;
        end if;

      elsif strFcdataType='3' then
         if strPrintType='2' then
             v_strReportId:=CONST_REPORTID.RPT_CH_CHECK1;

        else
           strResult:='N|[E30206]';
           return;
        end if;
      else
          strResult:='N|[E30207]';
          return;
      end if;

      if strPrintType<>'0' then
          --写打印任务
          PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterPriseNo,strWareHouseNo,
                                              strCheckNo,
                                              0,
                                              v_strReportId,
                                              strDockNo,
                                              0,
                                              strUserId,
                                              v_strPrtTask,
                                              strResult);


          if substr(strResult,0,1)='N' then
              return;
          end if;
      end if;

      strResult:='Y|';

     exception
      when others then
        strResult := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);

    end P_SendTask;
/********************************************************************************************************
 功能说明：储位检查按储位实时定位
 luozhiling
 2015.10.19
********************************************************************************************************/
 procedure P_LocateCell(strEnterPriseNo          in    fcdata_plan_m.enterprise_no%type,
                       strWareHouseNo           in    fcdata_plan_m.warehouse_no%type,--仓库编码
                       strOwnerNo               in    fcdata_plan_m.owner_no%type,--货主编号
                       strCheckNo               in    fcdata_check_m.check_no%type,--盘点单号
                       strCellNo                in    fcdata_check_d.cell_no%type,
                       strUserId                in    fcdata_check_m.rgst_name%type,--盘点人
                       strResult                OUT   varchar2)is
         v_strCellCheckType       wms_defbase.sdefine%type;
         v_nCellCheckType         wms_defbase.ndefine%type;
 begin
       strResult:='N|[P_LocateCell]';
        --读取
        PKLG_WMS_BASE.p_GetBasePara(strEnterPriseNo,strWareHouseNo,strOwnerNo,'CellCheckType',
              'FC','FC_LOCATE',v_strCellCheckType,v_nCellCheckType,strResult);
        if substr(strResult,1,1)='N' then
               strResult:='N|[E30025]';
               return;
        end if;

        if v_strCellCheckType='0' then
           PKOBJ_FCDATA.P_InsertCellToCheckD(strEnterPriseNo,strWareHouseNo,strOwnerNo,strCheckNo,strCellNo,
                  strUserId,strResult);
            if substr(strResult,1,1)='N' then
                   strResult:='N|[E30025]';
                   return;
            end if;
        end if;

       strResult:='Y|[]';
 end P_LocateCell;
 /*********************************************************************************************************88
  功能说明：校验盘点储位或标签

 ***********************************************************************************************************/
 procedure P_CheckCellOrLabel(strEnterPriseNo         in    fcdata_plan_m.enterprise_no%type,
                              strWareHouseNo          in    fcdata_plan_m.warehouse_no%type,--仓库编码
                              strOwnerNo              in    fcdata_plan_m.owner_no%type,
                              strCheckNo              in    fcdata_plan_m.plan_no%type,--盘点单号
                              strCellNo               in    fcdata_check_d.cell_no%type,--储位,支持标签或储位
                              strOutCellNo            out   fcdata_check_d.cell_no%type,
                              strResult               OUT   varchar2)is
    v_iCount                  integer;
    begin
         strResult:='N|[P_CheckCellOrLabel]';

         --首先判断是否是此盘点单上的储位
         select count(*) into v_iCount from fcdata_check_d fcd where fcd.enterprise_no=strEnterPriseNo
         and fcd.warehouse_no=strWareHouseNo and fcd.check_no=strCheckNo and fcd.cell_no=strCellNo;
         if v_iCount=0 then --若找不到盘点单上对应的储位，则找标签
            begin
              select fcd.cell_no into strOutCellNo from fcdata_check_d fcd where fcd.enterprise_no=strEnterPriseNo
                     and fcd.warehouse_no=strWareHouseNo and fcd.check_no=strCheckNo and fcd.label_no=strCellNo;
            exception when no_data_found then
               begin
                   select sc.cell_no into strOutCellNo from stock_content sc where sc.enterprise_no=strEnterPriseNo
                       and sc.warehouse_no=strWareHouseNo and sc.label_no=strCellNo;

                   strResult:='N|[此标签对应'||strOutCellNo||'储位]';
                   return;
               exception when no_data_found then
                   strResult:='N|[此标签不存在]';
                   return;
               end;
            end;
         else
             strOutCellNo:=strCellNo;
         end if;

         strResult:='Y|[成功]';
    end P_CheckCellOrLabel;

/**********************************************************************************************************
   zhouhuan
   2014.4.22
   功能：复盘/三盘发单
***********************************************************************************************************/
    procedure P_SendTaskAgain(strEnterPriseNo         in    fcdata_plan_m.enterprise_no%type,
                              strWareHouseNo          in    fcdata_plan_m.warehouse_no%type,--仓库编码
                              strOwnerNo              in    fcdata_plan_m.owner_no%type,
                              strUserId               in    fcdata_plan_m.rgst_name%type,--作业人
                              strCheckNo              in    fcdata_plan_m.plan_no%type,--盘点单号
                              strCheckType            in    fcdata_check_m.check_type%type,--2:复盘；3：三盘
                              strDockNo               in    pntset_printer_dock.dock_no%type,
                              strFirstFlag            in    varchar2,--0=第一张单
                              strPrintType            in    fcdata_check_d.check_type%type,--1:打印报表；2：打印标签;0: 不打印
                              strCellNo               in    fcdata_check_d.cell_no%type,--储位
                              strResult               OUT   varchar2)is
     v_strReportId            stock_label_m.report_id%type;
     v_strPrtTask             fcdata_plan_m.plan_no%type;
    begin
      strResult := 'N|[P_SendTaskAgain]';

      if strFirstFlag = 0 then
        --更新盘点单头档
        PKOBJ_FCDATA.P_Update_Fcdata_CheckM(strEnterPriseNo,strWareHouseNo,
                                            strOwnerNo,
                                            strCheckNo,
                                            strUserId,
                                            strCheckType,
                                            '10',
                                            strResult);
        if substr(strResult,0,1)='N' then
            return;
        end if;
      end if;




      --更新盘点单明细
      PKOBJ_FCDATA.P_Update_Fcdata_CheckD(strEnterPriseNo,strWareHouseNo,
                                          strOwnerNo,
                                          strCheckNo,
                                          strCellNo,
                                          strCheckType,
                                          '10',
                                          strResult
                             	           );
     if substr(strResult,0,1)='N' then
        return;
     end if;

      if strFirstFlag = 0 then
        if strCheckType='2' then
           if strPrintType='1' then
              v_strReportId:=CONST_REPORTID.RPT_CH_CHECK2;
           end if;
           if strPrintType='2' then
              v_strReportId:=CONST_REPORTID.RPT_CH_CHECK1_B; --目前标签暂时没定义，同报表
           end if;
        end if;

        if strCheckType='3' then
           if strPrintType='1' then
               v_strReportId:=CONST_REPORTID.RPT_CH_CHECK3;
           end if;
           if strPrintType='2' then
               v_strReportId:=CONST_REPORTID.RPT_CH_CHECK1_B;
           end if;
        end if;

        if strPrintType<>'0' then
            --写打印任务
            PKOBJ_PRINTTASK.p_insert_taskmaster(strEnterPriseNo,strWareHouseNo,
                                                strCheckNo,
                                                0,
                                                v_strReportId,
                                                strDockNo,
                                                0,
                                                strUserId,
                                                v_strPrtTask,
                                                strResult);
            if substr(strResult,0,1)='N' then
                return;
            end if;
        end if;
      end if;
      strResult:='Y|';

     exception
      when others then
        strResult := 'N|' || SQLERRM ||
                     substr(dbms_utility.format_error_backtrace, 1, 256);

    end P_SendTaskAgain;

end PKLG_FCDATA;

/

