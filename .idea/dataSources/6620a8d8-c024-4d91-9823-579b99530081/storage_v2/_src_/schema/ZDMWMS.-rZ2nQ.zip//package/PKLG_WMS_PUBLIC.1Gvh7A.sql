create package PKLG_WMS_Public is

  /*****************************************************************************************
   功能：公用包，WMS系统共用
  Modify By luozhiling AT 2016-6-22
  *****************************************************************************************/

  /***********************************************************************************************
  功能：获取打印机组
  luozhiling
  2013-11-10
  *************************************************************************************************/
  procedure GetPrintGroupByDockNo(strEnterpriseNo in bdef_defdock.enterprise_no%type,
                                  strWarehouse_No in bdef_defdock.warehouse_no%type,
                                  strDockNo       in bdef_defdock.dock_no%type,
                                  strPrintGroupNo out pntset_printer_dock.printer_group_no%type,
                                  strOutMsg       out varchar);

  /*****************************************************************************************
   功能：获取库存三级帐行号
  Modify By luozhiling AT 2013-11-4
  *****************************************************************************************/
  procedure p_MoveContent_rowid(n_Row_id out stock_content_move.row_id%type); --返回行号

  procedure P_Insert_ScanLabelNoLog
     (strEnterpriseNo         in                   bdef_scan_log.enterprise_no%type,
      strWarehouseNo          in                   BDEF_SCAN_LOG.warehouse_no%type,
      strOwnerNo	            in                   stock_box_m.owner_no%type,
      strScanBarcode          in                   BDEF_SCAN_LOG.Scan_Barcode%type,
      strSourceNo             in                   BDEF_SCAN_LOG.Source_No%type,
      strArticleNo            in                   bdef_scan_log.article_no%type,--进货整箱扫描时传实际商品，其余默认为N
      strCellNo               in                   BDEF_SCAN_LOG.Cell_No%type,--默认传 'N '，盘点使用
      strCheckType            in                   BDEF_SCAN_LOG.Check_Type%type,  --默认传 '1' ,盘点使用
      strWorkerNo             in                   BDEF_SCAN_LOG.Rgst_Name%type,
      strLabelNo              in                   BDEF_SCAN_LOG.Label_No%type,
      strType                 in                   varchar2, --[进货：I],[出货：O],[库内操作:M]
      strResult               out                  varchar2);

  procedure P_Insert_article_barcode
         (strEnterpriseNo           in       bset_article_barcode_m.enterprise_no%type,
          strWareHouseNo            in       bset_article_barcode_m.warehouse_no%type,
          strOwnerNo                in       bset_article_barcode_m.owner_no%type,
          strPaperNo                in       bset_article_barcode_m.paper_no%type,
          strArticleNo              in       bset_article_barcode_d.article_no%type,
          strFirstArticleNo         in       bset_article_barcode_d.barcode_type%type,--0:非第一个商品；1：第一个商品
          strUserId                 in       bset_article_barcode_m.rgst_name%type,
          nInSerialNo               in       bset_article_barcode_m.serial_no%type,
          nSerialNo                 out      bset_article_barcode_m.serial_no%type,
          strResult                 out      varchar2);
/*
  procedure P_Get_Boxbarcode
         (strEnterpriseNo   in         bset_article_barcode_m.enterprise_no%type,
          strWareHouseNo    in         bset_article_barcode_m.warehouse_no%type,
          nSerialNo         in         bset_article_barcode_m.serial_no%type,
          strArticleNo      in         bset_article_barcode_d.article_no%type,
          strBarcode        IN         bdef_defarticle.barcode%type,
          nPackingQty       in         bdef_article_packing.packing_qty%type,
          strUserId         in         bset_article_barcode_m.rgst_name%type,
          strResult         out        varchar2);
*/
  PROCEDURE PROC_CREATE_STOCK_BOX
    (strEnterpriseNo          in                   stock_box_m.enterprise_no%type,
     strWarehouseNo           in                   stock_box_m.warehouse_no%type,
     strArticleNo             in                   stock_box_d.article_no%type,
     strBoxNo                 in                   stock_box_m.box_no%type,
     nPackingQty              in                   stock_box_d.qty%type,
     strUserId                in                   stock_box_m.rgst_name%type,
     strResult                out                  varchar2);

   /*************************************************************************************************************
   功能说明：补印中心,
             目前只能补印进货验收和出货标签，补货、退货和返配标签暂不支持
             2015.9.22
   *************************************************************************************************************/
   procedure P_PrintLabel(strEnterPriseNo         in         job_printtask_m.Enterprise_No%type,
                          strWareHouseNo          in         job_printtask_m.Warehouse_No%type,
                          strLabelNo              in         stock_label_m.label_no%type,
                          strDockNo               in         pntset_printer_group.printer_group_no%type,
                          strUserId               in         stock_label_m.updt_name%type,
                          strOutMsg               out varchar2);

  /*=====================================================================================
  hb 20160624
  获取报表ID 底层用 返回唯一报表ID
  ======================================================================================*/
  PROCEDURE p_GetReportId(strEnterPriseNo in wms_warehouse_outorder.enterprise_no%type,--企业号
                          strWarehouseNo  in job_printtask_m.warehouse_no%type,--仓别号
                          strPaperType    in pntset_module_report.paper_type%type,--单据类型 参考包CONST_REPORT_TYPE
                          strReportType   in pntset_module_report.report_type%type,--报表类型 L:表单；M:标签头档；D:标签明细;WAY-面单;INV-发票;BOX-装箱清
                          strSourceNo     in job_printtask_m.source_no%type, --源单号
                          --返回参数
                          strReportId     out pntset_module_report.report_id%type, --返回报表ID
                          strOutMsg       out varchar2);

  --获取报表ID-扩展 底层用 返回唯一报表ID
  PROCEDURE p_GetReportIdExt(strEnterPriseNo in wms_warehouse_outorder.enterprise_no%type, --企业号
                             strWarehouseNo  in job_printtask_m.warehouse_no%type, --仓别号
                             strPaperType    in pntset_module_report.paper_type%type, --单据类型 参考包CONST_REPORT_TYPE
                             strReportType   in pntset_module_report.report_type%type, --报表类型 L:表单；M:标签头档；D:标签明细;WAY-面单;INV-发票;BOX-装箱清
                             strSourceNo     in job_printtask_m.source_no%type, --源单号
                             strRsvVarod1    in pntset_module_report.rsv_varod1%type, --预留字段
                             strRsvVarod2    in pntset_module_report.rsv_varod2%type, --预留字段
                             strRsvVarod3    in pntset_module_report.rsv_varod3%type, --预留字段
                             strRsvVarod4    in pntset_module_report.rsv_varod4%type, --预留字段
                             strRsvVarod5    in pntset_module_report.rsv_varod5%type, --预留字段
                             strRsvVarod6    in pntset_module_report.rsv_varod6%type, --预留字段
                             strRsvVarod7    in pntset_module_report.rsv_varod7%type, --预留字段
                             strRsvVarod8    in pntset_module_report.rsv_varod8%type, --预留字段
                             --返回参数
                             strReportId out pntset_module_report.report_id%type, --返回报表ID
                             strOutMsg   out varchar2);

  /*=====================================================================================
  hb insert to 20160620
  打印-通过配置查找报表 底层用 返回唯一报表ID
  ======================================================================================*/
  PROCEDURE p_GetReportSqlBySet(--查询条件
                               strEnterpriseNo    in pntset_module_report.enterprise_no%type,--企业
                               strPaperType       in pntset_module_report.paper_type%type,--单据类型 参考包CONST_REPORT_TYPE
                               strTaskType        in pntset_module_report.task_type%type,--任务类型 0：标签发单；1：纯表单发单（纯RF发单）2：任务标签发单；
                               strPickType        in pntset_module_report.pick_type%type,--作业类型 0-摘果；1-播种
                               strOperateType     in pntset_module_report.operate_type%type,--操作类型 'P','C','B'
                               strReportType      in pntset_module_report.report_type%type,--报表类型 L:表单；M:标签头档；D:标签明细
                               strOrderType       in pntset_module_report.order_type%type,--订单类型 例如'OE','ID'
                               strDeliverObjLevel in pntset_module_report.deliver_obj_level%type,--配送对象级别 0:按客户,1:按单据,2:按实体客户
                               strUseType         in pntset_module_report.use_type%type,--标签用途：0：收货标签；1：客户标签；2：分播标签；3：移库标签
                               strOwnerNo         in pntset_module_report.owner_no%type,--货主编码
                               strCustNo          in pntset_module_report.cust_no%type,--客户编码
                               strShipperNo       in pntset_module_report.shipper_no%type,--承运商编码
                               strRsvVarod1       in pntset_module_report.rsv_varod1%type,--预留字段
                               strRsvVarod2       in pntset_module_report.rsv_varod2%type,--预留字段
                               strRsvVarod3       in pntset_module_report.rsv_varod3%type,--预留字段
                               strRsvVarod4       in pntset_module_report.rsv_varod4%type,--预留字段
                               strRsvVarod5       in pntset_module_report.rsv_varod5%type,--预留字段
                               strRsvVarod6       in pntset_module_report.rsv_varod6%type,--预留字段
                               strRsvVarod7       in pntset_module_report.rsv_varod7%type,--预留字段
                               strRsvVarod8       in pntset_module_report.rsv_varod8%type,--预留字段
                               --返回参数
                               strReportId        out job_printtask_m.report_id%type, --打印的报表ID 如外部传入 则传具体的report_id且查询条件可全部为'N',否则本参数传'N'
                               strOutMsg          out varchar2);

  /*=====================================================================================
  hb 20160624
  获取报表ID 供前台界面调用
  ======================================================================================*/
  PROCEDURE p_GetReportIdUI(strEnterPriseNo in wms_warehouse_outorder.enterprise_no%type,--企业号
                            strWarehouseNo  in job_printtask_m.warehouse_no%type,--仓别号
                            strPaperType    in pntset_module_report.paper_type%type,--单据类型 参考包CONST_REPORT_TYPE
                            strReportType   in pntset_module_report.report_type%type,--报表类型 L:表单；M:标签头档；D:标签明细;WAY-面单;INV-发票;BOX-装箱清
                            strSourceNo     in job_printtask_m.source_no%type, --源单号
                            --返回参数
                            strOutSql       out varchar2,--返回sql语句
                            strOutMsg       out varchar2);

  /*=====================================================================================
  hb insert to 20160617
  补印-通过配置查找报表SQL 供前台界面调用
  ======================================================================================*/
  PROCEDURE p_GetReportSqlBySetUI(strEnterpriseNo    in pntset_module_report.enterprise_no%type,--企业
                                  strWarehouseNo     in job_printtask_m.warehouse_no%type,--仓别号
                                  strPaperType       in pntset_module_report.paper_type%type,--单据类型 参考包CONST_REPORT_TYPE
                                  strTaskType        in pntset_module_report.task_type%type,--任务类型 0：标签发单；1：纯表单发单（纯RF发单）2：任务标签发单；
                                  strPickType        in pntset_module_report.pick_type%type,--作业类型 0-摘果；1-播种
                                  strOperateType     in pntset_module_report.operate_type%type,--操作类型 'P','C','B'
                                  strReportType      in pntset_module_report.report_type%type,--报表类型 L:表单；M:标签头档；D:标签明细
                                  strOrderType       in pntset_module_report.order_type%type,--订单类型 例如'OE','ID'
                                  strDeliverObjLevel in pntset_module_report.deliver_obj_level%type,--配送对象级别 0:按客户,1:按单据,2:按实体客户
                                  strUseType         in pntset_module_report.use_type%type,--标签用途：0：收货标签；1：客户标签；2：分播标签；3：移库标签
                                  strOwnerNo         in pntset_module_report.owner_no%type,--货主编码
                                  strCustNo          in pntset_module_report.cust_no%type,--客户编码
                                  strShipperNo       in pntset_module_report.shipper_no%type,--承运商编码
                                  strRsvVarod1       in pntset_module_report.rsv_varod1%type,--预留字段
                                  strRsvVarod2       in pntset_module_report.rsv_varod2%type,--预留字段
                                  strRsvVarod3       in pntset_module_report.rsv_varod3%type,--预留字段
                                  strRsvVarod4       in pntset_module_report.rsv_varod4%type,--预留字段
                                  strRsvVarod5       in pntset_module_report.rsv_varod5%type,--预留字段
                                  strRsvVarod6       in pntset_module_report.rsv_varod6%type,--预留字段
                                  strRsvVarod7       in pntset_module_report.rsv_varod7%type,--预留字段
                                  strRsvVarod8       in pntset_module_report.rsv_varod8%type,--预留字段
                                  strOutSql          out varchar2,--返回sql语句
                                  strOutMsg          out varchar2);

  /*=====================================================================================
  hb 20160623
  特殊类报表通过配置新增打印任务(不写打印任务明细)
  ======================================================================================*/
  PROCEDURE p_Insert_SpecialReportTask(strEnterPriseNo in wms_warehouse_outorder.enterprise_no%type,--企业号
                                       strWarehouseNo  in job_printtask_m.warehouse_no%type,--仓别号
                                       strReportType   in pntset_module_report.report_type%type,--报表类型 WAY-面单;INV-发票;BOX-装箱清
                                       strSourceNo     in job_printtask_m.source_no%type, --源单号
                                       strDockNo       in varchar2, --码头或工作站号
                                       strReprintFlag  in job_printtask_m.reprint_flag%type, --补印标识
                                       strUserId       in job_printtask_m.Rgst_Name%type, --操作人员
                                       --返回参数
                                       strTaskNo       out job_printtask_m.task_no%type, --打印任务单号 如外部生成 则传外部生成打印任务号,否则传'N'
                                       strOutMsg       out varchar2);

/*=====================================================================================
  hb 20160623
  特殊类报表通过配置新增打印任务（扩展）
  ======================================================================================*/
  PROCEDURE p_Insert_SpecialReportTaskExt(strEnterPriseNo in wms_warehouse_outorder.enterprise_no%type, --企业号
                                          strWarehouseNo  in job_printtask_m.warehouse_no%type, --仓别号
                                          strReportType   in pntset_module_report.report_type%type, --报表类型 WAY-面单;INV-发票;BOX-装箱清
                                          strSourceNo     in job_printtask_m.source_no%type, --源单号
                                          strDockNo       in varchar2, --码头或工作站号
                                          strReprintFlag  in job_printtask_m.reprint_flag%type, --补印标识
                                          strUserId       in job_printtask_m.Rgst_Name%type, --操作人员
                                          strRsvVarod1    in pntset_module_report.rsv_varod1%type, --预留字段
                                          strRsvVarod2    in pntset_module_report.rsv_varod2%type, --预留字段
                                          strRsvVarod3    in pntset_module_report.rsv_varod3%type, --预留字段
                                          strRsvVarod4    in pntset_module_report.rsv_varod4%type, --预留字段
                                          strRsvVarod5    in pntset_module_report.rsv_varod5%type, --预留字段
                                          strRsvVarod6    in pntset_module_report.rsv_varod6%type, --预留字段
                                          strRsvVarod7    in pntset_module_report.rsv_varod7%type, --预留字段
                                          strRsvVarod8    in pntset_module_report.rsv_varod8%type, --预留字段
                                          --返回参数
                                          strTaskNo out job_printtask_m.task_no%type, --打印任务单号 如外部生成 则传外部生成打印任务号,否则传'N'
                                          strOutMsg out varchar2);


  /*===========================================进货公用方法begin==============================================


  ==================================================================================================*/
  /********************************************************************8
  取进货单据类型配置

  ********************************************************************/
  PROCEDURE P_GetIdataOrder(strEnterPriseNo in wms_warehouse_idatatype.enterprise_no%type,--企业号 必传
                            strWarehouseNo  in wms_warehouse_idatatype.warehouse_no%type, --仓别
                            strOwnerNo      in wms_warehouse_idatatype.owner_no%type, --系
                            strImportType   in wms_warehouse_idatatype.import_type%type, --单据类型 必传
                            strColumnName   in varchar2, --需要取值的列名
                            strColumnValue  out varchar2, --返回列名的值
                            strOutMsg       out varchar2);

  /*==============================================进货公用方法 end=============================================*/



  /*==============================================出货公用方法 begin=============================================*/

  /*=====================================================================================
  hb 20160622
  取出货类型策略信息
  ======================================================================================*/
  PROCEDURE p_OM_GetOutOrder(strEnterPriseNo in wms_warehouse_outorder.enterprise_no%type,--企业号 必传
                             strWarehouseNo  in wms_warehouse_outorder.warehouse_no%type, --仓别
                             strOwnerNo      in wms_warehouse_outorder.owner_no%type, --委托业主
                             strExpType      in wms_warehouse_outorder.exp_type%type, --单据类型 必传
                             strColumnName   in varchar2, --需要取值的列名
                             strColumnValue  out varchar2, --返回列名的值
                             strOutMsg       out varchar2);

  /*==============================================出货公用方法 end=============================================*/



  /*==============================================返配公用方法 begin=============================================*/

  /*=====================================================================================
  hb 20160804
  取返配类型策略信息
  ======================================================================================*/
  PROCEDURE p_GetRIdataOrder(strEnterPriseNo in wms_warehouse_riordertype.enterprise_no%type,--企业号 必传
                             strWarehouseNo  in wms_warehouse_riordertype.warehouse_no%type, --仓别
                             strOwnerNo      in wms_warehouse_riordertype.owner_no%type, --委托业主
                             strUntreadType  in wms_warehouse_riordertype.untread_type%type, --单据类型 必传
                             strClassType    in wms_warehouse_riordertype.class_type%type, --必传
                             strQualityFlag  in wms_warehouse_riordertype.quality_flag%type, --必传
                             strColumnName   in varchar2, --需要取值的列名
                             strColumnValue  out varchar2, --返回列名的值
                             strOutMsg       out varchar2);


 /*==============================================返配公用方法 end=============================================*/


end PKLG_WMS_Public;


/

