create trigger TRG_INS_BDEF_DEFLOC
    before insert
    on BDEF_DEFLOC
    for each row
declare
  strUpFlag varchar2(1);
  strEnterpriseNO varchar2(20);
  i_id number(18);
  v_enterpriseKey varchar2(64);
  v_interfaceKey varchar2(64);
  v_operateType varchar2(2);
begin
   --查看是否需要上传

   --新增容器资料
      insert into wms_defcontainer(warehouse_no,container_type,container_prefix,length,width,height,use_type,
      label_prefix,container_material,rgst_name,rgst_date,enterprise_no)
      values(:new.warehouse_no,'B','BS',38,31,31,'0','B','11','admin',sysdate,:new.enterprise_no);
      insert into wms_defcontainer(warehouse_no,container_type,container_prefix,length,width,height,use_type,
      label_prefix,container_material,rgst_name,rgst_date,enterprise_no)
      values(:new.warehouse_no,'B','BS',38,31,31,'1','B','11','admin',sysdate,:new.enterprise_no);
      insert into wms_defcontainer(warehouse_no,container_type,container_prefix,length,width,height,use_type,
      label_prefix,container_material,rgst_name,rgst_date,enterprise_no)
      values(:new.warehouse_no,'B','BS',38,31,31,'2','B','11','admin',sysdate,:new.enterprise_no);
      insert into wms_defcontainer(warehouse_no,container_type,container_prefix,length,width,height,use_type,
      label_prefix,container_material,rgst_name,rgst_date,enterprise_no)
      values(:new.warehouse_no,'P','PS',38,31,31,'0','P','31','admin',sysdate,:new.enterprise_no);
      insert into wms_defcontainer(warehouse_no,container_type,container_prefix,length,width,height,use_type,
      label_prefix,container_material,rgst_name,rgst_date,enterprise_no)
      values(:new.warehouse_no,'P','PS',38,31,31,'1','P','31','admin',sysdate,:new.enterprise_no);
      insert into wms_defcontainer(warehouse_no,container_type,container_prefix,length,width,height,use_type,
      label_prefix,container_material,rgst_name,rgst_date,enterprise_no)
      values(:new.warehouse_no,'P','PS',38,31,31,'2','P','31','admin',sysdate,:new.enterprise_no);

    --新增预约时间段
      insert into DOCK_SHEET (enterprise_no,Warehouse_No,start_time, end_time, rgst_name)
      values (:new.enterprise_no,:new.warehouse_no,'08:00', '08:59', 'admin');
      insert into DOCK_SHEET (enterprise_no,Warehouse_No,start_time, end_time, rgst_name)
      values (:new.enterprise_no,:new.warehouse_no,'09:00', '09:59', 'admin');
      insert into DOCK_SHEET (enterprise_no,Warehouse_No,start_time, end_time, rgst_name)
      values (:new.enterprise_no,:new.warehouse_no,'10:00', '10:59', 'admin');
      insert into DOCK_SHEET (enterprise_no,Warehouse_No,start_time, end_time, rgst_name)
      values (:new.enterprise_no,:new.warehouse_no,'11:00', '11:59',  'admin');
      insert into DOCK_SHEET (enterprise_no,Warehouse_No,start_time, end_time, rgst_name)
      values (:new.enterprise_no,:new.warehouse_no,'12:00', '12:59',  'admin');
      insert into DOCK_SHEET (enterprise_no,Warehouse_No,start_time, end_time, rgst_name)
      values (:new.enterprise_no,:new.warehouse_no,'13:00', '13:59', 'admin');
      insert into DOCK_SHEET (enterprise_no,Warehouse_No,start_time, end_time, rgst_name)
      values (:new.enterprise_no,:new.warehouse_no,'14:00', '14:59', 'admin');
      insert into DOCK_SHEET (enterprise_no,Warehouse_No,start_time, end_time, rgst_name)
      values (:new.enterprise_no,:new.warehouse_no,'15:00', '15:59','admin');
      insert into DOCK_SHEET (enterprise_no,Warehouse_No,start_time, end_time, rgst_name)
      values (:new.enterprise_no,:new.warehouse_no,'16:00', '16:59', 'admin');
      insert into DOCK_SHEET (enterprise_no,Warehouse_No,start_time, end_time, rgst_name)
      values (:new.enterprise_no,:new.warehouse_no,'17:00', '17:59', 'admin');
      insert into DOCK_SHEET (enterprise_no,Warehouse_No,start_time, end_time, rgst_name)
      values (:new.enterprise_no,:new.warehouse_no,'18:00', '18:59','admin');
      insert into DOCK_SHEET (enterprise_no,Warehouse_No,start_time, end_time, rgst_name)
      values (:new.enterprise_no,:new.warehouse_no,'19:00', '19:59', 'admin');
      insert into DOCK_SHEET (enterprise_no,Warehouse_No,start_time, end_time, rgst_name)
      values (:new.enterprise_no,:new.warehouse_no,'20:00', '20:59', 'admin');
      insert into DOCK_SHEET (enterprise_no,Warehouse_No,start_time, end_time, rgst_name)
      values (:new.enterprise_no,:new.warehouse_no,'21:00', '21:59', 'admin');
      insert into DOCK_SHEET (enterprise_no,Warehouse_No,start_time, end_time, rgst_name)
      values (:new.enterprise_no,:new.warehouse_no,'22:00', '23:00','admin');


      insert into WMS_ALLOT_ORDER ( ENTERPRISE_NO,WAREHOUSE_NO, OUTSTOCK_TYPE, OPERATE_TYPE, ALLOT_ORDER, SORT_ORDER, SORT_CONDITION,
      SORT_TYPE, RGST_NAME, RGST_DATE)
      values (:new.enterprise_no,:new.warehouse_no, 'OE', 'C', 1, 3, 'CUST_NO', 'DESC', 'admin', sysdate);
      insert into WMS_ALLOT_ORDER ( ENTERPRISE_NO,WAREHOUSE_NO, OUTSTOCK_TYPE, OPERATE_TYPE, ALLOT_ORDER, SORT_ORDER, SORT_CONDITION,
      SORT_TYPE, RGST_NAME, RGST_DATE)
      values (:new.enterprise_no,:new.warehouse_no, 'OE', 'C', 2, 1, 'TOTAL_QTY', 'DESC', 'admin', sysdate);
      insert into WMS_ALLOT_ORDER ( ENTERPRISE_NO,WAREHOUSE_NO, OUTSTOCK_TYPE, OPERATE_TYPE, ALLOT_ORDER, SORT_ORDER, SORT_CONDITION,
      SORT_TYPE, RGST_NAME, RGST_DATE)
      values (:new.enterprise_no,:new.warehouse_no, 'OE', 'C', 2, 2, 'LEFT_QTY', 'DESC', 'admin', sysdate);

      insert into WMS_ALLOT_ORDER ( ENTERPRISE_NO,WAREHOUSE_NO, OUTSTOCK_TYPE, OPERATE_TYPE, ALLOT_ORDER, SORT_ORDER, SORT_CONDITION,
      SORT_TYPE, RGST_NAME, RGST_DATE)
      values (:new.enterprise_no,:new.warehouse_no, 'ID', 'C', 1, 3, 'CUST_NO', 'DESC', 'admin', sysdate);
      insert into WMS_ALLOT_ORDER ( ENTERPRISE_NO,WAREHOUSE_NO, OUTSTOCK_TYPE, OPERATE_TYPE, ALLOT_ORDER, SORT_ORDER, SORT_CONDITION,
      SORT_TYPE, RGST_NAME, RGST_DATE)
      values (:new.enterprise_no,:new.warehouse_no, 'ID', 'C', 2, 1, 'TOTAL_QTY', 'DESC', 'admin', sysdate);
      insert into WMS_ALLOT_ORDER ( ENTERPRISE_NO,WAREHOUSE_NO, OUTSTOCK_TYPE, OPERATE_TYPE, ALLOT_ORDER, SORT_ORDER, SORT_CONDITION,
      SORT_TYPE, RGST_NAME, RGST_DATE)
      values (:new.enterprise_no,:new.warehouse_no, 'ID', 'C', 2, 2, 'LEFT_QTY', 'DESC', 'admin', sysdate);

      insert into WMS_ALLOT_RULE (ENTERPRISE_NO,WAREHOUSE_NO, OUTSTOCK_TYPE, OPERATE_TYPE, ALLOT_ORDER, ALLOT_TYPE, PRIO_TYPE, PRIO_LEVEL,
      HAND_TYPE, VALUE, RGST_NAME, RGST_DATE)
      values (:new.enterprise_no,:new.warehouse_no, 'ID', 'C', 1, 'RATE', 'QTY_RATE', -1, 'ROUND_1', 50, 'admin', sysdate);
      insert into WMS_ALLOT_RULE (ENTERPRISE_NO,WAREHOUSE_NO, OUTSTOCK_TYPE, OPERATE_TYPE, ALLOT_ORDER, ALLOT_TYPE, PRIO_TYPE, PRIO_LEVEL,
      HAND_TYPE, VALUE, RGST_NAME, RGST_DATE)
      values (:new.enterprise_no,:new.warehouse_no, 'ID', 'C', 2, 'PRIO', 'NORMAL', -1, 'CIRCLE', 50, 'admin', sysdate);
      insert into WMS_ALLOT_RULE (ENTERPRISE_NO,WAREHOUSE_NO, OUTSTOCK_TYPE, OPERATE_TYPE, ALLOT_ORDER, ALLOT_TYPE, PRIO_TYPE, PRIO_LEVEL,
      HAND_TYPE, VALUE, RGST_NAME, RGST_DATE)
      values (:new.enterprise_no,:new.warehouse_no, 'OE', 'C', 1, 'RATE', null, -1, 'ROUND_1', 50, 'admin', sysdate);
      insert into WMS_ALLOT_RULE (ENTERPRISE_NO,WAREHOUSE_NO, OUTSTOCK_TYPE, OPERATE_TYPE, ALLOT_ORDER, ALLOT_TYPE, PRIO_TYPE, PRIO_LEVEL,
      HAND_TYPE, VALUE, RGST_NAME, RGST_DATE)
      values (:new.enterprise_no,:new.warehouse_no, 'OE', 'C', 2, 'PRIO', 'NORMAL', -1, 'ALL', 50,'admin', sysdate);

      insert into bset_worker_loc(enterprise_no,warehouse_no,worker_no,rgst_name,rgst_date)
      values(:new.enterprise_no,:new.warehouse_no,'admin','admin',sysdate);

     /* insert into bset_user_role(enterprise_no,worker_no,role_id,rgst_name,rgst_date)
      values(:new.enterprise_no,'admin','61','admin',sysdate);*/
end;


/

