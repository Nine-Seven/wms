create package PKLG_ODATA_CHECK is
  /*************************************************************************************
  /*复核逻辑包
  luozhiling
  2016.9.27
  ************************************************************************************************/
  /*****************************************************************************************
   功能：用于电商复核打包的取标签号（电商特殊功能，一复核单对应多个配送对象，按复核标签明细的信息产生标签号

  20160605
  *****************************************************************************************/

  procedure P_DeliverObjLableNo(strEnterpriseNo  in stock_label_m.enterprise_no%type,
                                strWarehouseNo   in stock_label_m.warehouse_no%type, --仓别
                                strCheckNo       in stock_label_m.label_no%type, --源容器号
                                strDeliverObj    in stock_label_m.deliver_obj%type,
                                strContainerType in stock_label_m.container_type%type, ----P：栈板；B物流箱
                                strUserId        in bdef_defworker.worker_no%type,
                                strResult        out varchar2);
  /*****************************************************************************************
  出货整理打包》源标签号检验
  Modify By lich AT 2014-11-10
  *****************************************************************************************/
  procedure p_check_SLabelNo(strEnterpriseNo in stock_label_m.enterprise_no%type,
                             strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                             strLabelNo      in stock_label_m.label_no%type, --源容器号
                             strResult       out varchar2);
  /***********************************************************************************************
   功能说明 ：
            根据任务号或者箱号写复核单，目前用于电商的复核

  ***********************************************************************************************/

  procedure p_creat_odata_check(strEnterpriseNo in odata_check_m.enterprise_no%type,
                                strWareHouseNo  in odata_check_m.warehouse_no%type,
                                strCheckChuteNo in odata_check_m.check_chute_no%type, --复核台滑道号
                                strTaksNo       in stock_label_m.source_no%type, --任务号，没有则传N
                                --strBoxNo        in stock_label_m.label_no%type, --箱号/ 快递单号
                                strCheckType in varchar2, --复核类型：1:按任务复核或按箱号,2:快递单号复核
                                strUserId    in odata_check_m.rgst_name%type,
                                strCheckNo   out odata_check_m.check_no%type,
                                strResult    out varchar2);

  /***********************************************************************************************
   功能说明 ：
            根据任务号或者箱号写复核单，目前用于电商的复核

  ***********************************************************************************************/
  procedure P_CheckAndCreate(strEnterpriseNo in odata_check_m.enterprise_no%type,
                             strWareHouseNo  in odata_check_m.warehouse_no%type,
                             strCheckChuteNo in odata_check_m.check_chute_no%type, --复核台滑道号
                             strTaksNo       in stock_label_m.source_no%type, --任务号，没有则传N
                             strBoxNo        in stock_label_m.label_no%type, --箱号/ 快递单号
                             strCheckType    in varchar2, --复核类型：1:按任务复核\按箱号；2：快递单号复核
                             strUserId       in odata_check_m.rgst_name%type,
                             strAutoOutstock in varchar2, --是否可自动下架回单:Y-可以,N-不可以
                             strCheckNo      out odata_check_m.check_no%type,
                             strResult       out varchar2);

  /*****************************************************************************************
  根据箱号号写复核单数据
  chensr  2015.4.27
  *****************************************************************************************/
  procedure p_creat_odata_check_by_label(strEnterpriseNo in odata_check_m.enterprise_no%type,
                                         strWareHouseNo  in odata_check_m.warehouse_no%type,
                                         strLabelNo      in stock_label_m.label_no%type, --箱号号
                                         strCheckChuteNo in odata_check_m.check_chute_no%type, --复核台滑道号
                                         strUserId       in odata_check_m.rgst_name%type,
                                         strResult       out varchar2);

  /************************************************************************************************
  功能说明：复核单校验：
           1、支持按任务号校验；
           2、支持按箱号校验
  ************************************************************************************************/
  procedure P_TaskAndBoxCheck(strEnterpriseNo in odata_check_m.enterprise_no%type,
                              strWareHouseNo  in odata_check_m.warehouse_no%type,
                              strCheckChuteNo in odata_check_m.check_chute_no%type, --复核台滑道号
                              strTaksNo       in stock_label_m.source_no%type, --任务号，没有则传N
                              strBoxNo        in stock_label_m.label_no%type, --箱号/ 快递单号
                              strCheckType    in varchar2, --复核类型：1:按任务复核；2：按箱号或快递单号复核
                              strCheckNo      out odata_check_m.check_no%type,
                              strResult       out varchar2);
  /***********************************************************************************************
   --扫描商品条码-整理容器（电商）
   功能说明：根据复核单里的商品进行复核，需循环按商品抓取标签号再进行处理
   chensr
   2015.5.5
  ***********************************************************************************************/
  procedure P_CheckArticle(strEnterpriseNo in odata_check_m.enterprise_no%type,
                           strWareHouseNo  in odata_check_m.warehouse_no%type,
                           strCheckNo      in odata_check_m.check_no%type,
                           strDeliverObj   in odata_check_m.deliver_obj%type,
                           strArticle_No   in odata_check_d.article_no%type, --商品编码
                           nPacking_QTY    in odata_check_d.packing_qty%type, --包装数量
                           strQuality      in stock_article_info.quality%type, --品质
                           dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                           dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                           strLotNo        in stock_article_info.lot_no%type, --批次号
                           strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                           strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                           strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                           strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                           strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                           strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                           strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                           strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                           strBarcode      in stock_article_info.barcode%type,
                           strsLabelNo     in stock_label_m.label_no%type,
                           strDLabelNo     in stock_label_m.label_no%type, --目的标签
                           nRealQty        in odata_check_d.real_qty%type, --回单数量
                           strUserId       in odata_check_m.rgst_name%type,
                           strResult       out varchar2);

  /**************************************************************************************************
  功能说明：复核转病单
  luozhiling
  2015.5.5
  **************************************************************************************************/
  procedure P_DiffCheckSave(strEnterpriseNo in odata_check_m.enterprise_no%type,
                            strWareHouseNo  in odata_check_m.warehouse_no%type,
                            strCheckNo      in odata_check_m.check_no%type,
                            strDeliverObj   in odata_check_m.deliver_obj%type,
                            strUserId       in odata_check_m.updt_name%type,
                            strResult       out varchar2);

  /***********************************************************************************************
   --扫描商品条码-整理容器（电商）--自动封箱，转病单
   功能说明：按复核单上的商品进行复核
   chensr
   2015.5.5
   功能描述：1、根据条码取订单；
             2、若此订单未产生复核标签，新取号
             3、若此订单已有复核标签，复核保存
             4、若整订单扫描完成，自动封箱

  ***********************************************************************************************/
  procedure p_scanArticle_cutBox_sickOrder(strEnterpriseNo  in odata_check_m.enterprise_no%type,
                                           strWareHouseNo   in odata_check_m.warehouse_no%type,
                                           strCheckNo       in odata_check_m.check_no%type,
                                           strTaksNo        in stock_label_m.source_no%type, --任务号或快递单号
                                           strDeliverObj    in odata_check_m.deliver_obj%type, --第一次传N，后面用返回的值
                                           strArticle_No    in odata_check_d.article_no%type, --商品编码
                                           nRealQty         in odata_check_d.real_qty%type, --回单数量
                                           strUserId        in odata_check_m.rgst_name%type,
                                           strDockNo        in ridata_check_m.dock_no%type,
                                           strPrintWayBill  in odata_outstock_m.task_type%type, --是否打印快递面单，0：不打印，1：打印
                                           strPrintPackList in odata_outstock_m.task_type%type, --是否打印装箱清单，0：不打印，1：打印
                                           strPrintInVoice  in odata_outstock_m.task_type%type, --是否打印发票，0：不打印，1：打印
                                           strCheckType     in varchar2, --复核类型：1:按任务复核或箱号；2：快递单号复核
                                           strCloseFlag     out varchar2, --复核完成标识，'Y' 完成；‘N'未完成
                                           strOutDeliverObj out stock_label_m.deliver_obj%type,
                                           strOutLabelNo    out stock_label_m.label_no%type,
                                           strPackMateMsg   out bdef_defarticle.article_name%type, --提示的包材名称
                                           strOutFinishFlag out varchar2, --复核完成标识，'Y' 完成；‘N'未完成
                                           strResult        out varchar2);

  /*订单取消*/
  procedure p_OrderCancel(strEnterpriseNo in odata_check_m.enterprise_no%type,
                          strWareHouseNo  in odata_check_m.warehouse_no%type,
                          strCheckNo      in odata_check_m.check_no%type, --复核单号
                          strSource_No    in odata_exp_m.shipper_deliver_no%type, --面单号或原订单号
                          strCheckType    in varchar2, --复核类型：1:按原订单号；2：快递单号复核
                          strUserID       in odata_check_m.rgst_name%type,
                          strResult       out varchar2);
  /***********************************************************************************************
   对转病单的标签进行解锁
   chensr
   2015.5.5
  ***********************************************************************************************/
  procedure P_UnlockLabel(strEnterpriseNo in stock_label_m.Enterprise_No%type,
                          strWarehouseNo  in stock_label_m.Warehouse_No%type,
                          strDeliverObj   in stock_label_m.source_no%type,
                          strWorkerNo     in stock_label_m.rgst_name%type,
                          strResult       out varchar2);

  /*****************************************************************************************
   功能：出货整理扫描条码保存商品(根据箱号)
  chensr 2015-06-26
  *****************************************************************************************/
  procedure P_scanArticle_by_labelNo(strEnterpriseNo in odata_check_m.enterprise_no%type,
                                     strWareHouseNo  in odata_check_m.warehouse_no%type,
                                     strCheckNo      in odata_check_m.check_no%type,
                                     strArticle_No   in odata_check_d.article_no%type, --商品编码
                                     nPacking_QTY    in odata_check_d.packing_qty%type, --包装数量
                                     strQuality      in stock_article_info.quality%type, --品质
                                     dtProduceDate   in stock_article_info.produce_date%type, --生产日期
                                     dtExpireDate    in stock_article_info.expire_date%type, --到期日期
                                     strLotNo        in stock_article_info.lot_no%type, --批次号
                                     strRSV_BATCH1   in stock_article_info.rsv_batch1%type, --预留批属性1
                                     strRSV_BATCH2   in stock_article_info.rsv_batch2%type, --预留批属性2
                                     strRSV_BATCH3   in stock_article_info.rsv_batch3%type, --预留批属性3
                                     strRSV_BATCH4   in stock_article_info.rsv_batch4%type, --预留批属性4
                                     strRSV_BATCH5   in stock_article_info.rsv_batch5%type, --预留批属性5
                                     strRSV_BATCH6   in stock_article_info.rsv_batch6%type, --预留批属性6
                                     strRSV_BATCH7   in stock_article_info.rsv_batch7%type, --预留批属性7
                                     strRSV_BATCH8   in stock_article_info.rsv_batch8%type, --预留批属性8
                                     strBarcode      in stock_article_info.barcode%type,
                                     strsLabelNo     in stock_label_m.label_no%type, --来源标签
                                     strDLabelNo     in stock_label_m.label_no%type, --目的标签
                                     nRealQty        in odata_check_d.real_qty%type, --回单数量
                                     strUserId       in odata_check_m.rgst_name%type,
                                     strDockNo       in bdef_defdock.dock_no%type,
                                     strResult       out varchar2);
  /*****************************************************************************************
    功能：取消扫描、
    201511.05
  *****************************************************************************************/
  procedure p_CancelScanLabel(strEnterPriseNo in stock_label_m.enterprise_no%type,
                              strWareHouseNo  in stock_label_m.warehouse_no%type, --仓别
                              strUserId       in stock_label_m.rgst_name%type, --封箱人
                              strCheckNo      in odata_check_m.check_no%type,
                              strLabelNo      in stock_label_m.label_no%type, --标签号
                              strResult       out varchar2);
  /*****************************************************************************************
    功能：复核封箱打标签（天天惠）
    20150703
    chensr
  *****************************************************************************************/
  procedure P_ODATA_CHECK_CUTBOX(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                 strWareHouseNo  in stock_label_m.warehouse_no%type, --仓别
                                 strUserId       in stock_label_m.rgst_name%type, --封箱人
                                 strLabelNo      in stock_label_m.label_no%type, --标签号
                                 strDockNo       in ridata_check_m.dock_no%type,
                                 strResult       out varchar2);

  /*****************************************************************************************
    功能：复核封箱
  *****************************************************************************************/
  procedure P_ODATA_CHECK_CLOSEBOX(strEnterPriseNo in stock_label_m.enterprise_no%type,
                                   strWareHouseNo  in stock_label_m.warehouse_no%type, --仓别
                                   strUserId       in stock_label_m.rgst_name%type, --封箱人
                                   strLabelNo      in stock_label_m.label_no%type, --标签号
                                   --strPrinterGroupNo in ridata_check_m.printer_group_no%type,
                                   strResult out varchar2);

  /*****************************************************************************************
    功能：复核封箱
  *****************************************************************************************/
  procedure P_CLOSEBOX(strEnterPriseNo in stock_label_m.enterprise_no%type,
                       strWareHouseNo  in stock_label_m.warehouse_no%type, --仓别
                       strUserId       in stock_label_m.rgst_name%type, --封箱人
                       strLabelNo      in stock_label_m.label_no%type, --标签号
                       strResult       out varchar2);

  /*****************************************************************************************
    功能：复核封箱回单（天天惠）
    20151010
    chensr
  *****************************************************************************************/
  procedure P_PROC_Receipt(strEnterPriseNo in stock_label_m.enterprise_no%type,
                           strWareHouseNo  in stock_label_m.warehouse_no%type, --仓别
                           strCheckNo      in odata_check_m.check_no%type,
                           strResult       out varchar2);
  /*=====================================================================================
  功能说明：包材处理
           1、根据快递面单写库存调帐单；
           2、根据库存调帐单定位并回单；

  ======================================================================================*/
  PROCEDURE P_strPackMateDeal(strEnterpriseNo in STOCK_LABEL_M.enterprise_no%type, --企业号
                              strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                              strLabelNo      in stock_label_m.label_no%type, --快递面单，电商的快递面单等于标签
                              strArticlNo     in stock_label_d.article_no%type, --包材编码=商品编码
                              nRealQty        in stock_content.qty%type, --包材出货数量
                              strUserId       in stock_label_m.rgst_name%type, --操作人员
                              strOutMsg       out varchar2);

  /*=====================================================================================
  外复核--检查待复核板标签是否能复核
  huangb 20161123
  ======================================================================================*/
  PROCEDURE P_RecheckExistsLabelNo(strEnterpriseNo in STOCK_LABEL_M.enterprise_no%type, --企业号
                                   strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                                   strLabelNo      in stock_label_m.label_no%type, --待复核标签
                                   strOutMsg       out varchar2);

  /*=====================================================================================
  外复核--新增外复核单据信息
  huangb 20161126
  ======================================================================================*/
  PROCEDURE P_InsertRecheckOrder(strEnterpriseNo in STOCK_LABEL_M.enterprise_no%type, --企业号
                                 strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                                 strLabelNo      in stock_label_m.label_no%type, --待复核标签
                                 strUserId       in odata_recheck_m.rgst_name%type, --操作人员
                                 strOutRecheckNo out odata_recheck_m.recheck_no%type, --返回外复核单号
                                 strOutMsg       out varchar2);

  /**********************************************************************************************
  功能说明：校验此标签是否可做外复核扫描
  1、不可直接扫主标签复核；
  2、校验子标签是否存在此单；
  luozhiling
  2016.11.25
  ***********************************************************************************************/
   procedure P_CheckArticleAndLabelNo(strEnterpriseNo in odata_recheck_m.enterprise_no%type,
                           strWareHouseNo  in odata_recheck_m.warehouse_no%type,
                           strReCheckNo    in odata_recheck_m.recheck_no%type,
                           strLabelNo      in odata_recheck_d.label_no%type, --主标签
                           strSubLabelNo   in odata_recheck_d.sub_label_no%type,--子标签
                           strResult       out varchar2);

  /***********************************************************************************************
   功能说明:外复核回单，有两种类型：
   1、扫描外箱码循环累加复核数量，对于拆零扫描拆零标签，直接根据标签明细抓取商品信息进行复核回单
   2、扫描商品条码输入复核数量；
   本功能适用于按商品和数量进行回单
     luozhiling
   2016.11.24
  ***********************************************************************************************/
  procedure P_SaveCheckFromArticle(strEnterpriseNo in odata_recheck_m.enterprise_no%type,
                           strWareHouseNo          in odata_recheck_m.warehouse_no%type,
                           strReCheckNo            in odata_recheck_m.recheck_no%type,
                           strArticle_No           in odata_recheck_d.article_no%type, --商品编码
                           nPacking_QTY            in odata_recheck_d.packing_qty%type, --包装数量
                           strLabelNo              in odata_recheck_d.label_no%type,--标签
                           strSubLabelNo           in odata_recheck_d.sub_label_no%type,--子标签--
                           nRealQty                in odata_recheck_d.real_qty%type, --回单数量
                           strUserId               in odata_recheck_d.rgst_name%type,
                           strResult               out varchar2);

  /*************************************************************************************************8
  功能说明：扫描标签进行复核回单，首先根据标签查询标签表数据，若查询到数据，根据标签明细写外复核明显，
            若找不到,查询条码表是否有此扫描数据，若有根据条码对应的数量进行外复核回单。
  luozhiling
  2016.11.24
  *************************************************************************************************/
  procedure P_SaveLabelItem(strEnterpriseNo in odata_recheck_m.enterprise_no%type,
                           strWareHouseNo   in odata_recheck_m.warehouse_no%type,
                           strReCheckNo     in odata_recheck_m.recheck_no%type,
                           strLabelNo       in odata_recheck_d.label_no%type,
                           strSubLabelNo    in odata_recheck_d.sub_label_no%type,
                           strUserId        in odata_recheck_d.rgst_name%type,
                           strResult        out varchar2);

  /*=====================================================================================
  外复核--称重保存
  huangb 20161126
  ======================================================================================*/
  PROCEDURE P_SaveRecheckWeight(strEnterpriseNo in STOCK_LABEL_M.enterprise_no%type, --企业号
                                strWarehouseNo  in stock_label_m.warehouse_no%type, --仓别
                                strLabelNo      in stock_label_m.label_no%type, --称重标签
                                nWeight         in stock_label_m.weight%type, --重量
                                strUserId       in odata_recheck_m.rgst_name%type, --操作人员
                                strOutMsg       out varchar2);

end PKLG_ODATA_CHECK;


/

