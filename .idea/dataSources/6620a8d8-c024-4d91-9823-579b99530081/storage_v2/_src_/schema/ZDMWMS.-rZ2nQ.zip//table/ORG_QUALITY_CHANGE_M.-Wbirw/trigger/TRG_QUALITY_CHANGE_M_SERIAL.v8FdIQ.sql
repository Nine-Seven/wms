create trigger TRG_QUALITY_CHANGE_M_SERIAL
    before insert
    on ORG_QUALITY_CHANGE_M
    for each row
declare
  i_report_up_SERIAL NUMBER;
begin
  select SEQ_ORG_QUALITY_CHANGE_M.NEXTVAL into i_report_up_SERIAL from dual;
  :NEW.REPORT_UP_SERIAL := i_report_up_SERIAL;
end TRG_QUALITY_CHANGE_M_SERIAL;


/

