create view V_CUST_LINE_BATCH_CYCLE as
SELECT v.ENTERPRISE_NO,v.WAREHOUSE_NO,v.WEEK_NO,MAX (v.LINE_NO) LINE_NO,
       v.BATCH_NO,bdc.OWNER_NO,v.CUST_NO,
       MAX (LINE_SEQ_NO) LINE_SEQ_NO,
       MAX (DISTANCE) DISTANCE,
       MAX (v.CHARGE) CHARGE,
       MAX (v.TOLL_NO_ARRAY) TOLL_NO_ARRAY,
       MAX (v.SPEED_LIMIT) SPEED_LIMIT,
       b.batch_name
FROM (SELECT ENTERPRISE_NO, WAREHOUSE_NO, week_no, line_no, batch_no,
         cust_no, line_seq_no, distance, charge,
         toll_no_array, speed_limit
      FROM OSET_LINE_CYCLE_CUST_CHUTE
      UNION ALL
      SELECT ENTERPRISE_NO, WAREHOUSE_NO, week_no, line_no, batch_no,
          cust_no, line_seq_no, distance, charge,
          toll_no_array, speed_limit
      FROM OSET_line_cycle_cust
      UNION ALL
      SELECT ENTERPRISE_NO, WAREHOUSE_NO, NULL as week_no, line_no, batch_no,
          cust_no, line_seq_no, distance, charge,
          toll_no_array, speed_limit
      FROM OSET_line_batch_cust
      UNION ALL
      SELECT ENTERPRISE_NO, WAREHOUSE_NO, NULL as week_no, line_no, NULL as batch_no,
          cust_no, line_seq_no, distance, charge,
          toll_no_array, speed_limit
      FROM OSET_line_cust) v
            INNER JOIN bdef_defcust bdc
               ON v.cust_no = bdc.cust_no
            LEFT JOIN OSET_defbatch b
               ON v.WAREHOUSE_NO = b.WAREHOUSE_NO AND v.batch_no = b.batch_no AND v.ENTERPRISE_NO=b.ENTERPRISE_NO
   GROUP BY v.ENTERPRISE_NO,
            v.WAREHOUSE_NO,
            v.WEEK_NO,
            v.BATCH_NO,
            bdc.OWNER_NO,
            v.CUST_NO,
            b.batch_name


/

