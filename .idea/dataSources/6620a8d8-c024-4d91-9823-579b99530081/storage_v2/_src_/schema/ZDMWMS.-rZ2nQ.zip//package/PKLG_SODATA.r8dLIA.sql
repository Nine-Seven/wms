create package        PKLG_SODATA is
  /***********************************************************************************************************
   创建人：luozhiling
   时间：2015.7.27
   功能：报损手建单
  ***********************************************************************************************************/
  procedure P_CreatePlan(strEnterPriseNo in sodata_waste_m.enterprise_no%type,
                         strWareHouseNo  in sodata_waste_m.warehouse_no%type, --仓库编码
                         strOwnerNo      in sodata_waste_m.owner_no%type,
                         strUserId       in sodata_waste_m.rgst_name%type,
                         strCreateFlag   in sodata_waste_m.create_flag%type, --
                         strStockType   in sodata_waste_m.stock_type%type,
                         strStockValue  in sodata_waste_m.stock_value%type,
                         strOrgNo       in sodata_waste_m.org_no%type,
                         strArticleNo    in sodata_waste_d.article_no%type, --商品编码
                         nPackingQty     in sodata_waste_d.packing_qty%type,
                         strLotNo        in sodata_waste_d.lot_no%type,
                         nPlanQty        in sodata_waste_d.waste_qty%type, --计划报损量
                         strsWasteNo     in sodata_waste_d.waste_no%type, --原计划单号
                         strWasteNo       out sodata_waste_d.waste_no%type, --返回的计划单号
                         strResult       OUT varchar2);
  /*****************************************************************************************************
   功能说明：报损定位
   2015.7.27
  *****************************************************************************************************/
  procedure P_solocate_main(strEnterPriseNo in sodata_waste_m.enterprise_no%type,
                             strWareHouseNo  in sodata_waste_m.warehouse_no%type, --仓库编码
                             strOwnerNo      in sodata_waste_m.owner_no%type,
                             strWasteNo      in sodata_waste_m.waste_no%type,
                             strUserId       in sodata_waste_m.rgst_name%type,
                             strResult       OUT varchar2);

  /*******************************************************************************************************
  功能说明：报损拣货单发单
  1、一张报损单产生一张拣货单；
  2015.7.27
  *******************************************************************************************************/
  procedure P_GetTaskWaste(strEnterPriseNo in sodata_outstock_m.enterprise_no%type,
                          strWarehose_No   in sodata_outstock_m.warehouse_no%type,
                          strOwnerNo       in sodata_outstock_m.owner_no%type,
                          strWasteNo        in sodata_outstock_direct.source_no%type,
                          strUserID        in bdef_defworker.worker_no%type,
                          strDockNo        in bdef_defdock.dock_no%type,
                          strPrintFlag     in job_printtask_m.back_flag%type,--是否打印，0：表示不打印；1：表示打印
                          strOutMsg        out varchar2);
  /***********************************************************************************************8
  功能说明：按商品明细做拣货回单
           步骤：1、更新拣货明细；
                 2、更新库存；
  ************************************************************************************************/
  procedure P_SaveOutstock(strEnterPriseNo in sodata_outstock_m.enterprise_no%type,
                            strWarehose_No in sodata_outstock_m.warehouse_no%type,
                            strOwnerNo     in sodata_outstock_m.owner_no%type,
                            strOutStockNo  in sodata_outstock_d.outstock_no%type,
                            strArticleNo   in sodata_outstock_d.article_no%type,
                            nPackingQTY    in sodata_outstock_d.packing_qty%type,
                            strScellNo     in sodata_outstock_d.s_cell_no%type,
                            nRealQTY       in sodata_outstock_d.real_qty%type,
                            strOutUserID   in sodata_outstock_d.outstock_name%type,
                            strUserID      in sodata_outstock_d.assign_name%type,
                            strTERMINAL_FLAG  in stock_content_move.terminal_flag%type,
                            strDockNo        in bdef_defdock.dock_no%type,
                            strPrintFlag     in job_printtask_m.back_flag%type,--是否打印，0：表示不打印；1：表示打印
                            strOutMsg      out varchar2);
/*******************************************************************************************************
 创建人：czh
 时间:2016.5.25
 功能：报损手建单取消
********************************************************************************************************/
  procedure P_WasteCancel(strEnterPriseNo           in    sodata_waste_d.enterprise_no%type,
                         strWareHouseNo            in    sodata_waste_d.warehouse_no%type,--仓库编码
                         strOwnerNo                in    sodata_waste_m.owner_no%type,
                         strWasteNo                 in   sodata_waste_d.waste_no%type,--报损头档
                         strUserId                 in   sodata_waste_m.rgst_name%type,
                         strResult                 OUT    varchar2);
  /*****************************************************************************************************
   功能说明：1、对报损单进行定位；
             2、对报损单对应的下架指示进行发单；
             3、拣货回单；
             4、整单做报损确认（回写实际报损数量,并删除WMS库存，库存三级帐
             此功能需按单处理，所有的定位、发单、回单都是按报损单操作，并且一一对应。
   2015.7.27
  *****************************************************************************************************/
  procedure P_SaveConfirm(strEnterPriseNo in sodata_waste_m.enterprise_no%type,
                           strWareHouseNo  in sodata_waste_m.warehouse_no%type, --仓库编码
                           strOwnerNo      in sodata_waste_m.owner_no%type,
                           strWasteNo      in sodata_waste_m.waste_no%type,
                           strDockNo        in bdef_defdock.dock_no%type,
                           strPrintFlag     in job_printtask_m.back_flag%type,--是否打印，0：表示不打印；1：表示打印
                           strUserId       in sodata_waste_m.rgst_name%type,
                           strResult       OUT varchar2);

  /********************************************************************************************************
  功能说明：按报损计划单进行定位并发单
  2015.11.13
  ********************************************************************************************************/
  procedure P_LocateAndGetTask(strEnterPriseNo in sodata_waste_m.enterprise_no%type,
                             strWareHouseNo  in sodata_waste_m.warehouse_no%type, --仓库编码
                             strOwnerNo      in sodata_waste_m.owner_no%type,
                             strWasteNo      in sodata_waste_m.waste_no%type,
                             strUserId       in sodata_waste_m.rgst_name%type,
                             strDockNo        in bdef_defdock.dock_no%type,
                             strPrintFlag     in job_printtask_m.back_flag%type,--是否打印，0：表示不打印；1：表示打印
                             strResult       OUT varchar2);

 /********************************************************************************
   huangb 20150511
   功能说明：根据报损类型配置的策略对保存单单进行定位
  ********************************************************************************/
  PROCEDURE P_SODATA_LOCATE(strEnterPriseNo in sodata_waste_m.enterprise_no%type,
                             strWareHouseNo  in sodata_waste_m.warehouse_no%type, --仓库编码
                             strOwnerNo      in sodata_waste_m.owner_no%type,
                             strWasteNo      in sodata_waste_m.waste_no%type,
                             strStrategyId   in wms_sodataorder.strategy_id%type,
                             strPackinglevel in wms_sodataorder.packinglevel%type,
                             strDestCellNo   in cdef_defcell.cell_no%type,
                             strUserId       in sodata_waste_m.rgst_name%type,
                             strResult       OUT varchar2);

 /**********************************************************************************************
  功能：写报损下架指示
    2015.7.27
  huangb 20160511 从PKOBJ_SODATA移至PKLG_SODATA包
  **********************************************************************************************/
  procedure P_InsertSodateDirect(strEnterPriseNo in sodata_waste_m.enterprise_no%type,
                                  strWareHouseNo  in sodata_waste_m.warehouse_no%type,
                                  strWasteNo      in sodata_waste_m.waste_no%type,
                                  strDestCellNo   in cdef_defcell.cell_no%type,
                                  strUserId       in sodata_waste_m.rgst_name%type,
                                  nPoID           in sodata_waste_d.po_id%type,
                                  strSql          in varchar2,
                                  nQty            in out sodata_waste_d.waste_qty%type,
                                  strResult       out varchar2);

end PKLG_SODATA;


/

