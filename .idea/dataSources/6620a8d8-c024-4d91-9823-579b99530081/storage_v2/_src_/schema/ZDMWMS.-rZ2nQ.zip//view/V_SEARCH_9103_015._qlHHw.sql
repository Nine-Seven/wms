create view V_SEARCH_9103_015 as
select "ENTERPRISE_NO","WAREHOUSE_NO","OWNER_NO","RGST_DATE","EXPNO","CUST_NO","CUST_NAME","LABEL_NO","ARTICLE_NO","ARTICLE_NAME","BARCODE","QTY"
  from (select m.enterprise_no,
               m.warehouse_no,
               m.owner_no,
               trunc(m.rgst_date) rgst_date,
               to_char(trunc(m.rgst_date), 'yymmdd') || d.label_no expno,
               m.cust_no,
               bc.cust_name,
               d.label_no,
               d.article_no,
               ba.article_name,
               ba.barcode,
               sum(d.qty) qty
          from odata_deliver_m m,
               odata_deliver_d d,
               bdef_defcust    bc,
               bdef_defarticle ba
         where m.enterprise_no = d.enterprise_no
           and m.warehouse_no = d.warehouse_no
           and m.owner_no = d.owner_no
           and m.deliver_no = d.deliver_no
           and m.cust_no = bc.cust_no
           and m.enterprise_no = bc.enterprise_no
           and m.owner_no = bc.owner_no
           and d.enterprise_no = ba.enterprise_no
           and d.owner_no = ba.owner_no
           and d.article_no = ba.article_no
        /*from stock_label_m           slm,
               stock_label_d           sld,
               bdef_defcust            bc,
               bdef_defarticle         ba,
               stock_label_arrange_log t
         where slm.enterprise_no = sld.enterprise_no
           and slm.container_no = sld.container_no
           and slm.enterprise_no = bc.enterprise_no
           and slm.cust_no = bc.cust_no
           and sld.article_no = ba.article_no
           and slm.enterprise_no = t.enterprise_no
           and slm.label_no = t.label_no
           and t.arrange_type = '4'
           and slm.use_type = 1
           and slm.status > '61'
           and slm.status not like 'F%'
         group by t.enterprise_no,
                  t.warehouse_no,
                  t.owner_no,
                  trunc(t.rgst_date),
                  slm.label_no,
                  slm.cust_no,
                  bc.cust_name,
                  sld.article_no,
                  ba.article_name,
                  ba.barcode
        union all
        select t.enterprise_no,
               t.warehouse_no,
               t.owner_no,
               trunc(t.rgst_date) rgst_date,
               to_char(trunc(t.rgst_date), 'yymmdd') || slm.label_no expno,
               slm.cust_no,
               bc.cust_name,
               slm.label_no,
               sld.article_no,
               ba.article_name,
               ba.barcode,
               sum(sld.qty) qty
          from stock_label_mhty        slm,
               stock_label_dhty        sld,
               bdef_defcust            bc,
               bdef_defarticle         ba,
               stock_label_arrange_log t
         where slm.enterprise_no = sld.enterprise_no
           and slm.container_no = sld.container_no
           and slm.enterprise_no = bc.enterprise_no
           and slm.cust_no = bc.cust_no
           and sld.article_no = ba.article_no
           and slm.enterprise_no = t.enterprise_no
           and slm.label_no = t.label_no
           and t.arrange_type = '4'
           and slm.use_type = 1
           and slm.status not like 'F%'*/
         group by m.enterprise_no,
                  m.warehouse_no,
                  m.owner_no,
                  trunc(m.rgst_date),
                  d.label_no,
                  m.cust_no,
                  bc.cust_name,
                  d.article_no,
                  ba.article_name,
                  ba.barcode)
 order by expno, cust_no

/

