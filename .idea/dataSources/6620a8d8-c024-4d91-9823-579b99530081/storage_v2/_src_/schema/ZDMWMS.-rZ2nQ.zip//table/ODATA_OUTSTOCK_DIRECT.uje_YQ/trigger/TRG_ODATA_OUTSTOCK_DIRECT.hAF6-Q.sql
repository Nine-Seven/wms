create trigger TRG_ODATA_OUTSTOCK_DIRECT
    before insert
    on ODATA_OUTSTOCK_DIRECT
    for each row
declare
i_id integer;
begin
select SEQ_ODATA_OUTSTOCK_DIRECT.nextval into i_id from dual;
:NEW.DIRECT_SERIAL := i_id;
end;


/

