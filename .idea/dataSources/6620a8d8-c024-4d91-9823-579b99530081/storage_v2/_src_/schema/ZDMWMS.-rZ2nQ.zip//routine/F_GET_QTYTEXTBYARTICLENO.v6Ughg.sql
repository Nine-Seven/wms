create function        f_get_QtyTextByArticleNo(v_enterprise_no IN VARCHAR2,v_ownerNO IN VARCHAR2, v_articleNO in varchar2,v_qty in NUMBER)
    return varchar2
  is
  v_text            VARCHAR(256);
  v_boxpacking      bdef_article_packing.packing_qty%TYPE;--箱包装
  v_boxpackingUnit  bdef_article_packing.packing_unit%TYPE;--箱包装单位
  v_Qminpacking     bdef_defarticle.qmin_operate_packing%TYPE;--最小操作包装
  v_QminpackingUnit bdef_defarticle.qmin_operate_packing_unit%TYPE;--最小操作包装单位
  v_unitpacking     bdef_defarticle.unit_packing%TYPE;--基本包装
  v_Unit            bdef_defarticle.unit%TYPE;--基本包装单位

  n_qty             NUMBER;--记录还需要换算的数量
  BEGIN
     v_boxpacking := 0;
     v_Qminpacking := 0;
     v_unitpacking := 0;
     v_boxpackingUnit:='';
     v_QminpackingUnit:='';
     v_Unit:='';
     n_qty := v_qty;
     --此函数用于获取数量对应的文本信息，主要用于报表显示
     --Add by sunl 2016年8月6日

     --1. 获取当前传入商品对应的箱包装信息（包装数量，包装单位）
     BEGIN
       SELECT p.packing_qty,p.packing_unit INTO v_boxpacking,v_boxpackingUnit
       FROM bdef_article_packing p
       WHERE p.article_no = v_articleNO AND p.enterprise_no = v_enterprise_no;
     EXCEPTION
       WHEN OTHERS THEN
         v_boxpacking:=0;--这里如果取到多个箱包装，或者没有取到箱包装，直接给0，不考虑箱规格
     END;
     --2. 获取当前商品对应的最小操作包装、基本包装 及其单位
     BEGIN
       SELECT a.qmin_operate_packing,a.qmin_operate_packing_unit,a.unit_packing,a.unit
        INTO v_Qminpacking,v_QminpackingUnit,v_unitpacking,v_Unit
       FROM bdef_defarticle a
       WHERE a.article_no = v_articleNO AND a.enterprise_no = v_enterprise_no AND a.owner_no = v_ownerNO;
     EXCEPTION
       WHEN OTHERS THEN
         v_Qminpacking:=0;--这里如果没有取到，则直接给0
         v_unitpacking:=0;
     END;
     --3.校验
     BEGIN
       if(n_qty = 0) THEN
         RETURN '0';
       END IF;

       IF(v_boxpacking = 0 AND v_Qminpacking = 0 AND v_unitpacking = 0) THEN
          RETURN '' || n_qty;
       END IF;
     END;

     --4. 换算当前传入数量
     BEGIN
       IF(v_boxpacking != 0) THEN
          --如果箱包装数不为0，则需要换算箱数
          IF(v_Qminpacking !=0 OR v_unitpacking != 0) THEN
            --只要存在基本包装或者最小操作包装，那么这里重算剩余数量
            if(FLOOR(n_qty / v_boxpacking) != 0) THEN
              v_text := v_text || FLOOR(n_qty / v_boxpacking) || v_boxpackingUnit;
              n_qty := n_qty - (FLOOR(n_qty / v_boxpacking) * v_boxpacking);
            END IF;
          ELSE
            v_text := v_text || (n_qty / v_boxpacking) || v_boxpackingUnit;
            n_qty := 0;--只有箱包装数，则剩余量直接置为0
          END IF;
       END IF;

       IF(v_Qminpacking != 0 AND n_qty != 0) THEN
          --如果最小操作包装数不为0，则需要换算最小操作包装数
          IF(v_unitpacking != 0) THEN
            --只要存在基本包装，那么这里重算剩余数量
            IF(FLOOR(n_qty / v_Qminpacking) != 0) THEN
              v_text := v_text || FLOOR(n_qty / v_Qminpacking) || v_QminpackingUnit;
              n_qty := n_qty - (FLOOR(n_qty / v_Qminpacking) * v_Qminpacking);
            END IF;
          ELSE
            v_text := v_text || (n_qty / v_Qminpacking) || v_QminpackingUnit;
            n_qty := 0;--只有最小操作包装数，则剩余量直接置为0
          END IF;
       END IF;

       IF(v_unitpacking != 0 AND n_qty != 0) THEN
          --如果基本包装数不为0，则需要换算基本包装数
          v_text := v_text || (n_qty / v_unitpacking) || v_Unit;
       END IF;
     END;

     return v_text;
  end;


/

